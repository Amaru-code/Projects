# MCR DATENBRUECKE 0.8.1-rc.74

Kompakte Vollversion mit Schnellinstallation, Rueckweg, Master Run, Intel-Navigation, Phase-1- und Phase-2-Bearbeitung und per-Ticket-Journalschutz.

**RC74:** Altes SEND_INTENT wird bei DB-/DB+-Faellen nicht mehr allein wegen einer individuellen dritten `Moechte ...`-Anliegenzeile abgewiesen. Es bleiben erforderlich: alter unveraenderter USC-Hash, ein eindeutiger gebundener COMARCH-Ausgang und exakte gespeicherte Beschreibung. Kein Neuversand, kein pauschales Entsperren.

Menue 14 liefert zusaetzlich `P2_TEXTSTRUKTUR` fuer blockierte Tickets, ohne Nachrichteninhalte preiszugeben. Menue 12 bearbeitet die geprueften eigenen Intel-Tickets. `docs/RC74_RELEASE.md` enthaelt die Einzelheiten und Grenzen.

Installation: neue START.cmd -> Menue 1; danach ausschliesslich START.cmd aus dem **installierten** Ordner benutzen. Alte lokale `.runtime`-/`private_data`-Daten, Mapping, Browserprofil und Archiv bleiben beim Softwareupdate erhalten.
