# MCR DATENBRUECKE 0.8.1-rc.76

Kompaktes Vollpaket auf Basis des hochgeladenen RC75, mit dem bestehenden Installer, Software-Rueckweg und unveraenderter Phase-1-Fachbearbeitung.

## Phase 2

Die gespeicherte zusaetzliche Beschreibung bestimmt den Arbeitsweg: Phase-1-Status erforderlich; Bearbeitet/Reviewed verhindert Doppelbearbeitung; DB/DB+ direkt an Mark; Kontoauszug fuer DC/PP+ zum Review; privater MBC-Login mit bestehendem Antwortentwurf zum Review; unbekannte `Moechte ...`-Anfragen direkt an Mark.

Alte SEND-Journale bleiben unveraendert erhalten, werden aber nicht mehr als alleinige Sperre fuer interne Phase-2-Arbeit benutzt. Keine neue E-Mail. Offene Weiterleitungen und unklare Phase-2-Schreibaktionen bleiben gegen Wiederholung geschuetzt.

Menue 12 integriert die Pruefung vorhandener Kontoauszug-PDFs. Fehlende PDFs muessen weiterhin mit den vorhandenen Generatorprogrammen erstellt werden; RC76 erfindet keine Eingabeschnittstelle. Der Bot zeigt Pfade und erwartete Dateien und setzt nach der Inhaltspruefung mit dem vorhandenen Anhaenge-/Review-Ablauf fort.

Vollstaendige Regeln, bekannte Altformate, Testgrenzen und Installation: `docs/RC76_RELEASE.md`.

Installation: ZIP separat entpacken, neue START.cmd -> Menue 1; anschliessend nur START.cmd aus dem installierten Ordner. Danach Menue 14 (nur lesen) oder Menue 12 (echte Phase-2-Bearbeitung). private_data, Konfiguration, Browserprofil, Laufjournale und Archive bleiben lokal erhalten.

Die in RC75 ergaenzte Namenssuche und Identitaetsbestaetigung bleiben bestehen. Aeltere Release-Dokumente beschreiben die Historie, nicht die aktuelle Phase-2-Zulassungsregel.
