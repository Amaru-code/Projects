# LenWork – Inbox-Rueckblick ohne 50er-Gesamtlimit

## Status dieses Pakets
- Der vorhandene `msgraph_email`-Wrapper wurde nur aus dem vom Nutzer bereitgestellten LenWork-Protokoll als `count <= 50` beschrieben. Die LenWork-Tool-Schemas liegen diesem Paket nicht vor.
- `graph_pager.js` ist ein FUNKTIONIERENDER und lokal gegen MOCK-Daten getesteter Microsoft-Graph-GET-Paginator (Node.js 18+), **kein** bereits installierter LenWork-MCP-Connector.
- Es gab KEINEN Zugriff auf echte Microsoft-365-Mails, die LenWork-Integration oder ihren OAuth-Token. Produktive Lauffaehigkeit in LenWork ist daher nicht bestaetigt.

## Was liegt bei?
- `SKILL.md`: gesamte ueberarbeitete Anweisung mit echtem Coverage-Gate, Graph-Paging und Fail-Closed-Fallback.
- `absender`: vorhandene Absenderregeln mit verdeutlichten Ausnahme-Prioritaeten (Platzhalter weiterhin ersetzen).
- `graph_pager.js`: ausschliesslich Microsoft Graph GET, `$select`, `$filter`, `$top`, `@odata.nextLink`, Deduplizierung, 429-Retry, Paginierungs-Sicherheitschecks, selektives Volltext-GET.
- `tests/test_graph_pager.js`: synthetische Tests fuer 0 bis 1150 Mails und Fehlerfaelle.
- `LENWORK_DIAGNOSTIK_PROMPT.md`: fertig formulierter Diagnoseauftrag fuer LenWork.

## Jetzt in LenWork (empfohlen)
1. Back-up des bestehenden Skills erstellen; dessen ORIGINAL-YAML-Frontmatter bei Bedarf behalten.
2. Zuerst `LENWORK_DIAGNOSTIK_PROMPT.md` in einen **neuen** LenWork-Chat kopieren und Antwort pruefen.
3. Wenn ein Graph-GET-Tool inkl. `@odata.nextLink` zur Verfuegung steht: ueber `SKILL.md` Pfad A einsetzen; `graph_pager.js` nur dann als Script nutzen, wenn Code-Execution, Netzwerk und freigegebener Token-Provider wirklich vorhanden sind.
4. Andernfalls `SKILL.md` Pfad B verwenden – auf >100 erweitert, aber nur bei nachweisbarer Abdeckung. Mit 50 Treffern an einer unteilbaren Grenze als INCOMPLETE abbrechen.
5. Falls beide Wege nicht moeglich sind, bei interner IT/LenWork-Administration einen READ-ONLY-Graph-MCP-Connector anfragen, der Paging freigibt. Vorhandene Microsoft-365-Integration hat nicht zwangslaufig einen an frei hinzugesetzten JavaScript-Code delegierbaren OAuth-Token.

## Connector-Sollvertrag fuer die IT
- Delegated OAuth 2.0 im Nutzerkontext, ausschliesslich noetige Scopes, fuer Volltext `Mail.Read` (nicht `Mail.ReadWrite`).
- GET erlaubt: `/v1.0/me/mailFolders/inbox/messages?...` sowie `/v1.0/me/messages/{id}?$select=...` und optional `sentitems` fuer threadbasierte Erledigt-Pruefung.
- `@odata.nextLink` wird unveraendert durchgereicht oder serverseitig vollstaendig verfolgt.
- Ausgabe pro Request als strukturierte Daten mit Count, Cursor/NextLink, ErrorCode und Read-Only-Audit.
- Keine POST/PATCH/DELETE fuer E-Mails, kein Dauerexport, keine Tokens im Chat oder Skill-Code.
- Unternehmens-IT/DLP/Datenschutzfreigabe erforderlich, bevor produktive personenbezogene E-Mail-Daten in neue Verarbeitungspfade gelangen.

## Lokale Unit-Tests (ohne Outlook-Zugang)
```
node tests/test_graph_pager.js
```

## Eigenstaendige Nutzung des JS-Paginators ausserhalb LenWork (nur wenn von IT freigegeben)
Node 18+, ein separat und autorisiert beschafftes Graph Access Token mit delegated `Mail.Read`, keine weiteren NPM-Pakete notwendig.

```powershell
# Nur innerhalb einer genehmigten Unternehmensumgebung nutzen.
# Token NICHT in den Chat, in Skripte, in Projekt-ZIPs oder in Logdateien schreiben.
# Bereits vom zugelassenen Token-Provider gesetzte Umgebungsvariable GRAPH_ACCESS_TOKEN verwenden.
node .\graph_pager.js --start "2026-10-01T00:00:00+02:00" --end "2026-10-12T00:00:00+02:00" --out ".\private_inbox_result.json" --page-size 100 --include-read
```

Der Parameter `--include-read` schliesst fuer explizite Abwesenheits-Zeitraeume auch bereits gelesene Nachrichten ein. Ohne ihn werden ausschliesslich ungelesene Mails abgefragt (Default-Scope).

Der Befehl oben ist kein Weg, einen Token von der LenWork-Integration zu extrahieren. Ohne autorisiertes Token wird er sicher abbrechen. Auf der lokalen Festplatte werden personenbezogene Mail-Metadaten in der explizit genannten JSON-Datei gespeichert; Aufbewahrung/Loeschung nach Firmenrichtlinie.

Die JSON-Datei nicht blind in einen Chat hochladen. Zur Priorisierung sollte LenWork die Daten ueber einen autorisierten Tool-/Connector-Kanal erhalten.

## Die ehrliche Vollstaendigkeitsaussage
Graph-Paging bis `@odata.nextLink` fehlt belegt, dass alle Seiten **dieser Abfrage** abgeholt wurden. Bei parallelen Aenderungen des Mailboxbestands ist das keine transaktionale Momentaufnahme. Fuer einen starren Stand ist ein inkrementeller/snapshotfaehiger Prozess mit entsprechendem Design erforderlich.

## Microsoft-Quellen
- https://learn.microsoft.com/en-us/graph/api/user-list-messages?view=graph-rest-1.0
- https://learn.microsoft.com/en-us/graph/paging
- https://learn.microsoft.com/en-us/graph/throttling
- https://learn.microsoft.com/en-us/graph/api/message-get?view=graph-rest-1.0
