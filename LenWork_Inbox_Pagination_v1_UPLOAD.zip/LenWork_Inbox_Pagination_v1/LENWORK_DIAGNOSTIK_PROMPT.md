# In einen neuen LenWork-Chat kopieren (READ-ONLY Diagnose)

Prüfe bitte zuerst technisch, welche E-Mail-Abrufmöglichkeiten meine verbundene Microsoft-365-Integration in diesem Chat tatsächlich freigibt. NICHTS verändern, nichts schreiben oder senden, keine Zugangsdaten ausgeben.

1. Prüfe anhand der real verfügbaren Tool-Schemas, welche Parameter `msgraph_email` für list/search akzeptiert (insbesondere `count`, `date_range`, Zeitgranularität, `nextLink`, `skip`, `pageToken`). Erfinde keine Parameter.
2. Prüfe, ob ein anderes freigegebenes Tool oder ein MCP-/Custom-Connector authentifizierte Microsoft-Graph-GET-Requests unterstützt und das rohe JSON einschließlich `@odata.nextLink` liefert. Nutze die bestehende Verbindung nur, soweit dafür explizit ein Tool existiert.
3. Prüfe, ob JavaScript aus Skill-Dateien in dieser LenWork-Umgebung ausführbar ist, mit welchen Laufzeit-/Netzwerkrechten, und ob ein zulässiger OAuth-Token-Provider verfügbar ist. Aus bloßer Dateiablage keine Ausführung ableiten.
4. Führe noch keinen großen Mail-Abruf durch. Falls ein harmloser GET-Test für die Tool-Erkennung nötig ist, nutze nur Inbox-Metadaten und minimalen Umfang (max. 2 Nachrichten). Keine Betreffs, Mailtexte, persönlichen Adressen oder Token im Diagnosebericht ausgeben.
5. Antworte als technische Matrix mit den Spalten: Möglichkeit | Verifiziert? | Max pro Aufruf | Echte Pagination? | Token verfügbar? | Offene Voraussetzung.
6. Gib abschließend exakt einen empfohlenen Implementierungspfad an: A = direkter Graph-GET mit @odata.nextLink, B = rekursive Zeitintervall-Partition via msgraph_email, C = neue Unternehmensfreigabe / Custom-MCP-Connector notwendig.

Wichtig: Die Anforderung ist, >100 E-Mails vollständig zu erfassen und zu priorisieren, nicht nur den ersten 50er-Batch. Eine unbewiesene Vollständigkeit ist ein FAIL, kein PASS.
