/**
 * Microsoft Graph Inbox paginator for an authorized, READ-ONLY enterprise workflow.
 * Node.js 18+ / CommonJS. No external dependencies or authentication bypass.
 *
 * IMPORTANT: Adding this .js file to a LenWork Skill does not imply that LenWork
 * executes JavaScript or makes Microsoft 365 integration tokens available.
 * An approved Graph-capable execution environment and delegated Mail.Read token
 * are prerequisites for live calls.
 *
 * Exports: collectMessages, getMessageFullText, buildListUrl, GraphPagerError.
 */
'use strict';

const GRAPH_ORIGIN = 'https://graph.microsoft.com';
const VERSION = '/v1.0';
const DEFAULT_FIELDS = [
  'id', 'internetMessageId', 'receivedDateTime', 'sentDateTime',
  'from', 'toRecipients', 'ccRecipients', 'subject', 'isRead',
  'importance', 'hasAttachments', 'conversationId', 'bodyPreview', 'webLink'
];

class GraphPagerError extends Error {
  constructor(code, message) {
    super(message);
    this.name = 'GraphPagerError';
    this.code = code;
  }
}

function assertDateTime(value, field) {
  if (typeof value !== 'string' || !/(?:Z|[+-]\d{2}:\d{2})$/i.test(value)) {
    throw new GraphPagerError('INVALID_SCOPE', `${field} muss ein ISO-8601-Zeitpunkt mit UTC-Offset sein.`);
  }
  const epoch = Date.parse(value);
  if (!Number.isFinite(epoch)) {
    throw new GraphPagerError('INVALID_SCOPE', `${field} ist kein gueltiger Zeitpunkt.`);
  }
  return new Date(epoch).toISOString();
}

function validateFolder(folder) {
  if (!['inbox', 'sentitems'].includes(folder)) {
    throw new GraphPagerError('INVALID_FOLDER', 'Nur inbox oder sentitems sind freigegeben.');
  }
  return folder;
}

function buildListUrl(options = {}) {
  const { folder = 'inbox', start, end, unreadOnly = folder === 'inbox', pageSize = 100 } = options;
  validateFolder(folder);
  if (!Number.isInteger(pageSize) || pageSize < 1 || pageSize > 1000) {
    throw new GraphPagerError('INVALID_PAGE_SIZE', 'pageSize muss zwischen 1 und 1000 liegen.');
  }
  const startISO = assertDateTime(start, 'start');
  const endISO = assertDateTime(end, 'end');
  if (Date.parse(startISO) >= Date.parse(endISO)) {
    throw new GraphPagerError('INVALID_SCOPE', 'start muss vor end liegen.');
  }
  const dateField = folder === 'inbox' ? 'receivedDateTime' : 'sentDateTime';
  const clauses = [
    `${dateField} ge ${startISO}`,
    `${dateField} lt ${endISO}`,
  ];
  if (unreadOnly) clauses.push('isRead eq false');
  const path = `${VERSION}/me/mailFolders/${folder}/messages`;
  const url = new URL(path, GRAPH_ORIGIN);
  url.searchParams.set('$select', DEFAULT_FIELDS.join(','));
  url.searchParams.set('$filter', clauses.join(' and '));
  url.searchParams.set('$orderby', `${dateField} desc`);
  url.searchParams.set('$top', String(pageSize));
  return url.toString();
}

function validateGraphUrl(candidate, expectedPath) {
  let parsed;
  try {
    parsed = new URL(candidate);
  } catch {
    throw new GraphPagerError('UNSAFE_NEXTLINK', 'Ungueltige Pagination-URL.');
  }
  if (parsed.origin !== GRAPH_ORIGIN || parsed.username || parsed.password ||
      parsed.pathname.toLowerCase() !== expectedPath.toLowerCase()) {
    throw new GraphPagerError('UNSAFE_NEXTLINK', 'Pagination-URL ausserhalb des autorisierten Graph-Endpunkts.');
  }
  return parsed.toString();
}

function parseRetryAfter(value) {
  if (value == null) return null;
  const seconds = Number(value);
  if (Number.isFinite(seconds) && seconds >= 0) return seconds * 1000;
  const timestamp = Date.parse(value);
  return Number.isFinite(timestamp) ? Math.max(0, timestamp - Date.now()) : null;
}

async function defaultSleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Internal GET-only client, with bounded 429/503/502/504 retries.
 * getAccessToken (if supplied) is called for each request; callers handle auth.
 */
async function graphGet(url, options = {}) {
  const {
    accessToken, getAccessToken,
    fetchImpl = globalThis.fetch,
    sleepImpl = defaultSleep,
    maxRetries = 5,
    expectedPath,
  } = options;
  if (typeof fetchImpl !== 'function') {
    throw new GraphPagerError('NO_FETCH', 'Kein HTTP-fähiger JavaScript-Executor vorhanden.');
  }
  validateGraphUrl(url, expectedPath);
  if (!Number.isInteger(maxRetries) || maxRetries < 0 || maxRetries > 20) {
    throw new GraphPagerError('INVALID_CONFIG', 'Ungueltiges Retry-Limit.');
  }
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    const token = typeof getAccessToken === 'function' ? await getAccessToken() : accessToken;
    if (typeof token !== 'string' || !token.trim()) {
      throw new GraphPagerError('AUTH_REQUIRED', 'Autorisiertes Microsoft-Graph-Token fehlt.');
    }
    let response;
    try {
      response = await fetchImpl(url, {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: 'application/json',
          Prefer: 'outlook.body-content-type="text"'
        }
      });
    } catch (error) {
      throw new GraphPagerError('NETWORK_ERROR', `Graph-Verbindung fehlgeschlagen: ${error.message}`);
    }
    if (response.ok) {
      try {
        return await response.json();
      } catch {
        throw new GraphPagerError('INVALID_RESPONSE', 'Graph lieferte keine gueltige JSON-Antwort.');
      }
    }
    const retryable = [429, 502, 503, 504].includes(response.status);
    if (retryable && attempt < maxRetries) {
      const header = response.headers && typeof response.headers.get === 'function'
        ? response.headers.get('retry-after') : null;
      const waitMs = parseRetryAfter(header) ?? Math.min(30000, 1000 * 2 ** attempt);
      if (waitMs > 300000) {
        throw new GraphPagerError('RETRY_TOO_LONG', 'Graph fordert mehr als 5 Minuten Wartezeit.');
      }
      await sleepImpl(waitMs);
      continue;
    }
    const kind = response.status === 401 || response.status === 403 ? 'ACCESS_DENIED'
      : retryable ? 'GRAPH_THROTTLED' : 'GRAPH_HTTP_ERROR';
    throw new GraphPagerError(kind, `Graph GET fehlgeschlagen (HTTP ${response.status}); keine Vollstaendigkeit behaupten.`);
  }
  throw new GraphPagerError('UNREACHABLE', 'Interner Retry-Fehler.');
}

/**
 * Traverse ALL Graph pages; never stops merely because 50/100/1000 items arrived.
 * Returns complete=true only after an absent @odata.nextLink.
 * Never calls message write endpoints.
 */
async function collectMessages(options = {}) {
  const {
    folder = 'inbox', start, end,
    unreadOnly = folder === 'inbox', pageSize = 100,
    maxPages = 1000, ...authAndFetch
  } = options;
  if (!Number.isInteger(maxPages) || maxPages < 1 || maxPages > 100000) {
    throw new GraphPagerError('INVALID_CONFIG', 'maxPages ist ausserhalb des freigegebenen Bereichs.');
  }
  const initialUrl = buildListUrl({ folder, start, end, unreadOnly, pageSize });
  const allowedPath = new URL(initialUrl).pathname;
  const visited = new Set();
  const ids = new Set();
  const messages = [];
  let pagesRead = 0;
  let rawCount = 0;
  let next = initialUrl;
  while (next !== null) {
    if (pagesRead >= maxPages) {
      throw new GraphPagerError('PAGE_SAFETY_LIMIT', `Mehr als ${maxPages} Seiten; Erfassung NICHT vollstaendig.`);
    }
    next = validateGraphUrl(next, allowedPath);
    if (visited.has(next)) {
      throw new GraphPagerError('PAGINATION_LOOP', 'Wiederholter nextLink; Erfassung NICHT vollstaendig.');
    }
    visited.add(next);
    const payload = await graphGet(next, { ...authAndFetch, expectedPath: allowedPath });
    if (!payload || !Array.isArray(payload.value)) {
      throw new GraphPagerError('INVALID_RESPONSE', 'Graph-Antwort ohne value-Array.');
    }
    pagesRead++;
    rawCount += payload.value.length;
    for (const item of payload.value) {
      if (!item || typeof item.id !== 'string' || !item.id) {
        throw new GraphPagerError('INVALID_MESSAGE', 'Nachricht ohne eindeutige Graph-ID.');
      }
      if (!ids.has(item.id)) {
        ids.add(item.id);
        messages.push(item);
      }
    }
    const returnedNext = payload['@odata.nextLink'];
    if (returnedNext !== undefined && returnedNext !== null &&
        (typeof returnedNext !== 'string' || !returnedNext)) {
      throw new GraphPagerError('INVALID_NEXTLINK', 'Unbrauchbarer @odata.nextLink.');
    }
    next = returnedNext || null;
  }
  const field = folder === 'inbox' ? 'receivedDateTime' : 'sentDateTime';
  messages.sort((a, b) => Date.parse(b[field] || 0) - Date.parse(a[field] || 0));
  return {
    status: 'COMPLETE_GRAPH_PAGING',
    complete: true,
    scope: { folder, start: assertDateTime(start, 'start'), end: assertDateTime(end, 'end'), unreadOnly },
    pagesRead,
    rawCount,
    uniqueCount: messages.length,
    duplicateCount: rawCount - messages.length,
    caveat: 'Der Postfachbestand kann sich waehrend des Abrufs aendern; kein atomarer Snapshot.',
    messages
  };
}

/** Read one message body without changing isRead (only HTTP GET). */
async function getMessageFullText(options = {}) {
  const { messageId, ...authAndFetch } = options;
  if (typeof messageId !== 'string' || !messageId.length) {
    throw new GraphPagerError('INVALID_MESSAGE_ID', 'Message-ID fehlt.');
  }
  const path = `${VERSION}/me/messages/${encodeURIComponent(messageId)}`;
  const url = new URL(path, GRAPH_ORIGIN);
  url.searchParams.set('$select', 'id,subject,conversationId,body');
  const data = await graphGet(url.toString(), { ...authAndFetch, expectedPath: path });
  if (!data || !data.body || typeof data.body.content !== 'string') {
    throw new GraphPagerError('INVALID_RESPONSE', 'Kein auswertbarer Nachrichteninhalt.');
  }
  return {
    id: data.id,
    subject: data.subject,
    conversationId: data.conversationId,
    bodyContentType: data.body.contentType,
    bodyText: data.body.content
  };
}

module.exports = { collectMessages, getMessageFullText, buildListUrl, GraphPagerError };

if (require.main === module) {
  (async () => {
    const args = process.argv.slice(2);
    if (args.includes('--help') || args.length === 0) {
      console.log('READ-ONLY | node graph_pager.js --start 2026-10-01T00:00:00+02:00 --end 2026-10-12T00:00:00+02:00 --out output.json [--page-size 100] [--include-read]');
      console.log('Vorher: autorisiertes GRAPH_ACCESS_TOKEN als Umgebungsvariable setzen (NIEMALS im Chat posten).');
      process.exit(0);
    }
    function arg(name) {
      const idx = args.indexOf(name);
      return idx >= 0 ? args[idx + 1] : undefined;
    }
    const start = arg('--start');
    const end = arg('--end');
    const out = arg('--out');
    const pageSize = arg('--page-size') ? Number(arg('--page-size')) : 100;
    const unreadOnly = !args.includes('--include-read');
    if (!start || !end || !out) throw new GraphPagerError('MISSING_ARGS', '--start, --end und --out sind erforderlich.');
    const result = await collectMessages({ start, end, pageSize, unreadOnly, accessToken: process.env.GRAPH_ACCESS_TOKEN });
    const fs = require('node:fs');
    const path = require('node:path');
    const target = path.resolve(out);
    // Exclusive file creation: never silently overwrite potentially sensitive data.
    fs.writeFileSync(target, JSON.stringify(result, null, 2), { flag: 'wx', mode: 0o600 });
    console.log(`COMPLETE: ${result.uniqueCount} E-Mails, ${result.pagesRead} Seiten. Datei: ${target}`);
    console.log('Vertraulich: enthält E-Mail-Metadaten; nur entsprechend Unternehmensrichtlinie weitergeben.');
  })().catch(error => {
    console.error(`ABBRUCH (${error.code || 'ERROR'}): ${error.message}`);
    process.exitCode = 1;
  });
}
