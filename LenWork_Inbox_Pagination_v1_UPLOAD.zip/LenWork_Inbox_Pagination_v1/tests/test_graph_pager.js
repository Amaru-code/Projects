'use strict';
const assert = require('node:assert/strict');
const { collectMessages, buildListUrl, getMessageFullText } = require('../graph_pager');

const START = '2026-10-01T00:00:00+02:00';
const END = '2026-10-12T00:00:00+02:00';
const mkMails = count => Array.from({ length: count }, (_, n) => ({
  id: `synthetic-${n}`,
  receivedDateTime: new Date(Date.parse('2026-10-11T12:00:00Z') - n * 60000).toISOString(),
  subject: `SYNTHETIC-${n}`, from: { emailAddress: { address: 'synthetic@example.invalid' } },
  bodyPreview: 'Synthetic test only', isRead: false,
  hasAttachments: false, importance: 'normal', conversationId: `thread-${Math.floor(n / 3)}`
}));

function mockPagedGraph(count, opts = {}) {
  const messages = mkMails(count);
  let attempts = 0;
  const methods = [];
  const fetchImpl = async (url, request) => {
    attempts++;
    methods.push(request.method);
    const u = new URL(url);
    assert.equal(u.origin, 'https://graph.microsoft.com');
    assert.equal(u.pathname, '/v1.0/me/mailFolders/inbox/messages');
    assert.match(u.searchParams.get('$filter'), /isRead eq false/);
    assert.match(u.searchParams.get('$orderby'), /receivedDateTime desc/);
    assert.equal(request.headers.Authorization, 'Bearer fake-unit-test-only');
    if (opts.throttleFirst && attempts === 1) {
      return new Response('', { status: 429, headers: { 'Retry-After': '0' } });
    }
    const offset = Number(u.searchParams.get('$skip') || 0);
    const top = Number(u.searchParams.get('$top') || 100);
    const items = messages.slice(offset, offset + top);
    const next = offset + top < messages.length ? (() => {
      const copy = new URL(u.toString());
      copy.searchParams.set('$skip', String(offset + top));
      return copy.toString();
    })() : null;
    return Response.json({ value: items, ...(next ? { '@odata.nextLink': next } : {}) });
  };
  return { fetchImpl, methods, getAttempts: () => attempts };
}

async function testCounts() {
  for (const [count, pageSize, expectedPages] of [
    [0, 100, 1], [50, 50, 1], [100, 100, 1], [101, 100, 2],
    [137, 50, 3], [251, 100, 3], [650, 100, 7], [1150, 200, 6]
  ]) {
    const mock = mockPagedGraph(count);
    const result = await collectMessages({
      start: START, end: END, pageSize, accessToken: 'fake-unit-test-only', fetchImpl: mock.fetchImpl
    });
    assert.equal(result.complete, true);
    assert.equal(result.uniqueCount, count);
    assert.equal(result.pagesRead, expectedPages);
    assert.equal(result.duplicateCount, 0);
    assert.ok(mock.methods.every(method => method === 'GET'));
    console.log(`PASS: ${count} synthetic messages / ${expectedPages} Graph page(s)`);
  }
}

async function testThrottle() {
  const mock = mockPagedGraph(151, { throttleFirst: true });
  const delays = [];
  const result = await collectMessages({
    start: START, end: END, accessToken: 'fake-unit-test-only',
    fetchImpl: mock.fetchImpl, sleepImpl: async ms => { delays.push(ms); }
  });
  assert.equal(result.uniqueCount, 151);
  assert.equal(mock.getAttempts(), 3);
  assert.deepEqual(delays, [0]);
  console.log('PASS: Graph HTTP 429 Retry-After');
}

async function testUnsafeNextLink() {
  const fetchImpl = async () => Response.json({
    value: [{ id: 'one', receivedDateTime: '2026-10-09T00:00:00Z' }],
    '@odata.nextLink': 'https://attacker.example/steal'
  });
  await assert.rejects(collectMessages({
    start: START, end: END, accessToken: 'fake-unit-test-only', fetchImpl
  }), { code: 'UNSAFE_NEXTLINK' });
  console.log('PASS: cross-host nextLink blocked');
}

async function testLoop() {
  let firstUrl;
  const fetchImpl = async url => {
    firstUrl = firstUrl || url;
    return Response.json({ value: [{ id: 'one', receivedDateTime: '2026-10-09T00:00:00Z' }],
      '@odata.nextLink': firstUrl });
  };
  await assert.rejects(collectMessages({
    start: START, end: END, accessToken: 'fake-unit-test-only', fetchImpl
  }), { code: 'PAGINATION_LOOP' });
  console.log('PASS: paging loop blocked');
}

async function testSafetyAndBody() {
  await assert.rejects(collectMessages({
    start: START, end: END, accessToken: 'fake-unit-test-only', maxPages: 1,
    fetchImpl: mockPagedGraph(101).fetchImpl
  }), { code: 'PAGE_SAFETY_LIMIT' });
  const url = buildListUrl({ start: START, end: END });
  assert.equal(new URL(url).searchParams.get('$top'), '100');
  await assert.rejects(collectMessages({ start: START, end: END }), { code: 'AUTH_REQUIRED' });
  const methods = [];
  const msg = await getMessageFullText({
    messageId: 'ID=/+', accessToken: 'fake-unit-test-only',
    fetchImpl: async (url, req) => {
      methods.push(req.method);
      assert.equal(new URL(url).pathname, '/v1.0/me/messages/ID%3D%2F%2B');
      assert.equal(req.headers.Prefer, 'outlook.body-content-type="text"');
      return Response.json({ id: 'ID=/+', body: { contentType: 'text', content: 'Synthetisch' } });
    }
  });
  assert.equal(msg.bodyText, 'Synthetisch');
  assert.deepEqual(methods, ['GET']);
  console.log('PASS: safety stop, missing authentication, get body READ-ONLY');
}

(async () => {
  await testCounts();
  await testThrottle();
  await testUnsafeNextLink();
  await testLoop();
  await testSafetyAndBody();
  console.log('ALL TESTS PASS (no real Microsoft 365 calls, no real messages)');
})().catch(e => {
  console.error(e);
  process.exitCode = 1;
});
