import test from 'node:test';import assert from 'node:assert/strict';
import I from '../lib/identity-evidence.cjs';
const p={firstName:'Timm-Peter',lastName:'Mueller'};
const profile={source:'MEMBER_PROFILE_VERIFIED',id:'11412817',firstName:'Timm Peter',lastName:'Müller',display:'Mueller Timm Peter (INTL01-11412817) - Zusatztext',profileIdMatches:true};
test('RC24 structured Member profile accepts precise firstname tokens and surname despite UI suffix',()=>{
 assert.equal(I.requireMatched(profile,p,{expectedId:'11412817'}),true);
});
test('RC24 still blocks explicit MercerID conflict',()=>{
 assert.throws(()=>I.requireMatched(profile,p,{expectedId:'12345678'}),{code:'MEMBER_ID_CONFLICT'});
});
test('RC24 still blocks mismatching surname and forename',()=>{
 assert.throws(()=>I.requireMatched({...profile,firstName:'Daniel'},p,{}),{code:'MEMBER_NAME_MISMATCH'});
 assert.throws(()=>I.requireMatched({...profile,lastName:'Meier'},p,{}),{code:'MEMBER_NAME_MISMATCH'});
});
test('RC24 Member/profile mismatched IDs never pass even when displayed name looks good',()=>{
 assert.throws(()=>I.requireMatched({...profile,source:'MEMBER_PROFILE_CONFLICT',profileIdMatches:false},p,{}),{code:'MEMBER_PROFILE_CONFLICT'});
});
test('RC24 numeric ID alone is still insufficient',()=>{
 assert.throws(()=>I.requireMatched({source:'MEMBER_FIELD',id:'11412817',display:'A. Beispiel (INTL01-11412817)'},p,{}),{code:'MEMBER_NAME_MISMATCH'});
});
