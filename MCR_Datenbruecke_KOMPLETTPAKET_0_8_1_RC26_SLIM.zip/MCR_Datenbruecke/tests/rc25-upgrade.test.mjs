/** Original RC24 -> RC25 retains data, history, and uncertain SEND_INTENT. */
import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';
import {ROOT,temp,putActive,historyFixture} from './helpers.mjs';
import {sha256} from '../lib/core.mjs';import {readZip} from '../lib/zip.mjs';
import {verifyPackage,verifyPrevious,treeDigest} from '../tools/integrity.mjs';
import {planInstall,installSoftware,journals,restoreSoftware} from '../tools/deploy.mjs';
import {VERSION,ledger,writeJSON} from '../lib/control.mjs';
const ZIP=historyFixture('complete-0.8.1-rc.24.zip');
const SHA='3b3c99b1a09e4f24dccea0408e3511bc7e026986a5153dc4fd448ec94b42ce1c';
test('RC25 upgrade from pinned original RC24 and rollback preserve an uncertain send',()=>{
 assert.equal(sha256(ZIP),SHA);
 const d=temp(),target=path.join(d,'MCR_Datenbruecke');fs.mkdirSync(target);
 try{
  const zip=readZip(ZIP);
  for(const name of zip.names){assert.ok(name.startsWith('MCR_Datenbruecke/'));const rel=name.slice('MCR_Datenbruecke/'.length),f=path.join(target,rel);fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,zip.get(name));}
  putActive(target);
  const profile=path.join(target,'.runtime/edge-profile');fs.mkdirSync(profile,{recursive:true});fs.writeFileSync(path.join(profile,'persist'),'test');
  const l=ledger(target);l.begin('87422280','USC 10/ PP+');
  const statePath=path.join(target,'.runtime/beta-control/last-run.json');writeJSON(statePath,{schema:'MCR_BETA_RUN_V1',version:'0.8.1-rc.24',operation:'REAL_RUN',state:'STOP_REVIEW_REQUIRED',pilot:true,runId:'rc24-real'});
  const before={map:treeDigest(path.join(target,'private_data')),profile:treeDigest(profile),journal:fs.readFileSync(l.file),run:fs.readFileSync(statePath)};
  assert.equal(verifyPrevious(target).version,'0.8.1-rc.24');
  const r=installSoftware(planInstall(ROOT,target),{guard:()=>{}});
  assert.equal(r.state,'COMPLETE');assert.equal(verifyPackage(target).version,VERSION);
  assert.equal(treeDigest(path.join(target,'private_data')),before.map);
  assert.equal(treeDigest(profile),before.profile);
  assert.deepEqual(fs.readFileSync(l.file),before.journal);
  assert.deepEqual(fs.readFileSync(statePath),before.run);
  assert.equal(ledger(target).pending.length,1);
  assert.equal(restoreSoftware(journals(target)[0]).state,'ROLLED_BACK');
  assert.equal(verifyPrevious(target).version,'0.8.1-rc.24');
  assert.deepEqual(fs.readFileSync(l.file),before.journal);
 }finally{fs.rmSync(d,{recursive:true,force:true,maxRetries:5,retryDelay:200});}
});
