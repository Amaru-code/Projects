/** Two fictional 1-ticket CDP E2Es: COMARCH remapped MERCER#, delayed history refresh. */
import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';import os from 'node:os';import {spawn} from 'node:child_process';import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
for(const scenario of ['rc26-remapped-subject','rc26-refresh-history']){
 const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC26-SendBrowser-'));
 try{
  for(const d of ['src','lib','examples','config'])fs.cpSync(path.join(root,d),path.join(tmp,d),{recursive:true});
  const cfgFile=path.join(tmp,'config/local-runner-queue-send.json');const cfg=JSON.parse(fs.readFileSync(cfgFile,'utf8'));
  Object.assign(cfg,{runtimeDirectory:'.runtime',profileDirectory:'.runtime/edge-profile',downloadDirectory:'.runtime/downloads',diagnosticDirectory:'diagnostics'});fs.writeFileSync(cfgFile,JSON.stringify(cfg,null,2)+'\n');
  const run=await new Promise((resolve,reject)=>{
   const env={...process.env,MCR_DEMO_SCENARIO:scenario,MCR_DEMO_TICKET_LIMIT:'1'};delete env.NODE_OPTIONS;delete env.NODE_PATH;
   const child=spawn(process.execPath,[path.join(tmp,'src/local-bot-full-run.mjs'),'--demo','--close-browser'],{cwd:tmp,env,stdio:['ignore','pipe','pipe']});
   let out='';const tm=setTimeout(()=>child.kill('SIGKILL'),65000);for(const s of [child.stdout,child.stderr])s.on('data',b=>{out+=b.toString();if(out.length>120000)out=out.slice(-120000);});
   child.once('error',reject);child.once('exit',(code,signal)=>{clearTimeout(tm);resolve({code,signal,out});});
  });
  const d=JSON.parse(fs.readFileSync(path.join(tmp,'diagnostics/last-result.json'),'utf8'));
  assert.equal(run.code,0,run.out.slice(-2200));assert.equal(d.lastError,null);assert.equal(d.loop.processed,1);
  assert.equal(d.send.clicked,true);assert.equal(d.send.verified,true);assert.equal(d.send.ackMode,'BOUND_NEW_OUTGOING_HISTORY');assert.equal(d.send.boundHistoryVerified,true);
  assert.equal(d.send.htmlDialogs,1);assert.equal(d.save.verified,true);assert.equal(d.demoBrowser.sendClicks,1);assert.equal(d.demoBrowser.saveClicks,1);
  if(scenario==='rc26-remapped-subject')assert.equal(d.send.historyBindingOutcome,'SAME_LONG_SUBJECT_WITH_REMAPPED_TICKET_TAG');
  if(scenario==='rc26-refresh-history')assert.ok(d.send.historyRefreshAttempts>=1,'No actual safe refresh');
  console.log('PASS RC26 '+scenario+' SENT_ONCE_SAVED_ONCE');
 }finally{try{fs.rmSync(tmp,{recursive:true,force:true,maxRetries:7,retryDelay:250});}catch(e){if(!['EPERM','EBUSY','ENOTEMPTY','EACCES'].includes(e?.code))throw e;}}
}
