/** Browser-level two-ticket proof for the RC23 real-run blocker. Not run in
 * the normal setup because it launches additional Chromium instances. */
import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';import os from 'node:os';
import {spawn} from 'node:child_process';import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
async function execute(scenario){
 const folder=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC24-E2E-'));
 try{
  for(const dir of ['src','lib','config','examples'])fs.cpSync(path.join(root,dir),path.join(folder,dir),{recursive:true});
  const file=path.join(folder,'config/local-runner-queue-send.json'),config=JSON.parse(fs.readFileSync(file));
  Object.assign(config,{runtimeDirectory:'.runtime',profileDirectory:'.runtime/edge-profile',downloadDirectory:'.runtime/downloads',diagnosticDirectory:'diagnostics'});
  fs.writeFileSync(file,JSON.stringify(config));
  const result=await new Promise((resolve,reject)=>{
   const proc=spawn(process.execPath,[path.join(folder,'src/local-bot-full-run.mjs'),'--demo','--close-browser'],{cwd:folder,env:{...process.env,MCR_DEMO_SCENARIO:scenario},stdio:['ignore','pipe','pipe']});
   let output='';proc.stdout.on('data',v=>output+=v.toString());proc.stderr.on('data',v=>output+=v.toString());
   const timer=setTimeout(()=>proc.kill(),85000);
   proc.once('error',reject);proc.once('exit',code=>{clearTimeout(timer);resolve({code,output});});
  });
  const diag=JSON.parse(fs.readFileSync(path.join(folder,'diagnostics/last-result.json'),'utf8'));
  return {...result,diag};
 }finally{try{fs.rmSync(folder,{recursive:true,force:true,maxRetries:10,retryDelay:150});}catch{}}
}
const success=await execute('rc24-preselected-profile');
assert.equal(success.code,0,success.output);assert.equal(success.diag.lastError,null);
assert.equal(success.diag.loop.processed,2);assert.equal(success.diag.demoBrowser.sendClicks,2);assert.equal(success.diag.demoBrowser.saveClicks,2);
assert.ok(success.output.includes('PASS MEMBER_STRUCTURED_PROFILE_VERIFIED'));
assert.ok(success.output.includes('PASS OFFLINE_DEMO_2_TICKETS_VERIFIED'));
console.log('PASS RC24_PROFILE_ALREADY_SELECTED_TWO_TICKETS_SENT_AND_SAVED_ONCE');
const conflict=await execute('rc24-profile-id-conflict');
assert.notEqual(conflict.code,0);assert.equal(conflict.diag.lastError,'MEMBER_PROFILE_CONFLICT');
assert.equal(conflict.diag.send.clicked,false);assert.equal(conflict.diag.save.clicked,false);
assert.equal(conflict.diag.memberVerification.fieldProfileIdAgreement,false);
console.log('PASS RC24_PROFILE_ID_CONFLICT_NO_SEND_NO_SAVE');
