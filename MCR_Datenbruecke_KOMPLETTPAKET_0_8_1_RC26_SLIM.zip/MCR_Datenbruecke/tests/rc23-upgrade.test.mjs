/** Published RC22 ZIP -> RC23 software-only upgrade with intact identity, mapping and state. */
import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';
import {ROOT,temp,putActive,historyFixture} from './helpers.mjs';
import {sha256} from '../lib/core.mjs';import {readZip} from '../lib/zip.mjs';
import {verifyPackage,verifyPrevious,treeDigest} from '../tools/integrity.mjs';
import {planInstall,installSoftware,journals,restoreSoftware} from '../tools/deploy.mjs';
import {VERSION,ledger,writeJSON,readJSON} from '../lib/control.mjs';
import {blockedTicketIds} from '../lib/run-reset.mjs';
const ZIP=historyFixture('complete-0.8.1-rc.22.zip');
const RC22_SHA='bcc0f8b4c60c95a593cdd993ca5a67de0c0cf96f117ccb7e101edc0763726a13';
test('original RC22 slim ZIP is pinned, RC22 -> RC23 preserves mapping/profile, interrupted run and rollback',()=>{
 assert.equal(sha256(ZIP),RC22_SHA);
 const parent=temp(),target=path.join(parent,'MCR_Datenbruecke');fs.mkdirSync(target);
 try{
  const zip=readZip(ZIP);
  for(const name of zip.names){assert.ok(name.startsWith('MCR_Datenbruecke/'));const rel=name.slice('MCR_Datenbruecke/'.length),f=path.join(target,rel);fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,zip.get(name));}
  putActive(target);const profile=path.join(target,'.runtime/edge-profile');fs.mkdirSync(profile,{recursive:true});fs.writeFileSync(path.join(profile,'profile.sentinel'),'DO_NOT_MODIFY');
  const ctrl=path.join(target,'.runtime/beta-control');fs.mkdirSync(ctrl,{recursive:true});fs.writeFileSync(path.join(ctrl,'last-run.json'),JSON.stringify({schema:'MCR_BETA_RUN_V1',state:'INTERRUPTED_REVIEW_REQUIRED',operation:'REAL_RUN'})+'\n');
  const diagnostic=path.join(target,'diagnostics');fs.mkdirSync(diagnostic);fs.writeFileSync(path.join(diagnostic,'receipt.sentinel'),'DO_NOT_MODIFY');
  const before={mapping:treeDigest(path.join(target,'private_data')),profile:treeDigest(profile),run:sha256(fs.readFileSync(path.join(ctrl,'last-run.json'))),diagnostic:treeDigest(diagnostic)};
  const preserved=()=>{
   assert.equal(treeDigest(path.join(target,'private_data')),before.mapping);
   assert.equal(treeDigest(profile),before.profile);
   assert.equal(sha256(fs.readFileSync(path.join(ctrl,'last-run.json'))),before.run);
   assert.equal(treeDigest(diagnostic),before.diagnostic);
  };
  assert.equal(verifyPrevious(target).version,'0.8.1-rc.22');
  const plan=planInstall(ROOT,target);const r=installSoftware(plan,{guard:()=>{}});
  assert.equal(r.state,'COMPLETE');assert.equal(verifyPackage(target).version,VERSION);preserved();
  const rollback=restoreSoftware(journals(target)[0]);assert.equal(rollback.state,'ROLLED_BACK');assert.equal(verifyPrevious(target).version,'0.8.1-rc.22');preserved();
 }finally{fs.rmSync(parent,{recursive:true,force:true,maxRetries:2});}
});

test('RC23 installation from original RC22 succeeds with orphaned REAL_RUN lock while SEND_INTENT stays protected',()=>{
 const parent=temp(),target=path.join(parent,'MCR_Datenbruecke');fs.mkdirSync(target);
 try{
  const zip=readZip(ZIP);
  for(const name of zip.names){const rel=name.slice('MCR_Datenbruecke/'.length),f=path.join(target,rel);fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,zip.get(name));}
  putActive(target);
  const ctrl=path.join(target,'.runtime/beta-control');fs.mkdirSync(ctrl,{recursive:true});
  const state={schema:'MCR_BETA_RUN_V1',version:'0.8.1-rc.22',operation:'REAL_RUN',state:'RUNNING',
    pid:1999999999,runId:'old-e2e-test',startedAt:'2026-10-28T08:00:00.000Z'};
  const oldLock={schema:'MCR_OPERATION_LOCK_V1',operation:'REAL_RUN',pid:state.pid,
    token:'f'.repeat(48),createdAt:state.startedAt};
  writeJSON(path.join(ctrl,'last-run.json'),state);writeJSON(path.join(ctrl,'operation.lock.json'),oldLock);
  ledger(target).begin('87536494','original description');
  const beforeLedger=fs.readFileSync(path.join(ctrl,'ticket-ledger.json'));
  const profile=path.join(target,'.runtime/edge-profile');fs.mkdirSync(profile,{recursive:true});
  fs.writeFileSync(path.join(profile,'kept'),'same profile');
  const before={mapping:treeDigest(path.join(target,'private_data')),profile:treeDigest(profile),state:fs.readFileSync(path.join(ctrl,'last-run.json'))};
  const plan=planInstall(ROOT,target);const r=installSoftware(plan,{guard:()=>{}});
  assert.equal(r.state,'COMPLETE');assert.equal(r.recoveredStaleLock,true);
  assert.equal(verifyPackage(target).version,VERSION);
  assert.equal(fs.existsSync(path.join(ctrl,'operation.lock.json')),false);
  assert.deepEqual(fs.readFileSync(path.join(ctrl,'ticket-ledger.json')),beforeLedger);
  assert.deepEqual(fs.readFileSync(path.join(ctrl,'last-run.json')),before.state);
  assert.deepEqual(blockedTicketIds(target),['87536494']);
  assert.equal(treeDigest(path.join(target,'private_data')),before.mapping);
  assert.equal(treeDigest(profile),before.profile);
  assert.equal(readJSON(path.join(ctrl,'lock_archive',fs.readdirSync(path.join(ctrl,'lock_archive'))[0])).old.token,oldLock.token);
  const rollback=restoreSoftware(journals(target)[0]);assert.equal(rollback.state,'ROLLED_BACK');
  assert.equal(verifyPrevious(target).version,'0.8.1-rc.22');
  assert.deepEqual(fs.readFileSync(path.join(ctrl,'ticket-ledger.json')),beforeLedger);
 }finally{fs.rmSync(parent,{recursive:true,force:true,maxRetries:2});}
});
