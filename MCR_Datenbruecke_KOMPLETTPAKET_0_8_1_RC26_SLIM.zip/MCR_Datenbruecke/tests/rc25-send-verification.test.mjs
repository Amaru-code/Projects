import test from 'node:test';import assert from 'node:assert/strict';
import {verifiedNewOutgoingAcknowledgement} from '../lib/mail-history-audit.mjs';
import {validSendAcknowledgements,permitAcknowledgement} from '../lib/send-dialog-policy.mjs';
import {certifyPilot} from '../tools/proof.mjs';
const id='87422280',to='max.mustermann@example.invalid';
const standard='Sehr geehrter Herr Mustermann, vielen Dank, dass Sie sich mit uns in Verbindung gesetzt haben. Mit dieser E-Mail möchten wir Ihnen bestätigen, dass wir Ihr Ticket erhalten haben und unser Team derzeit daran arbeitet.';
const inbound={direction:'INCOMING',sender:to,recipient:'support@example.invalid',subject:'Anfrage',content:'Guten Tag.',documentId:'1',date:'heute'};
const outbound={direction:'OUTGOING',sender:'support@example.invalid',recipient:to,subject:'[MERCER#'+id+'] Anfrage',content:standard,documentId:'2',date:'danach'};
const snap=rows=>({ok:true,rows});
test('RC25 one distinct OK plus newly bound outgoing standard reply is a certified send',()=>{
 const out=verifiedNewOutgoingAcknowledgement(snap([inbound]),snap([inbound,outbound]),id,to);
 assert.equal(out.verified,true,out.reason);
 assert.equal(validSendAcknowledgements({htmlDialogs:1,jsDialogs:0,successNotices:0,boundHistoryVerified:true,ackMode:'BOUND_NEW_OUTGOING_HISTORY'}),true);
 assert.equal(validSendAcknowledgements({htmlDialogs:0,jsDialogs:0,successNotices:0,boundHistoryVerified:true,ackMode:'BOUND_NEW_OUTGOING_HISTORY'}),true);
});
test('RC25 one OK without NEW bound history never qualifies',()=>{
 assert.equal(validSendAcknowledgements({htmlDialogs:1,jsDialogs:0,successNotices:0}),false);
 assert.equal(validSendAcknowledgements({htmlDialogs:1,jsDialogs:0,successNotices:0,ackMode:'BOUND_NEW_OUTGOING_HISTORY',boundHistoryVerified:false}),false);
 assert.equal(verifiedNewOutgoingAcknowledgement(snap([inbound]),snap([inbound]),id,to).verified,false);
});
test('RC25 already sent before attempted click is not a new send',()=>{
 assert.equal(verifiedNewOutgoingAcknowledgement(snap([inbound,outbound]),snap([inbound,outbound]),id,to).verified,false);
});
test('RC25 wrong recipient and wrong ticket are never send proof',()=>{
 assert.equal(verifiedNewOutgoingAcknowledgement(snap([inbound]),snap([inbound,{...outbound,recipient:'other@example.invalid'}]),id,to).verified,false);
 assert.equal(verifiedNewOutgoingAcknowledgement(snap([inbound]),snap([inbound,{...outbound,subject:'[MERCER#12345678] Anfrage'}]),id,to).verified,false);
 assert.equal(verifiedNewOutgoingAcknowledgement(snap([inbound]),snap([inbound,outbound]),'12345678',to).verified,false);
});
test('RC25 arbitrary or inbound new row cannot be treated as a sent reply',()=>{
 assert.equal(verifiedNewOutgoingAcknowledgement(snap([inbound]),snap([inbound,{...outbound,direction:'INCOMING'}]),id,to).verified,false);
 assert.equal(verifiedNewOutgoingAcknowledgement(snap([inbound]),snap([inbound,{...outbound,content:'Andere Nachricht'}]),id,to).verified,false);
 assert.equal(verifiedNewOutgoingAcknowledgement(snap([inbound]),snap([inbound,outbound,{...outbound,documentId:'3'}]),id,to).verified,false);
});
test('RC25 old two and third explicit success retain their policy; unsafe third is never accepted',()=>{
 assert.equal(validSendAcknowledgements({htmlDialogs:2,jsDialogs:0}),true);
 assert.equal(validSendAcknowledgements({htmlDialogs:3,jsDialogs:0,successNotices:1}),true);
 assert.equal(validSendAcknowledgements({htmlDialogs:3,jsDialogs:0,successNotices:0,ackMode:'BOUND_NEW_OUTGOING_HISTORY',boundHistoryVerified:true}),false);
 assert.equal(permitAcknowledgement({previous:2,successNotices:0,success:false}),false);
});
test('RC25 no fake proof from an unavailable history table',()=>{
 assert.equal(verifiedNewOutgoingAcknowledgement({ok:false,rows:[]},snap([inbound,outbound]),id,to).verified,false);
});

test('RC25 real pilot after ONE dialog needs sent AND independently verified saved description',()=>{
 const d={mode:'REAL',lastError:null,send:{htmlDialogs:1,jsDialogs:0,successNotices:0,ackMode:'BOUND_NEW_OUTGOING_HISTORY',boundHistoryVerified:true,verified:true},save:{verified:true},loop:{completed:true,finishReason:'PILOT_LIMIT_AFTER_VERIFIED_SAVE',processed:1,myTasksProcessed:1,queueProcessed:0,processedTickets:[{sendAck:'BOUND_NEW_OUTGOING_HISTORY',save:'MY_TASKS_ALL_DESCRIPTION_CONTENT_MATCH'}]}};
 assert.equal(certifyPilot(d),true);
 assert.throws(()=>certifyPilot({...d,save:{verified:false}}),{code:'PILOT_NOT_VERIFIED'});
 assert.throws(()=>certifyPilot({...d,send:{...d.send,boundHistoryVerified:false}}),{code:'PILOT_NOT_VERIFIED'});
 assert.throws(()=>certifyPilot({...d,loop:{...d.loop,processed:0}}),{code:'PILOT_NOT_VERIFIED'});
});
