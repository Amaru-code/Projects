import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {temp} from './helpers.mjs';
import {readJSON,writeJSON,controlDir,ledger,runState,lock} from '../lib/control.mjs';
import {releaseOrphanedRealLock,prepareFreshRun,blockedTicketIds,pendingSnapshot,assertPendingUnchanged} from '../lib/run-reset.mjs';
const idle=()=>({schema:'MCR_PROCESS_GUARD_V1',checked:true,blockedCount:0,unknownCount:0});
const busy=()=>({schema:'MCR_PROCESS_GUARD_V1',checked:true,blockedCount:1,unknownCount:0});
const oldPid=1999999999;
const oldRun={schema:'MCR_BETA_RUN_V1',version:'0.8.1-rc.22',operation:'REAL_RUN',state:'RUNNING',
 pid:oldPid,runId:'OLD-REAL-RUN-123',startedAt:'2026-10-28T07:00:00.000Z'};
const oldLock={schema:'MCR_OPERATION_LOCK_V1',operation:'REAL_RUN',pid:oldPid,token:'a'.repeat(48),createdAt:'2026-10-28T07:00:00.000Z'};
function make({withIntent=true,withLock=true,run=oldRun,old=oldLock}={}){
 const d=temp(),ctrl=controlDir(d);
 if(run)writeJSON(path.join(ctrl,'last-run.json'),run);
 if(withLock)writeJSON(path.join(ctrl,'operation.lock.json'),old);
 if(withIntent)ledger(d).begin('87536494','Preserve original send intent');
 return d;
}
function cleanup(d){fs.rmSync(d,{recursive:true,force:true,maxRetries:2});}
test('RC23 installer archives orphaned old REAL_RUN lock, preserves send intent and state',()=>{
 const d=make(),ctrl=controlDir(d);try{
  const beforeState=fs.readFileSync(path.join(ctrl,'last-run.json'));
  const beforeJournal=fs.readFileSync(path.join(ctrl,'ticket-ledger.json'));
  const r=releaseOrphanedRealLock(d,{guard:idle});
  assert.equal(r.released,true);assert.equal(fs.existsSync(path.join(ctrl,'operation.lock.json')),false);
  assert.deepEqual(fs.readFileSync(path.join(ctrl,'last-run.json')),beforeState);
  assert.deepEqual(fs.readFileSync(path.join(ctrl,'ticket-ledger.json')),beforeJournal);
  assert.equal(readJSON(path.join(ctrl,'lock_archive',r.receipt)).old.token,oldLock.token);
  assert.equal(runState(d).reviewRequired,true);
  assert.deepEqual(blockedTicketIds(d),['87536494']);
 }finally{cleanup(d);}
});
test('RC23 new run auto archives abandoned state but quarantines unknown send',()=>{
 const d=make(),ctrl=controlDir(d);try{
  const beforeJournal=fs.readFileSync(path.join(ctrl,'ticket-ledger.json'));
  const r=prepareFreshRun(d,{guard:idle});
  assert.equal(r.oldRunClosed,true);assert.equal(r.lockReleased,true);
  assert.deepEqual(r.pending.map(p=>p.ticketId),['87536494']);
  assert.equal(runState(d).reviewRequired,false);
  assert.deepEqual(blockedTicketIds(d),['87536494']);
  assert.deepEqual(fs.readFileSync(path.join(ctrl,'ticket-ledger.json')),beforeJournal);
  assert.equal(readJSON(path.join(ctrl,r.receipt)).oldState.runId,oldRun.runId);
  assert.throws(()=>ledger(d).begin('87536494','retry'),{code:'DUPLICATE_GUARD'});
  const current=lock(d,'REAL_RUN');current.release();
 }finally{cleanup(d);}
});
test('RC23 quarantined old ticket does not prevent completing a different ticket',()=>{
 const d=make();try{
  const r=prepareFreshRun(d,{guard:idle});const before=r.pending;
  const l=ledger(d);l.begin('90001234','new description');l.set('90001234','SENT_CONFIRMED');
  l.set('90001234','SAVE_INTENT');l.set('90001234','COMPLETE');
  assertPendingUnchanged(d,before);
  assert.deepEqual(ledger(d).completedIds(),['90001234']);
  assert.deepEqual(blockedTicketIds(d),['87536494']);
  assert.throws(()=>l.begin('87536494','duplicate'),{code:'DUPLICATE_GUARD'});
 }finally{cleanup(d);}
});
test('RC23 newly pending send is never certified as a complete run',()=>{
 const d=make();try{
  const before=prepareFreshRun(d,{guard:idle}).pending;
  ledger(d).begin('90001234','new incomplete');
  assert.throws(()=>assertPendingUnchanged(d,before),{code:'RUN_PENDING_CHANGED'});
 }finally{cleanup(d);}
});
test('RC23 idle check blocks auto deletion of a lock owned by an active bot',()=>{
 const d=make(),ctrl=controlDir(d);try{
  assert.throws(()=>prepareFreshRun(d,{guard:busy}),{code:'PROCESS_CHECK_UNAVAILABLE'});
  assert.equal(fs.existsSync(path.join(ctrl,'operation.lock.json')),true);
  assert.equal(runState(d).reviewRequired,true);
 }finally{cleanup(d);}
});
test('RC23 old MIGRATION lock is not automatically removed',()=>{
 const d=make({old:{...oldLock,operation:'MIGRATION'}}),ctrl=controlDir(d);try{
  assert.throws(()=>releaseOrphanedRealLock(d,{guard:idle}),{code:'OPERATION_LOCKED'});
  assert.equal(fs.existsSync(path.join(ctrl,'operation.lock.json')),true);
 }finally{cleanup(d);}
});
test('RC23 mismatched lock and run cannot be detached',()=>{
 const d=make({old:{...oldLock,pid:19000000}}),ctrl=controlDir(d);try{
  assert.throws(()=>releaseOrphanedRealLock(d,{guard:idle}),{code:'LOCK_RUN_MISMATCH'});
  assert.equal(fs.existsSync(path.join(ctrl,'operation.lock.json')),true);
 }finally{cleanup(d);}
});
test('RC23 unknown run state remains blocked after safe lock release',()=>{
 const d=make({run:{...oldRun,state:'UNRECOGNIZED_STATE'}}),ctrl=controlDir(d);try{
  assert.throws(()=>prepareFreshRun(d,{guard:idle}),{code:'PREVIOUS_RUN_UNCLEAR'});
  assert.equal(runState(d).reviewRequired,true);
  assert.equal(fs.existsSync(path.join(ctrl,'operation.lock.json')),true);
  assert.deepEqual(blockedTicketIds(d),['87536494']);
 }finally{cleanup(d);}
});
test('RC23 no pending old pre-send run can be closed automatically',()=>{
 const d=make({withIntent:false});try{
  const r=prepareFreshRun(d,{guard:idle});
  assert.equal(r.oldRunClosed,true);assert.deepEqual(r.pending,[]);
  assert.equal(runState(d).reviewRequired,false);
 }finally{cleanup(d);}
});
test('RC23 unknown journal states block reopening',()=>{
 const d=make(),ctrl=controlDir(d);try{
  const jf=path.join(ctrl,'ticket-ledger.json'),j=readJSON(jf);
  j.tickets[Object.keys(j.tickets)[0]].state='UNKNOWN';writeJSON(jf,j);
  assert.throws(()=>prepareFreshRun(d,{guard:idle}),{code:'JOURNAL_STATE_UNCLEAR'});
  assert.equal(fs.existsSync(path.join(ctrl,'operation.lock.json')),true);
 }finally{cleanup(d);}
});
test('RC23 already clear run without stale lock remains unchanged',()=>{
 const d=make({withIntent:false,withLock:false,run:{...oldRun,state:'RUNNER_EXIT_0'}}),ctrl=controlDir(d);try{
  const before=fs.readFileSync(path.join(ctrl,'last-run.json'));
  const r=prepareFreshRun(d,{guard:idle});
  assert.equal(r.oldRunClosed,false);assert.deepEqual(fs.readFileSync(path.join(ctrl,'last-run.json')),before);
 }finally{cleanup(d);}
});
