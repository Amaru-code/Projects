/** RC25 explicit one/no COMARCH OK dialog browser qualification (fictional only). */
import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const names=process.env.MCR_RC25_SCENARIOS?.split(',').filter(Boolean)||['send-one-dialog','send-no-dialog'];
for(const name of names){
 const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC25-SingleBrowser-'));
 try{
  for(const d of ['src','lib','examples','config'])fs.cpSync(path.join(root,d),path.join(tmp,d),{recursive:true});
  const cfgFile=path.join(tmp,'config/local-runner-queue-send.json');const cfg=JSON.parse(fs.readFileSync(cfgFile,'utf8'));
  Object.assign(cfg,{runtimeDirectory:'.runtime',profileDirectory:'.runtime/edge-profile',downloadDirectory:'.runtime/downloads',diagnosticDirectory:'diagnostics'});
  fs.writeFileSync(cfgFile,JSON.stringify(cfg,null,2)+'\n');
  const run=await new Promise((resolve,reject)=>{
   const env={...process.env,MCR_DEMO_SCENARIO:name,MCR_DEMO_TICKET_LIMIT:'1'};
   delete env.NODE_OPTIONS;delete env.NODE_PATH;
   const child=spawn(process.execPath,[path.join(tmp,'src/local-bot-full-run.mjs'),'--demo','--close-browser'],{cwd:tmp,env,stdio:['ignore','pipe','pipe']});
   let out='',killed=false;
   for(const stream of [child.stdout,child.stderr])stream.on('data',b=>{out+=b.toString();if(out.length>150000)out=out.slice(-150000);});
   const timer=setTimeout(()=>{killed=true;child.kill('SIGKILL');},90000);
   child.once('error',reject);child.once('exit',(code,signal)=>{clearTimeout(timer);resolve({code,signal,out,killed});});
  });
  const d=JSON.parse(fs.readFileSync(path.join(tmp,'diagnostics/last-result.json'),'utf8'));
  if(name==='send-one-dialog-wrong-recipient'){
   assert.equal(run.code,1,run.out.slice(-1800));
   assert.equal(d.lastError,'SEND_UNVERIFIED');
   assert.equal(d.send.clicked,true);
   assert.equal(d.send.verified,false);
   assert.equal(d.save?.clicked,false);
   assert.equal(d.loop.processed,0);
   console.log('PASS RC25 WRONG_RECIPIENT_NO_SAVE_NO_RESEND');
   continue;
  }
  assert.equal(run.code,0,run.out.slice(-1800));
  assert.equal(d.lastError,null);assert.equal(d.loop.processed,1);
  assert.equal(d.send.ackMode,'BOUND_NEW_OUTGOING_HISTORY');assert.equal(d.send.boundHistoryVerified,true);
  assert.equal(d.send.htmlDialogs,name==='send-one-dialog'?1:0);
  assert.equal(d.demoBrowser.sendClicks,1);assert.equal(d.demoBrowser.saveClicks,1);
  assert.equal(d.demoBrowser.okClicks,name==='send-one-dialog'?1:0);
  assert.equal(d.save.verified,true);
  assert.deepEqual(d.demoBrowser.trustedSends,[true]);assert.deepEqual(d.demoBrowser.trustedSaves,[true]);
  console.log('PASS RC25 '+name+' ONE_SEND_HISTORY_BOUND_ONE_SAVE');
 }finally{
  // Browser processes can retain Windows temp handles for a short time.
  // Never delete anything outside this dedicated test directory.
  try{fs.rmSync(tmp,{recursive:true,force:true,maxRetries:7,retryDelay:220});}
  catch(e){if(!['EPERM','EBUSY','EACCES','ENOTEMPTY'].includes(e?.code))throw e;console.log('WARN RC25 TEMP_PROFILE_LOCKED, qualified browser assertions unaffected');}
 }
}
