import test from 'node:test';import assert from 'node:assert/strict';
import {subjectOfSameConversation,verifiedNewOutgoingAcknowledgement} from '../lib/mail-history-audit.mjs';
import {authorizeChainedContinuation} from '../lib/continuation-policy.mjs';
const id='87422280',to='maria.test@example.invalid',long='Aktuelle Berechnung meiner betrieblichen Altersversorgung und Portalzugang';
const standard='Mit dieser E-Mail möchten wir Ihnen bestätigen, dass wir Ihr Ticket erhalten haben und unser Team derzeit daran arbeitet.';
const incoming={direction:'INCOMING',sender:to,recipient:'servicelineintel@mercer.com',subject:long,content:'Bitte um Auskunft.',date:'heute',documentId:'12866697'};
const outgoing={direction:'OUTGOING',sender:'servicelineintel@mercer.com',recipient:to,subject:'[MERCER#77777777][SEND SECURE] '+long,content:standard,documentId:'12871735',date:'morgen'};
const snap=rows=>({ok:true,rows});
test('RC26: COMARCH remapped outgoing MERCER number accepted only for same long conversation and new outbound row',()=>{
 assert.equal(subjectOfSameConversation(long,outgoing.subject,id).mode,'SAME_LONG_SUBJECT_WITH_REMAPPED_TICKET_TAG');
 const p=verifiedNewOutgoingAcknowledgement(snap([incoming]),snap([incoming,outgoing]),id,to);
 assert.equal(p.verified,true,p.reason);assert.equal(p.subjectBinding,'SAME_LONG_SUBJECT_WITH_REMAPPED_TICKET_TAG');
});
test('RC26: unrelated subject, short generic subject, wrong recipient and wrong original document remain blocked',()=>{
 assert.equal(verifiedNewOutgoingAcknowledgement(snap([{...incoming,subject:'Anfrage'}]),snap([{...incoming,subject:'Anfrage'},{...outgoing,subject:'[MERCER#77777777] Anfrage'}]),id,to).verified,false);
 assert.equal(verifiedNewOutgoingAcknowledgement(snap([incoming]),snap([incoming,{...outgoing,subject:'[MERCER#77777777] Anderes Thema'}]),id,to).verified,false);
 assert.equal(verifiedNewOutgoingAcknowledgement(snap([incoming]),snap([incoming,{...outgoing,recipient:'other@example.invalid'}]),id,to).verified,false);
 assert.equal(verifiedNewOutgoingAcknowledgement(snap([incoming]),snap([{...incoming,documentId:'99999999'},outgoing]),id,to).verified,false);
 assert.equal(verifiedNewOutgoingAcknowledgement(snap([incoming]),snap([incoming,{...outgoing,direction:'INCOMING'}]),id,to).verified,false);
});
test('RC26: duplicate outbound, stale before row, no change and changed sender are never a new verified send',()=>{
 assert.equal(verifiedNewOutgoingAcknowledgement(snap([incoming]),snap([incoming,outgoing,{...outgoing,documentId:'12871736'}]),id,to).verified,false);
 assert.equal(verifiedNewOutgoingAcknowledgement(snap([incoming,outgoing]),snap([incoming,outgoing]),id,to).verified,false);
 assert.equal(verifiedNewOutgoingAcknowledgement(snap([incoming]),snap([incoming]),id,to).verified,false);
 assert.equal(verifiedNewOutgoingAcknowledgement(snap([incoming]),snap([{...incoming,sender:'different@example.invalid'},outgoing]),id,to).verified,false);
});
test('RC26: chained five-ticket authorization exists only after exact certified pilot for same version and mapping',()=>{
 const hash='a'.repeat(64),map='b'.repeat(64),runId='2026-10-28T10-00_testpilot',receipt={schema:'MCR_COMPLETE_PILOT_PASS_V1',manifestSha256:hash,mappingSha256:map,runId};
 assert.equal(authorizeChainedContinuation({runId,receipt,manifestSha:hash,mappingSha:map,ticketLimit:5}),true);
 for(const args of [{ticketLimit:100},{ticketLimit:6},{runId:'anotherpilot123456'},{manifestSha:'c'.repeat(64)},{mappingSha:'c'.repeat(64)},{receipt:{...receipt,schema:'FAKE'}}]){
  assert.throws(()=>authorizeChainedContinuation({...{runId,receipt,manifestSha:hash,mappingSha:map,ticketLimit:5},...args}));
 }
});
