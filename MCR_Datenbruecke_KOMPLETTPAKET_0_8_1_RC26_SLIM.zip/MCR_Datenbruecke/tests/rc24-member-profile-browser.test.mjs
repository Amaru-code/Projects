import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {selectedMember} from '../lib/browser-workflow.mjs';
import Identity from '../lib/identity-evidence.cjs';

const person={firstName:'Timm-Peter',lastName:'Mueller'};
const makeDOM=({field='Mueller, Timm Peter / COMARCH Dossier (INTL01-11412817) - 1978',profileId='11412817',first='Timm Peter',last='Müller'}={})=>`
<form id="mainForm"><div id="document-data-section"><input id="mainForm:member-value-id" value="${field}"></div>
<table><tbody>
<tr><td><div><label>MercerID:</label></div></td><td><label>INTL01-${profileId}</label></td></tr>
<tr><td><div><label>Vorname:</label></div></td><td><label>${first}</label></td></tr>
<tr><td><label>Nachname:</label></td><td><label>${last}</label></td></tr>
</tbody></table></form>`;

test('RC24 real browser: ID-bearing Member uses matching structured profile, not decorative field text',async()=>{
 const folder=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC24-PROFILE-'));
 let browser,cdp;
 try{
  browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:folder,startUrl:'about:blank',headless:true,extraArgs:process.platform!=='win32'&&process.getuid?.()===0?['--no-sandbox']:[]});
  ({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.url==='about:blank');
  async function bind(html){await page.eval('document.body.innerHTML='+JSON.stringify(html));return selectedMember(page,person);}
  const exact=await bind(makeDOM());
  assert.equal(exact?.source,'MEMBER_PROFILE_VERIFIED');assert.equal(exact?.id,'11412817');
  assert.equal(exact.firstName,'Timm Peter');assert.equal(exact.lastName,'Müller');
  assert.equal(Identity.requireMatched(exact,person,{expectedId:'11412817'}),true);
  // ICEfaces can show profile rows before the Member has been committed.
  assert.equal(await bind(makeDOM({field:''})),null,'blank Member input cannot be verified from old profile rows');
  const mismatch=await bind(makeDOM({profileId:'99990001'}));
  assert.equal(mismatch.source,'MEMBER_PROFILE_CONFLICT');
  assert.throws(()=>Identity.requireMatched(mismatch,person,{}),{code:'MEMBER_PROFILE_CONFLICT'});
  const other=await bind(makeDOM({first:'Daniel',last:'Müller'}));
  assert.equal(other.source,'MEMBER_PROFILE_VERIFIED');
  assert.throws(()=>Identity.requireMatched(other,person,{}),{code:'MEMBER_NAME_MISMATCH'});
  const missing=await bind('<form id="mainForm"><input id="mainForm:member-value-id" value="Mueller Timm Peter (INTL01-11412817)"></form>');
  assert.equal(missing.source,'MEMBER_FIELD');
  assert.equal(Identity.requireMatched(missing,person,{}),true,'legacy display still requires a full matching name');
  const unknown=await bind('<form id="mainForm"><input id="mainForm:member-value-id" value="Other name (INTL01-11412817)"></form>');
  assert.equal(unknown.source,'MEMBER_FIELD');
  assert.throws(()=>Identity.requireMatched(unknown,person,{}),{code:'MEMBER_NAME_MISMATCH'});
  const sameWithoutDirect=await bind(makeDOM({field:'Timm-Peter Müller'}));
  assert.equal(sameWithoutDirect.source,'PROFILE_ROWS');
  assert.equal(Identity.requireMatched(sameWithoutDirect,person,{}),true);
  console.log('PASS RC24_REAL_BROWSER_IDENTITY_PROFILE_STRICT_AND_BOUND');
 }finally{
  try{cdp?.close();}catch{}try{browser?.child?.kill();}catch{}
  try{fs.rmSync(folder,{recursive:true,force:true,maxRetries:3,retryDelay:200});}catch{}
 }
});
