# RC26: Versandnachweis und kontrollierte Fortsetzung

- **COMARCH hat den Versand bereits ausgeführt:** Kein zweiter Sendeklick, auch nicht bei `SEND_UNVERIFIED`. Bereits ausgegangene E-Mails werden niemals aus dem Journal gelöscht.
- Neue, im selben geöffneten Ticket sichtbare Ausgangsnachricht an den ursprünglichen Absender mit Standardtext und einer neuen dokumentierten Nachricht genügt für den Versandnachweis. Ein neuer `[MERCER#…]`-Tag ist nur bei **unverändertem aussagekräftigem Betreff** zulässig. Kurzbetreffe wie "Test" oder "Anfrage" erlauben diese Ausnahme ausdrücklich nicht.
- Der bot betätigt bis zu drei Mal **ausschließlich** das exakt zugeordnete `Nachrichtenverlauf`-Aktualisierungsicon, wenn keine modalen Dialoge mehr sichtbar sind. Danach versucht er den Nachweis erneut. Kein erneuter Versand.
- Ticket wird erst nach **Versand und tatsächlicher Speicherung** als abgeschlossen gezählt.
- **Menü 3** kündigt an: ein zertifizierter Pilot, danach maximal fünf weitere Tickets automatisch. Vor dem ersten Ticket muss der Bediener `START` eingeben. Die Fortsetzung kann erst nach dem vom Host unabhängig zertifizierten ersten Versand-und-Speicher-Beleg starten; die Folgeinstanz überprüft die exakt zugeordnete Freigabe erneut. Kein unkontrollierter Full Run.
- Bei `SEND_UNVERIFIED` oder `SAVE_UNVERIFIED`: **Keine automatische Fortsetzung**. Das Ticket bleibt im unveränderten Versandjournal gesperrt. Nach unabhängiger Statusprüfung kann ein neuer Pilot auf einem anderen, nicht gesperrten Ticket gestartet werden.
- Normaler Menü-4-Lauf und unveränderte Geschäftsfelder / Identitätsprüfung bleiben erhalten.
- Alle Test-Browserfälle sind fiktiv. Eine produktive COMARCH-Validierung ist noch erforderlich.
