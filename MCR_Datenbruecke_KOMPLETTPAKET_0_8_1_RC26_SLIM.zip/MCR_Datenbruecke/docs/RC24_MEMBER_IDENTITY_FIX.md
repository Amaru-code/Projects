# RC24 – Member-Nachweis anhand COMARCH-Profilfeldern

## Ursache

In RC23 wurde ein Member-Feld mit `INTL01-…` bevorzugt als Freitext erkannt. Der Namensvergleich prüfte den gesamten Anzeigepräfix. COMARCH kann aber Zusätze zur Dossieranzeige rendern, die nicht Teil des Vor- oder Nachnamens sind. Der Bot meldete daher `MEMBER_NAME_MISMATCH`, obwohl die strukturierten Felder `MercerID`, `Vorname` und `Nachname` sichtbar waren.

## Korrektur

- Bei im Member-Feld belegter ID werden die eindeutig beschrifteten COMARCH-Profilfelder bevorzugt und an dieselbe ID gebunden.
- Nur wenn Feld-ID **und** Profil-ID identisch sind, wird der strukturierte Vor-/Nachname zur Identitätsprüfung genutzt.
- Bei nicht übereinstimmenden IDs `MEMBER_PROFILE_CONFLICT`: keine automatische Weiterbearbeitung.
- Leeres/nicht bestätigtes Member-Feld kann nicht allein durch sichtbare alte Profilfelder als Auswahl durchgehen.
- Fehlen eindeutige Profilfelder, bleibt die bisherige strenge Anzeigeprüfung. Es gibt keine Identitätsfreigabe allein über E-Mail, Name oder MercerID.
- Ein zusätzlicher datenschutzschonender Diagnoseeintrag `memberVerification` zeigt Prüfmodus und Wahrheitswerte ohne Namens- oder ID-Inhalte.

Nicht verändert: Pflichtfeld-Automatik, Original-MSG-Abgleich, Zuordnung in Bestandsdatei, Versandreihenfolge, Versandjournal, Wiederanlaufsperren, Bericht über Nachrichtenverlauf.

**Einschränkung:** RC24 ist offline gegen die dokumentierte COMARCH-HTML-Struktur getestet. Ein tatsächlich abweichender Member bleibt mit `MEMBER_NAME_MISMATCH` gesperrt. Zur Bestimmung eines solchen Konflikts wird die originale Diagnose-ZIP benötigt.
