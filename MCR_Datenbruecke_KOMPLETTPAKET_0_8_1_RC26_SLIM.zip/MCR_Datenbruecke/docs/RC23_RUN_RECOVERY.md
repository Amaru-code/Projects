# RC23 – automatisch verwaiste Läufe schließen, offene Versandabsichten schützen

## Warum die Installation bisher scheiterte

Der erfolgreiche Paket-Selbsttest und die vier Browserdemos hatten mit der eigentlichen Fehlermeldung `STOP OPERATION_LOCKED` nichts zu tun. Ein alter `operation.lock.json`-Datensatz blieb in der bestehenden Installation zurück. `EINRICHTEN` wurde deshalb blockiert.

## Neuer Ablauf

- Vor dem Update werden auf Windows laufende Prozesse der **Zielinstallation** kontrolliert. Ist kein solcher Prozess aktiv, darf die **nachgewiesen verwaiste** REAL_RUN-Sperre archiviert und freigegeben werden. Eine Migrationssperre, ein nicht zuordenbarer Lock oder ein laufender Bot bleibt geschützt.
- Die vorherige `last-run.json` und jedes Ticket-Journal bleiben beim Update unverändert, ebenso `private_data`, Edge-Profil, Config und Diagnosen.
- Vor einem neuen echten Ticketlauf wird eine alte, nicht abgeschlossene Ausführung mit Originalzustand und offener Ticketliste in einen unverändernden Archivbeleg überführt. Das bedeutet **nicht**, dass ein früherer Versand bestätigt oder ein Ticket abschließend bearbeitet wurde.
- Jeder offene SEND_INTENT, SENT_CONFIRMED, SAVE_INTENT bzw. Weiterleitungszustand wird weiter im ursprünglichen `ticket-ledger.json` geführt. Diese Ticket-IDs werden vom **neuen** Botlauf ausgeschlossen. Andere Ticket-IDs können weiter bearbeitet werden.
- Nach dem neuen Lauf muss die Liste der alten offenen Absichten exakt unverändert sein; **keine neue offene Absicht** darf zurückbleiben, wenn der Lauf als erfolgreich gilt.
- Unklarer Versand, fehlendes Originaljournal, unbekannte Zustände, fremde Locks oder noch aktive Prozesse führen weiterhin zu einem sicheren Stopp.

## Was ausdrücklich nicht geschieht

Keine Löschung von Sendejournalen, keine blinde Wiederholung von `Senden`, keine Beendigung fremder Prozesse, kein Löschen des produktiven Edge-Profils oder der Mappingdateien. Alte Läufe sind historisch archiviert; unverifizierte Aktionen bleiben auditierbar. Menü 5 kann den ursprünglichen Versandzustand nach Prüfung nach wie vor dokumentieren.

## Installation

ZIP separat entpacken, START.cmd -> 1 -> EINRICHTEN; anschließend nur `START.cmd` der **installierten** MCR_Datenbruecke starten und Menü 3 verwenden.
