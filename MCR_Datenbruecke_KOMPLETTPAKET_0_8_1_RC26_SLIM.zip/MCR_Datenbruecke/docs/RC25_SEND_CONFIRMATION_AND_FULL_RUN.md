# RC25 – COMARCH Versand ohne feste Dialoganzahl

## Ursache des Echtlaufs vom 28.10.2026

RC24 behandelte exakt zwei OK-Bestaetigungen als Pflicht. Bei nur einer
Bestaetigung und bereits gesendeter Mail folgte `SEND_UNVERIFIED`; der
`SEND_INTENT` blieb absichtlich ungeklaert. Der erste irreversible Klick darf
**niemals** wiederholt werden.

## RC25-Regel

- Browser beobachtet VOR Send den Nachrichtenverlauf des exakt gebundenen Tickets.
- Ein einziger vertrauter Klick auf Senden, nur mit bereits gepruefter Identitaet,
  Mapping, Pflichtfeldern, Empfaenger, Inhalt und Duplikatssperre.
- Pro real sichtbarem bestaetigten COMARCH-Dialog maximal ein echter OK-Klick.
- 0/1/2 Dialoge sind moeglich. Bei weniger als 2 zaehlt nur eine **neue**
  ausgehende Standardantwort, die genau zur aktuellen Ticket-ID, zum
  urspruenglichen Absender und zum geprueften Antwortempfaenger gehoert.
- Die neue Antwort muss nach dem Klick als genau ein neuer ausgehender Eintrag
  erscheinen, gegen die vorherige Historie abgeglichen und stabil ohne
  offenen Dialog sichtbar sein. Eine alte Mail ist kein Nachweis.
- Nach erfolgreichem Versand genau einmal `Ticket speichern` und die
  **persistierte** Zusatzbeschreibung unabhaengig in der Aufgabenliste pruefen.
- Bei unklarer Lage: keine zweite E-Mail, alter Ticket-Intent bleibt gesperrt.

## Full Run

Menue 4 bleibt erst nach einem nachweislich gesendeten UND gespeicherten
Echtpilot zulaessig. Der alte RC24-Versand mit `SEND_UNVERIFIED` darf nicht
als erfolgreich gespeicherter Pilot etikettiert werden. In Menue 5 nur die
wahren COMARCH-Beobachtungen dokumentieren. Bei einer neuen RC25-Pilotpruefung
wird eine alte ungeklärte Ticket-ID durch das dauerhafte Journal vom Versand
exkludiert. Nach `PASS LIVE_PILOT_SEND_AND_SAVE_VERIFIED` kann Menue 4 mit
einem anfangs kleinen Limit (z.B. 3) freigegeben werden.

Daten/Profil/Journale werden beim Software-Update nicht geloescht. Die
COMARCH-PROD-Oberflaeche wurde hier nicht direkt fernbedient; die Qualifikation
ist offline plus der von Ihnen gemeldete RC24-Echtlauf.
