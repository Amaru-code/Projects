# MCR Ticket Assistant – Beta 5 RC1

**Dies ist eine offline geprüfte Beta-5-Integration – KEIN Ersatz für das laufende Beta-4-Programm.**

Einfach `BETA5_RC1_TESTEN.cmd` aus dem **vollständig entpackten ZIP**, z. B. in Downloads, starten. Das Skript ermittelt die portable `node.exe` unter `%USERPROFILE%\projects\Compiler\javascript\tools\node\node.exe`, startet alle lokalen Selbsttests und anschließend eine vollständig fiktive Chromium/Edge-Demo. Es wird kein COMARCH-Login geöffnet, kein echtes Ticket gelesen/verändert, keine reale Nachricht gesendet. Falls Edge oder Node nicht verfügbar sind, wird mit Fehlercode gestoppt.

Das Paket liegt in einem eigenen Ordner `Paket/`; NICHT in `MCR_Datenbruecke` entpacken oder einzelne Dateien dorthin kopieren. Beta 4 bleibt unverändert. Es gibt in diesem RC **keinen Installationsbefehl**. Die notwendigen Live-/Upgrade-Prüfungen sind im `Paket/docs/IDENTITY_GUARD_RC1.md` aufgeführt.

Bitte nach dem Test die Konsolenausgabe mit `RC1_TESTS_PASS` und `RC1_DEMO_PASS` zurückgeben. Erst dann planen wir einen kontrollierten Upgrader und einen einzelnen beaufsichtigten COMARCH-Piloten.
