@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
echo ==============================================================
echo  MCR BETA 5 RC1.1 - REINE OFFLINE INTEGRATIONSPRUEFUNG
echo  STARTFIX: Windows-Pfade korrekt geschrieben
echo  Keine Migration, kein COMARCH, kein echter Versand
echo ==============================================================
if not exist "%~dp0Paket\tools\beta-cli.mjs" goto incomplete
if not exist "%~dp0Paket\tools\find-node.cmd" goto incomplete
call "%~dp0Paket\tools\find-node.cmd"
if errorlevel 1 goto nodeerror
if not defined MCR_NODE goto nodeerror
"%MCR_NODE%" "%~dp0Paket\tools\beta-cli.mjs" --selftest
if errorlevel 1 goto failtest
echo.
echo RC1_TESTS_PASS
echo.
echo Jetzt folgt eine vollstaendig FIKTIVE Demo im eigenen temporaeren Browserprofil.
"%MCR_NODE%" "%~dp0Paket\tools\beta-cli.mjs" --demo
if errorlevel 1 goto faildemo
echo.
echo RC1_DEMO_PASS
echo ========================================
echo RC1_OFFLINE_QUALIFIED - kein Live-Release
echo ========================================
pause
exit /b 0
:incomplete
echo STOP: Testpaket unvollstaendig. Erwartet werden Paket\tools\beta-cli.mjs und Paket\tools\find-node.cmd direkt neben diesem Starter.
pause
exit /b 2
:nodeerror
echo STOP: Node.js nicht gefunden oder nicht geeignet.
pause
exit /b 3
:failtest
echo STOP: RC1_TESTS_FAILED - keine Installation oder Echtaktion.
pause
exit /b 4
:faildemo
echo STOP: RC1_DEMO_FAILED - keine Installation oder Echtaktion.
pause
exit /b 5
