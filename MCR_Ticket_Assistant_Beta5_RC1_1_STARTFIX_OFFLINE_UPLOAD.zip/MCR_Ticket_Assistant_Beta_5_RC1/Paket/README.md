# MCR Ticket Assistant – Beta 5 RC1 – Integration (nur Prüfung)

**STATUS: CANDIDATE / NICHT PRODUKTIV / NICHT INSTALLIERBAR.**

Dieser Release-Kandidat integriert exakt die gemeldete, 17-fach getestete Identity-Guard-Vorschau in eine separate Kopie der Beta-4-Paketstruktur. Der vorhandene installierte Beta-4-Ordner wird nicht angefasst. Hier sind echte Ticketläufe, reale Sendungen, Mapping-Neuaktivierung und die Installation ausdrücklich blockiert.

**Tests:** `BETA5_RC1_TESTEN.cmd` startet mit der vorhandenen portablen Node-Installation die lokale Integritäts-, Fach- und Identity-Testserie und anschließend eine fiktive Browserdemo. Ohne Windows: `node tools/beta-cli.mjs --selftest`, optional `--demo` mit Chromium.

**Codeabgleich:** 16 Dateien des 0.7.4-Kerns sind SHA256-byteidentisch; `src/local-bot-full-run.mjs` wurde gezielt durch den getesteten Patch ersetzt; `lib/identity-evidence.cjs` ist neu. 18 Kern-Dateien sind im RC-MANIFEST versiegelt. Detailnachweise in `docs/identity/PATCH_REPORT.json` und `docs/IDENTITY_GUARD_RC1.md`.

**Das RC-Archiv enthält keine produktiven Excel-Bestände, keine Mapping-JSONs, keine MSGs, keine Cookies/Browserprofile und keine Zugangsdaten.** Die einzige fiktive MSG aus der bestehenden Demo liegt unter `tools/demo/DEMO_Mail.msg`.

Bitte die laufende Beta 4 weiter nutzen, sofern sie freigegeben und nach abgebrochenem Lauf gesichert ist. Beta 5 darf erst nach separater Installations-/Rollbackqualifikation auf dem Windows-Rechner und einem autorisierten, beaufsichtigten COMARCH-Piloten mit tatsächlichem Versandnachweis produktiv freigegeben werden.
