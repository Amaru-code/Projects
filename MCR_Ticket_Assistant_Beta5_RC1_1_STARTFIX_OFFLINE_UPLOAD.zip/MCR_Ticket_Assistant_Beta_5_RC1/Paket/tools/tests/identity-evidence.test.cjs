'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const P = require('../../lib/identity-evidence.cjs');
const person = {firstName:'Max',lastName:'Mustermann'};
const selected = {id:'99900001',display:'Mustermann Max (INTL01-99900001) - 1959-03-31',source:'MEMBER_FIELD'};
const mail = (subject, body) => ({subject,body});

test('explicit current MercerID matches selected person and passes', () => {
 const proof=P.buildEvidence(mail('Anliegen MercerID: 99900001','Viele Gruesse\nMax Mustermann'),[]);
 assert.equal(proof.expectedId,'99900001');
 assert.equal(proof.mode,'CURRENT_EXPLICIT_ID');
 assert.equal(P.requireMatched(selected,person,proof),true);
});
test('wrong weak contextual number never becomes mandatory MercerID',()=>{
 const proof=P.buildEvidence(mail('Anliegen Max Mustermann 98765432','Mit freundlichen Gruessen\nMax Mustermann'),[{clientId:'98765432',strength:'CONTEXTUAL'}]);
 assert.equal(proof.expectedId,null);
 assert.equal(proof.mode,'NAME_AND_COMARCH_ONLY');
 assert.equal(P.requireMatched(selected,person,proof),true);
});
test('explicit wrong current ID blocks',()=>{
 const proof=P.buildEvidence(mail('MercerID: 99999999','Max Mustermann'));
 assert.throws(()=>P.requireMatched(selected,person,proof),{code:'MEMBER_ID_CONFLICT'});
});
test('two distinct current explicit IDs block even if one matches',()=>{
 assert.throws(()=>P.buildEvidence(mail('INTL01-99900001','ClientEEID: 99999999')),{code:'MAIL_ID_AMBIGUOUS'});
});
test('repeated same ID is not ambiguous',()=>{
 const p=P.buildEvidence(mail('MercerID: 99900001','INTL01-99900001'));
 assert.equal(p.expectedId,'99900001');
});
test('different quoted ID after reply separator is not binding',()=>{
 const p=P.buildEvidence(mail('Re: Anliegen','Neue Nachricht\nVielen Dank\nOn Friday 12 September wrote:\nMercerID: 99999999'));
 assert.equal(p.expectedId,null);
});
test('greater-than quotation is not binding',()=>{
 const p=P.buildEvidence(mail('Re:','Neue Nachricht\n> INTL01-99999999'));
 assert.equal(p.expectedId,null);
});
test('current explicit ID takes precedence over unrelated quoted ID',()=>{
 const p=P.buildEvidence(mail('MercerID: 99900001','Neue Nachricht\n-----Original Message-----\nMercerID: 99999999'));
 assert.equal(P.requireMatched(selected,person,p),true);
});
test('generic employee number is advisory, not a MercerID',()=>{
 const p=P.buildEvidence(mail('Employee ID: 98765432','Max Mustermann'));
 assert.equal(p.expectedId,null);
});
test('wrong name blocks even when explicit ID matches',()=>{
 const p=P.buildEvidence(mail('MercerID: 99900001','Max Mustermann'));
 assert.throws(()=>P.requireMatched({...selected,display:'Mueller Peter (INTL01-99900001)'},person,p),{code:'MEMBER_NAME_MISMATCH'});
});
test('member field containing ONLY ID cannot pass without profile names',()=>{
 assert.throws(()=>P.requireMatched({...selected,display:'INTL01-99900001'},person,null),{code:'MEMBER_NAME_MISMATCH'});
});
test('profile source requires both exact names',()=>{
 const s={id:'99900001',display:'Mustermann Max',source:'PROFILE_ROWS',firstName:'Max',lastName:'Mustermann'};
 assert.equal(P.requireMatched(s,person,null),true);
 assert.throws(()=>P.requireMatched({...s,lastName:'Braun'},person,null),{code:'MEMBER_NAME_MISMATCH'});
});
test('German umlaut/transcription normalized only for name comparison',()=>{
 assert.equal(P.memberNameMatches({id:'99900001',display:'Mueller Anna (INTL01-99900001)',source:'MEMBER_FIELD'},{firstName:'Anna',lastName:'Müller'}),true);
});
test('leading zeros in different ID never silently removed',()=>{
 assert.throws(()=>P.requireMatched({...selected,id:'099900001'},person,P.buildEvidence(mail('INTL01-99900001','body'))),{code:'MEMBER_ID_CONFLICT'});
});
