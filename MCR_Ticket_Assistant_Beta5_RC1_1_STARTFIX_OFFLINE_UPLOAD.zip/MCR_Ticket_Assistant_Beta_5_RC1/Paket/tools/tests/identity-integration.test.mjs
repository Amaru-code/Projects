import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {sha,verifyRelease,PACKAGE_ROOT,RELEASE,ENGINE} from '../beta-common.mjs';

const root=PACKAGE_ROOT;
const info=JSON.parse(fs.readFileSync(path.join(root,'docs/identity/PATCH_REPORT.json')));
const old=JSON.parse(fs.readFileSync(path.join(root,'tools/reference/baseline-0.7.4-manifest.json')));
const shaFile=(file)=>sha(fs.readFileSync(path.join(root,file)));

test('beta 4 baseline source hash pinned to preview source',()=>{
 const r=old.payload.find(x=>x.path==='src/local-bot-full-run.mjs');
 assert.equal(r.sha256,info.sourceSha256);
 assert.equal(info.sourceSha256,'6777ca3b806f0a5085f31e5e371eaa5c6d2caa45e11cb20e475d02ae8b353d72');
});
test('beta5 integrated runner has exact previewed hash',()=>{
 assert.equal(shaFile('src/local-bot-full-run.mjs'),info.candidateRunnerSha256);
 assert.equal(info.candidateRunnerSha256,'e63c12081c0b6991af3ad2f9cf60a96c1203e592b6d83de63c59f0a7d52789ed');
});
test('beta5 identity helper has exact previewed hash',()=>{
 assert.equal(shaFile('lib/identity-evidence.cjs'),info.helperSha256);
 assert.equal(info.helperSha256,'fe9e1afbca8ec4b5e3c8d7eb5bc53c741bfedc16d45429cfc2bda9a4dc5cd97a');
});
test('all other 16 core files preserved exactly',()=>{
 const lock=JSON.parse(fs.readFileSync(path.join(root,'tools/reference/engine-lock.json')));
 const pure=lock.files.filter(r=>!['src/local-bot-full-run.mjs','lib/identity-evidence.cjs'].includes(r.path));
 assert.equal(pure.length,16);
 for(const r of pure){
  assert.equal(shaFile(r.path),r.sha256);
  assert.equal(old.payload.find(x=>x.path===r.path)?.sha256,r.sha256);
 }
});
test('offline beta5 release seal includes guarded source',()=>{
 const r=verifyRelease(); assert.equal(r.version,RELEASE);assert.equal(r.engineVersion,ENGINE);assert.equal(r.frozenFiles,18);
});
test('real-run entry is fail-closed before browser or runtime initialization',()=>{
 const r=spawnSync(process.execPath,[path.join(root,'tools/beta-cli.mjs'),'--run'],{cwd:root,encoding:'utf8',timeout:12000});
 assert.equal(r.status,1);
 assert.match((r.stdout||'')+(r.stderr||''),/RC_LIVE_DISABLED/);
});
test('candidate is not installable using beta setup entry',()=>{
 const r=spawnSync(process.execPath,[path.join(root,'tools/setup.mjs'),'--inspect'],{cwd:root,encoding:'utf8',timeout:12000});
 assert.equal(r.status,1);
 assert.match((r.stdout||'')+(r.stderr||''),/RC_INSTALL_DISABLED/);
});
test('candidate includes no real personal data or browser profile',()=>{
 for(const x of ['private_data','.runtime','diagnostics','node_modules'])assert.equal(fs.existsSync(path.join(root,x)),false,'Prohibited bundled root item: '+x);
});
