# Beta 5 RC1 – kein Live-Release

- Basis: unveränderte, geprüfte Beta 4 (0.8.0-beta.4), Ticketkern 0.7.4
- Identitäts-Patch: genau die geprüfte Source Preview (Runner + identity-evidence)
- Stand: Integrationskandidat, nicht im installierten Tool aktiviert
- **Echtlauf und Umstellung absichtlich deaktiviert**
- Nächste Abnahme: Windows-Installation/Rollback mit Ausgangszustandsprüfung, beaufsichtigter COMARCH-Einzelticket-Pilot, dann erst mehrfache Queue
