# Beta 5 RC1 – Integrations- und Risikobewertung

## Umfang

Aus dem ursprünglichen, SHA256-verifizierten Beta-4-Runner (`6777ca3b...`) entsteht durch 14 eindeutige Patcher-Anker der Runner mit SHA256 `e63c1208...` plus Hilfsmodul `fe9e1afb...`. Es werden **keine** bisherigen 16 Kernmodule für COMARCH, Mapping, E/F/TPP, Personensuche, Outlook-MSG, Versendung, Speicherung oder Queue-Schleife modifiziert.

- Nur ausdrücklich in der aktuellen Nachricht/Betreff vorkommende MercerID/INTL01-Kennungen werden zu verbindlichen ID-Hinweisen; historische Zitate und beliebige Kontextnummern werden nicht als harte Gleichheitsbedingung angenommen.
- Die COMARCH-Identität verlangt Namen UND ID. Eine Kennung allein im Member-Feld reicht ohne sichtbare personenbezogene Zuordnung nicht aus.
- Ein Widerspruch von aktueller expliziter Kennung und COMARCH stoppt weiterhin. Ebenso zwei verschiedene aktuelle explizite Kennungen oder ein Namenskonflikt.
- Bestehende Fachlogik C=DC, D=PP+, E=DB+, F=TPP, Originalzeilen, Gender O, automatische Queue-Navigation und kein erneutes Senden bleibt erhalten.

## Bereits getestet

1. Die 17 isolierten Preview-Tests aus dem Patchkit wurden unabhängig ausgeführt.
2. Die 50 Beta-4-Regressions-/Selbsttests wurden unabhängig ausgeführt (mit zusätzlichen Windows-Migrationstests, die auf Linux bewusst übersprungen werden).
3. Fiktiver Chromium-End-to-End-Lauf: zwei Tickets, erst Meine Vorgänge, dann Warteschlange, mit automatischer Member-Zuordnung, zwei Beschreibungszeilen einschließlich TPP, je einem fiktiven Versand, Nachweis über History-Inkrement, Speicherprüfung und `RUN COMPLETE`. Kein COMARCH-Kontakt.
4. Release-Versiegelung und Offline-Eintrittssperren werden durch weitere Integrationstests kontrolliert.

## Offen vor Live

- Die Beta-4-Umstellung migriert nicht automatisch von bereits installiertem Beta 4 auf Beta 5. **Kein direktes Kopieren** über die bestehende Software; nötig ist ein eigener reversibler Windows-Upgrader.
- Windows-spezifische Lock-, Fsync- und Installations-/Rollbackpfade müssen am tatsächlichen Zielcomputer getestet werden.
- Ein realer, beaufsichtigter Pilot ist nötig, gerade im Ursprungsfall mit Identifikator-Konflikt.
- Die bestehenden COMARCH-Versandheuristiken (insbesondere `EDITOR_RESET_AFTER_CONFIRMED_DIALOGS`) bleiben unverändert und sind kein unabhängiger externer Zustellnachweis. Ein wiederaufgenommener Lauf darf niemals ohne Verlaufsprüfung erneut senden.
- Der Empfänger-Gate kontrolliert in 0.7.4 vor allem die Eindeutigkeit des „An“-Felds. Eine fachliche Empfängerbindung an den aktuell zuständigen Kunden ist noch separat zu qualifizieren.

## Freigabestatus

**RC = ausschließlich Offline-Qualifikation.** Der Browser kann nur in einer fiktiven Demo ausgeführt werden; der offizielle Echtlauf und Installer geben `RC_LIVE_DISABLED` bzw. `RC_INSTALL_DISABLED` zurück. Produktive Beta 4 bleibt unverändert.
