# Level 05A.2 – Julia Mode 1 Parity v0.1.0

Independent Julia implementation of the frozen LNW DC pipeline.

- existing `julia.exe` runtime only
- Julia stdlib only; no external packages
- no generated native candidate EXE
- no Python/C#/Rust/Node/Ruby/Java worker
- Excel is used only through the existing PowerShell COM bridge for workbook I/O/recalculation

Correctness target:
`078fdf618634632de329ebf250bede8b3a84ba7d7b604d8ec49f277ee2095e32`
