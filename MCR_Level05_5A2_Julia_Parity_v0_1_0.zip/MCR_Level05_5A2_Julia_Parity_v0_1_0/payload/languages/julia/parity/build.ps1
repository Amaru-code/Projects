[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$ModeRoot = $PSScriptRoot
$SrcRoot = Join-Path $ModeRoot 'src'
$BuildRoot = Join-Path $ModeRoot 'build'
$Publish = Join-Path $BuildRoot 'publish'
$JuliaPointer = Join-Path $BuildRoot 'julia_path.txt'

function Test-Julia([string]$Path) {
    if ([string]::IsNullOrWhiteSpace($Path) -or -not (Test-Path $Path -PathType Leaf)) { return $false }
    $old=$ErrorActionPreference; $ErrorActionPreference='Continue'
    try { $v=& $Path --version 2>$null; $c=$LASTEXITCODE } finally { $ErrorActionPreference=$old }
    return ($c -eq 0 -and $v -match '^julia version\s+\d+')
}

$Candidates = New-Object System.Collections.Generic.List[string]
$cmd = Get-Command julia.exe -ErrorAction SilentlyContinue
if ($cmd) { $Candidates.Add($cmd.Source) }

if ($env:USERPROFILE) {
    foreach ($p in @(
        (Join-Path $env:USERPROFILE 'projects\Compiler\julia\julia.exe'),
        (Join-Path $env:USERPROFILE 'projects\Compiler\julia\bin\julia.exe'),
        (Join-Path $env:USERPROFILE 'projects\Compiler\julia\tools\julia\bin\julia.exe')
    )) {
        if ((Test-Path $p -PathType Leaf) -and -not $Candidates.Contains($p)) { $Candidates.Add($p) }
    }
    $root = Join-Path $env:USERPROFILE 'projects\Compiler\julia'
    if (Test-Path $root) {
        Get-ChildItem $root -Recurse -Filter julia.exe -File -ErrorAction SilentlyContinue | ForEach-Object {
            if (-not $Candidates.Contains($_.FullName)) { $Candidates.Add($_.FullName) }
        }
    }
}

$Julia=$null
foreach($c in $Candidates){ if(Test-Julia $c){ $Julia=$c; break } }
if(-not $Julia){ throw 'Vorhandene Julia Runtime wurde nicht gefunden. Es wird nichts heruntergeladen.' }

Write-Host '============================================================'
Write-Host ' Level 05A.2 - Julia Parity Build'
Write-Host '============================================================'
Write-Host "julia:     $Julia"
Write-Host "Julia:     $(& $Julia --version)"
Write-Host "Source:    $SrcRoot"
Write-Host "Publish:   $Publish"
Write-Host ''
Write-Host 'Dependencies: existing Julia runtime + stdlib only / OFFLINE'
Write-Host 'Native candidate EXE generation: NONE'
Write-Host ''

$MainSource=Join-Path $SrcRoot 'main.jl'
if(-not(Test-Path $MainSource -PathType Leaf)){throw "Julia Source fehlt: $MainSource"}

# Parse/load check. main() is guarded and does not run during include.
$old=$ErrorActionPreference; $ErrorActionPreference='Continue'
try {
    & $Julia --startup-file=no --history-file=no -e 'include(ARGS[1]); println("JULIA_SOURCE_OK")' $MainSource
    $Code=$LASTEXITCODE
} finally { $ErrorActionPreference=$old }
if($Code -ne 0){throw "Julia Source Check fehlgeschlagen. ExitCode=$Code"}

if(Test-Path $Publish){Remove-Item $Publish -Recurse -Force}
New-Item -ItemType Directory -Force -Path $Publish | Out-Null
Copy-Item $MainSource (Join-Path $Publish 'main.jl') -Force
Copy-Item (Join-Path $SrcRoot 'excel_bridge.ps1') (Join-Path $Publish 'excel_bridge.ps1') -Force
New-Item -ItemType Directory -Force -Path (Join-Path $Publish 'resources') | Out-Null
Copy-Item (Join-Path $SrcRoot 'resources\settings.json') (Join-Path $Publish 'resources\settings.json') -Force
Copy-Item (Join-Path $SrcRoot 'resources\wwid_mapping.csv') (Join-Path $Publish 'resources\wwid_mapping.csv') -Force

New-Item -ItemType Directory -Force -Path $BuildRoot | Out-Null
Set-Content $JuliaPointer $Julia -Encoding UTF8

$Main=Join-Path $Publish 'main.jl'
if(-not(Test-Path $Main -PathType Leaf)){throw "Julia Build erzeugte kein main.jl: $Main"}

Write-Host ''
Write-Host 'JULIA PARITY BUILD: PASS' -ForegroundColor Green
Write-Host "MAIN: $Main"
Write-Host 'Runtime: existing julia.exe (no new native EXE)' -ForegroundColor Green
exit 0
