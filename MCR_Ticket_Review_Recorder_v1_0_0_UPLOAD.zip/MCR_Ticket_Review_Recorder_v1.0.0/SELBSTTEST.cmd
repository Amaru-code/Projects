@echo off
setlocal
cd /d "%~dp0"
%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0src\SelfTest.ps1"
set "E=%ERRORLEVEL%"
pause
exit /b %E%
