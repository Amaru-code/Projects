# Ticket Answer/Review Bot V2 — fachlicher Zielvertrag (noch nicht implementiert)

## Input und Bestandsschutz

- Quelle: bereits eröffnete INTL01-Tickets mit **nicht leerer zusätzlicher Beschreibung**.
- Vorhandene Felder sind autoritativ: Zuständigkeit, Dokumentenkategorie, Unterkategorie, Member und zusätzliche Beschreibung stammen aus dem Erstbot.
- Status, Rentenplan und ggf. mehrere physische Bestandszeilen/TPP ergeben sich aus der bestehenden zusätzlichen Beschreibung. Keine erneute Member-Zuordnung und kein erneuter Excel-Abgleich im zweiten Bot.
- Beispiele für Plankürzel aus V1: `DC`, `PP+`, `DB+`, `TPP`; Reihenfolge `DC;PP+;DB+;TPP`. Mehrzeilige Zusatzbeschreibungen dürfen nicht als mehrere Tickets behandelt werden.

## Fachverarbeitung

1. Original-E-Mail und ggf. relevanten bisherigen Verlauf lesen, Kundensprache DE/EN feststellen.
2. Aus `references/OneNote_Ticket_Antworten.md` den **passenden dokumentierten Fall** wählen. Dabei die vorhandene Zusatzbeschreibung als Personen-/Plan-Kontext nutzen.
3. Bestehende Vorlagen zuerst in einen Versionierten Fallkatalog überführen; Textbausteine erkennbar, mit DE/EN und erforderlichen Nachweisen. Keine automatische Erfindung zusätzlicher Renten-/Rechts-/Personenangaben.
4. Englischer Kundentext → englischer Entwurf; deutscher Kundentext → deutscher Entwurf. Bei gemischter Sprache/Unsicherheit dokumentierte Fallback-Logik statt stillem Erraten.
5. Keine falschen Aussagen über erledigte Tätigkeiten ("angefügt", "aktualisiert", "berechnet", "gesendet"), wenn keine verifizierte Anlage/Aktion vorliegt.
6. Namen/Anrede nur aus bereits verifiziertem Kontext ableiten; Unsicherheit → Review ohne erfundene Anrede.
7. Keine Freigabe zum direkten Kundenversand, Signatur COMARCH `INTL01 - Intel Deutschland GmbH` auswählen, Duplikate vermeiden.
8. **Entwurf speichern**, serverseitig Wiederauffindbarkeit prüfen; **keine Mail senden**.
9. `Nächster Schritt` → `Weiterleitung zur Überprüfung`; **Victor** als Review-Empfänger nur gemäß dem tatsächlich aufgenommenen UI-Vertrag.
10. Kommentar mit ca. fünf Wörtern: verständliche Kurzfassung des Falls, ggf. Blocker kennzeichnen. `Schritt ausführen` und Handoff verifizieren.
11. Keine erneute Weiterleitung bei Wiederholung/Retry; bereits vorhandene Entwürfe nicht überschreiben; bei uneindeutigem Fall kontrolliert zur menschlichen Sichtung statt frei formulieren.

## Offene Gates (durch Recording zu schließen)

- UI-Lokatoren / neue Frames und Speichermodus (Entwurf versus Senden).
- Technischer Nachweis des gespeicherten Entwurfs / Dialogzustände.
- Victor: impliziter Review-Empfänger oder explizite Auswahl?
- Reviewkommentar-Feld, Status-/Queue-Transition und Doppelverarbeitungs-Sperre.
- Echte Selektoren sind erst nach Aufnahme zu spezifizieren; bitte nicht raten.

## Einträge in der OneNote, die zusätzliche Regeln benötigen

- Nur sachlich einschlägige Fälle verwenden, keine pauschalen Antwort-Kopien.
- Adressänderungen: aktive versus ausgeschiedene versus IPP-Rentner; Zusatzbeschreibung als Kontext.
- Altera-Varianten, unterschiedliche Todesfall-Raten, Garantiezinsangaben 2022: Anwendungsfälle/Autorität prüfen.
- Historische Zinssätze und individuelle Zahlen/Umrechnungsfaktoren dürfen nicht pauschal als aktuelle Kundendaten ausgegeben werden.
- Behauptete Anlagen (Kontostand, Bescheinigung, finaler Leistungsbescheid), Passwort-Nachmails und Personendaten: nur bei tatsächlichem Nachweis und menschlicher Freigabe.
- Markdown-Linktexte und Linkziele aus der OneNote können divergieren; Linkziel nicht ungeprüft übernehmen.
