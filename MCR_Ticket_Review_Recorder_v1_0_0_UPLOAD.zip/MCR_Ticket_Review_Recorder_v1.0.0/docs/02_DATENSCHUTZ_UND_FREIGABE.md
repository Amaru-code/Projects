# Datenschutz und Freigabeprozedur

1. **Testfall statt reale Kundendaten.** Verwende möglichst einen genehmigten Demo-Fall, z. B. fiktiver Mitarbeiter, fiktive WWID, keine echten personenbezogenen Pensionsdaten.
2. Recorder erfasst auf dem Windows-System global F8/F9, Click-Positionen und Scrollbewegungen, **wertet aber nur Ereignisse aus Microsoft Edge** aus. Andere Tastendrücke werden vom Hook gar nicht protokolliert. Keine Payloads von Netzwerk, Browser-History oder E-Mails.
3. Ggf. aus Windows UI Automation sichtbare Steuerelementnamen werden streng auf technische UI-Texte reduziert. Unbekannte Texte werden als `REDACTED_UI_TEXT` protokolliert, IDs mit langen Zahlen und E-Mail-Adressen anonymisiert.
4. F8-Screenshots werden **ausschließlich** im lokalen `private/screens`-Ordner gespeichert. Diese Bilder können trotzdem sensible Daten enthalten.
5. `ANONYMISIEREN.cmd`: Für jedes Bild jede echte Person, E-Mail, WWID, Ticketnummer, Geburtsdatum, Adresse, Inhalt der E-Mail und Pensions-/Kontozahl schwärzen. Direkt danach manuell **freigeben**. Die Datei in `freigabe/screenshots` enthält dann deckende schwarze Bereiche, nicht nur optisch überlagerte Rechtecke.
6. MP4/WebM werden **nie** automatisch aus privaten Verzeichnissen übernommen. Manuell unter `freigabe/video` einfügen, und nur, wenn sie bereits sicher anonymisiert sind. Für sensible reale Bildschirmvideos lieber keinen Upload vornehmen.
7. `ABLAUF_NOTIZEN.md` kann von dir ergänzt werden. Der Export blockiert übliche Mailadressen und lange Kennungen in diesen Notizen als Sicherheitsnetz. Dies ist keine vollständige DLP-Prüfung; vor Upload prüfen.
8. `ERGEBNIS_ZIP_ERSTELLEN.cmd` exportiert ausschließlich die fünf technischen Dateien und explizit freigegebene Medien. ZIP-Manifeste enthalten Hash/Dateigrößen, eine ZIP-Verifikation prüft die Payload und erzeugt eine zusätzliche `.sha256`-Datei.
9. Prüfe vor Upload den ZIP-Inhalt: keine `private/`, keine sensiblen Daten, keine unanonymisierten Screenshots/Videos, keine Login-Informationen, kein Passwort, keine echten personenbezogenen Texte.

**Wenn du reale Kundendaten siehst:** Recorder stoppen, keine privaten Screenshots teilen, Testdaten verwenden. Keine Datenspeicherung in öffentlichen Online-Diensten ohne Unternehmensfreigabe.
