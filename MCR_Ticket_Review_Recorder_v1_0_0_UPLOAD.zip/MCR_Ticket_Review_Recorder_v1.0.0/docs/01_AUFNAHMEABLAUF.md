# Gezielte Aufnahme des REVIEW-Ticketflows

**Ausgangssituation:** Ein INTL01-E-Mail-Ticket ist bereits vorhanden und fachlich klassifiziert. Es hat Zuständigkeit, Dokumentenkategorie, Unterkategorie, den korrekten Member und eine **zusätzliche Beschreibung**, die der erste Ticketbot eingetragen hat. **Diese Beschreibung liefert Status/Plan-Zuordnung für die spätere Antwortauswahl.** Der zweite Bot sucht den Member nicht erneut und überschreibt diese Felder nicht.

Die folgende Demonstration erledigst **du manuell**, nicht der Recorder. Nach jedem Teilabschnitt `F8` drücken, sodass zusätzlich ein UI-Bild entsteht.

| Bereich | Was für den späteren Bot zu sehen sein soll | Besondere Rückfrage |
|---|---|---|
| 1. Ticketliste | Ansicht/Filter für **bereits vorbereitete** Tickets | Woran erkennt man eine ausgefüllte zusätzliche Beschreibung vor dem Öffnen? |
| 2. Öffnen | Exakte Klickfolge zum vorhandenen Ticket | Welches Element öffnet die Bearbeitung? |
| 3. Original-Nachricht | Position, über die die Original-E-Mail lesbar ist | MSG-Download oder direktes Textfeld? |
| 4. Zusatzbeschreibung | Wo Status und Plantext stehen | Beispiel anonymisiert als `USC XX/ PP+` etc. |
| 5. Antwort | Wie man **Antworttext einfügt**; keine reale Kundenmail kopieren | Editor, eigener Tab oder Frame? |
| 6. Signatur | `INTL01 - Intel Deutschland GmbH` auswählen | Wird automatisch angehängt, muss man im Editor kontrollieren? |
| 7. Entwurf speichern | **Ungesendete** Antwort sichern | An welchem Button ist erkennbar, dass nicht versendet wird? |
| 8. Verifikation | Entwurf ggf. nochmals öffnen | Bleibt der Text samt Signatur erhalten? |
| 9. Nächster Schritt | Dropdown/Bedienfolge | Wo `Weiterleitung zur Überprüfung` auswählen? |
| 10. Review-Ziel | Weiterleitung an **Victor** | Muss Victor ausdrücklich im UI gewählt werden? |
| 11. Kommentar | In ca. 5 Wörtern den Fall zusammenfassen | Welche Stelle und welches Format? |
| 12. Ausführen | `Schritt ausführen` auslösen | Dialog, Bestätigung, mögliche Warnungen? |
| 13. Verifikation | Neuer Status/Queue und gespeicherter Antwortentwurf | Woran erkennt man den erfolgreichen Review-Handoff? |

**Wichtig:** Die Demonstration sollte nach Möglichkeit mit einem autorisierten Dummy-/Testticket und fiktiver Kundenmail erfolgen. Bei realen Vorgängen keine nicht autorisierten Änderungen oder Weiterleitungen auslösen. Der Recorder speichert keine Eingabetexte; der manuelle Ablauf darf trotzdem COMARCH verändern.

## Was mit der Aufnahme bewiesen werden soll

- Ein bereits klassifiziertes Ticket kann ohne Änderung der Erstbot-Felder geöffnet werden.
- Der Antworteditor lässt einen nicht versendeten Entwurf zu und speichert ihn dauerhaft.
- Die COMARCH-Signatur lässt sich korrekt auswählen.
- Der Review-Schritt, das interne Ziel Victor, der Kurzkommentar und `Schritt ausführen` sind eindeutig auffindbar.
- Falls COMARCH Zwischenzustände oder Bestätigungsdialoge zeigt, sind diese dokumentiert.

## Was ausdrücklich NICHT Inhalt dieses Recorder-Projekts ist

Kein KI-Modell, keine Klassifikation, kein automatisches E-Mail-Verfassen, kein Versand und keine Live-Ticketverarbeitung. Der eigentliche zweite Bot wird **nach** dem Recording gebaut.
