# Rückgabe nach Testlauf

Bitte zurückgeben:

- [ ] `SELBSTTEST.cmd`-Ausgabe (PASS oder Fehlertext)
- [ ] `output/exports/MCR_TICKET_REVIEW_..._UPLOAD.zip`
- [ ] Prüfsumme aus Konsole / `.zip.sha256` (optional)
- [ ] `ABLAUF_NOTIZEN.md` vollständig anonymisiert ausgefüllt
- [ ] Mindestens einige **geschwärzte** Screenshots mit Editor/Signatur/Review-Aktionen im ZIP
- [ ] Optional anonymisierte Videodatei (wenn möglich und freigegeben)
- [ ] Bestätigen, ob der manuelle Test-Ticket-Durchlauf nach `Schritt ausführen` erfolgreich zur Überprüfung an Victor gelangt ist
- [ ] Beobachten, ob das gespeicherte E-Mail-Feld nach Wiederöffnen persistiert

**Nicht zurückgeben:** `private/screens`, echte E-Mails, Kundenstammdaten, WWIDs, echte Anhänge, Passwörter oder Cookies.

Der nächste Arbeitsschritt ist die Implementierung eines **eigenständigen** neuen Answer/Review-Bots, der die stabile V1/Beta4-Installation nicht überschreibt.
