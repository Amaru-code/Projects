DMS: Muster Antworten

Freitag, 28. April 2023

13:32



-

1. Muster Antwort Warteschlange (Montags und Donnerst

Dear [Member's Name],

thank you for reaching out to us. This email is to confirm that we have received your ticket and our team is currently working on it. We appreciate your patience and understanding as we strive to provide you with the best possible support.

Rest assured that your request is important to us, and we are committed to resolving it as quickly as possible. Our dedicated team is actively working on your ticket and will provide updates as progress is made.

If you have any additional information or questions regarding your ticket, please feel free to reply to this email.\
 

\
Sehr geehrter Herr XXX,

\
vielen Dank, dass Sie sich mit uns in Verbindung gesetzt haben.



Mit dieser E-Mail möchten wir Ihnen bestätigen, dass wir Ihr Ticket erhalten haben und unser Team derzeit daran arbeitet. Wir wissen Ihre Geduld und Ihr Verständnis zu schätzen, da wir uns bemühen, Ihnen den bestmöglichen Support zu bieten.

Seien Sie versichert, dass Ihr Anliegen für uns wichtig ist und wir uns bemühen, es so schnell wie möglich zu lösen. Unser engagiertes Team arbeitet aktiv an Ihrem Ticket und wird Sie über den aktuellen Stand der Dinge informieren.

Wenn Sie weitere Informationen oder Fragen zu Ihrem Ticket haben, können Sie gerne auf diese E-Mail antworten.







1. (Log-in MBC mit privater E-Mail) Frage von einem aktiven Mitarbeiter:

Ich werde mein Arbeitsverhältnis bei Intel am TT.MM.JJJJ beenden.

Bitte ändern Sie mein Login auf meine persönliche E-Mail.

### Antwort:



Sehr geehrter Herr/Sehr geehrte Frau #NACHNAME,

vielen Dank für Ihre Nachricht.

Der Wechsel zu einer privaten E-Mailadresse ist nicht möglich. Das Mercer Benefit Center soll als Plattform zur Bereitstellung von jährlichen Leistungsnachweisen an aktive Mitarbeiter genutzt werden. 

Nach Ausscheiden aus dem Unternehmen erhalten Sie postalisch eine Bestätigung Ihrer Anwartschaften in den verschiedenen Pensionsplänen bei Intel. Diese Bestätigungen ersetzen die jährlichen Leistungsnachweise und behalten insbesondere über den Austritt hinaus ihre Gültigkeit.

Wir stehen danach weiterhin als Ansprechpartner zur Intel-bAV zur Verfügung. 





### Englisch:

Dear Ms. / Mr. XXXX,

thank you for your message.

It is not possible to switch to a private email address.

The Mercer Benefit Center should only be used by active members as a portal to provide them their annual performance records. After leaving the company you will receive a confirmation of your entitlements in the various pension plans with Intel by post. These confirmations replace the annual account statement and are also valid after leaving the company.



Nevertheless, we remain available as a contact partner for Intel pension plans.





1. (Kontoauszug update + MBC log in) Frage von einem ehemaligen Mitarbeiter:

*kommt in der Regel von Mitarbeitern, die Intel verlassen haben, als Aon Administrator war*

Ich war von X bis Y bei Intel beschäftigt.

Können Sie mir die aktuelle Höhe meiner Rentenanwartschaft mitteilen?

Bitte geben Sie mir auch Zugang zu Ihrem Mitarbeiterportal.

### Antwort:

Sehr geehrter Herr/Sehr geehrte Frau #NACHNAME,

vielen Dank für Ihre Nachricht.  



Nach Ihrem Austritt aus dem Intel-Unternehmen haben Sie Unverfallbarkeitsbescheinigungen für Ihre Anwartschaften erhalten. Diese stellen den Wert zum Austrittszeitpunkt dar und sind immer noch gültig. Der Zugriff auf unser Portal ist nur mit einer gültigen Intel-Emailadresse möglich.



Die Versorgungsordnung sieht keine jährlichen Informationsschreiben nach Ende des Beschäftigungsverhältnisses mehr vor. Auf Basis Ihrer Anfrage erhalten Sie eine aktualisierte Übersicht Ihres Kontostands.

Im Leistungsfall wird eine vollständige Aktualisierung der Berechnungen und Werte vorgenommen und Ihnen mitgeteilt.

Zum Schutz der personenbezogenen Daten sind wir verpflichtet, die Übersicht Ihres Kontostandes mit einem zu sichern. Dieses teilen wir Ihnen in einer zweiten Email mit.

### Englische Version (ggf. ergänzen, wenn aktualisierte Übersicht erstellt werden soll):



Dear Ms./Mr. XXXX,

thank you for your email.



After leaving the Intel company you received vesting certificates for your entitlements. These represent the value at the time of departure and are still valid. Access to our portal is only possible with a valid Intel email address.



The pension plan no longer provides annual information letters after employment ends.

Attach we send you an updated overview of your account balance as well as an annex to this.

To protect personal data we are obliged to save the overview of your account balance with a password. You will receive this password in a second email.

In the event of a benefit claim, a complete update of the calculations and values will be made and communicated to you.





1. (Erste Log-in MBC / Passwort vergessen MBC) Anfrage von einem aktiven Mitarbeiter:

Wie kann ich mich einloggen / Wie lautet mein Benutzername / usw.

### Antwort:

Sehr geehrter Herr/Sehr geehrte Frau #NACHNAME,

vielen Dank für Ihre Nachricht.



Um Ihren Account initial zu aktivieren und ein Passwort festzulegen, folgen Sie bitte den folgenden Schritten: 



Sie erreichen das Mercer Benefit Center über den Link: [https://benefitcenter.mercer.com/en/](https://www.blogger.com/blog/post/edit/6533867811114114585/959072135751825868#)



Dort wählen Sie bitte den Menüpunkt „Passwort vergessen / Neuer Benutzer“ aus und tragen im anschließenden Fenster Ihren Nutzernamen ein. Dieser setzt sich aus Ihrer 8-stelligen Intel-

WWID und der Endung [„@intel.com“ zusammen (Bsp. 12345678@intel.com).](https://www.blogger.com/blog/post/edit/6533867811114114585/959072135751825868#)



Im Anschluss erhalten Sie nacheinander mehrere Emails an Ihre private Emailadresse. Mit diesen Emails werden Sie aufgefordert, die Emailadresse zu bestätigen, und anschließend wird Ihnen ein temporäres Passwort übermittelt. Bitte nutzen Sie dieses Passwort, um sich beim MBC anzumelden und ein dauerhaftes Passwort zu setzen. Damit schließen Sie den Registrierungsprozess ab.  

### Englische Version:

Dear Mr. / Ms. #NACHNAME

thank you for your message.

To initially activate your account and set a password, please follow the steps below: 



You can access the Mercer Benefit Center by clicking on the link:

[https://benefitcenter.mercer.com/en/](https://www.blogger.com/blog/post/edit/6533867811114114585/959072135751825868#)



There please select the menu item "Forgotten password / New user" and enter your user name in the subsequent window. This consists of your 8-digit Intel-WWID and the ending

"[@intel.com" (e.g. 12345678@intel.com).](https://www.blogger.com/blog/post/edit/6533867811114114585/959072135751825868#)



You will then receive several emails in succession to your private email address. With these emails you will be asked to confirm the email address and then a temporary password will be

sent to you. Please use this password to log in to the MBC and set a permanent password. This will complete the registration process.





1. Adressänderung UVA

### Antwort:

Sehr geehrter Herr/Sehr geehrte Frau #NACHNAME,

vielen Dank für Ihre Email. Wir haben Ihre neue Adresse zu Ihren Unterlagen hinzugefügt. Grundsätzlich ist es nicht notwendig, dass Sie uns über Ihre Postanschrift dauerhaft informieren. Zum Zeitpunkt des Versorgungsfalls (wegen Alter, Invalidität oder Tod) müssen die Leistungen bei Intel/ Mercer beantragt werden. In diesem Zusammenhang wird eine vollständige Datenprüfung durchgeführt werden.



English version:

Dear Mrs./ Mr. #NACHNAME,

thank you for your email. We added your new address to our documents. In general it is not necessary to keep us up to date constantly about your postal address. At the time of a pension event (because of age, disablement or death) the benefits have to be claimed at Intel. At this time a full check of your data will be done.





1. Adressänderung einer aktiven Mitarbeiterin (für UVAs siehe Nr. 4)

### Antwort:

### Sehr geehrter Herr XXXX, / Sehr geehrte Frau XXXX,

vielen Dank für Ihre Email.

Aktualisieren Sie bitte Ihre Informationen im Workday-System. Wir erhalten die persönlichen Daten von dort und aktualisieren sie alle paar Monate in unserem Portal.



English version:

Dear Mr./Mrs. #LASTNAME

Thank you for your email.

Please update your Information in the Workday System. We retrieve your personal Information from Workday every couple of months and use it to update our portal.





Adressänderung Rentner: IPP --> Soll sich direkt an Persema wenden: Telefon: 06151 49304-10 oder E-mail: [**info@persema.de**](https://www.blogger.com/blog/post/edit/6533867811114114585/959072135751825868#)





1. Aktiver Member frägt nach, warum sich der Garantiezins von 0,90% auf 0,25% abgesenkt hat.

### Antwort:

Sehr geehrter Herr XXXXXX, / Sehr geehrte Frau XXXXX,

vielen Dank für Ihre Nachricht. Der Garantiezins wird für jedes Geschäftsjahr von Intel selbst festgelegt. Die meisten Firmen richten sich bei dessen Festlegung nach dem Höchstrechnungszins, den wiederum das Bundesfinanzministerium für jedes Jahr festlegt. Wie der Name bereits sagt, handelt es sich hierbei um den höchsten Zinssatz, den Unternehmen gewähren dürfen. Im Jahr 2021 betrug dieser 0,90%, während er für das Jahr 2022 auf 0,5% abgesenkt wurde.





1.  Frage eines aktiven Mitarbeiters, warum Anhebungsbetrag bei Tod oder Invalidität von 2021 auf 2022 stark gesunken ist.

### Antwort:

Sehr geehrte/r Herr/ Frau XXXX,

vielen Dank für Ihre Nachricht.

Zur Ermittlung des Anhebungsbetrages, also der Leistung im Todesfall (oder bei Invalidität), wird der bei Eintritt des Versorgungsfalls erreichte Stand des Versorgungskontos (einschließlich Schlussüberschussgutschrift\*) aufgezinst bis zum Zeitpunkt der Vollendung des 63. Lebensjahres des Mitarbeiters bzw. der Mitarbeiterin mit dem zum Zeitpunkt des Versorgungsfalles maßgeblichen Garantiezinssatz. Die Änderung, die Sie ansprechen, kommt dadurch zustande, dass sich die Anzahl der Jahre bis zum Zeitpunkt der Vollendung des 63. Lebensjahres um eins vermindert und der Garantiezins von 0,90% in 2021 auf 0,25% in 2022 herabgesenkt hat.



\*Zusätzlich wird ein virtuelles Versorgungskonto (Schattenkonto) geführt. Grundlage der Verzinsung des Schattenkontos ist die Performance des "TRUST DER MERCER TREUHAND GmbH". Bei Eintritt des Versorgungsfalls, spätestens jedoch zusammen mit der jährlichen garantierten Zinsgutschrift zum Bereitstellungsstichtag im Alter 60, wird einmalig ein Schlussüberschuss dem Versorgungskonto gutgeschrieben. Der Schlussüberschuss beträgt 95% der Differenz zwischen Schattenkonto und Versorgungskonto.





1. Frage eines aktiven Mitarbeiters, warum Zinsgutschrift 2021/22 stark gesunken ist.

### Antwort:

Sehr geehrte/r Herr/ Frau XXXX,

vielen Dank für Ihre Nachricht.

Der Garantiezins entspricht dem jährlichen Höchstrechnungszins der deutschen Versicherungswirtschaft für Neuverträge. Im Jahr 2021 betrug dieser 0,90% und wurde für das Jahr 2022 auf 0,25% abgesenkt.



Dies ist in den Allgemeinen Versorgungsbedingungen (GBV PP+: Anlage 1) 4.2.2 geregelt und im MBC Download Center verfügbar.





1. Aktiver erhält Renteninformation von Generali Deutschland AG als Brief (= Servicepartner von Proxalto Lebensversicherung AG) und lädt sich außerdem auf MBC den LNW von uns herunter.

Frage: Beide zeigen unterschiedliche Beträge an. Sind beide gültig oder ist einer falsch?

Antwort: p

Sehr geehrter Herr/ Frau XXXX,

die Rentenzusage nach der Versorgungsordnung vom 01.01.2005 ist mit einer Rückdeckungsversicherung verbunden. In die Rückdeckungsversicherung wird der gesetzlich maximal zulässige Höchstbeitrag eingezahlt, ohne dabei zusätzliche Steuerbelastungen für Sie zu erzeugen. Die Regelung hierzu finden Sie in der Zusage unter Ziffer XIII., die Ihnen im MBC zur Verfügung steht.

Seit 2022 sind die Versicherungen verpflichtet, Standmitteilungen an alle Versorgungsberechtigten zu versenden, auch wenn die Leistungen einen Teil einer größeren Zusage darstellen. Aus diesem Grund erhalten Sie seither zusätzlich zum jährlichen Leistungsnachweis von Intel auch eine Übersicht von der Generali.



Englische Version:

Dear Mr./ Mrs. XXXX,



both statements are valid and correct.



Intel has included insurance benefits into the corporate pension to create some tax-free benefits as well as to secure the pension benefits. Due to change in German insurance law, Proxalto must inform you about the pension benefits, although the pension benefits will be credited into Intel's pension benefits.



The inclusion of the insurance into Intel's pension promise is explained in the pension plan documentation under section XIII. You can find a copy of the plan documents in MBC under downloads as well as in Intel's Retirement Circuit.



1. Ausgeschiedene/r möchte jährlich Kontostandsübersicht haben.

### Antwort:

Sehr geehrte/r Frau/ Herr XXXX,

vielen Dank für Ihre Nachricht. 

Nach Ihrem Austritt aus dem Intel Unternehmen haben Sie Unverfallbarkeitsbescheinigungen für Ihre Anwartschaften erhalten. Diese stellen den Wert zum Austrittszeitpunkt dar und sind immer noch gültig. Zusätzlich liegt Ihnen nun Ihre aktualisierte Kontoübersicht vor.



Die Versorgungsordnung sieht keine jährlichen Informationsschreiben nach Ende des Beschäftigungsverhältnisses mehr vor.

Da der einzige Unterschied jedes Jahr die Garantiezinsgutschrift wäre, wäre der Unterschied bei den jährlichen Aktualisierungen relativ gering.

Auf Anfrage sind wir gerne bereit, eine aktualisierte Übersicht zu erstellen.



Im Leistungsfall wird in jedem Fall eine vollständige Aktualisierung der Berechnungen und Werte vorgenommen und Ihnen mitgeteilt.





1. UVAs erhalten aktualisierte Kontostände und die Anlage zur Unverfallbarkeitsbescheinigung IPP:

### Antwort:

Sehr geehrter Herr ,



Vielen Dank für Ihre Nachricht.



Anbei senden wir Ihnen die aktualisierte Übersicht Ihres Kontostandes.



Englische Version:

Dear Ms./ Mr. XXXX,

attach we send you an updated overview of your account balance as well as an annex to this.

To protect personal data we are obliged to save the overview of your account balance with a password. You will receive this password in a second email.



### Zusendung Passwort in zweiter Email:

Sehr geehrte/r Frau/ Herr XXXX,

das Passwort zum Öffnen lautet: *INTL01_nachname*

### Zusendung Passwort in zweiter Email (Englisch):

### Dear Ms./Mr. XXXX,

Please use the following password to open the files provided with previous email: *INTL01_nachname*





1. Ausgeschiedener möchte wissen, wer nach Abteilungskauf durch Apple 2019 für Anwartschaft zuständig ist

### Antwort:

Sehr geehrter Herr Henry,

 vielen Dank für Ihre Nachricht.

Leider müssen wir Sie darüber informieren, dass Aon Sie fälschlich zu uns weitergeleitet hat. Vermutlich handelt es sich um eine automatisierte Antwort, weil Sie sich an eine "alte" Lantiq-Serviceemailadresse gewendet haben.

Im Rahmen des Verkaufs 2019, wurde auch die vollständige Anwartschaft, die Sie bei Intel/Lantiq hatten, zu Apple übertragen. Demnach ist Aon als Verwalter der Apple-Versorgungspläne weiterhin Ihr Ansprechpartner. Leider ist uns nicht bekannt, an welche Email Sie sich nun wenden können. Diese Info sollten Sie bei der Apple Personalabteilung erfragen können.

 Wir hoffen, dass sich Ihre Anfrage an anderer Stelle bald klären lässt.





1. Rentenempfänger/in frägt, was im Todesfalle mit Auszahlung (als Rente oder in Raten etc.) passiert

### Antwort:

Sehr geehrte/r Herr/ Frau XXXX,

vielen Dank für Ihre Nachricht.

Tritt der Tod nach Beginn der Auszahlung in Form einer lebenslagen Renten ein, so erwirbt zunächst der/die Ehepartner/in den Anspruch auf die Todesfallsumme. Falls kein/e Ehepartner/in existiert, erwerben die Kinder (im Sinne von § 32 Abs. 3 und 4 Satz 1 Nr. 1 bis 3, Abs. 5 EStG) diesen Anspruch. Die Todesfallsumme beträgt dann 60 % des zum letzten Bilanzstichtag des Unternehmens vor dem Todesfall ermittelten Barwerts des bestehenden Rentenanspruchs. Für die Auszahlung der Todesfallsumme gelten die vorstehenden Auszahlungsbestimmungen entsprechend. Das bedeutet, dass der/die Ehepartner/in wiederum aus den bekannten Auszahlungsoptionen (mtl. Rente, Auszahlung als Einmalkapital oder in Raten) wählen kann.



Erfolgt die Auszahlung in Jahresraten, geht der rechtliche Besitzstand des gesamten Kapitals zum Zeitpunkt des Versorgungsfalls auf Sie über. Im Fall eines Todes nach Versorgungsfall geht der Anspruch des noch nicht ausgezahlten Kapitals an Ihre gesetzlichen Erben über. Die Auszahlung wird dann entweder in der vereinbarten Form fortgeführt oder als Einmalkapital ausgezahlt.



Im Todesfall vor Eintritt des Versorgungsfalls und Beginn der Auszahlung, findet die Regelungen der Versorgungsordnung für Hinterbliebene Anwendung. In diesem Fall hat der/die Ehepartner/in die Möglichkeit aus den bekannten Auszahlungsoptionen (mtl. Rente, Auszahlung als Einmalkapital oder in Raten) zu wählen.





1. Findet alle 3 Jahre eine Überprüfung der Höhe bei 12-Jahresratenoption statt?

### Antwort:

Sehr geehrte/r Frau/Herr XXXX,

vielen Dank für Ihre Nachricht.

Zum Jahresende des Versorgungsfalls wird ein Ratenzins festgelegt. Um diesen Zinssatz werden die Raten jährlich angehoben. Der Zinssatz entspricht mindestens dem Garantiezinssatz der Zusage.

Hierzu Punkt 4.7.1 in Anlage 1 GBV INTEL DEUTSCHLAND PENSIONSPLAN+ (Stand: 29.06.2015):

"(...) Jeder Teilbetrag wird ab dem Versorgungsfall bis zu seiner Fälligkeit als Rate nach jeweils 12 Monaten mit dem vom Unternehmen nach Satz 6 festgelegten Zinssatz – mindestens jedoch mit dem bei Eintritt des Versorgungsfalles maßgeblichen Garantiezinssatz (4.2.2) – des zuvor erreichten Stands, bei weniger als 12 Monaten zeitanteilig, angehoben. Das Unternehmen legt den Zinssatz jeweils am Geschäftsjahresende für die im folgenden Geschäftsjahr beginnenden Ratenzahlungen in Höhe der Rendite von 8-jährigen bzw. 12-jährigen Bundesanleihen (Rendite in % bei einer Restlaufzeit von 8 bzw. 12 Jahren) entsprechend der Ratenanzahl laufzeitabhängig fest. Der festgelegte Zinssatz ist für die gesamte Ratenlaufzeit maßgebend. (...)"





1. Bis wann muss die Erklärung zur Optionswahl vorliegen (Auszahlungsoptionen Versorgungsguthaben)?

### Antwort:

Die Entscheidung bezüglich der Auszahlung ist bis Ende des Kalenderjahres zu treffen. Mit Beginn des nächsten Kalenderjahres verlieren die Optionen Ihre Gültigkeit. Eine Anbindung an die gesetzliche Rente liegt nicht vor.





1. Ist ein Dokument als Übersicht vorhanden?

### Antwort:

Im Anhang dieser Email finden Sie zum einen die vollständigen Planregelungen sowie eine grobe Zusammenfassung, die aber nur informatorischen Charakter haben kann.

### Anhänge:

Vollständige Planregelungen (dort auch auf Englisch):

[\\\MERCER.COM\EU_DATA\MUN\KUNDE\INTL01\1_Dauerakte\1_4_Zusagen\1_4_2_VOen\\\_Blanko für Versand\GBV Pensionsplan+ inkl. Anlage 1 und 2.pdf](https://www.blogger.com/blog/post/edit/6533867811114114585/959072135751825868#)

Grobe Zusammenfassung:

[\\\MERCER.COM\EU_DATA\MUN\KUNDE\INTL01\7_Personen\ZZ - Vorlagen für Kundenkommunikation\Anlage zur Unverfallbarkeitsbescheinigung_IPP.pdf](https://www.blogger.com/blog/post/edit/6533867811114114585/959072135751825868#)





1. Auszahlungsoptionen IPP versenden:

### Antwort:

Sehr geehrte/r Herr/ Frau XXXX,



anbei senden wir Ihnen eine Übersicht über die Auszahlungsoption aus dem Pensionsplan+. Bitte teilen Sie uns Ihre Entscheidung bzgl. der gewünschten Auszahlungsoption mit, indem Sie uns dieses Schreiben unterschrieben zurücksenden.







1. Was besagen Eckwerte und Steigerungsbeiträge, wann werden sie angewendet, Auswirkung dieser auf Kapital (Initialbaustein und Versorgungskonto)?

### Antwort:

Die Eckwerte und Steigerungsbeiträge dienen der Berechnung des jährlichen Beitrages im Intel Pensionsplan+ und insofern wirken sie sich auf die Höhe des Versorgungskontos aus (auf den Initialbaustein findet dadurch keine Auswirkung statt). Genaueres zur Berechnung lässt sich in dem angehängten Pensionsplan nachlesen (Anlage 1, Punkt 3.2 Beitragshöhe).





1. Fragen zu Garantiezins (-anhebung), Überschüssen

### Antwort:

Das Unternehmen gewährt (Schluss-)Überschussgutschriften auf Grundlage einer theoretischen Vermögensanlage. Näheres dazu ist im Intel Pensionsplan in der Anlage 1 zur GBV unter den Punkten 4.2 und 4.3 nachzulesen. Sie finden die Angaben zu Überschussgutschriften auch auf jedem Ihrer Kontoauszüge des Intel Pensionsplans+ als Teil des Todesfallkapitals. Beachten Sie bitte, dass die Überschussgutschrift erst im Alter 60 bzw. zum Zeitpunkt eines vorzeitigen Versorgungsfalls gutgeschrieben werden. Bis dahin gibt es hierauf keine Garantie.

Der Garantiezins orientiert sich am Höchstrechnungszins der Lebensversicherungen in Deutschland und wird für den Pensionsplan+ jährlich festgestellt. Näheres dazu in der Anlage 1 unter Punkt 4.2. Über den Zeitpunkt einer möglichen Anhebung des Höchstrechnungszinses in der Lebensversicherung liegen uns keine Informationen vor.





1. Ist eine Kündigung und Auszahlung des Versorgungskontos vor Versorgungsfall möglich?

### Antwort:

Die betriebliche Altersvorsorge hat den Zweck, im Falle von Alter, Invalidität oder Tod Leistungen zu erbringen, die vor dem Versorgungsfall angesammelt wurden. Die Beiträge, die Intel Ihnen im Rahmen dieser Zusage zur Verfügung stellt, können nicht ausgezahlt oder anderweitig verwendet werden. Eine Auszahlung der Leistungen vor Eintreten eines Versorgungsfalles außerhalb der im Pensionsplan+ festgelegten Bestimmungen ist nicht möglich.





1. Welche Rentenbezugsmöglichkeiten gibt es?

### Antwort:

Informationen zu einer Verrentung des Versorgungsguthabens finden Sie in der Anlage 1 unter den Punkten 4.7.2 und 4.7.2.2. Die Regelungen zur Garantierente sind in Anlage 2 unter Punkt 3.3.2 ff gegeben. Ihre Garantierente wurde gekürzt, da Sie vor Erreichen des 60. Lebensjahres aus dem Unternehmen ausgeschieden sind.





1. Warum wurde Initialbaustein nicht verzinst?

### Antwort:

Informationen zum Initialbaustein bei Austritt mit unverfallbarer Anwartschaft erhalten Sie in der Anlage 2 unter Punkt 3.2.4. Darin ist geregelt, dass der Initialbaustein auf Grundlage einer Rentenanwartschaft im Jahr 2006 ermittelt wird, indem dieser bis zum Alter 60 mit einem festen Zinssatz verzinst wird. Bei Ausscheiden vor Alter 60 bleibt Ihnen der Anteil des Initialbausteins erhalten, der Ihrer tatsächlichen Dienstzeit entspricht. Ab Alter 61 wird der Initialbaustein analog zum Versorgungskonto des Pensionsplan+ verzinst.





1. Aktiver schickt Rentenantrag aus DC und DC+ zurück mit Fragen zu Aufteilung des Guthabens:

### Antwort:

Sehr geehrte/r Frau/Herr XXXX,



gerne gehen wir näher auf die beiden Anwartschaften ein.



Die Zusage "Deferred Compensation" basiert auf der Zusage, die ursprünglich bei Infineon gegeben wurde und im Rahmen des Betriebsübergangs zu Intel übertragen wurde. Diese Zusage wurde dann bei der Intel Mobile Communication unverändert weitergeführt.

Zum 29.06.2015 wurde dann für die Intel Deutschland GmbH die Betriebsvereinbarung "Deferred Compensation+" abgeschlossen, um die Möglichkeit der Bonusumwandlung auf alle Mitarbeiter bei der Intel Deutschland GmbH zu erweitern. Diese Zusage ersetzt die zuvor existierende Zusage, die nur für Mitarbeiter der Intel Mobile Communication gegolten hat.



Auch wenn die Zusagen nahezu identisch sind, sind die Anwartschaften arbeitsrechtlich getrennt zu behandeln. Das gilt sowohl für die Garantiekapitalien als auch für die zugehörigen Fondsanlagen. Diese liegen in getrennten Depots vor, sodass eine Zuordnung der Anlagegewinne zu den beiden Anwartschaften möglich ist.



##  

1. Rentenhöhe zum Pensionierungszeitpunkt in der Zukunft

Antwort:



Sehr geehrte/r Frau/Herr XXXX,



vielen Dank für Ihre Nachricht. Gerne beantworten wir Ihre Fragen.



Nach Austritt werden wir Ihnen eine abschließende UV-Berechnung erstellen und zukommen lassen.



Ein Simulationstool bieten wir nicht an, da dies von Intel nicht beauftragt und technisch umgesetzt war. Zum aktuellen Zeitpunkt können wir Ihnen lediglich damit behilflich sein, Ihnen den aktuell gültigen Umrechnungsfaktor zu nennen.

Die Umrechnung des Versorgungskapitals in eine monatliche Rente hängt vom Zeitpunkt des Rentenbeginns, Ihrem Geburtsjahrgang, sowie der zukünftigen Renditeerwartung der 15-jährigen deutschen Bundesanleihen ab. Letztere wird jeweils für ein Kalenderjahr festgestellt und unterliegt aktuell sehr starker Schwankungen. Für 2025 gilt ein Zinssatz von 2,60%. Wie sich dieser für 2026 und weiter in die Zukunft entwickelt, ist nicht vorhersehbar noch abschätzbar.



Für 2025 gilt für Sie der Umrechnungsfaktor XXX,XX. Dieser Wert auf Grundlage der Renditeerwartung zum 31.12.2025 für 2026 aktualisiert und kann deutlich verändert ausfallen. Diese Auskunft begründet keinen Rechtsanspruch, sollte die Renditeerwartung in 2026 geringer ausfallen als 2025.



Die Monatsrente können Sie mit der Garantierente und Ihrem aktuellen Versorgungskapital wie folgt berechnen:

   Garantierente + (Versorgungskapital - Garantierente \* 175) / XXX,XX



1. DB-Member frägt nach Kontostandsentwicklung bei Austritt vor Rentenalter

Antwort:

In case you leave the company before the benefits become due, you will maintain a vested entitlement for all benefits under the plan.

The values in the account statement referring to the pension at normal retirement age / rly retirement are projections.



The amount given in proportional retirement pension (Höhe der unverfallbaren Altersrente) however is not a projection.

This is the amount of promised retirement pension you have accumulated as of 31.12.2022.

In other words if you had left Intel on 31.12.2022, this would have been the yearly pension you would have received at normal retirement age.



Your vesting factor as of 31.12.2022 was 74,96%. The longer you stay at the company, the higher your factor will go.

If your salary does not drop drastically in the next years, you can expect the vested retirement pension to go up.



1. IPP-Member frägt nach Rente 60 vs. Rente 65:

Antwort:

Zur monatlichen Rente zum Alter 65:

Die Umrechnung des Versorgungskapitals in eine monatliche Rente hängt vom Zeitpunkt des Rentenbeginns, Ihrem Geburtsjahrgang sowie der zukünftigen Renditeerwartung der 15-jährigen deutschen Bundesanleihen ab. Letztere wir für jeweils ein Kalenderjahr festgestellt und unterliegt aktuell sehr starken Schwankungen. Für 2023 gilt ein Zinssatz von 2,58%. Wie sich dieser für 2024 und weiter in die Zukunft entwickeln wird, ist nicht vorhersehbar noch abschätzbar.

Auf dem Versorgungskonto wird bis zum Eintritt des Versorgungsfalles eine garantierte jährliche Zinsgutschrift erteilt.



1. Wenn Tickets länger liegen bleiben:

Sehr geehrte/r Frau/Herr XXXX,

vielen Dank für Ihre Nachricht.

Ihr Ticket ist nach wie vor in Bearbeitung. Aufgrund der hohen Anzahl von Anfragen benötigen wir aktuell mehr Zeit als üblich für die Bearbeitung. Wir halten Sie weiterhin auf dem Laufenden und kommen auf Sie schnellstmöglich zurück. Wir danken Ihnen für Ihre Geduld.



Englisch:

Dear Mrs./ Mr. XXXX,

thank you for your email. Due to the high number of requests, we currently need more time than usual for processing. We will continue to keep you up to date and get back to you as soon as possible. We thank you for your patience.



1. Es möchte jemand die Zusagen des IPP und DC zugeschickt bekommen:

K:\INTL01\1_Dauerakte\1_4_Zusagen\1_4_2_VOen\\\_Blanko für Versand

Für DC: GBV Deferred Compensation+ (idF 29.06.2015).pdf

Für IPP: GBV Pensionsplan+ inkl. Anlage 1 und 2.pdf



1. Private Mailadresse für Kommunikation in DMS hinterlegen:
   1. Archiv in DMS aufrufen
   2. "Memberdaten aktualisieren für nicht oPen Kunden" auswählen
   3. Kunde und Member eingeben
   4. Email private ausfüllen und speichern



1. IPP: Rentenoption als Auszahlungsvariante nicht möglich:

Für Sie steht aktuell die Rentenoption nicht zur Verfügung, da eine Verrentung des Guthabens nur ab der Mindesthöhe des jeweils 10-fachen der

monatlichen Bezugsgröße nach § 18 Abs. 1 SGB IV möglich ist. (aktuell € 3.395 x 10 = € 33.950)



1. Anfrage von Rentner zur Rentenerhöhung der Alten Leipziger:

Sehr geehrte/r Frau/ Herr XXXXX,



vielen Dank für Ihre Nachricht.



Aufgrund der Informationspflicht wurden Sie von der Alten Leipziger über Rentenerhöhungen informiert, die allerdings nicht direkt an die Mitarbeitenden, sondern an Intel ausbezahlt werden. Intel zahlt Ihnen eine Betriebsrente, in die dieser Betrag von der Versicherung mit einfließt. Intel wiederum prüft gemäß der gesetzlichen Vorgaben alle drei Jahre die Anpassung der laufenden Renten. Falls eine Erhöhung erfolgt, werden Sie (von Intel) gesondert informiert.



1. Frage an Persema:

Sehr geehrte/r Frau/ Herr XXXX,



die Persema Telefonhotline lautet 06151/49304-14 und ist nur von 09:00 Uhr bis 12:00 Uhr besetzt.









1. Ehepartner Anmeldung



Sehr geehrte/r Frau Herr,

herzlichen Glückwunsch zu Ihrer Hochzeit!

Sie müssen Ihr/e Mann/Frau nicht anmelden. Sofern eine Heirat vorliegt, kann sie die Leistungen im Todesfall mit einer Kopie der Heiratsurkunde beantragen.

##  

##  

1. Todes Fall nach Auszahlungsbeginn



Sehr geehrte\
\
 Tritt der Tod nach Beginn der Auszahlung in Form einer lebenslange Renten ein, so erwirbt zunächst der/die Ehepartner/in den Anspruch auf die Todesfallsumme. Falls kein/e Ehepartner/in existiert, erwerben die Kinder (im Sinne von § 32 Abs. 3 und 4 Satz 1 Nr. 1 bis 3, Abs. 5 EStG) diesen Anspruch. Die Todesfallsumme beträgt dann 60 % des zum letzten Bilanzstichtag des Unternehmens vor dem Todesfall ermittelten Barwerts des bestehenden Rentenanspruchs. Für die Auszahlung der Todesfallsumme gelten die vorstehenden Auszahlungsbestimmungen entsprechend. Das bedeutet, dass der/die Ehepartner/in wiederum aus den bekannten Auszahlungsoptionen (mtl. Rente, Auszahlung als Einmalkapital oder in Raten) wählen kann.\
\
Im Falle des Todes, bevor die jährlichen Raten vollständig ausgezahlt wurden, hat Intel beschlossen, den verbleibenden Betrag als Einmalzahlung auf Ihr Konto zu überweisen. Der Anspruch auf das noch ausstehende Kapital geht an Ihre gesetzlichen Erben über und wird entweder über das Familiengericht oder durch Ihr schriftliches Testament geregelt.



Im Todesfall vor Eintritt des Versorgungsfalls und Beginn der Auszahlung, findet die Regelungen der Versorgungsordnung für Hinterbliebene Anwendung. In diesem Fall hat der/die Ehepartner/in die Möglichkeit aus den bekannten Auszahlungsoptionen (mtl. Rente, Auszahlung als Einmalkapital oder in Raten) zu wählen.



1. Rentenberechnung/Leistungsberechnung PP+ versenden



Sehr geehrte ,\
\
vielen Dank für Ihre Geduld.\
\
Anbei erhalten Sie die endgültige Leistungsberechnung aus dem Intel Pensionsplan+.\
Der Payroll Dienstleiser Persema, wird sich bezüglich weiterer Information bei Ihnen melden.\
Das Passwort für die PDF Datei ist dasselbe wie zuvor.







1. Von Intel der wechsel zu Altera.\
   \
    

Sehr geehrter Herr/Sehr geehrte Frau #NACHNAME,

vielen Dank für Ihre Nachricht.

Der Wechsel zu einer privaten E-Mailadresse ist nicht möglich. Das Mercer Benefit Center soll als Plattform zur Bereitstellung von jährlichen Leistungsnachweisen an aktive Mitarbeiter genutzt werden. Bitte beachten Sie, dass Mitglieder, die von Intel zu Altera wechseln, keinen Zugriff mehr auf das Mercer Benefit Center haben.

Nach Ausscheiden aus dem Unternehmen erhalten Sie postalisch eine Bestätigung Ihrer Anwartschaften in den verschiedenen Pensionsplänen bei Intel. Diese Bestätigungen ersetzen die jährlichen Leistungsnachweise und behalten insbesondere über den Austritt hinaus ihre Gültigkeit.

Wir stehen danach weiterhin als Ansprechpartner zur Intel-bAV zur Verfügung.\
\
 

Dear Mr./Ms. #LASTNAME,

Thank you for your message.

Switching to a private email address is not possible. The Mercer Benefit Center is intended to be used as a platform for providing annual benefit statements to active employees. Please note that members who transfer from Intel to Altera will no longer have access to the Mercer Benefit Center.

After leaving the company, you will receive a confirmation of your entitlements in the various pension plans at Intel by postal mail. These confirmations replace the annual benefit statements and remain valid, especially beyond your departure.

We remain available as a contact for Intel occupational pension matters thereafter







1. Anfrage Altera\
    



Sehr geehrte(r) Herr / Frau



Mit Ihrem Wechsel zu Altera wurde auch Ihr Pensionsplan übertragen und wird von Ihrem aktuellen Arbeitgeber weitergeführt. Das Mercer Benefit Center ist nur mit einem aktiven E‑Mail‑Konto zugänglich, das für die Nutzung durch aktive intel‑Mitarbeitende vorgesehen ist. Bitte wenden Sie sich mit Fragen zu Ihrem Pensionsplan an Ihren aktuellen Arbeitgeber. Mercer ist zum jetzigen Zeitpunkt nicht als Planadministrator (plan administrator) für Altera‑Pensionspläne beauftragt.\
 





Dear Sir / Madam,

With your transfer to Altera, your pension plan was also transferred and is being continued by your current employer. The Mercer Benefit Center is only accessible with an active email account intended for use by active Intel employees. Please direct any questions regarding your pension plan to your current employer. Mercer is not currently appointed as the plan administrator for Altera pension plans.



1. Scheidungsfall\
   \
   Sehr geehrter Herr XXX\
    

Ob und wie Ihre bAV nach Ihrer Scheidung aufgeteilt wird, entscheidet das Familiengericht. Es wird von Intel ein Versorgungsausgleichgutachten zu Ihren bAV-Ansprüchen innerhalb des Unternehmens anfordern. Das Gutachten wird dem Gericht zusammen mit all Ihren weiteren Ansprüchen und den Ansprüchen Ihrer Ex-Frau vorgelegt.



Wenn das Gericht entscheidet, einen Ihrer Ansprüche aufzuteilen, wird es Intel über Art und Umfang der Aufteilung informieren. Bislang haben wir keine Anfragen vom Familiengericht erhalten.





1. DB Rentner fragt warum die Rente gleich geblieben ist, obwohl Anpassung zum 01.01 erfolgen soll



Sehr geehrter Herr/Frau



Vielen Dank für Ihre Geduld.



Die Anpassung nach §16 BetrAVG findet alle drei Jahre statt. Die Rentenerhöhung erfolgt immer rückwirkend zum 01.01. und wird gegen April/Mai berechnet.



1. DB Rentner fragt warum die Rente im letzten LNW höher war als im aktuellen



For calculating the company pension, the best three consecutive years of pensionable earnings within the last five years are used. Each of those three years is split into a portion up to the contribution assessment ceiling (Beitragsbemessungsgrenze, BBG) of the German statutory pension insurance and a portion above the BBG. The average is calculated separately for both portions over the three years and then multiplied by the years of service and a percentage (0.5% for the portion up to the BBG; 1.5% for the portion above the BBG).

A lower reported pension can therefore arise, for example, if

- a year that was included on last year’s statement now falls outside the five‑year window and thus drops out of the three‑year period, causing the average to worsen, or
- your three‑year period has increased overall but the BBG has risen even more, which reduces the share of your salary that is credited at the 1.5% rate.

F



Gelbe Teil anpassen, falls KA ist erstellt
