@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo   MCR Ticket Review Recorder v1.0.0 - START
 echo ============================================================
echo Keine Installation. Kein automatisches Klicken oder Senden.
echo F8 = Screenshot und Marker. F9 = Aufnahme beenden.
echo Bitte zuerst ein anonymisiertes Testticket vorbereiten.
echo.
%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0src\Recorder.ps1"
set "EXITCODE=%ERRORLEVEL%"
echo.
if not "%EXITCODE%"=="0" echo FEHLER: Recorder Exitcode %EXITCODE%.
echo Danach ANONYMISIEREN.cmd und ERGEBNIS_ZIP_ERSTELLEN.cmd nutzen.
pause
exit /b %EXITCODE%
