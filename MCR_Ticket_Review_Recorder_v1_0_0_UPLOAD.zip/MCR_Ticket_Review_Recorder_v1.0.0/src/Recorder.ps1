﻿[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
. (Join-Path $PSScriptRoot 'Privacy.ps1')

function Write-Ln([string]$s) { Write-Host $s }
if ($PSVersionTable.PSVersion.Major -ne 5) {
  Write-Host 'WARNUNG: Windows PowerShell 5.1 empfohlen. PS-Version:' $PSVersionTable.PSVersion
}
try {
  Add-Type -AssemblyName System.Windows.Forms
  Add-Type -AssemblyName System.Drawing
  Add-Type -AssemblyName WindowsBase
  Add-Type -AssemblyName UIAutomationClient
  Add-Type -AssemblyName UIAutomationTypes
  Add-Type -Path (Join-Path $PSScriptRoot 'NativeHooks.cs') -ErrorAction Stop
} catch {
  Write-Host 'FEHLER: Windows-Hooks / UIAutomation koennen nicht geladen werden.' -ForegroundColor Red
  Write-Host $_.Exception.Message
  exit 10
}
$config = Get-Content (Join-Path $root 'config\aufnahme.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$allowed = @($config.allowed_process_names | ForEach-Object { ([string]$_).ToLowerInvariant() })
$stages = @(Get-Content (Join-Path $root 'config\markierungen.txt') -Encoding UTF8)
$started = [DateTimeOffset]::Now
$stamp = $started.ToString('yyyyMMdd_HHmmss')
$id = [guid]::NewGuid().ToString('N').Substring(0,8)
$runName = 'run_' + $stamp + '_' + $id
$runDir = Join-Path $root ('output\' + $runName)
$privateScreens = Join-Path $runDir 'private\screens'
$approvedScreens = Join-Path $runDir 'freigabe\screenshots'
$approvedVideo = Join-Path $runDir 'freigabe\video'
New-Item -ItemType Directory -Force -Path $privateScreens,$approvedScreens,$approvedVideo | Out-Null
$eventsFile = Join-Path $runDir 'ereignisse.jsonl'
$utf8NoBom = [System.Text.UTF8Encoding]::new($false)
[System.IO.File]::WriteAllText($eventsFile,'',$utf8NoBom)
$markerCount = 0
$clicks = 0
$scrolls = 0
$privateShotCount = 0
$totalEvents = 0
$done = $false
$stopReason = 'UNEXPECTED_EXIT'
$startUtc = [DateTimeOffset]::UtcNow

function Add-RecordedEvent {
 param([System.Collections.IDictionary]$Item)
 $json = ConvertTo-Json -InputObject $Item -Depth 9 -Compress
 [System.IO.File]::AppendAllText($eventsFile,$json+[Environment]::NewLine,$utf8NoBom)
 $script:totalEvents++
}

function New-WindowScreenshot {
  param([string]$File,[object]$Window)
  # Only crop the foreground browser window. Never capture the full multi-screen desktop.
  if ($Window.Width -lt 100 -or $Window.Height -lt 100) { return $false }
  $virtual = [System.Windows.Forms.SystemInformation]::VirtualScreen
  $left = [math]::Max([int]$Window.Left,[int]$virtual.Left)
  $top = [math]::Max([int]$Window.Top,[int]$virtual.Top)
  $right = [math]::Min([int]($Window.Left+$Window.Width),[int]$virtual.Right)
  $bottom = [math]::Min([int]($Window.Top+$Window.Height),[int]$virtual.Bottom)
  $width = $right-$left; $height = $bottom-$top
  if ($width -lt 100 -or $height -lt 100 -or $width -gt 10000 -or $height -gt 10000) { return $false }
  $bmp = [System.Drawing.Bitmap]::new($width,$height)
  try {
    $graphics = [System.Drawing.Graphics]::FromImage($bmp)
    try {
      $graphics.CopyFromScreen($left,$top,0,0,[System.Drawing.Size]::new($width,$height))
    } finally { $graphics.Dispose() }
    $bmp.Save($File,[System.Drawing.Imaging.ImageFormat]::Png)
    return $true
  } catch { return $false }
  finally { $bmp.Dispose() }
}

$info = [ordered]@{
 schema = 'MCR_TICKET_REVIEW_RECORDING_V1'
 id = $runName
 app = 'MCR Ticket Review Recorder'
 version = '1.0.0'
 started_at = $started.ToString('o')
 browser_process_allowlist = $allowed
 mode = 'PASSIVE_OBSERVATION_NO_AUTOMATION'
 event_file = 'ereignisse.jsonl'
 private_screens_not_exported = $true
 keystrokes_text_passwords_clipboard_network_not_captured = $true
}
[System.IO.File]::WriteAllText((Join-Path $runDir 'run_info.json'),(ConvertTo-Json $info -Depth 5),$utf8NoBom)
$note = @'
# Ablaufnotizen - bitte nur anonymisierte technische Angaben

Ein bereits fertig klassifiziertes INTL01-Ticket mit vorhandener zusaetzlicher Beschreibung auswaehlen.
Status der Person (aktiv / ausgeschieden / Rentner) und Plan (DC / PP+ / DB+ / TPP) kommen aus der zusaetzlichen Beschreibung, NICHT aus einer neuen Stammdatenrecherche.

Bitte hier nach der Aufnahme ergaenzen:
- Wie wird das Ticket geoeffnet (Liste/Filter/Schaltflaeche)?
- Wo wird der Original-Email-Text angezeigt? Nur UI-Position, kein echter Kundeninhalt.
- Wo steht die zusaetzliche Beschreibung?
- In welchem Feld wird die fertige Antwort eingegeben? HTML/Text/iframe?
- Wo wird die Signatur "INTL01 - Intel Deutschland GmbH" gewaehlt?
- Welcher Klick speichert nur den ENTWURF, ohne Kundenversand?
- Wie wird "Naechster Schritt" -> "Weiterleitung zur Ueberpruefung" eingestellt?
- Muss "Victor" als Person eingegeben/ausgewaehlt werden?
- Wo wird der ca. 5-Wort-Reviewkommentar eingetragen?
- Was passiert nach "Schritt ausfuehren" (neuer Status, Meldung, Queue)?
- Kann man den gespeicherten Entwurf danach wieder oeffnen?
- Fehlt noch ein wichtiger Sonderfall?

ACHTUNG: Keine echten Namen, E-Mail-Adressen, Kontonummern, WWIDs oder Inhalte in diese Notizen kopieren.
'@
[System.IO.File]::WriteAllText((Join-Path $runDir 'ABLAUF_NOTIZEN.md'),$note,$utf8NoBom)

Write-Host ''
Write-Host '=====================================================' -ForegroundColor Cyan
Write-Host ' MCR REVIEW RECORDER | v1.0.0 | NUR AUFZEICHNUNG' -ForegroundColor Cyan
Write-Host '=====================================================' -ForegroundColor Cyan
Write-Ln ('Laufordner: ' + $runDir)
Write-Ln 'Bitte ein anonymisiertes TESTTICKET verwenden.'
Write-Ln 'Keine Tastatureingaben, keine E-Mail-Inhalte, keine Zwischenablage.'
Write-Ln 'Nur Ereignisse in Microsoft Edge (msedge) werden protokolliert.'
Write-Ln 'F8: Etappe markieren + PRIVATES Screenshot des Edge-Fensters.'
Write-Ln 'F9: Beenden. Anschliessend werden technische Logs exportiert.'
Write-Ln 'VIDEO optional: Windows+Shift+R starten, spaeter anonymisierte MP4 manuell unter freigabe\video ablegen.'
Write-Host ''

try {
  [McrTicketReview.NativeHooks]::Start()
  Write-Host 'AUFZEICHNUNG AKTIV. Jetzt zu Microsoft Edge wechseln.' -ForegroundColor Green
  while (-not $done) {
    [System.Windows.Forms.Application]::DoEvents()
    Start-Sleep -Milliseconds 35
    $nativeEvt = $null
    while ([McrTicketReview.NativeHooks]::TryDequeue([ref]$nativeEvt)) {
      if ($nativeEvt.Kind -eq 'stop_f9') {
        $stopReason='STOP_F9'; $done=$true; break
      }
      $window = [McrTicketReview.NativeHooks]::GetForeground()
      if ($window.Process -notin $allowed) { continue }
      if ($totalEvents -ge [int]$config.event_limit) {
        $stopReason='EVENT_LIMIT_REACHED'; $done=$true; break
      }
      $ms = [int][math]::Round(([DateTimeOffset]::UtcNow-$startUtc).TotalMilliseconds)
      if ($nativeEvt.Kind -eq 'mark_f8') {
        $markerCount++
        $stage = if (($markerCount - 1) -lt $stages.Count) { $stages[$markerCount - 1] } else { 'Zusaetzlicher Marker ' + $markerCount }
        $shot = ''
        if ($config.capture_private_screenshot_on_f8 -and $privateShotCount -lt [int]$config.max_private_screenshots) {
          $filename = ('step_{0:D2}.png' -f $markerCount)
          if (New-WindowScreenshot -File (Join-Path $privateScreens $filename) -Window $window) {
            $shot='private/screens/' + $filename; $privateShotCount++
          }
        }
        Add-RecordedEvent ([ordered]@{time=$nativeEvt.Time.ToString('o'); elapsed_ms=$ms; kind='marker'; index=$markerCount;stage=$stage; private_screenshot=$shot; browser='msedge'})
        Write-Host ('MARKER {0:D2}: {1}' -f $markerCount,$stage) -ForegroundColor Yellow
        continue
      }
      if ($nativeEvt.Kind -match '^click_' -and $config.log_clicks) {
        $clicks++
        $uia = if ($config.capture_uia_metadata) { Get-SafeUiaInfo -X $nativeEvt.X -Y $nativeEvt.Y } else { [ordered]@{available=$false} }
        Add-RecordedEvent ([ordered]@{time=$nativeEvt.Time.ToString('o'); elapsed_ms=$ms;kind=$nativeEvt.Kind;x=$nativeEvt.X;y=$nativeEvt.Y;window=(Get-SafeWindowTitle $window.WindowTitle);uia=$uia})
      }
      elseif ($nativeEvt.Kind -match '^scroll_' -and $config.log_scroll) {
        $scrolls++
        Add-RecordedEvent ([ordered]@{time=$nativeEvt.Time.ToString('o'); elapsed_ms=$ms;kind=$nativeEvt.Kind;delta=$nativeEvt.Delta;x=$nativeEvt.X;y=$nativeEvt.Y;window=(Get-SafeWindowTitle $window.WindowTitle)})
      }
    }
  }
} catch {
  $stopReason='ERROR'
  Write-Host ('RECORDER FEHLER: ' + $_.Exception.Message) -ForegroundColor Red
} finally {
  [McrTicketReview.NativeHooks]::Stop()
  $finished = [DateTimeOffset]::Now
  $summary = [ordered]@{
    schema='MCR_TICKET_REVIEW_RECORDING_SUMMARY_V1'
    id=$runName; version='1.0.0'; started_at=$started.ToString('o');ended_at=$finished.ToString('o')
    stop_reason=$stopReason; browser='msedge'; clicks=$clicks; scrolls=$scrolls; markers=$markerCount
    screenshots_private=$privateShotCount; recorded_events=$totalEvents
    export_policy='Only sanitized logs + manually approved screenshots/videos. Private screenshots excluded.'
  }
  [System.IO.File]::WriteAllText((Join-Path $runDir 'zusammenfassung.json'),(ConvertTo-Json $summary -Depth 6),$utf8NoBom)
  [System.IO.File]::WriteAllText((Join-Path $runDir 'ABLAUF.txt'),(@(
    'MCR REVIEW RECORDING '+$runName,
    'Status: '+$stopReason,
    'Klicks: '+$clicks+' / Scrolls: '+$scrolls+' / Marker: '+$markerCount,
    'PRIVATE Screenshots: '+$privateShotCount+' (NICHT in Standard-ZIP)',
    'Notizen bitte in ABLAUF_NOTIZEN.md eintragen.',
    'Manuelle Pruefung: Ticketentwurf NICHT versenden; zur Review an Victor weiterleiten.'
  ) -join [Environment]::NewLine),$utf8NoBom)
  Write-Host ''
  Write-Host ('STOP: '+$stopReason+' | Klicks '+$clicks+' | Marker '+$markerCount) -ForegroundColor Cyan
  Write-Host ('Gespeichert unter: '+$runDir)
  try {
    & (Join-Path $PSScriptRoot 'Export.ps1') -RunPath $runDir -NonInteractive
  } catch {
    Write-Host ('Export fehlgeschlagen: '+$_.Exception.Message) -ForegroundColor Yellow
    Write-Host 'Bitte ERGEBNIS_ZIP_ERSTELLEN.cmd separat ausfuehren.'
  }
}
if ($stopReason -eq 'ERROR') { exit 1 }
exit 0
