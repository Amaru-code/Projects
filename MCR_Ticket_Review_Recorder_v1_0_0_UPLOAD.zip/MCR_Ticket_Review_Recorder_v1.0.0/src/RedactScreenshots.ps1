﻿# Offline photo redaction. Draw opaque black masks; images saved ONLY after explicit approval.
[CmdletBinding()]
param([string]$RunPath='')
$ErrorActionPreference='Stop'
Set-StrictMode -Version 2.0
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$root=(Resolve-Path (Join-Path $PSScriptRoot '..')).Path
if(-not $RunPath){
  $run=Get-ChildItem -LiteralPath (Join-Path $root 'output') -Directory | Where-Object {$_.Name -match '^run_\d{8}_\d{6}_[a-f0-9]{8}$'} | Sort-Object Name -Descending | Select-Object -First 1
  if(-not $run){throw 'Keine Aufzeichnung gefunden.'}
  $RunPath=$run.FullName
}
$source=Join-Path $RunPath 'private\screens'
$dest=Join-Path $RunPath 'freigabe\screenshots'
New-Item -ItemType Directory -Path $dest -Force | Out-Null
$files=@(Get-ChildItem -LiteralPath $source -Filter '*.png' -File | Sort-Object Name)
if($files.Count -eq 0){Write-Host 'Keine privaten Screenshots vorhanden.';exit 0}

$script:index=0
$script:masks=New-Object 'System.Collections.Generic.List[System.Drawing.Rectangle]'
$script:drawStart=$null
$script:drawCurrent=$null
$script:activeBitmap=$null
$script:saved=0
$form=New-Object System.Windows.Forms.Form
$form.Text='MCR Screenshot-Freigabe | nur TESTTICKETS / personenbezogene Inhalte schwärzen'
$form.Width=1240; $form.Height=860; $form.StartPosition='CenterScreen'; $form.MinimumSize=[System.Drawing.Size]::new(850,610)
$top=New-Object System.Windows.Forms.Label
$top.Dock='Top';$top.Height=64
$top.Text='Rechtecke mit der Maus ziehen: Name, E-Mail, WWID, Kundentext, Adressen, IDs SCHWAERZEN. Nur freigegebene Bilder werden exportiert.'
$top.TextAlign='MiddleCenter'; $top.Font=[System.Drawing.Font]::new('Segoe UI',10)
$form.Controls.Add($top)
$picture=New-Object System.Windows.Forms.PictureBox
$picture.Dock='Fill'; $picture.BackColor=[System.Drawing.Color]::FromArgb(35,35,35);$picture.SizeMode='Zoom'
$form.Controls.Add($picture)
$bar=New-Object System.Windows.Forms.Panel
$bar.Dock='Bottom';$bar.Height=74;$form.Controls.Add($bar)
$caption=New-Object System.Windows.Forms.Label
$caption.SetBounds(12,6,820,22);$bar.Controls.Add($caption)
function Make-Button([string]$t,[int]$x,[int]$w) {
 $b=New-Object System.Windows.Forms.Button
 $b.Text=$t; $b.SetBounds($x,30,$w,36);$bar.Controls.Add($b)
 return $b
}
$save=Make-Button 'SCHWAERZEN, FREIGEBEN und weiter' 10 290
$undo=Make-Button 'Letzte Maske entfernen' 311 195
$skip=Make-Button 'Bild NICHT freigeben' 519 195
$close=Make-Button 'Fertig / Schliessen' 727 170
$tip=New-Object System.Windows.Forms.Label
$tip.Text='Bilder werden standardmaessig NICHT exportiert. Hiermit einzeln freigeben.'
$tip.SetBounds(910,31,300,36);$bar.Controls.Add($tip)

function Get-ImageViewport {
  if($null -eq $script:activeBitmap -or $picture.ClientSize.Width -lt 1 -or $picture.ClientSize.Height -lt 1){return $null}
  $ratio=[math]::Min($picture.ClientSize.Width/[double]$script:activeBitmap.Width,$picture.ClientSize.Height/[double]$script:activeBitmap.Height)
  $rw=$script:activeBitmap.Width*$ratio; $rh=$script:activeBitmap.Height*$ratio
  return @{ratio=$ratio;x=($picture.ClientSize.Width-$rw)/2;y=($picture.ClientSize.Height-$rh)/2;w=$rw;h=$rh}
}
function Get-ImagePoint([System.Drawing.Point]$p) {
  $v=Get-ImageViewport
  if($null -eq $v){return $null}
  $x=[int][math]::Round(($p.X-$v.x)/$v.ratio)
  $y=[int][math]::Round(($p.Y-$v.y)/$v.ratio)
  $x=[math]::Max(0,[math]::Min($script:activeBitmap.Width,$x))
  $y=[math]::Max(0,[math]::Min($script:activeBitmap.Height,$y))
  return [System.Drawing.Point]::new($x,$y)
}
function Make-Rect([System.Drawing.Point]$a,[System.Drawing.Point]$b) {
 return [System.Drawing.Rectangle]::FromLTRB([math]::Min($a.X,$b.X),[math]::Min($a.Y,$b.Y),[math]::Max($a.X,$b.X),[math]::Max($a.Y,$b.Y))
}
function Draw-Mask([System.Drawing.Graphics]$g,[System.Drawing.Rectangle]$rect) {
  $v=Get-ImageViewport
  if($null -eq $v){return}
  $r=[System.Drawing.Rectangle]::new([int]($v.x+$rect.X*$v.ratio),[int]($v.y+$rect.Y*$v.ratio),[math]::Max(1,[int]($rect.Width*$v.ratio)),[math]::Max(1,[int]($rect.Height*$v.ratio)))
  $g.FillRectangle([System.Drawing.Brushes]::Black,$r)
  $g.DrawRectangle([System.Drawing.Pens]::Red,$r)
}
$picture.add_Paint({
 param($sender,$e)
 foreach($r in $script:masks){Draw-Mask $e.Graphics $r}
 if($script:drawStart -and $script:drawCurrent){Draw-Mask $e.Graphics (Make-Rect $script:drawStart $script:drawCurrent)}
})
$picture.add_MouseDown({
 param($sender,$e)
 if($e.Button -eq [System.Windows.Forms.MouseButtons]::Left -and $script:activeBitmap){
   $script:drawStart=Get-ImagePoint $e.Location; $script:drawCurrent=$script:drawStart
 }
})
$picture.add_MouseMove({
 param($sender,$e)
 if($script:drawStart){$script:drawCurrent=Get-ImagePoint $e.Location;$picture.Invalidate()}
})
$picture.add_MouseUp({
 param($sender,$e)
 if($script:drawStart){
   $end=Get-ImagePoint $e.Location
   if($end){$r=Make-Rect $script:drawStart $end;if($r.Width -gt 2 -and $r.Height -gt 2){$script:masks.Add($r)}}
   $script:drawStart=$null;$script:drawCurrent=$null;$picture.Invalidate()
 }
})

function Open-Image {
 if($null -ne $script:activeBitmap){$picture.Image=$null;$script:activeBitmap.Dispose();$script:activeBitmap=$null}
 $script:masks.Clear(); $script:drawStart=$null;$script:drawCurrent=$null
 if($script:index -ge $files.Count){
   $caption.Text='Fertig: '+$script:saved+' Bild(er) explizit freigegeben.'
   $save.Enabled=$false;$undo.Enabled=$false;$skip.Enabled=$false
   return
 }
 $sourceImage=[System.Drawing.Image]::FromFile($files[$script:index].FullName)
 try{$script:activeBitmap=$([System.Drawing.Bitmap]::new($sourceImage))}
 finally{$sourceImage.Dispose()}
 $picture.Image=$script:activeBitmap
 $caption.Text=('Screenshot {0}/{1}: {2} | {3} Masken' -f ($script:index+1),$files.Count,$files[$script:index].Name,$script:masks.Count)
 $picture.Invalidate()
}
$save.add_Click({
 if($null -eq $script:activeBitmap){return}
 $f=$files[$script:index]
 $new=$([System.Drawing.Bitmap]::new($script:activeBitmap))
 try{
   $g=[System.Drawing.Graphics]::FromImage($new)
   try{foreach($r in $script:masks){$g.FillRectangle([System.Drawing.Brushes]::Black,$r)}}
   finally{$g.Dispose()}
   $destination=Join-Path $dest $f.Name
   if(Test-Path $destination){Remove-Item -LiteralPath $destination -Force}
   $new.Save($destination,[System.Drawing.Imaging.ImageFormat]::Png)
   $script:saved++
 } finally{$new.Dispose()}
 $script:index++;Open-Image
})
$skip.add_Click({$script:index++;Open-Image})
$undo.add_Click({
 if($script:masks.Count -gt 0){$script:masks.RemoveAt($script:masks.Count-1);$picture.Invalidate()}
})
$close.add_Click({$form.Close()})
$form.add_Shown({Open-Image})
try{[void]$form.ShowDialog()}
finally{if($null -ne $script:activeBitmap){$picture.Image=$null;$script:activeBitmap.Dispose()};$form.Dispose()}
Write-Host ('Freigegebene Bilder: '+$script:saved+' | '+$dest)
Write-Host 'Bitte ERGEBNIS_ZIP_ERSTELLEN.cmd ausfuehren und ZIP selbst kontrollieren.'
