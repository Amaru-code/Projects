﻿[CmdletBinding()]
param([string]$RunPath='', [switch]$NonInteractive)
$ErrorActionPreference='Stop'
Set-StrictMode -Version 2.0
$root=(Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$outputRoot=Join-Path $root 'output'
$utf8NoBom=[System.Text.UTF8Encoding]::new($false)

function Fail([string]$message) { throw $message }
if (-not $RunPath) {
  $run=Get-ChildItem -LiteralPath $outputRoot -Directory | Where-Object {$_.Name -match '^run_\d{8}_\d{6}_[a-f0-9]{8}$'} | Sort-Object Name -Descending | Select-Object -First 1
  if (-not $run) { Fail 'Keine Aufzeichnung gefunden. Zuerst START_AUFZEICHNUNG.cmd ausfuehren.' }
  $RunPath=$run.FullName
}
if (-not (Test-Path -LiteralPath $RunPath -PathType Container)) { Fail 'Run-Ordner existiert nicht.' }
$resolved=(Resolve-Path -LiteralPath $RunPath).Path
$prefix=[System.IO.Path]::GetFullPath($outputRoot).TrimEnd('\','/') + [System.IO.Path]::DirectorySeparatorChar
if (-not $resolved.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)) { Fail 'Run muss innerhalb output/ liegen.' }
$runName=Split-Path $resolved -Leaf
if ($runName -notmatch '^run_\d{8}_\d{6}_[a-f0-9]{8}$') { Fail 'Unbekanntes Run-Format.' }
$required=@('run_info.json','zusammenfassung.json','ereignisse.jsonl','ABLAUF.txt','ABLAUF_NOTIZEN.md')
foreach($file in $required) { if (-not (Test-Path (Join-Path $resolved $file) -PathType Leaf)) { Fail ('Fehlende Datei: '+$file) } }

# Warn before sharing: syntax-based scan of user-editable notes, never blindly export PII.
$notes=Get-Content (Join-Path $resolved 'ABLAUF_NOTIZEN.md') -Raw -Encoding UTF8
if ($notes -match '(?i)[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}' -or
    $notes -match '\b\d{7,}\b' -or $notes -match '(?i)\b(?:IBAN|BIC|Geburtsdatum|Personalausweisnummer)\s*[:=]') {
  Fail 'Moegliche personenbezogene Daten in ABLAUF_NOTIZEN.md gefunden. Bitte anonymisieren; Export gesperrt.'
}

$staging=Join-Path $outputRoot ('_exportstage_'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $staging | Out-Null
try {
  foreach ($file in $required) { Copy-Item -LiteralPath (Join-Path $resolved $file) -Destination (Join-Path $staging $file) -ErrorAction Stop }
  $mediaTotal=0L
  foreach($group in @(@{name='screenshots';extensions=@('.png','.jpg','.jpeg')},@{name='video';extensions=@('.mp4','.webm')})) {
    $src=Join-Path $resolved ('freigabe\'+$group.name)
    if (-not (Test-Path $src -PathType Container)) { continue }
    $files=@(Get-ChildItem -LiteralPath $src -File | Where-Object { $group.extensions -contains $_.Extension.ToLowerInvariant() })
    foreach($f in $files) {
      # Explicit approved media only, no automatic private screenshot/video export.
      if($f.Length -gt 150MB){ Fail ('Medium zu gross: '+$f.Name) }
      $mediaTotal+=$f.Length
      if($mediaTotal -gt 250MB){ Fail 'Freigegebene Medien insgesamt >250 MB. Bitte kuerzen.' }
      $dstDir=Join-Path $staging ('freigabe\'+$group.name)
      New-Item -ItemType Directory -Path $dstDir -Force | Out-Null
      Copy-Item -LiteralPath $f.FullName -Destination (Join-Path $dstDir $f.Name)
    }
  }

  $entries=@()
  $basePath=[System.IO.Path]::GetFullPath($staging).TrimEnd('\','/')+[System.IO.Path]::DirectorySeparatorChar
  foreach($f in @(Get-ChildItem -LiteralPath $staging -File -Recurse | Sort-Object FullName)){
    $logical=$f.FullName.Substring($basePath.Length).Replace('\','/')
    $hash=(Get-FileHash -LiteralPath $f.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
    $entries+=([ordered]@{path=$logical;size_bytes=$f.Length;sha256=$hash})
  }
  $manifest=[ordered]@{
    schema='MCR_TICKET_REVIEW_EXPORT_MANIFEST_V1'
    version='1.0.0'
    run_id=$runName
    created_at=[DateTimeOffset]::Now.ToString('o')
    included_files=$entries.Count
    privacy='Keine privaten Screenshots enthalten. Nur explizit freigegebene Medien.'
    payload=$entries
  }
  [System.IO.File]::WriteAllText((Join-Path $staging 'manifest.json'),(ConvertTo-Json -InputObject $manifest -Depth 7),$utf8NoBom)

  $exportDir=Join-Path $outputRoot 'exports'
  New-Item -ItemType Directory -Path $exportDir -Force | Out-Null
  $zipName='MCR_TICKET_REVIEW_'+$runName.Substring(4)+'_UPLOAD.zip'
  $zip=Join-Path $exportDir $zipName
  if (Test-Path $zip) { Remove-Item -LiteralPath $zip -Force }
  Compress-Archive -Path (Join-Path $staging '*') -DestinationPath $zip -CompressionLevel Optimal -Force
  Add-Type -AssemblyName System.IO.Compression
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  $archive=[System.IO.Compression.ZipFile]::OpenRead($zip)
  try {
    $byPath=@{}
    foreach($zentry in $archive.Entries){
      if($zentry.FullName.EndsWith('/')){continue}
      $relative=$zentry.FullName.Replace('\','/')
      if($byPath.ContainsKey($relative)){Fail ('Duplicate in ZIP: '+$relative)}
      $byPath[$relative]=$zentry
    }
    if($byPath.Count -ne ($entries.Count+1)){Fail ('ZIP entry count mismatch: '+$byPath.Count)}
    foreach($entry in $entries){
      if(-not $byPath.ContainsKey($entry.path)){Fail ('ZIP missing: '+$entry.path)}
      $stream=$byPath[$entry.path].Open()
      try {
        $hasher=[Security.Cryptography.SHA256]::Create()
        try {$hash=[BitConverter]::ToString($hasher.ComputeHash($stream)).Replace('-','').ToLowerInvariant()}
        finally{$hasher.Dispose()}
      } finally {$stream.Dispose()}
      if($hash -ne $entry.sha256){Fail ('ZIP SHA mismatch: '+$entry.path)}
    }
    if(-not $byPath.ContainsKey('manifest.json')){Fail 'ZIP missing manifest.json'}
  } finally { $archive.Dispose() }
  $sha=(Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant()
  [System.IO.File]::WriteAllText(($zip+'.sha256'),($sha+'  '+$zipName+[Environment]::NewLine),$utf8NoBom)
  Write-Host ''
  Write-Host 'ERGEBNIS-ZIP VOLLSTAENDIG GEPRUEFT' -ForegroundColor Green
  Write-Host ('ZIP: '+$zip)
  Write-Host ('SHA256: '+$sha)
  Write-Host ('Inhalt: '+$entries.Count+' Nutzdateien + 1 Manifest')
  Write-Host 'WICHTIG: ZIP vor Upload nochmals selbst kontrollieren.' -ForegroundColor Yellow
} finally {
  if(Test-Path $staging) { Remove-Item -LiteralPath $staging -Recurse -Force -ErrorAction SilentlyContinue }
}
