// MCR Ticket Review Recorder: passive input/event metadata, no keylogging.
// Windows 10/11; .NET Framework 4.x; PowerShell 5.1.
using System;
using System.Text;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Collections.Concurrent;
using System.ComponentModel;

namespace McrTicketReview {
  public sealed class MouseKeyboardEvent {
    public string Kind { get; set; }
    public int X { get; set; }
    public int Y { get; set; }
    public int Delta { get; set; }
    public DateTimeOffset Time { get; set; }
  }
  public sealed class ForegroundDetails {
    public string Process { get; set; }
    public int ProcessId { get; set; }
    public IntPtr Handle { get; set; }
    public string WindowTitle { get; set; }
    public int Left { get; set; }
    public int Top { get; set; }
    public int Width { get; set; }
    public int Height { get; set; }
  }
  public static class NativeHooks {
    private const int WH_MOUSE_LL = 14, WH_KEYBOARD_LL = 13;
    private const int WM_LBUTTONUP = 0x0202, WM_RBUTTONUP = 0x0205, WM_MBUTTONUP = 0x0208;
    private const int WM_MOUSEWHEEL = 0x020A, WM_MOUSEHWHEEL = 0x020E;
    private const int WM_KEYDOWN = 0x0100, WM_SYSKEYDOWN = 0x0104;
    private const uint VK_F8 = 0x77, VK_F9 = 0x78;
    [StructLayout(LayoutKind.Sequential)] private struct POINT { public int X, Y; }
    [StructLayout(LayoutKind.Sequential)] private struct MSLLHOOKSTRUCT {
      public POINT Pt; public uint MouseData, Flags, Time; public UIntPtr ExtraInfo;
    }
    [StructLayout(LayoutKind.Sequential)] private struct KBDLLHOOKSTRUCT {
      public uint VkCode, ScanCode, Flags, Time; public UIntPtr ExtraInfo;
    }
    [StructLayout(LayoutKind.Sequential)] private struct RECT {
      public int Left, Top, Right, Bottom;
    }
    private delegate IntPtr HookProc(int nCode, IntPtr wParam, IntPtr lParam);
    private static HookProc _mouseDelegate = MouseCallback;
    private static HookProc _keyDelegate = KeyCallback;
    private static IntPtr _mouseHandle = IntPtr.Zero, _keyHandle = IntPtr.Zero;
    private static ConcurrentQueue<MouseKeyboardEvent> _events = new ConcurrentQueue<MouseKeyboardEvent>();

    [DllImport("user32.dll", SetLastError=true)] private static extern IntPtr SetWindowsHookEx(int idHook, HookProc lpfn, IntPtr hmod, uint threadId);
    [DllImport("user32.dll", SetLastError=true)] private static extern bool UnhookWindowsHookEx(IntPtr handle);
    [DllImport("user32.dll")] private static extern IntPtr CallNextHookEx(IntPtr handle, int nCode, IntPtr wParam, IntPtr lParam);
    [DllImport("kernel32.dll", CharSet=CharSet.Auto, SetLastError=true)] private static extern IntPtr GetModuleHandle(string moduleName);
    [DllImport("user32.dll")] private static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] private static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int capacity);
    [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);
    [DllImport("user32.dll")] private static extern bool GetWindowRect(IntPtr hWnd, out RECT rect);

    public static bool IsRunning { get { return _mouseHandle != IntPtr.Zero && _keyHandle != IntPtr.Zero; } }
    public static int PendingCount { get { return _events.Count; } }
    public static void Start() {
      if (IsRunning) throw new InvalidOperationException("Recorder is already running");
      // Hook callbacks are kept alive by static fields for entire recording.
      IntPtr module = GetModuleHandle(Process.GetCurrentProcess().MainModule.ModuleName);
      _mouseHandle = SetWindowsHookEx(WH_MOUSE_LL, _mouseDelegate, module, 0);
      if (_mouseHandle == IntPtr.Zero) throw new Win32Exception(Marshal.GetLastWin32Error(), "Mouse hook failed");
      _keyHandle = SetWindowsHookEx(WH_KEYBOARD_LL, _keyDelegate, module, 0);
      if (_keyHandle == IntPtr.Zero) {
        int err=Marshal.GetLastWin32Error(); UnhookWindowsHookEx(_mouseHandle); _mouseHandle=IntPtr.Zero;
        throw new Win32Exception(err, "Keyboard hotkey hook failed");
      }
    }
    public static void Stop() {
      if (_mouseHandle != IntPtr.Zero) { UnhookWindowsHookEx(_mouseHandle); _mouseHandle=IntPtr.Zero; }
      if (_keyHandle != IntPtr.Zero) { UnhookWindowsHookEx(_keyHandle); _keyHandle=IntPtr.Zero; }
    }
    public static bool TryDequeue(out MouseKeyboardEvent next) { return _events.TryDequeue(out next); }
    private static IntPtr MouseCallback(int nCode, IntPtr wParam, IntPtr lParam) {
      if (nCode >= 0) {
        int kind = wParam.ToInt32();
        string type=null;
        if (kind==WM_LBUTTONUP) type="click_left";
        else if(kind==WM_RBUTTONUP) type="click_right";
        else if(kind==WM_MBUTTONUP) type="click_middle";
        else if(kind==WM_MOUSEWHEEL) type="scroll_vertical";
        else if(kind==WM_MOUSEHWHEEL) type="scroll_horizontal";
        if (type!=null) {
          var input = (MSLLHOOKSTRUCT)Marshal.PtrToStructure(lParam, typeof(MSLLHOOKSTRUCT));
          int delta = kind==WM_MOUSEWHEEL||kind==WM_MOUSEHWHEEL ? (short)((input.MouseData>>16)&0xFFFF) : 0;
          _events.Enqueue(new MouseKeyboardEvent{Kind=type,X=input.Pt.X,Y=input.Pt.Y,Delta=delta,Time=DateTimeOffset.Now});
        }
      }
      return CallNextHookEx(_mouseHandle,nCode,wParam,lParam);
    }
    private static IntPtr KeyCallback(int nCode, IntPtr wParam, IntPtr lParam) {
      if (nCode>=0 && (wParam.ToInt32()==WM_KEYDOWN || wParam.ToInt32()==WM_SYSKEYDOWN)) {
        var input=(KBDLLHOOKSTRUCT)Marshal.PtrToStructure(lParam,typeof(KBDLLHOOKSTRUCT));
        // Intentionally record ONLY F8/F9. No text, other keys, passwords, or clipboard.
        if (input.VkCode==VK_F8 || input.VkCode==VK_F9)
          _events.Enqueue(new MouseKeyboardEvent{Kind=input.VkCode==VK_F8?"mark_f8":"stop_f9",Time=DateTimeOffset.Now});
      }
      return CallNextHookEx(_keyHandle,nCode,wParam,lParam);
    }
    public static ForegroundDetails GetForeground() {
      IntPtr hwnd=GetForegroundWindow();
      uint pid=0; GetWindowThreadProcessId(hwnd,out pid);
      string name="unknown";
      try { if(pid>0) name=Process.GetProcessById((int)pid).ProcessName.ToLowerInvariant(); } catch { }
      StringBuilder title=new StringBuilder(512); GetWindowText(hwnd,title,title.Capacity);
      RECT rect=new RECT(); GetWindowRect(hwnd,out rect);
      return new ForegroundDetails {Process=name,ProcessId=(int)pid,Handle=hwnd,
        WindowTitle=title.ToString(), Left=rect.Left,Top=rect.Top,
        Width=Math.Max(0,rect.Right-rect.Left),Height=Math.Max(0,rect.Bottom-rect.Top)};
    }
  }
}
