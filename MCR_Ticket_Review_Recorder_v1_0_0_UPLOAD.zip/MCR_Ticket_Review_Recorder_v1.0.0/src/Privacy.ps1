﻿# Common privacy functions for local recorder and self-tests.
Set-StrictMode -Version 2.0

function Get-SafeUiLabel {
    param([AllowNull()][string]$Label)
    if ([string]::IsNullOrWhiteSpace($Label)) { return '' }
    $name = ([regex]::Replace($Label.Trim(), '\s+', ' '))
    if ($name.Length -gt 90) { return '[REDACTED_UI_TEXT]' }
    # Strict, anchored allowlist of UI labels only. Not text within email or customer profiles.
    $allowed = @(
      '^(?:Bearbeiten|Abbrechen|OK|Ja|Nein|Schlie(?:ß|ss)en|Zurück|Weiter|Öffnen)$',
      '^(?:Speichern|Entwurf speichern|Antwort speichern|Antworten|Senden|Antwort|Nachricht|Neue Nachricht)$',
      '^(?:Signatur|Signatur auswählen|INTL01\s*[-–]\s*Intel Deutschland GmbH)$',
      '^(?:Nächster Schritt|Weiterleitung zur Überprüfung|Zur Überprüfung|Weiterleiten|Weiterleitung)$',
      '^(?:Schritt ausführen|Ausführen|Prüfen|Überprüfung|Kommentar|Kommentare|Bemerkung|Kommentar eingeben)$',
      '^(?:Zuständigkeit|Second Level|Dokumentenkategorie|Allgemeine Schriftwechsel)$',
      '^(?:Unterkategorie|Personenschriftwechsel|Zusätzliche Beschreibung|Member|Empfänger|Von|An|Betreff)$',
      '^(?:Warteschlange|Meine Vorgänge|In_Bearbeitung|In Bearbeitung|INTL01|E-Mail|Email|Mail)$',
      '^(?:Victor|Hinzufügen|Suche|Suchen|Anhang|Anlagen|Speichern und schließen)$',
      '^(?:Löschen|Fertig|Aktualisieren|Übernehmen|Auswählen|Bestätigen|Abschließen|Erledigt)$',
      '^(?:Posteingang|Vorgänge|Vorgang|Details|Verlauf|Aktionen|Weiterleitung zur Überpr(?:ü|u)fung)$'
    )
    foreach ($p in $allowed) {
      if ($name -imatch $p) { return $name }
    }
    return '[REDACTED_UI_TEXT]'
}

function Get-SafeAutomationId {
    param([AllowNull()][string]$Id)
    if ([string]::IsNullOrWhiteSpace($Id)) { return '' }
    # IDs with a long number, @, URL, personal identifier or GUID are not exported.
    if ($Id.Length -gt 48 -or $Id -match '@|\d{4,}|[\\/\:]|[\s]' -or $Id -notmatch '^[A-Za-z_][A-Za-z0-9_\-]*$') {
      return '[REDACTED_ID]'
    }
    return $Id
}

function Get-SafeWindowTitle {
    param([AllowNull()][string]$Title)
    if ([string]::IsNullOrWhiteSpace($Title)) { return '[NO_WINDOW_TITLE]' }
    if ($Title -imatch 'COMARCH') { return '[COMARCH_EDGE_WINDOW]' }
    if ($Title -imatch 'Microsoft Edge') { return '[MICROSOFT_EDGE_WINDOW]' }
    return '[WINDOW_TITLE_REDACTED]'
}

function Get-SafeUiaInfo {
    param([int]$X,[int]$Y)
    $result = [ordered]@{ available = $false; type = ''; label = ''; automation_id = ''; ancestors = @() }
    try {
      $point = [System.Windows.Point]::new([double]$X, [double]$Y)
      $item = [System.Windows.Automation.AutomationElement]::FromPoint($point)
      if ($null -eq $item) { return $result }
      $current = $item.Current
      $result.available = $true
      $result.type = [string]$current.ControlType.ProgrammaticName
      $result.label = Get-SafeUiLabel ([string]$current.Name)
      $result.automation_id = Get-SafeAutomationId ([string]$current.AutomationId)
      # Only ancestor control types are kept, not their text or field values.
      $node = $item
      $parents = @()
      for ($i=0; $i -lt 4; $i++) {
        $node = [System.Windows.Automation.TreeWalker]::ControlViewWalker.GetParent($node)
        if ($null -eq $node) { break }
        $parents += ([string]$node.Current.ControlType.ProgrammaticName)
      }
      $result.ancestors = @($parents)
    } catch { $result.available = $false }
    return $result
}
