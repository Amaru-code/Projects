﻿$ErrorActionPreference='Stop'
Set-StrictMode -Version 2.0
$root=(Resolve-Path (Join-Path $PSScriptRoot '..')).Path
. (Join-Path $PSScriptRoot 'Privacy.ps1')
$tests=0
function Check([bool]$ok,[string]$title){
 $script:tests++
 if(-not $ok){throw ('TEST FAIL: '+$title)}
 Write-Host ('PASS: '+$title)
}
try {
  Add-Type -AssemblyName WindowsBase
  Add-Type -AssemblyName UIAutomationClient
  Add-Type -AssemblyName UIAutomationTypes
  Add-Type -AssemblyName System.Windows.Forms
  Add-Type -AssemblyName System.Drawing
  Add-Type -Path (Join-Path $PSScriptRoot 'NativeHooks.cs')
  Check (-not [McrTicketReview.NativeHooks]::IsRunning) 'Windows-Recorder-Quellcode kompiliert'
  Check ((Get-SafeUiLabel 'Weiterleitung zur Überprüfung') -eq 'Weiterleitung zur Überprüfung') 'Review-Schritt ist freigegeben'
  Check ((Get-SafeUiLabel 'INTL01 - Intel Deutschland GmbH') -eq 'INTL01 - Intel Deutschland GmbH') 'Signatur wird erkannt'
  Check ((Get-SafeUiLabel 'Max Beispielmann') -eq '[REDACTED_UI_TEXT]') 'Personennamen werden anonymisiert'
  Check ((Get-SafeUiLabel 'beispiel@example.com') -eq '[REDACTED_UI_TEXT]') 'E-Mail-Adressen werden anonymisiert'
  Check ((Get-SafeUiLabel 'Ich möchte eine Kontostandsübersicht') -eq '[REDACTED_UI_TEXT]') 'Original-Mailtext wird nicht gespeichert'
  Check ((Get-SafeAutomationId 'ClientEEID_10012345') -eq '[REDACTED_ID]') 'Lange Memberkennungen sind geschützt'
  Check ((Get-SafeAutomationId 'reviewComment') -eq 'reviewComment') 'Statische UI-IDs sind erlaubt'
  Check ((Get-SafeWindowTitle 'Max Beispielmann - COMARCH - Microsoft Edge') -eq '[COMARCH_EDGE_WINDOW]') 'Fenstertitel ohne Personendaten'
  $json=Get-Content (Join-Path $root 'config\aufnahme.json') -Raw -Encoding UTF8 | ConvertFrom-Json
  Check (($json.allowed_process_names.Count -eq 1) -and ($json.allowed_process_names[0] -eq 'msedge')) 'Nur Edge wird aufgezeichnet'
  $code=Get-Content (Join-Path $PSScriptRoot 'NativeHooks.cs') -Raw -Encoding UTF8
  Check (($code -match 'VK_F8') -and ($code -match 'VK_F9') -and ($code -notmatch 'GetClipboardData|GetAsyncKeyState')) 'Kein Text-Keylogger/Clipboard im Windows-Hook'
  # End-to-end ZIP export with a synthetic, entirely fictitious recording.
  $suffix=[guid]::NewGuid().ToString('N').Substring(0,8)
  $fakeName='run_20300101_000000_'+$suffix
  $fakeDir=Join-Path $root ('output\'+$fakeName)
  $testZip=''
  New-Item -ItemType Directory -Force -Path $fakeDir | Out-Null
  try {
    @{
     'run_info.json'='{"schema":"MCR_TICKET_REVIEW_RECORDING_V1","mode":"TEST"}'
     'zusammenfassung.json'='{"schema":"MCR_TICKET_REVIEW_RECORDING_SUMMARY_V1","clicks":1}'
     'ereignisse.jsonl'='{"kind":"click_left","x":100,"y":100,"uia":{"label":"Bearbeiten"}}'
     'ABLAUF.txt'='Beispiel: Start Bearbeiten, Entwurf speichern, zur Ueberpruefung weiterleiten.'
     'ABLAUF_NOTIZEN.md'='Anonymisierte Testnotiz: Weiterleitung zur Ueberpruefung sichtbar.'
    }.GetEnumerator() | ForEach-Object {
      [System.IO.File]::WriteAllText((Join-Path $fakeDir $_.Key),$_.Value)
    }
    & (Join-Path $PSScriptRoot 'Export.ps1') -RunPath $fakeDir -NonInteractive
    $testZip=Join-Path $root ('output\exports\MCR_TICKET_REVIEW_'+$fakeName.Substring(4)+'_UPLOAD.zip')
    Check (Test-Path $testZip -PathType Leaf) 'ZIP-Export inklusive SHA-Verifikation'
    Check (Test-Path ($testZip+'.sha256') -PathType Leaf) 'Externes SHA256-Sidecar erzeugt'
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $z=[System.IO.Compression.ZipFile]::OpenRead($testZip)
    try {
      $names=@($z.Entries | ForEach-Object {$_.FullName})
      Check ($names -contains 'manifest.json') 'Manifest ist im ZIP enthalten'
      Check (-not ($names | Where-Object {$_ -match '^private/'})) 'Private Artefakte bleiben draussen'
    } finally {$z.Dispose()}
  } finally {
    if(Test-Path $fakeDir){Remove-Item -LiteralPath $fakeDir -Recurse -Force}
    if($testZip -and (Test-Path $testZip)){Remove-Item -LiteralPath $testZip -Force}
    if($testZip -and (Test-Path ($testZip+'.sha256'))){Remove-Item -LiteralPath ($testZip+'.sha256') -Force}
  }
  Write-Host ('=============================================================')
  Write-Host ('ALLE '+$tests+' SELBSTTESTS PASS') -ForegroundColor Green
  exit 0
} catch {
  Write-Host ('SELBSTTEST FAIL: '+$_.Exception.Message) -ForegroundColor Red
  exit 1
}
