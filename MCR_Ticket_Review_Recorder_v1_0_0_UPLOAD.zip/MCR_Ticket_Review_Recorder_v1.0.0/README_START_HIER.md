# MCR Ticket Review Recorder — v1.0.0

**Ziel:** Den noch unbekannten COMARCH-Klickablauf des **zweiten** INTL01-Ticketbots aufnehmen. Dies ist ein **Recorder, kein Kundenantwort-Bot**. Er verändert keine COMARCH-Tickets; alle Klicks der Demo werden ausschließlich von dir selbst durchgeführt.

**Bisheriger Bot bleibt unberührt:** `MCR Ticket Assistant 0.8.0-beta.4`, Softwarekern `0.7.4`, aktuelles F/TPP-Mapping und produktive Edge-Profile werden weder gelesen noch verändert. Bitte diesen Projektordner **separat** neben der vorhandenen Installation entpacken.

## Schnellstart (Windows 11 / Windows PowerShell 5.1)

1. Das ZIP **vollständig entpacken**; nicht direkt aus dem ZIP starten.
2. `SELBSTTEST.cmd` doppelklicken. Erwartet: `ALLE ... SELBSTTESTS PASS`. Bei FAIL den Lauf nicht starten, sondern die Konsolenausgabe zurückgeben.
3. Ein **anonymisiertes Testticket** in COMARCH vorbereiten. Es ist bereits eröffnet und enthält Zuständigkeit, Kategorie, Unterkategorie, Member und **zusätzliche Beschreibung** (inklusive Status/Pensionsplan).
4. `START_AUFZEICHNUNG.cmd` doppelklicken. Das offene Konsolenfenster läuft im Hintergrund und zeichnet **nur Microsoft Edge** auf. Nun im bereits angemeldeten Edge den Ticketprozess manuell ausführen.
5. Für wichtige Zwischenstände `F8` drücken (Marker + **privater** Screenshot des Edge-Fensters). Im Zweifel öfter markieren; die Ereignisse werden auch zwischen den Markern protokolliert. **`F9` beendet** die Aufnahme und erstellt direkt ein ZIP **nur mit anonymisierten technischen Logs**.
6. Nach dem Durchlauf die `ABLAUF_NOTIZEN.md` im neuesten `output/run_.../` kurz ergänzen (ohne echte Kundendaten).
7. `ANONYMISIEREN.cmd`: Screenshots nacheinander öffnen, **alle** personenbezogenen Inhalte mit schwarzen Rechtecken abdecken, jeden sicheren Screenshot mit „Schwärzen, freigeben und weiter“ einzeln freigeben. Nicht benötigte Bilder überspringen.
8. `ERGEBNIS_ZIP_ERSTELLEN.cmd`: schreibt das endgültige ZIP inklusive explizit freigegebener Screenshots unter `output/exports/` neu.
9. **Das fertige `*_UPLOAD.zip` hier im Chat hochladen.** Keine Dateien aus `private/` senden. Falls vorhanden, die SHA256-Zeile gern mitschicken.

### Optional: echte Bildschirmvideo-Aufnahme

In Windows 11 die **Snipping Tool**-Videoaufzeichnung mit `Windows + Shift + R` starten, *nur* das COMARCH-Fenster als Aufnahmebereich markieren, Aufnahme starten und nach dem Beispielablauf stoppen. MP4 zuerst lokal behalten und **nur nach vollständiger Anonymisierung** in `output/run_.../freigabe/video/` kopieren. Der Export schließt ausschließlich dort **bewusst freigegebene** Video-Dateien ein. Wenn kein redigierbares Testticket verfügbar ist, genügt die technische Klickaufzeichnung samt geschwärzten Screenshots. Video ist **optional**.

## Tasten und Datenerfassung

| Taste | Aktion |
|---|---|
| `F8` (Edge im Vordergrund) | Markierung + Screenshot unter `private/screens` |
| `F9` | Sofort stoppen und technische Logs exportieren |
| Andere Tasten | **Nicht** gespeichert (auch keine Buchstaben/Zahlen) |

Der Recorder liest **keine Mailtexte, Passwörter, Eingaben oder Zwischenablage**. Mauspositionen, Klicks, Scroll-Aktionen, UI-Steuerelementtypen und **streng erlaubte Funktionsbezeichnungen** werden gespeichert. Texte, die nicht exakt einer vordefinierten technischen UI-Bezeichnung entsprechen, werden als `REDACTED_UI_TEXT` anonymisiert. Der Event-Recorder nutzt Windows-Betriebssystemschnittstellen statt der COMARCH-DOM und benötigt weder Node.js noch Playwright.

**Grenze:** Bildschirme und Videos zeigen echte Inhalte und enthalten daher potenziell personenbezogene Daten. Automatisches Schwärzen ist nicht zuverlässig. **Nur die von dir persönlich geprüften, geschwärzten Bilder/Video(s) werden in das Freigabe-ZIP aufgenommen.** Auch die Freigabe-ZIP vor Upload selbst überprüfen; das Tool ist kein garantierter DLP-Filter.

## Welchen Ablauf vorführen?

Siehe `docs/01_AUFNAHMEABLAUF.md`. Beginne bei einem **bereits vorbereiteten** Ticket mit vorhandener „Zusätzlicher Beschreibung“. Dokumentiere die **manuelle** Antworterstellung, Signatur `INTL01 - Intel Deutschland GmbH`, das Speichern des **ungesendeten** Entwurfs, `Nächster Schritt` → `Weiterleitung zur Überprüfung`, ggf. die Auswahl `Victor`, kurzen Fallkommentar und `Schritt ausführen`, plus abschließende Kontrolle. Der Recorder selbst klickt niemals auf Speichern, Senden oder Schritt ausführen. Verwende diesen realen Workflow ausschließlich für autorisierte **Testtickets**.

## Ergebnisdateien

```
output/
  run_YYYYMMDD_HHMMSS_XXXXXXXX/
    ereignisse.jsonl           # datensparsame technische Click-/Scroll-Timeline
    ABLAUF.txt                 # Zählung / Status
    ABLAUF_NOTIZEN.md          # frei editierbar: nur anonymisierte Hinweise
    zusammenfassung.json      # Statistik
    run_info.json              # Aufnahme-Kontext ohne Benutzeridentität
    private/screens/          # NICHT exportiert / nicht hochladen
    freigabe/screenshots/     # vom Nutzer einzeln freigegeben / ggf. geschwärzt
    freigabe/video/           # nur manuell hinzugefügte, geprüfte MP4/WebM
  exports/
    MCR_TICKET_REVIEW_<run>_UPLOAD.zip
    MCR_TICKET_REVIEW_<run>_UPLOAD.zip.sha256
```

## Fehlerfälle

- `SELBSTTEST FAIL`: Komplette Konsolenausgabe schicken, **nicht** in den produktiven Bot eingreifen.
- Recorder öffnet nichts: Das ist korrekt! Edge manuell öffnen / COMARCH wie bisher verwenden.
- Keine Events: Während der Aufnahme ist **Microsoft Edge (`msedge.exe`)** im Vordergrund nötig.
- Screenshots fehlen: Eventlogs bleiben verwertbar; `F8` nur bei aktivem Edge und nicht minimiertem Fenster verwenden.
- `F9` vergessen: Konsolenfenster schließen führt unter Umständen zu unvollständiger Summary; Aufnahme mit F9 korrekt beenden.
- Keine Freigabe-Bilder: Das ZIP enthält bewusst nur technische Logs; nach Schwärzung erneut exportieren.
- PowerShell durch Unternehmensrichtlinie blockiert: Nicht umgehen; die Fehlermeldung zur Prüfung zurückgeben.

Die alte Installation wird nicht deinstalliert, migriert, gestartet oder verändert.
