@echo off
setlocal
pushd "%~dp0"
echo.
echo MCR Datenbruecke 0.2 - lokal, keine npm-Abhaengigkeiten
echo.
set "MCR_NODE="
if defined NODE_EXE if exist "%NODE_EXE%" set "MCR_NODE=%NODE_EXE%"
if not defined MCR_NODE if exist "%~dp0runtime\node.exe" set "MCR_NODE=%~dp0runtime\node.exe"
if not defined MCR_NODE if exist "%~dp0..\runtime\node.exe" set "MCR_NODE=%~dp0..\runtime\node.exe"
if not defined MCR_NODE if exist "%~dp0node.exe" set "MCR_NODE=%~dp0node.exe"
if not defined MCR_NODE for /f "delims=" %%I in ('where node.exe 2^>nul') do if not defined MCR_NODE set "MCR_NODE=%%I"
if not defined MCR_NODE set /p "MCR_NODE=Vollstaendiger Pfad zu node.exe ohne Anfuehrungszeichen: "
if not exist "%MCR_NODE%" (
 echo FEHLER: node.exe nicht gefunden.
 pause
 popd
 exit /b 1
)
"%MCR_NODE%" src\verify-package.mjs
if errorlevel 1 goto finished
if /i "%~1"=="test" (
 "%MCR_NODE%" --test tests\core.test.mjs tests\xlsx.test.mjs tests\bridge.test.mjs
 goto finished
)
if /i "%~1"=="demo" (
 "%MCR_NODE%" src\export-mapping.mjs --demo
) else (
 "%MCR_NODE%" src\export-mapping.mjs
)
:finished
set "MCR_RESULT=%ERRORLEVEL%"
echo.
echo Fenster mit beliebiger Taste schliessen.
pause
popd
exit /b %MCR_RESULT%
