import path from 'node:path';import {fileURLToPath} from 'node:url';
import {createInterface} from 'node:readline/promises';
import {stdin,stdout} from 'node:process';
import {readWorkbook} from '../lib/xlsx.mjs';import {exportMapping} from './mapping.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const demo=process.argv.includes('--demo');
const defaultFile=demo?path.join(root,'examples','DEMO_Datenbestand.xlsx'):String.raw`K:\INTL01\6_AU (Admin)\~ Data\~ Bestand Intel Gesamtübersicht\INTL01_Gesamtdatenbestand_30.09.2025.xlsx`;
const rl=createInterface({input:stdin,output:stdout});
try {
 console.log('\nMCR DATENBRUECKE 0.2 - XLSX -> lokaler JSON-Snapshot');
 console.log('Keine Netzabfragen, keine Excel-Aenderung, keine E-Mails.');
 let file=demo?defaultFile:(await rl.question('Excel-Pfad [Enter = bekannte INTL01-Datei]: ')).trim().replace(/^"|"$/g,'')||defaultFile;
 const book=readWorkbook(file);
 console.log('\nDatei:',book.meta.filename,'\nBlatt:',book.meta.sheet,'\nSpalten:',book.meta.headers,'\nGeaendert:',book.meta.modifiedAt,'\nSHA256:',book.meta.sha256);
 console.log('Datensaetze:',book.meta.dataRows,'Doppelte Kennungen:',book.meta.duplicateKeys,'Zeilen mit Formeln:',book.meta.formulaRows);
 console.log('Formeln werden NICHT neu berechnet; gespeichert wird nur der vorhandene Cache.');
 if (!demo && (await rl.question('Ist dies die richtige freigegebene Datenquelle und L der USC-Wert? JA: ')).trim()!=='JA') throw new Error('Abgebrochen. Keine Datei geschrieben.');
 const res=exportMapping(file,path.join(root,'private_data'),{mode:demo?'DEMO':'LOCAL_WORKBOOK',headerLConfirmed:true,expectedSha:book.meta.sha256});
 console.log('\nMAPPING ERZEUGT:',res.dest,'\nSHA256:',res.fileHash,'\nErgebnis:',res.summary);
 console.log('Gesperrte Kennungen werden NICHT geraten. JSON nur lokal behalten, nicht hochladen/committen.');
} catch(e) {console.error('\nSTOP:',e.code??'ERROR',e.message);process.exitCode=1;}
finally {rl.close();}
