import test from 'node:test';
import assert from 'node:assert/strict';
import {analyseCurrentTicketHistory,isStandardAcknowledgement,kindOfHistoryRow,STANDARD_ANSWER_NOTE} from '../lib/mail-history-audit.mjs';
const ACK='Sehr geehrter Herr Beispiel, vielen Dank, dass Sie sich mit uns in Verbindung gesetzt haben. Mit dieser E-Mail möchten wir Ihnen bestätigen, dass wir Ihr Ticket erhalten haben und unser Team derzeit daran arbeitet.';
const inbound={direction:'INCOMING',sender:'first.last@example.invalid',recipient:'team@example.invalid',subject:'Anfrage',content:'Bitte um Rückmeldung.'};
const outbound={direction:'OUTGOING',sender:'team@example.invalid',recipient:'first.last@example.invalid',subject:'[MERCER#90000001] Anfrage',content:ACK};

test('RC20 one inbound plus one sent standard answer: exact ticket, sender, and text',()=>{
 const a=analyseCurrentTicketHistory([inbound,outbound],'90000001');
 assert.deepEqual([a.total,a.customer,a.outgoing,a.system,a.unknown,a.standardAnswerRows],[2,1,1,0,0,1]);
 assert.equal(a.standardAnswerVerified,true);
 assert.equal(STANDARD_ANSWER_NOTE,'Standardantwort versendet');
});
test('RC20 another ticket number or wrong recipient cannot grant skip/annotation',()=>{
 assert.equal(analyseCurrentTicketHistory([inbound,{...outbound,subject:'[MERCER#90000002] Anfrage'}],'90000001').standardAnswerVerified,false);
 assert.equal(analyseCurrentTicketHistory([inbound,{...outbound,recipient:'other@example.invalid'}],'90000001').standardAnswerVerified,false);
 assert.equal(analyseCurrentTicketHistory([inbound,{...outbound,direction:'INCOMING'}],'90000001').standardAnswerVerified,false);
 assert.equal(analyseCurrentTicketHistory([inbound,outbound,outbound],'90000001').standardAnswerVerified,false);
 assert.equal(isStandardAcknowledgement('Vielen Dank für Ihre Rückmeldung.'),false);
});
test('RC20 incoming corporate secure relay and Exchange NDR are system, not customers',()=>{
 const relay={direction:'INCOMING',sender:'secureemail@mmc.com',recipient:'team@example.invalid',subject:'[SEND SECURE] Antwort',content:'Kundentext über Gateway'};
 const bounce={direction:'INCOMING',sender:'MicrosoftExchange329e71ec88ae4615bbc36ab6ce41109e@mercer.com',recipient:'team@example.invalid',subject:'Undeliverable: Nachricht',content:'Delivery has failed to these recipients'};
 const a=analyseCurrentTicketHistory([relay,bounce],'90000001');
 assert.deepEqual([a.total,a.customer,a.outgoing,a.system,a.unknown],[2,0,0,2,0]);
 assert.equal(a.standardAnswerVerified,false);
 assert.equal(kindOfHistoryRow({...relay,direction:'OUTGOING'}),'outgoing');
});
test('RC20 source counts separate customer, outgoing and uncertain labels',()=>{
 const rows=[{...inbound,sender:'two.part@example.invalid'},outbound,{...inbound,sender:'son.st@gmx.invalid'},
 {direction:'UNKNOWN',sender:'unknown',recipient:'',subject:'',content:''}];
 const a=analyseCurrentTicketHistory(rows,'90000001');
 assert.deepEqual([a.total,a.customer,a.outgoing,a.system,a.unknown],[4,2,1,0,1]);
 assert.equal(a.standardAnswerVerified,false); // Two possible original senders
});

test('RC20 compound first name from personal sender address, short aliases not auto-identified',async()=>{
 const {discoverNameHints}=await import('../lib/name-probes.mjs');
 for(const [local,expected] of [['jens.schumacher','Jens Schumacher'],['nataliia.stepanova','Nataliia Stepanova'],['krasimira.simeonova','Krasimira Simeonova'],['timm-peter.mueller','Timm-Peter Mueller']]){
  const hints=discoverNameHints({senderEmail:local+'@example.invalid',senderName:local+'@example.invalid',body:'Bitte um Bearbeitung.'});
  assert.equal(hints.candidates.length,1,local);
  assert.equal(hints.candidates[0].name,expected,local);
 }
 for(const local of ['son.st','no.reply','system.mail','sovan.middle.biswas','timm-peter']){
  const hints=discoverNameHints({senderEmail:local+'@example.invalid',body:'Bitte um Bearbeitung.'});
  if(local==='timm-peter')assert.equal(hints.candidates.length,1); // legacy first-last alias
  else assert.equal(hints.candidates.length,0,local);
 }
});
