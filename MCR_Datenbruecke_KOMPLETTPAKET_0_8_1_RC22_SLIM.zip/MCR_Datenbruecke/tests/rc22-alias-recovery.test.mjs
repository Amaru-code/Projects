import test from 'node:test';import assert from 'node:assert/strict';
import Person from '../lib/person-quoted.cjs';
import Identity from '../lib/identity-evidence.cjs';
import {weakSenderOnly,preferVerifiedFullName} from '../lib/name-resolution.mjs';
import {discoverNameHints} from '../lib/name-probes.mjs';
const scan=(senderEmail,body='')=>discoverNameHints({senderEmail,body}).candidates;
test('RC22 weak alias triggers original mail fallback rather than immediate final decision',()=>{
 const cs=scan('timm.mueller@example.invalid');
 assert.equal(cs.length,1);assert.equal(weakSenderOnly(cs),true);
 assert.equal(cs[0].firstName,'Timm');
});
test('RC22 original signed full compound name takes precedence over shorter alias when surname agrees',()=>{
 const alias=scan('timm.mueller@example.invalid');
 const signed=scan('timm.mueller@example.invalid','Hallo.\nMit freundlichen Grüßen\nTimm-Peter Müller');
 const best=preferVerifiedFullName([...alias,...signed]);
 assert.ok(best);assert.equal(best.firstName,'Timm-Peter');
 assert.equal(Identity.requireMatched({source:'PROFILE_ROWS',id:'12345',firstName:'Timm Peter',lastName:'Mueller'},best,{expectedId:'12345'}),true);
});
test('RC22 full MSG sender display can corroborate a shortened address, with COMARCH check retained',()=>{
 const alias=scan('timm.mueller@example.invalid');
 const display=discoverNameHints({senderEmail:'timm.mueller@example.invalid',senderName:'Timm-Peter Mueller'}).candidates;
 const best=preferVerifiedFullName([...alias,...display]);
 assert.ok(best);assert.equal(best.firstName,'Timm-Peter');
 assert.equal(Identity.requireMatched({source:'PROFILE_ROWS',id:'12345',firstName:'Timm Peter',lastName:'Mueller'},best,{}),true);
});
test('RC22 punctuation separators are allowed but different first/surname still blocked',()=>{
 const correct={firstName:'Timm-Peter',lastName:'Mueller'};
 assert.equal(Identity.requireMatched({source:'MEMBER_FIELD',id:'12345',display:'Mueller Timm Peter (INTL01-12345)'},correct,{}),true);
 assert.throws(()=>Identity.requireMatched({source:'PROFILE_ROWS',id:'12345',firstName:'Thomas Peter',lastName:'Mueller'},correct,{}),{code:'MEMBER_NAME_MISMATCH'});
 assert.throws(()=>Identity.requireMatched({source:'PROFILE_ROWS',id:'12345',firstName:'Timm-Peter',lastName:'Meyer'},correct,{}),{code:'MEMBER_NAME_MISMATCH'});
});
test('RC22 unrelated signature or contradictory strong names may not override sender',()=>{
 const alias=scan('timm.mueller@example.invalid');
 const different=scan('timm.mueller@example.invalid','Mit freundlichen Grüßen\nDaniel Müller');
 const other=scan('timm.mueller@example.invalid','Mit freundlichen Grüßen\nTimm-Peter Schmidt');
 assert.equal(preferVerifiedFullName([...alias,...different]),null);
 assert.equal(preferVerifiedFullName([...alias,...other]),null);
 const a=scan('timm.mueller@example.invalid','Name: Timm-Peter Mueller\nViele Grüße\nTimm-Jonas Mueller');
 assert.equal(preferVerifiedFullName([...alias,...a]),null);
});
test('RC22 explicit MercerID mismatch still blocks independent of e-mail alias',()=>{
 const full={firstName:'Timm-Peter',lastName:'Mueller'};
 assert.throws(()=>Identity.requireMatched({source:'PROFILE_ROWS',id:'12345',firstName:'Timm Peter',lastName:'Mueller'},full,{expectedId:'9999'}),{code:'MEMBER_ID_CONFLICT'});
});
