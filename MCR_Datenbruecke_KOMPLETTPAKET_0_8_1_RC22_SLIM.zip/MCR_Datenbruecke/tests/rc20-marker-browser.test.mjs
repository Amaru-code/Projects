/** Real headless browser: preserve current additional-description lines, add
 * exact status once and stop on overlong data. The reply editor is untouched. */
import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
import {appendStandardAnswerMarker} from '../lib/browser-workflow.mjs';
import {STANDARD_ANSWER_NOTE} from '../lib/mail-history-audit.mjs';
test('RC20 append already-sent status preserves USC lines and foreign email draft',async()=>{
 const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC20-NOTE-'));let browser,cdp;
 try{
  browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,extraArgs:process.platform==='linux'?['--no-sandbox','--disable-dev-shm-usage']:[]});
  ({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.url==='about:blank');
  await page.call(()=>{document.body.innerHTML=`<div id="mainForm:document-data-section"><label>Zusätzliche Beschreibung:</label><textarea id="description">USC 20/ PP+\nUSC 12/ DC</textarea></div><iframe id="reply"></iframe>`;
   document.getElementById('reply').contentDocument.body.innerText='Ein Entwurf von einem Mitarbeiter, NICHT veraendern!';});
  const first=await appendStandardAnswerMarker(page,STANDARD_ANSWER_NOTE);
  assert.equal(first.ok,true,JSON.stringify(first));assert.equal(first.changed,true);
  assert.equal(first.value,'USC 20/ PP+\nUSC 12/ DC\nStandardantwort versendet');
  const second=await appendStandardAnswerMarker(page,STANDARD_ANSWER_NOTE);
  assert.equal(second.ok,true);assert.equal(second.changed,false);
  const v=await page.call(()=>({note:document.getElementById('description').value,draft:document.getElementById('reply').contentDocument.body.innerText}));
  assert.equal(v.note,first.value);assert.equal(v.draft,'Ein Entwurf von einem Mitarbeiter, NICHT veraendern!');
  await page.call(()=>document.getElementById('description').value='x'.repeat(446));
  const tooLong=await appendStandardAnswerMarker(page,STANDARD_ANSWER_NOTE);
  assert.equal(tooLong.ok,false);assert.equal(tooLong.state,'STATUS_DESCRIPTION_TOO_LONG');
  assert.equal(await page.call(()=>document.getElementById('description').value),'x'.repeat(446));
  console.log('PASS RC20_APPENDED_STATUS_ONCE_NO_DRAFT_OVERWRITE_NO_TRUNCATION');
 }finally{await cleanupTemporaryTestBrowser({profile,browser,cdp});}
});
