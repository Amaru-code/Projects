import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
const make=()=>fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC20-NOTE-'));
const locked=code=>Object.assign(new Error('simulated Windows temporary profile lock'),{code});

test('RC21 cleanup waits for transient Windows EPERM and leaves no test directory',async()=>{
 const profile=make();let attempts=0,closes=0;
 const cdp={async send(m){assert.equal(m,'Browser.close');closes++;},close(){closes++;}};
 const result=await cleanupTemporaryTestBrowser({profile,cdp,browser:{child:{exitCode:0,signalCode:null}},pause:async()=>{},remove:async(p,o)=>{
  attempts++;if(attempts<=3)throw locked('EPERM');await fs.promises.rm(p,o);
 }});
 assert.equal(result.removed,true);assert.equal(attempts,4);assert.equal(closes,2);assert.equal(fs.existsSync(profile),false);
});

test('RC21 persistent Edge profile lock only warns after completed browser assertions',async()=>{
 const profile=make();const warnings=[];
 try{
  const result=await cleanupTemporaryTestBrowser({profile,attempts:3,pause:async()=>{},remove:async()=>{throw locked('EPERM');},warning:m=>warnings.push(m)});
  assert.equal(result.removed,false);assert.equal(result.errorCode,'EPERM');assert.equal(warnings.length,1);assert.match(warnings[0],/CLEANUP_DEFERRED/);
 }finally{fs.rmSync(profile,{force:true,recursive:true});}
});

test('RC21 temporary cleanup rejects any path outside its dedicated test prefix',async()=>{
 await assert.rejects(cleanupTemporaryTestBrowser({profile:path.join(os.tmpdir(),'MCR_BOT_LIVE_PROFILE'),remove:async()=>{throw new Error('should not run')}}),/UNSAFE_TEST_PROFILE_PATH/);
});

test('RC21 non-transient filesystem errors still fail rather than being concealed',async()=>{
 const profile=make();
 try{await assert.rejects(cleanupTemporaryTestBrowser({profile,attempts:2,remove:async()=>{throw locked('EINVAL');},pause:async()=>{}}),{code:'EINVAL'});}
 finally{fs.rmSync(profile,{force:true,recursive:true});}
});
