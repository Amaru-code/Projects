# RC22 — Alias-Auflösung ohne Identitätslockerung

## Ursache aus RC21-Liveprotokoll

`NAME_CANDIDATE_DISCOVERY: SENDER_EMAIL_LOCALPART` erzeugt lediglich einen Suchnamen aus der E-Mail. RC21 beendet die Recherche bereits bei diesem schwachen Kandidaten und prüft dessen exakte Schreibweise gegen COMARCH. Deshalb können zusammengesetzte Vornamen/abweichende Alias-Schreibweisen zu `MEMBER_NAME_MISMATCH` führen, obwohl die Original-MSG einen vollständigen unterschriebenen Namen enthalten könnte.

## Änderungen

- Besteht der einzige Namenshinweis aus einer persönlichen Absenderadresse, wird die **an das aktuelle Ticket gebundene Original-MSG** automatisch *lesend* abgerufen und nach einer eindeutig unterschriebenen oder ausdrücklich beschrifteten vollständigen Namensangabe durchsucht.
- Abkürzungen im E-Mail-Alias werden **nur für die Suche** genutzt. Ein stärkerer vollständiger Name ersetzt sie ausschließlich bei eindeutig übereinstimmendem Nachnamen und erstem Vornamenbestandteil; der ausgewählte COMARCH-Member und eine explizit genannte aktuelle MercerID müssen weiterhin exakt zur ausgewählten vollständigen Person passen.
- Varianten wie `Timm-Peter` / `Timm Peter` dürfen in COMARCH als dieselbe Folge vollständiger Namenstoken betrachtet werden; andere Vor- und Nachnamen bleiben blockiert.
- Die Sende-/Speicherlogik, Versandsperren, Archivpfade, Historiemarkierung und das Browserprofil wurden nicht geändert.

Bei weiterhin unpassendem Datensatz gilt `MEMBER_NAME_MISMATCH` als sicherer Stopp. Ohne die tatsächliche COMARCH-Diagnose kann nicht behauptet werden, dass der konkrete RC21-Echtfall durch die Aliasstrategie behoben ist.
