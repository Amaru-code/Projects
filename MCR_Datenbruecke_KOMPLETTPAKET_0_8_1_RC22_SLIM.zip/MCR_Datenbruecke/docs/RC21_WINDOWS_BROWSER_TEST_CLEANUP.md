# RC21 – Windows Testprofil-Bereinigung (27.10.2026)

## Beobachteter Fehler auf Windows
RC20 zeigte `PASS RC20_APPENDED_STATUS_ONCE_NO_DRAFT_OVERWRITE_NO_TRUNCATION`,
danach aber `EPERM` bei `fs.rmSync()` des generierten Chrome/Edge-Testprofils.
Der fachliche Test war erfolgreich; lediglich die synchrone Bereinigung eines
möglicherweise noch geöffneten Tempordners hat den Installer gestoppt.

## Zielgerichtete Reparatur
- Die Testbereinigung sendet `Browser.close` über die isolierte CDP-Verbindung.
- Sie wartet auf das Ende des **nur für diesen Test** gestarteten Browsers.
- Sie entfernt den Tempordner asynchron mit begrenzten Wiederholungen bei
  `EPERM`, `EACCES`, `EBUSY` und `ENOTEMPTY`.
- Falls ein externes Programm (z. B. Endpoint Security) diesen reinen
  Test-Tempordner länger blockiert, erfolgt eine sichtbare `WARN`-Meldung,
  aber **kein falscher Selbsttest-Fehler**. Die Tempdateien können später von
  der regulären Windows-Tempbereinigung entfernt werden.
- Andere Fehler (`EINVAL`, unbekannte Pfade) bleiben Fehler. Die Bereinigung
  akzeptiert **ausschließlich** neue `MCR-RC20-NOTE-*`-Ordner direkt unter
  dem System-Tempverzeichnis.

## Nicht geändert
Keine Änderung an produktivem Edge-Profil, privaten Mappingdaten, E-Mails,
Empfängern, Ticket-Markierungen, Sendelogik oder Journalen.

## Update
RC21 kann direkt über RC19 oder RC20 installiert werden. Alte Daten bleiben
mit dem vorhandenen Software-only-Installer erhalten. Aus einem separat
entpackten ZIP: `START.cmd` -> Menü 1 -> `EINRICHTEN`. Danach aus der
**installierten** `START.cmd` einen echten Pilotlauf über Menü 3 starten.

## Testumfang
Die bisherigen RC20-Tests bleiben vorhanden. Zusätzlich wird die Bereinigung
mit simuliertem transientem und permanentem Windows-`EPERM`, unzulässigen
Pfaden sowie nicht-transienten Fehlern regressionsgeprüft.
Die Tests im Paket ersetzen keine produktive COMARCH-Abnahme.
