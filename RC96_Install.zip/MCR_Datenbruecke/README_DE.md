# MCR DATENBRUECKE 0.8.1-rc.96

**Unveränderte Ticketbearbeitung aus RC95, Stationsfahrplan jetzt als echtes Vollbild.**

RC96 baut auf der RC95-Fassung mit `FLOW_MAP_OPEN_REQUESTED`, `MAP_START.cmd` und der gemeinsamen Bot-Edge-Sitzung auf. Die Karte enthält weiterhin die zwölf ursprünglichen Diagramme mit 341 Knoten und 429 Kanten. Der Fahrplan wird innerhalb dieser Oberfläche überarbeitet.

## Installieren

1. `RC96_Install.zip` vollständig in einen separaten Ordner entpacken.
2. Im entpackten Ordner `MCR_Datenbruecke\START.cmd` öffnen und **1** wählen.
3. Den Pfad der vorhandenen Installation prüfen und mit ENTER übernehmen. Auf **`PASS INSTALLATION_COMPLETE`** warten.
4. Anschließend die `START.cmd` der installierten Version verwenden. Die Titelzeile muss **0.8.1-rc.96** zeigen.

Beim Update werden Softwaredateien gesichert und ersetzt. Bestandsdaten, Konfiguration, Browserprofil und bisherige Laufjournale bleiben an ihrem Ort. Das Paket enthält keine produktiven Bestandsdaten. Zwei tatsächlich ausgelieferte, unveränderte RC94-Paketfassungen werden anhand ihrer festgelegten Prüfsummen unterstützt. Eine abweichende Installation wird weiterhin nicht stillschweigend übernommen.

## Person auswählen: Nummer oder Kennung

Der frühere Dialog wertete jede Eingabe als Listennummer aus. Bei zwei Namenshinweisen führte `11370121` deshalb zu `NAME_CHOICE`, statt als WWID weiterverarbeitet zu werden.

| Eingabe | Verhalten in RC95 |
| --- | --- |
| `1`, `2` usw. | Den entsprechenden angezeigten Namenshinweis auswählen. |
| `11370121` oder `WWID:11370121` | WWID als Suchhinweis verwenden und mit dem tatsächlichen COMARCH-Member verifizieren. |
| `ID:11370121` oder `MERCERID:11370121` | Die Kennung ausdrücklich als COMARCH-MercerID suchen und exakt prüfen. |
| Tippfehler oder leeres ENTER | Verständliche Rückmeldung; erneut nach der Auswahl fragen. |
| `UEBERSPRINGEN` | Diesen Fall vor Schreibaktionen und ohne offenes Aktionsjournal zurückstellen; andere geeignete Tickets können folgen. |
| `ABBRUCH` | Den Lauf ausdrücklich anhalten. |

Nach einer bestätigten Zuordnung geht der Runner durch die vorhandenen Identitätsprüfungen weiter zu Bestandsabgleich, Antwort und Versandablauf. Die eingegebene Kennung allein ersetzt keinen COMARCH-Profilnachweis. Eine WWID und eine MercerID werden getrennt behandelt. Fehlt ein eindeutiger Bezug, kann die Eingabe korrigiert oder eine Namensnummer ausgewählt werden, statt dass der ganze Lauf wegen der Eingabe endet.

Bei der WWID-Prüfung gilt entweder ein eindeutig beschriftetes WWID-Feld im bestätigten Profil oder der vorhandene geprüfte COMARCH-zu-Bestand-Lookup. Der bestehende Präfix-11-Fallback betrifft ausschließlich diesen Lookup. Er verändert weder die COMARCH-ID noch eine ausdrücklich im Originalticket genannte Identität. Falls die eingegebene Zahl tatsächlich die MercerID ist, bietet der Dialog den ausdrücklichen `ID:`-Weg an.

Ob die reale Kennung `11370121` in deinem Bestand WWID oder MercerID ist, lässt sich ohne diesen Datensatz nicht entscheiden. Der Regressionstest belegt die Verarbeitung der Eingabe und beider Zuordnungswege, keinen bereits ausgeführten Echtlauf dieses Tickets.

## Karte öffnen

- Beim Startangebot **„Live-Karte parallel öffnen?“** ENTER wählen.
- Im Hauptmenü **M** öffnet die Karte erneut.
- **`MAP_START.cmd`** oder **`MAP_OEFFNEN.cmd`** im installierten Ordner öffnet die verbundene Karte separat.
- Die zusätzlich gelieferte Datei `MCR_Flow_Lab_RC95.html` lässt sich allein im Browser öffnen. Das ist zunächst die unabhängige Karten- und Simulatoransicht. Eine automatische Live-Verbindung erhält sie über den Start aus der Installation.

Die normale Browserkarte und der eigene COMARCH-Bot-Edge bleiben getrennte Fenster. Die vorhandene lokale Ereignisverbindung wird übernommen. Kartenklicks steuern die Darstellung und den Simulator; Freigaben und Ticketaktionen erfolgen weiterhin im Bot.

## Fahrplan: den aktuellen Lauf verfolgen

Im Reiter **02 · Fahrplan** stehen 25 zusammengefasste Stationen mit festen Schriftgrößen. Breite Fenster zeigen die Strecke nebeneinander; bei wenig Platz bleibt sie scrollbar, statt alle Texte unleserlich klein zu skalieren.

Die Karte zeigt Start und Menü, Phase 1 mit Person/WWID/Bestand/Sprache/Versand/Speichern sowie Phase 2 mit den tatsächlichen Alternativen: direkte Weiterleitung, Kontoauszug, MBC-Entwurf und menschliche Einordnung einer unbekannten Anfrage. Beschriftete Rückwege führen zum nächsten Ticket oder Vorgang. Rückfragen, offene Fälle und Laufunterbrechung haben eigene Stationen.

Oben bleibt der Kontext sichtbar: **Phase, aktuelle Station, letzte Meldung und der vom Ergebnis abhängige nächste Schritt.** Ein Stationsklick öffnet die zugehörigen Erklärungen und Sprünge in die ursprünglichen Detaildiagramme. Phase 3 mit LenX und fachlichem Review bleibt als geplante Erweiterung gekennzeichnet.

Die Farben unterscheiden:

- **Grün:** der zur Station passende Nachweis; in der Simulation der berechnete Modellpfad.
- **Blau:** ein Schritt wurde gemeldet, sein Abschluss ist noch nicht nachgewiesen.
- **Gelb:** Rückfrage oder Prüfung wartet.
- **Rot:** Unterbrechung oder erforderliche Klärung.
- **Grau:** im aktuellen Ausschnitt noch nicht belegt.

Der Verlauf wird pro Ticket und Phase abgegrenzt. Frühere Ereignisse bleiben im Monitor, färben aber nicht das nächste Ticket erfolgreich. Fehlende Zwischenereignisse bleiben unbelegt. Neue Stationswechsel können eine tatsächlich vorhandene Kante kurz grün nachzeichnen. Die Anzeige baut keine künstliche Animationswarteschlange auf und hält den Bot nicht auf.

## Gesamtübersicht: schärfer und besser orientierbar

Die ursprüngliche Topologie bleibt vollständig erhalten. Geeignete Knotentexte werden als native SVG-Texte gezeichnet. Bei stärkerem Herauszoomen erscheinen ausgewählte **Kurzbeschriftungen in gleichbleibender Bildschirmgröße**: aktuelle Station, ausgewählte Station, relevante Ausgänge und wichtige Orientierungspunkte. Überlappende Beschriftungen werden begrenzt; der Volltext bleibt per Klick verfügbar.

**Aa Überblick** schaltet diese Beschriftungen um. **Aa Lesen** fokussiert eine Station. Das **Lesefenster** zeigt den vollständigen Text in fester Größe; es lässt sich an der Kopfzeile ziehen, einklappen oder ausblenden. Über **Lesefenster zeigen** kommt es zurück. Der weiße Hintergrund und die Navigation durch Ziehen bleiben erhalten.

Ein vollständiger Graph von etwa 4478 × 6688 Grafikeinheiten kann auf einem kleinen Bildschirm nicht zugleich sämtliche Absatztexte in normaler Schriftgröße zeigen. RC95 löst das durch lesbare Orientierungstexte und den Stationsfahrplan, nicht durch ein Versprechen beliebig kleiner, trotzdem lesbarer Schrift. Der SVG-Export umfasst das ganze ausgewählte Diagramm und nicht nur den aktuellen Bildausschnitt.

## Prüfstand und Grenzen

Siehe `docs/RC95_Pruefbericht.txt` für die tatsächlich ausgeführten Tests. Geprüft werden Dialog/Identitätsübergang, vorhandene Schutzregeln, Kartenmodelle, Laufabgrenzung, Geometrie, HTML-Syntax, lokaler Ereignistransport sowie Update/Rückweg mit synthetischen Daten.

**Kein produktiver COMARCH-Lauf und keine visuelle Windows-/Edge-Abnahme wurden in dieser Umgebung durchgeführt.** Die lokale Browser-Testumgebung lässt diese Prüfung hier nicht zu. Insbesondere tatsächliche Schriftmessung, Browserlayout und die reale WWID-Zuordnung müssen beim nächsten beaufsichtigten Einsatz beurteilt werden.

Wartung wie bisher: `node tools/cli.mjs --selftest`, `--demo`, `--status`, `--review`, `--rollback`, `--map`. Der komplette `--selftest` enthält auch ältere Browserprüfungen; die für diese Ausgabe ausgeführte Auswahl steht im Prüfbericht.

## RC96 · Fahrplan im Vollbild

1. Im Kartenfenster den Reiter **02 · Fahrplan** öffnen.
2. **⛶ Fahrplan-Vollbild** in der Zeile über dem Fahrplan klicken.
3. Die Karte füllt den Monitor. Andere Seitenleisten und das Simulatorpanel werden ausgeblendet.
4. Oben bleiben Phase, aktuelle Station, letztes Ereignis sowie die Regler **− / + / 100% / Einpassen** sichtbar.
5. Mit **✕ Schließen** oder **ESC** die normale Ansicht wiederherstellen.

**Einpassen** zeigt die ganze Stationskarte auf dem Bildschirm, notfalls mit kleineren Schriftgrößen. Für größere, gut lesbare Beschriftungen **+** verwenden und vertikal scrollen. Beides kann nicht gleichzeitig auf jedem Monitor garantiert werden. Bei blockierter nativer Vollbildfreigabe steht die gleiche Vollbildansicht innerhalb der Seite bereit.

Die Karte bleibt nur lesend, alle zwölf Originaldiagramme bleiben erhalten. RC96 führt **keine neuen COMARCH-Aktionen oder automatische Versandfreigaben** ein. Die lokale Live-Ereignisverbindung stammt unverändert aus RC95.
