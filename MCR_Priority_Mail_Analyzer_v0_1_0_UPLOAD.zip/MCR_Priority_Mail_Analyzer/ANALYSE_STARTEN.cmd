@echo off
setlocal
title MCR Outlook-Prioritaetsanalyse - NUR LESEND
cd /d "%~dp0"
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0PriorityMailAnalyzer.ps1"
set "MCR_EXIT=%ERRORLEVEL%"
echo.
if "%MCR_EXIT%"=="0" echo Lauf beendet. Details und Abdeckung im Bericht pruefen.
if "%MCR_EXIT%"=="2" echo Teilergebnis oder deklarierte Luecken. Bericht und coverage.csv pruefen.
if not "%MCR_EXIT%"=="0" if not "%MCR_EXIT%"=="2" echo Start-/Lauffehler. LIES_MICH.txt und obige Meldung pruefen.
echo Bei Signatur-/Firmenrichtlinienblockade keine Sicherheitseinstellungen abschalten; IT ansprechen.
pause
exit /b %MCR_EXIT%
