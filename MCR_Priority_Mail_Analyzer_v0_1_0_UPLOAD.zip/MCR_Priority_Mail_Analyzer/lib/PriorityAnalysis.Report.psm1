﻿#requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSScriptRoot 'PriorityAnalysis.Core.psm1') -ErrorAction Stop

function New-AnalysisContext {
    param([string]$RunPath,[string]$RunId,[object]$Rules,[object[]]$SelectedStores)
    $columns=@('RunId','RuleSetId','RulesSha256','MailKey','Store','Folder','FolderKind','DateUtc','Subject',
        'ProposedPriority','Provisional','Score','Reason','MatchedRules','NeedsReview','ReviewFlags',
        'OutlookImportance','BodyStatus','ReadStatus','Error','SyntheticTest','UnreadBefore','UnreadAfter',
        'BodyCharacters','AnalyzedCharacters','HumanPriority','HumanComment')
    $fc=@('StoreName','FolderPath','FolderKind','Status','FolderType','ItemsAtStart','ItemsAtEnd','RowsVisited',
        'MailRows','OtherRows','Duplicates','ContentGaps','Errors','ChildEnumerationComplete','Error')
    $ctx=[pscustomobject]@{
        RunId=$RunId; RunPath=$RunPath; Rules=$Rules; SelectedStores=$SelectedStores
        StartedUtc=[DateTime]::UtcNow; Status='RUNNING'; Total=0
        RealCounts=@{ urgent=0; important=0; low=0; unclassified=0 }
        SyntheticCounts=@{ urgent=0; important=0; low=0; unclassified=0 }
        FlagCounts=@{}; RuleHits=@{}; FolderKindCounts=@{}
        ReadGaps=0; SubjectOnly=0; ReviewNeeded=0; UnreadChanges=0; Errors=0
        FolderErrors=0; ChangedFolderCounts=0; SkippedSearchFolders=0; OtherRows=0; Duplicates=0
        CancelRequested=$false; LimitReached=$false; AllowConsoleCancel=$false; FatalOutputError=''
        StoreCoverage=(New-Object 'System.Collections.Generic.List[object]')
        FolderCoverage=(New-Object 'System.Collections.Generic.List[object]')
        Samples=@{}; SampleSeen=@{}; Random=[Random]::new(20261006)
        Csv=$null; FolderCsv=$null; IndexWriter=$null; Columns=$columns
    }
    try {
        $ctx.Csv=New-AnalysisCsvWriter (Join-Path $RunPath 'mail_analysis.csv') $columns
        $ctx.FolderCsv=New-AnalysisCsvWriter (Join-Path $RunPath 'coverage.csv') $fc
        $stream=[IO.File]::Open((Join-Path $RunPath 'message_index_PRIVATE.jsonl'),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
        $ctx.IndexWriter=[IO.StreamWriter]::new($stream,[Text.UTF8Encoding]::new($false))
        $ctx.IndexWriter.AutoFlush=$true
        return $ctx
    } catch {
        if ($null -ne $ctx.Csv) { $ctx.Csv.Writer.Dispose() }
        if ($null -ne $ctx.FolderCsv) { $ctx.FolderCsv.Writer.Dispose() }
        if ($null -ne $ctx.IndexWriter) { $ctx.IndexWriter.Dispose() }
        throw
    }
}
function Add-AnalysisCounter {
    param([hashtable]$Map,[string]$Key)
    if (-not $Map.ContainsKey($Key)) { $Map[$Key]=0 }
    $Map[$Key]++
}
function Add-AnalysisRecord {
    param([object]$Record,[object]$Context)
    $a=Get-MailPriorityAssessment -Subject $Record.Subject -Body $Record.Body -Rules $Context.Rules `
        -BodyStatus $Record.BodyStatus -OutlookImportance $Record.OutlookImportance `
        -MessageDateUtc $Record.MessageDateUtc -ReferenceUtc $Context.StartedUtc
    $flags=@($a.ReviewFlags -split ' \| ' | Where-Object { $_ })
    if ($Record.MetadataWarnings) { $flags+=@($Record.MetadataWarnings -split ' \| ') }
    if ($Record.FolderKind -in @('Sent','Drafts','Outbox')) { $flags+='OutgoingOrDraftContext' }
    $flags=@($flags | Select-Object -Unique)
    $review=($a.NeedsReview -or [bool]$Record.MetadataWarnings -or $Record.FolderKind -in @('Sent','Drafts','Outbox'))
    $key=Get-AnalysisSha256 ($Record.StoreId+"`0"+$Record.EntryId)
    $row=[pscustomobject][ordered]@{
        RunId=$Context.RunId; RuleSetId=$Context.Rules.Config.ruleSetId; RulesSha256=$Context.Rules.Sha256
        MailKey=$key; Store=$Record.StoreName; Folder=$Record.FolderPath; FolderKind=$Record.FolderKind
        DateUtc=$Record.MessageDateUtc; Subject=$Record.Subject
        ProposedPriority=$a.ProposedPriority; Provisional=$true; Score=$a.Score
        Reason=$a.Reason; MatchedRules=$a.MatchedRules; NeedsReview=$review; ReviewFlags=($flags -join ' | ')
        OutlookImportance=$Record.OutlookImportance; BodyStatus=$Record.BodyStatus
        ReadStatus=$Record.ReadStatus; Error=$Record.Error; SyntheticTest=$a.SyntheticTest
        UnreadBefore=$Record.UnreadBefore; UnreadAfter=$Record.UnreadAfter
        BodyCharacters=$a.BodyCharacters; AnalyzedCharacters=$a.AnalyzedCharacters
        HumanPriority=''; HumanComment=''
    }
    # No body, HTML, recipient list, attachments or quoted text is exported.
    Write-AnalysisCsvRow $Context.Csv $row
    $index=[pscustomobject]@{ MailKey=$key; StoreId=$Record.StoreId; EntryId=$Record.EntryId }
    $Context.IndexWriter.WriteLine(($index | ConvertTo-Json -Compress))
    $Context.Total++
    if ($a.SyntheticTest) { $Context.SyntheticCounts[$a.ProposedPriority]++ }
    else {
        $Context.RealCounts[$a.ProposedPriority]++
        foreach ($flag in $flags) { Add-AnalysisCounter $Context.FlagCounts $flag }
        foreach ($hit in @($a.MatchedRules -split ' \| ' | Where-Object { $_ })) { Add-AnalysisCounter $Context.RuleHits $hit }
        if ($review) { $Context.ReviewNeeded++ }
    }
    Add-AnalysisCounter $Context.FolderKindCounts $Record.FolderKind
    if ($Record.ReadStatus -ne 'Read') { $Context.ReadGaps++ }
    if ($Record.BodyStatus -eq 'Empty') { $Context.SubjectOnly++ }
    if ($Record.Error) { $Context.Errors++ }
    if ($flags -contains 'UnreadChangedDuringRead') { $Context.UnreadChanges++ }
    # Reservoir sampling across class x risk x folder context; not merely first N messages.
    if (-not $a.SyntheticTest) {
        $stratum=$a.ProposedPriority+'|'+[string]$review+'|'+$Record.FolderKind
        if (-not $Context.Samples.ContainsKey($stratum)) {
            $Context.Samples[$stratum]=New-Object 'System.Collections.Generic.List[object]'
            $Context.SampleSeen[$stratum]=0
        }
        $Context.SampleSeen[$stratum]++
        $sample=$Context.Samples[$stratum]
        $k=[int]$Context.Rules.Config.settings.reviewSamplePerStratum
        if ($sample.Count -lt $k) { [void]$sample.Add($row) }
        else {
            $pos=$Context.Random.Next([int]$Context.SampleSeen[$stratum])
            if ($pos -lt $k) { $sample[$pos]=$row }
        }
    }
}
function Add-AnalysisFolder {
    param([object]$Folder,[object]$Context)
    Write-AnalysisCsvRow $Context.FolderCsv $Folder
    [void]$Context.FolderCoverage.Add($Folder)
    if ($Folder.Errors -gt 0 -or -not $Folder.ChildEnumerationComplete) { $Context.FolderErrors++ }
    if ($Folder.Status -eq 'SkippedSearchFolder') { $Context.SkippedSearchFolders++ }
    if ($Folder.ItemsAtStart -ge 0 -and $Folder.ItemsAtEnd -ge 0 -and $Folder.ItemsAtStart -ne $Folder.ItemsAtEnd) {
        $Context.ChangedFolderCounts++
    }
    $Context.OtherRows += $Folder.OtherRows
    $Context.Duplicates += $Folder.Duplicates
}
function ConvertTo-AnalysisHtml {
    param([AllowNull()][object]$Value)
    return [Net.WebUtility]::HtmlEncode([string]$Value)
}
function Get-AnalysisRecommendations {
    param([object]$Context)
    $catalog=[ordered]@{
        NoReliableAssignment='Unklare Fälle fachlich prüfen. Erst aus bestätigten Beispielen fehlende Keywords oder Kriterien ableiten; fehlende Treffer nicht pauschal LOW nennen.'
        NegationFound='Verneinungen im Kontext prüfen. Ein einzelnes Wort wie dringend kann in nicht dringend vorkommen.'
        ResolutionConflict='Unterscheiden, ob eine Störung noch aktiv oder bereits behoben ist; keine automatische Regeländerung.'
        InformationActionConflict='Informationsmails mit eingebetteten Arbeitsaufträgen prüfen; FYI bedeutet nicht zwingend unwichtig.'
        UrgencyWithoutActionOrImpact='Prüfen, ob Zeitdruck ohne explizite Aufgabe/Auswirkung fachlich genügt; Betreff-Marketing kann ähnliche Wörter benutzen.'
        QuotedHistoryRemoved='Antwortketten prüfen: entfernt die Textaufbereitung nur historische Zitate oder auch benötigte aktuelle Zusammenhänge?'
        QuotedLinesRemoved='Zeilenweise Zitate werden ignoriert; bei Inline-Antworten kann Kontext fehlen.'
        BodyTruncated='Sehr lange Nachrichten prüfen. Für einen späteren Vergleich maxBodyCharacters kontrolliert anheben oder eine andere Textaufbereitung testen.'
        HistoricalMessage='Historische Mailtexte nicht mit heute offenen Aufgaben verwechseln. Die Diagnose bewertet Formulierungen, nicht den heutigen Bearbeitungsstand.'
        ImportanceDisagreement='Abweichungen zur Outlook-Markierung prüfen. Die Markierung stammt vom Absender und ist keine verlässliche Sollklasse.'
        ContentCoverageGap='Fehlende, geschützte oder nur als Header verfügbare Inhalte nachprüfen. Keine Umgehung von Schutzmechanismen.'
        SubjectOnly='Nur Betreff verfügbar: Vorschlag gesondert beurteilen und nicht wie eine vollständig gelesene Nachricht behandeln.'
        OutgoingOrDraftContext='Gesendet, Entwürfe und Postausgang gesondert bewerten. Eine Aufgabe für den Empfänger ist nicht automatisch deine eigene Aufgabe.'
        UnreadChangedDuringRead='Gelesenstatus änderte sich während des Lesefensters. Parallelaktivität/Add-ins prüfen; das Skript setzt diesen Status nicht zurück.'
        RegexTimeout='Mindestens ein Pattern erreichte sein Zeitlimit. Regel vereinfachen, bevor daraus Entscheidungen abgeleitet werden.'
    }
    $items=New-Object 'System.Collections.Generic.List[object]'
    foreach ($key in $catalog.Keys) {
        $count=0
        if ($Context.FlagCounts.ContainsKey($key)) { $count=$Context.FlagCounts[$key] }
        if ($count -gt 0) { [void]$items.Add([pscustomobject]@{ Signal=$key; Messages=$count; Proposal=$catalog[$key]; RuleChangeApplied=$false }) }
    }
    [void]$items.Add([pscustomobject]@{
        Signal='HumanValidationRequired'; Messages=($Context.Total-($Context.SyntheticCounts.Values | Measure-Object -Sum).Sum)
        Proposal='Auch scheinbar eindeutige Fälle stichprobenartig unabhängig bewerten. Ohne menschliche Sollklassen sind Genauigkeit, Precision und Recall nicht bestimmbar.'
        RuleChangeApplied=$false
    })
    return $items.ToArray()
}
function Complete-AnalysisReport {
    param([object]$Context)
    if ($null -ne $Context.Csv) { $Context.Csv.Writer.Dispose(); $Context.Csv=$null }
    if ($null -ne $Context.FolderCsv) { $Context.FolderCsv.Writer.Dispose(); $Context.FolderCsv=$null }
    if ($null -ne $Context.IndexWriter) { $Context.IndexWriter.Dispose(); $Context.IndexWriter=$null }
    $run=$Context.RunPath
    $scsv=New-AnalysisCsvWriter (Join-Path $run 'review_sample.csv') $Context.Columns
    $blindCols=@('RunId','MailKey','Store','Folder','DateUtc','Subject','HumanPriority','HumanComment')
    $bcsv=New-AnalysisCsvWriter (Join-Path $run 'review_blind.csv') $blindCols
    $sampleN=0
    try {
        foreach ($k in @($Context.Samples.Keys | Sort-Object)) {
            foreach ($row in $Context.Samples[$k]) {
                Write-AnalysisCsvRow $scsv $row; Write-AnalysisCsvRow $bcsv $row; $sampleN++
            }
        }
    } finally { $scsv.Writer.Dispose(); $bcsv.Writer.Dispose() }
    $stores=New-Object 'System.Collections.Generic.List[object]'
    foreach ($selected in $Context.SelectedStores) {
        $found=@($Context.StoreCoverage | Where-Object { $_.StoreId -eq $selected.StoreId })
        if ($found.Count -gt 0) { [void]$stores.Add($found[0]) }
        else { [void]$stores.Add([pscustomobject]@{ StoreName=$selected.Name; StoreId=$selected.StoreId; IsCachedExchange=$selected.IsCachedExchange; Status='NotStarted'; FoldersEnumerated=0; Error=''; DeletedFolderResolved=$false; ServerCompleteness='Unverified' }) }
    }
    Write-AnalysisJson (Join-Path $run 'stores_PRIVATE.json') @($stores.ToArray())
    $recommendations=@(Get-AnalysisRecommendations $Context)
    Write-AnalysisJson (Join-Path $run 'improvement_observations.json') $recommendations
    $duration=([DateTime]::UtcNow-$Context.StartedUtc).TotalSeconds
    $summary=[pscustomobject][ordered]@{
        SchemaVersion=1; RunId=$Context.RunId; Status=$Context.Status
        StartedUtc=$Context.StartedUtc.ToString('o'); FinishedUtc=[DateTime]::UtcNow.ToString('o')
        DurationSeconds=[Math]::Round($duration,2)
        RuleSetId=$Context.Rules.Config.ruleSetId; RulesSha256=$Context.Rules.Sha256
        DataSource=$(if ($Context.Status -like 'DEMO_*') {'SYNTHETIC_DEMO'} else {'OUTLOOK_OR_TEST_ADAPTER'}); SelectedStores=$Context.SelectedStores.Count; StartedStores=$Context.StoreCoverage.Count
        VisitedFolders=$Context.FolderCoverage.Count; FolderErrors=$Context.FolderErrors
        ChangedFolderCounts=$Context.ChangedFolderCounts; SkippedSearchFolders=$Context.SkippedSearchFolders
        TotalMailInstances=$Context.Total; RealMailProposals=$Context.RealCounts; SyntheticTestProposals=$Context.SyntheticCounts
        RealMailsNeedingReview=$Context.ReviewNeeded; ReadGaps=$Context.ReadGaps; EmptyBodies=$Context.SubjectOnly
        ReadErrors=$Context.Errors; UnreadChangesObserved=$Context.UnreadChanges
        OtherItemsNotAnalyzed=$Context.OtherRows; DuplicateStoreEntryIdsSkipped=$Context.Duplicates
        FolderKindCounts=$Context.FolderKindCounts; ReviewSignalsForRealMail=$Context.FlagCounts
        ReviewSampleMessages=$sampleN; RuleChangesApplied=$false; ExternalClassifierRequests=0
        MessageBodyExported=$false; MailboxWriteOperationsRequested=$false
        ServerCompleteness='UNVERIFIED'; RecoverableItems='NOT_SCANNED'; HiddenItems='NOT_SCANNED'
        GroundTruth='NOT_AVAILABLE'; Accuracy='NOT_MEASURED'
        Interpretation='Provisional classification of available message text in its historical context; not a current task list.'
    }
    Write-AnalysisJson (Join-Path $run 'summary_shareable.json') $summary
    $h=New-Object Text.StringBuilder
    [void]$h.AppendLine(@'
<!doctype html><html lang="de"><head><meta charset="utf-8">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'">
<title>MCR – Outlook-Prioritätsanalyse</title>
<style>body{font-family:Segoe UI,Arial,sans-serif;max-width:1150px;margin:40px auto;padding:0 25px;line-height:1.55;color:#23303d}h1{font-size:32px}h2{margin-top:32px}table{border-collapse:collapse;width:100%;margin:15px 0}th,td{text-align:left;padding:10px;border-bottom:1px solid #ddd;vertical-align:top}th{background:#f1f4f6}.notice{padding:18px;border-left:5px solid #b17519;background:#fff8e8}code{overflow-wrap:anywhere}small{color:#596572}</style></head><body>
<h1>Outlook-Prioritätsanalyse</h1><p>Lokale Diagnose · Nur lesend · Keine Regeländerungen</p>
<div class="notice"><b>Vorschläge, keine bestätigten Prioritäten.</b> Der Generator hatte keine Klassifizierungsregeln.
Diese neue Diagnose-Baseline ersetzt keine fachlich freigegebene Definition. URGENT bedeutet hier ein Signal
im damaligen Mailtext – nicht, dass diese historische Aufgabe heute noch offen ist.</div>
'@)
    [void]$h.AppendLine('<p>Status: <b>'+(ConvertTo-AnalysisHtml $summary.Status)+'</b> · Lauf: <code>'+(ConvertTo-AnalysisHtml $summary.RunId)+'</code></p>')
    if ($summary.DataSource -eq 'SYNTHETIC_DEMO') {
        [void]$h.AppendLine('<div class="notice"><b>SYNTHETISCHE DEMO:</b> Alle nachfolgenden Daten stammen aus Testfällen. Es wurden keinerlei echte Postfächer oder Mailtexte gelesen. Die als echte Mailinstanzen bezeichnete Vergleichsspalte enthält in diesem DEMO-Lauf nur synthetische Prüffälle ohne PRIO-TEST-Kennung.</div>')
    }
    [void]$h.AppendLine('<h2>1 · Vorläufige Verteilung</h2><table><tr><th>Vorschlag</th><th>Echte Mailinstanzen</th><th>Synthetische PRIO-TEST-Mails</th></tr>')
    foreach ($k in @('urgent','important','low','unclassified')) {
        [void]$h.AppendLine("<tr><td>$k</td><td>$($Context.RealCounts[$k])</td><td>$($Context.SyntheticCounts[$k])</td></tr>")
    }
    [void]$h.AppendLine('</table><p>unclassified bedeutet: fachlich prüfen. Es ist keine vierte fachliche Priorität. Gezählt werden gespeicherte Mailinstanzen; eine gesendete und eine empfangene Kopie sind getrennte Datensätze.</p>')
    [void]$h.AppendLine('<h2>2 · Abdeckung und Grenzen</h2>')
    [void]$h.AppendLine("<p>$($summary.SelectedStores) Speicher ausgewählt; $($summary.StartedStores) begonnen. $($summary.VisitedFolders) Ordner besucht; $($summary.FolderErrors) mit Fehlern/Lücken. $($summary.ReadGaps) Mailtexte nicht regulär gelesen. $($summary.ChangedFolderCounts) Ordner änderten ihre Elementanzahl während des Laufs.</p>")
    [void]$h.AppendLine('<table><tr><th>Datenspeicher</th><th>Cache-Modus</th><th>Traversal</th><th>Gelöschte Elemente identifiziert</th></tr>')
    foreach ($st in $stores) {
        [void]$h.AppendLine('<tr><td>'+(ConvertTo-AnalysisHtml $st.StoreName)+'</td><td>'+(ConvertTo-AnalysisHtml $st.IsCachedExchange)+'</td><td>'+(ConvertTo-AnalysisHtml $st.Status)+'</td><td>'+(ConvertTo-AnalysisHtml $st.DeletedFolderResolved)+'</td></tr>')
    }
    [void]$h.AppendLine('</table><p><b>Keine serverweite Vollständigkeitsbestätigung.</b> Es werden nur zugängliche, sichtbare Mailobjekte der ausgewählten Outlook-Speicher durchlaufen. Cache-Zeitraum, Rechte, Onlinearchive und fehlende Inhalte können die Abdeckung begrenzen. Gelöschte Elemente und deren Unterordner sind enthalten, soweit zugänglich. Versteckte Recoverable Items und endgültig entfernte Inhalte sind nicht enthalten. Kalender, Kontakte, Termine und Anhänge werden nicht inhaltlich analysiert.</p><p>Suchordner werden als virtuelle Duplikatansichten übersprungen. Unbekannte Ordnerarten werden versucht und in coverage.csv dokumentiert. Outlook sollte während des Scans nicht umorganisiert werden; es gibt keinen transaktionalen Snapshot.</p>')
    [void]$h.AppendLine('<h2>3 · Beobachtungen für spätere Verbesserungen</h2><p>Mehrfachzählungen möglich: eine Mail kann mehrere Prüfsignale haben. Die folgenden Hinweise ändern keine Regeln.</p><table><tr><th>Signal</th><th>Mails</th><th>Prüfansatz</th></tr>')
    foreach ($o in $recommendations) {
        [void]$h.AppendLine('<tr><td>'+(ConvertTo-AnalysisHtml $o.Signal)+'</td><td>'+$o.Messages+'</td><td>'+(ConvertTo-AnalysisHtml $o.Proposal)+'</td></tr>')
    }
    [void]$h.AppendLine('</table><h2>4 · Häufige Regeltreffer (nur echte Mails)</h2><table><tr><th>Regel</th><th>Nachrichten mit Treffer</th></tr>')
    foreach ($item in @($Context.RuleHits.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 40)) {
        [void]$h.AppendLine('<tr><td>'+(ConvertTo-AnalysisHtml $item.Key)+'</td><td>'+$item.Value+'</td></tr>')
    }
    [void]$h.AppendLine('</table><h2>5 · Fachliche Prüfung</h2><p>In <b>mail_analysis.csv</b> stehen alle Mailvorschläge samt Gründen. <b>review_sample.csv</b> enthält eine nach Klasse, Unsicherheit und Ordnerkontext geschichtete Stichprobe. <b>review_blind.csv</b> enthält dieselbe Stichprobe ohne Modellvorschläge. Trage dort HumanPriority (urgent, important oder low) und optional HumanComment ein; schlage die Mail bei Bedarf selbst in Outlook nach. Keine Mail wird zum Prüfen automatisch geöffnet.</p><p>Die Stichprobe ist bewusst nicht proportional. Ihre rohe Trefferquote wäre keine zuverlässige Gesamtgenauigkeit. Outlook-Wichtigkeit, Löschung und Gelesenstatus sind keine menschliche Referenzbewertung.</p>')
    [void]$h.AppendLine('<h2>6 · Datenschutz und Anpassung</h2><p>Keine API-Aufrufe an einen KI-Anbieter. Es werden keine Nachrichten versendet, gespeichert, verschoben oder gelöscht und keine Eigenschaften gesetzt. Outlook kann bei autorisiertem Lesen dennoch mit dem eigenen Mailserver kommunizieren. Volltexte und Anhänge werden nicht exportiert. Betreffzeilen, Ordnernamen, IDs und Fehlermeldungen in lokalen Ergebnisdateien sind vertraulich. Keine Ergebnis-ZIPs ungeprüft weitergeben.</p>')
    [void]$h.AppendLine('<p>Regeln: <code>config\priority_rules.json</code>; Entscheidungslogik: <code>lib\PriorityAnalysis.Core.psm1 → Get-MailPriorityAssessment</code>. Für spätere Varianten zuerst eine Kopie der Regeldatei erstellen und mit <code>-RulesPath</code> auswählen. Jeder Lauf archiviert seine Regeldatei unverändert und bindet sie per SHA256.</p>')
    [void]$h.AppendLine('<p><small>Regelsatz: '+(ConvertTo-AnalysisHtml $summary.RuleSetId)+' · SHA256: <code>'+$summary.RulesSha256+'</code></small></p></body></html>')
    [IO.File]::WriteAllText((Join-Path $run 'BERICHT.html'),$h.ToString(),[Text.UTF8Encoding]::new($false))
    return $summary
}
Export-ModuleMember -Function New-AnalysisContext,Add-AnalysisRecord,Add-AnalysisFolder,Complete-AnalysisReport
