﻿#requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Get-AnalysisSha256 {
    param([Parameter(Mandatory=$true)][AllowEmptyString()][string]$Text)
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($Text)))).Replace('-','').ToLowerInvariant() }
    finally { $sha.Dispose() }
}

function Read-AnalysisRules {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Path)
    $raw = [IO.File]::ReadAllText([IO.Path]::GetFullPath($Path), [Text.UTF8Encoding]::new($false,$true))
    $r = $raw | ConvertFrom-Json
    if ($r.schemaVersion -ne 1) { throw 'Nicht unterstützte schemaVersion der Regeldatei.' }
    if ([string]::IsNullOrWhiteSpace($r.ruleSetId)) { throw 'ruleSetId fehlt.' }
    $s = $r.settings
    foreach ($name in @('maxBodyCharacters','regexTimeoutMilliseconds','urgentScoreThreshold','importantScoreThreshold','historicalAfterDays','reviewSamplePerStratum')) {
        $v = $s.$name
        if (($v -isnot [int] -and $v -isnot [long]) -or $v -lt 1) { throw "settings.$name muss eine positive ganze Zahl sein." }
    }
    if ($s.maxBodyCharacters -gt 2000000 -or $s.regexTimeoutMilliseconds -gt 2000 -or $s.reviewSamplePerStratum -gt 200) {
        throw 'Regeldatei überschreitet Sicherheitsgrenzen (Text: 2 Mio. Zeichen; Regex: 2000 ms; Stichprobe: 200 je Gruppe).'
    }
    if ($s.stripQuotedHistory -isnot [bool]) { throw 'stripQuotedHistory muss true oder false sein.' }
    $names = @('urgency','impact','action','planning','information','resolution','negation')
    foreach ($p in $r.groups.PSObject.Properties) {
        if ($names -notcontains $p.Name) { throw ('Unbekannte Regelgruppe: '+$p.Name) }
    }
    $options = [Text.RegularExpressions.RegexOptions]::IgnoreCase -bor [Text.RegularExpressions.RegexOptions]::CultureInvariant
    $compiled = @{}
    foreach ($name in $names) {
        $g = $r.groups.$name
        if (($g.weight -isnot [int] -and $g.weight -isnot [long]) -or $g.weight -lt 0 -or $g.weight -gt 20) {
            throw "groups.$name.weight muss eine ganze Zahl zwischen 0 und 20 sein."
        }
        if ($name -in @('information','resolution','negation') -and $g.weight -ne 0) {
            throw "groups.$name.weight muss 0 bleiben; diese Kontextgruppen steuern keinen numerischen Score."
        }
        if ($g.keywords -isnot [array] -or $g.patterns -isnot [array]) { throw "keywords und patterns müssen Arrays sein: $name" }
        if (($g.keywords.Count + $g.patterns.Count) -gt 500) { throw "Zu viele Einträge in $name." }
        $matchers = New-Object 'System.Collections.Generic.List[object]'
        foreach ($kw in $g.keywords) {
            if ($kw -isnot [string] -or [string]::IsNullOrWhiteSpace($kw) -or $kw.Length -gt 300) { throw "Ungültiges Keyword in $name." }
            $normal = $kw.Trim().Normalize([Text.NormalizationForm]::FormC)
            $pattern = '(?<![\p{L}\p{N}_])' + [regex]::Escape($normal) + '(?![\p{L}\p{N}_])'
            $rx = [regex]::new($pattern, $options, [TimeSpan]::FromMilliseconds($s.regexTimeoutMilliseconds))
            [void]$matchers.Add([pscustomobject]@{ Id=($name+':'+$normal); Regex=$rx })
        }
        $i = 0
        foreach ($pattern in $g.patterns) {
            $i++
            if ($pattern -isnot [string] -or [string]::IsNullOrWhiteSpace($pattern) -or $pattern.Length -gt 1000) { throw "Ungültiges Pattern in $name." }
            try { $rx = [regex]::new($pattern,$options,[TimeSpan]::FromMilliseconds($s.regexTimeoutMilliseconds)) }
            catch { throw "Ungültiger regulärer Ausdruck in $name, Nummer $i." }
            if ($rx.IsMatch('')) { throw "Pattern darf nicht den leeren Text treffen: $name/$i." }
            [void]$matchers.Add([pscustomobject]@{ Id=($name+':pattern-'+$i); Regex=$rx })
        }
        $compiled[$name] = $matchers.ToArray()
    }
    return [pscustomobject]@{
        Config=$r; Compiled=$compiled; RawText=$raw
        Sha256=(Get-AnalysisSha256 -Text $raw)
    }
}

function Get-AnalysisText {
    param([AllowEmptyString()][string]$Subject='', [AllowEmptyString()][string]$Body='', [Parameter(Mandatory=$true)][object]$Rules)
    $flags = New-Object 'System.Collections.Generic.List[string]'
    $length = $Body.Length
    $limit = [int]$Rules.Config.settings.maxBodyCharacters
    if ($Body.Length -gt $limit) { $Body=$Body.Substring(0,$limit); [void]$flags.Add('BodyTruncated') }
    $Body = $Body.Replace("`r`n","`n").Replace("`r","`n")
    if ($Rules.Config.settings.stripQuotedHistory) {
        # Only well-defined reply-header boundaries, never arbitrary words in prose.
        $boundary = [regex]::Match($Body, '(?im)^(?:\s*-{2,}\s*(?:Original Message|Ursprüngliche Nachricht|Weitergeleitete Nachricht)\s*-{2,}\s*|\s*On .{1,250} wrote:\s*|\s*Am .{1,250} schrieb .{0,150}:\s*)$')
        if ($boundary.Success) { $Body=$Body.Substring(0,$boundary.Index); [void]$flags.Add('QuotedHistoryRemoved') }
        # Outlook's header block without a dashed separator.
        $boundary2 = [regex]::Match($Body, '(?im)^\s*(?:Von|From):[^\n]+\n(?:[^\n]*\n){0,2}\s*(?:Gesendet|Sent|Date|Datum):[^\n]+\n(?:[^\n]*\n){0,3}\s*(?:An|To):')
        if ($boundary2.Success) { $Body=$Body.Substring(0,$boundary2.Index); if (-not $flags.Contains('QuotedHistoryRemoved')) { [void]$flags.Add('QuotedHistoryRemoved') } }
        if ([regex]::IsMatch($Body,'(?m)^\s*>')) {
            $Body=[regex]::Replace($Body,'(?m)^\s*>[^\n]*(?:\n|$)','')
            [void]$flags.Add('QuotedLinesRemoved')
        }
    }
    $cleanSubject = [regex]::Replace($Subject,'(?i)^(?:(?:re|aw|fw|fwd|wg)\s*:\s*)+','')
    $cleanSubject = [regex]::Replace($cleanSubject,'(?i)\[PRIO-TEST\s+[^\]]+\]\s*','')
    $text = ($cleanSubject+"`n"+$Body).Normalize([Text.NormalizationForm]::FormC)
    return [pscustomobject]@{ Text=$text; Flags=$flags.ToArray(); OriginalBodyCharacters=$length; AnalyzedCharacters=$text.Length }
}

function Get-MailPriorityAssessment {
    [CmdletBinding()]
    param(
        [AllowEmptyString()][string]$Subject='',
        [AllowEmptyString()][string]$Body='',
        [Parameter(Mandatory=$true)][object]$Rules,
        [string]$BodyStatus='Available',
        [int]$OutlookImportance=-1,
        [AllowEmptyString()][string]$MessageDateUtc='',
        [datetime]$ReferenceUtc=[DateTime]::UtcNow
    )
    $prepared = Get-AnalysisText -Subject $Subject -Body $Body -Rules $Rules
    $flags = New-Object 'System.Collections.Generic.List[string]'
    foreach ($f in $prepared.Flags) { [void]$flags.Add($f) }
    $hits = New-Object 'System.Collections.Generic.List[string]'
    $groups = @{}
    $text = $prepared.Text
    $matchError=$false
    # Negated phrases are removed only at their own location, not from the entire mail.
    $negated=$false
    foreach ($m in $Rules.Compiled['negation']) {
        try {
            if ($m.Regex.IsMatch($text)) {
                $negated=$true; [void]$hits.Add($m.Id)
                $text=$m.Regex.Replace($text,' ')
            }
        } catch [Text.RegularExpressions.RegexMatchTimeoutException] { $matchError=$true }
    }
    if ($negated) { [void]$flags.Add('NegationFound') }
    foreach ($name in @('urgency','impact','action','planning','information','resolution')) {
        $found=$false
        foreach ($m in $Rules.Compiled[$name]) {
            try {
                $groupText=$text
                if ($name -in @('information','resolution')) { $groupText=$prepared.Text }
                if ($m.Regex.IsMatch($groupText)) { $found=$true; [void]$hits.Add($m.Id) }
            } catch [Text.RegularExpressions.RegexMatchTimeoutException] { $matchError=$true }
        }
        $groups[$name]=$found
    }
    $score=0
    foreach ($name in @('urgency','impact','action','planning')) {
        if ($groups[$name]) { $score += [int]$Rules.Config.groups.$name.weight }
    }
    $proposal='unclassified'
    $reason='Kein ausreichender positiver Regelbeleg; nicht automatisch unwichtig.'
    if ($groups.urgency -and ($groups.impact -or $groups.action) -and $score -ge $Rules.Config.settings.urgentScoreThreshold) {
        $proposal='urgent'; $reason='Zeitdruck plus Handlung/Auswirkung; Diagnose-Schwelle erreicht.'
    } elseif ($score -ge $Rules.Config.settings.importantScoreThreshold -and ($groups.action -or $groups.planning -or $groups.impact)) {
        $proposal='important'; $reason='Aufgabe, Auswirkung oder planbare Klärung ohne ausreichenden Urgent-Beleg.'
    } elseif (($groups.information -or $groups.resolution) -and -not ($groups.action -or $groups.planning -or $groups.impact -or $groups.urgency)) {
        $proposal='low'; $reason='Explizites Informations-/Entwarnungssignal; kein positiver Aufgabenbeleg.'
    }
    if ($groups.resolution -and ($groups.urgency -or $groups.impact)) {
        [void]$flags.Add('ResolutionConflict')
        $proposal='unclassified'
        $reason='Erledigung und Dringlichkeits-/Ausfallhinweis widersprechen sich; Kontext prüfen.'
    }
    if ($groups.information -and ($groups.action -or $groups.urgency -or $groups.impact)) { [void]$flags.Add('InformationActionConflict') }
    if ($groups.urgency -and -not ($groups.action -or $groups.impact)) { [void]$flags.Add('UrgencyWithoutActionOrImpact') }
    if ([string]::IsNullOrWhiteSpace($Body)) { [void]$flags.Add('SubjectOnly') }
    if ($BodyStatus -ne 'Available') {
        [void]$flags.Add('ContentCoverageGap')
        # Fail open for review, never silently classify unreadable mail as low.
        if ($BodyStatus -notin @('Empty','AvailableDownloadStateUnknown')) {
            $proposal='unclassified'; $reason='Nachrichtentext nicht vollständig lesbar; keine belastbare Einstufung.'
        }
    }
    if ($matchError) { [void]$flags.Add('RegexTimeout'); $proposal='unclassified'; $reason='Regex-Zeitlimit: Regelprüfung unvollständig.' }
    $age=''
    if (-not [string]::IsNullOrWhiteSpace($MessageDateUtc)) {
        $d=[DateTimeOffset]::MinValue
        if ([DateTimeOffset]::TryParse($MessageDateUtc,[ref]$d)) {
            $age=[Math]::Floor(($ReferenceUtc.ToUniversalTime()-$d.UtcDateTime).TotalDays)
            if ($age -ge $Rules.Config.settings.historicalAfterDays) { [void]$flags.Add('HistoricalMessage') }
        } else { [void]$flags.Add('MessageDateUnknown') }
    } else { [void]$flags.Add('MessageDateUnknown') }
    # Sender's Outlook marking is a comparison signal, never ground truth or a scoring input.
    if (($OutlookImportance -eq 2 -and $proposal -ne 'urgent') -or ($OutlookImportance -eq 0 -and $proposal -in @('urgent','important'))) {
        [void]$flags.Add('ImportanceDisagreement')
    }
    if ($proposal -eq 'unclassified') { [void]$flags.Add('NoReliableAssignment') }
    $synthetic=[regex]::IsMatch($Subject,'(?i)\[PRIO-TEST\s+[^\]]+\]')
    $riskFlags=@($flags | Where-Object { $_ -ne 'HistoricalMessage' })
    return [pscustomobject][ordered]@{
        ProposedPriority=$proposal; Provisional=$true; Score=$score
        Reason=$reason; MatchedRules=($hits -join ' | ')
        UrgencySignal=[bool]$groups.urgency; ImpactSignal=[bool]$groups.impact
        ActionSignal=[bool]$groups.action; PlanningSignal=[bool]$groups.planning
        InformationSignal=[bool]$groups.information; ResolutionSignal=[bool]$groups.resolution
        NeedsReview=($riskFlags.Count -gt 0); ReviewFlags=($flags -join ' | ')
        SyntheticTest=$synthetic; MessageAgeDays=$age
        BodyCharacters=$prepared.OriginalBodyCharacters; AnalyzedCharacters=$prepared.AnalyzedCharacters
    }
}

function ConvertTo-AnalysisCsvCell {
    param([AllowNull()][object]$Value)
    if ($null -eq $Value) { return '""' }
    $s=[string]$Value
    # CSV formula-injection protection, including after whitespace/control characters.
    $s=[regex]::Replace($s,'[\x00-\x08\x0B\x0C\x0E-\x1F]',' ')
    $s=$s.Replace("`r",' ').Replace("`n",' ')
    if ($s -match '^\s*[=+\-@]') { $s="'"+$s }
    return '"'+$s.Replace('"','""')+'"'
}

function New-AnalysisCsvWriter {
    param([Parameter(Mandatory=$true)][string]$Path,[Parameter(Mandatory=$true)][string[]]$Columns)
    $stream=[IO.File]::Open($Path,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
    $writer=[IO.StreamWriter]::new($stream,[Text.UTF8Encoding]::new($true))
    $writer.AutoFlush=$true
    $writer.WriteLine((@($Columns | ForEach-Object { ConvertTo-AnalysisCsvCell $_ }) -join ';'))
    return [pscustomobject]@{ Writer=$writer; Columns=$Columns }
}
function Write-AnalysisCsvRow {
    param([Parameter(Mandatory=$true)][object]$Csv,[Parameter(Mandatory=$true)][object]$Row)
    $values=foreach ($c in $Csv.Columns) {
        $p=$Row.PSObject.Properties[$c]
        if ($null -eq $p) { ConvertTo-AnalysisCsvCell '' } else { ConvertTo-AnalysisCsvCell $p.Value }
    }
    $Csv.Writer.WriteLine(($values -join ';'))
}
function Write-AnalysisJson {
    param([string]$Path,[object]$Value)
    [IO.File]::WriteAllText($Path,($Value | ConvertTo-Json -Depth 12),[Text.UTF8Encoding]::new($false))
}
Export-ModuleMember -Function Get-AnalysisSha256,Read-AnalysisRules,Get-AnalysisText,Get-MailPriorityAssessment,ConvertTo-AnalysisCsvCell,New-AnalysisCsvWriter,Write-AnalysisCsvRow,Write-AnalysisJson
