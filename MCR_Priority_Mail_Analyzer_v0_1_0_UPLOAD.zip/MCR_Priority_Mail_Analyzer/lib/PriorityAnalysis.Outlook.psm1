﻿#requires -Version 5.1
# Outlook adapter: read operations only. Does not import the generator's send module.
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSScriptRoot 'PriorityAnalysis.Core.psm1') -ErrorAction Stop

function Release-AnalysisCom {
    param([AllowNull()][object]$Value)
    if ($null -ne $Value -and [Runtime.InteropServices.Marshal]::IsComObject($Value)) {
        try { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($Value) } catch {}
    }
}
function Open-AnalysisOutlook {
    if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) { throw 'Echte Outlook-Analyse benötigt Windows.' }
    if ([Threading.Thread]::CurrentThread.ApartmentState -ne 'STA') { throw 'Bitte ANALYSE_STARTEN.cmd verwenden (Windows PowerShell 5.1, STA).' }
    $app=$null; $session=$null
    try {
        try { $app=[Runtime.InteropServices.Marshal]::GetActiveObject('Outlook.Application') }
        catch { $app=New-Object -ComObject Outlook.Application }
        $session=$app.GetNamespace('MAPI')
        return [pscustomobject]@{ Application=$app; Session=$session }
    } catch {
        Release-AnalysisCom $session; Release-AnalysisCom $app
        throw ('Klassisches Outlook mit eingerichtetem Profil wird benötigt. '+$_.Exception.Message)
    }
}
function Close-AnalysisOutlook {
    param([AllowNull()][object]$Connection)
    if ($null -ne $Connection) {
        Release-AnalysisCom $Connection.Session
        Release-AnalysisCom $Connection.Application
        # Deliberately no Outlook Quit or session Logoff.
    }
}
function Get-AnalysisStores {
    param([Parameter(Mandatory=$true)][object]$Session)
    $stores=$null
    try {
        $stores=$Session.Stores
        for ($i=1; $i -le $stores.Count; $i++) {
            $store=$null
            $info=[ordered]@{ Index=$i; Name=''; StoreId=''; IsCachedExchange='Unknown'; ExchangeStoreType='Unknown'; Status='Available'; Error='' }
            try {
                $store=$stores.Item($i); $info.Name=[string]$store.DisplayName; $info.StoreId=[string]$store.StoreID
                try { $info.IsCachedExchange=[string][bool]$store.IsCachedExchange } catch {}
                try { $info.ExchangeStoreType=[string][int]$store.ExchangeStoreType } catch {}
            } catch { $info.Status='Unavailable'; $info.Error=$_.Exception.Message; if (-not $info.Name) { $info.Name="Datenspeicher $i" } }
            finally { Release-AnalysisCom $store }
            [pscustomobject]$info
        }
    } finally { Release-AnalysisCom $stores }
}
function Test-AnalysisStop {
    param([object]$Context,[string]$RunPath,[int]$MaxMessages)
    if ($Context.CancelRequested -or $Context.LimitReached) { return $true }
    if ([IO.File]::Exists((Join-Path $RunPath 'STOP.request'))) { $Context.CancelRequested=$true; return $true }
    try {
        if ($Context.AllowConsoleCancel -and -not [Console]::IsInputRedirected -and [Console]::KeyAvailable) {
            $key=[Console]::ReadKey($true)
            if ($key.Key -eq [ConsoleKey]::Q) { $Context.CancelRequested=$true; return $true }
        }
    } catch {}
    if ($MaxMessages -gt 0 -and $Context.Total -ge $MaxMessages) { $Context.LimitReached=$true; return $true }
    return $false
}
function Read-AnalysisMail {
    param([object]$Session,[object]$FolderInfo,[string]$EntryId,[string]$MessageClass,[string]$Subject)
    $mail=$null
    $rec=[ordered]@{
        StoreName=$FolderInfo.StoreName; StoreId=$FolderInfo.StoreId
        FolderPath=$FolderInfo.FolderPath; FolderKind=$FolderInfo.FolderKind
        EntryId=$EntryId; MessageClass=$MessageClass; Subject=$Subject
        MessageDateUtc=''; Body=''; BodyStatus='ItemReadFailed'
        OutlookImportance=-1; UnreadBefore='Unknown'; UnreadAfter='Unknown'
        ReadStatus='Error'; Error=''; MetadataWarnings=''
    }
    $warnings=New-Object 'System.Collections.Generic.List[string]'
    try {
        $mail=$Session.GetItemFromID($EntryId,$FolderInfo.StoreId)
        if ([int]$mail.Class -ne 43) {
            $rec.BodyStatus='UnsupportedMailClass'; $rec.ReadStatus='Unsupported'
            return [pscustomobject]$rec
        }
        try { $rec.Subject=[string]$mail.Subject } catch { [void]$warnings.Add('SubjectReadFailed') }
        try { $rec.OutlookImportance=[int]$mail.Importance } catch { [void]$warnings.Add('ImportanceReadFailed') }
        try { $rec.UnreadBefore=[string][bool]$mail.UnRead } catch { [void]$warnings.Add('UnreadStateUnknown') }
        try {
            if ($FolderInfo.FolderKind -eq 'Sent') { $date=[datetime]$mail.SentOn }
            elseif ($FolderInfo.FolderKind -in @('Drafts','Outbox')) { $date=[datetime]$mail.CreationTime }
            else { $date=[datetime]$mail.ReceivedTime }
            if ($date.Year -ge 1900 -and $date.Year -lt 4500) { $rec.MessageDateUtc=$date.ToUniversalTime().ToString('o') }
        } catch { [void]$warnings.Add('MessageDateUnknown') }
        $download=-1
        try { $download=[int]$mail.DownloadState } catch { [void]$warnings.Add('DownloadStateUnknown') }
        if ($download -eq 0) {
            # olHeaderOnly. Do not change MarkForDownload or force synchronization.
            $rec.BodyStatus='HeaderOnly'; $rec.ReadStatus='Partial'
        } else {
            try {
                $rec.Body=[string]$mail.Body
                $rec.BodyStatus='Available'; $rec.ReadStatus='Read'
                if ([string]::IsNullOrWhiteSpace($rec.Body)) { $rec.BodyStatus='Empty' }
                elseif ($download -eq -1) { $rec.BodyStatus='AvailableDownloadStateUnknown' }
            } catch { $rec.BodyStatus='BodyReadFailed'; $rec.ReadStatus='Partial'; $rec.Error=$_.Exception.Message }
        }
        try { $rec.UnreadAfter=[string][bool]$mail.UnRead } catch {}
        if ($rec.UnreadBefore -ne 'Unknown' -and $rec.UnreadAfter -ne 'Unknown' -and $rec.UnreadBefore -ne $rec.UnreadAfter) {
            [void]$warnings.Add('UnreadChangedDuringRead')
        }
    } catch { $rec.Error=$_.Exception.Message }
    finally { Release-AnalysisCom $mail }
    $rec.MetadataWarnings=($warnings -join ' | ')
    return [pscustomobject]$rec
}

function Invoke-OutlookReadAnalysis {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][object]$Connection,
        [Parameter(Mandatory=$true)][object[]]$Stores,
        [Parameter(Mandatory=$true)][string]$RunPath,
        [Parameter(Mandatory=$true)][object]$Context,
        [Parameter(Mandatory=$true)][scriptblock]$OnMail,
        [Parameter(Mandatory=$true)][scriptblock]$OnFolder,
        [ValidateRange(0,2147483647)][int]$MaxMessages=0,
        [ValidateRange(0,1000)][int]$PauseMilliseconds=5
    )
    $session=$Connection.Session
    $seenFolders=New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::Ordinal)
    $seenItems=New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::Ordinal)
    $comStores=$null
    try {
        $comStores=$session.Stores
        foreach ($s in $Stores) {
            if (Test-AnalysisStop $Context $RunPath $MaxMessages) { break }
            $store=$null; $rootFolder=$null
            $sc=[pscustomobject][ordered]@{
                StoreName=$s.Name; StoreId=$s.StoreId; IsCachedExchange=$s.IsCachedExchange
                Status='Started'; FoldersEnumerated=0; Error=''
                DeletedFolderResolved=$false; ServerCompleteness='Unverified'
            }
            [void]$Context.StoreCoverage.Add($sc)
            $queue=New-Object 'System.Collections.Generic.Queue[object]'
            $defaultIds=@{}
            $searchIds=New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::Ordinal)
            try {
                # Reacquire by StoreID rather than trusting a potentially changed index.
                for ($si=1; $si -le $comStores.Count; $si++) {
                    $candidate=$comStores.Item($si)
                    if ([string]$candidate.StoreID -eq $s.StoreId) { $store=$candidate; break }
                    Release-AnalysisCom $candidate
                }
                if ($null -eq $store) { throw 'Ausgewählter Datenspeicher ist nicht mehr im Profil verfügbar.' }
                foreach ($pair in @(@(3,'Deleted'),@(5,'Sent'),@(16,'Drafts'),@(4,'Outbox'),@(23,'Junk'),@(6,'Inbox'))) {
                    $df=$null
                    try {
                        $df=$store.GetDefaultFolder([int]$pair[0])
                        if ($null -ne $df) {
                            $defaultIds[[string]$df.EntryID]=[string]$pair[1]
                            if ($pair[0] -eq 3) { $sc.DeletedFolderResolved=$true }
                        }
                    } catch {}
                    finally { Release-AnalysisCom $df }
                }
                $sfolders=$null
                try {
                    $sfolders=$store.GetSearchFolders()
                    for ($j=1; $j -le $sfolders.Count; $j++) {
                        $sf=$null
                        try { $sf=$sfolders.Item($j); [void]$searchIds.Add([string]$sf.EntryID) }
                        finally { Release-AnalysisCom $sf }
                    }
                } catch {} # PR_FOLDER_TYPE is an independent fallback below.
                finally { Release-AnalysisCom $sfolders }
                $rootFolder=$store.GetRootFolder()
                $queue.Enqueue([pscustomobject]@{ Id=[string]$rootFolder.EntryID; Path=[string]$rootFolder.FolderPath; Kind='Other'; Depth=0 })
                Release-AnalysisCom $rootFolder; $rootFolder=$null
                while ($queue.Count -gt 0) {
                    if (Test-AnalysisStop $Context $RunPath $MaxMessages) { break }
                    $node=$queue.Dequeue()
                    $fk=$s.StoreId+'|'+$node.Id
                    if (-not $seenFolders.Add($fk)) { continue }
                    $kind=$node.Kind
                    if ($defaultIds.ContainsKey($node.Id)) { $kind=$defaultIds[$node.Id] }
                    $finfo=[pscustomobject][ordered]@{
                        StoreName=$s.Name; StoreId=$s.StoreId; FolderPath=$node.Path; FolderKind=$kind
                        FolderId=$node.Id; Status='Started'; FolderType='Unknown'
                        ItemsAtStart=-1; ItemsAtEnd=-1; RowsVisited=0; MailRows=0; OtherRows=0; Duplicates=0
                        ContentGaps=0; Errors=0; ChildEnumerationComplete=$false; Error=''
                    }
                    $folder=$null; $table=$null; $children=$null; $columns=$null
                    try {
                        if ($node.Depth -gt 256) { throw 'Maximale Ordner-Tiefe überschritten; nicht still übersprungen.' }
                        $folder=$session.GetFolderFromID($node.Id,$s.StoreId)
                        $pa=$null
                        try { $pa=$folder.PropertyAccessor; $finfo.FolderType=[string][int]$pa.GetProperty('http://schemas.microsoft.com/mapi/proptag/0x36010003') }
                        catch {}
                        finally { Release-AnalysisCom $pa }
                        if ($searchIds.Contains($node.Id) -or $finfo.FolderType -eq '2') {
                            $finfo.Status='SkippedSearchFolder'; $finfo.ChildEnumerationComplete=$true
                        } else {
                            try {
                                $children=$folder.Folders
                                for ($j=1; $j -le $children.Count; $j++) {
                                    $child=$null
                                    try {
                                        $child=$children.Item($j)
                                        $queue.Enqueue([pscustomobject]@{ Id=[string]$child.EntryID; Path=[string]$child.FolderPath; Kind=$kind; Depth=($node.Depth+1) })
                                    } finally { Release-AnalysisCom $child }
                                }
                                $finfo.ChildEnumerationComplete=$true
                            } catch { $finfo.Errors++; $finfo.Error='Unterordner nicht vollständig auflistbar: '+$_.Exception.Message }
                            # olUserItems = 0: visible normal items, not hidden/recoverable/associated content.
                            $table=$folder.GetTable('',0)
                            $columns=$table.Columns
                            $columns.RemoveAll()
                            foreach ($c in @('EntryID','MessageClass','Subject')) {
                                $column=$null
                                try { $column=$columns.Add($c) } finally { Release-AnalysisCom $column }
                            }
                            try { $finfo.ItemsAtStart=[int]$table.GetRowCount() } catch {}
                            while (-not $table.EndOfTable) {
                                if (Test-AnalysisStop $Context $RunPath $MaxMessages) { break }
                                $row=$null
                                try {
                                    $row=$table.GetNextRow(); $finfo.RowsVisited++
                                    $id=[string]$row.Item('EntryID')
                                    $cls=[string]$row.Item('MessageClass')
                                    $subject=[string]$row.Item('Subject')
                                } finally { Release-AnalysisCom $row }
                                if ($cls -notmatch '^IPM\.Note(?:\.|$)') { $finfo.OtherRows++; continue }
                                if ([string]::IsNullOrWhiteSpace($id)) { $finfo.Errors++; continue }
                                $finfo.MailRows++
                                if (-not $seenItems.Add((Get-AnalysisSha256 ($s.StoreId+"`0"+$id)))) { $finfo.Duplicates++; continue }
                                $rec=Read-AnalysisMail -Session $session -FolderInfo $finfo -EntryId $id -MessageClass $cls -Subject $subject
                                if ($rec.ReadStatus -ne 'Read') { $finfo.ContentGaps++ }
                                # Callback failures (including disk full) must stop the entire scan, not become Outlook access errors.
                                try { & $OnMail $rec $Context }
                                catch { $Context.FatalOutputError=$_.Exception.Message; throw }
                                $rec=$null # Full body is not retained after classification.
                                if ($PauseMilliseconds -gt 0) { Start-Sleep -Milliseconds $PauseMilliseconds }
                                if (($Context.Total % 25) -eq 0) {
                                    Write-Progress -Activity 'Outlook-Prioritätsanalyse (nur lesend)' -Status ("{0} Mails | {1} | Q = Stop" -f $Context.Total,$node.Path)
                                }
                            }
                            try { $finfo.ItemsAtEnd=[int]$table.GetRowCount() } catch {}
                            if ($Context.CancelRequested -or $Context.LimitReached) { $finfo.Status='PartialStopped' }
                            elseif ($finfo.Errors -gt 0) { $finfo.Status='PartialErrors' }
                            else { $finfo.Status='VisibleEnumerationCompleted' }
                        }
                    } catch {
                        $finfo.Errors++
                        $finfo.Status='PartialErrors'
                        $finfo.Error=$_.Exception.Message
                        if ($Context.FatalOutputError) { throw }
                    } finally {
                        Release-AnalysisCom $columns; Release-AnalysisCom $table
                        Release-AnalysisCom $children; Release-AnalysisCom $folder
                        try { & $OnFolder $finfo $Context } catch { $Context.FatalOutputError=$_.Exception.Message; throw }
                        $sc.FoldersEnumerated++
                    }
                }
                if ($Context.CancelRequested -or $Context.LimitReached) { $sc.Status='PartialStopped' }
                else { $sc.Status='VisibleTraversalFinished' } # Folder-level errors stay in coverage.csv.
            } catch {
                $sc.Status='PartialErrors'; $sc.Error=$_.Exception.Message
                if ($Context.FatalOutputError) { throw }
            } finally { Release-AnalysisCom $rootFolder; Release-AnalysisCom $store }
        }
    } finally { Release-AnalysisCom $comStores; Write-Progress -Activity 'Outlook-Prioritätsanalyse (nur lesend)' -Completed }
}
Export-ModuleMember -Function Open-AnalysisOutlook,Close-AnalysisOutlook,Get-AnalysisStores,Invoke-OutlookReadAnalysis
