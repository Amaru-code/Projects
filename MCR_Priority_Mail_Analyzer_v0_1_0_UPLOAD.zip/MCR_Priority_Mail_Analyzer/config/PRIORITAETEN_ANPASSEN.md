﻿# Prioritäten später anpassen – ohne versteckte Änderungen

## 1. Was heute unverändert bleibt

Der bestehende Generator 1.1.0 bleibt vollständig separat. Seine Zuordnung
steht in `data/templates.json` unter `classes.high`, `classes.important`
und `classes.low`. Das sind **Sollklassen von Testvorlagen**, keine Keywords
eines Eingangsscanners.

Die neue `priority_rules.json` ist eine **vorläufige technische
Diagnose-Baseline**, keine freigegebene fachliche Policy. Sie wird beim
Analyselauf nur gelesen. Auch die Erweiterung ändert ihre eigene Konfiguration
nicht automatisch.

## 2. Die zentralen Stellen

| Wunsch | Datei und Feld/Funktion |
|---|---|
| Keywords ergänzen | `config/priority_rules.json → groups.<gruppe>.keywords` |
| Optionale Regex-Ausdrücke ergänzen | `groups.<gruppe>.patterns` |
| Zeitdruck stärker/schwächer gewichten | `groups.urgency.weight` |
| Auswirkung gewichten | `groups.impact.weight` |
| Handlungsauftrag gewichten | `groups.action.weight` |
| Planbare Frist/Klärung gewichten | `groups.planning.weight` |
| Urgent-Schwelle | `settings.urgentScoreThreshold` |
| Important-Schwelle | `settings.importantScoreThreshold` |
| Alte Antworttexte abtrennen | `settings.stripQuotedHistory` |
| Sehr lange Texte begrenzen | `settings.maxBodyCharacters` |
| Grundlegende Entscheidungslogik ändern | `lib/PriorityAnalysis.Core.psm1 → Get-MailPriorityAssessment` |
| Textaufbereitung verändern | `lib/PriorityAnalysis.Core.psm1 → Get-AnalysisText` |
| Neue datenabhängige Prüfhinweise | `lib/PriorityAnalysis.Report.psm1 → Get-AnalysisRecommendations` |

`priorityDefinitions` enthält erklärende Texte. **Nur diese Texte zu ändern,
ändert nicht die Entscheidung.** Für eine geänderte fachliche Semantik müssen
Keywords, Schwellen und gegebenenfalls die Entscheidungsfunktion dazu passen.

## 3. Die Regelgruppen

`urgency`: Zeitdruck.
`impact`: operative/fachliche Auswirkung.
`action`: Handlungsauftrag.
`planning`: planbare Aufgabe, Frist oder Klärung.
`information`: positive Hinweise auf reine Information.
`resolution`: Erledigung/Entwarnung.
`negation`: lokal zu entfernende verneinte Formulierungen.

Die ersten vier Gruppen tragen mit ihrem Gewicht zum Score bei.
Die letzten drei Gruppen sind Kontextsignale; deren Gewicht bleibt **0**.
Jede Gruppe zählt maximal einmal – zehnmal „dringend“ erhöht den Score nicht.

Die aktuelle Diagnoseentscheidung ist:
- `urgent`: urgency UND (action ODER impact) UND Score >= Urgent-Schwelle.
- `important`: Score >= Important-Schwelle und action/planning/impact.
- `low`: explizites Informations-/Erledigungssignal ohne positive Aufgabe,
  Planung, Auswirkung oder Dringlichkeit.
- andernfalls keine belastbare Zuordnung (`unclassified`).

Erledigung zusammen mit Ausfall-/Dringlichkeitssignal erzwingt derzeit eine
unklare Zuordnung zur Prüfung. Nicht lesbare Volltexte und Regex-Timeouts
werden nicht als sichere Klassifikation behandelt.

„Nicht dringend“ allein bedeutet ausdrücklich NICHT „unwichtig“.
Negationsphrasen werden nur an der gefundenen Textstelle entfernt, nicht
pauschal aus dem gesamten Textkontext. Vollständige sprachliche Negations-
und Verweisungserkennung wird damit nicht behauptet.

## 4. Keyword-Format

Die Einträge in `keywords` sind einfache Zeichenketten. Kein PowerShell-Code.
Sie werden ohne Beachtung der Großschreibung als ganze Wörter/Wortgruppen
gesucht. `urgent` soll beispielsweise nicht in `nonurgent` treffen.

Ein möglicher späterer fachlicher Begriff wäre `Produktionsstopp` in
`groups.impact.keywords`. Dieses Beispiel wurde **nicht eingetragen**.

Neue Wörter nicht allein aufgrund ihrer Häufigkeit übernehmen. Zuerst echte
manuelle Sollklassen prüfen: Ein Firmen-/Produktname kann häufig vorkommen,
ohne irgendetwas über Dringlichkeit auszusagen.

`patterns` akzeptiert .NET-RegEx. Die Ausdrücke werden validiert und besitzen
ein Zeitlimit. Defekte Regeln stoppen vor dem Outlook-Zugriff. Für einfache
Begriffe `keywords` statt regulärer Ausdrücke verwenden.

## 5. Kontrollierte spätere Variante

1. `priority_rules.json` nach `priority_rules.custom.json` kopieren.
2. Nur die Kopie bearbeiten; `ruleSetId` sinnvoll ändern.
3. Den Lauf mit `-RulesPath ".\config\priority_rules.custom.json"` starten.
4. Nicht dieselben Mailtexte sowohl zur Anpassung als auch zum unabhängigen
   Nachweis besserer Ergebnisse verwenden.
5. `rules.snapshot.json` und `RulesSha256` der Ergebnisse vergleichen.

Der automatische Selbsttest prüft weiterhin die mitgelieferte Baseline und
die Engine. Eine eigene Variante braucht zusätzliche fachliche Testfälle.
Eine valide JSON-Datei oder ein technisch bestandener Test bedeutet nicht,
dass neue Business-Regeln fachlich richtig sind.

Kein Ergebnis dieses Tools promotet eine Variante automatisch.
