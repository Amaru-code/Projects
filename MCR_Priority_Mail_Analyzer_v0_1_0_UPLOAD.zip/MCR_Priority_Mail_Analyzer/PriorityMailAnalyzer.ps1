﻿#requires -Version 5.1
<#
MCR Priority Mail Analyzer 0.1.0
Local, read-only Outlook diagnostic. No connection to the generator's send path.
Use ANALYSE_STARTEN.cmd. Rule configuration is never modified by this tool.
#>
[CmdletBinding()]
param(
    [switch]$AllStores,
    [int[]]$StoreIndices=@(),
    [ValidateRange(0,2147483647)][int]$MaxMessages=0,
    [ValidateRange(0,1000)][int]$PauseMilliseconds=5,
    [string]$RulesPath='',
    [string]$OutputRoot='',
    [switch]$NoPrompt,
    [switch]$NoPopup,
    [switch]$SelfTest,
    [switch]$Demo
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
if ($SelfTest) {
    & (Join-Path $PSScriptRoot 'tests/Run-Tests.ps1')
    exit 0
}
Import-Module (Join-Path $PSScriptRoot 'lib/PriorityAnalysis.Core.psm1') -ErrorAction Stop
Import-Module (Join-Path $PSScriptRoot 'lib/PriorityAnalysis.Report.psm1') -ErrorAction Stop
Import-Module (Join-Path $PSScriptRoot 'lib/PriorityAnalysis.Outlook.psm1') -ErrorAction Stop
if (-not $RulesPath) { $RulesPath=Join-Path $PSScriptRoot 'config/priority_rules.json' }
$rules=Read-AnalysisRules -Path $RulesPath
# Local synthetic qualification before accessing any real message.
$offlineCheck=& (Join-Path $PSScriptRoot 'tests/Run-Tests.ps1') -Quiet -PassThru
if (-not $OutputRoot) {
    $local=[Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)
    if (-not $local) { $local=Join-Path $PSScriptRoot 'Output' }
    $OutputRoot=Join-Path $local 'MCR/PriorityAnalyzer/Runs'
}
$connection=$null; $ctx=$null; $runPath=''; $fatal=''; $summary=$null; $exitCode=0
try {
    Write-Host ''
    Write-Host '============================================================'
    Write-Host ' MCR Outlook-Prioritaetsanalyse 0.1.0 -- NUR LESEND'
    Write-Host '============================================================'
    Write-Host 'Keine E-Mails senden, verschieben, loeschen oder bearbeiten.'
    Write-Host 'Keine KI-API. Volltexte nur im Arbeitsspeicher; keine Anhaenge.'
    Write-Host 'Einstufungen sind Diagnose-VORSCHLAEGE, keine Sollklassen.'
    Write-Host ''
    $selected=@()
    if ($Demo) {
        $selected=@([pscustomobject]@{Index=1; Name='SYNTHETISCHE DEMO'; StoreId='DEMO'; IsCachedExchange='False'; ExchangeStoreType='Demo'; Status='Available'; Error=''})
    } else {
        if ($NoPrompt -and -not $AllStores -and $StoreIndices.Count -eq 0) {
            throw '-NoPrompt erfordert ausdruecklich -AllStores oder -StoreIndices.'
        }
        $connection=Open-AnalysisOutlook
        $available=@(Get-AnalysisStores -Session $connection.Session)
        if ($available.Count -eq 0) { throw 'Im aktuellen Outlook-Profil wurden keine Datenspeicher gefunden.' }
        Write-Host 'Im aktuellen Outlook-Profil sichtbare Datenspeicher:'
        foreach ($s in $available) {
            Write-Host ('[{0}] {1} | Cache={2} | {3}' -f $s.Index,$s.Name,$s.IsCachedExchange,$s.Status)
        }
        if ($AllStores -and $StoreIndices.Count -gt 0) { throw '-AllStores und -StoreIndices nicht gleichzeitig verwenden.' }
        if (-not $AllStores -and $StoreIndices.Count -eq 0) {
            $selection=Read-Host 'ALLE fuer alle Speicher, oder Nummern mit Komma (z.B. 1,2)'
            if ($selection.Trim() -ieq 'ALLE') { $AllStores=$true }
            else {
                if ($selection -notmatch '^\s*\d+(?:\s*,\s*\d+)*\s*$') { throw 'Keine gueltige Auswahl. Es wurden keine Mailtexte gelesen.' }
                $StoreIndices=@($selection -split ',' | ForEach-Object { [int]$_.Trim() } | Select-Object -Unique)
            }
        }
        if ($AllStores) { $selected=$available }
        else {
            foreach ($i in $StoreIndices) { if ($i -notin $available.Index) { throw "Unbekannter Datenspeicher-Index: $i" } }
            $selected=@($available | Where-Object { $_.Index -in $StoreIndices })
        }
        Write-Host ''
        Write-Host 'Umfang: alle zugreifbaren Unterordner, inkl. Geloeschte Elemente,'
        Write-Host 'Gesendet, Entwuerfe, Junk sowie eingebundene Archive. Kein Datumsfilter.'
        Write-Host 'NICHT enthalten: versteckte Recoverable Items, endgueltig entfernte'
        Write-Host 'Mails, Anhaenge oder nicht eingebundene/unberechtigte Postfaecher.'
        Write-Host 'Cache und Zugriffsrechte koennen die Abdeckung begrenzen.'
        Write-Host 'Outlook muss fuer die gesamte Laufzeit geoeffnet bleiben.'
        Write-Host 'Bitte waehrenddessen keine Mails/Ordner umorganisieren.'
        if ($MaxMessages -gt 0) { Write-Host "BEGRENZTER Testlauf: hoechstens $MaxMessages Mailinstanzen. Keine Vollanalyse." }
        Write-Host ('Lokale vertrauliche Ergebnisdateien unter: '+[IO.Path]::GetFullPath($OutputRoot))
        if (-not $NoPrompt) {
            $ok=Read-Host 'Nur fuer berechtigte Analyse verwenden. Zum Start ANALYSIEREN eingeben'
            if ($ok.Trim() -cne 'ANALYSIEREN') { Write-Host 'Abgebrochen. Keine Mailtexte gelesen.'; return }
        }
    }
    $runId=[DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffZ')+'-'+[guid]::NewGuid().ToString('N').Substring(0,8)
    $runPath=Join-Path ([IO.Path]::GetFullPath($OutputRoot)) $runId
    if ([IO.Directory]::Exists($runPath)) { throw 'Laufordner existiert bereits; kein Ueberschreiben.' }
    [void][IO.Directory]::CreateDirectory($runPath)
    $snapshot=Join-Path $runPath 'rules.snapshot.json'
    [IO.File]::WriteAllText($snapshot,$rules.RawText,[Text.UTF8Encoding]::new($false))
    [IO.File]::WriteAllText((Join-Path $runPath 'rules.snapshot.sha256'),$rules.Sha256+"  rules.snapshot.json`r`n",[Text.UTF8Encoding]::new($false))
    Write-AnalysisJson (Join-Path $runPath 'run_state.json') ([pscustomobject]@{RunId=$runId; Status='RUNNING'; RulesSha256=$rules.Sha256; Meaning='Ohne finalen Status ist der Lauf unvollstaendig.'})
    Write-AnalysisJson (Join-Path $runPath 'selection_PRIVATE.json') $selected
    Write-AnalysisJson (Join-Path $runPath 'preflight_tests.json') $offlineCheck
    $stopCmd="@echo off`r`ntype nul > `"%~dp0STOP.request`"`r`necho Stop angefordert. Der aktuelle Outlook-Leseaufruf darf fertig werden.`r`n"
    [IO.File]::WriteAllText((Join-Path $runPath 'STOPPEN.cmd'),$stopCmd,[Text.Encoding]::ASCII)
    $ctx=New-AnalysisContext -RunPath $runPath -RunId $runId -Rules $rules -SelectedStores $selected
    $ctx.AllowConsoleCancel=(-not $NoPrompt -and -not $Demo)
    Write-Host ''
    Write-Host "Ergebnisordner: $runPath"
    Write-Host 'Kontrollierter Abbruch: Taste Q im Konsolenfenster oder STOPPEN.cmd im Laufordner.'
    Write-Host 'Ein blockierter COM-Aufruf kann erst nach seiner Rueckkehr abbrechen.'
    Write-Host ''
    if ($Demo) {
        $fixtures=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'tests/cases.json') -Raw -Encoding UTF8 | ConvertFrom-Json
        $i=0
        foreach ($case in $fixtures) {
            $i++
            $record=[pscustomobject]@{
                StoreName='SYNTHETISCHE DEMO'; StoreId='DEMO'; EntryId=[string]$i
                FolderPath='\Demo\Inbox'; FolderKind='Inbox'; Subject=$case.subject; Body=$case.body
                MessageDateUtc=[DateTime]::UtcNow.ToString('o'); BodyStatus=$case.bodyStatus
                OutlookImportance=$case.importance; ReadStatus='Read'; Error=''; MetadataWarnings=''
                UnreadBefore='True'; UnreadAfter='True'
            }
            Add-AnalysisRecord $record $ctx
        }
        [void]$ctx.StoreCoverage.Add([pscustomobject]@{StoreName='SYNTHETISCHE DEMO';StoreId='DEMO';IsCachedExchange='False';Status='DEMO';FoldersEnumerated=0;Error='';DeletedFolderResolved=$false;ServerCompleteness='NotApplicable'})
        $ctx.Status='DEMO_COMPLETED_NO_REAL_MAIL'
    } else {
        $onMail={ param($record,$context) Add-AnalysisRecord -Record $record -Context $context }
        $onFolder={ param($folder,$context) Add-AnalysisFolder -Folder $folder -Context $context }
        Invoke-OutlookReadAnalysis -Connection $connection -Stores $selected -RunPath $runPath -Context $ctx `
            -OnMail $onMail -OnFolder $onFolder -MaxMessages $MaxMessages -PauseMilliseconds $PauseMilliseconds
        if ($ctx.CancelRequested) { $ctx.Status='CANCELLED_PARTIAL'; $exitCode=2 }
        elseif ($ctx.LimitReached) { $ctx.Status='LIMITED_NOT_A_FULL_SCAN'; $exitCode=2 }
        elseif ($ctx.FolderErrors -gt 0 -or $ctx.ReadGaps -gt 0 -or @($ctx.StoreCoverage | Where-Object {$_.Status -eq 'PartialErrors'}).Count -gt 0) {
            $ctx.Status='COMPLETED_WITH_DECLARED_GAPS'; $exitCode=2
        } else { $ctx.Status='VISIBLE_SCAN_COMPLETED_SERVER_COVERAGE_UNVERIFIED' }
    }
} catch {
    $fatal=$_.Exception.Message; $exitCode=1
    if ($null -ne $ctx) { $ctx.Status='FAILED_PARTIAL' }
    Write-Warning ('Analyse nicht vollstaendig abgeschlossen: '+$fatal)
} finally {
    Close-AnalysisOutlook $connection
    if ($null -ne $ctx) {
        # A hard process kill cannot guarantee this finalization; run_state.json remains RUNNING.
        if ($ctx.Status -eq 'RUNNING') { $ctx.Status='INTERRUPTED_PARTIAL'; $exitCode=2 }
        try {
            $summary=Complete-AnalysisReport $ctx
            Write-AnalysisJson (Join-Path $runPath 'run_state.json') ([pscustomobject]@{RunId=$ctx.RunId;Status=$ctx.Status;RulesSha256=$rules.Sha256;CompletedUtc=[DateTime]::UtcNow.ToString('o');Error=$fatal})
        } catch {
            $exitCode=1; $fatal='Abschlussbericht konnte nicht vollstaendig geschrieben werden: '+$_.Exception.Message
            Write-Warning $fatal
            foreach ($writerName in @('Csv','FolderCsv')) {
                if ($null -ne $ctx.$writerName) { try {$ctx.$writerName.Writer.Dispose()} catch {} }
            }
            if ($null -ne $ctx.IndexWriter) { try {$ctx.IndexWriter.Dispose()} catch {} }
            try { Write-AnalysisJson (Join-Path $runPath 'run_state.json') ([pscustomobject]@{RunId=$ctx.RunId;Status='REPORT_FAILED_PARTIAL';Error=$fatal}) } catch {}
        }
    }
}
if ($null -ne $summary) {
    $c=$summary.RealMailProposals
    $text=@"
Status: $($summary.Status)

Verarbeitete Mailinstanzen: $($summary.TotalMailInstances)

Vorschläge für echte Mails:
  $($c.urgent) urgent
  $($c.important) important
  $($c.low) unwichtig
  $($c.unclassified) unklar / fachlich prüfen

Synthetische Testmails werden separat gezählt.
Leselücken: $($summary.ReadGaps)
Ordner mit Fehlern/Lücken: $($summary.FolderErrors)

Keine bestätigten Sollklassen. Keine Regeländerungen.
Serverweite Vollständigkeit bleibt ungeprüft.

Bericht: $runPath\BERICHT.html
"@
    if ($Demo) { $text="SYNTHETISCHE DEMO – keine echten Mails gelesen.`r`n`r`n"+$text }
    Write-Host $text
    if (-not $NoPopup -and [Environment]::OSVersion.Platform -eq [PlatformID]::Win32NT) {
        try {
            Add-Type -AssemblyName System.Windows.Forms
            [void][Windows.Forms.MessageBox]::Show($text,'MCR – Ergebnis der Prioritätsanalyse','OK','Information')
        } catch { Write-Warning 'Popup nicht verfuegbar; Ergebnis steht in der Konsole.' }
    }
}
if ($fatal) { Write-Host $fatal }
exit $exitCode
