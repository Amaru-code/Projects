﻿# Synthetic Outlook object graph. No COM instance, network, real mailbox or credentials.
Set-StrictMode -Version Latest
function New-MockCollection {
    param([object[]]$Values=@())
    $o=[pscustomobject]@{Values=$Values;Count=$Values.Count}
    Add-Member -InputObject $o -MemberType ScriptMethod -Name Item -Value {
        param($Index)
        if ($Index -lt 1 -or $Index -gt $this.Count) { throw 'Invalid collection index' }
        return $this.Values[$Index-1]
    }
    return $o
}
function New-MockRow {
    param([string]$Id,[string]$Subject,[string]$MessageClass='IPM.Note')
    $o=[pscustomobject]@{Values=@{EntryID=$Id;Subject=$Subject;MessageClass=$MessageClass}}
    Add-Member -InputObject $o -MemberType ScriptMethod -Name Item -Value {param($Name) return $this.Values[$Name]}
    return $o
}
function New-MockTable {
    param([object[]]$Rows=@())
    $cols=[pscustomobject]@{Marker='InMemoryColumns'}
    Add-Member -InputObject $cols -MemberType ScriptMethod -Name RemoveAll -Value {}
    Add-Member -InputObject $cols -MemberType ScriptMethod -Name Add -Value {param($Name) return [pscustomobject]@{Name=$Name}}
    $t=[pscustomobject]@{Rows=$Rows;Position=0;Columns=$cols}
    Add-Member -InputObject $t -MemberType ScriptProperty -Name EndOfTable -Value {return ($this.Position -ge $this.Rows.Count)}
    Add-Member -InputObject $t -MemberType ScriptMethod -Name GetRowCount -Value {return $this.Rows.Count}
    Add-Member -InputObject $t -MemberType ScriptMethod -Name GetNextRow -Value {
        if ($this.EndOfTable) {throw 'End of mock table'}
        $r=$this.Rows[$this.Position];$this.Position++
        return $r
    }
    return $t
}
function New-MockFolder {
    param([string]$Id,[string]$Path,[object[]]$Rows=@(),[int]$Type=1)
    $pa=[pscustomobject]@{Type=$Type}
    Add-Member -InputObject $pa -MemberType ScriptMethod -Name GetProperty -Value {param($Name) return $this.Type}
    $o=[pscustomobject]@{
        EntryID=$Id; FolderPath=$Path; PropertyAccessor=$pa
        Folders=(New-MockCollection); Table=(New-MockTable -Rows $Rows); Denied=$false
    }
    Add-Member -InputObject $o -MemberType ScriptMethod -Name GetTable -Value {
        param($Filter,$Contents)
        if ($this.Denied) {throw 'MOCK_ACCESS_DENIED'}
        return $this.Table
    }
    return $o
}
function New-MockMail {
    param([string]$Subject,[string]$Body,[int]$DownloadState=1,[bool]$BodyDenied=$false)
    $o=[pscustomobject]@{
        Class=43; Subject=$Subject; RawBody=$Body; Importance=1; DownloadState=$DownloadState; BodyDenied=$BodyDenied
        ReceivedTime=[datetime]'2026-10-06T12:00:00';SentOn=[datetime]'2026-10-06T12:00:00';CreationTime=[datetime]'2026-10-06T12:00:00'
    }
    Add-Member -InputObject $o -MemberType ScriptProperty -Name Body -Value {
        if ($this.BodyDenied) {throw 'MOCK_PROTECTED_BODY'}
        return $this.RawBody
    } -SecondValue {throw 'FORBIDDEN_MAIL_WRITE'}
    Add-Member -InputObject $o -MemberType ScriptProperty -Name UnRead -Value {return $true} -SecondValue {throw 'FORBIDDEN_UNREAD_WRITE'}
    foreach ($name in @('Send','Save','Move','Delete','Display','Reply','Forward')) {
        Add-Member -InputObject $o -MemberType ScriptMethod -Name $name -Value {throw 'FORBIDDEN_MAIL_METHOD'}
    }
    return $o
}
function New-MockStore {
    param([string]$Id,[string]$Name,[object]$Root,[hashtable]$Defaults,[object[]]$SearchFolders=@())
    $o=[pscustomobject]@{
        StoreID=$Id;DisplayName=$Name;IsCachedExchange=$true;ExchangeStoreType=0
        Root=$Root;Defaults=$Defaults;SearchFolders=(New-MockCollection -Values $SearchFolders)
    }
    Add-Member -InputObject $o -MemberType ScriptMethod -Name GetRootFolder -Value {return $this.Root}
    Add-Member -InputObject $o -MemberType ScriptMethod -Name GetDefaultFolder -Value {param($Type) if ($this.Defaults.ContainsKey([int]$Type)) {return $this.Defaults[[int]$Type]} return $null}
    Add-Member -InputObject $o -MemberType ScriptMethod -Name GetSearchFolders -Value {return $this.SearchFolders}
    return $o
}
function New-MockOutlook {
    $r1=New-MockFolder 'R1' '\Mock1'
    $inbox=New-MockFolder 'I1' '\Mock1\Inbox' -Rows @((New-MockRow 'M1' 'Störung'))
    $deleted=New-MockFolder 'D1' '\Mock1\Deleted' -Rows @((New-MockRow 'M2' 'Info'))
    $nested=New-MockFolder 'D2' '\Mock1\Deleted\Nested' -Rows @((New-MockRow 'M3' 'Prüfung'))
    $deleted.Folders=New-MockCollection -Values @($nested)
    $header=New-MockFolder 'H1' '\Mock1\Headers' -Rows @((New-MockRow 'M4' 'Dringend'))
    $protected=New-MockFolder 'P1' '\Mock1\Protected' -Rows @((New-MockRow 'M5' 'Störung'))
    $duplicate=New-MockFolder 'U1' '\Mock1\Duplicate' -Rows @((New-MockRow 'M1' 'Störung'))
    $search=New-MockFolder 'S1' '\Mock1\Search' -Rows @((New-MockRow 'M1' 'Störung')) -Type 2
    $calendar=New-MockFolder 'C1' '\Mock1\Calendar' -Rows @((New-MockRow 'A1' 'Appointment' 'IPM.Appointment'))
    $denied=New-MockFolder 'E1' '\Mock1\Denied'; $denied.Denied=$true
    $r1.Folders=New-MockCollection -Values @($inbox,$deleted,$header,$protected,$duplicate,$search,$calendar,$denied)
    $r2=New-MockFolder 'R2' '\Mock2'
    $inbox2=New-MockFolder 'I2' '\Mock2\Inbox' -Rows @((New-MockRow 'M1' 'FYI'))
    $r2.Folders=New-MockCollection -Values @($inbox2)
    $store1=New-MockStore 'STORE1' 'Mock 1' $r1 @{3=$deleted;6=$inbox} @($search)
    $store2=New-MockStore 'STORE2' 'Mock 2' $r2 @{6=$inbox2}
    $folders=@{}
    foreach ($f in @($r1,$inbox,$deleted,$nested,$header,$protected,$duplicate,$search,$calendar,$denied)) {$folders['STORE1|'+$f.EntryID]=$f}
    foreach ($f in @($r2,$inbox2)) {$folders['STORE2|'+$f.EntryID]=$f}
    $mails=@{
        'STORE1|M1'=(New-MockMail 'Störung' 'Bitte prüfe sofort.')
        'STORE1|M2'=(New-MockMail 'Info' 'FYI optional.')
        'STORE1|M3'=(New-MockMail 'Prüfung' 'Bitte prüfe den Entwurf.')
        'STORE1|M4'=(New-MockMail 'Dringend' '' -DownloadState 0)
        'STORE1|M5'=(New-MockMail 'Störung' '' -BodyDenied $true)
        'STORE2|M1'=(New-MockMail 'FYI' 'Zur Information.')
    }
    $session=[pscustomobject]@{Stores=(New-MockCollection -Values @($store1,$store2));FolderMap=$folders;MailMap=$mails}
    Add-Member -InputObject $session -MemberType ScriptMethod -Name GetFolderFromID -Value {
        param($Id,$StoreId)
        $key=$StoreId+'|'+$Id
        if (-not $this.FolderMap.ContainsKey($key)) {throw 'MOCK_MISSING_FOLDER'}
        return $this.FolderMap[$key]
    }
    Add-Member -InputObject $session -MemberType ScriptMethod -Name GetItemFromID -Value {
        param($Id,$StoreId)
        $key=$StoreId+'|'+$Id
        if ($key -eq 'STORE1|M5') {throw 'MOCK_ITEM_ACCESS_DENIED'}
        if (-not $this.MailMap.ContainsKey($key)) {throw 'MOCK_MISSING_ITEM'}
        return $this.MailMap[$key]
    }
    return [pscustomobject]@{Application=$null;Session=$session}
}
