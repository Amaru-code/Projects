﻿#requires -Version 5.1
[CmdletBinding()]
param([switch]$Quiet,[switch]$PassThru)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$base=Split-Path $PSScriptRoot -Parent
Import-Module (Join-Path $base 'lib/PriorityAnalysis.Core.psm1') -ErrorAction Stop
Import-Module (Join-Path $base 'lib/PriorityAnalysis.Report.psm1') -ErrorAction Stop
Import-Module (Join-Path $base 'lib/PriorityAnalysis.Outlook.psm1') -ErrorAction Stop
$script:passed=0; $script:failed=0
$script:results=New-Object 'System.Collections.Generic.List[object]'
function Assert-True { param([bool]$Value,[string]$Message='Assertion fehlgeschlagen') if (-not $Value) { throw $Message } }
function Test-Case {
    param([string]$Name,[scriptblock]$Block)
    try {
        & $Block
        $script:passed++
        [void]$script:results.Add([pscustomobject]@{Name=$Name;Status='PASS';Error=''})
        if (-not $Quiet) { Write-Host ('PASS '+$Name) }
    } catch {
        $script:failed++
        [void]$script:results.Add([pscustomobject]@{Name=$Name;Status='FAIL';Error=$_.Exception.Message})
        Write-Host ('FAIL '+$Name+' -- '+$_.Exception.Message)
    }
}
$temp=Join-Path ([IO.Path]::GetTempPath()) ('MCR_AnalysisTests_'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($temp)
$rulePath=Join-Path $base 'config/priority_rules.json'
$sourceHash=(Get-FileHash -LiteralPath $rulePath -Algorithm SHA256).Hash
try {
    foreach ($file in @(Get-ChildItem -LiteralPath $base -Recurse -File | Where-Object {$_.Extension -in @('.ps1','.psm1')})) {
        Test-Case ('Parse '+$file.Name) {
            $tokens=$null; $errors=$null
            $null=[Management.Automation.Language.Parser]::ParseFile($file.FullName,[ref]$tokens,[ref]$errors)
            Assert-True ($errors.Count -eq 0) (($errors | ForEach-Object {$_.Message}) -join '; ')
        }
    }
    $rules=Read-AnalysisRules $rulePath
    $fixtures=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'cases.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    foreach ($case in $fixtures) {
        Test-Case ('Classification '+$case.name) {
            $a=Get-MailPriorityAssessment -Subject $case.subject -Body $case.body -Rules $rules `
                -BodyStatus $case.bodyStatus -OutlookImportance $case.importance `
                -MessageDateUtc '2026-10-06T12:00:00Z' -ReferenceUtc ([datetime]'2026-10-06T14:00:00Z')
            Assert-True ($a.ProposedPriority -eq $case.expected) ('Erwartet '+$case.expected+', erhalten '+$a.ProposedPriority)
            foreach ($f in $case.expectedFlags) { Assert-True ($a.ReviewFlags -match [regex]::Escape($f)) ('Flag fehlt: '+$f) }
        }
    }
    Test-Case 'Historical date does not redefine priority' {
        $a=Get-MailPriorityAssessment -Subject 'Störung' -Body 'Bitte prüfe sofort.' -Rules $rules -MessageDateUtc '2010-01-01T00:00:00Z'
        Assert-True ($a.ProposedPriority -eq 'urgent')
        Assert-True ($a.ReviewFlags -match 'HistoricalMessage')
    }
    Test-Case 'Repeated keywords do not multiply group weights' {
        $a=Get-MailPriorityAssessment -Body 'Bitte prüfe dringend.' -Rules $rules
        $b=Get-MailPriorityAssessment -Body ('Bitte prüfe dringend. '*100) -Rules $rules
        Assert-True ($a.Score -eq $b.Score)
    }
    Test-Case 'Long text truncation is disclosed' {
        $a=Get-MailPriorityAssessment -Body ('FYI '+('x'*100100)) -Rules $rules
        Assert-True ($a.ReviewFlags -match 'BodyTruncated')
        Assert-True ($a.NeedsReview)
    }
    Test-Case 'Synthetic mail flag independent of priority' {
        $a=Get-MailPriorityAssessment -Subject '[PRIO-TEST DEMO-00001] FYI' -Body 'Zur Information.' -Rules $rules
        Assert-True $a.SyntheticTest
        Assert-True ($a.ProposedPriority -eq 'low')
    }
    Test-Case 'Store-scoped identity' {
        Assert-True ((Get-AnalysisSha256 "STORE1`0MAIL") -ne (Get-AnalysisSha256 "STORE2`0MAIL"))
    }
    foreach ($value in @('=2+2','+cmd','-1+1','@SUM(1)'," `t=2+2")) {
        Test-Case ('CSV guard '+$value) {
            $cell=ConvertTo-AnalysisCsvCell $value
            Assert-True ($cell.StartsWith('"'''))
        }
    }
    Test-Case 'CSV quote and newline protection' {
        Assert-True ((ConvertTo-AnalysisCsvCell "a;`"b`"`nc") -eq '"a;""b"" c"')
    }
    Test-Case 'Invalid regex rejected before Outlook' {
        $r=Get-Content -LiteralPath $rulePath -Raw -Encoding UTF8 | ConvertFrom-Json
        $r.groups.impact.patterns=@('[')
        $p=Join-Path $temp 'invalid.json'
        Write-AnalysisJson $p $r
        $thrown=$false
        try { $null=Read-AnalysisRules $p } catch { $thrown=$true }
        Assert-True $thrown
    }
    Test-Case 'Empty keyword rejected' {
        $r=Get-Content -LiteralPath $rulePath -Raw -Encoding UTF8 | ConvertFrom-Json
        $r.groups.action.keywords=@('')
        $p=Join-Path $temp 'empty.json'
        Write-AnalysisJson $p $r
        $thrown=$false
        try { $null=Read-AnalysisRules $p } catch { $thrown=$true }
        Assert-True $thrown
    }
    Test-Case 'Context group weights cannot be silently ignored' {
        $r=Get-Content -LiteralPath $rulePath -Raw -Encoding UTF8 | ConvertFrom-Json
        $r.groups.negation.weight=3
        $p=Join-Path $temp 'invalid-weight.json'
        Write-AnalysisJson $p $r
        $thrown=$false
        try { $null=Read-AnalysisRules $p } catch { $thrown=$true }
        Assert-True $thrown
    }
    Test-Case 'Read-only adapter static denylist' {
        $code=Get-Content -LiteralPath (Join-Path $base 'lib/PriorityAnalysis.Outlook.psm1') -Raw -Encoding UTF8
        Assert-True (-not [regex]::IsMatch($code,'(?im)\.(?:Send|Save|Move|Delete|Display|Forward|Reply|Quit|Logoff)\s*\('))
        Assert-True (-not [regex]::IsMatch($code,'(?im)\$mail\.\w+\s*='))
        Assert-True (-not [regex]::IsMatch($code,'(?i)\b(?:Invoke-WebRequest|Invoke-RestMethod|Set-ExecutionPolicy)\b'))
    }
    Test-Case 'Report integration: counts, CSV roundtrip, HTML and no body export' {
        $d=Join-Path $temp 'report'
        [void][IO.Directory]::CreateDirectory($d)
        $ss=@([pscustomobject]@{Name='DEMO';StoreId='DEMO';IsCachedExchange='False'})
        $ctx=New-AnalysisContext -RunPath $d -RunId 'TEST' -Rules $rules -SelectedStores $ss
        $rec=[pscustomobject]@{
            StoreName='DEMO'; StoreId='DEMO'; EntryId='1'; FolderPath='\DEMO\Deleted'; FolderKind='Deleted'
            Subject='Info; "A"'; Body='FYI BODY_SENTINEL_MUST_NOT_BE_EXPORTED'; BodyStatus='Available'
            MessageDateUtc='2026-10-06T12:00:00Z'; OutlookImportance=1; ReadStatus='Read'; Error=''
            MetadataWarnings=''; UnreadBefore='True'; UnreadAfter='True'
        }
        Add-AnalysisRecord $rec $ctx
        $rec.EntryId='2'; $rec.Subject='[PRIO-TEST DEMO] Information'
        Add-AnalysisRecord $rec $ctx
        $ctx.Status='TEST_COMPLETED'
        $s=Complete-AnalysisReport $ctx
        Assert-True ($s.TotalMailInstances -eq 2)
        Assert-True ($s.RealMailProposals.low -eq 1 -and $s.SyntheticTestProposals.low -eq 1)
        $rows=@(Import-Csv -LiteralPath (Join-Path $d 'mail_analysis.csv') -Delimiter ';' -Encoding UTF8)
        Assert-True ($rows.Count -eq 2)
        Assert-True ($rows[0].Subject -eq 'Info; "A"')
        Assert-True ([IO.File]::Exists((Join-Path $d 'BERICHT.html')))
        foreach ($f in @(Get-ChildItem -LiteralPath $d -File)) {
            Assert-True (-not ([IO.File]::ReadAllText($f.FullName).Contains('BODY_SENTINEL_MUST_NOT_BE_EXPORTED'))) ('Volltext exportiert: '+$f.Name)
        }
        $safe=Get-Content -LiteralPath (Join-Path $d 'summary_shareable.json') -Raw -Encoding UTF8
        Assert-True (-not $safe.Contains('Info;'))
        Assert-True (-not $safe.Contains('\DEMO\Deleted'))
        $blind=@(Import-Csv -LiteralPath (Join-Path $d 'review_blind.csv') -Delimiter ';' -Encoding UTF8)
        Assert-True ($blind.Count -eq 1)
        Assert-True ($null -eq $blind[0].PSObject.Properties['ProposedPriority'])
    }
    # Adapter tests use synthetic in-memory objects, never a live Outlook connection.
    . (Join-Path $PSScriptRoot 'Mock-Outlook.ps1')
    Test-Case 'Mock Outlook: all stores, deleted subtree, search dedup, nonmail and access gaps' {
        $d=Join-Path $temp 'adapter'; [void][IO.Directory]::CreateDirectory($d)
        $fake=New-MockOutlook
        $stores=@(Get-AnalysisStores $fake.Session)
        $ctx=New-AnalysisContext $d 'MOCK' $rules $stores
        Invoke-OutlookReadAnalysis -Connection $fake -Stores $stores -RunPath $d -Context $ctx `
            -OnMail {param($r,$c) Add-AnalysisRecord $r $c} `
            -OnFolder {param($f,$c) Add-AnalysisFolder $f $c} -PauseMilliseconds 0
        $ctx.Status='MOCK_COMPLETED'
        $s=Complete-AnalysisReport $ctx
        Assert-True ($s.TotalMailInstances -eq 6) ('Mailanzahl '+$s.TotalMailInstances)
        Assert-True ($s.StartedStores -eq 2)
        Assert-True ($s.FolderKindCounts.Deleted -eq 2)
        Assert-True ($s.SkippedSearchFolders -eq 1)
        Assert-True ($s.DuplicateStoreEntryIdsSkipped -eq 1)
        Assert-True ($s.OtherItemsNotAnalyzed -eq 1)
        Assert-True ($s.ReadGaps -eq 2)
        Assert-True ($s.FolderErrors -eq 1)
    }
    Test-Case 'Mock Outlook: bounded run is partial, not full' {
        $d=Join-Path $temp 'limited'; [void][IO.Directory]::CreateDirectory($d)
        $fake=New-MockOutlook; $stores=@(Get-AnalysisStores $fake.Session)
        $ctx=New-AnalysisContext $d 'LIMIT' $rules $stores
        Invoke-OutlookReadAnalysis -Connection $fake -Stores $stores -RunPath $d -Context $ctx `
            -OnMail {param($r,$c) Add-AnalysisRecord $r $c} `
            -OnFolder {param($f,$c) Add-AnalysisFolder $f $c} -PauseMilliseconds 0 -MaxMessages 2
        Assert-True ($ctx.Total -eq 2 -and $ctx.LimitReached)
        $ctx.Status='LIMITED'; $null=Complete-AnalysisReport $ctx
    }
    Test-Case 'Mock Outlook: controlled cancellation before mail read' {
        $d=Join-Path $temp 'cancel'; [void][IO.Directory]::CreateDirectory($d)
        $fake=New-MockOutlook; $stores=@(Get-AnalysisStores $fake.Session)
        $ctx=New-AnalysisContext $d 'CANCEL' $rules $stores
        [IO.File]::WriteAllText((Join-Path $d 'STOP.request'),'')
        Invoke-OutlookReadAnalysis -Connection $fake -Stores $stores -RunPath $d -Context $ctx `
            -OnMail {param($r,$c) Add-AnalysisRecord $r $c} `
            -OnFolder {param($f,$c) Add-AnalysisFolder $f $c} -PauseMilliseconds 0
        Assert-True ($ctx.Total -eq 0 -and $ctx.CancelRequested)
        $ctx.Status='CANCELLED'; $null=Complete-AnalysisReport $ctx
    }
    Test-Case 'Mock Outlook: output failure must abort whole scan' {
        $d=Join-Path $temp 'outputfail'; [void][IO.Directory]::CreateDirectory($d)
        $fake=New-MockOutlook; $stores=@(Get-AnalysisStores $fake.Session)
        $ctx=New-AnalysisContext $d 'OUTFAIL' $rules $stores
        $thrown=$false
        try {
            Invoke-OutlookReadAnalysis -Connection $fake -Stores $stores -RunPath $d -Context $ctx `
                -OnMail {param($r,$c) throw 'SIMULATED_OUTPUT_FAILURE'} `
                -OnFolder {param($f,$c) Add-AnalysisFolder $f $c} -PauseMilliseconds 0
        } catch { $thrown=$true }
        Assert-True ($thrown -and [bool]$ctx.FatalOutputError)
        $ctx.Status='FAILED_PARTIAL'; $null=Complete-AnalysisReport $ctx
    }
    Test-Case 'Baseline rule file unchanged' {
        Assert-True ((Get-FileHash -LiteralPath $rulePath -Algorithm SHA256).Hash -eq $sourceHash)
    }
} finally {
    try { [IO.Directory]::Delete($temp,$true) } catch {}
}
$result=[pscustomobject]@{
    TestSuite='MCR_ANALYSIS_OFFLINE_0_1'; Runtime=$PSVersionTable.PSVersion.ToString()
    Passed=$script:passed; Failed=$script:failed; RealOutlookUsed=$false
    Cases=$script:results.ToArray()
}
Write-Host ("Offline-Selbsttest: {0} PASS / {1} FAIL. Kein echtes Outlook verwendet." -f $result.Passed,$result.Failed)
if ($script:failed -gt 0) { throw 'Selbsttest fehlgeschlagen. Echte Postfachanalyse darf nicht gestartet werden.' }
if ($PassThru) { $result }
