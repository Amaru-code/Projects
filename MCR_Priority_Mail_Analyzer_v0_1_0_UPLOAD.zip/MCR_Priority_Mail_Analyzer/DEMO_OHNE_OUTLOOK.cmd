@echo off
setlocal
cd /d "%~dp0"
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0PriorityMailAnalyzer.ps1" -Demo
set "MCR_EXIT=%ERRORLEVEL%"
echo.
pause
exit /b %MCR_EXIT%
