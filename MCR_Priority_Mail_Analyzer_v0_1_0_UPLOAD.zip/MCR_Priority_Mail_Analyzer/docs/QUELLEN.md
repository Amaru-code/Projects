﻿# Technische Primärquellen

Geprüft am 6. Oktober 2026. Microsoft-Dokumentation; keine fremden
Postfachinhalte wurden aus dem Web bezogen.

- Stores enthält die im aktuellen Profil verfügbaren Datenspeicher:
  https://learn.microsoft.com/en-us/office/vba/api/outlook.stores
- Folder.GetTable, olUserItems und der Unterschied zu versteckten Inhalten:
  https://learn.microsoft.com/en-us/office/vba/api/outlook.folder.gettable
- Speicherbezogene Standardordner:
  https://learn.microsoft.com/en-us/office/vba/api/outlook.store.getdefaultfolder
- Standardordner-IDs (Deleted=3, Sent=5, Inbox=6, Drafts=16, Junk=23):
  https://learn.microsoft.com/en-us/office/vba/api/outlook.oldefaultfolders
- DownloadState ist lesbar; HeaderOnly wird hier nicht zum Download markiert:
  https://learn.microsoft.com/en-us/office/vba/api/outlook.mailitem.downloadstate
  https://learn.microsoft.com/en-us/office/vba/api/outlook.oldownloadstate
- Outlook.Importance bedeutet eine Markierung des Erstellers, keine Sollklasse:
  https://learn.microsoft.com/en-us/office/vba/api/outlook.olimportance
- Suchordner sind Verweise auf Nachrichten:
  https://learn.microsoft.com/en-us/office/client-developer/outlook/mapi/pidtagfoldertype-canonical-property
- Cache-Zeiträume können dazu führen, dass nur ein Teil der Mailbox verfügbar ist:
  https://learn.microsoft.com/en-us/troubleshoot/outlook/user-interface/only-subset-items-synchronized
- Zusätzliche Cache-Grenzen bei gemeinsamen Postfächern:
  https://learn.microsoft.com/en-us/troubleshoot/outlook/data-files/fewer-emails-in-shared-mailboxes-or-public-folders
- Gelöschte Elemente versus versteckte Recoverable Items:
  https://support.microsoft.com/en-US/Outlook/mail/recover-and-restore-deleted-items-in-outlook
- Neues versus klassisches Outlook: Outlook Object Model (OOM):
  https://support.microsoft.com/de-de/outlook/getstarted/feature-comparison-between-new-outlook-and-classic-outlook
- PowerShell Execution Policy: Prozess-Scope überschreibt keine Gruppenrichtlinie:
  https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_execution_policies

Die Prioritätsheuristik ist keine Aussage dieser Quellen. Sie ist eine
explizite Implementierungsentscheidung für die vorläufige Diagnose-Baseline.
