﻿# Prüfbericht – MCR Priority Mail Analyzer 0.1.0

## Ergebnis und Grenzen

Dieses Paket ist eine neue, getrennte Diagnose-Anwendung. Die vorhandene
Generator-ZIP wurde eingelesen und nicht verändert. Es wurden hier keine echten
Postfächer geöffnet und keine echten Nachrichten verarbeitet.

**Der Windows-PowerShell-Lauf einschließlich der Outlook-Anbindung ist hier
NICHT ausgeführt worden.** Die Entwicklungsumgebung hat weder Windows/Outlook
noch eine ausführbare PowerShell-Laufzeit bereitgestellt. Es wird deshalb kein
Windows-, COM-, Zustellungs-, Vollständigkeits- oder Produktiv-PASS behauptet.

## Tatsächlich hier ausgeführte Prüfungen

- Original-Generator-ZIP: CRC und SHA256 geprüft; Datei unverändert.
- Alle JSON-Dateien zum Bauzeitpunkt syntaktisch gelesen.
- Sechs PowerShell-Quelldateien: UTF-8-BOM, CRLF und ein einfacher lexikalischer
  Klammer-/String-Abschlusscheck geprüft. Dieser Check ersetzt ausdrücklich
  **nicht** den PowerShell-Parser.
- Outlook-Adapter statisch auf schreibende Mailmethoden, Mail-Property-Zuweisungen,
  externe Web-Cmdlets und dauerhafte Execution-Policy-Änderung geprüft.
- Unabhängige Python-Referenz: **30 von 30** synthetischen Fällen ergeben die
  beabsichtigte Klasse und die angeforderten Prüfflags.
- Die Python-Referenz führt **nicht** den PowerShell-Quellcode aus. Sie belegt
  weder vollständige .NET-RegEx-Parität noch die Runtime-/COM-Funktion.
- ZIP-CRC, sichere relative Pfade und Manifest-Prüfsummen werden beim abschließenden
  Paketbau geprüft.

Die maschinenlesbare Evidence steht in `evidence/build_validation.json`.
Das SHA256-Manifest liegt im Paketwurzelverzeichnis.

## Mitgelieferte, lokal auszuführende Prüfungen

`SELBSTTEST.cmd` startet `tests/Run-Tests.ps1` unter Windows PowerShell.
Die Analyse führt diesen Test ebenfalls automatisch **vor** dem Zugriff auf
echte Mailtexte aus. Bei Testfehlern wird die echte Analyse nicht begonnen.

Die Tests enthalten:

- PowerShell-Parserprüfung aller PS-Quelldateien.
- 30 synthetische Klassifikationsfälle.
- Wortgrenzen, Negation, historische Antwortzitate, Erledigungswidersprüche,
  gemischte Information/Aufgabe, fehlender Text und getrennte Outlook-Markierung.
- Zeitkontext, lange Texte, wiederholte Wörter und synthetische Testkennungen.
- JSON-/RegEx-Validierung, ungültige Gewichte und unveränderte Baseline.
- CSV-Formel-/Anführungszeichenschutz und Roundtrip.
- Berichtsaufbau, Stichprobe ohne Vorschläge und keine Volltext-Ausgabe.
- Synthetischer Outlook-Adapter mit mehreren Stores, gelöschten Unterordnern,
  Suchordnern, doppelten Ansichten, Nicht-Mail-Objekten und Lesefehlern.
- Begrenzter Lauf, kontrollierter Abbruch und erzwungener Ausgabefehler.

Diese Tests sind hier **beigelegt, aber nicht in PowerShell ausgeführt**.
Ein lokales PASS ist ein Offline-Nachweis; es ist noch kein Nachweis für
Zugriffsrechte, vollständige Synchronisation oder richtige fachliche Prioritäten.

## Empfohlene lokale Abnahme

1. ZIP vollständig in einen neuen Ordner entpacken.
2. `SELBSTTEST.cmd` ausführen und nur bei 0 FAIL fortfahren.
3. `DEMO_OHNE_OUTLOOK.cmd` zum Prüfen von Bericht und Popup verwenden.
4. Optional zunächst `-AllStores -MaxMessages 100 -NoPopup` als begrenzten
   Outlook-Lesetest verwenden. Das ist ausdrücklich keine Vollanalyse.
5. Für den vollständigen sichtbaren Bestand den normalen Starter verwenden,
   `ALLE` wählen und mit `ANALYSIEREN` bestätigen.
6. Zuerst `run_state.json`, `coverage.csv` und `stores_PRIVATE.json` prüfen.
   `VISIBLE_SCAN_COMPLETED_SERVER_COVERAGE_UNVERIFIED` ist keine serverweite
   Vollständigkeitsbestätigung.
7. Fachliche Vorschläge in einer Stichprobe mit den tatsächlichen Mails abgleichen.

Kein Fehler wird durch Änderungen an Outlook-Berechtigungen, Sicherheitsrichtlinien,
Schutzmarkierungen oder gelöschten Mailbeständen „repariert“.
