# MCR Level 05A.2 – TypeScript Mode-1 Parity v0.1.1

Next active Level-05 language after C#.

Rust is intentionally not continued on the managed laptop because its freshly generated native EXE triggered endpoint-security blocking. C++ and Go are also deferred on this endpoint because their normal benchmark form likewise produces new native executables.

TypeScript is therefore the next safe candidate in the benchmark order:

- source: TypeScript
- build artifact: JavaScript files only
- runtime: already installed `node.exe`
- no new native candidate EXE is generated
- no Python Oracle, C# worker or Rust worker is used
- Excel access is limited to the existing PowerShell/Excel-COM I/O bridge; TypeScript performs the business calculations itself

The package installs to `Level_05\languages\typescript\parity`, performs an offline TypeScript build, runs one full frozen `MCR_LNW_001` parity attempt, and validates all four artifacts against the certified Golden Reference.

v0.1.1 is correctness-first. Raw-file conversion is sequential initially; performance/concurrency work follows only after semantic parity is reached.
