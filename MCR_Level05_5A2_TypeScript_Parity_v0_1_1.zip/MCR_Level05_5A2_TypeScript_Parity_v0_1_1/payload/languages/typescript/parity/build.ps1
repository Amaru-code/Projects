[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$ModeRoot = $PSScriptRoot
$SrcRoot = Join-Path $ModeRoot 'src'
$BuildRoot = Join-Path $ModeRoot 'build'
$Publish = Join-Path $BuildRoot 'publish'
$NodePointer = Join-Path $BuildRoot 'node_path.txt'
$TscPointer = Join-Path $BuildRoot 'tsc_path.txt'
$TsConfig = Join-Path $ModeRoot 'tsconfig.json'

function Test-Node([string]$Path) {
    if ([string]::IsNullOrWhiteSpace($Path) -or -not (Test-Path $Path -PathType Leaf)) { return $false }
    $old=$ErrorActionPreference; $ErrorActionPreference='Continue'
    try { $v=& $Path --version 2>$null; $c=$LASTEXITCODE } finally { $ErrorActionPreference=$old }
    return ($c -eq 0 -and $v -match '^v\d+')
}

$NodeCandidates = New-Object System.Collections.Generic.List[string]
$cmd = Get-Command node.exe -ErrorAction SilentlyContinue
if ($cmd) { $NodeCandidates.Add($cmd.Source) }
if ($env:USERPROFILE) {
    foreach ($p in @(
        (Join-Path $env:USERPROFILE 'projects\Compiler\node\node.exe'),
        (Join-Path $env:USERPROFILE 'projects\Compiler\nodejs\node.exe'),
        (Join-Path $env:USERPROFILE 'projects\Compiler\javascript\node.exe'),
        (Join-Path $env:USERPROFILE 'projects\Compiler\typescript\node.exe')
    )) { if ((Test-Path $p -PathType Leaf) -and -not $NodeCandidates.Contains($p)) { $NodeCandidates.Add($p) } }
    $compiler=Join-Path $env:USERPROFILE 'projects\Compiler'
    if (Test-Path $compiler) {
        Get-ChildItem $compiler -Recurse -Filter node.exe -File -ErrorAction SilentlyContinue | ForEach-Object {
            if (-not $NodeCandidates.Contains($_.FullName)) { $NodeCandidates.Add($_.FullName) }
        }
    }
}
$Node=$null
foreach($c in $NodeCandidates){if(Test-Node $c){$Node=$c;break}}
if(-not $Node){throw 'Vorhandene Node.js Runtime wurde nicht gefunden. Es wird nichts heruntergeladen.'}

$TscCandidates = New-Object System.Collections.Generic.List[string]
foreach($n in @('tsc.cmd','tsc.exe')) {
    $x=Get-Command $n -ErrorAction SilentlyContinue
    if($x -and -not $TscCandidates.Contains($x.Source)){$TscCandidates.Add($x.Source)}
}
if($env:USERPROFILE){
    $compiler=Join-Path $env:USERPROFILE 'projects\Compiler'
    if(Test-Path $compiler){
        Get-ChildItem $compiler -Recurse -File -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -in @('tsc.cmd','tsc.js') } |
            ForEach-Object { if(-not $TscCandidates.Contains($_.FullName)){$TscCandidates.Add($_.FullName)} }
    }
}
$Tsc=$TscCandidates | Select-Object -First 1
if(-not $Tsc){throw 'Vorhandener TypeScript Compiler (tsc.cmd/tsc.js) wurde nicht gefunden. Es wird nichts heruntergeladen.'}

Write-Host '============================================================'
Write-Host ' Level 05A.2 - TypeScript Parity Build'
Write-Host '============================================================'
Write-Host "node:      $Node"
Write-Host "Node:      $(& $Node --version)"
Write-Host "tsc:       $Tsc"
$TscVersion = if([IO.Path]::GetExtension($Tsc) -ieq '.js') { & $Node $Tsc --version } else { & $Tsc --version }
Write-Host "TypeScript: $TscVersion"
Write-Host "Project:   $TsConfig"
Write-Host "Publish:   $Publish"
Write-Host ''
Write-Host 'Dependencies: Node/TypeScript existing runtime only / OFFLINE'
Write-Host 'Native candidate EXE generation: NONE'
Write-Host ''

if(Test-Path $Publish){Remove-Item $Publish -Recurse -Force}
New-Item -ItemType Directory -Force -Path $Publish | Out-Null

$old=$ErrorActionPreference; $ErrorActionPreference='Continue'
try {
    if([IO.Path]::GetExtension($Tsc) -ieq '.js') {
        & $Node $Tsc -p $TsConfig
    } else {
        & $Tsc -p $TsConfig
    }
    $Code=$LASTEXITCODE
} finally { $ErrorActionPreference=$old }
if($Code -ne 0){throw "TypeScript Build fehlgeschlagen. ExitCode=$Code"}

$Main=Join-Path $Publish 'main.js'
if(-not(Test-Path $Main -PathType Leaf)){throw "TypeScript Build erzeugte kein main.js: $Main"}
New-Item -ItemType Directory -Force -Path (Join-Path $Publish 'resources') | Out-Null
Copy-Item (Join-Path $SrcRoot 'resources\settings.json') (Join-Path $Publish 'resources\settings.json') -Force
Copy-Item (Join-Path $SrcRoot 'resources\wwid_mapping.csv') (Join-Path $Publish 'resources\wwid_mapping.csv') -Force
Copy-Item (Join-Path $SrcRoot 'excel_bridge.ps1') (Join-Path $Publish 'excel_bridge.ps1') -Force
New-Item -ItemType Directory -Force -Path $BuildRoot | Out-Null
Set-Content $NodePointer $Node -Encoding UTF8
Set-Content $TscPointer $Tsc -Encoding UTF8

Write-Host ''
Write-Host 'TYPESCRIPT PARITY BUILD: PASS' -ForegroundColor Green
Write-Host "MAIN: $Main"
Write-Host "Runtime: existing node.exe (no new native EXE)" -ForegroundColor Green
exit 0
