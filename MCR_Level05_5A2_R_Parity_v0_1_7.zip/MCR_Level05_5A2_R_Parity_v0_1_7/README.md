# MCR Level 05A.2 – R Mode 1 Parity v0.1.7

First R parity candidate for the frozen LNW DC benchmark.

- existing R runtime
- base R only
- offline build/run
- no external packages
- no new native candidate EXE
- complete business implementation in R
- common Level-05 validator after the timed candidate run

Run `START_5A2_R.ps1`.


## v0.1.7

If R is missing on the benchmark laptop, the package automatically provisions a
portable R 4.6.1 runtime as a ZIP below `projects/Compiler/r/tools`.
No Windows installer is launched.


## v0.1.7

Fixes a false-negative portable-R runtime check for version banners such as
`Rscript (R) version ...`. The already downloaded/extracted R runtime is reused.


## v0.1.7

Fixes the real BOM source: the temporary `_source_check.R` file written by
Windows PowerShell 5.1. `main.R` itself was already BOM-free.


## v0.1.7

Major R parser-performance fix. The previous character-by-character interpreted
parser caused the 252 DU files to run for tens of minutes. Normal delimited
input now uses native `count.fields/read.table`, with the old parser retained as
a correctness fallback.


## v0.1.7

Reworks R's hot path after the 79-minute diagnostic run:
vectorized early company filtering, in-memory conversion/merge, robust empty-TSV
headers and an automatic 25-file performance guard. No business semantics or
Golden contract changed.


## v0.1.7

R now filters the raw text down to header/metadata plus lines containing one of
the benchmark's allowed company IDs *before* expensive row parsing. Exact
company semantics are still enforced afterward by the original field-level
logic. A 5-file early performance guard prevents another long diagnostic run.
