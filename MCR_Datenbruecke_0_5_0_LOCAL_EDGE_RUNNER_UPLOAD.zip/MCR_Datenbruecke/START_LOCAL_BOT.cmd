@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
echo ==============================================================
echo  MCR Local Runner 0.5.0 - Node + Edge
echo ==============================================================
echo.
if not exist "%~dp0src\local-bot.mjs" goto notExtracted
set "NODE_EXE="
for %%N in (
  "C:\Users\Amaru-Zegarra\projects\Compiler\javascript\tools\node\node.exe"
  "%~dp0tools\node\node.exe"
) do if not defined NODE_EXE if exist "%%~N" set "NODE_EXE=%%~N"
if not defined NODE_EXE for /f "delims=" %%N in ('where node.exe 2^>nul') do if not defined NODE_EXE set "NODE_EXE=%%N"
if not defined NODE_EXE goto noNode
"%NODE_EXE%" "%~dp0src\verify-package.mjs"
if errorlevel 1 (
  echo.
  echo Paketintegritaet fehlgeschlagen. Runner wird nicht gestartet.
  pause
  exit /b 4
)
"%NODE_EXE%" "%~dp0src\local-bot.mjs"
set "RC=%errorlevel%"
echo.
if not "%RC%"=="0" echo Der Runner wurde fail-closed beendet. Details stehen oben und im Diagnose-ZIP.
pause
exit /b %RC%
:notExtracted
echo FEHLER: Paket nicht vollstaendig entpackt.
echo ZIP zuerst in einen normalen Ordner entpacken und START_LOCAL_BOT.cmd dort starten.
pause
exit /b 2
:noNode
echo FEHLER: node.exe wurde nicht gefunden.
echo Erwartet wird bevorzugt:
echo C:\Users\Amaru-Zegarra\projects\Compiler\javascript\tools\node\node.exe
pause
exit /b 3
