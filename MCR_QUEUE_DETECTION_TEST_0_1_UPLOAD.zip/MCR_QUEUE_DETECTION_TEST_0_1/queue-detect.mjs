import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { spawn } from 'node:child_process';
import readline from 'node:readline/promises';
import { stdin as input, stdout as output } from 'node:process';

const VERSION = '0.1';
const ROOT = process.env.MCR_PROJECT_ROOT || 'C:\\Users\\Amaru-Zegarra\\projects\\Aktive_Projekte\\Ticket_bot\\MCR_Datenbruecke';
const PROFILE = path.join(ROOT, '.runtime', 'edge-profile');
const DIAG_DIR = path.join(ROOT, 'diagnostics');
fs.mkdirSync(PROFILE, {recursive:true});
fs.mkdirSync(DIAG_DIR, {recursive:true});

const sleep = ms => new Promise(r => setTimeout(r, ms));
const rl = readline.createInterface({input, output});

function findEdge(){
  const candidates = [
    process.env['PROGRAMFILES(X86)'] && path.join(process.env['PROGRAMFILES(X86)'], 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
    process.env.PROGRAMFILES && path.join(process.env.PROGRAMFILES, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
    process.env.LOCALAPPDATA && path.join(process.env.LOCALAPPDATA, 'Microsoft', 'Edge', 'Application', 'msedge.exe')
  ].filter(Boolean);
  return candidates.find(p => fs.existsSync(p)) || null;
}

async function getJson(port, endpoint='/json/list'){
  try{
    const r = await fetch(`http://127.0.0.1:${port}${endpoint}`, {cache:'no-store'});
    if(!r.ok) return null;
    return await r.json();
  }catch{return null;}
}

async function findDebugPort(){
  const ports = [...Array.from({length:20},(_,i)=>9222+i), ...Array.from({length:10},(_,i)=>9333+i)];
  for(const p of ports){
    const list = await getJson(p);
    if(Array.isArray(list) && list.some(t => /comarchecm\.mercer\.com/i.test(t.url||''))) return p;
  }
  return null;
}

async function launchEdge(){
  const edge = findEdge();
  if(!edge) throw new Error('Microsoft Edge wurde nicht gefunden.');
  const port = 9337;
  spawn(edge, [
    `--remote-debugging-port=${port}`,
    `--user-data-dir=${PROFILE}`,
    '--no-first-run',
    '--no-default-browser-check',
    'https://comarchecm.mercer.com/DMSWWW/main.jspx'
  ], {detached:true, stdio:'ignore'}).unref();
  for(let i=0;i<80;i++){
    const v = await getJson(port, '/json/version');
    if(v) return port;
    await sleep(250);
  }
  throw new Error('Edge-Debugschnittstelle konnte nicht gestartet werden. Falls ein MCR-Edge mit demselben Profil offen ist: diesen schließen und erneut starten.');
}

class CDP {
  constructor(wsUrl){
    this.ws = new WebSocket(wsUrl);
    this.id = 0;
    this.pending = new Map();
  }
  async open(){
    await new Promise((res,rej)=>{this.ws.addEventListener('open',res,{once:true});this.ws.addEventListener('error',rej,{once:true});});
    this.ws.addEventListener('message',ev=>{
      const m = JSON.parse(ev.data);
      if(m.id && this.pending.has(m.id)){
        const {resolve,reject} = this.pending.get(m.id);this.pending.delete(m.id);
        if(m.error) reject(new Error(m.error.message)); else resolve(m.result);
      }
    });
  }
  send(method, params={}){
    const id=++this.id;
    return new Promise((resolve,reject)=>{this.pending.set(id,{resolve,reject});this.ws.send(JSON.stringify({id,method,params}));});
  }
  close(){try{this.ws.close();}catch{}}
}

async function findComarchTarget(port){
  const list = await getJson(port);
  if(!Array.isArray(list)) return null;
  const pages = list.filter(t => t.type==='page' && /comarchecm\.mercer\.com/i.test(t.url||''));
  // Prefer main.jspx and the most recently exposed page if possible.
  return pages.find(t=>/main\.jspx/i.test(t.url||'')) || pages[0] || null;
}

const browserProbe = String.raw`(() => {
  const norm = s => String(s ?? '')
    .replace(/\u00a0/g,' ')
    .replace(/\s+/g,' ')
    .trim();
  const key = s => norm(s).toLocaleLowerCase('de-DE')
    .replace(/[ä]/g,'ae').replace(/[ö]/g,'oe').replace(/[ü]/g,'ue').replace(/ß/g,'ss')
    .replace(/[^a-z0-9]+/g,'');
  const visible = e => {
    if(!e || !e.isConnected) return false;
    const r=e.getBoundingClientRect(), cs=getComputedStyle(e);
    return r.width>0 && r.height>0 && cs.display!=='none' && cs.visibility!=='hidden';
  };
  const allTables = [...document.querySelectorAll('table')].filter(visible);
  const methods = [];
  const candidateTables = [];

  function headers(table){
    const hs=[...table.querySelectorAll('thead th, tr:first-child th')].map((th,i)=>({i,text:norm(th.innerText||th.textContent),key:key(th.innerText||th.textContent)}));
    return hs;
  }
  function rows(table){
    const tbody=table.tBodies?.[0];
    return tbody ? [...tbody.rows].filter(visible) : [...table.querySelectorAll('tr')].filter(visible).slice(1);
  }
  function cellText(td){
    if(!td) return '';
    const text=norm(td.innerText||td.textContent);
    if(text) return text;
    const vals=[...td.querySelectorAll('input,textarea,select')].map(x=>norm(x.value)).filter(Boolean);
    return vals.join(' ');
  }
  function parse(table, route, inferred=false){
    const hs=headers(table), map={};
    for(const h of hs){
      if(h.key==='ticketid' || h.key.includes('ticketid')) map.ticket=h.i;
      else if(h.key==='quelle') map.source=h.i;
      else if(h.key.includes('zusatzlichebeschreibung')) map.desc=h.i;
    }
    const rs=rows(table);
    if(inferred || map.ticket===undefined || map.desc===undefined){
      // Current COMARCH In_Bearbeitung shape:
      // Ticket-ID, Group Employer Code, Group Name, Member name, Quelle, Aufgabenname,
      // Ticket Status, Zuständigkeit, Ticketpriorität, Erstelldatum, Letzter Statuswechsel, Zusätzliche Beschreibung
      const sample=rs.find(r=>r.cells.length>=10);
      if(sample){
        map.ticket ??= 0;
        map.source ??= sample.cells.length>=5 ? 4 : undefined;
        map.desc ??= sample.cells.length-1;
      }
    }
    const parsed=[];
    for(let ri=0;ri<rs.length;ri++){
      const r=rs[ri], cells=[...r.cells];
      if(map.ticket===undefined || map.desc===undefined || !cells[map.ticket] || !cells[map.desc]) continue;
      const ticket=cellText(cells[map.ticket]);
      if(!/^\d{6,15}$/.test(ticket)) continue;
      const source=map.source!==undefined && cells[map.source] ? cellText(cells[map.source]) : '';
      const desc=cellText(cells[map.desc]);
      const eligible=(!source || /E-?MAIL/i.test(source)) && desc==='';
      parsed.push({ri,ticket,sourceKey:key(source),descBlank:desc==='',eligible,cellCount:cells.length,row:r});
    }
    const eligible=parsed.filter(x=>x.eligible);
    return {route,table,tableId:table.id||'',headers:hs.map(h=>h.text),rowCount:rs.length,parsedCount:parsed.length,eligible,map,parsed};
  }
  function addMethod(name, tables, inferred=false){
    let found=null;
    for(const t of tables){
      const p=parse(t,name,inferred);
      candidateTables.push({strategy:name,tableId:p.tableId,headers:p.headers,rowCount:p.rowCount,parsedCount:p.parsedCount,eligibleCount:p.eligible.length});
      if(!found && p.eligible.length) found=p;
    }
    methods.push({name,tested:tables.length,success:!!found,eligibleCount:found?.eligible.length||0,tableId:found?.tableId||null});
    return found;
  }

  let hit=null;
  // 1. Known production ID family used by My Tasks/In_Bearbeitung.
  hit = addMethod('KNOWN_TASKS_TABLE_ID', allTables.filter(t=>/tasksTableFor_MyTasksList/i.test(t.id)||/tasksTableFor_.*TasksList/i.test(t.id)));
  // 2. Exact headers in the same table.
  if(!hit) hit = addMethod('HEADER_EXACT', allTables.filter(t=>{const ks=headers(t).map(h=>h.key);return ks.some(x=>x.includes('ticketid'))&&ks.some(x=>x.includes('zusatzlichebeschreibung'));}));
  // 3. Find header labels anywhere and climb to the closest table.
  if(!hit){
    const nodes=[...document.querySelectorAll('th,label,span,div')].filter(visible);
    const tid=nodes.filter(n=>key(n.textContent).includes('ticketid'));
    const desc=nodes.filter(n=>key(n.textContent).includes('zusatzlichebeschreibung'));
    const tables=[...new Set(tid.map(n=>n.closest('table')).filter(Boolean).filter(t=>desc.some(d=>d.closest('table')===t)))];
    hit=addMethod('HEADER_DESCENDANT_COMMON_TABLE',tables);
  }
  // 4. Generic work-area tables.
  if(!hit) hit=addMethod('WORKAREA_TABLE_CLASS',allTables.filter(t=>/workAreaTable/i.test(t.className||'')));
  // 5. Structural inference as last read-only fallback.
  if(!hit) hit=addMethod('ROW_SHAPE_INFERENCE',allTables.filter(t=>{const rs=rows(t);return rs.some(r=>r.cells.length>=10 && /^\d{6,15}$/.test(cellText(r.cells[0])));}),true);

  let highlight=null;
  if(hit){
    const first=hit.eligible[0];
    const r=first.row;
    r.dataset.mcrQueueDetected='true';
    r.style.outline='4px solid magenta';
    r.style.outlineOffset='-2px';
    r.scrollIntoView({block:'center',behavior:'instant'});
    highlight={ticket:first.ticket,rowIndex:first.ri,tableId:hit.tableId,route:hit.route};
  }

  const discovery=allTables.slice(0,80).map(t=>({
    id:t.id||'',
    cls:norm(t.className||'').slice(0,120),
    headers:headers(t).map(h=>h.text).slice(0,20),
    rows:rows(t).length,
    firstDataCells: rows(t)[0] ? rows(t)[0].cells.length : 0
  }));
  return {
    success:!!hit,
    route:hit?.route||null,
    tableId:hit?.tableId||null,
    eligibleCount:hit?.eligible.length||0,
    firstEligibleTicket:hit?.eligible[0]?.ticket||null,
    methods,
    candidateTables,
    discovery,
    highlight
  };
})()`;

function sanitize(res){
  // Structural only. Keep ticket ID out of saved diagnostic.
  return {
    schema:'MCR_QUEUE_DETECTION_PROBE_V1',
    version:VERSION,
    createdAt:new Date().toISOString(),
    success:!!res.success,
    route:res.route,
    tableId:res.tableId,
    eligibleCount:res.eligibleCount,
    methods:res.methods,
    candidateTables:res.candidateTables,
    discovery:(res.discovery||[]).map(x=>({id:x.id,cls:x.cls,headers:x.headers,rows:x.rows,firstDataCells:x.firstDataCells})),
    privacy:'No names, ticket IDs, email addresses, row text, URLs, cookies or ticket content.'
  };
}

console.log('==============================================================');
console.log(` MCR Queue Detection-Test ${VERSION} - NUR ERKENNUNG, KEIN KLICK`);
console.log('==============================================================');
console.log('Der Test verändert keine Ticketdaten und öffnet kein Ticket.');
console.log('Er probiert mehrere Erkennungswege und stoppt beim ersten Treffer.');
console.log('Die erkannte erste zulässige Zeile wird nur MAGENTA umrandet.');
console.log('');

let port = await findDebugPort();
if(!port){
  console.log('Kein steuerbares MCR-Edge gefunden. Starte eigenes MCR-Edge-Fenster ...');
  port = await launchEdge();
}else console.log(`Vorhandenes steuerbares MCR-Edge erkannt (Port ${port}).`);

console.log('Öffne jetzt im MCR-Edge: Meine Vorgänge > In_Bearbeitung.');
await rl.question('ENTER drücken, sobald die Ticketliste sichtbar ist ... ');

const target = await findComarchTarget(port);
if(!target) throw new Error('Kein COMARCH-Tab an der Edge-Debugschnittstelle gefunden.');
const cdp = new CDP(target.webSocketDebuggerUrl);
await cdp.open();
await cdp.send('Runtime.enable');
const ev = await cdp.send('Runtime.evaluate',{expression:browserProbe,returnByValue:true,awaitPromise:true,userGesture:false});
cdp.close();
const res = ev?.result?.value;
if(!res) throw new Error('Queue-Probe lieferte kein Ergebnis.');

console.log('');
for(const m of res.methods){
  console.log(`[${m.name}] getestet=${m.tested} success=${m.success?'JA':'NEIN'} eligible=${m.eligibleCount}${m.tableId?` table=${m.tableId}`:''}`);
  if(m.success) break;
}
console.log('');
if(res.success){
  console.log('==============================================================');
  console.log(' QUEUE-ERKENNUNG ERFOLG');
  console.log('==============================================================');
  console.log(`Methode: ${res.route}`);
  console.log(`Tabelle: ${res.tableId || '(ohne ID)'}`);
  console.log(`Zulässige Tickets mit leerer Zusätzlicher Beschreibung: ${res.eligibleCount}`);
  console.log(`Erste erkannte Ticket-ID: ${res.firstEligibleTicket}`);
  console.log('Die erste erkannte Zeile ist im Browser MAGENTA umrandet.');
  console.log('Es wurde NICHT geklickt und NICHTS am Ticket verändert.');
}else{
  console.log('==============================================================');
  console.log(' QUEUE-ERKENNUNG NOCH NICHT GELUNGEN');
  console.log('==============================================================');
  console.log('Es wurde nichts angeklickt. Die Strukturdiagnose wurde gespeichert.');
}

const diag = sanitize(res);
const file = path.join(DIAG_DIR, `MCR_QUEUE_DETECTION_${new Date().toISOString().replace(/[:.]/g,'-')}.json`);
fs.writeFileSync(file, JSON.stringify(diag,null,2), 'utf8');
console.log(`Diagnose: ${file}`);
console.log('');
await rl.question('ENTER zum Beenden ... ');
rl.close();
