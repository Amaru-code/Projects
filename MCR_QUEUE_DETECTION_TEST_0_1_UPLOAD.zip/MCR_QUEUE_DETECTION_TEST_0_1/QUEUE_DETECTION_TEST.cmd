@echo off
setlocal EnableExtensions
chcp 65001 >nul
set "NODE=C:\Users\Amaru-Zegarra\projects\Compiler\javascript\tools\node\node.exe"
if not exist "%NODE%" (
  echo FEHLER: Node nicht gefunden:
  echo %NODE%
  pause
  exit /b 1
)
"%NODE%" "%~dp0queue-detect.mjs"
if errorlevel 1 (
  echo.
  echo FEHLER: Queue-Detection-Test abgebrochen.
  pause
  exit /b 1
)
endlocal
