MCR Queue Detection-Test 0.1

Ziel:
- NUR herausfinden, wie die In_Bearbeitung-Tabelle zuverlässig erkannt wird.
- Kein Ticket öffnen.
- Keine Ticketdaten ändern.
- Mehrere Erkennungswege werden nacheinander getestet.
- Beim ersten Erfolg stoppt die Suche.
- Die erste Zeile mit leerer "Zusätzlicher Beschreibung" wird magenta umrandet.

Benutzung:
1. Falls ein alter MCR-Edge ohne Debug-Port offen ist, schließen.
2. QUEUE_DETECTION_TEST.cmd starten.
3. Im gestarteten MCR-Edge zu Meine Vorgänge > In_Bearbeitung wechseln.
4. ENTER drücken.
5. Terminalausgabe kopieren.

Erkennungswege:
1. KNOWN_TASKS_TABLE_ID
2. HEADER_EXACT
3. HEADER_DESCENDANT_COMMON_TABLE
4. WORKAREA_TABLE_CLASS
5. ROW_SHAPE_INFERENCE

Es wird nichts angeklickt und nichts gespeichert.
