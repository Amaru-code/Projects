# Nur diese Abrufabschnitte in den bestehenden LenWork-Skill übernehmen

**Keine Änderung** an YAML-Frontmatter, Skill-Name, `absender.md`, Step 2, Step 3, Step 4.

## Step 1b – Mehrfachabruf über das vorhandene `msgraph_email`-Tool (READ-ONLY)

Dieses Kapitel regelt **nur die Beschaffung der E-Mails**. Es ändert keine Priorität, Absenderregel oder Ausgabevorgabe aus Step 2–4. Das Tool ist pro `list`-Aufruf auf `count: 50` begrenzt. Die 50 sind KEINE Gesamtgrenze des Skills.

1. Für den durch Step 1 festgelegten Scope `msgraph_email` mit `action: list`, `folder: inbox`, `count: 50`, korrekt gesetztem `unread_only` und dem gewünschten `date_range` abfragen. Der ursprüngliche Standard bleibt `unread_only: true`; nur bei ausdrücklichem Wunsch nach gelesenen und ungelesenen E-Mails `unread_only: false` verwenden. Keine Parameter erfinden.
2. **Weniger als 50 Treffer** für ein nachweislich wirksam gefiltertes Intervall: vorläufig vollständiges Blatt. **Genau 50 Treffer:** nicht als vollständig behaupten; in zwei aufeinanderfolgende, disjunkte Kalendertagsintervalle aufteilen und beide abfragen. Die Aufteilung wiederholen, bis alle Blätter <50 haben.
3. Ein Einzeltag mit genau 50 Treffern bleibt `UNRESOLVED`, denn `date_range` hat nach der LenWork-Diagnose nur Tagesgranularität. Ohne belegbar vollständige andere Partition darf keine vollständige Auswertung behauptet werden.
4. Ausschließlich Blattdaten zusammenführen, anhand stabiler Message-IDs deduplizieren und tatsächliche Anzahl der Tool-Abrufe sowie nicht vollständig auflösbare Tage dokumentieren. Eine fehlende/instabile ID oder Tool-Fehler bedeutet `FETCH_STATUS=INCOMPLETE`.
5. Gilt `FETCH_STATUS=COMPLETE_UNDER_TOOL_CONTRACT`, fahre mit dem **unveränderten Step 2** fort. Dies ist keine atomare Snapshot-Garantie für das Postfach. Bei `INCOMPLETE` transparent nur als Teilauswertung berichten und ggf. Step 1c anbieten.

## Step 1c – Optionaler PowerShell-Export für mehr als 50 E-Mails an EINEM Tag

Nur wenn der Nutzer den lokalen Export ausdrücklich verwendet oder anbietet: `scripts/Export-InboxReadOnly.ps1` auf dem **eigenen Windows-Rechner mit geöffnetem KLASSISCHEM Outlook** ausführen lassen. LenWork kann das Skript nicht in seiner abgeschotteten Sandbox für Outlook auf dem Rechner ausführen. Das Skript liest lokal den Inbox-Ordner und schreibt strukturierte Daten in lokale Batch-Dateien – keine Outlook-Schreiboperationen.

1. Vor Verwendung sicherstellen, dass Export, lokale Dateiablage und Upload geschäftlicher E-Mails in die genehmigte LenWork-Umgebung zulässig sind. Keinen Export in öffentliche KI-Dienste, fremde Cloudspeicher oder diesen Chat hochladen.
2. `manifest.json` und sämtliche `mail_batch_*.jsonl`-Dateien bzw. `mail_batch_*.md` aus **demselben** Lauf einlesen. Falls die Python-Ausführung verfügbar ist, zuerst `scripts/verify_export.py` auf den Exportordner anwenden. Bei fehlenden Dateien, ungültigem Hash/Manifest, ID-Duplikaten oder `status != COMPLETE_LOCAL_STORE`, NICHT vollständige Abdeckung behaupten.
3. Jede eindeutige Nachricht in einer Verarbeitungsliste erfassen und in Batches zu etwa 20–30 dem **unveränderten Step 2–4** zuführen. Nicht nach 50 oder 100 abbrechen. Die Priorität wird ausschließlich nach dem Original-Skill und `absender.md` vergeben – **nicht durch PowerShell oder Python**.
4. Der Standardexport enthält nur Metadaten und kurze Vorschauen. Für Fälle, die laut Original-Step-2 den Volltext benötigen, die lokale Nachlieferung der betreffenden IDs über `-BodyIdsFile` nutzen (nur wenn genehmigt) oder die Original-Microsoft-365-Integration READ-ONLY für passende Detailnachrichten verwenden. Falls Details fehlen, "unklar" statt halluzinieren.
5. Bei gemischten Quellen nicht unbesehen Duplikate zusammenführen: Outlook-EntryIDs und Graph-IDs können verschiedene Identifikatoren derselben Nachricht sein. `COMPLETE_LOCAL_STORE` bedeutet vollständig **für die im klassischen Outlook erreichbaren lokalen Inbox-Objekte im angegebenen Zeitraum**, nicht zwingend alle Cloud-Nachrichten des M365-Postfachs.

**Wichtig:** Der Scriptweg ersetzt nur Step 1b (Datenabruf), NICHT Step 2 (Analyse), Step 3 (Prioritäten) oder Step 4 (Antwortformat). Wenn kein lokales COM-Outlook verfügbar ist, weiterhin die bewährte `msgraph_email`-Intervallpartitionierung nutzen.

