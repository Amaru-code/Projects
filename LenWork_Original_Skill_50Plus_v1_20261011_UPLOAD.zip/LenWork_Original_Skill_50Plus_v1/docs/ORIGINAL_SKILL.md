# Inbox catch-up after absence (Urlaubs-Rückblick)

## Goal
When the user comes back from vacation or another absence, read the emails received during that time and give a prioritized overview in German: what needs an answer now, what can wait, what is just for information, and what can be ignored.

## Hard rules
- READ-ONLY. Never send, reply, forward, delete, move, flag, categorize or mark any email as read. Drafts only if the user asks for them afterwards, and only shown in the chat.
- Output language is ALWAYS German, even if the user writes in English or the emails are in English.
- Use only what is in the emails. Do not invent deadlines, intentions or facts. If something is unclear, write "unklar".
- Before classifying anything, read the file absender.md from this skill (sender and subject rules). Its rules override your own judgment.

## Step 1 – Scope
- If the user gives a period (e.g. "Urlaub 22.09.–06.10."), use exactly that period.
- Otherwise: all UNREAD emails in the Inbox from the last 14 days. State this assumption in the first line of the answer.
- Inbox only, plus subfolders the user names explicitly. Skip Junk, Deleted Items and Archive.

## Step 1b – Mehrfachabruf, wenn mehr als 50 E-Mails im Scope liegen
Das zugrunde liegende Mail-Tool liefert pro Aufruf maximal 50 E-Mails und kennt keine automatische Seitenblätterung. Deshalb bei Bedarf mehrfach abrufen, bis der gesamte Scope abgedeckt ist:
1. Ersten Abruf mit `unread_only: true`, `count: 50`, Ordner Inbox, ohne engen Datumsfilter (neueste zuerst) ausführen.
2. Empfangsdatum/-zeit der ÄLTESTEN E-Mail in diesem Batch notieren.
3. Nächsten Abruf mit denselben Filtern ausführen, aber `date_range` so setzen, dass er VOR diesem notierten Zeitpunkt endet (nächstältere 50).
4. Schritt 3 wiederholen, bis entweder ein Abruf weniger als 50 Treffer liefert, oder die untere Grenze des Scope-Zeitraums erreicht ist (z. B. 14 Tage zurück, oder das vom Nutzer genannte Startdatum).
5. Alle Batches zu einer einzigen Liste zusammenführen und anhand Message-ID (oder Betreff + Absender + Empfangszeit) Duplikate entfernen, bevor mit Step 2 fortgefahren wird.
6. Keine Obergrenze von 50 oder 100 akzeptieren, wenn der Scope mehr enthält – so lange weiter abrufen, bis Punkt 4 zutrifft. Bei sehr großem Scope (z. B. >300 E-Mails) den Nutzer kurz informieren, wie viele Abrufe nötig waren.
7. In der Ausgabe (Step 4) immer die Gesamtzahl gefundener E-Mails und die Anzahl benötigter Abrufe nennen, nicht nur die Zahl aus einem einzelnen Aufruf.

## Step 2 – Metadata first, full text only when needed
1. List for every email: sender, whether the user is in To or only in CC, subject, received date, importance flag, attachments yes/no, conversation/thread, short preview.
2. Apply absender.md: everything matching "Ignorieren" goes straight to ⚪ without opening it.
3. Group by conversation/thread. Judge each thread by its LATEST message. If the question in a thread was already answered or solved by someone else, put it under "Bereits erledigt" and name who solved it.
4. If possible, check Sent Items for the same period: if the user already replied to a thread, mark it as "bereits beantwortet".
5. Open the full text only for emails that cannot be clearly classified as 🔵 or ⚪ from the metadata.
6. Work in batches of about 20–30 emails. Do not stop early; process all emails in scope.

## Step 3 – Priorities
🔴 Sofort beantworten (today):
- a direct question or request to the user (user in To)
- a deadline that has passed or is within the next 2 working days (mark passed ones as "ÜBERFÄLLIG")
- anything from a VIP in absender.md that contains a question or a deadline
- reminders and escalations ("Erinnerung", "dringend", "nochmals", 2nd follow-up)
- meeting requests for the next days that still need a response

🟡 Diese Woche:
- a request to the user without a tight deadline
- a deadline within the next ~2 weeks
- coordination where the user's input is expected

🔵 Zur Kenntnis:
- user only in CC, status updates, decisions already made, finished threads, past meeting invitations

⚪ Ignorierbar:
- newsletters, HR/IT mass mailings, marketing, automatic notifications, out-of-office replies, expired invitations

When in doubt between two levels, choose the higher one.

## Step 4 – Output (German, short)
Start with one line: Zeitraum, Anzahl gelesener E-Mails, Verteilung (🔴 x / 🟡 x / 🔵 x / ⚪ x).

### 🔴 Sofort beantworten
Table: Nr. | Von | Betreff | Worum geht es (1 Satz) | Was wird von dir erwartet | Frist

### 🟡 Diese Woche
Same table.

### 🔵 Zur Kenntnis
One line per thread: Von – Betreff – Kernaussage in 1 Satz.

### ⚪ Ignorierbar
Counts by group only, no details (e.g. "HR-Rundmails: 4, Newsletter: 7, Systembenachrichtigungen: 12").

### 📅 Fristen und Termine
Chronological list of all deadlines and dates found: Datum – was – von wem.

### ✅ Bereits erledigt / beantwortet
One line each: Betreff – erledigt durch wen.

End with exactly one question: "Soll ich für die 🔴-Mails Antwortentwürfe vorbereiten?"
Keep every summary to one sentence. No long quotes from emails.
