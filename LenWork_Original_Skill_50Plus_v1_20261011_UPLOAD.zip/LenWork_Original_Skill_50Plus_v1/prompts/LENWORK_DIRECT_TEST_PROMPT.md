# LenWork-Prompt: bestehender Connector, KEIN lokaler Export

Benutze meinen Original-Skill `inbox-urlaub-rueckblicke-v2` mit den unveränderten Step-2-, Step-3- und Step-4-Regeln und der unveränderten `absender.md`.

Ziel: Alle Inbox-Nachrichten meines explizit genannten Zeitraums erfassen und danach vollständig priorisieren – auch wenn es mehr als 50 sind.

Nutze ausschließlich autorisierte READ-ONLY-Aufrufe über `msgraph_email` mit `count=50` und rekursiver **Kalendertags**-Partitionierung (Step 1b). Bei jedem 50er-Ergebnis erneut teilen, solange Tagesgranularität dies zulässt. 50 Treffer an EINEM einzelnen Kalendertag sind `UNRESOLVED`, niemals `COMPLETE`. Bei solchen Überläufen stattdessen den lokalen Outlook-Export als Option nennen. Dedupliziere anhand stabiler Message-IDs und dokumentiere Anzahl API-Aufrufe und ungeklärte Tage.

ÄNDERE NIEMALS die originalen Regeln für ROT/GELB/BLAU/WEISS. Nimm keine neue Einstufungslogik aus QA-Versionen auf. Bei unvollständigem Abruf nur eine deutlich deklarierte Teilauswertung. Keine Schreiboperationen.
