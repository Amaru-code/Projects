# Inbox catch-up after absence (Urlaubs-Rückblick)

## Goal
When the user comes back from vacation or another absence, read the emails received during that time and give a prioritized overview in German: what needs an answer now, what can wait, what is just for information, and what can be ignored.

## Hard rules
- READ-ONLY. Never send, reply, forward, delete, move, flag, categorize or mark any email as read. Drafts only if the user asks for them afterwards, and only shown in the chat.
- Output language is ALWAYS German, even if the user writes in English or the emails are in English.
- Use only what is in the emails. Do not invent deadlines, intentions or facts. If something is unclear, write "unklar".
- Before classifying anything, read the file absender.md from this skill (sender and subject rules). Its rules override your own judgment.

## Step 1 – Scope
- If the user gives a period (e.g. "Urlaub 22.09.–06.10."), use exactly that period.
- Otherwise: all UNREAD emails in the Inbox from the last 14 days. State this assumption in the first line of the answer.
- Inbox only, plus subfolders the user names explicitly. Skip Junk, Deleted Items and Archive.

## Step 1b – Mehrfachabruf über das vorhandene `msgraph_email`-Tool (READ-ONLY)

Dieses Kapitel regelt **nur die Beschaffung der E-Mails**. Es ändert keine Priorität, Absenderregel oder Ausgabevorgabe aus Step 2–4. Das Tool ist pro `list`-Aufruf auf `count: 50` begrenzt. Die 50 sind KEINE Gesamtgrenze des Skills.

1. Für den durch Step 1 festgelegten Scope `msgraph_email` mit `action: list`, `folder: inbox`, `count: 50`, korrekt gesetztem `unread_only` und dem gewünschten `date_range` abfragen. Der ursprüngliche Standard bleibt `unread_only: true`; nur bei ausdrücklichem Wunsch nach gelesenen und ungelesenen E-Mails `unread_only: false` verwenden. Keine Parameter erfinden.
2. **Weniger als 50 Treffer** für ein nachweislich wirksam gefiltertes Intervall: vorläufig vollständiges Blatt. **Genau 50 Treffer:** nicht als vollständig behaupten; in zwei aufeinanderfolgende, disjunkte Kalendertagsintervalle aufteilen und beide abfragen. Die Aufteilung wiederholen, bis alle Blätter <50 haben.
3. Ein Einzeltag mit genau 50 Treffern bleibt `UNRESOLVED`, denn `date_range` hat nach der LenWork-Diagnose nur Tagesgranularität. Ohne belegbar vollständige andere Partition darf keine vollständige Auswertung behauptet werden.
4. Ausschließlich Blattdaten zusammenführen, anhand stabiler Message-IDs deduplizieren und tatsächliche Anzahl der Tool-Abrufe sowie nicht vollständig auflösbare Tage dokumentieren. Eine fehlende/instabile ID oder Tool-Fehler bedeutet `FETCH_STATUS=INCOMPLETE`.
5. Gilt `FETCH_STATUS=COMPLETE_UNDER_TOOL_CONTRACT`, fahre mit dem **unveränderten Step 2** fort. Dies ist keine atomare Snapshot-Garantie für das Postfach. Bei `INCOMPLETE` transparent nur als Teilauswertung berichten und ggf. Step 1c anbieten.

## Step 1c – Optionaler PowerShell-Export für mehr als 50 E-Mails an EINEM Tag

Nur wenn der Nutzer den lokalen Export ausdrücklich verwendet oder anbietet: `scripts/Export-InboxReadOnly.ps1` auf dem **eigenen Windows-Rechner mit geöffnetem KLASSISCHEM Outlook** ausführen lassen. LenWork kann das Skript nicht in seiner abgeschotteten Sandbox für Outlook auf dem Rechner ausführen. Das Skript liest lokal den Inbox-Ordner und schreibt strukturierte Daten in lokale Batch-Dateien – keine Outlook-Schreiboperationen.

1. Vor Verwendung sicherstellen, dass Export, lokale Dateiablage und Upload geschäftlicher E-Mails in die genehmigte LenWork-Umgebung zulässig sind. Keinen Export in öffentliche KI-Dienste, fremde Cloudspeicher oder diesen Chat hochladen.
2. `manifest.json` und sämtliche `mail_batch_*.jsonl`-Dateien bzw. `mail_batch_*.md` aus **demselben** Lauf einlesen. Falls die Python-Ausführung verfügbar ist, zuerst `scripts/verify_export.py` auf den Exportordner anwenden. Bei fehlenden Dateien, ungültigem Hash/Manifest, ID-Duplikaten oder `status != COMPLETE_LOCAL_STORE`, NICHT vollständige Abdeckung behaupten.
3. Jede eindeutige Nachricht in einer Verarbeitungsliste erfassen und in Batches zu etwa 20–30 dem **unveränderten Step 2–4** zuführen. Nicht nach 50 oder 100 abbrechen. Die Priorität wird ausschließlich nach dem Original-Skill und `absender.md` vergeben – **nicht durch PowerShell oder Python**.
4. Der Standardexport enthält nur Metadaten und kurze Vorschauen. Für Fälle, die laut Original-Step-2 den Volltext benötigen, die lokale Nachlieferung der betreffenden IDs über `-BodyIdsFile` nutzen (nur wenn genehmigt) oder die Original-Microsoft-365-Integration READ-ONLY für passende Detailnachrichten verwenden. Falls Details fehlen, "unklar" statt halluzinieren.
5. Bei gemischten Quellen nicht unbesehen Duplikate zusammenführen: Outlook-EntryIDs und Graph-IDs können verschiedene Identifikatoren derselben Nachricht sein. `COMPLETE_LOCAL_STORE` bedeutet vollständig **für die im klassischen Outlook erreichbaren lokalen Inbox-Objekte im angegebenen Zeitraum**, nicht zwingend alle Cloud-Nachrichten des M365-Postfachs.

**Wichtig:** Der Scriptweg ersetzt nur Step 1b (Datenabruf), NICHT Step 2 (Analyse), Step 3 (Prioritäten) oder Step 4 (Antwortformat). Wenn kein lokales COM-Outlook verfügbar ist, weiterhin die bewährte `msgraph_email`-Intervallpartitionierung nutzen.

## Step 2 – Metadata first, full text only when needed
1. List for every email: sender, whether the user is in To or only in CC, subject, received date, importance flag, attachments yes/no, conversation/thread, short preview.
2. Apply absender.md: everything matching "Ignorieren" goes straight to ⚪ without opening it.
3. Group by conversation/thread. Judge each thread by its LATEST message. If the question in a thread was already answered or solved by someone else, put it under "Bereits erledigt" and name who solved it.
4. If possible, check Sent Items for the same period: if the user already replied to a thread, mark it as "bereits beantwortet".
5. Open the full text only for emails that cannot be clearly classified as 🔵 or ⚪ from the metadata.
6. Work in batches of about 20–30 emails. Do not stop early; process all emails in scope.

## Step 3 – Priorities
🔴 Sofort beantworten (today):
- a direct question or request to the user (user in To)
- a deadline that has passed or is within the next 2 working days (mark passed ones as "ÜBERFÄLLIG")
- anything from a VIP in absender.md that contains a question or a deadline
- reminders and escalations ("Erinnerung", "dringend", "nochmals", 2nd follow-up)
- meeting requests for the next days that still need a response

🟡 Diese Woche:
- a request to the user without a tight deadline
- a deadline within the next ~2 weeks
- coordination where the user's input is expected

🔵 Zur Kenntnis:
- user only in CC, status updates, decisions already made, finished threads, past meeting invitations

⚪ Ignorierbar:
- newsletters, HR/IT mass mailings, marketing, automatic notifications, out-of-office replies, expired invitations

When in doubt between two levels, choose the higher one.

## Step 4 – Output (German, short)
Start with one line: Zeitraum, Anzahl gelesener E-Mails, Verteilung (🔴 x / 🟡 x / 🔵 x / ⚪ x).

### 🔴 Sofort beantworten
Table: Nr. | Von | Betreff | Worum geht es (1 Satz) | Was wird von dir erwartet | Frist

### 🟡 Diese Woche
Same table.

### 🔵 Zur Kenntnis
One line per thread: Von – Betreff – Kernaussage in 1 Satz.

### ⚪ Ignorierbar
Counts by group only, no details (e.g. "HR-Rundmails: 4, Newsletter: 7, Systembenachrichtigungen: 12").

### 📅 Fristen und Termine
Chronological list of all deadlines and dates found: Datum – was – von wem.

### ✅ Bereits erledigt / beantwortet
One line each: Betreff – erledigt durch wen.

End with exactly one question: "Soll ich für die 🔴-Mails Antwortentwürfe vorbereiten?"
Keep every summary to one sentence. No long quotes from emails.
