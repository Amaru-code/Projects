# LenWork – Original-Skill + mehr als 50 E-Mails (v1)

## Status und Entscheidung

**Die 50er-Gesamtgrenze ist bereits gelöst:** Im LenWork-Livetest wurden 266 Mails per Mehrfachabruf und 128 Mails inklusive Priorisierung verarbeitet. Bis zu 49 Treffer je disjunktem Tages-/Mehrtags-Intervall reichen für die bestehende native Lösung.

**Weiterhin offen:** Mehr als 50 Inbox-Mails an EINEM Kalendertag, weil `msgraph_email` nur 50 Treffer pro Aufruf und nur Datumsfilter auf Tagesgranularität kennt.

**Ergänzung durch Skripte:** Das hier mitgelieferte `Export-InboxReadOnly.ps1` liest statt `msgraph_email` den Inbox-Ordner im lokal laufenden **klassischen Outlook für Windows** über COM. Es schreibt reine lokale Datendateien in Batches. `verify_export.py` prüft anschließend Integrität und Vollständigkeit *des lokalen Exports*. LenWork priorisiert weiterhin selbst nach exakt denselben Originalregeln. Python/PowerShell enthalten KEINEN Priorisierungsalgorithmus.

## Unveränderte Regeln

- `docs/ORIGINAL_SKILL.md`: Originaltext aus der ersten Nutzer-Nachricht als Referenz.
- `SKILL.md`: Ausschließlich der Abschnitt **Step 1b (Abruf)** wurde durch die geprüfte Intervallstrategie ersetzt und **Step 1c (optionaler lokaler Export)** ergänzt. Alle übrigen Passagen sind exakt aus der Originaldatei übernommen.
- `absender.md`: Inhalt wie vom Nutzer bereitgestellt; nicht umgeschrieben.
- Der enthaltene Test `tests/test_export.py` vergleicht Step 2–4 bytegenau gegen das Original.

## Variante A – beste Standardlösung: LenWork Connector ohne zusätzlichen lokalen Aufwand

1. Erstelle in LenWork eine Testkopie des bestehenden Skills (kein produktives Überschreiben ohne Abnahme).
2. Übernimm den **Step-1b/Step-1c-Abschnitt** aus `SKILL.md`. Lass die restlichen Regeln des bestehenden Skills und die existierende `absender.md` unverändert.
3. Starte LenWork mit `prompts/LENWORK_DIRECT_TEST_PROMPT.md`.
4. Das funktioniert für >100 E-Mails verteilt über mehrere Tage; bei 50+ auf einem Tag ist die Abdeckung UNRESOLVED.

## Variante B – 100+ E-Mails auch an EINEM Tag: klassisches Outlook + PowerShell

**Voraussetzungen:** Windows, Windows PowerShell 5.1, geöffnetes **klassisches Outlook**, ausreichende Synchronisation/Onlineverfügbarkeit der relevanten Nachrichten; Unternehmensfreigabe für lokalen Export UND Upload in den genehmigten LenWork-Workspace. Keine neuen Graph-OAuth-Tokens und keine Adminrechte für den Script-Ansatz benötigt; lokale Office-Policies können COM blockieren.

1. Teste die lokale Verbindung:

   ```powershell
   & '.\scripts\Test-ClassicOutlookCom.ps1'
   ```

2. Aus dem entpackten Projektordner (PowerShell) einen Testtag exportieren. **Datumsangaben sind inklusiv und beziehen sich auf die lokale Windows-Zeitzone.** Der Beispieltag ist nur ein Platzhalter:

   ```powershell
   & '.\scripts\Export-InboxReadOnly.ps1' -StartDate '2026-10-11' -EndDate '2026-10-11' -UnreadOnly -BatchSize 25
   ```

   Für expliziten Zeitraum auch gelesene Mails einbeziehen: `-UnreadOnly` weglassen. Bei mehreren Outlook-Konten lässt sich mit `-MailboxName 'ANZEIGENAME'` die gewählte klassische Outlook-Store-Ansicht festlegen. Optional `-OwnAddress 'ich@firma.de'` für eine genaue To/CC-Erkennung, wenn Outlook diese nicht selbst ermitteln kann.

3. Das Skript meldet nur technische Zahlen und einen lokalen Ausgabeordner `InboxExport_...`. Dort liegen `manifest.json`, JSONL und Markdown-Lesekopien in `batches/`. Niemals die vertraulichen Exportdateien in diesen Chat oder unfreigegebene Cloud-Dienste hochladen.

4. Integrität lokal prüfen:

   ```powershell
   python .\scripts\verify_export.py 'PFAD_ZUM_AUSGABEORDNER\InboxExport_...'
   ```

   Wenn Python lokal nicht vorhanden ist, kann diese reine Standardbibliotheksprüfung im genehmigten LenWork-Python-Tool ausgeführt werden, sofern es die Dateien sehen kann. **Nicht annehmen**, dass Dateien aus dem PC automatisch in der LenWork-Cloud vorliegen.

5. Lade **nur in euren freigegebenen internen LenWork-Workspace** `manifest.json` plus alle `mail_batch_*.md` desselben Laufs hoch. Lade JSONL zusätzlich nur, falls der Python-Validator in LenWork alle Dateien direkt lesen soll. Die `.md`-Dateien sind exakte menschlich lesbare Datenkopien der JSONL-Nachrichten und dürfen nicht doppelt gezählt werden. Benutze `prompts/LENWORK_IMPORT_PROMPT.md`.

6. Unklare E-Mails benötigen laut ursprünglichem Step 2 den Volltext. LenWork kann die benötigten `message_id`s als `body_ids.txt` nennen. Dann lokal nachliefern:

   ```powershell
   & '.\scripts\Export-InboxReadOnly.ps1' -StartDate '2026-10-11' -EndDate '2026-10-11' -UnreadOnly -BodyIdsFile '.\body_ids.txt'
   ```

   Es entsteht ein **separater, gezielter** Export `mode=BODY_SUPPLEMENT` mit nur diesen Volltexten. Dies ist keine neue vollständige Inbox-Kopie und muss per Message-ID mit dem Grundlauf verbunden werden.

7. Entferne nach Freigabe/Verwendung lokale Klartext-Exports gemäß den Aufbewahrungs- und Datenschutzregeln eures Unternehmens.

## Grenzen / keine falschen Versprechen

- PowerShell läuft auf dem lokalen PC. Das LenWork-JavaScript-/Python-Sandbox-Tool erhielt im Diagnosebericht **keinen** Outlook-/Graph-Netzzugriff und kann den lokalen Outlook-COM-Export nicht selbst ausführen. Ablegen von `.ps1` oder `.py` in einem Skill verleiht LenWork keinen Zugriff auf den Benutzer-PC.
- Das klassische Outlook kann je nach Cached Mode/offline/Sync-Status weniger Elemente als der Exchange-Cloud-Store enthalten. `COMPLETE_LOCAL_STORE` belegt deshalb nur den erfolgreichen lokalen Scan innerhalb des angezeigten Outlook-Stores, **nicht automatisch absolute Microsoft-365-Cloud-Vollständigkeit**.
- `recipient_placement=unknown` bedeutet: To/CC-Eigenschaft nicht sicher aus Adresse auflösbar. Nicht einfach TO behaupten.
- Dieser Export enthält echte Korrespondenz. Bitte nur mit IT-/Compliance-Freigabe übertragen.
- Die Python- und PowerShell-Skripte vergeben weder Prioritäten noch Kategorien. Die originalen vier Stufen bleiben LenWorks Aufgabe.

## Technischer Abnahmetest

1. Lokal `python -m unittest discover -s tests -v` ausführen.
2. Vor produktiver Nutzung Windows-`Test-ClassicOutlookCom.ps1` und einmal `Export-InboxReadOnly.ps1` (mit wenigen Testmails) ausführen, anschließend `verify_export.py` und den LenWork-Import prüfen.
3. Bei >50 am selben Tag den vollständigen Bestand und die `unique_records` des Manifestes mit dem in LenWork verarbeiteten Ledger vergleichen.

**Noch nicht durch uns verifiziert:** Ausführung von COM auf deinem Windows-Rechner, Unternehmensfreigabe des Exports und Upload-/Script-Pfad in LenWork. Wir liefern einen getesteten Python-Validator und eine nicht auf Windows ausführbare PowerShell-Implementierung als Integrationskandidat.
