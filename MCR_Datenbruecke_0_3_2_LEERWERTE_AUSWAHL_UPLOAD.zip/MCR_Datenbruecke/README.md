# MCR Mail-Assistent 0.3.2 — leere Merkmale und echte Member-Auswahl

## Wichtig: ein neues Mapping erzeugen

Die vorige Version sperrte eine Bestandszeile bereits dann, wenn C, D oder E leer war. Das passte nicht zur ursprünglichen Beschreibungsregel **„nur bei 1 das jeweilige Kürzel ergänzen“**. 0.3.2 ergänzt die ausdrücklich bestätigte Regel `ONE_ONLY_BLANK_OMIT_V1`:

| Zellinhalt C/D/E | Behandlung im neuen Export |
|---|---|
| 1 | Zugehöriges Kürzel aufnehmen |
| 0 | Kein Kürzel |
| Leer oder nur Leerraum | Kein Kürzel; im JSON **null**, mit Spaltennachweis |
| Andere Werte, Excel-Fehler, fehlender numerischer Formelcache | Weiterhin sperren |

Das ist **keine Feststellung über einen Leistungsanspruch** und keine Änderung der Excel-Datei. Leer wird nicht als gespeicherte 0 ausgegeben. Der Export fragt Quelle, L=USC und diese Regel gemeinsam ab. Ohne Bestätigung wird kein neues Mapping geschrieben. Wenn gar kein Merkmal 1 ist, bleibt `NO_PLAN` zur fachlichen Prüfung bestehen. Ein fehlender USC oder eine doppelte Kennung wird nicht durch die neue Regel freigegeben.

**Alte JSON-Dateien werden weder verändert noch automatisch entsperrt.** Alte gesperrte Einträge enthalten nicht alle benötigten Quellwerte. Deshalb muss der Export einmal aus der Original-XLSX wiederholt werden.

## Der nächste Lauf — in dieser Reihenfolge

1. ZIP vollständig entpacken. Den enthaltenen Ordner **MCR_Datenbruecke** mit dem bisherigen gleichnamigen Ordner zusammenführen. Gelieferte Paketdateien ersetzen. Den bisherigen Ordner **nicht löschen**; `private_data`, eigene XLSX und Node-Runtime behalten.
2. **MAPPING_ERSTELLEN.cmd** starten. Der Starter zeigt Version **0.3.2** und verwendet dieselbe portable Node-Installation. Bei der Excel-Abfrage die bereits verwendete XLSX angeben. Quelle und Spalten kontrollieren; die angezeigte Regel mit **JA** bestätigen.
3. Am Ende den **neu angezeigten** Dateinamen hinter `MAPPING ERZEUGT:` merken. Der neue Snapshot liegt neben dem alten in `private_data`. Kein altes JSON bearbeiten oder umbenennen, um es künstlich zu entsperren.
4. In COMARCH genau ein Ticket öffnen und selbst **Bearbeiten** wählen. Dies kann bereits echte Vorgangsdaten verändern. Die Original-Mail herunterladen und speichern.
5. **MAIL_ASSISTENT_OEFFNEN.cmd** starten. Gesamten Code aus Notepad in die Edge-DevTools-Konsole der COMARCH-Seite (Kontext `top`) kopieren und ausführen. Schutzrichtlinien nicht umgehen. Im Panel muss **0.3.2** stehen.
6. Schritt 1: das **NEUE** JSON laden und Quelle bestätigen. Die Anzeige muss **„Nur 1 → Kürzel; 0 / leer → kein Kürzel (leer bleibt null)“** enthalten. Eine Meldung **„ALTES STRICT-Mapping“** bedeutet, dass die alte Datei geladen wurde.
7. Schritt 2: die gespeicherte Original-MSG dieses Tickets auswählen. Schritt 3: den richtigen Namen prüfen. Der Suchtext lautet **Nachname Vorname**. Ein MercerID-Hinweis darf bestätigt/ergänzt werden; niemals die Ticketnummer dafür verwenden.
8. Die Bestätigung **„Mail gehört zu diesem Ticket ... geprüft“** setzen. **Member suchen** klicken. Bei einem technisch gebundenen, ausreichend nachgewiesenen Einzeltreffer löst der Assistent **einen** Klick auf den echten Vorschlag aus und wartet auf die übernommenen Stammdaten. Bei mehreren Treffern wählst **du** in COMARCH. Anschließend wird der Abgleich fortgesetzt.
9. Schritt 4 zeigt die Beschreibung mit verwendeten Spaltenwerten. Bei Formeln ist die separate Prüfung gespeicherter Ergebnisse nötig. Mit **Beschreibung in COMARCH einsetzen** wird nur eine leere bzw. bereits identische Beschreibung befüllt; abweichender vorhandener Text bleibt geschützt. **Kein Versand, kein Ticket-Speichern.**

Wenn der richtige Member bereits ausgewählt ist: nach Laden und Prüfen von Mapping, Mail und Namen **„Meine Member-Auswahl bestätigen → weiter“** verwenden. Die Person nicht extra entfernen und erneut suchen.

### Weshalb die Auswahl vorher ausblieb

Der vorige Einzeltreffer-Code erkannte nur ausdrücklich verknüpfte ARIA-Listen mit einer deklarierten Gesamtzahl. Die alte ICEfaces-Komponente benutzt stattdessen unter anderem eine eigene Autocomplete-Registry und ein an das Member-Feld gebundenes `_div`-Element. Außerdem wurde der Bestands-Lookup irrtümlich schon vor der Auswahl aufgerufen. Ein gesperrter Bestand konnte deshalb eine ansonsten mögliche Auswahl verhindern.

0.3.2 trennt die Schritte: **Identität prüfen → tatsächlichen Vorschlag auswählen → übernommene MercerID prüfen → Bestand auswerten**. Eine Bestands­sperre verhindert nicht mehr die Auswahl, sondern erscheint anschließend ausdrücklich in Schritt 4.

Der zusätzliche ICEfaces-Adapter prüft das konkrete Eingabefeld, dessen Komponenteninstanz, das Ergebnis-DIV, die Zeilenanzahl und die zum Vorschlag gehörende Indexeigenschaft. Er schreibt **keinen versteckten Auswahlindex**, ruft **keinen direkten Submit** auf und füllt nicht bloß einen ausgewählten Membertext vor. Er klickt auf den echten gebundenen Ergebnis-DIV.

**Grenze der automatischen ICEfaces-Auswahl:** Die Komponente kann Ergebnisse begrenzen. Ein angezeigter Einzeltreffer beweist daher nicht allein die Eindeutigkeit im gesamten Bestand. Deshalb braucht diese Route zusätzlich die **oben fachlich geprüfte MercerID**, exakten passenden Vor-/Nachnamen und eine lesbare MercerID-Stammdatenanzeige zur anschließenden Übernahmeprüfung. Bei mehreren gelieferten Treffern wird auch mit einer Kennung nicht eigenständig einer ausgewählt.

Das tatsächliche COMARCH-System wurde hier nicht gestartet. Wenn dessen ausgelieferte Komponente vom geprüften Adaptervertrag abweicht oder synthetische Klicks nicht akzeptiert, bleibt die manuelle Auswahl bestehen. Die Oberfläche beschreibt diese Grenze statt einen Erfolg zu melden, der nur aus einem formatierten Suchfeld abgeleitet wurde.

## Falls die automatische Auswahl weiterhin wartet

Den offenen COMARCH-Vorschlag nicht sofort schließen. Im Assistenten **Auswahlliste prüfen** anklicken. Der Knopf versucht den Fokus der Liste zu erhalten. Anschließend **Diagnose-ZIP** anklicken. Das ZIP enthält vordefinierte Statuswerte/Anzahlen (Registry gefunden, Elementbindung, gelieferte Zeilen, ausstehende Übernahme), keine Namen, Kennungen, DOM-Texte oder Bestandswerte. Nur dieses eine `*_UPLOAD.zip` weitergeben.

Den richtigen COMARCH-Vorschlag darfst du weiterhin selbst anklicken. Danach sollte der Ablauf automatisch weitergehen. Bei nicht beobachteter Tastatur-/Mausauswahl **Meine Member-Auswahl bestätigen → weiter** drücken. Leere oder widersprüchliche MercerID-Stammdaten werden dadurch nicht übergangen.

## Quellenprüfung und lokale Bestandssperren

**MAPPING_PRUEFEN.cmd** bleibt verfügbar. Es liest das ausgewählte JSON und optional dessen SHA256-identische XLSX. Es respektiert die im jeweiligen Snapshot gebundene Regel. Alte STRICT-Snapshots bleiben dort wegen leerer Flags gesperrt; neue Snapshots erlauben die dokumentierten Leerwerte. Keine Änderung an Quelle/JSON.

C=1 → DC, D=1 → PP+, E=1 → DB+; Reihenfolge DC;PP+;DB+. USC kommt ausschließlich aus L. Beispiel mit fiktiven Werten C=leer, D=1, E=0, L=10: **USC 10/ PP+**. Dieses Beispiel ist kein Nachweis über die Werte einer realen Person.

## Unveränderte Grenzen

Nur vorhandene Node.js-Version ab 22.15, keine npm-Abhängigkeiten oder automatische Installation. Die bekannte portable Runtime wird wiederverwendet. Die Original-XLSX wird nur gelesen. Ein Snapshot ist keine automatische Bestätigung der Aktualität der Quelldaten.

MSG-Dateien mit gespeichertem Klartext werden unterstützt; RTF-/HTML-only und abweichende/geschützte Varianten sind nicht vollständig abgedeckt. Keine externen Mailanhänge/Bilder öffnen. Bei Bedarf den Text bewusst in das alternative Eingabefeld kopieren. Namen und Kennungen aus Mails bleiben Hinweise; Absender kann von betroffener Person abweichen. Keine Geschlechtsableitung aus Vornamen, kein automatischer Empfängerwechsel.

Die Bestand-/Maildateien gelangen beim Auswählen in den Speicher der COMARCH-Seite. Dies ist **keine isolierte Datenschutz-Sandbox**. Nur im betrieblich freigegebenen Kontext verwenden. Keine externe KI-Auswertung/Uploads im Assistenten. Eine freigegebene Member-Suche/Auswahl kann normale COMARCH-Anfragen auslösen. Der Ordner `private_data` ist nicht verschlüsselt und gehört nicht in Git oder einen Chat-Upload.

Kategorien, Signatur, Antwort, Empfängerprüfung, Senden, Dialoge, Ticket-Speichern und Queue-Durchlauf bleiben **manuell**. Der Assistent schließt kein Ticket. Vor dem nächsten Ticket **Neuer Fall**. Bei Seitenwechsel den Helfer ggf. neu einsetzen und Mapping laden. Nach Nutzung **Schließen**, insbesondere vor Weitergabe des PCs.

## Tests und Nachweise

Aktueller Nachweis: **docs/BLANKSELECT_TESTBERICHT.md**. Ältere Berichte unter `docs` beschreiben frühere Versionen, nicht den aktuellen Live-Stand. **SELBSTTEST.cmd** prüft Paket und Node-Tests lokal. Die beigefügten Python/Playwright-Browsertests sind Entwicklernachweise; dafür ist keine zusätzliche Installation beim Anwender nötig.
