"""Synthetic browser tests, not live COMARCH or Windows qualification.
Uses the existing about:blank injection harness; SHA-256 delegated to Python
because the container's navigation policy is left unchanged. No production shim.
"""
import re,json,hashlib,zipfile,io,pathlib,time
from playwright.sync_api import sync_playwright
R=pathlib.Path(__file__).resolve().parents[1]
results=[]
def mark(name):results.append({'name':name,'status':'PASS'});print('PASS',name,flush=True)
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True)
 page=browser.new_page(viewport={'width':1450,'height':1080})
 page.set_default_timeout(10000)
 original_wait=page.wait_for_function
 page.wait_for_function=lambda expression,**kw: original_wait(expression,polling=100,**kw)
 html=(R/'MAIL_DEMO.html').read_text();scripts=re.findall(r'<script>([\s\S]*?)</script>',html)
 page.set_content(re.sub(r'<script[^>]*>[\s\S]*?</script>','',html))
 for script in scripts:page.evaluate(script+"\n;void 0;")
 page.expose_function('__testSha',lambda b:list(hashlib.sha256(bytes(b)).digest()))
 page.evaluate("Object.defineProperty(crypto,'subtle',{value:{digest:async (_,data)=>new Uint8Array(await __testSha(Array.from(new Uint8Array(data)))).buffer}})")
 bundle=(R/'COMARCH_MAIL_ASSISTENT.js').read_text();page.evaluate(bundle)
 assert page.evaluate('MCR_MAIL.version')=='0.3.2';mark('New assistant installs with version 0.3.2')
 page.evaluate(bundle);assert page.locator('#__mcr_mail_assistant_v3').count()==1;mark('Reinstallation closes old listeners and removes duplicate UI')
 req=[];page.on('request',lambda r:req.append(r.url))
 root=page.locator('#__mcr_mail_assistant_v3')
 root.locator('#mapFile').set_input_files(str(R/'examples/DEMO_mapping.json'))
 page.wait_for_function('MCR_MAIL.diagnostic().mapping.loaded')
 root.get_by_label('Diese Bestandsversion',exact=False).check();mark('Existing V1 JSON mapping is accepted and source review advances step')
 def load_mail():
  root.locator('#mailFile').set_input_files(str(R/'examples/DEMO_Mail.msg'))
  page.wait_for_function('MCR_MAIL.diagnostic().mail.nameCandidates === 1')
 def approve():root.get_by_label('Mail gehört zu diesem Ticket',exact=False).check()
 def clear_form():page.evaluate("document.getElementById('mainForm:member-value-id').value='';document.getElementById('mainForm:j_id7019').value='';document.getElementById('suggestions').hidden=true;")
 def reset():page.evaluate('MCR_MAIL.resetCase()');clear_form()
 load_mail();assert root.locator('#firstName').input_value()=='Max';assert root.locator('#lastName').input_value()=='Mustermann';assert root.locator('#ticketId').input_value()=='90000001';mark('MSG file picker parses plain text and pre-fills reviewable address-block name')
 root.get_by_role('button',name='Member suchen',exact=True).click();assert page.evaluate('MCR_MAIL.diagnostic().lastError')=='MAIL_REVIEW';mark('No member search before person / ticket confirmation')
 approve();root.get_by_role('button',name='Member suchen',exact=True).click()
 assert page.locator('[id="mainForm:member-value-id"]').input_value()=='Mustermann Max';mark('Search writes surname space firstname into the known member field')
 page.wait_for_function('MCR_MAIL.diagnostic().flow.lookupReady',timeout=9000)
 assert 'USC 10/ PP+' in root.locator('.result').inner_text();assert page.evaluate('MCR_MAIL.diagnostic().flow.selectionMode')=='LINKED_SINGLE';mark('Explicitly linked completed single-result widget selected and lookup continues')
 assert page.locator('[id="mainForm:j_id7019"]').input_value()=='';assert page.evaluate('[demoSends,demoSaves]')==[0,0];mark('Lookup performs no automatic description write, send or save')
 root.get_by_role('button',name='Beschreibung in COMARCH einsetzen',exact=True).click();assert page.locator('[id="mainForm:j_id7019"]').input_value()=='USC 10/ PP+';mark('Confirmed description insertion with semantic label succeeds')
 raw=bytes(page.evaluate('async()=>Array.from(await MCR_MAIL.diagnosticBytes())'))
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  assert z.testzip() is None
  for line in z.read('SHA256SUMS.txt').decode().splitlines():digest,name=line.split('  ');assert hashlib.sha256(z.read(name)).hexdigest()==digest
  text=z.read('diagnostic.json').decode()
  for s in ['Max','Mustermann','99900001','90000001','example.invalid','DEMO_Mail','USC 10/ PP+']:assert s not in text,s
 mark('Diagnostic ZIP CRC / hashes valid and person/mail/mapping values absent')
 page.evaluate("document.getElementById('mainForm:member-value-id').value='Anders Eva (INTL01-99900002)'")
 page.wait_for_function("MCR_MAIL.diagnostic().lastError === 'MEMBER_CHANGED'")
 assert root.get_by_role('button',name='Beschreibung in COMARCH einsetzen',exact=True,include_hidden=True).is_disabled();mark('Member change invalidates previously calculated result')
 reset();page.evaluate("demoMode='many'");load_mail();approve();root.get_by_role('button',name='Member suchen',exact=True).click()
 page.wait_for_timeout(2500);assert not page.evaluate('MCR_MAIL.diagnostic().flow.lookupReady');assert page.locator('[id="mainForm:member-value-id"]').input_value()=='Mustermann Max';mark('Multiple COMARCH results are not auto-selected')
 page.locator('#suggestions [role=option]').first.click();page.wait_for_function('MCR_MAIL.diagnostic().flow.lookupReady',timeout=6000)
 assert page.evaluate('MCR_MAIL.diagnostic().flow.selectionMode')=='USER_CLICK';mark('Real user click on one of multiple candidates resumes lookup automatically')
 reset();page.evaluate("demoMode='legacy'");load_mail();approve();root.get_by_role('button',name='Member suchen',exact=True).click();page.wait_for_timeout(2400)
 assert not page.evaluate('MCR_MAIL.diagnostic().flow.lookupReady');mark('Unqualified legacy list does not trigger an automatic click')
 page.evaluate("document.getElementById('mainForm:member-value-id').value='Mustermann Max (INTL01-99900001)'")
 page.wait_for_timeout(1500);assert not page.evaluate('MCR_MAIL.diagnostic().flow.lookupReady');mark('A programmatically changed member value alone is not selection proof')
 root.get_by_role('button',name='Meine Member-Auswahl bestätigen',exact=False).click();page.wait_for_function('MCR_MAIL.diagnostic().flow.lookupReady');mark('Explicit selection confirmation resumes after keyboard/unobserved choice')
 page.evaluate("document.getElementById('mainForm:j_id7019').value='BESTEHENDE BESCHREIBUNG'")
 root.get_by_role('button',name='Beschreibung in COMARCH einsetzen',exact=True).click();assert page.evaluate('MCR_MAIL.diagnostic().lastError')=='DESCRIPTION_EXISTS';assert page.locator('[id="mainForm:j_id7019"]').input_value()=='BESTEHENDE BESCHREIBUNG';mark('Existing description is not overwritten')
 reset();load_mail();approve();page.evaluate("document.getElementById('mainForm:member-value-id').value='Mustermann Eva (INTL01-99900001)'")
 root.get_by_role('button',name='Meine Member-Auswahl bestätigen',exact=False).click();assert page.evaluate('MCR_MAIL.diagnostic().lastError')=='MEMBER_NAME_CONFLICT';mark('Same ID-shaped field with wrong name is blocked')
 reset();load_mail();approve();page.evaluate("document.getElementById('mainForm:member-value-id').value='Mustermann Max (INTL01-99900001)'")
 root.get_by_role('button',name='Meine Member-Auswahl bestätigen',exact=False).click();assert page.evaluate('MCR_MAIL.diagnostic().flow.lookupReady')
 page.evaluate("document.querySelector('main p b').nextElementSibling.textContent='90000002'")
 page.wait_for_function("MCR_MAIL.diagnostic().lastError === 'TICKET_CHANGED'");mark('Visible ticket identity change invalidates old lookup')
 reset();load_mail();approve();root.locator('#firstName').fill('Eva');assert not root.get_by_label('Mail gehört zu diesem Ticket',exact=False).is_checked();mark('Editing name invalidates prior identity confirmation')
 reset();page.evaluate("MCR_MAIL.setMail({format:'MANUAL',subject:'',senderName:'',senderEmail:'',body:'Name: Max Mustermann\\nClientEEID: 99900002',warnings:[]})")
 approve();page.evaluate("document.getElementById('mainForm:member-value-id').value='Mustermann Max (INTL01-99900001)'")
 root.get_by_role('button',name='Meine Member-Auswahl bestätigen',exact=False).click();assert page.evaluate('MCR_MAIL.diagnostic().lastError')=='MAIL_MEMBER_CONFLICT';mark('Explicit ID in mail must match selected member')
 reset();page.evaluate("MCR_MAIL.setMail({format:'MANUAL',subject:'',senderName:'',senderEmail:'',body:'Hier meine vollständige Adresse:\\nMax Mustermann\\n<script>window.BAD=true</script><img src=https://example.invalid/pixel>',warnings:[]})")
 assert not page.evaluate('!!window.BAD');assert len(req)==0,req;mark('Mail HTML is inert text and does not load tracking images or scripts')
 assert page.evaluate('[demoSends,demoSaves]')==[0,0];mark('No send / save calls in all test branches')
 reset();assert page.evaluate('MCR_MAIL.diagnostic().mapping.loaded');assert page.evaluate('MCR_MAIL.diagnostic().mail.plainText')==False;mark('New case clears mail/person state and retains reviewed mapping')
 # Tamper JSON leaves no active old mapping.
 obj=json.loads((R/'examples/DEMO_mapping.json').read_text());obj['payload']['entries']['99900001']['usc']='11';obj['payload']['entries']['99900001']['description']='USC 11/ PP+'
 err=page.evaluate("async s=>{try{await MCR_MAIL.loadMapText(s);return ''}catch(e){return e.code}}",json.dumps(obj));assert err=='MAP_HASH_MISMATCH';assert not page.evaluate('MCR_MAIL.diagnostic().mapping.loaded');mark('Tampered snapshot rejected and old lookup state invalidated')
 page.screenshot(path=str(R/'docs/BLANKSELECT_BASE_PREVIEW.png'),full_page=True)
 page.evaluate('MCR_MAIL.close()');assert page.locator('#__mcr_mail_assistant_v3').count()==0;assert not page.evaluate('!!window.MCR_MAIL');mark('Close removes timer, listeners, local data and panel API')
 browser.close()
(R/'docs/BLANKSELECT_BASE_BROWSER_TEST_RESULT.json').write_text(json.dumps({'environment':'Linux Chromium / injected synthetic about:blank DOM. SHA-256 delegated to Python hashlib by test harness. Native secure-context/file navigation, Windows Outlook and real COMARCH NOT tested. No browser policy changes.','tests':results},indent=2)+'\n')
