using System.Text;
using System.Text.RegularExpressions;
using Microsoft.VisualBasic.FileIO;

namespace Mcr.Ipp.Core;

public sealed record MonthFile(string Name, DateOnly Month, List<Dictionary<string, string?>> Rows, string? TariffColumn, SourceInfo Source)
{
    // Reference-keyed map survives PersonReview's filtered `with` copies; never renumber evidence rows.
    public IReadOnlyDictionary<Dictionary<string, string?>, int>? OriginalRecordNumbers { get; init; }
    public int? OriginalRecordCount { get; init; }
}
public static class MonthReader
{
    public static DateOnly ExtractMonth(string name)
    {
        var match = Regex.Match(Path.GetFileName(name), @"_(\d{2})(\d{4})(?:\D|$)");
        if (!match.Success) throw new IppException("MONTH_FILENAME", "TXT-Dateiname muss _MMJJJJ enthalten: " + Path.GetFileName(name));
        if (!int.TryParse(match.Groups[1].Value, out int m) || m < 1 || m > 12 || !int.TryParse(match.Groups[2].Value, out int y) || y < 2012 || y > 9998)
            throw new IppException("MONTH_INVALID", "Ungueltiger Dateimonat: " + Path.GetFileName(name));
        return new(y, m, 1);
    }
    public static MonthFile Read(SourceBlob blob, ContributionOptions options)
    {
        Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
        Encoding encoding = options.TextEncoding switch
        {
            "cp1252" => Encoding.GetEncoding(1252, EncoderFallback.ExceptionFallback, DecoderFallback.ExceptionFallback),
            "utf-8" => new UTF8Encoding(false, true),
            _ => throw new IppException("ENCODING_UNSUPPORTED", "Encoding muss cp1252 oder utf-8 sein.")
        };
        using var ms = new MemoryStream(blob.Bytes, false);
        using var parser = new TextFieldParser(ms, encoding, true) { TextFieldType = FieldType.Delimited, HasFieldsEnclosedInQuotes = true, TrimWhiteSpace = true };
        parser.SetDelimiters(";");
        var headers = parser.ReadFields()?.Select(h => h.Trim()).ToArray() ?? throw new IppException("TXT_EMPTY", "Leere TXT-Datei.");
        if (headers.Any(string.IsNullOrWhiteSpace) || headers.Distinct(StringComparer.Ordinal).Count() != headers.Length) throw new IppException("TXT_HEADERS", "Leere/doppelte TXT-Ueberschriften.");
        foreach (var req in new[] { "KDMA_IDENT", "ARBZEIT_PROZ", "BETRAG1", "BETRAG1_TYP", "ANSPRUCHSTYP" })
            if (!headers.Contains(req)) throw new IppException("TXT_SCHEMA", $"{blob.Info.Name}: Spalte {req} fehlt. Keine stille Fortsetzung.");
        var exact = new[] { "TARIFKLASSE", "TARIFKLASS", "TARIFKL", "TARIFCLASS", "TARIFFCLASS" };
        var tariffColumns = headers.Where(h => exact.Contains(Parse.Header(h)) || (Parse.Header(h).Contains("TARIF", StringComparison.Ordinal) && Parse.Header(h).Contains("KLASS", StringComparison.Ordinal))).ToList();
        if (tariffColumns.Count > 1) throw new IppException("TARIFF_AMBIGUOUS", "Mehrere moegliche Tarifklassenspalten.");
        if (tariffColumns.Count == 0 && !options.AllowMissingTariff && !options.ReviewTariffIssues) throw new IppException("TARIFF_COLUMN_MISSING", "Tarifklassenspalte fehlt.");
        var rows = new List<Dictionary<string, string?>>();
        while (!parser.EndOfData)
        {
            string[] values;
            try { values = parser.ReadFields() ?? Array.Empty<string>(); }
            catch (MalformedLineException) { throw new IppException("TXT_BAD_LINE", $"{blob.Info.Name}: ungueltige CSV-Zeile {parser.ErrorLineNumber}; kein Ueberspringen."); }
            if (values.Length == 0) continue;
            if (values.Length > headers.Length) throw new IppException("TXT_BAD_LINE", $"{blob.Info.Name}: mehr Werte als Spalten.");
            var row = new Dictionary<string, string?>(StringComparer.Ordinal);
            for (int i = 0; i < headers.Length; i++) row[headers[i]] = i < values.Length ? Parse.Text(values[i]) : null;
            if (row.Values.All(v => v is null)) continue;
            rows.Add(row);
        }
        if (rows.Count == 0) throw new IppException("TXT_NO_ROWS", "TXT ohne Datenzeilen: " + blob.Info.Name);
        return new(blob.Info.Name, ExtractMonth(blob.Info.Name), rows, tariffColumns.FirstOrDefault(), blob.Info)
        {
            OriginalRecordNumbers = rows.Select((row, i) => (row, record: i + 1)).ToDictionary(x => x.row, x => x.record),
            OriginalRecordCount = rows.Count
        };
    }
}

public sealed class ContributionEngine
{
    public static readonly string[] MasterColumns = { "Surname", "FirstName", "BirthDate", "Gender", "JoiningDate", "OriginalDateOfHire", "DAT_Zusage", "DAT_AD2" };
    private static readonly HashSet<string> DateColumns = new(StringComparer.Ordinal) { "BirthDate", "JoiningDate", "OriginalDateOfHire", "DAT_Zusage", "DAT_AD2" };
    public ContributionResult Run(InputTable baseline, IReadOnlyList<MonthFile> rawMonths, ContributionOptions options, Action<string>? progress = null, CancellationToken cancel = default, Action<TariffReviewReport>? tariffReviewReady = null)
    {
        if (options.ReviewTariffIssues && options.AllowMissingTariff) throw new IppException("TARIFF_POLICY_CONFLICT", "Tarifpruefung und pauschale Tarifzulassung duerfen nicht gleichzeitig aktiv sein.");
        if (options.CalculateMissingTariffProvisionally && (!options.ReviewTariffIssues || options.AllowMissingTariff))
            throw new IppException("TARIFF_POLICY_CONFLICT", "Vorlaeufige Berechnung erfordert aktive Tarifpruefung ohne pauschale Tarifzulassung.");
        if (options.Profile != "PYTHON_COMPAT_STRICT_V1") throw new IppException("PROFILE_UNKNOWN", "Unbekanntes Rechenprofil.");
        if (rawMonths.Count == 0) throw new IppException("TXT_SELECTION_EMPTY", "Mindestens eine TXT-Datei auswaehlen.");
        if (baseline.Columns.Any(c => Regex.IsMatch(c, @"^(ATTC|TZG|Betrag)_\d+$"))) throw new IppException("BASELINE_NOT_PRISTINE", "Bestand enthaelt bereits Monatsergebnisse; urspruengliche Bestandsvorlage verwenden.");
        var months = rawMonths.OrderBy(m => m.Month).ToList();
        if (months.Select(m => m.Month.Year).Distinct().Count() != 1) throw new IppException("MULTI_YEAR", "Pro Lauf nur ein Kalenderjahr; Monatsspalten wuerden sonst kollidieren.");
        if (months.Select(m => m.Month).Distinct().Count() != months.Count) throw new IppException("DUPLICATE_MONTH", "Mehrere TXT-Dateien fuer denselben Monat; Reihenfolge nicht als Korrekturfreigabe verwenden.");
        var result = new ContributionResult { Year = months[0].Month.Year, Months = months.Select(m => m.Month.Month).ToList(), MasterColumns = MasterColumns.Where(baseline.Columns.Contains).ToList() };
        result.AmountPolicy = options.CalculateMissingTariffProvisionally ? ContributionAmountPolicy.Provisional : ContributionAmountPolicy.Hold;
        if (result.Months[0] != 1 || result.Months.Where((m, i) => i > 0 && m != result.Months[i-1] + 1).Any())
            result.Warnings.Add(new("MONTH_GAPS", "Kein durchgaengiger Lauf ab Januar: der Referenz-Fallback verwendet nur vorhandene direkte Vormonate."));
        if (!baseline.Columns.Contains("DAT_AD2")) result.Warnings.Add(new("ENTRY_DATE_ABSENT", "DAT_AD2 fehlt; die Eintrittssperre des Python-Skripts wird nicht ausgefuehrt. JoiningDate wird nicht ersatzweise verwendet."));
        var bases = new Dictionary<string, Dictionary<string, object?>>(StringComparer.Ordinal);
        foreach (var row in baseline.Rows)
        {
            var id = Parse.Id(row.GetValueOrDefault("ClientID"));
            if (!bases.TryAdd(id, row)) throw new IppException("DUPLICATE_BASELINE_ID", "Doppelte/normalisiert kollidierende ClientID im Bestand.");
            var person = new PersonResult { ClientId = id, OriginalClientId = Parse.Text(row["ClientID"])!, TerminationDate = Parse.Date(row.GetValueOrDefault("TerminationDate"), "TerminationDate", baseline.Date1904), Claim = Parse.Text(row.GetValueOrDefault("ANSPRUCHSTYP"))?.ToUpperInvariant() };
            foreach (var col in result.MasterColumns) person.Master[col] = DateColumns.Contains(col) ? Parse.Date(row.GetValueOrDefault(col), col, baseline.Date1904) : Parse.Text(row.GetValueOrDefault(col));
            // Early validation even if TXT values later cover the baseline.
            Parse.Number(row.GetValueOrDefault("BaseSalary_1"), "BaseSalary_1");
            Parse.Number(row.GetValueOrDefault("PartTimeFactor_1"), "PartTimeFactor_1");
            result.Persons.Add(person);
        }
        var people = result.Persons.ToDictionary(p => p.ClientId, StringComparer.Ordinal);
        var running = new Dictionary<string, double?>();
        var tariffPlan = options.ReviewTariffIssues ? TariffReview.Analyze(result.Persons, months, cancel) : null;
        if (tariffPlan is not null)
        {
            result.TariffReview = tariffPlan.Report;
            result.TariffReview.Policy = result.AmountPolicy;
            // Persist diagnostics before unrelated numeric/date errors can interrupt the calculation.
            tariffReviewReady?.Invoke(tariffPlan.Report);
        }
        foreach (var month in months)
        {
            cancel.ThrowIfCancellationRequested(); progress?.Invoke($"Verarbeite {month.Month:MM.yyyy}");
            result.Inputs.Add(month.Source);
            var knownRows = new Dictionary<string, List<Dictionary<string, string?>>>(StringComparer.Ordinal);
            foreach (var row in month.Rows)
            {
                var id = Parse.Id(row.GetValueOrDefault("KDMA_IDENT"));
                if (!people.ContainsKey(id))
                {
                    if (!options.AllowUnknownTxtPersons) throw new IppException("TXT_PERSON_MISSING", "TXT enthaelt eine Person ausserhalb des Bestands. Bestand vervollstaendigen oder die dokumentierte Ignore-Option explizit aktivieren.");
                    result.Warnings.Add(new("TXT_PERSON_IGNORED", "Nicht im Bestand; analog Python-Left-Join ausgelassen.", id, month.Month.Month)); continue;
                }
                if (!knownRows.TryGetValue(id, out var list)) knownRows[id] = list = new();
                list.Add(row);
            }
            foreach (var p in result.Persons)
            {
                knownRows.TryGetValue(p.ClientId, out var rows); rows ??= new();
                if (rows.Count > 1) result.Warnings.Add(new("MULTIPLE_TXT_ROWS", "Mehrere Zeilen: letzte passende Zeile je Feld nach Referenzreihenfolge.", p.ClientId, month.Month.Month));
                double? tariff = null;
                running.TryGetValue(p.ClientId, out var prevTariff);
                double? effective;
                TariffMonthState? tariffState = null;
                if (tariffPlan is not null)
                {
                    tariffState = tariffPlan.States[(p.ClientId, month.Month.Month)];
                    tariff = tariffState.RawTariff; effective = tariffState.EffectiveTariff;
                    if (tariffState.ReviewRequired)
                        result.Warnings.Add(new("TARIFF_REVIEW_REQUIRED", tariffState.Reason + ": Tarifpruefung bleibt offen. Betragsbehandlung siehe Betrag_Status / Tarifpruefung.xlsx; keine Dokumentfreigabe.", p.ClientId, month.Month.Month));
                }
                else
                {
                    if (month.TariffColumn is not null) foreach (var row in rows) { var t = Parse.Tariff(row.GetValueOrDefault(month.TariffColumn)); if (t is not null) tariff = t; }
                    effective = tariff ?? prevTariff;
                    if (effective is null && !(p.Master.GetValueOrDefault("DAT_AD2") is DateOnly knownEntry && month.Month < new DateOnly(knownEntry.Year, knownEntry.Month, 1)))
                    {
                        if (!options.AllowMissingTariff) throw new IppException("TARIFF_UNKNOWN", $"Tarifklasse unbekannt: ClientID={p.ClientId}, Monat={month.Month:yyyy-MM}. Keine ungesicherte Freigabe von ATTC.");
                        result.Warnings.Add(new("UNKNOWN_TARIFF_ALLOWED", "Unbekannter Tarif wird wie im Python-Skript nicht als 98/99 gesperrt.", p.ClientId, month.Month.Month));
                    }
                }
                if (p.TariffOld is null && tariff is not null) p.TariffOld = tariff;
                if (prevTariff is not null && effective is not null && prevTariff != effective) { p.TariffNew = effective; p.TariffChangeDate = month.Month; }
                running[p.ClientId] = effective;
                var mr = new MonthlyResult { Month = month.Month.Month, SalaryDate = month.Month, RawTariff = tariff, EffectiveTariff = effective, TariffReviewRequired = tariffState?.ReviewRequired ?? false, TariffStatus = tariffState?.Status ?? "LEGACY", TariffIssue = tariffState?.Reason };
                if (rows.Count > 0)
                {
                    var last = rows[^1];
                    p.Claim = Parse.Text(last.GetValueOrDefault("ANSPRUCHSTYP"))?.ToUpperInvariant() ?? p.Claim;
                    var term = Parse.Date(last.GetValueOrDefault("DAT_AUSTRITT"), "DAT_AUSTRITT");
                    if (term is not null) p.TerminationDate = term;
                    mr.Tzg = Parse.Number(last.GetValueOrDefault("ARBZEIT_PROZ"), "ARBZEIT_PROZ");
                    if (mr.Tzg <= 1) mr.Tzg *= 100;
                    if (mr.Tzg is not null) mr.TzgSource = "TXT_LAST_ROW";
                    if (effective is not (98 or 99))
                    {
                        var salaryRows = rows.Where(r => Parse.Text(r.GetValueOrDefault("BETRAG1_TYP"))?.ToUpperInvariant() == "ATTC_BAV" && Parse.Text(r.GetValueOrDefault("ANSPRUCHSTYP"))?.ToUpperInvariant() == "AKTAN").ToList();
                        if (salaryRows.Count > 0) { mr.Attc = Parse.Number(salaryRows[^1].GetValueOrDefault("BETRAG1"), "BETRAG1"); if (mr.Attc is not null) mr.AttcSource = "TXT_ATTC_BAV_AKTAN"; }
                    }
                }
                p.Months.Add(mr.Month, mr);
            }
        }
        // Same stage order as reference: fallback -> tariff mask -> entry mask -> contribution -> exit mask.
        foreach (var p in result.Persons)
        {
            cancel.ThrowIfCancellationRequested();
            foreach (int m in result.Months)
            {
                var row = p.Months[m]; var baselineRow = bases[p.ClientId];
                // Salary is an input fact, not a tariff approval. Keep the reference
                // TXT -> January baseline -> direct previous month fallback even during review.
                if (row.TariffReviewRequired) row.Reasons.Add("TARIFF_REVIEW_REQUIRED");
                if (row.Attc is null)
                {
                    row.Attc = m == 1 ? Parse.Number(baselineRow.GetValueOrDefault("BaseSalary_1"), "BaseSalary_1") : p.Months.GetValueOrDefault(m - 1)?.Attc;
                    if (row.Attc is not null) row.AttcSource = m == 1 ? "BASE_SALARY_1" : "PREVIOUS_MONTH";
                }
                if (row.Tzg is null)
                {
                    row.Tzg = m == 1 ? Parse.Number(baselineRow.GetValueOrDefault("PartTimeFactor_1"), "PartTimeFactor_1") : p.Months.GetValueOrDefault(m - 1)?.Tzg;
                    if (row.Tzg is not null) row.TzgSource = m == 1 ? "BASE_PART_TIME_1" : "PREVIOUS_MONTH";
                }
                if (row.EffectiveTariff is 98 or 99) { row.Attc = null; row.Reasons.Add("TARIFF_98_99"); }
                if (row.Tzg is < 0 or > 100) throw new IppException("TZG_RANGE", "Teilzeitgrad ausserhalb 0..100.");
                if (row.Attc < 0) throw new IppException("ATTC_NEGATIVE", "Negatives ATTC erfordert eine explizite Korrekturregel.");
                if (row.Tzg == 1) result.Warnings.Add(new("TZG_ONE_AMBIGUOUS", "TZG=1 wird vom Python-Rechenkern als Faktor 1 (100%) interpretiert; Einheiten pruefen.", p.ClientId, m));
            }
            if (p.Master.GetValueOrDefault("DAT_AD2") is DateOnly entry)
                foreach (var r in p.Months.Values.Where(r => r.SalaryDate < new DateOnly(entry.Year, entry.Month, 1))) { r.Attc = r.Tzg = null; r.Reasons.Add("BEFORE_DAT_AD2"); }
            foreach (var row in p.Months.Values)
            {
                bool provisional = ContributionAmountPolicy.CanCalculate(options, row);
                row.Amount = row.TariffReviewRequired && !provisional ? null : ContributionFormula.Calculate(row.Attc, row.Tzg, row.SalaryDate);
                row.AmountStatus = row.Reasons.Contains("BEFORE_DAT_AD2") ? "BEFORE_DAT_AD2"
                    : row.EffectiveTariff is 98 or 99 ? "EXCLUDED_TARIFF_98_99"
                    : row.TariffReviewRequired && !provisional ? "HELD_TARIFF_REVIEW"
                    : row.Amount is not null && provisional ? ContributionAmountPolicy.ProvisionalStatus
                    : row.Amount is not null ? "CALCULATED_NOT_BUSINESS_APPROVED"
                    : "MISSING_OR_ZERO_TZG_OR_ATTC";
                if (row.Amount is null && row.Reasons.Count == 0) row.Reasons.Add("MISSING_OR_ZERO_TZG_OR_ATTC");
            }
            if (p.Claim == "AUGUAN" && p.TerminationDate is DateOnly exit)
                foreach (var row in p.Months.Values.Where(r => r.SalaryDate > exit))
                {
                    row.Attc = row.Tzg = row.Amount = null; row.AmountStatus = "AFTER_AUGUAN_EXIT"; row.Reasons.Add("AFTER_AUGUAN_EXIT");
                    if (row.TariffReviewRequired && result.TariffReview is not null)
                    {
                        row.TariffReviewRequired = false; row.TariffStatus = "NOT_REQUIRED_AFTER_AUGUAN_EXIT";
                        var c = result.TariffReview.Cases.Single(c => c.ClientId == p.ClientId && c.Month == row.SalaryDate.ToString("yyyy-MM", Parse.Inv));
                        c.Resolution = "NOT_REQUIRED_AFTER_AUGUAN_EXIT";
                        c.Note += " Abschliessender AUGUAN-Austrittsfilter leert diesen Monat ohnehin; kein offener Beitragstarif-Fall.";
                    }
                }
        }
        if (result.TariffReview is not null)
        {
            foreach (var c in result.TariffReview.Cases)
            {
                var monthly = people[c.ClientId].Months[int.Parse(c.Month[5..7], Parse.Inv)];
                c.AmountStatus = monthly.AmountStatus;
                if (monthly.AmountIsProvisional)
                {
                    monthly.TariffStatus = "TARIFF_OPEN_AMOUNT_PROVISIONAL";
                    monthly.Reasons.Add("MISSING_TARIFF_PROVISIONAL_NOT_APPROVED");
                    result.Warnings.Add(new("MISSING_TARIFF_PROVISIONAL_NOT_APPROVED", "Betrag wie Python bei fehlendem Tarif berechnet; Tarif NICHT bestaetigt, keine Dokumentfreigabe.", c.ClientId, monthly.Month));
                }
            }
            TariffReview.FinalizeCoverage(result.TariffReview);
            tariffReviewReady?.Invoke(result.TariffReview);
        }
        return result;
    }
}
