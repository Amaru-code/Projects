# MCR IPP 0.4.0 – Betragsmodus und Vorlagen-JSON

Native C#/.NET 10 Pipeline, Windows-Oberfläche und CLI. Nur IPP, keine DC-Vorlagen.
Keine zusätzliche Python-Installation, keine NuGet-Pakete, kein automatischer Download.
Der gemeinsame portable Compiler bleibt unter `projects/Compiler/csharp/tools/dotnet`.

**Start:** `START.cmd`. **Drei Vorlagen exportieren:** `VORLAGEN_JSON.cmd`
oder in der Anwendung **Vorlagen nach JSON...**.

## Zwei Änderungen

1. Rein fehlende Tarife können jetzt nach dem sichtbaren, standardmäßig aktivierten
   Rechenmodus wie im Python-Skript mit den verfügbaren ATTC-/TZG-Werten berechnet werden.
   Zahlen werden **vorläufig**, nicht fachlich freigegeben. Offene Prüffälle bleiben offen.
   Bekannte 98/99, widersprüchliche/ungültige Tarife, fehlende Daten und Eintritt/Austritt
   werden nicht pauschal freigegeben. Vorherige Hold-Variante bleibt wählbar.
2. Export der tatsächlich ausgewählten Excel-Vorlagenmappe in JSON: Zelltexte/-werte,
   Formeln, Styles, Zeilen-/Spaltenmaße, Seitenaufteilung, Zeichnungen und Bildreferenzen.
   Bilddaten sind getrennte JSON-Transportdateien. Kein Excel-Start, keine Makroausführung,
   keine Änderung der Quelle. Noch kein Import der drei Vorlagen in die PDF-Erzeugung.

**Zuerst START_HIER.md und BETRAGSFIX_UND_VORLAGENEXPORT_LESEN.md lesen.**
Alle bisherigen Korrekturen am ATTC-Fallback und PDF-Dateiabschluss bleiben erhalten.
Die vorhandenen PDF-Beitragsübersichten bleiben interne Entwürfe, keine echten LNW.

## Prüfstand

212 C#-Testdefinitionen inklusive 11.714 bestehender Geld-/Rundungsvektoren.
Das neue C#-Projekt wurde hier **nicht kompiliert oder ausgeführt**: kein SDK verfügbar.
START.cmd und VORLAGEN_JSON.cmd bauen und testen lokal vor dem Start.
Modelle unter evidence sind ausdrücklich unabhängig von der C#-Ausführung.
Prüfstatus: evidence/verification.json. Lokale tatsächliche Builds: evidence/local.
Historische Hinweise sind unter evidence/history bzw. als historisch markiert erhalten.

CLI nach Build: `contribute` oder `export-templates`, siehe src/Mcr.Ipp.Cli/Program.cs.
Exitcode 0 bei technisch abgeschlossenem Export ist keine Versandfreigabe.
