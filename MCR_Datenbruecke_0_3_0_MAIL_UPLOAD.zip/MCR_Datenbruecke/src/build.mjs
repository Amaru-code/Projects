import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const code='/* MCR Datenbruecke 0.2.2 - generated from lib/data-core.cjs + browser/ui.js. */\n(()=>{\nconst module={exports:{}};\n'+fs.readFileSync(path.join(root,'lib/data-core.cjs'),'utf8')+'\nconst Core=module.exports;\n'+fs.readFileSync(path.join(root,'browser/ui.js'),'utf8')+'\n})();\n';
fs.writeFileSync(path.join(root,'COMARCH_DATENBRUECKE.js'),code);

const modules=[['Core','lib/data-core.cjs'],['Msg','lib/msg.cjs'],['Person','lib/person.cjs']];
const v3='/* MCR Mail-Assistent 0.3.0. Offline MSG parser and supervised member workflow. */\n(()=>{\n'+modules.map(([name,file])=>'const '+name+'=(()=>{const module={exports:{}};\n'+fs.readFileSync(path.join(root,file),'utf8')+'\nreturn module.exports;})();\n').join('')+fs.readFileSync(path.join(root,'browser/mail-ui.js'),'utf8')+'\n})();\n';
fs.writeFileSync(path.join(root,'COMARCH_MAIL_ASSISTENT.js'),v3);
