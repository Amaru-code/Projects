# MCR Datenbrücke 0.3.0 — Original-Mail und Member-Assistent

## Für deinen aktuellen Stand

Dein JSON-Mapping ist schon erstellt. **Nicht erneut exportieren.** `private_data` und deine
Node-Installation bleiben erhalten. Dieses vollständige Paket ergänzt den vorhandenen Ordner.
Der neue Einstieg ist `MAIL_ASSISTENT_OEFFNEN.cmd` (auch `KONSOLE_OEFFNEN.cmd` öffnet jetzt den
neuen Helfer). Eine zusätzliche Installation oder `npm install` ist nicht erforderlich.

Der neue Helfer führt durch vier Schritte:

**Bestand laden → Original-Mail laden → Namen prüfen / Member auswählen → Beschreibung übernehmen.**

Das ist ein beaufsichtigter Daten-Assistent, kein vollständiger Versand- oder Queue-Bot.
Er klickt weder „Senden“ noch „Ticket speichern“, öffnet nicht selbst das nächste Ticket und
setzt nicht automatisch Kategorien oder Signaturen. Die vorhandene ältere Datenbrücke ist
über `ALTES_PANEL_OEFFNEN.cmd` weiterhin erreichbar.

## Update ohne Verlust deines Mappings

ZIP vollständig entpacken. Den enthaltenen Ordner `MCR_Datenbruecke` mit deinem vorhandenen
Ordner gleichen Namens zusammenführen und die gelieferten Paketdateien ersetzen. Nicht den
alten Ordner vorab löschen. Die Lieferung enthält keine echten Mappings oder Mails und keine
Node-Runtime. Deine vorhandenen Dateien unter `private_data` bleiben beim Zusammenführen bestehen.

## Genau ein Ticket testen

### Vorbereitung in COMARCH

1. In Edge selbst die Warteschlange INTL01 und genau ein Ticket öffnen.
2. Unter Nachrichtenverlauf die **Original-Mail herunterladen**. Im Downloadfenster
   **Speichern** oder **Speichern unter** wählen, nicht „Öffnen“. Das Ergebnis ist eine `.msg`.
   Du musst die Nachricht nicht in Outlook öffnen, weiterleiten oder neu speichern.
3. Im Ticket selbst **Bearbeiten** anklicken. Das kann bereits Status/Zuständigkeit des
   Vorgangs ändern. Verwende einen betrieblich freigegebenen Testfall.
4. `MAIL_ASSISTENT_OEFFNEN.cmd` doppelklicken. Notepad zeigt `COMARCH_MAIL_ASSISTENT.js`.
   Alles kopieren (Strg+A, Strg+C). In Edge F12, Konsole, Kontext möglichst **top**:
   den vollständigen Block einfügen und Enter. Sicherheits-/Unternehmensrichtlinien nicht umgehen.
5. Rechts erscheint **MCR Mail-Assistent 0.3.0**. Der alte Inspector und das alte Datenpanel
   werden, soweit in demselben zugreifbaren Seitenkontext aktiv, geschlossen bzw. deaktiviert.

### Schritt 1 — Bestand laden

Bei „Bestand laden“ deine schon erstellte `.json` aus `private_data` auswählen.
**Nicht die Excel und nicht die MSG.** Dateiname, Quellstand, Blatt und USC-Spalte prüfen und
die Quellenfreigabe ankreuzen. Das Panel wechselt zu Schritt 2.

Die bestehende Regel bleibt: B = ClientEEID, L = USC; C = DC, D = PP+, E = DB+.
Die Kürzel werden in dieser Reihenfolge mit Semikolon verbunden. Beispiele:
`USC 10/ PP+`, `USC 10/ DC;PP+`, `USC 10/ DC;PP+;DB+`.

Das Mapping wird anhand seines Schemas und seiner SHA256-Nutzdatenprüfsumme geprüft. Das ist
keine digitale Signatur und kein Nachweis wirtschaftlicher Aktualität. Deine Quellenprüfung
bleibt notwendig. Alte MCR_INTL01_LOOKUP_V1-Dateien, auch mit Blattname `output`, bleiben nutzbar.

### Schritt 2 — Original-Mail laden

Jetzt die eben gespeicherte **`.msg`** auswählen. Die Auswahl ist lokal; der Helfer sendet die
Datei nicht an einen externen Dienst. Er liest gespeicherten Klartext, Betreff und Absendername,
aber extrahiert/öffnet keine Anhänge und lädt keine externen Bilder.

Namen können aus einem Adressblock (z.B. „Hier meine vollständige Adresse:“), einer Signatur,
einem beschrifteten Namen oder dem Absenderfeld stammen. Mehrere Hinweise werden gezeigt,
nicht blind auf die erste Person reduziert. Der Text ist über „Gelesenen Text lokal prüfen“
als nicht ausführbarer Text einsehbar.

### Schritt 3 — Namen und Member

Vorname und Nachname in den beiden Feldern prüfen. Der Suchname wird als
**Nachname + Leerzeichen + Vorname** gebildet. Fiktiv: `Mustermann Max`.
Bei vertauschter Reihenfolge gibt es „Vorname / Nachname tauschen“. Bei unklaren mehrteiligen
Namen ist die Aufteilung bewusst manuell. Es erfolgt keine Geschlechts-/Anredeableitung.

Die Ticket-ID wird aus einer eindeutigen Detailanzeige übernommen, soweit diese technisch
auffindbar ist. Sonst die **Ticket-ID des geöffneten Tickets** selbst eingeben. Das ist nicht
die ClientEEID und nicht die Dokument-ID. Bestätige die Zuordnung von Mail und Person zum Ticket.

Mit **„Member suchen“** wird nur das bereits bekannte COMARCH-Suchfeld angesprochen. Die
COMARCH-Anwendung kann daraufhin ihre normalen Such-/Änderungsanfragen an ihren Server senden.
JavaScript-Ereignisse sind kein Beweis, dass die Suche auf deinem alten Frontend tatsächlich
angestoßen wurde. Öffnet sich keine Vorschlagsliste, im Member-Feld ein Zeichen löschen und
wieder eintippen oder „Suchnamen kopieren“ benutzen. Nicht auf Verdacht Enter/Senden betätigen.

**Trefferauswahl:**
- Einzelauswahl automatisch nur bei einem sichtbar und explizit zum Eingabefeld gehörenden
  Listen-Widget, das „fertig“ und eine Gesamtzahl von genau einem Treffer ausweist. Name,
  Mail-Kennung (falls vorhanden) und Mapping müssen passen. Es wird nie einfach der erste
  sichtbare Eintrag einer unbekannten oder mehrdeutigen Liste angeklickt.
- Bei mehreren Treffern wählst **du** den richtigen Eintrag in der echten COMARCH-Liste.
  Ein beobachteter echter Mausklick und eine danach stabile passende Member-Kennung können
  den Lookup automatisch fortsetzen. Das erfordert auch eine technisch gebundene Ticket-ID.
- Bei Tastaturauswahl, nicht lesbarer Trefferzeile, unbekanntem Widget oder manuell gebundener
  Ticket-ID: nach der tatsächlichen COMARCH-Auswahl **„Meine Member-Auswahl bestätigen → weiter“**.
  Der Knopf bestätigt eine echte zuvor erfolgte Auswahl; nur einen Namen einzutippen genügt nicht.

**Für deine echte COMARCH-Version ist die Trefferliste noch nicht qualifiziert.** Der bisherige
Inspector hatte an dieser Stelle nur `body` erfasst. Rechne deshalb zunächst auch bei einem
Treffer mit einem eigenen Klick. Die automatische Variante ist ausschließlich synthetisch getestet.

Nach zwei Minuten wird das automatische Warten pausiert. Die bewusste Bestätigung funktioniert
weiter. „Suche / Warten stoppen“ stoppt die Beobachtung, macht bereits erfolgte Eingaben aber nicht rückgängig.

### Schritt 4 — Beschreibung

Aus der bestätigten Member-Kennung wird die richtige JSON-Zeile nachgeschlagen. Das Ergebnis
zeigt die Beschreibung sowie Quellzeile und Werte. Bei Formeln muss vorher die vorhandene
Freigabe für gespeicherte Excel-Berechnungswerte erteilt werden.

„Beschreibung kopieren“ kopiert das Ergebnis auf deinen ausdrücklichen Klick.
„Beschreibung in COMARCH einsetzen“ schreibt nur in ein eindeutig erkanntes, beschriftetes
Beschreibungsfeld. Der beobachtete dynamische `j_id7019` allein reicht nicht als Bindung.
Ein vorhandener abweichender Text wird nicht überschrieben. Wird das Feld nicht eindeutig
erkannt, kopiere die Beschreibung und setze sie selbst ein.

Der Helfer hat danach **keine E-Mail versendet und nicht „Ticket speichern“ betätigt**.
COMARCH selbst kann auf Eingabe-/Change-Ereignisse mit Hintergrundänderungen reagieren.
Kategorien, Signatur, Empfänger, Anrede, Antworttext, Versand und Speichern bleiben in diesem
Paket im bisherigen manuellen Ablauf. Insbesondere Empfängeränderungen in einer Mail nicht
ungeprüft übernehmen.

## Nächstes Ticket

Vor dem nächsten Fall **„Neuer Fall“** drücken. Mail, Name, Member und Ergebnis werden im Helfer
verworfen; das freigegebene Mapping bleibt für diese Seitensitzung geladen. Das nächste Ticket
selbst öffnen und dessen Original-Mail laden. Bei vollständigem Seitenwechsel/Fensterwechsel
muss der Helfer erneut eingesetzt und das Mapping wieder geladen werden. Es gibt keine
browserübergreifende Fortsetzung und keine automatische Queue-Schleife.

## Unterstützte Mail-Dateien / klare Grenzen

Die MSG-Auswertung ist ein begrenzter, lesender MS-CFB/MS-OXMSG-Parser. Unterstützt werden
normale top-level IPM.Note-Nachrichten mit Unicode-Klartext oder String8-Klartext mit
unterstützter expliziter Codepage. Reines ASCII ist ohne Codepage eindeutig. FAT, MiniFAT,
DIFAT und 512-/4096-Byte-Sektoren werden unterstützt. Es wird nicht in angehängten Nachrichten
nach einem ersatzweisen Absender/Körper gesucht.

Maximal 32 MiB Originaldatei und 120.000 Klartextzeichen. Die Version öffnet weder RTF-only,
HTML-only noch verschlüsselte/geschützte Nachrichten als ausführbaren Inhalt. Sie liefert eine
Meldung und stoppt. `.eml` ist in dieser Version nicht unterstützt. Als Alternative kann der
relevante Text in „Alternative: Mailtext selbst einfügen“ übernommen oder als UTF-8 `.txt`
ausgewählt werden. Dieser Fallback muss bewusst aus der richtigen Original-Mail stammen.

Es handelt sich nicht um universelle Namens-KI: freie Formulierungen, unklare Namensreihenfolge,
Vertretung, Weiterleitungen oder mehrere erwähnte Personen brauchen menschliche Prüfung.
Eine Mail liefert Hinweise, keine Identitätsgarantie. Das Geschlecht wird nicht geraten.

## Häufige Stopps

| Meldung | Bedeutung / nächster Schritt |
|---|---|
| MEMBER_FIELD | Kein eindeutiges bearbeitbares Member-Feld: Ticket öffnen, Bearbeiten und richtigen Fensterkontext prüfen. |
| MEMBER_EXISTS | Schon zugeordnet: bewusst prüfen und bestätigen, nicht erneut überschreiben. |
| MEMBER_NAME_CONFLICT | Bestätigter Vor-/Nachname passt nicht zur COMARCH-Anzeige. Reihenfolge/Schreibweise/Person prüfen. |
| TICKET_REQUIRED | Ticket-ID aus Detailkopf selbst eintragen. |
| TICKET_CHANGED / TICKET_REBIND | Ticket/Formular gewechselt oder unzureichend gebunden. Mit Neuer Fall sauber neu beginnen. |
| MAIL_AMBIGUOUS / MAIL_MEMBER_CONFLICT | Mehrere oder widersprüchliche beschriftete Kennungen: manuell klären. |
| ID_NOT_FOUND / ID_BLOCKED | Person fehlt im JSON oder wurde beim Export gesperrt. Nicht raten. |
| DESCRIPTION_FIELD / DESCRIPTION_EXISTS | Beschreibung nicht eindeutig oder schon befüllt. Kopieren/manuell prüfen. |
| MSG_RTF_ONLY / MSG_HTML_ONLY / MSG_BODY_MISSING | Kein unterstützter Klartext: alternative bewusste Textübernahme verwenden. |
| MSG_CODEPAGE / MSG_ENCODING | Text nicht eindeutig dekodierbar. Kein erratener Name; alternative Textübernahme. |

## Datenschutz und technische Grenzen

Keine externen KI-Dienste, keine Telemetrie, kein Clipboard-Lesen, keine Screenshots, keine
Passwort-/Cookie-Auswertung und keine Suche im Outlook-Postfach. Original-Mail und Mapping
werden nur über deine Dateiauswahl gelesen. Es gibt keinen automatischen Scan des Downloads-Ordners.
Die heruntergeladene Originaldatei verbleibt an deinem gewählten Speicherort; betriebliche
Lösch-/Aufbewahrungsvorgaben beachten. Keine Änderung der Originaldatei.

**Der Browser-Seitenkontext ist nicht isoliert:** das gesamte minimierte Mapping und der
gewählte Mailtext gelangen in den Arbeitsspeicher der COMARCH-Seite. Nur mit betrieblicher
Freigabe einsetzen. Das Tool führt selbst keinen Upload aus; die Anwendung und Browserumgebung
sind dennoch Vertrauensvoraussetzungen. Keine Mails, echten Mappings, HAR-Dateien, Browserprofile
oder vollständigen Konsolen in Git oder in den Chat hochladen.

„Diagnose-ZIP“ erstellt genau ein `_UPLOAD.zip` mit Zählwerten, Status und Fehlercodes, nicht
mit Personenwerten, Dateinamen, Texten, IDs, URLs oder Mappingzeilen. SHA256/CRC dienen
Übertragungs- und Integritätsprüfung, nicht als Anonymisierung allgemeiner Dateien.

## Tests und Demo

`MAIL_DEMO_STARTEN.cmd` öffnet eine fiktive Testseite. Nutze `examples/DEMO_mapping.json` und
`examples/DEMO_Mail.msg`. Name `Max Mustermann`, ausgewählter Test-Member mit Endung `99900001`,
erwartete Beschreibung `USC 10/ PP+`. Buttons simulieren einen vollständigen Einzeltreffer,
mehrere Treffer und eine unbekannte Alt-Oberfläche. **Nie das Demo-Mapping produktiv einsetzen.**

`SELBSTTEST.cmd` prüft die Paketdateien und führt Node-Tests aus. Node ≥22.15 bleibt die
Voraussetzung für Export/Offline-Tests. Das bestehende Node-Verzeichnis wird weiterverwendet.
Der neue Konsolenhelfer selbst braucht keinen laufenden Node-Server.

Die Ergebnisse und klaren Testgrenzen stehen in `docs/MAIL_TESTBERICHT.md`.
Die tatsächliche COMARCH-Installation, Windows/Outlook und deine echte MSG/Arbeitsmappe wurden
in dieser Umgebung nicht ausgeführt. Es wurde keine echte Ticketänderung oder E-Mail hier vorgenommen.
