# MCR Ticket Assistant · Beta 2

**Paket:** `0.8.0-beta.2` · **Ticketkern:** `0.7.4` · **Einsatz:** beaufsichtigte Beta für INTL01

## Ein Einstieg für den Alltag

`START.cmd` doppelt anklicken. Das Menü startet nicht selbstständig einen Ticketlauf.

| Menü | Zweck |
|---|---|
| 1 | Echter Queue-Lauf. Erst nach `START` im Runner: Senden und Ticket speichern. |
| 2 | Paket, bytegleichen Kern und aktives TPP-Mehrzeilen-Mapping lokal prüfen. |
| 3 | Fiktive Demo in getrenntem Tempordner und Browserprofil. |
| 4 | Selbsttest ohne COMARCH und ohne Browser. |
| 5 | Gestaltetes Offline-Handbuch im Browser öffnen. |
| 6 | Wartung: Mapping aus derselben bereits freigegebenen XLSX neu erzeugen. |
| 7 | Nach Abbruch: eigene Verlaufskontrolle dokumentieren, keinen Versand auslösen. |
| 8 | Bestehenden Diagnoseordner öffnen. |

Vor einem neuen Echtlauf den vorherigen MCR-Bot und dessen eigenes Edge-Fenster schließen.
Andere Browserfenster/Programme werden weder beendet noch verändert.

## Einmalige Umstellung

Dieses Verzeichnis nicht manuell über den Altbestand kopieren. Das komplette Liefer-ZIP
**außerhalb** des bestehenden Projekts entpacken und dort `BETA_EINRICHTEN.cmd` starten.
Die Vorschau ändert keine Dateien. Erst `UMSTELLEN` archiviert alte Software und installiert
die Beta an demselben Projektpfad. Der Installer startet keinen Browser und keinen Ticketlauf.

## Bewusst unverändert

Die 17 in `tools/reference/engine-lock.json` aufgeführten Kern-Dateien sind bytegleich zum
0.7.4-Paket. Das umfasst Vollrunner, Personenanalyse, PAGE_FETCH, Mappingregeln, Queue-/Versandlogik
und deren Laufzeitabhängigkeiten. Die Pfade `private_data`, `.runtime/edge-profile` und
`diagnostics` bleiben bestehen. Das aktive JSON muss nicht erneut erzeugt oder aktiviert werden.

Alte Panels, Piloten, Versuche und Entwicklungsberichte liegen anschließend neben dem
Projekt unter `../_MCR_Archiv/beta2_<Zeitpunkt>/software`. Unbekannte Dateien außerhalb der
bekannten Softwareordner werden nicht gelöscht. Keine automatische Daten-/Cachebereinigung.

## Grenzen

Beta bedeutet nicht allgemeine Produktionszertifizierung. Der bekannte COMARCH-Versandnachweis
ist weiterhin ein Anwendungssignal, kein Nachweis über die Zustellung im Empfängerpostfach.
Es gibt weiterhin keine systemübergreifende Exactly-once-Zustellgarantie. Bei unklarem Ausgang:
Nachrichtenverlauf und Diagnose prüfen, nicht blind wiederholen. Eine manuelle Wiederanlauffreigabe
ist kein technischer Versandnachweis. Ein Software-Rollback macht keine Ticketaktion rückgängig.

Detaillierte Bedienung: `docs/HANDBUCH.html`. Prüfstand: `docs/QUALIFIKATION.json`.

## Beta-2 Windows-Hotfix

Die Umstellung verwendet fuer ihr lokales Migrationsjournal weiterhin atomare Dateiumbenennung als ersten Weg. Falls ein verwaltetes Windows-System diesen Rename mit `EPERM`, `EACCES` oder `EBUSY` blockiert, faellt nur das Umstellungsjournal auf einen fsync-geprueften Direktwrite mit `migration.json.bak` als letzter gueltiger Rueckfallkopie zurueck. Ticketkern 0.7.4 und Ticketlogik bleiben unveraendert.
