/** Reversible in-place software reorganisation. Protected user data never moves. */
import fs from 'node:fs';
import path from 'node:path';
import {loadActiveMapping} from '../lib/active-mapping.mjs';
import {SCHEMA as TPP_SCHEMA} from '../lib/multirow-tpp-mapping.mjs';
import {PACKAGE_ROOT,RELEASE,PROTECTED,need,sha,stamp,jsonRead,atomicJSON,journalJSON,journalRead,safeRelative,assertPlainPath,treeRecord,verifyRelease,verifyBaseline,acquireLock} from './beta-common.mjs';
const EXTRA_LEGACY=['DOWNLOAD_TEST_MANIFEST.json','MAPPING_EF_TPP_AKTUALISIEREN.cmd','patch-ef-tpp.mjs','README_EF_TPP_PATCH_0_1.md','MCR_QUEUE_DETECTION_TEST_0_1'];
const BARRIER='BETA_UMSTELLUNG_LAEUFT.txt';
const ARCHIVE='_MCR_Archiv';const ARCHIVE_PREFIX='beta2_';
function oneName(x){return safeRelative(x)&&!x.includes('/')&&!PROTECTED.has(x)&&x!==BARRIER;}
function sameRecord(a,b){return a.kind===b.kind&&a.bytes===b.bytes&&a.files===b.files&&a.digest===b.digest;}
export function activeSnapshot(root){
 assertPlainPath(path.join(root,'private_data'));
 const active=loadActiveMapping(root);need(active.map.schema===TPP_SCHEMA,'TPP_MAPPING_REQUIRED','Zuerst das aktive TPP-Mehrzeilen-Mapping 0.7.4 fertigstellen. Keine Neuerzeugung waehrend der Bereinigung.');
 assertPlainPath(active.path);assertPlainPath(active.pointerPath);
 return {file:path.basename(active.path),fileHash:active.fileHash,pointerHash:sha(fs.readFileSync(active.pointerPath)),schema:active.map.schema};
}
function sameActive(root,expected){const a=activeSnapshot(root);need(JSON.stringify(a)===JSON.stringify(expected),'ACTIVE_CHANGED','Aktives Mapping/Zeiger wurde waehrend der Umstellung geaendert.');return a;}
function guardedTarget(root,packageRoot){
 root=assertPlainPath(path.resolve(root));need(path.basename(root).toLowerCase()==='mcr_datenbruecke','TARGET_NAME','Ziel muss der vorhandene Ordner MCR_Datenbruecke sein.');
 need(fs.lstatSync(root).isDirectory(),'TARGET_DIRECTORY','Ziel ist kein Ordner.');
 const pkg=path.resolve(packageRoot);need(root!==pkg&&!pkg.startsWith(root+path.sep)&&!root.startsWith(pkg+path.sep),'SETUP_LOCATION','ZIP ausserhalb des vorhandenen Projektordners entpacken; nicht ueberkopieren.');
 return root;
}
function oldNames(packageRoot){const ref=jsonRead(path.join(packageRoot,'tools/reference/baseline-0.7.4-manifest.json'));return [...new Set([...ref.payload.map(x=>x.path.split('/')[0]),'MANIFEST.json','SHA256SUMS.txt',...EXTRA_LEGACY])].filter(x=>oneName(x));}
function newNames(packageRoot){return fs.readdirSync(packageRoot).filter(x=>oneName(x)).sort();}
function orderNames(names){return [...names].sort((a,b)=>Number(/\.(cmd|bat)$/i.test(b))-Number(/\.(cmd|bat)$/i.test(a))||a.localeCompare(b));}
export function makePlan(root,packageRoot=PACKAGE_ROOT){
 root=guardedTarget(root,packageRoot);verifyRelease(packageRoot);
 const installed=path.join(root,'package.json');
 if(fs.existsSync(installed)){
  const p=jsonRead(installed,65536);if(p.version===RELEASE){const r=verifyRelease(root);return {schema:'MCR_BETA_MIGRATION_PLAN_V1',alreadyInstalled:true,target:root,release:RELEASE,check:r,active:activeSnapshot(root)};}
 }
 need(!fs.existsSync(path.join(root,BARRIER)),'MIGRATION_INCOMPLETE','Vorherige Umstellung unvollstaendig. BETA_ZURUECK.cmd verwenden.');
 const baseline=verifyBaseline(root,packageRoot),active=activeSnapshot(root);
 for(const n of PROTECTED)if(fs.existsSync(path.join(root,n)))assertPlainPath(path.join(root,n));
 const names=orderNames(oldNames(packageRoot).filter(n=>fs.existsSync(path.join(root,n))));
 const install=newNames(packageRoot);
 for(const n of install){need(oneName(n),'PROTECTED_TARGET','Unzulaessiger Paketordner.');need(!fs.existsSync(path.join(root,n))||names.includes(n),'UNKNOWN_COLLISION','Nicht zugeordneter bestehender Ordner/Datei kollidiert: '+n+'. Bleibt unveraendert.');}
 const source=names.map(name=>({name,...treeRecord(path.join(root,name))}));
 const incoming=install.map(name=>({name,...treeRecord(path.join(packageRoot,name))}));
 const untouched=fs.readdirSync(root).filter(n=>!names.includes(n));
 return {schema:'MCR_BETA_MIGRATION_PLAN_V1',alreadyInstalled:false,release:RELEASE,target:root,packageHash:sha(fs.readFileSync(path.join(packageRoot,'MANIFEST.json'))),baselineVersion:baseline.version,source,incoming,active,untouched,archiveParent:path.join(path.dirname(root),ARCHIVE),newTopLevel:install,protected:[...PROTECTED],createdAt:new Date().toISOString()};
}
function checkPlan(plan,packageRoot){
 need(plan?.schema==='MCR_BETA_MIGRATION_PLAN_V1'&&plan.release===RELEASE&&!plan.alreadyInstalled,'PLAN_INVALID','Kein anwendbarer Umstellungsplan.');
 guardedTarget(plan.target,packageRoot);verifyRelease(packageRoot);
 need(plan.packageHash===sha(fs.readFileSync(path.join(packageRoot,'MANIFEST.json'))),'PACKAGE_CHANGED','Installationspaket seit Vorschau geaendert.');
 for(const x of plan.source){need(oneName(x.name),'PLAN_PATH','Unsicherer Quellpfad.');need(sameRecord(x,treeRecord(path.join(plan.target,x.name))),'SOURCE_CHANGED','Software seit Vorschau geaendert: '+x.name);}
 for(const x of plan.incoming){need(oneName(x.name),'PLAN_PATH','Unsicherer Paketpfad.');need(sameRecord(x,treeRecord(path.join(packageRoot,x.name))),'PACKAGE_CHANGED','Paket seit Vorschau geaendert: '+x.name);}
 sameActive(plan.target,plan.active);
}
function copyItem(source,dest){
 assertPlainPath(source);need(!fs.existsSync(dest),'DEST_EXISTS','Ziel existiert bereits: '+path.basename(dest));
 const st=fs.lstatSync(source);
 if(st.isDirectory()){fs.mkdirSync(dest);for(const n of fs.readdirSync(source))copyItem(path.join(source,n),path.join(dest,n));}
 else{need(st.isFile(),'SPECIAL_FILE','Keine normale Quelldatei.');fs.copyFileSync(source,dest,fs.constants.COPYFILE_EXCL);}
}
function journalWrite(j){return journalJSON(path.join(j.archive,'migration.json'),j);}
export function applyPlan(plan,{packageRoot=PACKAGE_ROOT,idleCheck,fault=null}={}){
 need(typeof idleCheck==='function','IDLE_CHECK_REQUIRED','Eine Prozesspruefung ist Pflicht.');idleCheck(plan.target);checkPlan(plan,packageRoot);
 const root=plan.target;const lock=acquireLock(root,'MIGRATION');let j=null;
 try{
  idleCheck(root);checkPlan(plan,packageRoot);
  if(!fs.existsSync(plan.archiveParent))fs.mkdirSync(plan.archiveParent);assertPlainPath(plan.archiveParent);
  const archive=path.join(plan.archiveParent,ARCHIVE_PREFIX+stamp());fs.mkdirSync(archive);
  j={...plan,archive,schema:'MCR_BETA_MIGRATION_JOURNAL_V1',state:'STAGING',movedOld:[],installedNew:[],createdAt:new Date().toISOString()};
  fs.mkdirSync(path.join(archive,'software'));fs.mkdirSync(path.join(archive,'stage'));journalWrite(j);
  fs.writeFileSync(path.join(archive,'NUR_LOKAL.txt'),'Lokales Softwarearchiv und Umstellungsjournal. Keine Tickets, Mappings oder Browserprofile zuruecksetzen. Konfigurationen koennen private Pfade enthalten: nicht pauschal weitergeben.\n',{flag:'wx'});
  // Stage the complete release and verify it before moving any original file.
  for(const x of j.incoming)copyItem(path.join(packageRoot,x.name),path.join(archive,'stage',x.name));
  verifyRelease(path.join(archive,'stage'));checkPlan(plan,packageRoot);idleCheck(root);
  fs.writeFileSync(path.join(root,BARRIER),'Umstellung aktiv. Nicht starten. Wiederherstellung mit BETA_ZURUECK.cmd aus dem entpackten Betapaket.\n',{flag:'wx'});
  j.state='MOVING_OLD';journalWrite(j);let count=0;
  for(const x of j.source){
   j.intent={phase:'OLD',name:x.name};journalWrite(j);
   fs.renameSync(path.join(root,x.name),path.join(archive,'software',x.name));
   fault?.('after-old-rename',++count,j);
   j.movedOld.push(x.name);delete j.intent;journalWrite(j);
  }
  j.state='INSTALLING';journalWrite(j);count=0;
  for(const x of j.incoming){
   j.intent={phase:'NEW',name:x.name};journalWrite(j);
   fs.renameSync(path.join(archive,'stage',x.name),path.join(root,x.name));
   fault?.('after-new-rename',++count,j);
   j.installedNew.push(x.name);delete j.intent;journalWrite(j);
  }
  // The barrier is a TXT file, so release verification remains valid during commit.
  verifyRelease(root);sameActive(root,j.active);
  const receipt={schema:'MCR_BETA_INSTALL_V1',release:RELEASE,engineVersion:'0.7.4',installedAt:new Date().toISOString(),archive,journal:path.join(archive,'migration.json'),engineUnchanged:true,activeMappingUnchanged:true};
  atomicJSON(path.join(root,'.runtime','beta-control','install.json'),receipt);
  j.state='COMPLETE';j.completedAt=new Date().toISOString();journalWrite(j);
  fs.unlinkSync(path.join(root,BARRIER));return {state:'COMPLETE',archive,oldTopItems:j.source.length,newTopItems:j.incoming.length,activeUnchanged:true};
 }catch(e){
  if(j){
   if(e.simulatedPowerLoss===true)throw e;
   j.errorCode=e.code||'IO_ERROR';journalWrite(j);
   try{rollbackJournal(path.join(j.archive,'migration.json'),{packageRoot,idleCheck,insideMigration:true});}
   catch(rollbackError){e.rollbackCode=rollbackError.code||'IO_ERROR';e.message+=' Rueckweg noch offen: BETA_ZURUECK.cmd verwenden. Archiv: '+j.archive;}
  }
  throw e;
 }finally{try{lock.release();}catch{}}
}
function validateJournal(file,packageRoot){
 assertPlainPath(file);const j=journalRead(file,16*1024*1024);
 need(j.schema==='MCR_BETA_MIGRATION_JOURNAL_V1'&&j.release===RELEASE,'JOURNAL_SCHEMA','Unbekanntes Umstellungsjournal.');
 guardedTarget(j.target,packageRoot);
 const expectedParent=path.join(path.dirname(j.target),ARCHIVE);
 need(path.dirname(j.archive)===expectedParent&&/^beta2_[0-9TZ_-]+[a-f0-9]{8}$/.test(path.basename(j.archive))&&path.resolve(file)===path.join(j.archive,'migration.json'),'JOURNAL_PATH','Journal gehoert nicht zum lokalen Betaarchiv.');
 assertPlainPath(j.archive);const allowedOld=new Set(oldNames(packageRoot)),allowedNew=new Set(newNames(packageRoot));
 need(Array.isArray(j.source)&&Array.isArray(j.incoming),'JOURNAL_CONTENT','Journal ist unvollstaendig.');
 for(const x of j.source)need(oneName(x.name)&&allowedOld.has(x.name),'JOURNAL_PATH','Nicht erlaubter alter Softwarepfad.');
 for(const x of j.incoming)need(oneName(x.name)&&allowedNew.has(x.name),'JOURNAL_PATH','Nicht erlaubter neuer Softwarepfad.');
 need(new Set(j.source.map(x=>x.name)).size===j.source.length&&new Set(j.incoming.map(x=>x.name)).size===j.incoming.length,'JOURNAL_CONTENT','Doppelte Journaleintraege.');
 return j;
}
export function rollbackJournal(file,{packageRoot=PACKAGE_ROOT,idleCheck,insideMigration=false,fault=null}={}){
 need(typeof idleCheck==='function','IDLE_CHECK_REQUIRED','Prozesspruefung fehlt.');verifyRelease(packageRoot);let j=validateJournal(file,packageRoot);
 idleCheck(j.target);if(j.state==='ROLLED_BACK')return {state:'ALREADY_ROLLED_BACK',archive:j.archive};
 const root=j.target,backup=path.join(j.archive,'software'),stage=path.join(j.archive,'stage');
 const retired=path.join(j.archive,'beta_retired');if(!fs.existsSync(retired))fs.mkdirSync(retired);assertPlainPath(retired);
 // Validate *all* old material before restoring any of it. For interrupted renames,
 // the location + hash decides what happened; the latest journal intent is not trusted alone.
 for(const x of j.source){
  const old=path.join(backup,x.name),live=path.join(root,x.name);
  if(fs.existsSync(old))need(sameRecord(x,treeRecord(old)),'BACKUP_CHANGED','Archivierte Software geaendert: '+x.name);
  else need(fs.existsSync(live)&&sameRecord(x,treeRecord(live)),'BACKUP_MISSING','Original weder unveraendert im Archiv noch am Ursprungsort: '+x.name);
 }
 let lock=null;if(!insideMigration)lock=acquireLock(root,'ROLLBACK');
 try{
  j.state='ROLLING_BACK';journalWrite(j);
  // Keep every installed beta item, including newly added local files, in beta_retired.
  for(const x of j.incoming){
   const live=path.join(root,x.name),staged=path.join(stage,x.name),old=path.join(backup,x.name);
   const orig=j.source.find(y=>y.name===x.name);
   const isOriginal=orig&&!fs.existsSync(old)&&fs.existsSync(live)&&sameRecord(orig,treeRecord(live));
   if(fs.existsSync(live)&&!isOriginal){
    need(!fs.existsSync(staged),'ROLLBACK_CONFLICT','Beide neue Orte belegt: '+x.name+'. Keine Datei wird ueberschrieben.');
    treeRecord(live);const dest=path.join(retired,x.name);need(!fs.existsSync(dest),'ROLLBACK_CONFLICT','Rueckwegarchiv belegt: '+x.name);
    fs.renameSync(live,dest);fault?.('after-retire',x.name,j);
   }
  }
  for(const x of j.source){
   const old=path.join(backup,x.name),live=path.join(root,x.name);
   if(fs.existsSync(old)){need(!fs.existsSync(live),'ROLLBACK_CONFLICT','Originalziel noch belegt: '+x.name);fs.renameSync(old,live);fault?.('after-restore',x.name,j);}
   need(sameRecord(x,treeRecord(live)),'ROLLBACK_VERIFY','Wiederherstellung abweichend: '+x.name);
  }
  verifyBaseline(root,packageRoot);activeSnapshot(root); // current data remains current, not restored to an old mapping
  j.state='ROLLED_BACK';j.rolledBackAt=new Date().toISOString();delete j.intent;journalWrite(j);
  const marker=path.join(root,BARRIER);if(fs.existsSync(marker))fs.unlinkSync(marker);
  const ctrl=path.join(root,'.runtime','beta-control');atomicJSON(path.join(ctrl,'rollback.json'),{schema:'MCR_BETA_ROLLBACK_V1',state:'SOFTWARE_RESTORED',createdAt:new Date().toISOString(),dataRestored:false,ticketActionsUndone:false});
  return {state:'SOFTWARE_RESTORED',archive:j.archive};
 }finally{try{lock?.release();}catch{}}
}
export function findJournals(root){
 const parent=path.join(path.dirname(path.resolve(root)),ARCHIVE);if(!fs.existsSync(parent))return [];assertPlainPath(parent);
 return fs.readdirSync(parent).filter(n=>/^beta2_/.test(n)).map(n=>path.join(parent,n,'migration.json')).filter(f=>fs.existsSync(f)||fs.existsSync(f+'.bak')).sort().reverse();
}
