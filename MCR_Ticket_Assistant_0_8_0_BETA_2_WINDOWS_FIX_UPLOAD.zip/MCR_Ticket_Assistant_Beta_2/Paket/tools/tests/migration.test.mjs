/** Extended qualification: requires an unpacked original 0.7.4 release via MCR_BASELINE_DIR. */
import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';
import {PACKAGE_ROOT,verifyRelease,verifyBaseline,treeRecord,jsonRead,sha} from '../beta-common.mjs';
import {makePlan,applyPlan,rollbackJournal,findJournals,activeSnapshot} from '../migration.mjs';
import {fakeData,temp,dispose} from './fixtures.mjs';
const base=process.env.MCR_BASELINE_DIR;
const err=code=>e=>e.code===code;
const idle=()=>({checked:true,blockedCount:0,unknownCount:0});
function fixture(){
 const parent=temp(),root=path.join(parent,'MCR_Datenbruecke');fs.cpSync(base,root,{recursive:true});fakeData(root);
 fs.writeFileSync(path.join(parent,'FIKTIVE_QUELLE.xlsx'),'SYNTHETIC_WORKBOOK_SENTINEL');
 fs.mkdirSync(path.join(root,'MCR_QUEUE_DETECTION_TEST_0_1'));fs.writeFileSync(path.join(root,'MCR_QUEUE_DETECTION_TEST_0_1','local-test.mjs'),'// locally added historical test');
 fs.writeFileSync(path.join(root,'private-notes.txt'),'UNKNOWN_FILE_STAYS');
 fs.writeFileSync(path.join(root,'src','__tmp_editorreset.mjs'),'// locally added old experiment');
 fs.writeFileSync(path.join(root,'config','local-runner-gender.json'),'{}');
 return {parent,root};
}
function protectedState(root){return Object.fromEntries(['private_data','.runtime/edge-profile','.runtime/downloads','diagnostics','.git','private-notes.txt'].map(x=>[x,treeRecord(path.join(root,x))]));}
function withFixture(fn){const f=fixture();try{return fn(f);}finally{dispose(f.parent);}}
const options={skip:!base};
test('preview does not mutate any files and excludes browser/private data',options,()=>withFixture(({root})=>{const before=treeRecord(root),p=makePlan(root);assert.deepEqual(treeRecord(root),before);assert.ok(p.source.some(x=>x.name==='src'));assert.ok(p.source.some(x=>x.name==='MCR_QUEUE_DETECTION_TEST_0_1'));for(const n of ['.runtime','private_data','diagnostics','.git'])assert.ok(!p.source.some(x=>x.name===n));}));
test('install and rollback retain all original software plus private sentinels',options,()=>withFixture(({root,parent})=>{
 const before=protectedState(root),p=makePlan(root),r=applyPlan(p,{idleCheck:idle});assert.equal(r.state,'COMPLETE');verifyRelease(root);assert.deepEqual(protectedState(root),before);assert.equal(fs.readFileSync(path.join(parent,'FIKTIVE_QUELLE.xlsx'),'utf8'),'SYNTHETIC_WORKBOOK_SENTINEL');
 assert.ok(fs.existsSync(path.join(r.archive,'software','src','__tmp_editorreset.mjs')));assert.ok(fs.existsSync(path.join(r.archive,'software','MCR_QUEUE_DETECTION_TEST_0_1')));
 assert.ok(!fs.existsSync(path.join(root,'START_FULL_QUEUE_RUN.cmd')));const back=rollbackJournal(path.join(r.archive,'migration.json'),{idleCheck:idle});assert.equal(back.state,'SOFTWARE_RESTORED');verifyBaseline(root);assert.deepEqual(protectedState(root),before);for(const x of p.source)assert.equal(treeRecord(path.join(root,x.name)).digest,x.digest);
}));
test('already installed beta is idempotent; no second archive',options,()=>withFixture(({root})=>{applyPlan(makePlan(root),{idleCheck:idle});const j=findJournals(root);assert.equal(makePlan(root).alreadyInstalled,true);assert.deepEqual(findJournals(root),j);}));
test('closed source invariant detects change after preview',options,()=>withFixture(({root})=>{const p=makePlan(root);fs.appendFileSync(path.join(root,'src/local-bot-full-run.mjs'),'//edit');assert.throws(()=>applyPlan(p,{idleCheck:idle}),err('SOURCE_CHANGED'));assert.equal(findJournals(root).length,0);}));
test('active pointer change after preview blocks before mutation',options,()=>withFixture(({root})=>{const p=makePlan(root);fs.appendFileSync(path.join(root,'private_data/active-mapping.json'),' ');assert.throws(()=>applyPlan(p,{idleCheck:idle}),err('ACTIVE_CHANGED'));assert.equal(findJournals(root).length,0);}));
test('running process guard blocks before mutation',options,()=>withFixture(({root})=>{const p=makePlan(root),before=treeRecord(root);assert.throws(()=>applyPlan(p,{idleCheck:()=>{throw Object.assign(new Error('busy'),{code:'BUSY'});}}),err('BUSY'));assert.deepEqual(treeRecord(root),before);}));
test('idle check cannot be omitted',options,()=>withFixture(({root})=>assert.throws(()=>applyPlan(makePlan(root)),err('IDLE_CHECK_REQUIRED'))));
test('unknown folder collision is not overwritten',options,()=>withFixture(({root})=>{fs.mkdirSync(path.join(root,'tools'));fs.writeFileSync(path.join(root,'tools/own.txt'),'KEEP');assert.throws(()=>makePlan(root),err('UNKNOWN_COLLISION'));assert.equal(fs.readFileSync(path.join(root,'tools/own.txt'),'utf8'),'KEEP');}));
test('software symlink blocks before staging',options,()=>withFixture(({root,parent})=>{fs.symlinkSync(parent,path.join(root,'src/linked'),process.platform==='win32'?'junction':'dir');assert.throws(()=>makePlan(root),err('LINK_BLOCKED'));}));
test('wrong target name rejected',options,()=>withFixture(({root,parent})=>{const other=path.join(parent,'NotThisProject');fs.renameSync(root,other);assert.throws(()=>makePlan(other),err('TARGET_NAME'));}));
for(const [phase,index] of [['after-old-rename',1],['after-old-rename',12],['after-old-rename',30],['after-new-rename',1],['after-new-rename',5],['after-new-rename',10]]){
 test('automatic rollback on injected failure '+phase+' '+index,options,()=>withFixture(({root})=>{const before=protectedState(root),p=makePlan(root);assert.throws(()=>applyPlan(p,{idleCheck:idle,fault:(at,n)=>{if(at===phase&&n===index)throw Object.assign(new Error('injected'),{code:'INJECTED'});}}),err('INJECTED'));verifyBaseline(root);assert.deepEqual(protectedState(root),before);assert.equal(jsonRead(findJournals(root)[0]).state,'ROLLED_BACK');}));
}
for(const [phase,index] of [['after-old-rename',3],['after-new-rename',4]]){
 test('recovery after crash between rename and journal '+phase,options,()=>withFixture(({root})=>{const before=protectedState(root),p=makePlan(root);assert.throws(()=>applyPlan(p,{idleCheck:idle,fault:(at,n)=>{if(at===phase&&n===index)throw Object.assign(new Error('crash'),{code:'CRASH',simulatedPowerLoss:true});}}),err('CRASH'));const f=findJournals(root)[0];rollbackJournal(f,{idleCheck:idle});verifyBaseline(root);assert.deepEqual(protectedState(root),before);}));
}
test('rollback refusal on changed backup does not overwrite beta',options,()=>withFixture(({root})=>{const r=applyPlan(makePlan(root),{idleCheck:idle});fs.appendFileSync(path.join(r.archive,'software/src/local-bot-full-run.mjs'),'//bad');assert.throws(()=>rollbackJournal(path.join(r.archive,'migration.json'),{idleCheck:idle}),err('BACKUP_CHANGED'));verifyRelease(root);}));
test('rollback preserves locally added beta files in retired archive',options,()=>withFixture(({root})=>{const r=applyPlan(makePlan(root),{idleCheck:idle});fs.writeFileSync(path.join(root,'tools','my-note.txt'),'KEEP ME');rollbackJournal(path.join(r.archive,'migration.json'),{idleCheck:idle});assert.equal(fs.readFileSync(path.join(r.archive,'beta_retired','tools','my-note.txt'),'utf8'),'KEEP ME');verifyBaseline(root);}));
test('repeated rollback is no-op',options,()=>withFixture(({root})=>{const r=applyPlan(makePlan(root),{idleCheck:idle}),f=path.join(r.archive,'migration.json');rollbackJournal(f,{idleCheck:idle});assert.equal(rollbackJournal(f,{idleCheck:idle}).state,'ALREADY_ROLLED_BACK');}));
test('journal cannot address protected mapping folder',options,()=>withFixture(({root})=>{const r=applyPlan(makePlan(root),{idleCheck:idle}),f=path.join(r.archive,'migration.json'),j=jsonRead(f);j.incoming.push({name:'private_data'});fs.writeFileSync(f,JSON.stringify(j));const before=protectedState(root);assert.throws(()=>rollbackJournal(f,{idleCheck:idle}),err('JOURNAL_PATH'));assert.deepEqual(protectedState(root),before);}));
test('installed CLI resolves own root after relocation with spaces and Unicode',options,async()=>{
 const {execFileSync}=await import('node:child_process');const f=fixture();const moved=path.join(f.parent,'Test Leerzeichen Aeu ß');fs.mkdirSync(moved);const root=path.join(moved,'MCR_Datenbruecke');fs.renameSync(f.root,root);
 try{applyPlan(makePlan(root),{idleCheck:idle});const out=execFileSync(process.execPath,[path.join(root,'tools/beta-cli.mjs'),'--status'],{encoding:'utf8',cwd:f.parent});assert.match(out,/17 Kern-Dateien bytegleich/);assert.match(out,/Verwendbare Personen: 1/);assert.match(out,/0\.8\.0-beta\.2/);}finally{dispose(f.parent);}
});
