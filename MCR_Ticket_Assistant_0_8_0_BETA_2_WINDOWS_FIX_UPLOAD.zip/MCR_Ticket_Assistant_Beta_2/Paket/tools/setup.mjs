/** Installer UI. Default is inspection; mutation requires UMSTELLEN/ZURUECK. */
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';
import readline from 'node:readline/promises';
import {PACKAGE_ROOT,RELEASE,need,verifyRelease,assertWindowsIdle,jsonRead,journalRead,processAlive,stamp,assertPlainPath} from './beta-common.mjs';
import {makePlan,applyPlan,rollbackJournal,findJournals} from './migration.mjs';
async function ask(s){const rl=readline.createInterface({input:process.stdin,output:process.stdout});try{return String(await rl.question(s)).trim();}finally{rl.close();}}
const args=process.argv.slice(2),opt=n=>{const i=args.indexOf(n);return i>=0?args[i+1]:null;};
function strip(s){return s.trim().replace(/^"(.*)"$/,'$1');}
function oldDefault(){return path.join(os.homedir(),'projects','Aktive_Projekte','Ticket_bot','MCR_Datenbruecke');}
function clearDeadOperationLock(root){
 const file=path.join(root,'.runtime','beta-control','operation.lock.json');if(!fs.existsSync(file))return;
 assertPlainPath(file);const lock=jsonRead(file,65536);need(lock.schema==='MCR_OPERATION_LOCK_V1'&&['MIGRATION','ROLLBACK'].includes(lock.operation),'RUN_REVIEW_REQUIRED','Es liegt keine tote Umstellungssperre vor. Einen unterbrochenen Ticketlauf zuerst ueber START.cmd / Wiederanlauf pruefen.');
 need(!processAlive(lock.pid),'OPERATION_ALIVE','Eine Umstellung ist noch aktiv. Keine Wiederherstellung.');
 const dir=path.join(root,'.runtime','beta-control','lock_archive');fs.mkdirSync(dir,{recursive:true});assertPlainPath(dir);
 fs.renameSync(file,path.join(dir,'migration_lock_'+stamp()+'.json'));
}
try{
 verifyRelease(PACKAGE_ROOT);
 const target=path.resolve(strip(opt('--target')||(await ask('Vorhandener Projektordner [ENTER = '+oldDefault()+']: '))||oldDefault()));
 if(args.includes('--rollback')){
  assertWindowsIdle(target);
  const all=findJournals(target),usable=all.filter(f=>{try{return journalRead(f).state!=='ROLLED_BACK';}catch{return false;}});
  need(usable.length>0,'NO_ROLLBACK','Kein offenes/lokales Beta-Umstellungsarchiv gefunden.');
  const file=usable[0],j=journalRead(file);
  console.log('\nSOFTWARE-RUECKWEG\nZiel: '+target+'\nArchiv: '+j.archive+'\nZustand: '+j.state);
  console.log('Nur Software wird zurueckgestellt. Keine versendete Mail, kein Ticket und kein Mapping werden rueckgaengig gemacht.');
  if((await ask('Diesen Softwarestand wiederherstellen? ZURUECK: ')).toUpperCase()!=='ZURUECK'){console.log('Abgebrochen. Keine Aenderung.');process.exitCode=0;}
  else{assertWindowsIdle(target);clearDeadOperationLock(target);const r=rollbackJournal(file,{idleCheck:assertWindowsIdle});console.log('\n'+r.state+'\nSoftware wiederhergestellt. Benutzerdaten unveraendert.\nArchiv: '+r.archive);}
 }else{
  const p=makePlan(target);
  if(p.alreadyInstalled){console.log('\nBETA BEREITS INSTALLIERT | '+RELEASE+'\nPaket und aktives Mapping geprueft. Kein weiteres Archiv erzeugt.\nAb jetzt: '+path.join(target,'START.cmd'));}
  else{
   console.log('\n==============================================================\n VORSCHAU - NOCH KEINE DATEI VERSCHOBEN\n==============================================================');
   console.log('Ziel bleibt: '+p.target+'\nSoftwarebasis: '+p.baselineVersion+'\nNeues Paket: '+RELEASE);
   console.log('Softwarebestand: '+p.source.reduce((s,x)=>s+x.files,0)+' Dateien / '+p.source.length+' oberste Eintraege ins lokale Archiv.');
   console.log('Neuer Programmeinstieg: START.cmd\nArchiv: '+p.archiveParent+'\\beta2_<Zeitpunkt>\\software');
   console.log('Geschuetzt: private_data, .runtime/edge-profile, bisherige Laufdaten, diagnostics, .git, die XLSX im uebergeordneten Ordner.');
   console.log('Das Mapping '+p.active.file+' bleibt aktiv; keine erneute Aktivierung noetig.');
   console.log('Archiviert werden:\n  '+p.source.map(x=>x.name).join('\n  '));
   console.log('Bestehende oberste Eintraege ohne Verschiebung:\n  '+p.untouched.join('\n  '));
   console.log('\nAlten MCR-Bot UND das eigene MCR-Edge-Fenster vorher schliessen.\nAndere Edge-Fenster/Programme werden nicht beendet. Kein Browserstart, kein Versand.');
   if(args.includes('--plan-only'))console.log('\nNUR VORSCHAU beendet.');
   else if((await ask('\nUmstellung jetzt mit Archiv und Rueckweg ausfuehren? UMSTELLEN: ')).toUpperCase()!=='UMSTELLEN')console.log('Abgebrochen. Keine Aenderung.');
   else{
    // A previous setup may have died before its finally-block removed the operation lock.
    // Only a dead MIGRATION/ROLLBACK lock is archived; live/unknown locks remain fail-closed.
    assertWindowsIdle(target);clearDeadOperationLock(target);
    const r=applyPlan(p,{idleCheck:assertWindowsIdle});
    console.log('\n==============================================================\n BETA-UMSTELLUNG ABGESCHLOSSEN\n==============================================================');
    console.log('Ticketkern: 17 Dateien bytegleich zu 0.7.4\nAktives Mapping: SHA256 unveraendert\nEdge-Profil: am bisherigen Ort, nicht gelesen/kopiert/verschoben\nSoftwarearchiv: '+r.archive+'\nStart: '+path.join(target,'START.cmd'));
    console.log('\nJetzt START.cmd oeffnen: zuerst Menue 2 (Status), danach 3 (fiktive Demo).\nDieser Installer startet KEINEN Ticketlauf.');
   }
  }
 }
}catch(e){console.error('\nSTOP: '+(e.code||'SETUP_ERROR')+' - '+e.message);process.exitCode=1;}
