# Technische Referenzen für die neue Release-Hülle

Abruf am 6. Oktober 2026. Ausschließlich öffentliche Primärdokumentation; private COMARCH-Seiten
oder Kundenakten wurden dafür nicht im Web gesucht.

* Node.js 22 Dateisystem: https://nodejs.org/docs/latest-v22.x/api/fs.html
  Exclusives Kopieren/Öffnen, Rename, lstat und Verzeichnisbehandlung.
* Node.js Child Process: https://nodejs.org/api/child_process.html
  Direkter Prozessstart mit Argumentliste; keine Shell für Node-Aufrufe.
* Microsoft Get-CimInstance, PowerShell 5.1: https://learn.microsoft.com/en-us/powershell/module/cimcmdlets/get-ciminstance?view=powershell-5.1
* Microsoft Prozess-CommandLine: https://devblogs.microsoft.com/scripting/powertip-use-powershell-to-find-command-line-of-processes/
* Microsoft Edge UserDataDir: https://learn.microsoft.com/en-us/deployedge/microsoft-edge-policies/UserDataDir
  Edge verwaltet die Inhalte seines Benutzerdatenverzeichnisses selbst. Daher kein pauschales
  Umräumen oder Löschen einzelner Profildateien durch die Beta-Bereinigung.

Die Webseiten sind weder Abhängigkeiten noch Downloadziele des Programms. Das ausgelieferte
Handbuch lädt keine externen Inhalte. Betriebliches Edge/COMARCH nutzt im echten Lauf wie bisher
seine eigenen Netzverbindungen.
