# Architektur und Umstellungsgrenzen

## Keine Umstrukturierung des bewährten Ticketalgorithmus

Beta-Paket 0.8.0-beta.2 verwendet den vollständigen Vollrunner 0.7.4 unverändert. Die produktiven
Importpfade bleiben src/ und lib/. Hier wird nicht die enorme Edge-Verzeichnisstruktur umbenannt,
nicht der Browser neu konfiguriert und kein bestehendes Mapping neu interpretiert.
Die neue Shell ist `tools/beta-cli.mjs`. Sie stellt ein Menü, Releaseprüfung, lokale Sperre und einen
konservativen Abbruchmarker bereit. Sie modifiziert weder Empfänger noch Nachricht noch Ticketregel.

Der Runtime-Importabschluss umfasst exakt 17 Originaldateien. `engine-lock.json` hält deren
Original-SHA256 fest. `MANIFEST.json` prüft das neue vollständige Paket, nicht ein altes Patchmanifest.
Ein SHA256-Manifest ist eine Integritätsprüfung, keine digitale Herausgebersignatur.

## Ordner

* src/: zwei operative 0.7.4-Einstiegsskripte.
* lib/: 15 benötigte, unveränderte Laufzeitmodule.
* config/: eine versiegelte Runner-Konfiguration ohne alte, absolute Mappingpfade.
* tools/: Menü, Installer, Rückweg, Prozessprüfung und aktuelle Tests; keine alten Alternativrunner.
* docs/: Handbuch, Grenzen und aktuelle Qualifikation.
* private_data/: unveränderte private Mappings, Aktivierungszeiger und ältere Rückstände.
* .runtime/: unverändertes Browserprofil/Downloads; zusätzlich beta-control für lokale Sperre/Status.
* diagnostics/: vorhandene und neue Engine-Diagnosen bleiben bestehen.

Die drei privaten Ordner sind nicht im Liefer-ZIP enthalten. `.gitignore` schließt sie aus.
Keine Schriftdateien, Cookies, Erweiterungsdateien, echten MSG/XLSX oder Kundenmappings werden verpackt.
Die zwei Datenbeispiele unter tools/demo sind fiktiv.

## Umstellungsverfahren

1. Vollständiges Lieferpaket und 0.7.4-Quellmanifest prüfen.
2. Ausschließlich bekannte Softwareeinträge inventarisieren; Verknüpfungen nicht verfolgen.
3. Aktiven Mappingzeiger und Snapshot prüfen und Prüfsummen binden.
4. Vorschau anzeigen; keine Zieländerung vor ausdrücklichem UMSTELLEN.
5. Prozessprüfung: kein eigener MCR-Runner/Edge darf aktiv sein. Keine Prozessbeendigung.
6. Neue Software in einem gleichvolumigen, zeitgestempelten Archiv staging vorbereiten und prüfen.
7. Alte bekannte Softwareeinträge per Rename archivieren; die neuen per Rename einsetzen.
8. Paket, 17 Kern-Dateien und unveränderten aktiven Snapshot erneut prüfen.
9. Lokalen Installationsbeleg schreiben. Kein COMARCH-Zugriff durch den Installer.

Jeder Umbenennung geht ein Journal-Intent voraus. Nach einem unterbrochenen Rename wird der tatsächliche
Ort plus Hash der Software geprüft, nicht nur eine möglicherweise veraltete Journalzeile. Der gesamte
Mehrdateiwechsel ist nicht atomar. Bei einem Fehler wird ein Software-Rückweg versucht; bei Stromausfall
kann `BETA_ZURUECK.cmd` aus dem getrennt entpackten Paket das Journal verwenden. Die Dateien des
Beta-Zustands werden beim Rückweg ebenfalls archiviert, nicht gelöscht.

Unbekannte oberste Einträge bleiben. Zusätzliche lokale Dateien innerhalb bekannter Softwareordner
werden zusammen mit ihrem Ordner archiviert. Kollisionen mit neuen Ordnern stoppen die Umstellung.
Die Excel-Datei im übergeordneten Ordner wird nicht gelesen oder verschoben.

## Start-/Abbruchschutz

Die Shell verwendet einen exklusiven lokalen Dateilock und prüft laufende Windows-Prozesse. Ein
unklarer/abgebrochener Beta-Lauf hinterlässt STOP_REVIEW_REQUIRED. Eine neue Freigabe dokumentiert nur,
dass der Benutzer den COMARCH-Ausgang selbst geprüft hat. Die Shell hat keinen neuen Versandalgorithmus
und stellt keine verteilte oder absturzfeste Genau-einmal-Zustellung her. Die alte Aussage über genau
 einen Sendeklick im Runnerprotokoll ist nicht als End-to-End-Zustellgarantie zu verstehen.

Die Demo kopiert ausschließlich die geprüften Laufzeitdateien und fiktive Beispiele in einen neu erzeugten
Tempordner. Sie verwendet weder private_data noch das bestehende MCR-Browserprofil. Die lokalen Demoordner
bleiben für Prüfung erhalten; sie enthalten keine importierten echten Geschäftsdaten.

## Wartung und Rückweg

Aktuelle Mappings bleiben an ihrem unveränderten Pfad. Die neue Beta muss nicht mit einem neuen JSON
aktiviert werden. Das Wartungsmenü ruft den unveränderten Exporter nur für dieselbe freigegebene XLSX auf.
Ein anderer Quelldatenstand erfordert weiter eine gesonderte fachliche Freigabe; hier wird kein Gate gelockert.

Der Software-Rückweg stellt 0.7.4-Dateien wieder her, lässt aber den aktuellen privaten Datenstand und
bestehende COMARCH-Tickets unangetastet. Nach einem bereits vorgenommenen Versand wird niemals durch ein
Datei-Rollback versucht, die Transaktion rückgängig zu machen. Das lokale Archiv nicht pauschal hochladen:
auch historische Konfigurationen können private Pfade enthalten.
