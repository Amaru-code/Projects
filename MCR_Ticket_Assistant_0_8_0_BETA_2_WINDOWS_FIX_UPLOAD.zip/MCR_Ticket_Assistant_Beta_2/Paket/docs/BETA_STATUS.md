# Beta-Status · 6. Oktober 2026

## Vom Benutzer berichteter Realnachweis für den übernommenen Kern 0.7.4

Der bereitgestellte Lauf endete mit RUN COMPLETE und drei bearbeiteten Tickets:
eines aus Meine Vorgänge > In_Bearbeitung und zwei aus Warteschlange > INTL01.
Bei einer Person war eine manuelle Bestätigung für einen Namen nur im zitierten Text nötig.
Ein Ticket enthielt zwei identische Beschreibungszeilen, die separat erhalten blieben.
Der Lauf berichtete je Ticket Anwendungssignale für Versand und anschließend den vollständigen
Beschreibungstextabgleich nach dem Speichern. Die Original-Diagnose wurde in dieser Umstellung nicht
unabhängig abgerufen; diese Realangaben stammen aus dem vom Benutzer eingefügten Protokoll.

## Aktueller Status

BETREUTE_BETA, nicht allgemeine Produktionsfreigabe.
Das neue Paket ist ein Release-/Bedienungs- und Archivierungsschritt. Der Ticketkern bleibt 0.7.4.
Windows-CMD/CIM und die reale Umstellung auf dem Benutzerhost sind hier nicht ausgeführt.
Ein lokaler Status-/Demo-Test und ein beobachteter erster echter Beta-Lauf auf dem Zielhost stehen noch an.

## Unveränderte Grenzen

* Nicht jeder Mailtext liefert eine eindeutige Person; manuelle Gates bleiben.
* Fünf gesperrte Personen im vom Benutzer berichteten Mapping bleiben gesperrt.
* Die Anzeige leerer zusätzlicher Beschreibung bleibt das operative Auswahlkriterium, kein allgemeiner
  dauerhafter Nachweis, dass in der Vergangenheit nie etwas versandt wurde.
* Der Versandnachweis EDITOR_RESET_AFTER_CONFIRMED_DIALOGS ist ein COMARCH-Anwendungssignal und kein
  unabhängiger Empfangs-/Zustellnachweis. Die Zahl der OK-Klicks ist kein fachlicher Qualitätsbeweis.
* Kein neuer abteilungs-/hostübergreifender Wiederholungsschutz und keine neue fachliche Klassifikation
  von Rücknahmen/Erledigungen im Mailtext. Solche Fälle benötigen weiterhin betrieblich definierte Regeln.
* Es werden die in den geprüften Listen gefundenen Tickets verarbeitet; daraus folgt keine Freigabe für
  beliebige Ansichten, beliebige Mengen oder nicht geladene/paginierte Ergebnisse.

Bei unbekanntem Sendestatus zuerst den echten Nachrichtenverlauf prüfen. Die Beta darf Fehler nicht
verdecken, nur weil der Ordner übersichtlicher ist.

## Beta 2 Hotfix

Auf einem verwalteten Windows-Zielhost wurde der erste Migrationsjournal-Commit mit `EPERM` beim Rename einer temporären Datei auf `migration.json` blockiert. Dieser Fehler trat **vor** dem Verschieben der 0.7.4-Software auf. Beta 2 behält atomaren Rename als Standardweg bei und verwendet bei `EPERM`, `EACCES` oder `EBUSY` einen byteverifizierten, `fsync`-gesicherten Direktwrite; bei späteren Journalupdates wird die letzte gültige Version zusätzlich als `migration.json.bak` erhalten. Der Ticketkern 0.7.4 ist unverändert.
