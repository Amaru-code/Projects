import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const src=fs.readFileSync(path.join(root,'src','local-bot-full-run.mjs'),'utf8');

test('Vollrunner priorisiert Meine Vorgänge vor INTL01',()=>{
  const a=src.indexOf("navigateToScope(page,'IN_BEARBEITUNG')");
  const b=src.indexOf("navigateToScope(page,'WARTESCHLANGE_INTL01')",a+1);
  assert.ok(a>=0&&b>a);
});

test('Vollrunner speichert und prüft Persistenz vor nächstem Ticket',()=>{
  assert.match(src,/await saveTicket\(page\)/);
  assert.match(src,/await verifySavedAndReturn\(page,row\.ticketId\)/);
  assert.match(src,/SAVE_UNVERIFIED/);
});

test('Versandnachweis akzeptiert serverseitig geleerten Editor nach bestätigten Dialogen',()=>{
  assert.match(src,/EDITOR_RESET_AFTER_CONFIRMED_DIALOGS/);
  assert.match(src,/dialogCount>=1/);
  assert.match(src,/ed\.ok&&ed\.empty/);
});

test('Doppelversand- und Endlosschleifen-Gates sind vorhanden',()=>{
  assert.match(src,/DUPLICATE_GUARD/);
  assert.match(src,/MAX_TICKETS_REACHED/);
  assert.match(src,/NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS/);
});
