import test from 'node:test';
import assert from 'node:assert/strict';
import {focusInput,setInputQuery} from '../lib/browser-workflow.mjs';

// Isolated COMARCH-like DOM contract: no real person, account or ticket.
async function fixture({occludedAt=[],alwaysOccluded=false,duplicate=false,disabled=false,initialFocus=false,manual=false,manualFocus=true,replaceAfterPoint=false}={},exercise){
 const before={document:globalThis.document};
 const id='mainForm:member-value-id';let block='center',clicks=0,scrolls=[],setCalls=0,events=[];
 const document={activeElement:null,defaultView:{getComputedStyle:()=>({display:'block',visibility:'visible'}),innerWidth:900,innerHeight:650,
   Event:class{constructor(t){this.type=t;}},KeyboardEvent:class{constructor(t){this.type=t;}},HTMLInputElement:class{set value(v){this._value=v;} get value(){return this._value||'';}}}};
 const field=Object.assign(new document.defaultView.HTMLInputElement(),{id,tagName:'INPUT',isConnected:true,disabled,readOnly:false,ownerDocument:document,
  getClientRects:()=>[{left:220,right:520,top:120,bottom:154}],scrollIntoView(o){block=o.block;scrolls.push(block);},dispatchEvent(e){events.push(e.type);return true;}});
 document.activeElement=initialFocus?field:null;
 document.querySelectorAll=s=>s==='input'?(duplicate?[field,field]:[field]):[];
 document.getElementById=x=>x===id?field:null;
 document.elementFromPoint=()=>alwaysOccluded||occludedAt.includes(block)?null:field;
 globalThis.document=document;
 const page={call:async(fn,...args)=>fn(...args),mouseClick:async(x,y)=>{assert.ok(Number.isFinite(x)&&Number.isFinite(y)&&x>=0&&y>=0);clicks++;if(!replaceAfterPoint)document.activeElement=field;}};
 let prompts=0;const manualGate=manual?async()=>{prompts++;if(manualFocus)document.activeElement=field;}:null;
 try {return await exercise({page,id,field,manualGate,stats:()=>({clicks,scrolls,prompts,setCalls,events,focused:document.activeElement===field})});}
 finally {if(before.document===undefined)delete globalThis.document;else globalThis.document=before.document;}
}

test('RC6 input: editable field receives at most one trusted click',async()=>fixture({},async({page,id,stats})=>{
 const result=await focusInput(page,id);assert.equal(result.ok,true);assert.equal(stats().clicks,1);assert.equal(result.method,'SCROLLED_TRUSTED_INPUT');
}));
test('RC6 input: when center is overlaid, scroll to another alignment and hit test',async()=>fixture({occludedAt:['center']},async({page,id,stats})=>{
 const result=await focusInput(page,id);assert.equal(result.ok,true);assert.equal(result.block,'start');assert.deepEqual(stats().scrolls,['center','start']);assert.equal(stats().clicks,1);
}));
test('RC6 input: permanently overlaid member requires verified operator focus',async()=>fixture({alwaysOccluded:true,manual:true},async({page,id,manualGate,stats})=>{
 const result=await setInputQuery(page,id,'Mustermann Max',{manualGate});assert.equal(result,true);
 assert.equal(stats().clicks,0);assert.equal(stats().prompts,1);
 assert.ok(stats().events.includes('input'));assert.ok(stats().events.includes('keyup'));
}));
test('RC6 input: fake manual confirmation without focus remains blocked',async()=>fixture({alwaysOccluded:true,manual:true,manualFocus:false},async({page,id,manualGate,stats})=>{
 await assert.rejects(setInputQuery(page,id,'Mustermann Max',{manualGate}),{code:'MANUAL_INPUT_FOCUS_UNVERIFIED'});
 assert.equal(stats().clicks,0);assert.equal(stats().prompts,1);
}));
test('RC6 input: missing field is never replaced with another clickable element',async()=>fixture({duplicate:true},async({page,id,stats})=>{
 const r=await focusInput(page,id);assert.equal(r.ok,false);assert.equal(r.state,'INPUT_NOT_UNIQUE');assert.equal(stats().clicks,0);
}));
test('RC6 input: a disabled member field does not receive a click',async()=>fixture({disabled:true},async({page,id,stats})=>{
 const r=await focusInput(page,id);assert.equal(r.ok,false);assert.equal(r.state,'INPUT_NOT_EDITABLE');assert.equal(stats().clicks,0);
}));
test('RC6 input: previously focused field needs no second click',async()=>fixture({initialFocus:true},async({page,id,stats})=>{
 const r=await focusInput(page,id);assert.equal(r.ok,true);assert.equal(r.method,'ALREADY_FOCUSED');assert.equal(stats().clicks,0);
}));
test('RC6 input: no duplicate action when the click is not followed by focus',async()=>fixture({replaceAfterPoint:true},async({page,id,stats})=>{
 const r=await focusInput(page,id);assert.equal(r.ok,false);assert.equal(r.state,'INPUT_FOCUS_NOT_CONFIRMED');assert.equal(stats().clicks,1);
}));
