/** Chromium reproduction for an autocomplete target whose raw bounding-box
 * center is negative even though a real portion is clickable. Offline only. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {suggestionPoints} from '../lib/browser-workflow.mjs';
const d=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC5-Geometry-'));
let browser=null,cdp=null;
try{
 const ex=findEdgeExecutable();assert.ok(ex,'Chromium/Edge executable unavailable');
 browser=await launchBrowser({executable:ex,userDataDir:d,startUrl:'about:blank',headless:true,extraArgs:[...(process.platform!=='win32'&&process.getuid?.()===0?['--no-sandbox']:[])]});
 ({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.url==='about:blank');
 await page.eval(`(()=>{document.body.innerHTML='<input id="mainForm:member-value-id" style="position:fixed;top:80px;left:20px;width:220px;height:24px"><div id="choice" style="position:fixed;left:-900px;top:115px;width:1080px;height:27px;background:#eee">Mustermann Max (INTL01-99900001)</div>';window.__clicks=[];const node=document.getElementById('choice');node.onmousedown=e=>window.__clicks.push({trusted:e.isTrusted});window.__originalCenter=node.getBoundingClientRect().left+node.getBoundingClientRect().width/2;})()`);
 assert.ok((await page.eval('window.__originalCenter'))<0,'fixture should reproduce invalid negative center');
 const points=await suggestionPoints(page,'mainForm:member-value-id',['Mustermann Max','Max Mustermann'],{member:true});
 assert.equal(points.length,1,'one selected candidate');assert.ok(points[0].x>=0&&points[0].x<=180);
 await page.mouseClick(points[0].x,points[0].y);
 assert.deepEqual(await page.eval('window.__clicks'),[{trusted:true}]);
 console.log('PASS RC5_NEGATIVE_BOUNDING_CENTER_CLIPPED_TO_TRUSTED_CLICK');
 await page.eval(`(()=>{document.getElementById('choice').style.left='-1300px';window.__clicks=[];})()`);
 const noPoints=await suggestionPoints(page,'mainForm:member-value-id',['Mustermann Max','Max Mustermann'],{member:true});
 assert.deepEqual(noPoints,[]);assert.deepEqual(await page.eval('window.__clicks'),[]);
 console.log('PASS RC5_OFFSCREEN_NO_CLICK');
}finally{try{cdp?.close()}catch{}try{browser?.child?.kill()}catch{}try{fs.rmSync(d,{recursive:true,force:true})}catch{}}
