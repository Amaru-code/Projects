/** Offline Chromium test for actual input focus/scroll recovery. No COMARCH. */
import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {focusInput,setInputQuery} from '../lib/browser-workflow.mjs';
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC6-Focus-'));let browser,cdp;const report={schema:'MCR_RC6_INPUT_FOCUS_BROWSER_V1',checks:[],platform:process.platform,realCOMARCH:false};
try{
 browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:dir,startUrl:'about:blank',headless:true,extraArgs:process.platform!=='win32'&&process.getuid?.()===0?['--no-sandbox']:[]});
 ({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.url==='about:blank');
 const id='mainForm:member-value-id';
 await page.eval(`(()=>{document.body.innerHTML='<div style="height:2400px;position:relative"><input id="mainForm:member-value-id" style="position:absolute;top:1350px;left:30px;width:250px;height:30px"></div><div id="overlay" style="position:fixed;left:0;right:0;top:35%;height:30%;background:#ccc;z-index:999"></div>';window.__trustedInputClicks=[];const n=document.getElementById('mainForm:member-value-id');n.addEventListener('click',e=>window.__trustedInputClicks.push(e.isTrusted));})()`);
 const start=await page.eval(`(()=>{const n=document.getElementById('mainForm:member-value-id');return {windowHeight:innerHeight,top:n.getBoundingClientRect().top,focused:document.activeElement===n}})()`);
 assert.ok(start.top>start.windowHeight,'input must initially be below viewport');
 const r=await focusInput(page,id);assert.ok(r.ok,JSON.stringify(r));assert.equal(r.method,'SCROLLED_TRUSTED_INPUT');
 const state=await page.eval(`(()=>({focused:document.activeElement===document.getElementById('mainForm:member-value-id'),trusted:window.__trustedInputClicks,top:document.getElementById('mainForm:member-value-id').getBoundingClientRect().top}))()`);
 assert.equal(state.focused,true);assert.deepEqual(state.trusted,[true]);
 console.log('PASS RC6_AUTO_SCROLL_WITH_TRUSTED_INPUT_FOCUS',JSON.stringify({block:r.block,startTop:start.top,endTop:state.top}));
 report.checks.push({name:'AUTOMATIC_SCROLL_TRUSTED_INPUT',pass:true,block:r.block});
 // A fully covering shield must NOT be automatically clicked through.
 await page.eval(`(()=>{document.activeElement?.blur();document.getElementById('overlay').style.inset='0';document.getElementById('overlay').style.height='100%';window.__trustedInputClicks=[];})()`);
 let gates=0;
 const ok=await setInputQuery(page,id,'Mustermann Max',{manualGate:async()=>{
   gates++;
   assert.deepEqual(await page.eval('window.__trustedInputClicks'),[]);
   await page.eval('document.getElementById("overlay").remove()');
   const p=await page.call(function(){const f=document.getElementById('mainForm:member-value-id');f.scrollIntoView({block:'center'});const r=f.getBoundingClientRect();return {x:r.left+r.width/2,y:r.top+r.height/2};});
   await page.mouseClick(p.x,p.y);
 }});
 assert.equal(ok,true);assert.equal(gates,1);
 assert.equal(await page.eval('document.getElementById("mainForm:member-value-id").value'),'Mustermann Max');
 assert.deepEqual(await page.eval('window.__trustedInputClicks'),[true]);
 console.log('PASS RC6_OCCLUDED_INPUT_MANUAL_GATE_VERIFIED_AND_QUERY_SET');
 report.checks.push({name:'OCCLUDED_INPUT_NO_AUTOMATIC_CLICK_MANUAL_FOCUS',pass:true});
 // An unconfirmed manual gate cannot make the runner write behind a shield.
 await page.eval(`(()=>{const f=document.getElementById('mainForm:member-value-id');f.blur();document.body.insertAdjacentHTML('beforeend','<div id="overlay" style="position:fixed;inset:0;background:#ddd;z-index:999"></div>');window.__trustedInputClicks=[];})()`);
 await assert.rejects(()=>setInputQuery(page,id,'Should Not Change',{manualGate:async()=>{}}),{code:'MANUAL_INPUT_FOCUS_UNVERIFIED'});
 assert.equal(await page.eval('document.getElementById("mainForm:member-value-id").value'),'Mustermann Max');
 console.log('PASS RC6_UNVERIFIED_MANUAL_GATE_STOPS_WITHOUT_EDITING');
 report.checks.push({name:'UNVERIFIED_MANUAL_GATE_FAIL_CLOSED',pass:true});
}finally{
 try{cdp?.close();}catch{}try{browser?.child?.kill();}catch{}
 try{fs.rmSync(dir,{recursive:true,force:true,maxRetries:3});}catch{}
}
const out=path.join(path.dirname(new URL(import.meta.url).pathname),'../docs/RC6_INPUT_FOCUS_BROWSER.json');fs.writeFileSync(out,JSON.stringify(report,null,2)+'\n');
