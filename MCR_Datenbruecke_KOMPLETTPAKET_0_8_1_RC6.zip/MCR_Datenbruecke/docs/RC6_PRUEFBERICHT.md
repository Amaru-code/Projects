# MCR Datenbrücke 0.8.1 RC6 – technischer Prüfbericht

## Tatsächlicher Auslöser

Der Windows-COMARCH-Einzelpilot unter RC5 stoppte bei `ACTION_OCCLUDED_OR_OFFSCREEN [PHASE MEMBER_SEARCH]`, also **vor** der Bestandsabfrage und damit auch vor dem Prefix-11-Fallback. Die fehlgeschlagene Aktion war das Fokussieren des Member-Eingabefelds über `trustedAction` in `setInputQuery`. Der RC5-Code hatte für ein einmal verdecktes Feld **keinen** automatischen zweiten Scroll-Ausrichtungsversuch und keinen manuellen Fokus-Gate. Die genaue Überlagerung der echten COMARCH-Seite ist nicht eindeutig nachgewiesen.

## Implementierte Korrektur

- `focusInput()` verlangt genau ein verbundenes, editierbares Input mit der erwarteten ID; es wartet bei kurzzeitig fehlendem/disabled Input begrenzt auf die mögliche ICEfaces-Neuzeichnung.
- Automatische Scroll-Ausrichtungen `center`, `start`, `end`, `nearest`, überprüfte, auf den sichtbaren Viewport begrenzte Feldpunkte und erneuter `elementFromPoint()`-Abgleich unmittelbar vor **einem einzigen echten Browser-Klick**.
- Danach wird `document.activeElement === input` geprüft. Bei dauerhaft überdecktem/fehlendem Feld wird kein anderer HTML-Knoten angeklickt, kein DOM-Click und kein im Hintergrund erzwungener Fokus verwendet. Der operatorbestätigte manuelle Klick ist nur mit positiver Fokuskontrolle gültig.
- Für die abhängige Unterkategorie und die Kategorie-/Signatur-Suchfelder gilt der gleiche Feld-Fokusvertrag; Send/Save/Forwarding bleiben bei den bestehenden streng geschützten Aktionen.
- Die originale COMARCH-MercerID wird nicht verändert. Nur nach gesicherter Member-Identität sucht der Bestandsabgleich bei `ID_NOT_FOUND` und einem anfänglichen `11` einmal zusätzlich ohne exakt diese beiden Ziffern. Beide Fehlversuche führen zum getrennten Weiterleitungsweg ohne E-Mail.

## Nachweise (offline/synthetisch)

- Unit- und Installationstests in der lokalen Entwicklungsumgebung: **174/174 PASS, 0 FAIL, 0 SKIP**.
- Drei Chromium-Prüfungen des Fokusmechanismus: überlagertes Feld durch neues Scrollalignment anklickbar; vollständig überdecktes Feld nur nach bestätigtem manuellem Fokus; unbestätigter manueller Fokus verweigert jede Texteingabe. **3/3 PASS**.
- Offizieller Programmdemostarter aus dem RC6-Arbeitsbaum: **3/3 Szenarien PASS**: normales Mapping 2/2 Versand+Save, Prefix11 2/2 Versand+Save, kein Mapping 2/2 Weiterleitung und 0 E-Mail.
- Upgrade-/Rollback mit original veröffentlichtem RC5-ZIP (`SHA256 a3f827efa4f5a6137b82b1a8904d1949936fcd0a5843052f33476aab027c4ca3`): PASS, erhält private_data, Browserprofil, letzten Laufstatus und Diagnosen.

## Nicht nachgewiesen

RC6 wurde nicht gegen eine echte COMARCH-Sitzung oder einen echten Firmen-Windows-Browser ausgeführt. Echte Autocomplete-Layouts, Berechtigungen und mögliche Dialoge bleiben dort zu qualifizieren. Kein produktiver Betrieb und keine automatische Freigabe allein aus den Offline-Tests. Vor neuem echten Einzelpilot: offene Laufprüfung in COMARCH durchführen und ggf. unter Menü 5 freigeben; ein ungeklärter Versand oder eine ungeklärte Weiterleitung darf nicht erneut ausgelöst werden.
