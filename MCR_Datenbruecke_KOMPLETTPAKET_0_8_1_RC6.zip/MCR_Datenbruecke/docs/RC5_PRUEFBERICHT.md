# MCR Datenbrücke 0.8.1 RC5 – technischer Prüfbericht

## Auslöser und Befund

Am 23.10.2026 stoppte der beaufsichtigte RC4-Einzelpilot mit `STOP RUNNER_ERROR: Ungeltige Klickposition` nach dem Öffnen des ersten echten COMARCH-Tickets. Das Foto zeigt eine geöffnete Member-Autocomplete-Auswahl; fachliche Pflichtfelder wurden noch nicht befüllt. Die alte Funktion `suggestionPoints` verwendete den unbeschränkten Mittelpunkt eines Bounding-Rects, der bei teilweise aus dem Browserfenster ragenden Vorschlagscontainern negativ sein kann. Ein Stacktrace des realen Fehlers liegt nicht vor. Deshalb ist die Zuordnung plausibel, aber nicht als einzige mögliche Ursache bewiesen.

## RC5-Korrektur

- Vorschlagsklicks nur auf den **sichtbaren Teil** von Client-Rects, innerhalb der Browser-Viewport-Grenzen und mit `elementFromPoint` verifiziert
- Keine automatischen Klicks auf unsichtbare, verdeckte, uneindeutige oder Eingabefeld-enthaltende Zielcontainer
- Automatische Member-Auswahl direkt vor dem Klick erneut an Punkt und ID gebunden; sonst manuelles Auswählen des COMARCH-Vorschlags mit verpflichtender Identitätsbestätigung
- Datensparsame Prozessphase im Diagnosebericht; negative Koordinaten werden vom CDP-Transport vor jedem Klick mit eigenem Fehlercode abgewiesen
- Browsertransport, E-Mail-Senden, Ticket-Speichern, `11`-Fallback, Weiterleitung, Schutz bei unklarem Zustand und Wiederanlaufsperren bleiben ansonsten unverändert

## Ausgeführte Qualifikation

- **165 / 165 Node-Selbsttests bestanden**, 0 fehlgeschlagen, 0 übersprungen
- Separater echter Chromium-CDP-Klicktest für einen Autocomplete-Kandidaten mit negativem Bounding-Center: `PASS RC5_NEGATIVE_BOUNDING_CENTER_CLIPPED_TO_TRUSTED_CLICK`; offscreen Kandidat: `PASS RC5_OFFSCREEN_NO_CLICK`
- Fiktive Chromium-Zwei-Ticket-Demo `normal`: 2 Versandbestätigungen, 2 Speicherverifikationen, PASS
- Fiktive Chromium-Zwei-Ticket-Demo `prefixed-member`: 2 `PREFIX11_FALLBACK_MATCH`, 2 Versandbestätigungen und 2 Speicherverifikationen, PASS
- Fiktive Chromium-Zwei-Ticket-Demo `missing-member`: 2 Weiterleitungen, 0 E-Mails, PASS
- RC4→RC5-Installation aus dem **originalen, per SHA-256 geprüften RC4-ZIP** sowie vollständiger Rückweg: PASS; aktives Bestandsmapping, Browserprofil, vergangener Laufstatus und Diagnosen blieben unverändert
- Manifest- und Dateihashprüfung beim Erzeugen und erneuten Entpacken der ZIP (siehe SHA256SUMS.txt)

## Betriebsgrenzen und nächster Pilot

**RC5 ist kein erfolgreich auf COMARCH live validierter Produktionsrelease.** Das ursprüngliche RC4-Ticket wurde vor dem Versand abgebrochen. Dadurch ist die Laufkontrolle wahrscheinlich wieder `INTERRUPTED_REVIEW_REQUIRED`. Der Nutzer muss in COMARCH sicher feststellen, ob bei diesem und gegebenenfalls anderen offenen Fällen eine Antwort oder Weiterleitung ausgelöst wurde. Den *eigenen Bot-Edge* schließen, über die `START.cmd` der installierten Version Menü 5 nutzen und nur bei tatsächlichem Nachweis die Sperre freigeben. Ein erneuter Pilot ist danach auf genau ein Ticket begrenzt; reale Nachricht erst nach manueller Kontrolle von Member, Empfänger, Beschreibung und Antwort und explizitem `SENDEN`.

Diese Datei enthält keine Kunden-, Ticket- oder Kontodaten. Die verwendeten Demo-Personen sind fiktiv.
