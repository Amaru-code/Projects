# RC4: Windows-Installationsfix nach EPERM auf `stage/tests`

Am 23.10.2026 beendete die RC3-Einrichtung nach erfolgreichen fiktiven Browserproben den Softwarewechsel bei `fs.renameSync(stage/tests, MCR_Datenbruecke/tests)` mit `EPERM` und meldete `Rueckweg: SOFTWARE_RESTORED`. Es war daher **keine erfolgreiche RC3-Installation**, und der danach gestartete Download-Starter hatte kein `private_data`.

RC4 verwendet zum Einspielen **ausschließlich Kopieren aus einer vollständig verifizierten Stage**, nach jeder installierten Einheit wird der vollständige Baum-Hash verglichen. So entfällt der fehleranfällige Verzeichnis-Rename beim NEW-Schritt. Für das Archivieren alter Software und die Wiederherstellung werden `rename`-Wiederholungen sowie bei Windows-`EPERM` ein verifiziertes Kopieren mit anschließendem Entfernen unterstützt. Weder Mapping noch Browserprofil noch E-Mail-Diagnosen werden kopiert oder überschrieben.

Ein unterbrochener oder inhaltlich ungeprüfter Echtlauf wird durch eine Software-Neuinstallation **nicht** freigegeben. Das letzte RC3-Log `INTERRUPTED_REVIEW_REQUIRED` muss nach tatsächlicher Kontrolle des COMARCH-Tickets über Menü 5 behandelt werden. Keine automatischen Wiederholungsversuche von Senden/Weiterleiten.

**Abnahmegrenze**: Dateisystem-Regressionstests mit simulierter `EPERM`-Sperre sind kein Nachweis des konkreten Firmen-Windows oder von COMARCH. RC4 bleibt bis zur Prüfung vor Ort ein Release-Kandidat. Bei nicht vollständig bestätigtem Rückweg kein neuer Installationsversuch.
