# RC6 – Feld-Fokus nach COMARCH `ACTION_OCCLUDED_OR_OFFSCREEN`

## Evidenz und Fehlerort

Im RC5-Echtpilot stoppte `trustedAction(page,{id:'mainForm:member-value-id'})` in `lib/browser-workflow.mjs/setInputQuery()` bereits bei `PHASE MEMBER_SEARCH`. Das Element existierte eindeutig, aber der Mittelpunkt eines `ClientRect` war beim Browser-Hit-Test nicht erreichbar. Deshalb wurde noch keine Bestands-ID geprüft; ein Prefix11-Fallback wäre an dieser Stelle sinnlos. Ein sichtbares COMARCH-Autocomplete/Overlay kann der Auslöser sein, die konkrete Ursache des echten Overlay-Zustands ist ohne Browsertrace nicht bewiesen.

## RC6-Regeln

- Suche nach exakt einem sichtbaren, bearbeitbaren INPUT mit genau bekannter ID; kein Klick auf Elterncontainer oder fremde Elemente.
- Warte kurz auf ICEfaces-Formularaktualisierung, danach vier begrenzte `scrollIntoView`-Ausrichtungen und mehrere geprüfte Viewport-Punkte, genau einmal den Browser-Mausklick auslösen.
- Nach dem Klick belege über `activeElement`, dass der richtige Input fokussiert wurde. Keine zweite automatische Klickserie bei einem fehlgeschlagenen Versuch.
- Bei vollständig überdecktem/nicht zu erreichendem Eingabefeld: explizite manuelle Fokussierung nur dieses Eingabefeldes, erneut `activeElement` prüfen. Ohne Nachweis kein `input`/`keyup`-Event, keine Server-Aktion.
- Gleiches sichere Verhalten vor der abhängigen Unterkategorie und für Kategorie-/Signaturfelder.
- Die im RC5 abgesicherte Vorschlagsauswahl, die COMARCH-Identität, das aktive V2-Mapping, `11`-Fallback, Weiterleitung ohne Antwortmail, echtes SEND/SAVE und die persistenten Einzelticket-/Wiederanlaufsperren bleiben erhalten.

## Abnahmegrenze

Offline-Unit-Tests und synthetische Chromium-Tests können die reproduzierte Fokus-/Scroll-Geometrie validieren, aber keine vollständige reale COMARCH-Interaktion. Live-Qualifikation erst nach beaufsichtigtem Pilot und tatsächlich bestätigtem Versand oder Weiterleitungsstatus. Es ist keine automatische Produktionsfreigabe.
