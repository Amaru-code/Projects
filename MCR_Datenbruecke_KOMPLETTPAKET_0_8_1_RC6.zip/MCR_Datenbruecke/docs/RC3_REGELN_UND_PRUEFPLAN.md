# RC3 – Regelvertrag und Tests

## Fachliche Reihenfolge

1. COMARCH-Member bleibt unveraendert und muss mit Vor- und Nachnamen abgeglichen sein.
2. Suche V2-Mapping nach der numerischen COMARCH-MercerID. Eine Sperre ID_BLOCKED ist endgueltig.
3. Nur bei ID_NOT_FOUND und genau einem fuehrenden Praefix 11: Suche nach `id.slice(2)`. Nur positive Ziffernfolgen, fuehrende Nullen im Rest erhalten. Keine weitere Kuerzung.
4. Wenn nach den zugelassenen Suchen kein Treffer: keine E-Mail, nur Pflichtbeschreibung `Person nicht im Gesamtbestand gefunden` und Second Level/Allgemeine Schriftwechsel/Personenschriftwechsel/Signatur; vor Weiterleitung alles speichern und danach das persistierte Formular erneut pruefen.
5. Eindeutigen Vorschlag `Gutierrez Victor (Victor.Gutierrez)` im oberen Bearbeiterfeld uebernommen nachweisen; nur einen echten Mausklick auf `Weiterleitung`, bestaetigte Rueckmeldung oder kontrollierte manuelle Nachkontrolle.
6. Aktives Mapping niemals neu erzeugen oder Pointer umhaengen. Journal verhindert stillen Doppelversand und doppeltes Weiterleiten nach ungeklaertem Abbruch.

## Testabnahme

- Unit: exakter Treffer gewinnt, korrektes 11-Kuerzen, fuehrende Nullen, gesperrte direkte/gekuerzte ID, Nicht-11, Not-found und Journaltransitions.
- Browser: normaler fiktiver Ticketablauf, Praefix-11-Ablauf, zwei fiktive Weiterleitungen ohne Mail, ungespeicherte Pflichtfelder, uneindeutiger Vorschlag, unbestaetigte Weiterleitung.
- Install: Version 0.8.1-rc.2 -> 0.8.1-rc.3, separate ZIP mit gesichertem Rollback; kein Aendern echter Datenprofile/Excel/Mapping
- Echtgeldbetrieb: kein COMARCH-Livebeweis in der Entwicklung, nur einzelner lokaler Pilot unter Aufsicht.
