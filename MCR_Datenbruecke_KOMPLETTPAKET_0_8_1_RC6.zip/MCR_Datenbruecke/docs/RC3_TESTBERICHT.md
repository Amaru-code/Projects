# RC3 – Qualifikationsbericht

**Stand:** 23.10.2026. Basis: MCR Datenbruecke 0.8.1-rc.2; Update zu 0.8.1-rc.3.

## Nachgewiesener neuer Fachvertrag

1. Exakte COMARCH-ID wird zuerst gegen das aktivierte V2-Mapping gesucht.
2. Nur bei `ID_NOT_FOUND` wird bei einer ID mit Praefix `11` exakt einmal `slice(2)` versucht. Kein Umbenennen des COMARCH-Members, keine Wiederholung bei gesperrten IDs.
3. Scheitern beide Lookupwege, wird ohne E-Mail die zusaetzliche Beschreibung `Person nicht im Gesamtbestand gefunden` gesetzt, Second Level/Allgemeine Schriftwechsel/Personenschriftwechsel/Signatur gesetzt und gespeichert; erst nach kontrolliertem Nachlesen wird die Weiterleitung an `Gutierrez Victor (Victor.Gutierrez)` einmal angestossen.
4. Versand und Weiterleitung besitzen getrennte persistente Intent-Zustaende. Eine unklare Aktion darf nicht automatisch wiederholt werden. Eine Nur-Weiterleitung ist **kein** Versand-Pilot-Pass.

## Ausgefuehrte Pruefungen im Entwicklungscontainer

- Node.js v22.16.0: **151/151 Unit-/Installations-/Regressionstests bestanden**, 0 Fehler (inklusive exaktem RC2-Originalarchiv, Update, Sicherung und Rueckweg, unveraendertem aktivem Mapping und Browserprofil).
- Isolierte Chromium-Demo **normal**: zwei fiktive Tickets, beide gesendet und gespeichert, Rueckkontrolle bestanden.
- Isolierte Chromium-Demo **prefixed-member**: beide fiktiven Tickets mit `11`-Fallback gesucht, gesendet und gespeichert.
- Isolierte Chromium-Demo **missing-member**: beide fiktiven Tickets mit exakter Fehlbeschreibung gespeichert und jeweils einmal weitergeleitet, **0 gesendete Nachrichten**.
- Negativprobe **missing-fixed-unpersisted**: eindeutiger `ROUTE_FIXED_FIELDS_NOT_SAVED`-Stopp; keine Weiterleitung ohne persistierte Pflichtfelder.
- Negativproben fuer mehrdeutige Victor-Auswahl und nicht bestaetigte Weiterleitung: korrektes Fail-Closed-Verhalten in getrennten fiktiven Laeufen.
- Die kombinierte Linux-Chromium-Stressprobe wurde wegen eines sporadischen Browser-Haengers nicht als PASS gewertet. Jeder neue Demo-Teilprozess hat ein eigenes Browserprofil und im RC3-Start einen Laufzeit-Cutoff; bei unklarem Ergebnis wird keine Freigabe erteilt.

## Noch nicht nachgewiesen

- **Kein** Echtversand und **keine** echte Weiterleitung in COMARCH im Entwicklungscontainer. COMARCH kann insbesondere bei der Bearbeiter-Vorschlagsliste oder nach dem Weiterleitungsklick anders reagieren als die fiktive DOM-Demo.
- Die Weiterleitungsroute bleibt deshalb bewusst beaufsichtigt. Im Zweifel: stoppen, COMARCH manuell pruefen, vor allem nicht blind erneut senden/weiterleiten.
- Die vorhandene RC2-Laufkontrolle kann nach dem abgebrochenen `ID_NOT_FOUND`-Piloten `STOP_REVIEW_REQUIRED` sein; vor neuem Live-Pilot Menue 5 und **tatsaechliche** COMARCH-Kontrolle.

**Bereitstellung:** Vollstaendiges ZIP mit dem Ordner `MCR_Datenbruecke`. Installation ausschliesslich aus separatem entpacktem Paket; keine Datei direkt in den bisherigen Produktionsordner kopieren.
