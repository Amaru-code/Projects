/** Full software deployment, preserving all user data in place.
 * No recursive copy of .runtime/private_data, no browser launch, no ticket action.
 */
import fs from 'node:fs';import path from 'node:path';import {requireThat as need,sha256} from '../lib/core.mjs';import {plainPath,readJSON,writeJSON,stamp,lock,controlDir} from '../lib/control.mjs';import {loadActiveMapping} from '../lib/active-mapping.mjs';import {verifyPackage,verifyPrevious,treeDigest} from './integrity.mjs';import {windowsIdle} from './process-guard.mjs';
const NAMES=['START.cmd','package.json','MANIFEST.json','SHA256SUMS.txt','README_DE.md','README.md','.gitignore','src','lib','tools','tests','docs','examples'];
const BARRIER='BETA_UMSTELLUNG_LAEUFT.txt';
function copyTree(src,dst){plainPath(src);need(!fs.existsSync(dst),'DEST_EXISTS','Ziel existiert bereits.');const s=fs.statSync(src);if(s.isDirectory()){fs.mkdirSync(dst);for(const n of fs.readdirSync(src))copyTree(path.join(src,n),path.join(dst,n));}else{need(s.isFile(),'SOURCE_FILE','Keine normale Softwaredatei.');fs.copyFileSync(src,dst,fs.constants.COPYFILE_EXCL);}}
function targetCheck(source,target){source=plainPath(path.resolve(source));target=plainPath(path.resolve(target));need(path.basename(target).toLowerCase()==='mcr_datenbruecke','TARGET_NAME','Ziel muss MCR_Datenbruecke heissen.');need(source!==target&&!source.startsWith(target+path.sep)&&!target.startsWith(source+path.sep),'SETUP_LOCATION','Neues Paket getrennt ausserhalb der alten Installation entpacken.');return {source,target};}
function dataBinding(root){const a=loadActiveMapping(root);return {mappingFileSha256:a.fileHash,pointerSha256:sha256(fs.readFileSync(a.pointerPath)),configSha256:sha256(fs.readFileSync(path.join(root,'config/local-runner-queue-send.json')))};}
export function planInstall(source,target,{verifyOld=verifyPrevious}={}){({source,target}=targetCheck(source,target));const release=verifyPackage(source);need(!fs.existsSync(path.join(target,BARRIER)),'MIGRATION_INCOMPLETE','Offene Umstellung: Rueckweg im neuen START-Menue verwenden.');const old=verifyOld(target);
 const programs=fs.readdirSync(target).filter(n=>/\.(cmd|bat|ps1|mjs|cjs|js|html)$/i.test(n)&&n!=='START.cmd');need(!programs.length,'UNKNOWN_ROOT_PROGRAM','Unbekannte Programme im Hauptordner. Nichts wird still geloescht.');const before=dataBinding(target),oldItems=NAMES.filter(n=>fs.existsSync(path.join(target,n))).map(name=>({name,hash:treeDigest(path.join(target,name))})),incoming=NAMES.filter(n=>fs.existsSync(path.join(source,n))).map(name=>({name,hash:treeDigest(path.join(source,name))}));return {schema:'MCR_COMPLETE_INSTALL_PLAN_V1',source,target,release,old,before,oldItems,incoming};}
// Windows may temporarily prohibit renaming a directory (especially `tests`)
// while enterprise AV/indexers scan it. A staged copy is safer than requiring a
// directory rename: the deployment barrier remains set throughout, and every
// installed tree is checked against the sealed source digest before proceeding.
const RETRYABLE_MOVE=new Set(['EPERM','EACCES','EBUSY','EXDEV','EINVAL']);
function pause(ms){Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0,ms);}
function tryRename(src,dest){
 let last;
 for(let i=0;i<4;i++){
  try{fs.renameSync(src,dest);return true;}
  catch(e){if(!RETRYABLE_MOVE.has(e.code))throw e;last=e;if(i<3)pause(80*(i+1));}
 }
 return false;
}
function removeSoftware(p){
 plainPath(p);
 fs.rmSync(p,{recursive:true,force:false,maxRetries:6,retryDelay:120});
 need(!fs.existsSync(p),'MOVE_SOURCE_REMAINS','Verifizierte Softwarequelle blieb nach der Archivierung erhalten.');
}
function moveSoftwareVerified(src,dst,expected){
 plainPath(src);need(!fs.existsSync(dst),'DEST_EXISTS','Archiv-/Zielpfad ist bereits belegt.');
 need(treeDigest(src)===expected,'SOURCE_CHANGED','Software vor dem Verschieben veraendert.');
 if(tryRename(src,dst)){
  need(treeDigest(dst)===expected,'MOVE_VERIFY','Verschobene Software weicht ab.');return 'RENAME';
 }
 // Do not delete the source before verifying the independent backup.
 copyTree(src,dst);
 need(treeDigest(dst)===expected,'MOVE_COPY_VERIFY','Kopierte Software weicht vom Original ab.');
 removeSoftware(src);
 return 'COPY_VERIFY_REMOVE';
}
function installStagedSoftware(stage,target,expected){
 plainPath(stage);need(!fs.existsSync(target),'DEST_EXISTS','Unerwartete Datei am Installationsziel.');
 need(treeDigest(stage)===expected,'STAGE_CHANGED','Gestagte Software hat sich vor dem Installieren veraendert.');
 // Never rename staged directories into the live path. Windows can deny the
 // rename despite an otherwise fully writable destination. Copy file by file.
 copyTree(stage,target);
 need(treeDigest(target)===expected,'INSTALL_COPY_VERIFY','Installierte Software konnte nicht vollstaendig verifiziert werden.');
 return 'COPY_AND_VERIFY';
}
function saveJournal(j){writeJSON(path.join(j.archive,'migration.json'),j);}
function checkJournal(j,target){need(j?.schema==='MCR_COMPLETE_INSTALL_JOURNAL_V1'&&path.resolve(j.target)===path.resolve(target),'JOURNAL_INVALID','Falsches Installationsjournal.');const parent=path.join(path.dirname(path.resolve(target)),'_MCR_Archiv');need(path.dirname(j.archive)===parent&&/^complete_[0-9TZ_-]+[a-f0-9]{8}$/.test(path.basename(j.archive)),'JOURNAL_PATH','Fremder Archivpfad.');for(const xs of [j.oldItems,j.incoming]){need(Array.isArray(xs)&&xs.length>0,'JOURNAL_INVALID','Journal unvollstaendig.');const seen=new Set();for(const x of xs){need(NAMES.includes(x.name)&&!seen.has(x.name)&&/^[a-f0-9]{64}$/.test(x.hash),'JOURNAL_INVALID','Journalpfad falsch.');seen.add(x.name);}}plainPath(j.archive);}
export function restoreSoftware(j,{verifyOld=verifyPrevious}={}){checkJournal(j,j.target);const target=j.target,backup=path.join(j.archive,'software'),retired=path.join(j.archive,'retired');if(!fs.existsSync(retired))fs.mkdirSync(retired);plainPath(retired);
 for(const x of j.oldItems){
  const b=path.join(backup,x.name),p=path.join(target,x.name);
  const originalAtTarget=fs.existsSync(p)&&treeDigest(p)===x.hash;
  const verifiedBackup=fs.existsSync(b)&&treeDigest(b)===x.hash;
  need(originalAtTarget||verifiedBackup,'BACKUP_CHANGED','Originalsoftware weder unveraendert am Ziel noch im Archiv nachgewiesen.');
 }
 for(const x of j.incoming){
  const p=path.join(target,x.name),old=j.oldItems.find(o=>o.name===x.name);
  if(fs.existsSync(p)&&(!old||treeDigest(p)!==old.hash)){
   let d=path.join(retired,x.name);if(fs.existsSync(d))d+='_'+stamp();
   moveSoftwareVerified(p,d,treeDigest(p));
  }
 }
 for(const x of j.oldItems){
  const b=path.join(backup,x.name),p=path.join(target,x.name);
  if(!fs.existsSync(p)){
   need(fs.existsSync(b),'BACKUP_MISSING','Originalsoftware fehlt im lokalen Archiv.');
   moveSoftwareVerified(b,p,x.hash);
  }
  need(treeDigest(p)===x.hash,'ROLLBACK_VERIFY','Wiederherstellung abweichend.');
 }
 verifyOld(target);need(JSON.stringify(dataBinding(target))===JSON.stringify(j.before),'DATA_CHANGED','Mapping/Config geaendert. Keine Daten werden zurueckgesetzt.');j.state='ROLLED_BACK';j.finishedAt=new Date().toISOString();saveJournal(j);const marker=path.join(target,BARRIER);if(fs.existsSync(marker))fs.unlinkSync(marker);return j;
}
export function installSoftware(plan,{guard=windowsIdle,verifyOld=verifyPrevious,fault=null}={}){guard(plan.target);const fresh=planInstall(plan.source,plan.target,{verifyOld});need(JSON.stringify(fresh)===JSON.stringify(plan),'PLAN_CHANGED','Installationsstand seit Vorschau geaendert.');const l=lock(plan.target,'MIGRATION');let j=null;
 try{guard(plan.target);const parent=path.join(path.dirname(plan.target),'_MCR_Archiv');if(!fs.existsSync(parent))fs.mkdirSync(parent);plainPath(parent);const archive=path.join(parent,'complete_'+stamp());fs.mkdirSync(archive);fs.mkdirSync(path.join(archive,'software'));fs.mkdirSync(path.join(archive,'stage'));
 j={...plan,schema:'MCR_COMPLETE_INSTALL_JOURNAL_V1',archive,state:'STAGING',oldMoved:[],newMoved:[],createdAt:new Date().toISOString()};saveJournal(j);
 for(const x of plan.incoming){copyTree(path.join(plan.source,x.name),path.join(archive,'stage',x.name));need(treeDigest(path.join(archive,'stage',x.name))===x.hash,'STAGE_VERIFY','Staging abweichend.');}
 // Data/config remain at their existing path; this marker also stops Beta-4 START.cmd.
 fs.writeFileSync(path.join(plan.target,BARRIER),'Softwareumstellung offen. START.cmd aus dem NEUEN entpackten Paket -> Rueckweg.\n',{flag:'wx'});j.state='MOVING';saveJournal(j);let count=0;
 for(const x of plan.oldItems){
  need(treeDigest(path.join(plan.target,x.name))===x.hash,'SOURCE_CHANGED','Alte Software geaendert.');
  moveSoftwareVerified(path.join(plan.target,x.name),path.join(archive,'software',x.name),x.hash);
  j.oldMoved.push(x.name);saveJournal(j);fault?.('OLD',++count);
 }
 for(const x of plan.incoming){
  installStagedSoftware(path.join(archive,'stage',x.name),path.join(plan.target,x.name),x.hash);
  j.newMoved.push(x.name);saveJournal(j);fault?.('NEW',++count);
 }
 verifyPackage(plan.target);need(JSON.stringify(dataBinding(plan.target))===JSON.stringify(plan.before),'DATA_CHANGED','Bestandsmapping/Config hat sich veraendert.');writeJSON(path.join(controlDir(plan.target),'complete-install.json'),{schema:'MCR_COMPLETE_INSTALL_RECEIPT_V1',version:plan.release.version,manifestSha256:plan.release.manifestSha256,archive,installedAt:new Date().toISOString(),mappingUnchanged:true,profileTouched:false});j.state='COMPLETE';saveJournal(j);fs.unlinkSync(path.join(plan.target,BARRIER));return {archive,target:plan.target,state:'COMPLETE'};
 }catch(e){if(j){if(e.simulatePowerLoss){throw e;}try{restoreSoftware(j,{verifyOld});e.rollback='SOFTWARE_RESTORED';}catch(r){e.rollback='OPEN';e.rollbackCode=r.code||'IO_ERROR';}}throw e;}
 finally{try{l.release();}catch{}}
}
export function journals(target){const parent=path.join(path.dirname(path.resolve(target)),'_MCR_Archiv');if(!fs.existsSync(parent))return [];plainPath(parent);const out=[];for(const n of fs.readdirSync(parent).filter(n=>/^complete_[0-9TZ_-]+[a-f0-9]{8}$/.test(n)).sort().reverse()){const file=path.join(parent,n,'migration.json');if(fs.existsSync(file)){const j=readJSON(file);checkJournal(j,target);if(j.state!=='ROLLED_BACK')out.push(j);}}return out;}
