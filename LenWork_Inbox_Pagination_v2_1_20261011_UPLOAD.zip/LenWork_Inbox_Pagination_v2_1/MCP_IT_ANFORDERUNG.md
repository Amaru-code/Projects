# Technische Anforderung an IT / LenWork-Administration: read-only Microsoft-Graph-Paging

## Problem
Die vorhandene LenWork-Microsoft-365-Integration bietet `msgraph_email` mit festem `count <= 50`, ohne Weiterblaettern und mit tagesgenauem Datum. Mehr als 50 Mails an einem Tag koennen im Skill nicht nachweislich vollstaendig aufgelistet werden. Skill-JS hat weder Netzwerkzugriff noch Zugriff auf einen Graph-Token. Das ist eine Produkt-/Toolgrenze, KEIN Promptproblem.

## Ziel
Ein **genehmigter, auditiert lesender** Connector, der die Graph-Pagination kapselt und dem LenWork-Agenten einen sicheren, begrenzten Cursor statt direkter Token bereitstellt.

### Minimal erforderliche Tools (Beispiel-Vertrag, an LenWork anpassen)

**`mail_list_scope`**: Inputs `folder=inbox` (ggf. zusaetzliche explizit erlaubte Unterordner), `received_from` (ISO-Zeitpunkt), `received_until_exclusive` (ISO-Zeitpunkt), `unread_only` (boolean), `page_size` (z. B. 100), optional `cursor` (opaque). Outputs `items[]` mit stabiler `id`, `conversationId`, `receivedDateTime`, `from`, `toRecipients`, `ccRecipients`, `subject`, `importance`, `hasAttachments`, `bodyPreview`; `next_cursor` oder `null`; `request_id`, `errors`, `continuation_complete`. Graph-`@odata.nextLink` nur serverseitig und geschuetzt verwalten, wenn Token/Query-Secrets enthalten sein koennten. Keine Token an Chat/Skill herausgeben.

**`mail_get_message`**: Input `message_id`, Output `body`/`bodyPreview` der berechtigten Nachricht ohne Aenderung von `isRead` (Graph GET; kein PATCH).

**`mail_list_sent_thread`** (optional): Nur per READ-ONLY ueber autorisierten Zeitraum/Thread fuer Antwortstatus.

## Autorisierung / Netzwerk
- Microsoft Entra ID, delegated OAuth im Namen des angemeldeten Benutzers, minimal notwendige `Mail.Read`-Berechtigung fuer Volltext. `Mail.ReadBasic` allein liefert keinen Mailbody/Preview in der gleichen Tiefe und reicht fuer die volle Aufgabe nicht aus.
- Keine `Mail.Send`, `Mail.ReadWrite` und keine appweiten Postfach-Leserechte, sofern nicht explizit vom Sicherheits-Team genehmigt und notwendig.
- Berechtigungen per User, TLS, Freigabe von Endpunkten, Audit ohne Mailinhalte, Rate-Limit/429 und `Retry-After`, DLP/Retention und datenschutzkonforme Datensparsamkeit.
- Falls LenWork Remote-MCP-Connectors anbinden kann: sicherstellen, dass der gewuenschte Server von LenWork tatsaechlich erreichbar und administrativ freigegeben ist. Falls nicht, den Connector direkt als native LenWork-Integration implementieren.
- Es wird keine Token-Extraktion aus bestehender LenWork-Integration vorgeschlagen.

## Microsoft Graph technische Umsetzung
- `GET /v1.0/me/mailFolders/inbox/messages` mit serverseitigem `$filter` und `$select`, `$top` in sinnvoller Hoehe (z. B. 100) und allen benoetigten READ-ONLY-Daten.
- Bei Graph-Antwort mit `@odata.nextLink` diese URL **unveraendert** intern fuer naechsten GET nutzen, bis sie fehlt. Graph-Paging ist nicht automatisch atomarer Snapshot.
- Graph-Endpunkte und Ordner-/Zeitfilter strikt gegen erlaubte Zielmailbox pruefen. Cursor an Benutzer, Scope und Ablaufzeit binden.
- Fehler/429/Timeout/Cursor-Ungueltigkeit als explizite Fail-Closed-Fehler ausgeben, nicht als leere Inbox interpretieren.

## Abnahmekriterien (synthetisch + genehmigtes Testpostfach)
- 0, 1, 49, 50, 51, 137, 500, 1000+ passende Nachrichten: alle IDs genau einmal ohne stilles Trunkieren nach mehrseitigem Abruf, 0 fehlende IDs.
- >=100 Mails auf EINEM Kalendertag korrekt vollstaendig erfasst.
- `UNREAD=true` gegen alle Nachrichten sauber getrennt; TZ/DST-Grenzen und Ende exklusiv getestet.
- GET einer Nachricht veraendert `isRead` nicht; keine Schreibaktionen im Tool-Schema.
- 429-Rate-Limit, abgelaufener Cursor, fehlende Rechte, Loop-Link, geaenderter Postfachzustand: klare Fehler/Status, kein falsches `COMPLETE`.
- `Mail.Read` nur in genehmigter Umgebung; keine personenbezogenen Daten in Logs/Exporten, Loesch-/Aufbewahrungskonzept dokumentiert.

## Quellen
- https://learn.microsoft.com/en-us/graph/api/user-list-messages?view=graph-rest-1.0
- https://learn.microsoft.com/en-us/graph/paging
- https://learn.microsoft.com/en-us/graph/permissions-reference
