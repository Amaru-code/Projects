# LenWork Urlaubs-Rueckblick – nativer Skill v2.1

## Hintergrund
Die LenWork-Diagnose vom 11.10.2026 (vom Nutzer bereitgestellt) hat ergeben:
- `msgraph_email` kann pro Listen-/Suchaufruf hoechstens 50 Treffer zurueckgeben. Es gibt KEIN `nextLink`/`pageToken` und keine frei benutzbare Graph-GET-Schnittstelle.
- `date_range` akzeptiert nur ganze Kalendertage (`YYYY-MM-DD` oder `YYYY-MM-DD..YYYY-MM-DD`).
- JavaScript-Dateien im Skill duerfen keinen `fetch()` ins Internet ausfuehren und bekommen keinen Graph-OAuth-Token. Darum ist der fruehere `graph_pager.js` aus v1 derzeit **nicht in LenWork lauffaehig**.

## Was diese Version leistet
- Mehr als 100 Inbox-Nachrichten **ueber mehrere Tage** durch rekursive Tagesaufteilung sammeln.
- Das 50er-Limit nicht faelschlich als Inbox-Gesamtlimit interpretieren.
- Bei 50 Treffern an **einem Tag** korrekt `INCOMPLETE` melden. Weitere Stichprobenfilter allein beweisen KEINE Vollstaendigkeit.
- Doppelten Abruf, Fehler, Unread/Alle-Mails-Scoping und Auswertungsfortschritt transparent dokumentieren.
- Alle vorhandenen Unternehmens-Absenderregeln samt Ausnahmen nutzen.

## In LenWork einspielen
1. Oeffne Customize -> Skills -> `inbox-urlaub-rueckblicke-v2` -> Content.
2. Erstelle vorher eine Sicherheitskopie der bestehenden `SKILL.md` und `absender`-Datei. Unverwandte Arbeitsdateien unangetastet lassen.
3. Ersetze NUR den Inhalt von `SKILL.md` durch die beigefuegte neue `SKILL.md`. Falls LenWork ein anderes original-YAML-Frontmatter verwaltet, **behalte dessen autoritative Felder** und ersetze den Markdown-Body; der Name sollte beim bestehenden Skill bleiben.
4. Ersetze den Inhalt der Datei `absender` mit der beigefuegten Version oder lass bestehende zusaetzliche, real gepflegte Absenderregeln stehen und uebernimm nur die Klarstellung der Ausnahmen. Der beigefuegte Inhalt enthaelt die Regeln aus dem bisherigen bereitgestellten Paket.
5. Eine `.js`-Datei MUSS NICHT in LenWork angelegt werden. Ein gesonderter Graph-Skript-Upload wuerde in der nachgewiesenen Sandbox keine Graph-Berechtigung erzeugen.
6. Speichere. Das System weist darauf hin, dass Speichern eine neue Skill-Version veroeffentlicht; daher wenn moeglich zuerst in einer **privaten Testkopie** erproben.
7. Starte in einem frischen Chat den Inhalt von `LENWORK_ABNAHME_PROMPT.md`. Den rein technischen Coverage-Befund kannst du hier ohne personenbezogene Mailinhalte zurueckgeben.

## Was nicht versprochen wird
- Bei >=50 passenden E-Mails innerhalb desselben Kalendertags gibt es ohne weitere **nachgewiesen vollstaendige** Filterpartitionierung keine 100%-Garantie.
- Ein ungesaettigter Datumsbereich ist nur dann als vollstaendig markierbar, wenn der vorhandene Toolvertrag fuer die genutzten Filter richtig funktioniert.
- Ein geaenderter Unread-Status, verschobene Nachrichten oder laufender Maileingang verhindern eine transaktionale Momentaufnahme; dieser Skill hat keinen Snapshotmechanismus.
- Bei laengerem Zeitraum koennen Modell-/Kontextlimits eine Auswertung verhindern, auch wenn die Daten einzeln abrufbar sind. Der Skill muss solche Limitierungen anzeigen.

## Offline-Test
Im Paket liegt ein kleiner JavaScript-Simulator, der ausschliesslich KUNSTDATEN nutzt. Er testet die beschriebene Aufteilungslogik, NICHT die reale LenWork-Integration:

```powershell
node .\tests\test_coverage_planner.js
```

## Dauerhafte Loesung
Siehe `MCP_IT_ANFORDERUNG.md`. Ein offiziell freigegebener READ-ONLY-Microsoft-Graph-Connector mit echter Pagination ist die richtige Architektur fuer vollstaendige 100-, 500- oder 1000+-Inbox-Auswertungen (vorbehaltlich liveveraenderlichem Postfach). Es geht NICHT darum, eine bestehende Sandbox-Sicherheitsgrenze zu umgehen.
