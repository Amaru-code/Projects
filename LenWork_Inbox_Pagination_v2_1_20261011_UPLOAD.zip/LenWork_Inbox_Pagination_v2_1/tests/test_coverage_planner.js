'use strict';
const assert = require('node:assert/strict');
const { coverRange, dayNumber, isoDay, HARD_LIMIT } = require('./coverage_planner');

function synth(days, distribution) {
  const start = dayNumber(days);
  const items = [];
  distribution.forEach((n, i) => {
    for (let j = 0; j < n; j++) {
      items.push({ id: `day${i}-email${j}`, receivedDateTime: `${isoDay(start+i)}T10:00:00Z` });
    }
  });
  return { items, start: days, end: isoDay(start+distribution.length-1) };
}
function mock(items, options = {}) {
  return async query => {
    assert.equal(query.count, HARD_LIMIT);
    assert.equal(query.folder, 'Inbox');
    assert.equal(query.unread_only, true);
    const [a, b = a] = query.date_range.split('..');
    if (options.failDay && query.date_range === options.failDay) throw Error('Simulated 429');
    const results = items.filter(x => {
      const d = x.receivedDateTime.slice(0, 10);
      return d >= a && d <= b;
    });
    return results.sort((a,b) => b.receivedDateTime.localeCompare(a.receivedDateTime) || b.id.localeCompare(a.id)).slice(0, HARD_LIMIT);
  };
}

async function test(label, distribution, shouldBeComplete, extra = {}) {
  const input = synth('2026-10-01', distribution);
  const result = await coverRange({ startDay: input.start, endDay: input.end,
    listRange: mock(input.items, extra), filterSemanticsKnown: extra.semanticsKnown !== false });
  assert.equal(result.status === 'COMPLETE_UNDER_TOOL_CONTRACT', shouldBeComplete, `${label}: status`);
  if (shouldBeComplete) {
    assert.equal(result.uniqueMessages, input.items.length, `${label}: total exact`);
    assert.deepEqual(result.ids, input.items.map(x => x.id).sort(), `${label}: full ID set`);
    assert.equal(result.unresolved.length, 0);
  } else assert.ok(result.unresolved.length >= 1);
  console.log(`PASS ${label}: total=${input.items.length} calls=${result.calls} captured=${result.uniqueMessages} ${result.status}`);
  return result;
}
(async () => {
  assert.throws(() => dayNumber('2026-02-30'), /Invalid calendar day/);
  await test('empty', [0], true);
  await test('single day < 50', [49], true);
  const fifty = await test('exactly 50 on one day = INCOMPLETE', [50], false);
  assert.equal(fifty.saturatedDays, 1);
  const above = await test('100+ in one day = INCOMPLETE', [137], false);
  assert.equal(above.uniqueMessages, 50);
  await test('two days 50 each = INCOMPLETE', [50,50], false);
  await test('100+ across days', [15, 15, 15, 15, 15, 15, 15, 15, 15], true);
  await test('180 across 12 days', Array.from({length: 12}, () => 15), true);
  await test('600 across 30 days', Array.from({length: 30}, () => 20), true);
  await test('1000 across 40 days', Array.from({length: 40}, () => 25), true);
  {
    const leap = synth('2028-02-28', [25, 25, 25]);
    const result = await coverRange({ startDay: leap.start, endDay: leap.end, listRange: mock(leap.items) });
    assert.equal(leap.end, '2028-03-01');
    assert.equal(result.status, 'COMPLETE_UNDER_TOOL_CONTRACT');
    assert.equal(result.uniqueMessages, 75);
    console.log(`PASS leap-day partition: total=75 calls=${result.calls}`);
  }
  await test('filter semantics unknown', [12, 13, 14], false, {semanticsKnown: false});
  const failed = await test('request failure is fail-closed', [25,25,25], false, {failDay: '2026-10-01'});
  assert.ok(failed.unresolved.find(x => x.reason === 'RETRIEVAL_OR_INTEGRITY_ERROR'));
  assert.ok(failed.calls > 1, 'Error occurs in leaf after parent succeeds');
  const input = synth('2026-10-01', [30, 30, 30]);
  const limited = await coverRange({ startDay: input.start, endDay: input.end, listRange: mock(input.items), maxCalls: 2 });
  assert.equal(limited.status, 'INCOMPLETE');
  assert.ok(limited.unresolved.some(x=> x.reason==='RESOURCE_LIMIT'));
  console.log('PASS call budget triggers INCOMPLETE');
  const noIds = await coverRange({ startDay: '2026-10-01', endDay:'2026-10-01', listRange: async ()=> [{receivedDateTime:'2026-10-01T10:00:00Z'}] });
  assert.equal(noIds.status, 'INCOMPLETE');
  console.log('PASS missing stable ids trigger INCOMPLETE');
  const corrupt = await coverRange({ startDay:'2026-10-01', endDay:'2026-10-01', listRange: async()=> [{id:'A'},{id:'A'}] });
  assert.equal(corrupt.status,'INCOMPLETE');
  console.log('PASS duplicate ids inside one response trigger INCOMPLETE');
  console.log('ALL OFFLINE COVERAGE TESTS PASS; no real Microsoft 365 access');
})().catch(e=> { console.error(e); process.exitCode=1; });
