'use strict';
/*
 * Offline reference model for the LenWork SKILL.md algorithm.
 * NO network, NO Outlook integration, NO token, NO write operations.
 * In LenWork, tool calls must be made by the agent through msgraph_email.
 */

const HARD_LIMIT = 50;
const ISO_DAY = /^\d{4}-\d{2}-\d{2}$/;

function dayNumber(day) {
  if (typeof day !== 'string' || !ISO_DAY.test(day)) throw Error('Invalid ISO day: ' + day);
  const milliseconds = Date.parse(`${day}T00:00:00Z`);
  if (!Number.isFinite(milliseconds) || new Date(milliseconds).toISOString().slice(0, 10) !== day) {
    throw Error('Invalid calendar day: ' + day);
  }
  return milliseconds / 86400000;
}
function isoDay(number) { return new Date(number * 86400000).toISOString().slice(0, 10); }
function intervalLabel(from, to) { return from === to ? from : `${from}..${to}`; }

/** listRange({date_range,count,folder,unread_only}) returns an array of messages or rejects. */
async function coverRange({ startDay, endDay, listRange, folder = 'Inbox', unreadOnly = true,
                            filterSemanticsKnown = true, maxCalls = 500 }) {
  if (typeof listRange !== 'function') throw Error('listRange required');
  let start = dayNumber(startDay), end = dayNumber(endDay);
  if (start > end) throw Error('Start after end');
  const log = [], unresolved = [], stableMessages = new Map(), integrityIssues = [];
  let rawParent = 0, rawLeaf = 0;

  const retrieve = async (left, right) => {
    const range = intervalLabel(isoDay(left), isoDay(right));
    if (log.length >= maxCalls) {
      unresolved.push({ date_range: range, reason: 'RESOURCE_LIMIT' });
      return;
    }
    const query = { date_range: range, count: HARD_LIMIT, folder, unread_only: unreadOnly };
    const entry = { index: log.length + 1, date_range: range, count: null, saturated: null, error: null };
    log.push(entry);
    let batch;
    try {
      batch = await listRange(query);
      if (!Array.isArray(batch) || batch.length > HARD_LIMIT) throw Error('Invalid/over-limit response');
      for (const msg of batch) {
        if (!msg || typeof msg.id !== 'string' || !msg.id) throw Error('Missing stable message id');
      }
    } catch (e) {
      entry.error = e.message || String(e);
      unresolved.push({ date_range: range, reason: 'RETRIEVAL_OR_INTEGRITY_ERROR' });
      return;
    }
    entry.count = batch.length;
    entry.saturated = batch.length === HARD_LIMIT;
    if (batch.length === HARD_LIMIT && left < right) {
      rawParent += batch.length;
      const middle = left + Math.floor((right - left) / 2);
      await retrieve(left, middle);
      await retrieve(middle + 1, right);
      return;
    }
    rawLeaf += batch.length;
    const batchIds = new Set();
    for (const msg of batch) {
      if (batchIds.has(msg.id)) integrityIssues.push(`Duplicate id inside ${range}`);
      batchIds.add(msg.id);
      const existing = stableMessages.get(msg.id);
      if (existing && existing.id !== msg.id) integrityIssues.push('Impossible ID mismatch');
      if (existing && existing._source_range !== range) integrityIssues.push('Repeated ID across disjoint leaves');
      if (!existing) stableMessages.set(msg.id, { ...msg, _source_range: range });
    }
    if (entry.saturated) unresolved.push({ date_range: range, reason: 'SATURATED_DAY' });
  };

  await retrieve(start, end);
  if (!filterSemanticsKnown) unresolved.push({ date_range: intervalLabel(startDay,endDay), reason: 'FILTER_SEMANTICS_UNVERIFIED' });
  if (integrityIssues.length) unresolved.push({ date_range: intervalLabel(startDay,endDay), reason: 'ID_INTEGRITY_ISSUE' });
  return {
    status: unresolved.length ? 'INCOMPLETE' : 'COMPLETE_UNDER_TOOL_CONTRACT',
    calls: log.length, uniqueMessages: stableMessages.size, rawLeaf, rawParent,
    saturatedDays: unresolved.filter(r => r.reason === 'SATURATED_DAY').length,
    log, unresolved, integrityIssues,
    /* Messages are present only so the TEST can validate exact ID equality; real live data are not used. */
    ids: Array.from(stableMessages.keys()).sort(),
  };
}

module.exports = { coverRange, HARD_LIMIT, dayNumber, isoDay, intervalLabel };
