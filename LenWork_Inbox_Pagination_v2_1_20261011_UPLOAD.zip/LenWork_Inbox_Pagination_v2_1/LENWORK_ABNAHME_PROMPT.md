# Testauftrag an LenWork nach Einbau von SKILL.md v2.1

Fuehre einen READ-ONLY Abnahmetest fuer den installierten Skill `inbox-urlaub-rueckblicke-v2` durch. Verwende ausschliesslich die vorhandene `msgraph_email`-Integration; KEINE E-Mails senden, verschieben, aendern, markieren oder als gelesen setzen. Keine Tokens/Geheimnisse suchen.

TEST-SCOPE: letzte 14 Tage, nur ungelesene Inbox-Mails, bis zur Startzeit des Tests. Nutze `count: 50` und datumsbasierte rekursive Intervallpartitionierung, wie im Skill beschrieben. Wenn mehr als 50 Treffer im Gesamtzeitraum vorliegen, rufe mehrfach ab. Bei genau 50 Treffern an einem unteilbaren Kalendertag: `SATURATED_DAY`; nicht „vollstaendig“ behaupten.

ZUNAeCHST NUR TECHNISCHER ABRUF- UND COVERAGE-BERICHT; keine personenbezogenen Nachrichtendetails, Betreffs, Absender, E-Mail-Inhalte oder Adressen ausgeben. Keine Mail-Volltexte fuer diesen Test abrufen.

Gib aus:
- Scope inkl. Inbox, Unread, Start/Ende/Zeitzone und fixierter Teststartzeit
- angewandte `msgraph_email`-Aktion und die tatsaechlich existierenden Filterparameter (keine erfundenen Parameter)
- pro Abfrage: fortlaufende Nummer, Kalendertagsbereich, Trefferanzahl, ob =50 gesaettigt, Fehlerstatus
- eindeutige Message-IDs vorhanden? Nur JA/NEIN ausgeben; niemals IDs abdrucken
- Filtersemantik verifiziert? JA/NEIN, mit kurzer technischen Begruendung
- Anzahl API-Aufrufe, Anzahl gefundener eindeutiger Nachrichten, Tage mit 50-Treffer-Ueberlauf, ungeklaerte Intervalle
- FETCH_STATUS (COMPLETE_UNDER_TOOL_CONTRACT / INCOMPLETE / INCOMPLETE_OR_CHANGED) und warum
- ANALYSIS_STATUS=NOT_STARTED (fuer diesen Diagnoselauf ist keine Priorisierung vorgesehen)

Wenn alle Teilintervalle weniger als 50 haben: nur bedingte Vollstaendigkeit unter dem getesteten Toolvertrag, KEINE atomare Snapshot-Garantie. Falls ein 50er-Tag bleibt: sage explizit, dass die unbekannten restlichen Mails nicht gezaehlt werden koennen.

Schliesse mit einer knappen technischen Empfehlung. Keine Antwortentwuerfe vorbereiten.
