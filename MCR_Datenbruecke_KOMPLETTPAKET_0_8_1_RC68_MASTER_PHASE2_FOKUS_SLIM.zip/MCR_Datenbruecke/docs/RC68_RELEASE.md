# RC68 – Masterweiterlauf bei leerer Phase 1 und MBC-Fokus

## Ziel

An RC65 anschließen, die produktiven COMARCH-Klickfolgen nicht verändern. Nach jeder nachgewiesenen Weiterleitung erneut nur die echte Intel-Ansicht `In_Bearbeitung` lesen und den nächsten zulässigen Fall wählen.

## Neu

- `P2_ZULASSUNG` zeigt echte Freigaben und zusätzlich strukturell prüfbare alte Versandjournale getrennt an.
- Bereits gespeicherte `USC / Standardantwort versendet` werden auch mit **genau einer unterstützten weiteren Anfragezeile** akzeptiert, wenn der unveränderte alte SHA-256, der konkrete COMARCH-Servertext und genau eine passende ausgehende Standardantwort mit eindeutigen Dokument-IDs zusammenpassen.
- Bei **fehlender Statuszeile** darf RC67 nur bei demselben unveränderten alten SHA-256 und zweifelsfrei gebundenem Ausgang einen einmaligen Statusnachtrag vornehmen. Vor der ersten Formularänderung wird der `SAVE_INTENT` dauerhaft protokolliert. Nach einem unklaren Speicherklick erfolgt **nie** eine automatische Wiederholung. Nur ein frischer Vorgangslisten- und Detail-Readback beendet den Statusnachtrag.
- Statuszeile kommt vor einer erhaltenen MBC-/Kontoauszug-Anfragezeile. Fremde Hinweise, doppelte Status, mehrere Ausgangsantworten, fehlende Identität oder ein bereits offener `SAVE_INTENT` bleiben unverändert gesperrt.
- Master zeigt bei übrigen nicht bearbeiteten Fällen auch nach erfolgreichen Weiterleitungen `PARTIAL_PHASE2_OPEN_CASES` an, nicht einen irreführenden Gesamtabschluss.

## Grenzen

Nur sichtbare Tickets der eigenen Intel-Ansicht; ohne dokumentierten COMARCH-Paginierungsvertrag keine Navigation durch unspezifizierte Folgeseiten. Unbekannte fachliche Anfragetypen werden nicht beantwortet. `SEND_INTENT` ist **kein** Nachweis eines versendeten Briefs. Die reale Windows-/COMARCH-Oberfläche muss den neuen Speichernachtrag noch bestätigen. Phase 2 versendet niemals eine E-Mail.

## Installation

ZIP separat entpacken → `START.cmd` → Menü 1 → vorhandene RC65-Installation. Software-Rückweg und lokale Journale bleiben erhalten. Danach **installierte** `START.cmd` → Menü 12, Startticket leer. Die bereits erfolgreiche Phase 1 muss dafür nicht erneut laufen.

## RC68: Gezielter MBC-Fokus und Master ohne neuen Pilot

- Wenn die COMARCH-Beschreibung nach dem Speichern eines MBC-Entwurfs an allen sicheren Mausklickpunkten verdeckt ist, versucht RC68 **einmal `DOM.focus`** auf die zuvor eindeutig per COMARCH-Feldlabel gebundene TEXTAREA; vor und nach dem Fokus werden Ticketnummer, Feldidentitaet, Unveraendertheit und Fokus geprueft. Keine JavaScript-Werte, kein JS-Klick, keine Formularabgabe.
- Sichtbare Modal-Dialoge werden nicht per DOM-Fokus umgangen. Scheitert die Prüfung, bleibt die alte manuelle Fokussierung mit `BEREIT_BESCHREIBUNG` erhalten.
- Erst nach nativer Texteingabe, nachgewiesenem ICEfaces-Blur, einem separaten Ticket-Speicher-Readback und Mark-Baindl-Nachweis darf weitergeleitet werden. Offene MBC-Draft-Journale bleiben erhalten.
- Ein **vollständig und fehlerfrei als leer bestätigter** Phase-1-Pilotlauf (`NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS`, keine Sendeklicks) erlaubt im Master unmittelbar Phase 2. Es entsteht dadurch **keine** Phase-1-Pilot-Zertifizierung oder Sendefreigabe. Jeder andere fehlgeschlagene oder unklare Pilot blockiert Phase 2 weiterhin.
- Begrenzung unverändert: Phase 2 liest nur die aktuell sichtbare Intel-Liste; alte unklare Versandjournale und nicht unterstützte Anfragen bleiben gesperrt.
