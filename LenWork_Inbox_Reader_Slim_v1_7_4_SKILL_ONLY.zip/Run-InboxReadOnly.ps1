<#
LenWork COM Reader launcher v1.7.4.
Reads Outlook through the pinned v1.7.0 read-only script, verifies the entire
export, and emits a single ZIP for ingestion. No Outlook writes, no Graph, no
ExecutionPolicy override. Run in Windows PowerShell 5.1 on the Outlook host.
Console output is ASCII status only; diagnostic files remain on the host.
#>
[CmdletBinding()]
param(
    [ValidateSet('All','Default14','Range')][string]$Scope = 'Default14',
    [string]$StartDate = '',
    [string]$EndDate = '',
    [ValidateRange(1,100)][int]$BatchSize = 25,
    [ValidateRange(0,2000)][int]$PreviewChars = 350
)

$ErrorActionPreference = 'Stop'
$watch = [Diagnostics.Stopwatch]::StartNew()
$stage = 'PRECHECK'
$job = $null
$utf8 = [Text.UTF8Encoding]::new($false, $true)
$culture = [Globalization.CultureInfo]::InvariantCulture
$expectedReaderSha = 'f2e696628536125fe5fb9f0f08da49328cdc54525626d7e72afa93bf852098ef'

try {
    if ($PSVersionTable.PSVersion.Major -ne 5) { throw 'PS_VERSION' }
    if ([string]::IsNullOrWhiteSpace($PSScriptRoot)) { throw 'PHYSICAL_SKILL_REQUIRED' }
    $reader = Join-Path $PSScriptRoot 'Export-InboxReadOnly.ps1'
    if (-not [IO.File]::Exists($reader)) { throw 'READER_NOT_FOUND' }
    $readerSha = (Get-FileHash -LiteralPath $reader -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($readerSha -cne $expectedReaderSha) { throw 'READER_HASH_MISMATCH' }

    $today = (Get-Date).Date
    if ($Scope -eq 'All') {
        $StartDate = '1900-01-01'
        $EndDate = $today.ToString('yyyy-MM-dd',$culture)
    } elseif ($Scope -eq 'Default14') {
        $StartDate = $today.AddDays(-13).ToString('yyyy-MM-dd',$culture)
        $EndDate = $today.ToString('yyyy-MM-dd',$culture)
    } elseif (-not $StartDate -or -not $EndDate) {
        throw 'MISSING_RANGE_DATES'
    }
    $from = [datetime]::ParseExact($StartDate,'yyyy-MM-dd',$culture)
    $through = [datetime]::ParseExact($EndDate,'yyyy-MM-dd',$culture)
    if ($from -gt $through) { throw 'INVALID_DATE_RANGE' }
    $until = $through.AddDays(1)

    $stage = 'CREATE_JOB'
    $root = Join-Path $env:LOCALAPPDATA 'LenWorkInboxExports'
    $job = Join-Path $root ('LW_' + [guid]::NewGuid().ToString('N'))
    [IO.Directory]::CreateDirectory($job) | Out-Null
    $stdoutPath = Join-Path $job 'child_stdout.txt'
    $stderrPath = Join-Path $job 'child_stderr.txt'
    $exportsDir = Join-Path $job 'exports'
    [IO.Directory]::CreateDirectory($exportsDir) | Out-Null

    $stage = 'CHILD_START'
    $exe = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
    if (-not [IO.File]::Exists($exe)) { throw 'POWERSHELL5_NOT_FOUND' }
    $args = '-NoProfile -NonInteractive -File "{0}" -StartDate {1} -EndDate {2} -UnreadOnly -ScanMode Auto -BatchSize {3} -PreviewChars {4} -OutputDir "{5}"' -f $reader,$StartDate,$EndDate,$BatchSize,$PreviewChars,$exportsDir
    $child = Start-Process -FilePath $exe -ArgumentList $args -Wait -PassThru -RedirectStandardOutput $stdoutPath -RedirectStandardError $stderrPath
    if ($child.ExitCode -ne 0) { throw ('READER_CHILD_EXIT_' + $child.ExitCode) }

    $stage = 'VERIFY_MANIFEST'
    $runs = @(Get-ChildItem -LiteralPath $exportsDir -Directory | Where-Object { $_.Name -like 'InboxExport_*' })
    if ($runs.Count -ne 1) { throw 'RUN_DIRECTORY_COUNT' }
    $runDir = $runs[0].FullName
    $runId = $runs[0].Name
    $manifestFile = Join-Path $runDir 'manifest.json'
    if (-not [IO.File]::Exists($manifestFile)) { throw 'MISSING_MANIFEST' }
    $m = ConvertFrom-Json -InputObject ([IO.File]::ReadAllText($manifestFile,$utf8))
    if ($m.schema -cne 'LENWORK_ORIGINAL_INBOX_EXPORT_V1' -or $m.reader_version -cne '1.7.0') { throw 'MANIFEST_SCHEMA_VERSION' }
    if ($m.status -cne 'COMPLETE_LOCAL_STORE' -or $m.source -cne 'classic_outlook_local_com') { throw 'MANIFEST_SOURCE_STATUS' }
    if (@('UNREAD_RESTRICT','BASELINE_RESTRICT_UNAVAILABLE') -cnotcontains [string]$m.scan_strategy_used -or -not [bool]$m.unread_only) { throw 'MANIFEST_STRATEGY' }
    if ($m.scope_start -cne $StartDate -or $m.scope_end_inclusive -cne $EndDate) { throw 'MANIFEST_SCOPE' }
    if (@($m.issue_codes | Where-Object { $_ }).Count -gt 0) { throw 'READER_ISSUES' }
    if ([int]$m.unique_records -ne [int]$m.readback_records) { throw 'MANIFEST_READBACK_MISMATCH' }

    $stage = 'VERIFY_BATCHES'
    $batchFiles = @($m.files | Where-Object { $_.format -eq 'jsonl' })
    if ($batchFiles.Count -ne [int]$m.batch_count) { throw 'BATCH_COUNT' }
    $actualFiles = @(Get-ChildItem -LiteralPath (Join-Path $runDir 'batches') -File -Filter '*.jsonl')
    if ($actualFiles.Count -ne $batchFiles.Count) { throw 'UNEXPECTED_BATCH_FILES' }
    $seen = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::Ordinal)
    $records = 0
    foreach ($entry in $batchFiles) {
        $rel = [string]$entry.path
        if ($rel -notmatch '^batches/mail_batch_[0-9]{4}\.jsonl$') { throw 'UNSAFE_BATCH_PATH' }
        $path = Join-Path $runDir ($rel.Replace('/', [IO.Path]::DirectorySeparatorChar))
        if (-not [IO.File]::Exists($path)) { throw 'MISSING_BATCH' }
        $actualSha = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actualSha -cne [string]$entry.sha256) { throw 'BATCH_HASH' }
        $lines = [IO.File]::ReadAllLines($path,$utf8)
        if ($lines.Count -ne [int]$entry.records) { throw 'BATCH_RECORD_COUNT' }
        foreach ($line in $lines) {
            if ([string]::IsNullOrWhiteSpace($line)) { throw 'BLANK_JSONL' }
            $mail = ConvertFrom-Json -InputObject $line
            $id = [string]$mail.message_id
            if (-not $id -or -not $seen.Add($id)) { throw 'MISSING_OR_DUPLICATE_ID' }
            if (-not [bool]$mail.is_unread) { throw 'NOT_UNREAD' }
            $received = [datetime]::ParseExact([string]$mail.received_at_local,'yyyy-MM-ddTHH:mm:ss',$culture)
            if ($received -lt $from -or $received -ge $until) { throw 'OUT_OF_SCOPE_RECORD' }
            $records++
        }
    }
    if ($records -ne [int]$m.unique_records) { throw 'EXPORT_RECORD_COUNT' }

    $stage = 'PACKAGE'
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip = Join-Path $job ('import_' + $runId + '.zip')
    [IO.Compression.ZipFile]::CreateFromDirectory($runDir,$zip,[IO.Compression.CompressionLevel]::Optimal,$false)
    $zipSha = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant()
    $zipBytes = (Get-Item -LiteralPath $zip).Length
    $zipPathB64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($zip))
    $watch.Stop()

    [Console]::WriteLine('READER_EXEC=PASS')
    [Console]::WriteLine('FETCH_SOURCE=CLASSIC_OUTLOOK_COM')
    [Console]::WriteLine('READER_VERSION=1.7.0')
    [Console]::WriteLine('SCAN_STRATEGY=' + [string]$m.scan_strategy_used)
    [Console]::WriteLine('RUN_ID=' + $runId)
    [Console]::WriteLine('EXPORTED_COUNT=' + $records)
    [Console]::WriteLine('BATCH_COUNT=' + $batchFiles.Count)
    [Console]::WriteLine('READER_SCAN_MS=' + [string]$m.scan_duration_ms)
    [Console]::WriteLine('READER_TOTAL_MS=' + [string]$m.total_duration_ms)
    [Console]::WriteLine('LAUNCH_TOTAL_MS=' + [string]$watch.ElapsedMilliseconds)
    [Console]::WriteLine('ZIP_SHA256=' + $zipSha)
    [Console]::WriteLine('ZIP_SIZE_BYTES=' + $zipBytes)
    [Console]::WriteLine('ZIP_PATH_UTF8_B64=' + $zipPathB64)
    [Console]::WriteLine('LENWORK_IMPORT=NOT_YET_VERIFIED')
    exit 0
} catch {
    if ($null -ne $job -and [IO.Directory]::Exists($job)) {
        try {
            [IO.File]::WriteAllText((Join-Path $job 'launcher_error.txt'),[string]$_.Exception.ToString(),[Text.UTF8Encoding]::new($false))
        } catch { }
    }
    [Console]::WriteLine('READER_EXEC=FAIL')
    [Console]::WriteLine('BLOCKED_STAGE=' + $stage)
    exit 5
}
