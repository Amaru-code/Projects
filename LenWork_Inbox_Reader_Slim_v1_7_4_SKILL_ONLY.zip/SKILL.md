# Inbox catch-up after absence (Urlaubs-Rückblick)

## Goal and invariants
Read *all* requested unread messages in classic Outlook Inbox (READ-ONLY) and create the unchanged German priority summary. No message changes, no send, mark-read, move, delete, or flag. No invented deadlines or assignments. `absender.md` and original Steps 2–4 remain authoritative and unchanged.

**Flat skill root:** `SKILL.md`, `absender.md`, `Export-InboxReadOnly.ps1`, `Run-InboxReadOnly.ps1`. Read sender rules using `skill_read` with `file="absender.md"` (never `references/absender.md`). A visible virtual skill path alone does NOT guarantee a host file; this workflow uses the physically installed root that was previously hash-verified on Windows. If the root/file is not accessible, report `BLOCKED_STAGE=SKILL_FILE` and STOP. Never invent or rewrite script contents.

## COM Fast Launch v1.7.4

**No `msgraph_email` calls, no silent 50-mail fallback.** The skill must use Windows PowerShell 5.1 + classic Outlook on the same authorized Windows host. Never change execution policy or use `-ExecutionPolicy Bypass` / `-EncodedCommand`. The existing v1.7.0 Reader (`Export-InboxReadOnly.ps1`) is SHA256-pinned by the launcher and is unchanged. Do not repeat ad-hoc PowerShell probes once a valid direct launch succeeds. Read/write only local output files, never modify Outlook messages.

### Step A – Single host launch

Call the available `bash` tool ONCE with a **nonempty `command` parameter** containing the appropriate exact command below. The value must be an actual tool argument (not an empty call); do not rewrite quoting, build Base64 blocks or spawn Python subprocesses. Each call looks up the *current Windows user's* physical skill root via `%APPDATA%` from PowerShell; no hardcoded username.

For **"Priorisiere alle meine ungelesenen E-Mails"** (all local unread Inbox history):

```bash
powershell.exe -NoProfile -NonInteractive -Command "& (Join-Path ([Environment]::GetFolderPath('ApplicationData')) 'lenwork/global/agent/skills/inbox-urlaub-rueckblicke-v2/Run-InboxReadOnly.ps1') -Scope All"
```

For the **original 14-day default** when the user did NOT explicitly request *all* and gave no dates:

```bash
powershell.exe -NoProfile -NonInteractive -Command "& (Join-Path ([Environment]::GetFolderPath('ApplicationData')) 'lenwork/global/agent/skills/inbox-urlaub-rueckblicke-v2/Run-InboxReadOnly.ps1') -Scope Default14"
```

For **explicit inclusive dates** (substitute only YYYY-MM-DD literals; preserve the rest of the command):

```bash
powershell.exe -NoProfile -NonInteractive -Command "& (Join-Path ([Environment]::GetFolderPath('ApplicationData')) 'lenwork/global/agent/skills/inbox-urlaub-rueckblicke-v2/Run-InboxReadOnly.ps1') -Scope Range -StartDate '2026-10-11' -EndDate '2026-10-12'"
```

Expect `READER_EXEC=PASS`, `FETCH_SOURCE=CLASSIC_OUTLOOK_COM`, `RUN_ID`, `EXPORTED_COUNT`, `BATCH_COUNT`, `ZIP_SHA256`, and `ZIP_PATH_UTF8_B64`. All console lines are ASCII-only. Decode the path field as UTF-8 Base64 if needed to locate the local ZIP. Launcher starts the original COM Reader once with `UnreadOnly`, `ScanMode Auto`, `BatchSize 25`, `PreviewChars 350`, reads back *every* batch, verifies hashes, uniqueness and scope, then packages just the new run's manifest + JSONL in one ZIP. If Outlook does not support the optimized `Restrict` query, accept the Reader's declared `BASELINE_RESTRICT_UNAVAILABLE` fallback, but report that it ran slower, never switch to Graph. Original output stays local. If `READER_EXEC=FAIL` or bash reports an error, STOP with `BLOCKED_STAGE`; no fallback or reported mail summary.

### Step B – Single ZIP transfer and verified import

Transfer **exactly one** ZIP (`ZIP_PATH_UTF8_B64` decoded), from this run, through LenWork's authorized host-file-read/workspace transfer mechanism. Do not move private work mail to unapproved services. Never assume Pyodide can read Windows paths directly: use the approved transfer mechanism. Do not repeatedly copy individual batches or run `python subprocess`. If no authorized file bridge is available, say `BLOCKED_STAGE=HOST_TO_LENWORK_IMPORT`, STOP, and retain the host ZIP for diagnostics. Do not falsely claim import based on manifest counters.

In the Python sandbox, verify the *copied* ZIP in one execution; below is reference code. Set `zip_path` to the **workspace-local copy** and `expected_zip_sha` to the fresh `ZIP_SHA256` from Step A. Validate all expected members, SHA256 per file, the actual JSONL lines, uniqueness, unread flags and counts. Keep the verified `rows` in the permitted runtime or a local working JSONL for subsequent batch-based analysis. **Do not print raw IDs or contents in technical logs.**

```python
from pathlib import Path
from io import BytesIO
from zipfile import ZipFile
import hashlib, json
zip_path = Path('PATH_TO_APPROVED_IMPORTED_ZIP')
expected_zip_sha = 'FRESH_ZIP_SHA256_FROM_STEP_A'
raw = zip_path.read_bytes()
assert hashlib.sha256(raw).hexdigest() == expected_zip_sha, 'ZIP_SHA256'
with ZipFile(BytesIO(raw)) as z:
    names = z.namelist()
    assert len(names) == len(set(names)), 'ZIP_DUPLICATE_NAME'
    assert all(n == 'manifest.json' or (n.startswith('batches/mail_batch_') and n.endswith('.jsonl')) for n in names), 'ZIP_UNEXPECTED_MEMBER'
    m = json.loads(z.read('manifest.json').decode('utf-8'))
    assert m['schema'] == 'LENWORK_ORIGINAL_INBOX_EXPORT_V1'
    assert m['reader_version'] == '1.7.0' and m['source'] == 'classic_outlook_local_com'
    assert m['status'] == 'COMPLETE_LOCAL_STORE'
    assert m['scan_strategy_used'] in ('UNREAD_RESTRICT', 'BASELINE_RESTRICT_UNAVAILABLE')
    assert m['unread_only'] is True and not m['issue_codes']
    batch_files = [f for f in m['files'] if f['format'] == 'jsonl']
    assert len(batch_files) == m['batch_count'] and len(names) == 1 + len(batch_files), 'FILES'
    ids = set()
    rows = []
    for f in batch_files:
        payload = z.read(f['path'])
        assert hashlib.sha256(payload).hexdigest() == f['sha256'], 'BATCH_SHA256'
        lines = payload.decode('utf-8').splitlines()
        assert len(lines) == f['records'], 'BATCH_RECORDS'
        for line in lines:
            row = json.loads(line)
            assert row['is_unread'] is True and row['message_id'] not in ids, 'BAD_OR_DUPLICATE_ID'
            ids.add(row['message_id'])
            rows.append(row)
    assert len(rows) == m['unique_records'] == m['readback_records'], 'TOTAL_COUNT'
    print('IMPORT_STATUS=PASS')
    print('IMPORTED_COUNT=' + str(len(rows)))
    print('BATCHES_VERIFIED=' + str(len(batch_files)))
```

If import or validation fails, report `IMPORT_INCOMPLETE`, and STOP. No output based on a first batch or 50-result partial list.

### Step C – Prioritize only the complete import

Apply the **unchanged** `absender.md` and Steps 2–4 below to every verified message ID. Minimize Python/tool roundtrips: work through imported rows in batches of 20–30; extract only metadata and necessary previews, request full text only where ambiguous. Preserve real conversation IDs: identical templates are NOT proof of a common thread. Count every ID once before grouping. Only claim `END_TO_END_RESULT=COMPLETE` when `EXPORTED_COUNT=IMPORTED_COUNT=ANALYZED_COUNT`, zero missing/duplicate IDs, and all batches verified. Report `LAUNCH_TOTAL_MS`, but do not represent it as chat end-to-end time (the latter includes transfer, Python, and classification). The final German user-facing summary must follow unchanged Step 4.

**Fail-closed diagnostic fields:** `BLOCKED_STAGE`, `READER_EXEC`, `FETCH_SOURCE`, `RUN_ID`, `EXPORTED_COUNT`, `IMPORTED_COUNT`, `ANALYZED_COUNT`, `MISSING_COUNT`, `BATCHES_VERIFIED`, `END_TO_END_RESULT`. Never invent missing fields or treat an old run as current.

## Step 1 – Scope
- If the user gives a period (e.g. "Urlaub 22.09.–06.10."), use exactly that period.
- If the user explicitly requests **alle meine ungelesenen E-Mails**, use the entire unread Inbox history available in the local store, not only the last 14 days.
- Otherwise: all UNREAD emails in the Inbox from the last 14 days. State this assumption in the first line of the answer.
- Inbox only, plus subfolders the user names explicitly. Skip Junk, Deleted Items and Archive.


## Step 2 – Metadata first, full text only when needed
1. List for every email: sender, whether the user is in To or only in CC, subject, received date, importance flag, attachments yes/no, conversation/thread, short preview.
2. Apply absender.md: everything matching "Ignorieren" goes straight to ⚪ without opening it.
3. Group by conversation/thread. Judge each thread by its LATEST message. If the question in a thread was already answered or solved by someone else, put it under "Bereits erledigt" and name who solved it.
4. If possible, check Sent Items for the same period: if the user already replied to a thread, mark it as "bereits beantwortet".
5. Open the full text only for emails that cannot be clearly classified as 🔵 or ⚪ from the metadata.
6. Work in batches of about 20–30 emails. Do not stop early; process all emails in scope.

## Step 3 – Priorities
🔴 Sofort beantworten (today):
- a direct question or request to the user (user in To)
- a deadline that has passed or is within the next 2 working days (mark passed ones as "ÜBERFÄLLIG")
- anything from a VIP in absender.md that contains a question or a deadline
- reminders and escalations ("Erinnerung", "dringend", "nochmals", 2nd follow-up)
- meeting requests for the next days that still need a response

🟡 Diese Woche:
- a request to the user without a tight deadline
- a deadline within the next ~2 weeks
- coordination where the user's input is expected

🔵 Zur Kenntnis:
- user only in CC, status updates, decisions already made, finished threads, past meeting invitations

⚪ Ignorierbar:
- newsletters, HR/IT mass mailings, marketing, automatic notifications, out-of-office replies, expired invitations

When in doubt between two levels, choose the higher one.

## Step 4 – Output (German, short)
Start with one line: Zeitraum, Anzahl gelesener E-Mails, Verteilung (🔴 x / 🟡 x / 🔵 x / ⚪ x).

### 🔴 Sofort beantworten
Table: Nr. | Von | Betreff | Worum geht es (1 Satz) | Was wird von dir erwartet | Frist

### 🟡 Diese Woche
Same table.

### 🔵 Zur Kenntnis
One line per thread: Von – Betreff – Kernaussage in 1 Satz.

### ⚪ Ignorierbar
Counts by group only, no details (e.g. "HR-Rundmails: 4, Newsletter: 7, Systembenachrichtigungen: 12").

### 📅 Fristen und Termine
Chronological list of all deadlines and dates found: Datum – was – von wem.

### ✅ Bereits erledigt / beantwortet
One line each: Betreff – erledigt durch wen.

End with exactly one question: "Soll ich für die 🔴-Mails Antwortentwürfe vorbereiten?"
Keep every summary to one sentence. No long quotes from emails.
