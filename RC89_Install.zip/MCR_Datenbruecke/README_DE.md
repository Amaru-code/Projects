# MCR DATENBRUECKE 0.8.1-rc.87

Vollstaendiges, versionsgebundenes Update auf Basis RC86. Keine produktiven `private_data`-Dateien im Paket.

## Installation

1. ZIP separat und vollstaendig entpacken.
2. `MCR_Datenbruecke/START.cmd` aus dem entpackten Paket ausfuehren.
3. Menue **1**, bisherigen Installationsordner durch ENTER bestaetigen.
4. Danach ausschliesslich `START.cmd` im **installierten** Projektordner ausfuehren.

## Vereinfachtes Menue

```text
 1  Schnellinstallation / aktualisieren
 2  Bestandsdaten / Mapping aktualisieren (nur bei Bedarf)
 3  PHASE 1: Alle geeigneten Tickets bearbeiten
 4  PHASE 2: Bearbeiten und weiterleiten
 5  MASTER RUN: Phase 1 -> Phase 2
 0  Beenden
```

Phase 1: mit ENTER (oder `PHASE1_START`) einmal den laufenden Einsatz freigeben. Zuerst ein echter Pilot. Nur nach bestaetigtem E-Mail-Versand UND Speicherung darf der Bot einen groesseren Batch durchlaufen. Nach einer Weiterleitung ohne E-Mail wird lediglich der naechste Einzelpilot gestartet. Bis zu 100 Tickets pro Batch, hoechstens 10 Batches pro Start; weitere Durchlaeufe koennen anschliessend gestartet werden. Kein unbegrenzter Versand und kein blinder Wiederanlauf.

MASTER RUN: ENTER (oder `MASTER_START`), anschliessend Phase 1 und bei bestaetigtem Verlauf Phase 2. Phase 2 beginnt nicht, wenn der Phase-1-Nachweis unklar ist. PDF-Erzeugung im bestehenden Generator erfolgt weiterhin durch den Benutzer. Vorhandene Sperren, Protokolle und saemtliche Versand-/Weiterleitungsnachweise bleiben erhalten.

## Namen und Member

Vor-/Nachnamen stammen aus COMARCH-E-Mails, Originalnachrichten, Signaturen, sichtbaren Ticketfeldern und vor allem dem **bestaetigten COMARCH-Memberprofil**. Das Bestandsmapping dient dem ID-basierten USC-/Planabgleich. Ist der Member-Filter trotz Eingabe leer, klickt der Bot hoechstens einmal auf dasselbe Inputfeld (mit Hit-Test) und wartet nochmals. Ist der richtige Vorschlag weiterhin nicht sicher erkannt, wird die bisherige manuelle Member-Auswahl angeboten.

Bei einem **Namenskonflikt** sind ID, Vorname und Nachname aus dem COMARCH-Profil weiterhin separat zu verifizieren. Die abschliessende Frage nach Original-Ticket, Person und Berechtigung kann nach dieser Pruefung mit **ENTER** bestaetigt werden, oder mit `ABBRUCH` abgebrochen werden.

## Technische Wartung (aus Hauptmenue ausgeblendet)

Verfuegbar ueber Node.js mit `node tools/cli.mjs --selftest`, `--demo`, `--status`, `--review`, `--rollback`. Rueckweg stellt nur Software wieder her; keine Ticketdaten. Bestandsmapping weiterhin nur im dafuer vorgesehenen Menue 2 mit ausdruecklicher Freigabe pflegen.

**Release Candidate:** Die RC86-Master-Weiterleitungen sind durch das Laufprotokoll bestaetigt; RC87 wurde noch nicht produktiv in COMARCH getestet. Siehe `docs/RC87_RELEASE.md`.

## RC87: kurze Bestaetigungen, Fenster, Bearbeiter-Filter, Fehlerfortsetzung

Einmalige eindeutige Operator-Bestaetigungen erfordern nun nur **ENTER** statt langer Befehle. Abbruch bleibt `ABBRUCH`. Felder mit Namen, Mitgliedsnummern, Auswahlalternativen oder ungeklärten Schreibvorgaengen bleiben explizit. Das Phase-2-Fenster laesst sich an der Titelleiste ziehen; vor Browser-Eingaben ist es klickdurchlaessig (bei nicht bestaetigter Windows-Freigabe: sicher ausgeblendet). Der Bearbeiterfilter darf ein einziges Mal durch erneuten Klick ins identische Feld aktiviert werden. Ein alter DB-Fall mit unveraendertem Journal, aber unklarer erneuter **Lesebestaetigung** wird zur manuellen Pruefung zurueckgestellt; die anderen Tickets koennen fortfahren. Ein ungeklaerter Versand-, Speicher- oder Weiterleitungsklick stoppt weiterhin den Lauf.

RC89: Zwei reguläre Abschlussmeldungen, zusätzlich strukturierter Bericht für offene Fälle. Details siehe docs/RC89_RELEASE.md.
