# RC94 · Fünf Map-Prototypen zum Testen

Stand: 18. November 2026. Grundlage: die bereitgestellte RC94-Map `MCR_Flow_Lab_1_2_RC94.html` und ihr vorhandenes Ereignisformat `MCR_FLOW_EVENT_V1`.

## Schnell anfangen

1. Das ZIP vollständig in einen eigenen Ordner entpacken.
2. **`START_HIER.html`** doppelklicken.
3. Einen der fünf Prototypen öffnen. Alle starten mit dem gleichen fiktiven Szenario.
4. Unten **Weiter** oder **Abspielen** verwenden. Bei einer Entscheidung hält die Wiedergabe an und zeigt Auswahlknöpfe.
5. Mit **Letzte Entscheidung** zum vorherigen Abzweig zurückgehen und einen anderen Ausgang wählen.

Für die Simulation ist weder Node noch ein laufender Bot erforderlich. Die HTML-Dateien enthalten ihre Darstellung, Szenarien und die vollständige bisherige Originalkarte. Es werden keine Web-Bibliotheken nachgeladen.

## Die fünf Versionen

| Nr. | Ansicht | Schwerpunkt |
|---|---|---|
| 01 | Navigator | Große Anzeige: Wo befindet sich die Arbeit, was passiert jetzt, was ist der nächste bedingte Schritt? |
| 02 | Stationskarte | Eine nummerierte Strecke pro aktueller Phase; Stationen mit festen, lesbaren Beschriftungen. |
| 03 | Ticket-Leitstand | Ticket- und Phasenstände als Karten: in Arbeit, wartet/zurückgestellt, mit Nachweis abgeschlossen. |
| 04 | Entscheidungsansicht | Aktueller Prüfpunkt, seine Begründung und die möglichen Ausgänge. |
| 05 | Cockpit | Feste Kombination aus Phasen, aktueller Aktion, Browserorientierung, Ticketroute und Ergebnissen. |

Oben kannst du innerhalb jeder HTML-Datei zwischen allen fünf Ansichten wechseln. Der simulierte Verlauf bleibt dabei erhalten. Die fünf separat benannten Dateien öffnen jeweils ihre zugehörige Ansicht als Standard.

## Mit deinem vorhandenen RC94 verbinden

1. **`START_TEST.cmd`** aus dem entpackten Testpaket starten.
2. Den **bereits installierten** RC94-Hauptordner wählen. Ein vorhandener passender Ordner wird vorgeschlagen; ENTER bestätigt ihn. Gemeint ist beispielsweise `C:\Users\Amaru-Zegarra\projects\Aktive_Projekte\Ticket_bot\MCR_Datenbruecke`.
3. Die Vergleichsübersicht wird im Standardbrowser geöffnet. Eine Testversion öffnen; sie erhält die Verbindung automatisch.
4. Deinen Bot wie gewohnt über seine installierte `START.cmd` starten. Die neue Ansicht beobachtet die bereits vorhandene RC94-Ereignisspur.
5. Das zusätzliche Karten-Terminal offen lassen. STRG+C beendet nur diesen Kartenmonitor.

Du musst **keine fünf Botinstallationen durchführen**. Es sind fünf Testoberflächen für denselben RC94-Bot. Der Starter aktualisiert keine Installation, startet keinen Ticketlauf und lädt keinen ausführbaren Code aus der gewählten Installation. Er liest ausschließlich deren vorhandenes Präsentationsprotokoll unter `.runtime\flow-map\events.jsonl`.

Die automatische Map, die dein bisheriger Bot selbst öffnet, bleibt seine bisherige Map. Diese Prototypen werden zum Vergleich separat gestartet. So kannst du die Darstellung auswählen, bevor sie in den normalen Start integriert wird.

Mehrere Varianten können parallel mit demselben Lauf verbunden sein. Für einen verbundenen Test immer die Links aus der vom Starter geöffneten Übersicht verwenden. Eine direkt per Doppelklick geöffnete HTML-Datei hat keine automatische Live-Verbindung.

Wenn Node nicht gefunden wird, kannst du die HTML-Simulation trotzdem sofort verwenden. Der Live-Starter verwendet denselben bekannten Node-Pfad wie RC94 oder ein vorhandenes Node im PATH. Er benötigt Node 18 oder neuer.

## Vergleichen ohne viele Einstellungen

Beginne mit **Phase 2 · Unbekannte Anfrage**. Gehe mit Weiter bis zur fachlichen Entscheidung. Wähle zuerst **An Mark**, später **Weiterleitung simulieren**. Beobachte den Unterschied zwischen dem ausgelösten Weiterleitungsklick und dem danach bestätigten Nachweis.

Nutze anschließend **Letzte Entscheidung** oder **Anfang**, um **Offen lassen** und **Lauf stoppen** auszuprobieren. Vergleiche dieselbe Situation in den fünf Ansichten über das Auswahlfeld oben.

Weitere Szenarien:

- Master Run mit einer Standardantwort und einem gesonderten Phase-2-Ticket.
- DB / DB+ direkt an Mark.
- Kontoauszug mit fehlenden PDFs und Entwurf.
- Privater MBC-Login als Entwurf.
- Verbindungsfehler nach einem erfolgreich abgeschlossenen Phase-1-Pilot.
- Fehlgeschlagener Wertevergleich mit zurückgestelltem Ticket.
- Unklare Identität mit menschlicher Prüfung.
- Hauptmenü 0 bis 5, Installationsergebnis und Mapping-Prüfung als vereinfachte Simulation.

Der neue schnelle Simulator stellt ausgewählte reale Entscheidungsarten dar. Für sämtliche bisherigen Fachregeln, frei bearbeitbare Ticketzeilen und den freien Graphmodus öffne **Originalkarte**. **Zurück zum Prototyp** bringt dich wieder in die neue Ansicht.

## Bedienelemente

| Bedienung | Wirkung |
|---|---|
| Zurück / Weiter | Ein beobachtetes Simulations- oder Wiedergabeereignis zurück/vor. |
| Letzte Entscheidung | Zur zuletzt durchlaufenen Simulatorentscheidung zurück; ein neuer Ausgang ersetzt den bisherigen Folgezweig. |
| Abspielen / Pause | Ereignisse abspielen; an erforderlichen Entscheidungen wird angehalten. |
| Aa+ | Zentrale Kartenbeschriftungen und Erläuterungen vergrößern. |
| Bedienung ausblenden | Simulatorleiste ausblenden und der Ansicht mehr Raum geben. |
| Station / Ticket anklicken | Erklärung und Beleg im Seitenfluss öffnen; kein schwebendes Fenster über der Karte. |
| Belege | Herkunft, Ereigniscode, Zeit und bisherige Meldungen ansehen. |
| Wiedergabe | Den sichtbaren Verlauf einfrieren und durchgehen; ausdrücklich kein Live-Stand. |
| Datei laden | Eine RC94-`events.jsonl` als historische Wiedergabe öffnen; bei mehreren Läufen wird der letzte verwendet. |
| Variante bewerten | Lesbarkeit, Orientierung und Gesamtgefühl bewerten; Notiz lokal merken oder als JSON exportieren. |

Wenn mehrere Testfenster über denselben lokalen Starter geöffnet sind, kann **Testfenster synchronisieren** die Simulatorentscheidungen zwischen ihnen übertragen. Änderungen gelten für geöffnete Fenster im Simulationsmodus. Die Darstellung und Bewertung bleiben pro Ansicht individuell. Bei direkt geöffneten `file:`-Dateien hängt die fensterübergreifende Synchronisation von den Browserregeln ab; der Wechsel im selben Fenster funktioniert ohne diese Funktion.

## Was die Anzeige tatsächlich weiß

- **Simulation:** fiktive Tickets und simulierte Ergebnisse; keine COMARCH-Ausführung.
- **Live:** zuletzt eingegangene RC94-Ereignisse; eine funktionierende Verbindung beweist nicht, dass der Bot gerade arbeitet.
- **Wiedergabe:** ein historischer, eingefrorener Stand.
- **Bestätigt:** der zugehörige Nachweis wurde protokolliert. Eine Absicht, ein Klick oder eine Kontoauswahl allein ist kein Weiterleitungsnachweis.
- **Browserorientierung:** entweder ausdrücklich belegt oder aus einem Arbeitsschritt abgeleitet. RC94 liefert nicht jeden Seiten-/Reiterwechsel. Die Ansicht erfindet keine exakte Navigation.
- **Zähler:** nur aus vorhandenen Ereignissen des beobachteten Laufs, keine globale COMARCH-Ticketzahl.
- **Phase 3:** LenX und fachlicher Review sind weiterhin geplante Funktionen.

Die aktuelle Aktion aktualisiert sich direkt aus dem Ereignisstrom. Kurze Markierungen halten den Bot nicht auf und erzeugen keine absichtlich verzögerte „Live“-Vorführung. Für langsames Präsentieren gibt es die Wiedergabe. Nach einem erfolgreichen Lauf bleibt die Abschlussaussage erhalten, auch wenn der Browser anschließend geschlossen wird.

## Prüfumfang

Logik, Entscheidungsausgänge, die fünf Renderer, die zusammengebauten HTML-Scripts und der lokale Nur-Lese-Dienst wurden automatisiert geprüft. Details stehen in `PRUEFBERICHT.txt`.

Ein echter Windows-/Edge-/COMARCH-Durchlauf und eine visuelle Browserprüfung dieser fünf neuen Oberflächen wurden hier nicht ausgeführt. Der lokale Browserstart war in dieser Arbeitsumgebung gesperrt; die Cloud-Vorschau konnte den lokalen Testserver nicht erreichen. Deshalb enthalten die Ergebnisse keine Behauptung über einen bereits erfolgreichen Echtlauf der neuen Darstellung.

## Rückmeldung

Notiere einfach: **Nummer · was gefällt · was stört**. Auch „keine der fünf“ ist ein verwertbares Ergebnis. Die Oberflächen können danach gezielt kombiniert oder ersetzt werden.
