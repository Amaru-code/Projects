/* RC94 design prototype 03: ticket board. Presentation only. */
(() => {
  'use strict';
  const css = `
  .px-v3{--board-ink:#173246;--board-green:#087a55;display:grid;gap:20px;color:var(--board-ink)}
  .px-v3 .board-overview{display:flex;align-items:center;justify-content:space-between;gap:24px;padding:4px 0 0}
  .px-v3 .board-kicker{font-size:12px;letter-spacing:.12em;text-transform:uppercase;font-weight:750;color:#607584;margin:0 0 7px}
  .px-v3 .board-overview h2{font-size:28px;line-height:1.15;letter-spacing:-.025em;margin:0 0 7px}
  .px-v3 .board-overview p{font-size:15px;color:#536d7e;margin:0;line-height:1.5}
  .px-v3 .board-metrics{display:flex;gap:10px;flex-shrink:0}
  .px-v3 .board-metric{min-width:102px;border:1px solid #dde6e9;background:white;border-radius:13px;padding:12px 16px}
  .px-v3 .board-metric b{display:block;font-size:27px;font-weight:750;line-height:1.1;letter-spacing:-.03em}
  .px-v3 .board-metric span{display:block;margin-top:6px;font-size:13px;color:#516d7d}
  .px-v3 .board-metric.open b{color:#906000}
  .px-v3 .board-live{display:grid;grid-template-columns:minmax(0,1.35fr) minmax(250px,1fr);border:1px solid #cfe2d9;border-radius:16px;background:#f3faf6;overflow:hidden}
  .px-v3 .board-live-main{padding:19px 22px;border-left:5px solid #07805a}
  .px-v3 .board-live-main h3{font-size:25px;line-height:1.25;margin:8px 0 8px;letter-spacing:-.025em}
  .px-v3 .board-live-main p{font-size:15px;line-height:1.5;margin:0;color:#3d6156}
  .px-v3 .board-live-next{padding:19px 22px;border-left:1px solid #d8e9e0;display:flex;flex-direction:column;justify-content:center;gap:8px;background:#fff}
  .px-v3 .board-live-next small{font-size:12px;text-transform:uppercase;letter-spacing:.1em;font-weight:750;color:#6c7f89}
  .px-v3 .board-live-next p{font-size:17px;line-height:1.5;margin:0}
  .px-v3 .board-live.wait,.px-v3 .board-live.deferred{background:#fffbef;border-color:#eedeb5}
  .px-v3 .board-live.wait .board-live-main,.px-v3 .board-live.deferred .board-live-main{border-color:#b27a0a}
  .px-v3 .board-live.error{background:#fff4f1;border-color:#efcec6}
  .px-v3 .board-live.error .board-live-main{border-color:#bc4436}
  .px-v3 .board-live.error .board-live-main p{color:#774a43}
  .px-v3 .board-controls{display:flex;justify-content:space-between;align-items:center;gap:12px}
  .px-v3 .board-filter{display:flex;gap:5px;flex-wrap:wrap}
  .px-v3 .board-filter button{padding:8px 13px;border-radius:8px;background:#fff;border:1px solid #dee6eb;font-size:14px;color:#3c596c;font-weight:650}
  .px-v3 .board-filter button.active{background:#183b50;color:#fff;border-color:#183b50}
  .px-v3 .board-count-note{font-size:13px;color:#6c7d89;line-height:1.4;text-align:right}
  .px-v3 .board-lanes{display:grid;grid-template-columns:1.16fr 1fr 1fr;gap:16px;align-items:stretch}
  .px-v3 .board-lane{border:1px solid #e0e7eb;border-radius:14px;min-width:0;background:#f8fafb;display:flex;flex-direction:column;overflow:hidden}
  .px-v3 .board-lane-head{padding:15px 17px 14px;display:flex;align-items:center;justify-content:space-between;gap:8px;border-bottom:1px solid #e4eaed;background:white}
  .px-v3 .board-lane-head h3{font-size:16px;line-height:1.3;margin:0;font-weight:750}
  .px-v3 .board-lane-head .count{font-size:13px;min-width:25px;height:25px;border-radius:7px;display:grid;place-items:center;background:#eaf0f3;color:#476174}
  .px-v3 .board-lane.active .board-lane-head{border-top:3px solid #148560;padding-top:12px}
  .px-v3 .board-lane.open .board-lane-head{border-top:3px solid #d19b30;padding-top:12px}
  .px-v3 .board-lane.done .board-lane-head{border-top:3px solid #527a90;padding-top:12px}
  .px-v3 .board-lane-body{padding:12px;display:grid;gap:10px;align-content:start;max-height:390px;overflow:auto}
  .px-v3 .ticket-card{padding:16px;border:1px solid #dfe7eb;background:white;border-radius:11px;box-shadow:0 2px 3px #163d4b03}
  .px-v3 .ticket-card.selected{outline:2px solid #259b73;outline-offset:0}
  .px-v3 .ticket-card-top{display:flex;justify-content:space-between;gap:8px;align-items:center;margin-bottom:12px}
  .px-v3 .ticket-card-id{font-size:17px;color:#173246;letter-spacing:.015em;font-weight:800;background:none;border:0;padding:0;text-align:left}
  .px-v3 .ticket-card-id:hover{color:#087a55;text-decoration:underline}
  .px-v3 .ticket-card h4{font-size:17px;line-height:1.4;margin:0 0 11px;letter-spacing:-.01em}
  .px-v3 .ticket-status{display:flex;align-items:start;gap:7px;font-size:14px;line-height:1.5;color:#346d5a;margin:0 0 10px}
  .px-v3 .ticket-card.wait .ticket-status,.px-v3 .ticket-card.deferred .ticket-status{color:#916319}
  .px-v3 .ticket-meta{padding-top:11px;border-top:1px solid #edf1f4;color:#687d89;font-size:13px;line-height:1.6}
  .px-v3 .ticket-meta strong{color:#455f6e;font-weight:600}
  .px-v3 .ticket-open{padding:0;margin-top:10px;color:#357b64;border:0;background:transparent;font-size:13px;font-weight:700}
  .px-v3 .board-empty{padding:24px 13px;text-align:center;color:#6f8290;line-height:1.6;font-size:15px}
  .px-v3 .board-empty b{display:block;font-size:16px;margin-bottom:7px;color:#516c7d;font-weight:650}
  .px-v3 .board-bottom{display:flex;gap:18px;align-items:start;justify-content:space-between;border-top:1px solid #e5ebef;padding-top:13px;color:#5d7483;font-size:13px;line-height:1.5}
  .px-v3 .board-bottom button{flex-shrink:0;font-size:13px;border:0;background:#edf4f6;color:#365e76;border-radius:7px;padding:7px 11px}
  @media(max-width:1100px){.px-v3 .board-overview{align-items:flex-start}.px-v3 .board-metrics{gap:6px}.px-v3 .board-metric{min-width:82px;padding:11px}.px-v3 .board-lanes{gap:10px}.px-v3 .board-lane-body{padding:8px}.px-v3 .ticket-card{padding:12px}.px-v3 .board-live{grid-template-columns:1.2fr 1fr}}
  @media(max-width:760px){.px-v3{gap:15px}.px-v3 .board-overview{display:block}.px-v3 .board-metrics{margin-top:16px}.px-v3 .board-metric{flex:1}.px-v3 .board-live{grid-template-columns:1fr}.px-v3 .board-live-next{border-left:0;border-top:1px solid #d8e9e0}.px-v3 .board-lanes{grid-template-columns:1fr}.px-v3 .board-lane-body{max-height:none}.px-v3 .board-controls{align-items:flex-start;flex-direction:column}.px-v3 .board-count-note{text-align:left}.px-v3 .board-bottom{flex-direction:column}.px-v3 .board-overview h2{font-size:26px}}
  `;

  function render(vm,h) {
    const esc=h.e;
    const all=Array.isArray(vm.tickets)?vm.tickets:[];
    const filter=vm.filter||'all';
    const list=all.filter(t=>filter==='all'||filter==='open'&&['wait','deferred'].includes(t.state)||t.phase===filter);
    const active=list.filter(t=>t.state==='active');
    const open=list.filter(t=>['wait','deferred'].includes(t.state));
    const done=list.filter(t=>t.state==='done');
    function card(t) {
      const isDone=t.state==='done';
      const label=t.phase==='P2'?'Phase 2':'Phase 1';
      const doneText=t.phase==='P2'?'Interne Weiterleitung bestätigt':'Standardantwort und Speicherung bestätigt';
      const loc=typeof t.location==='string'?t.location:t.location?.label||'';
      return `<article class="ticket-card ${esc(t.state)} ${vm.selectedTicket===t.id?'selected':''}">
       <div class="ticket-card-top"><button class="ticket-card-id" data-action="select-ticket" data-ticket="${esc(t.id)}" aria-label="Verlauf von Ticket ${esc(h.ticket(t.id))} anzeigen">${esc(h.ticket(t.id))}</button>${h.badge(label,t.phase==='P2'?'blue':'neutral')}</div>
       <h4>${esc(isDone?doneText:t.action||t.statusText||'Schritt noch nicht gemeldet')}</h4>
       <p class="ticket-status"><span aria-hidden="true">${isDone?'✓':t.state==='active'?'●':'◷'}</span><span>${esc(t.statusText||(isDone?'Nachweis vorhanden':'Schritt wird beobachtet'))}</span></p>
       <div class="ticket-meta">${loc?`<strong>Letzter Bereich</strong><br>${esc(loc)}<br>`:''}${t.phase==='P2'?'<strong>Keine Kunden-E-Mail in Phase 2.</strong>':'Phase 1: Standardantwort.'}${t.lastAt?`<br>${esc(h.time(t.lastAt))}`:''}</div>
       <button class="ticket-open" data-action="select-ticket" data-ticket="${esc(t.id)}">Ticketverlauf ansehen →</button>
      </article>`;
    }
    function lane(cls,title,items,emptyTitle,emptyCopy) {
      return `<section class="board-lane ${cls}"><div class="board-lane-head"><h3>${title}</h3><span class="count">${items.length}</span></div><div class="board-lane-body">${items.length?items.map(card).join(''):`<div class="board-empty"><b>${emptyTitle}</b>${emptyCopy}</div>`}</div></section>`;
    }
    return `<div class="px-v3">
     <div class="board-overview"><div><p class="board-kicker">03 / Ticket-Leitstand</p><h2>Jedes Ticket an seinem Platz.</h2><p>Der Bot bearbeitet einen Fall nach dem anderen.</p></div><div class="board-metrics" aria-label="Nachweise im beobachteten Lauf"><div class="board-metric"><b>${Number(vm.counts?.p1||0)}</b><span>Phase 1 bestätigt</span></div><div class="board-metric"><b>${Number(vm.counts?.p2||0)}</b><span>Phase 2 bestätigt</span></div><div class="board-metric open"><b>${Number(vm.counts?.open||0)}</b><span>Offene Prüffälle</span></div></div></div>
     <section class="board-live ${esc(vm.status)}" aria-label="Aktueller Botzustand"><div class="board-live-main">${h.badge(vm.phaseTitle||'Noch kein Lauf')}&nbsp;${h.badge(vm.statusLabel||'Bereit',vm.status==='error'?'red':vm.status==='wait'?'amber':'green')}<h3>${esc(vm.actionLabel||'Bereit zum Beobachten')}</h3><p><strong>${esc(vm.place?.certainty||'Nicht gemeldet')}:</strong> ${esc(vm.place?.label||'Noch kein COMARCH-Bereich gemeldet')}</p></div><div class="board-live-next"><small>Danach · wenn die Voraussetzungen erfüllt sind</small><p>${esc(vm.next||'Auf die nächste Meldung warten.')}</p></div></section>
     ${h.choice(vm)}
     <div class="board-controls"><nav class="board-filter" aria-label="Ticketliste filtern">${[['all','Alle'],['P1','Phase 1'],['P2','Phase 2'],['open','Offene Fälle']].map(([id,label])=>`<button data-action="set-filter" data-filter="${id}" class="${filter===id?'active':''}" aria-pressed="${filter===id}">${label}</button>`).join('')}</nav><div class="board-count-note">${all.length} Ticket-/Phasenstände in diesem Lauf<br>Kein vollständiger COMARCH-Bestand</div></div>
     <div class="board-lanes">
      ${lane('active','In Arbeit',active,'Kein aktiver Fall in dieser Ansicht','Der nächste Fall erscheint, sobald er im Protokoll gemeldet wird.')}
      ${lane('open','Wartet / zurückgestellt',open,'Keine offenen Fälle gemeldet','Hier bleiben Rückfragen und zurückgestellte Tickets sichtbar.')}
      ${lane('done','Schritt bestätigt',done,'Noch kein Abschluss belegt','Ein Klick genügt nicht. Erst der bestätigte Nachweis verschiebt das Ticket hierher.')}
     </div>
     <div class="board-bottom"><span>Die Spalten zeigen protokollierte Zustände. „Schritt bestätigt“ bedeutet den Abschluss der jeweiligen Phase – die Kundenanfrage kann danach weiterbearbeitet werden.</span><button data-action="show-details">Belege und Ereignisse öffnen</button></div>
    </div>`;
  }
  window.ProtoVariants[3]={name:'Ticket-Leitstand',tagline:'Aktive, wartende und bestätigte Tickets auf einen Blick.',css,render};
})();
