(function () {
  'use strict';
  window.ProtoVariants[2] = {
    name: 'Stationskarte',
    tagline: 'Die gesamte Ticketroute auf einen Blick – Station für Station.',
    css: `
.px-v2 { --ink:#19304b; --emerald:#087e61; color:var(--ink); font-size:16px; line-height:1.45; }
.px-v2 * { box-sizing:border-box; }
.px-v2 button { font:inherit; }
.px-v2 .v2-phase-lines { display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:12px; margin:0 0 18px; }
.px-v2 .v2-phase { padding:13px 16px; border:1px solid #dce5eb; border-radius:12px; background:#fff; position:relative; }
.px-v2 .v2-phase.current { border-color:#64b79c; box-shadow:inset 0 -3px 0 #108869; background:#f3fbf7; }
.px-v2 .v2-phase.planned { border-style:dashed; color:#637389; background:#fcfcfd; }
.px-v2 .v2-phase strong { display:flex; gap:10px; align-items:center; font-size:18px; }
.px-v2 .v2-phase small { display:block; color:#62758a; font-size:16px; margin-top:4px; }
.px-v2 .v2-phase-dot { width:13px; height:13px; border-radius:50%; border:2px solid #9badba; background:#fff; flex:0 0 13px; }
.px-v2 .v2-phase.current .v2-phase-dot { border-color:#0c8666; background:#0c8666; }
.px-v2 .v2-phase.observed .v2-phase-dot { background:#b1c1cd; }
.px-v2 .v2-phase.planned .v2-phase-dot { border-style:dashed; }
.px-v2 .v2-sheet { background:#fff; border:1px solid #dae4eb; border-radius:17px; overflow:hidden; }
.px-v2 .v2-heading { display:flex; align-items:flex-start; justify-content:space-between; gap:20px; padding:20px 25px 15px; }
.px-v2 .v2-heading h2 { margin:0; font-size:24px; letter-spacing:-.35px; }
.px-v2 .v2-heading p { font-size:16px; color:#607588; margin:5px 0 0; }
.px-v2 .v2-ticket { font-size:16px; font-weight:650; color:#375873; text-align:right; }
.px-v2 .v2-ticket span { display:block; margin-top:5px; color:#607588; font-weight:400; }
.px-v2 .v2-tracks { padding:4px 25px 13px; }
.px-v2 .v2-track { display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:20px; position:relative; padding-top:6px; }
.px-v2 .v2-station-wrap { min-width:0; position:relative; }
.px-v2 .v2-station-wrap:not(:last-child)::after { content:''; position:absolute; top:20px; left:38px; right:-20px; height:3px; background:#dce6eb; z-index:0; }
.px-v2 .v2-station-wrap.connected:not(:last-child)::after { background:#129773; }
.px-v2 .v2-station { width:100%; background:transparent; border:1px solid transparent; padding:0 5px 9px 0; text-align:left; cursor:pointer; color:var(--ink); border-radius:10px; position:relative; z-index:1; }
.px-v2 .v2-station:hover { background:#f6faf8; }
.px-v2 .v2-station.selected { background:#edf7f2; border-color:#cfe5d9; }
.px-v2 .v2-station:focus-visible,.px-v2 .v2-detail-button:focus-visible { outline:3px solid #75bba7; outline-offset:3px; }
.px-v2 .v2-stop-row { display:flex; align-items:center; gap:10px; }
.px-v2 .v2-stop { display:grid; place-items:center; width:40px; height:40px; border:3px solid #c4d2dc; border-radius:50%; background:#fff; font-size:16px; font-weight:750; color:#6c8194; flex:0 0 40px; }
.px-v2 .v2-station-wrap.verified .v2-stop { border-color:#087e61; background:#087e61; color:#fff; }
.px-v2 .v2-station-wrap.observed .v2-stop { border-color:#8aa1b2; color:#4e677f; background:#f0f5f8; }
.px-v2 .v2-station-wrap.active .v2-stop { border-color:#087e61; color:#087e61; box-shadow:0 0 0 5px #e1f5eb; }
.px-v2 .v2-station-wrap.wait .v2-stop { border-color:#aa731b; color:#97600a; background:#fff5df; }
.px-v2 .v2-station-wrap.error .v2-stop { border-color:#b73d40; color:#a73235; background:#fff0ee; }
.px-v2 .v2-station-state { background:#fff; color:#61768a; font-size:16px; padding:1px 6px; position:relative; }
.px-v2 .v2-station-wrap.active .v2-station-state { color:#087e61; font-weight:700; }
.px-v2 .v2-station-wrap.wait .v2-station-state { color:#97600a; font-weight:650; }
.px-v2 .v2-station-wrap.error .v2-station-state { color:#b73d40; font-weight:650; }
.px-v2 .v2-station strong { display:block; font-size:17px; margin:10px 4px 0; line-height:1.25; overflow-wrap:anywhere; }
.px-v2 .v2-continue { color:#6b8093; font-size:16px; margin:0 0 3px; padding:2px 0 6px; border-bottom:1px solid #edf1f4; }
.px-v2 .v2-continue span { color:#315f7c; font-weight:600; }
.px-v2 .v2-info { margin:0 25px 20px; padding:17px 19px; border-radius:12px; background:#f3faf7; border:1px solid #d4e8df; display:grid; grid-template-columns:minmax(0,1.3fr) minmax(0,1fr); gap:24px; }
.px-v2 .v2-info.wait,.px-v2 .v2-info.deferred { background:#fffbf2; border-color:#ead8ac; }
.px-v2 .v2-info.error { background:#fff6f4; border-color:#ebccc6; }
.px-v2 .v2-info.idle { background:#f7f9fb; border-color:#e0e7ed; }
.px-v2 .v2-eyebrow { font-size:16px; color:#526e7e; font-weight:650; margin:0 0 5px; }
.px-v2 .v2-info h3 { margin:8px 0 9px; font-size:26px; line-height:1.2; letter-spacing:-.4px; }
.px-v2 .v2-info p { font-size:16px; color:#4c6678; margin:6px 0; }
.px-v2 .v2-place { font-size:17px; font-weight:650; }
.px-v2 .v2-detail-button { background:#fff; color:#255b73; border:1px solid #cbdbe4; border-radius:8px; font-size:16px; padding:8px 11px; margin-top:10px; cursor:pointer; }
.px-v2 .v2-detail-button:hover { border-color:#128264; }
.px-v2 .v2-branch { margin:0 25px 18px; padding:12px 0 0; border-top:1px solid #e7edf0; font-size:16px; }
.px-v2 .v2-branch summary { color:#385c76; font-weight:650; cursor:pointer; }
.px-v2 .v2-branch-grid { display:grid; grid-template-columns:1fr 1fr; gap:10px 20px; margin-top:12px; }
.px-v2 .v2-branch-grid p { margin:0; color:#586d80; font-size:16px; }
.px-v2 .v2-branch-grid strong { color:#213f59; }
.px-v2 .v2-choice { margin:16px 0 0; }
.px-v2 .v2-legend { display:flex; align-items:center; flex-wrap:wrap; gap:16px 24px; padding:12px 1px 0; color:#526c80; font-size:16px; }
.px-v2 .v2-legend span { display:flex; align-items:center; gap:8px; }
.px-v2 .v2-key { width:12px; height:12px; background:#fff; border:2px solid #c4d2dc; display:inline-block; border-radius:50%; }
.px-v2 .v2-key.done { background:#087e61; border-color:#087e61; }
.px-v2 .v2-key.now { border-color:#087e61; box-shadow:0 0 0 3px #e1f5eb; }
.px-v2 .v2-key.wait { background:#fff5df; border-color:#aa731b; }
.px-v2 .v2-empty { padding:20px 0 30px; color:#607588; font-size:18px; }
@media (max-width:1100px) { .px-v2 .v2-tracks { padding-left:20px; padding-right:20px; } .px-v2 .v2-track { gap:15px; } .px-v2 .v2-station-wrap:not(:last-child)::after { right:-15px; } .px-v2 .v2-info { margin-left:20px; margin-right:20px; gap:17px; } }
@media (max-width:760px) { .px-v2 .v2-phase-lines { grid-template-columns:1fr; gap:8px; } .px-v2 .v2-phase { padding:10px 14px; } .px-v2 .v2-phase small { margin-left:23px; } .px-v2 .v2-heading { flex-direction:column; gap:10px; padding:18px; } .px-v2 .v2-ticket { text-align:left; } .px-v2 .v2-track { grid-template-columns:1fr; gap:5px; padding:0; } .px-v2 .v2-station-wrap:not(:last-child)::after { left:19px; width:3px; right:auto; top:40px; bottom:-5px; height:auto; } .px-v2 .v2-station { display:grid; grid-template-columns:150px 1fr; align-items:center; gap:12px; padding:6px 0; } .px-v2 .v2-station strong { margin:0; } .px-v2 .v2-station-state { padding-left:0; } .px-v2 .v2-info { grid-template-columns:1fr; gap:10px; margin:12px 16px 16px; } .px-v2 .v2-info h3 { font-size:26px; } .px-v2 .v2-branch { margin:0 16px 16px; } .px-v2 .v2-branch-grid { grid-template-columns:1fr; } .px-v2 .v2-continue { padding:8px 0; margin:4px 0; } }
@media (prefers-reduced-motion:reduce) { .px-v2 * { animation:none!important; transition:none!important; } }
`,
    render(vm,h) {
      const e=h.e;
      const route=vm.route||[];
      const groups=[];
      for(let i=0;i<route.length;i+=3)groups.push(route.slice(i,i+3));
      const words={verified:'Bestätigt',observed:'Gemeldet',active:'Jetzt',wait:'Wartet',error:'Stopp',pending:'Offen'};
      const statusTone={active:'success',verified:'success',done:'success',wait:'warning',deferred:'warning',error:'danger',idle:'neutral'}[vm.status]||'neutral';
      const place=vm.place||{label:'Noch kein COMARCH-Bereich gemeldet',certainty:'Nicht gemeldet',detail:''};
      return `<div class="px-v2">
        <div class="v2-phase-lines" aria-label="Phasenübersicht">${(vm.phases||[]).map(p=>`<div class="v2-phase ${e(p.state)}" ${p.state==='current'?'aria-current="step"':''}><strong><span class="v2-phase-dot" aria-hidden="true"></span>${e(p.label)}</strong><small>${e(p.sub||'')}${p.state==='planned'&&!/geplant/i.test(p.sub||'')?' · Geplant':''}</small></div>`).join('')}</div>
        <section class="v2-sheet" aria-label="Stationen des aktuellen Ablaufs">
          <div class="v2-heading"><div><h2>${e(vm.phaseTitle||'Ticketroute')}</h2><p>Der nummerierten Route folgen. Stationen anklicken für Details.</p></div><div class="v2-ticket">${e(vm.ticketLabel||'Noch kein Ticket geöffnet')}<span>${route.length} Stationen · ${route.filter(s=>s.state==='verified').length} bestätigt</span></div></div>
          <div class="v2-tracks">${groups.map((g,gi)=>`<div class="v2-track" aria-label="Stationen ${gi*3+1} bis ${gi*3+g.length}">${g.map((s,j)=>`<div class="v2-station-wrap ${e(s.state||'pending')} ${s.state==='verified'&&g[j+1]?.state==='verified'?'connected':''}"><button class="v2-station ${vm.selectedStep===s.id?'selected':''}" data-action="select-step" data-step="${e(s.id)}" aria-label="Station ${gi*3+j+1}: ${e(s.label)}, ${e(words[s.state]||'Offen')}" ${['active','wait','error'].includes(s.state)?'aria-current="step"':''}><span class="v2-stop-row"><span class="v2-stop" aria-hidden="true">${s.state==='verified'?'✓':s.state==='error'?'!':gi*3+j+1}</span><span class="v2-station-state">${e(words[s.state]||'Offen')}</span></span><strong>${e(s.label)}</strong></button></div>`).join('')}</div>${gi<groups.length-1?`<div class="v2-continue">↓ <span>Weiter bei Station ${gi*3+4}</span></div>`:''}`).join('')}${!route.length?'<p class="v2-empty">Die Route erscheint mit dem ersten Ereignis.</p>':''}</div>
          <div class="v2-info ${e(vm.status||'idle')}"><div>${h.badge(vm.statusLabel||'Bereit',statusTone)}<h3>${e(vm.actionLabel||'Bereit für den ersten Schritt')}</h3><p>${e(vm.reason||'Wähle ein Szenario oder verbinde diese Ansicht mit RC94.')}</p><button class="v2-detail-button" data-action="show-details">Aktuelles Ereignis ansehen</button></div><div><p class="v2-eyebrow">Orientierung im Browser</p><div class="v2-place">${e(place.label)}</div><p>${e(place.certainty)}${place.detail?' · '+e(place.detail):''}</p><p class="v2-eyebrow" style="margin-top:14px">Danach, falls die Voraussetzungen erfüllt sind</p><p>${e(vm.next||'Noch kein nächster Schritt gemeldet.')}</p></div></div>
          ${vm.phase==='P2'?`<details class="v2-branch"><summary>Welche Wege kann Phase 2 nehmen?</summary><div class="v2-branch-grid"><p><strong>DB / DB+</strong><br>Direkt intern an Mark; kein Kundenversand.</p><p><strong>Kontoauszug für DC / PP+</strong><br>Nachweise und PDF prüfen; Entwurf zur internen Prüfung.</p><p><strong>Privater MBC-Login</strong><br>Antwortentwurf vorbereiten und intern zur Prüfung geben.</p><p><strong>Unbekannte Anfrage</strong><br>Fachlich einordnen; Mark, offen lassen oder Lauf stoppen.</p></div></details>`:''}
        </section>
        ${vm.choice?`<div class="v2-choice">${h.choice(vm)}</div>`:''}
        <div class="v2-legend" aria-label="Legende"><span><i class="v2-key done" aria-hidden="true"></i>Bestätigt</span><span><i class="v2-key now" aria-hidden="true"></i>Aktueller Schritt</span><span><i class="v2-key wait" aria-hidden="true"></i>Warten / Prüfung</span><span><i class="v2-key" aria-hidden="true"></i>Noch nicht bestätigt</span></div>
      </div>`;
    }
  };
})();
