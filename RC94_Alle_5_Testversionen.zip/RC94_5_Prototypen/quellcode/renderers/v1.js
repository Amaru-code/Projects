(function () {
  'use strict';
  window.ProtoVariants[1] = {
    name: 'Navigator',
    tagline: 'Ort, Aktion und nächster Schritt – groß und ruhig.',
    css: `
.px-v1 { --navy:#172d46; --green:#0c8666; color:var(--navy); font-size:16px; line-height:1.45; }
.px-v1 * { box-sizing:border-box; }
.px-v1 button { font:inherit; }
.px-v1 .v1-layout { display:grid; grid-template-columns:minmax(0,1.25fr) minmax(330px,.8fr); gap:20px; margin-top:16px; }
.px-v1 .v1-main { min-width:0; }
.px-v1 .v1-location { border:1px solid #dbe4eb; background:#fff; border-radius:16px; padding:18px 22px; display:flex; gap:15px; align-items:flex-start; }
.px-v1 .v1-loc-icon { flex:0 0 42px; height:42px; display:grid; place-items:center; color:#315775; border-radius:12px; background:#edf3f8; }
.px-v1 .v1-loc-icon svg { width:25px; height:25px; }
.px-v1 .v1-kicker { color:#53697c; font-size:16px; font-weight:650; margin:0 0 5px; }
.px-v1 .v1-location strong { display:block; font-size:20px; font-weight:700; line-height:1.35; }
.px-v1 .v1-location p { margin:6px 0 0; color:#596c7d; font-size:16px; }
.px-v1 .v1-location .v1-confidence { margin-top:7px; color:#49647a; font-size:16px; }
.px-v1 .v1-hero { margin-top:14px; border:1px solid #cde7df; border-left:5px solid var(--green); border-radius:17px; padding:24px 25px; background:linear-gradient(120deg,#f6fcf9,#fff 72%); }
.px-v1 .v1-hero.wait { border-color:#ead5a5; border-left-color:#a66c0b; background:linear-gradient(120deg,#fffaf0,#fff 72%); }
.px-v1 .v1-hero.error { border-color:#ecc8c8; border-left-color:#bb4141; background:linear-gradient(120deg,#fff5f4,#fff 72%); }
.px-v1 .v1-hero.deferred { border-color:#ead5a5; border-left-color:#a66c0b; background:#fffdf7; }
.px-v1 .v1-hero.idle { border-color:#dbe4eb; border-left-color:#7892a6; background:#fff; }
.px-v1 .v1-topline { display:flex; justify-content:space-between; align-items:center; gap:12px; flex-wrap:wrap; }
.px-v1 .v1-ticket { font-size:16px; color:#475f73; font-weight:650; }
.px-v1 .v1-hero h2 { font-size:clamp(27px,2.4vw,35px); font-weight:750; line-height:1.2; margin:19px 0 14px; letter-spacing:-.6px; overflow-wrap:anywhere; }
.px-v1 .v1-hero .v1-explanation { font-size:17px; color:#425c70; line-height:1.55; margin:0; }
.px-v1 .v1-next { border-top:1px solid #dce9e3; margin-top:21px; padding-top:17px; display:flex; align-items:flex-start; gap:12px; }
.px-v1 .v1-next-arrow { color:var(--green); font-size:25px; line-height:1.3; }
.px-v1 .v1-next p { margin:3px 0 0; color:#455c70; font-size:17px; }
.px-v1 .v1-detail-button { border:1px solid #c8d8e3; border-radius:9px; padding:9px 13px; margin-top:18px; color:#214d69; background:#fff; cursor:pointer; }
.px-v1 .v1-detail-button:hover { border-color:#1b8067; background:#f2faf7; }
.px-v1 .v1-detail-button:focus-visible,.px-v1 .v1-step:focus-visible { outline:3px solid #76b9a9; outline-offset:3px; }
.px-v1 .v1-choice { margin-top:16px; }
.px-v1 .v1-route { background:#fff; border:1px solid #dbe4eb; border-radius:16px; padding:19px 21px 13px; min-width:0; }
.px-v1 .v1-route-head { display:flex; justify-content:space-between; align-items:flex-start; gap:10px; padding-bottom:12px; }
.px-v1 .v1-route h3 { margin:0; font-size:20px; }
.px-v1 .v1-route-head span { color:#627487; font-size:16px; }
.px-v1 .v1-route ol { list-style:none; margin:0; padding:0; }
.px-v1 .v1-route li { position:relative; padding-bottom:3px; }
.px-v1 .v1-route li:not(:last-child)::after { position:absolute; content:''; left:18px; width:2px; top:39px; bottom:-5px; background:#dce5ea; pointer-events:none; }
.px-v1 .v1-route li.connected:not(:last-child)::after { background:#169b76; }
.px-v1 .v1-step { border:1px solid transparent; border-radius:10px; width:100%; background:transparent; padding:8px 7px 10px 0; text-align:left; display:grid; grid-template-columns:38px 1fr; gap:12px; align-items:start; cursor:pointer; color:var(--navy); }
.px-v1 .v1-step:hover { background:#f6f9fb; }
.px-v1 .v1-step.selected { background:#eef7f3; border-color:#d3e8de; }
.px-v1 .v1-node { width:37px; height:37px; background:#fff; border:2px solid #d5e0e7; display:grid; place-items:center; border-radius:50%; font-size:16px; font-weight:700; z-index:1; color:#6a7f90; }
.px-v1 .v1-route li.verified .v1-node { background:#087d5f; border-color:#087d5f; color:#fff; }
.px-v1 .v1-route li.observed .v1-node { border-color:#8fa6b7; background:#eff4f7; color:#47647c; }
.px-v1 .v1-route li.active .v1-node { border-color:#0c8666; color:#0c8666; box-shadow:0 0 0 4px #e3f5ed; }
.px-v1 .v1-route li.wait .v1-node { border-color:#af751c; background:#fff6e3; color:#915d08; }
.px-v1 .v1-route li.error .v1-node { border-color:#bb4141; background:#fff1ef; color:#b12c2c; }
.px-v1 .v1-step strong { display:block; font-size:17px; line-height:1.3; margin-top:2px; }
.px-v1 .v1-step small { display:block; color:#61768a; font-size:16px; margin-top:2px; line-height:1.25; }
.px-v1 .v1-route-note { color:#627589; border-top:1px solid #e5ebef; padding-top:12px; margin:10px 0 0; font-size:16px; }
.px-v1 .v1-summary { display:grid; grid-template-columns:1fr 1fr 1fr; gap:14px; margin-top:16px; }
.px-v1 .v1-stat { border:1px solid #dbe4eb; border-radius:12px; padding:14px 16px; background:#fff; }
.px-v1 .v1-stat strong { font-size:25px; line-height:1.1; margin-right:7px; }
.px-v1 .v1-stat span { font-size:16px; color:#50677a; }
.px-v1 .v1-footnote { margin:9px 0 0; font-size:16px; color:#687b8d; }
.px-v1 .v1-empty { padding:20px 0; color:#64798a; }
@media (max-width:1100px) { .px-v1 .v1-layout { grid-template-columns:minmax(0,1.1fr) minmax(300px,.9fr); gap:14px; } .px-v1 .v1-hero { padding:20px; } .px-v1 .v1-route { padding:17px 15px; } }
@media (max-width:760px) { .px-v1 .v1-layout { grid-template-columns:1fr; } .px-v1 .v1-hero h2 { font-size:28px; } .px-v1 .v1-summary { grid-template-columns:1fr; gap:8px; } .px-v1 .v1-stat { padding:11px 16px; } .px-v1 .v1-location { padding:16px; } }
@media (prefers-reduced-motion:reduce) { .px-v1 * { animation:none!important; transition:none!important; } }
`,
    render(vm,h) {
      const e=h.e;
      const route=vm.route||[];
      const currentIndex=route.findIndex(s=>['active','wait','error'].includes(s.state));
      const stateWords={verified:'Bestätigt',observed:'Gemeldet',active:'Jetzt',wait:'Wartet',error:'Unterbrochen',pending:'Noch nicht bestätigt'};
      const statusTone={active:'success',verified:'success',done:'success',wait:'warning',deferred:'warning',error:'danger',idle:'neutral'}[vm.status]||'neutral';
      const place=vm.place||{label:'Noch kein COMARCH-Bereich gemeldet',certainty:'Nicht gemeldet',detail:''};
      const counts=vm.counts||{};
      const locHeading=place.certainty==='Belegt'?'Letzter bestätigter Ort':'Orientierung im Browser';
      return `<div class="px-v1">
        ${h.phaseRail(vm)}
        <div class="v1-layout">
          <section class="v1-main" aria-label="Aktuelle Navigation">
            <div class="v1-location">
              <div class="v1-loc-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M19 10c0 5-7 11-7 11S5 15 5 10a7 7 0 1 1 14 0Z"/><circle cx="12" cy="10" r="2.5"/></svg></div>
              <div><p class="v1-kicker">${e(locHeading)}</p><strong>${e(place.label)}</strong><p class="v1-confidence">${e(place.certainty)}${place.detail?' · '+e(place.detail):''}</p></div>
            </div>
            <article class="v1-hero ${e(vm.status||'idle')}">
              <div class="v1-topline">${h.badge(vm.statusLabel||'Bereit',statusTone)}<span class="v1-ticket">${e(vm.ticketLabel||'Noch kein Ticket geöffnet')}</span></div>
              <h2>${e(vm.actionLabel||'Bereit für den ersten Schritt')}</h2>
              <p class="v1-explanation">${e(vm.reason||'Wähle ein Szenario oder verbinde die Ansicht mit dem bestehenden RC94-Lauf.')}</p>
              <div class="v1-next"><span class="v1-next-arrow" aria-hidden="true">→</span><div><p class="v1-kicker">${vm.outcome?'Ergebnis / Fortsetzung':'Danach, wenn die Voraussetzungen erfüllt sind'}</p><p>${e(vm.next||'Der nächste Schritt wird angezeigt, sobald er bekannt ist.')}</p></div></div>
              <button class="v1-detail-button" data-action="show-details">Ereignis und Nachweis ansehen</button>
            </article>
            ${vm.choice?`<div class="v1-choice">${h.choice(vm)}</div>`:''}
          </section>
          <aside class="v1-route" aria-label="Route des aktuellen Tickets">
            <div class="v1-route-head"><div><p class="v1-kicker">Deine Orientierung</p><h3>${e(vm.phaseTitle||'Ablauf')}</h3></div><span>${currentIndex>=0?`${currentIndex+1} / ${route.length}`:`${route.length} Stationen`}</span></div>
            <ol>${route.map((s,i)=>`<li class="${e(s.state||'pending')} ${s.state==='verified'&&route[i+1]?.state==='verified'?'connected':''}"><button class="v1-step ${vm.selectedStep===s.id?'selected':''}" data-action="select-step" data-step="${e(s.id)}" aria-label="Station ${i+1}: ${e(s.label)}, ${e(stateWords[s.state]||'Noch nicht bestätigt')}" ${['active','wait','error'].includes(s.state)?'aria-current="step"':''}><span class="v1-node" aria-hidden="true">${s.state==='verified'?'✓':s.state==='error'?'!':i+1}</span><span><strong>${e(s.label)}</strong><small>${e(stateWords[s.state]||'Noch nicht bestätigt')}</small></span></button></li>`).join('')}</ol>
            ${!route.length?'<div class="v1-empty">Mit dem ersten Ereignis erscheint die passende Route.</div>':''}
            <p class="v1-route-note">Station anklicken, um den Schritt genauer zu verstehen.</p>
          </aside>
        </div>
        <div class="v1-summary" aria-label="Bestätigte Ergebnisse des beobachteten Laufs">
          <div class="v1-stat"><strong>${e(counts.p1||0)}</strong><span>Phase 1 bestätigt</span></div>
          <div class="v1-stat"><strong>${e(counts.p2||0)}</strong><span>Phase 2 weitergeleitet</span></div>
          <div class="v1-stat"><strong>${e(counts.open||0)}</strong><span>Offene Fälle gemeldet</span></div>
        </div><p class="v1-footnote">Zähler beziehen sich auf diesen beobachteten Lauf und die gemeldeten Fälle.</p>
      </div>`;
    }
  };
})();
