/* RC94 design prototype 04: one current decision, clearly bounded branches. */
(() => {
  'use strict';
  const css=`
  .px-v4{--decision-ink:#183549;--decision-green:#087c56;display:grid;gap:18px;color:var(--decision-ink)}
  .px-v4 .decision-topline{display:flex;align-items:center;justify-content:space-between;gap:20px;padding:3px 0 0}
  .px-v4 .decision-topline h2{font-size:27px;letter-spacing:-.025em;margin:4px 0 0;line-height:1.25}
  .px-v4 .decision-kicker{font-size:12px;font-weight:750;letter-spacing:.12em;text-transform:uppercase;color:#607989}
  .px-v4 .decision-topline p{max-width:360px;line-height:1.55;font-size:14px;color:#5c7485;margin:0;text-align:right}
  .px-v4 .decision-workspace{display:grid;grid-template-columns:240px minmax(0,1fr);gap:24px;align-items:start}
  .px-v4 .decision-trail{padding:19px 17px;border:1px solid #e0e7ec;border-radius:14px;background:#fafcfd;min-width:0}
  .px-v4 .decision-trail h3{font-size:15px;margin:0 0 6px;letter-spacing:-.01em}
  .px-v4 .decision-trail>p{font-size:13px;color:#748791;line-height:1.5;margin:0 0 20px}
  .px-v4 .decision-history{display:grid;gap:0;margin:0;padding:0;list-style:none}
  .px-v4 .decision-history li{position:relative;margin:0;padding:0 0 22px 25px;font-size:14px;line-height:1.45;color:#567082}
  .px-v4 .decision-history li::before{content:'✓';position:absolute;left:0;top:1px;width:17px;height:17px;display:grid;place-items:center;border-radius:50%;background:#dfefe7;color:#1d815c;font-size:11px;font-weight:800;z-index:1}
  .px-v4 .decision-history li::after{content:'';position:absolute;left:8px;top:17px;bottom:0;width:2px;background:#dce9e3}
  .px-v4 .decision-history li:last-child{padding-bottom:0}
  .px-v4 .decision-history li:last-child::after{display:none}
  .px-v4 .decision-history li b{display:block;color:#254b5c;font-size:14px;font-weight:650;margin-top:4px}
  .px-v4 .decision-history .observed::before{content:'•';background:#e8edf1;color:#5b7689}
  .px-v4 .decision-empty{font-size:14px;color:#6e818c;line-height:1.6;padding:8px 0}
  .px-v4 .decision-trail button{margin-top:20px;border:0;border-top:1px solid #e0e8ed;background:transparent;border-radius:0;padding:14px 0 0;width:100%;text-align:left;font-size:13px;font-weight:650;color:#426b80}
  .px-v4 .decision-main{min-width:0;display:grid;gap:0}
  .px-v4 .decision-place{display:flex;gap:12px;align-items:flex-start;padding:0 5px 18px;font-size:14px;color:#547080;line-height:1.5}
  .px-v4 .decision-place .place-icon{display:grid;place-items:center;width:28px;height:28px;background:#edf3f6;color:#395f76;border-radius:8px;font-size:17px;flex-shrink:0}
  .px-v4 .decision-place strong{font-size:15px;color:#2a4d61;font-weight:650}
  .px-v4 .decision-place small{font-size:12px;color:#6d7f8a;display:block;margin-top:2px}
  .px-v4 .decision-card{position:relative;border:1px solid #cddfd5;border-radius:18px;background:#fff;box-shadow:0 10px 32px #153e4f08;overflow:hidden}
  .px-v4 .decision-card::before{content:'';height:5px;background:#0c815b;display:block}
  .px-v4 .decision-card.wait{border-color:#e6d5ac}
  .px-v4 .decision-card.wait::before{background:#b17a0e}
  .px-v4 .decision-card.error{border-color:#edcec7}
  .px-v4 .decision-card.error::before{background:#ba493c}
  .px-v4 .decision-card-head{padding:23px 27px 0;display:flex;gap:10px;align-items:center;justify-content:space-between}
  .px-v4 .decision-card-head>span{font-size:13px;letter-spacing:.02em;font-weight:650;color:#728591}
  .px-v4 .decision-card-content{padding:17px 27px 24px}
  .px-v4 .decision-card h3{font-size:32px;font-weight:750;letter-spacing:-.03em;line-height:1.2;margin:0 0 16px;max-width:850px}
  .px-v4 .decision-reason{font-size:17px;line-height:1.65;color:#4d697b;margin:0}
  .px-v4 .decision-reason strong{color:#284b5e;font-weight:650}
  .px-v4 .decision-card-foot{display:flex;align-items:center;justify-content:space-between;gap:15px;padding:13px 27px;background:#f7faf9;border-top:1px solid #e7eeea;font-size:13px;line-height:1.5;color:#5a776b}
  .px-v4 .decision-card-foot button{background:transparent;border:0;color:#187c59;font-weight:700;padding:0;font-size:13px;white-space:nowrap}
  .px-v4 .decision-connector{display:flex;align-items:center;justify-content:center;height:41px;position:relative;color:#8ca79b;font-size:19px;pointer-events:none}
  .px-v4 .decision-connector::before{content:'';position:absolute;top:0;left:50%;height:21px;width:2px;background:#b9d5c7}
  .px-v4 .decision-connector span{position:relative;top:11px;line-height:1}
  .px-v4 .decision-exits{border:1px solid #dce6eb;border-radius:14px;background:#fafcfd;padding:20px 23px}
  .px-v4 .decision-exits h4{font-size:15px;color:#5a7483;margin:0 0 13px;line-height:1.4}
  .px-v4 .decision-exits .px-choice{margin:0}
  .px-v4 .decision-exits button{min-height:53px;white-space:normal;font-size:16px}
  .px-v4 .decision-next{display:flex;gap:15px;align-items:flex-start}
  .px-v4 .decision-next .next-icon{display:grid;place-items:center;flex-shrink:0;width:37px;height:37px;background:#e4f0e9;color:#0a7c56;border-radius:11px;font-size:21px}
  .px-v4 .decision-next p{font-size:18px;line-height:1.5;color:#294e61;margin:0}
  .px-v4 .decision-next small{font-size:13px;color:#657d8b;display:block;margin-top:8px;line-height:1.5}
  .px-v4 .decision-live-note{padding:12px 0 0;font-size:13px;color:#7b6a43;line-height:1.6;margin:0}
  .px-v4 .decision-footer{display:flex;justify-content:space-between;gap:15px;align-items:center;padding:14px 0 0;border-top:1px solid #e2eaee;font-size:13px;line-height:1.55;color:#6a808c}
  .px-v4 .decision-footer button{font-size:13px;padding:8px 12px;color:#446d82;border:1px solid #dce6ec;border-radius:8px;background:#fff;white-space:nowrap}
  @media(max-width:1100px){.px-v4 .decision-workspace{grid-template-columns:205px minmax(0,1fr);gap:17px}.px-v4 .decision-card h3{font-size:28px}.px-v4 .decision-card-content{padding:17px 22px 22px}.px-v4 .decision-card-head{padding:20px 22px 0}.px-v4 .decision-card-foot{padding:12px 22px}}
  @media(max-width:760px){.px-v4 .decision-topline{align-items:flex-start;flex-direction:column;gap:10px}.px-v4 .decision-topline p{text-align:left;max-width:none}.px-v4 .decision-workspace{display:flex;flex-direction:column-reverse;gap:20px}.px-v4 .decision-main,.px-v4 .decision-trail{width:100%}.px-v4 .decision-trail{padding:17px}.px-v4 .decision-history{grid-template-columns:1fr 1fr;gap:15px}.px-v4 .decision-history li{padding-bottom:0}.px-v4 .decision-history li::after{display:none}.px-v4 .decision-card h3{font-size:26px}.px-v4 .decision-card-head{align-items:flex-start;gap:10px}.px-v4 .decision-card-content{padding:16px 19px 22px}.px-v4 .decision-card-head{padding:20px 19px 0}.px-v4 .decision-exits{padding:17px}.px-v4 .decision-footer{align-items:flex-start;flex-direction:column}.px-v4 .decision-card-foot{align-items:flex-start}}
  `;

  function render(vm,h){
    const e=h.e;
    const branches=vm.branchHistory||[];
    const steps=(vm.route||[]).filter(s=>['verified','observed'].includes(s.state)).slice(-5);
    const decision=vm.choice;
    const canChoose=Boolean(decision&&vm.mode==='simulation');
    let trail;
    if(branches.length){trail=branches.slice(-5).map(b=>`<li>${e(b.label)}<b>${e(b.answer)}</b></li>`).join('');}
    else if(steps.length){trail=steps.map(s=>`<li class="${s.state==='observed'?'observed':''}">${e(s.label)}<b>${s.state==='verified'?'Nachweis bestätigt':'Im Protokoll beobachtet'}</b></li>`).join('');}
    else trail='';
    const question=decision?.question||vm.actionLabel||'Auf das erste Ereignis warten';
    const statusTone=vm.status==='error'?'red':vm.status==='wait'||vm.status==='deferred'?'amber':'green';
    return `<div class="px-v4">
      <div class="decision-topline"><div><span class="decision-kicker">04 / Entscheidungen verstehen</span><h2>Ein Prüfpunkt. Ein klarer Weg.</h2></div><p>Der aktuelle Schritt steht im Mittelpunkt. Vorherige Entscheidungen bleiben nachvollziehbar.</p></div>
      ${h.phaseRail(vm)}
      <div class="decision-workspace">
       <aside class="decision-trail"><h3>Bisheriger Weg</h3><p>${branches.length?'Deine Entscheidungen in dieser Simulation.':'Beobachtete Schritte dieses Tickets.'}</p>${trail?`<ol class="decision-history">${trail}</ol>`:'<div class="decision-empty">Der Verlauf beginnt mit der ersten protokollierten Aktion.</div>'}<button data-action="show-details">Gesamten Ereignisverlauf ansehen →</button></aside>
       <section class="decision-main" aria-label="Aktueller Prüfpunkt">
        <div class="decision-place"><span class="place-icon" aria-hidden="true">⌖</span><div><strong>${e(vm.place?.label||'Noch kein COMARCH-Bereich gemeldet')}</strong><small>${e(vm.place?.certainty||'Nicht gemeldet')}${vm.place?.detail?' · '+e(vm.place.detail):''}</small></div></div>
        <article class="decision-card ${e(vm.status)}">
         <div class="decision-card-head">${h.badge(vm.statusLabel||'Bereit',statusTone)}<span>${e(vm.ticketLabel||'Noch kein Ticket')}</span></div>
         <div class="decision-card-content"><h3>${e(question)}</h3><p class="decision-reason"><strong>${decision?'Entscheidungsgrund':'Was die Meldung bedeutet'}:</strong> ${e(vm.reason||'Die nächste Botmeldung wird hier mit ihrem Kontext angezeigt.')}</p></div>
         <div class="decision-card-foot"><span>${e(vm.phaseTitle||'Programm')}${vm.current?.at?' · '+e(h.time(vm.current.at)):''}</span><button data-action="show-details">Nachweis ansehen ↗</button></div>
        </article>
        <div class="decision-connector" aria-hidden="true"><span>↓</span></div>
        <section class="decision-exits">
         <h4>${canChoose?'Welche Entscheidung möchtest du testen?':decision?'Entscheidung im Bot erforderlich':'Nächster möglicher Schritt'}</h4>
         ${canChoose?h.choice(vm):`<div class="decision-next"><span class="next-icon" aria-hidden="true">→</span><div><p>${e(vm.next||'Auf die nächste bestätigte Meldung warten.')}</p><small>Noch keine ausgeführte Aktion; erst ein Ereignis bestätigt den nächsten Schritt.</small></div></div>`}
         ${vm.mode==='live'?'<p class="decision-live-note">Live-Beobachtung: Eine erforderliche Freigabe erfolgt im Bot. Diese Ansicht erteilt keine Freigaben.</p>':''}
        </section>
       </section>
      </div>
      <div class="decision-footer"><span>Für den kompletten Zusammenhang bleiben alle ursprünglichen Entscheidungsdiagramme verfügbar. Phase 3 mit LenX und inhaltlichem Review ist geplant.</span><button data-action="original">Vollständige Diagramme öffnen</button></div>
    </div>`;
  }
  window.ProtoVariants[4]={name:'Entscheidungsansicht',tagline:'Warum der Bot diesen Weg nimmt – Schritt für Schritt.',css,render};
})();
