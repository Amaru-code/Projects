/* Five read-only presentation views for the existing RC94 event schema. */
(()=>{
'use strict';
const $=id=>document.getElementById(id),SC=window.ProtoScenarios,V=window.ProtoVariants;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const tone=s=>({success:'good',warning:'wait',danger:'bad',green:'good',red:'bad',amber:'wait',blue:'neutral'})[s]||s;
const params=()=>new URLSearchParams(location.hash.slice(1));
const token=params().get('live');
const canLive=location.protocol==='http:'&&location.hostname==='127.0.0.1'&&/^[a-f0-9]{64}$/.test(token||'');
const phases={P1:'Phase 1 · Standardantwort',P2:'Phase 2 · Bearbeiten und weiterleiten',SYSTEM:'Start und Laufsteuerung'};
const stageDefs={
 start:['Start / Menü','Startweg und erforderliche Freigaben.'],browser:['Bot-Edge','Verbindung mit dem eigenen Bot-Browser.'],
 p1scan:['Ticket auswählen','Geeignete Fälle in den erlaubten Listen finden.'],person:['Person prüfen','Originalnachricht, Name und COMARCH-Member abgleichen.'],mapping:['Bestand abgleichen','WWID, USC und Versorgungspläne zuordnen.'],reply:['Antwort vorbereiten','Sprache, Antworttext, Signatur und Pflichtfelder.'],send:['Versand nachweisen','Ein Versandklick ist noch kein bestätigter Ausgang.'],p1save:['Speicherung prüfen','Servernachweis nach Versand und Speichern.'],
 p2scan:['Vorgänge prüfen','Sichtbare eigene Tickets auf Phase-2-Zulassung prüfen.'],rule:['Anfrage einordnen','Dritte Zeile und Fachregel bestimmen den Weg.'],prepare:['Dokumente / Entwurf','Nur bei benötigten Anlagen oder Antwortentwürfen.'],p2save:['Stand nachprüfen','Gespeicherte Beschreibung, GEVO und Entwurf nachlesen.'],assignee:['Mark auswählen','Bearbeiterkonto und erforderliche Freigabe prüfen.'],route:['Weiterleitung prüfen','Einmal intern weiterleiten und Erfolg separat belegen.'],issue:['Klärung / Fehler','Offener Ticketfall oder Unterbrechung.'],end:['Laufabschluss','Abschlussaussage nur aus ausdrücklich gemeldetem Ergebnis.']
};
const routes={P1:['p1scan','person','mapping','reply','send','p1save'],P2:['p2scan','rule','prepare','p2save','assignee','route'],SYSTEM:['start','browser','end']};
const stageSuccess={person:['MEMBER_VERIFIED'],mapping:['MAPPING_VERIFIED'],reply:['REPLY_PREPARED'],send:['SEND_VERIFIED'],p1save:['P1_COMPLETED'],p2save:['P2_SAVE_VERIFIED'],assignee:['ASSIGNEE_VERIFIED'],route:['ROUTE_VERIFIED']};
const nextByStage={start:'Nach der Startfreigabe verbindet sich der Bot mit seiner Sitzung.',browser:'Bei bestätigter Verbindung: die erlaubten Vorgangslisten prüfen.',p1scan:'Wenn ein geeignetes Ticket vorliegt: Originalnachricht und Person prüfen.',person:'Bei eindeutig bestätigter Person: Bestandsdaten zuordnen.',mapping:'Bei passendem Bestand: Antwort in der Sprache der Originalnachricht vorbereiten.',reply:'Wenn Text und Pflichtfelder stimmen: Versandfreigabe und Versandnachweis.',send:'Erst mit Versandnachweis: Status speichern und Serverstand prüfen.',p1save:'Nach bestätigter Speicherung: nächsten geeigneten Phase-1-Fall suchen.',p2scan:'Wenn ein geeigneter Fall vorliegt: Anfrage und Fachregel prüfen.',rule:'Je nach Fachregel: direkt an Mark vorbereiten oder Dokumente und Entwurf prüfen.',prepare:'Nach Dokument- und Entwurfsprüfung: speichern und Serverwerte nachlesen.',p2save:'Bei passendem gespeicherten Stand: Mark als Bearbeiter auswählen.',assignee:'Nach erforderlicher Freigabe: einmal intern weiterleiten und Nachweis prüfen.',route:'Nach bestätigter Weiterleitung: nächsten eigenen Phase-2-Fall prüfen.',issue:'Originalzustand und Nachweis prüfen; keine ungeklärte Schreibaktion wiederholen.',end:'Laufergebnis und offene Fälle ansehen; das Hauptmenü bleibt verfügbar.'};
const state={
 variant:V[Number(params().get('design'))]?Number(params().get('design')):window.PROTOTYPE_DEFAULT||1,
 mode:canLive?'live':'simulation',scenario:'mark',path:['start'],cursor:0,answers:{},speed:1100,playing:false,timer:null,
 live:[],runId:null,keys:new Set(),es:null,connected:false,sourceState:canLive?'connecting':'offline',sourceMessage:canLive?'Verbindung wird aufgebaut':'Kein lokaler Lauf verbunden',lastReceived:null,
 replay:[],replayCursor:0,mask:true,sync:true,showControls:true,selectedStep:null,selectedTicket:null,detail:null,filter:'all',large:false,legacy:false,notice:null,
 client:Math.random().toString(36).slice(2),channel:null,ratings:{},runMissing:false
};
try{state.mask=localStorage.getItem('mcr94proto_mask')!=='false';state.ratings=JSON.parse(localStorage.getItem('mcr94proto_ratings')||'{}');}catch{}
function scenario(){return SC[state.scenario];}
function simNode(){return scenario().nodes[state.path[state.cursor]];}
function simEvents(){return state.path.slice(0,state.cursor+1).map((id,i)=>({schema:'MCR_FLOW_EVENT_V1',runId:'SIM-'+state.scenario,seq:i+1,at:new Date(Date.UTC(2026,10,18,9,0,i*3)).toISOString(),...scenario().nodes[id].event}));}
function visibleEvents(){return state.mode==='simulation'?simEvents():state.mode==='replay'?state.replay.slice(0,state.replayCursor+1):state.live;}
function tmask(id){return id?state.mask?'••••'+String(id).slice(-4):String(id):'Noch kein Ticket';}
function eventStatus(e){
 if(!e)return'idle';if(e.code==='TICKET_DEFERRED')return'deferred';if(e.code==='RUN_RESULT')return e.kind==='good'?'done':'deferred';
 if(e.kind==='bad')return'error';if(e.kind==='wait')return'wait';if(e.kind==='good')return'verified';return'active';
}
function statusLabel(e){const x=eventStatus(e);return({idle:'Bereit',active:'Arbeitet',wait:'Wartet / prüft',verified:'Nachweis gemeldet',error:'Unterbrochen / Klärung',done:'Lauf abgeschlossen',deferred:'Offen dokumentiert'})[x];}
function place(e,history){
 if(!e)return{label:'Noch kein COMARCH-Bereich gemeldet',certainty:'Nicht gemeldet',detail:'Sobald ein Ereignis vorliegt, erscheint sein belegter oder abgeleiteter Arbeitsbereich.'};
 if(e.code==='BROWSER_CLOSED')return{label:'Bot-Edge geschlossen',certainty:'Belegt',detail:'Der Browserabschluss wurde ausdrücklich protokolliert.'};
 if(e.stage==='browser')return{label:e.kind==='bad'||e.code==='BROWSER_CONNECT_RETRY'?'Lokale Browserverbindung':'Eigener Bot-Edge',certainty:'Belegt',detail:'Das Protokoll beschreibt die Browserverbindung. Ein konkreter COMARCH-Reiter wird nicht gemeldet.'};
 const labels={start:'Hauptmenü / Startfreigabe',p1scan:'Eigene Vorgänge / erlaubte Warteschlange',person:'Ticket · Originalnachricht / Personenprüfung',mapping:'Bestandsabgleich',reply:'Ticket · Antwortvorbereitung',send:'Ticket · Versand / Nachrichtenhistorie',p1save:'Ticket · Speicherung / Listenprüfung',p2scan:'Eigene Vorgänge',rule:'Ticket · Anfrage und Beschreibung',prepare:'Ticket · Anlagen / Antwortentwurf',p2save:'Ticket · gespeicherter Bearbeitungsstand',assignee:'Ticket · Bearbeiterzuordnung',route:'Ticket · interne Weiterleitung',end:'Laufbericht / Hauptmenü'};
 if(e.code==='P2_TICKET_BOUND')return{label:'COMARCH · Ticket '+tmask(e.ticket),certainty:'Belegt',detail:'Ticketöffnung bzw. Editorbindung gemeldet. Der genaue aktive Unterbereich ist nicht separat belegt.'};
 if(e.stage==='issue'){
  const prev=[...history].reverse().find(x=>!['issue','end'].includes(x.stage));
  return{label:prev?labels[prev.stage]||'Letzter gemeldeter Bereich':'Kein aktueller Browser-Ort bestätigt',certainty:'Aus Arbeitsschritt abgeleitet',detail:'Letzter Arbeitsbereich vor der Meldung. Ein Fehler beweist keinen neuen Browser-Ort.'};
 }
 return{label:labels[e.stage]||'Kein genauer Bereich gemeldet',certainty:['start','end'].includes(e.stage)?'Belegt':'Aus Arbeitsschritt abgeleitet',detail:['start','end'].includes(e.stage)?'Gemeldeter Programmabschnitt; kein zusätzlicher COMARCH-Reiter.':'Aus dem protokollierten Arbeitsschritt abgeleitet. RC94 meldet nicht jeden Seiten- oder Reiterwechsel.'};
}
function model(){
 const history=visibleEvents(),current=history.at(-1)||null,phase=current?.phase||'SYSTEM';
 const activeTicket=current?.ticket||null;const samePhase=history.filter(e=>e.phase===phase);
 const ticketHistory=activeTicket?samePhase.filter(e=>e.ticket===activeTicket):samePhase.filter(e=>!e.ticket);
 let outcome=null;for(const e of history){if(e.code==='RUN_RESULT')outcome={kind:e.kind,label:e.label};}
 const byTicket=new Map();const doneP1=new Set(),doneP2=new Set(),open=new Set();
 for(const e of history){if(!e.ticket)continue;const key=e.phase+':'+e.ticket;let t=byTicket.get(key)||{id:e.ticket,phase:e.phase,state:'active',statusText:'In Bearbeitung',action:e.label,location:'',proof:null,lastAt:e.at};
  t.action=e.label;t.lastAt=e.at;t.location=place(e,history).label;
  if(e.code==='P1_COMPLETED'){doneP1.add(e.ticket);open.delete(key);t.state='done';t.statusText='Standardantwort + Speicherung bestätigt';t.proof=e.code;}
  else if(e.code==='ROUTE_VERIFIED'){doneP2.add(e.ticket);open.delete(key);t.state='done';t.statusText='Intern weitergeleitet · keine E-Mail';t.proof=e.code;}
  else if(e.code==='TICKET_DEFERRED'){open.add(key);t.state='deferred';t.statusText='Offen / zurückgestellt';}
  else if(t.state!=='done'&&t.state!=='deferred'){t.state=e.kind==='wait'?'wait':e.kind==='bad'?'deferred':'active';t.statusText=e.kind==='wait'?'Wartet / Nachweis offen':e.kind==='bad'?'Klärung erforderlich':'In Bearbeitung';if(e.kind==='bad')open.add(key);}
  byTicket.set(key,t);
 }
 const ticketList=[...byTicket.values()];for(const t of ticketList){if(t.state==='active'&&(t.id!==activeTicket||t.phase!==phase)){t.state='deferred';t.statusText='Kein Abschlussereignis beobachtet';open.add(t.phase+':'+t.id);}}
 let routeIds=[...(routes[phase]||routes.SYSTEM)];
 const direct=ticketHistory.some(e=>['DB_DIRECT','MARK_DIRECT'].includes(e.code));
 if(phase==='P2'&&direct)routeIds=routeIds.filter(s=>s!=='prepare');
 const route=routeIds.map(id=>{
  let es=ticketHistory.filter(e=>e.stage===id);if(id==='p1scan'||id==='p2scan')es=samePhase.filter(e=>e.stage===id);
  const last=es.at(-1);let st=last?'observed':'pending';
  const proven=[...es].reverse().find(e=>(stageSuccess[id]||[]).includes(e.code));if(proven)st='verified';
  if(current?.stage===id)st=current.kind==='bad'?'error':current.kind==='wait'?'wait':proven?'verified':'active';
  const proofIndex=proven?ticketHistory.indexOf(proven):-1;
  const laterIssue=ticketHistory.some((e,i)=>i>proofIndex&&e.kind==='bad'&&(e.stage===id||(e.stage==='issue'&&[...ticketHistory.slice(0,i)].reverse().find(x=>x.stage!=='issue')?.stage===id)));
  if(laterIssue)st='error';
  return{id,label:stageDefs[id]?.[0]||id,detail:stageDefs[id]?.[1]||'',state:st,proof:proven?.label||last?.label||'Noch kein Ereignis für diesen Abschnitt.'};
 });
 const choiceDef=state.mode==='simulation'?simNode()?.choice:null;
 const currentChoice=choiceDef?{...choiceDef,id:state.path[state.cursor]}:null;
 const branchHistory=Object.entries(state.answers).filter(([i])=>Number(i)<=state.cursor).sort((a,b)=>Number(a[0])-Number(b[0])).map(([,a])=>({label:a.question,answer:a.label}));
 let next=nextByStage[current?.stage]||'Ein Ereignis abwarten.';
 if(current?.code==='ROUTE_INTENT')next='Nur den Weiterleitungsnachweis prüfen. Ein zweiter Klick ist nicht freigegeben.';
 if(current?.code==='SEND_INTENT')next='Nur den tatsächlichen Versandnachweis prüfen. Ein zweiter Versand ist nicht freigegeben.';
 if(current?.code==='TICKET_DEFERRED')next='Weitere geeignete Tickets prüfen; dieser Fall bleibt offen im Bericht.';
 if(current?.kind==='bad')next='Klärung im Bot und anhand des gespeicherten Zustands. Diese Ansicht löst keine Wiederholung aus.';
 if(outcome&&current?.stage==='end')next='Ergebnis prüfen. Ein neuer Lauf wird separat im Bot gestartet.';
 const afterClose=current?.code==='BROWSER_CLOSED'&&outcome;
 return{mode:state.mode,phase,phaseTitle:phases[phase]||phase,current,history,actionLabel:afterClose?(outcome.kind==='good'?'Lauf abgeschlossen · Bot-Edge geschlossen':'Lauf beendet mit offenen Fällen · Bot-Edge geschlossen'):current?.label||'Warte auf den nächsten beobachteten Lauf',status:afterClose?(outcome.kind==='good'?'done':'deferred'):eventStatus(current),statusLabel:afterClose?(outcome.kind==='good'?'Lauf abgeschlossen':'Beendet · offene Fälle'):statusLabel(current),ticket:activeTicket,ticketLabel:tmask(activeTicket),place:place(current,history),next,reason:current?explain(current):'Der Kartenmonitor ist bereit. Der Bot wird weiterhin im Terminal gestartet.',route,
 phases:[{id:'P1',label:'Phase 1',sub:'Standardantwort',state:phase==='P1'?'current':history.some(e=>e.phase==='P1')?'observed':'pending'},{id:'P2',label:'Phase 2',sub:'Bearbeiten / Weiterleiten',state:phase==='P2'?'current':history.some(e=>e.phase==='P2')?'observed':'pending'},{id:'P3',label:'Phase 3',sub:'LenX + Review · geplant',state:'planned'}],
 tickets:ticketList,counts:{p1:doneP1.size,p2:doneP2.size,open:open.size,seen:new Set(ticketList.map(t=>t.id)).size},outcome,choice:currentChoice,selectedStep:state.selectedStep,selectedTicket:state.selectedTicket,filter:state.filter,branchHistory,cursor:state.cursor,total:state.path.length};
}
function explain(e){
 const map={REQUEST_REVIEW:'Die Anfrage passt zu keiner bekannten Formel. Die fachliche Einordnung muss vom Menschen kommen.',ACTION_APPROVAL:e.phase==='P2'?'Die interne Weiterleitung braucht die aktuell vorgesehene Schrittfreigabe.':'Die Standardantwort wartet auf die vorgesehene Versandfreigabe.',SEND_INTENT:'Ein Versand wurde ausgelöst. Erst eine passende neue Ausgangsnachricht bestätigt das Ergebnis.',SEND_VERIFIED:'Das Versandereignis belegt eine passende Ausgangsnachricht. Die Speicherung wird separat geprüft.',P1_COMPLETED:'Beide Nachweise sind gemeldet: Standardantwort versendet und Ticket gespeichert. Das sagt noch nichts über weitere Tickets aus.',PILOT_VERIFIED:'Der nachgewiesene Pilot erlaubt den nächsten Teillauf. Der gesamte Master Run ist damit noch nicht beendet.',ROUTE_INTENT:'Die Weiterleitung wurde ausgelöst. Ein Auftrag oder Klick ist noch kein Ergebnisnachweis.',ROUTE_VERIFIED:'Die interne Weiterleitung ist bestätigt. Daraus folgt keine Kunden-E-Mail und keine abgeschlossene fachliche Phase-3-Prüfung.',TICKET_DEFERRED:'Dieser Fall bleibt offen. Sofern der Bot es freigibt, kann er andere Fälle weiter prüfen.',P2_TICKET_BOUND:'Die Bindung an das richtige Ticket wurde gemeldet. Ein genauer aktiver Browser-Reiter wird nicht separat übertragen.',ASSIGNEE_VERIFIED:'Das exakte Bearbeiterkonto ist bestätigt. Die Weiterleitung selbst folgt mit eigenem Nachweis.',REVIEW_REQUIRED:'Eine Prüfung lieferte keinen eindeutigen Erfolg. Die Karte zeigt deshalb keinen grünen Abschluss.',BROWSER_CONNECT_FAILED:'Die lokale Browserverbindung fehlt. Bereits bestätigte Ticketabschlüsse bleiben erhalten.',RUN_RESULT:'Dies ist die ausdrücklich gemeldete Zusammenfassung des geprüften Bereichs. Unsichtbare Listen sind nicht eingeschlossen.',DIRECT_UNCHANGED:'Beim Direktfall bleibt die Beschreibung unverändert. Es wird kein neuer Bearbeitet-Vermerk angenommen.',LANGUAGE_VERIFIED:'Die Sprachwahl wurde für die Originalnachricht gemeldet; DE und EN sind separate Simulationszweige.',SIM_LANGUAGE_CHOICE:'Hier kannst du für den Vergleich dieselbe Situation auf Deutsch oder Englisch durchspielen.'};
 return map[e.code]||stageDefs[e.stage]?.[1]||'Zu diesem Ereignis liegt nur der protokollierte Klartext vor.';
}
const helpers={e:esc,ticket:tmask,time:at=>{const d=new Date(at);return Number.isNaN(d.getTime())?'—':d.toLocaleTimeString('de-DE',{timeZone:'Europe/Berlin',hour:'2-digit',minute:'2-digit',second:'2-digit'});},
 badge:(label,t='neutral')=>`<span class="px-badge ${esc(tone(t))}">${esc(label)}</span>`,
 icon:s=>({verified:'✓',done:'✓',observed:'·',active:'●',wait:'!',error:'!',pending:'○',deferred:'!'}[s]||'○'),
 steps:(items,{compact=false}={})=>`<ol class="px-steps${compact?' compact':''}">${items.map((s,i)=>`<li class="px-step ${esc(s.state)} ${s.state==='verified'&&items[i+1]?.state==='verified'?'connected':''}"><span class="px-step-dot">${helpers.icon(s.state)}</span><button data-action="select-step" data-step="${esc(s.id)}"><b>${esc(s.label)}</b><small>${esc(({verified:'Bestätigt',observed:'Gemeldet',active:'Aktuell',wait:'Nachweis / Freigabe offen',error:'Klärung',pending:'Noch nicht belegt'})[s.state])}</small></button></li>`).join('')}</ol>`,
 timeline:(evs,limit=4)=>`<div class="px-timeline">${evs.slice(-limit).reverse().map(e=>`<div class="px-timeline-item"><time>${esc(helpers.time(e.at))}</time><div><strong>${esc(e.label)}</strong><code>${esc(e.code)}</code></div></div>`).join('')||'<p class="px-muted">Noch keine Ereignisse.</p>'}</div>`,
 phaseRail:vm=>`<div class="px-phase-rail">${vm.phases.map((p,i)=>`<div class="px-phase ${p.state}"><span class="px-phase-dot">${i+1}</span><div><b>${esc(p.label)}</b><small>${esc(p.sub)}</small></div></div>`).join('')}</div>`,
 choice:vm=>vm.mode==='simulation'&&vm.choice?`<section class="px-choice-box"><span class="px-overline">Deine Entscheidung · nur Simulation</span><h3>${esc(vm.choice.question)}</h3><div class="px-choice-actions">${vm.choice.options.map(o=>`<button data-action="choose" data-choice="${esc(o.id)}"><b>${esc(o.label)}</b><small>${esc(o.detail)}</small></button>`).join('')}</div></section>`:vm.mode==='live'&&vm.status==='wait'?'<div class="px-choice-box"><b>Freigabe oder Nachweis im Bot abwarten.</b><p class="px-small">Diese Karte beobachtet nur. Sie erteilt keine Freigabe.</p></div>':''
};
const root=document.createElement('div');root.id='prototypeRoot';document.body.append(root);
const style=document.createElement('style');style.textContent=Object.values(V).map(v=>v.css).join('\n');document.head.append(style);
function sourceLabel(){
 if(state.mode==='simulation')return['simulation','Simulation · fiktive Beispieldaten'];
 if(state.mode==='replay')return['simulation','Wiedergabe · kein Live-Stand'];
 if(!canLive)return['','Keine Live-Verbindung · START_TEST.cmd verwenden'];
 return[state.connected&&state.sourceState==='ready'?'online':state.sourceState==='waiting'?'':'error',state.sourceMessage];
}
function render(){
 if(state.legacy)return;const vm=model(),v=V[state.variant],[sourceTone,sourceText]=sourceLabel();
 document.title=`RC94 · ${String(state.variant).padStart(2,'0')} ${v.name} · Prototyp`;
 root.classList.toggle('px-large-type',state.large);root.dataset.variant=String(state.variant);
 const outcome=vm.outcome?`<div class="px-banner ${vm.outcome.kind==='good'?'':vm.outcome.kind==='bad'?'bad':'wait'}"><strong>${vm.outcome.kind==='good'?'✓':'!'} ${esc(vm.outcome.label)}</strong><span class="px-small">Gemeldeter geprüfter Bereich</span></div>`:'';
 const notice=state.notice?`<div class="px-banner neutral">${esc(state.notice)}<button class="px-button-link" data-action="dismiss">Schließen</button></div>`:'';
 root.innerHTML=`<header class="px-top"><div class="px-brand"><div class="px-monogram">mcr</div><div><span class="px-overline">RC94 · Prototyp ${String(state.variant).padStart(2,'0')} von 05</span><h1>${esc(v.name)}</h1><div class="px-title-sub">${esc(v.tagline)}</div></div></div><div class="px-top-actions"><label for="pxDesign">Ansicht</label><select id="pxDesign" aria-label="Prototyp wechseln">${Object.keys(V).map(id=>`<option value="${id}" ${Number(id)===state.variant?'selected':''}>${id} · ${esc(V[id].name)}</option>`).join('')}</select><button data-action="toggle-size" aria-pressed="${state.large}" title="Größere Schrift">A<span class="px-secondary-label">a</span>+</button><button data-action="original">Originalkarte ↗</button></div></header>
 <div class="px-sourcebar"><div class="px-mode-switch" aria-label="Datenquelle"><button data-action="mode" data-mode="simulation" aria-pressed="${state.mode==='simulation'}">Simulation</button><button data-action="mode" data-mode="live" aria-pressed="${state.mode==='live'}">Live</button><button data-action="mode" data-mode="replay" aria-pressed="${state.mode==='replay'}">Wiedergabe</button></div><div class="px-source-info"><i class="px-connection-dot ${sourceTone}"></i><strong>${esc(sourceText)}</strong></div><span class="px-time-stamp">${vm.current?'Letztes Ereignis '+esc(helpers.time(vm.current.at)):'Noch kein Ereignis'}</span><button class="px-button-link" data-action="show-details">Belege</button><button class="px-button-link" data-action="toggle-controls">${state.showControls?'Bedienung ausblenden':'Bedienung einblenden'}</button></div>
 <main class="px-main">${notice}${outcome}<div id="pxView" class="px-new-step">${v.render(vm,helpers)}</div>${detailHTML(vm)}</main>
 ${state.showControls?controlsHTML(vm):''}
 <footer class="px-footer"><div class="px-legend"><span class="px-dot-label good"><i></i>Nachweis</span><span class="px-dot-label wait"><i></i>Wartet / prüft</span><span class="px-dot-label error"><i></i>Klärung / Stop</span><span class="px-dot-label"><i></i>Noch nicht belegt</span></div><span>Phase 3 geplant · RC94 nur beobachten</span><button class="px-button-link" data-action="feedback">Variante bewerten</button></footer>`;
 bindControls();
}
function controlsHTML(vm){
 const sim=state.mode==='simulation',live=state.mode==='live',cur=sim?state.cursor:state.replayCursor,len=sim?state.path.length:state.replay.length;
 const currentNode=sim?simNode():null;const terminal=sim&&!currentNode?.choice&&!currentNode?.next;
 if(live)return`<section class="px-sim-controls"><div class="px-transport-main"><div class="px-progress-meta"><strong>${state.connected?'Kartenverbindung aktiv':'Keine aktive Kartenverbindung'}</strong>${state.live.length} protokollierte Ereignisse</div><p class="px-small px-muted" style="flex:1">${state.live.at(-1)?.replayed?'Vorhandener Lauf nachgeladen. ':''}Die Anzeige folgt sofort dem jüngsten Ereignis; Animationen halten den Bot nicht auf.</p><button data-action="reconnect">Neu verbinden</button><button data-action="load-file">Ereignisdatei laden</button><input type="file" id="pxFileInput" hidden accept=".jsonl,.json,.txt"></div></section>`;
 return`<section class="px-sim-controls"><div class="px-transport-main"><div class="px-scenario-field"><label for="pxScenario">${sim?'Gleiches Szenario in allen fünf Ansichten':'Historischer Ablauf'}</label>${sim?`<select id="pxScenario">${Object.entries(SC).map(([id,s])=>`<option value="${id}" ${id===state.scenario?'selected':''}>${esc(s.title)}</option>`).join('')}</select>`:`<button data-action="load-file">Ereignisdatei laden</button>`}</div><div class="px-transport-buttons"><button data-action="restart" title="Zum Beginn">↺ Anfang</button><button data-action="back" ${cur===0?'disabled':''}>← Zurück</button>${sim?`<button data-action="back-decision" ${!Object.keys(state.answers).some(i=>Number(i)<state.cursor)?'disabled':''}>Letzte Entscheidung</button>`:''}<button class="px-primary" data-action="play" ${terminal||(!sim&&!len)?'disabled':''}>${state.playing?'Ⅱ Pause':'▶ Abspielen'}</button><button data-action="next" ${terminal||(!sim&&cur>=len-1)?'disabled':''}>Weiter →</button></div><div class="px-progress-meta"><strong>${len?'Ereignis '+(cur+1):'Keine Ereignisse'}${sim?'':' / '+len}</strong>${sim&&vm.choice?'Entscheidung auswählen':terminal?'Szenario beendet':sim?'Fiktiver Ablauf':'Historischer Stand'}</div></div><div class="px-sim-sub"><input id="pxSeek" type="range" aria-label="Im beobachteten Verlauf zurückgehen" min="0" max="${Math.max(0,len-1)}" value="${cur}" ${len<2?'disabled':''}><label>Tempo <select id="pxSpeed"><option value="1700" ${state.speed===1700?'selected':''}>Ruhig</option><option value="1100" ${state.speed===1100?'selected':''}>Normal</option><option value="450" ${state.speed===450?'selected':''}>Schnell</option></select></label>${sim?`<label><input type="checkbox" id="pxSync" ${state.sync?'checked':''}>Testfenster synchronisieren</label>`:''}<label><input type="checkbox" id="pxMask" ${state.mask?'checked':''}>IDs maskieren</label><button class="px-button-link" data-action="load-file">Datei laden</button><input type="file" id="pxFileInput" hidden accept=".jsonl,.json,.txt"></div></section>`;
}
function detailHTML(vm){
 if(!state.detail)return'';let title='Belege und Herkunft',content='';
 if(state.detail==='step'){
  const s=vm.route.find(s=>s.id===state.selectedStep);title=s?.label||'Schritt';content=`<p>${esc(s?.detail||'Dieser Schritt gehört zur vorherigen Phase.')}</p><p><strong>Beobachtung:</strong> ${esc(s?.proof||'Kein Nachweis im sichtbaren Verlauf.')}</p><p class="px-small px-muted">Eine graue Station ist kein Fehler. Sie kann noch bevorstehen, in diesem Weg entfallen oder im Protokoll nicht separat erfasst sein.</p>`;
 }else if(state.detail==='ticket'){
  const xs=vm.history.filter(e=>e.ticket===state.selectedTicket);title='Verlauf · '+tmask(state.selectedTicket);content=helpers.timeline(xs,30);
 }else if(state.detail==='feedback'){
  title='Dein Urteil · '+V[state.variant].name;const r=state.ratings[state.variant]||{};
  content=`<div class="px-details-form"><label>Lesbarkeit<select id="pxRateRead">${ratingOptions(r.read)}</select></label><label>Orientierung<select id="pxRateOrientation">${ratingOptions(r.orientation)}</select></label><label>Gesamtgefühl<select id="pxRateFeel">${ratingOptions(r.feel)}</select></label><label style="grid-column:1/-1">Was passt oder stört?<textarea id="pxRateNote" placeholder="Zum Beispiel: Ort sofort klar, aber nächste Phase zu klein …">${esc(r.note||'')}</textarea></label></div><div style="display:flex;gap:8px;margin-top:12px;flex-wrap:wrap"><button data-action="save-feedback" class="px-primary">Bewertung merken</button><button data-action="export-feedback">Alle Bewertungen exportieren</button></div><p class="px-small px-muted" style="margin-top:10px">Nur in diesem Browser gespeichert. Der Export enthält deine Bewertungen, keine Ticketdaten.</p>`;
 }else{
  content=`<div class="px-grid-two"><div><p><strong>Quelle:</strong> ${esc(state.mode==='simulation'?'Synthetisches Szenario; keine COMARCH-Ausführung':state.mode==='replay'?'Historische Ereignisse; kein Live-Stand':'Lokale RC94-Ereignisspur; nur lesen')}</p><p><strong>Browser-Ort:</strong> ${esc(vm.place.certainty)}</p><p>${esc(vm.place.detail)}</p><p style="margin-top:12px">${esc(vm.reason)}</p>${vm.current?`<code>${esc(vm.current.code)}\n${esc(vm.current.phase)} · #${vm.current.seq} · ${esc(vm.current.at)}</code>`:''}</div><div>${helpers.timeline(vm.history,8)}</div></div>`;
 }
 return`<section class="px-detail-area" id="pxDetail"><div class="px-detail-head"><h3>${esc(title)}</h3><button data-action="close-details" class="px-button-link">Schließen ×</button></div><div class="px-detail-content">${content}</div></section>`;
}
function ratingOptions(n){return'<option value="">Noch offen</option>'+[1,2,3,4,5].map(x=>`<option value="${x}" ${Number(n)===x?'selected':''}>${x} / 5${x===1?' · passt nicht':x===5?' · passt sehr gut':''}</option>`).join('');}
function stop(){state.playing=false;clearTimeout(state.timer);state.timer=null;}
function broadcast(){if(!state.sync||state.mode!=='simulation')return;const data={schema:'MCR_PROTO_SYNC_V1',sender:state.client,scenario:state.scenario,path:state.path,cursor:state.cursor,answers:state.answers};try{state.channel?.postMessage(data);localStorage.setItem('mcr94proto_sync',JSON.stringify({...data,at:Date.now()}));}catch{}}
function acceptSync(d){if(!state.sync||state.mode!=='simulation'||!d||d.schema!=='MCR_PROTO_SYNC_V1'||d.sender===state.client||!SC[d.scenario]||!Array.isArray(d.path)||d.path.length>2000||!Number.isInteger(d.cursor)||d.cursor<0||d.cursor>=d.path.length||!d.path.every(id=>SC[d.scenario].nodes[id]))return;stop();state.scenario=d.scenario;state.path=d.path;state.cursor=d.cursor;state.answers=d.answers&&typeof d.answers==='object'?d.answers:{};state.detail=null;render();}
try{state.channel=new BroadcastChannel('mcr94-prototypes');state.channel.onmessage=e=>acceptSync(e.data);}catch{}
window.addEventListener('storage',e=>{if(e.key==='mcr94proto_sync')try{acceptSync(JSON.parse(e.newValue));}catch{}});
function loadScenario(id){if(!SC[id])return;stop();state.scenario=id;state.path=[SC[id].start];state.cursor=0;state.answers={};state.selectedStep=null;state.selectedTicket=null;state.detail=null;render();broadcast();}
function next({auto=false}={}){
 if(state.mode==='live')return false;
 if(state.mode==='replay'){if(state.replayCursor>=state.replay.length-1){stop();render();return false;}state.replayCursor++;render();return true;}
 const node=simNode();
 if(state.cursor<state.path.length-1){state.cursor++;render();broadcast();return true;}
 if(node.choice){stop();render();return false;}
 let target=node.next;
 if(state.scenario==='menu'&&state.path[state.cursor]==='p1_empty'){
  const menuAnswer=Object.entries(state.answers).sort((a,b)=>Number(b[0])-Number(a[0])).map(([,a])=>a).find(a=>a.node==='menu');if(menuAnswer?.option==='3')target='menu';
 }
 if(!target||!scenario().nodes[target]){stop();render();return false;}
 state.path.push(target);state.cursor++;render();broadcast();return true;
}
function choose(id){if(state.mode!=='simulation')return;const c=simNode()?.choice;const option=c?.options.find(o=>o.id===id);if(!option)return;
 stop();state.path=state.path.slice(0,state.cursor+1);for(const k of Object.keys(state.answers)){if(Number(k)>=state.cursor)delete state.answers[k];}
 state.answers[state.cursor]={node:state.path[state.cursor],option:id,label:option.label,question:c.question};state.path.push(option.next);state.cursor++;state.detail=null;render();broadcast();
}
function autoplay(){if(state.mode==='live')return;state.playing=true;render();const tick=()=>{if(!state.playing)return;if(!next({auto:true}))return;if(state.mode==='simulation'&&simNode()?.choice){stop();render();return;}state.timer=setTimeout(tick,state.speed);};state.timer=setTimeout(tick,state.speed);}
function changeMode(mode){stop();if(mode==='replay'){
  if(state.mode==='live')state.replay=[...state.live];else if(state.mode==='simulation')state.replay=simEvents();state.replayCursor=Math.max(0,state.replay.length-1);
 }state.mode=mode;state.detail=null;state.notice=null;if(mode==='live'&&!canLive)state.notice='Für den echten Lauf: START_TEST.cmd aus dem entpackten Prototyp-Paket öffnen und deinen bestehenden RC94-Ordner wählen. Diese einzeln geöffnete HTML-Datei bleibt offline.';render();}
function ingest(e){
 if(!e||e.schema!=='MCR_FLOW_EVENT_V1'||typeof e.runId!=='string'||e.runId.length>150||!Number.isSafeInteger(e.seq)||e.seq<1||typeof e.label!=='string'||e.label.length>1000||typeof e.code!=='string'||e.code.length>100||!stageDefs[e.stage]||!['P1','P2','SYSTEM'].includes(e.phase)||Number.isNaN(Date.parse(e.at)))return false;
 if(e.ticket!==null&&e.ticket!==undefined&&(typeof e.ticket!=='string'||e.ticket.length>40))return false;
 if(state.runId!==e.runId){state.live=[];state.keys.clear();state.runId=e.runId;state.selectedTicket=null;state.selectedStep=null;}
 const key=e.runId+':'+e.seq;if(state.keys.has(key))return false;state.keys.add(key);state.live.push({...e});state.live.sort((a,b)=>a.seq-b.seq);if(state.live.length>3000)state.live.splice(0,state.live.length-3000);state.lastReceived=Date.now();state.runMissing=false;
 try{window.MCR94?.ingest(e);}catch{}
 if(state.mode==='live')render();return true;
}
function resetLive(data){state.live=[];state.keys.clear();state.runId=data?.runId||null;state.selectedTicket=null;state.selectedStep=null;state.runMissing=true;if(state.mode==='live')render();}
function connect(){
 if(!canLive){state.connected=false;state.sourceState='offline';state.sourceMessage='Keine Live-Verbindung · START_TEST.cmd verwenden';render();return;}
 state.es?.close();state.connected=false;state.sourceMessage='Lokaler Kartenmonitor wird verbunden …';
 const es=new EventSource('/api/events?token='+encodeURIComponent(token));state.es=es;
 es.addEventListener('hello',m=>{try{const d=JSON.parse(m.data);if(d.readOnly!==true){state.sourceMessage='Unbekannter Monitor · Verbindung beendet';es.close();state.connected=false;render();return;}state.connected=true;state.sourceMessage=d.source?.message||'Live verbunden · letzter gemeldeter RC94-Stand';state.sourceState=d.sourceState||'ready';render();}catch{state.sourceMessage='Monitorantwort nicht lesbar';render();}});
 es.addEventListener('flow',m=>{try{const ok=ingest(JSON.parse(m.data));if(ok&&state.sourceState==='ready')state.sourceMessage='Live verbunden · letzter gemeldeter RC94-Stand';}catch{state.notice='Ein ungültiges Ereignis wurde nicht dargestellt.';render();}});
 es.addEventListener('source',m=>{try{const d=JSON.parse(m.data);state.sourceState=d.state;state.sourceMessage=d.message||'Kartenmonitor verbunden';if(state.mode==='live')render();}catch{}});
 es.addEventListener('reset',m=>{try{resetLive(JSON.parse(m.data));}catch{resetLive({});}});
 es.onerror=()=>{state.connected=false;state.sourceMessage='Verbindung unterbrochen · verbindet automatisch neu';state.sourceState='error';if(state.mode==='live')render();};
 render();
}
function showOriginal(){stop();state.legacy=true;root.hidden=true;$('legacyRoot').hidden=false;$('pxLegacyBack').hidden=false;document.body.classList.remove('proto-active');try{window.MCR94?.leave();window.MCRUpgrade?.setView('diagram');window.MCRLab?.setDiagram(0);setTimeout(()=>{try{fitGraph();}catch{}},60);}catch{}}
function hideOriginal(){state.legacy=false;root.hidden=false;$('legacyRoot').hidden=true;$('pxLegacyBack').hidden=true;document.body.classList.add('proto-active');render();}
function saveFeedback(){const r={read:$('pxRateRead')?.value||'',orientation:$('pxRateOrientation')?.value||'',feel:$('pxRateFeel')?.value||'',note:$('pxRateNote')?.value||'',name:V[state.variant].name};state.ratings[state.variant]=r;try{localStorage.setItem('mcr94proto_ratings',JSON.stringify(state.ratings));}catch{}return r;}
function exportFeedback(){if(state.detail==='feedback')saveFeedback();const data={schema:'MCR_RC94_DESIGN_FEEDBACK_V1',at:new Date().toISOString(),variants:state.ratings};download(JSON.stringify(data,null,2),'RC94_Design_Bewertung.json','application/json');}
function download(data,name,type){const u=URL.createObjectURL(new Blob([data],{type}));const a=document.createElement('a');a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);}
async function readFile(file){if(!file)return;stop();if(file.size>16*1024*1024){state.notice='Die Ereignisdatei ist zu groß (maximal 16 MB).';render();return;}
 try{const text=await file.text();let items;try{const j=JSON.parse(text);items=Array.isArray(j)?j:Array.isArray(j.events)?j.events:[j];}catch{items=text.split(/\r?\n/).filter(Boolean).map(line=>{try{return JSON.parse(line);}catch{return null;}}).filter(Boolean);}
  items=items.filter(e=>e?.schema==='MCR_FLOW_EVENT_V1'&&typeof e.label==='string'&&stageDefs[e.stage]&&['P1','P2','SYSTEM'].includes(e.phase)&&typeof e.runId==='string'&&Number.isInteger(e.seq)&&!Number.isNaN(Date.parse(e.at)));
  if(!items.length)throw Error('Keine RC94-Präsentationsereignisse enthalten. Wähle .runtime/flow-map/events.jsonl. Für alte Textlogs verwende die Originalkarte.');
  const run=items.at(-1).runId;const keys=new Set();state.replay=items.filter(e=>e.runId===run).sort((a,b)=>a.seq-b.seq).filter(e=>{const k=e.runId+':'+e.seq;if(keys.has(k))return false;keys.add(k);return true;}).slice(-3000);
  state.replayCursor=0;state.mode='replay';state.detail=null;state.notice='Ereignisdatei geladen · letzter enthaltener Lauf · historische Wiedergabe.';render();
 }catch(e){state.notice='Datei konnte nicht gelesen werden: '+e.message;render();}
}
function bindControls(){
 const design=$('pxDesign');if(design)design.onchange=()=>{state.variant=Number(design.value);state.selectedStep=null;state.detail=null;const ps=params();ps.set('design',String(state.variant));try{history.replaceState(null,'','#'+ps.toString());}catch{}render();root.scrollTop=0;};
 if($('pxScenario'))$('pxScenario').onchange=e=>loadScenario(e.target.value);
 if($('pxSpeed'))$('pxSpeed').onchange=e=>{state.speed=Number(e.target.value);};
 if($('pxSync'))$('pxSync').onchange=e=>{state.sync=e.target.checked;if(state.sync)broadcast();};
 if($('pxMask'))$('pxMask').onchange=e=>{state.mask=e.target.checked;try{localStorage.setItem('mcr94proto_mask',String(state.mask));}catch{}render();};
 if($('pxSeek'))$('pxSeek').oninput=e=>{stop();if(state.mode==='simulation')state.cursor=Number(e.target.value);else state.replayCursor=Number(e.target.value);render();broadcast();};
 if($('pxFileInput'))$('pxFileInput').onchange=e=>readFile(e.target.files[0]);
 for(const id of ['pxRateRead','pxRateOrientation','pxRateFeel','pxRateNote'])if($(id))$(id).oninput=()=>saveFeedback();
}
root.addEventListener('click',e=>{
 const b=e.target.closest('[data-action]');if(!b||b.disabled)return;const a=b.dataset.action;
 if(a==='choose')return choose(b.dataset.choice);
 if(a==='next'){stop();return next();}
 if(a==='play'){if(state.playing){stop();render();}else autoplay();return;}
 if(a==='back'){stop();if(state.mode==='simulation')state.cursor=Math.max(0,state.cursor-1);else if(state.mode==='replay')state.replayCursor=Math.max(0,state.replayCursor-1);render();broadcast();return;}
 if(a==='back-decision'){stop();const ks=Object.keys(state.answers).map(Number).filter(n=>n<state.cursor);if(ks.length)state.cursor=Math.max(...ks);render();broadcast();return;}
 if(a==='restart'){if(state.mode==='simulation')loadScenario(state.scenario);else{stop();state.replayCursor=0;render();}return;}
 if(a==='mode')return changeMode(b.dataset.mode);
 if(a==='reconnect')return connect();
 if(a==='load-file'){$('pxFileInput')?.click();return;}
 if(a==='original')return showOriginal();
 if(a==='toggle-controls')state.showControls=!state.showControls;
 else if(a==='toggle-size')state.large=!state.large;
 else if(a==='show-details')state.detail='evidence';
 else if(a==='close-details')state.detail=null;
 else if(a==='select-step'){state.selectedStep=b.dataset.step;state.detail='step';}
 else if(a==='select-ticket'){state.selectedTicket=b.dataset.ticket;state.detail='ticket';}
 else if(a==='set-filter'){state.filter=b.dataset.filter;}
 else if(a==='feedback'){state.detail='feedback';}
 else if(a==='save-feedback'){saveFeedback();state.notice='Bewertung für '+V[state.variant].name+' gespeichert.';}
 else if(a==='export-feedback'){exportFeedback();return;}
 else if(a==='dismiss')state.notice=null;
 render();if(['show-details','select-step','select-ticket','feedback'].includes(a))$('pxDetail')?.scrollIntoView({block:'nearest',behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});
});
document.addEventListener('keydown',e=>{
 if(state.legacy||/INPUT|TEXTAREA|SELECT|BUTTON/.test(e.target.tagName)||e.altKey||e.ctrlKey||e.metaKey)return;
 if(e.key==='ArrowRight'){e.preventDefault();stop();next();}else if(e.key==='ArrowLeft'&&state.mode!=='live'){e.preventDefault();stop();if(state.mode==='simulation')state.cursor=Math.max(0,state.cursor-1);else state.replayCursor=Math.max(0,state.replayCursor-1);render();broadcast();}
});
$('pxBackToProto').onclick=hideOriginal;
window.addEventListener('beforeunload',()=>{state.es?.close();state.channel?.close();stop();});
window.MCRPrototype={state,model,ingest,resetLive,loadScenario,next,choose,changeMode,render,connect,showOriginal,hideOriginal,readFile,scenarios:SC};
document.body.classList.add('proto-active');render();if(canLive)connect();
})();
