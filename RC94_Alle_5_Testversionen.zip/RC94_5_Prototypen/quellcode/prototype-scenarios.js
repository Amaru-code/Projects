/* Deterministic presentation scenarios. No ticket or browser operations. */
window.ProtoScenarios=(()=>{
 'use strict';
 const E=(code,stage,label,phase='P1',kind='info',ticket=null,extra={})=>({code,stage,label,phase,kind,ticket,...extra});
 const N=(event,next,choice)=>({event,next,choice});
 const choice=(question,options)=>({question,options:options.map(([id,label,detail,next])=>({id,label,detail,next}))});
 const start=(mode)=>E('RUN_START','start',mode==='P2'?'Phase 2 ausgewählt · Startfreigabe ausstehend':'Phase 1 ausgewählt · Startfreigabe ausstehend',mode);
 function p1Nodes({end='empty',prefix='',ticket='90000001'}={}){
  const nodes={};const add=(id,e,next,c)=>nodes[prefix+id]=N(e,next?prefix+next:null,c?{...c,options:c.options.map(o=>({...o,next:prefix+o.next}))}:undefined);
  add('browser',E('P1_BROWSER_REUSE','browser','Phase 1 nutzt den gemeinsamen Bot-Edge'),'scan');
  add('scan',E('P1_RUN','p1scan','Eigene Vorgänge und erlaubte Warteschlange prüfen'),'ticket');
  add('ticket',E('P1_TICKET','p1scan','Ein geeignetes Phase-1-Ticket ausgewählt','P1','info',ticket),'read');
  add('read',E('NAME_DISCOVERY','person','Originalnachricht und Namenshinweise prüfen','P1','info',ticket),'identity');
  add('identity',E('MEMBER_VERIFIED','person','Member-ID und COMARCH-Name sind bestätigt','P1','good',ticket),'mapping');
  add('mapping',E('MAPPING_VERIFIED','mapping','WWID, USC und Versorgungspläne abgeglichen','P1','good',ticket),'language');
  add('language',E('SIM_LANGUAGE_CHOICE','reply','Welche Sprache hat die erste Member-Nachricht?','P1','wait',ticket),null,choice('Sprache der Originalnachricht simulieren',[
   ['de','Deutsch','Deutsche Standardantwort vorbereiten.','de'],['en','English','Englische Standardantwort vorbereiten.','en']
  ]));
  add('de',E('LANGUAGE_VERIFIED','reply','Deutsche Antwort auf die Originalnachricht','P1','good',ticket),'reply');
  add('en',E('LANGUAGE_VERIFIED','reply','Englische Antwort auf die Originalnachricht','P1','good',ticket),'reply');
  add('reply',E('REPLY_PREPARED','reply','Antwort, INTL01-Signatur und Pflichtfelder vorbereitet','P1','good',ticket),'approval');
  add('approval',E('ACTION_APPROVAL','send','Warten auf die einmalige Versandfreigabe','P1','wait',ticket),null,choice('Versandfreigabe im Simulator',[
   ['approve','Freigabe simulieren','Genau einen Versand und anschließend den Nachweis zeigen.','send'],['stop','Lauf stoppen','Es folgt kein simuliertes Senden.','stop']
  ]));
  add('send',E('SEND_INTENT','send','Versand einmal ausgelöst · Nachweis noch offen','P1','wait',ticket),'proof');
  add('proof',E('SEND_VERIFIED','send','Neue ausgehende Standardantwort im Ticket bestätigt','P1','good',ticket),'save');
  add('save',E('P1_SAVE_INTENT','p1save','Status und Beschreibung speichern und nachprüfen','P1','info',ticket),'done');
  add('done',E('P1_COMPLETED','p1save','Versand und Speicherung dieses Tickets bestätigt','P1','good',ticket),'pilot');
  add('pilot',E('PILOT_VERIFIED','p1save','Pilot erfolgreich · nächster Phase-1-Teillauf freigegeben','P1','good',ticket),end);
  add('stop',E('SIM_ABORT','issue','Simulation: Lauf vor dem Versand gestoppt','P1','bad',ticket));
  return nodes;
 }
 function p2Nodes({rule='MARK_DIRECT',prefix='',ticket='90000002',unknown=false,end='finish'}={}){
  const nodes={};const add=(id,e,next,c)=>nodes[prefix+id]=N(e,next?prefix+next:null,c?{...c,options:c.options.map(o=>({...o,next:prefix+o.next}))}:undefined);
  add('start',start('P2'),'scan');
  add('scan',E('P2_RUN','p2scan','Sichtbare eigene Vorgänge auf Phase-2-Fälle prüfen','P2'),'rule');
  add('rule',E(rule,'rule',rule==='DB_DIRECT'?'DB / DB+ erkannt · direkter Weg an Mark':rule==='ACCOUNT_STATEMENT'?'Kontoauszug erkannt · Dokumente und Entwurf nötig':rule==='MBC_PRIVATE_EMAIL'?'Privater MBC-Login · Entwurf zur Prüfung':'Anfrage zur internen Weiterleitung erkannt','P2','info',ticket),'bound');
  add('bound',E('P2_TICKET_BOUND','rule','Richtiges Phase-2-Ticket geöffnet und gebunden','P2','good',ticket),unknown?'request':rule==='ACCOUNT_STATEMENT'?'pdfwait':rule==='MBC_PRIVATE_EMAIL'?'draft':'direct');
  add('request',E('REQUEST_REVIEW','rule','Dritte Zeile enthält keine bekannte Anfrageformel','P2','wait',ticket),null,choice('Was soll mit der unbekannten Anfrage passieren?',[
   ['mark','An Mark','Nur intern weiterleiten. Keine Kunden-E-Mail.','direct'],['skip','Offen lassen','Dieses Ticket zurückstellen; weitere Fälle prüfen.','defer'],['abort','Lauf stoppen','Gesamten simulierten Lauf anhalten.','stop']
  ]));
  add('pdfwait',E('PDF_REQUIRED','prepare','Fehlende Kontoauszüge müssen erstellt werden','P2','wait',ticket),null,choice('Dokumentprüfung simulieren',[
   ['pdf_ok','PDFs geprüft','Identität und benötigte Pläne passen.','pdf'],['pdf_missing','PDFs fehlen','Ticket zur Klärung offen lassen.','defer']
  ]));
  add('pdf',E('PDF_PREPARE','prepare','Kontoauszüge prüfen und im Uploadbereich auswählen','P2','info',ticket),'draft');
  add('draft',E('DRAFT_PREPARE','prepare','Antwortentwurf und Dialog prüfen · kein Versand','P2','info',ticket),'save');
  add('direct',E('DIRECT_UNCHANGED','p2save','Direktfall · Originalbeschreibung unverändert geprüft','P2','good',ticket),'saved');
  add('save',E('P2_SAVE_PENDING','p2save','Entwurf und Ticket speichern · Servernachweis offen','P2','wait',ticket),'saved');
  add('saved',E('P2_SAVE_VERIFIED','p2save','Gespeicherter Bearbeitungsstand bestätigt','P2','good',ticket),'assignee');
  add('assignee',E('ASSIGNEE_SELECT','assignee','Mark im Bearbeiterfeld auswählen','P2','info',ticket),'account');
  add('account',E('ASSIGNEE_VERIFIED','assignee','Bearbeiterkonto mark.baindl exakt bestätigt','P2','good',ticket),'approval');
  add('approval',E('ACTION_APPROVAL','assignee','Warten auf die einmalige Schrittfreigabe','P2','wait',ticket),null,choice('Interne Weiterleitung im Simulator',[
   ['approve','Weiterleitung simulieren','Einen Klick und den separaten Nachweis anzeigen.','route'],['stop','Lauf stoppen','Keine Weiterleitung simulieren.','stop']
  ]));
  add('route',E('ROUTE_INTENT','route','Interne Weiterleitung einmal ausgelöst · Nachweis offen','P2','wait',ticket),'routed');
  add('routed',E('ROUTE_VERIFIED','route','Interne Weiterleitung bestätigt · keine Kunden-E-Mail','P2','good',ticket),'empty');
  add('empty',E('P2_SCAN_FINISHED','end','Keine weiteren automatisch bearbeitbaren Phase-2-Fälle','P2'),'finish');
  add('finish',E('RUN_RESULT','end','Alle Tickets im geprüften Bereich bearbeitet','P2','good'),end==='finish'?'closed':end);
  add('closed',E('BROWSER_CLOSED','end','Bot-Edge am Laufende geschlossen','P2'));
  add('defer',E('TICKET_DEFERRED','issue','Ticket offen dokumentiert · übrige Fälle können weiterlaufen','P2','wait',ticket),'openfinish');
  add('openfinish',E('RUN_RESULT','end','Lauf beendet · ein offener Prüffall bleibt im Bericht','P2','wait'));
  add('stop',E('SIM_ABORT','issue','Simulation: Lauf vor der Weiterleitung gestoppt','P2','bad',ticket));
  return nodes;
 }
 const scenarios={};
 const master={title:'Master · Phase 1 und Phase 2',description:'Zwei fiktive Tickets: Standardantwort und anschließend eine bestehende offene Anfrage. Ein Phase-1-Abschluss ersetzt die manuelle dritte Zeile nicht.',start:'start',nodes:{start:N(E('RUN_START','start','Master-Run ausgewählt · Startfreigabe ausstehend','P1'),'p1_browser'),...p1Nodes({prefix:'p1_'}),...p2Nodes({prefix:'p2_',unknown:true})}};
 master.nodes.p1_empty=N(E('P1_EMPTY','p1scan','Beide erlaubten Phase-1-Listen geprüft · keine weiteren geeigneten Fälle','P1','good'),'p2_scan');
 scenarios.master=master;
 scenarios.mark={title:'Phase 2 · Unbekannte Anfrage',description:'Die dritte Zeile wird manuell eingeordnet. Probiere Mark, offen lassen und abbrechen aus.',start:'start',nodes:p2Nodes({unknown:true})};
 scenarios.db={title:'Phase 2 · DB / DB+ an Mark',description:'Direkter interner Weg: Beschreibung unverändert, Mark auswählen, Weiterleitungsnachweis.',start:'start',nodes:p2Nodes({rule:'DB_DIRECT'})};
 scenarios.ka={title:'Phase 2 · Kontoauszug',description:'Fehlende PDFs, Dokumentprüfung, Entwurf, Speicherung und interne Review-Übergabe.',start:'start',nodes:p2Nodes({rule:'ACCOUNT_STATEMENT'})};
 scenarios.mbc={title:'Phase 2 · Privater MBC-Login',description:'Ein Entwurf wird vorbereitet und intern zur Prüfung weitergegeben. Keine Kunden-E-Mail.',start:'start',nodes:p2Nodes({rule:'MBC_PRIVATE_EMAIL'})};
 scenarios.interrupted={title:'Fehler · Nach erfolgreichem Pilot',description:'Ein Ticket ist bestätigt fertig. Der nächste Phase-1-Verbindungsaufbau scheitert; der Lauf bleibt in Phase 1.',start:'start',nodes:{start:N(start('P1'),'p1_browser'),...p1Nodes({prefix:'p1_',end:'batch'})}};
 Object.assign(scenarios.interrupted.nodes,{
  p1_batch:N(E('P1_RUN','p1scan','Nächster Phase-1-Teillauf wird initialisiert'),'retry'),
  retry:N(E('BROWSER_CONNECT_RETRY','browser','Lokale Browserverbindung prüfen · keine Ticketaktion','P1','wait'),'broken'),
  broken:N(E('BROWSER_CONNECT_FAILED','issue','Lokale Browserverbindung nicht erreichbar · Lauf unterbrochen','P1','bad'))
 });
 const mismatch=p2Nodes({rule:'DB_DIRECT'});mismatch.bound.next='readback';
 mismatch.readback=N(E('DIRECT_UNCHANGED','p2save','Gespeicherte Beschreibung gelesen; erneuter Vergleich folgt','P2','good','90000002'),'mismatch');
 mismatch.mismatch=N(E('REVIEW_REQUIRED','issue','Gespeicherte Werte und erneut geöffneter Editor stimmen nicht sicher überein','P2','bad','90000002'),'defer');
 scenarios.deferred={title:'Fehler · Ein Ticket zurückgestellt',description:'Ein fehlgeschlagener Wertevergleich lässt das Ticket offen; andere Fälle dürfen fortgesetzt werden.',start:'start',nodes:mismatch};
 scenarios.identity={title:'Phase 1 · Identität unklar',description:'Menschliche Prüfung bleibt erforderlich. Ein offener Identitätsnachweis ist keine Versandfreigabe.',start:'start',nodes:{
  start:N(start('P1'),'browser'),...p1Nodes(),
  read:N(E('IDENTITY_REVIEW','person','Personenzuordnung benötigt menschliche Prüfung','P1','wait','90000001'),null,choice('Identitätsprüfung simulieren',[
   ['verified','Identität bestätigt','Nur den bestätigten Prüfzweig anzeigen.','identity'],['unresolved','Nicht eindeutig','Lauf zur Prüfung anhalten.','idstop']
  ])),
  idstop:N(E('IDENTITY_UNRESOLVED','issue','Identitätsnachweis fehlt · keine Standardantwort ausgelöst','P1','bad','90000001')),
  empty:N(E('P1_EMPTY','p1scan','Keine weiteren geeigneten Phase-1-Tickets','P1','good'),'end'),
  end:N(E('RUN_RESULT','end','Alle Tickets im geprüften Phase-1-Bereich bearbeitet','P1','good'))
 }};
 const menuChoice=choice('Welche Menüauswahl möchtest du durchspielen?',[
  ['1','1 · Installation','Software prüfen, sichern und aktualisieren.','install'],
  ['2','2 · Mapping','Bestandsdaten und aktives Mapping aktualisieren.','mapping'],
  ['3','3 · Phase 1','Standardantwort und Nachweise.','p1_browser'],
  ['4','4 · Phase 2','Bearbeiten und intern weiterleiten.','p2_scan'],
  ['5','5 · Master Run','Phase 1, danach Phase 2.','p1_browser'],
  ['0','0 · Beenden','Programm schließen.','exit']
 ]);
 scenarios.menu={title:'Start · Menüpunkte 0 bis 5',description:'Eine vereinfachte Präsentation des Hauptmenüs. Die vollständigen technischen Verzweigungen findest du unter „Originalkarte“.',start:'menu',nodes:{...p1Nodes({prefix:'p1_'}),...p2Nodes({prefix:'p2_',unknown:true}),
  menu:N(E('SIM_MENU','start','Hauptmenü · einen Bedienweg auswählen','SYSTEM'),null,menuChoice),
  install:N(E('SIM_INSTALL_CHECK','start','Softwarepaket und Zielinstallation prüfen','SYSTEM'),null,choice('Installationsergebnis simulieren',[
   ['pass','Prüfung erfolgreich','Sicherung und Installation zeigen.','installed'],['fail','Schreibfehler','Software-Rückweg zeigen.','rollback']
  ])),
  installed:N(E('SIM_INSTALL_DONE','end','Installation abgeschlossen · Hauptmenü verfügbar','SYSTEM','good'),'menu'),
  rollback:N(E('SIM_ROLLBACK','issue','Installation fehlgeschlagen · Software wiederhergestellt','SYSTEM','bad'),'menu'),
  mapping:N(E('SIM_MAPPING','mapping','Bestandsdaten einlesen und Mehrzeilen-/TPP-Regeln prüfen','SYSTEM'),null,choice('Mapping-Ergebnis simulieren',[
   ['valid','Daten gültig','Aktives Mapping aktualisieren.','mapped'],['invalid','Daten unklar','Bisheriges Mapping beibehalten.','mapstop']
  ])),
  mapped:N(E('SIM_MAPPING_DONE','end','Aktives Mapping aktualisiert · kein Echtversand','SYSTEM','good'),'menu'),
  mapstop:N(E('SIM_MAPPING_INVALID','issue','Mapping benötigt Prüfung · bisheriger Stand bleibt aktiv','SYSTEM','wait'),'menu'),
  exit:N(E('SIM_EXIT','end','Programm beendet','SYSTEM','good')),
  p1_empty:N(E('P1_EMPTY','p1scan','Phase-1-Listen geprüft · keine weiteren geeigneten Tickets','P1','good'),'p2_scan')
 }};
 return scenarios;
})();
