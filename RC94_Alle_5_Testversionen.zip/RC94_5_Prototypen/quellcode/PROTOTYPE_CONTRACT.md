# RC94 Prototype renderer contract

All renderer modules are plain scripts; window.ProtoVariants is initialized before them. Register `window.ProtoVariants[1] = {name, tagline, css, render(vm,h)}`; for assigned number. Every CSS selector starts `.px-v1` (or respective variant). Root returned outer div `.px-v1`. No external dependencies, SVG inline okay. Native HTML text 16px+, current action 26-36px. White panels, navy ink, emerald active/verified, amber waiting, red error. No global CSS or large scaled SVG labels. Responsive layouts at 1100/760px. Five truly distinct layouts.

VM fields:
- mode: simulation | live | replay; phase: P1 | P2 | SYSTEM; phaseTitle: human title
- current: {code, label, stage, kind, phase, ticket, at, seq}, may be null
- actionLabel, statusLabel, status: active | wait | verified | error | done | deferred | idle
- ticketLabel: masked human ticket, ticket: raw id or null; mask is handled by h.ticket(id)
- place: {label, certainty, detail}; certainty = Belegt | Aus Arbeitsschritt abgeleitet | Nicht gemeldet
- next: conditional next-action string; reason: why current step / evidence
- route: [{id,label,detail,state,proof}], state=verified | observed | active | wait | error | pending. 6-8 steps/current phase
- phases: [{id,label,sub,state}] includes Phase3 planned, state=current|observed|pending|planned
- history: chronological event array same fields as current; last is latest visible
- tickets: [{id,phase,action,state,statusText,location,proof,lastAt}], state=active|wait|deferred|done; one active at most; id raw use h.ticket
- counts: {p1,p2,open,seen} counts only observed proof, no global backlog
- outcome: null or {kind,label}; terminal confirmed outcome persists when BROWSER_CLOSED arrives
- choice: null or {id,question,options:[{id,label,detail}]} current simulator choice (only simulator actionable)
- selectedStep: route id or null; selectedTicket: raw id or null
- branchHistory: [{label,answer}]

Helpers h:
- e(s): safe HTML escape (also attribute values)
- ticket(id): masked by current preference (safe text, escape if inserting)
- badge(label, tone='neutral'): string markup .px-badge tone
- icon(state): string symbol
- time(iso): readable time
- steps(vm.route, {compact:false}={}): shared vertical clickable .px-steps list
- timeline(events,limit=4): common evidence list
- phaseRail(vm): shared phase rail
- choice(vm): current simulation decision buttons, or explanation

Interactions are delegated in root. Use:
- data-action="select-step" data-step="routeId" opens anchored detail area in common UI, no popup overlay
- data-action="select-ticket" data-ticket="rawID" selects ticket, common details area
- data-action="choose" data-choice="optionId" simulation decision
- data-action="show-details" opens evidence drawer (in normal document flow)
- data-action="original" opens original complete RC94 diagram/simulator; back button provided
- data-action="set-filter" data-filter="all|P1|P2|open" handled by core; vm.filter provided

Common shell already shows design number/name, source badge, simulation/live tabs, comparison select, phase chip, scenario selector and transport bar. Renderer can repeat phase rail for spatial positioning but avoid duplicating entire toolbar. Core offers show/hide simulator controls and presentation text size. Do not pretend arbitrary navigation or future Phase3 implemented. End outcome already displayed in global banner and may also be central design element. Keep counts labels explicitly 'In diesem beobachteten Lauf'.

Each renderer output should fit 1366x850 with core ~185px overhead ideally, but document scrolling allowed. No global screen scaling.
