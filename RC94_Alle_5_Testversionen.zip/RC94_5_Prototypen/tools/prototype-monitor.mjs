/** RC94 Designstudio: isolated, loopback-only, read-only presentation server.
 * Reads the installation's existing sanitized event journal; never loads its code,
 * writes into its directory, starts the bot, or provides COMARCH write endpoints.
 */
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import {randomBytes, timingSafeEqual} from 'node:crypto';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {createInterface} from 'node:readline/promises';

const THIS_FILE=fileURLToPath(import.meta.url);
const PACKAGE_ROOT=path.resolve(path.dirname(THIS_FILE),'..');
export const MAP_FILES=Object.freeze([
 'RC94_01_Navigator.html','RC94_02_Stationskarte.html','RC94_03_Leitstand.html',
 'RC94_04_Entscheidungen.html','RC94_05_Cockpit.html'
]);
const STAGES=new Set(['start','browser','p1scan','person','mapping','reply','send','p1save','p2scan','rule','prepare','p2save','assignee','route','issue','end']);
const MAX_JOURNAL_BYTES=16*1024*1024;
const MAX_EVENTS=3000;

function readSmallJson(file){
 const st=fs.lstatSync(file);
 if(!st.isFile()||st.isSymbolicLink()||st.size>1024*1024)throw new Error('Ungültige RC94-Paketbeschreibung.');
 return JSON.parse(fs.readFileSync(file,'utf8'));
}

/** Reads metadata only. The original installation remains entirely untouched. */
export function validateInstallation(input){
 if(typeof input!=='string'||!input.trim())throw new Error('Kein Installationsordner angegeben.');
 let value=input.trim();
 if(value.startsWith('"')&&value.endsWith('"'))value=value.slice(1,-1);
 const root=fs.realpathSync(path.resolve(value));
 if(!fs.statSync(root).isDirectory())throw new Error('Der Installationspfad ist kein Ordner.');
 const manifest=readSmallJson(path.join(root,'MANIFEST.json'));
 if(manifest.schema!=='MCR_COMPLETE_PACKAGE_V1'||manifest.package!=='MCR_Datenbruecke'||manifest.version!=='0.8.1-rc.94'){
  throw new Error('Dieser Ordner ist keine MCR-Datenbrücke RC94. Bitte den installierten RC94-Hauptordner wählen.');
 }
 if(!fs.statSync(path.join(root,'lib','flow-events.mjs')).isFile())throw new Error('Die RC94-Ereignisanbindung fehlt in diesem Ordner.');
 for(const relative of ['.runtime',path.join('.runtime','flow-map')]){
  const file=path.join(root,relative);
  if(fs.existsSync(file)&&(!fs.lstatSync(file).isDirectory()||fs.lstatSync(file).isSymbolicLink())){
   throw new Error('Der Ereignisordner ist kein direkter lokaler Installationsordner.');
  }
 }
 return root;
}

function cleanEvent(e){
 if(!e||e.schema!=='MCR_FLOW_EVENT_V1'||typeof e.runId!=='string'||!e.runId||e.runId.length>160||
  !Number.isSafeInteger(e.seq)||e.seq<1||typeof e.label!=='string'||e.label.length>1200||
  typeof e.at!=='string'||!Number.isFinite(Date.parse(e.at))||!STAGES.has(e.stage)||
  !['P1','P2','SYSTEM'].includes(e.phase)||!['info','good','wait','bad'].includes(e.kind))return null;
 // Allowlist the sanitized presentation contract. Never forward unknown fields.
 return {schema:'MCR_FLOW_EVENT_V1',version:'0.8.1-rc.94',runId:e.runId,seq:e.seq,at:e.at,
  code:typeof e.code==='string'?e.code.slice(0,160):'UNKNOWN',stage:e.stage,label:e.label,
  overview:typeof e.overview==='string'?e.overview.slice(0,80):'',kind:e.kind,phase:e.phase,
  ticket:typeof e.ticket==='string'&&/^\d{6,12}$/.test(e.ticket)?e.ticket:null};
}

export async function createPrototypeMonitor({installationRoot=null,packageRoot=PACKAGE_ROOT,
 token=randomBytes(32).toString('hex'),port=0,pollMs=180,heartbeatMs=10000,maxClients=12}={}){
 if(!/^[a-f0-9]{64}$/.test(token))throw new Error('Invalid local capability');
 if(!Number.isInteger(port)||port<0||port>65535)throw new Error('Invalid local port');
 const root=installationRoot===null?null:validateInstallation(installationRoot);
 const assets=fs.realpathSync(packageRoot);
 const routes=new Map([['/',path.join(assets,'START_HIER.html')],['/START_HIER.html',path.join(assets,'START_HIER.html')],
  ...MAP_FILES.map(file=>['/maps/'+file,path.join(assets,'maps',file)])]);
 const journal=root?path.join(root,'.runtime','flow-map','events.jsonl'):null;
 const serverId=randomBytes(12).toString('hex');
 const clients=new Set();
 let boundPort=port,events=[],seen=new Set(),runId=null,lastSize=-1,lastMtime=-1,lastIno=-1;
 let sourceState=root?'waiting':'offline',sourceMessage=root?'Noch kein Ereignisprotokoll vorhanden.':'Nur Simulation; keine Installation verbunden.';
 let closed=false;
 const authorized=value=>typeof value==='string'&&/^[a-f0-9]{64}$/.test(value)&&timingSafeEqual(Buffer.from(value),Buffer.from(token));
 const send=(res,type,data,id)=>{
  if(res.destroyed||res.writableEnded){clients.delete(res);return;}
  try{
   const ok=res.write((id?'id: '+id+'\n':'')+'event: '+type+'\ndata: '+JSON.stringify(data)+'\n\n');
   if(!ok){clients.delete(res);res.end();}
  }catch{clients.delete(res);res.destroy();}
 };
 const sourceInfo=()=>({state:sourceState,message:sourceMessage,liveSource:!!root});
 function setSource(state,message){
  if(state===sourceState&&message===sourceMessage)return;
  sourceState=state;sourceMessage=message;
  for(const res of clients)send(res,'source',sourceInfo());
 }
 function clearRun(reason){
  if(!events.length&&!runId)return;
  events=[];seen=new Set();runId=null;
  for(const res of clients)send(res,'reset',{runId:null,reason});
 }
 function refresh(){
  if(!root||closed)return;
  try{
   for(const relative of ['.runtime',path.join('.runtime','flow-map')]){
    const stat=fs.lstatSync(path.join(root,relative));
    if(!stat.isDirectory()||stat.isSymbolicLink())throw new Error('Der Ereignisordner wurde ersetzt.');
   }
   const stat=fs.lstatSync(journal);
   if(!stat.isFile()||stat.isSymbolicLink())throw new Error('Das Ereignisprotokoll ist keine direkte Datei.');
   if(stat.size>MAX_JOURNAL_BYTES)throw new Error('Ereignisprotokoll zu groß; Anzeige pausiert.');
   if(stat.size===lastSize&&stat.mtimeMs===lastMtime&&stat.ino===lastIno)return;
   lastSize=stat.size;lastMtime=stat.mtimeMs;lastIno=stat.ino;
   // Bounded read, rechecked after open to avoid accidental links or oversized files.
   const fd=fs.openSync(journal,fs.constants.O_RDONLY|(fs.constants.O_NOFOLLOW||0));
   let text;
   try{
    const opened=fs.fstatSync(fd);
    if(!opened.isFile()||opened.size>MAX_JOURNAL_BYTES)throw new Error('Ungültiges Ereignisprotokoll.');
    const buffer=Buffer.alloc(opened.size);
    let offset=0;
    while(offset<buffer.length){const n=fs.readSync(fd,buffer,offset,buffer.length-offset,offset);if(!n)break;offset+=n;}
    text=buffer.subarray(0,offset).toString('utf8');
   }finally{fs.closeSync(fd);}
   // Only complete lines. An append may be in progress between two refreshes.
   const lines=text.slice(0,text.lastIndexOf('\n')+1).split('\n').slice(-MAX_EVENTS-1001);
   const next=[];
   for(const line of lines){if(!line||line.length>8000)continue;try{const e=cleanEvent(JSON.parse(line));if(e)next.push(e);}catch{}}
   const nextRun=next.at(-1)?.runId||null;
   if(nextRun!==runId){
    seen=new Set();runId=nextRun;
    for(const res of clients)send(res,'reset',{runId,reason:'new-run'});
   }
   const distinct=new Map();
   for(const e of next)if(e.runId===runId)distinct.set(e.seq,e);
   events=[...distinct.values()].sort((a,b)=>a.seq-b.seq).slice(-MAX_EVENTS);
   setSource(events.length?'ready':'waiting',events.length?'RC94-Ereignisprotokoll wird beobachtet.':'Warte auf einen neuen RC94-Lauf.');
   for(const e of events){
    const id=e.runId+':'+e.seq;if(seen.has(id))continue;
    seen.add(id);for(const res of clients)send(res,'flow',e,id);
   }
   if(seen.size>MAX_EVENTS+1000)seen=new Set(events.map(e=>e.runId+':'+e.seq));
  }catch(error){
   lastSize=-1;lastMtime=-1;lastIno=-1;
   const missing=error?.code==='ENOENT';
   clearRun(missing?'journal-missing':'source-error');
   setSource(missing?'waiting':'error',missing?'Noch kein Ereignisprotokoll vorhanden.':error?.code?'Ereignisprotokoll nicht lesbar.':String(error.message||'Ereignisprotokoll nicht lesbar.'));
  }
 }
 const server=http.createServer((req,res)=>{
  const origin=`http://127.0.0.1:${boundPort}`;
  res.setHeader('X-Content-Type-Options','nosniff');
  res.setHeader('Referrer-Policy','no-referrer');
  res.setHeader('Cache-Control','no-store');
  if(req.headers.host!==`127.0.0.1:${boundPort}`||(req.headers.origin&&req.headers.origin!==origin)){
   res.writeHead(403);res.end('Local origin only');return;
  }
  if(!['GET','HEAD'].includes(req.method)){res.writeHead(405,{Allow:'GET, HEAD'});res.end();return;}
  let url;try{url=new URL(req.url,origin);}catch{res.writeHead(400);res.end();return;}
  if(routes.has(url.pathname)){
   const file=routes.get(url.pathname);
   res.setHeader('Content-Type','text/html; charset=utf-8');
   res.setHeader('Content-Security-Policy',"default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data: blob:; font-src data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'");
   try{
    const st=fs.lstatSync(file);
    if(!st.isFile()||st.isSymbolicLink()||st.size>16*1024*1024)throw new Error('Invalid map asset');
    const real=fs.realpathSync(file);
    if(!real.startsWith(assets+path.sep))throw new Error('Asset escaped package');
    const html=fs.readFileSync(file);res.writeHead(200);res.end(req.method==='HEAD'?undefined:html);
   }catch{res.writeHead(503);res.end('Map asset unavailable');}
   return;
  }
  if(!url.pathname.startsWith('/api/')){res.writeHead(404);res.end();return;}
  if(!authorized(url.searchParams.get('token'))){res.writeHead(403);res.end('Capability required');return;}
  if(url.pathname==='/api/status'){
   refresh();res.writeHead(200,{'Content-Type':'application/json'});
   res.end(req.method==='HEAD'?undefined:JSON.stringify({schema:'MCR_MAP_SERVICE_V1',version:'0.8.1-rc.94',serverId,
    readOnly:true,prototype:true,liveSource:!!root,runId,eventCount:events.length,sourceState,...{source:sourceInfo()}}));return;
  }
  if(url.pathname==='/api/events'&&req.method==='GET'){
   if(clients.size>=maxClients){res.writeHead(429);res.end('Too many local viewers');return;}
   refresh();res.writeHead(200,{'Content-Type':'text/event-stream; charset=utf-8','Connection':'keep-alive'});res.flushHeaders();
   send(res,'hello',{version:'0.8.1-rc.94',readOnly:true,serverId,at:new Date().toISOString(),liveSource:!!root,sourceState,source:sourceInfo()});
   const last=req.headers['last-event-id'];
   const after=last?events.findIndex(e=>e.runId+':'+e.seq===last):-1;
   if(last&&after<0)send(res,'reset',{runId,reason:'replay-from-available-history'});
   for(const e of events.slice(after>=0?after+1:0))send(res,'flow',{...e,replayed:true},e.runId+':'+e.seq);
   if(!res.destroyed&&!res.writableEnded)clients.add(res);
   req.on('close',()=>clients.delete(res));return;
  }
  res.writeHead(404);res.end();
 });
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve);});
 boundPort=server.address().port;
 const timer=setInterval(refresh,Math.max(40,pollMs));
 const heartbeat=setInterval(()=>{for(const res of clients){try{res.write(': heartbeat\n\n');}catch{clients.delete(res);res.destroy();}}},Math.max(100,heartbeatMs));
 const close=()=>new Promise(resolve=>{
  if(closed){resolve();return;}closed=true;clearInterval(timer);clearInterval(heartbeat);
  for(const res of clients)res.end();clients.clear();server.close(()=>resolve());server.closeIdleConnections?.();
 });
 refresh();
 return {server,port:boundPort,token,serverId,installationRoot:root,
  url:`http://127.0.0.1:${boundPort}/`+(root?'#live='+token:''),refresh,close};
}

export function parseArgs(args){
 const out={root:undefined,noOpen:false,offline:false};
 for(let i=0;i<args.length;i++){
  if(args[i]==='--root'){if(!args[i+1]||args[i+1].startsWith('--'))throw new Error('--root benötigt einen Installationspfad.');out.root=args[++i];}
  else if(args[i]==='--no-open')out.noOpen=true;
  else if(args[i]==='--offline')out.offline=true;
  else if(args[i]==='--help')out.help=true;
  else throw new Error('Unbekannte Option: '+args[i]);
 }
 if(out.offline&&out.root)throw new Error('--root und --offline nicht gemeinsam verwenden.');
 return out;
}

function defaultInstallation(){
 const candidates=[
  process.env.MCR_INSTALL_ROOT,
  process.env.USERPROFILE?path.join(process.env.USERPROFILE,'projects','Aktive_Projekte','Ticket_bot','MCR_Datenbruecke'):null,
  path.resolve(PACKAGE_ROOT,'..','MCR_Datenbruecke'),
  'C:\\Users\\Amaru-Zegarra\\projects\\Aktive_Projekte\\Ticket_bot\\MCR_Datenbruecke'
 ].filter(Boolean);
 for(const candidate of candidates){try{return validateInstallation(candidate);}catch{}}
 return null;
}

async function main(){
 const args=parseArgs(process.argv.slice(2));
 if(args.help){console.log('RC94 Designstudio: --root "INSTALLATIONSORDNER" [--no-open] | --offline [--no-open]');return;}
 if(Number(process.versions.node.split('.')[0])<18)throw new Error('Node.js 18 oder neuer wird benötigt; nutze das Node aus deiner RC94-Einrichtung.');
 let installationRoot=null;
 console.log('\nMCR RC94 · FÜNF MAP-PROTOTYPEN\nNur Anzeige und Simulation; der Ticketbot wird hier nicht gestartet.\n');
 if(args.root)installationRoot=validateInstallation(args.root);
 else if(!args.offline&&process.stdin.isTTY){
  const candidate=defaultInstallation();
  const rl=createInterface({input:process.stdin,output:process.stdout});
  try{
   console.log('Für Live-Vergleich den bereits installierten RC94-Ordner wählen.');
   console.log('Den normalen Bot wie gewohnt separat starten. Alle fünf Karten beobachten denselben Lauf.');
   if(candidate)console.log('Vorgeschlagene Installation: '+candidate);
   while(true){
    const answer=(await rl.question(candidate?'ENTER = diesen Ordner / O = nur Simulation / anderer Ordner: ':'Installationsordner eingeben / ENTER = nur Simulation: ')).trim();
    if(/^o(?:ffline)?$/i.test(answer)||(!answer&&!candidate))break;
    try{installationRoot=validateInstallation(answer||candidate);break;}
    catch(error){console.log('Ordner nicht verwendet: '+error.message);}
   }
  }finally{rl.close();}
 }else if(!args.offline){console.log('Kein Installationspfad angegeben. Nur Simulation; für Live --root verwenden.');}
 const monitor=await createPrototypeMonitor({installationRoot});
 console.log(installationRoot?'BEOBACHTETE RC94-INSTALLATION: '+installationRoot:'MODUS: Nur Simulation, keine Installation verbunden.');
 console.log('VERGLEICH ÖFFNEN: '+monitor.url);
 console.log('Dieses Fenster offen lassen. STRG+C beendet nur die Kartenverbindung.');
 console.log('Der Bot und sein COMARCH-Browser werden dadurch nicht beendet.\n');
 if(!args.noOpen&&process.platform==='win32'){
  const child=spawn('rundll32.exe',['url.dll,FileProtocolHandler',monitor.url],{stdio:'ignore',windowsHide:true,detached:true});
  child.on('error',()=>console.log('Browser bitte über die oben gezeigte Adresse öffnen.'));child.unref();
 }
 for(const signal of ['SIGINT','SIGTERM'])process.once(signal,async()=>{await monitor.close();process.exitCode=0;});
}

if(process.argv[1]&&path.resolve(process.argv[1])===THIS_FILE){
 main().catch(error=>{console.error('KARTENSTART_FEHLER: '+error.message);process.exitCode=1;});
}
