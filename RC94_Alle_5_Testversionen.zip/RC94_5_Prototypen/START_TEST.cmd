@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
set "MCR_STUDIO_NODE="
if exist "%USERPROFILE%\projects\Compiler\javascript\tools\node\node.exe" set "MCR_STUDIO_NODE=%USERPROFILE%\projects\Compiler\javascript\tools\node\node.exe"
if defined MCR_STUDIO_NODE goto run
for /f "delims=" %%N in ('where node.exe 2^>nul') do if not defined MCR_STUDIO_NODE set "MCR_STUDIO_NODE=%%N"
if defined MCR_STUDIO_NODE goto run
echo Node.js wurde nicht gefunden. Fuer die Simulation START_HIER.html oeffnen.
echo Fuer die Live-Anbindung das Node.js aus der vorhandenen RC94-Einrichtung verwenden.
start "" "%~dp0START_HIER.html"
pause
exit /b 1
:run
"%MCR_STUDIO_NODE%" "%~dp0tools\prototype-monitor.mjs"
if errorlevel 1 goto failed
exit /b 0
:failed
echo Die Kartenverbindung wurde nicht gestartet. Die RC94-Installation blieb unveraendert.
pause
exit /b 1
