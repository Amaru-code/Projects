import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {secureDemoMapping,DEMO_MAPPING_REL,DEMO_MAPPING_SHA256} from '../tools/demo-assets.mjs';

const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const fixture=Buffer.from('{"schema":"MCR_FAKE_DEMO_MAPPING_V1","testOnly":true,"rows":[]}\n','utf8');
const pinned=hash(fixture);
function root(t){const x=fs.mkdtempSync(path.join(os.tmpdir(),'mcr-v3-fixture-'));t.after(()=>fs.rmSync(x,{recursive:true,force:true}));return x;}
function installFixture(root,bytes=fixture) {const p=path.join(root,...DEMO_MAPPING_REL.split('/'));fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,bytes);return p;}
function source(installRoot,candidate={entries:null},options={}){return secureDemoMapping({installRoot,candidate,preloaded:new Map(),demoMappingSha256:pinned,...options});}

test('documented original demo SHA is fixed and not the synthetic test SHA',()=>{assert.equal(DEMO_MAPPING_SHA256,'c147a9eb9c93d5c6d4a47f208c9f98c2afd0b0144cbf63b2c50b1c06676fdc40');assert.notEqual(pinned,DEMO_MAPPING_SHA256);});
test('copies only exact SHA-pinned local fictional demo JSON',t=>{const r=root(t);installFixture(r);const res=source(r);assert.deepEqual(res.bytes,fixture);assert.equal(res.source,'PINNED_LOCAL_DEMO_FIXTURE');});
test('keeps existing active mapping untouched',t=>{const r=root(t);installFixture(r);const sensitive=Buffer.from('real mapping');const p=path.join(r,'private_data','active-mapping.json');fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,sensitive);const got=source(r);assert.deepEqual(got.bytes,fixture);assert.deepEqual(fs.readFileSync(p),sensitive);});
test('rejects missing local fixture before touching live',t=>{const r=root(t);assert.throws(()=>source(r),{code:'DEMO_MAPPING_MISSING'});});
test('rejects changed demo mapping and does not disclose its content',t=>{const r=root(t);const sensitive='PII_PERSON_PERSON';installFixture(r,Buffer.from(JSON.stringify({real:sensitive})));let err;try{source(r);}catch(e){err=e;}assert.equal(err.code,'DEMO_MAPPING_HASH_MISMATCH');assert.equal(err.message.includes(sensitive),false);});
test('rejects syntactically invalid JSON even with correct injected pin',t=>{const r=root(t);const b=Buffer.from('{broken');installFixture(r,b);assert.throws(()=>source(r,{entries:null},{demoMappingSha256:hash(b)}),{code:'DEMO_MAPPING_JSON_INVALID'});});
test('rejects top-level non-object even with correct injected pin',t=>{const r=root(t);const b=Buffer.from('[]');installFixture(r,b);assert.throws(()=>source(r,{entries:null},{demoMappingSha256:hash(b)}),{code:'DEMO_MAPPING_JSON_INVALID'});});
test('rejects symlink fixture',t=>{const r=root(t);const target=path.join(r,'target.json');fs.writeFileSync(target,fixture);fs.mkdirSync(path.join(r,'examples'));try{fs.symlinkSync(target,path.join(r,'examples','DEMO_mapping.json'));}catch(e){if(e.code==='EPERM')return t.skip('symlink rights unavailable');throw e;}assert.throws(()=>source(r),{code:'PATH_LINK'});});
test('rejects symlink fixture parent directory',t=>{const r=root(t);const d=path.join(r,'redirect');fs.mkdirSync(d);fs.writeFileSync(path.join(d,'DEMO_mapping.json'),fixture);try{fs.symlinkSync(d,path.join(r,'examples'),'dir');}catch(e){if(e.code==='EPERM')return t.skip('symlink rights unavailable');throw e;}assert.throws(()=>source(r),{code:'PATH_LINK'});});
test('trusted pinned full release archive fixture preferred to local changed file',t=>{const r=root(t);installFixture(r,Buffer.from('changed'));const prefix='rc1/';const contents=Buffer.from('{"trusted":true}\n');const candidate={prefix,entries:new Map([[prefix+DEMO_MAPPING_REL,contents]])};const got=secureDemoMapping({installRoot:r,candidate,preloaded:new Map([[DEMO_MAPPING_REL,contents]])});assert.equal(got.source,'PINNED_RELEASE_ARCHIVE');assert.deepEqual(got.bytes,contents);});
test('preloaded mapping without matching release archive is denied',t=>{const r=root(t);const f=new Map([[DEMO_MAPPING_REL,fixture]]);assert.throws(()=>secureDemoMapping({installRoot:r,candidate:{entries:null},preloaded:f}),{code:'DEMO_ASSET_UNTRUSTED'});});
test('preloaded content different from sealed archive is denied',t=>{const r=root(t);const candidate={prefix:'release/',entries:new Map([['release/'+DEMO_MAPPING_REL,fixture]])};assert.throws(()=>secureDemoMapping({installRoot:r,candidate,preloaded:new Map([[DEMO_MAPPING_REL,Buffer.from('wrong')]])}),{code:'DEMO_ASSET_UNTRUSTED'});});
test('isolated Node child can open exact formerly missing examples/DEMO_mapping.json',t=>{const r=root(t),scratch=root(t);installFixture(r);const got=source(r);const p=installFixture(scratch,got.bytes);assert.ok(fs.existsSync(p));const code=`const fs=require('node:fs');const path=require('node:path');const x=JSON.parse(fs.readFileSync(path.resolve('examples/DEMO_mapping.json'),'utf8'));if(!x.testOnly)process.exit(2);`;
 const result=spawnSync(process.execPath,['-e',code],{cwd:scratch,encoding:'utf8'});assert.equal(result.status,0,result.stderr);assert.equal(fs.existsSync(path.join(scratch,'private_data')),false);});
