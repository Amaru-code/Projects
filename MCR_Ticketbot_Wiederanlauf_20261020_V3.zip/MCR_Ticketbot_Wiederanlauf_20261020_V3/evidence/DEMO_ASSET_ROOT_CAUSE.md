# MCR Ticketbot V3 – Ursache des Demo-Abbruchs (20.10.2026)

## Belegte Beobachtungen

- `PINNED_IDENTITY_RUNNER_FOUND`: SHA256-gepinnter RC1.1-Runner wurde auf Windows gefunden.
- `BASELINE_AND_IDENTITY_HASHES`, `EXISTING_ACTIVE_MAPPING_PRESENT`, `LOCAL_DEPENDENCY_SYNTAX`: bestanden.
- `DEPENDENCIES_LOCAL_ONLY_NOT_INDEPENDENTLY_PINNED`: Quelle war der gepinnte einzelne Runner, nicht das vollstaendige release-gepinnte Archiv mit Demo-Beispieldaten.
- `ENOENT .../examples/DEMO_mapping.json`: In der **isoliert kopierten** Demo wurde die Datei nicht mitkopiert, weil der V2-Code Demo-Assets ausschliesslich aus einer vollstaendig geprueften `candidate.entries`-Archivquelle uebernimmt. Ein einzelner SHA256-gepinnter Runner hat aber keine `candidate.entries`.
- `OFFLINE_DEMO_NOT_VERIFIED`: korrekt geblockt; keine Aenderung an der echten Installation und kein COMARCH-Versand belegt.

## Minimalinvasive Korrektur V3

- Archivquelle vorhanden: nur die Beispielressourcen aus dem release-gepinnten Archiv wie bisher; `examples/DEMO_mapping.json` zusaetzlich gegen den Archivinhalt gebunden.
- Archivquelle nicht vorhanden: exakt `examples/DEMO_mapping.json` aus der bestehenden Installation bzw. einem alten lokalen Projekt-/Download-Snapshot suchen und nur einlesen, wenn ihr SHA256 exakt `c147a9eb9c93d5c6d4a47f208c9f98c2afd0b0144cbf63b2c50b1c06676fdc40` betraegt. Dieser Wert wurde bei der bereits erfolgreichen **fiktiven** Demo im alten Chat protokolliert. Der Hash muss zu den tatsaechlichen Originalbytes passen.
- SHA-Pruefung geschieht **vor** dem isolierten Demo-Start; bei fehlender/abweichender Datei fail-closed mit eigenem Code.
- Aktives Mapping, produktive Bestandsdaten, Konfiguration, Browserprofile und private_data werden nicht in die Demo kopiert.
- Keine Aenderung am urspruenglichen Runner, an der Identitaetslogik, am COMARCH-Selektor oder an der maximalen Live-Ticketanzahl.
- Neuer expliziter `DEMO_TESTEN_OHNE_VERSAND.cmd` mit streng getrennter Demo-Ausfuehrung ohne Installation oder Echtversand.

## Offene Nachweise

- Originale RC1.1-Runner- und Demo-Mapping-Bytes waren in dieser isolierten Chat-Umgebung nicht gleichzeitig verfuegbar; die V3-Live-Inbetriebnahme kann daher **nur** am bereits verifizierten lokalen Windows-System nachgewiesen werden.
- Im Linux-Offline-Test wurden Quelle-/Datei-/Pfadsperren, Priorisierung einer release-gepinnten Datei, JSON-Pruefung und eine echte isolierte Node-Dateioeffnung geprueft; der originale COMARCH-Browser ist dort nicht gestartet.
- Meldet Windows `DEMO_MAPPING_MISSING` oder `DEMO_MAPPING_HASH_MISMATCH`, muss die echte unveraenderte synthetische Datei aus der vorherigen erfolgreichen Demoinstallation / aus dem Originalpaket bereitgestellt werden. Ein Neuaufbau aus aktiven Mitgliederdaten ist **nicht** zulaessig.
