/* Recovery 2026-10-20 V3: reproducible fictional demo fixtures only.
 * Never open the active mapping, Excel file, browser profile or real COMARCH config here.
 */
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {sha,demand,inside,readBytes,walk} from './recovery-core.mjs';

export const DEMO_MAPPING_REL='examples/DEMO_mapping.json';
// Observed in the successful two-ticket DEMO run in the original MCR conversation.
export const DEMO_MAPPING_SHA256='c147a9eb9c93d5c6d4a47f208c9f98c2afd0b0144cbf63b2c50b1c06676fdc40';

/**
 * Prefer a fixture inside a cryptographically pinned RC1.1 release archive.
 * With an individually pinned candidate runner, use ONLY the existing local
 * demo fixture matching the SHA-256 from the original successful demo run.
 * No arbitrary 'examples/' clone, active mapping or private data access.
 * Returns an entirely in-memory fixture; the calling demo uses a temporary root.
 */
export function secureDemoMapping({installRoot, candidate, preloaded, demoMappingSha256=DEMO_MAPPING_SHA256}) {
  if (preloaded.has(DEMO_MAPPING_REL)) {
    // Only preloaded when the complete release archive itself is SHA-pinned.
    demand(candidate?.entries instanceof Map && candidate.entries.has(candidate.prefix+DEMO_MAPPING_REL),
      'DEMO_ASSET_UNTRUSTED','Die bereits geladene Demo-Datei hat keinen gueltigen Originalarchiv-Beleg.');
    const trusted=candidate.entries.get(candidate.prefix+DEMO_MAPPING_REL);
    demand(preloaded.get(DEMO_MAPPING_REL).equals(trusted),'DEMO_ASSET_UNTRUSTED');
    validateDemoJson(trusted);
    return {bytes:Buffer.from(trusted),source:'PINNED_RELEASE_ARCHIVE'};
  }
  const pinnedSource=String(candidate?.filePath||'').trim();
  const previewRoot=pinnedSource && path.basename(pinnedSource).toLowerCase()==='local-bot-full-run.mjs'
    ? path.dirname(path.dirname(pinnedSource)) : null;
  const chosen=String(candidate?.demoMappingPath||'').trim();
  const candidates=[
    inside(installRoot,DEMO_MAPPING_REL),
    ...(previewRoot?[path.join(previewRoot,DEMO_MAPPING_REL)]:[]),
    ...(chosen?[path.resolve(chosen)]:[]),
  ];
  // Restrict discovery to the exact filename, to local files, and to original
  // SHA-pinned bytes. Never inspect private_data or browser/profile folders.
  const home=os.homedir();
  const roots=[path.join(home,'Downloads'),path.join(home,'Documents'),
    path.join(home,'Desktop'),path.join(home,'projects','Aktive_Projekte','Ticket_bot')];
  const visited=new Set(), observed=[];
  function accept(file){
    if(visited.has(path.resolve(file).toLowerCase()))return null;
    visited.add(path.resolve(file).toLowerCase());
    let stat;
    try {
      const parent=fs.lstatSync(path.dirname(file));
      stat=fs.lstatSync(file);
      if(!parent.isDirectory()||parent.isSymbolicLink()||!stat.isFile()||stat.isSymbolicLink()||
          stat.size<1||stat.size>1024*1024) return null;
    }catch{return null;}
    let bytes;try{bytes=readBytes(file,1024*1024);}catch{return null;}
    if(sha(bytes)!==demoMappingSha256){observed.push(file);return null;}
    validateDemoJson(bytes);
    return {bytes,source:'PINNED_LOCAL_DEMO_FIXTURE'};
  }
  for(const file of candidates){const found=accept(file);if(found)return found;}
  // A prior demo may have its example in a project snapshot rather than the
  // active installation. Bounded filename-only lookup; no unpinned import.
  for(const root of roots) {
    if(!fs.existsSync(root))continue;
    let candidates=[];
    try { candidates=walk(root,{maxDepth:9,maxFiles:20000}); }
    catch(e){if(['SCAN_LIMIT','EACCES','EPERM'].includes(e.code))continue;throw e;}
    for(const file of candidates)if(path.basename(file).toLowerCase()==='demo_mapping.json'){
      const found=accept(file);if(found)return found;
    }
  }
  if(observed.length) throw Object.assign(new Error(
    'Gefundene DEMO_mapping.json stimmt nicht mit der SHA256 des erfolgreichen frueheren Demo-Laufs ueberein. Keine Realbestandsdaten kopiert. Bitte die originale Demo-Datei aus dem frueheren Paket bereitstellen.'),
    {code:'DEMO_MAPPING_HASH_MISMATCH'});
  throw Object.assign(new Error(
    'Die originale synthetische examples\\DEMO_mapping.json wurde lokal nicht gefunden. Sie muss in einem frueheren Paket/Installationsordner vorhanden sein. Reale Bestandsdateien duerfen NICHT als Ersatz verwendet werden.'),
    {code:'DEMO_MAPPING_MISSING'});
}
function validateDemoJson(bytes) {
  let obj;
  try {obj=JSON.parse(bytes.toString('utf8').replace(/^\uFEFF/,''));}
  catch {throw Object.assign(new Error('Die nachgewiesene Demo-Mappingdatei ist kein gueltiges JSON.'),{code:'DEMO_MAPPING_JSON_INVALID'});}
  demand(obj!==null && typeof obj==='object' && !Array.isArray(obj),
    'DEMO_MAPPING_JSON_INVALID','Demo-Mapping muss ein JSON-Objekt sein.');
  return true;
}
