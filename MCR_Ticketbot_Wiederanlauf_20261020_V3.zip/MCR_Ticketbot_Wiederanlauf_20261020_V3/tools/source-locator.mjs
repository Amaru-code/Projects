/* Local, read-only source discovery. No network; source must match an already pinned SHA-256. */
import fs from 'node:fs';
import path from 'node:path';
import {PINS,demand,sha,readBytes,walk,readZip} from './recovery-core.mjs';

const RUNNER='src/local-bot-full-run.mjs';
const MAX_ARCHIVE=16*1024*1024;
const CANDIDATE_NAME='local-bot-full-run.mjs';
function isFile(p){try{return fs.lstatSync(p).isFile()&&!fs.lstatSync(p).isSymbolicLink();}catch{return false;}}
function isDir(p){try{return fs.lstatSync(p).isDirectory()&&!fs.lstatSync(p).isSymbolicLink();}catch{return false;}}
function dedupeNames(a){const uniq=new Set();return a.filter(x=>{const key=process.platform==='win32'?path.resolve(x).toLowerCase():path.resolve(x);if(uniq.has(key))return false;uniq.add(key);return true;});}
function rootHints({kit,home,installRoot,env=process.env}) {
 const roots=[
   {p:path.join(home,'Downloads'),name:'Downloads'},
   {p:path.join(home,'Desktop'),name:'Desktop'},
   {p:path.join(home,'Documents'),name:'Documents'},
   {p:path.join(home,'projects','Aktive_Projekte','Ticket_bot'),name:'TicketBotProject'},
   {p:path.join(installRoot,'..'),name:'InstalledProjectParent'},
   {p:kit,name:'RecoveryKit'},
   {p:env.OneDrive||'',name:'OneDrive'},
   {p:env.OneDriveCommercial||'',name:'OneDriveCommercial'},
   {p:env.OneDriveConsumer||'',name:'OneDriveConsumer'},
   {p:path.join(home,'OneDrive','Downloads'),name:'OneDriveDownloads'},
   {p:path.join(home,'OneDrive','Desktop'),name:'OneDriveDesktop'},
   {p:env.TEMP||'',name:'Temp'},
 ];
 const seen=new Set();return roots.filter(x=>{
    if(!x.p || !isDir(x.p))return false;
    const key=process.platform==='win32'?path.resolve(x.p).toLowerCase():path.resolve(x.p);
    if(seen.has(key))return false;seen.add(key);return true;
 });
}
function mightContainSource(file){
 const name=path.basename(file);
 if(name.toLowerCase()===CANDIDATE_NAME) return true;
 if(!/\.zip$/i.test(name))return false;
 return /mcr|ticket|identity|beta.?5|rc1|rc2|preview|upload/i.test(file);
}
export function verifyCandidateFile(file,pins=PINS) {
 if(!isFile(file))return null;
 let stat;try{stat=fs.statSync(file);}catch{return null;}
 if(stat.size<1||stat.size>MAX_ARCHIVE)return null;
 const input=readBytes(file,MAX_ARCHIVE);
 const digest=sha(input);
 if(digest===pins.candidate)return {bytes:input,archiveSha256:null,entries:null,prefix:null,source:'PINNED_LOCAL_PREVIEW',filePath:file};
 if(!pins.archives.includes(digest))return null;
 const entries=readZip(input);
 for(const [name,data]of entries) {
   if(!name.endsWith('/'+RUNNER)&&name!==RUNNER)continue;
   if(sha(data)!==pins.candidate)continue;
   return {bytes:data,archiveSha256:digest,entries,prefix:name.slice(0,-RUNNER.length),source:'PINNED_LOCAL_ARCHIVE'};
 }
 return null;
}
export function discoverCandidate({settings={},kit,home,installRoot,env=process.env,pins=PINS,limits={},onProgress=()=>{}}) {
 const stats={checked:0,scannedFiles:0,skippedRoots:0,rootsChecked:[],hashMismatchCount:0};
 const explicit=String(settings.candidateRunner||'').trim();
 const maxFiles=limits.maxFiles??40000;
 function checkFiles(files,filterByName=true) {
   const paths=dedupeNames(filterByName?files.filter(mightContainSource):files);
   paths.sort((a,b)=>Number(!/\.zip$/i.test(a))-Number(!/\.zip$/i.test(b)));
   for(const p of paths) {
     stats.checked++;
     let exact=null;
     try{exact=verifyCandidateFile(p,pins);}catch(e) {
       if(e.code==='ZIP_SIZE'||e.code==='ZIP_ENCODING'||e.code==='ZIP_END'||e.code==='FILE_UNSAFE') continue;
       if(e.code==='EACCES'||e.code==='EPERM'||e.code==='ENOENT') continue;
       throw e;
     }
     if(exact)return {...exact,stats};
     if(isFile(p))stats.hashMismatchCount++;
   }
   return null;
 }
 if(explicit){
   const p=path.resolve(explicit);
   demand(fs.existsSync(p),'SOURCE_PATH_NOT_FOUND','Der in recovery-settings.json eingetragene Quellpfad ist nicht mehr vorhanden. Quelle neu auswaehlen oder Eintrag leeren.');
   let files=[];
   if(isFile(p))files=[p];
   else if(isDir(p)){
     try{files=walk(p,{maxDepth:11,maxFiles});}catch(e){
       if(e.code==='SCAN_LIMIT')throw Object.assign(new Error('Zu viele Dateien. Bitte direkt das RC1.1-ZIP oder die local-bot-full-run.mjs angeben.'),{code:'SOURCE_FOLDER_TOO_LARGE'});
       throw e;
     }
   }else throw Object.assign(new Error('Quelle muss eine normale Datei oder ein Ordner sein.'),{code:'SOURCE_INVALID'});
   const matched=checkFiles(files,!isFile(p));
   if(matched)return matched;
   throw Object.assign(new Error('Die ausgewaehlte Datei enthaelt NICHT den unveraenderten, SHA256-geprueften RC1.1-Runner. Kein Versand. Bitte das urspruengliche RC1.1-ZIP aus dem alten Chat verwenden.'),{code:'CANDIDATE_HASH_MISMATCH',stats});
 }
 for(const root of rootHints({kit,home,installRoot,env})) {
   stats.rootsChecked.push(root.name);
   onProgress(root.name);
   let files=[];
   try {files=walk(root.p,{maxDepth:root.name.startsWith('OneDrive')?7:root.name==='Temp'?5:11,maxFiles});}
   catch(e){
     if(['SCAN_LIMIT','EACCES','EPERM','ENOENT'].includes(e.code)){stats.skippedRoots++;continue;}
     throw e;
   }
   stats.scannedFiles+=files.length;
   const matched=checkFiles(files);
   if(matched)return matched;
 }
 throw Object.assign(new Error('Der erforderliche RC1.1-Runner ist in den untersuchten Ordnern nicht vorhanden. Er ist NICHT Teil dieses Reparaturpakets. Bitte das Original MCR_Ticket_Assistant_Beta5_RC1_1_STARTFIX_OFFLINE_UPLOAD.zip aus dem alten Chat auf den PC laden, dann QUELLE_AUSWAEHLEN.cmd verwenden.'),{code:'CANDIDATE_NOT_FOUND',stats});
}
