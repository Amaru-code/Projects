[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$ModeRoot = $PSScriptRoot
$SrcRoot = Join-Path $ModeRoot 'src'
$BuildRoot = Join-Path $ModeRoot 'build'
$Publish = Join-Path $BuildRoot 'publish'
$NodePointer = Join-Path $BuildRoot 'node_path.txt'

function Test-Node([string]$Path) {
    if ([string]::IsNullOrWhiteSpace($Path) -or -not (Test-Path $Path -PathType Leaf)) { return $false }
    $old=$ErrorActionPreference; $ErrorActionPreference='Continue'
    try { $v=& $Path --version 2>$null; $c=$LASTEXITCODE } finally { $ErrorActionPreference=$old }
    return ($c -eq 0 -and $v -match '^v\d+')
}

$NodeCandidates = New-Object System.Collections.Generic.List[string]
$cmd = Get-Command node.exe -ErrorAction SilentlyContinue
if ($cmd) { $NodeCandidates.Add($cmd.Source) }

if ($env:USERPROFILE) {
    foreach ($p in @(
        (Join-Path $env:USERPROFILE 'projects\Compiler\node\node.exe'),
        (Join-Path $env:USERPROFILE 'projects\Compiler\nodejs\node.exe'),
        (Join-Path $env:USERPROFILE 'projects\Compiler\javascript\node.exe'),
        (Join-Path $env:USERPROFILE 'projects\Compiler\javascript\tools\node\node.exe')
    )) {
        if ((Test-Path $p -PathType Leaf) -and -not $NodeCandidates.Contains($p)) { $NodeCandidates.Add($p) }
    }
    $compiler=Join-Path $env:USERPROFILE 'projects\Compiler'
    if(Test-Path $compiler){
        Get-ChildItem $compiler -Recurse -Filter node.exe -File -ErrorAction SilentlyContinue | ForEach-Object {
            if(-not $NodeCandidates.Contains($_.FullName)){ $NodeCandidates.Add($_.FullName) }
        }
    }
}

$Node=$null
foreach($c in $NodeCandidates){if(Test-Node $c){$Node=$c;break}}
if(-not $Node){throw 'Vorhandene Node.js Runtime wurde nicht gefunden. Es wird nichts heruntergeladen.'}

Write-Host '============================================================'
Write-Host ' Level 05A.2 - JavaScript Parity Build'
Write-Host '============================================================'
Write-Host "node:      $Node"
Write-Host "Node:      $(& $Node --version)"
Write-Host "Source:    $SrcRoot"
Write-Host "Publish:   $Publish"
Write-Host ''
Write-Host 'Dependencies: existing Node.js runtime only / OFFLINE'
Write-Host 'Transpiler during benchmark build: NONE'
Write-Host 'Native candidate EXE generation: NONE'
Write-Host ''

if(Test-Path $Publish){Remove-Item $Publish -Recurse -Force}
New-Item -ItemType Directory -Force -Path $Publish | Out-Null

$JsFiles=@(Get-ChildItem $SrcRoot -Filter '*.js' -File -ErrorAction Stop)
if($JsFiles.Count -eq 0){throw 'Keine JavaScript-Quelldateien gefunden.'}
foreach($f in $JsFiles){Copy-Item $f.FullName (Join-Path $Publish $f.Name) -Force}

New-Item -ItemType Directory -Force -Path (Join-Path $Publish 'resources') | Out-Null
Copy-Item (Join-Path $SrcRoot 'resources\settings.json') (Join-Path $Publish 'resources\settings.json') -Force
Copy-Item (Join-Path $SrcRoot 'resources\wwid_mapping.csv') (Join-Path $Publish 'resources\wwid_mapping.csv') -Force
Copy-Item (Join-Path $SrcRoot 'excel_bridge.ps1') (Join-Path $Publish 'excel_bridge.ps1') -Force

New-Item -ItemType Directory -Force -Path $BuildRoot | Out-Null
Set-Content $NodePointer $Node -Encoding UTF8

$Main=Join-Path $Publish 'main.js'
if(-not(Test-Path $Main -PathType Leaf)){throw "JavaScript Build erzeugte kein main.js: $Main"}

Write-Host ''
Write-Host 'JAVASCRIPT PARITY BUILD: PASS' -ForegroundColor Green
Write-Host "MAIN: $Main"
Write-Host 'Runtime: existing node.exe (no new native EXE)' -ForegroundColor Green
exit 0
