# Level 05A.2 – JavaScript Mode 1 Parity v0.1.0

Standalone JavaScript/CommonJS implementation of the frozen LNW DC pipeline.

Runtime contract:
- existing Node.js only
- no TypeScript compiler at benchmark build/run time
- no generated native candidate EXE
- no Python Oracle / C# / Rust worker

Build only copies frozen `.js` source/resources into `build/publish`.
