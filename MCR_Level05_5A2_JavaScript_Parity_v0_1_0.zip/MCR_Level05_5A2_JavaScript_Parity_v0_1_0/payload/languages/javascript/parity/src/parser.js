"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TextParser = void 0;
const util_1 = require("./util");
const parser_helpers_1 = require("./parser_helpers");
const MARKER_PREFIXES = [">>>>", "<<<<", ">>>", "<<<", "===="];
const METADATA_LABELS = new Set([
    "dateiname", "datei name", "info", "informationen", "groesse", "größe", "dateigroesse", "dateigröße", "typ", "dateityp", "erstellungsdatum", "erstellt am", "geaendert am", "geändert am", "aenderungsdatum", "änderungsdatum"
]);
const KNOWN_HEADER_TERMS = new Set([
    "erstellungsdatum", "vermittlerzentrale", "vermittlernummer", "kundenidentifikator", "kunden_identifikator", "depotnummer", "unterdepot", "wkn", "isin", "kag", "fondsname", "depotvariante", "anteilspreis", "waehrungpreis", "währungpreis", "produktart", "bestandstuecke", "bestand_stuecke", "bestandbetrag", "bestand_betrag", "firmenid", "dat", "wwid", "umsatzstuecke", "umsatz_stuecke", "abgerechneterpreis", "anlbetrag", "zahlbetrag", "umsatzart", "devisenkurs", "kursdatum", "zvf_id_alt", "zvu_id_alt", "eroeffnungsdatum", "währung_bestand", "waehrung_bestand", "schlusstag", "bonus", "status", "id-mercer"
]);
const DU_PROFILE_MARKERS = new Set(["umsatzstuecke", "abgerechneterpreis", "anlbetrag", "zahlbetrag", "umsatzart", "devisenkurs", "zvfidalt", "zvuidalt"]);
const DP_PROFILE_MARKERS = new Set(["anteilspreis", "eroeffnungsdatum", "bestandstuecke", "bestandbetrag", "waehrungbestand", "schlusstag", "idmercer"]);
class TextParser {
    constructor(settings, mapping) {
        this.settings = settings;
        this.mapping = mapping;
        this.allowedCompanyIds = new Set(settings.allowed_company_ids.map(x => this.normalizeCompanyId(x)));
    }
    parseFile(filePath) {
        const path = require("path");
        const content = readTextWithFallback(filePath);
        const rows = parseTextRows(content);
        return this.extractTable(rows, true, true, path.basename(filePath));
    }
    detectTargetProfile(sourceHeader, fallbackWidth, sourceName) {
        const fp = (0, util_1.profileFromFilename)(sourceName);
        if (fp)
            return fp;
        const normalized = new Set(sourceHeader.filter(x => x.trim()).map(util_1.normalizeHeader));
        let duScore = 0, dpScore = 0;
        for (const x of DU_PROFILE_MARKERS)
            if (normalized.has(x))
                duScore++;
        for (const x of DP_PROFILE_MARKERS)
            if (normalized.has(x))
                dpScore++;
        if (duScore >= 2 && duScore > dpScore)
            return "du";
        if (dpScore >= 2 && dpScore > duScore)
            return "dp";
        if (fallbackWidth >= 30)
            return "du";
        return "dp";
    }
    extractTable(rawRows, fixedTargetHeader, applyCompanyFilter, sourceName) {
        let rows = splitPackedRows(rawRows);
        rows = removeNoiseRows(rows);
        if (rows.length === 0) {
            if (!fixedTargetHeader)
                return { header: [], rows: [], sourceName };
            const profile = this.detectTargetProfile([], 0, sourceName);
            const header = (profile === "du" ? this.settings.du_target_headers : this.settings.dp_target_headers).slice();
            return { header, rows: [], sourceName };
        }
        let headerIndex = null;
        for (let i = 0; i < Math.min(30, rows.length); i++) {
            if (this.headerMatchScore(rows[i], null) >= 5 || this.looksLikeHeader(rows[i])) {
                headerIndex = i;
                break;
            }
        }
        const detectedSourceHeader = headerIndex !== null ? rows[headerIndex].slice() : [];
        let header;
        let dataRows;
        let sourceHeader;
        let sourceCompanyIndex;
        let targetCompanyIndex;
        let targetMapping;
        let width;
        if (fixedTargetHeader) {
            const sourceWidth = detectedSourceHeader.length ? detectedSourceHeader.length : Math.max(...rows.map(r => r.length));
            const profile = this.detectTargetProfile(detectedSourceHeader, sourceWidth, sourceName);
            header = (profile === "du" ? this.settings.du_target_headers : this.settings.dp_target_headers).slice();
            dataRows = rows.slice(headerIndex !== null ? headerIndex + 1 : 0);
            width = header.length;
            sourceHeader = detectedSourceHeader;
            sourceCompanyIndex = this.findCompanyIdColumn(sourceHeader, sourceHeader.length, false);
            targetCompanyIndex = this.findCompanyIdColumn(header, width, true);
            targetMapping = buildTargetMapping(sourceHeader, header);
        }
        else {
            if (headerIndex !== null) {
                header = makeUniqueHeaders(rows[headerIndex]);
                dataRows = rows.slice(headerIndex + 1);
                width = header.length;
            }
            else {
                width = Math.max(...rows.map(r => r.length));
                header = Array.from({ length: width }, (_, i) => `Feld_${String(i + 1).padStart(2, "0")}`);
                dataRows = rows;
            }
            sourceHeader = header.slice();
            sourceCompanyIndex = this.findCompanyIdColumn(sourceHeader, width, false);
            targetCompanyIndex = sourceCompanyIndex;
            targetMapping = null;
        }
        const normalizedHeader = header.map(util_1.normalizeHeader);
        const normalizedSourceHeader = sourceHeader.map(util_1.normalizeHeader);
        const cleanData = [];
        for (const row of dataRows) {
            if (isEmptyRow(row) || isMarkerRow(row) || isMetadataRow(row))
                continue;
            const fittedForHeader = normalizeRowWidth(row, Math.max(width, sourceHeader.length));
            const rowNorm = fittedForHeader.map(util_1.normalizeHeader);
            const targetOverlap = pairOverlap(rowNorm, normalizedHeader);
            const sourceOverlap = pairOverlap(rowNorm, normalizedSourceHeader);
            if (targetOverlap >= Math.max(4, Math.min(8, Math.floor(width / 3))) ||
                sourceOverlap >= Math.max(4, Math.min(8, Math.floor(Math.max(1, sourceHeader.length) / 3))) ||
                this.headerMatchScore(row, header) >= 5 ||
                (sourceHeader.length > 0 && this.headerMatchScore(row, sourceHeader) >= 5))
                continue;
            let companyId = null;
            if (applyCompanyFilter) {
                companyId = this.findAllowedCompanyId(row, [sourceCompanyIndex, this.settings.company_id_column_index]);
                if (companyId === null)
                    continue;
            }
            const fitted = mapRowToTarget(row, width, targetMapping);
            if (fixedTargetHeader) {
                const idxMap = new Map();
                header.forEach((h, i) => { const n = (0, util_1.normalizeHeader)(h); if (n)
                    idxMap.set(n, i); });
                const wwidIdx = idxMap.get("wwid");
                const depotIdx = idxMap.get("depotnummer");
                const underIdx = idxMap.get("unterdepot");
                if (wwidIdx !== undefined && depotIdx !== undefined) {
                    const existing = fitted[wwidIdx] ?? "";
                    const depot = fitted[depotIdx] ?? "";
                    const under = underIdx !== undefined ? (fitted[underIdx] ?? "") : "";
                    fitted[wwidIdx] = this.mapping.resolve(depot, under, existing);
                }
            }
            if (companyId !== null && targetCompanyIndex !== null && targetCompanyIndex < fitted.length)
                fitted[targetCompanyIndex] = companyId;
            if (fitted.some(x => x !== ""))
                cleanData.push(fitted);
        }
        return { header, rows: cleanData, sourceName };
    }
    findAllowedCompanyId(row, preferred) {
        const checked = new Set();
        for (const idx of preferred) {
            if (idx === null || idx < 0 || idx >= row.length || checked.has(idx))
                continue;
            checked.add(idx);
            const c = this.normalizeCompanyId(row[idx]);
            if (this.allowedCompanyIds.has(c))
                return c;
        }
        for (let i = 0; i < row.length; i++) {
            if (checked.has(i))
                continue;
            const c = this.normalizeCompanyId(row[i]);
            if (this.allowedCompanyIds.has(c))
                return c;
        }
        return null;
    }
    findCompanyIdColumn(header, width, fixed) {
        const norm = header.map(util_1.normalizeHeader);
        for (const c of ["firmenid", "companyid", "firmen_id", "company_id"]) {
            const i = norm.indexOf((0, util_1.normalizeHeader)(c));
            if (i >= 0)
                return i;
        }
        if (fixed && this.settings.company_id_column_index < width)
            return this.settings.company_id_column_index;
        return null;
    }
    normalizeCompanyId(value) { return (0, util_1.cleanCell)(value).toUpperCase(); }
    headerMatchScore(row, reference) {
        const rowNorm = new Set(row.filter(x => x.trim()).map(util_1.normalizeHeader));
        if (reference) {
            const refNorm = new Set(reference.filter(x => x.trim()).map(util_1.normalizeHeader));
            let n = 0;
            for (const x of refNorm)
                if (rowNorm.has(x))
                    n++;
            return n;
        }
        let du = 0, dp = 0;
        const duNorm = new Set(this.settings.du_target_headers.map(util_1.normalizeHeader));
        const dpNorm = new Set(this.settings.dp_target_headers.map(util_1.normalizeHeader));
        for (const x of rowNorm) {
            if (duNorm.has(x))
                du++;
            if (dpNorm.has(x))
                dp++;
        }
        return Math.max(du, dp);
    }
    looksLikeHeader(row) {
        const cells = row.map(util_1.cleanCell).filter(Boolean);
        if (cells.length < 4)
            return false;
        const normalized = new Set(cells.map(util_1.normalizeHeader));
        const known = new Set(Array.from(KNOWN_HEADER_TERMS).map(util_1.normalizeHeader));
        let hits = 0;
        for (const x of normalized)
            if (known.has(x))
                hits++;
        if (hits >= 3)
            return true;
        if (this.headerMatchScore(cells, null) >= 5)
            return true;
        const alphaCells = cells.filter(x => /[A-Za-zÄÖÜäöüß]/.test(x)).length;
        const numericCells = cells.filter(isNumericLike).length;
        const dateLikeFirst = /^\d{8}$/.test(cells[0]);
        if (dateLikeFirst || numericCells >= Math.max(3, Math.floor(cells.length / 3)))
            return false;
        return alphaCells >= Math.max(4, Math.floor(cells.length * 0.65));
    }
}
exports.TextParser = TextParser;
function buildTargetMapping(sourceHeader, targetHeader) {
    if (!sourceHeader.length)
        return null;
    const sourceIndex = new Map();
    sourceHeader.forEach((h, i) => { const n = (0, util_1.normalizeHeader)(h); if (n && !sourceIndex.has(n))
        sourceIndex.set(n, i); });
    const targetNorm = targetHeader.map(util_1.normalizeHeader);
    const overlap = targetNorm.filter(n => n && sourceIndex.has(n)).length;
    if (overlap < Math.max(5, Math.floor(targetNorm.length * 0.35)))
        return null;
    return targetNorm.map((n, i) => sourceIndex.has(n) ? sourceIndex.get(n) : (i < sourceHeader.length ? i : null));
}
function mapRowToTarget(row, targetWidth, mapping) {
    if (!mapping)
        return normalizeRowWidth(row, targetWidth);
    return Array.from({ length: targetWidth }, (_, i) => {
        const s = i < mapping.length ? mapping[i] : null;
        return s !== null && s >= 0 && s < row.length ? (0, util_1.cleanCell)(row[s]) : "";
    });
}
function pairOverlap(a, b) { let n = 0; for (let i = 0; i < Math.min(a.length, b.length); i++)
    if (a[i] && a[i] === b[i])
        n++; return n; }
function makeUniqueHeaders(headers) {
    const counts = new Map();
    return headers.map((h, i) => {
        let name = (0, util_1.cleanCell)(h);
        if (!name)
            name = `Feld_${String(i + 1).padStart(2, "0")}`;
        const c = (counts.get(name) ?? 0) + 1;
        counts.set(name, c);
        return c > 1 ? `${name}_${c}` : name;
    });
}
function trimTrailingEmpty(row) { const v = row.map(util_1.cleanCell); while (v.length && !v[v.length - 1])
    v.pop(); return v; }
function removeNoiseRows(rows) { return rows.map(trimTrailingEmpty).filter(r => r.length && !isMarkerRow(r) && !isMetadataRow(r)); }
function splitPackedRows(rows) {
    return rows.map(r => {
        const c = trimTrailingEmpty(r);
        const nonempty = c.filter(Boolean);
        if (nonempty.length === 1 && (nonempty[0].match(/;/g) ?? []).length >= 3)
            return (0, parser_helpers_1.parseDelimitedLine)(nonempty[0], ";").map(util_1.cleanCell);
        return c;
    });
}
function normalizeRowWidth(row, width) { return Array.from({ length: width }, (_, i) => i < row.length ? (0, util_1.cleanCell)(row[i]) : ""); }
function isEmptyRow(row) { return !row.some(x => (0, util_1.cleanCell)(x) !== ""); }
function firstNonempty(row) { return row.map(util_1.cleanCell).find(Boolean) ?? ""; }
function isMarkerRow(row) { const f = firstNonempty(row).trimStart(); return !!f && MARKER_PREFIXES.some(p => f.startsWith(p)); }
function isMetadataRow(row) { const c = row.map(util_1.cleanCell).filter(Boolean); if (!c.length || c.length > 3)
    return false; return METADATA_LABELS.has(c[0].toLowerCase().trim().replace(/:$/, "")); }
function isNumericLike(value) { return /^[-+]?\d+(?:[.,]\d+)?$/.test(value.trim()) || /^\d{6,14}$/.test(value.trim()) || /^[A-Z]{2}\d{9,12}$/.test(value.trim()); }
function detectSeparator(content) {
    const lines = content.replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n").filter(x => x.trim()).slice(0, 20);
    if (!lines.length)
        return null;
    const candidates = [";", "\t", "|", ","];
    let best = null, bestScore = 0;
    for (const c of candidates) {
        const score = lines.reduce((s, l) => s + countOutsideQuotes(l, c), 0);
        if (score > bestScore) {
            best = c;
            bestScore = score;
        }
    }
    return bestScore > 0 ? best : null;
}
function countOutsideQuotes(line, delimiter) { let quoted = false, count = 0; for (let i = 0; i < line.length; i++) {
    if (line[i] === '"') {
        if (quoted && i + 1 < line.length && line[i + 1] === '"')
            i++;
        else
            quoted = !quoted;
    }
    else if (line[i] === delimiter && !quoted)
        count++;
} return count; }
function parseTextRows(content) {
    const sep = detectSeparator(content);
    const lines = content.replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n");
    const rows = [];
    for (const raw of lines) {
        if (!raw.trim())
            continue;
        const row = sep ? (0, parser_helpers_1.parseDelimitedLine)(raw, sep) : [raw.trim()];
        const cleaned = row.map(util_1.cleanCell);
        if (cleaned.some(Boolean))
            rows.push(cleaned);
    }
    return rows;
}
function readTextWithFallback(path) {
    const fs = require("fs"), util = require("util");
    const bytes = fs.readFileSync(path);
    let body = bytes;
    if (bytes.length >= 3 && bytes[0] === 0xEF && bytes[1] === 0xBB && bytes[2] === 0xBF)
        body = bytes.subarray(3);
    try {
        const dec = new util.TextDecoder("utf-8", { fatal: true });
        return dec.decode(body);
    }
    catch {
        return decodeCp1252(body);
    }
}
function decodeCp1252(bytes) {
    const map = ["€", "\u0081", "‚", "ƒ", "„", "…", "†", "‡", "ˆ", "‰", "Š", "‹", "Œ", "\u008D", "Ž", "\u008F", "\u0090", "‘", "’", "“", "”", "•", "–", "—", "˜", "™", "š", "›", "œ", "\u009D", "ž", "Ÿ"];
    let out = "";
    for (const b of bytes) {
        if (b <= 0x7F)
            out += String.fromCharCode(b);
        else if (b <= 0x9F)
            out += map[b - 0x80];
        else
            out += String.fromCharCode(b);
    }
    return out;
}
