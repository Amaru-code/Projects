"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Pipeline = void 0;
const util_1 = require("./util");
const xlsx_1 = require("./xlsx");
const lnw_1 = require("./lnw");
const fs = require("fs");
const pathMod = require("path");
class Pipeline {
    constructor(parser) {
        this.parser = parser;
    }
    run(options) {
        if (!fs.existsSync(options.inputDir) || !fs.statSync(options.inputDir).isDirectory())
            throw new Error(`Input directory missing: ${options.inputDir}`);
        if (!fs.existsSync(options.templatePath) || !fs.statSync(options.templatePath).isFile())
            throw new Error(`Template missing: ${options.templatePath}`);
        fs.mkdirSync(options.outputDir, { recursive: true });
        const work = pathMod.join(options.outputDir, "work"), convertRoot = pathMod.join(work, "01_convert_merge"), duConverted = pathMod.join(convertRoot, "DU"), dpConverted = pathMod.join(convertRoot, "DP"), lnwDir = pathMod.join(work, "02_LNW");
        [duConverted, dpConverted, lnwDir].forEach((p) => fs.mkdirSync(p, { recursive: true }));
        const files = [];
        enumerateFiles(options.inputDir, files);
        const filtered = files.filter(p => !pathMod.basename(p).startsWith("~$"));
        const duFiles = filtered.filter(p => (0, util_1.profileFromFilename)(pathMod.basename(p)) === "du").sort(ciNameSort);
        const dpAll = filtered.filter(p => (0, util_1.profileFromFilename)(pathMod.basename(p)) === "dp").sort(ciNameSort);
        console.log(`Quelldateien erkannt: ${duFiles.length} DU | ${dpAll.length} DP | ${filtered.length - duFiles.length - dpAll.length} ignoriert`);
        if (!duFiles.length)
            throw new Error("No DU raw files found.");
        if (!dpAll.length)
            throw new Error("No DP raw files found.");
        const dpFiles = selectDp(dpAll);
        const duMaster = pathMod.join(options.outputDir, "DU_MASTER.xlsx"), dpMaster = pathMod.join(options.outputDir, "DP_MASTER.xlsx");
        const du = this.convertAndMerge("du", duFiles, duConverted, duMaster, options.workers);
        const dp = this.convertAndMerge("dp", dpFiles, dpConverted, dpMaster, options.workers);
        const ext = pathMod.extname(options.templatePath) || ".xlsm", lnwExcel = pathMod.join(options.outputDir, "LNW_Output" + ext), lnwCsv = pathMod.join(options.outputDir, "LNW_Output.csv");
        console.log("[LNW] DU- und DP-Master werden an die JavaScript LNW-Engine uebergeben ...");
        (0, lnw_1.runLnw)(options.templatePath, du.table, dp.table, lnwExcel, lnwCsv, lnwDir);
        return { duMaster, dpMaster, lnwExcel, lnwCsv, duRows: du.table.rows.length, dpRows: dp.table.rows.length };
    }
    convertAndMerge(profile, sourceFiles, convertedDir, masterPath, workers) {
        const label = profile.toUpperCase();
        console.log(`[${label}] ${sourceFiles.length} Rohdatei(en) werden konvertiert und zusammengefuehrt ...`);
        fs.mkdirSync(convertedDir, { recursive: true });
        const reservations = reserveOutputPaths(sourceFiles, convertedDir);
        const results = new Map();
        const errors = [];
        let completed = 0;
        // Correctness-first JavaScript implementation. Conversion is intentionally
        // sequential in v0.1.0; Mode-1 performance optimization happens only after parity.
        for (const source of sourceFiles) {
            try {
                const table = this.parser.parseFile(source);
                (0, xlsx_1.writeXlsx)(reservations.get(source), "Ziel 1", table.header, table.rows);
                results.set(source, table);
                completed++;
                console.log(`[${label}] ${completed}/${sourceFiles.length} | ${pathMod.basename(source)} | Datei abgeschlossen`);
            }
            catch (e) {
                completed++;
                errors.push(`${pathMod.basename(source)}: ${e?.message ?? e}`);
                console.log(`[${label}] ${completed}/${sourceFiles.length} | ${pathMod.basename(source)} | FEHLER: ${e?.message ?? e}`);
            }
        }
        const successful = sourceFiles.filter(s => results.has(s));
        if (!successful.length)
            throw new Error(`No ${label} source could be converted.\n` + errors.slice(0, 20).join("\n"));
        console.log(`[${label}] Konvertierung fertig. ${successful.length} Datei(en) werden zum Master zusammengefuehrt ...`);
        const header = results.get(successful[0]).header.slice();
        const merged = [];
        let pos = 0;
        for (const source of successful) {
            pos++;
            const table = results.get(source);
            try {
                merged.push(...alignRows(table, header));
                console.log(`[${label}] Merge ${pos}/${successful.length + 1} | ${pathMod.basename(reservations.get(source))} | Datei abgeschlossen | ${merged.length} Zeilen`);
            }
            catch (e) {
                errors.push(`${pathMod.basename(reservations.get(source))}: ${e?.message ?? e}`);
                console.log(`[${label}] Merge ${pos}/${successful.length + 1} | ${pathMod.basename(reservations.get(source))} | FEHLER: ${e?.message ?? e} | ${merged.length} Zeilen`);
            }
        }
        (0, xlsx_1.writeXlsx)(masterPath, "Gesamtdaten", header, merged);
        console.log(`[${label}] Merge ${successful.length + 1}/${successful.length + 1} | ${pathMod.basename(masterPath)} | Masterdatei gespeichert | ${merged.length} Zeilen`);
        console.log(`[${label}] Master fertig: ${pathMod.basename(masterPath)} | ${merged.length} Datenzeilen`);
        return { table: { header, rows: merged, sourceName: masterPath }, errors };
    }
}
exports.Pipeline = Pipeline;
function enumerateFiles(dir, out) { for (const name of fs.readdirSync(dir)) {
    const p = pathMod.join(dir, name);
    const st = fs.statSync(p);
    if (st.isDirectory())
        enumerateFiles(p, out);
    else if (st.isFile())
        out.push(p);
} }
function ciNameSort(a, b) { const aa = pathMod.basename(a).toLowerCase(), bb = pathMod.basename(b).toLowerCase(); return aa < bb ? -1 : aa > bb ? 1 : 0; }
function selectDp(files) { if (files.length <= 1)
    return files.slice(); const sorted = files.slice().sort((a, b) => filenameDate(a) - filenameDate(b) || ciNameSort(a, b)); console.log(`[DP] ${files.length} DP-Dateien erkannt. Verwendet wird ${pathMod.basename(sorted[0])}.`); return [sorted[0]]; }
function filenameDate(filePath) { const stem = pathMod.parse(filePath).name; const re = /(?<!\d)(20\d{6})(?!\d)/g; const vals = []; let m; while ((m = re.exec(stem)) !== null)
    vals.push(Number(m[1])); return vals.length ? vals[vals.length - 1] : 99999999; }
function reserveOutputPaths(sourceFiles, outputDir) { const used = new Set(), map = new Map(); for (const source of sourceFiles) {
    const stem = pathMod.parse(source).name || pathMod.basename(source);
    let candidate = pathMod.join(outputDir, stem + ".xlsx"), counter = 1;
    while (used.has(candidate.toLowerCase()))
        candidate = pathMod.join(outputDir, `${stem}_${counter++}.xlsx`);
    used.add(candidate.toLowerCase());
    map.set(source, candidate);
} return map; }
function alignRows(source, masterHeader) { const sourceNorm = source.header.map(util_1.normalizeHeader), masterNorm = masterHeader.map(util_1.normalizeHeader); if (sourceNorm.length === masterNorm.length && sourceNorm.every((x, i) => x === masterNorm[i]))
    return source.rows.map(r => r.slice()); const sourceIndex = new Map(); sourceNorm.forEach((n, i) => { if (n)
    sourceIndex.set(n, i); }); const common = masterNorm.filter(n => sourceIndex.has(n)).length; if (common < Math.max(4, Math.floor(masterNorm.length * 0.60)))
    throw new Error("Header weicht zu stark von den übrigen Dateien ab."); return source.rows.map(row => masterNorm.map(n => { const i = sourceIndex.get(n); return i !== undefined && i < row.length ? row[i] : ""; })); }
