"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.writeXlsx = writeXlsx;
const util_1 = require("./util");
const fs = require("fs");
const pathMod = require("path");
function crc32(buf) {
    let crc = 0xFFFFFFFF;
    for (let i = 0; i < buf.length; i++) {
        crc ^= buf[i];
        for (let j = 0; j < 8; j++)
            crc = (crc & 1) ? ((crc >>> 1) ^ 0xEDB88320) : (crc >>> 1);
    }
    return (~crc) >>> 0;
}
function u16(v) { const b = Buffer.alloc(2); b.writeUInt16LE(v & 0xFFFF, 0); return b; }
function u32(v) { const b = Buffer.alloc(4); b.writeUInt32LE(v >>> 0, 0); return b; }
function writeStoreZip(filePath, files) {
    const parent = pathMod.dirname(filePath);
    fs.mkdirSync(parent, { recursive: true });
    const parts = [];
    const entries = [];
    let offset = 0;
    for (const [name, data] of files) {
        const nameb = Buffer.from(name, "utf8");
        const crc = crc32(data);
        const size = data.length;
        const local = Buffer.concat([u32(0x04034b50), u16(20), u16(0), u16(0), u16(0), u16(0x0021), u32(crc), u32(size), u32(size), u16(nameb.length), u16(0), nameb, data]);
        parts.push(local);
        entries.push({ name, crc32: crc, size, offset });
        offset += local.length;
    }
    const centralStart = offset;
    for (const e of entries) {
        const nameb = Buffer.from(e.name, "utf8");
        const c = Buffer.concat([u32(0x02014b50), u16(20), u16(20), u16(0), u16(0), u16(0), u16(0x0021), u32(e.crc32), u32(e.size), u32(e.size), u16(nameb.length), u16(0), u16(0), u16(0), u16(0), u32(0), u32(e.offset), nameb]);
        parts.push(c);
        offset += c.length;
    }
    const centralSize = offset - centralStart;
    parts.push(Buffer.concat([u32(0x06054b50), u16(0), u16(0), u16(entries.length), u16(entries.length), u32(centralSize), u32(centralStart), u16(0)]));
    fs.writeFileSync(filePath, Buffer.concat(parts));
}
function columnName(col) { let s = ""; while (col > 0) {
    col--;
    s = String.fromCharCode(65 + (col % 26)) + s;
    col = Math.floor(col / 26);
} return s; }
function worksheetXml(header, rows) {
    let s = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>';
    const writeRow = (rnum, values) => { s += `<row r="${rnum}">`; for (let i = 0; i < values.length; i++) {
        const value = values[i] ?? "";
        if (!value)
            continue;
        const cref = `${columnName(i + 1)}${rnum}`;
        s += `<c r="${cref}" t="inlineStr"><is><t`;
        if (/^\s|\s$/.test(value))
            s += ' xml:space="preserve"';
        s += '>' + (0, util_1.xmlEscape)(value) + '</t></is></c>';
    } s += '</row>'; };
    writeRow(1, header);
    rows.forEach((r, i) => writeRow(i + 2, r));
    s += '</sheetData></worksheet>';
    return s;
}
function writeXlsx(filePath, sheetName, header, rows) {
    const contentTypes = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>';
    const rootRels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>';
    const workbook = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="${(0, util_1.xmlEscape)(sheetName)}" sheetId="1" r:id="rId1"/></sheets></workbook>`;
    const workbookRels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>';
    const sheet = worksheetXml(header, rows);
    writeStoreZip(filePath, [
        ["[Content_Types].xml", Buffer.from(contentTypes, "utf8")],
        ["_rels/.rels", Buffer.from(rootRels, "utf8")],
        ["xl/workbook.xml", Buffer.from(workbook, "utf8")],
        ["xl/_rels/workbook.xml.rels", Buffer.from(workbookRels, "utf8")],
        ["xl/worksheets/sheet1.xml", Buffer.from(sheet, "utf8")],
    ]);
}
