"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mapping_1 = require("./mapping");
const parser_1 = require("./parser");
const pipeline_1 = require("./pipeline");
const fs = require("fs"), pathMod = require("path");
function parseArgs() {
    const args = process.argv.slice(2), map = new Map();
    for (let i = 0; i < args.length; i++) {
        const k = args[i];
        if (!k.startsWith("--"))
            throw new Error(`Unexpected argument: ${k}`);
        if (i + 1 >= args.length)
            throw new Error(`Missing value for ${k}`);
        map.set(k.toLowerCase(), args[++i]);
    }
    const need = (k) => { const v = map.get(k); if (!v || !v.trim())
        throw new Error(`Required argument missing: ${k}`); return v; };
    const workers = Math.max(1, Number(map.get("--workers") ?? "4") || 4);
    return { caseId: map.get("--case") ?? "MCR_LNW_001", inputDir: pathMod.resolve(need("--input")), templatePath: pathMod.resolve(need("--template")), outputDir: pathMod.resolve(need("--output")), workers };
}
function main() {
    try {
        const options = parseArgs();
        if (options.caseId !== "MCR_LNW_001")
            throw new Error("This candidate is frozen to case MCR_LNW_001.");
        const settingsPath = pathMod.join(__dirname, "resources", "settings.json"), mappingPath = pathMod.join(__dirname, "resources", "wwid_mapping.csv");
        if (!fs.existsSync(settingsPath) || !fs.existsSync(mappingPath))
            throw new Error("Candidate resources are missing from build output.");
        console.log("=".repeat(72));
        console.log("MCR LEVEL 05A.2 - JAVASCRIPT MODE 1 PARITY CANDIDATE");
        console.log("=".repeat(72));
        console.log(`Case:    ${options.caseId}`);
        console.log(`Input:   ${options.inputDir}`);
        console.log(`Template:${options.templatePath}`);
        console.log(`Output:  ${options.outputDir}`);
        console.log(`Workers: ${options.workers}`);
        console.log();
        fs.mkdirSync(options.outputDir, { recursive: true });
        const settings = JSON.parse(fs.readFileSync(settingsPath, "utf8"));
        const mapping = mapping_1.WwidMapping.load(mappingPath);
        const parser = new parser_1.TextParser(settings, mapping);
        const result = new pipeline_1.Pipeline(parser).run(options);
        const candidate = { schema: "mcr.level05.candidate-result.v1", status: "success", case: options.caseId, language: "javascript", mode: "parity", artifacts: { du_master: pathMod.basename(result.duMaster), dp_master: pathMod.basename(result.dpMaster), lnw_excel: pathMod.basename(result.lnwExcel), lnw_csv: pathMod.basename(result.lnwCsv) }, diagnostics: { du_master_rows: result.duRows, dp_master_rows: result.dpRows, workers: options.workers, runtime: process.version } };
        fs.writeFileSync(pathMod.join(options.outputDir, "candidate_result.json"), JSON.stringify(candidate, null, 2), "utf8");
        console.log();
        console.log("JavaScript candidate completed successfully.");
        console.log(`DU Master Rows: ${result.duRows}`);
        console.log(`DP Master Rows: ${result.dpRows}`);
        console.log("candidate_result.json written.");
        return 0;
    }
    catch (e) {
        console.error();
        console.error("JAVASCRIPT CANDIDATE FAILED");
        console.error(e?.stack ?? e);
        return 1;
    }
}
process.exitCode = main();
