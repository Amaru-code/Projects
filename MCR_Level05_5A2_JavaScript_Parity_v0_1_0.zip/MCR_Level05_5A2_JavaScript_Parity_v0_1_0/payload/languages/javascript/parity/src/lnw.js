"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.runLnw = runLnw;
const util_1 = require("./util");
const fs = require("fs");
const pathMod = require("path");
const cp = require("child_process");
function at(row, idx) { return idx >= 0 && idx < row.length ? row[idx] : ""; }
function duKey(wwid, fund, movement) { return `${wwid}\u0000${fund}\u0000${movement}`; }
function dpKey(wwid, fund) { return `${wwid}\u0000${fund}`; }
function aggregateDu(table, investmentValue) {
    const map = (0, util_1.headerMap)(table.header);
    const wwidIdx = (0, util_1.findIndex)(map, ["WWID"]);
    const fundIdx = (0, util_1.findIndex)(map, ["Fondsname", "Fonds Name"]);
    const movementIdx = (0, util_1.findIndex)(map, ["Umsatzart", "Umsatz Art"]);
    const sharesIdx = (0, util_1.findIndex)(map, ["UmsatzStuecke", "Umsatzstücke", "Umsatz Stücke"]);
    const valueIdx = investmentValue ? (0, util_1.findIndex)(map, ["Anlbetrag", "AnlBetrag", "Anl Betrag", "Anlagebetrag"]) : (0, util_1.findIndex)(map, ["ZahlBetrag", "Zahlbetrag", "Zahl Betrag"]);
    const out = new Map();
    for (const row of table.rows) {
        const wwid = (0, util_1.normalizeWwid)(at(row, wwidIdx));
        const fund = (0, util_1.normalizeFund)(at(row, fundIdx));
        const movement = (0, util_1.normalizeText)(at(row, movementIdx));
        if (!wwid || !fund || !movement)
            continue;
        const k = duKey(wwid, fund, movement);
        const cur = out.get(k) ?? { shares: 0, value: 0 };
        cur.shares += (0, util_1.asNumber)(at(row, sharesIdx));
        cur.value += (0, util_1.asNumber)(at(row, valueIdx));
        out.set(k, cur);
    }
    return out;
}
function aggregateDp(table) {
    const map = (0, util_1.headerMap)(table.header);
    const wwidIdx = (0, util_1.findIndex)(map, ["WWID"]);
    const fundIdx = (0, util_1.findIndex)(map, ["Fondsname", "Fonds Name"]);
    const sharesIdx = (0, util_1.findIndex)(map, ["Bestand_Stuecke", "BestandStuecke", "Bestand Stücke", "Bestand_Stücke", "Bestandstücke"]);
    const valueIdx = (0, util_1.findIndex)(map, ["Bestand_Betrag", "BestandBetrag", "Bestand Betrag"]);
    const out = new Map();
    for (const row of table.rows) {
        const wwid = (0, util_1.normalizeWwid)(at(row, wwidIdx));
        const fund = (0, util_1.normalizeFund)(at(row, fundIdx));
        if (!wwid || !fund)
            continue;
        const k = dpKey(wwid, fund);
        const cur = out.get(k) ?? { shares: 0, value: 0 };
        cur.shares += (0, util_1.asNumber)(at(row, sharesIdx));
        cur.value += (0, util_1.asNumber)(at(row, valueIdx));
        out.set(k, cur);
    }
    return out;
}
function bridgePath() { const p = pathMod.join(__dirname, "excel_bridge.ps1"); if (!fs.existsSync(p))
    throw new Error(`Excel bridge missing: ${p}`); return p; }
function runBridge(args) {
    const full = ["-NoProfile", "-ExecutionPolicy", "Bypass", "-File", bridgePath(), ...args];
    const r = cp.spawnSync("powershell.exe", full, { stdio: "inherit", windowsHide: true });
    if (r.error)
        throw new Error(`Excel bridge could not start: ${r.error.message}`);
    if (r.status !== 0)
        throw new Error(`Excel bridge failed with exit code ${r.status}`);
}
function parseSnapshot(filePath) {
    const text = fs.readFileSync(filePath, "utf8");
    let headerRow = 0, lastRow = 0;
    const rows = [];
    for (const line of text.split(/\r?\n/)) {
        if (!line)
            continue;
        const p = line.split("\t");
        if (p[0] === "META" && p.length >= 4) {
            headerRow = Number(p[1]);
            lastRow = Number(p[3]);
        }
        else if (p[0] === "ROW" && p.length >= 13) {
            rows.push({ row: Number(p[1]), wwid: (0, util_1.normalizeWwid)(p[2]), prev: p.slice(3, 13).map((x) => Number(x) || 0) });
        }
    }
    if (!headerRow || lastRow <= headerRow)
        throw new Error("Snapshot metadata invalid");
    return { headerRow, lastRow, rows };
}
function numberText(v) { return Number.isFinite(v) ? String(v) : "0"; }
function runLnw(templatePath, du, dp, outputExcel, outputCsv, workDir) {
    fs.mkdirSync(workDir, { recursive: true });
    fs.copyFileSync(templatePath, outputExcel);
    const snapshotPath = pathMod.join(workDir, "excel_snapshot.tsv");
    const planPath = pathMod.join(workDir, "excel_plan.tsv");
    console.log("[LNW] Output-Template wird ueber Microsoft Excel geoeffnet ...");
    runBridge(["-Mode", "Snapshot", "-Workbook", outputExcel, "-SnapshotPath", snapshotPath]);
    const snap = parseSnapshot(snapshotPath);
    console.log(`[LNW] Zielblatt erkannt: WWID-Header Zeile ${snap.headerRow}, letzte WWID-Zeile ${snap.lastRow}.`);
    console.log("[LNW] DU wird nach WWID, Fonds und Umsatzart aggregiert ...");
    const duAgg = aggregateDu(du, false);
    const purchaseAgg = aggregateDu(du, true);
    console.log("[LNW] DP wird nach WWID und Fonds aggregiert ...");
    const dpAgg = aggregateDp(dp);
    const lines = [`META\t${snap.headerRow + 1}\t${snap.lastRow}`];
    const set = (addr, val) => lines.push(`SET\t${addr}\t${numberText(val)}`);
    const prevToCurrent = [["AJ", 0], ["AK", 1], ["AL", 2], ["AM", 3], ["AN", 4], ["AO", 5], ["AP", 6], ["AQ", 7], ["AR", 8], ["AS", 9]];
    const purchaseMaps = [["DWS EURORENTA", "AV", "AW"], ["DWS INS.-ESG EO MO.M.IC", "AY", "AZ"], ["DWSI-EUR.EQ.HI.CO.FC", "BB", "BC"]];
    const funds = [
        ["DWSI-EUR.EQ.HI.CO.FC", "CL", "CM", "BI", "BJ"], ["DWS EURORENTA", "CN", "CO", "BK", "BL"], ["DWS INS.-ESG EO MO.M.IC", "CP", "CQ", "BM", "BN"], ["SIEMENS EUROINVEST AKTIEN", "CR", "CS", null, null], ["SIEMENS EUROINVEST RENTEN", "CT", "CU", null, null]
    ];
    const purchaseMovement = (0, util_1.normalizeText)("Kauf"), reallocMovement = (0, util_1.normalizeText)("Fondsportfolioanpassung"), distFund = (0, util_1.normalizeFund)("DWS EURORENTA");
    console.log("[LNW] Schreibplan fuer AJ:CU wird erzeugt ...");
    for (const s of snap.rows) {
        if (!s.wwid)
            continue;
        for (const [col, i] of prevToCurrent)
            set(`${col}${s.row}`, s.prev[i] ?? 0);
        for (const [fund, sc, vc] of purchaseMaps) {
            const v = purchaseAgg.get(duKey(s.wwid, (0, util_1.normalizeFund)(fund), purchaseMovement)) ?? { shares: 0, value: 0 };
            set(`${sc}${s.row}`, v.shares);
            set(`${vc}${s.row}`, v.value);
        }
        let ds = 0, dv = 0;
        for (const [k, v] of duAgg.entries()) {
            const [w, f, m] = k.split("\u0000");
            if (w === s.wwid && f === distFund && (0, util_1.isDistribution)(m)) {
                ds += v.shares;
                dv += v.value;
            }
        }
        set(`BF${s.row}`, ds);
        set(`BG${s.row}`, dv);
        for (const [fund, endS, endV, rs, rv] of funds) {
            const f = (0, util_1.normalizeFund)(fund);
            if (rs && rv) {
                const v = duAgg.get(duKey(s.wwid, f, reallocMovement)) ?? { shares: 0, value: 0 };
                set(`${rs}${s.row}`, v.shares);
                set(`${rv}${s.row}`, v.value);
            }
            const d = dpAgg.get(dpKey(s.wwid, f)) ?? { shares: 0, value: 0 };
            set(`${endS}${s.row}`, d.shares);
            set(`${endV}${s.row}`, d.value);
        }
    }
    fs.writeFileSync(planPath, lines.join("\r\n") + "\r\n", "utf8");
    console.log("[LNW] Konstanten werden geloescht, Werte geschrieben und Excel neu berechnet ...");
    runBridge(["-Mode", "Apply", "-Workbook", outputExcel, "-PlanPath", planPath, "-CsvPath", outputCsv]);
    console.log("[LNW] Verarbeitung erfolgreich abgeschlossen.");
}
