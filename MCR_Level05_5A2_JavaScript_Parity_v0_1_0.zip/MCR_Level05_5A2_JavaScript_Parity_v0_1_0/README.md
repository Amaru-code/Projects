# MCR Level 05A.2 – JavaScript Mode 1 Parity v0.1.0

Standalone JavaScript candidate using the already installed Node.js runtime.
No TypeScript compiler is invoked by the benchmark package and no native
candidate EXE is generated.

Run `START_5A2_JAVASCRIPT.ps1`.
