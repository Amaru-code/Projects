# Level 05A.2 – R Mode 1 Parity v0.1.0

Independent base-R implementation of the frozen LNW DC pipeline.

- existing `Rscript.exe`
- base/recommended R only; no external R packages
- no generated native candidate EXE
- no Python/C#/Rust/Node/Ruby/Julia/Java worker
- DU/DP parsing, company filtering, WWID mapping, merge and LNW aggregation in R
- PowerShell/.NET is used only as a workbook-I/O bridge for XLSX serialization and Excel COM recalculation/CSV output

The converted DU/DP files and both masters are materialized as XLSX files using a minimal OOXML writer in the I/O bridge; business rules remain in R.


## v0.1.1

Runtime bootstrap fix.

If no `Rscript.exe` is installed, the build now downloads the portable Windows
R 4.6.1 ZIP from Posit's R builds CDN and extracts it under:

`~/projects/Compiler/r/tools/R-4.6.1`

No installer is executed, no registry entries are required, and no new native
candidate executable is compiled. The benchmark still executes `main.R` through
the prebuilt `Rscript.exe` runtime and uses only base/recommended R.


## v0.1.2

Portable R runtime-detection fix.

The v0.1.1 bootstrap successfully downloaded and extracted R 4.6.1, but its
runtime test accepted only banners containing `R scripting front-end` or the
literal contiguous text `R version`. Some Windows R builds report
`Rscript (R) version ...`, which caused a false negative even when
`Rscript.exe --version` succeeded.

v0.1.2 accepts the normal R/Rscript version-banner variants and additionally
prints the direct exit code/banner if a genuine runtime launch failure occurs.

No R business logic, benchmark data, Golden Reference, validator, or output
contract changed.


## v0.1.4

Windows PowerShell 5.1 BOM fix for the temporary R source-check script.

The R 4.6.1 runtime itself is healthy and `main.R` is already plain UTF-8
without BOM. The failure came from `_source_check.R`: Windows PowerShell 5.1
writes `Set-Content -Encoding UTF8` with a UTF-8 BOM, and this R build rejected
that BOM as an unexpected input character.

v0.1.4 writes the tiny ASCII-only checker as ASCII (and the runtime pointer as
ASCII). No R business logic, benchmark data, Golden Reference, validator,
Excel bridge, or output contract changed.


## v0.1.5 – parser performance architecture fix

The first complete R execution attempt proved the implementation was
functionally progressing, but the DU parser was far too slow: it processed
every input line character-by-character in interpreted R and repeatedly
concatenated strings with `paste0`.

v0.1.5 replaces the normal delimited-text path with native R parsing:

- `utils::count.fields()` determines row width.
- `utils::read.table(..., colClasses="character")` performs quote-aware parsing.
- cell cleanup is vectorized over a character matrix.
- the previous parser remains as a fail-safe fallback for malformed edge cases.
- `parse_delimited_line()` also has a native `strsplit()` fast path when no
  quotes are present.

No business rules, company filter, WWID mapping, merge semantics, LNW logic,
Golden Reference, validator, Excel bridge, or output contract changed.


## v0.1.6 – full-run performance + TSV robustness

The v0.1.5 run proved that R reached all 252 DU inputs but still spent about
79 minutes before failing on the first empty intermediate TSV/XLSX conversion.

v0.1.6 changes architecture without changing business semantics:

1. **Early vectorized company filtering**: raw files are read into a character
   matrix, company-ID rows are selected in vectorized/native R code, and only
   the tiny retained subset enters expensive row-by-row normalization and WWID
   mapping.
2. **No 252 intermediate XLSX files**: conversion and merge remain logically
   separate but the converted tables stay in memory; only the validated
   `DU_MASTER.xlsx` and `DP_MASTER.xlsx` are materialized.
3. **Legacy parser fallback** remains active for malformed edge cases.
4. **25-file performance guard** aborts automatically if the optimized parser
   still projects an excessive runtime (>5 s/file after 25 files).
5. **Zero-row TSV headers** are parsed directly in PowerShell, fixing the
   `Could not parse TSV header` failure.
6. The build preflight no longer prints the entire parsed R expression.

Golden Reference, company rules, WWID mapping, merge alignment, LNW logic,
Excel recalculation and validator contracts are unchanged.
