import fs from 'node:fs';import path from 'node:path';import os from 'node:os';import {fileURLToPath} from 'node:url';import {spawn} from 'node:child_process';import readline from 'node:readline/promises';
import {sha256,requireThat as need} from '../lib/core.mjs';import {applyEnterApproval} from '../lib/operator-enter.mjs';import {VERSION,stamp,plainPath,readJSON,writeJSON,controlDir,lock,ledger,runState,assertNoReview,processAlive,assertNoMigrationPriority} from '../lib/control.mjs';import {loadActiveMapping} from '../lib/active-mapping.mjs';import {resolveConfig} from '../lib/config.mjs';import {verifyPackage,verifyPrevious} from './integrity.mjs';import {planInstall,installSoftware,journals,restoreSoftware} from './deploy.mjs';import {windowsIdle} from './process-guard.mjs';import {certifyDemo,certifyPrefixDemo,certifyForwardDemo,certifyManualNameDemo,certifyPilot,certifyForwardWithoutEmail} from './proof.mjs';
import {beginMigrationPriority,recoverOrphanedMigrationPriority} from '../lib/migration-priority.mjs';
import {releaseProvenPreActionAbort} from '../lib/preaction-recovery.mjs';
import {inventoryLive,generatorPreflight,manualPdfPilot} from '../src/phase2-supervised.mjs';
import {phase2Run} from '../src/phase2-run.mjs';
import {phase2ReadOnlyInventory} from '../src/phase2-inventory-run.mjs';
import {masterCompletion,completionLines} from '../lib/master-completion.mjs';
import {describeTicketIssue} from '../lib/ticket-error-catalog.mjs';import {browserLeaseEnvironment} from '../lib/master-browser-lease.mjs';import {findEdgeExecutable,launchBrowser,connectBrowser} from '../lib/cdp.mjs';
import {prepareFreshRun,pendingSnapshot,assertPendingUnchanged} from '../lib/run-reset.mjs';import {interruptedPilotCandidate} from '../lib/master-pilot-recovery.mjs';import {authorizeChainedContinuation,authorizeForwardPilotContinuation,authorizeMasterBatch} from '../lib/continuation-policy.mjs';
import {createFlowRecorder,captureFlowConsole} from '../lib/flow-events.mjs';
import {ensureFlowBridge,openFlowMap} from '../lib/flow-launcher.mjs';
let flowRecorder=null;
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),defaultTarget=()=>path.join(os.homedir(),'projects/Aktive_Projekte/Ticket_bot/MCR_Datenbruecke');
const log=s=>console.log(s);async function ask(text){const rl=readline.createInterface({input:process.stdin,output:process.stdout});try{return applyEnterApproval(text,await rl.question(text));}finally{rl.close();}}
function outDir(){const d=path.join(root,'Ergebnis');fs.mkdirSync(d,{recursive:true});plainPath(d);return d;}
function cleanEnv(extra={}){const e={...process.env};for(const k of Object.keys(e))if(k.startsWith('MCR_'))delete e[k];delete e.NODE_OPTIONS;delete e.NODE_PATH;return {...e,...extra};}
export async function runChild(file,args=[],options={}){
 // RC30: mirror the complete real runner stream, including the pilot AND its
 // continuation, to a local append-only daily transcript. Console stays fast.
 const {logFile,...spawnOptions}=options;
 return new Promise((resolve,reject)=>{
  if(logFile){plainPath(path.dirname(logFile));if(fs.existsSync(logFile))plainPath(logFile);
   fs.appendFileSync(logFile,'\n=== MCR '+VERSION+' '+new Date().toISOString()+' ===\n',{mode:0o600});}
  const child=spawn(process.execPath,[file,...args],{cwd:root,stdio:logFile?['inherit','pipe','pipe']:'inherit',env:cleanEnv(),windowsHide:false,...spawnOptions});
  if(logFile)for(const [stream,destination] of [[child.stdout,process.stdout],[child.stderr,process.stderr]]){
   stream?.on('data',bytes=>{destination.write(bytes);flowRecorder?.chunk(bytes,stream);try{fs.appendFileSync(logFile,bytes,{mode:0o600});}
    catch{destination.write('\nWARN MCR_LOG_WRITE: Lokale Laufprotokoll-Datei nicht beschreibbar.\n');}});
   stream?.on('end',()=>flowRecorder?.endStream(stream));
  }
  child.once('error',reject);child.once('close',(code,signal)=>resolve({code,signal}));
 });
}
// The old immutable release ZIPs are *development qualification fixtures*.
// Do not copy archived full releases into each new production release: doing so
// previously doubled the distributed ZIP on every version (7 -> 14 -> 28 MiB).
export async function selftest(){
 verifyPackage(root);
 const tests=fs.readdirSync(path.join(root,'tests')).filter(n=>n.endsWith('.test.mjs')).sort().map(n=>path.join(root,'tests',n));
 need(tests.length>=8,'TESTS_MISSING','Aktuelle Sicherheits- und Betriebstests fehlen.');
 log('QA-PROFIL KOMPAKT: '+tests.length+' aktuelle Testmodule. Aeltere Regressionen verbleiben im lokalen Installationsarchiv.');
 const r=await runChild('--test',['--test-concurrency=3',...tests]);
 need(r.code===0&&!r.signal,'SELFTEST_FAILED','Selbsttest fehlgeschlagen.');
 log('PASS SELFTEST_COMPACT_RUNTIME');return true;
}
export async function demo(){
 const pkg=verifyPackage(root),proofs=[];
 for(const scenario of ['normal','prefixed-member','missing-member','manual-name']){
  const temp=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-Komplett-Demo-')),runId=stamp();
  for(const d of ['src','lib','examples','config'])fs.cpSync(path.join(root,d),path.join(temp,d),{recursive:true,errorOnExist:true,force:false,dereference:false});
  const config=readJSON(path.join(root,'config/local-runner-queue-send.json'));
  writeJSON(path.join(temp,'config/local-runner-queue-send.json'),{...config,profileDirectory:'.runtime/edge-profile',downloadDirectory:'.runtime/downloads',runtimeDirectory:'.runtime',diagnosticDirectory:'diagnostics'});
  log('\nFiktive Browserprobe ['+scenario+'] - eigener Tempordner, keine COMARCH-Anmeldung.');
  const r=await runChild(path.join(temp,'src/local-bot-full-run.mjs'),['--demo','--auto','--headless','--close-browser'],{cwd:temp,env:cleanEnv({MCR_RUN_ID:runId,MCR_DEMO_SCENARIO:scenario}),timeout:120000});
  const reportPath=path.join(temp,'diagnostics/last-result.json');need(fs.existsSync(reportPath),'DEMO_DIAGNOSTIC_MISSING','Demobericht fehlt.');
  const d=readJSON(reportPath);writeJSON(path.join(outDir(),'DEMO_'+scenario.toUpperCase().replace(/-/g,'_')+'_ERGEBNIS.json'),d);
  for(const n of fs.readdirSync(path.join(temp,'diagnostics')))if(n.endsWith('_UPLOAD.zip'))fs.copyFileSync(path.join(temp,'diagnostics',n),path.join(outDir(),n));
  need(r.code===0&&!r.signal&&d.runId===runId,'DEMO_FAILED','Demo ['+scenario+'] abgebrochen. Ergebnis pruefen.');
  if(scenario==='normal')certifyDemo(d);
  else if(scenario==='prefixed-member')certifyPrefixDemo(d);
  else if(scenario==='manual-name')certifyManualNameDemo(d);
  else certifyForwardDemo(d);
  proofs.push(scenario);
  log('PASS DEMO_'+scenario.toUpperCase().replace(/-/g,'_'));
 }
 const receipt={schema:'MCR_COMPLETE_DEMO_PASS_V2',version:VERSION,manifestSha256:pkg.manifestSha256,passedAt:new Date().toISOString(),scenarios:proofs,trustedMouseSends:2,trustedMouseSaves:2,trustedPrefixSends:2,trustedForwardsNoEmail:2};
 writeJSON(path.join(controlDir(root),'complete-demo-pass.json'),receipt);log('PASS DEMO_GESAMTPAKET_4_SCENARIOS');return receipt;
}

function demoPassed(pkg){const f=path.join(root,'.runtime/beta-control/complete-demo-pass.json');if(!fs.existsSync(f))return false;const d=readJSON(f);return d.schema==='MCR_COMPLETE_DEMO_PASS_V2'&&d.manifestSha256===pkg.manifestSha256&&d.trustedMouseSends===2&&d.trustedMouseSaves===2&&d.trustedPrefixSends===2&&d.trustedForwardsNoEmail===2&&JSON.stringify(d.scenarios)===JSON.stringify(['normal','prefixed-member','missing-member','manual-name']);}
async function status(target=root){const pkg=verifyPackage(target),state=runState(target);let map=null,error=null;try{const a=loadActiveMapping(target);map={valid:true,fileHash:a.fileHash,schema:a.map.schema,validKeys:a.map.payload.summary.validKeys};}catch(e){error=e.code||'MAPPING_ERROR';}const pending=fs.existsSync(path.join(target,'.runtime/beta-control/ticket-ledger.json'))?ledger(target).pending.length:0;const report={schema:'MCR_COMPLETE_STATUS_V1',package:pkg,mapping:map,mappingError:error,previousRun:state,unreviewedTickets:pending,liveReady:false,note:'Status alone does not authorize a send.'};writeJSON(path.join(outDir(),'STATUS.json'),report);log(JSON.stringify(report,null,2));return report;}
async function setup(){let target=defaultTarget();if(path.resolve(root)===path.resolve(target)){log('Bereits installierte Version. QA intern: --selftest und --demo.');await status();return;}
 const input=await ask('Vorhandene Installation [ENTER = '+target+']: ');if(input)target=path.resolve(input.replace(/^"|"$/g,''));
 recoverOrphanedMigrationPriority(target,{verifyOld:verifyPrevious,log});
 let p=planInstall(root,target);
 if(p.old.legacyResiduals?.length){log('\nPASS BEKANNTE_BETA4_ALTDATEIEN_VERIFIZIERT: '+p.old.legacyResiduals.length);log('Diese Altdateien werden mit der bisherigen Software gesichert, nicht in den neuen Lauf uebernommen:');for(const f of p.old.legacyResiduals)log('  '+f.path);}
 log('\nZiel: '+target+'\nAlt: '+p.old.version+' -> '+VERSION+'\nNur Software wird archiviert/ersetzt. private_data, Config, Browserprofil und bisherige Laufdaten bleiben am Ort.\nEinrichtung versendet keine Nachrichten.');
 const migration=beginMigrationPriority(p,{log});
 try{
  // Freeze the data binding only AFTER the owned old execution has stopped.
  p=planInstall(root,target,{migration});
  // RC49 quick install: verifyPackage + planInstall + migration barrier +
  // independently verified rollback remain mandatory. Expensive 480+ tests
  // and four Chromium demos are explicitly available via Menu 6/2, not every
  // time the operator updates software. No claim of runtime pilot approval.
  log('SCHNELLINSTALLATION: Paket-Hash/Altversion verifiziert; Prozesssperre, Staging, Rueckweg und Datenbindung bleiben aktiv.');
  log('LANGTESTS: bei Bedarf ueber --selftest / --demo; nicht bei jeder Installation.');
  migration.check();const r=installSoftware(p,{migration});
  log('PASS INSTALLATION_COMPLETE\nSicherung: '+r.archive);
  // No fabricated or stale demo receipt. Real pilot menus still require the version-bound demo proof.
 }finally{migration.release();}
 log('\nAb jetzt nur '+path.join(target,'START.cmd'));log('Das neue Hauptmenue der installierten Version wird geoeffnet.');
 await runChild(path.join(target,'tools/cli.mjs'),['--menu'],{cwd:target});return 'EXIT';
}
async function real(pilot,{automaticContinuation=false,limitAfterPilot=5,pilotRunId=null,initialDeliveryMode='MANUAL',masterLimit=null,forwardChainRunId=null,masterId=null,sharedBrowser=null}={}){need(process.platform==='win32','WINDOWS_REQUIRED','COMARCH-Echtlauf nur auf Windows.');const pkg=verifyPackage(root);need(fs.existsSync(path.join(root,'private_data')),'LIVE_FROM_DOWNLOAD_BLOCKED','Dieses Downloadpaket enthaelt keine produktiven Bestandsdaten. Echter Ticketlauf ausschliesslich aus der installierten MCR_Datenbruecke starten.');need(!fs.existsSync(path.join(root,'BETA_UMSTELLUNG_LAEUFT.txt')),'MIGRATION_INCOMPLETE','Softwareumstellung nicht abgeschlossen.');const active=loadActiveMapping(root);windowsIdle(root);const recovery=releaseProvenPreActionAbort(root);if(recovery.released)log('PASS AUTO_REVIEW_PRE_ACTION: Kein vom Bot begonnener Versand/keine Weiterleitung. Vorheriger Abbruch automatisch dokumentiert ('+recovery.phase+').');const fresh=prepareFreshRun(root,{guard:windowsIdle});if(fresh.oldRunClosed||fresh.lockReleased)log('PASS AUTO_CLOSE_OLD_RUN: Vergangener Bot-Lauf archiviert; keine alten Prozesse aktiv.');if(fresh.pending.length)log('PASS UNRESOLVED_TICKETS_EXCLUDED: '+fresh.pending.map(x=>x.ticketId).join(', ')+'. Diese Tickets erhalten KEINE automatische neue E-Mail.');assertNoReview(root);const journal=ledger(root);const previousPending=pendingSnapshot(root);log('ECHTLAUF_DIREKT: Keine fiktiven Demos. QA-Browserprobe nur ueber --demo.');
 // A verified forwarding is sufficient for ONE additional single-ticket pilot,
 // but never for a regular/bulk email run. Master batches require a real SEND proof.
 let forwardReceipt=null,masterReport=null;
 if(forwardChainRunId!==null){
  need(pilot,'FORWARD_CHAIN_NOT_PILOT','Interne Weiterleitungsfortsetzung nur als Einzelpilot.');
  const f=path.join(root,'.runtime/beta-control/complete-forward-pilot-pass.json');
  need(fs.existsSync(f),'FORWARD_CHAIN_MISSING','Vorige Weiterleitung nicht zertifiziert.');forwardReceipt=readJSON(f,65536);
  authorizeForwardPilotContinuation({runId:forwardChainRunId,receipt:forwardReceipt,
   manifestSha:pkg.manifestSha256,mappingSha:active.fileHash,ticketLimit:1});
 }
 if(!pilot){const f=path.join(root,'.runtime/beta-control/complete-pilot-pass.json');need(fs.existsSync(f),'PILOT_REQUIRED','Phase-1-Batch bleibt gesperrt: Erst nach einem echt abgeschlossenen Piloten mit nachgewiesenem Versand UND Speicherung wird der reguläre Lauf freigegeben (Menue 3).');const p=readJSON(f);need(p.schema==='MCR_COMPLETE_PILOT_PASS_V1'&&p.manifestSha256===pkg.manifestSha256&&p.mappingSha256===active.fileHash,'PILOT_REQUIRED','Die vorhandene Pilotfreigabe gehoert zu einer anderen Programm- oder Mapping-Version. Menue 3 erneut mit nachgewiesenem Versand UND Speicherung abschliessen.');}
 let limit=1;if(!pilot){if(automaticContinuation){
  limit=limitAfterPilot;
  const receipt=readJSON(path.join(root,'.runtime/beta-control/complete-pilot-pass.json'),65536);
  authorizeChainedContinuation({runId:pilotRunId,receipt,manifestSha:pkg.manifestSha256,mappingSha:active.fileHash,ticketLimit:limit});
  log('AUTO_FORTSETZUNG: Zertifizierter E-Mail-Pilot beendet; maximal '+limit+' weitere Tickets unter derselben Menue-3-Freigabe.');
 }else if(masterLimit!==null){
  limit=masterLimit;need(Number.isInteger(limit)&&limit>=1&&limit<=100,'TICKET_LIMIT','Masterlimit ungueltig.');
  if(masterId){const mf=path.join(root,'.runtime/master','MCR_MASTER_RUN_'+masterId+'.json');
   need(fs.existsSync(mf),'MASTER_BATCH_NOT_AUTHORIZED','Masterreport fehlt.');masterReport=readJSON(mf,65536);
   authorizeMasterBatch({masterId,masterReport,receipt:readJSON(path.join(root,'.runtime/beta-control/complete-pilot-pass.json'),65536),
    manifestSha:pkg.manifestSha256,mappingSha:active.fileHash,ticketLimit:limit});}
 }else{const s=await ask('Maximal wie viele Tickets (1 bis 100; ENTER=100): ');limit=s?Number(s):100;need(Number.isInteger(limit)&&limit>=1&&limit<=100,'TICKET_LIMIT','Ungueltiges Limit.');}}
 windowsIdle(root);const l=lock(root,'REAL_RUN'),dir=controlDir(root),runId=stamp(),sf=path.join(dir,'last-run.json'),state={schema:'MCR_BETA_RUN_V1',version:VERSION,operation:'REAL_RUN',state:'RUNNING',pid:process.pid,startedAt:new Date().toISOString(),runId,ticketDeliveryVerified:false,pilot};writeJSON(sf,state);
 const interrupt=()=>{state.state='INTERRUPTED_REVIEW_REQUIRED';try{writeJSON(sf,state);}catch{}};process.on('SIGINT',interrupt);process.on('SIGTERM',interrupt);
 try{
 const cfgForLog=resolveConfig(root);
 const reports=path.join(cfgForLog.runtimeDirectory,'reports');fs.mkdirSync(reports,{recursive:true});plainPath(reports);
 const day=new Date().toLocaleDateString('sv-SE');
 const transcript=path.join(reports,'MCR_ECHTLAUF_'+day+'.log');
 log('VOLLSTAENDIGES_LAUFPROTOKOLL: '+transcript+' (beide Pilot-/Folgelauf-Prozesse werden angehaengt)');
 const r=await runChild(path.join(root,'src/local-bot-full-run.mjs'),[pilot?'--pilot':'--full-run','--inspect-browser',...(automaticContinuation?['--chained-after-pilot']:[]),...(forwardChainRunId?['--chained-after-forward']:[]),...(masterId?['--master-phase1-batch']:[])],{logFile:transcript,env:cleanEnv({MCR_SESSION_TOKEN:l.token,MCR_RUN_ID:runId,MCR_MAX_TICKETS:String(limit),...(sharedBrowser?browserLeaseEnvironment(sharedBrowser):{}),...(automaticContinuation?{MCR_CHAINED_PILOT_RUN_ID:pilotRunId,MCR_DELIVERY_MODE:initialDeliveryMode}:{}),...(forwardChainRunId?{MCR_CHAINED_FORWARD_RUN_ID:forwardChainRunId}:{}),...(masterId?{MCR_MASTER_RUN_ID:masterId}:{})})});const cfg=resolveConfig(root),f=path.join(cfg.diagnosticDirectory,'last-result.json');need(fs.existsSync(f),'LIVE_DIAGNOSTIC_MISSING','Frischer Laufbericht fehlt.');const d=readJSON(f);need(d.runId===runId&&d.mode==='REAL','LIVE_DIAGNOSTIC_STALE','Bericht gehoert nicht zum aktuellen Lauf.');writeJSON(path.join(outDir(),'LETZTER_ECHTLAUF.json'),d);if(d.lastError?.startsWith('BROWSER_'))throw Object.assign(new Error('Browserverbindung vor Ticketbeginn unterbrochen: '+d.lastError+'. Kein Ticket-Neuversand.'),{code:d.lastError});if(['NAME_CHOICE_CANCELLED','NAME_WWID_TICKET_BINDING'].includes(d.lastError)){const issue=describeTicketIssue({reason:d.lastError,phase:'P1'});throw Object.assign(new Error(issue.cause+' '+issue.nextAction),{code:d.lastError});}need(r.code===0&&!r.signal&&!d.lastError&&d.loop?.completed&&state.state==='RUNNING','LIVE_NOT_VERIFIED','Echtlauf nicht sauber bestaetigt. Verlauf pruefen; kein blinder Neustart.');assertPendingUnchanged(root,previousPending);state.state='RUNNER_EXIT_0';state.finishedAt=new Date().toISOString();state.processed=d.loop.processed;writeJSON(sf,state);
 if(pilot&&d.loop.processed===1&&d.loop.forwarded===1){
  certifyForwardWithoutEmail(d);
  writeJSON(path.join(dir,'complete-forward-pilot-pass.json'),{schema:'MCR_COMPLETE_FORWARD_PILOT_PASS_V1',
   manifestSha256:pkg.manifestSha256,mappingSha256:active.fileHash,runId,ticketLimit:1,
   noEmail:true,forwardVerified:true,passedAt:new Date().toISOString()});
  log('PASS PILOT_ROUTED_WITHOUT_EMAIL - Einzelticket-Weiterleitung verifiziert. Nur naechster Einzelpilot erlaubt, KEINE Batch-E-Mail-Freigabe.');
  return {pilotVerified:false,forwardVerified:true,runId,processed:1,skippedIdentity:d.loop?.skippedIdentity||0,deliveryMode:d.deliveryMode==='AUTO'?'AUTO':'MANUAL'};
 }else if(pilot&&d.loop.processed===1){certifyPilot(d);writeJSON(path.join(dir,'complete-pilot-pass.json'),{schema:'MCR_COMPLETE_PILOT_PASS_V1',manifestSha256:pkg.manifestSha256,mappingSha256:active.fileHash,runId,passedAt:new Date().toISOString()});log('PASS LIVE_PILOT_SEND_AND_SAVE_VERIFIED | PHASE1_BATCH_FREIGEGEBEN');return {pilotVerified:true,runId,processed:d.loop.processed,skippedIdentity:d.loop?.skippedIdentity||0,deliveryMode:d.deliveryMode==='AUTO'?'AUTO':'MANUAL'};}else if(pilot){
  // RC68: A fully read, exhausted Phase-1 queue is NOT a failed send pilot.
  // Keep the pilot certificate absent (no send permission), but explicitly
  // authorize the independent Phase-2 read/process path in the master.
  const emptyProof=phase1QueueExhaustedProof(d);
  log(emptyProof?'PASS PHASE1_QUEUE_EXHAUSTED_NO_SEND: Beide erlaubten Intel-Listen geprueft; kein neuer Versandpilot erforderlich fuer Phase 2.':'Kein passendes Ticket vorhanden. Noch keine Pilotfreigabe.');
  return {pilotVerified:false,noEligible:emptyProof,reason:emptyProof?'NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS':'UNVERIFIED_NO_PILOT',runId,processed:0,skippedIdentity:d.loop?.skippedIdentity||0,skippedWithoutEmail:d.loop?.skippedWithoutEmail||0};
 }else{log('PASS LIVE_RUN_VERIFIED');return {verified:true,runId,processed:d.loop.processed,limit,finishReason:d.loop.finishReason,skippedIdentity:d.loop?.skippedIdentity||0};}
 }catch(e){if(state.state!=='INTERRUPTED_REVIEW_REQUIRED')state.state='STOP_REVIEW_REQUIRED';state.errorCode=/^[A-Z0-9_]+$/.test(e.code||'')?e.code:'RUN_ERROR';state.finishedAt=new Date().toISOString();writeJSON(sf,state);throw e;}
 finally{process.removeListener('SIGINT',interrupt);process.removeListener('SIGTERM',interrupt);try{l.release();}catch{}}
}
/** RC68: only a real, completed and write-free Intel-list scan can prove
 * that a fresh Phase-1 pilot is unnecessary BEFORE entering independent Phase 2.
 * A failed pilot, any click, an incomplete scan or a missing diagnostic is NOT
 * equivalent to an empty queue and must never grant Phase-2 permission. */
export function phase1QueueExhaustedProof(d){
 return d?.mode==='REAL'&&d?.lastError===null&&d.loop?.completed===true&&
  d.loop?.finishReason==='NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS'&&
  d.loop?.processed===0&&d.loop?.forwarded===0&&
  Array.isArray(d.loop?.processedTickets)&&d.loop.processedTickets.length===0&&
  d.send?.clicked===false&&d.send?.verified!==true;
}
/** RC60: sequential master coordinator, reuses unchanged guarded runners. */
export async function masterRun({runPhase1=real,runPhase2=phase2Run,recoverPilot=completionOnly,confirm=ask,write=writeJSON,output=log,rootDir=root,phase1Only=false}={}){
 need(process.platform==='win32'||runPhase1!==real,'WINDOWS_REQUIRED','Master Run nur auf Windows.');
 verifyPackage(rootDir);
 need(fs.existsSync(path.join(rootDir,'private_data'))||runPhase1!==real,'LIVE_FROM_DOWNLOAD_BLOCKED','Master Run ausschliesslich aus installierter Software starten.');
 const approval=await confirm(phase1Only?'PHASE 1: Alle geeigneten Tickets bis zur nachgewiesenen Leerpruefung (max. 1000 Aktionen je Lauf). ECHTE E-MAILS und interne Weiterleitungen. ENTER = bestaetigen. PHASE1_START / ABBRUCH: ':'MASTER RUN: ECHTE Standardantworten in Phase 1, danach Phase 2 OHNE E-MAIL. Sicher starten? ENTER = bestaetigen. MASTER_START / ABBRUCH: ');
 need(approval===(phase1Only?'PHASE1_START':'MASTER_START'),'MASTER_ABORT','Lauf nicht gestartet.');
 const folder=path.join(rootDir,'.runtime','master');fs.mkdirSync(folder,{recursive:true});plainPath(folder);
 const id=stamp(),file=path.join(folder,'MCR_MASTER_RUN_'+id+'.json');
 const pkgAtStart=verifyPackage(rootDir),mapAtStart=runPhase1===real?loadActiveMapping(rootDir).fileHash:'TEST_ONLY';
 const result={schema:'MCR_MASTER_RUN_V1',version:VERSION,id,startedAt:new Date().toISOString(),explicitMasterStart:!phase1Only,explicitPhase1Start:phase1Only,manifestSha256:pkgAtStart.manifestSha256,mappingSha256:mapAtStart,state:'STARTED',phase1:{status:'PENDING',batches:[],pilotAttempts:[],forwardedBeforeSendPilot:0,manualIdentityReviewObserved:0},phase2:{status:phase1Only?'NOT_REQUESTED':'PENDING'},scope:phase1Only?'PHASE1_MAX_100_PER_BATCH':'PHASE1_MAX_100_PER_BATCH_PHASE2_VISIBLE_MY_TASKS',noBlindRetry:true};
 const checkpoint=()=>write(file,result);
 checkpoint();output('MASTER_REPORT: '+file);
 let ownedBrowser=null;
 async function browserReady(){
  if(!ownedBrowser)return;
  try{const probe=await connectBrowser(ownedBrowser.port,{onRetry:r=>output('BROWSER_CONNECT_RETRY: '+r.attempt+'/'+r.attempts+' | nur Verbindung')});probe.cdp.close();return;}
  catch(e){
   // Coordinator calls only BEFORE a new runner / phase. No replay of a ticket.
   const child=ownedBrowser.child;
   need(child.exitCode!==null||child.signalCode!==null,'BROWSER_LOOPBACK_UNAVAILABLE','Eigener Edge-Prozess noch aktiv, Debugverbindung aber unklar. Keine neue Instanz und kein Ticket-Neuversand.');
   const cfg=resolveConfig(rootDir),exe=findEdgeExecutable(cfg.edgePath);windowsIdle(rootDir);
   output('MASTER_BROWSER_RECOVERY_BEGIN: Eigener Browser ist beendet; neue Verbindung vor naechstem Teilprozess. Bereits bearbeitete Tickets bleiben abgeschlossen.');
   ownedBrowser=await launchBrowser({executable:exe,userDataDir:cfg.profileDirectory,startUrl:'about:blank'});
   const probe=await connectBrowser(ownedBrowser.port);const neutral=await probe.cdp.send('Target.createTarget',{url:'about:blank'});ownedBrowser.keeper=neutral.targetId;probe.cdp.close();
   ownedBrowser.lease={port:ownedBrowser.port,masterId:id,ownerPid:process.pid};
   output('PASS MASTER_BROWSER_RECOVERED: Nur Browser vor neuem Teilprozess wiederhergestellt; keine Aktion wiederholt.');
  }
 }
 try{
  result.state='PHASE1';result.phase1.status='RUNNING';checkpoint();
  // RC61: Stop at a previous interrupted pilot and offer a SINGLE, named
  // completion-only path. This never resends mail, never clears unrelated
  // SEND_INTENT entries, and never creates a new pilot receipt from an old run.
  const previousFile=path.join(rootDir,'.runtime/beta-control/last-run.json');
  const interrupted=interruptedPilotCandidate(fs.existsSync(previousFile)?readJSON(previousFile,65536):null,ledger(rootDir).pending);
  if(interrupted){
   output('MASTER_VORHERIGER_PILOT_OFFEN: Ticket '+interrupted.ticketId+' | '+interrupted.state+'. Keine neue E-Mail an dieses Ticket.');
   const decision=await confirm('Dieses Ticket zuerst OHNE NEUVERSAND pruefen und nur Status/Ticket speichern? PRUEFEN '+interrupted.ticketId+' / UEBERSPRINGEN / ABBRUCH: ');
   need([`PRUEFEN ${interrupted.ticketId}`,'UEBERSPRINGEN'].includes(decision),'MASTER_RECOVERY_NOT_APPROVED','Unklarer Pilot bleibt gesperrt. Kein Master-Versand gestartet.');
   result.phase1.interruptedPilot={ticketId:interrupted.ticketId,originalState:interrupted.state,status:decision==='UEBERSPRINGEN'?'UNRESOLVED_EXCLUDED':'REVIEW_IN_PROGRESS'};checkpoint();
   if(decision!== 'UEBERSPRINGEN'){
    output('MASTER_ABSCHLUSS_OHNE_NEUVERSAND: Nur Ticket '+interrupted.ticketId+'. Original-Ausgang im COMARCH-Verlauf muss verifiziert sein.');
    const otherPending=pendingSnapshot(rootDir).filter(t=>t.ticketId!==interrupted.ticketId);
    await recoverPilot(rootDir,interrupted.ticketId);
    assertPendingUnchanged(rootDir,otherPending);
    need(ledger(rootDir).completedIds().includes(interrupted.ticketId),'MASTER_RECOVERY_NOT_COMPLETED','Altes Ticket nicht als versendet UND gespeichert nachgewiesen. Kein neuer Versand.');
    result.phase1.interruptedPilot.status='SENT_AND_SAVED_VERIFIED_NO_NEW_EMAIL';checkpoint();
    output('PASS MASTER_ABSCHLUSS_OHNE_NEUVERSAND: '+interrupted.ticketId+' | Status und Speicherung nachgewiesen.');
   }else output('MASTER_PILOT_GESPERRT: '+interrupted.ticketId+' bleibt ungeklärt und wird bei allen neuen Läufen übersprungen.');
  }
  // If an older send requires recovery, complete it before starting the shared
  // browser. Two Edge owners must never use the same bot profile at once.
  // RC92: the coordinator OWNS one Edge process for a whole native master.
  // Every real pilot/batch and Phase 2 still independently binds a fresh page.
  // Injected QA runners remain browser-free and deterministic.
  if(runPhase1===real && (phase1Only||runPhase2===phase2Run)){
   windowsIdle(rootDir);
   const cfg=resolveConfig(rootDir),exe=findEdgeExecutable(cfg.edgePath);
   need(exe,'MASTER_BROWSER_NOT_FOUND','Edge fehlt; Master nicht gestartet.');
   ownedBrowser=await launchBrowser({executable:exe,userDataDir:cfg.profileDirectory,startUrl:'about:blank'});
   const lease=browserLeaseEnvironment({port:ownedBrowser.port,masterId:id,ownerPid:process.pid});
   try{const probe=await connectBrowser(ownedBrowser.port);const neutral=await probe.cdp.send('Target.createTarget',{url:'about:blank'});ownedBrowser.keeper=neutral.targetId;probe.cdp.close();}
   catch(e){try{ownedBrowser.child.kill();}catch{}ownedBrowser=null;throw e;}
   output('PASS MASTER_BROWSER_EINMAL_GESTARTET: Ein Edge-Prozess fuer Phase 1 und Phase 2; pro Teillauf eine frische gebundene Seite.');
   ownedBrowser.lease={port:ownedBrowser.port,masterId:id,ownerPid:process.pid};
  }
  // An exact, still-valid RC61 pilot receipt may be reused. Otherwise the
  // existing guarded pilot is mandatory: no fabricated shipping approval.
  const pkg=verifyPackage(rootDir),mapping=runPhase1===real?loadActiveMapping(rootDir):{fileHash:"TEST_ONLY"};
  const cert=path.join(rootDir,'.runtime/beta-control/complete-pilot-pass.json');
  const proof=fs.existsSync(cert)?readJSON(cert,65536):null;
  let ready=proof?.schema==='MCR_COMPLETE_PILOT_PASS_V1'&&proof.manifestSha256===pkg.manifestSha256&&proof.mappingSha256===mapping.fileHash;
  if(!ready){
   output('MASTER_PHASE1_PILOT_KETTE: Weiterleitung ohne E-Mail fuehrt zum naechsten Einzelpilot, nicht zu einer Batch-Versandfreigabe.');
   let predecessor=null,finishedNoEligible=false;
   for(let attempt=0;attempt<1000;attempt++){
    await browserReady();
    const p=await runPhase1(true,{...(predecessor?{forwardChainRunId:predecessor.runId}:{}),...(ownedBrowser?{sharedBrowser:ownedBrowser.lease}:{})});
    result.phase1.pilot=p;
    result.phase1.pilotAttempts.push({runId:p?.runId||null,processed:p?.processed||0,
     outcome:p?.pilotVerified?'SEND_SAVED':p?.forwardVerified?'FORWARD_NO_EMAIL':p?.noEligible?'NO_NEW_ELIGIBLE':'UNVERIFIED',
     skippedIdentity:p?.skippedIdentity||0});
    result.phase1.manualIdentityReviewObserved+=(p?.skippedIdentity||0);checkpoint();
    if(p?.pilotVerified===true&&p?.processed===1){ready=true;break;}
    if(p?.forwardVerified===true&&p?.pilotVerified!==true&&p?.processed===1&&
      typeof p.runId==='string'&&p.runId.length>=12&&p.runId.length<=160){
     predecessor=p;result.phase1.forwardedBeforeSendPilot++;checkpoint();
     output('MASTER_PHASE1_FORWARD_OK: '+result.phase1.forwardedBeforeSendPilot+
      ' interne Weiterleitung(en) verifiziert. Naechsten Einzelpilot automatisch suchen, KEINE E-Mail-Batch-Freigabe.');
     continue;
    }
    if(p?.noEligible===true&&p?.processed===0&&p?.reason==='NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS'){
     result.phase1.status=(p.skippedIdentity||0)>0?'NO_NEW_ELIGIBLE_MANUAL_IDENTITY_REVIEW':'NO_ELIGIBLE_TICKETS';
     result.phase1.noSendPilot=true;result.phase1.skippedIdentity=p.skippedIdentity||0;
     finishedNoEligible=true;checkpoint();
     output('MASTER_PHASE1_QUEUE_ABGESUCHT: Kein weiterer geeigneter Fall in den beiden geprueften Listen;'+
      (p.skippedIdentity?' Identitaetsfaelle bleiben MANUELL OFFEN.':'')+(phase1Only?' Phase-1-Lauf endet nach Listenpruefung.':' Phase 2 startet getrennt OHNE E-Mail.'));
     break;
    }
    result.phase1.status='NO_SEND_PILOT';result.state='PARTIAL_PHASE1_NO_PILOT';result.finishedAt=new Date().toISOString();checkpoint();
    output('MASTER_PHASE1_STOP: Weder verifizierter Versand noch verifizierte Weiterleitung noch vollstaendige Leerpruefung. Keine Phase-2-Fortsetzung.');return result;
   }
   if(!ready&&!finishedNoEligible){result.phase1.status='ROUTE_LIMIT_REACHED';result.state='PARTIAL_PHASE1_ROUTE_LIMIT';result.finishedAt=new Date().toISOString();checkpoint();
    output('MASTER_PHASE1_ROUTE_LIMIT: 1000 Einzelpiloten erreicht. Kein blinder weiterer Versand/Weiterleitung.');return result;}
  }
  if(ready){
   // Stop if a batch consumes fewer than its cap. The cap keeps pagination
   // bounded and enforces new session/journal checks for every batch.
   for(let n=0;n<10;n++){
    const cap=100;output('MASTER_PHASE1_BATCH '+(n+1)+' (maximal '+cap+' Tickets).');
    await browserReady();
    const r=await runPhase1(false,{masterLimit:cap,masterId:id,...(ownedBrowser?{sharedBrowser:ownedBrowser.lease}:{})});
    need(r?.verified===true&&Number.isInteger(r.processed)&&r.processed>=0&&r.processed<=cap,'MASTER_PHASE1_UNVERIFIED','Phase 1 nicht unabhaengig bestaetigt.');
    result.phase1.batches.push({runId:r.runId,processed:r.processed,limit:cap,skippedIdentity:r.skippedIdentity||0});
    result.phase1.manualIdentityReviewObserved+=(r.skippedIdentity||0);checkpoint();
    if(r.processed<cap){need(r.finishReason==='NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS'||runPhase1!==real&&r.finishReason===undefined,'MASTER_PHASE1_NOT_EXHAUSTED','Batch ohne Leerpruefung vorzeitig beendet; kein naechster Schritt.');break;}
    if(n===9)result.phase1.limitReached=true;
   }
   result.phase1.status=result.phase1.limitReached?'LIMIT_REACHED':'VERIFIED';
  }
  // A hard cap is NOT evidence of an exhausted ticket list.
  if(result.phase1.limitReached){result.state='PARTIAL_PHASE1_LIMIT';checkpoint();output('MASTER_PARTIAL: Phase-1-Limit erreicht; Phase 2 noch nicht begonnen.');return result;}
  if(phase1Only){
   result.phase2.status='NOT_REQUESTED';
   result.state=result.phase1.manualIdentityReviewObserved>0?'PARTIAL_PHASE1_MANUAL_IDENTITY_REVIEW':'PHASE1_COMPLETE_VISIBLE_SCOPE';
   result.finishedAt=new Date().toISOString();checkpoint();
   output('PHASE1_LAUF_ENDE: '+result.phase1.status+' | bearbeitete Tickets gemaess Pilot-/Batchberichten. Keine Phase 2 gestartet.');
   return result;
  }
  await browserReady();
  result.state='PHASE2';result.phase2.status='RUNNING';checkpoint();
  output('MASTER_PHASE2: Alle sichtbaren geeigneten Vorgaenge. MASTER_START deckt die allgemeine Startfreigabe ab; erforderliche Fachpruefungen bleiben bestehen. KEIN E-Mail-Versand.');
  const l=lock(rootDir,'PHASE2_COMARCH_PILOT');
  try{const p=await runPhase2({root:rootDir,masterApproved:true,...(ownedBrowser?{session:{port:ownedBrowser.port,masterId:id}}:{})});need(p?.status==='COMPLETED_VISIBLE_SCOPE','MASTER_PHASE2_UNVERIFIED','Phase-2-Lauf nicht erfolgreich abgeschlossen.');result.phase2={status:'VERIFIED_VISIBLE_SCOPE',processed:p.processed,scope:p.scope,skipped:p.skipped,runId:p.runId,errorSummary:p.errorSummary,errorFiles:p.errorFiles};checkpoint();}
  finally{l.release();}
  // Two NORMAL operator-facing endings. Preserve older machine states for
  // existing checkpoints and audits. Never use either label after an error.
  result.completion=masterCompletion(result);
  if(result.phase2.skipped?.length)
   result.state=result.phase2.processed===0?'PARTIAL_PHASE2_NO_ELIGIBLE':'PARTIAL_PHASE2_OPEN_CASES';
  else if(result.phase1.manualIdentityReviewObserved>0)
   result.state='PARTIAL_PHASE1_MANUAL_IDENTITY_REVIEW';
  else result.state='COMPLETE_VISIBLE_SCOPE';
  result.finishedAt=new Date().toISOString();checkpoint();
  for(const line of completionLines(result.completion))output(line);
  if(result.phase2.errorFiles?.csv)output('MASTER_TICKETFEHLER_CSV: '+result.phase2.errorFiles.csv);
  if(result.phase2.errorFiles?.json)output('MASTER_TICKETFEHLER_JSON: '+result.phase2.errorFiles.json);
  return result;
 }catch(e){
  const stage=result.state==='PHASE1'?'P1':'P2';
  result.state='STOP_REVIEW_REQUIRED';result.errorCode=e.code||'ERROR';
  result.message=String(e.message||'').slice(0,350);
  result.failure=describeTicketIssue({reason:result.errorCode,phase:stage});
  result.finishedAt=new Date().toISOString();checkpoint();
  output('MASTER_UNTERBROCHEN: '+result.errorCode+' | '+result.failure.errorCode+
   '; KEIN Abschluss, unabhaengige Pruefung notwendig; kein blinder Wiederanlauf.');
  output('MASTER_FEHLER_URSACHE: '+result.failure.cause);
  output('MASTER_FEHLER_MASSNAHME: '+result.failure.nextAction);
  throw e;}
 finally{
  if(ownedBrowser){
   let keepOpen=false;
   if(result.state==='STOP_REVIEW_REQUIRED'){
    output('MASTER_BROWSER_PRUEFUNG: Browser nach Unterbrechung fuer die Sichtpruefung geoeffnet.');
    try{keepOpen=(await confirm('Bot-Edge fuer manuelle Pruefung offen lassen? OFFEN / ENTER = schliessen: ')).trim().toUpperCase()==='OFFEN';}catch{}
   }
   if(keepOpen){ownedBrowser.child.unref();output('MASTER_BROWSER_OFFEN: Vor neuem Lauf Bot-Edge schliessen.');}
   else{try{ownedBrowser.child.kill();}catch{}output('MASTER_BROWSER_GESCHLOSSEN: Ein Edge-Prozess am Ende des Master-Runs geschlossen.');}
  }
 }
}
async function completionOnly(target,id){
 verifyPackage(target);loadActiveMapping(target);windowsIdle(target);
 prepareFreshRun(target,{guard:windowsIdle});assertNoReview(target);
 const before=pendingSnapshot(target);need(before.some(t=>t.ticketId===id&&t.kind==='SEND'),'REPAIR_PENDING_MISSING','Ticket ist kein offener Versand.');
 const l=lock(target,'REAL_RUN'),runId=stamp(),sf=path.join(controlDir(target),'last-run.json');
 let state={schema:'MCR_BETA_RUN_V1',version:VERSION,operation:'REAL_RUN',state:'RUNNING',pid:process.pid,startedAt:new Date().toISOString(),runId};writeJSON(sf,state);
 try{
  const cfg=resolveConfig(target),reports=path.join(cfg.runtimeDirectory,'reports');fs.mkdirSync(reports,{recursive:true});
  const r=await runChild(path.join(target,'src/local-bot-full-run.mjs'),['--complete-pending','--inspect-browser'],{cwd:target,logFile:path.join(reports,'MCR_ABSCHLUSS_OHNE_NEUVERSAND_'+runId+'.log'),env:cleanEnv({MCR_SESSION_TOKEN:l.token,MCR_RUN_ID:runId,MCR_MAX_TICKETS:'1',MCR_REPAIR_TICKET:id})});
  const d=readJSON(path.join(cfg.diagnosticDirectory,'last-result.json'));
  need(r.code===0&&!r.signal&&d.runId===runId&&!d.lastError&&d.completionOnly?.id===id&&d.completionOnly?.status==='COMPLETE'&&d.send?.clicked===false,'REPAIR_NOT_VERIFIED','Nachbearbeitung nicht bestaetigt. Kein Neuversand.');
  assertPendingUnchanged(target,before.filter(t=>t.ticketId!==id));state.state='RUNNER_EXIT_0';
  log('PASS ABSCHLUSS_OHNE_NEUVERSAND: '+id+'; andere offene Tickets unveraendert.');
 }catch(e){state.state='STOP_REVIEW_REQUIRED';state.errorCode=e.code||'ERROR';throw e;}
 finally{state.finishedAt=new Date().toISOString();writeJSON(sf,state);l.release();}
}
async function review(target=root){plainPath(target);const dir=controlDir(target),lf=path.join(dir,'operation.lock.json'),sf=path.join(dir,'last-run.json');windowsIdle(target);const recovery=releaseProvenPreActionAbort(target);if(recovery.released){log('PASS AUTO_REVIEW_PRE_ACTION: Kein Bot-Versand oder -Weiterleitungsversuch begonnen. Keine manuelle SICHER_KEIN_VERSAND-Bestaetigung notwendig.');return;}if(fs.existsSync(lf))need(!processAlive(readJSON(lf).pid),'OPERATION_ALIVE','Sperrbesitzer laeuft noch.');const j=ledger(target);log('Vorheriger Lauf: '+JSON.stringify(runState(target)));log('Offene Sende-/Weiterleitungsabsichten: '+j.pending.length);log('Nur lokale Anzeige offener Tickets:');for(const t of j.pending)log('Ticket '+t.ticketId+' | '+t.state);
 if(j.pending.some(t=>t.kind==='SEND')){
  log('NEU: Einzelnes bereits versendetes Ticket abschliessen, OHNE neue E-Mail. Empfohlen fuer SEND_UNVERIFIED.');
  const chosen=await ask('Ticket-ID fuer Status-/Speichernachtrag (z.B. 88149870), ENTER = bisherige manuelle Pruefung: ');
  if(chosen){need(/^\d{6,12}$/.test(chosen),'REPAIR_TICKET_ID','Genau eine Ticketnummer.');return completionOnly(target,chosen);}
 }
 const pendingKinds=[...new Set(j.pending.map(p=>p.kind==='FORWARD'?'FORWARD':'SEND'))];need(pendingKinds.length<=1,'REVIEW_MIXED_ACTIONS','Gemischte offene Sendungen und Weiterleitungen muessen einzeln extern geklaert werden.');const forwarding=pendingKinds[0]==='FORWARD';
 log('\nCOMARCH manuell pruefen. Weitergeleitet ist NICHT gleich gesendet. Bei Unsicherheit abbrechen.');
 const prompt=forwarding?'WEITERGELEITET_GEPRUEFT oder SICHER_NICHT_WEITERGELEITET; sonst ENTER: ':'SICHER_KEIN_VERSAND oder VERSAND_UND_SPEICHERUNG_GEPRUEFT; sonst ENTER: ';
 const answer=await ask(prompt);const allowed=forwarding?['WEITERGELEITET_GEPRUEFT','SICHER_NICHT_WEITERGELEITET']:['SICHER_KEIN_VERSAND','VERSAND_UND_SPEICHERUNG_GEPRUEFT'];if(!allowed.includes(answer)){log('Sperre bleibt bestehen.');return;}
 windowsIdle(target);if(fs.existsSync(lf)){const old=readJSON(lf);need(!processAlive(old.pid),'OPERATION_ALIVE','Sperrbesitzer aktiv.');const a=path.join(dir,'lock_archive');fs.mkdirSync(a,{recursive:true});plainPath(a);fs.copyFileSync(lf,path.join(a,'review_'+stamp()+'.json'),fs.constants.COPYFILE_EXCL);fs.unlinkSync(lf);}
 j.review(forwarding?(answer==='WEITERGELEITET_GEPRUEFT'?'OPERATOR_CONFIRMED_ROUTED':'OPERATOR_CONFIRMED_NOT_ROUTED_RETRY_ALLOWED'):(answer==='SICHER_KEIN_VERSAND'?'OPERATOR_CONFIRMED_NO_SEND_RETRY_ALLOWED':'OPERATOR_CONFIRMED_SENT_SAVED'));if(fs.existsSync(sf)){const old=readJSON(sf);writeJSON(path.join(dir,'review_'+stamp()+'.json'),old);writeJSON(sf,{...old,state:'OPERATOR_REVIEWED_NOT_RETRIED',reviewedAt:new Date().toISOString(),ticketDeliveryVerified:false});}log('Pruefentscheidung dokumentiert. Keine Nachricht versendet.');
}
async function rollback(){const input=await ask('Ziel der Wiederherstellung [ENTER = '+defaultTarget()+']: '),target=input?path.resolve(input.replace(/^"|"$/g,'')):defaultTarget();recoverOrphanedMigrationPriority(target,{forRollback:true,verifyOld:verifyPrevious,log});windowsIdle(target);const all=journals(target);need(all.length,'NO_ROLLBACK','Kein passendes Gesamtpaket-Archiv gefunden.');const j=all[0];log('Software-Rueckweg: '+j.archive+'\nKeine Tickets, Nachrichten oder Daten werden rueckgaengig gemacht.');need((await ask('ZURUECK: ')).toUpperCase()==='ZURUECK','ROLLBACK_ABORT','Keine Freigabe.');const l=lock(target,'ROLLBACK');try{restoreSoftware(j);log('PASS SOFTWARE_RESTORED');}finally{l.release();}}
async function mappingMaintenance(){verifyPackage(root);loadActiveMapping(root);assertNoReview(root);ledger(root).assertClear();windowsIdle(root);need((await ask('Mappingwartung ist fuer die Reparatur NICHT erforderlich. Fortfahren? WARTUNG: ')).toUpperCase()==='WARTUNG','ABORT','Keine Mappingwartung.');const l=lock(root,'REAL_RUN');try{const r=await runChild(path.join(root,'src/export-multirow.mjs'),[],{env:cleanEnv({MCR_SESSION_TOKEN:l.token})});need(r.code===0&&!r.signal,'MAPPING_MAINTENANCE_FAILED','Mappingwartung nicht abgeschlossen. Aktivierungszeiger vor Ticketlauf pruefen.');}finally{l.release();}}
/** RC83: single menu-3 authorization covers at most six proven actions.
 * Only a real send-and-save pilot may unlock a multi-ticket e-mail runner. */
export async function menu3Flow({runPhase1=real,runFull=real,output=log}={}){
 let completed=0,previous=null;
 while(completed<6){
  const p=await runPhase1(true,previous?{forwardChainRunId:previous.runId}:{});
  if(p?.forwardVerified===true&&p?.pilotVerified!==true&&p?.processed===1){
   need(typeof p.runId==='string'&&p.runId.length>=12,'MENU3_FORWARD_PROOF','Weiterleitungsbeleg fehlt.');
   completed++;previous=p;
   output('MENU3_FORTSETZUNG: '+completed+'/6 abgeschlossen ohne E-Mail. Suche automatisch naechsten Einzelpilot.');
   continue;
  }
  if(p?.pilotVerified===true&&p?.processed===1){
   completed++;
   if(completed<6){output('PASS PILOT -> FORTSETZUNG: '+(6-completed)+' weitere Tickets unter derselben Menue-3-Freigabe.');
    await runFull(false,{automaticContinuation:true,limitAfterPilot:6-completed,pilotRunId:p.runId,initialDeliveryMode:p.deliveryMode});}
   return {status:'SUCCESS',processedByPilots:completed,pilotVerified:true};
  }
  if(p?.noEligible===true&&p?.processed===0&&p?.reason==='NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS'){
   output('MENU3_LISTEN_GEPRUEFT: '+completed+' Weiterleitung(en), kein zusaetzlicher E-Mail-Pilot. Menue 4 bleibt gesperrt.');
   return {status:'NO_MORE_ELIGIBLE',processedByPilots:completed,pilotVerified:false};
  }
  output('MENU3_STOP: Pilotnachweis unklar. Kein automatischer Folgelauf.');
  return {status:'STOP_REVIEW',processedByPilots:completed,pilotVerified:false};
 }
 output('MENU3_LIMIT: Sechs bestaetigte Weiterleitungen; kein E-Mail-Pilot. Fuer weitere Tickets Menu 3 erneut oder Master Run.');
 return {status:'LIMIT',processedByPilots:completed,pilotVerified:false};
}
// RC86: Compact operator menu. Technical recovery, rollback, QA and demos
// are retained behind explicit CLI flags but no longer clutter routine work.
export const OPERATOR_MENU=Object.freeze([
 '1  Schnellinstallation / aktualisieren (kein Echtversand)',
 '2  Bestandsdaten / Mapping aktualisieren (nur bei Bedarf)',
 '3  PHASE 1: Alle geeigneten Tickets bearbeiten',
 '4  PHASE 2: Bearbeiten und weiterleiten',
 '5  MASTER RUN: Phase 1 -> Phase 2',
 '0  Beenden'
]);
async function showMap(){const service=await ensureFlowBridge(root);openFlowMap(service.url);log('FLOW_MAP_OPEN_REQUESTED: Live-Karte im normalen Browser angefordert; Verbindungsstatus steht in der Karte. Nur Anzeige, keine Botfreigabe.');}
async function menu(){
 try{flowRecorder=createFlowRecorder(root,{onWarning:s=>process.stderr.write(s+'\n')});captureFlowConsole(flowRecorder);}catch{log('HINWEIS: Live-Protokoll nicht beschreibbar; Bot kann ohne Karte arbeiten.');}
 if(fs.existsSync(path.join(root,'private_data'))){const choice=(await ask('Live-Karte parallel oeffnen? ENTER = Ja / N = ohne Karte: ')).trim().toUpperCase();if(choice!=='N')try{await showMap();}catch(e){log('FLOW_MAP_UNAVAILABLE: '+e.message);}}
 for(;;){
 log('\n==============================================================\n MCR DATENBRUECKE '+VERSION+'\n==============================================================\n'+OPERATOR_MENU.join('\n')+'\nM  Live-Karte oeffnen (nur Anzeige)');
 try{
  const a=await ask('Auswahl: ');if(a==='0')return;
  assertNoMigrationPriority(root);
  if(a==='1'){if(await setup()==='EXIT')return;}
  else if(a==='2')await mappingMaintenance();
  else if(a==='3'){flowRecorder?.begin('P1');await masterRun({phase1Only:true});flowRecorder?.finish('RETURNED');}
  else if(a==='4'){flowRecorder?.begin('P2');windowsIdle(root);const l=lock(root,'PHASE2_COMARCH_PILOT');try{await phase2Run({root});flowRecorder?.finish('RETURNED');}finally{l.release();}}
  else if(a==='5'){flowRecorder?.begin('MASTER');await masterRun();flowRecorder?.finish('RETURNED');}
  else if(a.toUpperCase()==='M')await showMap();
  else log('Bitte 0 bis 5 oder M waehlen.');
 }catch(e){console.error('STOP '+(e.code||'ERROR')+': '+e.message);flowRecorder?.finish('INTERRUPTED');if(e.rollback)log('Rueckweg: '+e.rollback);}
 await ask('\nENTER zum Hauptmenue: ');
}}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){try{const [major,minor]=process.versions.node.split('.').map(Number);need(major>22||major===22&&minor>=15,'NODE_VERSION','Vorhandenes Node.js ab 22.15 erforderlich.');assertNoMigrationPriority(root);verifyPackage(root);const action=process.argv[2]||'--menu';if(action==='--selftest')await selftest();else if(action==='--demo')await demo();else if(action==='--status')await status();else if(action==='--rollback')await rollback();else if(action==='--review')await review(root);else if(action==='--map')await showMap();else if(action==='--menu')await menu();else need(false,'ARGUMENT','Zulaessig: --menu, --status, --selftest, --demo, --rollback, --review, --map.');}catch(e){console.error('STOP '+(e.code||'ERROR')+': '+e.message);process.exitCode=1;}}
