import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {ROOT} from './helpers.mjs';
import {masterRun} from '../tools/cli.mjs';

function fixture(){
 const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC60-MASTER-'));
 const target=path.join(tmp,'MCR_Datenbruecke');
 fs.cpSync(ROOT,target,{recursive:true,filter:p=>!p.includes('/.runtime/')&&!p.includes('/Ergebnis/')&&!p.includes('/diagnostics/')});
 return {tmp,target};
}
test('RC60 master: real pilot, bounded phase1, then phase2, with persistent checkpoint',{timeout:20000},async()=>{
 const {tmp,target}=fixture();let n=0;const calls=[];
 try{
  const report=await masterRun({rootDir:target,confirm:async()=> 'MASTER_START',output:()=>{},runPhase1:async(pilot,opts)=>{
   calls.push(pilot?'pilot':'full');if(pilot)return {pilotVerified:true,runId:'pilot-mock',processed:1};
   assert.equal(opts.masterLimit,100);return {verified:true,runId:'full-mock',processed:2};
  },runPhase2:async({root})=>{calls.push('phase2');assert.equal(root,target);return {status:'COMPLETED_VISIBLE_SCOPE',runId:'p2-mock',scope:'VISIBLE_MY_TASKS_NO_PAGINATION',processed:3,skipped:[{ticketId:'90000999',reason:'UNRESOLVED_PHASE1_JOURNAL'}]};}});
  assert.deepEqual(calls,['pilot','full','phase2']);assert.equal(report.state,'PARTIAL_PHASE2_OPEN_CASES');
  assert.equal(report.phase2.processed,3);
  const reports=fs.readdirSync(path.join(target,'.runtime/master'));assert.equal(reports.length,1);
  assert.deepEqual(JSON.parse(fs.readFileSync(path.join(target,'.runtime/master',reports[0]))).state,'PARTIAL_PHASE2_OPEN_CASES');
 }finally{fs.rmSync(tmp,{recursive:true,force:true});}
});
test('RC60 master: failed phase1 prevents phase2 and leaves review checkpoint',{timeout:20000},async()=>{
 const {tmp,target}=fixture();let phase2=false;
 try{
  await assert.rejects(()=>masterRun({rootDir:target,confirm:async()=> 'MASTER_START',output:()=>{},runPhase1:async(pilot)=>{if(pilot)return {pilotVerified:true,runId:'pilot-mock'};throw Object.assign(new Error('unconfirmed phase1'),{code:'LIVE_NOT_VERIFIED'});},runPhase2:async()=>{phase2=true;}}),/unconfirmed phase1/);
  assert.equal(phase2,false);
  const reports=fs.readdirSync(path.join(target,'.runtime/master'));
  assert.equal(JSON.parse(fs.readFileSync(path.join(target,'.runtime/master',reports[0]))).state,'STOP_REVIEW_REQUIRED');
 }finally{fs.rmSync(tmp,{recursive:true,force:true});}
});
