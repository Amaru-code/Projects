import test from 'node:test';import assert from 'node:assert/strict';import {EventEmitter} from 'node:events';
import {DeliveryGate,createDeliveryConsole,completionDisplay} from '../lib/delivery-console.mjs';
import {reviewUnverifiedSend} from '../lib/operator-send-review.mjs';import {validSendAcknowledgements} from '../lib/send-dialog-policy.mjs';
const msg=(event,more={})=>({schema:'MCR_CONTROL_V1',event,...more});
test('RC53 default MANUAL cannot send without ticket-bound approval',()=>{
 const g=new DeliveryGate(),r=g.request('88149870');assert.equal(g.mode,'MANUAL');assert.equal(g.lease(),null);
 assert(!g.accept(msg('approve',{ticket:'88149871',challenge:r.challenge})));assert.equal(g.lease(),null);
 assert(!g.accept(msg('approve',{ticket:r.ticket,challenge:'stale'})));assert.equal(g.lease(),null);
 assert(g.accept(msg('approve',r)));const lease=g.lease();assert(g.consume(lease));assert.throws(()=>g.consume(lease));
});
test('RC53 AUTO is explicit; switching back to MANUAL invalidates earlier approval',()=>{
 const g=new DeliveryGate();g.request('88149870');g.accept(msg('mode',{mode:'AUTO'}));const lease=g.lease();assert(lease);
 g.accept(msg('mode',{mode:'MANUAL'}));assert.equal(g.lease(),null);assert.throws(()=>g.consume(lease));
});
test('RC53 approval is never transferable to next ticket or later same-ticket request',()=>{
 const g=new DeliveryGate();const first=g.request('88149870');g.accept(msg('approve',first));const lease=g.lease();
 g.request('88149871');assert(!g.accept(msg('approve',first)));assert.throws(()=>g.consume(lease));
 g.request('88149870');assert(!g.accept(msg('approve',first)));assert.equal(g.lease(),null);
});
test('RC53 invalid protocol and closed gate cannot enable AUTO or approve',()=>{
 const g=new DeliveryGate();g.request('88149870');assert(!g.accept({event:'mode',mode:'AUTO'}));assert(!g.accept(msg('mode',{mode:'anything'})));
 g.accept(msg('abort'));assert.equal(g.lease(),null);assert(!g.accept(msg('mode',{mode:'AUTO'})));assert.throws(()=>g.request('88149871'));
});
test('RC53 unavailable Windows panel falls back to exact terminal consent, not automatic send',async()=>{
 const x=createDeliveryConsole({platform:'linux'});assert.equal(await x.ready(),false);
 await assert.rejects(()=>x.authorize({ticketId:'88149870',ask:async()=>''}),e=>e.code==='SEND_NOT_AUTHORIZED');
 const lease=await x.authorize({ticketId:'88149870',ask:async q=>{assert(q.includes('SENDEN 88149870'));return 'SENDEN 88149870';}});
 await x.commitAuthorization(lease);await assert.rejects(()=>x.commitAuthorization(lease));x.close();
});
test('RC53 IPC hides interactive panel before browser input; environment excludes bot token',async()=>{
 let child,options;const trace=[],out=[];
 const launcher=(exe,args,opts)=>{options=opts;child=new EventEmitter();child.stdin=new EventEmitter();child.stdout=new EventEmitter();child.stdin.writable=true;child.stdin.end=()=>{};
  child.stdin.write=line=>{const m=JSON.parse(line);out.push(m);if(m.event==='suspend'){trace.push('hidden');child.stdout.emit('data',JSON.stringify(msg('hidden',{seq:m.seq}))+'\n');}};return child;};
 const x=createDeliveryConsole({platform:'win32',env:{MCR_SESSION_TOKEN:'secret'},launcher});
 const ready=x.ready();child.stdout.emit('data',JSON.stringify(msg('ready'))+'\n');assert(await ready);
 assert.equal(options.env.MCR_SESSION_TOKEN,undefined);assert.deepEqual(options.stdio,['pipe','pipe','ignore']);
 const waiting=x.authorize({ticketId:'88149870',ask:async()=>{throw Error('no terminal');}});const pending=out.find(x=>x.event==='approval');
 child.stdout.emit('data',JSON.stringify(msg('approve',{ticket:pending.ticket,challenge:pending.challenge}))+'\n');
 const lease=await waiting;await x.commitAuthorization(lease);
 const cdp={send:async method=>{trace.push(method);return {};}};x.protectInput(cdp);await cdp.send('Input.dispatchMouseEvent',{});
 assert.deepEqual(trace,['hidden','hidden','Input.dispatchMouseEvent']);
 child.emit('exit',0);assert.equal(x.gate.mode,'MANUAL');x.close();
});
test('RC53 completion overlay never reports complete on error, does not announce pilot before continuation',()=>{
 assert.equal(completionDisplay({completed:true,error:'SEND_UNVERIFIED'}),null);
 assert.equal(completionDisplay({completed:false}),null);
 assert.equal(completionDisplay({completed:true,finishReason:'PILOT_LIMIT_AFTER_VERIFIED_SAVE',pilot:true,processed:1}),null);
 const d=completionDisplay({completed:true,finishReason:'LIMIT_AFTER_VERIFIED_ACTION',processed:5});assert.equal(d.title,'FERTIG');assert.equal(d.durationMs,5000);assert(!d.title.includes('ALLE'));
});
test('RC53 manually verified outbound is explicit evidence only with all review fields',async()=>{
 const calls=[],result=await reviewUnverifiedSend({ticketId:'88149870',recipient:'a@example.invalid',assertTicket:async x=>{assert.equal(x,'88149870');},hasPendingDialogs:async()=>false,
  ask:async()=> 'VERSAND_88149870_GEPRUEFT',record:(e,d)=>calls.push([e,d])});
 assert.equal(calls.length,1);assert(validSendAcknowledgements({htmlDialogs:0,jsDialogs:0,successNotices:0,...result}));
 for(const k of ['operatorReviewed','operatorTicketBound','operatorRecipientReviewed','operatorContentReviewed','noPendingDialogs'])assert(!validSendAcknowledgements({htmlDialogs:0,jsDialogs:0,...result,[k]:false}));
});
test('RC53 blank, foreign ticket or open dialog cannot confirm previously sent mail',async()=>{
 for(const answer of ['', 'JA','VERSAND_88149871_GEPRUEFT'])await assert.rejects(()=>reviewUnverifiedSend({ticketId:'88149870',recipient:'a@example.invalid',assertTicket:async()=>{},hasPendingDialogs:async()=>false,ask:async()=>answer}),e=>e.code==='SEND_UNVERIFIED');
 await assert.rejects(()=>reviewUnverifiedSend({ticketId:'88149870',recipient:'a@example.invalid',assertTicket:async()=>{},hasPendingDialogs:async()=>true,ask:async()=>{throw Error('unexpected');}}),e=>e.code==='SEND_REVIEW_DIALOG_OPEN');
});
test('RC53 STOP prevents every further automated mouse or keyboard event',async()=>{
 const x=createDeliveryConsole({platform:'linux'});let sent=0;const cdp={send:async()=>{sent++;return {};}};x.protectInput(cdp);
 x.gate.accept(msg('abort'));await assert.rejects(()=>cdp.send('Input.dispatchKeyEvent',{}),e=>e.code==='OPERATOR_ABORT');assert.equal(sent,0);
 await cdp.send('Runtime.evaluate',{});assert.equal(sent,1);x.close();
});
