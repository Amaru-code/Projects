# MCR Flow Lab 1.1
## Lesbare Diagramme, Fahrplan und lesender Lauf-Monitor

**Projektbasis: RC93 · Präsentationsoberfläche 1.1 · 14. November 2026**

Dies ist keine neue Ticketbot-Version. Die installierte MCR DATENBRUECKE, ihre Konfiguration, Browserprofile, Bestandsdateien und Journale werden nicht geändert.

## Sofort starten

`MCR_Flow_Lab_1_1.html` vollständig herunterladen und in einem normalen Edge- oder Chrome-Fenster öffnen. Nicht in der statischen Markdown-Vorschau. Die Diagramme, der Simulator und das Beispielprotokoll sind vollständig eingebettet; kein Internet, Server oder zusätzliche Installation ist für die Präsentation nötig.

Oben gibt es jetzt drei Ansichten:

| Reiter | Verwendung |
|---|---|
| **01 · Diagramme** | Originalkarten, freie Entscheidungen und Ticket-Simulation. |
| **02 · Fahrplan** | Gesamtes Projekt auf einer kompakten, geordneten Oberfläche. |
| **03 · Live-Monitor** | Vorhandene lokale Botprotokolle ausschließlich lesen und ihren Verlauf auf der Karte anzeigen. |

Die Simulatorsteuerung lässt sich über **Steuerung ausblenden** wegklappen. Das separate Simulatorfenster über ↗ bleibt erhalten.

## Die vier Bedienungsverbesserungen

### Schrift und Zoom

Das Diagrammfeld ist weiß. Knotentexte bleiben dunkel und werden außerhalb des grünen Pfads nicht mehr durchsichtig dargestellt. Wo die vorhandene Knotengröße es zulässt, werden Beschriftungen kräftiger gesetzt. Die Textbreite wird innerhalb der Knoten angepasst; kein Text wird nur zugunsten einer fetteren Schrift abgeschnitten.

Beim sehr starken Herauszoomen kann die gesamte Originalkarte nicht gleichzeitig in normaler Leseschrift dargestellt werden. Deshalb gibt es das **Lesefenster** mit konstanter Schriftgröße: Beim Überfahren oder Auswählen eines Knotens steht dort dessen vollständiger Text unabhängig vom Zoom. Mit **Aa Lesen** oder **Lesbar fokussieren** springt die Karte auf eine lesbare Detailgröße.

Das Lesefenster lässt sich mit − einklappen. Die Minikarte steht rechts, damit sie es nicht verdeckt.

### Weißes Feld ohne Raster

Das graue Punktraster ist vollständig entfernt. Die Hintergrundfläche des Diagramms ist rein weiß; Funktionsfarben und der grüne Verlauf bleiben bestehen.

### Letzte Entscheidung zurück

**↶ Entscheidung zurück** nimmt im freien Modus die zuletzt gewählte Verzweigung zurück, zentriert diese Entscheidung und lässt dort einen anderen Ausgang wählen. Das ist bewusst etwas anderes als der kleine Schritt-zurück-Knopf der Abspielleiste: Der verschiebt nur die Abspielposition.

Tastatur: **Alt + Pfeil links** oder **Rücktaste**, solange du nicht in einem Eingabefeld schreibst. Die Funktion ist auch im separaten Simulatorfenster verfügbar.

Bei mehreren Kanten zum selben Ziel wird nun die tatsächlich gewählte Kante markiert. Beispielsweise bleiben „DB/DB+“ und „unbekanntes Möchte …“ unterscheidbar, obwohl beide zur Direktweiterleitung führen.

### Ziehen ohne blaue Textauswahl

Linke Maustaste gedrückt halten und ziehen verschiebt das Diagramm – auch wenn der Griff auf einem Knotentext beginnt. Währenddessen wird keine Browser-Textauswahl erzeugt. Die normalen Eingabefelder außerhalb des Diagramms bleiben editierbar und auswählbar.

## Der neue Fahrplan

Die 12 Originaldiagramme mit **341 Knoten und 429 Kanten** bleiben erhalten. Der Fahrplan bündelt sämtliche Originalknoten genau einmal in **42 Stationen auf 7 Linien**:

A. Start, Schutz und Menü 1–5.
B. Eingang, Namenssuche, Member und Bestand.
C. Sprache, Antwort, Freigabe, Versand und Speicherung.
D. Die vier Beschreibungsblöcke und ihre Fachwege.
E. PDFs, Entwurf, Speichern, Mark und Routing.
F. Wiederholbare Leseprüfungen, Rückstellung, Unterbrechung, Reparatur und Ergebnis.
G. Geplante LenX-/Review-Erweiterungen und weitere Abnahme.

**Klick auf eine Station:** Vollständige zugehörige Knotentexte mit Herkunft öffnen. Ein weiterer Klick springt exakt in den Originalknoten samt seinen Ausgängen. Es wurde keine Funktion aus der Originalkarte entfernt.

Die gedruckte Fahrplankarte ist eine verdichtete Übersicht, nicht der vollständige Wortlaut aller 341 Knoten auf Papier. Die vollständigen Texte und verschachtelten Verzweigungen bleiben digital per Klick erreichbar. Menüzugänge und Fachwege sind Alternativen, keine zwingend nacheinander ausgeführten Schritte. Für die genaue Reihenfolge und Schleifen bleibt das Originaldiagramm maßgeblich.

**Ein Blatt drucken** verwendet ein Layout für **A3 quer**. Im Druckdialog A3, Querformat, 100 % und bei Bedarf Hintergrundgrafiken wählen; Browser-Kopf-/Fußzeilen abschalten. A4 ist möglich, verkleinert aber die Schrift. Am Desktop wurde die komplette Übersicht bei 1600 × 1000 sowie 1440 × 900 ohne abgeschnittene Linien geprüft. Auf kleinen Displays darf die Ansicht scrollen.

## Karte, Browser und Terminal parallel

### Die drei Bildschirme

**Bildschirm 1:** Flow Lab im normalen Browser, beobachtete Karte.

**Bildschirm 2:** Der vom Ticketbot gestartete eigene COMARCH-Edge.

**Bildschirm 3:** Das Terminal mit dem unveränderten Botlauf.

### So verbindest du den Lauf

1. Im Flow Lab **Live-Monitor → .runtime-Ordner verbinden** anklicken.
2. Den Ordner `.runtime` der **installierten** `MCR_Datenbruecke` auswählen und den Lesezugriff erlauben. Nicht `private_data` und nicht den heruntergeladenen ZIP-Ordner auswählen.
3. Erst danach den Bot wie gewohnt über `START.cmd` und Menü 3, 4 oder 5 starten.
4. **Beobachteten Weg zeigen** öffnet die Karte. „Karte folgt dem aktuellen Schritt“ kann ein- oder ausgeschaltet werden.

Der Monitor kontrolliert ungefähr alle 1,2 Sekunden die jüngsten passenden Dateien:

- `reports/MCR_ECHTLAUF_*.log` und die vorhandenen Completion-only-Laufprotokolle;
- `phase2/MCR_PHASE2_LAUF_*.log`;
- `master/MCR_MASTER_RUN_*.json` für Zustände und Abschlussberichte.

Er liest nur diese freigegebenen Dateien. Es gibt **keine Schreibberechtigung**, keine Befehle an den Bot, keine CDP-Verbindung, keine Freigabe eines Tickets, keine PDF-Öffnung und keine Netzwerkübertragung. Die Anwendung enthält weiterhin eine Content-Security-Policy mit `connect-src 'none'`.

**Beim Verbinden vorhandene Logzeilen werden nicht als neue Live-Ereignisse abgespielt.** Verbinde deshalb vor dem Start. Zum Nachverfolgen eines bereits abgeschlossenen oder teilweise vergangenen Laufs gibt es **Log wiedergeben**. Diese Ansicht ist ausdrücklich als historische Wiedergabe gekennzeichnet.

**Einzelnes Log verfolgen** kann alternativ eine konkrete Datei beobachten. Es folgt dann nur dieser einen Datei – nicht automatisch dem Wechsel zwischen Phase 1 und Phase 2. Für den ganzen Master-Run ist die Ordnerverbindung vorgesehen.

### Was die grüne Live-Linie bedeutet

Sie markiert erkannte Ereignisse aus dem Protokoll. Ticket-ID, Phase, Filter-Reklick, Versandprüfung, Speichern, Weiterleitung, Rückstellung und Masterabschluss werden auf vorhandene Diagrammknoten abgebildet. Ticket-IDs sind für Präsentationen zunächst teilweise maskiert.

Nicht jeder interne Botschritt besitzt eine eigene Logmeldung. Es werden daher **keine fehlenden Zwischenstationen hinzuerfunden und keine Lücken automatisch grün verbunden**. Ein Speicher- oder Weiterleitungsklick ist noch kein Erfolgsnachweis. `NETWORK_QUIET` wird nicht zu „gespeichert“ umgedeutet. Nicht zugeordnete Zeilen werden gezählt, aber nicht als durchlaufene Knoten dargestellt.

Die Reihenfolge zwischen getrennten Logdateien ist eine Lese-/Empfangsreihenfolge. Die Dateien haben nicht auf jeder Zeile einen gemeinsamen Zeitstempel. Dies ist deshalb eine Präsentationsbeobachtung und kein neuer rechtsverbindlicher oder transaktionaler Auditnachweis. Verbindlich bleiben die produktiven Botjournale und COMARCH.

**Zur Simulation** trennt die Darstellung vom beobachteten Pfad. Die Verbindung kann weiter lesen, verändert aber keine Simulationseinstellungen. **Trennen** beendet den Lesezugriff vollständig; der Bot selbst läuft unabhängig weiter.

### Berechtigungen und Grenzen

Die Ordnerbeobachtung verwendet die File System Access API. Sie verlangt eine ausdrückliche Browserfreigabe; Unternehmensrichtlinien können diese Funktion sperren. Die Datei verändert oder umgeht keine Richtlinie. Bei fehlender API oder verweigerter Freigabe bleibt die historische Log-Wiedergabe verfügbar.

Für die ersten produktiven Tests am Arbeitsplatz ist noch zu prüfen, ob dein verwalteter Edge den lokalen Ordnerzugriff erlaubt und ob die gewünschten produktiven Logstellen alle im Monitor sichtbar sind. Der Monitor ist lokal mit Dateihandle-Testdoubles, wachsenden Dateien, Teilzeilen und Lesefehlern geprüft, **nicht in deinem Windows-COMARCH-Echtlauf abgenommen**.

Die dargestellten Daten bleiben im Arbeitsspeicher des Browserfensters. Kein automatisches Hochladen und kein automatisches Speichern der Logs. Szenarioexporte aus dem vorhandenen Simulator können wie bisher eingegebene Werte enthalten; für Präsentationen fiktive Daten verwenden.

## Demo ohne Produktivdaten

Unter **Live-Monitor → Fiktive Demo** wird ein eingebetteter Beispiellauf geladen: ein intern weitergeleitetes Ticket, ein sicher zurückgestellter Altfall und ein Abschluss mit offenem Fall. Das ist keine echte COMARCH-Ausführung.

Das Paket enthält zusätzlich `Fiktives_Laufprotokoll.log`. Es kann mit **Log wiedergeben** importiert werden. Jede Zeile ist fiktiv.

## Basis und Abgrenzung

- Original: `MCR_Flow_Lab_RC93.html` und `MCR_Ticketbot_RC93_Projektlandkarte.md` aus diesem Chat.
- Für den Live-Leser geprüft: RC93-Dateinamen und Meldungen in `tools/cli.mjs`, `src/phase2-run.mjs`, `lib/master-completion.mjs` und `lib/phase2-ticket-console.mjs`.
- Die Regel-/Sprachmodule des Präsentationsmodells und alle zwölf Graphdaten sind unverändert übernommen.
- Die Anzeige führt keine produktiven Botmodule aus.
- LenX, fachlicher Review, Korrekturschleife und endgültiger Kundenversand bleiben als zukünftige Entwicklung markiert.

Technische Dokumentation zum Dateizugriff:

Chrome Developers, „The File System Access API: simplifying access to local files“:
`https://developer.chrome.com/docs/capabilities/web-apis/file-system-access`

Microsoft Learn, Edge-Richtlinie „DefaultFileSystemReadGuardSetting“:
`https://learn.microsoft.com/en-us/deployedge/microsoft-edge-browser-policies/defaultfilesystemreadguardsetting`
