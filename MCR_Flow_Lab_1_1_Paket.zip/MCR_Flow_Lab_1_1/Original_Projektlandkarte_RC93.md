# MCR Ticketbot — Projektlandkarte RC93

**MCR DATENBRUECKE · Stand 13. November 2026 · Ist-Zustand und Phase-3-Zielbild**

> **Meilenstein erreicht:** Im zuletzt gemeldeten RC93-Master-Run wurde das letzte sichtbare DB-Ticket weitergeleitet. **0 offene Fälle im tatsächlich geprüften Bereich.** Die Ticketbearbeitung in Phase 1 und Phase 2 ist damit für diesen Bestand abgeschlossen — nicht automatisch auch der spätere fachliche Review oder Kundenversand.

Diese Datei ist eine **Präsentations- und Architekturdokumentation**, keine neue Botversion. Sie enthält ein Gesamtdiagramm und zusammengehörige Detaildiagramme. Die Detailansichten machen auch die Fehler- und Wiederaufnahmewege lesbar, die in einem einzigen Riesendiagramm kaum präsentierbar wären. Alle produktiven `lib/`, `src/`- und `tools/`-Dateien des bereitgestellten RC93-Pakets sind zusätzlich im Modulverzeichnis erfasst.

## Präsentieren in VS Code

Die Datei öffnen und **Strg+Umschalt+V** für die Markdown-Vorschau verwenden; **Strg+K, danach V** öffnet die Vorschau daneben. Die aktuelle VS-Code-Dokumentation beschreibt Mermaid-Blöcke in der integrierten Vorschau sowie Schwenken und Zoomen. Bei einer älteren Unternehmensinstallation kann dafür noch Mermaid-Unterstützung fehlen; aus einer fehlenden Darstellung folgt kein Fehler im Ticketbot. Für die Präsentation zunächst Diagramm 01 zeigen, danach über die Gliederung in die Detailansichten wechseln. [S4]

**Legende:** Blau = vorhandene RC93-Funktion; Gelb = Benutzereingriff oder Fachentscheidung; Grün = nachgewiesenes Ergebnis; Rot = Fehler/Sperre; Grau = lokale Daten oder Nachweis; Violett mit gestrichelter Umrandung = geplant, noch nicht produktiv. Eine gestrichelte Verbindung bedeutet Ergänzung, Bezug oder zukünftigen Übergang. Farben sind zusätzliche Orientierung; die Texte nennen den Status ebenfalls.

## Inhalt

01. [Gesamtdiagramm: vom Start zum Ergebnis](#01-gesamtdiagramm)
02. [Menü 1 und 2: Installation und Bestandsdaten](#02-installation-und-mapping)
03. [Menü 3, 4 und 5: Laufsteuerung](#03-laufsteuerung)
04. [Phase 1: Identität und Bestandsabgleich](#04-phase-1-identitaet)
05. [Phase 1: Sprache, Antwort, Versand und Speichern](#05-phase-1-antwort-und-versand)
06. [Zusätzliche Beschreibung und Entscheidungsregeln](#06-beschreibung-und-fallentscheidung)
07. [Phase 2: Kontoauszug](#07-phase-2-kontoauszug)
08. [Phase 2: direkte Weiterleitung, MBC und Review-Übergabe](#08-phase-2-routing-und-review-uebergabe)
09. [Fehler, Workarounds und Wiederaufnahme](#09-fehler-und-wiederaufnahme)
10. [Daten, Technik, Statusfenster und Outputs](#10-daten-und-technik)
11. [Phase 3: LenX und fachlicher Review — geplant](#11-phase-3-geplant)
12. [Roadmap und Abnahmekriterien](#12-roadmap)
13. [Fehlercode-Katalog und historische Reparaturen](#13-fehlercode-katalog)
14. [Vollständiges Modulverzeichnis](#14-modulverzeichnis)
15. [Quellen und Prüfstatus](#15-quellen)

## Stand und belastbare Aussage

| Bereich | Stand / Grenze |
|---|---|
| Phase 1 | Automatischer Standardweg von Sichtung bis Antwort und Speicherung vorhanden. Identitätskonflikte, unklare Sprache, Texteingriffe oder fehlende Nachweise können weiterhin menschliche Prüfung verlangen. |
| Zeile 3 | **Heute vom Benutzer eingetragen.** Ein erfolgreicher Phase-1-Lauf erzeugt nicht automatisch einen fachlich klassifizierten Kundenwunsch. |
| Phase 2 | Beschreibungsbasierte Fachbearbeitung und interne Weiterleitung vorhanden. **Kein Kunden-E-Mail-Versand.** PDFs werden bei Bedarf weiterhin außerhalb des Bots durch den Benutzer erzeugt. |
| Letzter RC93-Lauf | Phase 1: 0 neue geeignete Tickets; Phase 2: 1 bestätigte Weiterleitung; danach 0 offene Fälle in den geprüften Listen. |
| Deutsch / Englisch | Seit RC88 vorhanden; ein englischer Versand ist im gelieferten RC88-Protokoll belegt. Eine systematische Abnahme über DE, EN, Mischtexte und Weiterleitungen bleibt offen. Die gewünschte Bindung an die **erste Member-E-Mail** muss ausdrücklich getestet werden. |
| Phase 3 | LenX-Anbindung, Skill für Zeile 3, fachlicher Review, Überarbeitung und Versand nach Freigabe sind **Zielbild**, nicht RC93-Funktion. |
| Gesamtabschluss | Bezieht sich auf geprüfte, sichtbare und sicher zugeordnete COMARCH-Listen. Keine Aussage über nicht eingesehene Seiten, andere Gruppen oder später neu eintreffende Tickets. |

**Wo ist die Fertigmeldung?** Sie steht in der Konsole nach dem Phase-2-Fehlerbericht unter `MASTER RUN - ABSCHLUSS`. Anschließend werden Berichtspfade ausgegeben, der gemeinsame Master-Edge geschlossen und das Hauptmenü wieder angeboten. Eine prominentere, stehenbleibende Abschlusskarte im Panel ist als UI-Verbesserung geplant. [S1, S2]

```text
MASTER RUN - ABSCHLUSS
Alle Tickets bearbeitet (im geprueften, sichtbaren Bereich)
Phase 1 bearbeitet: 0 | Phase 2 weitergeleitet: 1
ERGEBNIS: Alle Tickets im geprueften Bereich bearbeitet;
          0 Tickets konnten nicht bearbeitet werden.
OFFENE FAELLE: 0 in den geprueften Listen.
```

<a id="01-gesamtdiagramm"></a>

## 01 · Gesamtdiagramm

```mermaid
flowchart TB
    START(["Benutzer startet START.cmd"]) --> GUARD["Node, Paketintegrität und Betriebssperren prüfen"]
    GUARD --> VALID{"Startbedingungen gültig?"}
    VALID -->|Nein| SYS["Keine Echtaktion<br/>Fehlercode, Ursache und Handlung anzeigen"]
    VALID -->|Ja| MENU{"Hauptmenü RC93"}
    MENU -->|1| INSTALL["Schnellinstallation<br/>Software sichern, prüfen und austauschen"]
    MENU -->|2| MAP["Bestandsmapping kontrolliert regenerieren<br/>Freigegebene XLSX lesen; Quelle unverändert"]
    MENU -->|3| ONLYP1["Nur Phase 1<br/>Pilot und kontrollierte Folgeläufe"]
    MENU -->|4| ONLYP2["Nur Phase 2<br/>Vorbereitete eigene Tickets"]
    MENU -->|5| MASTER["Master-Run<br/>Phase 1, danach Phase 2"]
    MENU -->|0| EXIT(["Programm beenden"])
    MENU -->|Andere Eingabe| MENUHINT["Gültige Auswahl 0 bis 5 anzeigen"]
    MENUHINT --> MENU
    INSTALL --> BACK["Ergebnis anzeigen<br/>Installiertes Hauptmenü"]
    MAP --> BACK
    SYS --> BACK
    BACK --> MENU
    ONLYP1 --> COMMON["ENTER-Freigabe<br/>Sitzung und Mapping binden"]
    MASTER --> COMMON
    COMMON --> EDGE["Ein eigener Edge-Prozess<br/>Frische gebundene Seiten je Teillauf"]
    EDGE --> P1SCAN["Phase 1: eigene Intel-Vorgänge<br/>und INTL01-Warteschlange prüfen"]
    P1SCAN --> P1NEXT{"Geeignetes Ticket vorhanden?"}
    P1NEXT -->|Ja| ID["Originalnachricht lesen<br/>Name suchen, COMARCH-Member verifizieren"]
    ID --> MAPCHECK["WWID zu USC und allen Planzeilen abgleichen"]
    MAPCHECK --> FOUND{"Person im freigegebenen Bestand?"}
    FOUND -->|Nein| NOMAP["Keine E-Mail<br/>Zuständigen Bearbeiter bewusst wählen"]
    FOUND -->|Ja| LANG["Sprache der Originalnachricht<br/>DE oder EN; unklar: D/E auswählen"]
    LANG --> REPLY["Standardantwort und INTL01-Signatur<br/>Pflichtfelder und Planblock vorbereiten"]
    REPLY --> SEND["Freigeben, genau einmal senden<br/>Ausgangsnachricht nachweisen"]
    SEND --> SAVE["Standardantwort-Status setzen<br/>Ticket speichern und Serverwerte nachlesen"]
    NOMAP --> P1PROOF["Interne Weiterleitung prüfen<br/>Kein E-Mail-Pilotnachweis"]
    SAVE --> P1DONE["Ticketabschluss und Bericht<br/>Nur bestätigtes Ergebnis zählen"]
    P1PROOF --> P1DONE
    P1DONE --> P1SCAN
    P1NEXT -->|Nein, Listen geprüft| MODE{"Nur Phase 1 gewählt?"}
    MODE -->|Ja| FINISH
    MODE -->|Nein, Master| Z3["Heute: Benutzer ergänzt Kundenwunsch<br/>in zusätzlicher Beschreibung"]
    ONLYP2 --> Z3
    Z3 -. "Zukünftiger Ersatz" .-> LENX["GEPLANT: Phase 3A<br/>LenX und Skill erstellen geprüfte Anfragezeile"]
    LENX -. "Validierte Zeile, keine Versandfreigabe" .-> P2SCAN
    Z3 --> P2SCAN["Phase 2: eigene sichtbare Intel-Liste<br/>Beschreibung und alte Journale prüfen"]
    P2SCAN --> P2NEXT{"Freigegebener Fall vorhanden?"}
    P2NEXT -->|Ja| RULE{"Fachregel aus Beschreibung"}
    RULE -->|DB oder DB+ hat Vorrang| DIRECT["Direkt an Mark<br/>Keinen Bearbeitet-Vermerk ergänzen"]
    RULE -->|KA oder Kontoauszug| PDF["PDFs finden; Benutzer erzeugt fehlende<br/>Inhalte prüfen, anhängen, Anschreiben entwerfen"]
    RULE -->|Privater MBC-Login| MBC["Vorgegebenen MBC-Text als Entwurf<br/>mit INTL01-Signatur vorbereiten"]
    RULE -->|Unbekanntes Möchte| DIRECT
    RULE -->|Andere nicht leere Anfrage| ASK["Benutzer entscheidet<br/>ENTER oder Mark, überspringen, abbrechen"]
    ASK -->|Mark freigegeben| DIRECT
    ASK -->|Überspringen| OPEN["Offen mit Ursache dokumentieren"]
    RULE -->|Phase 1 fehlt oder Auftrag fehlt| OPEN
    PDF --> PREVIEW["Bearbeitet not reviewed<br/>Entwurf speichern und OK behandeln<br/>Ticket und Anlagen dauerhaft prüfen"]
    MBC --> PREVIEW
    PREVIEW --> REVIEW["Weiterleiten zur Überprüfung<br/>Nächster Bearbeiter: mark.baindl"]
    DIRECT --> ROUTE["Bearbeiter: mark.baindl<br/>Genau eine interne Weiterleitung"]
    REVIEW --> ROUTE
    ROUTE --> VERIFIED["ROUTED_VERIFIED<br/>Beleg und Abschlussbericht"]
    VERIFIED --> P2SCAN
    OPEN --> P2SCAN
    P2NEXT -->|Nein, sichtbare Liste geprüft| FINISH["Ergebnis zusammenstellen<br/>Erledigt, offen, Fehlercodes und Pfade"]
    FINISH --> ALL{"Noch offene Fälle?"}
    ALL -->|Nein| SUCCESS["Alle Tickets bearbeitet<br/>0 offene Fälle im geprüften Bereich"]
    ALL -->|Ja| PARTIAL["Alle derzeit bearbeitbaren Tickets bearbeitet<br/>X Tickets nicht bearbeitet; Gründe anzeigen"]
    SUCCESS --> CLOSE["Master-Edge schließen<br/>ENTER zum Hauptmenü"]
    PARTIAL --> CLOSE
    CLOSE --> MENU
    ID -. "Fehler oder Widerspruch" .-> ERR["Gemeinsame Fehlerbehandlung<br/>Nachweise und Aktionsjournal prüfen"]
    SEND -. "Nachweis fehlt" .-> ERR
    SAVE -. "Nachweis fehlt" .-> ERR
    P2SCAN -. "Lesefehler oder Altjournal" .-> ERR
    ROUTE -. "Abschluss unklar" .-> ERR
    ERR --> SAFE{"Sicher begrenzter Fehler<br/>ohne ungeklärte Schreibaktion?"}
    SAFE -->|Ja, erlaubter Fall| SAFEOPEN["Betroffenen Fall offen dokumentieren"]
    SAFEOPEN --> WHICH{"Aktueller Laufabschnitt?"}
    WHICH -->|Phase 1| P1SCAN
    WHICH -->|Phase 2| P2SCAN
    SAFE -->|Nein| HOLD["UNTERBROCHEN<br/>Keine Blindwiederholung; Zustand sichern"]
    HOLD --> BACK
    VERIFIED -. "Noch kein fachlicher Review" .-> P3B["GEPLANT: Phase 3B<br/>Review, Korrekturschleife, freigegebener Versand"]
    class START,GUARD,MENU,INSTALL,MAP,ONLYP1,ONLYP2,MASTER,COMMON,EDGE,P1SCAN,ID,MAPCHECK,LANG,REPLY,SEND,SAVE,P1PROOF,P2SCAN,RULE,DIRECT,PDF,MBC,PREVIEW,REVIEW,ROUTE,FINISH,CLOSE,BACK current;
    class Z3,ASK,NOMAP human;
    class SUCCESS,P1DONE,VERIFIED good;
    class SYS,ERR,HOLD,OPEN,SAFEOPEN,PARTIAL error;
    class LENX,P3B future;
    classDef default fill:#e8f1ff,stroke:#245b95,color:#102c49,stroke-width:1.3px;
    classDef current fill:#e8f1ff,stroke:#245b95,color:#102c49,stroke-width:1.4px;
    classDef human fill:#fff1cf,stroke:#a46a08,color:#4f3303,stroke-width:1.4px;
    classDef good fill:#e2f3e8,stroke:#287344,color:#153f26,stroke-width:1.6px;
    classDef error fill:#fce6e6,stroke:#a93535,color:#5c1616,stroke-width:1.4px;
    classDef future fill:#f0e8fb,stroke:#7753a5,color:#3a2456,stroke-width:1.5px,stroke-dasharray:5 4;
    classDef store fill:#edf0f4,stroke:#65768a,color:#263545,stroke-width:1.2px;
```

**Quellbezug:** RC93 `tools/cli.mjs`, `src/local-bot-full-run.mjs`, `src/phase2-run.mjs`, `lib/phase2-description.mjs`; Phase-3-Erweiterung: Nutzerziel [S3].

**Nicht verwechseln:** Die grüne interne Übergabe bedeutet „vom Bot vorbereitet/weitergeleitet“, nicht „vom Reviewer fachlich freigegeben“ und nicht „Kundenantwort versendet“. Die Eintragung des Kundenwunsches geschieht heute außerhalb der automatischen Master-Steuerung; der Knoten zeigt diese fachliche Voraussetzung, keinen bereits implementierten interaktiven LenX-Schritt.

<a id="02-installation-und-mapping"></a>

## 02 · Menü 1 und 2: Installation und Mapping

```mermaid
flowchart TB
    CHOICE{"Benutzer wählt"}
    subgraph UPDATE["MENÜ 1 · Software aktualisieren"]
      U1["Zielinstallation wählen<br/>ENTER übernimmt bisherigen Pfad"] --> U2{"Start bereits aus Zielinstallation?"}
      U2 -->|Ja| USTATUS["Paket- und Statusbericht<br/>Kein erneutes Einspielen"]
      U2 -->|Nein| U3["Altversion und neues Manifest prüfen<br/>Dateihashes und zulässige Dateien"]
      U3 --> U4["Migrationssperre setzen<br/>Nur zugeordnete Bot-Prozesse und Bot-Edge stoppen"]
      U4 --> U5["Aktuelle Datenbindung einfrieren<br/>Software archivieren und Staging vorbereiten"]
      U5 --> U6["Software ersetzen und prüfen<br/>private_data, Config, Laufdaten und Profil erhalten"]
      U6 --> UOK{"Installation verifiziert?"}
      UOK -->|Ja| U7["PASS INSTALLATION_COMPLETE<br/>Archivpfad anzeigen; installiertes Menü öffnen"]
      UOK -->|Nein| UR["Fehler melden; Software-Rückweg<br/>Keine COMARCH-Aktionen rückgängig machen"]
      U3 -. "Integrität fehlt" .-> UERR["Update verweigern<br/>Kein Versand, kein Ticketzugriff"]
    end
    subgraph MAPPING["MENÜ 2 · Lokales Bestandsmapping pflegen"]
      M1["Paket und aktives Mapping prüfen<br/>Keine offenen Aktionssperren; Bot ruht"] --> M2["Wartung bewusst freigeben<br/>Pfad zur Original-XLSX eingeben"]
      M2 --> M3{"Quellhash entspricht<br/>freigegebenem Bestandsstand?"}
      M3 -->|Nein| MERR["SOURCE_CHANGED<br/>Keine neue Quelle automatisch aktivieren"]
      M3 -->|Ja| M4["Blatt Output lesen<br/>B ID; C DC; D PP+; E DB+; F TPP; L USC; O Anrede"]
      M4 --> M5["Alle Quellzeilen in Originalreihenfolge<br/>Leere Flags nicht als aktive Pläne werten"]
      M5 --> M6["Fehlerhafte Personen vollständig sperren<br/>Keine Teilübernahme beschädigter Zeilen"]
      M6 --> M7["Zusammenfassung anzeigen<br/>Benutzer bestätigt Aktivierung"]
      M7 --> M8["Neue versionierte Mappingdatei plus Hash<br/>Alten Aktivierungszeiger sichern"]
      M8 --> M9["active-mapping.json umstellen<br/>Hash und Bindung erneut lesen"]
      M9 --> MOK{"Aktivierung gültig?"}
      MOK -->|Ja| M10["PASS MAPPING_ACTIVE<br/>Neuer Snapshot verlangt neuen Versandpiloten"]
      MOK -->|Nein| MFAIL["Kein Ticketlauf freigegeben<br/>Aktivierungszeiger prüfen"]
    end
    CHOICE -->|1| U1
    CHOICE -->|2| M1
    U7 --> RETURN["Ergebnis und Pfade anzeigen<br/>Zurück zum Hauptmenü"]
    USTATUS --> RETURN
    UR --> RETURN
    UERR --> RETURN
    MERR --> RETURN
    M10 --> RETURN
    MFAIL --> RETURN
    class U1,U3,U4,U5,U6,M1,M4,M5,M6,M8,M9,RETURN current;
    class M2,M7 human;
    class U7,M10,USTATUS good;
    class UR,UERR,MERR,MFAIL error;
    classDef default fill:#e8f1ff,stroke:#245b95,color:#102c49,stroke-width:1.3px;
    classDef current fill:#e8f1ff,stroke:#245b95,color:#102c49,stroke-width:1.4px;
    classDef human fill:#fff1cf,stroke:#a46a08,color:#4f3303,stroke-width:1.4px;
    classDef good fill:#e2f3e8,stroke:#287344,color:#153f26,stroke-width:1.6px;
    classDef error fill:#fce6e6,stroke:#a93535,color:#5c1616,stroke-width:1.4px;
    classDef future fill:#f0e8fb,stroke:#7753a5,color:#3a2456,stroke-width:1.5px,stroke-dasharray:5 4;
    classDef store fill:#edf0f4,stroke:#65768a,color:#263545,stroke-width:1.2px;
```

**Quellbezug:** `tools/deploy.mjs`, `tools/integrity.mjs`, `lib/migration-priority.mjs`, `src/export-multirow.mjs`, `lib/active-mapping.mjs`, `lib/multirow-tpp-mapping.mjs`.

**Wichtige Ist-Grenze bei Menü 2:** Der Name „Bestandsdaten aktualisieren“ bedeutet im vorhandenen Exporter nicht, dass eine beliebige neue XLSX akzeptiert wird. RC93 verlangt denselben bereits freigegebenen Quellhash. Ein künftig regulärer Import eines neuen Bestandsstichtags benötigt einen eigens freigegebenen Aktualisierungsprozess. Die Anredequelle kann Spalte O sein; Vor- und Nachnamen werden damit nicht aus dieser Mappingdatei bezogen.

Die Installation führt weder einen Echtversand noch automatisch die vollständige Testsuite aus. Interne Wartung ist weiterhin über `--status`, `--selftest`, `--demo`, `--review` und `--rollback` vorhanden. Ein Software-Rollback kann eine bereits versendete Nachricht oder eine COMARCH-Weiterleitung nicht zurücknehmen.

<a id="03-laufsteuerung"></a>

## 03 · Menü 3, 4 und 5: Laufsteuerung und Browserbesitz

```mermaid
flowchart TB
    SEL{"Arbeitsmodus"} -->|3| P1ONLY["Phase-1-Lauf ohne Phase 2"]
    SEL -->|5| FULL["Master: Phase 1 und Phase 2"]
    SEL -->|4| P2ONLY["Phase 2 separat<br/>Optional Startticket, danach weitere Fälle"]
    P1ONLY --> RELEASE["ENTER-Freigabe<br/>Version, Mapping, Run-ID und Sperren prüfen"]
    FULL --> RELEASE
    RELEASE --> OLD{"Ungeklärter früherer Pilot?"}
    OLD -->|Ja| REC["Prüfen ohne Neuversand oder gesperrt auslassen<br/>Benutzer entscheidet; Journal erhalten"]
    OLD -->|Nein| BROWSER["Koordinator startet genau einen Bot-Edge<br/>Unterläufe erhalten nur eine gebundene Sitzung"]
    REC --> BROWSER
    BROWSER --> CERT{"Gültiger Versandpilot<br/>für genau Paket und Mapping vorhanden?"}
    CERT -->|Nein| PILOT["Einzelticket-Pilot<br/>Frische Seite und Ticketbindung"]
    PILOT --> RESULT{"Pilot-Ergebnis"}
    RESULT -->|Versand plus Speicherung belegt| PCERT["Versions- und mappinggebundene<br/>Pilotfreigabe speichern"]
    RESULT -->|Weiterleitung ohne E-Mail belegt| PILOT
    RESULT -->|Keine geeigneten Tickets in beiden Listen| EMPTY["Phase 1 ohne neuen Versand beendet"]
    RESULT -->|Nachweis unklar| STOP["UNTERBROCHEN<br/>Kein E-Mail-Batch und keine falsche Freigabe"]
    PCERT --> BATCH["Batch mit höchstens 100 Tickets<br/>Je Unterlauf neue sichere Seite"]
    CERT -->|Ja| BATCH
    BATCH --> MORE{"Batch vollständig ausgewertet?"}
    MORE -->|Leerprüfung bestätigt| EMPTY
    MORE -->|100 Aktionen und weiterer Block erlaubt| BATCH
    MORE -->|Grenze erreicht| LIMIT["Teilergebnis und Limit melden<br/>Limit ist kein Beweis einer leeren Liste"]
    MORE -->|Fehler oder unklarer Schreibzustand| STOP
    EMPTY --> MODE{"Nur Phase 1?"}
    MODE -->|Ja| P1END["Phase-1-Bericht und Rückkehr<br/>Keine Phase 2 gestartet"]
    MODE -->|Nein| P2MASTER["Phase 2 im selben Edge<br/>Neue gebundene COMARCH-Seite"]
    P2ONLY --> P2START["Separater Bot-Edge und ENTER-Startfreigabe"]
    P2START --> P2LOOP["Geeignete sichtbare eigene Tickets<br/>einzeln und nachweisgebunden bearbeiten"]
    P2MASTER --> P2LOOP
    P2LOOP --> P2RESULT{"Liste geprüft / Ergebnis?"}
    P2RESULT -->|Weitere sichere Fälle| P2LOOP
    P2RESULT -->|Kein weiterer Kandidat| ENDREPORT["Abschluss, offene Tickets und Fehlerdateien"]
    P2RESULT -->|Ungeklärter irreversibler Schritt| STOP
    ENDREPORT --> CLOSE["Browserbesitzer beendet Edge<br/>ENTER führt zum Menü"]
    P1END --> CLOSE
    LIMIT --> CLOSE
    STOP --> INSPECT["Browser zur Sichtprüfung offenlassen möglich<br/>Vor neuem Lauf Besitz und Sperren klären"]
    class P1ONLY,FULL,P2ONLY,RELEASE,BROWSER,PILOT,BATCH,P2MASTER,P2START,P2LOOP,CLOSE current;
    class REC,INSPECT human;
    class PCERT,EMPTY,P1END,ENDREPORT good;
    class STOP,LIMIT error;
    classDef default fill:#e8f1ff,stroke:#245b95,color:#102c49,stroke-width:1.3px;
    classDef current fill:#e8f1ff,stroke:#245b95,color:#102c49,stroke-width:1.4px;
    classDef human fill:#fff1cf,stroke:#a46a08,color:#4f3303,stroke-width:1.4px;
    classDef good fill:#e2f3e8,stroke:#287344,color:#153f26,stroke-width:1.6px;
    classDef error fill:#fce6e6,stroke:#a93535,color:#5c1616,stroke-width:1.4px;
    classDef future fill:#f0e8fb,stroke:#7753a5,color:#3a2456,stroke-width:1.5px,stroke-dasharray:5 4;
    classDef store fill:#edf0f4,stroke:#65768a,color:#263545,stroke-width:1.2px;
```

**Quellbezug:** `tools/cli.mjs::masterRun`, `lib/continuation-policy.mjs`, `lib/master-browser-lease.mjs`, `lib/master-pilot-recovery.mjs`, `src/phase1-completion-only.mjs`.

**Grenzen transparent halten:** Phase 1 verwendet bis zu zehn Batches mit je höchstens 100 Aktionen und eine separat begrenzte Einzelticket-Pilotkette. Die konkrete Schleife, nicht ein Marketingversprechen „unbegrenzt“, ist maßgeblich. Phase 2 hat in RC93 standardmäßig höchstens 100 besuchte Kandidaten pro Lauf und arbeitet auf sichtbaren eigenen Vorgängen. Eine vollständige seitenübergreifende Inventur sowie der ausdrückliche Nachweis der Restmenge beim Erreichen der Phase-2-Grenze gehören in die nächste QA-Runde.

**Startticket bedeutet nicht Einzeltest:** In Menü 4 wird die eingegebene Ticket-ID zunächst bevorzugt/selektiert; nach bestätigtem Abschluss kann der Lauf weitere passende sichtbare Tickets bearbeiten. Im Master läuft Phase 2 ohne diese Startticket-Abfrage. Globale Freigaben ersetzen keine Identitäts-, PDF- oder Empfängerprüfung.

<a id="04-phase-1-identitaet"></a>

## 04 · Phase 1: Originalnachricht, Name und Member

```mermaid
flowchart TB
    Q["Meine Vorgänge und INTL01-Warteschlange<br/>Nur zulässige gebundene Intel-Ansichten"] --> ELIG{"Ticket geeignet und nicht bereits erledigt<br/>oder durch altes Sendejournal gesperrt?"}
    ELIG -->|Nein| SKIP["Grund protokollieren<br/>Nächsten Kandidaten prüfen"]
    ELIG -->|Ja| OPEN["Ticketzeile eindeutig anklicken<br/>Falls nötig manuell öffnen; ID erneut prüfen"]
    OPEN --> HISTORY["Mailhistorie klassifizieren<br/>Kunde, eigener Ausgang, System, unklar"]
    HISTORY --> OLD{"Standardantwort bereits vorhanden?"}
    OLD -->|Ja| NORESEND["Nicht erneut senden<br/>Nur erlaubte Status-/Abschlussprüfung"]
    OLD -->|Nein| NAME["Namenshinweise suchen<br/>Absenderanzeige, aktuelle Originalnachricht,<br/>explizite Namen, Signatur, E-Mail-Alias"]
    NAME --> MSG["Bei Bedarf gebundene Original-MSG lesen<br/>Keine pauschale PDF-Downloadfreigabe"]
    MSG --> CAND{"Sicherer Suchkandidat?"}
    CAND -->|Nein| LABEL["Sichtbare Vor-/Nachname-Labels prüfen<br/>mainForm:j_id5899 und mainForm:j_id5919"]
    LABEL --> HAVE{"Beide Namen plausibel und ticketgebunden?"}
    HAVE -->|Nein| MANUAL["Benutzer gibt Vor- und Nachnamen ein<br/>Originalticket kontrollieren"]
    HAVE -->|Ja| SEARCH["Memberfeld fokussieren und suchen"]
    MANUAL --> SEARCH
    CAND -->|Ja| SEARCH
    SEARCH --> SUG{"Vorschlag eindeutig?"}
    SUG -->|Nein| RECLICK["Einmal dasselbe Memberfeld erneut anklicken<br/>Filter aktivieren und neu lesen"]
    RECLICK --> SUG2{"Jetzt eindeutig?"}
    SUG2 -->|Nein| PICK["Benutzer wählt den richtigen Member<br/>ENTER; nicht nur freien Namen übernehmen"]
    SUG2 -->|Ja| PROFILE["COMARCH-Memberprofil lesen<br/>Numerische ID und getrennte Namensfelder"]
    SUG -->|Ja| PROFILE
    PICK --> PROFILE
    PROFILE --> CONFLICT{"Name, Person und Berechtigung konsistent?"}
    CONFLICT -->|Nein| REVIEW["Namenskonflikt offen anzeigen<br/>ID, Vorname, Nachname unabhängig prüfen"]
    REVIEW --> CONFIRM{"Eindeutig bestätigt?"}
    CONFIRM -->|Nein| IDOPEN["Keine E-Mail / keine ungeprüfte Weiterleitung<br/>Identitätsfall offen dokumentieren"]
    CONFIRM -->|Ja, ENTER nach Prüfung| VERIFIED["Verifizierte Person nur für dieses Ticket"]
    CONFLICT -->|Ja| VERIFIED
    VERIFIED --> LOOK["Aktives Mapping zuerst mit voller ID abfragen"]
    LOOK --> EXACT{"Treffer?"}
    EXACT -->|Ja| ROWS["Alle zugehörigen Quellzeilen behalten<br/>USC, DC, PP+, DB+, TPP und Anrede prüfen"]
    EXACT -->|Nicht gefunden und führende 11| PREFIX["Nur beim Lookup einmal Präfix 11 entfernen<br/>COMARCH-ID nicht verändern"]
    PREFIX --> PFOUND{"Treffer?"}
    PFOUND -->|Ja| ROWS
    PFOUND -->|Nein| NOTFOUND["Person nicht im Gesamtbestand gefunden<br/>Ohne E-Mail an Mark oder Victor nach Auswahl"]
    EXACT -->|Nicht gefunden ohne Fallback| NOTFOUND
    EXACT -->|ID_BLOCKED oder Datenfehler| MAPERR["Keine Teilübernahme<br/>Mappingfehler zur Prüfung"]
    ROWS --> NEXT["Zur Sprachwahl und Standardantwort"]
    SKIP --> Q
    NORESEND --> Q
    IDOPEN --> Q
    class Q,OPEN,HISTORY,NAME,MSG,LABEL,SEARCH,RECLICK,PROFILE,LOOK,PREFIX,ROWS,NEXT current;
    class MANUAL,PICK,REVIEW,NOTFOUND human;
    class VERIFIED good;
    class SKIP,IDOPEN,MAPERR,NORESEND error;
    classDef default fill:#e8f1ff,stroke:#245b95,color:#102c49,stroke-width:1.3px;
    classDef current fill:#e8f1ff,stroke:#245b95,color:#102c49,stroke-width:1.4px;
    classDef human fill:#fff1cf,stroke:#a46a08,color:#4f3303,stroke-width:1.4px;
    classDef good fill:#e2f3e8,stroke:#287344,color:#153f26,stroke-width:1.6px;
    classDef error fill:#fce6e6,stroke:#a93535,color:#5c1616,stroke-width:1.4px;
    classDef future fill:#f0e8fb,stroke:#7753a5,color:#3a2456,stroke-width:1.5px,stroke-dasharray:5 4;
    classDef store fill:#edf0f4,stroke:#65768a,color:#263545,stroke-width:1.2px;
```

**Quellbezug:** `src/local-bot-full-run.mjs`, `lib/name-probes.mjs`, `lib/person.cjs`, `lib/name-resolution.mjs`, `lib/comarch-name-labels.mjs`, `lib/member-review.mjs`, `lib/member-mapping.mjs`, `lib/mail-history-audit.mjs`.

**Namensspeicherung:** COMARCH ist die Stammdatenquelle. Der Bot hat keine zentrale neue Namensdatenbank in `private_data`; Suchhinweise entstehen im Ticketkontext. Lokale Prüfprotokolle und Entwurfssicherungen können dennoch Namen enthalten. Ein E-Mail-Alias ist kein Identitätsbeweis. Bei Stellvertretung, Namensvarianten oder vertauschter Feldreihenfolge darf der Bot nicht automatisch „passend machen“.

**Anrede:** Deutsche Herr/Frau-Anrede benötigt eine verifizierte Datenquelle beziehungsweise manuelle Entscheidung. Das Vorliegen eines vermeintlich männlichen oder weiblichen Vornamens genügt nicht. Englische Standardantworten verwenden die verifizierten Vor- und Nachnamen.

<a id="05-phase-1-antwort-und-versand"></a>

## 05 · Phase 1: Sprache, bearbeitbare Antwort und Versandnachweis

```mermaid
flowchart TB
    PERSON["Identität und Mapping bestätigt"] --> ORIGINAL["Kundentext der gebundenen Originalnachricht<br/>Zitierte ältere E-Mails und Signatur abgrenzen"]
    ORIGINAL --> LANG{"Lokale DE-/EN-Erkennung eindeutig?"}
    LANG -->|Deutsch| DE["Deutsche vorgegebene Standardantwort<br/>Sehr geehrter Herr / Sehr geehrte Frau + Nachname"]
    LANG -->|Englisch| EN["Englische vorgegebene Standardantwort<br/>Dear + Vorname + Nachname"]
    LANG -->|Kurz, gemischt, andere Sprache| CHOOSE["Benutzer wählt D oder E<br/>ENTER errät keine Sprache"]
    CHOOSE -->|D| DE
    CHOOSE -->|E| EN
    CHOOSE -->|Ungeklärt oder Abbruch| OPEN["Kein Versand<br/>Fehler P1_LANGUAGE_UNVERIFIED"]
    DE --> PREP["Second Level; Allgemeine Schriftwechsel;<br/>Personenschriftwechsel; INTL01-Signatur<br/>USC-/Planblock und Antwort vorbereiten"]
    EN --> PREP
    PREP --> MODE{"Versandmodus"}
    MODE -->|MANUELL| GATE["Benutzer gibt Aktion frei"]
    MODE -->|AUTO freigegeben| VERIFY["Ticket, Person, Empfänger und Pflichtfelder<br/>direkt vor Versand erneut prüfen"]
    GATE --> VERIFY
    VERIFY --> EDIT{"Sichtbarer Antworttext geändert?"}
    EDIT -->|Ja| EDITGATE["Änderung behalten; nicht überschreiben<br/>Benutzer prüft und gibt aktuellen Text frei"]
    EDITGATE -->|Weiter bearbeiten| EDITGATE
    EDITGATE -->|Bestätigt| HASH["Freigegebenen Inhalt an dieses Ticket<br/>und diesen Empfänger binden"]
    EDIT -->|Nein| HASH
    HASH --> INTENT["SEND_INTENT dauerhaft protokollieren"]
    INTENT --> CLICK["Genau ein Versandklick<br/>Zugehörige COMARCH-OK-Dialoge behandeln"]
    CLICK --> PROOF{"Neue passende Ausgangsnachricht<br/>im richtigen Ticket nachgewiesen?"}
    PROOF -->|Ja| SENT["Versand bestätigt"]
    PROOF -->|Noch nicht| WAIT["Bis zur Prüfgrenze nur nachlesen<br/>Keine zweite E-Mail senden"]
    WAIT -->|Automatisch belegt| SENT
    WAIT -->|Weiter unklar| HUMAN["Benutzer kontrolliert tatsächlichen Ausgang<br/>Empfänger, Inhalt, Fehler/Rückläufer"]
    HUMAN -->|Unabhängig bestätigt| SENT
    HUMAN -->|Nicht nachweisbar| BLOCK["Sendeversuch unklar<br/>Journal sperrt Neuversand"]
    SENT --> STATUS["USC-/Planblock erhalten<br/>Standardantwort versendet ergänzen"]
    STATUS --> SAVE["Ticket genau kontrolliert speichern<br/>Neu geladene Liste / Detailwerte lesen"]
    SAVE --> SAVED{"Speicherung bestätigt?"}
    SAVED -->|Ja| DONE["VERSAND_UND_SPEICHERUNG_VERIFIZIERT<br/>CSV-Spalten, Tagesbericht, Pilotnachweis"]
    SAVED -->|Nein| COMPLETEONLY["Nur Abschluss ohne Neuversand reparieren<br/>Sendejournal erhalten"]
    DONE --> LOOP["Nächster Kandidat gemäß Laufsteuerung"]
    ORIGINAL -. "Nächste Abnahme" .-> FIRST["GEPLANT ZU FESTIGEN:<br/>Sprache dauerhaft an erste Member-E-Mail binden"]
    class PERSON,ORIGINAL,DE,EN,PREP,VERIFY,HASH,INTENT,CLICK,WAIT,STATUS,SAVE,LOOP current;
    class CHOOSE,GATE,EDITGATE,HUMAN human;
    class SENT,DONE good;
    class OPEN,BLOCK,COMPLETEONLY error;
    class FIRST future;
    classDef default fill:#e8f1ff,stroke:#245b95,color:#102c49,stroke-width:1.3px;
    classDef current fill:#e8f1ff,stroke:#245b95,color:#102c49,stroke-width:1.4px;
    classDef human fill:#fff1cf,stroke:#a46a08,color:#4f3303,stroke-width:1.4px;
    classDef good fill:#e2f3e8,stroke:#287344,color:#153f26,stroke-width:1.6px;
    classDef error fill:#fce6e6,stroke:#a93535,color:#5c1616,stroke-width:1.4px;
    classDef future fill:#f0e8fb,stroke:#7753a5,color:#3a2456,stroke-width:1.5px,stroke-dasharray:5 4;
    classDef store fill:#edf0f4,stroke:#65768a,color:#263545,stroke-width:1.2px;
```

**Quellbezug:** `lib/phase1-language.mjs`, `lib/ticket-prep.cjs`, `lib/phase1-edited-reply.mjs`, `lib/send-dialog-policy.mjs`, `lib/operator-send-review.mjs`, `lib/post-send-status-retry.mjs`, `lib/status-columns.mjs`.

**DE/EN: umgesetzt ist nicht dasselbe wie vollständig abgenommen.** RC93 enthält eine lokale, regelbasierte Sprachindikation mit manueller D/E-Auswahl bei Unsicherheit. LenX ist dafür heute nicht erforderlich. Im gelieferten RC88-Protokoll steht bereits `PASS P1_SPRACHE: ENGLISCH` mit bestätigtem Versand. Noch zu prüfen sind insbesondere deutsche Vergleichsfälle, kurze Anfragen, mehrsprachige Signaturen, zitierte Gegen-Sprachen und die stabile Auswahl der ersten Member-Nachricht in langen Verläufen.

Die vorhandenen Kontoauszug- und MBC-Entwürfe in Phase 2 sind im untersuchten Code deutsch. Eine zugesicherte durchgehend zweisprachige Fachantwort darf daraus noch nicht abgeleitet werden. Die Phase-1-Standardtexte sind die vom Benutzer vorgegebenen Fassungen in `lib/ticket-prep.cjs`.

<a id="06-beschreibung-und-fallentscheidung"></a>

## 06 · Zusätzliche Beschreibung: Vertrag und Prioritäten

```mermaid
flowchart TB
    DESC["Zusätzliche Beschreibung des geöffneten Tickets"] --> BLOCK1["Logischer Block 1: USC und Pläne<br/>Beispiel: USC 20/ DC;PP+"]
    BLOCK1 --> BLOCK2["Logischer Block 2: Standardantwort versendet"]
    BLOCK2 --> BLOCK3["Logischer Block 3: Kundenwunsch<br/>Heute manuell; später LenX"]
    BLOCK3 --> BLOCK4["Logischer Block 4: Bearbeitungs-/Reviewstatus<br/>Nur bei tatsächlicher Fachbearbeitung"]
    BLOCK4 --> PARSE["Parser: Aufbau, Länge, Pläne und Status prüfen<br/>Bekannte Altformate gezielt akzeptieren"]
    PARSE --> VALID{"Struktur gültig und Phase 1 belegt?"}
    VALID -->|Nein| INVALID["PHASE1_REQUIRED oder BLOCKED<br/>Fehlergrund anzeigen; nichts erfinden"]
    VALID -->|Ja| JOURNAL{"Vorhandenes Aktionsjournal?"}
    JOURNAL -->|Ja| RESUME["Zuerst zulässige Wiederaufnahme prüfen<br/>Kein erneuter Upload/Versand/Routing nach Verdacht"]
    JOURNAL -->|Nein| DONE{"Bearbeitungs-/Reviewmarker vorhanden?"}
    DONE -->|Ja| ALREADY["Nicht als neue Fachbearbeitung behandeln<br/>Reviewstatus ist keine Versandfreigabe"]
    DONE -->|Nein| DB{"DB oder DB+ im Planblock?"}
    DB -->|Ja| DIRECT["DB_DIRECT<br/>Direkt an Mark, Beschreibung unverändert"]
    DB -->|Nein| MBC{"Privater MBC-Login angefragt?"}
    MBC -->|Ja| MBCR["MBC_PRIVATE_EMAIL<br/>Entwurf und Übergabe zum Review"]
    MBC -->|Nein| KA{"Möchte KA / Kontoauszug<br/>oder bekannte Schreibvariante?"}
    KA -->|Ja| PLANS{"DC / PP+ eindeutig?<br/>IPP-Altbezeichnung zusätzlich verifizieren"}
    PLANS -->|Ja| KAR["ACCOUNT_STATEMENT<br/>Alle benötigten DC-/PP+-PDFs"]
    PLANS -->|Nein| BADPLAN["PLANS_UNKNOWN / NO_DC_PP_PLAN<br/>Keine falsche PDF auswählen"]
    KA -->|Nein| WANTS{"Unbekanntes Möchte ...?"}
    WANTS -->|Ja| MARK["MARK_DIRECT<br/>Ohne Fachbearbeitung an Mark"]
    WANTS -->|Nein| NONEMPTY{"Andere nicht leere Anfragezeile?"}
    NONEMPTY -->|Ja| ASK["Originalwunsch prüfen lassen<br/>ENTER / Mark / Weiterleiten"]
    ASK -->|Freigegeben| MARK
    ASK -->|Übersprungen| DEFER["Offen mit Fehlergrund dokumentieren"]
    NONEMPTY -->|Nein| MISSING["NOT_REQUESTED<br/>Benutzer muss Wunsch klären oder ergänzen"]
    RESUME --> CURRENT["Gespeicherte Werte, richtige Felder<br/>und Journal bestimmen Fortsetzung"]
    class DESC,BLOCK1,BLOCK2,BLOCK3,BLOCK4,PARSE,DIRECT,MBCR,KAR,MARK,RESUME,CURRENT current;
    class ASK human;
    class INVALID,ALREADY,BADPLAN,DEFER,MISSING error;
    classDef default fill:#e8f1ff,stroke:#245b95,color:#102c49,stroke-width:1.3px;
    classDef current fill:#e8f1ff,stroke:#245b95,color:#102c49,stroke-width:1.4px;
    classDef human fill:#fff1cf,stroke:#a46a08,color:#4f3303,stroke-width:1.4px;
    classDef good fill:#e2f3e8,stroke:#287344,color:#153f26,stroke-width:1.6px;
    classDef error fill:#fce6e6,stroke:#a93535,color:#5c1616,stroke-width:1.4px;
    classDef future fill:#f0e8fb,stroke:#7753a5,color:#3a2456,stroke-width:1.5px,stroke-dasharray:5 4;
    classDef store fill:#edf0f4,stroke:#65768a,color:#263545,stroke-width:1.2px;
```

**Quellbezug:** `lib/phase2-description.mjs`, `lib/phase2-work-rules.mjs`, `lib/phase2-request-approval.mjs`, `src/phase2-run.mjs::choosePhase2Candidate`.

### Verbindliche Statusregeln

| Inhalt | Bedeutung | Schreibt ihn aktuell wer? |
|---|---|---|
| `USC …/ DC;PP+;DB+;TPP` | Freigegebene Bestandsinformationen, nur tatsächlich aktive Pläne | Phase 1 aus dem ID-gebundenen Mapping |
| `Standardantwort versendet` | Phase-1-Status für die weitere Fachzuordnung; ersetzt allein keinen technisch gebundenen Versandbeleg | Phase 1 nach Versandnachweis |
| `Möchte …` | Fachlicher Kundenauftrag | Heute Benutzer; geplant LenX-Skill |
| `Bearbeitet not reviewed` | Fachliche Vorbereitung erfolgt, Review noch nicht abgeschlossen | Phase 2 nach Bearbeitung; **nicht** bei DB-/Mark-Direktweiterleitung |
| `reviewed` / vorhandener Abschlussstatus | Hinweis auf bereits vorbereiteten/überprüften Vorgang | Heute bestehender Prozess; künftige sichere Reviewfreigabe in Phase 3 noch zu entwerfen |

**Mehrzeilenmapping:** Bei mehreren Quellzeilen können mehrere USC-Zeilen am Anfang stehen. „Zeile 2, 3, 4“ ist deshalb der fachliche Normalfall, nicht für alle Tickets eine feste physische Zeilennummer. Ein LenX-Skill muss später den Auftrag **nach dem gesamten Planblock und dem Versandstatus** platzieren.

**Eingebaute Sonderfälle:** `Stansardantwort versendet` und `Standartantwort versendet`, die bekannte Schreibvariante `Kontoasuzug`, ältere Planreihenfolge wie `DC,IPP,USC …` und IPP als verifizierungsbedürftiger PP+-Alias. Das ist keine beliebige unscharfe Texterkennung. Leere Zwischenzeilen, mehrere Auftragszeilen, doppelte Statusmarker, unbekannte Pläne und Überschreitung der Beschreibungsgrenze bleiben echte Prüffälle. Die RC93-Parsergrenze liegt bei 450 Zeichen mit der im Code verwendeten Zeilenumbruchzählung.

**DB-Vorrang:** Ein gültiger, noch nicht erledigter DB-/DB+-Fall geht direkt an Mark, auch bei einem anderen Kundenwunsch. Fehlender Phase-1-Status, Konflikte oder eine bereits begonnene Aktion werden dadurch nicht übergangen.

<a id="07-phase-2-kontoauszug"></a>

## 07 · Phase 2: Kontoauszüge und gespeicherter Entwurf

```mermaid
flowchart TB
    KA["ACCOUNT_STATEMENT aus Beschreibung"] --> J{"Vorhandenes PDF-/Schreibjournal?"}
    J -->|Ja| RESUME["Nachweisgebunden fortsetzen<br/>Gespeicherte Anlagen nicht erneut hochladen"]
    J -->|Nein| ID["Ticket, INTL01-Member und WWID binden<br/>DC-/PP+-Zielpläne aus Bestand bestätigen"]
    ID --> FIND["Lokale Ausgabe_PDF-Ordner prüfen<br/>WWID_Kontoauszug_DC.pdf / WWID_Kontoauszug_PP+.pdf"]
    FIND --> EXIST{"Benötigte PDFs vorhanden<br/>und Nachweise aktuell?"}
    EXIST -->|Nein| GEN["Benutzer bedient vorhandene Generator-BATs<br/>Bot zeigt Pfade und erwartete Dateien"]
    GEN --> RECHECK["Nach Bereitschaft Dateien erneut lesen"]
    RECHECK --> EXIST
    EXIST -->|Ja| APPROVE["Benutzer prüft Person, WWID, Zeitraum,<br/>Berechtigung und Inhalte aller PDFs einmal"]
    APPROVE -->|Überspringen / nicht freigegeben| DEFER["Ticket offen protokollieren<br/>Keine ungeprüften Anlagen"]
    APPROVE -->|Freigegeben| HASH["Freigabe an Dateihashes, Person<br/>und aktuellen Lauf binden"]
    HASH --> EDIT["Richtiges Ticket bearbeiten<br/>Member und WWID erneut bestätigen"]
    EDIT --> INTENT["UPLOAD_INTENT dauerhaft schreiben"]
    INTENT --> UP["Je PDF eigener Datei-Auswahldialog<br/>PP+ und DC einzeln über FilePond auswählen"]
    UP --> UI{"Anhangszuordnung automatisch eindeutig?"}
    UI -->|Ja| STAGED["Anlagen bereit im Editor<br/>Noch kein dauerhafter Servernachweis"]
    UI -->|Nein, nur Dateinamen sichtbar| VISUAL["Benutzer prüft beide Anlagen im richtigen Ticket<br/>Ungebundener Name ist kein Uploadbeweis"]
    VISUAL -->|Bestätigt| STAGED
    STAGED --> GEVO["GEVO Anfrage Member setzen<br/>Fokus und übernommene Auswahl prüfen"]
    GEVO --> DRAFT["Kontoauszug-Anschreiben mit verifiziertem Namen<br/>Bestehenden abweichenden Text nicht blind ersetzen"]
    DRAFT --> DREVIEW{"Entwurf freigegeben?"}
    DREVIEW -->|Nein| DEFER
    DREVIEW -->|Ja| DSAVE["Genau einmal Entwurf speichern<br/>Zugehörigen HTML-/JavaScript-OK-Dialog behandeln"]
    DSAVE --> MARK["Bearbeitet not reviewed ergänzen<br/>Originalzeilen erhalten; Längenlimit prüfen"]
    MARK --> TSAVE["Ticket speichern<br/>Falls Button verdeckt: kontrollierte manuelle Hilfe"]
    TSAVE --> READ["Ticket neu öffnen<br/>Beschreibung, GEVO, Entwurf und Anlagen prüfen"]
    RESUME --> READ
    READ --> STORED{"Dauerhaft gespeicherter Zustand belegt?"}
    STORED -->|Nur Marker fehlt und exakt zulässiger Altfall| REPAIR["Einmalige genehmigte Marker-Reparatur<br/>Kein Neu-Upload; Speicherung neu nachweisen"]
    REPAIR --> READ
    STORED -->|Widerspruch / unklarer Klick| BLOCK["Journal schützen; Fehler melden<br/>Keine blinde Wiederholung"]
    STORED -->|Ja| REVIEW["Weiterleiten zur Überprüfung an Mark<br/>Genau ein Schritt-ausführen-Klick"]
    REVIEW --> RECEIPT["Routing unabhängig nachweisen<br/>Abschlussbeleg, dann nächstes Ticket"]
    class KA,ID,FIND,RECHECK,HASH,EDIT,INTENT,UP,STAGED,GEVO,DRAFT,DSAVE,MARK,TSAVE,READ,RESUME,REVIEW current;
    class GEN,APPROVE,VISUAL,REPAIR human;
    class RECEIPT good;
    class DEFER,BLOCK error;
    classDef default fill:#e8f1ff,stroke:#245b95,color:#102c49,stroke-width:1.3px;
    classDef current fill:#e8f1ff,stroke:#245b95,color:#102c49,stroke-width:1.4px;
    classDef human fill:#fff1cf,stroke:#a46a08,color:#4f3303,stroke-width:1.4px;
    classDef good fill:#e2f3e8,stroke:#287344,color:#153f26,stroke-width:1.6px;
    classDef error fill:#fce6e6,stroke:#a93535,color:#5c1616,stroke-width:1.4px;
    classDef future fill:#f0e8fb,stroke:#7753a5,color:#3a2456,stroke-width:1.5px,stroke-dasharray:5 4;
    classDef store fill:#edf0f4,stroke:#65768a,color:#263545,stroke-width:1.2px;
```

**Quellbezug:** `src/phase2-pdf-prepare.mjs`, `src/phase2-comarch-pilot.mjs`, `lib/phase2-pdf-evidence.mjs`, `lib/phase2-filepond.mjs`, `lib/phase2-statement-draft.mjs`, `lib/phase2-write-journal.mjs`.

**Aktuelle Generatoren:** `Kontoauszug_DC/START_KONTOAUSZUG_DC.bat` und `Kontoauszug_pp+/START_KONTOAUSZUG.bat`, jeweils mit `Ausgabe_PDF`. Dies sind benutzereigene Komponenten neben dem Ticketbot; das RC93-Paket enthält keine vollständige automatische Bedienung dieser Generatoren. Ein Dateiname allein beweist weder PDF-Inhalt noch Verschlüsselung noch richtige Person.

**Aktueller Kontoauszug-Entwurf:**

> Sehr geehrter Herr / Sehr geehrte Frau [verifizierter Nachname],
>
> anbei erhalten Sie die gewünschten Kontoauszüge. Die Dateien sind mit dem gewohnten Passwort verschlüsselt, Sie erhalten es nochmals in der nächsten Nachricht.

Dieser Text bleibt in Phase 2 ein Entwurf. Die behauptete Verschlüsselung und die spätere Passwortnachricht müssen im Review tatsächlich abgesichert werden; ein automatischer separater Passwortversand ist im gezeigten Ablauf noch nicht implementiert.

Das Diagramm beschreibt die fachlichen Abhängigkeiten. Im vorhandenen Runner werden GEVO und Beschreibung bereits vorbereitet und nach dem Entwurfsspeichern erneut kontrolliert; ein kurzzeitig gesetzter Editorwert ist noch kein Speicherbeweis.

<a id="08-phase-2-routing-und-review-uebergabe"></a>

## 08 · Phase 2: Direktweiterleitung, MBC und Review-Übergabe

```mermaid
flowchart TB
    KIND{"Freigegebener Fachweg"}
    KIND -->|DB_DIRECT oder MARK_DIRECT| DIRECT["Originalbeschreibung unverändert lassen<br/>Kein Bearbeitet not reviewed"]
    DIRECT --> DJ{"Neuer Fall oder Altjournal?"}
    DJ -->|Neu| DPREP["Bestehende Pflicht-/GEVO-Vorbereitung<br/>Speicherung unabhängig prüfen"]
    DJ -->|Wiederaufnahme| DR["Originalbeschreibung und GEVO nachlesen<br/>RC93: genau das zugeordnete Beschreibungsfeld"]
    DR --> DVALID{"Werte und Journal konsistent?"}
    DVALID -->|Ja| DF["Feld Bearbeiter<br/>mainForm:persona-assignment-id"]
    DPREP --> DF
    DVALID -->|Nein| ERR["Gezielte Diagnose und sichere Rückstellung<br/>Kein neues Speichern erzwingen"]
    KIND -->|MBC_PRIVATE_EMAIL| MBC["Verifizierte Person und Anrede<br/>Vorgegebenen privaten MBC-Login-Text laden"]
    MBC --> OLD{"Editor bereits befüllt?"}
    OLD -->|Abweichender Text| BACKUP["Vorhandenen Entwurf lokal sichern<br/>Benutzer: ersetzen oder unverändert lassen"]
    BACKUP -->|Behalten| SKIP["Nur dieses Ticket offenlassen<br/>Kein Überschreiben"]
    BACKUP -->|Ersetzen| MDRAFT["MBC-Antwort und INTL01-Signatur setzen<br/>Bearbeitet not reviewed ergänzen"]
    OLD -->|Leer oder sicher passend| MDRAFT
    MDRAFT --> MSAVE["Entwurf und Ticket kontrolliert speichern<br/>Serverwerte erneut öffnen und prüfen"]
    MSAVE --> REVIEW["Weiterleiten zur Überprüfung wählen"]
    KA["Kontoauszug aus Diagramm 07<br/>Anlagen und Entwurf gespeichert"] --> REVIEW
    REVIEW --> RF["Feld Nächster Bearbeiter<br/>mainForm:next-persona-assignment-id"]
    DF --> LOOK["mark.baindl suchen<br/>Nur im exakt zugeordneten Feld"]
    RF --> LOOK
    LOOK --> FOUND{"Richtiger Vorschlag eindeutig?"}
    FOUND -->|Nein| RETRY["Feld nach Teilaktualisierung neu binden<br/>Einmal erneut anklicken und Filter aktivieren"]
    RETRY --> FOUND2{"Jetzt gefunden?"}
    FOUND2 -->|Nein| MAN["Benutzer wählt Baindl Mark<br/>ENTER; selbst noch nicht ausführen"]
    FOUND2 -->|Ja| CHECK["Tatsächlich übernommener Account<br/>mark.baindl im richtigen Feld verifiziert"]
    FOUND -->|Ja| CHECK
    MAN --> CHECK
    CHECK --> JOURNAL["REVIEW_VERIFIED protokollieren<br/>Noch keine fachliche Reviewfreigabe"]
    JOURNAL --> MODE{"MANUELL oder AUTO?"}
    MODE -->|MANUELL| BUTTON["Einmalige Aktionsfreigabe im Panel"]
    MODE -->|AUTO| FINAL["Ticket, Beschreibung und Ziel<br/>unmittelbar vor Ausführung prüfen"]
    BUTTON --> FINAL
    FINAL --> EXEC["EXECUTE_INTENT<br/>Genau ein Weiterleiten-/Schritt-Klick"]
    EXEC --> EVIDENCE{"Routing nachgewiesen?"}
    EVIDENCE -->|Ja| DONE["ROUTED_VERIFIED<br/>Abschlussbeleg und nächste Ticketprüfung"]
    EVIDENCE -->|Nein| UNKNOWN["Weiterleitungsstatus unklar<br/>Kein zweiter Klick; Fehlerbericht"]
    class DIRECT,DPREP,DR,DF,MBC,MDRAFT,MSAVE,REVIEW,RF,LOOK,RETRY,CHECK,JOURNAL,FINAL,EXEC,KA current;
    class BACKUP,MAN,BUTTON human;
    class DONE good;
    class ERR,SKIP,UNKNOWN error;
    classDef default fill:#e8f1ff,stroke:#245b95,color:#102c49,stroke-width:1.3px;
    classDef current fill:#e8f1ff,stroke:#245b95,color:#102c49,stroke-width:1.4px;
    classDef human fill:#fff1cf,stroke:#a46a08,color:#4f3303,stroke-width:1.4px;
    classDef good fill:#e2f3e8,stroke:#287344,color:#153f26,stroke-width:1.6px;
    classDef error fill:#fce6e6,stroke:#a93535,color:#5c1616,stroke-width:1.4px;
    classDef future fill:#f0e8fb,stroke:#7753a5,color:#3a2456,stroke-width:1.5px,stroke-dasharray:5 4;
    classDef store fill:#edf0f4,stroke:#65768a,color:#263545,stroke-width:1.2px;
```

**Quellbezug:** `src/phase2-work-handler.mjs`, `src/phase2-direct-marker-recovery.mjs`, `lib/phase2-assignee.mjs`, `lib/phase2-mbc-draft.mjs`, `lib/phase2-mbc-signature.mjs`, `lib/phase2-review-flow.mjs`, `lib/phase2-route-receipt.mjs`.

**MBC-Inhalt in RC93:** Vorgegebener Entwurf: Wechsel auf private E-Mailadresse nicht möglich; MBC dient aktiven Mitarbeitern; nach Austritt gelten die postalischen Anwartschaftsbestätigungen; Mercer bleibt Ansprechpartner. Diese Dokumentation beschreibt die implementierte Vorlage und erfindet keine neue Fachauskunft.

**Zwei verschiedene Bedeutungen von „Review“:** `REVIEW_VERIFIED` im technischen Journal bestätigt den ausgewählten Übergabeweg/Prüfer. Es bestätigt **nicht**, dass Mark den Inhalt bereits geprüft hat. Erst ein eigenständiger fachlicher Reviewbeleg in der geplanten Phase 3 kann eine spätere Kundenantwort freigeben.

**Letzter RC93-Beleg:** Beim Altfall `88078437` waren Beschreibung und GEVO nach Wiederaufnahme bestätigt; der Filter-Reklick fand Mark; `ROUTED_VERIFIED` schloss den Fall ohne neue E-Mail ab. Danach zeigte der Bestand 0 eigene Zeilen. [S2]

<a id="09-fehler-und-wiederaufnahme"></a>

## 09 · Fehlerbehandlung: nicht blind wiederholen, nicht pauschal abbrechen

```mermaid
flowchart TB
    EVENT["Fehler oder fehlender Nachweis erkannt"] --> SNAP["Ticket-ID, Phase, technische Ursache,<br/>Journal vor/nach Aktion und Run-ID sichern"]
    SNAP --> TYPE{"Welche Fehlerklasse?"}
    TYPE -->|Eingabe unverständlich| INPUT["Erneut fragen; zulässige Antworten zeigen<br/>Kein Schreibklick"]
    INPUT -->|Eindeutig| RETURN["Am geprüften Schritt fortsetzen"]
    INPUT -->|Wiederholt unklar| DEFER["Nur Ticket offenlassen<br/>Fehler, Ursache und nächste Maßnahme"]
    TYPE -->|Bekanntes UI-/Lesetiming| READ["Begrenzt erneut lesen oder Feld neu binden<br/>Ticket-ID jedes Mal kontrollieren"]
    READ --> OK{"Nachweis jetzt eindeutig?"}
    OK -->|Ja| RETURN
    OK -->|Nein| SAFE{"Explizit erlaubter Rückstellfall?<br/>Kein neuer Schreibbeginn; Journal sicher"}
    SAFE -->|Ja| DEFER
    SAFE -->|Nein| HOLD["UNTERBROCHEN<br/>Keine erneute E-Mail, Anlage oder Weiterleitung"]
    TYPE -->|Upload, Speichern oder Weiterleitung unklar| HOLD
    TYPE -->|Falsche Identität, fremdes Ticket oder defekte Bindung| HOLD
    TYPE -->|Unbekannte Exception, globaler Fehler oder Benutzerabbruch| HOLD
    DEFER --> LIST{"Sichere Rückkehr zur eigenen Liste<br/>erneut nachgewiesen?"}
    LIST -->|Ja| NEXT["Ticket für diesen Lauf merken<br/>Andere geeignete Tickets weiterbearbeiten"]
    LIST -->|Nein| HOLD
    HOLD --> REPORT["Fehlercode, Klartext, Maßnahme und Berichtspfad<br/>Keine falsche Fertigmeldung"]
    REPORT --> USER["Gespeicherten COMARCH-Zustand unabhängig prüfen"]
    USER --> STATE{"Was ist wirklich geschehen?"}
    STATE -->|Kein irreversibler Klick belegt; zulässiger Weg| PRE["Kontrollierte Freigabe / Vorbereitung<br/>Nicht pauschal alle Journale löschen"]
    STATE -->|E-Mail versendet; Status/Speicherung offen| POST["Completion-only<br/>Nur fehlenden Abschluss, kein Neuversand"]
    STATE -->|PDFs und GEVO gespeichert; Marker fehlt| MARKER["Genehmigter Marker-only-Reparaturpfad<br/>Kein erneuter PDF-Upload"]
    STATE -->|Routing bereits nachgewiesen| ROUTED["Als erledigt behandeln<br/>Nicht nochmals weiterleiten"]
    STATE -->|Weiterhin unklar| PENDING["Ticket bleibt gesperrt<br/>Kein Risiko durch Wiederholklick"]
    PRE --> RETURN
    POST --> CHECK["Reparatur / Nachweis erneut vom Server lesen"]
    MARKER --> CHECK
    CHECK -->|Verifiziert| RETURN
    CHECK -->|Unklar| PENDING
    NEXT --> END{"Nach Listenprüfung noch offene Fälle?"}
    ROUTED --> END
    END -->|Nein| ALL["Alle Tickets bearbeitet<br/>Nur im tatsächlich geprüften Bereich"]
    END -->|Ja| SOME["Alle derzeit bearbeitbaren Tickets bearbeitet<br/>X Tickets konnten nicht bearbeitet werden"]
    ALL --> OUTPUT["Konsole, Masterbericht, CSV/JSON<br/>Hauptmenü bleibt verfügbar"]
    SOME --> OUTPUT
    class EVENT,SNAP,READ,RETURN,NEXT,PRE,POST,CHECK,OUTPUT current;
    class INPUT,USER,MARKER human;
    class ROUTED,ALL good;
    class DEFER,HOLD,REPORT,PENDING,SOME error;
    classDef default fill:#e8f1ff,stroke:#245b95,color:#102c49,stroke-width:1.3px;
    classDef current fill:#e8f1ff,stroke:#245b95,color:#102c49,stroke-width:1.4px;
    classDef human fill:#fff1cf,stroke:#a46a08,color:#4f3303,stroke-width:1.4px;
    classDef good fill:#e2f3e8,stroke:#287344,color:#153f26,stroke-width:1.6px;
    classDef error fill:#fce6e6,stroke:#a93535,color:#5c1616,stroke-width:1.4px;
    classDef future fill:#f0e8fb,stroke:#7753a5,color:#3a2456,stroke-width:1.5px,stroke-dasharray:5 4;
    classDef store fill:#edf0f4,stroke:#65768a,color:#263545,stroke-width:1.2px;
```

**Quellbezug:** `lib/phase2-safe-defer.mjs`, `lib/phase2-readback-retry.mjs`, `lib/phase2-bound-description.mjs`, `lib/preaction-recovery.mjs`, `lib/phase2-write-journal.mjs`, `lib/ticket-error-catalog.mjs`, `lib/master-completion.mjs`.

**Was RC93 wirklich abfängt:** Die Fortsetzung ist eine gezielte Liste nachgewiesener sicherer Fälle, kein allgemeines „catch und weiter“. Für neue Phase-2-Fälle dürfen bestimmte reine Vor-Schreibfehler nur ohne vorhandenes/neues Arbeits- oder PDF-Journal isoliert werden. Für alte DB-/Mark-Wiederaufnahmen müssen insbesondere Journal und Ereignisse unverändert sein und es darf kein `EXECUTE_INTENT` existieren. Anschließend muss die sichere Vorgangsliste erneut nachgewiesen sein.

**Was noch ausgebaut werden kann:** Weitere eindeutig sichere Fehlerklassen, verständlichere Hilfen und bessere Pausen-/Fortsetzen-Bedienung. Bei unbekanntem tatsächlichem Schreibstatus bleibt eine Unterbrechung erforderlich; daraus darf keine normale Erfolgsmeldung werden. „Alles abgefangen“ kann nicht aus der Existenz eines Fehlerkatalogs geschlossen werden.

**RC93-Workaround:** Die Beschreibung wird genau am zugeordneten Feld gelesen, nicht durch Zählen beliebiger Textareas. Bis zu vier reine Leseversuche helfen bei COMARCH-Teilaktualisierungen. Nur begrenzte Darstellungsunterschiede (unter anderem CRLF, NFC, NBSP und Leerraum am Zeilenende) werden toleriert; echte Plan-, Auftrags- oder Statusänderungen bleiben Konflikte. Die Diagnose nennt Struktur und erste abweichende Zeile, nicht den Kundentext.

<a id="10-daten-und-technik"></a>

## 10 · Architektur, lokale Daten, Fenster und Outputs

```mermaid
flowchart LR
    subgraph OP["Benutzeroberfläche"]
      CMD["START.cmd und Menü 0 bis 5"]
      PANEL["Windows-Status-/Freigabefenster<br/>Ticket, Person, ID, Pläne, Schritt und Modus"]
      INPUT["ENTER-Bestätigungen<br/>Gezielte Auswahl bei Mehrdeutigkeit"]
    end
    subgraph ENGINE["Lokaler Bot"]
      CLI["tools/cli.mjs<br/>Koordinator und Betriebssperren"]
      P1["local-bot-full-run<br/>Phase-1-Bearbeitung"]
      P2["phase2-run<br/>Fachregeln und Wiederaufnahme"]
      CDP["Browserworkflow und CDP<br/>Ticket-/Feldbindung und geprüfte Klicks"]
      UI["PowerShell-Fenster + lokaler Austausch<br/>Drag, MANUELL/AUTO und Eingabeschutz"]
      CHECK["Integrität, Journale und Nachweispolitik"]
    end
    subgraph EXT["Bestehende lokale / betriebliche Systeme"]
      COMARCH["Eigenes Edge-Profil → COMARCH<br/>Tickets, E-Mails, Member, Editor, Anlagen"]
      XLSX["Freigegebene Bestands-XLSX<br/>Quelle nur lesend"]
      GEN["DC-/PP+-Generatoren<br/>Heute vom Benutzer bedient"]
      PDF["Lokale verschlüsselte PDFs laut Fachprozess<br/>Existenz und Inhalt separat prüfen"]
      MARK["Mark / zuständiger Bearbeiter<br/>Fachlicher Review außerhalb RC93"]
    end
    subgraph DATA["Dateien und Belege bleiben lokal"]
      MAP[("private_data<br/>active-mapping.json + versionierter Snapshot")]
      CFG[("config + Browserprofil")]
      LEDGER[(".runtime/beta-control<br/>Sperren, Pilotbeleg, Versandjournal")]
      P2J[(".runtime/phase2/actions<br/>PDF- und Arbeitsjournale")]
      REPORTS[(".runtime/reports + .runtime/master<br/>Läufe, Tages-CSV, Bearbeitungsstatus")]
      P2REPORT[(".runtime/phase2<br/>Inventur, Abschluss, Fehler-CSV/JSON,<br/>PDF-Belege und Entwurfsbackups")]
      ARCH[("_MCR_Archiv + diagnostics<br/>Software-Rückweg und Diagnose-ZIPs")]
    end
    CMD --> CLI
    INPUT --> CLI
    PANEL <--> UI
    CLI --> P1
    CLI --> P2
    CLI --> CHECK
    P1 --> CDP
    P2 --> CDP
    UI <--> P1
    UI <--> P2
    CDP <--> COMARCH
    XLSX --> MAP
    MAP --> P1
    MAP --> P2
    CFG --> CLI
    P1 <--> LEDGER
    P2 <--> P2J
    P1 --> REPORTS
    CLI --> REPORTS
    P2 --> P2REPORT
    CHECK --> ARCH
    GEN --> PDF
    PDF --> P2
    COMARCH --> MARK
    class CMD,CLI,P1,P2,CDP,UI,CHECK,COMARCH current;
    class PANEL,INPUT,GEN,MARK human;
    class MAP,CFG,LEDGER,P2J,REPORTS,P2REPORT,ARCH,XLSX,PDF store;
    classDef default fill:#e8f1ff,stroke:#245b95,color:#102c49,stroke-width:1.3px;
    classDef current fill:#e8f1ff,stroke:#245b95,color:#102c49,stroke-width:1.4px;
    classDef human fill:#fff1cf,stroke:#a46a08,color:#4f3303,stroke-width:1.4px;
    classDef good fill:#e2f3e8,stroke:#287344,color:#153f26,stroke-width:1.6px;
    classDef error fill:#fce6e6,stroke:#a93535,color:#5c1616,stroke-width:1.4px;
    classDef future fill:#f0e8fb,stroke:#7753a5,color:#3a2456,stroke-width:1.5px,stroke-dasharray:5 4;
    classDef store fill:#edf0f4,stroke:#65768a,color:#263545,stroke-width:1.2px;
```

**Quellbezug:** `START.cmd`, `lib/cdp.mjs`, `lib/control.mjs`, `lib/config.mjs`, `lib/delivery-console.mjs`, `lib/progress-overlay.mjs`, `lib/phase2-ticket-console.mjs`, PowerShell-Fenster unter `tools/`.

### Dateien, die der Benutzer als Ergebnis bekommt

| Pfad relativ zur Installation | Zweck |
|---|---|
| `.runtime/reports/MCR_ECHTLAUF_<Datum>.log` | Gemeinsames Phase-1-Konsolenprotokoll |
| `.runtime/reports/MCR_TICKETVERLAUF_<Datum>.csv` | Tagesverlauf mit tatsächlichen Ticketresultaten |
| `.runtime/reports/MCR_Bearbeitungsstatus_<Lauf-ID>.csv` | USC/Pläne und Versandstatus in getrennten Spalten |
| `.runtime/master/MCR_MASTER_RUN_<Lauf-ID>.json` | Ablauf, Phasen, Freigabebindung, Ergebnis und offene Fälle |
| `.runtime/phase2/MCR_PHASE2_LAUF_<Lauf-ID>.log` / `.json` | Phase-2-Verlauf und strukturierter Laufbericht |
| `.runtime/phase2/MCR_PHASE2_TICKETBESTAND_LETZTE.json` | Letzte geprüfte sichtbare Inventur |
| `.runtime/phase2/MCR_PHASE2_FEHLER_<Lauf-ID>.csv` / `.json` | Ticket-ID, Fehlercode, Ursache und nächste Maßnahme |
| `.runtime/phase2/MCR_PHASE2_ABSCHLUSS_<Ticket-ID>_*.json` | Nachweis einer abgeschlossenen Review-Weiterleitung, je Ablauf |
| `.runtime/phase2/actions/` | Unverzichtbare Wiederaufnahme- und Aktionsjournale |
| `.runtime/phase2/draft-backups/` | Vorhandene Entwürfe vor einem freigegebenen Ersetzen sichern |
| `diagnostics/*_UPLOAD.zip` | Technische Diagnose; Inhalt vor externem Teilen prüfen |
| `../_MCR_Archiv/complete_*/` | Archivierter Softwarestand und Migrationsbeleg |

**Panel heute:** Separate Fortschritts-, Versand- und Phase-2-Steuerung. Das Phase-2-Fenster ist an der Titelleiste verschiebbar; vor automatischen Eingaben wird es klickdurchlässig, bei nicht bestätigter Freigabe kann es als sicherer Ausweichweg verborgen werden. Das vollständige Windows-Verhalten ist nicht durch diesen Dokumentationslauf neu getestet.

**Panel als nächstes:** Eine konsistente, kompakte Bedienoberfläche mit gespeicherter Position, zuverlässiger Wiederherstellung nach Navigation, klarer Trennung zwischen „wartet auf Benutzer“, „arbeitet“, „Prüffall“ und „fertig“. Abschlusskarte stehen lassen, statt den Erfolg nur zwischen vielen Logzeilen auszugeben. Keine zusätzlichen unkontrollierten Klickflächen über COMARCH.

**Datenminimierung:** Diese Präsentationsdatei verwendet keine Kunden-E-Mail-Adressen oder Membernamen. Reale lokale Reports sind nicht automatisch anonym; Entwurfsbackups und Prüfmeldungen können personenbezogene Angaben enthalten. Die LenX-Anbindung darf nicht ungeprüft Bestandsdateien, Passwörter oder Browserprofile übermitteln.

<a id="11-phase-3-geplant"></a>

## 11 · Phase 3 — geplant: LenX vor Phase 2, Review und Versand danach

```mermaid
flowchart TB
    P1["BESTEHEND: Phase 1 abgeschlossen<br/>Identität, Sprache, Planblock und Eingangsantwort"]
    subgraph A["PHASE 3A · LenX-gestützte Auftragserfassung — GEPLANT"]
      CONNECT["LenX-Edge-Erweiterung zuverlässig verbinden<br/>Installations-, Login- und Sitzungszustand prüfen"]
      BIND["Kontext eindeutig binden<br/>Ticket-ID, Member-ID und Originalnachricht"]
      SKILL["Versionierten Skill aufrufen<br/>Kundenwunsch aus Ticket lesen"]
      PROPOSAL["Strukturierten Vorschlag erzeugen<br/>Auftrag, Anfragezeile, Sprache und Beleg"]
      VALIDATE{"Vorschlag eindeutig, aktuell<br/>und mit erlaubter Fachregel vereinbar?"}
      MANUAL["Bei Unklarheit: Benutzer entscheidet<br/>Heutige manuelle Zeile bleibt als Fallback"]
      CAS["Nur Auftragszeile kontrolliert übernehmen<br/>Planblock, Versandstatus und Reviewstatus erhalten"]
      READBACK["Gespeicherte Zeile erneut lesen<br/>Ticket, Inhalt und Skill-Version protokollieren"]
      FAIL["LenX-/Skill-Fehler mit eigenem Code<br/>Kein falscher Auftrag, keine direkte E-Mail"]
      CONNECT --> BIND --> SKILL --> PROPOSAL --> VALIDATE
      VALIDATE -->|Ja| CAS --> READBACK
      VALIDATE -->|Nein| MANUAL --> CAS
      CONNECT -->|Nicht verfügbar| FAIL
      SKILL -->|Timeout / ungültige Antwort| FAIL
      FAIL --> MANUAL
    end
    P1 -. "Ersetzt später die manuelle Zeile" .-> CONNECT
    READBACK -. "Bestehende Fachregeln bleiben maßgeblich" .-> P2["BESTEHEND: Phase 2<br/>Direktweiterleitung oder Fachentwurf und Anlagen"]
    P2 --> CURRENTREVIEW["HEUTE: interne Übergabe an Mark<br/>Bot hat noch nicht fachlich freigegeben"]
    subgraph B["PHASE 3B · Review, Nacharbeit und Kundenversand — GEPLANT"]
      SNAP["Reviewpaket binden<br/>Ticket, Person, Empfänger, Sprache,<br/>Text, Signatur und Anlagenversionen"]
      REVIEW["Berechtigter Reviewer prüft Inhalt,<br/>Rechte, Anlagen, Zeitraum und Verschlüsselung"]
      DECISION{"Reviewentscheidung"}
      REWORK["Korrektur mit konkretem Grund<br/>Alte Freigabe ungültig machen"]
      REJECT["Zurückstellen / ablehnen<br/>Kein Kundenversand"]
      APPROVED["Expliziter Reviewbeleg<br/>An exakt diese Fassung gebunden"]
      CHANGED{"Seit Freigabe etwas geändert?"}
      PRESEND["Frischer Empfänger-, Ticket- und Anlagencheck<br/>Keine offenen Sendeabsichten"]
      SEND["Genau eine fachliche Antwort senden<br/>Gebundene Ausgangsnachricht nachweisen"]
      RECEIPT{"Versand vollständig bestätigt?"}
      UNCLEAR["Sendeausgang ungeklärt<br/>Sperre und sichere Prüfung, kein Neuversand"]
      PASSWORD["Separater Passwortprozess, falls erforderlich<br/>Kanal, Reihenfolge und Freigabe noch festlegen"]
      CLOSED["Fachlicher Abschluss und Auditbeleg<br/>Endgültiger Ticketabschluss nach definierter Regel"]
      SNAP --> REVIEW --> DECISION
      DECISION -->|Korrektur| REWORK --> SNAP
      DECISION -->|Ablehnen / offenlassen| REJECT
      DECISION -->|Freigeben| APPROVED --> CHANGED
      CHANGED -->|Ja| REWORK
      CHANGED -->|Nein| PRESEND --> SEND --> RECEIPT
      RECEIPT -->|Nein| UNCLEAR
      RECEIPT -->|Ja| PASSWORD --> CLOSED
    end
    CURRENTREVIEW -. "Künftige Integration" .-> SNAP
    DIRECT["DB-/unbekannter Fall ohne Bot-Fachentwurf"] -. "Reviewer erstellt oder veranlasst Fachantwort" .-> SNAP
    GUARD["GEPLANTE SICHERHEITSGRENZE:<br/>E-Mail-Inhalt ist Dateninput, kein Bot-Befehl.<br/>LenX darf Freigaben nicht selbst erfinden."] -.-> SKILL
    class P1,P2,CURRENTREVIEW current;
    class CONNECT,BIND,SKILL,PROPOSAL,VALIDATE,MANUAL,CAS,READBACK,FAIL,SNAP,REVIEW,DECISION,REWORK,REJECT,APPROVED,CHANGED,PRESEND,SEND,RECEIPT,UNCLEAR,PASSWORD,CLOSED,DIRECT,GUARD future;
    classDef default fill:#e8f1ff,stroke:#245b95,color:#102c49,stroke-width:1.3px;
    classDef current fill:#e8f1ff,stroke:#245b95,color:#102c49,stroke-width:1.4px;
    classDef human fill:#fff1cf,stroke:#a46a08,color:#4f3303,stroke-width:1.4px;
    classDef good fill:#e2f3e8,stroke:#287344,color:#153f26,stroke-width:1.6px;
    classDef error fill:#fce6e6,stroke:#a93535,color:#5c1616,stroke-width:1.4px;
    classDef future fill:#f0e8fb,stroke:#7753a5,color:#3a2456,stroke-width:1.5px,stroke-dasharray:5 4;
    classDef store fill:#edf0f4,stroke:#65768a,color:#263545,stroke-width:1.2px;
```

**Quellbezug:** Nutzerziel [S3]. Dies ist ein Entwurf für die nächste Projektphase, keine Beschreibung vorhandener RC93-Schnittstellen.

### Warum Phase 3 an zwei Stellen eingreift

„Phase 3“ bezeichnet hier die **nächste Ausbaustufe**, nicht ausschließlich einen Schritt ganz am Ende. **3A** ersetzt die heutige manuelle Auftragserfassung zwischen Phase 1 und Phase 2. **3B** ergänzt nach der Phase-2-Vorbereitung den fachlichen Review, die Korrekturschleife und erst dann den Kundenversand. Die Bezeichnungen 3A/3B sind Dokumentationsnamen; das aktuelle Menü erhält dadurch noch keinen neuen Eintrag.

### Noch festzulegender LenX-Vertrag

| Thema | Vorgeschlagene Anforderung — nicht implementiert |
|---|---|
| Verbindung | Verfügbarkeits- und Authentifizierungsprüfung der Edge-Erweiterung; Abbruch/Timeout nachvollziehbar; keine erfundene LenX-API voraussetzen |
| Skill-Aufruf | Eindeutiger, versionierter Skill mit klarer Ein- und Ausgabe; tatsächlicher Aufrufweg noch zu vermessen |
| Eingang | Ticket-ID, gebundene Member-ID, erste relevante Member-Nachricht und nötiger Ticketkontext; Datenumfang minimieren |
| Ausgabe | Ticketbezug, erkannte Sprache, vorgeschlagene Fachklasse, vorgeschlagene Anfragezeile, Unsicherheit und Bezug auf den Eingangstext |
| Fachklassen | Bestehende Regeln verwenden: Kontoauszug, privater MBC-Login, unbekannt; DB-Vorrang bleibt eine lokale Fachregel |
| Schreiben | Vorherigen Beschreibungsstand vergleichen, nur den Auftragsblock ändern, danach Serverzustand lesen; keine parallele Benutzeränderung überschreiben |
| Unbekannter Wunsch | Benutzer entscheidet; bei freigegebenem unbekanntem Fachfall interne Weiterleitung an Mark |
| Sicherheitsgrenze | Keine direkte Änderung der WWID/Pläne, kein erfundener Reviewstatus, kein selbst freigegebener Kundenversand, keine Befehlsausführung aus E-Mail-Text |
| Fehlermodus | LenX nicht erreichbar / Skill antwortet ungültig / Ticket inzwischen gewechselt → dokumentierter Fallback auf manuelle Eingabe |

### Noch festzulegender Review-Vertrag

Eine Statuszeile `reviewed` allein ist kein hinreichender künftiger Versandbeleg. Vorgeschlagen ist ein Nachweis mit Reviewer, Zeitpunkt, Ticket, Empfänger sowie Hash/Version des Antworttextes und aller Anlagen. Jede relevante Änderung verlangt neuen Review. Der technische Journalzustand `REVIEW_VERIFIED` aus RC93 wird **nicht** als solche fachliche Freigabe umgedeutet.

Der Review muss bei Kontoauszügen zusätzlich die tatsächliche Verschlüsselung und den in der Nachricht angekündigten Passwortprozess prüfen. Ein Passwort darf nicht stillschweigend zusammen mit den geschützten Dateien über denselben ungeprüften Schritt verschickt werden. Die konkrete betriebliche Regel ist vor Implementierung festzulegen.

<a id="12-roadmap"></a>

## 12 · Roadmap: Bestand festigen und Phase 3 kontrolliert ausbauen

```mermaid
flowchart TB
    NOW["ERREICHT · RC93<br/>Phase 1 und 2 für gemeldeten Bestand abgeschlossen<br/>Letzter Altfall weitergeleitet; 0 offen"]
    NOW --> DOC["JETZT · Dokumentation<br/>Ist, Grenzen, Fehlerwege und Zielbild festhalten"]
    DOC --> NEXT["AB MONTAG, 16.11.2026 · Geplanter Arbeitsbeginn<br/>Keine automatische Termin- oder Testausführung"]
    NEXT --> LANG["DE/EN-Abnahme<br/>Erste Member-Mail, Mischtext, Zitate,<br/>Anrede, manuell geänderter Inhalt"]
    NEXT --> LENX["LenX-Verbindung zuerst nachweisen<br/>Sitzung, Skill-Aufruf, Antwort und Fehlerverhalten"]
    LENX --> SKILL["Klassifikations-Skill testen<br/>Noch ohne Schreibrecht; Ergebnisse vergleichen"]
    SKILL --> Z3["Nur Anfragezeile kontrolliert übernehmen<br/>Vergleich und Server-Readback"]
    Z3 --> P2["Bestehende Phase-2-Wege wiederverwenden<br/>Keine zweite Fachlogik parallel erfinden"]
    P2 --> REVIEW["Reviewdaten und Reviewerprozess festlegen<br/>Freigabe, Ablehnung und Korrekturschleife"]
    REVIEW --> SEND["Kundenversand erst nach Review-Abnahme<br/>Doppelversandschutz und Passwortprozess"]
    NEXT --> UI["Panel und Interface verbessern<br/>Ziehen, Position, Pausieren, Status,<br/>sichtbare Fertigmeldung"]
    NEXT --> ROBUST["Robustheit / Fehlerkatalog erweitern<br/>Sichere Einzelfehler isolieren;<br/>unklare Aktionen weiterhin sperren"]
    NEXT --> SCOPE["Reichweite und Limits prüfen<br/>Pagination, neue Tickets während des Laufs,<br/>100er-Phase-2-Grenze und echte Restmenge"]
    NEXT --> DATA["Bestandswechsel sauber freigeben<br/>Neue XLSX-Quelle statt nur altem Quellhash"]
    LANG --> ACCEPT["Abnahmematrix und reale Belege<br/>Kein Erfolgsstatus nur aufgrund lokaler Tests"]
    SEND --> ACCEPT
    UI --> ACCEPT
    ROBUST --> ACCEPT
    SCOPE --> ACCEPT
    DATA --> ACCEPT
    ACCEPT --> STABLE["Spätere stabile Freigabe<br/>Erst nach definierten Abnahmekriterien"]
    class NOW good;
    class DOC current;
    class NEXT,LANG,LENX,SKILL,Z3,P2,REVIEW,SEND,UI,ROBUST,SCOPE,DATA,ACCEPT,STABLE future;
    classDef default fill:#e8f1ff,stroke:#245b95,color:#102c49,stroke-width:1.3px;
    classDef current fill:#e8f1ff,stroke:#245b95,color:#102c49,stroke-width:1.4px;
    classDef human fill:#fff1cf,stroke:#a46a08,color:#4f3303,stroke-width:1.4px;
    classDef good fill:#e2f3e8,stroke:#287344,color:#153f26,stroke-width:1.6px;
    classDef error fill:#fce6e6,stroke:#a93535,color:#5c1616,stroke-width:1.4px;
    classDef future fill:#f0e8fb,stroke:#7753a5,color:#3a2456,stroke-width:1.5px,stroke-dasharray:5 4;
    classDef store fill:#edf0f4,stroke:#65768a,color:#263545,stroke-width:1.2px;
```

**Quellbezug:** Nächste Schritte aus Nutzerauftrag [S3], ergänzt um beim Lesen des RC93-Codes erkennbare Prüfgrenzen [S1].

### Konkrete Abnahmekriterien für die nächsten Ausbauschritte

| Thema | Nachweis, bevor es als erledigt gilt |
|---|---|
| LenX-Verbindung | Reproduzierbarer Start/Anschluss, Ticketbindung, Timeout und Wiederanmeldung ohne fremdes Ticket zu bearbeiten |
| Skill | Richtige Anfragezeile auf repräsentativen Fällen; Mehrdeutigkeit wird angezeigt, nicht erraten; keine Anweisung aus Kundentext erhält Systemrechte |
| Beschreibung | Planblock und Versandstatus bleiben unverändert, Mehrzeilenmapping funktioniert, fremde Benutzeränderung wird nicht überschrieben |
| Sprache | Deutsche und englische Originale, kurze/mehrsprachige Texte, alte Zitate und wechselnde Verlaufsnachrichten getestet; erste Member-Nachricht bleibt der definierte Bezug |
| Review | Fachliche Freigabe eindeutig von technischer Prüferauswahl getrennt; nach Änderung alter Freigabezustand ungültig |
| Versand nach Review | Richtiger Empfänger, richtige Text-/Anlagenfassung, genau ein Klick, tatsächlicher Ausgang belegt, unklarer Ausgang verhindert Wiederholung |
| Statusfenster | Bleibt benutzbar, verdeckt keine benötigten Bedienelemente dauerhaft, Wiederherstellung nach Navigation, eindeutiges Ende mit Erledigt-/Offen-Zahlen |
| Fehlerfortsetzung | Ein sicher isolierbarer Fehler hält andere geeignete Tickets nicht auf; unbekannte Schreibzustände werden nicht übersprungen, als wären sie erledigt |
| Gesamtreichweite | Sichtbarer Bereich, Pagination und Limit klar im Ergebnis; keine „alles fertig“-Behauptung bei ungelesenen Restseiten |
| Regression | Bestehende Phase-1-Antwort, PDF-Anhang, MBC-Entwurf, DB-Direktrouting, Altfall-Reparaturen und Master-Browserbesitz bleiben erhalten |

**Nicht heute gestartet:** Keine neue Botversion, kein neuer Echtlauf, keine LenX-Verbindung, kein Versand und keine Hintergrundaufgabe. Die nächste Woche ist eine Roadmap, keine bereits eingerichtete Automation.

<a id="13-fehlercode-katalog"></a>

## 13 · Fehlercode-Katalog und bisherige Workarounds

Der folgende Katalog stammt aus `lib/ticket-error-catalog.mjs`. Er beschreibt bekannte Fälle. Für noch nicht spezialisierte technische Gründe erzeugt RC93 zusätzlich einen stabil abgeleiteten `MCR-P1-U…`- oder `MCR-P2-U…`-Code und behält den ursprünglichen Fehlernamen. Das macht einen unbekannten Fehler identifizierbar, aber noch nicht automatisch reparierbar.

| Benutzer-Code | Technischer Grund / Gruppe | Bedeutung | Sicherer nächster Schritt |
|---|---|---|---|

| `MCR-P2-201` | `P2_WORK_SERVER_VALUES_REVIEW_REQUIRED`, `P2_WORK_SERVER_VALUES` | Gespeicherte Ticketwerte und der erneut geoeffnete Editor stimmen nicht sicher ueberein. | Originalbeschreibung, GEVO und unveraendertes Arbeitsjournal im richtigen Ticket vergleichen. Keine erneute Weiterleitung. |

| `MCR-P2-202` | `P2_WORK_READBACK_UNCLEAR_REVIEW_REQUIRED`, `P2_WORK_READBACK_UNCLEAR` | Beschreibung bei der Wiederaufnahme mehrfach nicht eindeutig lesbar. | COMARCH-Ticket und gespeicherte Beschreibung unabhaengig pruefen. Keinen Speicherklick wiederholen. |

| `MCR-P2-203` | `WORK_JOURNAL_REVIEW_REQUIRED` | Das alte Bearbeitungsjournal passt nicht eindeutig zum gespeicherten Ticket. | Alte Aktionen und gespeicherten Zustand pruefen; keine automatische Doppelweiterleitung. |

| `MCR-P1-201` | `UNRESOLVED_PHASE1_JOURNAL` | Ein frueherer Versand- oder Weiterleitungsversuch ist noch nicht abschliessend bestaetigt. | Original-Mailverlauf und Journal pruefen. Keine zweite E-Mail ausloesen. |

| `MCR-P2-204` | `UNRESOLVED_FORWARD_INTENT` | Eine fruehere Weiterleitungsaktion ist noch ungeklaert. | Bei Mark und im COMARCH-Verlauf feststellen, ob die Weiterleitung bereits erfolgt ist. |

| `MCR-P2-205` | `CONFLICTING_PHASE2_JOURNALS` | Zwei unterschiedliche Phase-2-Arbeitsjournale beanspruchen dasselbe Ticket. | Journale und gespeicherte Anhaenge pruefen; keine automatische Wiederholung. |

| `MCR-P2-301` | `OTHER_REQUEST` | Die dritte Beschreibungszeile ist keiner sicheren Bearbeitungsregel zugeordnet. | Kundenanfrage im Ticket pruefen; wenn unklar, explizit als reine Weiterleitung an Mark freigeben. |

| `MCR-P2-302` | `REQUEST_REVIEW_NOT_CONFIRMED` | Die nicht erkannte Anfrage wurde nicht fuer die Weiterleitung an Mark freigegeben. | Anfragezeile und Zustand des Tickets manuell kontrollieren. Keine automatische Weiterleitung. |

| `MCR-P2-303` | `NOT_REQUESTED` | Kein eindeutiger Bearbeitungsauftrag in der zusaetzlichen Beschreibung vorhanden. | Originalticket und Beschreibung ueberpruefen; Fachregel fehlt oder wurde noch nicht eingetragen. |

| `MCR-P1-101` | `PHASE1_NOT_DONE`, `PHASE1_REQUIRED` | Phase 1 ist fuer dieses Ticket noch nicht belegt. | Phase-1-Pilot und Nachrichtenverlauf pruefen, bevor Phase 2 gestartet wird. |

| `MCR-P1-102` | `USC_MISSING` | USC-/Planangaben fehlen oder sind ungueltig. | COMARCH-Member und Bestand abgleichen, Beschreibung erst nach Pruefung korrigieren. |

| `MCR-P1-103` | `MANUAL_IDENTITY_REVIEW` | Eine Person konnte trotz Pruefung nicht unabhaengig zugeordnet werden. | Originalticket, betroffene Person und Berechtigung manuell pruefen; ohne sicheren Nachweis keine E-Mail. |

| `MCR-P2-401` | `PDF_PROOF_REQUIRED_OR_STALE` | Ein erforderlicher Kontoauszug fehlt oder sein Nachweis ist nicht aktuell. | PDF mit bestaetigter WWID und Inhalt erstellen beziehungsweise pruefen. |

| `MCR-P2-402` | `PDF_JOURNAL_NOT_RESUMABLE` | Der vorherige PDF-Anhangs-/Speicherschritt kann nicht sicher fortgesetzt werden. | Gespeicherte PDF-Anlagen und Journal pruefen; keinen zweiten Upload ausloesen. |

| `MCR-P2-403` | `MBC_EXISTING_DRAFT_RETAINED` | Vorhandener Antwortentwurf wurde bewusst nicht ersetzt. | Entwurf im richtigen Ticket inhaltlich kontrollieren und Review manuell entscheiden. |

| `MCR-P2-501` | `REVIEW_PENDING` | Bearbeitung oder Pruefung ist bereits vorbereitet; Abschluss nicht belegt. | Bearbeitungsstand und naechsten Bearbeiter nachpruefen. |

| `MCR-P2-601` | `OUTSIDE_INTEL_GROUP` | Ticket gehoert nicht zu einer bestaetigten Intel-Gruppe. | Zustaendigkeit manuell pruefen; keine automatische Intel-Bearbeitung. |

| `MCR-P2-602` | `DUPLICATE_TICKET_ID` | Die Ticketnummer wurde mehrfach in der sichtbaren Liste gefunden. | Listenansicht pruefen, erst nach eindeutiger Ticketbindung bearbeiten. |

| `MCR-P2-701` | `P2_WORK_REPAIR_LIMIT` | Die Grenze sicherer Wiederaufnahmeversuche ist erreicht. | Aktionsjournal und COMARCH-Schreibstatus manuell pruefen; kein Wiederholklick. |

| `MCR-P2-702` | `P2_WORK_SERVER_DESCRIPTION_CONFLICT` | Gespeicherte Beschreibung stimmt nicht mit dem urspruenglich freigegebenen Inhalt ueberein. | Vor Aenderungen den Originaltext im Ticket und das Journal vergleichen. |

### Weitere technisch wichtige Stopps und Reparaturen

| Beobachtung / Code | Ursache beziehungsweise bisheriger Schutz | Vorhandener Workaround / Grenze |
|---|---|---|
| `INTL_TICKET_OPEN_BLOCKED` | Ticketzeile nicht sicher an erlaubte Intel-Liste gebunden | Genau diese Zeile neu prüfen, sortierte ID-Spalten berücksichtigen; manuelles Öffnen erst mit anschließender Ticket-ID-Prüfung |
| `ACTION_NOT_UNIQUE`, `P2_EDIT_NOT_READY` | Schaltfläche fehlt, ist verdeckt oder mehrfach möglich | Passive Scroll-/Hit-Test-Prüfung; eindeutige manuelle Bearbeiten-Hilfe; keine beliebige Koordinate anklicken |
| `FIXED_QUERY_MISMATCH` | COMARCH hat Suchtext nach Teilaktualisierung nicht unverändert übernommen | Dasselbe Member-/Bearbeiterfeld erneut binden und begrenzt fokussieren; exakte Vorschlagsauswahl prüfen; sonst Benutzerhilfe |
| `MEMBER_REVIEW_NOT_AUTHORIZED` | Person/Name/Berechtigung nicht ausreichend bestätigt | Unabhängige Zuordnung; keine Versandfreigabe nur aus ähnlich klingendem Namen |
| `REPLY_CHANGED` | Ursprünglich Abbruch bei bearbeitetem Text | Seit RC85 aktueller Benutzertext freigebbar; neue Inhaltsbindung statt Zurücksetzen |
| `NEW_ROW_NOT_APPROVED_CONTENT` | Ausgangszeile belegt noch nicht genau den freigegebenen Antwortinhalt | Nachlesen, danach unabhängige Benutzerprüfung; niemals zweite E-Mail zur „Probe“ |
| `P2_REQUEST_APPROVAL` | Alte Version verstand die Eingabe Mark nicht | Seit RC92 ENTER, Mark und Weiterleiten akzeptiert; falsche Eingabe erneut fragen, dann sicher offenlassen |
| `P2_SAVE_DESCRIPTION_CHANGED` | Beschreibung vor finalem Speichern abweichend | Tatsächlichen Editor-/Serverzustand prüfen; keine falsche Speichermeldung |
| `P2_SAVE_UNVERIFIED`, `P2_RC52_SERVER_MARKER_MISSING` | Speicherklick erfolgt, erwarteter Marker nicht bestätigt | Gespeicherte PDFs/GEVO unabhängig prüfen; nur zugelassene Marker-only-Reparatur ohne erneuten Upload |
| `P2_KA_DRAFT_*` | Entwurf, OK-Dialog oder dessen Zugehörigkeit nicht eindeutig | Genau ein Entwurfsspeicherklick; nur zugehörigen HTML-/JS-Dialog bestätigen; danach Nachweis |
| `P2_WORK_FINAL_MARKER` | Früher erwartete Direktweiterleitung einen falschen Bearbeitet-Marker | DB/Mark-Weiterleitung verändert Beschreibung nicht; alter selbst erzeugter Marker nur gezielt freigegeben korrigierbar |
| `P2_WORK_SERVER_VALUES` | Altfallvergleich lieferte widersprüchliche Beschreibung | RC93 bindet genau das richtige Beschreibungsfeld und liest begrenzt erneut; echter Widerspruch bleibt offen |
| `P2_WORK_READBACK_UNCLEAR` | Wiederaufnahmebeschreibung vorübergehend unlesbar | Bis zu vier reine Leseversuche; nur bei nachgewiesener unveränderter Journal-/Nichtschreibsituation sicher zurückstellen |
| `UNKNOWN` beim Öffnen von `migration.json` | Im gelieferten Installationslauf Dateizugriffsfehler; genaue OS-Ursache unbelegt | Software-Rückweg wurde gemeldet; erst nach erfolgreicher Installation den Ticketlauf starten |
| `MASTER_UNTERBROCHEN`, `LIVE_NOT_VERIFIED` | Übergeordnete Meldung: Teilablauf nicht sicher belegt | Ursprünglichen Fehlergrund und tatsächlichen Aktionszustand ansehen; nicht automatisch alles neu starten |

**Grundsatz:** Bedienung, Fachlichkeit und technische Nachweise sind verschiedene Ebenen. Eine ENTER-Bestätigung ersetzt langes Tippen, aber nicht den technischen Nachweis des richtigen Tickets und Empfängers. Eine Benutzerbestätigung wird als solche dokumentiert und nicht als automatischer Nachweis ausgegeben.

<a id="14-modulverzeichnis"></a>

## 14 · Vollständiges Modulverzeichnis des RC93-Pakets

Dieses Verzeichnis führt **alle 110 Dateien unter `lib/`, `src/` und `tools/`** auf. Die Diagramme zeigen deren fachliche Zusammenarbeit; die Tabelle macht den Bezug zum tatsächlichen gewachsenen Code sichtbar. Ein Dateiname oder historischer RC-Kommentar ist keine neue Produktzusage. Ältere Hilfsroutinen können im Paket vorhanden sein, ohne einen eigenen Menüpunkt zu haben.

| Baustein | Zuständigkeit / Verweis |
|---|---|

| `lib/active-mapping.mjs` | Aktivierungszeiger, Dateihashes und Bindung des produktiven Bestands prüfen · 02/04 |

| `lib/browser-actions.mjs` | Gezielte browserseitige Aktionshilfen · 04/07/08 |

| `lib/browser-workflow.mjs` | COMARCH-Ansichten, Ticketbindung, Felder, Member, Nachrichten, Klick- und Nachweisfunktionen · 03–09 |

| `lib/cdp.mjs` | Edge-Prozess, Chrome-DevTools-Verbindung, Sessions, Seiten und Eingaben · 03/10 |

| `lib/comarch-missing-member.mjs` | Fehlende Member / Zuordnung im COMARCH-Kontext behandeln · 04 |

| `lib/comarch-name-labels.mjs` | Vor-/Nachnamen als ticketgebundene Ausweichquelle aus sichtbaren Labels · 04 |

| `lib/config.mjs` | Lokale Pfade, COMARCH-Adresse und Bot-Profil konfigurieren · 10 |

| `lib/continuation-policy.mjs` | Pilot-/Folgelauf-/Masterfreigaben an Paket, Mapping und Run binden · 03 |

| `lib/control.mjs` | Version, sichere JSON-Dateien, Sperren, Zustände und Versandledger · 02/03/09 |

| `lib/core.mjs` | Prüfsummen und gemeinsame Fehler-/Bedingungsprüfung · 02/09 |

| `lib/data-core.cjs` | Basisregeln für IDs, Flags, USC, Datenvalidierung · 02/04 |

| `lib/delivery-console.mjs` | Versandfreigabe MANUELL/AUTO und Fenster-/Terminalsteuerung · 05/10 |

| `lib/demo-browser-shutdown.mjs` | QA-Hilfe zum geordneten Schließen von Demobrowsern, kein Fachweg · 12 |

| `lib/demo.mjs` | Fiktive COMARCH-/Browser-Szenarien für lokale Tests · 12 |

| `lib/forwarding.mjs` | Phase-1-Weiterleitung ohne E-Mail bei fehlendem Bestand · 04 |

| `lib/history-binding.mjs` | Nachrichtenhistorie an das richtige Ticket binden · 04/05 |

| `lib/identity-evidence.cjs` | Identitäts- und Originalnachrichten-Evidenz · 04/05 |

| `lib/mail-history-audit.mjs` | Eingänge, Ausgänge, Systemnachrichten und bereits beantwortete Tickets unterscheiden · 04/05 |

| `lib/manual-person.mjs` | Manuelle Namenseingabe und überprüfbare Bestätigung · 04 |

| `lib/master-browser-lease.mjs` | Sichere Mitnutzung des einen Master-Browserprozesses · 03 |

| `lib/master-completion.mjs` | Zwei reguläre Abschlussmeldungen mit geprüftem Sichtbereich und offenen Fällen · 09/10 |

| `lib/master-pilot-recovery.mjs` | Ungeklärten früheren Pilot erkennen; Abschluss ohne Neuversand vorbereiten · 03/09 |

| `lib/member-mapping.mjs` | Voll-ID zuerst, danach dokumentierter Präfix-11-Lookup · 04 |

| `lib/member-review.mjs` | Namenskonflikte, getrennte Profilfelder und unabhängige Benutzerprüfung · 04 |

| `lib/migration-priority.mjs` | Exklusive Softwareumstellung und Wiederherstellung verwaister Migrationszustände · 02 |

| `lib/msg.cjs` | Gebundene Original-MSG technisch lesen · 04/05 |

| `lib/multirow-tpp-mapping.mjs` | Mehrzeilen-/TPP-Regeln, Spaltenherkunft, Sperren und Beschreibungsbildung · 02/04 |

| `lib/name-probes.mjs` | Namenshinweise aus erlaubten ticketbezogenen Quellen sammeln · 04 |

| `lib/name-resolution.mjs` | Namenskandidaten bewerten und zusammenführen · 04 |

| `lib/operator-enter.mjs` | ENTER auf ausdrücklich definierte Bestätigungen abbilden · 03/04/08 |

| `lib/operator-send-review.mjs` | Manuelle Prüfung eines unklaren tatsächlichen E-Mail-Ausgangs · 05 |

| `lib/person-quoted.cjs` | Personensuche unter Abgrenzung zitierter Nachrichten · 04 |

| `lib/person.cjs` | Personennamen, Absenderanzeige und Signaturhinweise analysieren · 04 |

| `lib/phase1-edited-reply.mjs` | Manuelle Antwortänderungen sichern und inhaltsgebunden freigeben · 05 |

| `lib/phase1-language.mjs` | DE-/EN-Signale aus Originaltext und manuelle Sprachentscheidung · 05 |

| `lib/phase1-signature-policy.mjs` | Verbindliche INTL01-Signaturpolitik vor Versand · 05 |

| `lib/phase2-account-statement-plan.mjs` | Kontoauszug-Zielpläne und zugehöriger Dateibedarf · 07 |

| `lib/phase2-admission.mjs` | Zulassung im Verhältnis zu Phase-1-/Versandjournalen · 06/09 |

| `lib/phase2-assignee.mjs` | Bearbeiter suchen, Filter-Reklick, exakte Accountauswahl und manueller Fallback · 08 |

| `lib/phase2-bound-description.mjs` | RC93: beschriftetes Feld statt generischer Textareas; begrenzter Vergleich und Diagnose · 09 |

| `lib/phase2-bound-save.mjs` | Ticketspeichern an korrektes Ticket und erwartete Werte binden · 07/08 |

| `lib/phase2-comarch-actions.mjs` | COMARCH-Aktionen für GEVO, Upload, Entwurf, Beschreibung und Speichern · 07/08 |

| `lib/phase2-description.mjs` | Zusätzliche Beschreibung parsen und Fachwege priorisieren · 06 |

| `lib/phase2-draft-preview.mjs` | Vorhandenen Entwurfsinhalt prüfen und Vorschau-/Ersetzungsentscheidung vorbereiten · 07/08 |

| `lib/phase2-edit-mode.mjs` | Bearbeitungsmodus sicher erkennen und betreten · 07/08 |

| `lib/phase2-filepond.mjs` | PDF-Auswahl und Anhangszuordnung im FilePond-Bereich · 07 |

| `lib/phase2-handoff-ledger.mjs` | Nachweise beim Übergang zwischen alten Phase-1- und Phase-2-Zuständen · 09 |

| `lib/phase2-handoff.mjs` | Alte Versand-/Speicherbelege kontrolliert für Phase 2 beurteilen · 09 |

| `lib/phase2-intake-audit.mjs` | Sichtbare Kandidaten, Sperren, Wiederaufnahmen und Klassifikationen auswerten · 06/09 |

| `lib/phase2-legacy-direct-admission.mjs` | Zulässige alte Direktweiterleitungsjournale erkennen · 08/09 |

| `lib/phase2-mbc-draft.mjs` | MBC-Entwurf, Sicherung vorhandenen Textes und kontrolliertes Ersetzen · 08 |

| `lib/phase2-mbc-signature.mjs` | INTL01-Signatur im MBC-Entwurf setzen und prüfen · 08 |

| `lib/phase2-member-evidence.mjs` | PDF-/Phase-2-Member-ID und zugehörige Person belegen · 07 |

| `lib/phase2-navigation.mjs` | Eigene Liste und Phase-2-Ticket sicher öffnen · 06/07/08 |

| `lib/phase2-pdf-approval.mjs` | Eine PDF-Inhaltsfreigabe im selben Lauf nicht unnötig erneut anfordern · 07 |

| `lib/phase2-pdf-evidence.mjs` | Lokale PDF-Nachweise, Hashbindung, Aktualität und Inhaltsfreigabe · 07 |

| `lib/phase2-readback-retry.mjs` | Nur lesende, begrenzte Wiederholung bei unlesbarer Beschreibung · 09 |

| `lib/phase2-readonly.mjs` | Nur lesende Phase-2-Inventur-/Vorprüfungsregeln · 06/10 |

| `lib/phase2-request-approval.mjs` | Unbekannten Auftrag bestätigen; Mark/ENTER verstehen; falsche Eingabe erneut fragen · 06 |

| `lib/phase2-review-flow.mjs` | Weiterleiten zur Überprüfung, nächster Bearbeiter und technische Übergabe · 08 |

| `lib/phase2-route-receipt.mjs` | Weiterleitung anhand gebundener Aktion und frischer Liste nachweisen · 08 |

| `lib/phase2-safe-defer.mjs` | Eng begrenzte sichere Einzelfehler zurückstellen, ohne andere Tickets zu blockieren · 09 |

| `lib/phase2-save-readback.mjs` | Gespeicherte Beschreibung/Status über erneutes Lesen beurteilen · 07/09 |

| `lib/phase2-save-settle.mjs` | Schreibrequests und Beruhigung nach Speichern beobachten; kein alleiniger Erfolg · 07/09 |

| `lib/phase2-statement-draft.mjs` | Kontoauszug-Anschreiben und sicherer Entwurf-/OK-Dialogablauf · 07 |

| `lib/phase2-ticket-console.mjs` | Phase-2-Fenster, Status, Freigaben und Schutz automatischer Eingaben · 10 |

| `lib/phase2-upload-continuation.mjs` | Fortsetzung nach einzelnen Datei-Auswahlen anhand vorhandener Nachweise · 07/09 |

| `lib/phase2-work-journal.mjs` | Aktionsjournal für DB-, Mark- und MBC-Wege · 08/09 |

| `lib/phase2-work-rules.mjs` | Direktweiterleitung ohne Marker; MBC-Vorlage; Bearbeitungsmarkierung · 06/08 |

| `lib/phase2-write-journal.mjs` | Zustände, Sperren und zulässige Reparaturen des PDF-/Speicherablaufs · 07/09 |

| `lib/post-send-editor-rebind.mjs` | Editor nach Versand/COMARCH-Teilaktualisierung erneut binden · 05 |

| `lib/post-send-status-retry.mjs` | Begrenzte Statusprüfung nach nachgewiesenem Versand · 05 |

| `lib/pre-send-description.mjs` | Beschreibung vor Versand prüfen bzw. kontrolliert vorbereiten · 05 |

| `lib/preaction-recovery.mjs` | Nachweislich vor einer Aktion abgebrochene Läufe sicher freigeben · 09 |

| `lib/preaction-skip.mjs` | Definierte vor-Aktionsfälle auslassen, ohne Doppelversand zuzulassen · 09 |

| `lib/progress-overlay.mjs` | Allgemeines Fortschrittsfenster und Zustandsübergabe · 10 |

| `lib/queue-send.cjs` | Ticket-/Queue-Versandkonfiguration und zugehörige Prüfung · 03/05 |

| `lib/route-fixed-policy.mjs` | Pflichtfelder für interne Weiterleitung ohne E-Mail · 04/08 |

| `lib/run-reset.mjs` | Alte Läufe/Sperren prüfen und sichere Neustartbedingungen herstellen · 03/09 |

| `lib/send-dialog-policy.mjs` | Sendebestätigungen kontrollieren, doppelte oder fremde Dialoge vermeiden · 05 |

| `lib/source-neutral-policy.mjs` | Quellenneutraler Eingang/Weiterleitung und begrenzter Originalnachrichtenzugriff · 04/05 |

| `lib/status-columns.mjs` | Getrennte CSV-Ausgaben für USC/Pläne und Standardantwort-Status · 10 |

| `lib/ticket-error-catalog.mjs` | Stabile Fehlercodes, Klartext, nächste Maßnahme und Fehler-CSV · 09/13 |

| `lib/ticket-prep.cjs` | DE-/EN-Standardtexte, Anrede, Pflichtfelder und Inhaltsvergleich · 05 |

| `lib/trusted-description.mjs` | Zusätzliche Beschreibung über geprüften Fokus/nativen Input bearbeiten · 05/07/08 |

| `lib/xlsx-multirow.mjs` | XLSX-Blatt Output mit mehrzeiligen Bestandsdaten lesen · 02 |

| `lib/xml.mjs` | Lokale XML-Verarbeitung für Datei-/Datenleser · 02 |

| `lib/zip.mjs` | Lokale ZIP-Strukturen lesen/erzeugen, unter anderem XLSX und Diagnose · 02/10 |

| `src/export-multirow.mjs` | Explizite Mappingwartung aus unveränderter freigegebener XLSX · 02 |

| `src/local-bot-full-run.mjs` | Vollständiger Phase-1-Pilot-/Batchrunner · 03–05 |

| `src/phase1-completion-only.mjs` | Unterbrochenen Versandabschluss ohne erneute E-Mail nachweisen/abschließen · 09 |

| `src/phase2-comarch-pilot.mjs` | Kontoauszug mit Upload, Entwurf, Speicherbeleg, Review und Altfall-Reparaturen · 07 |

| `src/phase2-direct-marker-recovery.mjs` | Falschen alten Direktweiterleitungsmarker gezielt und freigegeben behandeln · 08/09 |

| `src/phase2-inventory-run.mjs` | Nur lesender Bestands-/Blockadenbericht, intern verfügbar · 06/10 |

| `src/phase2-pdf-prepare.mjs` | PDFs innerhalb des Phase-2-Laufs finden und vom Benutzer prüfen lassen · 07 |

| `src/phase2-run.mjs` | Phase-2-Kandidatenauswahl, Einzelfallsteuerung, Fortsetzung und Fehlerberichte · 06–10 |

| `src/phase2-supervised.mjs` | Beaufsichtigte Inventur-/Generator-/PDF-Vorprüfung, interne Hilfswege · 07/10 |

| `src/phase2-work-handler.mjs` | Direktweiterleitung und MBC-Fachbearbeitung mit Wiederaufnahme · 08/09 |

| `tools/cli.mjs` | Menü, Update, Mappingwartung, Phase1-only, Master und interne Wartungsbefehle · 01–03 |

| `tools/delivery-window.ps1` | Windows-Versandfreigabefenster · 05/10 |

| `tools/deploy.mjs` | Installationsplanung, Archivierung, Softwareaustausch und Rückweg · 02 |

| `tools/find-node.cmd` | Vorhandene Node.js-Laufzeit finden · 01/02 |

| `tools/integrity.mjs` | Manifest, Payload und Dateiintegrität kontrollieren · 02 |

| `tools/phase2-ticket-window.ps1` | Verschiebbares Phase-2-Fenster, Modi, Freigaben und Klickdurchlässigkeit · 10 |

| `tools/process-guard.mjs` | Prozess-/Sperrprüfung vor lokalen Aktionen · 02/03 |

| `tools/process-guard.ps1` | Windows-Prozessprüfung unterstützen · 02/03 |

| `tools/process-policy.mjs` | Zugehörigkeit und sichere Behandlung von Bot-Prozessen · 02/03 |

| `tools/process-stop.ps1` | Nur freigegebene eigene Bot-Prozesse stoppen · 02 |

| `tools/progress-window.ps1` | Allgemeines Windows-Fortschrittsfenster · 10 |

| `tools/proof.mjs` | Demo-, Versandpilot- und Weiterleitungsnachweise validieren · 03/12 |

### Weitere Paketbestandteile

`START.cmd` ist der Einstieg; `package.json` und `config/local-runner-queue-send.json` gehören zur Laufzeitkonfiguration. `MANIFEST.json` und `SHA256SUMS.txt` sichern den Paketbestand. `examples/DEMO_mapping.json` ist nur ein Demo-Bestand und darf kein produktives Mapping ersetzen. Releasebeschreibungen unter `docs/RC74_RELEASE.md` bis `docs/RC93_RELEASE.md` dokumentieren historische Änderungen; die ursprünglichen Hinweise „noch nicht produktiv getestet“ werden durch spätere echte Protokolle nur für den jeweils nachgewiesenen Fall ergänzt.

<details>
<summary>Testdateien und Hilfen im Paket (47 Dateien)</summary>

Die folgenden Dateien gehören zum vorhandenen QA-Bestand. Sie wurden für diese Dokumentation nicht erneut als produktive Tests ausgeführt.

```text

browser-test-profile-cleanup.mjs
control.test.mjs
helpers.mjs
identity.test.mjs
manual-person.test.mjs
mapping.test.mjs
parsers.test.mjs
rc20-mail-history-audit.test.mjs
rc25-send-verification.test.mjs
rc26-send-verification.test.mjs
rc27-send-recovery.test.mjs
rc28-status-columns.test.mjs
rc53-delivery-control.test.mjs
rc60-master-orchestrator.test.mjs
rc61-master-interruption.test.mjs
rc62-presend-description.unit.test.mjs
rc63-intel-only-navigation-browser.test.mjs
rc63-secure-relay-history.test.mjs
rc64-signature-policy.test.mjs
rc65-phase2-handoff.test.mjs
rc67-phase2-continuation.test.mjs
rc68-master-phase2-and-native-focus.test.mjs
rc69-description-input-recovery.test.mjs
rc70-review-select-chain.test.mjs
rc71-phase2-save-native.test.mjs
rc72-mbc-signature-final-receipt.test.mjs
rc73-ticket-inventory-and-intel-boundary.test.mjs
rc74-db-handoff-readable-notes.test.mjs
rc75-ticket-label-name.test.mjs
rc76-description-routing.test.mjs
rc77-direct-work-marker.test.mjs
rc78-account-typo-and-edit-gate.test.mjs
rc79-fewer-confirmations-save-binding.test.mjs
rc80-marker-only-repair.test.mjs
rc81-statement-draft-and-dialog.test.mjs
rc82-review-query-rebind.test.mjs
rc83-master-flow.test.mjs
rc84-ticket-open-binding-recovery.test.mjs
rc85-edited-reply.test.mjs
rc86-operator-flow.test.mjs
rc87-enter-panel-and-continuation.test.mjs
rc88-bilingual-master.test.mjs
rc89-master-completion.test.mjs
rc90-readback-recovery.test.mjs
rc91-ticket-failures.test.mjs
rc92-operator-and-browser.test.mjs
rc93-bound-description-resume.test.mjs
```

</details>

<a id="15-quellen"></a>

## 15 · Quellen, Abgleich und Prüfstatus

**[S1] Bereitgestellter Originalcode:** `RC93_Install.zip`, Manifestversion `0.8.1-rc.93`; 185 Archiveinträge. SHA-256:

```text
6d81d553faee0365933e9aa414619893173d25de0bbf50d8b3a33266f34af8ba
```

Die ZIP wurde zur Dokumentation lokal gelesen; CRC-Prüfung ohne Archivfehler. Alle 110 Dateien unter `lib/`, `src/` und `tools/` sind im Verzeichnis erfasst. Die Entscheidungen in den Diagrammen wurden insbesondere gegen `tools/cli.mjs`, die Phase-1-/Phase-2-Runner, Beschreibungsparser, Mappingregeln, Sprachmodul, Journale und Fehlerkatalog abgeglichen. Das ältere README trägt noch historische Überschriften; für den Ist-Zustand wurden Manifest und tatsächliche Implementierung höher gewichtet.

**[S2] Vom Benutzer gelieferte COMARCH-Laufprotokolle:** RC73 bis RC93 in diesem Chat; insbesondere der letzte Master-Run vom 13.11.2026 mit Run-ID `2026-11-13T10-52-02-175Z_dfee648f`. Er belegt die abschließende Weiterleitung von Ticket `88078437`, 0 offene Fälle in den geprüften Listen und den geregelten Browserabschluss. Frühere Protokolle belegen unter anderem Kontoauszug-Anhänge, direkte Mark-Weiterleitungen, den einmaligen englischen Phase-1-Fall und die manuelle Inhaltsfreigabe.

**[S3] Aktueller Nutzerauftrag:** Nur Dokumentation; Phase 3 soll LenX mit Skill zur Auftragserfassung sowie Review/Nacharbeit/Versand abdecken. DE/EN soll weiter gefestigt, Panel und Oberfläche weiter verbessert werden. Arbeit daran ist für die nächste Woche vorgesehen, ohne dass hier Termine oder Hintergrundaufgaben eingerichtet werden.

**[S4] Darstellung:** Offizielle VS-Code-Dokumentation „Markdown and Visual Studio Code“, Abschnitte Markdown preview und Mermaid diagram rendering; offizielle Mermaid-Dokumentation „Flowcharts Syntax“. Abruf 13.11.2026. Referenzadressen:

```text
https://code.visualstudio.com/docs/languages/markdown
https://mermaid.js.org/syntax/flowchart.html
```

**Testhistorie versus heutige Arbeit:** Im mitgelieferten `RC93_Pruefbericht.txt` werden 437 bestandene automatisierte Tests und ein Offline-Update-/Rückwegtest berichtet. Das sind vorhandene Releaseangaben, keine im Rahmen dieser Dokumentation erneut ausgeführten COMARCH-Tests. Der neue, vom Benutzer gelieferte Echtlauf liefert den zusätzlichen produktiven Beleg für den letzten DB-Altfall. Die Dokumentation verändert keine Software, keine produktiven Daten und keine Tickets.

**Mermaid-Prüfung dieser Datei:** Alle 12 Mermaid-Blöcke wurden lokal mit dem Mermaid-Parser geprüft und in einem isolierten Chromium als SVG gerendert; 12 von 12 erfolgreich. Die Diagramme verwenden die grundlegende Flowchart-Syntax mit beschrifteten Knoten, Teilgruppen und Klassen. Die Gesamtsicht sowie die Architekturansicht wurden zusätzlich visuell kontrolliert. Das ist eine Dokumentationsprüfung, kein neuer Bot-/COMARCH-Test. Die Darstellung in der konkreten VS-Code-Version des Benutzers wurde hier nicht geöffnet.

---

**Präsentationsschluss:** RC93 hat den aktuell geprüften Bestand bis einschließlich Phase 2 abgearbeitet. Der nächste Entwicklungsschritt ist nicht mehr ein weiterer allgemeiner Ticketlauf, sondern die sichere Automatisierung der manuellen Auftragszeile und ein ausdrücklich freigegebener fachlicher Review-/Versandprozess. Bestehende Nachweise und Fehlergrenzen bleiben dabei erhalten.
