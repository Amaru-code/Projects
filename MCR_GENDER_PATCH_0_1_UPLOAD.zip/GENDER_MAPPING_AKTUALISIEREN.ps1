param(
    [string]$ProjectRoot = 'C:\Users\Amaru-Zegarra\projects\Aktive_Projekte\Ticket_bot\MCR_Datenbruecke',
    [string]$ExcelPath = 'C:\Users\Amaru-Zegarra\projects\Aktive_Projekte\Ticket_bot\INTL01_Gesamtdatenbestand_30.09.2025.xlsx',
    [string]$MappingPath = 'C:\Users\Amaru-Zegarra\projects\Aktive_Projekte\Ticket_bot\MCR_Datenbruecke\private_data\INTL01_mapping_2026-09-29T13-00-41-552Z_64ea2aec.json'
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Stop-With([string]$Message) { throw $Message }
function Find-Node {
    $candidates = @(
        'C:\Users\Amaru-Zegarra\projects\Compiler\javascript\tools\node\node.exe',
        (Join-Path $ProjectRoot 'tools\node\node.exe')
    )
    foreach ($p in $candidates) { if (Test-Path -LiteralPath $p) { return $p } }
    $cmd = Get-Command node.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    Stop-With 'node.exe wurde nicht gefunden.'
}

Write-Host ''
Write-Host '=============================================================='
Write-Host ' MCR Gender-Erweiterung - Excel Spalte O -> M/F -> Herr/Frau'
Write-Host '=============================================================='
Write-Host 'Die bestehende Mapping-Datei und der produktive Runner werden NICHT ueberschrieben.'
Write-Host 'Es entstehen ein neues Mapping und START_LOCAL_BOT_GENDER.cmd.'
Write-Host ''

if (!(Test-Path -LiteralPath $ProjectRoot)) { Stop-With "Projektordner fehlt: $ProjectRoot" }
if (!(Test-Path -LiteralPath $ExcelPath)) { Stop-With "Excel-Datei fehlt: $ExcelPath" }
if (!(Test-Path -LiteralPath $MappingPath)) { Stop-With "Mapping fehlt: $MappingPath" }
$Node = Find-Node

& $Node (Join-Path $ProjectRoot 'src\verify-package.mjs')
if ($LASTEXITCODE -ne 0) { Stop-With 'Basispaket-Integritaet ist nicht PASS. Keine Aenderung.' }

$map = Get-Content -LiteralPath $MappingPath -Raw -Encoding UTF8 | ConvertFrom-Json -Depth 100
$excelSha = (Get-FileHash -LiteralPath $ExcelPath -Algorithm SHA256).Hash.ToLowerInvariant()
$mapSha = ([string]$map.payload.source.sha256).ToLowerInvariant()
if ($excelSha -ne $mapSha) { Stop-With 'Die XLSX ist nicht dieselbe Quelle wie im Mapping (SHA256 abweichend). Bitte Mapping neu erzeugen statt mischen.' }

$excel = $null; $wb = $null; $ws = $null
$temp = Join-Path $env:TEMP ('mcr_gender_' + [guid]::NewGuid().ToString('N') + '.json')
try {
    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $excel.DisplayAlerts = $false
    $wb = $excel.Workbooks.Open($ExcelPath, 0, $true)
    $matches = @()
    foreach ($sheet in @($wb.Worksheets)) {
        if ($sheet.Name.Trim().ToLowerInvariant() -eq 'output') { $matches += $sheet }
    }
    if ($matches.Count -ne 1) { Stop-With "Blatt 'output' fehlt oder ist nicht eindeutig." }
    $ws = $matches[0]
    $headerRow = [int]$map.payload.source.headerRow
    $headerO = ([string]$ws.Cells.Item($headerRow, 15).Value2).Trim()
    if ([string]::IsNullOrWhiteSpace($headerO)) { Stop-With 'Spalte O hat keinen Header.' }

    Write-Host "Excel-Quelle SHA256 PASS"
    Write-Host "Blatt: $($ws.Name)"
    Write-Host "Spalte O Header: $headerO"
    Write-Host 'Erlaubte Werte fuer automatische Anrede: M, F oder leer.'
    $ok = Read-Host 'Bestaetigen mit JA'
    if ($ok -ne 'JA') { Stop-With 'Abgebrochen. Keine Datei wurde geaendert.' }

    $rows = [ordered]@{}
    $countM=0; $countF=0; $countBlank=0
    foreach ($prop in $map.payload.entries.PSObject.Properties) {
        $id = [string]$prop.Name
        $row = [int]$prop.Value.sourceRow
        $idValue = $ws.Cells.Item($row, 2).Value2
        if ($null -eq $idValue) { Stop-With "ClientEEID in Excel-Zeile $row ist leer." }
        if ($idValue -is [double] -or $idValue -is [decimal] -or $idValue -is [int] -or $idValue -is [long]) {
            $excelId = ([string][long]$idValue).Trim()
        } else {
            $excelId = ([string]$idValue).Trim()
        }
        if ($excelId -ne $id) {
            $excelIdText = ([string]$ws.Cells.Item($row, 2).Text).Trim()
            if ($excelIdText -ne $id) { Stop-With "ClientEEID stimmt in Excel-Zeile $row nicht mit dem Mapping ueberein." }
        }
        $rawGender = $ws.Cells.Item($row, 15).Value2
        $gender = if ($null -eq $rawGender) { '' } else { ([string]$rawGender).Trim().ToUpperInvariant() }
        if ($gender -eq '') { $genderValue = $null; $countBlank++ }
        elseif ($gender -eq 'M') { $genderValue = 'M'; $countM++ }
        elseif ($gender -eq 'F') { $genderValue = 'F'; $countF++ }
        else { Stop-With "Unerwarteter Wert in Spalte O, Excel-Zeile $row. Erlaubt sind nur M, F oder leer." }
        $rows[$id] = [ordered]@{ sourceRow = $row; gender = $genderValue }
    }

    $sidecar = [ordered]@{
        schema = 'MCR_GENDER_SIDECAR_V1'
        sourceSha256 = $excelSha
        sheet = $ws.Name
        column = 'O'
        header = $headerO
        rows = $rows
        summary = [ordered]@{ M=$countM; F=$countF; blank=$countBlank }
    }
    $sidecar | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $temp -Encoding UTF8
}
finally {
    if ($wb) { $wb.Close($false) | Out-Null }
    if ($excel) { $excel.Quit() }
    if ($ws) { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($ws) }
    if ($wb) { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($wb) }
    if ($excel) { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($excel) }
    [GC]::Collect(); [GC]::WaitForPendingFinalizers()
}

try {
    $helper = Join-Path $PSScriptRoot 'apply-gender.mjs'
    if (!(Test-Path -LiteralPath $helper)) { Stop-With "Hilfsskript fehlt: $helper" }
    & $Node $helper $ProjectRoot $MappingPath $temp
    if ($LASTEXITCODE -ne 0) { Stop-With 'Gender-Mapping konnte nicht erzeugt werden.' }
}
finally {
    Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue
}

Write-Host ''
Write-Host '=============================================================='
Write-Host ' FERTIG'
Write-Host '=============================================================='
Write-Host 'Neues Mapping liegt in private_data.'
Write-Host 'Der bisherige 0.5.5-Runner und das alte Mapping bleiben unveraendert.'
Write-Host 'Ab jetzt fuer den Test starten:'
Write-Host (Join-Path $ProjectRoot 'START_LOCAL_BOT_GENDER.cmd')
Write-Host ''
Write-Host 'Regel: M -> Herr | F -> Frau | leer -> manuelle Rueckfrage. Keine Namensableitung.'
