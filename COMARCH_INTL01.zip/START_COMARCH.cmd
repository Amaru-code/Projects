@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
title COMARCH - INTL01
cd /d "%~dp0"
if errorlevel 1 goto folder_error

rem Optional: NODE_EXE vor dem Aufruf auf den vollstaendigen Pfad setzen.
set "COMARCH_NODE="
set "COMARCH_NODE_MODULES=C:\Users\Amaru-Zegarra\projects\Compiler\javascript\tools\node\node_modules"

if defined NODE_EXE if exist "%NODE_EXE%" set "COMARCH_NODE=%NODE_EXE%"
if not defined COMARCH_NODE if exist "%COMARCH_NODE_MODULES%\node.exe" set "COMARCH_NODE=%COMARCH_NODE_MODULES%\node.exe"
if not defined COMARCH_NODE if exist "%COMARCH_NODE_MODULES%\node\bin\node.exe" set "COMARCH_NODE=%COMARCH_NODE_MODULES%\node\bin\node.exe"
if not defined COMARCH_NODE if exist "%COMARCH_NODE_MODULES%\node-bin\bin\node.exe" set "COMARCH_NODE=%COMARCH_NODE_MODULES%\node-bin\bin\node.exe"
if not defined COMARCH_NODE if exist "%COMARCH_NODE_MODULES%\node-win-x64\node.exe" set "COMARCH_NODE=%COMARCH_NODE_MODULES%\node-win-x64\node.exe"
if not defined COMARCH_NODE if exist "%COMARCH_NODE_MODULES%\..\node.exe" set "COMARCH_NODE=%COMARCH_NODE_MODULES%\..\node.exe"
if not defined COMARCH_NODE if exist "%COMARCH_NODE_MODULES%\..\bin\node.exe" set "COMARCH_NODE=%COMARCH_NODE_MODULES%\..\bin\node.exe"
if not defined COMARCH_NODE if exist "%~dp0node.exe" set "COMARCH_NODE=%~dp0node.exe"
if not defined COMARCH_NODE for /f "delims=" %%N in ('where node.exe 2^>nul') do if not defined COMARCH_NODE set "COMARCH_NODE=%%N"

if not defined COMARCH_NODE goto node_error
if not exist "%~dp0comarch.cjs" goto script_error

rem Vorhandene Module im angegebenen Node-Ordner ebenfalls verwenden.
if defined NODE_PATH (
    set "NODE_PATH=%COMARCH_NODE_MODULES%;%NODE_PATH%"
) else (
    set "NODE_PATH=%COMARCH_NODE_MODULES%"
)

echo Node.js: "%COMARCH_NODE%"
echo.
"%COMARCH_NODE%" "%~dp0comarch.cjs"
set "COMARCH_EXIT=%ERRORLEVEL%"
echo.
if not "%COMARCH_EXIT%"=="0" echo Das Skript wurde mit Code %COMARCH_EXIT% beendet.
echo Fenster mit einer Taste schliessen.
pause >nul
exit /b %COMARCH_EXIT%

:node_error
echo node.exe wurde nicht gefunden.
echo Lege node.exe in denselben Ordner wie diese Startdatei.
echo Alternativ vor dem Aufruf den tatsaechlichen Pfad setzen:
echo set "NODE_EXE=C:\Pfad\zu\node.exe"
goto failed

:script_error
echo comarch.cjs fehlt. Beide Dateien muessen im selben entpackten Ordner liegen.
goto failed

:folder_error
echo Der Ordner der Startdatei konnte nicht geoeffnet werden.

:failed
echo.
echo Fenster mit einer Taste schliessen.
pause >nul
exit /b 1
