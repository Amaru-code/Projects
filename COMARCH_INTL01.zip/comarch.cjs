#!/usr/bin/env node
'use strict';

/* COMARCH ECM / INTL01 — Start: START_COMARCH.cmd
 * START nach der Anmeldung; ENTER/OK erst nach dem Review jeder Antwort.
 * Benötigt Node >=20 sowie Edge oder Chrome. Kein API-Schlüssel erforderlich.
 * Die echte Oberfläche und deine Mapping-Datei müssen beim ersten Lauf geprüft werden.
 *
 * BEDIENUNG
 * 1. comarch.cjs und START_COMARCH.cmd in denselben Ordner entpacken.
 * 2. START_COMARCH.cmd doppelklicken. Falls nötig, wird playwright-core mit npm
 *    einmalig in diesen Ordner installiert (keine globale Installation).
 * 3. Im geöffneten Browser selbst anmelden, im Terminal START eingeben.
 * 4. Vorbereitete Felder, Member, Empfänger, Anrede und Antwort im Browser prüfen.
 *    ENTER / OK sendet; HERR Nachname / FRAU Nachname ändert die Anrede.
 *    R wiederholt die Vorbereitung; W lässt das Ticket für diesen Lauf aus.
 * 5. Nach erfolgreichem Versand folgen geantwortet und ggf. Weiterleitung an Victor.
 *    STOP beendet das Programm und schließt dessen Browserfenster.
 *
 * STATUS zeigt comarch-status.json: Versandversuche bleiben über Neustarts erhalten.
 * Bei unklarem Ergebnis wird nicht automatisch erneut gesendet. Nach eigener Prüfung
 * kann BESTÄTIGT den erfolgreichen Versand bestätigen. OFFEN lässt ihn ungeklärt.
 * FREIGEBEN Ticket-ID am START-Prompt ist nur für tatsächlich NICHT gesendete Tickets.
 *
 * Die Mapping-Datei wird lokal gelesen. Fehlende Datei, kaputtes JSON und unbekanntes
 * Schema sind Konfigurationsfehler, keine nicht gefundene Person. Es gibt keine
 * KI-/Cloud-Abfrage für Namen oder Kundendaten. Anmeldung erfolgt nur im Browser.
 *
 * Grenzen: Dropdown-Reihenfolge entspricht deinen Angaben (Kategorie 1, Unterkategorie 3).
 * JSON-Schlüssel können über mappingOptions angepasst werden. Unbekannte Anrede ergibt
 * zunächst Guten Tag + Name; im Review Herr/Frau wählen oder im Browser korrigieren.
 * USC XX/ bleibt wörtlich, bis descriptionPrefix geändert wird. Falls der E-Mail-Bereich
 * noch zugeklappt ist, ihn im Browser öffnen und R verwenden.
 */
const fs = require('node:fs');
const path = require('node:path');
const readline = require('node:readline');
const {spawn} = require('node:child_process');

// -------- Nur hier ändern, wenn URL, Pfad oder gewünschte Auswahl abweichen. --------
const CONFIG = {
  url: process.env.COMARCH_URL || 'https://comarchecm.mercer.com/DMSWWW/',
  mappingPath: process.env.COMARCH_MAPPING || String.raw`C:\Users\Amaru-Zegarra\Downloads\INTL01_mapping_multirow_2026-10-06T14-30-22-387Z_64ea2aec_1f871026.json`,
  moduleDirectory: String.raw`C:\Users\Amaru-Zegarra\projects\Compiler\javascript\tools\node\node_modules`,
  browserExe: process.env.COMARCH_BROWSER_EXE || '',
  browserChannel: 'msedge',
  queue: 'INTL01',
  responsibility: 'Second Level',
  categoryDown: 1,
  subcategoryDown: 3,
  signatureQuery: 'intl01',
  forwardingQuery: 'victor',
  descriptionPrefix: 'USC XX/',
  // Optional: echte Spaltennamen deiner JSON-Datei eintragen, z.B. ['PP+', 'DC', 'DB'].
  // Ohne Liste: PP+, DC und kurze großgeschriebene 0/1-Produktspalten erkennen.
  mappingOptions: {},
  actionTimeout: 15000,
  ajaxWait: 850,
  sendTimeout: 15000,
  maxOkDialogs: 2,
  playwrightVersion: '1.64.1',
  stateFile: path.join(__dirname, 'comarch-status.json'),
};

const Mapping = (() => {


// Pure helpers. The real mapping file stays on the user's computer.
const fs = require('node:fs');

class MappingError extends Error {
  constructor(code, message) { super(message); this.name = 'MappingError'; this.code = code; }
}
const keyNorm = value => String(value).normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9+]/g, '');
const ID_KEYS = ['wwid', 'mercerid', 'memberid', 'employeeid', 'workerid', 'personnelnumber', 'personalnummer', 'personid', 'id'];
const FIRST_KEYS = ['firstname', 'givenname', 'vorname', 'first'];
const LAST_KEYS = ['lastname', 'surname', 'familyname', 'nachname', 'last'];
const SALUTATION_KEYS = ['anrede', 'salutation', 'title', 'geschlecht', 'gender', 'sex'];
const PLAN_KEYS = ['plan', 'planname', 'product', 'produkt', 'scheme', 'baustein', 'benefit'];
const FLAG_KEYS = ['value', 'wert', 'active', 'aktiv', 'enabled', 'flag', 'eligible', 'included'];
const META_KEYS = new Set([...ID_KEYS, ...FIRST_KEYS, ...LAST_KEYS, ...SALUTATION_KEYS, ...PLAN_KEYS, ...FLAG_KEYS,
  'name', 'fullname', 'membername', 'email', 'emailaddress', 'mail', 'age', 'alter', 'status', 'row', 'rowid', 'index', 'count', 'anzahl',
  'employercode', 'groupemployercode', 'payrollid', 'employee', 'person', 'member', 'company', 'firma', 'datum', 'date', 'birthdate', 'geburtsdatum',
  'source', 'quelle', 'usc', 'uscxx', 'version', 'level', 'priority', 'prioritat', 'selected', 'deleted', 'valid', 'isactive', 'activeemployee']);
const FIELD_CONTAINERS = new Set(['person', 'member', 'employee', 'identity', 'stammdaten', 'plans', 'products', 'flags', 'benefits', 'werte', 'values']);
const PLAN_CONTAINERS = new Set(['plans', 'products', 'flags', 'benefits']);
const isObject = value => value && typeof value === 'object' && !Array.isArray(value);
const isOn = value => value === 1 || value === true || String(value).trim() === '1';
const isFlag = value => value === true || value === false || value === 0 || value === 1 || ['0', '1', ''].includes(String(value).trim());

function normalizeId(value) {
  if (typeof value === 'number') return Number.isSafeInteger(value) && value >= 0 ? String(value) : null;
  const text = String(value ?? '').trim();
  const match = text.match(/^(?:INTL01-)?(\d+)$/i);
  return match ? match[1] : null;
}
function extractWwid(memberText) {
  const text = String(memberText ?? '').trim();
  const match = text.match(/\bINTL01-(\d+)\b/i);
  return match ? match[1] : normalizeId(text);
}
function fieldsOf(row) {
  const result = {...row};
  for (const [key, value] of Object.entries(row)) {
    if (FIELD_CONTAINERS.has(keyNorm(key)) && isObject(value)) Object.assign(result, fieldsOf(value));
  }
  return result;
}
function fieldValue(row, keys) {
  const wanted = new Set(keys.map(keyNorm));
  const entry = Object.entries(row).find(([key, value]) => wanted.has(keyNorm(key)) && value !== null && value !== undefined && String(value).trim() !== '');
  return entry ? String(entry[1]).trim() : '';
}
function normalizeMapping(json, options = {}) {
  const idKeys = (options.idKeys || ID_KEYS).map(keyNorm);
  const forcedPlans = options.planKeys ? new Set(options.planKeys.map(keyNorm)) : null;
  const index = new Map();
  let rowCount = 0;
  const warnings = [];
  const visited = new Set();
  function append(id, row) {
    if (!index.has(id)) index.set(id, []);
    index.get(id).push(row);
    rowCount++;
  }
  function walk(node, inheritedId = null, depth = 0) {
    if (!node || typeof node !== 'object' || depth > 30 || visited.has(node)) return;
    visited.add(node);
    if (Array.isArray(node)) { node.forEach(item => walk(item, inheritedId, depth + 1)); return; }
    // Common spreadsheet export: {headers:[...], rows:[[...], ...]}.
    const columns = node.headers || node.columns;
    const matrix = node.rows || node.data;
    if (Array.isArray(columns) && Array.isArray(matrix) && matrix.some(Array.isArray)) {
      const names = columns.map(column => typeof column === 'string' ? column : column?.name || column?.key || column?.title || '');
      for (const values of matrix) {
        if (Array.isArray(values)) walk(Object.fromEntries(names.map((name, i) => [name, values[i]])), inheritedId, depth + 1);
        else walk(values, inheritedId, depth + 1);
      }
      for (const [key, value] of Object.entries(node)) if (value !== columns && value !== matrix) walk(value, inheritedId, depth + 1);
      return;
    }
    const flat = fieldsOf(node);
    let id = null;
    // Alias priority matters when both an incidental row id and WWID exist.
    for (const key of idKeys) {
      // A multirow record can have an incidental `id: 1` within its WWID key.
      if (key === 'id' && inheritedId) continue;
      const found = Object.entries(flat).find(([candidate]) => keyNorm(candidate) === key);
      if (found && (id = normalizeId(found[1]))) {
        if (key !== 'id' && inheritedId && id !== inheritedId) {
          const equivalent = (id.startsWith('11') && id.slice(2) === inheritedId) || (inheritedId.startsWith('11') && inheritedId.slice(2) === id);
          if (!equivalent) throw new MappingError('SCHEMA_INVALID', `Widersprüchliche WWIDs im Mapping: ${inheritedId} / ${id}.`);
          id = inheritedId;
        }
        // Generic top-level export metadata must not become a person record.
        if (key === 'id' && !Object.entries(flat).some(([name, value]) =>
          [...FIRST_KEYS, ...LAST_KEYS, ...PLAN_KEYS].includes(keyNorm(name)) || (!META_KEYS.has(keyNorm(name)) && isFlag(value) &&
            (forcedPlans ? forcedPlans.has(keyNorm(name)) : /^(?:PP\+|DC)$/i.test(name) || /^[A-Z][A-Z0-9 +/_-]{0,24}$/.test(name.trim())))) &&
          !Object.keys(node).some(name => PLAN_CONTAINERS.has(keyNorm(name)))) id = null;
        if (id) break;
      }
    }
    id ||= inheritedId;
    const primitives = Object.fromEntries(Object.entries(flat).filter(([, value]) => value === null || ['string', 'number', 'boolean'].includes(typeof value)));
    if (id && Object.keys(primitives).length) append(id, primitives);
    for (const [key, value] of Object.entries(node)) {
      if (isObject(value) || Array.isArray(value)) {
        // Only recognized field containers inherit identity. A collection does too
        // when its parent is itself a keyed or explicitly identified record.
        // Numeric child keys within a known person are row indexes, not WWIDs.
        const nestedId = id || normalizeId(key);
        if (PLAN_CONTAINERS.has(keyNorm(key)) && nestedId) {
          const entries = Array.isArray(value) ? value : Object.entries(value).map(([name, item]) => typeof item === 'object' ? {plan:name, ...item} : {[name]:item});
          for (const item of entries) {
            if (Array.isArray(item) && item.length === 2 && typeof item[0] === 'string' && isFlag(item[1])) append(nestedId, {[item[0]]:item[1]});
            else if (isObject(item)) {
              const plan = fieldValue(item, [...PLAN_KEYS, 'name', 'code']);
              const flag = Object.entries(item).find(([name]) => FLAG_KEYS.includes(keyNorm(name)));
              if (plan && flag && isFlag(flag[1])) append(nestedId, {plan, value:flag[1]});
              else walk(item, nestedId, depth + 1);
            } else throw new MappingError('SCHEMA_INVALID', `Nicht unterstützte Planliste unter ${key}; erwartet werden Plan und 0/1-Wert.`);
          }
        } else if (!FIELD_CONTAINERS.has(keyNorm(key)) || Array.isArray(value)) walk(value, nestedId, depth + 1);
      }
    }
  }
  walk(json);
  if (!index.size) throw new MappingError('SCHEMA_INVALID', 'In der JSON-Datei wurden keine Datensätze mit erkennbarer WWID gefunden. ID-Spalten oder JSON-Struktur prüfen.');
  return {index, rowCount, warnings, options: {...options, forcedPlans}};
}
function loadMapping(filePath, options = {}) {
  let raw;
  try { raw = fs.readFileSync(filePath, 'utf8'); }
  catch (error) { throw new MappingError('FILE_READ', `Mapping-Datei kann nicht gelesen werden: ${error.message}`); }
  let json;
  try { json = JSON.parse(raw.replace(/^\uFEFF/, '')); }
  catch (error) { throw new MappingError('JSON_PARSE', `Mapping-Datei enthält kein gültiges JSON: ${error.message}`); }
  return normalizeMapping(json, options);
}
function flagsForRows(rows, options = {}) {
  const flags = new Map();
  const forced = options.forcedPlans || (options.planKeys ? new Set(options.planKeys.map(keyNorm)) : null);
  const setFlag = name => {
    const clean = String(name).trim();
    if (clean) flags.set(keyNorm(clean), clean);
  };
  for (const row of rows) {
    const plan = fieldValue(row, options.planNameKeys || PLAN_KEYS);
    const active = Object.entries(row).find(([key]) => (options.flagKeys || FLAG_KEYS).map(keyNorm).includes(keyNorm(key)));
    if (plan && active && isOn(active[1]) && (!forced || forced.has(keyNorm(plan)))) setFlag(plan);
    for (const [key, value] of Object.entries(row)) {
      const normalized = keyNorm(key);
      if (META_KEYS.has(normalized) || !isFlag(value)) continue;
      // Unknown uppercase short flag columns are treated as plan codes. Use
      // planKeys explicitly for other labels or schema-specific metadata.
      const looksLikePlan = /^(?:PP\+|DC)$/i.test(key) || /^[A-Z][A-Z0-9 +/_-]{0,24}$/.test(key.trim());
      if ((forced ? forced.has(normalized) : looksLikePlan) && isOn(value)) setFlag(key);
    }
  }
  return [...flags.values()].sort((a, b) => {
    const rank = value => keyNorm(value) === 'pp+' ? 0 : keyNorm(value) === 'dc' ? 1 : 2;
    return rank(a) - rank(b) || a.localeCompare(b, 'de');
  });
}
function personForRows(rows) {
  const collect = keys => [...new Set(rows.map(row => fieldValue(row, keys)).filter(Boolean))];
  const firstNames = collect(FIRST_KEYS), lastNames = collect(LAST_KEYS), salutations = collect(SALUTATION_KEYS);
  return {
    firstName: firstNames.length === 1 ? firstNames[0] : '',
    lastName: lastNames.length === 1 ? lastNames[0] : '',
    salutation: salutations.length === 1 ? salutations[0] : '',
    ambiguous: firstNames.length > 1 || lastNames.length > 1 || salutations.length > 1,
  };
}
function findPerson(mapping, wwid) {
  const id = extractWwid(wwid);
  if (!id) throw new MappingError('ID_INVALID', 'Die ausgewählte Person enthält keine gültige INTL01-WWID.');
  const searchedIds = [id];
  if (id.startsWith('11') && id.length > 2) searchedIds.push(id.slice(2));
  for (const matchedId of searchedIds) {
    const rows = mapping.index.get(matchedId);
    if (rows?.length) return {status: 'found', searchedIds: searchedIds.slice(0, searchedIds.indexOf(matchedId) + 1), matchedId,
      usedPrefixFallback: matchedId !== id, rows, flags: flagsForRows(rows, mapping.options), person: personForRows(rows)};
  }
  return {status: 'not_found', searchedIds, matchedId: null, usedPrefixFallback: false, rows: [], flags: [], person: {}};
}
function buildDescription(result, prefix = 'USC XX/') {
  return result.status === 'found' ? `${prefix}${result.flags.join('/')}` : 'Person nicht gefunden';
}
function inferMemberQueries(email) {
  const match = String(email ?? '').trim().match(/^(?:.*<)?([^\s<>@]+)@([^\s<>@]+)>?$/);
  if (!match) return [];
  const local = match[1].toLowerCase().split('+')[0];
  const domain = match[2].toLowerCase().replace(/>$/, '').split('.')[0];
  const clean = value => value.replace(/[^\p{L}\p{M}' -]/gu, '').replace(/\s+/g, ' ').trim();
  const tokens = local.split(/[._-]+/).map(clean).filter(Boolean);
  const generic = /^(?:info|office|service|support|contact|kontakt|mail|email|noreply|no reply|admin|hr|personal|centralclientmailbox)$/i;
  const provider = /^(?:gmail|googlemail|gmx|web|outlook|hotmail|live|yahoo|icloud|aol|t-online|proton|protonmail|mailbox|posteo)$/i;
  if (!tokens.length || generic.test(tokens.join(' '))) return [];
  const candidates = [];
  const add = query => { if (query && !candidates.some(item => item.query === query)) candidates.push({query, heuristic: true, source: 'email'}); };
  if (tokens.length >= 2) {
    add(`${tokens.slice(1).join(' ')} ${tokens[0]}`);
    add(tokens.join(' '));
  } else if (tokens[0].length > 1 && clean(domain) && !generic.test(domain) && !provider.test(domain)) add(`${clean(domain)} ${tokens[0]}`);
  return candidates;
}
function getSalutation(person, lastName = person?.lastName) {
  if (!lastName || person?.ambiguous) return null;
  const value = keyNorm(person?.salutation || '');
  if (['herr', 'mr', 'mister', 'male', 'mann', 'mannlich', 'm'].includes(value)) return `Sehr geehrter Herr ${lastName},`;
  if (['frau', 'mrs', 'ms', 'miss', 'female', 'weiblich', 'w', 'f'].includes(value)) return `Sehr geehrte Frau ${lastName},`;
  return null;
}

return {MappingError, normalizeMapping, loadMapping, findPerson, buildDescription, extractWwid, inferMemberQueries, getSalutation};

})();

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const norm = value => String(value || '').replace(/\s+/g, ' ').trim();
const answered = value => /\bgeantwortet\b/i.test(String(value || ''));
const cssId = id => `[id=${JSON.stringify(id)}]`;
const escapeHtml = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const EMAIL_PATTERN = /[A-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi;
const emails = value => [...new Set((String(value || '').match(EMAIL_PATTERN) || []).map(s => s.toLowerCase()))];
const ERROR_TEXT = /\b(fehler|error|fehlgeschlagen|ungültig|gescheitert)\b|nicht (gesendet|versendet|gespeichert)|konnte.{0,50}nicht/i;
const SEND_SUCCESS = /(?:e-?mail|nachricht).{0,100}(?:erfolgreich (?:gesendet|versendet)|wurde (?:gesendet|versandt|versendet))|erfolgreich (?:gesendet|versendet)/i;

function descriptionWith(existing, mainLine, mark = false) {
  const lines = String(existing || '').split(/\r?\n/).map(s => s.trim()).filter(Boolean)
    .filter(s => !/^USC\s+XX\//i.test(s) && !/^Person nicht gefunden$/i.test(s) && !/^geantwortet$/i.test(s));
  const text = [mainLine, ...lines, ...(mark ? ['geantwortet'] : [])].filter(Boolean).join('\n');
  if (text.length > 450) throw new Error('Zusätzliche Beschreibung wäre länger als 450 Zeichen. Bitte im Browser kürzen.');
  return text;
}
function replyText(salutation) {
  return `${salutation}\n\nvielen Dank, dass Sie sich mit uns in Verbindung gesetzt haben.\n\nMit dieser E-Mail möchten wir Ihnen bestätigen, dass wir Ihr Ticket erhalten haben und unser Team derzeit daran arbeitet. Wir wissen Ihre Geduld und Ihr Verständnis zu schätzen, da wir uns bemühen, Ihnen den bestmöglichen Support zu bieten.\nSeien Sie versichert, dass Ihr Anliegen für uns wichtig ist und wir uns bemühen, es so schnell wie möglich zu lösen. Unser engagiertes Team arbeitet aktiv an Ihrem Ticket und wird Sie über den aktuellen Stand der Dinge informieren.\nWenn Sie weitere Informationen oder Fragen zu Ihrem Ticket haben, können Sie gerne auf diese E-Mail antworten.`;
}
function replyHtml(salutation) {
  return replyText(salutation).split('\n\n').map(p => `<p style="font-family:Arial,Helvetica,sans-serif;font-size:11pt;">${escapeHtml(p).replace(/\n/g, '<br>')}</p>`).join('');
}
function memberParts(text) {
  const match = String(text || '').trim().match(/^(.+?)\s*\(INTL01-(\d+)\)\s*$/i);
  return match ? {display: match[0], name: match[1].trim(), wwid: match[2]} : null;
}

class Terminal {
  constructor() {
    this.rl = readline.createInterface({input: process.stdin, output: process.stdout});
    this.pending = null;
    this.closed = false;
    // Zeilen nur am sichtbaren Prompt annehmen: vorab gedrücktes ENTER sendet nichts.
    this.rl.on('line', line => { const done = this.pending; this.pending = null; if (done) done(line.trim()); });
    this.rl.on('close', () => { this.closed = true; if (this.pending) this.pending('STOP'); this.pending = null; });
    this.rl.on('SIGINT', () => this.rl.close());
  }
  ask(message) {
    if (this.closed) return Promise.resolve('STOP');
    return new Promise(resolve => { this.pending = resolve; process.stdout.write(message); });
  }
  log(message) { console.log(message); }
  close() { this.rl.close(); }
}

class Journal {
  constructor(file) {
    this.file = file;
    this.data = {version: 1, tickets: {}};
    if (fs.existsSync(file)) {
      try { this.data = JSON.parse(fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '')); }
      catch { throw new Error(`Statusdatei unlesbar: ${file}. Erst prüfen; sie schützt vor doppeltem Versand.`); }
      if (this.data.version !== 1 || !this.data.tickets || typeof this.data.tickets !== 'object' || Array.isArray(this.data.tickets))
        throw new Error('Unbekanntes Format der Statusdatei. Datei vor einem weiteren Versand prüfen.');
    }
  }
  get(id) { return this.data.tickets[id]; }
  blocks(id) { return /^(sending|sent|uncertain|forwarding|forwarded|forward_uncertain)$/.test(this.get(id)?.status || ''); }
  set(id, status, extra = {}) {
    if (!/^\d+$/.test(id)) throw new Error('Ungültige Ticket-ID für Statusdatei.');
    this.data.tickets[id] = {...this.get(id), ...extra, status, updatedAt: new Date().toISOString()};
    this.save();
  }
  remove(id) { delete this.data.tickets[id]; this.save(); }
  save() {
    const tmp = `${this.file}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(this.data, null, 2), {encoding: 'utf8', mode: 0o600});
    fs.renameSync(tmp, this.file);
  }
}

class ComarchBot {
  constructor(page, options = {}) {
    this.page = page;
    this.cfg = {...CONFIG, ...options.config};
    this.io = options.io || {log: console.log, ask: async () => 'STOP'};
    this.journal = options.journal || new Journal(this.cfg.stateFile);
    this.mapping = options.mapping || null;
    this.mappingError = null;
    this.skipped = new Set();
    this.active = null;
    this.dialogWindow = null;
    this.posts = new Set();
    this.lastPostEnd = 0;
    page.setDefaultTimeout(this.cfg.actionTimeout);
    page.on('request', req => {
      // ICEfaces-Push darf dauerhaft offen bleiben. Nur Formularereignisse zählen.
      const formEvent = /(?:^|&)(?:ice\.event\.[^=]+|ice\.submit\.[^=]+|javax\.faces\.source|javax\.faces\.partial\.ajax|mainForm(?:%3A|:)[^=]+)=/i.test(req.postData() || '');
      if (req.method() === 'POST' && ['xhr','fetch'].includes(req.resourceType()) && formEvent) this.posts.add(req);
    });
    const finish = req => { if (this.posts.delete(req)) this.lastPostEnd = Date.now(); };
    page.on('requestfinished', finish);
    page.on('requestfailed', finish);
    page.on('dialog', async dialog => {
      const gate = this.dialogWindow;
      try {
        if (gate && Date.now() < gate.until && gate.count < this.cfg.maxOkDialogs && ['alert','confirm'].includes(dialog.type())) {
          gate.count++;
          gate.messages.push(dialog.message());
          this.io.log(`[Dialog] ${norm(dialog.message())}`);
          await dialog.accept();
        } else {
          this.io.log(`[Hinweis] Browserdialog nicht automatisch bestätigt: ${norm(dialog.message())}`);
          await dialog.dismiss();
        }
      } catch (error) { this.io.log(`[Dialog] ${error.message}`); }
    });
  }
  field(id) { return this.page.locator(cssId(id)); }
  async wait(test, message, timeout = this.cfg.actionTimeout) {
    const end = Date.now() + timeout;
    let last;
    while (Date.now() < end) {
      if (this.page.isClosed()) throw new Error('Browserfenster wurde geschlossen.');
      try { const value = await test(); if (value) return value; } catch (error) { last = error; }
      await sleep(180);
    }
    throw new Error(`${message}${last ? ` (${last.message.split('\n')[0]})` : ''}`);
  }
  async settle(minimum = this.cfg.ajaxWait) {
    await sleep(minimum);
    const end = Date.now() + this.cfg.actionTimeout;
    while (this.posts.size || Date.now() - this.lastPostEnd < 350) {
      if (Date.now() > end) throw new Error('Die letzte Formularanfrage wurde noch nicht abgeschlossen.');
      await sleep(150);
    }
  }
  async step(name, action, attempts = 2) {
    for (let n = 1; n <= attempts; n++) {
      try { const value = await action(); this.io.log(`  OK  ${name}`); return value; }
      catch (error) {
        this.io.log(`  !   ${name} (${n}/${attempts}): ${error.message.split('\n')[0]}`);
        if (this.page.isClosed()) throw error;
        if (n < attempts) await sleep(500);
      }
    }
    if (this.active) this.active.issues.push(name);
    return null;
  }
  async unique(locator, name) {
    const visible = locator.filter({visible:true});
    await visible.first().waitFor({state: 'visible'});
    if (await visible.count() !== 1) throw new Error(`${name} ist nicht eindeutig. Bitte die Ansicht im Browser prüfen.`);
    return visible;
  }
  async navigate(name) {
    const menu = this.page.locator('span.ellipsisText.flexColumn').filter({hasText: new RegExp(`^${name}$`)});
    const target = await this.unique(menu, `Menü ${name}`);
    await target.scrollIntoViewIfNeeded();
    await target.click();
    const tableId = name === 'In_Bearbeitung' ? 'mainForm:tasksTableFor_MyTasksList' : 'mainForm:tasksTableFor_MyQueuesTasksList';
    await this.field(tableId).waitFor({state:'visible'});
    await this.settle();
    return tableId;
  }
  async tableRows(tableId) {
    return this.page.evaluate(id => {
      const table = document.getElementById(id);
      if (!table || !table.getClientRects().length) throw new Error('Die angeforderte Ticketliste ist nicht sichtbar.');
      const clean = s => String(s || '').replace(/\s+/g,' ').trim();
      const header = Array.from(table.tHead?.rows[0]?.cells || []).map(cell => clean(cell.querySelector('span[title]')?.getAttribute('title') || cell.textContent));
      const idCol = header.indexOf('Ticket-ID'), descCol = header.indexOf('Zusätzliche Beschreibung'), groupCol = header.indexOf('Group Employer Code');
      if (idCol < 0 || descCol < 0) throw new Error('Ticket-ID oder Zusätzliche Beschreibung fehlt als Tabellenspalte.');
      const rows = Array.from(table.tBodies[0]?.rows || []).map(row => {
        const idCell = row.cells[idCol], descCell = row.cells[descCol];
        const ticketId = clean(idCell?.textContent);
        const description = [descCell?.textContent, ...Array.from(descCell?.querySelectorAll('[title]') || []).map(el => el.title)].join('\n');
        return {ticketId, rowId: row.id, linkId: idCell?.querySelector('a')?.id || '', description,
          group: groupCol < 0 ? '' : clean(row.cells[groupCol]?.textContent)};
      }).filter(row => /^\d+$/.test(row.ticketId) && row.linkId);
      const area = document.getElementById('mainForm:resultsID');
      return {rows, explicitlyEmpty: /Keine Ergebnisse gefunden/i.test(area?.innerText || '')};
    }, tableId);
  }
  async candidates(name) {
    const table = await this.navigate(name);
    const result = await this.wait(async () => {
      const data = await this.tableRows(table);
      return data.rows.length || data.explicitlyEmpty ? data : null;
    }, `Liste ${name} hat noch keine auswertbaren Ergebnisse.`, 12000);
    return result.rows.filter(row => {
      if (row.group && row.group.toUpperCase() !== this.cfg.queue) return false;
      return !answered(row.description) && !this.journal.blocks(row.ticketId) && !this.skipped.has(row.ticketId);
    });
  }
  async nextTicket(firstPass = false) {
    for (const menu of firstPass ? ['In_Bearbeitung', this.cfg.queue] : [this.cfg.queue]) {
      const rows = await this.candidates(menu);
      if (rows.length) return rows[0];
    }
    return null;
  }
  async labelValue(text, rootId = '') {
    return this.page.evaluate(({text, rootId}) => {
      const root = rootId ? document.getElementById(rootId) : document;
      const clean = s => String(s || '').replace(/\s+/g,' ').trim();
      const label = Array.from(root?.querySelectorAll('label') || []).find(el => clean(el.textContent) === text && el.getClientRects().length);
      if (!label) return '';
      const next = label.nextElementSibling;
      if (next && ['LABEL','INPUT','SELECT','SPAN'].includes(next.tagName)) return clean(next.value ?? next.textContent);
      const cell = label.closest('td');
      const valueCell = cell?.nextElementSibling;
      if (!valueCell) return '';
      const field = valueCell.querySelector('input:not([type="hidden"]),select,textarea');
      return clean(field ? field.value : valueCell.textContent);
    }, {text, rootId});
  }
  async ticketId() {
    return this.page.evaluate(() => {
      const summary = document.querySelector('.taskViewHeaderSummaryRow');
      const label = Array.from(summary?.querySelectorAll('label') || []).find(el => el.textContent.trim() === 'Ticket-ID:');
      return label?.nextElementSibling?.textContent.trim() || '';
    });
  }
  async assertTicket(id) {
    const actual = await this.ticketId();
    if (actual !== id) throw new Error(`Ticketansicht stimmt nicht überein (erwartet ${id}, sichtbar ${actual || 'keine'}).`);
  }
  async openTicket(row) {
    await this.field(row.linkId).click();
    await this.wait(async () => await this.ticketId() === row.ticketId, `Ticket ${row.ticketId} wurde nicht geöffnet.`);
    await this.settle();
  }
  descriptionLocator() {
    return this.field('mainForm:document-data-section').locator('label').filter({hasText:/^Zusätzliche Beschreibung:\s*$/})
      .locator('xpath=ancestor::table[1]').locator('textarea');
  }
  async readDescription() {
    const area = this.descriptionLocator();
    if (await area.count() === 1 && await area.isVisible()) return area.inputValue();
    return this.field('mainForm:document-data-section').locator('label').filter({hasText:/^Zusätzliche Beschreibung:\s*$/})
      .locator('xpath=ancestor::table[1]').innerText().then(s => s.replace(/^\s*Zusätzliche Beschreibung:\s*/, '').trim());
  }
  async setDescription(value) {
    if (value.length > 450) throw new Error('Zusätzliche Beschreibung überschreitet 450 Zeichen.');
    const area = await this.unique(this.descriptionLocator(), 'Zusätzliche Beschreibung');
    await area.fill(value);
    await area.press('Tab');
    await this.settle();
    if ((await this.readDescription()).replace(/\r/g,'') !== value.replace(/\r/g,'')) throw new Error('Beschreibung wurde nach der Formularaktualisierung verändert.');
  }
  async ensureEditable() {
    const member = this.field('mainForm:member-value-id');
    if (await member.isVisible() && await member.isEditable()) { await member.click(); return true; }
    const button = await this.unique(this.page.getByRole('button', {name:'Bearbeiten', exact:true}), 'Bearbeiten');
    await button.scrollIntoViewIfNeeded();
    await button.click();
    await this.wait(async () => await member.isVisible() && await member.isEditable(), 'Ticket ist nach Bearbeiten noch nicht editierbar.');
    await member.click();
    await this.settle();
    return true;
  }
  async autocomplete(id, {query, down = 1, validate = value => !!norm(value)} = {}) {
    let input = this.field(id);
    await input.waitFor({state:'visible'});
    if (!await input.isEditable()) throw new Error(`${id} ist nicht editierbar.`);
    await input.scrollIntoViewIfNeeded();
    await input.click();
    await input.press('Escape');
    await input.fill(query ?? '');
    // fill() allein löst kein keyup aus; die ICEfaces-Suche benötigt Tastaturereignisse.
    if (query !== undefined) { await input.press('End'); await this.settle(); }
    for (let n=0; n<down; n++) {
      await this.field(id).press('ArrowDown');
      await this.settle(n === 0 ? this.cfg.ajaxWait : 180);
    }
    const choices = [...new Set((await this.page.locator('.iceSelInpTxtSelRow:visible, .iceSelInpTxtListSel:visible, [role="option"][aria-selected="true"]:visible').allTextContents()).map(norm).filter(Boolean))];
    await this.field(id).press('Enter');
    await this.settle();
    await this.wait(async () => {
      const value = await this.field(id).inputValue();
      return validate(value) ? value : null;
    }, `Keine bestätigte Auswahl in ${id}.`);
    await this.field(id).press('Tab');
    await this.settle();
    const value = await this.field(id).inputValue();
    if (!validate(value)) throw new Error(`Auswahl in ${id} wurde nicht übernommen.`);
    this.lastAutocomplete = {id, value, selectionEvidence: choices.length===1 && norm(choices[0])===norm(value) || norm(value)!==norm(query ?? '')};
    return value;
  }
  historySection() {
    return this.page.locator('span').filter({hasText:/^Nachrichtenverlauf\s*$/}).locator('xpath=ancestor::div[contains(concat(" ",normalize-space(@class)," ")," icePnlClpsbl ")][1]');
  }
  async historyRows() {
    const section = this.historySection();
    if (!await section.count()) return [];
    return section.first().evaluate(root => {
      const clean = s => String(s || '').replace(/\s+/g, ' ').trim();
      const table = Array.from(root.querySelectorAll('table')).find(t => t.tHead && Array.from(t.tHead.rows[0].cells).some(c => clean(c.textContent) === 'Von'));
      if (!table) return [];
      const labels = Array.from(table.tHead.rows[0].cells).map(c => clean(c.textContent));
      const val = (row, name) => clean(row.cells[labels.indexOf(name)]?.textContent);
      return Array.from(table.tBodies[0]?.rows || []).map(row => ({from:val(row,'Von'), to:val(row,'An'), subject:val(row,'Betreff'), body:val(row,'Inhalt'), date:val(row,'Datum')})).filter(row => row.from || row.to);
    });
  }
  async senders() {
    const rows = await this.historyRows();
    return [...new Set(rows.flatMap(row => emails(row.from)))].filter(email => !/@(?:[^@.]+\.)?(?:mercer|mmc|marsh)\.com$/i.test(email));
  }
  async actualRecipients() {
    // Nur echte editierbare Empfängerfelder, niemals die eingehende E-Mail-an-Anzeige.
    return this.page.evaluate(() => {
      const clean = s => String(s || '').replace(/\s+/g,' ').trim();
      const fields = Array.from(document.querySelectorAll('input,textarea')).filter(el => el.getClientRects().length && !el.disabled && el.type !== 'hidden');
      const found = [];
      for (const field of fields) {
        const id = `${field.id} ${field.name}`;
        const named = /(?:email|message)[-_:]?(?:to|recipient)(?:[-_:]|$)|(?:to|recipient)[-_:]?(?:email|message)/i.test(id);
        const linked = Array.from(document.querySelectorAll('label')).some(label => {
          if (!/^(An|Empfänger|Empfaenger|E-Mail an):?$/i.test(clean(label.textContent))) return false;
          return label.htmlFor === field.id || label.closest('td')?.nextElementSibling?.contains(field);
        });
        if (named || linked) found.push(field.value);
      }
      return found.join('; ');
    }).then(emails);
  }
  async resolveMember() {
    const current = await this.field('mainForm:member-value-id').inputValue();
    if (memberParts(current)) return current;
    const senders = await this.senders();
    if (senders.length > 1) this.io.log(`  Hinweis: Mehrere externe Absender im Verlauf: ${senders.join(', ')}. Member im Review prüfen.`);
    const queries = current.trim() ? [{query:current}] : Mapping.inferMemberQueries(senders[0]);
    if (!queries.length) throw new Error('Kein eindeutiger Suchname aus der E-Mail ableitbar. Member im Browser auswählen und R eingeben.');
    for (const item of queries) {
      this.io.log(`  Member-Suchvorschlag aus E-Mail: ${item.query}`);
      try { return await this.autocomplete('mainForm:member-value-id', {query:item.query, down:1, validate:value=>!!memberParts(value)}); }
      catch (error) { this.io.log(`  Kein bestätigter Treffer für ${item.query}: ${error.message.split('\n')[0]}`); }
    }
    throw new Error('Member-Auswahl nicht bestätigt. Bitte Person im Browser wählen; R wiederholt die Vorbereitung.');
  }
  reloadMapping() {
    try { this.mapping = Mapping.loadMapping(this.cfg.mappingPath, this.cfg.mappingOptions); this.mappingError = null; }
    catch (error) { this.mapping = null; this.mappingError = error.message; }
  }
  async editorGet() {
    return this.page.evaluate(() => {
      const editor = window.CKEDITOR?.instances?.['mainForm:emailMessageBodyRichEditor'];
      if (!editor || editor.readOnly) throw new Error('Der E-Mail-Editor ist noch nicht verfügbar. E-Mail-Bereich im Browser öffnen.');
      return editor.getData();
    });
  }
  async editorSet(html) {
    await this.page.evaluate(html => new Promise((resolve,reject) => {
      const editor = window.CKEDITOR?.instances?.['mainForm:emailMessageBodyRichEditor'];
      if (!editor || editor.readOnly) return reject(new Error('E-Mail-Editor nicht verfügbar.'));
      const timeout = setTimeout(() => reject(new Error('Editor hat den neuen Inhalt nicht bestätigt.')), 12000);
      editor.setData(html, function() {
        clearTimeout(timeout);
        editor.updateElement();
        editor.fire('change');
        resolve();
      });
    }), html);
  }
  async editorSnapshot() {
    return this.page.evaluate(() => {
      const editor = window.CKEDITOR?.instances?.['mainForm:emailMessageBodyRichEditor'];
      if (!editor) throw new Error('E-Mail-Editor fehlt.');
      editor.updateElement();
      const html = editor.getData(), div = document.createElement('div');
      div.innerHTML = html;
      div.querySelectorAll('br').forEach(br=>br.replaceWith('\n'));
      div.querySelectorAll('p,div,li,tr').forEach(block=>block.appendChild(document.createTextNode('\n')));
      return {html, text: (div.textContent || '').trim()};
    });
  }
  async greetingChange(command) {
    const match = command.match(/^(HERR|FRAU|NEUTRAL)(?:\s+(.+))?$/i);
    if (!match) return false;
    const name = match[2] || this.active.lastName;
    if (!name) throw new Error('Nachnamen mit angeben, z.B. HERR Mustermann.');
    const greeting = match[1].toUpperCase() === 'HERR' ? `Sehr geehrter Herr ${name},` : match[1].toUpperCase() === 'FRAU' ? `Sehr geehrte Frau ${name},` : `Guten Tag ${name},`;
    const html = await this.page.evaluate(({html,greeting}) => {
      const div = document.createElement('div'); div.innerHTML = html;
      const first = div.querySelector('p');
      if (!first || !/^(Sehr geehrt|Guten Tag)/i.test(first.textContent.trim())) throw new Error('Anrede bitte direkt im Browser ändern.');
      first.textContent = greeting;
      return div.innerHTML;
    }, {html:await this.editorGet(), greeting});
    await this.editorSet(html);
    this.active.salutation = greeting;
    return true;
  }
  async prepare(row) {
    this.active = {id:row.ticketId, issues:[], forward:false, member:null, mappingResult:null, lastName:'', signatureHtml:null, signatureReady:false};
    await this.assertTicket(row.ticketId);
    const group = await this.labelValue('Group Employer Code:', 'mainForm:document-data-section');
    if (group && group.toUpperCase() !== this.cfg.queue) throw new Error(`Ticket gehört zu ${group}, nicht zu ${this.cfg.queue}.`);
    if (answered(await this.readDescription())) { this.skipped.add(row.ticketId); return null; }
    const editable = await this.step('Ticket zur Bearbeitung öffnen', () => this.ensureEditable());
    if (!editable) return this.active;
    await this.step('Zuständigkeit Second Level', async () => {
      await this.field('mainForm:responsibility-value-id').selectOption({label:this.cfg.responsibility});
      await this.settle();
      if (await this.field('mainForm:responsibility-value-id').inputValue() !== this.cfg.responsibility) throw new Error('Second Level wurde nicht übernommen.');
    });
    await this.step('Dokumentenkategorie: erster Eintrag', () => this.autocomplete('mainForm:category-value-id', {down:this.cfg.categoryDown}));
    const member = await this.step('Member auswählen / vorhandenen Member verwenden', () => this.resolveMember(), 1);
    this.active.member = member && memberParts(member);
    await this.step('Unterkategorie: dritter Eintrag', () => this.autocomplete('mainForm:category-sub-value-id', {down:this.cfg.subcategoryDown}));
    await this.step('WWID in Mapping zuordnen und Beschreibung eintragen', async () => {
      if (!this.mapping) throw new Error(this.mappingError || 'Mapping-Datei ist nicht geladen.');
      const selected = memberParts(await this.field('mainForm:member-value-id').inputValue());
      if (!selected) throw new Error('Keine bestätigte WWID im Member-Feld.');
      this.active.member = selected;
      const result = Mapping.findPerson(this.mapping, selected.wwid);
      this.active.mappingResult = result;
      this.active.forward = result.status === 'not_found';
      if (result.usedPrefixFallback) this.io.log(`  WWID ${selected.wwid}: Treffer ohne führendes 11 (${result.matchedId}).`);
      if (result.status === 'found' && !result.flags.length) this.io.log('  Hinweis: Kein aktiver Produktcode erkannt. Mapping-Spalten im Review prüfen.');
      const core = Mapping.buildDescription(result, this.cfg.descriptionPrefix);
      await this.setDescription(descriptionWith(await this.readDescription(), core));
    });
    await this.step('Signatur intl01', async () => {
      const selected = await this.autocomplete('mainForm:signature-value-id', {query:this.cfg.signatureQuery, down:1});
      if (!this.lastAutocomplete.selectionEvidence) throw new Error('Im Signaturfeld steht nur der Suchtext; Auswahl nicht bestätigt.');
      await this.wait(async () => {
        const html = await this.editorGet();
        return html.replace(/<[^>]*>/g,'').replace(/&nbsp;/g,' ').trim().length>5 || /<img\b/i.test(html);
      }, 'Signatur wurde nicht in den Editor übernommen.');
      this.active.signatureReady=true;
      this.active.signatureValue=selected;
    });
    await this.step('Antworttext im E-Mail-Editor vorbereiten', async () => {
      const details = this.active.mappingResult?.person || {};
      const last = await this.labelValue('Nachname:', 'mainForm:document-data-section');
      const first = await this.labelValue('Vorname:', 'mainForm:document-data-section');
      this.active.lastName = last || details.lastName || '';
      const explicit = await this.labelValue('Anrede:', 'mainForm:document-data-section');
      const person = {...details, ...(explicit ? {salutation:explicit, ambiguous:false} : {})};
      let greeting = Mapping.getSalutation(person, this.active.lastName);
      if (!greeting) {
        const fullName = norm([first || details.firstName, this.active.lastName].filter(Boolean).join(' ')) || this.active.member?.name;
        if (!fullName) throw new Error('Name für Anrede fehlt. Member im Browser zuordnen und R eingeben.');
        greeting = `Guten Tag ${fullName},`;
        this.io.log('  Anrede fehlt in den Daten. Im Review HERR Nachname oder FRAU Nachname eingeben oder Text im Browser ändern.');
      }
      const existing = await this.wait(() => this.editorGet(), 'E-Mail-Editor wurde nicht geladen.');
      // Bei einer Wiederholung niemals vorhandenen Antworttext als Signatur duplizieren.
      if (/vielen Dank, dass Sie sich mit uns in Verbindung gesetzt haben/.test(existing)) {
        this.io.log('  Vorhandener Antwortentwurf bleibt erhalten; bitte im Review prüfen.');
        return;
      }
      this.active.signatureHtml = existing;
      this.active.salutation = greeting;
      await this.editorSet(replyHtml(greeting) + '<p><br></p>' + existing);
    });
    if (this.active.forward) await this.step('Weiterleitung an Victor vorbereiten', () => this.autocomplete('mainForm:persona-assignment-id', {
      query:this.cfg.forwardingQuery, down:1, validate:value=>/victor/i.test(value) && norm(value).toLowerCase() !== this.cfg.forwardingQuery.toLowerCase(),
    }));
    return this.active;
  }
  async validation() {
    await this.assertTicket(this.active.id);
    const missing = [];
    const read = async id => this.field(id).inputValue().catch(()=>'');
    const selected = memberParts(await read('mainForm:member-value-id'));
    if (!selected) missing.push('Member mit bestätigter INTL01-WWID');
    if (selected && this.active.member && selected.wwid !== this.active.member.wwid) missing.push('Member wurde geändert: R für neue Zuordnung');
    if (await read('mainForm:responsibility-value-id') !== this.cfg.responsibility) missing.push('Second Level');
    for (const [id,label] of [['category-value-id','Dokumentenkategorie'],['category-sub-value-id','Unterkategorie'],['signature-value-id','Signatur']])
      if (!norm(await read(`mainForm:${id}`))) missing.push(label);
    if (!this.active.signatureReady || await read('mainForm:signature-value-id')!==this.active.signatureValue) missing.push('bestätigte Signaturauswahl (R nach Korrektur)');
    if (!this.mapping || !this.active.mappingResult) missing.push('ausgewertete Mapping-Datei (R nach Korrektur)');
    const description = await this.readDescription();
    if (this.active.mappingResult && !description.includes(Mapping.buildDescription(this.active.mappingResult,this.cfg.descriptionPrefix))) missing.push('Beschreibung passend zur Mapping-Zuordnung');
    if (answered(description)) missing.push('Ticket enthält bereits geantwortet; Versand wird ausgelassen');
    if (description.length + '\ngeantwortet'.length > 450) missing.push('Platz für geantwortet in der Beschreibung (max. 450 Zeichen)');
    const body = await this.editorSnapshot().catch(()=>({html:'',text:''}));
    if (norm(body.text).length < 60 || /\bXXX\b/.test(body.text)) missing.push('vollständiger E-Mail-Entwurf ohne XXX');
    if (this.active.forward) {
      const assignee = await read('mainForm:persona-assignment-id');
      if (!/victor/i.test(assignee) || norm(assignee).toLowerCase() === this.cfg.forwardingQuery.toLowerCase()) missing.push('ausgewählte Person für Weiterleitung an Victor');
    }
    return {missing, selected, description, body, recipients:await this.actualRecipients()};
  }
  async showReview() {
    const state = this.active;
    await this.assertTicket(state.id);
    this.io.log(`\n========== REVIEW — Ticket ${state.id} ==========`);
    const read = id => this.field(`mainForm:${id}`).inputValue().catch(()=>'(nicht verfügbar)');
    this.io.log(`Member:         ${await read('member-value-id')}`);
    this.io.log(`Zuständigkeit:  ${await read('responsibility-value-id')}`);
    this.io.log(`Kategorie:      ${await read('category-value-id')}`);
    this.io.log(`Unterkategorie: ${await read('category-sub-value-id')}`);
    this.io.log(`Signatur:       ${await read('signature-value-id')}`);
    const recipients = await this.actualRecipients();
    this.io.log(`Empfänger:      ${recipients.join('; ') || '(Formularfeld nicht automatisch erkannt — im Browser prüfen)'}`);
    this.io.log(`Absender im Nachrichtenverlauf: ${(await this.senders()).join('; ') || '(nicht erkannt)'}`);
    this.io.log(`Beschreibung:\n${await this.readDescription()}`);
    if (state.forward) this.io.log(`Nach dem Versand weiterleiten an: ${await read('persona-assignment-id')}`);
    this.io.log(`\nAntwortentwurf (im Browser bearbeitbar):\n${(await this.editorSnapshot().catch(()=>({text:'(Editor fehlt)'}))).text}\n`);
    this.io.log('ENTER / OK = geprüfte Antwort senden; R = Vorbereitung erneut versuchen; W = auslassen; STOP = beenden.');
    this.io.log('Anrede ändern: HERR Nachname oder FRAU Nachname (z.B. HERR Mustermann).');
  }
  async review(row) {
    for (;;) {
      await this.showReview();
      const command = await this.io.ask('Review > ');
      if (/^(stop|ende|q)$/i.test(command)) return 'stop';
      if (/^(w|weiter|skip)$/i.test(command)) { this.skipped.add(row.ticketId); return 'skip'; }
      if (/^r$/i.test(command)) { this.reloadMapping(); await this.prepare(row); continue; }
      try { if (await this.greetingChange(command)) continue; }
      catch (error) { this.io.log(error.message); continue; }
      if (command !== '' && !/^ok$/i.test(command)) { this.io.log('Bitte ENTER, OK, R, W, STOP oder HERR/FRAU Nachname eingeben.'); continue; }
      // Nach Review ausschließlich aktuellen Browserinhalt verwenden.
      const check = await this.validation();
      if (check.missing.length) { this.io.log(`Noch zu korrigieren:\n- ${check.missing.join('\n- ')}\nIm Browser korrigieren oder R/W wählen. Das Programm bleibt geöffnet.`); continue; }
      return await this.sendReviewed(check);
    }
  }
  async acknowledgeDialogs(gate) {
    if (gate.count >= this.cfg.maxOkDialogs) return false;
    const dialogs = this.page.locator('.icePnlPop:visible, [role="dialog"]:visible, .ui-dialog:visible');
    for (let i=0; i<await dialogs.count(); i++) {
      const dialog = dialogs.nth(i);
      const ok = dialog.getByRole('button', {name:/^OK$/i}).filter({visible:true});
      if (await ok.count() !== 1) continue;
      const message = await dialog.innerText();
      gate.messages.push(message);
      gate.count++;
      this.io.log(`[OK ${gate.count}] ${norm(message)}`);
      await ok.click();
      await this.settle(250);
      return true;
    }
    return false;
  }
  async visibleFeedback() {
    return this.page.locator('.iceMsgs:visible, .iceMsg:visible, [role="alert"]:visible, .icePnlPop:visible, .ui-dialog:visible')
      .allTextContents().then(parts=>parts.join('\n'));
  }
  newOutgoing(before, after, recipients, body) {
    const counts = new Map();
    const key = row => JSON.stringify(row);
    for (const row of before) counts.set(key(row), (counts.get(key(row)) || 0)+1);
    const prefix = norm(body).slice(0,70).toLowerCase();
    for (const row of after) {
      const k = key(row), count = counts.get(k) || 0;
      if (count) { counts.set(k,count-1); continue; }
      const targets = emails(row.to);
      const expected = recipients.length && recipients.every(target=>targets.includes(target));
      const excerpt = norm(row.body).toLowerCase();
      const matchesBody = prefix.length >= 24 && (excerpt.includes(prefix) || (excerpt.length>=24 && prefix.startsWith(excerpt.replace(/\.{3}$/,''))));
      if (expected && matchesBody) return true;
    }
    return false;
  }
  async sendReviewed(check) {
    const id = this.active.id;
    await this.assertTicket(id);
    if (this.journal.blocks(id)) throw new Error('Für dieses Ticket wurde bereits ein Versandversuch gespeichert. STATUS prüfen.');
    const before = await this.historyRows();
    const beforeFeedback = await this.visibleFeedback();
    const targets = check.recipients.length ? check.recipients : await this.senders();
    const send = await this.unique(this.field('mainForm:send-new-message-button'), 'Senden');
    if (!await send.isEnabled()) throw new Error('Senden ist noch deaktiviert.');
    await send.scrollIntoViewIfNeeded();
    // Ab hier keine automatische Wiederholung des Versandklicks, auch nicht bei Timeout.
    this.journal.set(id, 'sending', {markerVerified:false, forwardNeeded:this.active.forward});
    const gate = {until:Date.now()+this.cfg.sendTimeout+this.cfg.actionTimeout, count:0, messages:[]};
    this.dialogWindow = gate;
    let sent = false, sendError = '';
    try {
      await send.click();
      const end = Date.now()+this.cfg.sendTimeout;
      let refreshed = false;
      while (Date.now()<end) {
        await this.acknowledgeDialogs(gate);
        const feedback = await this.visibleFeedback();
        const newFeedback = feedback !== beforeFeedback ? feedback : '';
        const allMessages = gate.messages.join('\n')+'\n'+newFeedback;
        if (ERROR_TEXT.test(allMessages)) throw new Error(norm(allMessages));
        if (SEND_SUCCESS.test(allMessages) || this.newOutgoing(before, await this.historyRows(), targets, check.body.text)) {
          sent = true;
          // Ein zweites OK kann erst nach dem Erfolgsnachweis erscheinen.
          const drainUntil=Date.now()+1600;
          while (Date.now()<drainUntil && gate.count<this.cfg.maxOkDialogs) {
            await this.acknowledgeDialogs(gate);
            await sleep(150);
          }
          break;
        }
        if (!refreshed && end-Date.now()<this.cfg.sendTimeout-2500) {
          refreshed = true;
          const refresh = this.historySection().locator('input[type="image"][src*="arrow_refresh_small"]');
          if (await refresh.count()===1 && await refresh.isVisible() && await refresh.isEnabled()) await refresh.click();
        }
        await sleep(250);
      }
    } catch (error) { sendError = error.message.split('\n')[0]; }
    finally { this.dialogWindow = null; }
    if (!sent) {
      this.journal.set(id, 'uncertain', {reason:sendError || 'Kein eindeutiger Versandnachweis'});
      this.io.log(`\nTicket ${id}: Versandstatus unklar${sendError ? ` (${sendError})` : ''}. Kein zweiter automatischer Versand.`);
      this.io.log('Im Nachrichtenverlauf prüfen. BESTÄTIGT = Versand selbst gesehen; OFFEN = später klären; STOP = beenden.');
      const resolution = await this.io.ask('Versandstatus > ');
      if (/^bestätigt$|^bestaetigt$/i.test(resolution)) sent = true;
      else return /^(stop|ende)$/i.test(resolution) ? 'stop' : 'uncertain';
    }
    this.journal.set(id, 'sent', {reason:'', forwardNeeded:this.active.forward});
    await this.finishSent(id);
    this.io.log(`\nTicket ${id}: Versand bestätigt.\n`);
    return 'sent';
  }
  async finishSent(id) {
    await this.assertTicket(id);
    const core = Mapping.buildDescription(this.active.mappingResult, this.cfg.descriptionPrefix);
    const marked = await this.step('geantwortet nach Versand eintragen', async () => {
      await this.ensureEditable();
      await this.setDescription(descriptionWith(await this.readDescription(), core, true));
      return true;
    });
    if (!marked) this.io.log('  Beschreibung nicht bestätigt. Lokaler Versandstatus verhindert eine zweite Antwort.');
    if (this.active.forward) {
      const prepared = await this.step('Victor-Auswahl für Weiterleitung prüfen', async () => {
        const value = await this.field('mainForm:persona-assignment-id').inputValue();
        if (!/victor/i.test(value) || norm(value).toLowerCase()==='victor') throw new Error('Keine bestätigte Victor-Auswahl.');
        return value;
      });
      if (prepared) await this.forwardOnce(id, prepared);
      else this.io.log('  Weiterleitung offen. Antwort ist bereits gesendet; nicht nochmals senden.');
    }
    // Die in der Listenansicht geladene Beschreibung prüft auch die Speicherung.
    try {
      let verified = false;
      for (const menu of [this.cfg.queue, 'In_Bearbeitung']) {
        const table = await this.navigate(menu);
        const row = (await this.tableRows(table)).rows.find(row=>row.ticketId===id);
        if (row && answered(row.description)) { verified = true; break; }
      }
      const entry = this.journal.get(id);
      this.journal.set(id, entry.status, {markerVerified:verified});
      if (!verified) this.io.log('  geantwortet konnte in der Liste nicht nachgeprüft werden (z.B. Ticket weitergeleitet). Versandstatus ist lokal gespeichert.');
    } catch (error) { this.io.log(`  Listenprüfung später nötig: ${error.message.split('\n')[0]}`); }
  }
  async forwardOnce(id, assignee) {
    await this.assertTicket(id);
    this.journal.set(id, 'forwarding', {sent:true, assignee, forwardNeeded:true});
    const gate = {until:Date.now()+this.cfg.actionTimeout+6000,count:0,messages:[]};
    this.dialogWindow = gate;
    try {
      await this.field('mainForm:current-performer-assign-link').click();
      await this.settle();
      for (let n=0;n<2;n++) if (!await this.acknowledgeDialogs(gate)) await sleep(350);
      if (gate.messages.some(s=>ERROR_TEXT.test(s))) throw new Error('Oberfläche meldet Fehler bei Weiterleitung.');
      const performer = await this.labelValue('Bearbeiter:');
      const feedback = (await this.visibleFeedback()) + gate.messages.join(' ');
      if (norm(performer).toLowerCase() !== norm(assignee).toLowerCase() && !/erfolgreich.{0,40}weitergeleitet|wurde.{0,40}weitergeleitet/i.test(feedback)) {
        this.journal.set(id, 'forward_uncertain', {sent:true,forwardNeeded:true});
        this.io.log('  Weiterleitung angeklickt; Ergebnis bitte im Browser prüfen. Kein automatischer zweiter Klick.');
      } else {
        this.journal.set(id, 'forwarded', {sent:true,forwardNeeded:false});
        this.io.log(`  Weiterleitung an ${assignee} bestätigt.`);
      }
    } catch (error) {
      this.journal.set(id, 'forward_uncertain', {sent:true,forwardNeeded:true});
      this.io.log(`  Weiterleitung unklar: ${error.message.split('\n')[0]}. Antwort wurde bereits gesendet.`);
    } finally { this.dialogWindow = null; }
  }
}

async function getPlaywright(io) {
  const names = ['playwright-core','playwright'];
  const load = () => {
    for (const name of names) for (const target of [path.join(__dirname,'node_modules',name),name,path.join(CONFIG.moduleDirectory,name)]) {
      try {
        const resolved=require.resolve(target);
        const manifest=JSON.parse(fs.readFileSync(path.join(path.dirname(resolved),'package.json'),'utf8'));
        const [major,minor]=manifest.version.split('.').map(Number);
        if (major===1 && minor<51) continue;
        return require(target);
      } catch (error) { if (!['MODULE_NOT_FOUND','ENOENT'].includes(error.code)) throw error; }
    }
    return null;
  };
  let pw = load();
  if (pw) return pw;
  const nodeDir = path.dirname(process.execPath);
  const npmPaths = [path.join(nodeDir,'node_modules/npm/bin/npm-cli.js'),path.join(CONFIG.moduleDirectory,'npm/bin/npm-cli.js'),path.join(__dirname,'node_modules/npm/bin/npm-cli.js')];
  try { npmPaths.push(path.join(path.dirname(require.resolve('npm/package.json')),'bin/npm-cli.js')); } catch {}
  const npmCli = npmPaths.find(file=>fs.existsSync(file));
  if (!npmCli) throw new Error('Playwright und npm wurden nicht gefunden. Einmal mit einer Node-Installation mit npm in diesem Ordner ausführen: npm install playwright-core@'+CONFIG.playwrightVersion);
  io.log(`Browsersteuerung wird einmalig lokal installiert: playwright-core@${CONFIG.playwrightVersion}`);
  const code = await new Promise((resolve,reject) => {
    const child = spawn(process.execPath,[npmCli,'install','--prefix',__dirname,'--no-save','--no-package-lock','--ignore-scripts','--no-audit','--no-fund',`playwright-core@${CONFIG.playwrightVersion}`], {stdio:'inherit', shell:false});
    child.on('error',reject); child.on('close',resolve);
  });
  if (code!==0 || !(pw=load())) throw new Error('Playwright konnte nicht installiert werden. Paketinstallation/Netzwerk prüfen und erneut starten.');
  return pw;
}
async function launchBrowser(pw, io) {
  const attempts = CONFIG.browserExe ? [{executablePath:CONFIG.browserExe}] : [{channel:CONFIG.browserChannel},{channel:'chrome'},{}];
  let last;
  for (const options of attempts) {
    try {
      const browser = await pw.chromium.launch({...options,headless:false,args:['--start-maximized']});
      const context = await browser.newContext({viewport:null});
      return {browser,context,page:await context.newPage()};
    } catch (error) { last = error; }
  }
  throw new Error('Edge/Chrome konnte nicht gestartet werden. COMARCH_BROWSER_EXE auf die Browser-EXE setzen. '+last.message.split('\n')[0]);
}
async function main() {
  const io = new Terminal();
  let browser;
  const lock = path.join(__dirname,'comarch.lock');
  let ownsLock = false;
  try {
    if (Number(process.versions.node.split('.')[0])<20) throw new Error('Bitte Node.js 20 oder neuer verwenden.');
    try { fs.writeFileSync(lock,String(process.pid),{flag:'wx'}); ownsLock = true; }
    catch (error) {
      if (error.code!=='EEXIST') throw error;
      const pid = Number(fs.readFileSync(lock,'utf8'));
      let running = true;
      if (Number.isInteger(pid) && pid>0) { try { process.kill(pid,0); } catch (e) { if (e.code==='ESRCH') running=false; } }
      if (running) throw new Error('Es läuft bereits eine Instanz, oder comarch.lock muss nach einem Absturz manuell geprüft werden.');
      fs.unlinkSync(lock); fs.writeFileSync(lock,String(process.pid),{flag:'wx'}); ownsLock=true;
    }
    const journal = new Journal(CONFIG.stateFile);
    const pw = await getPlaywright(io);
    const launched = await launchBrowser(pw,io); browser=launched.browser;
    let page=launched.page;
    try { await page.goto(CONFIG.url,{waitUntil:'domcontentloaded',timeout:45000}); }
    catch (error) { io.log(`Seite noch nicht geladen: ${error.message.split('\n')[0]}. URL im geöffneten Browser korrigieren und dort anmelden.`); }
    io.log('\nCOMARCH geöffnet. Bitte im Browser anmelden. Anschließend hier START eingeben.');
    io.log('STATUS zeigt gemerkte Versandversuche. STOP beendet das Programm.');
    let bot = null;
    while (!io.closed) {
      const command = await io.ask('\nSTART / STATUS / STOP > ');
      if (/^(stop|ende|q)$/i.test(command)) break;
      if (/^status$/i.test(command)) {
        const entries = Object.entries(journal.data.tickets);
        io.log(entries.length ? entries.map(([id,r])=>`${id}: ${r.status}; geantwortet geprüft: ${!!r.markerVerified}${r.forwardNeeded?'; Weiterleitung offen':''}`).join('\n') : 'Noch keine Versandversuche gespeichert.');
        io.log('Nur nach eigener Prüfung: FREIGEBEN Ticket-ID entfernt einen Eintrag und ermöglicht erneuten Versand.');
        continue;
      }
      const release = command.match(/^FREIGEBEN\s+(\d+)$/i);
      if (release) {
        const answer = await io.ask(`Nur wenn Ticket ${release[1]} wirklich NICHT gesendet wurde: NICHT GESENDET eingeben > `);
        if (/^NICHT GESENDET$/i.test(answer)) { journal.remove(release[1]); io.log('Lokaler Eintrag entfernt. Ein vorhandenes geantwortet in COMARCH bleibt wirksam.'); }
        continue;
      }
      if (!/^start$/i.test(command)) continue;
      const appPages = [];
      for (const candidate of launched.context.pages()) if (!candidate.isClosed() && new URL(candidate.url()).hostname===new URL(CONFIG.url).hostname && await candidate.locator('span.ellipsisText.flexColumn').filter({hasText:/^In_Bearbeitung$/}).count()) appPages.push(candidate);
      if (appPages.length!==1) { io.log('COMARCH-Menü nicht eindeutig sichtbar. Anmeldung abschließen / richtige Ansicht öffnen, dann START.'); continue; }
      page=appPages[0];
      if (!bot || bot.page!==page) bot = new ComarchBot(page,{io,journal});
      bot.skipped.clear(); bot.reloadMapping();
      if (bot.mappingError) io.log(`Mapping-Hinweis: ${bot.mappingError}. Andere Formularschritte werden vorbereitet; bei Dateifehlern keine automatische Weiterleitung.`);
      let first=true, stop=false;
      while (!io.closed) {
        let row;
        try { row=await bot.nextTicket(first); first=false; }
        catch (error) { io.log(`Listenansicht noch nicht bereit: ${error.message.split('\n')[0]}. Im Browser korrigieren, dann erneut START.`); break; }
        if (!row) { io.log('Keine unbearbeiteten Tickets gefunden. Markierte, gesendete oder für diesen Lauf ausgelassene Tickets werden übersprungen.'); break; }
        io.log(`\n--- Ticket ${row.ticketId} ---`);
        try {
          await bot.openTicket(row);
          if (!await bot.prepare(row)) continue;
          const outcome=await bot.review(row);
          if (outcome==='stop') { stop=true; break; }
        } catch (error) {
          bot.skipped.add(row.ticketId);
          io.log(`Ticket ${row.ticketId} für diesen Lauf ausgelassen: ${error.message.split('\n')[0]}`);
          if (page.isClosed()) { stop=true; break; }
        }
      }
      if (stop) break;
    }
  } catch (error) {
    io.log(`\nStartproblem: ${error.message}`);
    await io.ask('Fenster bleibt zur Prüfung offen. ENTER zum Beenden > ');
    process.exitCode=1;
  } finally {
    if (browser) await browser.close().catch(()=>{});
    if (ownsLock) try { fs.unlinkSync(lock); } catch {}
    io.close();
  }
}

if (require.main===module) main().catch(error=>{ console.error(error); process.exitCode=1; });
module.exports = {CONFIG,Mapping,ComarchBot,Journal,Terminal,answered,descriptionWith,memberParts,replyText,replyHtml};
