import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';
import {ROOT} from './helpers.mjs';
import {sha256} from '../lib/core.mjs';
import {VERSION} from '../lib/control.mjs';
import {verifyPackage,verifyPrevious} from '../tools/integrity.mjs';
test('RC62 seals original RC61, changes only pre-send repair and release tooling',{timeout:20000},()=>{
 assert.equal(VERSION,'0.8.1-rc.62');
 assert.equal(verifyPackage(ROOT).version,VERSION);
 assert.equal(verifyPrevious(ROOT).version,VERSION);
 const f=path.join(ROOT,'tools/reference/complete-0.8.1-rc.61-manifest.json');
 assert.equal(sha256(fs.readFileSync(f)),'4e5e272933e57225922884b75ba4f10076a5d51f4ccf2d571f1359f76f6083f6');
 const original=JSON.parse(fs.readFileSync(f));assert.equal(original.version,'0.8.1-rc.61');
 const allowed=new Set(['src/local-bot-full-run.mjs','lib/demo.mjs','lib/control.mjs','tools/cli.mjs','tools/integrity.mjs']);
 for(const entry of original.payload.filter(x=>/^(src|lib|tools)\//.test(x.path)))if(!allowed.has(entry.path))
  assert.equal(sha256(fs.readFileSync(path.join(ROOT,entry.path))),entry.sha256,'RC61 module unexpectedly changed: '+entry.path);
 const runner=fs.readFileSync(path.join(ROOT,'src/local-bot-full-run.mjs'),'utf8');
 assert(runner.includes('ensurePreSendDescription'));
 assert(runner.includes('PRESEND_DESCRIPTION_CHANGED_AT_CLICK'));
 assert(runner.includes('if(!DEMO){await overlay.commitAuthorization(approval);journal.begin(id,savedDescription);}') );
 // Phase-2 routing, PDFs, MBC, signatures, master orchestration untouched.
 for(const f of ['src/phase2-work-handler.mjs','lib/phase2-comarch-actions.mjs','lib/phase2-filepond.mjs','lib/phase2-review-flow.mjs']){
  const entry=original.payload.find(x=>x.path===f);assert(entry);
  assert.equal(sha256(fs.readFileSync(path.join(ROOT,f))),entry.sha256,f);
 }
});
