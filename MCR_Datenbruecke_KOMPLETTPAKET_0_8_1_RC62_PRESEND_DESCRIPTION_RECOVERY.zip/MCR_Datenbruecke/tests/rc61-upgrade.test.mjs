import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';
import {ROOT,temp,putActive,historyFixture} from './helpers.mjs';
import {sha256} from '../lib/core.mjs';import {readZip} from '../lib/zip.mjs';
import {VERSION,writeJSON,ledger} from '../lib/control.mjs';
import {verifyPrevious,verifyPackage,treeDigest} from '../tools/integrity.mjs';
import {planInstall,installSoftware,journals,restoreSoftware} from '../tools/deploy.mjs';
import {beginMigrationPriority} from '../lib/migration-priority.mjs';
import {createHash} from 'node:crypto';

test('RC61 original RC60 ZIP update + rollback preserve interrupted real pilot, other pending actions, profile, mapping',{timeout:120000},()=>{
 const zip=historyFixture('complete-0.8.1-rc.60.zip');
 const originalSha=sha256(zip);
 assert.match(originalSha,/^[a-f0-9]{64}$/);
 const parent=temp(),target=path.join(parent,'MCR_Datenbruecke');fs.mkdirSync(target);
 try{
  const files=readZip(zip);for(const name of files.names){if(name.endsWith('/'))continue;
   assert(name.startsWith('MCR_Datenbruecke/'));const f=path.join(target,name.slice('MCR_Datenbruecke/'.length));
   fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,files.get(name));}
  putActive(target);
  const sent=path.join(target,'.runtime/beta-control/ticket-ledger.json');
  ledger(target).begin('88149870','USC old\nStandardantwort versendet');
  ledger(target).begin('88296387','USC new\nStandardantwort versendet');
  const report=path.join(target,'.runtime/beta-control/last-run.json');writeJSON(report,{schema:'MCR_BETA_RUN_V1',operation:'REAL_RUN',pilot:true,state:'INTERRUPTED_REVIEW_REQUIRED',startedAt:'2026-11-05T10:14:13Z',runId:'pilot-aborted'});
  const profile=path.join(target,'.runtime/edge-profile');fs.mkdirSync(profile,{recursive:true});fs.writeFileSync(path.join(profile,'sentinel'),'PROFILE_UNCHANGED');
  const dir=path.join(target,'.runtime/phase2/actions');fs.mkdirSync(dir,{recursive:true});writeJSON(path.join(dir,'existing-work.json'),{kind:'MBC',state:'ROUTED_VERIFIED'});
  const hashes=Object.fromEntries(['private_data','config','.runtime/edge-profile','.runtime/phase2'].map(n=>[n,treeDigest(path.join(target,n))]));
  const originalLedger=fs.readFileSync(sent),originalLastRun=fs.readFileSync(report);
  assert.equal(verifyPrevious(target).version,'0.8.1-rc.60');
  const stopped=()=>({schema:'MCR_PROCESS_GUARD_V1',checked:true,blockedCount:0,unknownCount:0,inspectedPids:[process.pid],inspectedProcesses:[{pid:process.pid,relation:'PROTECTED'}],stoppedProcesses:[]});
  const migration=beginMigrationPriority(planInstall(ROOT,target),{stop:stopped});let result;
  try{result=installSoftware(planInstall(ROOT,target,{migration}),{migration});}finally{migration.release();}
  assert.equal(result.state,'COMPLETE');assert.equal(verifyPackage(target).version,VERSION);
  for(const [name,hash] of Object.entries(hashes))assert.equal(treeDigest(path.join(target,name)),hash,name);
  assert.deepEqual(fs.readFileSync(sent),originalLedger);assert.deepEqual(fs.readFileSync(report),originalLastRun);
  assert.deepEqual(ledger(target).pending.map(x=>x.ticketId).sort(),['88149870','88296387']);
  assert.equal(restoreSoftware(journals(target)[0]).state,'ROLLED_BACK');assert.equal(verifyPrevious(target).version,'0.8.1-rc.60');
  for(const [name,hash] of Object.entries(hashes))assert.equal(treeDigest(path.join(target,name)),hash,name+' rollback');
  assert.deepEqual(fs.readFileSync(sent),originalLedger);assert.deepEqual(fs.readFileSync(report),originalLastRun);
 }finally{fs.rmSync(parent,{recursive:true,force:true,maxRetries:6,retryDelay:100});}
});
