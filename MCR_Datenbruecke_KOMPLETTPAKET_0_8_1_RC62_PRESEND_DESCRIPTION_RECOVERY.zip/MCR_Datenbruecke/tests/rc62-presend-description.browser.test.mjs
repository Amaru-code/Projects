import test from 'node:test';import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';import fs from 'node:fs';
import path from 'node:path';import {fileURLToPath} from 'node:url';
import {readZip} from '../lib/zip.mjs';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
function runDemo(scenario){return spawnSync(process.execPath,[path.join(ROOT,'src/local-bot-full-run.mjs'),'--demo','--auto','--headless','--close-browser'],{
 cwd:ROOT,env:{...process.env,MCR_DEMO_SCENARIO:scenario,MCR_DEMO_TICKET_LIMIT:'1',MCR_RUN_ID:scenario+'-run'},
 encoding:'utf8',timeout:100000,maxBuffer:4*1024*1024});}
test('RC62 Chromium: ICEfaces-like pre-send reset -> one send, marker, one save, next-step proof',{timeout:110000,skip:process.env.MCR_RC62_CHROMIUM_QA!=='1'?'Optional, previously executed as standalone Chromium demo':false},()=>{
 const r=runDemo('rc62-presend-blank');assert.equal(r.status,0,(r.stdout||'').slice(-3200)+'\n'+r.stderr);
 assert.match(r.stdout,/PASS PRESEND_DESCRIPTION_RESTORED/);
 assert.match(r.stdout,/PASS POST_SEND_STATUS_CONFIRMED/);
 assert.match(r.stdout,/Ticket speichern PASS/);
 assert.match(r.stdout,/RUN COMPLETE \| Bearbeitet: 1/);
});
test('RC62 Chromium: foreign note blocks before send; diagnostic proves no send/save click',{timeout:110000,skip:process.env.MCR_RC62_CHROMIUM_QA!=='1'?'Optional, previously executed as standalone Chromium demo':false},()=>{
 const r=runDemo('rc62-presend-conflict');assert.equal(r.status,1,(r.stdout||'').slice(-1500));
 assert.match(r.stdout,/STOP PRESEND_DESCRIPTION_CONFLICT/);
 const diag=(r.stdout||'').match(/Diagnose: (.*\.zip)/)?.[1];assert(diag&&fs.existsSync(diag));
 const z=readZip(fs.readFileSync(diag)),d=JSON.parse(z.get('diagnostic.json').toString('utf8'));
 assert.equal(d.send.clicked,false);assert.equal(d.save.clicked,false);
});
