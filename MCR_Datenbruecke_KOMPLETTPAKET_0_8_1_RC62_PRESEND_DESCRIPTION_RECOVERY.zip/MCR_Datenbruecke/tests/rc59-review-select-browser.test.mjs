import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {temp,mapping} from './helpers.mjs';
import {withPhase2Browser,installPhase2Fixture} from './rc52-browser-fixture.mjs';
import {selectReviewMode,phase2FieldSnapshot} from '../lib/phase2-comarch-actions.mjs';
import {handlePhase2Work} from '../src/phase2-work-handler.mjs';
import {phase2WorkJournal} from '../lib/phase2-work-journal.mjs';
import {markedPhase2Description,privateMbcDraft,PRIVATE_MBC_REQUEST} from '../lib/phase2-work-rules.mjs';
import {MBC_SIGNATURE_VALUE} from '../lib/phase2-mbc-signature.mjs';
const id='87160524',original='USC 100/ DC\nStandardantwort versendet\n'+PRIVATE_MBC_REQUEST;
const after=markedPhase2Description(original),draft=privateMbcDraft({lastName:'Mustermann',gender:'M'});
const member=async()=>({profileVerified:true,profile:{first:'Max',last:'Mustermann',mercerId:'99900001'}});
const noAsk=async prompt=>{throw Error('Unexpected operator prompt: '+prompt);};
function reviewReady(root){const j=phase2WorkJournal(root,id);
 j.begin({rule:'MBC_PRIVATE_EMAIL',descriptionBefore:original,descriptionAfter:after,draft,memberId:'99900001'});
 for(const state of ['EDIT_INTENT','DRAFT_SAVE_INTENT','DRAFT_SAVE_VERIFIED','EDIT_VERIFIED','TICKET_SAVE_INTENT','TICKET_SAVE_VERIFIED','REVIEW_INTENT','REVIEW_VERIFIED'])j.advance(state);
 return j;
}
async function overlayReview(page,{full=false}={}){
 await page.call(({full})=>{
  const f=[...document.querySelectorAll('select')].find(s=>[...s.options].some(o=>o.value==='FORWARD_TO_REVIEW'));
  if(!f)throw new Error('Fixture has no review select');
  const r=f.getBoundingClientRect(),e=document.createElement('div');e.id='review-blocker';
  Object.assign(e.style,{position:'fixed',background:'rgba(200,0,0,.85)',zIndex:'9999',pointerEvents:'auto',
   left:(r.left+(full?0:r.width*.35))+'px',top:(r.top+(full?0:r.height*.28))+'px',
   width:(r.width*(full?1:.3))+'px',height:(r.height*(full?1:.44))+'px'});
  document.body.appendChild(e);
 },{full});
}
async function openFixture(page){await installPhase2Fixture(page,[{ticketId:id,description:after,gevo:'Anfrage Member',draft,signature:MBC_SIGNATURE_VALUE}],{requireMbcSignature:true});
 await page.call(i=>showDetail(i),id);}

test('RC59 real Chromium: review SELECT center occluded, side still safe; native trusted click selects FORWARD_TO_REVIEW without fallback or route click',{timeout:30000},()=>withPhase2Browser(async page=>{
 await openFixture(page);await overlayReview(page);
 const logs=[];const r=await selectReviewMode(page,{log:s=>logs.push(s),manualFocus:()=>{throw Error('should not request manual focus');}});
 assert(r.ok);assert.equal(r.method,'PASSIVE_REPOSITION_HIT_TEST');
 assert((await phase2FieldSnapshot(page)).reviewValue==='FORWARD_TO_REVIEW');
 assert(logs.some(s=>s.includes('P2_REVIEW_SELECT_TRUSTED_FOCUS')));
 assert.deepEqual(await page.eval('_counts'),{open:0,save:0,draft:0,review:0,direct:0,send:0,upload:0});
}));

test('RC59 real Chromium: totally covered SELECT with no manual fallback stops before any keys/actions',{timeout:30000},()=>withPhase2Browser(async page=>{
 await openFixture(page);await overlayReview(page,{full:true});
 await assert.rejects(()=>selectReviewMode(page),e=>e.code==='REVIEW_DROPDOWN_OCCLUDED');
 assert.equal((await phase2FieldSnapshot(page)).reviewValue,'');
 assert.equal(await page.eval('_counts.review+_counts.send+_counts.save+_counts.draft'),0);
}));

test('RC59 real Chromium: covered SELECT can be physically focused by operator and then native keyboard selects exactly once',{timeout:32000},()=>withPhase2Browser(async page=>{
 await openFixture(page);await overlayReview(page,{full:true});let gates=0;
 const logs=[];const r=await selectReviewMode(page,{log:s=>logs.push(s),manualFocus:async()=>{
  gates++;const loc=await page.call(()=>{document.getElementById('review-blocker').remove();
   const s=document.getElementById('mainForm:j_id7870'),r=s.getBoundingClientRect();return {x:r.left+r.width/2,y:r.top+r.height/2};});
  await page.mouseClick(loc.x,loc.y);
 }});
 assert.equal(gates,1);assert.equal(r.method,'OPERATOR_PHYSICAL_FOCUS');
 assert.equal((await phase2FieldSnapshot(page)).reviewValue,'FORWARD_TO_REVIEW');
 assert(logs.some(s=>s.includes('PASS P2_REVIEW_SELECT_OPERATOR_FOCUS')));
 assert.equal(await page.eval('_counts.review+_counts.send+_counts.save'),0);
}));

test('RC59 real Chromium: manual callback cannot make unrelated input a selection authorization',{timeout:30000},()=>withPhase2Browser(async page=>{
 await openFixture(page);await overlayReview(page,{full:true});
 await assert.rejects(()=>selectReviewMode(page,{manualFocus:async()=>{
  await page.call(()=>{document.getElementById('review-blocker').remove();
   const old=document.getElementById('mainForm:j_id7870');old.style.display='none';
   document.getElementById('mainForm:persona-assignment-id').focus();});
 }}),e=>e.code==='REVIEW_DROPDOWN_CHANGED');
 assert.equal((await phase2FieldSnapshot(page)).reviewCount,0);
 assert.equal(await page.eval('_counts.review+_counts.send+_counts.save'),0);
}));

test('RC59 real Chromium: duplicate visible REVIEW dropdown blocks before focus or routing',{timeout:30000},()=>withPhase2Browser(async page=>{
 await openFixture(page);await page.call(()=>{const n=document.getElementById('mainForm:j_id7870').cloneNode(true);n.id='other-select';document.body.appendChild(n);});
 let calls=0;await assert.rejects(()=>selectReviewMode(page,{manualFocus:async()=>calls++}),e=>e.code==='REVIEW_DROPDOWN_NOT_UNIQUE');
 assert.equal(calls,0);assert.equal(await page.eval('_counts.review'),0);
}));

test('RC59 complete RC58 MBC REVIEW_VERIFIED continuation: signature intact, centered dropdown overlaid, exactly one Mark route, no resave or mail',{timeout:65000},()=>withPhase2Browser(async page=>{
 const root=temp();try{
  const j=reviewReady(root),prior=j.read().events;
  await installPhase2Fixture(page,[{ticketId:id,description:after,gevo:'Anfrage Member',draft,signature:MBC_SIGNATURE_VALUE}],{requireMbcSignature:true});
  await page.call(()=>{const old=window.showDetail;window.showDetail=(ticket)=>{old(ticket);
   const f=document.getElementById('mainForm:j_id7870'),r=f.getBoundingClientRect();const e=document.createElement('div');e.className='review-center-veil';
   Object.assign(e.style,{position:'fixed',zIndex:'99999',background:'#b20',pointerEvents:'auto',
    left:(r.left+r.width*.35)+'px',top:(r.top+r.height*.28)+'px',width:r.width*.3+'px',height:r.height*.44+'px'});
   document.body.appendChild(e);
  };});
  const logs=[];
  const result=await handlePhase2Work({root,page,row:{ticketId:id,descriptionValue:after},mapping:mapping(),memberLookup:member,ask:noAsk,log:s=>logs.push(s)});
  assert.equal(result.status,'ROUTED_VERIFIED');assert.equal(j.read().state,'ROUTED_VERIFIED');
  assert.deepEqual(j.read().events.slice(0,prior.length),prior);
  assert.equal(await page.eval('_counts.review'),1);assert.equal(await page.eval('_counts.draft+_counts.save+_counts.send+_counts.upload'),0);
  assert.equal((await page.eval('_routeInfo'))[0].field,'mainForm:next-persona-assignment-id');
  assert(logs.some(s=>s.includes('PASS P2_REVIEW_SELECT_TRUSTED_FOCUS')));
 }finally{fs.rmSync(root,{recursive:true,force:true,maxRetries:5,retryDelay:50});}
}));

test('RC59 repeated call after a verified route does not open the finished ticket for a second execute',{timeout:65000},()=>withPhase2Browser(async page=>{
 const root=temp();try{
  reviewReady(root);await installPhase2Fixture(page,[{ticketId:id,description:after,gevo:'Anfrage Member',draft,signature:MBC_SIGNATURE_VALUE}],{requireMbcSignature:true});
  const run=()=>handlePhase2Work({root,page,row:{ticketId:id,descriptionValue:after},mapping:mapping(),memberLookup:member,ask:noAsk,log:()=>{}});
  assert.equal((await run()).status,'ROUTED_VERIFIED');
  await assert.rejects(run);
  assert.equal(await page.eval('_counts.review'),1);assert.equal(await page.eval('_counts.send'),0);
 }finally{fs.rmSync(root,{recursive:true,force:true,maxRetries:5,retryDelay:50});}
}));
