import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';
import {ROOT} from './helpers.mjs';import {VERSION} from '../lib/control.mjs';import {sha256} from '../lib/core.mjs';import {verifyPackage} from '../tools/integrity.mjs';
test('RC57 pins exact RC56 published package and preserves PDF, existing Mark routing, MBC editor, Phase1, migration and installer bytes',()=>{
 assert.equal(VERSION,'0.8.1-rc.60');const x=fs.readFileSync(path.join(ROOT,'tools/reference/complete-0.8.1-rc.56-manifest.json'));
 assert.equal(sha256(x),'0f3c51803ef2f305e362a5725e4a5954199d8109826b966ebce99de42efdc93a');
 const old=JSON.parse(x);for(const name of ['lib/phase2-filepond.mjs','lib/phase2-assignee.mjs','lib/phase2-mbc-draft.mjs','src/phase2-run.mjs','src/local-bot-full-run.mjs','tools/deploy.mjs','lib/migration-priority.mjs','tools/phase2-ticket-window.ps1']){
  assert.equal(sha256(fs.readFileSync(path.join(ROOT,name))),old.payload.find(x=>x.path===name).sha256,name);
 }
 const prior58=JSON.parse(fs.readFileSync(path.join(ROOT,'tools/reference/complete-0.8.1-rc.58-manifest.json')));
 assert.equal(prior58.payload.find(x=>x.path==='lib/phase2-review-flow.mjs').sha256,
  old.payload.find(x=>x.path==='lib/phase2-review-flow.mjs').sha256,
  'published RC58 routing genuinely matches the historical baseline');
 assert.equal(verifyPackage(ROOT).version,VERSION);
});
test('RC57 only revisits RC56 pre-click focus failure after verified server readback and express operator permission',()=>{
 const s=fs.readFileSync(path.join(ROOT,'src/phase2-work-handler.mjs'),'utf8');
 assert(s.includes('SAVE_REPAIR_FOCUS_RETRY_AUTHORIZED'));assert(s.includes('tail.length===0'));
 assert(s.includes("'NICHT_GESPEICHERT_'+id"));assert(s.includes('manualFocus:async()=>'));
 const f=fs.readFileSync(path.join(ROOT,'lib/trusted-description.mjs'),'utf8');
 assert(f.includes('elementFromPoint(x,y)===n'));assert(f.includes('focus.focused'));
 assert(f.includes("'DESCRIPTION_FOCUS'"));assert(!f.includes('f.focus()'));
 assert(!/sendOnce\(|sendPhase2Mail\(|attachLocalFiles\(/.test(s));
});
