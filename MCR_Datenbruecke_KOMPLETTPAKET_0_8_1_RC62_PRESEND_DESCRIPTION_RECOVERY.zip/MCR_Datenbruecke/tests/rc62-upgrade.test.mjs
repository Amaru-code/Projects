import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';
import {ROOT,temp,putActive} from './helpers.mjs';
import {readZip} from '../lib/zip.mjs';
import {readJSON,ledger,writeJSON,VERSION} from '../lib/control.mjs';
import {verifyPackage,verifyPrevious,treeDigest} from '../tools/integrity.mjs';
import {planInstall,installSoftware,journals,restoreSoftware} from '../tools/deploy.mjs';
import {beginMigrationPriority} from '../lib/migration-priority.mjs';
const source=process.env.MCR_RC61_SOURCE_ZIP;
test('RC62 direct real RC61 ZIP update + rollback keeps all journals and profile unchanged',{
 timeout:120000,skip:!source||!fs.existsSync(source)?'Published RC61 ZIP optional external QA fixture not available':false
},()=>{
 const parent=temp(),target=path.join(parent,'MCR_Datenbruecke');fs.mkdirSync(target);
 try{
  const contents=readZip(fs.readFileSync(source));
  for(const n of contents.names){if(n.endsWith('/'))continue;assert(n.startsWith('MCR_Datenbruecke/'));
   const dest=path.join(target,n.slice('MCR_Datenbruecke/'.length));fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,contents.get(n));}
  assert.equal(verifyPrevious(target).version,'0.8.1-rc.61');
  putActive(target);ledger(target).begin('88296387','USC 10/ DC\nStandardantwort versendet');
  ledger(target).begin('88478801','USC 11/ PP+\nStandardantwort versendet');
  const report=path.join(target,'.runtime/beta-control/last-run.json');
  writeJSON(report,{schema:'MCR_BETA_RUN_V1',version:'0.8.1-rc.61',operation:'REAL_RUN',state:'STOP_REVIEW_REQUIRED',pilot:true,startedAt:'2026-11-06T10:10:33Z'});
  for(const folder of ['.runtime/edge-profile','.runtime/phase2'])fs.mkdirSync(path.join(target,folder),{recursive:true});
  fs.writeFileSync(path.join(target,'.runtime/edge-profile','sentinel'),'DO_NOT_CHANGE');
  fs.writeFileSync(path.join(target,'.runtime/phase2','sentinel'),'DO_NOT_CHANGE');
  const preserved=['private_data','config','.runtime/edge-profile','.runtime/phase2'];
  const before=Object.fromEntries(preserved.map(p=>[p,treeDigest(path.join(target,p))]));
  const ledgerBytes=fs.readFileSync(path.join(target,'.runtime/beta-control/ticket-ledger.json'));
  const lastRunBytes=fs.readFileSync(report);
  const stopped=()=>({schema:'MCR_PROCESS_GUARD_V1',checked:true,blockedCount:0,unknownCount:0,inspectedPids:[process.pid],inspectedProcesses:[{pid:process.pid,relation:'PROTECTED'}],stoppedProcesses:[]});
  const migration=beginMigrationPriority(planInstall(ROOT,target),{stop:stopped});let result;
  try{result=installSoftware(planInstall(ROOT,target,{migration}),{migration});}finally{migration.release();}
  assert.equal(result.state,'COMPLETE');assert.equal(verifyPackage(target).version,VERSION);
  for(const [p,h] of Object.entries(before))assert.equal(treeDigest(path.join(target,p)),h,p+' update');
  assert.deepEqual(fs.readFileSync(path.join(target,'.runtime/beta-control/ticket-ledger.json')),ledgerBytes);
  assert.deepEqual(fs.readFileSync(report),lastRunBytes);
  assert.deepEqual(ledger(target).pending.map(x=>x.ticketId).sort(),['88296387','88478801']);
  assert.equal(restoreSoftware(journals(target)[0]).state,'ROLLED_BACK');
  assert.equal(verifyPrevious(target).version,'0.8.1-rc.61');
  for(const [p,h] of Object.entries(before))assert.equal(treeDigest(path.join(target,p)),h,p+' rollback');
  assert.deepEqual(fs.readFileSync(path.join(target,'.runtime/beta-control/ticket-ledger.json')),ledgerBytes);
  assert.deepEqual(fs.readFileSync(report),lastRunBytes);
 }finally{fs.rmSync(parent,{recursive:true,force:true,maxRetries:6,retryDelay:150});}
});
