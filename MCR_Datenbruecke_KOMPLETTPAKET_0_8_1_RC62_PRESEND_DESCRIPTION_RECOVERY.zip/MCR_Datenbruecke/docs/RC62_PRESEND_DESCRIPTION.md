# RC62 – Vorversand-Feldprüfung und begrenzte ICEfaces-Wiederherstellung

**Reale Beobachtung:** Der Pilot `88503774` endete nach Personen- und
Pflichtfeldkontrolle bei `STOP DESCRIPTION_CHANGED [PHASE DESCRIPTION_AND_FIXED_FIELDS]`.
Das gepostete Terminalprotokoll zeigt keinen Sendeklick. Der genaue COMARCH-
Feldinhalt beim Abbruch ist ohne lokales Diagnosearchiv nicht belegbar.

## Begrenzte Korrektur

1. Die zusätzliche Beschreibung wird vor der ersten Bearbeitung eindeutig
   anhand der COMARCH-Sektion/Bezeichnung gebunden.
2. Nach Reply-Editor, Signatur, Pflichtfeldern und MANUELL/AUTO-Freigabe
   wird genau dieses Feld erneut gelesen.
3. Ist der alte Wert leer, das neue USC-Feld zuvor nachweislich eingesetzt
   worden und nur dieser Wert durch einen DOM-/ICEfaces-Reset geleert,
   kann exakt derselbe Text noch einmal vor dem Versand nativ gesetzt werden.
   Kein erneuter Versand, kein Speichern, kein Journal-Versandintent bei dieser Reparatur.
4. Fremde Werte, veränderte USC-/Pläne, mehrdeutige oder unlesbare Felder
   führen zu Stop ohne Überschreiben. Ein leerer Wert ohne vorausgegangenen
   bestätigten Schreibvorgang darf nicht repariert werden.
5. Danach erfolgt die vollständige bisherige Prüfung von gebundenem Ticket,
   Member, Empfänger, Zuständigkeit, Kategorie, Unterkategorie, Signatur,
   Antwort und Verlauf. Direkt am irreversiblen Sendeklick wird die
   zusätzliche Beschreibung **nochmals** gelesen; bei Abweichung Stop.
6. Nur nach tatsächlich bestätigtem Versand: Statuszeile, Speichern,
   erneutes Nachlesen, nächstes Ticket. Weiterleitung/Phase 2 bleiben unverändert.

## Grenzen

Die Browsertests verwenden Chromium mit fiktiver COMARCH-Oberfläche.
Die echte Ursache des RC61-Abbruchs kann eine Löschung, ein geänderter
Text oder ein nicht eindeutig lesbares Feld gewesen sein. RC62 behandelt
nur den nachweisbaren Blank-Reset automatisch. Reale Windows-/COMARCH-Abnahme
steht noch aus. Ältere `SEND_INTENT` nicht erneut versenden.
