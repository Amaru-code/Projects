# RC59 — COMARCH-Prüfschritt sicher fokussieren

## Ausgangslage

Der echte RC58-Lauf, Ticket 87160524, meldete
`PASS P2_WORK_SERVER_PERSISTENCE`, `PASS P2_MBC_SIGNATURE_EXACT` und
`PASS P2_MBC_SIGNATURE_DRAFT_READY`, stoppte aber bei
`REVIEW_DROPDOWN_OCCLUDED`. Die alte Funktion in
`lib/phase2-comarch-actions.mjs` prüfte ausschließlich die Bildschirmmitte
des SELECT mit dem Wert `FORWARD_TO_REVIEW`. Das war kein Nachweis, dass
das ganze Dropdown unzugänglich war. Es gab keinen Ausführungsklick.

## Korrektur

* Das genau einmal gefundene, sichtbar und aktiv nutzbare COMARCH-SELECT
  wird über seinen enthaltenen `FORWARD_TO_REVIEW`-Optionswert erkannt,
  unabhängig von einer dynamischen ICEfaces-ID.
* Passive Scrollpositionen `center`, `nearest`, `start` und `end`.
  In jedem sichtbaren Teilrechteck werden neun Punkte geprüft.
  Nur ein Treffer auf **demselben SELECT** erlaubt einen nativen CDP-Mausklick.
* Direkt vor dem Klick wird der Treffpunkt nochmals geprüft.
  Danach wird der reale Browserfokus auf genau diesem SELECT kontrolliert.
* Ist alles verdeckt, folgt **keine automatische Ersatzaktion**. Erst im
  Terminal `BEREIT_PRUEFSCHRITT` eingeben und anschließend im Bot-Edge das
  korrekte Dropdown **physisch fokussieren**. Browserfokus wird kontrolliert,
  kein `element.click()`, `.focus()` oder direkte Wertzuweisung verwendet.
* Erst dann erfolgt die native Tastaturauswahl. Das ICEfaces-Formular darf
  nicht durch Enter auf einem fremden Element abgeschickt werden.
* Nach Auswahl müssen `FORWARD_TO_REVIEW` und das sichtbare nächste
  Bearbeiterfeld stabil sein. `Baindl Mark (mark.baindl)` wird nach tatsächlicher
  Vorschlagsauswahl erneut geprüft. Die bestehende MANUELL/AUTO-Freigabe vor
  einem einzigen `Schritt ausführen` bleibt erhalten.

## Wiederaufnahme und Grenzen

Für Ticket 87160524 ist nur die Review-Auswahl offen. Der vorherige
MBC-Entwurf, INTL01-Signatur, Beschreibung und Ticket-Speicherung dürfen
nicht automatisch wiederholt werden. Offene `EXECUTE_INTENT` werden
weiterhin nicht erneut geklickt. Die Windows-COMARCH-Oberfläche konnte
hier nicht live gesteuert werden; Browsertests verwenden die nachgebildete
COMARCH-Oberfläche mit absichtlich verdecktem Dropdown.

Nach Download: neue START.cmd, Menü 1 (Schnellinstallation), danach
installierte START.cmd, Menü 12, Ticket `87160524`.
