# RC61 – Masterversand mit unterbrochenem Pilot

## Beleg aus dem RC60-Pilot

Das reale Terminalprotokoll endet direkt nach der Meldung `VERSANDPRUEFUNG` mit `^C` und der Windows-Rueckfrage zum Batchabbruch. Das ist eine Bedienerunterbrechung, **kein Versandnachweis und auch kein Nachweis eines fehlgeschlagenen Versands**. Ein erneuter Senden-Klick ist nicht zulaessig.

## RC61-Ablauf

1. Master Run (Menue 13, `MASTER_START`) liest das unveraenderte letzte REAL_RUN-Pilotjournal. Ein passender **einziger** neuer SEND_INTENT seit dessen Start wird als unterbrochener Pilot angeboten. Andere, aeltere oder nicht zuordenbare SEND_INTENT-Journale sind nicht betroffen.
2. Nur nach `PRUEFEN <Ticket-ID>` startet der bestehende `--complete-pending`-Runner. Er oeffnet ausschliesslich das gebundene Ticket, prueft den Originalausgang, fuegt nur `Standardantwort versendet` zu USC hinzu, speichert und prueft den nachgeladenen Serverstand. **Keine Senden-Funktion** in diesem Pfad. Bei unklarem Versand ist eine ausdrueckliche Sichtpruefung im COMARCH-Verlauf erforderlich. Ohne Beleg kein Status und keine Speicherung.
3. Wird der Abschluss nicht nachgewiesen, stoppt der gesamte Master. `UEBERSPRINGEN` belaesst das alte Ticket gesperrt und laesst neue geeignete Tickets zu.
4. Der abgeschlossene vorherige Pilot gilt nicht pauschal als Zertifizierung fuer die neue Softwareversion. Falls kein versionsgebundener Pilotbeleg vorhanden ist, startet genau ein neuer normaler Pilot. Danach erst Phase-1-Batches und schliesslich Phase 2. Kein erfolgreicher neuer Pilot: kein automatischer Phase-2-Start (Menue 12 bleibt getrennt moeglich).
5. Der aktive Versandlauf meldet alle 5 Sekunden den Prueffortschritt. Nach 35 Sekunden ohne eindeutigen automatischen Nachweis fragt er den Bediener nach einer aktiven Pruefung des vorhandenen Ausgangs. **Kein zweiter Versandklick**; `ABBRUCH` laesst das Journal offen.

## Erlaubte und nicht erlaubte Aussagen

`SEND_PRUEFUNG_AKTIV` oder `SEND_WARTET_AUF_NACHWEIS` bedeutet noch keinen Versandnachweis. `PASS SEND_OPERATOR_VERIFIED` ist eine nach Ticket, Empfaenger und Nachricht manuell bestaetigte Sichtpruefung – kein automatischer Serverbeleg. `PASS POST_SEND_STATUS_CONFIRMED` und `Ticket speichern PASS` setzen voraus, dass die Ueberpruefung erfolgreich abgeschlossen wurde.

RC61 aendert keine Phase-2-Upload-, GEVO-, Signatur- oder Weiterleitungsregeln. Alle Mapping-, Browserprofil-, private_data- und alten Ticket-Journaldaten bleiben bei der Schnellinstallation erhalten.
