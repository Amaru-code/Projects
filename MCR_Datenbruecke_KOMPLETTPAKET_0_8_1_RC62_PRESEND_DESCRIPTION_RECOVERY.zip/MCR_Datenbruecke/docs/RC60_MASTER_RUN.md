# RC60 – Master Run, Phase 1 → Phase 2

Menü 13 führt die existierenden und unveränderten Browser-Runner in zwei getrennten Phasen aus.

- Phase 1: Prüft versions- und mappinggebundenen echten Pilotnachweis. Ohne Nachweis zuerst genau einen echten Pilot ausführen. Nur ein bestätigter Versand UND gespeicherte Beschreibung genehmigen den regulären Lauf. Bereits offengebliebene SEND_INTENT-Fälle werden von der vorhandenen Journalprüfung ausgeschlossen. Kein erzwungener Neuversand.
- Reguläre Phase-1-Batches: höchstens 100 Tickets je Batch und höchstens 10 Batches; jeder Batch prüft den Abschluss und den vorherigen Journalbestand. Stop bei weniger als 100 bearbeiteten Tickets; bei erreichtem Gesamtlimit KEINE automatische Phase 2, sondern Status PARTIAL_PHASE1_LIMIT.
- Ohne geeigneten echten Versandpiloten wird KEINE Pilotfreigabe erfunden. Phase 2 kann unabhängig mit ihrem bisherigen Schutz fortfahren.
- Phase 2: Der bestehende `phase2Run` für aktuelle sichtbare eigene Vorgänge, mit Fenster MANUELL/AUTO, konkreter Kontrolle der Weiterleitung und ohne E-Mail-Versand. Zu Beginn bleibt die bereits vorhandene START-Eingabe; Start-Ticket leer lassen für den sichtbaren Bereich.
- Kein automatischer Generatorstart. Keine unbekannten Phase-2-Regeln. Keine Behauptung, alle Seiten einer paginierten Liste verarbeitet zu haben.
- Der Masterbericht liegt dauerhaft unter `.runtime/master/MCR_MASTER_RUN_*.json`. Bei Fehler `STOP_REVIEW_REQUIRED`, ohne blinden Neustart; die jeweiligen Ticket- und Versandjournale gelten weiterhin.
- RC60 wird per Menü 1 aus RC59 installiert. Es werden nur Softwaredateien ersetzt; lokale Bestandsdaten und Journale bleiben erhalten.
