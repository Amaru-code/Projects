RC63: kompaktes RC62→RC63-Vollupgrade. Produktive Module und Journalschutz bleiben erhalten. Siehe README_DE.md.
