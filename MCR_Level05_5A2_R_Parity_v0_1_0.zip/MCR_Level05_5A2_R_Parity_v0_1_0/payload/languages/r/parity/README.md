# Level 05A.2 – R Mode 1 Parity v0.1.0

Independent base-R implementation of the frozen LNW DC pipeline.

- existing `Rscript.exe`
- base/recommended R only; no external R packages
- no generated native candidate EXE
- no Python/C#/Rust/Node/Ruby/Julia/Java worker
- DU/DP parsing, company filtering, WWID mapping, merge and LNW aggregation in R
- PowerShell/.NET is used only as a workbook-I/O bridge for XLSX serialization and Excel COM recalculation/CSV output

The converted DU/DP files and both masters are materialized as XLSX files using a minimal OOXML writer in the I/O bridge; business rules remain in R.
