[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$ModeRoot = $PSScriptRoot
$SrcRoot = Join-Path $ModeRoot 'src'
$BuildRoot = Join-Path $ModeRoot 'build'
$Publish = Join-Path $BuildRoot 'publish'
$Pointer = Join-Path $BuildRoot 'rscript_path.txt'
$MainSource = Join-Path $SrcRoot 'main.R'
$MainPublish = Join-Path $Publish 'main.R'

function Test-Rscript([string]$Path) {
    if ([string]::IsNullOrWhiteSpace($Path) -or -not (Test-Path $Path -PathType Leaf)) { return $false }
    $old=$ErrorActionPreference; $ErrorActionPreference='Continue'
    try { $v=& $Path --version 2>&1; $c=$LASTEXITCODE } finally { $ErrorActionPreference=$old }
    return ($c -eq 0 -and ($v -join ' ') -match 'R scripting front-end|R version')
}

$Candidates = New-Object System.Collections.Generic.List[string]
$cmd = Get-Command Rscript.exe -ErrorAction SilentlyContinue
if ($cmd) { $Candidates.Add($cmd.Source) }
if ($env:USERPROFILE) {
    foreach ($root in @(
        (Join-Path $env:USERPROFILE 'projects\Compiler\r'),
        (Join-Path $env:USERPROFILE 'projects\Compiler\R')
    )) {
        if (Test-Path $root) {
            Get-ChildItem $root -Recurse -Filter Rscript.exe -File -ErrorAction SilentlyContinue | ForEach-Object {
                if (-not $Candidates.Contains($_.FullName)) { $Candidates.Add($_.FullName) }
            }
        }
    }
}
foreach ($root in @('C:\Program Files\R','C:\Program Files (x86)\R')) {
    if (Test-Path $root) {
        Get-ChildItem $root -Recurse -Filter Rscript.exe -File -ErrorAction SilentlyContinue | ForEach-Object {
            if (-not $Candidates.Contains($_.FullName)) { $Candidates.Add($_.FullName) }
        }
    }
}

$Rscript=$null
foreach($c in $Candidates){if(Test-Rscript $c){$Rscript=$c;break}}
if(-not $Rscript){throw 'Vorhandene Rscript.exe Runtime wurde nicht gefunden. Es wird nichts heruntergeladen.'}

Write-Host '============================================================'
Write-Host ' Level 05A.2 - R Parity Build'
Write-Host '============================================================'
Write-Host "Rscript:   $Rscript"
& $Rscript --version
Write-Host "Source:    $MainSource"
Write-Host "Publish:   $Publish"
Write-Host ''
Write-Host 'Dependencies: existing R runtime + base/recommended R only / OFFLINE'
Write-Host 'External R packages: NONE'
Write-Host 'Native candidate EXE generation: NONE'
Write-Host ''

if(Test-Path $Publish){Remove-Item $Publish -Recurse -Force}
New-Item -ItemType Directory -Force -Path $Publish | Out-Null
Copy-Item $MainSource $MainPublish -Force
Copy-Item (Join-Path $SrcRoot 'excel_bridge.ps1') (Join-Path $Publish 'excel_bridge.ps1') -Force
New-Item -ItemType Directory -Force -Path (Join-Path $Publish 'resources') | Out-Null
Copy-Item (Join-Path $SrcRoot 'resources\settings.json') (Join-Path $Publish 'resources\settings.json') -Force
Copy-Item (Join-Path $SrcRoot 'resources\wwid_mapping.csv') (Join-Path $Publish 'resources\wwid_mapping.csv') -Force
New-Item -ItemType Directory -Force -Path $BuildRoot | Out-Null
Set-Content $Pointer $Rscript -Encoding UTF8

# Parse-only preflight via a tiny .R file to avoid Windows native -e quoting.
$Check = Join-Path $BuildRoot '_source_check.R'
@'
args <- commandArgs(trailingOnly=TRUE)
parse(file=args[[1]])
cat("R_SOURCE_OK\n")
'@ | Set-Content $Check -Encoding UTF8
$old=$ErrorActionPreference; $ErrorActionPreference='Continue'
try { & $Rscript --vanilla $Check $MainPublish; $Code=$LASTEXITCODE } finally { $ErrorActionPreference=$old }
Remove-Item $Check -Force -ErrorAction SilentlyContinue
if($Code -ne 0){throw "R Source Check fehlgeschlagen. ExitCode=$Code"}

Write-Host ''
Write-Host 'R PARITY BUILD: PASS' -ForegroundColor Green
Write-Host "MAIN: $MainPublish"
Write-Host 'Runtime: existing Rscript.exe (no new native EXE)' -ForegroundColor Green
exit 0
