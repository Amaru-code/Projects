# MCR Level 05A.2 – R Mode 1 Parity v0.1.0

First R parity candidate for the frozen LNW DC benchmark.

- existing R runtime
- base R only
- offline build/run
- no external packages
- no new native candidate EXE
- complete business implementation in R
- common Level-05 validator after the timed candidate run

Run `START_5A2_R.ps1`.
