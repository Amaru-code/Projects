/** Test shutdown solely with in-memory fake child processes: never launches
 * taskkill or a COMARCH browser, including on actual Windows workstations. */
import test from 'node:test';
import assert from 'node:assert/strict';
import os from 'node:os';
import fs from 'node:fs';
import path from 'node:path';
import {EventEmitter} from 'node:events';
import {ownedFictionalBrowserPid,shutdownFictionalBrowser} from '../lib/demo-browser-shutdown.mjs';
import {ROOT} from './helpers.mjs';
import {VERSION} from '../lib/control.mjs';
import {sha256} from '../lib/core.mjs';

function fixture({valid=true}={}){
 const profile=path.join(os.tmpdir(),'MCR-Fiktiv-Profil-TEST41','edge-profile');
 const child=new EventEmitter();
 Object.assign(child,{pid:41241,spawnfile:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',spawnargs:['msedge.exe','--remote-debugging-port=0','--user-data-dir='+profile],exitCode:null,signalCode:null,kills:0,unrefs:0});
 child.kill=()=>{child.kills++;return true;};child.unref=()=>{child.unrefs++;};
 return {child,activeFile:path.join(profile,'DevToolsActivePort')};
}
function cdp(){return {opened:true,async send(method){assert.equal(method,'Browser.close');throw new Error('already disconnected');},close(){}};}
test('RC41 Windows stubborn own Edge: isolated PID tree fallback must verify a real exit',async()=>{
 const browser=fixture();let call=0;
 const result=await shutdownFictionalBrowser({browser,cdp:cdp(),platform:'win32',tmpDir:os.tmpdir(),graceMs:5,killWaitMs:5,treeWaitMs:5,
  runTaskkill:async pid=>{call++;assert.equal(pid,41241);browser.child.exitCode=0;browser.child.emit('exit',0,null);return true;}});
 assert.equal(call,1);assert.equal(result.closed,true);assert.equal(result.mode,'OWNED_DEMO_TREE_EXIT');assert.equal(browser.child.kills,1);
});
test('RC41 Windows taskkill alone is NOT proof of process exit',async()=>{
 const browser=fixture();let call=0;
 const result=await shutdownFictionalBrowser({browser,cdp:cdp(),platform:'win32',tmpDir:os.tmpdir(),graceMs:5,killWaitMs:5,treeWaitMs:5,
  runTaskkill:async()=>{call++;return true;}});
 assert.equal(call,1);assert.equal(result.closed,false);assert.equal(result.mode,'TREE_KILLED_WITHOUT_EXIT_PROOF');
});
test('RC41 never targets user Edge, wrong profile, wrong exe or outside temporary directory',async()=>{
 for(const mutate of [
  b=>{b.activeFile=path.join(os.tmpdir(),'normal-profile','DevToolsActivePort');},
  b=>{b.activeFile=path.join(os.homedir(),'Desktop','MCR-Fiktiv-Profil-TEST41','edge-profile','DevToolsActivePort');},
  b=>{b.child.spawnfile='C:/Windows/System32/cmd.exe';},
  b=>{b.child.spawnargs[2]='--user-data-dir='+path.join(os.tmpdir(),'another');},
  b=>{b.child.pid=process.pid;},
  b=>{b.child.spawnargs.push('--user-data-dir='+path.join(os.tmpdir(),'foreign'));},
  b=>{b.child.pid=-2;}
 ]){
  const b=fixture();mutate(b);
  assert.equal(ownedFictionalBrowserPid({browser:b,platform:'win32',tmpDir:os.tmpdir()}),null);
  let calls=0;
  const r=await shutdownFictionalBrowser({browser:b,cdp:{opened:false,close(){}},platform:'win32',tmpDir:os.tmpdir(),graceMs:1,killWaitMs:1,treeWaitMs:1,runTaskkill:async()=>{calls++;return true;}});
  assert.equal(r.closed,false);assert.equal(calls,0);
 }
});
test('RC41 on non-Windows cannot use native tree kill; graceful exit still recognized',async()=>{
 const b=fixture();let calls=0;
 const r=await shutdownFictionalBrowser({browser:b,cdp:cdp(),platform:'linux',graceMs:5,killWaitMs:5,runTaskkill:async()=>{calls++;return true;}});
 assert.equal(r.closed,false);assert.equal(calls,0);
});
test('RC41 original RC40 manifest exact and software-only update',()=>{
 assert.equal(VERSION,'0.8.1-rc.45');
 const original=path.join(ROOT,'tools/reference/complete-0.8.1-rc.40-manifest.json');
 assert.equal(sha256(fs.readFileSync(original)),'1b0ff59a90cb58d432a9b26f7e6e215a86b2017c683824ef7f40ae966ad9de2b');
 const code=fs.readFileSync(path.join(ROOT,'tools/integrity.mjs'),'utf8');
 assert.match(code,/m\.version==='0\.8\.1-rc\.40'/);
});
