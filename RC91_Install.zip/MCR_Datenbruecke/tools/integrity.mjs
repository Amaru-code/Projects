/** RC86 slim, fail-closed package verifier. Upgrade nur von verifizierten RC64-/RC65-/RC67-/RC68-/RC69-/RC70-/RC71-/RC72-/RC73-/RC74-/RC75-/RC76-/RC77-/RC78-/RC79-Installationen (SHA-gebunden). Historical releases remain in the local
 * rollback archive, not the distributed executable package. */
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {sha256,requireThat as need} from '../lib/core.mjs';
import {readJSON,plainPath,VERSION} from '../lib/control.mjs';
import {resolveConfig} from '../lib/config.mjs';
const PACKAGE_ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const RC90_MANIFEST_SHA='dab7966bb862344b340087bd2d69346f5e3c1ff7fb603375f83607e9a0c08676';
const RC89_MANIFEST_SHA='6d5c825760394bce6b4e128587578c95a248acd93e4b9a8795f1167a74665580';
const RC88_MANIFEST_SHA='559e29acfd833104ba95f4856c89ee4825ea10250fe86be0e5d12e825180b69b';
const RC87_MANIFEST_SHA='1f1bfbc5cabb59a4852e55856623dc9b505c5e25efe8aca3f2f1c34a974231c6';
const RC86_MANIFEST_SHA='7820f91b57dcfca6a769e211f7fcc4472053bb53f068b3e9e05c8d069f98c029';
const RC85_MANIFEST_SHA='df122b594acdade1073b172f3acf40b9ac31dc740f75033cb04cee740b1282b6';
const RC84_MANIFEST_SHA='c6d50ff7bba1fccbd425ad8f872dee0ca0c6f71fdadb5fb208311251f181e015';
const RC83_MANIFEST_SHA='6fc1bc461cfeb5a39f974ea5b2ed8f3a6695159ee6196eaa80fb1ad72287a74c';
const RC82_MANIFEST_SHA='f87b30ac30d59cdc3aaecf4081a5b3f794a7bf4367e4fb0e3b473947cf6d7b27';
const RC81_MANIFEST_SHA='b7924db25c8bf2a52f230f9cdfe02d97866d8dd7c509a018d99598831925fce6';
const RC80_MANIFEST_SHA='a0644c23a00915d68ffa244faf5ba3e33b8f49c91091347e98f50c00473aac71';
const RC79_MANIFEST_SHA='3dcac2c8c14deaff1a55bde99b6d4f45f7c7b50a5dd97710ad61e950a5517239';
const RC78_MANIFEST_SHA='8d99a070a092639427217d9a932c5d36c0f063826a77582c475f2f2768a1785c';
const RC77_MANIFEST_SHA='f98c4a2259ae1a38deb553fc929148db1e4bc39f7ce8d4f3f452fb09e8950529';
const RC76_MANIFEST_SHA='ede7beb828558ba0b6cbead64b791284731764600daa65f78625b02bfcdabde2';
const RC75_MANIFEST_SHA='ab916367c9c2fb3b188c7140afa36edf68283f15a319c88736fc365b1bbbbc5c';
const RC74_MANIFEST_SHA='bb63bdbbbab32b84a40d47281dd2aa5506a7aee6d7aa1407c351842a396df65c';
const RC73_MANIFEST_SHA='7dc28bd66f8caba0c5932a3288ae3984546fc09da3eb33ac754c2e1f79141f86';
const RC72_MANIFEST_SHA='f4cba0ab9511ab17bff4fb795b32b218179abcc98155fd8231afecd624bd6633';
const RC71_MANIFEST_SHA='de11bdd7a1a08167de48ef76078c3908d8b74626c1ab6755b15391aa4bd9a0c6';
const RC70_MANIFEST_SHA='4b22f1d3816e4d389640304906f4001d46bf64dc7874118f53b92ef9a6e540c3';
const RC69_MANIFEST_SHA='6943e16e8906aa30789540571c1b8553e61430d5498f1f44b4874ba6647ac40e';
const RC68_MANIFEST_SHA='23dcfe5c56741d1844e0fabf862284223c2341fde90caa446bc00cf8f6b9a71f';
const RC67_MANIFEST_SHA='e97f8d9b78b770a8e0f8a50253af0a51bc9175866f47d20e0df8d3cd44f7b73f';
const RC65_MANIFEST_SHA='f8cf24bcb95e68d12209f49bfc602bf0b452102eefb226de4e935c089dfa6512';
const RC64_MANIFEST_SHA='67b836e15f7a11bc9ed8f6cb8e5765396a58da4bf6824db1e7678802c8e65c0e';
const CODE_DIRS=['src','lib','tools','tests','examples'];
export const safeRelative=p=>typeof p==='string'&&p.length>0&&!/[\\:\x00-\x1f]/.test(p)&&!p.startsWith('/')&&!p.split('/').some(x=>!x||x==='.'||x==='..');
export function verifyRecords(root,records,{skipConfig=false}={}){
 need(Array.isArray(records)&&records.length>0&&records.length<2000,'MANIFEST_INVALID','Manifest fehlt/zu gross.');
 const seen=new Set();
 for(const r of records){
  need(r&&safeRelative(r.path)&&!seen.has(r.path.toLowerCase())&&Number.isSafeInteger(r.bytes)&&r.bytes>=0&&/^[a-f0-9]{64}$/.test(r.sha256),'MANIFEST_INVALID','Manifestpfad/Hash falsch.');
  seen.add(r.path.toLowerCase());
  if(skipConfig&&r.path==='config/local-runner-queue-send.json')continue;
  const p=plainPath(path.join(root,...r.path.split('/'))),st=fs.statSync(p);
  need(st.isFile()&&st.size===r.bytes&&st.size<32*1024*1024,'PACKAGE_SIZE','Dateilaenge abweichend: '+r.path);
  need(sha256(fs.readFileSync(p))===r.sha256,'PACKAGE_HASH','Programmdatei abweichend: '+r.path);
 }
 return seen;
}
function verifyCodeTree(root,seen){
 const visited=new Set();let count=0;
 function walk(p,rel){plainPath(p);need(fs.existsSync(p),'CODE_TREE_MISSING','Programmpfad fehlt: '+rel);
  for(const n of fs.readdirSync(p).sort()){
   const f=path.join(p,n),r=rel+'/'+n,k=r.toLowerCase();
   need(++count<=10000&&safeRelative(r)&&!visited.has(k),'CODE_TREE_LIMIT','Unzulaessiger Dateipfad: '+r);
   visited.add(k);plainPath(f);const st=fs.statSync(f);
   if(st.isDirectory()){walk(f,r);continue;}
   need(st.isFile()&&seen.has(k),'UNSEALED_CODE','Nicht manifestierter Programmcode: '+r);
  }
 }
 for(const d of CODE_DIRS)walk(path.join(root,d),d);
}
export function verifyPackage(root,{strictConfig=false}={}){
 plainPath(root);const m=readJSON(path.join(root,'MANIFEST.json'),2*1024*1024);
 need(m.schema==='MCR_COMPLETE_PACKAGE_V1'&&m.package==='MCR_Datenbruecke'&&m.version===VERSION,'PACKAGE_VERSION','Nicht das freigegebene RC91-Paket.');
 need(!m.payload.some(r=>/^tests\/fixtures\/complete-0\.8\.1-rc\.\d+\.zip$/i.test(r.path||'')),'PACKAGE_RECURSION','Kein altes Komplettpaket einbetten.');
 const seen=verifyRecords(root,m.payload,{skipConfig:!strictConfig});verifyCodeTree(root,seen);resolveConfig(root);
 return {version:m.version,files:m.payload.length,manifestSha256:sha256(fs.readFileSync(path.join(root,'MANIFEST.json')))};
}
export function verifyPrevious(root){
 plainPath(root);const m=readJSON(path.join(root,'MANIFEST.json'),2*1024*1024);
 need(m.schema==='MCR_COMPLETE_PACKAGE_V1'&&m.package==='MCR_Datenbruecke','PREVIOUS_COMPLETE_VERSION','Nur verifizierte Bestandsinstallationen bis RC91 erlaubt.');
 const expected=m.version==='0.8.1-rc.90'?RC90_MANIFEST_SHA:m.version==='0.8.1-rc.89'?RC89_MANIFEST_SHA:m.version==='0.8.1-rc.88'?RC88_MANIFEST_SHA:m.version==='0.8.1-rc.87'?RC87_MANIFEST_SHA:m.version==='0.8.1-rc.86'?RC86_MANIFEST_SHA:m.version==='0.8.1-rc.85'?RC85_MANIFEST_SHA:m.version==='0.8.1-rc.84'?RC84_MANIFEST_SHA:m.version==='0.8.1-rc.83'?RC83_MANIFEST_SHA:m.version==='0.8.1-rc.82'?RC82_MANIFEST_SHA:m.version==='0.8.1-rc.81'?RC81_MANIFEST_SHA:m.version==='0.8.1-rc.80'?RC80_MANIFEST_SHA:m.version==='0.8.1-rc.79'?RC79_MANIFEST_SHA:m.version==='0.8.1-rc.78'?RC78_MANIFEST_SHA:m.version==='0.8.1-rc.77'?RC77_MANIFEST_SHA:m.version==='0.8.1-rc.76'?RC76_MANIFEST_SHA:m.version==='0.8.1-rc.75'?RC75_MANIFEST_SHA:m.version==='0.8.1-rc.74'?RC74_MANIFEST_SHA:m.version==='0.8.1-rc.73'?RC73_MANIFEST_SHA:m.version==='0.8.1-rc.72'?RC72_MANIFEST_SHA:m.version==='0.8.1-rc.71'?RC71_MANIFEST_SHA:m.version==='0.8.1-rc.70'?RC70_MANIFEST_SHA:m.version==='0.8.1-rc.69'?RC69_MANIFEST_SHA:m.version==='0.8.1-rc.68'?RC68_MANIFEST_SHA:m.version==='0.8.1-rc.67'?RC67_MANIFEST_SHA:m.version==='0.8.1-rc.65'?RC65_MANIFEST_SHA:m.version==='0.8.1-rc.64'?RC64_MANIFEST_SHA:m.version===VERSION?sha256(fs.readFileSync(path.join(PACKAGE_ROOT,'MANIFEST.json'))):null;
 need(expected,'PREVIOUS_COMPLETE_VERSION','Kompaktes Update von verifizierten Bestandsversionen bis RC90 nach RC91; andere Version erst gesondert migrieren.');
 const digest=sha256(fs.readFileSync(path.join(root,'MANIFEST.json')));
 need(digest===expected,'PREVIOUS_MANIFEST_CHANGED','Bestandssoftware weicht vom unveraenderten Release ab.');
 const seen=verifyRecords(root,m.payload,{skipConfig:true});verifyCodeTree(root,seen);resolveConfig(root);
 return {version:m.version,files:m.payload.length,manifestSha256:digest,state:'COMPLETE_RELEASE_VERIFIED',legacyResiduals:[],authorization:'SOFTWARE_UPDATE_ONLY'};
}
export function treeDigest(root){plainPath(root);const rows=[];let count=0,total=0;
 function visit(p,rel){plainPath(p);const st=fs.statSync(p);need(++count<10000,'TREE_LIMIT','Zu viele Dateien.');
  if(st.isDirectory()){rows.push(['D',rel]);for(const n of fs.readdirSync(p).sort())visit(path.join(p,n),rel?rel+'/'+n:n);}
  else{need(st.isFile()&&st.size<32*1024*1024,'TREE_FILE','Keine normale Softwaredatei.');total+=st.size;need(total<128*1024*1024,'TREE_LIMIT','Software zu gross.');rows.push(['F',rel,st.size,sha256(fs.readFileSync(p))]);}
 }visit(root,'');return sha256(JSON.stringify(rows));}
