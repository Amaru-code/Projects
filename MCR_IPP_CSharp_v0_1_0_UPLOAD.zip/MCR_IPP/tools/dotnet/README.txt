Hier kann ein BEREITS VORHANDENES portables .NET 10 SDK liegen:
MCR_IPP\tools\dotnet\dotnet.exe

Es wird kein SDK mitgeliefert und nichts automatisch heruntergeladen.
START.cmd erkennt alternativ IPP_DOTNET, settings.local.txt oder dotnet.exe im bestehenden PATH.
Ohne Treffer fragt es nach dem Pfad zu einer vorhandenen dotnet.exe.
Keine Installation, keine Adminrechte, kein globaler PATH, keine Registry-Aenderungen.
Das SDK muss zum Windows-Rechner passen und Windows-Desktop-Referenzpakete enthalten.
Ein bestehendes Windows .NET 10 SDK (z.B. 10.0.400) kann verwendet werden.
Nicht bei Updates loeschen. Paketwurzel MCR_IPP bleibt stabil.
