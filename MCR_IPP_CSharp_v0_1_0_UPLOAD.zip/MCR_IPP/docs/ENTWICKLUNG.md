# Entwicklung und Qualifikation

## Toolchain

C# 14, .NET 10, Standardbibliothek; WinForms nur im Desktopprojekt.
Keine PackageReference und keine Online-NuGet-Quelle. Ein bestehendes portables Windows-
.NET-SDK kann außerhalb des Ordners verbleiben; der Pfad wird lokal gespeichert.
Build: `BUILD_UND_TEST.cmd`. Bedienoberfläche: `START.cmd`. Synthetischer CLI-Lauf: `DEMO.cmd`.
Die Wrapper haben CRLF, ASCII-Inhalt und kein BOM. Es wird kein langes PowerShell-
Skript in eine Konsole kopiert. Keine Backtick-Zeilenfortsetzungen.

Linux-/macOS-Coretests sind mit vorhandenem .NET-10-SDK prinzipiell separat möglich;
der Desktop-Build benötigt Windows-Desktop-Referenzen. Die gepackte Anwendung wurde
hier nicht kompiliert. Für den ersten realen Build sind evidence/local/build.log und
evidence/local/tests.log maßgeblich. Schlägt ein Test fehl, nicht auskommentieren, um
die Oberfläche freizuschalten, sondern Ursache/Referenz prüfen.

CLI Beispiel (nach Build, eine Zeile):

```
dotnet src/Mcr.Ipp.Cli/bin/Release/net10.0/Mcr.Ipp.Cli.dll contribute --baseline examples/Bestand_Synthetisch.xlsx --txt examples/Monatsdaten/Aenderungen_012026.txt --out Output
```

`--ipp` fügt die geprüfte Vorbereitungsstufe hinzu; `--options` erlaubt explizite
Eingabeoptionen. Exitcodes: 0=Beitragspfad erfolgreich, 2=Fehler, 3=Beitragspfad
fertig, angeforderte IPP-Stufe blockiert. 0 bedeutet niemals Produktions-PDF-freigegeben.

## Tests

56 benannte C#-Tests ohne externe Testframeworks. Die numerischen Sweeps vergleichen
6684 Beitragsergebnisse und 5030 Rundungsergebnisse mit gespeicherten Python-Vektoren.
Daneben: Tarif98/99, Rückwechsel, Fallback, Wiederaufnahme ohne ATTC, Ein-/Austritt,
Claim-Filter, Reihenfolge, Duplikate, Nullwerte, IDs, Parser, sichere XLSX-Texte,
Roundtrip, Demo-E2E und Ablehnung falscher IPP-Vorlagen. JUnit und JSON werden nur
nach tatsächlichem lokalen C#-Lauf erzeugt. Das Paket enthält keinen fiktiven PASS.

Die Demo stammt aus artifact_tool und nicht aus dem C#-Writer. Alle Personen sind
synthetisch. Nullwerte/Datumswerte/IDs werden dabei unabhängig vom Writer eingelesen.
Die reinen Formelreferenzen stammen aus dem Python-Funktionsauszug (offengelegte T01-
Korrektur und Datum-/NA-Adapter), nicht aus erwarteten C#-Ergebnissen.

Es fehlen noch: vollständige User-Python-Gesamtpipeline-Parität unter exakt gepinntem
Python/pandas-Stand, reale input/output Golden Cases, echte COM-Läufe, geänderte
Vorlagenversionen, unterschriebene/geschützte Sonderdateien, Produktionslast/Absturztests.
Die Input-Grammatik ist bewusst enger als pandas; siehe REGELVERTRAG.md.

## Nächster geschlossener Workstream

Zuerst den realen Windows-Build qualifizieren und alle Testfehler mit Belegen beheben.
Anschließend anonymisierte Realdaten von Baseline+TXT gegen den tatsächlich benutzten
Python-Stand vergleichen. Jede Abweichung als Eingabeschutz, Bugfix oder fachliche
Änderung klassifizieren; keine stillen Redefinitionen.

Für IPP nur die vom Nutzer benannte Vorlage und ihre explizit freigegebenen Datenquellen
verwenden. Den fehlenden Mappingvertrag anhand echter IPP-Belege schließen. Keine erneute
DC-/Benchmark-Projektsuche. Keine Mehrjahres-/Jahressummenannahme aus Spaltenpositionen.
VBA/Add-in nicht selbsttätig aktivieren. Erst nach Mapping-/Parameterfreigabe originale
und neue Personenergebnisse vergleichen, dann Excel-Renderpfad produktionsqualifizieren.

## Weitergabe eines Fehlerberichts

Für technische Buildprobleme sind build.log, tests.log, csharp_tests.json und ggf. JUnit
relevant. Keine Bestandsdateien, Monats-TXT, Beiträge oder PDFs ungeprüft hochladen.
Dateien im Output sind personenbezogene Kundendaten, keine automatisch anonymisierten
Support-Artefakte. Das Programm sendet nichts an externe Dienste.
