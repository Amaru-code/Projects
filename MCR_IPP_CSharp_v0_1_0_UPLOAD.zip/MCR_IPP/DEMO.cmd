@echo off
setlocal
cd /d "%~dp0"
call BUILD_UND_TEST.cmd
if errorlevel 1 goto failed
call scripts\SDK.cmd
if errorlevel 1 goto failed
"%IPP_DOTNET%" "src\Mcr.Ipp.Cli\bin\Release\net10.0\Mcr.Ipp.Cli.dll" contribute --baseline "examples\Bestand_Synthetisch.xlsx" --txt "examples\Monatsdaten\Aenderungen_012026.txt" --txt "examples\Monatsdaten\Aenderungen_022026.txt" --txt "examples\Monatsdaten\Aenderungen_032026.txt" --txt "examples\Monatsdaten\Aenderungen_042026.txt" --txt "examples\Monatsdaten\Aenderungen_052026.txt" --txt "examples\Monatsdaten\Aenderungen_062026.txt" --out "Output"
if errorlevel 1 goto failed
echo Demo erstellt. Nur synthetische Beitraege; keine Leistungsbescheinigung.
pause
exit /b 0
:failed
pause
exit /b 1
