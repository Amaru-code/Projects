@echo off
setlocal
cd /d "%~dp0"
if "%~1"=="" goto usage
call BUILD_UND_TEST.cmd
if errorlevel 1 goto failed
call scripts\SDK.cmd
if errorlevel 1 goto failed
"%IPP_DOTNET%" "src\Mcr.Ipp.Desktop\bin\Release\net10.0-windows\Mcr.Ipp.Desktop.dll" --render-preview "%~1"
if errorlevel 1 goto failed
exit /b 0
:usage
echo Nur fuer gepruefte, externe-abhaengigkeitsfreie IPP-Arbeitskopien.
echo Beispiel: PDF_VORSCHAU_ENTWICKLUNG.cmd "C:\Pfad\preview-job.json"
echo Die bekannte IPP-Datei ist wegen offener Abhaengigkeiten NICHT hierfuer freigegeben.
echo Siehe docs\PDF_PREVIEW.md. Keine produktiven PDFs.
:failed
pause
exit /b 1
