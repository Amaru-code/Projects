# MCR IPP · 0.1.0
## C#-Projekt: Bestand + TXT → Monatsbeiträge + geprüfte IPP-Vorbereitung

**Geltungsbereich: ausschließlich IPP. Keine DC-Vorlage und keine Benchmark-Daten.**

Dieses Paket ist ein vollständiges Quellprojekt mit Windows-Oberfläche, Kommandozeile,
Beitragskern, XLSX-Ein-/Ausgabe, statischer IPP-Prüfung, kopiebasierter IPP-Vorbereitung,
mechanischem PDF-Entwurfsadapter, Tests und synthetischen Eingaben. Es ist **noch keine
fachlich freigegebene Ende-zu-Ende-LNW-Produktion**.

## Start

1. Die ZIP vollständig in einen beschreibbaren lokalen Ordner entpacken. Der Ordner
   `MCR_IPP` bleibt bei künftigen Updates gleich. Nicht direkt in der ZIP starten.
2. `START.cmd` doppelklicken. Das Skript sucht ein vorhandenes Windows-.NET-10-SDK:
   `tools\dotnet\dotnet.exe`, die Variable `IPP_DOTNET`, die lokale Pfad-Datei oder PATH.
   Falls nötig den Pfad zu einer vorhandenen portablen `dotnet.exe` eingeben.
   Ein bereits vorhandenes Windows-SDK 10.0.400 passt zur Projektkonfiguration.
3. Es wird zuerst **offline gebaut und getestet**. Nur bei erfolgreichem Build und
   erfolgreichen enthaltenen Tests öffnet sich die Oberfläche.
4. Zum ersten Kennenlernen „Synthetisches Beispiel laden“ anklicken, dann „Beiträge
   erstellen“. Die Demo hat 12 erfundene Personen und 6 Monatsdateien.
5. Für eigene Daten die **Bestandsvorlage** mit `ClientID`, `BaseSalary_1` und
   `PartTimeFactor_1` auswählen; dazu die Monats-TXT-Dateien desselben Jahres.
   Die IPP-Dokumentvorlage ist ein separates, optionales Feld.

Es erfolgt kein automatischer Download, keine Installation, keine Änderung am globalen
PATH oder der Registry und kein Abschalten von Unternehmensrichtlinien. Python wird
für den normalen Betrieb nicht benötigt. Das SDK ist wegen Größe und Offline-Vorgabe
nicht Bestandteil dieser ZIP. Eine reine .NET-Runtime genügt nicht für den ersten Build.

## Welcher Teil funktioniert im Projekt?

| Bestandteil | Implementierung | Grenze |
|---|---|---|
| Windows-Dateiauswahl | WinForms, nativ C# | Ausführung auf Windows erforderlich |
| Beitragsermittlung | C# mit Python-kompatibler Binärzahl-Rundung | Strengere Eingabeprüfung; siehe Regelvertrag |
| Monats-Excel | `Ergebnis.xlsx`, formatierte numerische Werte, ID als Text | Keine Jahres-/Bereitstellungssumme erfunden |
| Audit | JSON, Monatsprotokoll, Dateihashes, Manifest | Keine fachliche Genehmigung |
| IPP-Vorlagenprüfung | Ausschließlich bekannte IPP-Vorlage, hashgebunden | Änderung der Vorlage benötigt neue Prüfung |
| IPP-Kopie | Fügt `MCR_Status` und `MCR_Beitraege` hinzu | Bestehende Importtabellen bleiben unverändert |
| Produktions-PDF | **Nicht autorisiert** | Mapping, Bestandsquellen, UDFs, Fallentscheidung offen |
| PDF-Entwurfsadapter | Separates Entwicklerkommando; Excel-COM, Kopie, Wasserzeichen | Sperrt externe Referenzen/aktive Inhalte; bekannte Vorlage besteht diese Prüfung noch nicht |

**„Ergebnis erstellt“ bezieht sich nur auf Beiträge.** Die IPP-Kopie heißt bewusst
`IPP_VORBEREITUNG_NICHT_FREIGEGEBEN.xlsm`. Sie ist keine aktualisierte freigegebene LNW.
Die bisherigen Salden und Importwerte in der Kopie können weiterhin alte Werte sein.
Sie werden nicht ungeprüft als neue Berechnung ausgegeben.

## Originale und Ausgaben

Es werden neue Laufordner `Output\IPP_Run_...` angelegt, niemals Originale überschrieben.
Fehler-/Abbruchläufe bleiben unter `.inprogress_*` mit `FAILED.json`, ohne Erfolgsfreigabe.
Ein erfolgreicher Beitragslauf enthält mindestens:

- `Ergebnis.xlsx`: Personenstammdaten, Tarifwechsel, ATTC/TZG/Betrag je ausgewähltem Monat.
- `Contribution_Result.json`: strukturierte Ergebnisse einschließlich Claim und Herkunft.
- `Monatsprotokoll.csv`: Herkunft von ATTC/TZG und Gründe für leere Monatswerte.
- `Run_Report.json`, `Options_used.json`, `Manifest.json`, `00_LAUF_LESEN.txt`.

Mit passender IPP-Vorlage zusätzlich: statischer Prüfbericht, markierte Vorbereitungs-
Arbeitsmappe und Nachweis unverändert kopierter Originalbestandteile einschließlich VBA.
Die Original-.xlsm ist nicht in der ZIP enthalten. Auf dem Nutzerrechner auswählen:
`Kopie BA von IPP Unverfallbarkeitsbescheinigung_Template.xlsm`.

Die SHA256-Bindung der bekannten Originalvorlage lautet:
`A9F51A8CC0614A96903AE8975F6967D26549011CD8EDFB0DA0F028EABD0C591B`.

## Zwei Korrekturen gegenüber dem geposteten Python-Kern

Die Endgrenze 31.03.2026 wurde bereits vom Nutzer korrigiert und so übernommen.
Die letzte Zeile enthält aber weiterhin `8116,67, 12158,33` (vier Zahlen statt zwei).
T01 interpretiert die erkennbare Schreibabsicht als `8116.67, 12158.33`.
T02 verwendet im C#-Intervall ein offenes Enddatum statt eines pandas-Zeitstempel-Sentinels.
Beides ist ausdrücklich dokumentiert, keine wirtschaftliche Bestätigung der Parameter.
Der Originalauszug wird unter `reference/python_formula_received.txt` erhalten.

## Was wurde hier tatsächlich geprüft?

`evidence/verification.json` ist maßgeblich. In der Erstellungsumgebung waren kein
.NET-SDK und kein Excel verfügbar; ein SDK-Download war nicht möglich.
**Der C#-Build, die C#-Tests und Excel-COM wurden hier NICHT ausgeführt. Es gibt kein
mitgeliefertes, bereits auf Windows getestetes EXE.**

Ausgeführt wurden die Erzeugung von 6.684 Referenz-Beitragsfällen aus dem wörtlichen
Python-Funktionsauszug mit offengelegten Anpassungen sowie 5.030 Rundungsfälle.
Ein unabhängiges Python-Modell der Binärzahl-Rundung stimmt bei diesen 5.030 Fällen mit
Pythons `round` überein. Dies ersetzt weder den C#-Testlauf noch eine vollständige
pandas-Pipeline-Parität mit echten Daten.

`BUILD_UND_TEST.cmd` führt auf dem Nutzerrechner 56 enthaltene C#-Tests mit insgesamt
11.714 Zahlenvergleichsfällen sowie synthetischen Ablauf-/Dateitests aus.
Es erzeugt echte lokale Prüfnachweise unter `evidence\local`. Bei Fehlern kein UI-Autostart.
Erfolgreiche technische Tests sind noch keine Genehmigung von Zins-/Versorgungsregeln.

## Weitere Dokumente

`docs/REGELVERTRAG.md` beschreibt Referenzlogik und bewusste Eingabeverschärfungen.
`docs/IPP_MAPPING_OFFEN.md` grenzt die fehlende Zuordnung ein.
`docs/PDF_PREVIEW.md` beschreibt den getrennten, nicht produktiven COM-Adapter.
`docs/ENTWICKLUNG.md` beschreibt Builds, Tests und das Vorgehen bis zur Ende-zu-Ende-Freigabe.
`docs/QUELLEN.md` enthält die technischen Referenzen und Herkunft der Projektdaten.
