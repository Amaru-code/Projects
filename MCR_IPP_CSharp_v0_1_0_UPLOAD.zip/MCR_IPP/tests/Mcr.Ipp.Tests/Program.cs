using Mcr.Ipp.Core;
using System.Text;
using System.Text.Json;
using System.Xml.Linq;
using System.Security.Cryptography;

string root = args.Length > 0 ? Path.GetFullPath(args[0]) : Directory.GetCurrentDirectory();
var results = new List<(string Name, string? Error)>();
int vectorComparisons = 0;
void Check(bool condition, string message) { if (!condition) throw new Exception(message); }
void Equal(double? actual, double? expected) => Check(actual == expected, $"Erwartet {expected}, erhalten {actual}");
void Throws(string code, Action action) { try { action(); } catch (IppException e) { Check(e.Code==code,$"Erwartet {code}, erhalten {e.Code}: {e.Message}"); return; } throw new Exception("Erwarteter Fehler fehlt: "+code); }
void Test(string name, Action action) { try { action(); results.Add((name,null)); Console.WriteLine("PASS " + name); } catch(Exception e) { results.Add((name,e.ToString())); Console.WriteLine("FAIL " + name + ": " + e.Message); } }
Dictionary<string,object?> BaseRow() => new() { ["ClientID"]="1001", ["Surname"]="Demo", ["FirstName"]="Test", ["BirthDate"]="01.01.1980", ["BaseSalary_1"]=8000d, ["PartTimeFactor_1"]=100d, ["DAT_AD2"]=null, ["TerminationDate"]=null };
InputTable Base(Dictionary<string,object?>? row=null) { row ??= BaseRow(); return new("Tabelle1",row.Keys.ToList(),new(){row},false); }
Dictionary<string,string?> Row(string? tariff="10", string? attc="8000",string? tzg="100",string? claim="AKTAN",string? term=null,string type="ATTC_BAV",string id="1001") => new() { ["KDMA_IDENT"]=id,["Tarifklasse"]=tariff,["BETRAG1"]=attc,["ARBZEIT_PROZ"]=tzg,["ANSPRUCHSTYP"]=claim,["DAT_AUSTRITT"]=term,["BETRAG1_TYP"]=type };
MonthFile Month(int month, params Dictionary<string,string?>[] rows) => new($"Change_{month:D2}2026.txt",new(2026,month,1),rows.ToList(),"Tarifklasse",new("synthetic",new string('0',64),0));
ContributionResult Run(InputTable? baseline, params MonthFile[] months) => new ContributionEngine().Run(baseline ?? Base(),months,new());

Test("T01_intervals_are_contiguous",()=> { for(int i=0;i<ContributionFormula.Periods.Count;i++) { var p=ContributionFormula.Periods[i]; Check(p.Eckwert1>0&&p.Eckwert2>p.Eckwert1,"Eckwerte"); if(i>0)Check(ContributionFormula.Periods[i-1].To!.Value.AddDays(1)==p.From,"Intervalluebergang"); } });
Test("T02_reference_known_rounding",()=> { Equal(PythonRound.Round(2.675,2),2.67); Equal(PythonRound.Round(-2.675,2),-2.67); Equal(PythonRound.Round(.125,2),.12); });
Test("T03_all_python_rounding_vectors",()=> { using var j=JsonDocument.Parse(File.ReadAllText(Path.Combine(root,"tests","golden_vectors.json"))); foreach(var v in j.RootElement.GetProperty("rounding").EnumerateArray()) { Equal(PythonRound.Round(v.GetProperty("value").GetDouble(),v.GetProperty("digits").GetInt32()),v.GetProperty("expected").GetDouble()); vectorComparisons++; } });
Test("T04_all_python_formula_vectors",()=> { using var j=JsonDocument.Parse(File.ReadAllText(Path.Combine(root,"tests","golden_vectors.json"))); double? N(JsonElement e)=>e.ValueKind==JsonValueKind.Null?null:e.GetDouble(); foreach(var v in j.RootElement.GetProperty("contributions").EnumerateArray()) { Equal(ContributionFormula.Calculate(N(v.GetProperty("attc")),N(v.GetProperty("tzg")),DateOnly.Parse(v.GetProperty("date").GetString()!,Parse.Inv)),N(v.GetProperty("expected"))); vectorComparisons++; } });
Test("T05_normal_month",()=> { var r=Run(null,Month(1,Row())); Equal(r.Persons[0].Months[1].Attc,8000); Equal(r.Persons[0].Months[1].Tzg,100); Check(r.Persons[0].Months[1].Amount>0,"Beitrag fehlt"); });
Test("T06_january_fallback",()=> { var r=Run(null,Month(1,Row(attc:null,tzg:null))); Equal(r.Persons[0].Months[1].Attc,8000); Equal(r.Persons[0].Months[1].Tzg,100); });
Test("T07_previous_month_fallback",()=> { var r=Run(null,Month(1,Row(attc:"9000",tzg:"80")),Month(2,Row(attc:null,tzg:null))); Equal(r.Persons[0].Months[2].Attc,9000); Equal(r.Persons[0].Months[2].Tzg,80); });
Test("T08_tariff_99_only_current_month",()=> { var r=Run(null,Month(1,Row(tariff:"99")),Month(2,Row(tariff:"10"))); Equal(r.Persons[0].Months[1].Amount,null); Equal(r.Persons[0].Months[2].Attc,8000); Check(r.Persons[0].TariffOld==99&&r.Persons[0].TariffNew==10,"Tarifhistorie"); });
Test("T09_tariff_98_only_current_month",()=> { var r=Run(null,Month(1,Row(tariff:"10")),Month(2,Row(tariff:"98")),Month(3,Row(tariff:"10"))); Check(r.Persons[0].Months[1].Amount>0&&r.Persons[0].Months[3].Amount>0,"Monatssperre"); Equal(r.Persons[0].Months[2].Amount,null); });
Test("T10_no_restore_of_blocked_attc_without_new_value",()=> { var p=Run(null,Month(1,Row(tariff:"99")),Month(2,Row(tariff:"10",attc:null))).Persons[0]; Equal(p.Months[2].Attc,null); });
Test("T11_latest_change_can_return_to_original_tariff",()=> { var p=Run(null,Month(1,Row(tariff:"10")),Month(2,Row(tariff:"20")),Month(3,Row(tariff:"10"))).Persons[0]; Check(p.TariffOld==10&&p.TariffNew==10&&p.TariffChangeDate==new DateOnly(2026,3,1),"Rueckwechsel"); });
Test("T12_missing_monthly_tariff_carried_forward",()=> { var p=Run(null,Month(1,Row(tariff:"99")),Month(2,Row(tariff:null))).Persons[0]; Equal(p.Months[2].EffectiveTariff,99); Equal(p.Months[2].Attc,null); });
Test("T13_unknown_initial_tariff_blocks",()=>Throws("TARIFF_UNKNOWN",()=>Run(null,Month(1,Row(tariff:null)))));
Test("T14_unknown_tariff_opt_in_is_visible",()=> { var r=new ContributionEngine().Run(Base(),new[]{Month(1,Row(tariff:null))},new(){AllowMissingTariff=true}); Check(r.Warnings.Any(w=>w.Code=="UNKNOWN_TARIFF_ALLOWED"),"Warnung fehlt"); });
Test("T15_new_person_blocks",()=>Throws("TXT_PERSON_MISSING",()=>Run(null,Month(1,Row(id:"9999")))));
Test("T16_unknown_person_ignore_matches_left_join",()=> { var r=new ContributionEngine().Run(Base(),new[]{Month(1,Row(),Row(id:"9999"))},new(){AllowUnknownTxtPersons=true}); Check(r.Persons.Count==1&&r.Warnings.Any(w=>w.Code=="TXT_PERSON_IGNORED"),"Left join"); });
Test("T17_duplicate_baseline_blocks",()=> { var b=Base(); b.Rows.Add(BaseRow()); Throws("DUPLICATE_BASELINE_ID",()=>Run(b,Month(1,Row()))); });
Test("T18_duplicate_normalized_ids_block",()=> { var b=Base(); var r=BaseRow();r["ClientID"]="001001";b.Rows.Add(r); Throws("DUPLICATE_BASELINE_ID",()=>Run(b,Month(1,Row()))); });
Test("T19_baseline_alphanumeric_ids_block",()=> { var b=BaseRow();b["ClientID"]="1001 W";Throws("ID_UNSUPPORTED",()=>Run(Base(b),Month(1,Row()))); });
Test("T20_akta_filter_then_fallback",()=> { var p=Run(null,Month(1,Row(attc:"9999",claim:"AUGUAN"))).Persons[0]; Equal(p.Months[1].Attc,8000); });
Test("T21_last_matching_salary_row",()=> { var p=Run(null,Month(1,Row(attc:"8500"),Row(attc:"100",tzg:"80",type:"OTHER"))).Persons[0]; Equal(p.Months[1].Attc,8500); Equal(p.Months[1].Tzg,80); });
Test("T22_last_row_salary_wins",()=>Equal(Run(null,Month(1,Row(attc:"8500"),Row(attc:"9000"))).Persons[0].Months[1].Attc,9000));
Test("T23_factor_to_percent",()=>Equal(Run(null,Month(1,Row(tzg:"0,5"))).Persons[0].Months[1].Tzg,50));
Test("T24_one_means_full_time_in_raw_txt",()=>Equal(Run(null,Month(1,Row(tzg:"1"))).Persons[0].Months[1].Tzg,100));
Test("T25_one_percent_legacy_ambiguity_reported",()=>Check(Run(null,Month(1,Row(tzg:"0.01"))).Warnings.Any(w=>w.Code=="TZG_ONE_AMBIGUOUS"),"Warnung fehlt"));
Test("T26_zero_tzg_empty_amount",()=>Equal(Run(null,Month(1,Row(tzg:"0"))).Persons[0].Months[1].Amount,null));
Test("T27_negative_salary_blocks",()=>Throws("ATTC_NEGATIVE",()=>Run(null,Month(1,Row(attc:"-1")))));
Test("T28_negative_tzg_blocks",()=>Throws("TZG_RANGE",()=>Run(null,Month(1,Row(tzg:"-1")))));
Test("T29_entry_month_allowed_not_prorated",()=> { var b=BaseRow();b["DAT_AD2"]="15.02.2026";var p=Run(Base(b),Month(1,Row()),Month(2,Row())).Persons[0]; Equal(p.Months[1].Attc,null); Check(p.Months[2].Amount>0,"Eintrittsmonat"); });
Test("T30_entry_after_all_selected_months",()=> { var b=BaseRow();b["DAT_AD2"]="01.04.2026";var p=Run(Base(b),Month(1,Row()),Month(2,Row())).Persons[0]; Check(p.Months.Values.All(m=>m.Attc is null&&m.Tzg is null&&m.Amount is null),"Vor Eintritt"); });
Test("T31_no_entry_substitution",()=> { var b=BaseRow();b.Remove("DAT_AD2");b["JoiningDate"]="15.02.2026";var r=Run(Base(b),Month(1,Row())); Check(r.Persons[0].Months[1].Amount>0&&r.Warnings.Any(w=>w.Code=="ENTRY_DATE_ABSENT"),"DAT_AD2 ersetzt"); });
Test("T32_auguan_exit_after_month_cleared",()=> { var p=Run(null,Month(1,Row()),Month(2,Row(claim:"AUGUAN",term:"15.01.2026"))).Persons[0]; Check(p.Months[1].Amount>0,"Austrittsmonat"); Equal(p.Months[2].Amount,null); });
Test("T33_aktan_does_not_cut_exit",()=> { var p=Run(null,Month(1,Row()),Month(2,Row(term:"15.01.2026"))).Persons[0]; Check(p.Months[2].Amount>0,"Unzulassiger Cutoff"); });
Test("T34_blank_termination_not_a_deletion",()=> { var p=Run(null,Month(1,Row(term:"15.01.2026")),Month(2,Row(term:null))).Persons[0]; Check(p.TerminationDate==new DateOnly(2026,1,15),"Termination overwritten"); });
Test("T35_reordered_files_same_results",()=> { var a=Run(null,Month(2,Row()),Month(1,Row())); var b=Run(null,Month(1,Row()),Month(2,Row())); Check(JsonSerializer.Serialize(a,JsonFiles.Options)==JsonSerializer.Serialize(b,JsonFiles.Options),"Order parity"); });
Test("T36_duplicate_months_block",()=>Throws("DUPLICATE_MONTH",()=>Run(null,Month(1,Row()),Month(1,Row()))));
Test("T37_mixed_years_block",()=> { var m=Month(2,Row()) with { Month=new DateOnly(2027,2,1) };Throws("MULTI_YEAR",()=>Run(null,Month(1,Row()),m)); });
Test("T38_empty_selection_blocks",()=>Throws("TXT_SELECTION_EMPTY",()=>Run(null)));
Test("T39_month_filename",()=>Check(MonthReader.ExtractMonth("change_042026.txt")==new DateOnly(2026,4,1),"Month parse"));
Test("T40_bad_month_filename",()=>Throws("MONTH_FILENAME",()=>MonthReader.ExtractMonth("data.txt")));
Test("T41_bad_month_number",()=>Throws("MONTH_INVALID",()=>MonthReader.ExtractMonth("data_132026.txt")));
Test("T42_parse_german_date",()=>Check(Parse.Date("29.02.2024","date")==new DateOnly(2024,2,29),"Datum"));
Test("T43_bad_date_rejected",()=>Throws("INVALID_DATE",()=>Parse.Date("31.02.2026","date")));
Test("T44_excel_date_serial",()=>Check(Parse.Date(45808d,"date")==new DateOnly(2025,5,31),"Excelserial"));
Test("T45_decimal_comma",()=>Equal(Parse.Number("8116,67","x"),8116.67));
Test("T46_thousands_separator_rejected",()=>Throws("INVALID_NUMBER",()=>Parse.Number("8.116,67","x")));
Test("T47_id_leading_zero_reference_normalization",()=>Check(Parse.Id("001001")=="1001","ID"));
Test("T48_csv_semicolon_and_quoting",()=> { var text="KDMA_IDENT;ARBZEIT_PROZ;BETRAG1;BETRAG1_TYP;ANSPRUCHSTYP;Tarifklasse\n1001;100;8000;ATTC_BAV;AKTAN;10\n";var b=new SourceBlob(Encoding.UTF8.GetBytes(text),new("change_012026.txt",new string('0',64),0));Check(MonthReader.Read(b,new(){TextEncoding="utf-8"}).Rows.Count==1,"CSV"); });
Test("T49_missing_claim_column_blocks",()=> { var b=new SourceBlob(Encoding.UTF8.GetBytes("KDMA_IDENT;ARBZEIT_PROZ;BETRAG1;BETRAG1_TYP;Tarifklasse\n1001;100;8000;ATTC_BAV;10"),new("change_012026.txt",new string('0',64),0));Throws("TXT_SCHEMA",()=>MonthReader.Read(b,new())); });
Test("T50_output_id_is_text_formula_injection_safe",()=> { var r=Run(null,Month(1,Row()));r.Persons[0].Master["Surname"]="=HYPERLINK(\"https://invalid\")";var doc=SpreadsheetWriter.SheetXml(SpreadsheetWriter.Contributions(r));Check(!doc.Descendants(SpreadsheetReader.Main+"f").Any(),"Formula injection"); });
Test("T51_result_roundtrip",()=> { string file=Path.Combine(Path.GetTempPath(),Guid.NewGuid()+".xlsx");try { var r=Run(null,Month(1,Row()));SpreadsheetWriter.Write(file,SpreadsheetWriter.Contributions(r));using var reader=new SpreadsheetReader(File.ReadAllBytes(file));Check(reader.Sheets.Single().Name=="Ergebnis","Sheet");Check(reader.Cells(reader.Sheets[0]).Any(c=>c.Address=="A2"&&Convert.ToString(c.Value)=="1001"),"ID roundtrip"); } finally { File.Delete(file); } });
Test("T52_source_missing_rejected",()=>Throws("INPUT_MISSING",()=>SourceBlob.Read(Path.Combine(Path.GetTempPath(),Guid.NewGuid()+".xlsx"))));
Test("T53_template_unknown_cannot_be_staged",()=> { string file=Path.Combine(Path.GetTempPath(),Guid.NewGuid()+".xlsx");try {SpreadsheetWriter.Write(file,new OutputSheet("Tabelle1",new(){"ClientID"},new(){new(){"1001"}}));var b=SourceBlob.Read(file);Check(!TemplatePreparation.Inspect(b).MatchesKnownIppTemplate,"Identity");Throws("IPP_TEMPLATE_IDENTITY",()=>TemplatePreparation.CreateStagingCopy(b,Run(null,Month(1,Row())),file+".xlsm"));}finally{File.Delete(file);} });
Test("T54_raw_monthly_result_not_accepted_as_baseline",()=> {var b=Base();b.Columns.Add("ATTC_1");Throws("BASELINE_NOT_PRISTINE",()=>Run(b,Month(1,Row())));});
Test("T55_full_demo_pipeline_and_no_pdf_claim",()=>
{
    string output=Path.Combine(Path.GetTempPath(),"MCR_IPP_TEST_"+Guid.NewGuid());
    string baseline=Path.Combine(root,"examples","Bestand_Synthetisch.xlsx");
    var hash=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(baseline)));
    try
    {
        var result=new Pipeline().Execute(new RunRequest { BaselinePath=baseline,TxtPaths=Directory.GetFiles(Path.Combine(root,"examples","Monatsdaten"),"*.txt").ToList(),OutputDirectory=output });
        Check(result.Persons==12&&result.Months==6,"Demoumfang");Check(File.Exists(Path.Combine(result.Directory,"Ergebnis.xlsx")),"Output");Check(result.PdfStatus=="NOT_AUTHORIZED","False readiness");
        Check(hash==Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(baseline))),"Input changed");
    }
    finally { if(Directory.Exists(output))Directory.Delete(output,true); }
});
Test("T56_cancellation_prevents_successful_publish",()=> { using var c=new CancellationTokenSource();c.Cancel();try{new ContributionEngine().Run(Base(),new[]{Month(1,Row())},new(),cancel:c.Token);}catch(OperationCanceledException){return;}throw new Exception("Cancellation ignored");});

Directory.CreateDirectory(Path.Combine(root,"evidence","local"));
string report=Path.Combine(root,"evidence","local","csharp_tests.json");
var failures=results.Count(r=>r.Error is not null);
JsonFiles.Write(report,new { status=failures==0?"PASS":"FAIL",utc=DateTimeOffset.UtcNow,runtime=System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription,operatingSystem=System.Runtime.InteropServices.RuntimeInformation.OSDescription,tests=results.Count,passed=results.Count-failures,failed=failures,vectorComparisons,fullPythonWorkflowParityCertified=false,realExcelComTested=false,details=results.Select(r=>new{name=r.Name,passed=r.Error is null,error=r.Error}) });
var junit=new XDocument(new XElement("testsuite",new XAttribute("name","MCR_IPP"),new XAttribute("tests",results.Count),new XAttribute("failures",failures),results.Select(r=>new XElement("testcase",new XAttribute("name",r.Name),r.Error is null?null:new XElement("failure",r.Error)))));
junit.Save(Path.Combine(root,"evidence","local","csharp_tests.junit.xml"));
Console.WriteLine($"\n{results.Count-failures}/{results.Count} tests; {vectorComparisons} vector comparisons; failures={failures}");
return failures==0?0:1;
