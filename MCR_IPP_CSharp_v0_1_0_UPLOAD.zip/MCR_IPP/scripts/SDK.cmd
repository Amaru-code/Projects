@echo off
rem Called from project-root wrappers. Changes remain inside the caller's SETLOCAL.
if defined IPP_DOTNET goto check
if exist "%CD%\tools\dotnet\dotnet.exe" set "IPP_DOTNET=%CD%\tools\dotnet\dotnet.exe"
if defined IPP_DOTNET goto check
if exist "%CD%\settings.local.txt" set /p "IPP_DOTNET="<"%CD%\settings.local.txt"
if defined IPP_DOTNET goto check
for /f "delims=" %%D in ('where dotnet.exe 2^>nul') do if not defined IPP_DOTNET set "IPP_DOTNET=%%D"
if defined IPP_DOTNET goto check
echo.
echo Ein .NET 10 SDK wird benoetigt. Es wird NICHT heruntergeladen oder installiert.
echo Vorhandene portable dotnet.exe auswaehlen, z.B. aus Ihrem bisherigen CSharp-Projekt.
echo Alternativ das vorhandene SDK nach tools\dotnet kopieren.
set /p "IPP_DOTNET=Vollstaendiger Pfad zu dotnet.exe (leer = Abbruch): "
:check
if not defined IPP_DOTNET exit /b 2
set "IPP_DOTNET=%IPP_DOTNET:"=%"
if not exist "%IPP_DOTNET%" goto invalid
for %%D in ("%IPP_DOTNET%") do set "DOTNET_ROOT=%%~dpD"
set "DOTNET_CLI_HOME=%CD%\.dotnet_home"
set "DOTNET_CLI_TELEMETRY_OPTOUT=1"
set "DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1"
set "DOTNET_CLI_WORKLOAD_UPDATE_NOTIFY_DISABLE=1"
set "DOTNET_MULTILEVEL_LOOKUP=0"
set "MSBUILDDISABLENODEREUSE=1"
set "NUGET_PACKAGES=%CD%\.packages"
"%IPP_DOTNET%" --version
if errorlevel 1 goto invalid
>"%CD%\settings.local.txt" echo "%IPP_DOTNET%"
exit /b 0
:invalid
echo SDK nicht lesbar oder .NET 10 SDK nicht vorhanden. Nur Runtime reicht zum Build nicht.
echo Pruefen Sie settings.local.txt oder tools\dotnet. Keine Firmenrichtlinien aendern.
exit /b 2
