@echo off
setlocal
cd /d "%~dp0"
call BUILD_UND_TEST.cmd
if errorlevel 1 goto failed
call scripts\SDK.cmd
if errorlevel 1 goto failed
"%IPP_DOTNET%" "src\Mcr.Ipp.Desktop\bin\Release\net10.0-windows\Mcr.Ipp.Desktop.dll"
if errorlevel 1 goto failed
exit /b 0
:failed
echo.
echo Start abgebrochen. Details siehe evidence\local.
pause
exit /b 1
