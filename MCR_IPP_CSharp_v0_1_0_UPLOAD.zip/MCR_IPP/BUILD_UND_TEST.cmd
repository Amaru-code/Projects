@echo off
setlocal
cd /d "%~dp0"
call scripts\SDK.cmd
if errorlevel 1 goto failed
if not exist "evidence\local" mkdir "evidence\local"
echo.
echo MCR IPP: Offline-Build ohne NuGet-Downloads...
"%IPP_DOTNET%" restore MCR_IPP.slnx --configfile NuGet.Config --ignore-failed-sources -p:NuGetAudit=false >"evidence\local\build.log" 2>&1
if errorlevel 1 goto failed
"%IPP_DOTNET%" build MCR_IPP.slnx --no-restore --configuration Release --nologo >>"evidence\local\build.log" 2>&1
if errorlevel 1 goto failed
echo MCR IPP: CSharp-Tests und Python-Formelvektoren...
"%IPP_DOTNET%" "tests\Mcr.Ipp.Tests\bin\Release\net10.0\Mcr.Ipp.Tests.dll" "%CD%" >"evidence\local\tests.log" 2>&1
if errorlevel 1 goto failed
type "evidence\local\tests.log"
echo.
echo Build und enthaltene CSharp-Tests PASS. Keine wirtschaftliche IPP/PDF-Freigabe.
exit /b 0
:failed
echo.
echo BUILD/TEST NICHT BESTAETIGT. Die Anwendung wird nicht automatisch gestartet.
if exist "evidence\local\build.log" type "evidence\local\build.log"
if exist "evidence\local\tests.log" type "evidence\local\tests.log"
echo Diagnose: evidence\local. Keine automatischen Downloads, keine Registry-Aenderung.
exit /b 1
