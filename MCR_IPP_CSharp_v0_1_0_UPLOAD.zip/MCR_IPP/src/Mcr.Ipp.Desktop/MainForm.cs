using System.Drawing;
using System.Windows.Forms;
using System.Diagnostics;
using Mcr.Ipp.Core;

namespace Mcr.Ipp.Desktop;

public sealed class MainForm : Form
{
    private readonly TextBox baseline = new() { Dock = DockStyle.Fill, ReadOnly = true };
    private readonly TextBox template = new() { Dock = DockStyle.Fill, ReadOnly = true };
    private readonly TextBox output = new() { Dock = DockStyle.Fill };
    private readonly ListBox txts = new() { Dock = DockStyle.Fill, HorizontalScrollbar = true };
    private readonly TextBox log = new() { Dock = DockStyle.Fill, Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Vertical, BackColor = Color.FromArgb(247,249,252) };
    private readonly Button start = new() { Text = "Beitraege erstellen", AutoSize = true, BackColor = Color.FromArgb(22,93,121), ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
    private readonly Button cancel = new() { Text = "Abbrechen", AutoSize = true, Enabled = false };
    private readonly Button open = new() { Text = "Letzten Lauf oeffnen", AutoSize = true, Enabled = false };
    private readonly CheckBox allowUnknownPersons = new() { Text = "TXT-Personen ausserhalb Bestand mit Warnung ignorieren (wie Python-Left-Join)", AutoSize = true };
    private readonly CheckBox allowMissingTariff = new() { Text = "Unbekannte Tarife mit Warnung zulassen (Python-Referenzverhalten; nicht empfohlen)", AutoSize = true };
    private readonly Label status = new() { Dock = DockStyle.Fill, Text = "Bereit. PDF-Produktion ist in V0.1 nicht freigegeben.", ForeColor = Color.FromArgb(143,72,0), AutoSize = true };
    private readonly List<Control> selectors = new();
    private string? lastRun;
    private CancellationTokenSource? cancellation;
    private readonly string root;

    public MainForm()
    {
        root = FindRoot();
        Text = "MCR IPP | Beitrags- und Dokumentpipeline | 0.1.0";
        ClientSize = new Size(1080,780); MinimumSize = new Size(860,690);
        Font = new Font("Segoe UI", 10); StartPosition = FormStartPosition.CenterScreen;
        BackColor = Color.White;
        var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 9, Padding = new Padding(22) };
        layout.RowStyles.Add(new(SizeType.Absolute,74));
        layout.RowStyles.Add(new(SizeType.Absolute,42));
        layout.RowStyles.Add(new(SizeType.Absolute,130));
        layout.RowStyles.Add(new(SizeType.Absolute,42));
        layout.RowStyles.Add(new(SizeType.Absolute,42));
        layout.RowStyles.Add(new(SizeType.Absolute,74));
        layout.RowStyles.Add(new(SizeType.Absolute,48));
        layout.RowStyles.Add(new(SizeType.Absolute,40));
        layout.RowStyles.Add(new(SizeType.Percent,100));
        var title = new Label { Text = "MCR  /  IPP\nBestand + Monatsdaten → Beitraege → IPP-Vorbereitung", Dock = DockStyle.Fill, Font = new Font("Segoe UI",17,FontStyle.Bold), ForeColor = Color.FromArgb(23,50,77) };
        layout.Controls.Add(title,0,0);
        layout.Controls.Add(Chooser("1  Bestandsvorlage", baseline, () => ChooseFile(baseline, "Bestand mit ClientID, BaseSalary_1 und PartTimeFactor_1", "Excel (*.xlsx;*.xlsm)|*.xlsx;*.xlsm")),0,1);
        var trow = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 3 };
        trow.ColumnStyles.Add(new(SizeType.Absolute,205)); trow.ColumnStyles.Add(new(SizeType.Percent,100)); trow.ColumnStyles.Add(new(SizeType.Absolute,125));
        trow.Controls.Add(new Label { Text = "2  Monats-TXT\nDateinamen: _MMJJJJ", AutoSize = true },0,0); trow.Controls.Add(txts,1,0);
        var tb = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown };
        var select = new Button { Text = "Auswaehlen...", AutoSize = true };
        select.Click += (_,_) => { using var d = new OpenFileDialog { Filter = "Monatsdaten (*.txt)|*.txt", Multiselect = true, Title = "Alle Monatsdateien desselben Jahres" }; if (d.ShowDialog(this)==DialogResult.OK) { txts.Items.Clear(); txts.Items.AddRange(d.FileNames); } };
        var clear = new Button { Text = "Leeren", AutoSize = true }; clear.Click += (_,_) => txts.Items.Clear();
        tb.Controls.Add(select); tb.Controls.Add(clear); selectors.Add(select); selectors.Add(clear); trow.Controls.Add(tb,2,0); layout.Controls.Add(trow,0,2);
        layout.Controls.Add(Chooser("3  IPP.xlsm (optional)", template, () => ChooseFile(template, "Nur die autoritative IPP-Unverfallbarkeitsbescheinigung; keine DC-Datei", "IPP (*.xlsm)|*.xlsm")),0,3);
        layout.Controls.Add(Chooser("4  Ausgabeordner", output, () => { using var d = new FolderBrowserDialog { Description = "Ausgabeordner", SelectedPath = output.Text }; if (d.ShowDialog(this)==DialogResult.OK) output.Text=d.SelectedPath; }),0,4);
        var options = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, WrapContents = false };
        options.Controls.Add(allowUnknownPersons); options.Controls.Add(allowMissingTariff); selectors.Add(allowUnknownPersons); selectors.Add(allowMissingTariff); layout.Controls.Add(options,0,5);
        var actions = new FlowLayoutPanel { Dock = DockStyle.Fill };
        var demo = new Button { Text = "Synthetisches Beispiel laden", AutoSize = true }; demo.Click += (_,_) => LoadDemo(); selectors.Add(demo);
        actions.Controls.Add(start); actions.Controls.Add(cancel); actions.Controls.Add(open); actions.Controls.Add(demo); layout.Controls.Add(actions,0,6);
        layout.Controls.Add(status,0,7); layout.Controls.Add(log,0,8); Controls.Add(layout);
        output.Text = Path.Combine(root,"Output");
        start.Click += async (_,_) => await RunAsync();
        cancel.Click += (_,_) => cancellation?.Cancel();
        open.Click += (_,_) => { if (lastRun is not null) Process.Start(new ProcessStartInfo(lastRun) { UseShellExecute = true }); };
        FormClosing += (_,e) => { if (cancellation is not null) { e.Cancel=true; cancellation.Cancel(); Append("Abbruch angefordert. Bitte Abschluss des laufenden Schritts abwarten."); } };
        Append("V0.1 berechnet Monatsbeitraege nativ in C#. Keine Python-Installation benoetigt.");
        Append("Technische Korrektur: letzte Eckwerte 8116.67 / 12158.33; offenes Enddatum. Keine wirtschaftliche Freigabe.");
        Append("Eine optionale IPP-Kopie erhaelt nur MCR_Status/MCR_Beitraege. Bestehende Imports werden NICHT neu zugeordnet.");
    }
    private Control Chooser(string label, TextBox field, Action action)
    {
        var p = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 3 };
        p.ColumnStyles.Add(new(SizeType.Absolute,205)); p.ColumnStyles.Add(new(SizeType.Percent,100)); p.ColumnStyles.Add(new(SizeType.Absolute,125));
        p.Controls.Add(new Label { Text = label, AutoSize = true, Padding = new Padding(0,5,0,0) },0,0); p.Controls.Add(field,1,0);
        var button = new Button { Text = "Auswaehlen...", AutoSize = true }; button.Click += (_,_) => action(); p.Controls.Add(button,2,0); selectors.Add(button); selectors.Add(field); return p;
    }
    private void ChooseFile(TextBox field, string title, string filter) { using var d = new OpenFileDialog { Title = title, Filter = filter }; if (d.ShowDialog(this)==DialogResult.OK) field.Text=d.FileName; }
    private void LoadDemo()
    {
        baseline.Text=Path.Combine(root,"examples","Bestand_Synthetisch.xlsx"); template.Text=""; txts.Items.Clear();
        if (Directory.Exists(Path.Combine(root,"examples","Monatsdaten"))) txts.Items.AddRange(Directory.GetFiles(Path.Combine(root,"examples","Monatsdaten"),"*.txt").OrderBy(x=>x,StringComparer.Ordinal).ToArray());
        Append("Nur erfundene Demopersonen geladen. Keine IPP-Dokumentvorlage im Paket.");
    }
    private async Task RunAsync()
    {
        if (!File.Exists(baseline.Text) || txts.Items.Count==0) { MessageBox.Show(this,"Bitte Bestandsvorlage und mindestens eine TXT-Datei auswaehlen."); return; }
        var request = new RunRequest { BaselinePath=baseline.Text, TxtPaths=txts.Items.Cast<string>().ToList(), OutputDirectory=output.Text, IppTemplatePath=string.IsNullOrWhiteSpace(template.Text)?null:template.Text, Options=new() { AllowMissingTariff=allowMissingTariff.Checked, AllowUnknownTxtPersons=allowUnknownPersons.Checked } };
        foreach(var c in selectors) c.Enabled=false;
        start.Enabled=false; cancel.Enabled=true; cancellation=new(); var token=cancellation.Token;
        status.Text="Verarbeitung laeuft...";
        try
        {
            var outcome = await Task.Run(()=>new Pipeline().Execute(request, text=>BeginInvoke((Action)(()=>Append(text))),token));
            lastRun=outcome.Directory; open.Enabled=true;
            status.Text=$"{outcome.Persons} Personen / {outcome.Months} Monate; {outcome.Warnings} Hinweise. PDFs: nicht freigegeben.";
            Append("AUSGABE: " + outcome.Directory); Append("IPP-STATUS: " + outcome.IppStatus);
        }
        catch (OperationCanceledException) { status.Text="Abgebrochen; kein erfolgreicher Lauf veroeffentlicht."; Append(status.Text); }
        catch (Exception ex) { status.Text="Lauf abgebrochen. Details im Protokoll."; Append((ex is IppException e?e.Code:ex.GetType().Name)+": "+ex.Message); MessageBox.Show(this,ex.Message,"IPP-Pruefung",MessageBoxButtons.OK,MessageBoxIcon.Warning); }
        finally { cancellation.Dispose(); cancellation=null; foreach(var c in selectors)c.Enabled=true; start.Enabled=true; cancel.Enabled=false; }
    }
    private void Append(string text) => log.AppendText(DateTime.Now.ToString("HH:mm:ss")+"  "+text+Environment.NewLine);
    private static string FindRoot() { var d=new DirectoryInfo(AppContext.BaseDirectory); while(d is not null) { if(File.Exists(Path.Combine(d.FullName,"MCR_IPP.slnx")))return d.FullName; d=d.Parent; } return AppContext.BaseDirectory; }
}
