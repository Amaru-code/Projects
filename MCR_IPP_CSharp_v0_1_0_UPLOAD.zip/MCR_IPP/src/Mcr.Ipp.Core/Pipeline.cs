using System.Security.Cryptography;
using System.Text;

namespace Mcr.Ipp.Core;

public sealed class RunRequest
{
    public string BaselinePath { get; set; } = "";
    public List<string> TxtPaths { get; set; } = new();
    public string OutputDirectory { get; set; } = "";
    public string? IppTemplatePath { get; set; }
    public ContributionOptions Options { get; set; } = new();
}
public sealed record RunOutcome(string Directory, int Persons, int Months, int Warnings, string ContributionStatus, string IppStatus, string PdfStatus);
public sealed class Pipeline
{
    public RunOutcome Execute(RunRequest request, Action<string>? progress = null, CancellationToken token = default)
    {
        if (string.IsNullOrWhiteSpace(request.OutputDirectory)) throw new IppException("OUTPUT_MISSING", "Ausgabeordner fehlt.");
        string output = Path.GetFullPath(request.OutputDirectory); Directory.CreateDirectory(output);
        string runId = "IPP_Run_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + "_" + Guid.NewGuid().ToString("N")[..8];
        string stage = Path.Combine(output, ".inprogress_" + runId), final = Path.Combine(output, runId);
        Directory.CreateDirectory(stage);
        try
        {
            progress?.Invoke("Lese Bestandsvorlage...");
            var baselineBlob = SourceBlob.Read(request.BaselinePath);
            using var reader = new SpreadsheetReader(baselineBlob.Bytes);
            var table = reader.Baseline(request.Options.BaselineSheet);
            var sources = request.TxtPaths.Select(SourceBlob.Read).ToList();
            var monthInputs = sources.Select(b => MonthReader.Read(b, request.Options)).ToList();
            var result = new ContributionEngine().Run(table, monthInputs, request.Options, progress, token);
            result.Inputs.Insert(0, baselineBlob.Info);
            progress?.Invoke("Schreibe Ergebnis.xlsx und Rechenprotokoll...");
            SpreadsheetWriter.Write(Path.Combine(stage, "Ergebnis.xlsx"), SpreadsheetWriter.Contributions(result));
            JsonFiles.Write(Path.Combine(stage, "Contribution_Result.json"), result);
            JsonFiles.Write(Path.Combine(stage, "Options_used.json"), request.Options);
            WriteTrace(Path.Combine(stage, "Monatsprotokoll.csv"), result);
            string ippStatus = "NOT_REQUESTED";
            if (!string.IsNullOrWhiteSpace(request.IppTemplatePath))
            {
                token.ThrowIfCancellationRequested(); progress?.Invoke("Pruefe ausschliesslich die IPP-Vorlage...");
                try
                {
                    var ipp = SourceBlob.Read(request.IppTemplatePath);
                    var audit = TemplatePreparation.Inspect(ipp);
                    JsonFiles.Write(Path.Combine(stage, "IPP_Pruefung.json"), audit);
                    if (audit.MatchesKnownIppTemplate)
                    {
                        var proof = TemplatePreparation.CreateStagingCopy(ipp, result, Path.Combine(stage, "IPP_VORBEREITUNG_NICHT_FREIGEGEBEN.xlsm"));
                        JsonFiles.Write(Path.Combine(stage, "IPP_Staging_Proof.json"), proof);
                        ippStatus = "STAGING_ONLY_MAPPING_NOT_BOUND";
                    }
                    else ippStatus = "BLOCKED_TEMPLATE_IDENTITY";
                }
                catch (IppException ex)
                {
                    ippStatus = "BLOCKED_" + ex.Code;
                    JsonFiles.Write(Path.Combine(stage, "IPP_Fehler.json"), new { code = ex.Code, message = ex.Message });
                }
            }
            token.ThrowIfCancellationRequested();
            var outcome = new RunOutcome(final, result.Persons.Count, result.Months.Count, result.Warnings.Count, "EXPORTED_NOT_BUSINESS_CERTIFIED", ippStatus, "NOT_AUTHORIZED");
            JsonFiles.Write(Path.Combine(stage, "Run_Report.json"), new { app = "MCR_IPP", version = "0.1.0", scope = "IPP_NOT_DC", utc = DateTimeOffset.UtcNow, outcome, inputs = result.Inputs, rules = ContributionFormula.Periods, pythonReceivedPatch = "T01 decimal-comma tuple; T02 open-ended sentinel", fullPythonParityCertified = false, economicRulesApproved = false, pdfsCreated = 0 });
            File.WriteAllText(Path.Combine(stage, "00_LAUF_LESEN.txt"), $"MCR IPP V0.1\n\nBEITRAEGE: {result.Persons.Count} Personen / {result.Months.Count} Monate exportiert.\nWARNUNGEN: {result.Warnings.Count}; Monatsprotokoll und JSON pruefen.\nIPP: {ippStatus}\nPDF: NICHT FREIGEGEBEN. Keine freigegebene LNW erstellt.\n\nErgebnis.xlsx ist der C#-Beitragsoutput. Eine IPP_VORBEREITUNG-Kopie enthaelt nur zusaetzliche Staging-Blaetter; alte Importdaten sind unveraendert.\nKeine automatische Beitragsbereitstellung, Saldenuebernahme oder Fallentscheidung.\nAlle Originaldateien wurden nur gelesen.\n", new UTF8Encoding(false));
            var manifest = Directory.GetFiles(stage).OrderBy(Path.GetFileName, StringComparer.Ordinal).Select(p => new { file = Path.GetFileName(p), bytes = new FileInfo(p).Length, sha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(p))) }).ToList();
            JsonFiles.Write(Path.Combine(stage, "Manifest.json"), manifest);
            Directory.Move(stage, final); progress?.Invoke("Beitragsexport erstellt. IPP/PDF bleibt gesondert gekennzeichnet.");
            return outcome;
        }
        catch (Exception ex)
        {
            // Preserve failed run evidence locally; never label partial output as successful.
            try { JsonFiles.Write(Path.Combine(stage, "FAILED.json"), new { status = "FAILED_NOT_PUBLISHED", code = ex is IppException ie ? ie.Code : ex.GetType().Name, message = ex.Message }); }
            catch { /* Original exception must be retained. */ }
            throw;
        }
    }
    private static void WriteTrace(string path, ContributionResult result)
    {
        string Q(string? s) => "\"" + (s ?? "").Replace("\"", "\"\"") + "\"";
        using var writer = new StreamWriter(path, false, new UTF8Encoding(true));
        writer.WriteLine("ClientID;Monat;ATTC_Quelle;TZG_Quelle;Tarifklasse;Gruende");
        foreach (var p in result.Persons) foreach (var r in p.Months.Values)
            writer.WriteLine(string.Join(";", Q(p.ClientId), Q(r.SalaryDate.ToString("yyyy-MM")), Q(r.AttcSource), Q(r.TzgSource), Q(r.EffectiveTariff?.ToString(Parse.Inv)), Q(string.Join("|", r.Reasons))));
    }
}
