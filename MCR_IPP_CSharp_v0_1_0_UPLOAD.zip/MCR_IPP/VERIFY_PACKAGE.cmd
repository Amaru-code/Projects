@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -File "%~dp0scripts\Verify-Package.ps1"
if errorlevel 1 echo Verification failed or local script policy blocked execution. Do not change company policies.
pause
