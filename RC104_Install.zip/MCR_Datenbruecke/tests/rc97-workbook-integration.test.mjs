/** Execute real orchestration functions with read/action adapters, never Edge,
 * COMARCH or Windows storage. Tests assert failure boundaries and data flow. */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import vm from 'node:vm';
import {requireThat as need} from '../lib/core.mjs';
import Identity from '../lib/identity-evidence.cjs';
import Prep from '../lib/ticket-prep.cjs';
import {requireReviewedMember} from '../lib/member-review.mjs';
import {descriptionWithStatus,sourceUSCLines} from '../lib/status-columns.mjs';
import {STANDARD_ANSWER_NOTE} from '../lib/mail-history-audit.mjs';
import {persistWorkbookContactAfterCompletion} from '../lib/workbook-contact-completion.mjs';
import {approveChangedRecipient} from '../lib/phase1-recipient-approval.mjs';
import {describeTicketIssue,dedupeTicketIssues,errorCsv} from '../lib/ticket-error-catalog.mjs';
import {routeFixedAssessment} from '../lib/route-fixed-policy.mjs';

function extract(file,start,end){
 const source=fs.readFileSync(new URL('../'+file,import.meta.url),'utf8'),a=source.indexOf(start),b=end?source.indexOf(end,a+start.length):source.length;
 assert(a>=0&&b>a,'Expected production function boundaries');
 return source.slice(a,b).replace(/^export /,'');
}
const problem=code=>Object.assign(new Error(code),{code});

function masterHarness({refreshFailure=false,contactFailure=false}={}){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC97-INTEGRATION-')),events=[];
 fs.mkdirSync(path.join(root,'private_data'));let currentHash='OLD_SNAPSHOT',report;
 const context={root,need,fs,path,process:{platform:'win32'},VERSION:'TEST',
  verifyPackage:()=>({manifestSha256:'manifest'}),plainPath:()=>{},stamp:()=> '2026-11-18T10-00-00_test',
  assertNoMigrationPriority:()=>{},windowsIdle:()=>{},log:()=>{},ask:()=>assert.fail('Unexpected prompt'),
  writeJSON:()=>{},phase2Run:async()=>{},completionOnly:async()=>{},real:async()=>assert.fail('No live runner'),
  refreshLiveWorkbook:()=>{events.push('read-workbook');if(refreshFailure)throw problem('WORKBOOK_UNAVAILABLE');currentHash='FRESH_SNAPSHOT';},
  flushWorkbookContacts:()=>{events.push('flush-contacts');if(contactFailure)throw problem('EACCES');return {applied:0,pending:0};},
  loadActiveMapping:()=>{events.push('bind-mapping');return {fileHash:currentHash};}};
 vm.createContext(context);
 context.mappingMaintenance=vm.runInContext('('+extract('tools/cli.mjs','async function mappingMaintenance(','/** RC83:')+')',context);
 const run=vm.runInContext('('+extract('tools/cli.mjs','export async function masterRun(','async function completionOnly(')+')',context);
 return {events,get report(){return report;},close:()=>fs.rmSync(root,{recursive:true,force:true}),
  run:(approval='MASTER_START')=>run({rootDir:root,confirm:async()=>approval,output:()=>{},write:(_f,value)=>{report=value;events.push('master-checkpoint');throw problem('TEST_CHECKPOINT_REACHED');}})};
}
test('RC97 integration: CLI refreshes XLSX before binding the master report and pilot snapshot',async()=>{
 const h=masterHarness();try{
  await assert.rejects(h.run(),{code:'TEST_CHECKPOINT_REACHED'});
  assert.deepEqual(h.events,['read-workbook','flush-contacts','bind-mapping','master-checkpoint']);
  assert.equal(h.report.mappingSha256,'FRESH_SNAPSHOT');
 }finally{h.close();}
});
test('RC97 integration: unavailable XLSX prevents master binding; cancelled start performs no maintenance',async()=>{
 const h=masterHarness({refreshFailure:true});try{
  await assert.rejects(h.run(),{code:'WORKBOOK_UNAVAILABLE'});assert.deepEqual(h.events,['read-workbook']);assert.equal(h.report,undefined);
 }finally{h.close();}
 const cancelled=masterHarness();try{await assert.rejects(cancelled.run('ABBRUCH'),{code:'MASTER_ABORT'});assert.deepEqual(cancelled.events,[]);}finally{cancelled.close();}
});
test('RC97 integration: a contact-queue recovery error does not discard refreshed master data',async()=>{
 const h=masterHarness({contactFailure:true});try{await assert.rejects(h.run(),{code:'TEST_CHECKPOINT_REACHED'});assert.equal(h.report.mappingSha256,'FRESH_SNAPSHOT');}finally{h.close();}
});

function ticketHarness({changedBeforeDraft=false,changedBeforeSend=false,changedMemberAtApproval=false,wwidMismatch=false,contactFailure=false,saveFailure=false,manualRecipientChange=false}={}){
 const events=[],contactArgs=[],logs=[],member={id:'99900001',firstName:'Erika',lastName:'Beispiel',source:'MEMBER_PROFILE_VERIFIED',profileIdMatches:true};
 const final={...member,wwid:wwidMismatch?'99900002':'99900001',wwidEvidence:'EXACT_LABELED_WWID'};
 const person={firstName:'Erika',lastName:'Beispiel'},review={reviewed:false},mail={senderName:'Erika Beispiel',senderEmail:'erika.beispiel@example.invalid',body:'Bitte senden Sie mir meine Informationen.'};
 const languageEvidence={language:'DE',reason:'CURRENT_ORIGINAL_MESSAGE'},entry={description:'USC 10/ DC',gender:'F',rowCount:1,descriptionLines:['USC 10/ DC']};
 const mapping={map:{},fileHash:'FRESH'},row={ticketId:'99990001'},journal={pending:[],set:(id,state)=>{events.push(state);if(state==='COMPLETE')journal.pending=[];}};
 const diag={mapping:{fileHash:'FRESH'},send:{verified:false},save:{verified:false},loop:{processed:0,myTasksProcessed:0,queueProcessed:0,processedTickets:[]}};
 let approved=false,written=false,recipientReads=0;
 const freshMember=async()=>{events.push('read-profile');return changedMemberAtApproval&&approved?{...final,id:'99900002'}:final;};
 const UI={ensureEdit:async()=>{},assertTicket:async(_p,id)=>assert.equal(id,row.ticketId),acknowledgementAlreadyInHistory:async()=>false,
  additionalDescriptionState:async()=>({ok:true,editable:true,value:''}),writeDescription:async()=>{written=true;events.push('write-description');return {ok:true};},verifyDescription:async()=>true,
  editor:async()=>({ok:true}),recipient:async()=>({ok:true,address:manualRecipientChange&&++recipientReads>1?'alternate@example.invalid':mail.senderEmail}),fixedFieldValues:async()=>({...Prep.FIXED}),selectedMember:freshMember};
 const context={need,Identity,Prep,approveChangedRecipient,root:'TEST_ROOT',DEMO:false,PILOT:true,DEMO_SCENARIO:'normal',diag,UI,log:x=>logs.push(x),show:()=>{},sleep:async()=>{},
  sourceUSCLines,descriptionWithStatus,STANDARD_ANSWER_NOTE,requireReviewedMember,readBoundMemberProfile:freshMember,
  ask:async()=>manualRecipientChange?'JA':assert.fail('Unexpected prompt'),mailAndPerson:async()=>({mail,person,evidence:Identity.buildEvidence(mail)}),
  selectMember:async()=>({member,person,review}),resolveMemberMapping:()=>({kind:'FOUND',method:'EXACT',lookupId:'99900001',entry}),
  resolveTicketLanguage:async()=>languageEvidence,fixedFields:async()=>{},overlay:{gate:{mode:'MANUAL'},authorize:async()=>({mode:'MANUAL'})},
  ensurePreSendDescription:async()=>({restored:false}),approveOperatorReply:async({expectedText})=>{approved=true;events.push('reply-approved');return {text:expectedText,edited:false};},
  loadActiveMapping:()=>mapping,assertLiveWorkbookCurrent:()=>{events.push('check-workbook');if((changedBeforeDraft&&!written)||(changedBeforeSend&&approved))throw problem('WORKBOOK_DATA_CHANGED');},
  sendOnce:async(_page,_rl,_id,_journal,recipient)=>{events.push('send');if(manualRecipientChange)assert.equal(recipient,'alternate@example.invalid');diag.send={verified:true,ackMode:'BOUND_NEW_OUTGOING_HISTORY',htmlDialogs:2,jsDialogs:0,successNotices:2};journal.pending=[{ticketId:row.ticketId,state:'SENT_CONFIRMED'}];},
  validSendAcknowledgements:()=>true,markAfterVerifiedSend:async()=>{},commitDescription:async()=>{},
  saveOnce:async()=>events.push('save'),verifySaved:async()=>{events.push('save-readback');if(saveFailure)throw problem('SAVE_UNVERIFIED');diag.save={verified:true,verification:'TEST_SERVER_READBACK'};},
  reportColumnsAfterSave:()=>{},ticketAudit:()=>events.push('audit-completed'),persistWorkbookContactAfterCompletion,
  recordWorkbookContact:async args=>{events.push('contact');contactArgs.push(args);assert.equal(diag.loop.processed,1);assert.equal(journal.pending.length,0);if(contactFailure)throw problem('EACCES');return {status:'APPLIED'};}};
 const run=vm.runInNewContext('('+extract('src/local-bot-full-run.mjs','async function processTicket(','async function diagnostic(')+')',context);
 return {events,contactArgs,logs,diag,final,mapping,mail,languageEvidence,run:()=>run({},mapping,{},row,'IN_BEARBEITUNG',{},journal)};
}
test('RC104 integration: a manually changed recipient is approved, sent once and not learned as a member contact',async()=>{
 const h=ticketHarness({manualRecipientChange:true});await h.run();
 assert.equal(h.events.filter(x=>x==='send').length,1);
 assert.equal(h.events.filter(x=>x==='save').length,1);
 assert.equal(h.contactArgs.length,0);
 assert(h.logs.some(x=>x.includes('P1_RECIPIENT_OPERATOR_APPROVED')));
 assert(h.logs.some(x=>x.includes('BESTAND_EMPFANGER_WECHSEL_NICHT_GESCHRIEBEN')));
});
test('RC97 integration: workbook update during identity/language review blocks first description and all ticket actions',async()=>{
 const h=ticketHarness({changedBeforeDraft:true});await assert.rejects(h.run(),{code:'WORKBOOK_DATA_CHANGED'});
 assert(!h.events.includes('write-description'));assert(!h.events.includes('send'));assert(!h.events.includes('contact'));
});
test('RC97 integration: workbook update after draft approval blocks send and contact learning',async()=>{
 const h=ticketHarness({changedBeforeSend:true});await assert.rejects(h.run(),{code:'WORKBOOK_DATA_CHANGED'});
 assert(h.events.includes('reply-approved'));assert(!h.events.includes('send'));assert(!h.events.includes('save'));assert(!h.events.includes('contact'));
});
test('RC97 integration: profile changed during edited-reply approval cannot send or become an Excel contact',async()=>{
 const h=ticketHarness({changedMemberAtApproval:true});await assert.rejects(h.run(),{code:'MEMBER_CHANGED'});assert(!h.events.includes('send'));assert(!h.events.includes('contact'));
});
test('RC97 integration: freshly labeled WWID mismatch blocks send before contact update',async()=>{
 const h=ticketHarness({wwidMismatch:true});await assert.rejects(h.run(),{code:'MEMBER_WWID_MAPPING_CONFLICT'});assert(!h.events.includes('send'));assert(!h.events.includes('contact'));
});
test('RC97 integration: original mail, fresh profile/WWID and original language reach contact writer after journal completion',async()=>{
 const h=ticketHarness();await h.run();assert.equal(h.contactArgs.length,1);
 const args=h.contactArgs[0];assert.equal(args.member,h.final);assert.equal(args.active,h.mapping);assert.equal(args.mail,h.mail);assert.equal(args.languageEvidence,h.languageEvidence);assert.equal(args.recipient,h.mail.senderEmail);
 assert(h.events.indexOf('save-readback')<h.events.indexOf('COMPLETE'));assert(h.events.indexOf('COMPLETE')<h.events.indexOf('contact'));assert(h.events.indexOf('audit-completed')<h.events.indexOf('contact'));
 assert.equal(h.events.filter(x=>x==='send').length,1);assert.equal(h.events.filter(x=>x==='save').length,1);
});
test('RC97 integration: contact persistence error leaves journal, successful ticket count and pilot proof complete',async()=>{
 const h=ticketHarness({contactFailure:true});await h.run();assert.equal(h.diag.loop.processed,1);assert.equal(h.diag.workbookContactWarnings,1);
 assert.equal(h.events.filter(x=>x==='send').length,1);assert.equal(h.events.filter(x=>x==='save').length,1);assert.equal(h.events.filter(x=>x==='contact').length,1);
 assert(h.logs.some(x=>x.startsWith('PASS PILOT_STATUS_UND_SPEICHERUNG_VERIFIZIERT')));
});
test('RC97 integration: unverified ticket save cannot create a personal contact record',async()=>{
 const h=ticketHarness({saveFailure:true});await assert.rejects(h.run(),{code:'SAVE_UNVERIFIED'});assert(!h.events.includes('COMPLETE'));assert(!h.events.includes('contact'));assert.equal(h.diag.loop.processed,0);
});

function forwardHarness({changeAtDestination=false,changeAtAssignment=false}={}){
 const events=[],row={ticketId:'99990001'},person={firstName:'Erika',lastName:'Beispiel'},member={id:'99900001',...person,source:'MEMBER_PROFILE_VERIFIED',profileIdMatches:true};
 const evidence=Identity.buildEvidence({senderName:'Erika Beispiel',senderEmail:'erika.beispiel@example.invalid',body:'Bitte helfen Sie mir.'});
 const active={fileHash:'FRESH'},diag={mapping:active,save:{verification:'TEST_SERVER_READBACK'},loop:{processed:0,forwarded:0,myTasksProcessed:0,queueProcessed:0,processedTickets:[]}};
 let changed=false;
 const journal={beginForward:()=>events.push('BEGIN_FORWARD'),forwardSet:(_id,state)=>events.push(state)};
 const context={root:'TEST_ROOT',need,Prep,DEMO:false,PILOT:false,DEMO_SCENARIO:'normal',diag,NOT_FOUND_DESCRIPTION:'Nicht im Bestand',requireReviewedMember,routeFixedAssessment,
  loadActiveMapping:()=>active,assertLiveWorkbookCurrent:()=>{events.push('check-workbook');if(changed)throw problem('WORKBOOK_DATA_CHANGED');},
  chooseForwardDestination:async()=>{changed=changeAtDestination;return {key:'mark',account:'mark.baindl',display:'Baindl Mark'};},ask:async()=>assert.fail('Unexpected prompt'),log:()=>{},sleep:async()=>{},show:()=>{},ticketAudit:()=>events.push('audit'),
  UI:{writeDescription:async()=>{events.push('description');return {ok:true};},verifyDescription:async()=>true,selectedMember:async()=>member,fixedFieldValues:async()=>({...Prep.FIXED}),navigateToScope:async()=>({rows:[row]}),openTicket:async()=>{},ensureEdit:async()=>{},assertTicket:async()=>{}},
  fixedFields:async()=>{},saveOnce:async()=>events.push('save'),verifySaved:async()=>events.push('save-readback'),
  selectAssignee:async()=>{changed=changeAtAssignment;return {method:'EXACT_TEST_ACCOUNT'};},
  forwardOnce:async(_page,_dest,{beforeClick})=>{await beforeClick();events.push('forward-click');return {source:'TEST_SERVER_READBACK'};}};
 const run=vm.runInNewContext('('+extract('src/local-bot-full-run.mjs','async function forwardMissingPerson(','async function processTicket(')+')',context);
 return {events,diag,run:()=>run({}, {},row,'IN_BEARBEITUNG',journal,person,evidence,member,{reviewed:false},{})};
}
test('RC97 integration: workbook changed during destination selection blocks the missing-person draft',async()=>{
 const h=forwardHarness({changeAtDestination:true});await assert.rejects(h.run(),{code:'WORKBOOK_DATA_CHANGED'});assert.deepEqual(h.events,['check-workbook']);assert.equal(h.diag.loop.processed,0);
});
test('RC97 integration: workbook changed during assignee selection blocks forward intent and click after saved note',async()=>{
 const h=forwardHarness({changeAtAssignment:true});await assert.rejects(h.run(),{code:'WORKBOOK_DATA_CHANGED'});assert(h.events.includes('ROUTE_SAVED_VERIFIED'));assert(!h.events.includes('FORWARD_INTENT'));assert(!h.events.includes('forward-click'));assert.equal(h.diag.loop.processed,0);
});

function phase2Harness({firstCheckFails=false,changeDuringReview=false}={}){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC97-P2-INTEGRATION-')),events=[],row={ticketId:'99990001',descriptionValue:'USC 10/ DC\nStandardantwort versendet\nUnbekannte Anfrage'};let changed=false;
 const controls={ready:async()=>{},protectInput:()=>()=>{},update:()=>{},start:()=>{},close:()=>{},error:()=>{},complete:()=>{}};
 const context={root,need,fs,path,VERSION:'TEST',loadActiveMapping:()=>({map:{}}),plainPath:()=>{},stamp:()=> 'test-run',
  readPhase2MemberEvidence:async()=>{},createPhase2TicketConsole:()=>controls,writeJSON:()=>{},readJSON:()=>null,ledger:()=>({pending:[]}),
  assertLiveWorkbookCurrent:()=>{events.push('check-workbook');if(firstCheckFails||changed)throw problem('WORKBOOK_DATA_CHANGED');},
  UI:{navigateToScope:async()=>events.push('navigate')},readPhase2Queue:async()=>({ok:true,rows:[row]}),
  phase2Inventory:()=>({}),phase2BlockingIds:()=>[],phase2WorkRule:()=>({kind:'MARK_DIRECT'}),
  inspectPhase2Tickets:()=>({items:[],counts:{visible:1,ready:1}}),phase2IntakeSummary:()=>({stats:{visible:1,readyWithoutBlock:1}}),
  choosePhase2Candidate:()=>({row,kind:'MARK_DIRECT',skipped:[]}),phase2Admission:()=>({rule:{requiresRequestConfirmation:true}}),
  approveUnclassifiedRequest:async()=>{events.push('operator-reviewed');changed=changeDuringReview;return 'MARK';},capturePhase2RouteList:async()=>({}),
  handlePhase2Work:async()=>{events.push('ticket-handler');return {status:'ROUTED_VERIFIED'};},
  phase2Completion:()=>({}),completionLines:()=>[],describeTicketIssue,dedupeTicketIssues,errorCsv};
 const run=vm.runInNewContext('('+extract('src/phase2-run.mjs','export async function phase2Run(')+')',context);
 return {events,close:()=>fs.rmSync(root,{recursive:true,force:true}),run:()=>run({root,masterApproved:true,maxTickets:1,log:()=>{},session:{page:{cdp:{}},rl:{close:()=>{}}}})};
}
test('RC97 integration: Phase 2 rejects changed workbook before queue navigation',async()=>{
 const h=phase2Harness({firstCheckFails:true});try{await assert.rejects(h.run(),{code:'WORKBOOK_DATA_CHANGED'});assert.deepEqual(h.events,['check-workbook']);}finally{h.close();}
});
test('RC97 integration: Phase 2 rechecks workbook after request review and before ticket handler',async()=>{
 const h=phase2Harness({changeDuringReview:true});try{await assert.rejects(h.run(),{code:'WORKBOOK_DATA_CHANGED'});assert.deepEqual(h.events,['check-workbook','navigate','operator-reviewed','check-workbook']);assert(!h.events.includes('ticket-handler'));}finally{h.close();}
});
test('RC97 integration: stable Phase 2 workbook permits the requested handler once',async()=>{
 const h=phase2Harness();try{const r=await h.run();assert.equal(r.processed,1);assert.equal(h.events.filter(x=>x==='ticket-handler').length,1);assert.equal(h.events.filter(x=>x==='check-workbook').length,2);}finally{h.close();}
});
