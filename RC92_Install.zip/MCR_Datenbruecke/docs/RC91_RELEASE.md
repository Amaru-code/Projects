# MCR DATENBRUECKE 0.8.1-rc.91 – Ticketfehler transparent und begrenzt fortsetzen

## Anlass (13.11.2026)

Der RC90-Master hatte in der sichtbar gebundenen COMARCH-Liste zwei offene
Tickets: 88078437 (DB-Direktweiterleitung, wiederholt widerspruechliche
Beschreibung zwischen Listenansicht und Editor) und 89112070 (`OTHER_REQUEST`,
kein eindeutiger bekannter Auftrag in der dritten Textzeile). Beide blieben
unangetastet; der Master setzte die Suche fort, fand aber keine weitere
freigegebene Aktion. Erstaunlich wenig hilfreiches Ergebnis fuer den Operator.

## Neu

1. Fehlerkatalog (`lib/ticket-error-catalog.mjs`) mit stabilen Codes, deutschen
   Ursachen, naechsten Schritten sowie unveraenderten technischen Originalcodes.
   Unbekannte Fehler werden nicht unter einem einzigen generischen Fehler
   verschluckt, sondern erhalten einen deterministischen code-abhaengigen
   Kennzeichner.
2. Phase-2-JSON und -CSV mit jedem nicht erledigten sichtbaren Ticket,
   `fehlercode`, `ursache_code`, Erklaerung, naechster Schritt. Berichte liegen
   lokal in `.runtime/phase2` und erhalten keine E-Mail-Texte oder Namen.
3. Eine valide, nicht leere dritte Beschreibungszeile, die keine bekannte
   \"Moechte\"-Anfrage ist, wird als moegliche unbekannte Kundenanfrage
   angeboten. Erst nach Sichtpruefung und ausdruecklicher Freigabe (ENTER)
   kann sie **ohne E-Mail** als `MARK_DIRECT` bearbeitet werden.
   `UEBERSPRINGEN` protokolliert den offenen Fall. Ein leerer Auftrag wird
   weiterhin nicht automatisch weitergeleitet.
4. Ein eng begrenzter, rein lesender/browserbezogener Einzelfehler kann ohne
   vorhandenes oder neu angelegtes Phase-2-Journal unter gesicherter
   erneuter Bindung der eigenen Vorgangsliste isoliert werden. Andere
   Tickets koennen fortgesetzt werden. Unklare Schreib-/Upload-/Sende-
   oder Weiterleitungsvorgaenge bleiben sicherheitsbedingte Unterbrechungen.
5. Der Abschluss nennt die Anzahl der erledigten und offen gebliebenen Tickets
   explizit: \"Alle derzeit automatisch bearbeitbaren Tickets bearbeitet;
   X Tickets konnten nicht bearbeitet werden\" mit den Einzelfehlercodes.
   Die Aussage umfasst ausschliesslich die gebundenen sichtbaren Listen.

## Unveraendert

Kein automatischer zweiter Versand-, Save-, Upload- oder Weiterleitungsklick;
keine Mutation alter Journale und kein Ignorieren geaenderter Member- oder
Ticket-IDs. Das Alt-Ticket 88078437 wird **nicht** als repariert ausgegeben,
solange die Beschreibung nicht zweifelsfrei bestaetigt werden kann.

## Test und Installation

Bisherige Regressionstests, neue Unit-Tests, Paketpruefsummen und
Offline-Update/Rueckweg RC90 -> RC91 -> RC90 vor Produktionsfreigabe pruefen.
RC91 ersetzt nur Software. `private_data`, Browserprofil, lokale Journale,
Ticket- und Konfigurationsdaten bleiben erhalten. Kein COMARCH-Echtlauf beim
Paketbau.
