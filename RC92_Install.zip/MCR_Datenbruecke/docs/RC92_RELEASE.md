# MCR DATENBRUECKE 0.8.1-rc.92

## Korrektur: Ticket 89112070 (unbekannte dritte Anfragezeile)

RC91 zeigte `ENTER = Mark`, akzeptierte aber bei manueller Eingabe nicht `Mark`, sondern nur ENTER oder `WEITERLEITEN`. Dadurch stoppte der komplette MASTER RUN vor jeder Änderung. RC92 akzeptiert ENTER, MARK, WEITERLEITEN, MARK.BAINDL und JA als Freigabe **nur für die interne Weiterleitung ohne E-Mail**. Bei Tippfehlern wird bis zu dreimal nachgefragt; danach wird das Ticket ohne Klick und mit offenem Prüfstatus zurückgestellt. `ABBRUCH` bleibt eine bewusste Bedienerentscheidung.

## Nur ein Edge-Prozess im Master

Der MASTER RUN startet Edge einmal im übergeordneten Menüprozess. Jeder Phase-1-Unterlauf erhält einen **neuen CDP-Tab**, nicht die alte DOM-Seite; Phase 2 verbindet sich im selben Edge und bindet ebenfalls einen neuen Tab. Die Unterprozesse dürfen den Master-Edge nicht beenden. Der Master schließt Edge am Laufende. Bei einem Sicherheitsstopp kann der Bediener Edge zur Prüfung offen lassen. Alle Bestandsdaten, getrennten Nachweise, Journale und Freigaben bleiben erhalten.

Einzelne Standalone-Läufe von Menü 3 / 4 bleiben eigenständig. Die Wiederverwendung erfolgt nur innerhalb eines vom Master gestarteten Laufes und ist an die Manifest- und Mapping-Bindung, Master-ID und Besitzer-PID gebunden.

**Kein neu automatisierter Versand.** COMARCH-Echtlauf bleibt beaufsichtigt; mögliche Schreib- oder Weiterleitungsklicks werden nie blind wiederholt.
