# MCR DATENBRUECKE 0.8.1-rc.90 — sicheres Weiterlesen statt Master-Abbruch

## Beobachtung am 13.11.2026

Master Phase 1: keine geeigneten Tickets; Phase 2: Ticket 88078437, DB_DIRECT,
alt gespeichertes Arbeitsjournal, aber `STOP P2_WORK_READBACK_UNCLEAR` nach dem
Oeffnen der alten COMARCH-Beschreibung. Der RC87-Ausweichweg reagierte nur auf
`P2_WORK_SERVER_VALUES` und beendete daher in RC89 den gesamten Master.

## Fix

* Beschreibung im **gleichen verifizierten Ticket** bis zu viermal **nur lesen**,
  nach ICEfaces-Teilaktualisierungen mit kurzer begrenzter Wartezeit.
* Falls weiterhin nicht lesbar, **ausschliesslich** bei DB_DIRECT/MARK_DIRECT
  mit vorhandenem, unveraendertem **vor EXECUTE_INTENT** Arbeitsjournal und
  unveraendertem/fehlendem PDF-Journal das Ticket zur manuellen Nachpruefung
  zurueckstellen. Das Ticket gilt NICHT als erledigt.
* Ein separater Sicherheitsgrund `P2_WORK_READBACK_UNCLEAR_REVIEW_REQUIRED`
  steht in Abschlussbericht und offenen Faellen.
* Nach Rueckstellung die uebrigen sichtbaren Intel-Tickets weiter prüfen.
  Bei keiner weiteren zulässigen Arbeit: regulärer, eingeschraenkter Abschluss
  „Alle zu bearbeitenden Tickets bearbeitet“, mit offenen Ticket-IDs.
* **Kein** Wiederholungsklick auf Senden, Speichern oder Weiterleiten; kein
  Journal geloescht oder ueberschrieben. Fremde/veraenderte Beschreibungen,
  unklarer Ticketbezug, laufende Schreibaktionen und unbekannte Fehler
  bleiben bewusst gesperrt und duerfen den Master unterbrechen.

## Testumfang

Neue Unit-Tests: vier Leseversuche, id-gebundene Wiederholung, fehlerhafte
Beschreibung, unveraenderte/veraenderte Journale, alte PDF-Versuche,
EXECUTE_INTENT, Ablehnung aller sonstigen Fehlercodes. Vollstaendige
bestehende Testsuite und Offline-Update/Rueckweg separat pruefen.

## Echte Umgebung

Keine COMARCH-Verbindung beim Paketbau. RC90 zuerst beaufsichtigt ueber
Menue 5 starten; 88078437 muss ggf. als offen erscheinen, nicht als erledigt.
