import test from 'node:test';
import assert from 'node:assert/strict';
import {parseMarkApproval,approveUnclassifiedRequest} from '../lib/phase2-request-approval.mjs';
import {browserLeaseEnvironment,validateBrowserLease} from '../lib/master-browser-lease.mjs';
import {launchBrowser,connectBrowser,attachFreshPage,findEdgeExecutable} from '../lib/cdp.mjs';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';

const report=()=>({schema:'MCR_MASTER_RUN_V1',id:'2026-11-13T10-13-00_c80fd141',state:'PHASE1',manifestSha256:'a'.repeat(64),mappingSha256:'b'.repeat(64)});
const claim=()=>browserLeaseEnvironment({port:38911,masterId:report().id,ownerPid:25812});

test('RC92: ENTER, Mark and approved aliases all confirm only internal Mark routing',()=>{
 for(const v of ['', 'Mark','MARK','mark.baindl','Baindl Mark','WEITERLEITEN','JA'])assert.equal(parseMarkApproval(v),'MARK',v);
 for(const v of ['UEBERSPRINGEN','Nein','ÜBERSPRINGEN'])assert.equal(parseMarkApproval(v),'SKIP');
 for(const v of ['ABBRUCH','STOP'])assert.equal(parseMarkApproval(v),'ABORT');
 for(const v of ['Entwurf speichern','Senden','123','no',''])if(v!=='')assert.equal(parseMarkApproval(v),'RETRY');
});
test('RC92: a mistype is reprompted, not fatal; then Mark is accepted',async()=>{
 const answers=['Mrak','Mark'],logs=[];let asks=0;
 const d=await approveUnclassifiedRequest({ticketId:'89112070',ask:async q=>{assert.match(q,/ENTER \/ MARK/);asks++;return answers.shift();},log:s=>logs.push(s)});
 assert.equal(d,'MARK');assert.equal(asks,2);assert.ok(logs.some(s=>s.includes('P2_ANFRAGE_EINGABE_UNBEKANNT')));
});
test('RC92: three unknown answers defer ticket without side effects',async()=>{
 const logs=[];const d=await approveUnclassifiedRequest({ticketId:'89112070',ask:async()=> '???',log:s=>logs.push(s)});
 assert.equal(d,'SKIP');assert.equal(logs.filter(s=>s.includes('EINGABE_UNBEKANNT')).length,3);
});
test('RC92: explicit ABORT is distinguished from mistaken text',async()=>{
 const d=await approveUnclassifiedRequest({ticketId:'89112070',ask:async()=> 'ABBRUCH'});
 assert.equal(d,'ABORT');
 await assert.rejects(approveUnclassifiedRequest({ticketId:'foo',ask:async()=>''}),{code:'P2_REQUEST_TICKET_ID'});
});
test('RC92: shared Edge lease is bound to parent process, master, manifest, mapping and phase',()=>{
 const env=claim();const c=validateBrowserLease(env,{parentPid:25812,report:report(),manifestSha:'a'.repeat(64),mappingSha:'b'.repeat(64)});
 assert.deepEqual(c,{port:38911,masterId:report().id,ownerPid:25812});
 assert.equal(validateBrowserLease({},{}),null);
 for(const overrides of [{parentPid:25813},{report:{...report(),state:'PHASE2'}},{report:{...report(),id:'other-run'}},{manifestSha:'c'.repeat(64)},{mappingSha:'d'.repeat(64)}]){
  assert.throws(()=>validateBrowserLease(env,{parentPid:25812,report:report(),manifestSha:'a'.repeat(64),mappingSha:'b'.repeat(64),...overrides}));
 }
 assert.throws(()=>validateBrowserLease({...env,MCR_MASTER_BROWSER_PORT:'0'},{parentPid:25812,report:report(),manifestSha:'a'.repeat(64),mappingSha:'b'.repeat(64)}));
 assert.throws(()=>validateBrowserLease({MCR_MASTER_BROWSER_PORT:'38911'},{}));
});

test('RC92: two independent CDP sessions open two fresh pages within ONE owned Chromium process', {timeout:35000},async(t)=>{
 if(process.platform==='win32'){t.skip('Standalone Windows Edge is tested by the supervised COMARCH master run.');return;}
 const exe=findEdgeExecutable('auto');if(!exe){t.skip('No Chromium installed.');return;}
 const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'mcr-rc92-browser-'));
 let browser,cdp1,cdp2;
 try{
  browser=await launchBrowser({executable:exe,userDataDir:path.join(tmp,'profile'),startUrl:'about:blank',headless:true,
   extraArgs:['--no-sandbox','--disable-dev-shm-usage','--disable-background-networking','--disable-component-update','--disable-sync']});
  ({cdp:cdp1}=await connectBrowser(browser.port));const p1=await attachFreshPage(cdp1,'about:blank');
  const one=await p1.call(()=>({url:location.href}));assert.equal(one.url,'about:blank');
  // Emulate a separate phase by disconnecting, WITHOUT closing Chromium.
  cdp1.close();cdp1=null;
  ({cdp:cdp2}=await connectBrowser(browser.port));const p2=await attachFreshPage(cdp2,'about:blank');
  assert.notEqual(p1.targetId,p2.targetId);
  assert.equal((await p2.call(()=>location.href)),'about:blank');
  const {targetInfos}=await cdp2.send('Target.getTargets');
  assert.ok(targetInfos.some(x=>x.targetId===p1.targetId));
  assert.ok(targetInfos.some(x=>x.targetId===p2.targetId));
  await cdp2.send('Target.closeTarget',{targetId:p1.targetId});
  await cdp2.send('Target.closeTarget',{targetId:p2.targetId});
 }finally{
  try{cdp1?.close();}catch{}try{cdp2?.close();}catch{}
  try{browser?.child?.kill('SIGTERM');}catch{}
  // Keep cleanup bounded; browser shutdown is not the evidence of test success.
  try{fs.rmSync(tmp,{recursive:true,force:true,maxRetries:2,retryDelay:100});}catch{}
 }
});
