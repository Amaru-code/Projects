import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {ROOT} from './helpers.mjs';
import {phase2Completion,masterCompletion,completionLines} from '../lib/master-completion.mjs';
import {masterRun} from '../tools/cli.mjs';

const p1={status:'VERIFIED',pilotAttempts:[{processed:1}],batches:[{processed:0}],manualIdentityReviewObserved:0};
const p2={status:'VERIFIED_VISIBLE_SCOPE',processed:1,runId:'p2-test',scope:'VISIBLE_MY_TASKS_NO_PAGINATION',skipped:[]};
function fixture(){const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC89-FINISH-'));
 const root=path.join(tmp,'MCR_Datenbruecke');
 fs.cpSync(ROOT,root,{recursive:true,filter:p=>!p.includes('/.runtime/')&&!p.includes('/diagnostics/')&&!p.includes('/Ergebnis/')});
 return {root,close:()=>fs.rmSync(tmp,{recursive:true,force:true,maxRetries:4,retryDelay:100})};
}

test('RC89: zero unresolved means all tickets in verified scope, never global invisible pages',()=>{
 const x=masterCompletion({phase1:p1,phase2:p2});
 assert.equal(x.kind,'ALL_TICKETS');assert.equal(x.label,'Alle Tickets bearbeitet');
 assert.equal(x.openCount,0);assert.equal(x.fullyResolved,true);
 assert.match(completionLines(x).join('\n'),/geprueften, sichtbaren Bereich/);
});
test('RC89: the observed RC88 run shows two open IDs and does not claim all complete',()=>{
 const x=masterCompletion({phase1:p1,phase2:{...p2,skipped:[
  {ticketId:'88078437',reason:'P2_WORK_SERVER_VALUES_REVIEW_REQUIRED'},
  {ticketId:'89112070',reason:'OTHER_REQUEST'}]}});
 assert.equal(x.kind,'ALL_ELIGIBLE_TICKETS');assert.equal(x.label,'Alle zu bearbeitenden Tickets bearbeitet');
 assert.equal(x.openCount,2);assert.equal(x.fullyResolved,false);
 const lines=completionLines(x).join('\n');
 assert.match(lines,/88078437 \| P2_WORK_SERVER_VALUES_REVIEW_REQUIRED/);
 assert.match(lines,/89112070 \| OTHER_REQUEST/);
 assert.match(lines,/Diese Faelle wurden NICHT als bearbeitet verbucht/);
});
test('RC89: duplicate skips must not inflate open tickets, unknown skips must never be thrown away',()=>{
 const x=phase2Completion({processed:0,skipped:[{ticketId:'88078437',reason:'WORK_JOURNAL_REVIEW_REQUIRED'},
  {ticketId:'88078437',reason:'WORK_JOURNAL_REVIEW_REQUIRED'},
  {reason:'UNKNOWN_REASON'}]});
 assert.equal(x.openCount,2);assert.equal(x.fullyResolved,false);
 assert.equal(x.openTickets[1].ticketId,null);
});
test('RC89: incomplete phase1 identity review keeps explicit open status even with no p2 skips',()=>{
 const x=masterCompletion({phase1:{...p1,manualIdentityReviewObserved:2},phase2:p2});
 assert.equal(x.kind,'ALL_ELIGIBLE_TICKETS');
 assert.match(completionLines(x).join('\n'),/2 Identitaetspruefung/);
 assert.equal(x.openCount,0);assert.equal(x.phase1IdentityReviews,2);
});
test('RC89: missing Phase2 verification never yields either completion label',()=>{
 assert.throws(()=>masterCompletion({phase1:p1,phase2:{...p2,status:'STOP_REVIEW_REQUIRED'}}),{code:'COMPLETION_NOT_VERIFIED'});
 assert.throws(()=>phase2Completion({processed:-1,skipped:[]}),{code:'COMPLETION_PROOF'});
});
test('RC89: real orchestrator leaves old audit state but writes two-end completion and open-case records',async()=>{
 const f=fixture(),output=[];
 try{
  const r=await masterRun({rootDir:f.root,confirm:async()=> 'MASTER_START',output:x=>output.push(x),
   runPhase1:async pilot=>pilot?{pilotVerified:true,runId:'pilot-test-id',processed:1}:
    {verified:true,processed:0,runId:'batch-test-id',finishReason:'NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS'},
   runPhase2:async()=>({status:'COMPLETED_VISIBLE_SCOPE',processed:1,runId:'p2-id',
    scope:'VISIBLE_MY_TASKS_NO_PAGINATION',skipped:[{ticketId:'89112070',reason:'OTHER_REQUEST'}]})});
  assert.equal(r.state,'PARTIAL_PHASE2_OPEN_CASES');
  assert.equal(r.completion.kind,'ALL_ELIGIBLE_TICKETS');
  assert.ok(output.some(s=>s.includes('OFFEN: 89112070 | OTHER_REQUEST')));
  const reports=fs.readdirSync(path.join(f.root,'.runtime/master'));
  assert.equal(reports.length,1);
  const persisted=JSON.parse(fs.readFileSync(path.join(f.root,'.runtime/master',reports[0])));
  assert.equal(persisted.completion.openCount,1);
 }finally{f.close();}
});
test('RC89: unexpected interrupted run is a pause, never a third successful completion',async()=>{
 const f=fixture(),output=[];
 try{
  await assert.rejects(masterRun({rootDir:f.root,confirm:async()=> 'MASTER_START',output:x=>output.push(x),
   runPhase1:async pilot=>{if(pilot)return {pilotVerified:true,processed:1,runId:'pilot-test-id'};
    throw Object.assign(new Error('unconfirmed'),{code:'LIVE_NOT_VERIFIED'});},
   runPhase2:async()=>{throw new Error('no p2');}}),/unconfirmed/);
  const report=JSON.parse(fs.readFileSync(path.join(f.root,'.runtime/master',fs.readdirSync(path.join(f.root,'.runtime/master'))[0])));
  assert.equal(report.state,'STOP_REVIEW_REQUIRED');
  assert.equal(report.completion,undefined);
  assert.ok(output.some(s=>s.includes('MASTER_UNTERBROCHEN: LIVE_NOT_VERIFIED')));
 }finally{f.close();}
});
