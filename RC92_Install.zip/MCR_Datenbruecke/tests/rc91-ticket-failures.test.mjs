import test from 'node:test';
import assert from 'node:assert/strict';
import {describeTicketIssue,dedupeTicketIssues,errorCsv} from '../lib/ticket-error-catalog.mjs';
import {phase2Completion,masterCompletion,completionLines} from '../lib/master-completion.mjs';
import {descriptionPhase2Rule} from '../lib/phase2-description.mjs';
import {choosePhase2Candidate} from '../src/phase2-run.mjs';
import {mayDeferPhase2PreWrite} from '../lib/phase2-safe-defer.mjs';
const row=(ticketId,descriptionValue)=>({ticketId,descriptionValue,intelGroupVerified:true});
const raw='USC 20/ PP+\nStandardantwort versendet\nBitte um Beratung zum Schreiben';

test('RC91: observed 88078437 has stable coded explanation and safe next action',()=>{
 const r=describeTicketIssue({ticketId:'88078437',reason:'P2_WORK_SERVER_VALUES_REVIEW_REQUIRED'});
 assert.equal(r.errorCode,'MCR-P2-201');assert.match(r.cause,/Gespeicherte/i);
 assert.equal(r.ticketResolved,false);assert.equal(r.writeAuthorized,false);
 assert.match(r.nextAction,/Arbeitsjournal/);
});
test('RC91: observed OTHER_REQUEST gets unique code and a human triage action',()=>{
 const r=describeTicketIssue({ticketId:'89112070',reason:'OTHER_REQUEST'});
 assert.equal(r.errorCode,'MCR-P2-301');assert.match(r.nextAction,/Mark/);
});
test('RC91: unknown reason is not lost or shown as completed',()=>{
 const r=describeTicketIssue({ticketId:'89112070',reason:'A_PROBLEM_NOT_YET_CATALOGUED'});
 assert.match(r.errorCode,/^MCR-P2-U[A-F0-9]{7}$/);assert.equal(r.reason,'A_PROBLEM_NOT_YET_CATALOGUED');
 assert.equal(r.ticketResolved,false);
});
test('RC91: summary dedupes ID, includes code and precisely counts open tickets',()=>{
 const completed=phase2Completion({processed:7,skipped:[
  {ticketId:'88078437',reason:'P2_WORK_SERVER_VALUES_REVIEW_REQUIRED'},
  {ticketId:'89112070',reason:'OTHER_REQUEST'},
  {ticketId:'88078437',reason:'P2_WORK_SERVER_VALUES_REVIEW_REQUIRED'},
 ]});
 assert.equal(completed.openCount,2);assert.equal(completed.notProcessed,2);
 const msg=completionLines(completed,{master:false}).join('\n');
 assert.match(msg,/7|Phase 2 weitergeleitet/);
 assert.match(msg,/2 Tickets konnten nicht bearbeitet werden/);
 assert.match(msg,/MCR-P2-201/);assert.match(msg,/MCR-P2-301/);
 assert.match(msg,/Keine erneute Weiterleitung/);
});
test('RC91: anonymized CSV has code, explanation and no raw request text',()=>{
 const records=dedupeTicketIssues([{ticketId:'88078437',reason:'P2_WORK_SERVER_VALUES'},
  {ticketId:'89112070',reason:'OTHER_REQUEST'}]);
 assert.equal(records.length,2);
 const csv=errorCsv(records);
 assert.match(csv,/fehlercode/);assert.match(csv,/MCR-P2-201/);assert.match(csv,/MCR-P2-301/);
 assert.ok(!csv.includes('USC 20'));
});
test('RC91: unknown third-line request without Moechte can reach Mark only after review',()=>{
 const r=descriptionPhase2Rule(row('89112070',raw));
 assert.equal(r.kind,'MARK_DIRECT');assert.equal(r.requiresRequestConfirmation,true);
 assert.equal(r.route,'DIRECT');
 const c=choosePhase2Candidate([row('89112070',raw)]);
 assert.equal(c.row?.ticketId,'89112070');assert.equal(c.kind,'MARK_DIRECT');
});
test('RC91: no request line stays unclassified, no automatic forwarding',()=>{
 const r=descriptionPhase2Rule(row('89112070','USC 20/ PP+\nStandardantwort versendet'));
 assert.equal(r.kind,'SKIP');assert.equal(r.reason,'NOT_REQUESTED');
 assert.equal(choosePhase2Candidate([row('89112070','USC 20/ PP+\nStandardantwort versendet')]).row,null);
});
test('RC91: no automatic continuation after unknown write or unbound ticket',()=>{
 assert.equal(mayDeferPhase2PreWrite({code:'ACTION_NOT_UNIQUE'}),true);
 assert.equal(mayDeferPhase2PreWrite({code:'P2_WORK_SAVE_NETWORK'}),false);
 assert.equal(mayDeferPhase2PreWrite({code:'TICKET_NOT_BOUND'}),false);
 assert.equal(mayDeferPhase2PreWrite({code:'ACTION_NOT_UNIQUE',afterWork:{state:'EDIT_INTENT'}}),false);
});
test('RC91: no invisible scope is described as fully completed',()=>{
 const r=masterCompletion({phase1:{status:'VERIFIED',pilotAttempts:[],batches:[],manualIdentityReviewObserved:0},
  phase2:{status:'VERIFIED_VISIBLE_SCOPE',processed:0,skipped:[{ticketId:'88078437',reason:'P2_WORK_SERVER_VALUES_REVIEW_REQUIRED'}]}});
 assert.equal(r.fullyResolved,false);
 assert.match(completionLines(r).join('\n'),/1 Ticket konnte nicht bearbeitet werden/);
 assert.match(completionLines(r).join('\n'),/sichtbaren Bereich/);
});
