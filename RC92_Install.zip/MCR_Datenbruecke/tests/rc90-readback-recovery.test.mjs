import test from 'node:test';
import assert from 'node:assert/strict';
import {readBoundedWorkDescription} from '../lib/phase2-readback-retry.mjs';
import {mayDeferPhase2Readback} from '../lib/phase2-safe-defer.mjs';
import {phase2Completion,completionLines} from '../lib/master-completion.mjs';

const original='USC 20 / DB\nStandardantwort versendet\nMöchte Anfrage';
const previousWork=()=>({
 schema:'MCR_PHASE2_WORK_JOURNAL_V1',ticketId:'88078437',rule:'DB_DIRECT',
 state:'REVIEW_VERIFIED',descriptionBefore:original,descriptionAfter:original,
 events:[{state:'TICKET_SAVE_VERIFIED',at:'2026-11-12'},{state:'REVIEW_VERIFIED',at:'2026-11-12'}]
});
const claim=(options={})=>({
 code:'P2_WORK_READBACK_UNCLEAR',kind:'DB_DIRECT',
 beforeWork:previousWork(),afterWork:previousWork(),beforePdf:null,afterPdf:null,...options
});

test('RC90: bounded read-only retry succeeds on transient ICEfaces NOT_FOUND',async()=>{
 const states=[{ok:false,state:'NOT_FOUND'}, {ok:false,state:'AMBIGUOUS'},
  {ok:true,value:original,editable:false,state:'EXACT_ADDITIONAL_DESCRIPTION'}];
 const readCalls=[],assertCalls=[],delayCalls=[],logs=[];
 const result=await readBoundedWorkDescription({},'88078437',{
  read:async()=>{readCalls.push(1);return states.shift();},
  assertTicket:async(_page,id)=>assertCalls.push(id),
  delay:async millis=>delayCalls.push(millis),log:x=>logs.push(x),
 });
 assert.equal(result.ok,true);assert.equal(result.value,original);assert.equal(result.attempts,3);
 assert.equal(readCalls.length,3);assert.deepEqual(assertCalls,['88078437','88078437','88078437']);
 assert.deepEqual(delayCalls,[220,440]);
 assert.ok(logs.some(x=>x.startsWith('PASS P2_WORK_READBACK_RETRY')));
});

test('RC90: permanently unreadable description returns unverified, never synthesizes row text',async()=>{
 let reads=0;const delays=[];const logs=[];
 const result=await readBoundedWorkDescription({},'88078437',{
  read:async()=>{reads++;return {ok:false,state:'NOT_FOUND'};},
  assertTicket:async()=>true,delay:async ms=>delays.push(ms),log:x=>logs.push(x),
 });
 assert.equal(reads,4);assert.deepEqual(delays,[220,440,660]);
 assert.equal(result.ok,false);assert.equal(result.value,undefined);assert.equal(result.attempts,4);
 assert.ok(logs.some(x=>x.startsWith('P2_WORK_READBACK_UNCLEAR_AFTER_RETRY')));
});

test('RC90: incorrect ticket id prevents a fallback and cannot be bypassed',async()=>{
 let reads=0;
 await assert.rejects(readBoundedWorkDescription({},'88078437',{
  read:async()=>{reads++;return {ok:false,state:'NOT_FOUND'};},
  assertTicket:async()=>{throw Object.assign(new Error('other ticket'),{code:'TICKET_NOT_BOUND'});},
  delay:async()=>{},
 }),{code:'TICKET_NOT_BOUND'});
 assert.equal(reads,0);
});

test('RC90: never hide browser exceptions or conflicting readable descriptions',async()=>{
 const error=Object.assign(new Error('CDP disconnected'),{code:'CDP_DISCONNECTED'});
 await assert.rejects(readBoundedWorkDescription({},'88078437',{
  read:async()=>{throw error;},assertTicket:async()=>true,delay:async()=>{},
 }),{code:'CDP_DISCONNECTED'});
 const r=await readBoundedWorkDescription({},'88078437',{
  read:async()=>({ok:true,value:'Fremder geaenderter Status'}),
  assertTicket:async()=>true,delay:async()=>{},
 });
 assert.equal(r.ok,true);assert.notEqual(r.value,original);
 // Such a readable conflict is handled by the existing fail-closed guard;
 // the new deferral accepts only the explicit UNREADABLE code.
 assert.equal(mayDeferPhase2Readback(claim({code:'P2_WORK_READBACK_CONFLICT'})),false);
});

test('RC90: observed old DB journal is safe to defer only if byte-identical',()=>{
 assert.equal(mayDeferPhase2Readback(claim()),true);
 assert.equal(mayDeferPhase2Readback(claim({code:'P2_WORK_SERVER_VALUES'})),true);
 const after=previousWork();after.events.push({state:'SAVE_REPAIR_AUTHORIZED',at:'2026-11-13'});
 assert.equal(mayDeferPhase2Readback(claim({afterWork:after})),false);
 assert.equal(mayDeferPhase2Readback(claim({afterWork:null})),false);
 assert.equal(mayDeferPhase2Readback(claim({beforeWork:null})),false);
});

test('RC90: no deferral for previous upload or started execution',()=>{
 assert.equal(mayDeferPhase2Readback(claim({beforePdf:{state:'UPLOAD_VERIFIED'}})),false);
 assert.equal(mayDeferPhase2Readback(claim({afterPdf:{state:'DRAFT_SAVE_INTENT'}})),false);
 const exec=previousWork();exec.events.push({state:'EXECUTE_INTENT',at:'2026-11-13'});
 assert.equal(mayDeferPhase2Readback(claim({beforeWork:exec,afterWork:structuredClone(exec)})),false);
 for(const state of ['EXECUTE_INTENT','PREPARED','EDIT_INTENT','TICKET_SAVE_INTENT']){
  const j=previousWork();j.state=state;
  assert.equal(mayDeferPhase2Readback(claim({beforeWork:j,afterWork:structuredClone(j)})),false,state);
 }
});

test('RC90: no deferral of unbound ticket, unknown error or non-direct work',()=>{
 assert.equal(mayDeferPhase2Readback(claim({code:'P2_WORK_SAVE_NETWORK'})),false);
 assert.equal(mayDeferPhase2Readback(claim({code:'P2_WORK_SERVER_DESCRIPTION_CONFLICT'})),false);
 assert.equal(mayDeferPhase2Readback(claim({kind:'ACCOUNT_STATEMENT'})),false);
 const bad=previousWork();bad.ticketId='xyz';
 assert.equal(mayDeferPhase2Readback(claim({beforeWork:bad,afterWork:structuredClone(bad)})),false);
 const noSchema=previousWork();delete noSchema.schema;
 assert.equal(mayDeferPhase2Readback(claim({beforeWork:noSchema,afterWork:structuredClone(noSchema)})),false);
});

test('RC90: an unreadable resumed ticket remains visibly OPEN in the final report',()=>{
 const c=phase2Completion({processed:0,skipped:[
  {ticketId:'88078437',reason:'P2_WORK_READBACK_UNCLEAR_REVIEW_REQUIRED',writeAttempted:false},
  {ticketId:'89112070',reason:'OTHER_REQUEST'},
 ]});
 assert.equal(c.kind,'ALL_ELIGIBLE_TICKETS');assert.equal(c.fullyResolved,false);
 assert.equal(c.openCount,2);assert.equal(c.processed,0);
 const out=completionLines(c,{master:false}).join('\n');
 assert.match(out,/88078437 \| P2_WORK_READBACK_UNCLEAR_REVIEW_REQUIRED/);
 assert.match(out,/89112070 \| OTHER_REQUEST/);
 assert.match(out,/Diese Faelle wurden NICHT als bearbeitet verbucht/);
});

test('RC90: observed legacy RC76 DB-marker journal restored to original text is read-only deferrable',()=>{
 const legacy=previousWork();
 legacy.descriptionAfter=original+'\nBearbeitet not reviewed';
 legacy.events.push({state:'RC77_DIRECT_CLEANUP_VERIFIED',at:'2026-11-12'});
 // The prior RC77 cleanup succeeded on an earlier date. On this run no
 // additional event or click occurred and the fresh detail textarea was
 // hidden/unreadable after the already verified original-text observation.
 assert.equal(mayDeferPhase2Readback(claim({beforeWork:legacy,afterWork:structuredClone(legacy)})),true);
 const mut=structuredClone(legacy);mut.events.push({state:'RC77_DIRECT_CLEANUP_SAVE_CLICK_INTENT',at:'2026-11-13'});
 assert.equal(mayDeferPhase2Readback(claim({beforeWork:legacy,afterWork:mut})),false);
});
