options(stringsAsFactors = FALSE)
Sys.setlocale("LC_NUMERIC", "C")

CASE_ID <- "MCR_LNW_001"
SEPKEY <- "\u001f"
MARKER_PREFIXES <- c(">>>>", "<<<<", ">>>", "<<<", "====")
METADATA_LABELS <- c(
  "dateiname", "datei name", "info", "informationen", "groesse", "größe",
  "dateigroesse", "dateigröße", "typ", "dateityp", "erstellungsdatum",
  "erstellt am", "geaendert am", "geändert am", "aenderungsdatum", "änderungsdatum"
)
KNOWN_HEADER_TERMS <- c(
  "erstellungsdatum", "vermittlerzentrale", "vermittlernummer", "kundenidentifikator",
  "kunden_identifikator", "depotnummer", "unterdepot", "wkn", "isin", "kag",
  "fondsname", "depotvariante", "anteilspreis", "waehrungpreis", "währungpreis",
  "produktart", "bestandstuecke", "bestand_stuecke", "bestandbetrag", "bestand_betrag",
  "firmenid", "dat", "wwid", "umsatzstuecke", "umsatz_stuecke", "abgerechneterpreis",
  "anlbetrag", "zahlbetrag", "umsatzart", "devisenkurs", "kursdatum", "zvf_id_alt",
  "zvu_id_alt", "eroeffnungsdatum", "währung_bestand", "waehrung_bestand",
  "schlusstag", "bonus", "status", "id-mercer"
)
DU_PROFILE_MARKERS <- c("umsatzstuecke", "abgerechneterpreis", "anlbetrag", "zahlbetrag", "umsatzart", "devisenkurs", "zvfidalt", "zvuidalt")
DP_PROFILE_MARKERS <- c("anteilspreis", "eroeffnungsdatum", "bestandstuecke", "bestandbetrag", "waehrungbestand", "schlusstag", "idmercer")
ALLOWED_COMPANY_IDS <- c(
  "MERCER_0003", "MERCER_0351", "MERCER_0342", "MERCER_0352", "MERCER_0343",
  "INTELJP_0003", "INTELSK_0001", "INTELSK_0002", "INTELSK_0003", "MERCER_XXX"
)
COMPANY_ID_COLUMN_INDEX <- 25L
DU_TARGET_HEADERS <- c(
  "Erstellungsdatum", "Vermittlerzentrale", "Vermittlernummer", "Kunden_Identifikator",
  "WWID", "Depotnummer", "Unterdepot", "WKN", "ISIN", "KAG", "Fondsname", "Depotvariante",
  "UmsatzStuecke", "Abgerechneter Preis", "WaehrungPreis", "Anlbetrag", "Waehrung Anlagebetrag",
  "ZahlBetrag", "Waehrung Zahlungsbetrag", "Umsatzart", "Storno", "Produktart", "leer2", "leer3",
  "leer4", "leer5", "Antweilwert", "Waehrung_ Antweilwert", "Devisenkurs", "Kursdatum", "ZVF_ID_ALT",
  "ZVU_ID_ALT", "FirmenID", "DAT"
)
DP_TARGET_HEADERS <- c(
  "Erstellungsdatum", "Vermittlerzentrale", "Vermittlernummer", "Kunden_Identifikator", "Leer1", "WWID",
  "Depotnummer", "Unterdepot", "WKN", "ISIN", "KAG", "Fondsname", "Depotvariante", "Anteilspreis",
  "Waehrung_Preis", "Eroeffnungsdatum", "Produktart", "Bestand_Stuecke", "Bestand_Betrag", "Waehrung_Bestand",
  "Schlusstag", "Bonus", "Status", "ID-Mercer", "FirmenID", "DAT"
)

clean_cell <- function(value) {
  if (length(value) == 0L || is.null(value) || is.na(value)) return("")
  trimws(gsub("\u00A0", " ", as.character(value), fixed = TRUE))
}

normalize_header <- function(value) {
  s <- tolower(clean_cell(value))
  s <- gsub("ä", "ae", s, fixed=TRUE)
  s <- gsub("ö", "oe", s, fixed=TRUE)
  s <- gsub("ü", "ue", s, fixed=TRUE)
  s <- gsub("ß", "ss", s, fixed=TRUE)
  gsub("[^a-z0-9]+", "", s, perl=TRUE)
}

normalize_text <- function(value) {
  s <- tolower(clean_cell(value))
  gsub("\\s+", " ", s, perl=TRUE)
}

FUND_ALIASES <- c(
  "dws inv.foc.europe fc" = "dwsi-eur.eq.hi.co.fc",
  "dwsi-eur.eq.hi.co.fc anteile" = "dwsi-eur.eq.hi.co.fc"
)
normalize_fund <- function(value) {
  n <- normalize_text(value)
  if (n %in% names(FUND_ALIASES)) unname(FUND_ALIASES[[n]]) else n
}

normalize_wwid <- function(value) {
  s <- clean_cell(value)
  if (grepl("^\\d+\\.0$", s)) s <- substr(s, 1L, nchar(s)-2L)
  s
}

as_number <- function(value) {
  if (length(value)==0L || is.null(value) || is.na(value) || identical(value, "")) return(0.0)
  if (is.numeric(value)) {
    v <- as.numeric(value)
    return(if (is.finite(v)) v else 0.0)
  }
  text <- gsub(" ", "", trimws(as.character(value)), fixed=TRUE)
  if (!nzchar(text)) return(0.0)
  comma <- regexpr(",[^,]*$", text, perl=TRUE)[1]
  dot <- regexpr("\\.[^.]*$", text, perl=TRUE)[1]
  if (comma > 0L && dot > 0L) {
    if (comma > dot) {
      text <- gsub(".", "", text, fixed=TRUE)
      text <- sub(",", ".", text, fixed=TRUE)
    } else {
      text <- gsub(",", "", text, fixed=TRUE)
    }
  } else if (comma > 0L) {
    text <- gsub(".", "", text, fixed=TRUE)
    text <- sub(",", ".", text, fixed=TRUE)
  }
  v <- suppressWarnings(as.numeric(text))
  if (is.na(v) || !is.finite(v)) 0.0 else v
}

is_distribution <- function(value) {
  t <- normalize_text(value)
  startsWith(t, "ertragsaussch") && endsWith(t, "ttung")
}

profile_from_filename <- function(name) {
  stem <- tolower(trimws(tools::file_path_sans_ext(basename(as.character(name)))))
  if (grepl("^du($|[_\\-[:space:]])", stem, perl=TRUE)) return("du")
  if (grepl("^dp($|[_\\-[:space:]])", stem, perl=TRUE)) return("dp")
  NULL
}

at <- function(row, i) {
  if (is.null(i) || is.na(i) || i < 1L || i > length(row)) "" else row[[i]]
}

header_map <- function(header) {
  out <- integer(0); names(out) <- character(0)
  for (i in seq_along(header)) {
    n <- normalize_header(header[[i]])
    if (nzchar(n) && !(n %in% names(out))) out[n] <- i
  }
  out
}

find_index <- function(map, aliases) {
  for (a in aliases) {
    n <- normalize_header(a)
    if (n %in% names(map)) return(unname(map[[n]]))
  }
  stop(paste0("Required master header missing: ", paste(aliases, collapse=" / ")))
}

parse_delimited_line <- function(line, delimiter) {
  # Fast path for the overwhelmingly common case: no quoting.
  # strsplit() is implemented in native R code and avoids the previous
  # character-by-character R loop / repeated paste0 allocations.
  if (!grepl('"', line, fixed=TRUE)) {
    return(strsplit(line, delimiter, fixed=TRUE)[[1]])
  }

  # Quoted fallback: keep the exact legacy parser semantics.
  chars <- strsplit(line, "", fixed=TRUE)[[1]]
  result <- character(0); field <- ""; quoted <- FALSE; i <- 1L
  while (i <= length(chars)) {
    ch <- chars[[i]]
    if (ch == '"') {
      if (quoted && i < length(chars) && chars[[i+1L]] == '"') {
        field <- paste0(field, '"'); i <- i + 1L
      } else {
        quoted <- !quoted
      }
    } else if (ch == delimiter && !quoted) {
      result <- c(result, field); field <- ""
    } else {
      field <- paste0(field, ch)
    }
    i <- i + 1L
  }
  c(result, field)
}

read_text_with_fallback <- function(path) {
  sz <- file.info(path)$size
  con <- file(path, "rb"); on.exit(close(con), add=TRUE)
  b <- readBin(con, what="raw", n=sz)
  if (length(b)>=3L && identical(as.integer(b[1:3]), c(239L,187L,191L))) b <- b[-(1:3)]
  rawtxt <- rawToChar(b)
  utf <- suppressWarnings(iconv(rawtxt, from="UTF-8", to="UTF-8", sub=NA))
  if (!is.na(utf)) return(utf)
  cp <- suppressWarnings(iconv(rawtxt, from="CP1252", to="UTF-8", sub=""))
  if (is.na(cp)) rawtxt else cp
}

mapping_clean <- function(value) {
  text <- clean_cell(value)
  text <- gsub("^'+|'+$", "", text, perl=TRUE)
  if (grepl("^\\d+\\.0$", text)) text <- substr(text,1L,nchar(text)-2L)
  text
}
normalize_depot <- function(value) gsub("\\s+", "", mapping_clean(value), perl=TRUE)
normalize_underdepot <- function(value) {
  text <- mapping_clean(value)
  if (!nzchar(text)) return("")
  digits <- gsub("\\D", "", text, perl=TRUE)
  if (!nzchar(digits)) return(text)
  stripped <- sub("^0+", "", digits, perl=TRUE)
  if (!nzchar(stripped)) "0" else stripped
}
normalize_mapping_wwid <- mapping_clean

load_mapping <- function(path) {
  text <- read_text_with_fallback(path)
  text <- gsub("\r\n|\r", "\n", text, perl=TRUE)
  lines <- strsplit(text, "\n", fixed=TRUE)[[1]]
  exact <- new.env(hash=TRUE, parent=emptyenv())
  fallback <- new.env(hash=TRUE, parent=emptyenv())
  conflicts <- new.env(hash=TRUE, parent=emptyenv())
  if (length(lines)==0L || !nzchar(trimws(lines[[1]]))) return(list(exact=exact,fallback=fallback,conflicts=conflicts))
  header <- parse_delimited_line(sub("^\ufeff", "", lines[[1]], perl=TRUE), ";")
  fields <- setNames(seq_along(header), tolower(trimws(header)))
  fidx <- function(...) {
    ns <- c(...)
    for (n in ns) if (tolower(n) %in% names(fields)) return(unname(fields[[tolower(n)]]))
    NA_integer_
  }
  wi <- fidx("WWID"); d1 <- fidx("Depot_01","Depo_01"); d2 <- fidx("Depot_02","Depo_02"); d3 <- fidx("Depot_03","Depo_03")
  if (any(is.na(c(wi,d1,d2,d3)))) stop("WWID mapping header is incomplete.")
  cand <- new.env(hash=TRUE, parent=emptyenv()); depcand <- new.env(hash=TRUE,parent=emptyenv())
  if (length(lines)>=2L) for (line in lines[-1L]) {
    if (!nzchar(trimws(line))) next
    row <- parse_delimited_line(line, ";")
    wwid <- normalize_mapping_wwid(at(row,wi)); if (!nzchar(wwid)) next
    for (pair in list(c("1",d1),c("2",d2),c("3",d3))) {
      depot <- normalize_depot(at(row,as.integer(pair[[2]]))); if(!nzchar(depot)) next
      key <- paste0(depot,SEPKEY,pair[[1]])
      vals <- if (exists(key,cand,inherits=FALSE)) get(key,cand) else character(0)
      assign(key, unique(c(vals,wwid)), cand)
      vals2 <- if (exists(depot,depcand,inherits=FALSE)) get(depot,depcand) else character(0)
      assign(depot, unique(c(vals2,wwid)), depcand)
    }
  }
  for (k in ls(cand,all.names=TRUE)) {
    vals <- get(k,cand); if(length(vals)==1L) assign(k,vals[[1]],exact) else assign(k,vals,conflicts)
  }
  for (k in ls(depcand,all.names=TRUE)) {
    vals <- get(k,depcand); if(length(vals)==1L) assign(k,vals[[1]],fallback)
  }
  list(exact=exact,fallback=fallback,conflicts=conflicts)
}

resolve_mapping <- function(m, depot, underdepot, existing_wwid) {
  dk <- normalize_depot(depot); uk <- normalize_underdepot(underdepot); existing <- normalize_mapping_wwid(existing_wwid)
  if (!nzchar(dk)) return(existing)
  key <- paste0(dk,SEPKEY,uk)
  if (nzchar(uk) && exists(key,m$exact,inherits=FALSE)) return(get(key,m$exact))
  if (nzchar(uk) && exists(key,m$conflicts,inherits=FALSE)) return(existing)
  if (exists(dk,m$fallback,inherits=FALSE)) return(get(dk,m$fallback))
  existing
}

count_outside_quotes <- function(line, delimiter) {
  chars <- strsplit(line,"",fixed=TRUE)[[1]]; quoted<-FALSE; n<-0L; i<-1L
  while(i<=length(chars)) {
    ch<-chars[[i]]
    if(ch=='"') {
      if(quoted && i<length(chars) && chars[[i+1L]]=='"') i<-i+1L else quoted<-!quoted
    } else if(ch==delimiter && !quoted) n<-n+1L
    i<-i+1L
  }
  n
}

detect_separator <- function(content) {
  lines <- strsplit(gsub("\r\n|\r","\n",content,perl=TRUE),"\n",fixed=TRUE)[[1]]
  lines <- lines[nzchar(trimws(lines))]
  if(length(lines)==0L) return(NULL)
  lines <- head(lines,20L)
  candidates <- c(";","\t","|",","); scores <- sapply(candidates,function(d) sum(vapply(lines,count_outside_quotes,integer(1),delimiter=d)))
  if(max(scores)<=0L) NULL else candidates[[which.max(scores)]]
}

parse_text_rows_legacy <- function(content, sep=NULL) {
  if (is.null(sep)) sep <- detect_separator(content)
  lines <- strsplit(gsub("\r\n|\r","\n",content,perl=TRUE),"\n",fixed=TRUE)[[1]]
  out <- list()
  for(raw in lines) {
    if(!nzchar(trimws(raw))) next
    row <- if(is.null(sep)) c(trimws(raw)) else parse_delimited_line(raw,sep)
    row <- vapply(row,clean_cell,character(1))
    if(any(nzchar(row))) out[[length(out)+1L]] <- row
  }
  out
}

parse_text_rows <- function(content) {
  sep <- detect_separator(content)
  normalized <- gsub("\r\n|\r", "\n", content, perl=TRUE)

  # Single-column fallback keeps the exact legacy behavior.
  if (is.null(sep)) return(parse_text_rows_legacy(normalized, NULL))

  # Performance-critical fast path:
  # count.fields/read.table are native R routines and correctly handle quoted
  # delimiters. The old implementation parsed every character in R and used
  # paste0 repeatedly, which made the 252-file DU corpus take tens of minutes.
  fast <- tryCatch({
    tc_count <- textConnection(normalized, open="r", local=TRUE, encoding="UTF-8")
    on.exit(close(tc_count), add=TRUE)
    counts <- utils::count.fields(
      tc_count,
      sep=sep,
      quote='"',
      blank.lines.skip=TRUE,
      comment.char=""
    )
    close(tc_count)
    on.exit(NULL, add=FALSE)

    counts <- counts[!is.na(counts)]
    if (length(counts)==0L) return(list())
    width <- max(counts)
    if (!is.finite(width) || width < 1L) return(list())

    tc <- textConnection(normalized, open="r", local=TRUE, encoding="UTF-8")
    on.exit(close(tc), add=TRUE)
    df <- utils::read.table(
      tc,
      header=FALSE,
      sep=sep,
      quote='"',
      comment.char="",
      fill=TRUE,
      col.names=paste0("V", seq_len(width)),
      colClasses="character",
      stringsAsFactors=FALSE,
      check.names=FALSE,
      na.strings=character(0),
      blank.lines.skip=TRUE,
      strip.white=FALSE,
      allowEscapes=FALSE,
      skipNul=TRUE
    )

    if (nrow(df)==0L) return(list())

    mat <- as.matrix(df)
    vals <- as.character(mat)
    vals[is.na(vals)] <- ""
    vals <- trimws(gsub("\u00A0", " ", vals, fixed=TRUE))
    dim(vals) <- dim(mat)

    keep <- rowSums(matrix(nzchar(vals), nrow=nrow(vals), ncol=ncol(vals))) > 0L
    if (!any(keep)) return(list())
    vals <- vals[keep,,drop=FALSE]

    lapply(seq_len(nrow(vals)), function(i) unname(vals[i,,drop=TRUE]))
  }, error=function(e) {
    NULL
  })

  if (!is.null(fast)) return(fast)

  # Fail-safe correctness fallback for malformed/edge-case text files.
  parse_text_rows_legacy(normalized, sep)
}

trim_trailing_empty <- function(row) {
  v <- vapply(row,clean_cell,character(1))
  while(length(v)>0L && !nzchar(v[[length(v)]])) v <- v[-length(v)]
  v
}
first_nonempty <- function(row) { for(x in row){c<-clean_cell(x);if(nzchar(c))return(c)}; "" }
is_marker_row <- function(row) { f<-sub("^\\s+","",first_nonempty(row),perl=TRUE); nzchar(f) && any(startsWith(f,MARKER_PREFIXES)) }
is_metadata_row <- function(row) {
  cels <- vapply(row,clean_cell,character(1)); cels<-cels[nzchar(cels)]
  if(length(cels)==0L || length(cels)>3L) return(FALSE)
  tolower(sub(":$","",trimws(cels[[1]]),perl=TRUE)) %in% METADATA_LABELS
}
remove_noise_rows <- function(rows) {
  out<-list(); for(r in rows){t<-trim_trailing_empty(r);if(length(t)>0L && !is_marker_row(t)&&!is_metadata_row(t))out[[length(out)+1L]]<-t};out
}
split_packed_rows <- function(rows) {
  out<-list(); for(r in rows){c<-trim_trailing_empty(r);ne<-c[nzchar(c)];if(length(ne)==1L && lengths(regmatches(ne,gregexpr(";",ne,fixed=TRUE)))>=3L){out[[length(out)+1L]]<-vapply(parse_delimited_line(ne,";"),clean_cell,character(1))}else out[[length(out)+1L]]<-c};out
}

normalize_row_width <- function(row,width) vapply(seq_len(width),function(i) if(i<=length(row))clean_cell(row[[i]]) else "",character(1))
pair_overlap <- function(a,b) { n<-min(length(a),length(b)); if(n==0L)return(0L); sum(nzchar(a[seq_len(n)]) & a[seq_len(n)]==b[seq_len(n)]) }
make_unique_headers <- function(headers) {
  counts<-new.env(hash=TRUE,parent=emptyenv());out<-character(length(headers))
  for(i in seq_along(headers)){nm<-clean_cell(headers[[i]]);if(!nzchar(nm))nm<-sprintf("Feld_%02d",i);cnt<-if(exists(nm,counts,inherits=FALSE))get(nm,counts)+1L else 1L;assign(nm,cnt,counts);out[[i]]<-if(cnt>1L)paste0(nm,"_",cnt)else nm};out
}
is_empty_row <- function(row) !any(nzchar(vapply(row,clean_cell,character(1))))
is_numeric_like <- function(v) { t<-trimws(v); grepl("^[-+]?\\d+(?:[.,]\\d+)?$",t,perl=TRUE)||grepl("^\\d{6,14}$",t,perl=TRUE)||grepl("^[A-Z]{2}\\d{9,12}$",t,perl=TRUE) }

header_match_score <- function(row, reference=NULL) {
  rn <- unique(vapply(row[nzchar(trimws(row))],normalize_header,character(1)))
  if(!is.null(reference)) {
    ref <- unique(vapply(reference[nzchar(trimws(reference))],normalize_header,character(1)))
    return(sum(ref %in% rn))
  }
  du <- unique(vapply(DU_TARGET_HEADERS,normalize_header,character(1))); dp<-unique(vapply(DP_TARGET_HEADERS,normalize_header,character(1)))
  max(sum(rn %in% du),sum(rn %in% dp))
}

looks_like_header <- function(row) {
  cells<-vapply(row,clean_cell,character(1));cells<-cells[nzchar(cells)];if(length(cells)<4L)return(FALSE)
  normalized<-unique(vapply(cells,normalize_header,character(1)));known<-unique(vapply(KNOWN_HEADER_TERMS,normalize_header,character(1)))
  if(sum(normalized %in% known)>=3L)return(TRUE)
  if(header_match_score(cells)>=5L)return(TRUE)
  alpha<-sum(vapply(cells,function(x)grepl("[A-Za-zÄÖÜäöüß]",x,perl=TRUE),logical(1)))
  numeric<-sum(vapply(cells,is_numeric_like,logical(1))); datefirst<-grepl("^\\d{8}$",cells[[1]],perl=TRUE)
  if(datefirst || numeric>=max(3L,floor(length(cells)/3)))return(FALSE)
  alpha>=max(4L,floor(length(cells)*0.65))
}

detect_target_profile <- function(source_header,fallback_width,source_name) {
  fp<-profile_from_filename(source_name);if(!is.null(fp))return(fp)
  norm<-unique(vapply(source_header[nzchar(trimws(source_header))],normalize_header,character(1)))
  du<-sum(DU_PROFILE_MARKERS %in% norm);dp<-sum(DP_PROFILE_MARKERS %in% norm)
  if(du>=2L&&du>dp)return("du");if(dp>=2L&&dp>du)return("dp");if(fallback_width>=30L)"du" else "dp"
}

find_company_id_column <- function(header,width,fixed) {
  norm<-vapply(header,normalize_header,character(1));for(c in c("firmenid","companyid","firmen_id","company_id")){idx<-match(normalize_header(c),norm);if(!is.na(idx))return(idx)}
  if(fixed && COMPANY_ID_COLUMN_INDEX<=width) COMPANY_ID_COLUMN_INDEX else NA_integer_
}
find_allowed_company_id <- function(row, preferred) {
  checked<-integer(0)
  for(idx in preferred){if(is.na(idx)||idx<1L||idx>length(row)||idx%in%checked)next;checked<-c(checked,idx);cid<-toupper(clean_cell(row[[idx]]));if(cid%in%ALLOWED_COMPANY_IDS)return(cid)}
  for(i in seq_along(row)){if(i%in%checked)next;cid<-toupper(clean_cell(row[[i]]));if(cid%in%ALLOWED_COMPANY_IDS)return(cid)}
  NULL
}

build_target_mapping <- function(source_header,target_header) {
  if(length(source_header)==0L)return(NULL)
  source_norm<-vapply(source_header,normalize_header,character(1));source_index<-integer(0);names(source_index)<-character(0)
  for(i in seq_along(source_norm)){n<-source_norm[[i]];if(nzchar(n)&&!(n%in%names(source_index)))source_index[n]<-i}
  target_norm<-vapply(target_header,normalize_header,character(1));overlap<-sum(nzchar(target_norm)&target_norm%in%names(source_index))
  if(overlap<max(5L,floor(length(target_norm)*0.35)))return(NULL)
  vapply(seq_along(target_norm),function(i){n<-target_norm[[i]];if(n%in%names(source_index))unname(source_index[[n]]) else if(i<=length(source_header))i else NA_integer_},integer(1))
}
map_row_to_target <- function(row,target_width,mapping) {
  if(is.null(mapping))return(normalize_row_width(row,target_width))
  vapply(seq_len(target_width),function(i){s<-if(i<=length(mapping))mapping[[i]]else NA_integer_;if(!is.na(s)&&s>=1L&&s<=length(row))clean_cell(row[[s]])else""},character(1))
}

extract_table <- function(raw_rows,fixed_target_header=TRUE,apply_company_filter=TRUE,source_name="") {
  rows<-remove_noise_rows(split_packed_rows(raw_rows))
  if(length(rows)==0L){profile<-detect_target_profile(character(0),0L,source_name);return(list(header=if(profile=="du")DU_TARGET_HEADERS else DP_TARGET_HEADERS,rows=list(),source_name=source_name))}
  header_index<-NA_integer_
  for(i in seq_len(min(30L,length(rows)))){if(header_match_score(rows[[i]])>=5L||looks_like_header(rows[[i]])){header_index<-i;break}}
  detected<-if(!is.na(header_index))rows[[header_index]]else character(0)
  if(fixed_target_header){
    source_width<-if(length(detected)>0L)length(detected)else max(vapply(rows,length,integer(1)));profile<-detect_target_profile(detected,source_width,source_name);header<-if(profile=="du")DU_TARGET_HEADERS else DP_TARGET_HEADERS
    data_rows<-if(!is.na(header_index)&&header_index<length(rows))rows[(header_index+1L):length(rows)] else if(!is.na(header_index))list() else rows
    width<-length(header);source_header<-detected;source_company_index<-find_company_id_column(source_header,length(source_header),FALSE);target_company_index<-find_company_id_column(header,width,TRUE);target_mapping<-build_target_mapping(source_header,header)
  } else {
    if(!is.na(header_index)){header<-make_unique_headers(rows[[header_index]]);data_rows<-if(header_index<length(rows))rows[(header_index+1L):length(rows)]else list();width<-length(header)}else{width<-max(vapply(rows,length,integer(1)));header<-sprintf("Feld_%02d",seq_len(width));data_rows<-rows}
    source_header<-header;source_company_index<-find_company_id_column(source_header,width,FALSE);target_company_index<-source_company_index;target_mapping<-NULL
  }
  nh<-vapply(header,normalize_header,character(1));nsh<-vapply(source_header,normalize_header,character(1));clean_data<-list()
  for(row in data_rows){
    if(is_empty_row(row)||is_marker_row(row)||is_metadata_row(row))next
    fitted_header<-normalize_row_width(row,max(width,length(source_header)));row_norm<-vapply(fitted_header,normalize_header,character(1));to<-pair_overlap(row_norm,nh);so<-pair_overlap(row_norm,nsh)
    if(to>=max(4L,min(8L,floor(width/3)))||so>=max(4L,min(8L,floor(max(1L,length(source_header))/3)))||header_match_score(row,header)>=5L||(length(source_header)>0L&&header_match_score(row,source_header)>=5L))next
    cid<-NULL
    if(apply_company_filter){cid<-find_allowed_company_id(row,c(source_company_index,COMPANY_ID_COLUMN_INDEX));if(is.null(cid))next}
    fitted<-map_row_to_target(row,width,target_mapping)
    if(fixed_target_header){hm<-header_map(header);wi<-if("wwid"%in%names(hm))hm[["wwid"]]else NA_integer_;di<-if("depotnummer"%in%names(hm))hm[["depotnummer"]]else NA_integer_;ui<-if("unterdepot"%in%names(hm))hm[["unterdepot"]]else NA_integer_;if(!is.na(wi)&&!is.na(di))fitted[[wi]]<-resolve_mapping(G_MAPPING,at(fitted,di),at(fitted,ui),at(fitted,wi))}
    if(!is.null(cid)&&!is.na(target_company_index)&&target_company_index<=length(fitted))fitted[[target_company_index]]<-cid
    if(any(nzchar(fitted)))clean_data[[length(clean_data)+1L]]<-fitted
  }
  list(header=header,rows=clean_data,source_name=source_name)
}

read_lines_encoding <- function(path, encoding_name) {
  warnings_seen <- character(0)
  con <- file(path, open="rt", encoding=encoding_name)
  on.exit(close(con), add=TRUE)

  lines <- withCallingHandlers(
    readLines(con, warn=FALSE, skipNul=TRUE),
    warning=function(w) {
      warnings_seen <<- c(warnings_seen, conditionMessage(w))
      invokeRestart("muffleWarning")
    }
  )

  if (
    length(warnings_seen) > 0L &&
    any(grepl("invalid input|invalid multibyte|cannot translate", warnings_seen, ignore.case=TRUE))
  ) {
    stop(paste(warnings_seen, collapse=" | "))
  }

  if (length(lines) > 0L) {
    lines[[1]] <- sub("^\ufeff", "", lines[[1]], perl=TRUE)
  }

  lines
}

read_lines_with_fallback <- function(path) {
  tryCatch(
    read_lines_encoding(path, "UTF-8"),
    error=function(e) read_lines_encoding(path, "CP1252")
  )
}

parse_file_prefilter <- function(path) {
  lines <- read_lines_with_fallback(path)

  if (length(lines)==0L) {
    profile <- detect_target_profile(character(0), 0L, basename(path))
    return(list(
      header=if(profile=="du") DU_TARGET_HEADERS else DP_TARGET_HEADERS,
      rows=list(),
      source_name=basename(path)
    ))
  }

  lead_limit <- min(length(lines), 1000L)
  lead_window <- lines[seq_len(lead_limit)]
  lead_nonempty <- which(nzchar(trimws(lead_window)))
  lead_idx <- head(lead_nonempty, 120L)

  idx_mercer <- grep("MERCER_", lines, fixed=TRUE, ignore.case=TRUE)
  idx_intel  <- grep("INTEL",   lines, fixed=TRUE, ignore.case=TRUE)
  company_idx <- sort(unique(c(idx_mercer, idx_intel)))

  selected_idx <- sort(unique(c(lead_idx, company_idx)))
  selected <- lines[selected_idx]

  sep_probe <- lead_window[which(nzchar(trimws(lead_window)))]
  sep <- detect_separator(paste(head(sep_probe, 20L), collapse="\n"))

  rows <- vector("list", length(selected))
  out_n <- 0L

  for (raw in selected) {
    if (!nzchar(trimws(raw))) next

    row <- if (is.null(sep)) {
      c(trimws(raw))
    } else {
      parse_delimited_line(raw, sep)
    }

    row <- vapply(row, clean_cell, character(1))
    if (any(nzchar(row))) {
      out_n <- out_n + 1L
      rows[[out_n]] <- row
    }
  }

  if (out_n==0L) rows <- list()
  else rows <- rows[seq_len(out_n)]

  extract_table(
    rows,
    TRUE,
    TRUE,
    basename(path)
  )
}

parse_file <- function(path) {
  tryCatch(
    parse_file_prefilter(path),
    error=function(e) {
      tab <- extract_table(
        parse_text_rows_legacy(read_text_with_fallback(path)),
        TRUE,
        TRUE,
        basename(path)
      )
      attr(tab, "parser_fallback") <- TRUE
      attr(tab, "fallback_reason") <- conditionMessage(e)
      tab
    }
  )
}

align_rows <- function(source,master_header) {
  sn<-vapply(source$header,normalize_header,character(1));mn<-vapply(master_header,normalize_header,character(1));if(length(sn)==length(mn)&&all(sn==mn))return(lapply(source$rows,identity))
  idx<-integer(0);names(idx)<-character(0);for(i in seq_along(sn))if(nzchar(sn[[i]]))idx[sn[[i]]]<-i
  common<-sum(mn%in%names(idx));if(common<max(4L,floor(length(mn)*0.60)))stop("Header weicht zu stark von den übrigen Dateien ab.")
  lapply(source$rows,function(row)vapply(mn,function(n){i<-if(n%in%names(idx))idx[[n]]else NA_integer_;if(!is.na(i)&&i<=length(row))row[[i]]else""},character(1)))
}

bridge_path <- function() file.path(dirname(normalizePath(sys.frame(1)$ofile %||% commandArgs(trailingOnly=FALSE)[grep("--file=",commandArgs(trailingOnly=FALSE),fixed=TRUE)][1],winslash="/",mustWork=FALSE)),"excel_bridge.ps1")
`%||%` <- function(a,b) if(length(a)==0L||is.null(a)||is.na(a)||!nzchar(a))b else a
script_dir <- function() {
  full <- commandArgs(trailingOnly=FALSE);hit<-grep("^--file=",full,value=TRUE)
  if(length(hit)>0L)return(dirname(normalizePath(sub("^--file=","",hit[[1]]),winslash="/",mustWork=FALSE)))
  getwd()
}

run_bridge <- function(args) {
  bridge<-file.path(script_dir(),"excel_bridge.ps1")
  if(!file.exists(bridge))stop(paste("Excel bridge missing:",bridge))
  q<-function(x)shQuote(as.character(x),type="cmd")
  allargs<-c("-NoProfile","-ExecutionPolicy","Bypass","-File",q(bridge),vapply(args,q,character(1)))
  status<-system2("powershell.exe",args=allargs,stdout="",stderr="")
  if(!identical(status,0L))stop(paste("Excel bridge failed with exit code",status))
}

rows_to_df <- function(header,rows) {
  if(length(rows)==0L){df<-as.data.frame(setNames(replicate(length(header),character(0),simplify=FALSE),header),check.names=FALSE);return(df)}
  mat<-do.call(rbind,lapply(rows,function(r)normalize_row_width(r,length(header))));df<-as.data.frame(mat,stringsAsFactors=FALSE,check.names=FALSE);names(df)<-header;df
}
write_table_tsv <- function(path,header,rows) {
  df<-rows_to_df(header,rows)
  write.table(df,file=path,sep="\t",quote=TRUE,row.names=FALSE,col.names=TRUE,fileEncoding="UTF-8",qmethod="double",na="")
}
write_xlsx <- function(path,sheet_name,header,rows) {
  tmp<-tempfile(fileext=".tsv");on.exit(unlink(tmp),add=TRUE);write_table_tsv(tmp,header,rows)
  run_bridge(c("-Mode","WriteTable","-Workbook",normalizePath(path,winslash="\\",mustWork=FALSE),"-TablePath",normalizePath(tmp,winslash="\\",mustWork=TRUE),"-SheetName",sheet_name))
}
write_converted_batch <- function(results,source_files,reservations,converted_dir) {
  manifest<-file.path(converted_dir,"_mcr_write_batch.tsv");lines<-character(0);temps<-character(0);counter<-0L
  for(source in source_files){if(!(source%in%names(results)))next;counter<-counter+1L;tmp<-file.path(converted_dir,sprintf("_mcr_table_%04d.tsv",counter));write_table_tsv(tmp,results[[source]]$header,results[[source]]$rows);temps<-c(temps,tmp);lines<-c(lines,paste(normalizePath(reservations[[source]],winslash="\\",mustWork=FALSE),"Ziel 1",normalizePath(tmp,winslash="\\",mustWork=TRUE),sep="\t"))}
  writeLines(lines,manifest,useBytes=TRUE)
  on.exit(unlink(c(manifest,temps)),add=TRUE)
  run_bridge(c("-Mode","WriteTablesBatch","-Workbook",normalizePath(file.path(converted_dir,"_batch_placeholder.xlsx"),winslash="\\",mustWork=FALSE),"-BatchManifest",normalizePath(manifest,winslash="\\",mustWork=TRUE)))
}

reserve_output_paths <- function(source_files,output_dir) {
  used<-character(0);out<-setNames(character(length(source_files)),source_files)
  for(source in source_files){stem<-tools::file_path_sans_ext(basename(source));if(!nzchar(stem))stem<-basename(source);candidate<-file.path(output_dir,paste0(stem,".xlsx"));counter<-1L;while(tolower(candidate)%in%used){candidate<-file.path(output_dir,paste0(stem,"_",counter,".xlsx"));counter<-counter+1L};used<-c(used,tolower(candidate));out[[source]]<-candidate};out
}

convert_and_merge <- function(profile,source_files,converted_dir,master_path,workers) {
  label<-toupper(profile)
  cat(sprintf("[%s] %d Rohdatei(en) werden konvertiert und zusammengefuehrt ...\n",label,length(source_files)))
  dir.create(converted_dir,recursive=TRUE,showWarnings=FALSE)
  reservations<-reserve_output_paths(source_files,converted_dir)
  results<-list()
  errors<-character(0)
  completed<-0L
  stage_start<-proc.time()[["elapsed"]]

  requested_workers <- suppressWarnings(as.integer(workers))
  if (is.na(requested_workers) || requested_workers < 1L) requested_workers <- 1L
  parse_workers <- min(requested_workers, length(source_files))

  parse_one <- function(source) {
    tryCatch({
      tab <- parse_file(source)
      list(
        ok=TRUE,
        source=source,
        tab=tab,
        fallback=isTRUE(attr(tab,"parser_fallback")),
        fallback_reason=if(is.null(attr(tab,"fallback_reason"))) "" else attr(tab,"fallback_reason")
      )
    }, error=function(e) {
      list(
        ok=FALSE,
        source=source,
        tab=NULL,
        fallback=FALSE,
        fallback_reason="",
        error=conditionMessage(e)
      )
    })
  }

  process_result <- function(item) {
    source <- item$source
    completed <<- completed + 1L

    if (isTRUE(item$ok)) {
      results[[source]] <<- item$tab

      if (isTRUE(item$fallback)) {
        cat(sprintf(
          "[R-PARSER-FALLBACK] %s | %s\n",
          basename(source),
          item$fallback_reason
        ))
      }

      cat(sprintf(
        "[%s] %d/%d | %s | Datei abgeschlossen\n",
        label,completed,length(source_files),basename(source)
      ))
    } else {
      err <- if(is.null(item$error)) "unknown parser failure" else item$error
      errors <<- c(errors,paste0(basename(source),": ",err))
      cat(sprintf(
        "[%s] %d/%d | %s | FEHLER: %s\n",
        label,completed,length(source_files),basename(source),err
      ))
    }
  }

  report_and_guard <- function(early=FALSE) {
    if (completed < 1L) return(invisible(NULL))

    elapsed<-proc.time()[["elapsed"]]-stage_start
    avg<-elapsed/completed
    projected<-avg*length(source_files)

    cat(sprintf(
      "[%s] PERFORMANCE | %d/%d | elapsed %.1fs | %.3fs/file wall | projected %.1fs\n",
      label,completed,length(source_files),elapsed,avg,projected
    ))
    flush.console()

    # Certification policy:
    # v0.1.8 already demonstrated ~4.2 s/file wall and a ~17.7 minute
    # projection at 200/252. That is slow, but still useful benchmark data.
    # Abort only when the run is clearly pathological again.
    if(early && length(source_files)>=100L && avg>10.0){
      stop(sprintf(
        "R PERFORMANCE GUARD EARLY: %.3f s/file wall after %d files (projected %.1f min). Aborted early.",
        avg,completed,projected/60.0
      ))
    }

    if(!early && completed>=64L && length(source_files)>=100L && projected>1800.0){
      stop(sprintf(
        "R PERFORMANCE GUARD: projected %.1f min after %d files exceeds the 30-minute certification ceiling. Aborted.",
        projected/60.0,completed
      ))
    }

    invisible(NULL)
  }

  if (parse_workers >= 2L && length(source_files) >= 8L) {
    cat(sprintf("[R-PARALLEL] PSOCK parse workers: %d\n",parse_workers))
    cat("[R-PERFORMANCE-POLICY] Full certification continues while projected DU parse time stays <= 30 min.\n")

    cl <- parallel::makePSOCKcluster(parse_workers)
    cluster_stopped <- FALSE
    on.exit({
      if(!cluster_stopped) try(parallel::stopCluster(cl), silent=TRUE)
    }, add=TRUE)

    export_names <- ls(envir=.GlobalEnv, all.names=TRUE)
    parallel::clusterExport(cl, varlist=export_names, envir=.GlobalEnv)
    parallel::clusterEvalQ(cl, {
      options(stringsAsFactors=FALSE)
      Sys.setlocale("LC_NUMERIC","C")
      NULL
    })

    batch_size <- max(parse_workers, parse_workers * 2L)
    starts <- seq.int(1L, length(source_files), by=batch_size)

    for (start in starts) {
      stop_idx <- min(length(source_files), start + batch_size - 1L)
      batch <- source_files[start:stop_idx]

      batch_results <- parallel::parLapplyLB(
        cl,
        batch,
        function(source) {
          tryCatch({
            tab <- parse_file(source)
            list(
              ok=TRUE,
              source=source,
              tab=tab,
              fallback=isTRUE(attr(tab,"parser_fallback")),
              fallback_reason=if(is.null(attr(tab,"fallback_reason"))) "" else attr(tab,"fallback_reason")
            )
          }, error=function(e) {
            list(
              ok=FALSE,
              source=source,
              tab=NULL,
              fallback=FALSE,
              fallback_reason="",
              error=conditionMessage(e)
            )
          })
        }
      )

      for (item in batch_results) process_result(item)

      if (start == 1L) {
        report_and_guard(TRUE)
      } else if (
        completed >= 32L &&
        (completed %% 32L == 0L || completed == length(source_files))
      ) {
        report_and_guard(FALSE)
      }
    }

    parallel::stopCluster(cl)
    cluster_stopped <- TRUE
  } else {
    cat("[R-PARALLEL] Sequential parse path\n")

    for (source in source_files) {
      process_result(parse_one(source))

      if (completed == 5L) {
        report_and_guard(TRUE)
      } else if (
        completed >= 25L &&
        (completed %% 25L == 0L || completed == length(source_files))
      ) {
        report_and_guard(FALSE)
      }
    }
  }

  report_and_guard(FALSE)

  successful<-source_files[source_files%in%names(results)];if(length(successful)==0L)stop(paste0("No ",label," source could be converted.\n",paste(head(errors,20L),collapse="\n")))
  cat(sprintf("[%s] Konvertierung fertig. %d Datei(en) werden direkt im Speicher zum Master zusammengefuehrt ...\n",label,length(successful)))
  header<-results[[successful[[1]]]]$header;merged<-list();pos<-0L
  for(source in successful){pos<-pos+1L;al<-tryCatch(align_rows(results[[source]],header),error=function(e)e);if(inherits(al,"error")){msg<-conditionMessage(al);errors<-c(errors,paste0(basename(reservations[[source]]),": ",msg));cat(sprintf("[%s] Merge %d/%d | %s | FEHLER: %s | %d Zeilen\n",label,pos,length(successful)+1L,basename(reservations[[source]]),msg,length(merged)))}else{merged<-c(merged,al);cat(sprintf("[%s] Merge %d/%d | %s | Datei abgeschlossen | %d Zeilen\n",label,pos,length(successful)+1L,basename(reservations[[source]]),length(merged)))}}
  write_xlsx(master_path,"Gesamtdaten",header,merged);cat(sprintf("[%s] Merge %d/%d | %s | Masterdatei gespeichert | %d Zeilen\n",label,length(successful)+1L,length(successful)+1L,basename(master_path),length(merged)));cat(sprintf("[%s] Master fertig: %s | %d Datenzeilen\n",label,basename(master_path),length(merged)))
  list(table=list(header=header,rows=merged,source_name=master_path),errors=errors)
}

agg_add <- function(env,key,shares,value) { if(exists(key,env,inherits=FALSE)){v<-get(key,env);v<-v+c(shares,value)}else v<-c(shares,value);assign(key,v,env) }
aggregate_du <- function(table,investment=FALSE) {
  m<-header_map(table$header);wi<-find_index(m,c("WWID"));fi<-find_index(m,c("Fondsname","Fonds Name"));mi<-find_index(m,c("Umsatzart","Umsatz Art"));si<-find_index(m,c("UmsatzStuecke","Umsatzstücke","Umsatz Stücke"));vi<-if(investment)find_index(m,c("Anlbetrag","AnlBetrag","Anl Betrag","Anlagebetrag"))else find_index(m,c("ZahlBetrag","Zahlbetrag","Zahl Betrag"));out<-new.env(hash=TRUE,parent=emptyenv())
  for(row in table$rows){ww<-normalize_wwid(at(row,wi));fund<-normalize_fund(at(row,fi));mov<-normalize_text(at(row,mi));if(!nzchar(ww)||!nzchar(fund)||!nzchar(mov))next;agg_add(out,paste(ww,fund,mov,sep=SEPKEY),as_number(at(row,si)),as_number(at(row,vi)))};out
}
aggregate_dp <- function(table) {
  m<-header_map(table$header);wi<-find_index(m,c("WWID"));fi<-find_index(m,c("Fondsname","Fonds Name"));si<-find_index(m,c("Bestand_Stuecke","BestandStuecke","Bestand Stücke","Bestand_Stücke","Bestandstücke"));vi<-find_index(m,c("Bestand_Betrag","BestandBetrag","Bestand Betrag"));out<-new.env(hash=TRUE,parent=emptyenv())
  for(row in table$rows){ww<-normalize_wwid(at(row,wi));fund<-normalize_fund(at(row,fi));if(!nzchar(ww)||!nzchar(fund))next;agg_add(out,paste(ww,fund,sep=SEPKEY),as_number(at(row,si)),as_number(at(row,vi)))};out
}
get_pair <- function(env,key) if(exists(key,env,inherits=FALSE))get(key,env)else c(0.0,0.0)

parse_snapshot <- function(path) {
  lines<-readLines(path,warn=FALSE,encoding="UTF-8");headerRow<-0L;lastRow<-0L;rows<-list()
  for(line in lines){if(!nzchar(line))next;p<-strsplit(line,"\t",fixed=TRUE)[[1]];if(p[[1]]=="META"&&length(p)>=4L){headerRow<-as.integer(p[[2]]);lastRow<-as.integer(p[[4]])}else if(p[[1]]=="ROW"&&length(p)>=13L){prev<-vapply(p[4:13],as_number,numeric(1));rows[[length(rows)+1L]]<-list(row=as.integer(p[[2]]),wwid=normalize_wwid(p[[3]]),prev=prev)}}
  if(headerRow==0L||lastRow<=headerRow)stop("Snapshot metadata invalid");list(header_row=headerRow,last_row=lastRow,rows=rows)
}
numtext <- function(v){if(!is.finite(v))v<-0;sprintf("%.17g",as.numeric(v))}
run_lnw <- function(template,du,dp,output_excel,output_csv,work_dir) {
  dir.create(work_dir,recursive=TRUE,showWarnings=FALSE);file.copy(template,output_excel,overwrite=TRUE);snap_path<-file.path(work_dir,"excel_snapshot.tsv");plan_path<-file.path(work_dir,"excel_plan.tsv");cat("[LNW] Output-Template wird ueber Microsoft Excel geoeffnet ...\n");run_bridge(c("-Mode","Snapshot","-Workbook",normalizePath(output_excel,winslash="\\",mustWork=TRUE),"-SnapshotPath",normalizePath(snap_path,winslash="\\",mustWork=FALSE)));snap<-parse_snapshot(snap_path);cat(sprintf("[LNW] Zielblatt erkannt: WWID-Header Zeile %d, letzte WWID-Zeile %d.\n",snap$header_row,snap$last_row));cat("[LNW] DU wird nach WWID, Fonds und Umsatzart aggregiert ...\n");duagg<-aggregate_du(du,FALSE);purchase<-aggregate_du(du,TRUE);cat("[LNW] DP wird nach WWID und Fonds aggregiert ...\n");dpagg<-aggregate_dp(dp)
  lines<-c(sprintf("META\t%d\t%d",snap$header_row+1L,snap$last_row));prevcols<-c("AJ","AK","AL","AM","AN","AO","AP","AQ","AR","AS");purchases<-list(c("DWS EURORENTA","AV","AW"),c("DWS INS.-ESG EO MO.M.IC","AY","AZ"),c("DWSI-EUR.EQ.HI.CO.FC","BB","BC"));funds<-list(c("DWSI-EUR.EQ.HI.CO.FC","CL","CM","BI","BJ"),c("DWS EURORENTA","CN","CO","BK","BL"),c("DWS INS.-ESG EO MO.M.IC","CP","CQ","BM","BN"),c("SIEMENS EUROINVEST AKTIEN","CR","CS",NA,NA),c("SIEMENS EUROINVEST RENTEN","CT","CU",NA,NA));pm<-normalize_text("Kauf");rm<-normalize_text("Fondsportfolioanpassung");df<-normalize_fund("DWS EURORENTA");cat("[LNW] Schreibplan fuer AJ:CU wird erzeugt ...\n")
  setv<-function(addr,v){lines<<-c(lines,paste("SET",addr,numtext(v),sep="\t"))}
  for(s in snap$rows){if(!nzchar(s$wwid))next;for(i in seq_along(prevcols))setv(paste0(prevcols[[i]],s$row),s$prev[[i]]);for(x in purchases){v<-get_pair(purchase,paste(s$wwid,normalize_fund(x[[1]]),pm,sep=SEPKEY));setv(paste0(x[[2]],s$row),v[[1]]);setv(paste0(x[[3]],s$row),v[[2]])};ds<-0;dv<-0;for(k in ls(duagg,all.names=TRUE)){parts<-strsplit(k,SEPKEY,fixed=TRUE)[[1]];if(length(parts)==3L&&parts[[1]]==s$wwid&&parts[[2]]==df&&is_distribution(parts[[3]])){v<-get(k,duagg);ds<-ds+v[[1]];dv<-dv+v[[2]]}};setv(paste0("BF",s$row),ds);setv(paste0("BG",s$row),dv);for(x in funds){f<-normalize_fund(x[[1]]);if(!is.na(x[[4]])&&!is.na(x[[5]])){v<-get_pair(duagg,paste(s$wwid,f,rm,sep=SEPKEY));setv(paste0(x[[4]],s$row),v[[1]]);setv(paste0(x[[5]],s$row),v[[2]])};d<-get_pair(dpagg,paste(s$wwid,f,sep=SEPKEY));setv(paste0(x[[2]],s$row),d[[1]]);setv(paste0(x[[3]],s$row),d[[2]])}}
  writeLines(lines,plan_path,useBytes=TRUE,sep="\r\n");cat("[LNW] Konstanten werden geloescht, Werte geschrieben und Excel neu berechnet ...\n");run_bridge(c("-Mode","Apply","-Workbook",normalizePath(output_excel,winslash="\\",mustWork=TRUE),"-PlanPath",normalizePath(plan_path,winslash="\\",mustWork=TRUE),"-CsvPath",normalizePath(output_csv,winslash="\\",mustWork=FALSE)));cat("[LNW] Verarbeitung erfolgreich abgeschlossen.\n")
}

filename_date <- function(path) { stem<-tools::file_path_sans_ext(basename(path));m<-gregexpr("(?<!\\d)(20\\d{6})(?!\\d)",stem,perl=TRUE)[[1]];if(m[[1]]<0L)return(99999999L);vals<-regmatches(stem,list(m))[[1]];as.integer(tail(vals,1L)) }
select_dp <- function(files){if(length(files)<=1L)return(files);ord<-order(vapply(files,filename_date,integer(1)),tolower(basename(files)));sorted<-files[ord];cat(sprintf("[DP] %d DP-Dateien erkannt. Verwendet wird %s.\n",length(files),basename(sorted[[1]])));sorted[[1]]}

run_pipeline <- function(options) {
  if(!dir.exists(options$input_dir))stop(paste("Input directory missing:",options$input_dir));if(!file.exists(options$template_path))stop(paste("Template missing:",options$template_path));dir.create(options$output_dir,recursive=TRUE,showWarnings=FALSE);work<-file.path(options$output_dir,"work");convert_root<-file.path(work,"01_convert_merge");du_conv<-file.path(convert_root,"DU");dp_conv<-file.path(convert_root,"DP");lnw_dir<-file.path(work,"02_LNW");dir.create(du_conv,recursive=TRUE,showWarnings=FALSE);dir.create(dp_conv,recursive=TRUE,showWarnings=FALSE);dir.create(lnw_dir,recursive=TRUE,showWarnings=FALSE)
  files<-list.files(options$input_dir,recursive=TRUE,full.names=TRUE,all.files=FALSE);files<-files[!file.info(files)$isdir];filtered<-files[!startsWith(basename(files),"~$")];profiles<-vapply(filtered,function(p){x<-profile_from_filename(basename(p));if(is.null(x))""else x},character(1));du_files<-sort(filtered[profiles=="du"]);dp_all<-sort(filtered[profiles=="dp"]);cat(sprintf("Quelldateien erkannt: %d DU | %d DP | %d ignoriert\n",length(du_files),length(dp_all),length(filtered)-length(du_files)-length(dp_all)));if(length(du_files)==0L)stop("No DU raw files found.");if(length(dp_all)==0L)stop("No DP raw files found.");dp_files<-select_dp(dp_all);du_master<-file.path(options$output_dir,"DU_MASTER.xlsx");dp_master<-file.path(options$output_dir,"DP_MASTER.xlsx");du<-convert_and_merge("du",du_files,du_conv,du_master,options$workers);dp<-convert_and_merge("dp",dp_files,dp_conv,dp_master,options$workers);ext<-tools::file_ext(options$template_path);ext<-if(nzchar(ext))paste0(".",ext)else".xlsm";lnw_excel<-file.path(options$output_dir,paste0("LNW_Output",ext));lnw_csv<-file.path(options$output_dir,"LNW_Output.csv");cat("[LNW] DU- und DP-Master werden an die R LNW-Engine uebergeben ...\n");run_lnw(options$template_path,du$table,dp$table,lnw_excel,lnw_csv,lnw_dir);list(du_master=du_master,dp_master=dp_master,lnw_excel=lnw_excel,lnw_csv=lnw_csv,du_rows=length(du$table$rows),dp_rows=length(dp$table$rows))
}

parse_args <- function(argv) {
  map<-list();i<-1L;while(i<=length(argv)){k<-argv[[i]];if(!startsWith(k,"--"))stop(paste("Unexpected argument:",k));if(i>=length(argv))stop(paste("Missing value for",k));map[[tolower(k)]]<-argv[[i+1L]];i<-i+2L};need<-function(k){v<-map[[k]];if(is.null(v)||!nzchar(trimws(v)))stop(paste("Required argument missing:",k));v};workers<-suppressWarnings(as.integer(if(is.null(map[["--workers"]]))"4"else map[["--workers"]]));if(is.na(workers)||workers<1L)workers<-4L;list(case_id=if(is.null(map[["--case"]]))CASE_ID else map[["--case"]],input_dir=normalizePath(need("--input"),winslash="/",mustWork=FALSE),template_path=normalizePath(need("--template"),winslash="/",mustWork=FALSE),output_dir=normalizePath(need("--output"),winslash="/",mustWork=FALSE),workers=workers)
}
json_escape <- function(s){s<-gsub("\\\\","\\\\\\\\",as.character(s));s<-gsub('"','\\\\"',s,fixed=TRUE);s<-gsub("\r","\\\\r",s,fixed=TRUE);s<-gsub("\n","\\\\n",s,fixed=TRUE);s}
write_candidate_result <- function(path,options,result) {
  txt<-sprintf('{\n  "schema": "mcr.level05.candidate-result.v1",\n  "status": "success",\n  "case": "%s",\n  "language": "r",\n  "mode": "parity",\n  "artifacts": {\n    "du_master": "%s",\n    "dp_master": "%s",\n    "lnw_excel": "%s",\n    "lnw_csv": "%s"\n  },\n  "diagnostics": {\n    "du_master_rows": %d,\n    "dp_master_rows": %d,\n    "workers": %d,\n    "runtime": "%s"\n  }\n}\n',json_escape(options$case_id),json_escape(basename(result$du_master)),json_escape(basename(result$dp_master)),json_escape(basename(result$lnw_excel)),json_escape(basename(result$lnw_csv)),result$du_rows,result$dp_rows,options$workers,json_escape(paste("R",R.version.string)))
  writeLines(txt,path,useBytes=TRUE)
}

main <- function() {
  options<-parse_args(commandArgs(trailingOnly=TRUE));if(options$case_id!=CASE_ID)stop("This candidate is frozen to case MCR_LNW_001.");mapping_path<-file.path(script_dir(),"resources","wwid_mapping.csv");if(!file.exists(mapping_path))stop("Candidate resources are missing from build output.");cat(paste(rep("=",72),collapse=""),"\n",sep="");cat("MCR LEVEL 05A.2 - R MODE 1 PARITY CANDIDATE\n");cat(paste(rep("=",72),collapse=""),"\n",sep="");cat("Case:    ",options$case_id,"\n",sep="");cat("Input:   ",options$input_dir,"\n",sep="");cat("Template:",options$template_path,"\n",sep="");cat("Output:  ",options$output_dir,"\n",sep="");cat("Workers: ",options$workers,"\n\n",sep="")
  cat("R parser: CONNECTION_PREFILTER_V4 + PSOCK_PARALLEL\n\n");dir.create(options$output_dir,recursive=TRUE,showWarnings=FALSE);G_MAPPING<<-load_mapping(mapping_path);result<-run_pipeline(options);write_candidate_result(file.path(options$output_dir,"candidate_result.json"),options,result);cat("\nR candidate completed successfully.\n");cat("DU Master Rows: ",result$du_rows,"\n",sep="");cat("DP Master Rows: ",result$dp_rows,"\n",sep="");cat("candidate_result.json written.\n")
}

tryCatch({main();quit(status=0)},error=function(e){cat("\nR CANDIDATE FAILED\n",file=stderr());cat(conditionMessage(e),"\n",file=stderr());traceback(20L);quit(status=1)})
