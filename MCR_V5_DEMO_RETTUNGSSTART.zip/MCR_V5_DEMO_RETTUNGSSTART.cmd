@echo off
setlocal DisableDelayedExpansion

rem Standalone MCR Ticketbot V5 demo rescue starter (2026-10-21).
rem This script NEVER starts COMARCH REAL / live/pilot/queue modes.
rem It validates the unchanged, original V5 ZIP before extracting and executing
rem its DEMO_TESTEN_OHNE_VERSAND.cmd from a complete, fresh directory.

title MCR Ticketbot V5 - Sicherer Demo-Rettungsstart

echo.
echo ==============================================================
echo  MCR TICKETBOT V5 - REPARATUR DES ZIP-/DATEIPFADS
echo  NUR ZWEI FIKTIVE DEMO-TICKETS - KEIN ECHTVERSAND
echo ==============================================================
echo.

set "MCR_V5_ARCHIVE="
if not "%~1"=="" if exist "%~f1" set "MCR_V5_ARCHIVE=%~f1"
if defined MCR_V5_ARCHIVE goto archive_found

rem The supplied original archive is searched only at ordinary local locations.
rem Renamed archives can be dragged onto this CMD file instead.
for %%F in ("%~dp0MCR_Ticketbot_Wiederanlauf_20261020_V5*.zip") do if not defined MCR_V5_ARCHIVE if exist "%%~fF" set "MCR_V5_ARCHIVE=%%~fF"
for %%F in ("%USERPROFILE%\Downloads\MCR_Ticketbot_Wiederanlauf_20261020_V5*.zip") do if not defined MCR_V5_ARCHIVE if exist "%%~fF" set "MCR_V5_ARCHIVE=%%~fF"
for %%F in ("%USERPROFILE%\Documents\MCR_Ticketbot_Wiederanlauf_20261020_V5*.zip") do if not defined MCR_V5_ARCHIVE if exist "%%~fF" set "MCR_V5_ARCHIVE=%%~fF"
for %%F in ("%USERPROFILE%\Desktop\MCR_Ticketbot_Wiederanlauf_20261020_V5*.zip") do if not defined MCR_V5_ARCHIVE if exist "%%~fF" set "MCR_V5_ARCHIVE=%%~fF"

if defined MCR_V5_ARCHIVE goto archive_found
echo STOPP V5_ZIP_NICHT_GEFUNDEN
echo Das Originalarchiv MCR_Ticketbot_Wiederanlauf_20261020_V5.zip fehlt in den Standardordnern.
echo Ziehe die V5-ZIP-Datei mit der Maus AUF diese CMD-Datei.
echo Bitte keine anderen, ungeprueften Dateien als Ersatz verwenden.
set "MCR_RESULT=11"
goto finish

:archive_found
echo INFO  V5-ZIP-Datei gefunden.
set "MCR_V5_EXPECTED_SHA=a2c97657869af035aecb51c7e4725def11deee0bfe63e4f303af33f692cc7a4f"
if not defined LOCALAPPDATA (
 echo STOPP LOCALAPPDATA_NICHT_VERFUEGBAR
 set "MCR_RESULT=12"
 goto finish
)

set "MCR_BASE=%LOCALAPPDATA%\MCR\Ticketbot_Wiederherstellung"
set "MCR_V5_DEST=%MCR_BASE%\V5_%RANDOM%_%RANDOM%"
if exist "%MCR_V5_DEST%" (
 echo STOPP ZIELVERZEICHNIS_BEREITS_BELEGT
 set "MCR_RESULT=13"
 goto finish
)

if not exist "%MCR_BASE%" mkdir "%MCR_BASE%"
if not exist "%MCR_BASE%" (
 echo STOPP ZIELVERZEICHNIS_NICHT_ERSTELLBAR
 set "MCR_RESULT=14"
 goto finish
)

echo INFO  Pruefe Original-ZIP mit festem SHA-256 und entpacke neu.
set "MCR_PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%MCR_PS%" (
 echo STOPP WINDOWS_POWERSHELL_NICHT_GEFUNDEN
 set "MCR_RESULT=15"
 goto finish
)

"%MCR_PS%" -NoProfile -NonInteractive -Command "$ErrorActionPreference='Stop'; try { $actual=(Get-FileHash -LiteralPath $env:MCR_V5_ARCHIVE -Algorithm SHA256).Hash.ToLowerInvariant(); if ($actual -ne $env:MCR_V5_EXPECTED_SHA) { Write-Host 'STOPP V5_ZIP_SHA256_FALSCH'; exit 21 }; Write-Host 'PASS  V5_ZIP_SHA256_ORIGINAL'; Expand-Archive -LiteralPath $env:MCR_V5_ARCHIVE -DestinationPath $env:MCR_V5_DEST -ErrorAction Stop; Write-Host 'PASS  ZIP_VOLLSTAENDIG_ENTPACKT'; exit 0 } catch { Write-Host 'STOPP ZIP_EXTRAKTION_FEHLGESCHLAGEN'; exit 22 }"
set "MCR_PS_EXIT=%ERRORLEVEL%"
if not "%MCR_PS_EXIT%"=="0" (
 echo STOPP V5-Archiv konnte nicht nachweisbar entpackt werden. Exitcode %MCR_PS_EXIT%.
 set "MCR_RESULT=16"
 goto finish
)

set "MCR_KIT=%MCR_V5_DEST%\MCR_Ticketbot_Wiederanlauf_20261020_V5"
if not exist "%MCR_KIT%\tools\run.cmd" (
 echo STOPP STARTPFAD_FEHLT: tools\run.cmd fehlt trotz Entpackung.
 set "MCR_RESULT=17"
 goto finish
)
if not exist "%MCR_KIT%\tools\recover.mjs" (
 echo STOPP STARTPFAD_FEHLT: tools\recover.mjs fehlt trotz Entpackung.
 set "MCR_RESULT=18"
 goto finish
)
if not exist "%MCR_KIT%\MANIFEST_SHA256.json" (
 echo STOPP MANIFEST_FEHLT
 set "MCR_RESULT=19"
 goto finish
)
if not exist "%MCR_KIT%\DEMO_TESTEN_OHNE_VERSAND.cmd" (
 echo STOPP DEMO_STARTER_FEHLT
 set "MCR_RESULT=20"
 goto finish
)

echo PASS  V5_VERZEICHNISSTRUKTUR_VOLLSTAENDIG
echo INFO  Starte jetzt NUR die unveraenderte fiktive V5-Demo.
echo.
pushd "%MCR_KIT%"
if errorlevel 1 (
 echo STOPP V5_ZIELVERZEICHNIS_NICHT_ERREICHBAR
 set "MCR_RESULT=23"
 goto finish
)
call ".\DEMO_TESTEN_OHNE_VERSAND.cmd"
set "MCR_DEMO_EXIT=%ERRORLEVEL%"
popd

if not "%MCR_DEMO_EXIT%"=="0" (
 echo.
 echo STOPP ORIGINAL_V5_DEMO_EXITCODE_%MCR_DEMO_EXIT%
 echo Bitte nur die Ausgabemeldungen ab dem ersten STOPP sowie den Statuscode mitteilen.
 echo Der extrahierte Ordner befindet sich unter LOCALAPPDATA\MCR\Ticketbot_Wiederherstellung.
 set "MCR_RESULT=%MCR_DEMO_EXIT%"
 goto finish
)

echo.
echo PASS  V5_DEMO_STARTER_BEENDET
 echo.
echo Die Ausgangsdateien sind unveraendert. Dieser Starter hat KEINEN Echtversand ausgefuehrt.
echo Fuer den kontrollierten Echtlauf den frisch entpackten V5-Ordner benutzen.
echo Oeffne den entpackten Ordner jetzt im Explorer ...
start "" "%MCR_KIT%"
set "MCR_RESULT=0"
goto finish

:finish
echo.
echo MCR-Rettungsstarter Exitcode: %MCR_RESULT%
echo.
pause
exit /b %MCR_RESULT%
