@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "MCR_JS=%~dp0COMARCH_MAIL_ASSISTENT.js"
if not exist "%MCR_JS%" goto notExtracted
start "" notepad.exe "%MCR_JS%"
exit /b 0
:notExtracted
echo.
echo FEHLER: COMARCH_MAIL_ASSISTENT.js wurde neben diesem Starter nicht gefunden.
echo Das ZIP wurde sehr wahrscheinlich nicht vollstaendig entpackt.
echo Bitte das gesamte ZIP entpacken und diesen Starter dort erneut ausfuehren.
echo.
pause
exit /b 2
