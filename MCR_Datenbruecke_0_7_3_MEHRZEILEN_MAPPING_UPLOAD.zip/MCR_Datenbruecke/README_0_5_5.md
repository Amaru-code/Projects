# MCR Local Runner 0.5.5 – bewährter PAGE_FETCH

## Zweck
0.5.5 übernimmt den im isolierten Realtest am 30.09.2026 bestätigten MSG-Downloadweg direkt in den stabilen 0.5.3-Runner.

Der Realtest ergab:
`PAGE_FETCH -> Mail 1 -> PASS - gültige MSG`

## Downloadregel
1. Nachrichtenzeilen mit `GetFile?docId=...` werden direkt im aktuell angemeldeten COMARCH-Dokument ermittelt.
2. Neueste/unterste Nachrichtenzeile zuerst.
3. Die Ressource wird **innerhalb der angemeldeten COMARCH-Seite** mit
   `fetch(..., {credentials:'include', cache:'no-store', redirect:'follow'})`
   geladen.
4. Der Runner akzeptiert die Antwort nur, wenn:
   - 512 Byte bis 32 MiB,
   - Outlook/Compound-File-Magic vorhanden,
   - der interne MSG-Parser die Datei erfolgreich lesen kann.
5. Erst wenn PAGE_FETCH für alle Nachrichtenzeilen fehlschlägt, bleibt der bisherige Browserklick als Fallback erhalten.

## Unverändert
- vorhandenes INTL01-Mapping
- automatische eindeutige Member-Auswahl
- Human Gate bei mehreren Membern
- MercerID aus dem tatsächlich ausgewählten COMARCH-Member
- USC/DC/PP+/DB+ Lookup
- zusätzliche Beschreibung
- Second Level / Kategorien / Signatur
- Antwortvorbereitung
- harter Stopp vor Senden und Ticket speichern

## Start
`START_LOCAL_BOT.cmd`

Kein neues Mapping erforderlich. `private_data` und `.runtime\edge-profile` behalten.
