@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
set "NODE_EXE="
for %%N in (
  "C:\Users\Amaru-Zegarra\projects\Compiler\javascript\tools\node\node.exe"
  "%~dp0tools\node\node.exe"
) do if not defined NODE_EXE if exist "%%~N" set "NODE_EXE=%%~N"
if not defined NODE_EXE for /f "delims=" %%N in ('where node.exe 2^>nul') do if not defined NODE_EXE set "NODE_EXE=%%N"
if not defined NODE_EXE goto noNode
"%NODE_EXE%" "%~dp0src\local-bot.mjs" --demo --auto
pause
exit /b %errorlevel%
:noNode
echo Node.js nicht gefunden.
pause
exit /b 3
