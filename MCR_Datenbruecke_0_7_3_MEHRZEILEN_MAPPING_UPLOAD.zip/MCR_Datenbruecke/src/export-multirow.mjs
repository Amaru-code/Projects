import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {fileURLToPath} from 'node:url';
import readline from 'node:readline/promises';
import {stdin,stdout} from 'node:process';
import Core from '../lib/data-core.cjs';
import {sha256} from '../lib/core.mjs';
import {readWorkbook} from '../lib/xlsx-multirow.mjs';
import {makeMultirowMapping,validateMultirowMapping,lookupMultirow,SCHEMA} from '../lib/multirow-mapping.mjs';
import {readJsonBytes,publishActiveMapping,loadActiveMapping} from '../lib/active-mapping.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const args=process.argv.slice(2);const opt=n=>{const i=args.indexOf(n);return i>=0?args[i+1]:null;};
const strip=v=>String(v??'').trim().replace(/^"(.*)"$/s,'$1');
const rl=readline.createInterface({input:stdin,output:stdout});
function legacyMap(p){const x=readJsonBytes(p);if(x.value.schema===SCHEMA)validateMultirowMapping(x.value);else{Core.validateMap(x.value);Core.need(sha256(JSON.stringify(x.value.payload))===x.value.payloadSha256,'MAP_HASH','Alter Mapping-Hash abweichend.');}return x.value;}
function baseline(){
  const explicit=opt('--baseline');if(explicit)return {path:explicit,map:legacyMap(explicit)};
  if(fs.existsSync(path.join(root,'private_data','active-mapping.json')))return loadActiveMapping(root);
  const cfgPath=path.join(root,'config','local-runner-queue-send.json');let cfg={};if(fs.existsSync(cfgPath))cfg=readJsonBytes(cfgPath,65536).value;
  const dirs=[path.join(root,'private_data'),cfg.mappingDirectory].filter(d=>d&&fs.existsSync(d));const names=[];
  if(cfg.mappingPath&&fs.existsSync(cfg.mappingPath))names.push(cfg.mappingPath);
  for(const d of dirs)for(const n of fs.readdirSync(d))if(/^INTL01_mapping_.*\.json$/i.test(n))names.push(path.join(d,n));
  const unique=[...new Set(names.map(p=>path.resolve(p)))].sort((a,b)=>fs.statSync(b).mtimeMs-fs.statSync(a).mtimeMs||a.localeCompare(b));
  for(const p of unique){try{return {path:p,map:legacyMap(p)};}catch(e){console.log('Kein verwendbarer Quellnachweis: '+path.basename(p)+' ('+(e.code||'JSON_INVALID')+')');}}
  Core.fail('BASE_MAPPING_MISSING','Kein geprueftes altes Mapping gefunden. private_data erhalten und erneut starten.');
}
try{
  console.log('\n==============================================================\n MCR 0.7.3 - ALLE Bestandszeilen uebernehmen und Mapping aktivieren\n==============================================================');
  console.log('Excel/alte JSONs bleiben unveraendert. Kein Edge, keine Ticketaktion, kein Versand.');
  const base=baseline();const expected=base.map.payload.source.sha256;
  const filename=base.map.payload.source.filename||'INTL01_Gesamtdatenbestand_30.09.2025.xlsx';
  const candidates=[opt('--excel'),path.join(root,'..',filename),path.join(root,filename),path.join(os.homedir(),'projects','Aktive_Projekte','Ticket_bot',filename),String.raw`K:\INTL01\6_AU (Admin)\~ Data\~ Bestand Intel Gesamtuebersicht\${filename}`].filter(Boolean);
  let excel=candidates.find(p=>fs.existsSync(p));
  if(!excel)excel=strip(await rl.question('Vollstaendiger Pfad zur Original-.xlsx: '));
  Core.need(excel,'XLSX_MISSING','Kein Excel-Pfad angegeben.');
  const book=readWorkbook(excel);
  Core.need(book.meta.sha256===expected,'SOURCE_CHANGED','Die XLSX stimmt nicht mit dem SHA256-Quellstand des vorhandenen Mappings ueberein. Keine stille Vermischung.');
  console.log('Quellnachweis: '+path.basename(base.path));console.log('Excel-Quelle SHA256 PASS');
  console.log('Blatt: '+book.meta.sheet);console.log('Spalten:',book.meta.headers);
  console.log('REGEL: Je Kennung ALLE physischen Zeilen, jeweils eine Beschreibung, getrennt durch echte Zeilenumbrueche.');
  console.log('Auch identische Beschreibungszeilen bleiben erhalten. Kein Erstzeilen-/TPP-Override, keine Zusammenfassung.');
  console.log('C=DC; D=PP+; E=DB+ und pensIntel; F=tpp; L=USC; O=Gender. TPP wird gespeichert, kein neuer Textcode.');
  console.log('Leere Flags bleiben null. Ungueltige Werte sperren die ganze Person, nicht nur die fehlerhafte Zeile.');
  console.log('Anrede nur bei durchgehend gleichem M/F automatisch; sonst Rueckfrage. Maximal 450 Zeichen mit Zeilenumbruechen.');
  const map=makeMultirowMapping(book,{headerConfirmed:true,expectedSourceSha:expected});
  console.log('Neue Zusammenfassung:',map.payload.summary);
  // Explicitly verify the case which motivated this user-approved change; never hard-code its values.
  const target='10102131';
  if(Object.hasOwn(map.payload.entries,target)){
    const e=lookupMultirow(map,target);console.log('\nKontrolle ClientEEID '+target+': '+e.rowCount+' Zeile(n).');
    for(const r of e.records)console.log('  Excel-Zeile '+r.sourceRow+' | PensIntel='+r.pensIntel+' | TPP='+r.tpp+' | '+r.description);
    console.log('Fertige Beschreibung:\n'+e.description);
  }else if(Object.hasOwn(map.payload.blocked,target))console.log('Kontrollfall bleibt gesperrt: '+map.payload.blocked[target].codes.join(', '));
  const answer=strip(await rl.question('\nDiese Mehrzeilenregel und den neuen Mapping-Stand aktivieren? JA: '));
  Core.need(/^ja$/i.test(answer),'ABORT','Abgebrochen. Keine neue Datei geschrieben.');
  // Pin the same source again after operator review, in case Excel saved meanwhile.
  Core.need(sha256(fs.readFileSync(excel))===book.meta.sha256,'SOURCE_CHANGED','Excel wurde waehrend der Freigabe geaendert. Erneut starten.');
  const active=publishActiveMapping(root,map);
  console.log('\n==============================================================\n FERTIG - MEHRZEILEN-MAPPING AKTIV\n==============================================================');
  console.log('NEW_MAPPING='+active.path);console.log('SHA256='+active.fileHash);
  console.log('ACTIVE_MAPPING='+active.pointerPath);console.log('Mehrzeilige Personen: '+map.payload.summary.multirowKeys);
  console.log('Gesperrte Personen: '+map.payload.summary.blockedKeys);
  console.log('Der neue START_FULL_QUEUE_RUN.cmd liest exakt diesen Stand. Kein Rueckfall auf altes Gender-JSON.');
  console.log('Keine neue Mail erzeugt/gesendet. Naechster Schritt: START_FULL_QUEUE_RUN.cmd.');
}catch(e){console.error('\nSTOP: '+(e.code||'ERROR')+' - '+e.message);process.exitCode=1;}finally{rl.close();}
