import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const code='/* MCR Datenbruecke 0.2.2 - generated from lib/data-core.cjs + browser/ui.js. */\n(()=>{\nconst module={exports:{}};\n'+fs.readFileSync(path.join(root,'lib/data-core.cjs'),'utf8')+'\nconst Core=module.exports;\n'+fs.readFileSync(path.join(root,'browser/ui.js'),'utf8')+'\n})();\n';
fs.writeFileSync(path.join(root,'COMARCH_DATENBRUECKE.js'),code);

const modules=[['Core','lib/data-core.cjs'],['Msg','lib/msg.cjs'],['Person','lib/person.cjs'],['Widget','lib/member-widget.cjs'],['ListDOM','lib/member-list.cjs'],['Profile','lib/member-profile.cjs'],['Suggest','lib/member-suggest.cjs'],['Description','lib/description-field.cjs']];
const v3='/* MCR Mail-Assistent 0.3.6. Offline MSG parser and supervised member workflow. */\n(()=>{\n'+modules.map(([name,file])=>'const '+name+'=(()=>{const module={exports:{}};\n'+fs.readFileSync(path.join(root,file),'utf8')+'\nreturn module.exports;})();\n').join('')+fs.readFileSync(path.join(root,'browser/mail-ui.js'),'utf8')+'\n})();\n';
fs.writeFileSync(path.join(root,'COMARCH_MAIL_ASSISTENT.js'),v3);

const prep='/* MCR Ticket-Vorbereiter 0.4.1. No send/save. */\n(()=>{\nconst Prep=(()=>{const module={exports:{}};\n'+fs.readFileSync(path.join(root,'lib/ticket-prep.cjs'),'utf8')+'\nreturn module.exports;})();\n'+fs.readFileSync(path.join(root,'browser/ticket-prep-ui.js'),'utf8')+'\n})();\n';
fs.writeFileSync(path.join(root,'COMARCH_TICKET_VORBEREITER.js'),prep);


// One-console runner: starts the data assistant and automatically transitions to
// the ticket preparer after the description was actually inserted and verified.
// It deliberately preserves the hard stop before send/save.
const mailModules=modules.map(([name,file])=>'const '+name+'=(()=>{const module={exports:{}};\n'+fs.readFileSync(path.join(root,file),'utf8')+'\nreturn module.exports;})();\n').join('');
const prepModule='const Prep=(()=>{const module={exports:{}};\n'+fs.readFileSync(path.join(root,'lib/ticket-prep.cjs'),'utf8')+'\nreturn module.exports;})();\n';
const prepUi=fs.readFileSync(path.join(root,'browser/ticket-prep-ui.js'),'utf8');
const mailUi=fs.readFileSync(path.join(root,'browser/mail-ui.js'),'utf8');
const runner='/* MCR Ticket Runner 0.4.1. One console injection. No send/save. */\n(()=>{\n'+
'const __runnerTop=(()=>{try{return window.top}catch{return window}})();\n'+
'function __startPrep(){if(__runnerTop.MCR_PREP)return __runnerTop.MCR_PREP;\n'+prepModule+prepUi+'\nreturn __runnerTop.MCR_PREP;}\n'+
mailModules+mailUi+'\n'+
'let __runnerSwitched=false;const __runnerWatch=setInterval(()=>{try{const d=__runnerTop.MCR_MAIL?.diagnostic?.();if(!__runnerSwitched&&d?.flow?.descriptionWritten){__runnerSwitched=true;clearInterval(__runnerWatch);setTimeout(__startPrep,250);}}catch{}},400);\n'+
'__runnerTop.MCR_RUNNER=Object.freeze({version:"0.4.1",startPrep:__startPrep,diagnostic:()=>({schema:"MCR_RUNNER_DIAGNOSTIC_V1",version:"0.4.1",phase:__runnerTop.MCR_PREP?"PREP":__runnerTop.MCR_MAIL?"MAIL":"IDLE",automaticSend:false,automaticSave:false})});\n'+
'console.info("MCR Ticket Runner 0.4.1 aktiv. Ein Skript bis zum Pre-Send-Gate; kein Senden, kein Ticket-Speichern.");\n})();\n';
fs.writeFileSync(path.join(root,'COMARCH_RUNNER.js'),runner);
