import path from 'node:path';import {fileURLToPath} from 'node:url';
import {verifyPackage} from '../lib/package-integrity.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
try {
 const [major,minor]=process.versions.node.split('.').map(Number);
 if(major<22||(major===22&&minor<15))throw new Error('Node.js >=22.15 wird fuer dieses Paket vorausgesetzt.');
 const r=verifyPackage(root);
 console.log('Paketintegritaet PASS | Version:',r.version,'| Dateien:',r.files,'| Node:',process.versions.node);
} catch(e){console.error('STOP:',e.code??'PACKAGE_ERROR','-',e.message);process.exitCode=1;}
