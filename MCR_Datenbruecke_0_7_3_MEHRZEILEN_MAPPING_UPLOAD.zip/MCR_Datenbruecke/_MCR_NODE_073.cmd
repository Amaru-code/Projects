@echo off
rem Shared lookup. Does not install anything or change PATH.
set "MCR_NODE="
if defined NODE_EXE if exist "%NODE_EXE%" set "MCR_NODE=%NODE_EXE%"
if not defined MCR_NODE if exist "%USERPROFILE%\projects\Compiler\javascript\tools\node\node.exe" set "MCR_NODE=%USERPROFILE%\projects\Compiler\javascript\tools\node\node.exe"
if not defined MCR_NODE if exist "%~dp0tools\node\node.exe" set "MCR_NODE=%~dp0tools\node\node.exe"
if not defined MCR_NODE for /f "delims=" %%N in ('where node.exe 2^>nul') do if not defined MCR_NODE set "MCR_NODE=%%N"
if not defined MCR_NODE (
 echo STOP: node.exe fehlt. Vorhandene Portable-Node-Installation benoetigt.
 exit /b 3
)
for %%N in ("%MCR_NODE%") do if /i not "%%~nxN"=="node.exe" (
 echo STOP: Erwartet wird node.exe, keine Excel-Datei.
 exit /b 3
)
"%MCR_NODE%" -e "const [a,b]=process.versions.node.split('.').map(Number);if(a<22||(a===22&&b<15))process.exit(3)"
if not "%errorlevel%"=="0" exit /b 3
exit /b 0
