@echo off
start "" "%~dp0MAIL_DEMO.html"
