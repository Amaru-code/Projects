# Qualifikationsbericht — MCR Mail-Assistent 0.3.0

## Ergebnis und Reichweite

**182 Node-Tests bestanden, 0 fehlgeschlagen / übersprungen.**
Enthalten sind die bisherigen 136 Prüfungen sowie 36 MSG-/Namensprüfungen und
10 neue statische Quellcode-/Starterprüfungen.

**26 neue Browser-Funktionsprüfungen bestanden.**
Zusätzlich wurden die 20 vorhandenen Sheetfix-/Altes-Panel-Prüfungen erneut ausgeführt.
Keine echte Mail wurde versendet, kein echtes Ticket geändert. Browser-Tests laufen
an einer synthetischen Nachbildung, nicht an COMARCH.

## Reale Testumgebung dieses Pakets

- Node.js 22.16.0 unter Linux.
- Chromium unter Linux, über Python Playwright angesteuert.
- DOM und Demo-Skripte wurden auf `about:blank` injiziert. Vorhandene Browser-
  Navigationsrichtlinien wurden nicht geändert oder umgangen.
- SHA256 wurde im Browser-Testharness durch Python hashlib bereitgestellt, da die
  injizierte `about:blank`-Seite dort kein nativer Secure Context ist.
  Die ausgelieferte Produktionsdatei enthält diesen Testersatz **nicht**.
- Browser-Dateiauswahl wurde mit synthetischem MSG und synthetischem JSON getestet.
- Ein eigener, separater CFB-Fixture-Writer erzeugt die fiktiven MSG-Dateien.
  Das ist keine unabhängige Microsoft-Outlook-Qualifikation. Ein zusätzlicher
  Fremdparser konnte mangels Netzwerkzugang zur Paketquelle nicht installiert werden.

## Geprüfte MSG-Fälle

Unicode-Klartext, ANSI Windows-1252, ASCII ohne Codepage, 512- und 4096-Byte-
Sektoren, MiniFAT, normale FAT, DIFAT-Erweiterung, Stream-/Verzeichniszyklen,
Abschneiden, falsche Magic Bytes, falsche Codepage, Längengrenzen, nicht-null
Buffer-Offsets und UTF-8-Textfallback.

Angehängte Nachrichten werden nicht als Hauptnachricht ausgewertet. HTML-only,
RTF-only, nicht unterstützte Nachrichtentypen und verschlüsselte Klassen stoppen.
Der Parser führt keine Inhalte aus und öffnet keine Anhänge. Ein PDF/OCR-Fallback
wurde nicht eingebaut.

## Geprüfter UI-Ablauf

Bestehendes Mapping laden → Quellenfreigabe → MSG-Datei auswählen → Name aus
Adressblock/Signatur erkennen → Vor-/Nachname und Ticket bestätigen → Suchname
im bekannten Member-Feld setzen → sichere Einzelauswahl oder bewusstes Warten bei
Mehrfach-/unbekannter Liste → Member-ID lesen → unveränderte B/C/D/E/L-Regel →
Beschreibung auf gesonderten Klick einsetzen.

Mehrfachtreffer wurden nicht automatisch gewählt. Ein echter Browser-Mausklick
auf einen der mehreren Testtreffer setzte den Lookup fort. Ein bloß per Skript
geänderter Feldwert reichte nicht. Ohne beobachteten Klick konnte die ausdrücklich
bediente Bestätigung den Vorgang fortsetzen. Mitglieds- und Ticketwechsel,
Mail-/Member-Konflikte, geänderte Namen, manipulierte Mapping-Nutzdaten und
abweichender vorhandener Beschreibungstext wurden blockiert.

HTML/Script/Tracking-Pixel im Mailtext blieben inaktiv. Im synthetischen Ablauf
wurden keine Netzwerkrequests des Helfers beobachtet. In COMARCH können Eingabe-
ereignisse selbstverständlich die normalen Anfragen der Anwendung auslösen.

## Nicht qualifiziert / keine Behauptung produktiver Vollständigkeit

- Windows-CMD-Ausführung, Edge auf dem Rechner des Benutzers.
- Original-MSG-Dateien des Benutzers, seine tatsächliche Arbeitsmappe und sein Mapping.
- Echte COMARCH-2016.1-Autocomplete-Struktur, Backend-Übernahme und AJAX-Neurendering.
- Universelle Namens-/Identitätserkennung, automatische Anrede oder Empfängeränderung.
- Senden, Sendebestätigungsdialoge, Ticket speichern, Queue-Durchlauf, Wiederanlauf nach Versand.
- Automatischer Download der Original-Mail. Die Datei wird in dieser Version bewusst selbst ausgewählt.
- Vollständige Unterstützung sämtlicher Varianten des MSG-Formats.

Die automatische Einzelauswahl ist deshalb nur ein streng begrenzter Adapter für
explizit verknüpfte ARIA-Widgets mit vollständiger Trefferzahl eins. Für das bisher
vermessene COMARCH wurde die echte Trefferliste nicht qualifiziert; manueller Klick
und Bestätigung sind der vorgesehene Fallback.

## Belege

`MAIL_NODE_TEST_RESULT.tap`: tatsächlicher Node-Prüflauf.
`MAIL_BROWSER_TEST_RESULT.json`: 26 neue Browserfälle.
`SHEETFIX_BROWSER_TEST_RESULT.json`: erneute 20 Legacy-Prüfungen.
`MAIL_UI_TEST.png`: synthetische UI-Ansicht, keine Kundendaten.
`MAIL_CHANGESET.json`: Vergleich zur 0.2.2-Grundlage.
`MAIL_SECRET_SCAN.json`: begrenzter Paket-Scan; keine allgemeine Datenschutzgarantie.

ZIP-CRC, Pfadsicherheit, Symlinks und alle Manifest-/SHA256SUMS-Payloads werden
vor Bereitstellung erneut geprüft. Der finale ZIP-SHA256 wird außerhalb des ZIP
in der Chat-Antwort genannt.
