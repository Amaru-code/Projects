# MCR Mail-Assistent 0.3.4 — mousedown-Auswahl und MercerID-Ausgabe

## Diesmal KEIN neuer Excel-Export

Das mit 0.3.2 erzeugte JSON bleibt verwendbar. Datenregeln, Leerwertbehandlung,
USC-/Plankürzel, Mappingformat, MSG-Leser und Namenserkennung wurden nicht geändert.
Dieses Update korrigiert die Browseranbindung. Es ist weiterhin kein Queue-Bot
und versendet oder speichert keine Tickets selbstständig.

## Für den aktuell bereits ausgewählten Member

1. ZIP vollständig entpacken. Den enthaltenen Ordner **MCR_Datenbruecke** mit
   dem bisherigen gleichnamigen Ordner zusammenführen; gelieferte Paketdateien
   ersetzen. Den bisherigen Ordner nicht löschen. Eigene Mails, Excel,
   `private_data` und Node-Runtime behalten.
2. **MAIL_ASSISTENT_OEFFNEN.cmd** starten. Gesamten Code aus Notepad kopieren,
   in der Edge-DevTools-Konsole des echten COMARCH-Tickets (Kontext möglichst
   `top`) einsetzen. Im Panel muss **0.3.4** stehen. Keine Unternehmensrichtlinie
   für DevTools oder Scriptausführung umgehen.
3. Vorhandenes JSON aus `private_data` laden, Quellenstand bestätigen. Original-MSG
   dieses Tickets laden. Richtigen Namensvorschlag, Vorname/Nachname und ggf.
   MercerID-Hinweis prüfen; Identitätskästchen setzen.
4. Den bereits korrekt ausgewählten COMARCH-Member **nicht löschen**. Auf
   **Übernommene Person prüfen → Schritt 4** klicken. Nach etwa einer Sekunde
   stabiler Feld-/MercerID-Werte wird der Bestandsabgleich versucht.
5. Schritt 4 zeigt die Beschreibung oder einen konkreten Bestandsfehler. Die
   Beschreibung erst auf **Beschreibung kopieren** bzw. **Beschreibung in
   COMARCH einsetzen** übernehmen. Senden und Ticket speichern bleiben manuell.

Der Hauptnachweis einer Auswahl ist nicht der Suchtext: Die unabhängige
MercerID-Stammdatenanzeige muss, soweit vorhanden, zur Kennung des ausgewählten
Members passen. Die Ticket-ID dient nur zur Absicherung des geöffneten Falls
und wird niemals als Excel-Suchschlüssel verwendet.

## Sichtbare MercerID ist gefüllt, aber der Helfer kann sie trotzdem nicht lesen

Es gibt jetzt einen direkten Weg, das konkrete Ausgabeelement zu verbinden:

1. In Schritt 3 **Nur bei Erkennungsproblemen: Element einmal verbinden** öffnen.
2. **MercerID-Anzeige verbinden** anklicken.
3. **ALT gedrückt halten und auf die ausgefüllte MercerID direkt unter dem
   COMARCH-Member-Feld klicken**. Nicht auf das Suchfeld, nicht auf eine offene
   Vorschlagszeile und nicht auf eine Nummer im Mailtext klicken.

Der Markierungsklick verändert kein COMARCH-Feld. Akzeptiert wird nur eine
sichtbare, atomare ID-Ausgabe im gleichen Formular, nahe dem Member-Feld, die
zur tatsächlich ausgewählten Person passt. Widersprüche werden nicht durch
manuelle Bindung überstimmt. Der anschließende Schritt-4-Abgleich bleibt
regelbasiert. Die Bindung ist nur im Speicher der laufenden Seite gültig.

Alternative für Entwickler: die wirkliche MercerID-Ausgabe über **Untersuchen**
auswählen, dann `MCR_MAIL.bindProfile($0)` ausführen. Es gelten dieselben Prüfungen.
Das ist keine Funktion zum Überschreiben einer ID.

## Bei einem noch nicht ausgewählten Member

Nach Mapping-/Mail-/Namensprüfung **Member suchen** wählen. Suchformat bleibt
**Nachname Vorname**. Der Helfer erkennt weiterhin bekannte ARIA-/ICE-Listen und
hat zusätzlich einen Adapter für `suggestions.js` mit `mousedown`-Auswahl.

- Ein eindeutig gebundener, stabiler Einzeltreffer mit exaktem geprüftem Namen
  und (beim Custom-/Legacy-Adapter) geprüfter MercerID kann einmal ausgewählt werden.
- Mehrere gelieferte Treffer bleiben immer zur Auswahl durch den Anwender.
  Versteckte zusätzliche Zeilen zählen mit. Eine Listenanzeige beweist nicht die
  Eindeutigkeit in der gesamten Datenbank.
- Bei unbekannter Struktur wird nicht irgendwo nach dem ersten passenden Namen
  geklickt. Den echten Vorschlag selbst auswählen oder die Zeile explizit verbinden.

### Unbekannte Vorschlagsliste einmal verbinden

Die Liste geöffnet lassen. Unter **Element einmal verbinden** auf
**Vorschlagszeile verbinden** klicken. ALT halten und auf den richtigen echten
Vorschlag klicken. Dieser Markierungsklick bestätigt zunächst nur die technische
Liste, noch nicht den Member. Bei einem passenden Einzeltreffer kann danach
höchstens ein automatisches `mousedown` ausgelöst werden. Bei mehreren Treffern
weiterhin selbst regulär auswählen. Name und MercerID-Hinweis müssen geprüft sein.

Der Adapter verändert keine versteckten ID-Felder und ruft weder SuggestServlet
noch iceSubmit direkt auf. Er aktiviert den realen Zeilen-Handler einmal. Dieser
COMARCH-Handler kann normale COMARCH-Serveranfragen auslösen. Der Erfolg wird
nicht aus HTTP-Logs oder Rückgabewerten abgeleitet, sondern aus der danach
übernommenen und passenden MercerID-Ausgabe.

**Member-Suchfeld anzeigen (keine Auswahl)** scrollt und markiert lediglich das
Suchfeld. Es ist kein Knopf zur Auswahl einer Person und löst keine zusätzliche
Fokus-/Suchanfrage aus.

## Technische Änderungen

- Eigener Custom-Adapter statt Voraussetzung einer ICE.Autocompleter-Registry.
  Erstmalige Portal-Erkennung erfordert die passende Feldinitialisierung,
  `suggestions.js`, eine eng eingegrenzte Liste beim Feld und mousedown-Handler
  auf den Zeilen. Andernfalls explizite Anwenderbindung.
- Für diesen Adapter genau **ein mousedown**, kein zusätzlicher click/mouseup
  und kein anschließender direkter Submit-Aufruf. Keine Wiederholung bei
  unklarer Übernahme. Script-Ereignisse bleiben untrusted; Prüfungen der Seite
  werden nicht umgangen.
- MercerID-Leser unterstützt verschachtelte Label-/Wert-Zellen, Wrapper,
  Label-for, Definition Lists und angrenzende Textknoten. Keine Suche nach
  beliebigen Nummern im Dokument; Suchfeld, Vorschlagszeile, versteckte Ausgabe
  und unpassende Nachbarfelder werden nicht als Stammdaten ausgegeben.
- Manuelle Bestätigung wartet auf stabile Werte, statt eine gerade laufende
  Formularersetzung als Erfolg auszugeben. Ein bestehender korrekter Member kann
  ohne erneute Suche übernommen werden.
- Nach einem Lookup invalidiert eine geänderte unabhängige MercerID-Ausgabe
  das Ergebnis. Fall-, Namens-, ID-, Mehrdeutigkeits- und Bestandsprüfungen bleiben.
- Diagnose enthält nun die Erkennungsroute der Profilanzeige und das
  Auswahlereignis; weiterhin keine Personenwerte, Mailtexte oder Zellwerte.

## Unveränderte Regeln und Grenzen

B = ClientEEID; L = USC; C=1 → DC, D=1 → PP+, E=1 → DB+; Reihenfolge
DC;PP+;DB+. Leere C/D/E bleiben im JSON `null` und erzeugen kein Kürzel.
Fehler, doppelte Kennungen, fehlender USC und fehlende Formel-Caches bleiben
zur Prüfung gesperrt. Bestandsdaten werden weder in Excel noch im JSON geändert.

Senden, Ticket speichern, Kategorien, Signatur, Antwort, Anrede, Empfänger und
Queue-Navigation bleiben manuell. Keine Geschlechts- oder Empfängerableitung.
MSG-Klartext wird lokal gelesen; HTML-/RTF-only oder geschützte Varianten können
weiterhin den manuellen Textweg benötigen. Anhänge werden nicht geöffnet.

Mail und gesamtes minimiertes Mapping werden in den Speicher der COMARCH-Seite
geladen. Dies ist **keine isolierte Datenschutz-Sandbox**. Nur betrieblich
freigegeben nutzen. Kein externer KI-Dienst, keine eigene Hintergrundübertragung.
`private_data` ist nicht verschlüsselt und gehört nicht in Git oder den Chat.

Nach diesem Ticket **Neuer Fall**, nach Nutzung **Schließen**. Seitenwechsel
können erneutes Einsetzen und Laden des Mappings erforderlich machen. Escape
bricht eine aktive Elementmarkierung ab. **Suche / Warten stoppen** deaktiviert
anstehende Automatisierung, macht aber keine bereits erfolgte COMARCH-Auswahl
rückgängig. Kein Probeversand, um Dialoge zu testen.

## Diagnose und Tests

Bei einem weiteren Fehler nur **Diagnose-ZIP** verwenden und das erzeugte
`MCR_MAIL_..._UPLOAD.zip` weitergeben. Nicht die vollständige Konsole, die MSG,
die Excel-Datei oder das Mapping hochladen.

**SELBSTTEST.cmd** prüft die Paketdateien und die Node-Tests. Node >=22.15,
vorhandene portable Runtime, kein npm install. Für diesen Browser-Patch ist
keine neue Runtime erforderlich. **MAPPING_ERSTELLEN.cmd** und
**MAPPING_PRUEFEN.cmd** bleiben für spätere Quellenaktualisierungen verfügbar.

Aktueller Bericht: `docs/MOUSEDOWN_TESTBERICHT.md`.
Aktuelle Browserqualifizierung: `tests/profile_mouse_browser.py` mit
`MCR_GROUP=1` bis `7`. Diese Python-/Playwright-Tests sind Entwicklernachweise,
keine zusätzliche Voraussetzung am Arbeitsplatz. Frühere Python-Testläufe und
Berichte im Paket dokumentieren frühere Releases und UI-Beschriftungen.

Die produktive COMARCH-Komponente und ihre Originaldatei `suggestions.js` wurden
hier nicht ausgeführt bzw. eingesehen. Der neue Adapter ist anhand des
bereitgestellten Callstacks und nachgebildeter Browserfälle getestet. Ein
bestandener synthetischer Test ist keine Zusage über jede echte COMARCH-Variante.
