# MCR 0.3.5 — Prüfbericht Beschreibungsfeld

## Ergebnis und Gegenstand

357 Node-Tests PASS, 0 FAIL, 0 SKIP. Nach zufälliger Verlagerung des gesamten
Paketordners erneut 357/357 PASS. 34 gezielte Browserprüfungen und 43 bestehende
Member-/Profil-Browserregressionen PASS, insgesamt 77. Keine Page-Errors in den
abschließenden Browserläufen. Die genaue Bundle-SHA256 ist in den JSON-Berichten
und `DESCRIPTION_QUALIFICATION.json` gebunden.

Geändert: ausschließlich die Browser-Beschreibungsanbindung und dazugehörige
Fehlerbehandlung, UI, Tests, Build-Einbindung, Anleitung und Versionsangaben.
Die zuvor funktionierenden Member-/Profilmodule, Mail-/Namenserkennung und
Excel-/Mappingregeln wurden bytegleich übernommen (14 Module; Nachweis in
`DESCRIPTION_UNCHANGED.json`). Der Windows-Selbsttest umfasst nun auch die schon
bestehenden Profiltests und die neuen Beschreibungsprüfungen.

## Reproduzierte Altfehler

Mit dem unveränderten 0.3.4-Bundle wurde in einer synthetischen Maske gezeigt:
Eine verschachtelte Beschriftung plus Textarea mit anderer dynamischer ID liefert
`DESCRIPTION_FIELD`, obwohl der gültige Member-basierte Lookup vorher vorhanden
war. Die alte Fehlerbehandlung löscht dann auch die Vorschau und deaktiviert
„Beschreibung kopieren“. Das ist dieselbe Fehlerklasse wie im gemeldeten Foto;
die genaue private DOM-Anordnung ist weiterhin nicht bekannt.

## Neue Nachweise

- Semantische Zielbindung für label-for, Wrapper, verschachtelte Tabellenzellen,
  ARIA-Namen, aria-labelledby, Definition Lists, umschließende Labels, NBSP und
  zerlegte Umlaute. Keine Abhängigkeit von einer historischen j_id.
- Reale ALT-Mauseingabe in der Browserfixture verbindet exakt eine Textarea,
  ohne deren input/change-Handler auszulösen oder einen Wert einzutragen.
- Danach ausdrücklich freigegebene Übernahme: ein nativer Value-Setter-Aufruf,
  input/change am Feld mit erneuter Identitätsprüfung dazwischen, unmittelbarer
  und verzögerter DOM-Readback. Identischer vorhandener Text erzeugt keine
  Wiederholung und keine weiteren Ereignisse.
- Fehlendes/mehrdeutiges Zielfeld, bereits belegtes Feld, readonly/disabled,
  maxlength-Konflikt und verzögerter Seiten-Reset: kein stiller Verlust des noch
  gültigen Lookups. Einsetzen wiederholt sich nicht selbständig.
- Die Kopieraktion erhält den unveränderten Text auch nach Zielfeldfehlern.
  Ein Clipboard-Fehler wird gesondert behandelt, ohne die Vorschau zu löschen.
- Falsches Formular, Member-Input, Body/Label statt Textarea, Mail-/Editorframe,
  ein separat als Kommentar beschriftetes Feld und veraltete Elementverbindungen
  werden abgewiesen. Zwei Beschreibungsfelder erfordern explizite Zuordnung.
- Wird der Member während eines input-Handlers verändert, bleibt change aus;
  der ungültige Lookup wird zurückgenommen. Ticketwechsel vor Einfügen erzeugt
  keine Schreibaktion. Spätere manuelle Textänderung wird nicht überschrieben.
- Schließen stoppt die ausstehende Prüfung. Keine Send-/Save-/Form-Submit-
  Aktivierung durch den Assistenten in den Browserfixtures.
- Diagnose-ZIP mit CRC/Hashprüfung und Prüfung auf verbotene fiktive Werte:
  keine Namen, Kennungen, Mail-/Feldtexte, Selektoren oder URLs im Diagnosebericht.

## Testumgebung und Grenzen

Node 22.16.0 unter Linux. Browser: installiertes Chromium, nachgebildete DOMs,
fiktive Daten. Die Container-Richtlinie blockiert localhost-Navigation des
Browsers. Deshalb laufen die Tests auf `about:blank` mit einer ausschließlich
im Testharness eingesetzten SHA256-Brücke zu Python hashlib. Die gezielten
Clipboard-Tests verwenden ebenfalls ausschließlich im Testharness einen Stub.
DOM-, Beschriftungs-, Pointer-/Maus- und input/change-Ereignisse werden im realen
Chromium-Browser geprüft. Es wurden keine Browserrichtlinien umgangen.

Die Produktdatei enthält keine Testbrücke: Sie verlangt WebCrypto im zulässigen
Browserkontext und verwendet die echte Clipboard-API mit Fehlerbehandlung.
Native WebCrypto/OS-Clipboard in diesem Portal wurden hier nicht qualifiziert.

Windows-CMD, COMARCH, die private Maske sowie reale Bestandsdatei/MSG wurden
nicht ausgeführt oder gelesen. Die unmittelbare bzw. verzögerte Sichtprüfung im
DOM beweist keine dauerhafte Serverspeicherung. Die Prüfzeit ist begrenzt;
Seitenhandler können später noch Änderungen vornehmen. Kein Probeversand und
keine echte Ticket-Speicherung wurden ausgelöst. Die explizite Textfeldbindung
ist der lokale Rückfallweg bei unbekannter Portalstruktur.

## Reproduktion

- `node --test tests/*.test.mjs`
- Gezielte Browsertests: `MCR_GROUP=1` bis `4`, dann
  `python tests/description_browser.py`.
- Memberregressionen: `MCR_GROUP=1` bis `7` und
  `MCR_OUT_PREFIX=DESCRIPTION_MEMBER_REGRESSION`, dann
  `python tests/profile_mouse_browser.py`.
- Die Browsertests sind Entwicklernachweise und keine Voraussetzung zur
  Benutzung am Arbeitsplatz. Dort genügt für lokale Node-/Pakettests
  `SELBSTTEST.cmd` mit der vorhandenen Node-Installation.

Ältere Prüfberichte im Paket gehören zu früheren Versionen und UI-Beschriftungen.
Nur die DESCRIPTION-Berichte beschreiben den aktuellen Änderungsumfang.
