# MCR Datenbrücke 0.2.2 – Prüfbericht

Datum: 29.09.2026. Getestete Umgebung: Linux x86-64, Node.js 22.16.0; Browserprüfung mit lokalem Chromium und Playwright.

## Ergebnis

- 136/136 Node-Tests bestanden, 0 Fehler, 0 Skips. Davon 99 übernommene Tests (einschließlich acht statischer CMD-Quellprüfungen) und 37 neue Sheetfix-Regressionen. Rohbeleg: `SHEETFIX_NODE_TEST_RESULT.tap`.
- 20/20 synthetische Browser-Prüfungen bestanden. Rohbeleg: `SHEETFIX_BROWSER_TEST_RESULT.json`.
- Groß-/Kleinschreibung, äußere Leerzeichen und NBSP, Namenskollisionen, kein Fuzzy-Fallback, echte Quellnamen im JSON, Abweisung anderer Quellen, alte V1-Mappings, unveränderte Headerprüfung, Read-only-Dateizugriff und Bindung des Quellenhashes geprüft.
- Tatsächlicher Node-CLI-Durchlauf mit quotiertem Dateipfad, Blatt `output`, ausdrücklichem `JA`, JSON-Export und anschließendem Aufräumen der fiktiven Testdateien bestanden. Dies ist kein Windows-CMD-Test.
- Defekt gezielt gegen unveränderte 0.2.1 reproduziert: `SHEETFIX_REPRODUCTION.json`.
- Fachliche B/C/D/E/L-Auswertung, Mailanalyse, manuelle Freigaben und COMARCH-Leseoberfläche unverändert; nur gemeinsame Blattvalidierung, Quelle und Exportdiagnose angepasst. Dateivergleich: `SHEETFIX_CHANGESET.json`.

## Browser-Testgrenzen

Verwendet wurde ein synthetischer DOM auf `about:blank`, ohne Navigation zum echten COMARCH. Weil diese Umgebung kein nativer sicherer Browserkontext ist, wurde SHA-256 ausschließlich im Test durch Python hashlib bereitgestellt. Der Produktcode wurde dafür nicht verändert. Dies qualifiziert weder den echten Browser-Sicherheitskontext noch eine Unternehmensrichtlinie. Der Test prüft insbesondere, dass das neue JSON mit `source.sheet = output` geladen und im bestehenden Panel angezeigt werden kann.

Keine Ticketfelder wurden vom Helfer geändert, keine E-Mails gesendet, keine Tickets gespeichert und während der Lese-/Lookup-Prüfung keine Netzwerkrequests durch den Helfer festgestellt.

## Nicht geprüft

Die tatsächliche Windows-Installation und Node 24.19.0 des Nutzers, die lokale/Netzlaufwerk-Excel-Datei, deren fachliche Aktualität, weitere unbekannte OOXML-Sonderfälle und die produktive COMARCH-Oberfläche. Der nächste lokale Lauf muss weiterhin Quelle, Spalten L sowie die Datenzeile bestätigen. Kein Erfolg des Gesamtworkflows wird aus diesem Patch abgeleitet.

## Reproduktion

`node --test tests/*.test.mjs` oder unter Windows `SELBSTTEST.cmd`. Optionale Browser-Entwicklerprüfung: `python tests/sheetfix_browser_qualification.py` mit installiertem Python/Playwright/Chromium; nicht erforderlich für die normale Nutzung.

Die historischen Berichte `TESTBERICHT.md`, `BROWSER_TEST_RESULT.json` und `STARTER_FIX_*` bleiben als Belege ihrer jeweiligen Vorversionen erhalten. Maßgeblich für diesen Patch sind die `SHEETFIX_*`-Dateien.

## Integrität

MANIFEST.json und SHA256SUMS.txt werden für dieses Paket neu erzeugt. Der äußere ZIP-Hash wird separat veröffentlicht. CRC, sichere relative ZIP-Pfade, Payload-Hashes und ein begrenzter textbasierter Secret-Scan wurden vor der Übergabe geprüft. Dies ist keine digitale Signatur und kein vollständiges DLP- oder Sicherheitsaudit.
