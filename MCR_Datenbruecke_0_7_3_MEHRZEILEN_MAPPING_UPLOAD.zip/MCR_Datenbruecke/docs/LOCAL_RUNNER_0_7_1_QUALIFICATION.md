# MCR Local Runner 0.7.1 – Qualification

- Real defect addressed: `MEMBER_COMMIT` despite visibly populated COMARCH profile fields.
- Root cause: previous commit detector required `INTL01-*` inside `mainForm:member-value-id`.
- Fix: semantic same-form profile read of exact labels `MercerID:`, `Vorname:`, `Nachname:` plus reviewed-name match.
- Recovery gate: already committed profile is reused only when it matches the current mail person.
- Full Node suite: 394 PASS / 0 FAIL.
- Synthetic full-loop demo: PASS with member input containing only `Mustermann Max` and separate profile rows containing `INTL01-99900001`, `Max`, `Mustermann`.
