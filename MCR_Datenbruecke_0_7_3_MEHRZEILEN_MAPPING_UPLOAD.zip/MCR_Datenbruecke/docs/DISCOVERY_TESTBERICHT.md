# MCR 0.3.3 — Prüfbericht Auswahlbindung

## Ergebnis
- 317/317 Node-Tests bestanden, 0 Fehler/Skips.
- 317/317 Node-Tests nach Kopie in einen zufälligen Pfad mit Leerzeichen und Unicode erneut bestanden.
- 32/32 neue synthetische Browserprüfungen bestanden.
- 26/26 bestehende Mail-/ARIA-Browserregressionsprüfungen mit dem neuen Bundle bestanden.
- 11 Daten-/Parserdateien byte-identisch zum manifestgeprüften 0.3.2-Basispaket, darunter Excel-Leser, Export, Mappingregeln, MSG-Leser, Namenslogik und Bestandsdiagnose.

## Was der gemeldete Fehler tatsächlich belegt
Der Anwenderbericht zeigt `REGISTRY_UNAVAILABLE`, `autoClickAttempted=false`, `profileIdPresent=false`, `lookupAttempted=false`. Die Anwendung hat damit keinen automatischen Auswahlklick ausgelöst und den Bestand noch nicht für den Member geprüft. Es ist keine Fehlermeldung des JSON-Lookups. Die frühere Auswahlbindung setzte einen Registry-Schlüssel gleich der Feld-ID und ein davon abgeleitetes `_div`-Element voraus. Diese Bindung ist für die gemeldete Oberfläche nicht nachgewiesen.

Das neue Bundle sucht in begrenzten bekannten Registries und Monitoren nach einer Instanz mit identischer Live-Input-Referenz und verwendet deren tatsächlich gebundenes Popup. Ist das nicht möglich, gibt es keinen geratenen globalen Klick. Ein echter manueller Auswahlklick wird beobachtet. Nur nach passender gefüllter MercerID-Anzeige kann eine strukturell erkennbare lokale oder Portal-Liste für dieses Dokument gelernt werden.

## Browserabdeckung
Alias-Registry und alternative Popup-ID, direkter Registryzugriff, Monitor-Bindung, widersprüchliche/stale Instanzen, laufende AJAX-Abfrage, manuelle Auswahl ohne Registry, lokale/Portal-Listen, ein- und mehrzeilige sowie versteckte zusätzliche Treffer, exakter Name/ID-Abgleich, fehlender geprüfter ID-Hinweis, ausbleibender Profilcommit, zu früh betätigtes Weiter, spätere zweite Zeile, ungültiger Ticketwechsel, verlorene gelernte Bindung, Lade-/Footer-Zeilen, zeitverzögerte Auswahl, Ende/Entfernen des Helfers, bestandsschonender Lookup und explizites Einsetzen ohne Versand/Speichern.

Der frühere ARIA-/Mailpfad wurde zusätzlich ausgeführt: echtes Dateiauswahlfeld für die fiktive MSG, alte V1-Mappings, Namensvorschläge, manueller Mehrfachtreffer, Identity-Gates, Datentamper, bestehende Beschreibung, Rücksetzung, Diagnose-ZIP und inert behandelter Mailtext.

## Testumgebung und wichtige Grenzen
Node v22.16.0; Python/Playwright mit dem bereitgestellten Linux-Chromium. Es wurde **nicht** die Windows-Version des Anwenders oder dessen Node v24.19.0 ausgeführt.

Loopback-HTTP-Navigation wird von der Browserrichtlinie dieser Testumgebung blockiert (`ERR_BLOCKED_BY_ADMINISTRATOR`). Diese Richtlinie wurde nicht geändert oder umgangen. Die Browserprüfungen verwenden deshalb synthetische `about:blank`-Seiten. Nur in der Testseite delegiert ein SHA256-only-Testadapter die Berechnung an Python hashlib. Kein solcher Adapter ist im ausgelieferten Browsercode enthalten; dort bleibt die native `crypto.subtle`-Anforderung erhalten.

Die ICEfaces-/DOM-Listen sind eigenständig erstellte Interface-/DOM-Testdoubles, keine vollständig gestartete ICEfaces- oder COMARCH-Installation. Ein synthetischer JavaScript-Klick garantiert keine Annahme durch jede echte Oberfläche. Es wurde keine echte Original-Mail, kein echter Bestand und kein Kunden-Ticket getestet, versendet oder gespeichert.

**Live-Status: noch nicht bestätigt.** Eine unbekannte Liste ohne sichere Bindung bleibt manuell. Das Update ist kein freigegebener Queue-Runner. Lernen gilt nur im Speicher und nur solange die konkret gebundene Seite/Struktur weiter passt.

## Änderungen an Testdateien
- Die alte Widget-Unit-Fixture enthält jetzt auch die tatsächliche Popup-ID, damit die verstärkte DOM-Identitätsprüfung getestet werden kann. Die bisherigen Busy-/Mehrfach-/Index-/Bindungsprüfungen wurden nicht entfernt.
- Der bestehende Mail-Browsertest liest die aktuelle Paketversion statt einer fest eingebauten 0.3.2-Zeichenkette. Seine fachlichen Assertions bleiben bestehen. Neue Ergebnisdateinamen verhindern das Überschreiben historischer Berichte.
- Neue JavaScript-Syntaxprüfung für beide kompletten Konsolenbundles und neue Discovery-/Sicherheitsprüfungen.

## Artefakte
- `DISCOVERY_NODE_RESULT.tap`
- `DISCOVERY_RELOCATION_NODE.tap` und `DISCOVERY_RELOCATION.json`
- `DISCOVERY_BROWSER_RESULT.json`
- `DISCOVERY_ARIA_REGRESSION.json`
- `DISCOVERY_UNCHANGED_DATA.json`
- `DISCOVERY_READY_PREVIEW.png`, `DISCOVERY_WAIT_PREVIEW.png` und `DISCOVERY_ARIA_PREVIEW.png` (nur fiktive Daten)
- `DISCOVERY_CHANGESET.json`, `DISCOVERY_SECRET_SCAN.json`

CRC, sichere Archivpfade, manifestgebundene Dateilängen/Hashes und SHA256SUMS werden beim Verpacken zusätzlich geprüft. Ein eigener Integritätstest ist mit `SELBSTTEST.cmd` möglich. Historische Berichte anderer Versionen sind keine neuen Live-Nachweise.
