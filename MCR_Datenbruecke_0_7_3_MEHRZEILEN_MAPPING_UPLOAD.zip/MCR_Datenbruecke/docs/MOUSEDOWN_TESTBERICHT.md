# MCR 0.3.4 — Prüfbericht

## Ergebnis

- 333/333 Node-Tests bestanden; 0 Fehler/Skips. Darunter die bestehenden
  317 Prüfungen und 16 zusätzliche Prüfungen der neuen Module/Schutzbedingungen.
- 333/333 Node-Tests erneut nach Kopie in einen neuen Pfad mit Leerzeichen bestanden.
- 43/43 Browser-Funktionsprüfungen in sieben separat ausgeführten Gruppen bestanden.
  Diese Zahl enthält zwei erfolgreich reproduzierte Altfehler sowie positive und
  negative Fälle; sie ist keine Anzahl real bearbeiteter COMARCH-Tickets.
- Keine echten Kundendaten, MSGs, Mappings oder Produktivendpoints verwendet.
- Aktuelle Nachweise: MOUSEDOWN_NODE.tap, MOUSEDOWN_RELOCATED_NODE.tap,
  MOUSEDOWN_BROWSER_1.json bis _7.json, MOUSEDOWN_QUALIFICATION.json.

## Nachgebildete Altfehler

Die archivierte 0.3.3-Referenz liest bei einer verschachtelten Tabellenzelle die
sichtbare MercerID nicht und bleibt nach manueller Auswahl ohne Lookup. Die
Fixture repräsentiert einen möglichen fehlerauslösenden Aufbau, nicht das
unbekannte Original-DOM. Separat aktiviert .click() den reinen mousedown-Handler
nicht. Der bereitgestellte Nutzer-Callstack belegt diesen Ereignistyp im echten
COMARCH; der private Originalcode wurde nicht gelesen.

## Geprüfte Korrekturen und Gegenfälle

Ein passender Custom-Einzeltreffer löst genau ein mousedown und danach die
unabhängige Profilprüfung aus. Kein zusätzliches click oder direkter Submit.
Fiktiver Normalfall bis zur ausdrücklich angeforderten Beschreibung funktioniert.

Mehrere/unsichtbare weitere Treffer, falsche ID, falscher Name, fehlende Freigabe,
unpassende Stammdaten, Ticketwechsel, spätere zweite Vorschlagszeile und bloßer
Suchfeldtext ohne Profileintrag aktivieren keinen unzulässigen Lookup.

Manuell bereits übernommene Personen erreichen Schritt 4 ohne erneutes Suchen.
Formularersetzung bei stabiler Fallbindung, sieben Profil-Layouts, sechs
absichtlich unpassende Ausgaben, widersprüchliche Profile und nachträglich
geänderte Stammdaten wurden geprüft. Explizite ALT-Bindung von Ausgabe bzw.
Vorschlagsliste funktioniert; der Markierungsklick führt keine Personenauswahl
aus. Die normale Auswahl kann danach, unter ihren eigenen Gates, erfolgen.

Diagnose-ZIP-CRC und SHA256SUMS stimmen. Testkennungen, Namen, DOM-IDs,
Mail-/Mappingwerte und Adressen erscheinen nicht in diesen Diagnosedaten.
In allen geprüften Abläufen blieben die Send-/Save-Testzähler null.

## Umgebungsgrenzen

Node 22.16.0, Linux; Chromium 144.0.7559.96. Browser-Fixtures auf about:blank
mit einer ausschließlich im Test eingerichteten SHA256-Brücke, weil dort
crypto.subtle nicht wie im HTTPS-Produktivkontext verfügbar ist. Der ausgelieferte
Helfer hat diese Brücke nicht und verlangt weiterhin WebCrypto.

Windows-CMD, echte Unternehmensrichtlinien und die reale COMARCH-Version sind
hier NICHT getestet. Die Custom-Liste wurde passend zum Callstack modelliert,
nicht gegen die echte suggestions.js qualifiziert. Die echte automatische
Auswahl bleibt lokal nachzuweisen. Die manuelle Elementbindung ist die bewusst
mitgelieferte Alternative für nicht erkannte Markup-Varianten.

Es gab während der Entwicklung abgebrochene lange Sammelläufe. Die oben gezählten
Nachweise stammen aus abgeschlossenen Einzelgruppen. Die Tests verwenden frische
Browserseiten pro Fixture, um fremde Testzustände nicht zu übernehmen.

## Unveränderte Grenzen

Excel-/JSON-Regeln, MSG-Parser und Personennamenregeln sind bytegleich zur
0.3.3-Basis (MOUSEDOWN_DATA_UNCHANGED.json). Kein neuer Mappingexport nötig.
Kein automatisches Senden, Ticket speichern, Kategorisieren oder Queue-Lauf.
Die bloße Existenz des erzeugten Mappings beweist nicht die Freigabe jeder ID.

## Paketprüfung

Manifest bindet alle ausgelieferten Payload-Dateien; SHA256SUMS bindet zusätzlich
das Manifest. ZIP wird nach Erzeugung auf CRC, sichere/eindeutige Pfade, Symlinks,
Payload-Längen und sämtliche Hashes geprüft. Eingeschränkter Credential-Musterscan
in MOUSEDOWN_SECRET_SCAN.json; kein Anspruch auf erschöpfende Secret-Erkennung.
