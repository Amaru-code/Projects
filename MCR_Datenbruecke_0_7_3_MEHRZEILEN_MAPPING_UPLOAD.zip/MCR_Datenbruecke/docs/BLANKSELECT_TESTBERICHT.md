# MCR 0.3.2 — Prüfbericht

## Ergebnis und Umgebung

**297 Node-Tests bestanden, 0 Fehler, 0 Skips.** Node.js 22.16.0 unter Linux. Enthalten sind die bisherigen 220 Prüfungen und 77 zusätzliche Tests zu Leerwertregeln, Quellbindung, Formelcache, Null-Provenienz und Widget-Verknüpfung.

**65 Browser-Prüfungen bestanden:** 23 neue Auswahl-/Leerwertprüfungen, 26 bisherige Mail-Assistenten-Prüfungen und 16 Member-/Bestandsfehler-Regressionsprüfungen. Chromium 144.0.7559.96 unter Linux. Die vier neuen Gruppen wurden in separaten Browserprozessen ausgeführt. Zwei monolithische Vorläufe wurden durch die Ausführungszeitgrenze abgebrochen; sie werden nicht als vollständiger Testnachweis gezählt. Maßgeblich sind die abgeschlossenen Einzelgruppen.

**2 interaktive Node-CLI-Prüfabläufe bestanden:** gültiger Bestand und älteres gesperrtes Mapping, inklusive Diagnose-ZIP-CRC, SHA256 und datensparsamer Ausgabe. Der aktualisierte Export-Dialog samt Regelbestätigung und Pfad mit Leerzeichen ist zusätzlich Bestandteil der 297 Node-Tests.

Die Browserseiten wurden als synthetischer DOM in `about:blank` geladen. Eine ausschließlich im Test verwendete SHA256-Brücke zu Python `hashlib` wurde benötigt. Im ausgelieferten Skript bleibt die Prüfung mit nativer SubtleCrypto unverändert. Browser-/Unternehmensrichtlinien wurden nicht umgangen.

**Nicht durchgeführt:** reales Windows/CMD, persönliche XLSX-/MSG-Datei, produktive COMARCH-Seite, deren echte ICEfaces-Version, echter Serverauswahl-/Speichervorgang. Der ICEfaces-Test verwendet ein kleines DOM-/Schnittstellen-Testdouble nach dem recherchierten Quellvertrag, nicht eine komplette ausgeführte Framework-Distribution. Der Adapter ist deshalb technisch implementiert, aber vor Ort noch zu bestätigen.

## Geprüfte Fehlerbehebung

- Eine leere C-Zelle wird unter der **explizit bestätigten neuen Exportregel** als `null` mit `blankColumns:["C"]` abgelegt. Bei fiktiven D=1, E=0 und L=10 entsteht genau **USC 10/ PP+**, kein DC.
- Alle 27 Kombinationen aus leer/0/1 in C/D/E wurden geprüft. Ohne irgendeine 1 bleibt `NO_PLAN` bestehen. Nichtbinäre Werte, fehlender USC, doppelte Kennung und relevante Excel-Fehler bleiben gesperrt.
- Fehlender bzw. leerer numerischer Formelcache wird nicht zu einem erlaubten Leerwert. Ein explizit gespeicherter leerer Formel-String bleibt als Formel markiert und benötigt die separate Ergebnisprüfung.
- Ältere STRICT-Snapshots bleiben gesperrt und unverändert. Eine Umdeutung oder Rekonstruktion ohne Originalquelle findet nicht statt. Regelwechsel, falsche Null-Provenienz und abweichender Quellenhash werden geprüft.
- Mitgliederauswahl hat keinen Bestands-Lookup mehr als Vorbedingung. Ein korrekter Member kann auch bei gesperrtem Bestand übernommen werden; danach erscheint der konkrete Sperrgrund, keine Beschreibung aus ungeprüften Werten.
- ICEfaces-Test: genaue Input-/Registry-/DIV-Verknüpfung, ganzzahlige gelieferte Zeilenanzahl und Zeilenindex. Einzeltreffer benötigt bestätigte Personennummer, exakten Namen, stabile Liste und lesbare MercerID-Stammdatenanzeige.
- Bei mehr als einem gelieferten Treffer wird nie automatisch gewählt, auch wenn die erwartete ID einen davon treffen würde. Versteckte zweite Zeilen, unbekannte Registry, falsche Elementbindung, laufende Aktualisierung, falscher Name/ID und spätere Listenänderung verhindern den automatischen Klick.
- Es wird ein tatsächlicher Ergebnis-DIV angeklickt, kein versteckter Index oder fertig formatierter Personenwert gesetzt. Nach dem Klick wird auf passende MercerID-Stammdaten gewartet. Ein Test mit ausbleibender Übernahme darf keinen Lookup auslösen; ein danebenstehender anderer Name/ID-Text darf nicht als Profilübernahme gelten. Dieser Test deckte eine zu weite benachbarte DOM-Abfrage auf; sie wurde vor den finalen Prüfläufen eingegrenzt.
- Ein echter manueller Testklick bei mehreren Ergebnissen setzt den Lookup fort. Bei unbekannter Oberfläche bleibt die ausdrückliche Auswahlbestätigung. Vorschlagtext allein ist kein Übernahmenachweis.
- Mail und Mapping werden in der Oberfläche mit `textContent` dargestellt; bestehende Beschreibungen bleiben gegen Überschreiben geschützt. In allen geprüften Zweigen blieben Senden/Speichern-Testzähler 0. Nach Wechsel von Member/Ticket wird ein altes Ergebnis ungültig.
- Das Diagnose-ZIP enthält nur definierte Codes, boolesche Werte und Zählwerte. Geprüfte fiktive Namen, IDs, Quellzeilen, Beschreibungen und Datumswerte waren nicht enthalten; CRC und SHA256 stimmten.

## Nachweisdateien

`BLANKSELECT_QUALIFICATION.json` enthält Versionen, Testzahlen und Hashes des geprüften Ausführungscodes. Einzelberichte: `BLANKSELECT_BROWSER_GROUP_1.json` bis `_4.json`, `BLANKSELECT_BASE_BROWSER_TEST_RESULT.json`, `BLANKSELECT_MEMBER_REGRESSION.json`, `BLANKSELECT_CLI_TEST_RESULT.json` und `BLANKSELECT_NODE_TEST_RESULT.tap`. `BLANKSELECT_RESULT_PREVIEW.png` zeigt ausschließlich einen fiktiven Testfall.

`BLANKSELECT_RELOCATION.json` dokumentiert die erneute Node-Qualifikation nach Verlagerung. `BLANKSELECT_SECRET_SCAN.json` beschreibt den begrenzten textbasierten Scan, nicht eine Garantie der Anonymität beliebiger Anwenderdaten. Ältere `MEMBERFIX_*`, `MAIL_*` und `SHEETFIX_*`-Berichte betreffen frühere Versionen.

## Reproduzieren (Entwicklungsumgebung)

Anwender unter Windows: `SELBSTTEST.cmd` (vorhandene Node-Runtime wird genutzt, keine Python-/Playwright-Installation nötig).

Entwicklung: `node --test tests/*.test.mjs`. Browser: `python tests/blankselect_browser_qualification.py 1`, entsprechend Gruppen 2–4, plus `tests/mail_browser_qualification.py` und `tests/memberfix_browser_qualification.py`. Diese Prüfungen benötigen die dokumentierte Python-/Playwright-/Chromium-Testumgebung. Der Aufruf ohne Gruppennummer startet die vier Gruppen in getrennten Prozessen. `python tests/memberfix_cli_qualification.py` führt die zwei interaktiven CLI-Prüfungen aus.

## Nächster echter Nachweis

Neues Mapping exportieren und im aktualisierten 0.3.2-Panel laden. Ein freigegebener einzelner Fall mit überprüftem Name/MercerID ist ausreichend für den nächsten Test. Wenn die Auswahl nicht übernommen wird: tatsächliche Liste offen lassen, **Auswahlliste prüfen**, anschließend **Diagnose-ZIP**. Keine echten Mappings, Mails oder vollständige DOM-Dumps hochladen. Kein automatischer Versand oder Ticketabschluss.
