# 0.3.2 — technische Quellen und Aussagegrenzen

Die Aussage über leere C/D/E stützt sich auf den vom Anwender gelieferten lokalen Prüfbericht und die ursprüngliche Regel „bei 1 das jeweilige Kürzel ergänzen“. Es wurden keine echten Personen-/Bestandsdateien für diese Änderung verarbeitet.

Für den alten ICEfaces-Adapter wurde der von ICEsoft stammende Quellcode in einem öffentlichen SVN-Mirror gelesen. Das ist ein **Implementierungsvertrag einer historischen Fassung**, keine Feststellung der tatsächlich auf dem Kundensystem ausgelieferten Version:

- SelectInputTextRenderer.java: `<clientId>_div` und `<clientId>_idx`, `Ice.Autocompleter`, die gerenderte DIV-Liste und mögliche Begrenzung über `rows`.
  https://github.com/svn2github/icefaces/blob/247d68fc688e598fc4ceebcd35f904b8cdadba41/compat/components/src/main/java/com/icesoft/faces/component/selectinputtext/SelectInputTextRenderer.java
- extras.js: `Autocompleter.Finder`, `.element`, `.update`, `.entryCount`, `.getEntry()`, `entry.autocompleteIndex`, `inTransit`, `changed`, `active`, `hasFocus`.
  Klickpfad: tatsächlicher Ergebnis-DIV → `onClick` → `selectEntry` → vorhandenes `getUpdatedChoices(true,event,idx)` → normale COMARCH/ICEfaces-Übernahme.
  https://github.com/svn2github/icefaces/blob/247d68fc688e598fc4ceebcd35f904b8cdadba41/compat/core/src/main/javascript/extras/extras.js
  Vom Connector gelieferter Git-Blob-SHA: `f28b6dd2d761138aa8e3842a557e67c79dc6bad3`.

Der neue Adapter ist eine eigenständige Implementierung. Es wurde kein kompletter Framework-Quelltext in das Paket kopiert. Er inspiziert vorhandene Verknüpfungen, klickt höchstens einmal pro bestätigter Suche und schreibt weder den versteckten Index noch direkt den endgültigen Personenwert. Framework-Handler und Serverantwort müssen die Auswahl tatsächlich übernehmen.

Eine mit JavaScript ausgelöste `.click()`-Aktion ist kein physischer vertrauenswürdiger Benutzerklick. Systeme können sie ignorieren. Die Version meldet deshalb erst nach verifizierter MercerID-Stammdatenübernahme einen durchlaufenen Auswahl-/Lookup-Schritt, nicht bereits nach dem Klick:
https://developer.mozilla.org/en-US/docs/Web/API/Event/isTrusted

Weder DOM-Foto noch diese Quellen beweisen die konkrete Browserkonfiguration der produktiven Instanz. Für unbekannte Komponenten bleibt die manuelle Auswahl und der datensparsame Diagnoseexport vorgesehen.
