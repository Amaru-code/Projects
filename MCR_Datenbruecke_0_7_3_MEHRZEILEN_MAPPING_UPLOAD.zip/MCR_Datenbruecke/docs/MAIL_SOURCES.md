# Primärquellen des neuen Readers

Aufgerufen am 29.09.2026. Keine Daten von diesen Seiten werden zur Laufzeit geladen.

- Microsoft, [MS-OXMSG], Outlook Item (.msg) File Format:
  https://learn.microsoft.com/en-us/openspecs/exchange_server_protocols/ms-oxmsg/b046868c-9fbf-41ae-9ffb-8de2bd4eec82
- Microsoft, [MS-CFB], Compound File Binary File Format:
  https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-cfb/53989ce4-7b05-4f8d-829b-d08d6148375b
- Microsoft, PidTagBody (0x1000; Unicode / String8):
  https://learn.microsoft.com/en-us/office/client-developer/outlook/mapi/pidtagbody-canonical-property
- Microsoft, PidTagSenderName (0x0C1A; Anzeigename des Absenders):
  https://learn.microsoft.com/en-us/office/client-developer/outlook/mapi/pidtagsendername-canonical-property
- MDN, File API / vom Benutzer ausgewählte Dateien:
  https://developer.mozilla.org/en-US/docs/Web/API/File_API/Using_files_from_web_applications
- MDN, input event: bloßes Setzen von value erzeugt nicht automatisch ein input-Event:
  https://developer.mozilla.org/en-US/docs/Web/API/Element/input_event

Kein Anspruch auf Implementierung der kompletten Microsoft-Spezifikationen.
Die tatsächliche Unterstützung ist in README und Testbericht begrenzt.
