# MCR 0.3.1 — MEMBERFIX / Prüfbericht

## Befund aus 0.3.0

`ID_BLOCKED` wird durch `Core.lookup(map, s.clientId)` ausgelöst, wenn die aus dem Member-Feld gelesene Personenkennung in `payload.blocked` steht. Das Ticketfeld wird nicht als JSON-Lookup-Key benutzt. Die vom Nutzer gelieferte datensparsame Diagnose bewies keinen bestimmten Untercode; dieser wurde in 0.3.0 schlicht nicht exportiert. Deshalb wird weder ein fehlender USC noch eine leere Merkmalszelle oder eine doppelte Kennung als konkrete reale Ursache behauptet.

Daneben war die Oberfläche missverständlich: eine editierbare Ticket-ID stand im Mittelpunkt der Personensuche. Vorschlagsliste und abgeschlossene Personenzuordnung waren nicht hinreichend voneinander unterscheidbar. Die automatische Auswahl in 0.3.0 setzte ARIA-Verknüpfung, abgeschlossene Liste und deklarierte Gesamtzahl 1 voraus; ein normal angezeigter Vorschlag einer unbekannten COMARCH-Alt-Oberfläche erfüllte diese Bedingungen nicht.

## Änderungen

- Nicht editierbare Vorgangsnummer in separatem Technikbereich; keine manuelle Ticketnummer mehr erforderlich. Eindeutig bestätigte Personennummer und tatsächlicher ausgewählter Member werden getrennt geprüft.
- Ein optionales MercerID-/ClientEEID-Feld nimmt nur einen überprüften Personenhinweis auf. Lookup-Key bleibt ausschließlich der ausgewählte Member.
- Betreff wird in die Textanalyse aufgenommen. Nummern neben einem erkannten Namen werden gesondert als kontextuelle, bestätigungspflichtige Hinweise angezeigt. Keine beliebigen Ziffernfolgen als Personenkennung, keine Geschlechtsableitung.
- Leere auslesbare MercerID-Stammdaten blockieren eine vermeintlich fertige Auswahl. Ein echter Auswahlklick kann bei gebundenem Vorgang und stabilen Werten den Abgleich fortsetzen. Unbekannte/mehrdeutige Listen bleiben manuell.
- Bei ID_BLOCKED zeigt Schritt 4 Gründe und Quellzeilen. Diagnose enthält ausschließlich fest definierte Untercodes, Spaltenzustände und Anzahlen, keine Personenkennung oder Zeilennummer.
- `MAPPING_PRUEFEN.cmd`: ein Bestandskey wird lokal geprüft; optional Original-XLSX nur bei identischem Quellenhash. Genau ein Diagnose-ZIP, keine Reparatur und kein Upload durch das Programm.
- Neue Exporte ergänzen `blocked.issues`; alte V1-JSONs bleiben lesbar. Zulässigkeit von Datensätzen und B/C/D/E/L-Regeln bleiben unverändert.

## Ausgeführte Tests

**220 Node-Tests: PASS**, keine Skips. Grundlage: `docs/MEMBERFIX_NODE_TEST_RESULT.tap`, einschließlich 38 neuer gezielter Tests. 182 bisherige Tests bleiben enthalten.

**62 synthetische Browserprüfungen: PASS:**

- 26 Mail-Assistent-Regressionsprüfungen: `MEMBERFIX_BASE_BROWSER_TEST_RESULT.json`.
- 16 gezielte MEMBERFIX-Prüfungen: `MEMBERFIX_FOCUSED_BROWSER_TEST_RESULT.json`.
- 20 Kompatibilitätsprüfungen des weiterhin enthaltenen alten Datenbrücken-Panels: `MEMBERFIX_LEGACY_BROWSER_TEST_RESULT.json`.

**2 interaktive CLI-Abläufe: PASS**, gültiger und gesperrter fiktiver Mappingeintrag. ZIP-CRC, Payload-Hashes und Verzicht auf Personenwerte geprüft: `MEMBERFIX_CLI_TEST_RESULT.json`.

Unter anderem geprüft: Ticket-ID ≠ MercerID; read-only Ticketfeld; Name-nahe Betreffkennung nur Hinweis; keine ID in der Mail bei bestätigtem Member; widersprüchliche Personenkennung blockiert; leere MercerID-Stammdaten gelten nicht als Auswahl; getrennte Sperrdiagnose; alte Mappingdatei ohne Spaltendetails; Fehlercodes mit Fremdtext werden für die Diagnose normalisiert; leere Flags bleiben gesperrt; Formelergebnisfreigabe; Mehrfachtreffer nicht automatisch gewählt; unbekannte Liste manuell; tatsächlicher Nutzerklick setzt Abgleich fort; bestehende Beschreibung wird nicht überschrieben; kein Senden/Speichern.

Darüber hinaus werden Node-Tests nach zufälliger Verlagerung mit Leerzeichen im Verzeichnis erneut ausgeführt; das Ergebnis steht in `MEMBERFIX_RELOCATION_RESULT.json`. Die Paketprüfsummen werden für das endgültige ZIP separat neu aufgebaut und verifiziert.

## Umgebung und Grenzen

Node **22.16.0**, Linux. Browser: installiertes Chromium, Playwright Python. Die Container-Browserrichtlinie verhindert Navigation (`ERR_BLOCKED_BY_ADMINISTRATOR`); sie wurde **nicht** verändert. Browserprüfungen laufen deshalb mit eingesetztem synthetischem `about:blank`-DOM. SHA256 ist ausschließlich im Testharness an Python hashlib angebunden, da dieser Kontext nicht den produktiven HTTPS-Kontext bereitstellt. Der ausgelieferte Helfer verlangt weiterhin normales natives SubtleCrypto. Kein solcher Testshim wird in den produktiven JavaScript-Bundle eingebaut.

**Nicht ausgeführt:** echter Windows-CMD-Start, natives Edge-Datei-/HTTPS-Verhalten, tatsächliches COMARCH, die konkrete Vorschlagslistenstruktur, die originale MSG des Nutzers und dessen echtes Bestandsmapping. Die Dokumentlink-Fallbindung ist eine zusätzliche technische Absicherung, keine eigenständig in COMARCH nachgewiesene Authority. Keine Live-/Produktions-/Versandfreigabe aus diesen Tests ableiten.

Das Update hebt keine reale Datensperre auf. Der tatsächliche Untercode und gegebenenfalls die zuständige Spalte werden erst mit dem lokalen Prüfprogramm beziehungsweise dem neuen Panel ermittelt. Eine mögliche semantische Änderung (z. B. leeres C/D/E bedeutet fachlich „nein“) muss ausdrücklich geklärt werden, bevor sie implementiert wird.

Quellen und Basispaket: `MEMBERFIX_SOURCES.md`, `MEMBERFIX_CHANGESET.json`. Die Vorschau-PNGs zeigen ausschließlich fiktive Prüfdaten.
