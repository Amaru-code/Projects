# MCR Local Runner 0.5.5 – Testbericht

## Anlass
Der isolierte reale MSG-Downloadtest auf COMARCH ergab unmittelbar:

`[PAGE_FETCH] Mail 1: PASS - gültige MSG`

Die Datei wurde zusätzlich durch den internen MSG-Parser validiert. Der Haupt-Runner 0.5.5 übernimmt deshalb **exakt diesen nachgewiesenen Weg** und verändert den funktionierenden 0.5.3-Arbeitsablauf ansonsten nicht.

## Integrierter Ablauf
- reale `GetFile?docId=...`-Links aus den sichtbaren Nachrichtenzeilen lesen;
- Reihenfolge: neueste/unterste Mail zuerst;
- Fetch im angemeldeten COMARCH-Seitenkontext mit `credentials: 'include'`;
- `cache: 'no-store'`, `redirect: 'follow'`;
- Accept: Outlook MSG / Binärdaten;
- Antwort nur akzeptieren, wenn Größe, CFB-Magic und interner `Msg.parseMsg` erfolgreich sind;
- gültige Bytes unter `.runtime/downloads` speichern;
- erst nach Fehlschlag aller PAGE_FETCH-Kandidaten auf den bisherigen Maus-/manuellen Download zurückfallen.

## Regression
`node --test tests/*.test.mjs`: **380/380 PASS**.

Headless Demo: **PASS bis BEREIT VOR VERSAND**.

## Grenzen
Der reale PAGE_FETCH selbst ist durch den separaten Operator-Probelauf bestätigt. Die neu integrierte 0.5.5-Version muss noch einmal auf dem realen COMARCH-Ticket ausgeführt werden.

0.5.5 sendet keine E-Mail und klickt nicht auf `Ticket speichern`.
