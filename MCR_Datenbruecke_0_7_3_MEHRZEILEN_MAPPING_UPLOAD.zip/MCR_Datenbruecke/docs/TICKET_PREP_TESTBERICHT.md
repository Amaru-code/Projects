# MCR Ticket-Vorbereiter 0.4.0 — Testbericht

## Scope

0.4.0 ergänzt den bestätigten 0.3.5-Datenpfad um ein separates Modul zur
Vorbereitung des Tickets **nach** erfolgreicher Beschreibungseinfügung.
`COMARCH_MAIL_ASSISTENT.js` aus 0.3.5 wurde bytegenau unverändert übernommen.

Neu geprüft:

- exakt gebundene Zuständigkeit `Second Level`,
- Kategorie `Allgemeine Schriftwechsel`,
- Unterkategorie `Personenschriftwechsel`,
- Signatur `INTL01 - Intel Deutschland GmbH`,
- manuelle Anrede (Herr/Frau), keine Geschlechtsableitung,
- feste Antwortvorlage mit geprüftem Nachnamen,
- Einsetzen und lokales Rücklesen in einem `contenteditable`-Editor,
- harte Vor-Versand-Gates für feste Felder, zusätzliche Beschreibung und Empfänger,
- keine Aktion für Senden oder Ticket-Speichern,
- datensparsame Diagnose ohne Personenwerte oder Antworttext.

## Node-Regressionslauf

`node --test` über die vollständige Windows-Selbsttest-Suite einschließlich
`tests/ticket-prep.test.mjs`: **365/365 PASS**.

Der neue reine Regeltest prüft unter anderem exakte feste Werte, beide Anreden,
ungültige/fehlende Anrede, Antwortvorlage, Textvergleich, Bundle-Parsability und
das Fehlen der bekannten produktiven Senden-/Speichern-Selektoren im neuen UI.

## Native Browser-Qualifikation

`tests/ticket_prep_browser.py` wurde unter Linux/Chromium auf einer synthetischen
Formularseite ausgeführt: **12 Prüfpunkte PASS**.

Dabei wurden echte DOM- und Eventmechanismen von Chromium verwendet. Die
nachgebildeten Vorschlagszeilen besitzen `mousedown`-Handler. Geprüft wurden:

- Setzen der Select-Option Second Level,
- je genau ein mousedown-Commit für Kategorie, Unterkategorie und Signatur,
- keine Betätigung der synthetischen Senden-/Speichern-Schaltflächen,
- manuell gewählte Anrede und geprüfter Nachname,
- Antworttext im `contenteditable`-Iframe,
- finale `readyBeforeSend=true` erst nach den menschlichen Kontroll-Gates,
- Diagnose ohne Namen, Kennungen, Beschreibung, Antworttext oder URL.

Nachweis: `docs/TICKET_PREP_BROWSER.json` und `docs/TICKET_PREP_READY.png`.

## Wichtige Grenze

Die tatsächliche Mercer/COMARCH-Instanz wurde in dieser Umgebung nicht ausgeführt.
Insbesondere die Kategorie-/Signatur-Vorschlagslisten müssen im realen System
lokal bestätigt werden. Erkennt 0.4.0 keinen eindeutigen exakten Vorschlag, bleibt
der manuelle Auswahlweg vorgesehen; das finale Gate verlangt ohnehin die visuelle
Prüfung der vier Felder.

Das lokale Rücklesen des Antworteditors ist **kein** Nachweis einer Serverspeicherung.
Versand, Versanddialoge und Ticket-Speichern bleiben in 0.4.0 absichtlich außerhalb
des Automatisierungsumfangs.
