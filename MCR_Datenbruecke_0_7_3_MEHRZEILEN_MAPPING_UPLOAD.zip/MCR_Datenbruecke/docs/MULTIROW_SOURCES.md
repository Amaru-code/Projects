# Technische Referenzen 0.7.3

- Node.js Dateioperationen: https://nodejs.org/api/fs.html
  `openSync(..., 'wx')`, `fsyncSync`, `renameSync` werden für neue Dateien und die
  Aktivierung verwendet. Es wird kein globales Dateisystem-/Rechte-Setup verändert.
- Node.js SHA256: https://nodejs.org/api/crypto.html
- Textarea-Werte und Zeilenumbrüche: https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/textarea
- Feldlängengrenze: https://developer.mozilla.org/en-US/docs/Web/API/HTMLTextAreaElement/maxLength

Die fachlichen B/C/D/E/F/L/O-Regeln, die Mehrzeilenentscheidung und das im früheren
COMARCH-HTML sichtbare 450-Zeichen-Limit stammen aus den Nutzerangaben in diesem
Dialog. Es wurden keine privaten COMARCH-Daten online gesucht.
