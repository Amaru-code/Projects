# 0.3.4 · Quellen und Ableitungsgrenzen

## Nutzerbelege in diesem Chat

- Callstack nennt `initWithShowAllOption`, `suggestionsInvokeFromEvent` und
  `suggestionDiv.onmousedown` in `suggestions.js`; beim Zeilen-Mousedown folgt
  COMARCHs `iceSubmit`.
- Zweites Bildschirmfoto zeigt Member-Label plus befüllte MercerID-Stammdaten;
  gleichzeitig meldet die Helferdiagnose `profileIdPresent:false`,
  `MEMBER_COMMIT_PENDING` und `lookupAttempted:false`.
- Die konkrete DOM-Verschachtelung und der Originalcode von suggestions.js sind
  NICHT verfügbar. Weder die Privatseite noch SuggestServlet wurden abgerufen.
- Die verschachtelte Tabellen-Testfixture demonstriert eine Lücke des alten
  Prüfers; sie behauptet NICHT, das exakte COMARCH-Markup wiederzugeben.

## Öffentliche API-Dokumentation (abgerufen 2026-09-29)

S1: MDN, HTMLElement.click(): löst das click-Ereignis aus.
https://developer.mozilla.org/en-US/docs/Web/API/HTMLElement/click

S2: MDN, mousedown: Drücken einer Maustaste; eigenes Ereignis im Unterschied
zum späteren vollständigen click.
https://developer.mozilla.org/en-US/docs/Web/API/Element/mousedown_event

S3: MDN, EventTarget.dispatchEvent(): Dispatch und Handlerausführung;
Rückgabewert ist kein Nachweis über eine spätere Serverübernahme.
https://developer.mozilla.org/en-US/docs/Web/API/EventTarget/dispatchEvent

## Umsetzung

Der Adapter sendet an eine geprüfte echte Vorschlagszeile genau ein synthetisches
mousedown, ohne zusätzliches mouseup/click und ohne eigenen iceSubmit-Aufruf.
Er simuliert kein isTrusted und umgeht keine Zugriffskontrolle. Das normale
COMARCH-Seitenprogramm verarbeitet das Ereignis. Erfolg wird anschließend über
die unabhängige, passende MercerID-Ausgabe geprüft. Unklare Fälle bleiben manuell.
