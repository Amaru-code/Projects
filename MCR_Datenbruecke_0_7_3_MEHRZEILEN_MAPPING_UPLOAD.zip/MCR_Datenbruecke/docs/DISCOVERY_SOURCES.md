# 0.3.3 technische Referenzen

## Primäre Arbeitsgrundlage
Der vom Anwender bereitgestellte Diagnosezustand 0.3.2: Registry-Funktion vorhanden, aber keine Instanz unter der angenommenen Feld-ID; geratene `_div`-Liste nicht vorhanden; kein automatischer Klick; keine übernommene MercerID; Lookup nicht aufgerufen. Keine Kundendaten oder Originaldiagnosewerte wurden in das Paket kopiert.

Das vorhandene `lib/member-widget.cjs` und `browser/mail-ui.js` aus dem überprüften 0.3.2-Paket waren die Änderungsbasis. Die neue Suche leitet keine konkrete proprietäre COMARCH-Komponentenfassung aus öffentlichen Bibliotheksquellen ab.

## Web-API-Referenzen (29.09.2026 geprüft)
- HTMLElement.click(): https://developer.mozilla.org/en-US/docs/Web/API/HTMLElement/click
  Ein `.click()` ist ein synthetischer Klick. Er garantiert weder Annahme durch jede Anwendung noch einen Backend-Commit.
- Event.isTrusted: https://developer.mozilla.org/en-US/docs/Web/API/Event/isTrusted
  Beobachtete Benutzerevents werden von selbst ausgelösten Events unterschieden; eine manuelle Bestätigung ist kein Ersatz für tatsächliche Stammdatenübernahme.
- MutationObserver: https://developer.mozilla.org/en-US/docs/Web/API/MutationObserver
  Als Alternative für spätere Ereignisbeobachtung geprüft; diese Version nutzt begrenztes Polling und konkrete Eingabe-/Klickereignisse, keinen globalen Mail-/DOM-Dump.

Die zuvor im Paket dokumentierte ICEfaces-Referenz bleibt historische Grundlage des alten Adapters. Ein öffentlicher Framework-Quelltext beweist nicht, welche Version oder Anpassung im tatsächlichen COMARCH ausgeliefert wird.
