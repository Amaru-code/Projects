# MCR Local Runner 0.5.3 – Testbericht

## Ziel

0.5.3 beseitigt zwei im realen 0.5.2-Lauf beobachtete Reibungspunkte:

1. Für die Personenermittlung wird der sichtbare COMARCH-Nachrichtenverlauf bevorzugt direkt gelesen. Ein `.msg`-Download ist nur noch Fallback.
2. Nach Member-Übernahme und Kategorie-Update wird das echte Member-Feld erneut mit der Browsermaus angeklickt, bevor `Personenschriftwechsel` gesetzt wird.

## Automatisierte Tests

- Node-Test-Suite: 379/379 PASS.
- Headless Chromium Demo-E2E: PASS bis `BEREIT VOR VERSAND`.
- Demo prüft: 2 Nachrichtenzeilen -> direkte DOM-Mailauswertung -> eindeutiger Member -> echter Browser-Mausklick -> MercerID -> Mapping -> Beschreibung -> Second Level -> Kategorie -> erneuter Member-Klick -> Unterkategorie -> Signatur -> Antworttext -> Pre-Send-Gate.

## Grenzen

- Reales COMARCH bleibt die maßgebliche Qualifikation.
- Bei mehreren Member-Treffern bleibt die Personenauswahl ein Human Gate.
- `Senden` und `Ticket speichern` sind weiterhin deaktiviert.
- Wenn sichtbarer Nachrichteninhalt keinen brauchbaren Namenshinweis enthält, bleibt der MSG-Download-Fallback erhalten.
