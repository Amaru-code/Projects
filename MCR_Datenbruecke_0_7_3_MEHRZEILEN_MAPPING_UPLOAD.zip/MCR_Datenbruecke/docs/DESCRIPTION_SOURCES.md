# Technische Referenzen (29.09.2026 geprüft)

- MDN, HTMLTextAreaElement.value: Zugriff auf den tatsächlichen Textarea-Wert.
  https://developer.mozilla.org/en-US/docs/Web/API/HTMLTextAreaElement/value
- MDN, input event: Programmatisches Setzen von value erzeugt nicht von selbst
  ein input-Ereignis. Der Helfer löst input/change nur am bestätigten Textfeld aus.
  https://developer.mozilla.org/en-US/docs/Web/API/Element/input_event
- MDN, EventTarget.dispatchEvent: Handler laufen synchron; eine lokale Rückkehr
  belegt keine spätere Serververarbeitung. Deshalb zusätzlicher begrenzter Readback.
  https://developer.mozilla.org/en-US/docs/Web/API/EventTarget/dispatchEvent
- MDN, label: Explizite for/id- und implizite Label-Verknüpfungen.
  https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/label

Die Referenzen erklären Browser-APIs, nicht die private COMARCH-Maske.
Die tatsächlich gelieferten DOM-Strukturen und deren Änderungshandler sind nicht
vollständig bekannt. Explizite per-Seite-Textfeldbindung ist deshalb enthalten.
