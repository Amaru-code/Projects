# Fachliche und technische Grundlagen — 0.3.1

## Maßgebliche lokale Evidenz

- Vom Nutzer bereitgestellter 0.3.0-Diagnoseauszug: geladenes/bestätigtes Mapping; `lastError=ID_BLOCKED`; keine Personenwerte im Upload.
- Basispaket `MCR_Datenbruecke_0_3_0_MAIL_UPLOAD.zip`: insbesondere `lib/data-core.cjs` (`lookup`), `src/mapping.mjs`, `browser/mail-ui.js` (`acceptMember`, `strictSingle`). Die ursprüngliche `lookup`-Implementierung unterscheidet ID_BLOCKED und ID_NOT_FOUND; die Ticketnummer wurde bereits dort nicht als Bestandskey verwendet.
- Screenshotinterpretation: Vorschlag vorhanden, MercerID-/Namens-Stammdaten zum Zeitpunkt der Aufnahme noch leer. Ein Screenshot beweist nicht, welcher spätere Klick verarbeitet wurde.
- Die echte Sperrursache unterhalb ID_BLOCKED war im Nutzerbericht nicht enthalten; keine Spekulation als bewiesene Ursache übernehmen.

## Primärdokumentation (am 29.09.2026 konsultiert)

- ICEfaces SelectInputText: https://wiki.icefaces.org/en/SelectInputText.html — Vorschlagsliste, serverseitige Suche, begrenzte Ergebniszahl; sichtbarer Einzelvorschlag ist ohne weitere Zusage keine belegte vollständige Population.
- MDN Event.isTrusted: https://developer.mozilla.org/en-US/docs/Web/API/Event/isTrusted — synthetisch ausgelöste Events sind kein Nachweis eines echten Nutzerklicks. `isTrusted` allein ist kein allgemeiner Identitätsnachweis.

Diese Quellen ersetzen keine technische Qualifikation des konkret eingesetzten COMARCH-Widgets.
