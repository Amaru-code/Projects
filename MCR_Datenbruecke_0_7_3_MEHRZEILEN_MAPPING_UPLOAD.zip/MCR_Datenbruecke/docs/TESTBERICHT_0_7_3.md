# Testbericht 0.7.3 — Mehrzeilen-Mapping

## Ausgeführt in dieser Erstellung

Umgebung: Linux, Node.js 22.16.0, installierter Chromium (headless).
Nur fiktive Testdaten. Kein Zugriff auf die private Original-XLSX oder COMARCH.
Die Windows-CMD-Dateien wurden statisch geprüft, nicht unter Windows ausgeführt.

| Prüfung | Ergebnis |
|---|---|
| Node-Tests, insgesamt | 457 bestanden, 0 fehlgeschlagen, 0 übersprungen |
| Davon neue Mehrzeilen-/Aktivierungs-/Integritätstests | 60 bestanden |
| Produktions-Textarea-Schreiben/-Rücklesen in Chromium | 13 Prüfungen bestanden |
| Tatsächliche Export-CLI mit fiktiver XLSX und Promptantworten | 10 Prüfungen bestanden |
| Haupt-Queue-Runner im Chromium-Demomodus | 2 Tickets abgeschlossen |
| Echte Klickzähler der Testseite | 2 Sendeklicks und 2 Speicherklicks |
| Gespeicherte Beschreibungszeilen der Testseite | [2, 2] — zwei pro Ticket |

Der Demomodus verwendet die bestehende synthetische COMARCH-Oberfläche und
vereinfacht unter anderem das Setzen fester Felder. Er ist kein Beleg für die echte
COMARCH-DOM-Struktur, den Live-Mailversand oder eine Wiederanlaufsicherheit über
unabhängige Prozesse. Der Download-/Member-/Dialogpfad des bisherigen Runners wurde
in diesem Patch nicht neu implementiert.

## Regressionsfälle

Mehrfachzeilen mit gleichen sowie unterschiedlichen Beschreibungen, unterschiedliche
USC-/Planwerte ohne Vermischung, E/PensIntel und F/TPP getrennt je Zeile, unveränderte
Einzelzeilenregel, durchgehend M/F, fehlendes und widersprüchliches Gender,
aufsteigende physische Zeilennummern, erhaltene identische Zeilen, führende Nullen,
fehlende/fehlerhafte Werte, keine Teilfreigabe bei einer fehlerhaften Dublette,
fehlende Formel-Caches und vorhandene Formeln in F/O, Feldlängenprüfung,
Manipulation von Hashes und abgeleiteten Feldern, unterdrückte Zeilen und falsche
Kennungszuordnung.

Die Dateitests prüfen: Der aktivierte Snapshot gewinnt gegenüber dem noch in der
Alt-Konfiguration stehenden Gender-Dateipfad. Bei defektem oder fehlendem aktiven
Mapping gibt es keinen stillen Rückfall. UTF-8-BOM in einer Aktivierungsdatei ist
lesbar. Ein injizierter Fehler vor dem Aktivierungs-Rename lässt den vorher aktiven
Snapshot bestehen. Wiederholte Exporte überschreiben die alten JSONs nicht.
Ein Vier-Dateien-Manifest wird von der Vollpaketprüfung abgewiesen.

Der Browsertest verwendet die aus dem aktuellen Vollrunner entnommenenen echten
`writeDescription`-/`verifyDescription`-Funktionen. Er prüft zusätzlich:
Zeilenumbrüche bleiben erhalten, identische Texte werden nicht erneut geschrieben,
abweichend gefüllte Felder bleiben unangetastet, weggefallene Zeilen oder zusammen-
gezogene Zeilenumbrüche werden erkannt, Überlänge wird nicht abgeschnitten,
Kommentar/Senden/Speichern werden durch den isolierten Schreibtest nicht betätigt.

## Belege

- `MULTIROW_NODE_TEST_RESULT.tap`
- `MULTIROW_BROWSER_RESULT.json`
- `MULTIROW_CLI_RESULT.json`
- `MULTIROW_E2E_DIAGNOSTIC.json`
- `MULTIROW_RELOCATION_RESULT.json`
- `MULTIROW_PACKAGE_CHECK.json`

Die Belege anderer Versionen im `docs`-Ordner sind historische Nachweise und werden
nicht als neue 0.7.3-Tests ausgegeben.

## Fachliche Grenzen

Kein erfundener TPP-Ausgabecode. Der frühere Override für nur eine TPP-Zeile wird
nicht weiter angewandt. E/F/O werden aus der gesamten unveränderten Original-XLSX
neu eingelesen, nicht aus einem selektierten Vorgänger-JSON rekonstruiert.
Ungültige Bestandszeilen und Beschreibungen über 450 Zeichen bleiben gesperrt.

Die genaue Zahl freigegebener Dubletten in der tatsächlichen Quelldatei ergibt sich
erst aus dem lokalen Export. Es wird nicht behauptet, dass alle 58 zuvor gesperrten
Kennungen verwendbar sind. Nach dem Patch sollte der erste reale Mehrzeilenticket-
Lauf beobachtet und die Beschreibung im gespeicherten Ticket geprüft werden.
