# MCR Local Runner 0.7.1 – Member-Profil-Erkennung

## Zweck

0.7.1 behebt einen real beobachteten COMARCH-Fall, bei dem der Member erfolgreich ausgewählt wurde, das Eingabefeld danach aber nur den Namen enthält. Die MercerID steht in separaten COMARCH-Profilzeilen (`MercerID:`, `Vorname:`, `Nachname:`). 0.7.0 wertete nur eine `INTL01-...`-Kennung direkt im Member-Eingabefeld als Commit und konnte deshalb fälschlich mit `MEMBER_COMMIT` stoppen.

## Neue Commit-Regel

Ein Member gilt als übernommen, wenn entweder:

1. das Member-Feld selbst genau eine `INTL01-...`-Kennung enthält, **oder**
2. im selben COMARCH-Formular genau eine sichtbare `MercerID:`-Profilzeile sowie genau ein `Vorname:` und `Nachname:` gefunden werden und diese Namen zum aus der aktuellen Mail geprüften Member passen.

Umlaute werden beim reinen Namensvergleich ä/ö/ü/ß ↔ ae/oe/ue/ss tolerant verglichen. Die MercerID bleibt unverändert und ist weiterhin die Authority für den JSON-Lookup.

## Recovery

Wenn ein vorheriger Teil-Lauf den korrekten Member bereits per ICEfaces-Partial-Submit übernommen hat, verwendet 0.7.1 diesen nur dann weiter, wenn MercerID + Vorname + Nachname semantisch zum aktuellen Mail-Kandidaten passen. Ein abweichender bereits gesetzter Member wird nicht stillschweigend übernommen.

## Unverändert

Queue-Reihenfolge, PAGE_FETCH, Gender-Mapping, USC/Plan-Regeln, Beschreibung, Kategorien, Signatur, Antwort, Send-Ack, Ticket speichern, Persistenzprüfung und Queue-Schleife bleiben gegenüber 0.7.0 unverändert.

## Qualifikation

- 394/394 Node-Tests PASS.
- Vollständiger synthetischer Full-Queue-Lauf PASS mit einem COMARCH-Member-Feld, das **nur den Namen** enthält und MercerID/Vorname/Nachname getrennt rendert.
- Kein zweiter Send-Klick bei unklarem Versandstatus.

Der reale COMARCH-Lauf bleibt maßgeblich.
