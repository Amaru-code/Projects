# MCR Datenbrücke 0.7.3

**Neu: Alle Bestandszeilen je ClientEEID → eine mehrzeilige Beschreibung → eine
Antwort pro Ticket.** PensIntel (E), TPP (F), Gender (O) bleiben zeilenweise erhalten.

## Jetzt starten

ZIP vollständig entpacken und mit dem bisherigen `MCR_Datenbruecke`-Ordner
zusammenführen. Gelieferte Paketdateien ersetzen; `private_data` und `.runtime`
NICHT löschen. Der frühere Vier-Dateien-Patchnachweis wird durch den vollständigen
Paketnachweis ersetzt.

**Einmal:** `MAPPING_MEHRZEILIG_AKTUALISIEREN.cmd` → Quelle/Regel prüfen → `JA`.
Es wird ein neuer Snapshot erzeugt und ausdrücklich aktiviert.

**Danach:** `START_FULL_QUEUE_RUN.cmd` → Version 0.7.3 und aktives
`INTL01_mapping_multirow_...json` kontrollieren → `START` für echten Versandlauf.

Kein `npm install`, kein neuer Compiler, kein neuer Excel-Download. Die ursprüngliche
XLSX wird nur gelesen. Alte Snapshotdateien bleiben unverändert.

Vollständige Bedienung und Grenzen: **README_0_7_3.md**.
Tests: **docs/TESTBERICHT_0_7_3.md**.
Ältere READMEs sind historische Dokumentation, nicht die Anleitung für das neue
Mappingformat.
