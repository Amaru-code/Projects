# MCR Local Runner 0.6.3 – Dual Queue Legacy-Kompatibilität

Patch auf 0.6.2.

## Behoben

- `Warteschlange > INTL01` (`mainForm:tasksTableFor_MyQueuesTasksList`) und `Meine Vorgänge > In_Bearbeitung` werden weiterhin unterstützt.
- Die Queue-Auswertung verwendet im COMARCH-Seitenkontext keine `HTMLCollection.entries()`-/Spread-Iteration mehr. Stattdessen werden klassische Indexschleifen verwendet, um Konflikte mit älteren ICEfaces/Prototype-Skripten zu vermeiden.
- `detailTicketId()` ist jetzt explizit implementiert und bindet die geöffnete Detailansicht an genau eine sichtbare numerische Ticket-ID.
- Die strikte Eligibility-Regel bleibt: echte `tbody`-Zeile, Ticket-ID 6–12 Ziffern, Quelle `E-MAIL`, `Zusätzliche Beschreibung` leer.

Der Pilot bearbeitet weiterhin nur ein Ticket. `Ticket speichern` und Queue-Schleife bleiben deaktiviert.
