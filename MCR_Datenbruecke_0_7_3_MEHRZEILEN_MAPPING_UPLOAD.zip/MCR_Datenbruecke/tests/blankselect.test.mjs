import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import Core from '../lib/data-core.cjs';
import {makeMapping,exportMapping} from '../src/mapping.mjs';
import {readWorkbook} from '../lib/xlsx.mjs';
const policy=Core.BLANK_OMIT_FLAGS;
const row=(extra={})=>({row:17,B:'99900001',C:'',D:'1',E:'0',L:'10',errors:{},formulas:[],...extra});
const book=(rows)=>({meta:{sheet:'output',sha256:'a'.repeat(64),headers:{B:'ClientEEID',C:'DC',D:'IPP',E:'PensIntel',L:'USC'},filename:'FIKTIV.xlsx'},allRows:()=>rows});
const map=(rows,more={})=>makeMapping(book(rows),{mode:'DEMO',headerLConfirmed:true,flagPolicy:policy,...more});
const code=c=>e=>e.code===c;

test('0.3.2 old strict snapshot stays blocked; no in-place unlock',()=>{
 const m=map([row()],{flagPolicy:Core.STRICT_FLAGS}),before=JSON.stringify(m);
 assert.throws(()=>Core.lookup(m,'99900001'),code('ID_BLOCKED'));
 assert.equal(m.payload.blocked['99900001'].issues[0].state,'EMPTY');
 assert.equal(JSON.stringify(m),before);
 delete m.payload.flagPolicy;
 Core.validateMap(m);
 assert.throws(()=>Core.lookup(m,'99900001'),code('ID_BLOCKED'));
});
test('0.3.2 diagnosed empty C is preserved as null and only omits DC',()=>{
 const r=row(),before=JSON.stringify(r),m=map([r]),entry=Core.lookup(m,'99900001');
 assert.equal(entry.description,'USC 10/ PP+');assert.equal(entry.dc,null);
 assert.deepEqual(entry.blankColumns,['C']);assert.equal(entry.ppPlus,1);assert.equal(entry.dbPlus,0);
 assert.equal(m.payload.flagPolicy,policy);assert.equal(m.payload.summary.blankOmittedRows,1);
 assert.equal(JSON.stringify(r),before);Core.validateMap(m);
});
for(const C of ['',0,1])for(const D of ['',0,1])for(const E of ['',0,1]){
 test('0.3.2 all 27 blank/binary combinations '+JSON.stringify([C,D,E]),()=>{
  const m=map([row({C,D,E})]),plans=[C===1?'DC':'',D===1?'PP+':'',E===1?'DB+':''].filter(Boolean);
  if(!plans.length){assert.deepEqual(m.payload.blocked['99900001'].codes,['NO_PLAN']);return;}
  const e=Core.lookup(m,'99900001');assert.equal(e.description,'USC 10/ '+plans.join(';'));
  assert.deepEqual(e.blankColumns,[C===''?'C':'',D===''?'D':'',E===''?'E':''].filter(Boolean));
  Core.validateMap(m);
 });
}
for(const C of [' ', '\u00a0',null,undefined])test('0.3.2 blank spellings normalize without false binary claim '+JSON.stringify(C),()=>{
 const e=Core.lookup(map([row({C})]),'99900001');assert.equal(e.dc,null);assert.equal(e.description,'USC 10/ PP+');
});
for(const C of ['2','x','true',true,false,'01','1.0','-',{},NaN])test('0.3.2 non-binary values still blocked '+String(C),()=>{
 const m=map([row({C})]);assert.ok(m.payload.blocked['99900001'].codes.includes('FLAG_INVALID'));
});
for(const L of ['',null,'USC 10','-10','#N/A'])test('0.3.2 invalid USC still blocked '+String(L),()=>{
 const m=map([row({L})]);assert.deepEqual(m.payload.blocked['99900001'].codes,['USC_INVALID']);
});
test('0.3.2 Excel error or missing cache does not become a permitted blank',()=>{
 const m=map([row({errors:{C:'Formel ohne gespeichertes Ergebnis'}})]);
 assert.deepEqual(m.payload.blocked['99900001'].codes,['CELL_ERROR']);
 assert.deepEqual(m.payload.blocked['99900001'].issues,[{code:'CELL_ERROR',column:'C',state:'ERROR_OR_CACHE'}]);
});
test('0.3.2 duplicate person key still blocks all candidate rows',()=>{
 const m=map([row(),row({row:18})]);assert.deepEqual(m.payload.blocked['99900001'].codes,['DUPLICATE_ID']);
 assert.equal(Object.keys(m.payload.entries).length,0);
});
test('0.3.2 formula provenance retained for separate cache review',()=>{
 const e=Core.lookup(map([row({formulas:['C','L']})]),'99900001');assert.deepEqual(e.formulas,['C','L']);
});
test('0.3.2 changed null/column provenance rejected',()=>{
 const m=map([row()]);m.payload.entries['99900001'].blankColumns=[];
 assert.throws(()=>Core.validateMap(m),code('MAP_BLANK_PROVENANCE'));
});
test('0.3.2 changing explicit flag policy alone does not re-admit snapshot',()=>{
 const m=map([row()]);m.payload.flagPolicy=Core.STRICT_FLAGS;
 assert.throws(()=>Core.validateMap(m),code('MAP_FLAG_POLICY'));
 assert.throws(()=>Core.lookup(m,'99900001'),code('MAP_FLAG_POLICY'));
});
test('0.3.2 unknown policies rejected at export and validation',()=>{
 assert.throws(()=>map([row()],{flagPolicy:'UNREVIEWED'}),code('MAP_FLAG_POLICY'));
 const m=map([row()]);m.payload.flagPolicy='UNREVIEWED';assert.throws(()=>Core.validateMap(m),code('MAP_FLAG_POLICY'));
});
test('0.3.2 fresh export preserves original workbook bytes and creates a distinct file',()=>{
 const source=new URL('../examples/DEMO_Datenbestand.xlsx',import.meta.url);const before=fs.readFileSync(source);
 const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'mcr032-export-'));
 try{
  const sourcePath=path.join(tmp,'FIKTIV.xlsx');fs.writeFileSync(sourcePath,before);
  const b=readWorkbook(sourcePath);
  const out=exportMapping(sourcePath,path.join(tmp,'out'),{mode:'DEMO',headerLConfirmed:true,flagPolicy:policy,expectedSha:b.meta.sha256});
  const m=JSON.parse(fs.readFileSync(out.dest));assert.equal(m.payload.flagPolicy,policy);Core.validateMap(m);
  assert.deepEqual(fs.readFileSync(sourcePath),before);assert.ok(fs.existsSync(out.dest+'.sha256'));
  assert.throws(()=>exportMapping(sourcePath,path.join(tmp,'out'),{mode:'DEMO',headerLConfirmed:true,flagPolicy:policy,expectedSha:'b'.repeat(64)}),code('SOURCE_CHANGED'));
 }finally{fs.rmSync(tmp,{recursive:true,force:true});}
});
// Deliberately crafted in-memory OOXML corruption/cache fixtures, not a user workbook edit.
import {readWorkbookBuffer} from '../lib/xlsx.mjs';
import {readZip,writeZip} from '../lib/zip.mjs';
function cacheFixture(cell){
 const z=readZip(fs.readFileSync(new URL('../examples/DEMO_Datenbestand.xlsx',import.meta.url)));
 return writeZip(z.names.map(name=>({name,data:name==='xl/worksheets/sheet1.xml'?z.get(name).toString().replace(/<(?:x:)?c\b([^>]*\br="C3"[^>]*)>[\s\S]*?<\/(?:x:)?c>/,cell):z.get(name)})));
}
for(const cell of ['<c r="C3"><f>IF(1=1,"",0)</f></c>', '<c r="C3"><f>IF(1=1,"",0)</f><v></v></c>'])test('0.3.2 missing numeric formula cache stays blocked '+cell,()=>{
 const b=readWorkbookBuffer(cacheFixture(cell)),m=makeMapping(b,{mode:'DEMO',headerLConfirmed:true,flagPolicy:policy});
 assert.ok(m.payload.blocked['99900001'].codes.includes('CELL_ERROR'));
});
test('0.3.2 explicit cached empty string formula retains formula-review obligation',()=>{
 const b=readWorkbookBuffer(cacheFixture('<c r="C3" t="str"><f>IF(1=1,"",0)</f><v></v></c>'));
 const m=makeMapping(b,{mode:'DEMO',headerLConfirmed:true,flagPolicy:policy});
 const e=Core.lookup(m,'99900001');assert.equal(e.dc,null);assert.deepEqual(e.blankColumns,['C']);assert.ok(e.formulas.includes('C'));
});
