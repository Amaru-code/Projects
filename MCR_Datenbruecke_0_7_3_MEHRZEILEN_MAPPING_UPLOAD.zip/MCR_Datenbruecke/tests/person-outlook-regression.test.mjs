import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
const Person=require('../lib/person.cjs');

test('Microsoft Outlook is never a person candidate',()=>{
  assert.equal(Person.plausible('Microsoft Outlook'),false);
  assert.equal(Person.plausible('Outlook Microsoft'),false);
});

test('Yours sincerely signature wins over technical Outlook sender',()=>{
  const mail={
    senderName:'Microsoft Outlook',
    body:'Dear Mercer Team,\nThank you for your email.\n\nYours sincerely,\nMark Brailey\nGet Outlook for iOS'
  };
  const c=Person.candidates(mail);
  assert.deepEqual(c.map(x=>x.name),['Mark Brailey']);
  assert.equal(c[0].firstName,'Mark');
  assert.equal(c[0].lastName,'Brailey');
  assert.ok(c[0].sources.includes('Signatur'));
});

test('English signature variants are recognized and system footer names rejected',()=>{
  for(const closing of ['Yours faithfully,','Sincerely,','Sincerely yours,','Best wishes,','Warm regards,']){
    const c=Person.candidates({senderName:'Microsoft Outlook',body:`Hello\n\n${closing}\nJane Doe\nSent from Outlook Mobile`});
    assert.equal(c.length,1,closing);
    assert.equal(c[0].name,'Jane Doe',closing);
  }
});
