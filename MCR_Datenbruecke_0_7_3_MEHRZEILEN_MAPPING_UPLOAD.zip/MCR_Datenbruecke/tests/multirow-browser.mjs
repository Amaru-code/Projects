/** Real Chromium test of the production textarea writer/reader. Only synthetic data. */
import assert from 'node:assert/strict';import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import vm from 'node:vm';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
const src=fs.readFileSync(new URL('../src/local-bot-full-run.mjs',import.meta.url),'utf8');
function functionFrom(a,b){return vm.runInNewContext('('+src.slice(src.indexOf(a),src.indexOf(b,src.indexOf(a))).trim()+')');}
const writer=functionFrom('async function writeDescription(page,text)','\nasync function verifyDescription(');
const reader=functionFrom('async function verifyDescription(page,text)','\nasync function setSelectExact(');
const profile=fs.mkdtempSync(path.join(os.tmpdir(),'mcr-multirow-browser-'));let browser,cdp;let count=0;
const ok=()=>count++;
try{
 browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,extraArgs:['--no-sandbox']});
 ({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.url==='about:blank');
 const base='<form><label>Member<input id="mainForm:member-value-id" value="Mustermann Max (INTL01-99900001)"></label><table><tr><td><div><label>Zusätzliche Beschreibung:</label></div></td></tr><tr><td><textarea id="changing-id" maxlength="450"></textarea></td></tr></table><label>Kommentar:<textarea id="comment"></textarea></label><button id="send" type="button" onclick="window.testSends++">Senden</button><button id="save" type="button" onclick="window.testSaves++">Ticket speichern</button></form>';
 await page.call(html=>{document.body.innerHTML=html;window.testSends=0;window.testSaves=0;},base);
 const lines='USC 20/ DB+\nUSC 20/ DB+';
 let r=await writer(page,lines);assert.equal(r.ok,true);ok();
 assert.equal(await page.eval('document.getElementById("changing-id").value'),lines);ok();
 r=await reader(page,lines);assert.equal(r.ok,true);assert.equal(r.lineCount,2);ok();
 // Repeat is idempotent: the correct value is not re-written and does not fire new changes.
 await page.eval('window.changes=0;document.getElementById("changing-id").onchange=()=>window.changes++');
 r=await writer(page,lines);assert.equal(r.ok,true);assert.equal(await page.eval('window.changes'),0);ok();
 r=await writer(page,'USC 30/ DC');assert.equal(r.ok,false);assert.equal(r.occupied,true);ok();
 assert.equal(await page.eval('document.getElementById("changing-id").value'),lines);ok();
 await page.eval('document.getElementById("changing-id").value="USC 20/ DB+ USC 20/ DB+"');
 assert.equal((await reader(page,lines)).ok,false);ok(); // collapsed line breaks are not proof
 await page.eval('document.getElementById("changing-id").value="USC 20/ DB+"');assert.equal((await reader(page,lines)).ok,false);ok();
 await page.eval('document.getElementById("changing-id").value=""');
 r=await writer(page,'x'.repeat(451));assert.equal(r.ok,false);assert.equal(r.state,'DESCRIPTION_TOO_LONG');ok();
 await page.eval('document.getElementById("changing-id").maxLength=10');
 r=await writer(page,lines);assert.equal(r.ok,false);assert.equal(await page.eval('document.getElementById("changing-id").value'), '');ok();
 await page.eval('document.getElementById("changing-id").maxLength=450;document.getElementById("changing-id").onchange=()=>{document.getElementById("changing-id").value="USC 20/ DB+"}');
 r=await writer(page,lines);assert.equal(r.ok,false);ok(); // synchronous page truncation detected
 assert.equal(await page.eval('window.testSends'),0);assert.equal(await page.eval('window.testSaves'),0);ok();
 assert.equal(await page.eval('document.getElementById("comment").value'),'');ok();
 console.log(JSON.stringify({suite:'multirow-production-textarea',checks:count,status:'PASS',browser:'Chromium headless',platform:process.platform,syntheticOnly:true,sendClicks:0,saveClicks:0},null,2));
}finally{try{cdp?.close();browser?.child?.kill();}catch{}setTimeout(()=>{try{fs.rmSync(profile,{recursive:true,force:true});}catch{}},200);}
