"""0.3.5: description binding / state preservation in native Chromium.
Uses about:blank and test-only SHA256/clipboard bridges because the container
blocks localhost browser navigation. DOM/events are native Chromium.
No Windows, real COMARCH, original Excel or customer mail accessed.
"""
import os,json,hashlib,io,zipfile
from pathlib import Path
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];GROUP=int(os.environ.get('MCR_GROUP','0'));RESULT=[]
HTML='''<!doctype html><html lang="de"><meta charset="utf-8"><style>body{font:16px Arial;background:#edf3f7;margin:20px}form{background:white;width:850px;padding:20px}input{padding:6px;width:440px}textarea{width:650px;height:110px}#profileArea{margin:12px 0}label{display:block}#descriptionArea{margin-top:25px}h1{font-size:24px}td{padding:8px}</style><h1>Fiktiver Formular-Test · MCR 0.3.5</h1><p>Nachgebildete Felder. Keine COMARCH-Verbindung und kein E-Mail-Versand.</p><form id="caseForm" onsubmit="return false"><p>Ticket-ID: <span id="ticket">90000001</span></p><label>Member</label><input id="mainForm:member-value-id" value="Mustermann Max (INTL01-99900001)"><div id="profileArea"><span>MercerID:</span><b>INTL01-99900001</b></div><div id="descriptionArea">__MARKUP__</div><label for="comment">Kommentar</label><textarea id="comment"></textarea><button id="send" type="button">Senden</button><button id="save" type="button">Ticket speichern</button></form><div id="foreignArea"></div></html>'''
DEFAULT='<div><span><b>Zusätzliche Beschreibung:</b></span></div><div><span><textarea id="descActual"></textarea></span></div>'
PLAIN='<p>Individuelle Maske</p><textarea id="descActual"></textarea>'
base=(R/'examples/DEMO_mapping.json').read_text()
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);ctx=browser.new_context(viewport={'width':1660,'height':1160},permissions=['clipboard-read','clipboard-write'])
 page=ctx.new_page();page.expose_function('__testDigest',lambda data:list(hashlib.sha256(bytes(data)).digest()));errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 def mark(s):RESULT.append({'test':s,'status':'PASS'});print('PASS',s,flush=True)
 def diag():return page.evaluate('MCR_MAIL.diagnostic()')
 def reset(markup=DEFAULT,old=False,extra=''):
  page.evaluate('window.MCR_MAIL?.close()');page.set_content(HTML.replace('__MARKUP__',markup));page.evaluate('(v)=>document.getElementById("foreignArea").innerHTML=v',extra)
  page.evaluate('''()=>{window.inputs=0;window.changes=0;window.sends=0;window.saves=0;window.submissions=0;window.f=document.getElementById('mainForm:member-value-id');window.t=document.getElementById('descActual');document.getElementById('caseForm').onsubmit=e=>{e.preventDefault();submissions++;};document.getElementById('send').onclick=()=>sends++;document.getElementById('save').onclick=()=>saves++;if(t){t.addEventListener('input',()=>inputs++);t.addEventListener('change',()=>changes++);}}''')
  page.evaluate("if(!crypto.subtle)Object.defineProperty(crypto,'subtle',{configurable:true,value:{digest:async(_,data)=>new Uint8Array(await __testDigest(Array.from(new Uint8Array(data)))).buffer}});Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText:async text=>{window.__testClipboard=text;}}});")
  page.evaluate((R/('tests/support/MAIL_034_REFERENCE.js' if old else 'COMARCH_MAIL_ASSISTENT.js')).read_text())
  page.evaluate('v=>MCR_MAIL.loadMapText(v)',base)
  root=page.locator('#__mcr_mail_assistant_v3');root.get_by_label('Diese Bestandsversion',exact=False).check()
  page.evaluate("MCR_MAIL.setMail({format:'MANUAL',subject:'Frage',senderName:'Max Mustermann',senderEmail:'',body:'Mit freundlichen Grüßen\\nMax Mustermann',warnings:[]})")
  root.get_by_label('Mail gehört zu diesem Ticket',exact=False).check();root.get_by_role('button',name='Übernommene Person prüfen → Schritt 4',exact=True).click()
  page.wait_for_function('MCR_MAIL.diagnostic().flow.lookupReady',timeout=6000);return root
 def apply(root):root.get_by_role('button',name='Beschreibung in COMARCH einsetzen',exact=True).click()
 def written():page.wait_for_function('MCR_MAIL.diagnostic().flow.descriptionWritten',timeout=5000)
 def no_write():assert page.evaluate('[inputs,changes,sends,saves,submissions]')==[0,0,0,0,0]
 def quiet():assert page.evaluate('[sends,saves,submissions]')==[0,0,0]
 def code_of(expr):return page.evaluate('()=>{try{'+expr+';return null;}catch(e){return e.code;}}')
 try:
  if GROUP in (0,1):
   root=reset(old=True);apply(root);assert diag()['lastError']=='DESCRIPTION_FIELD';assert not diag()['flow']['lookupReady'];assert root.get_by_role('button',name='Beschreibung kopieren',exact=True).is_disabled();no_write()
   mark('0.3.4 reproduced: dynamic/nested target not found; valid lookup and copy button erased')
   root=reset();apply(root);written();assert page.locator('#descActual').input_value()=='USC 10/ PP+';assert page.locator('#comment').input_value()=='';assert page.evaluate('[inputs,changes]')==[1,1];quiet()
   mark('0.3.5 nested semantic target found independently of dynamic ID; one guarded input/change write')
   page.screenshot(path=str(R/'docs/DESCRIPTION_READY.png'),full_page=True)
   apply(root);written();assert page.evaluate('[inputs,changes]')==[1,1];quiet();mark('Identical description is a no-op: no duplicate change or input events')
   root=reset(PLAIN);apply(root);assert diag()['lastError']=='DESCRIPTION_FIELD';assert diag()['flow']['lookupReady'];assert not root.get_by_role('button',name='Beschreibung kopieren',exact=True).is_disabled();no_write();mark('Missing target preserves member-bound lookup, source values and copy button')
   root.get_by_role('button',name='Beschreibung kopieren',exact=True).click();assert page.evaluate('window.__testClipboard')=='USC 10/ PP+';no_write();mark('Copy action sends intact preview to clipboard stub after target failure')
   page.evaluate("()=>{navigator.clipboard.writeText=async()=>{throw new Error('not allowed');};}");root.get_by_role('button',name='Beschreibung kopieren',exact=True).click();assert diag()['lastError']=='COPY_FAILED';assert diag()['flow']['lookupReady'];no_write();mark('Clipboard denial preserves readable preview and does not attempt any field write')
   page.evaluate("()=>{navigator.clipboard.writeText=async value=>{window.__testClipboard=value;};}")
   root.get_by_role('button',name='Beschreibungsfeld verbinden',exact=True).click();page.locator('#descActual').click(modifiers=['Alt']);assert diag()['description']['bound'];no_write();assert page.locator('#descActual').input_value()==''
   mark('Real trusted ALT-click binds exact textarea without input/change or application clicks')
   apply(root);written();assert page.locator('#descActual').input_value()=='USC 10/ PP+';quiet();mark('Explicit bind then explicit insert recovers unknown markup')
   raw=bytes(page.evaluate('async()=>Array.from(await MCR_MAIL.diagnosticBytes())'))
   with zipfile.ZipFile(io.BytesIO(raw)) as z:
    assert z.testzip() is None
    for line in z.read('SHA256SUMS.txt').decode().splitlines():h,n=line.split('  ');assert hashlib.sha256(z.read(n)).hexdigest()==h
    d=z.read('diagnostic.json').decode()
    for s in ['99900001','90000001','Mustermann','Max','descActual','caseForm','USC 10/ PP+','http://']:assert s not in d,s
   mark('Diagnostic ZIP CRC/hashes pass; no field values, names, IDs, selectors or URLs exported')
  if GROUP in (0,2):
   layouts=[
    ('label-for with changing ID','<label for="descActual">Zusätzliche Beschreibung:</label><textarea id="descActual"></textarea>'),
    ('nested table-cell label/value','<table><tr><td><span><b>Zusätzliche Beschreibung:</b></span></td><td><div><textarea id="descActual"></textarea></div></td></tr></table>'),
    ('ARIA name','<textarea aria-label="Zusätzliche Beschreibung" id="descActual"></textarea>'),
    ('ARIA labelledby','<div id="cap">Zusätzliche Beschreibung</div><p>Ein Bereich</p><textarea aria-labelledby="cap" id="descActual"></textarea>'),
    ('definition list','<dl><dt><span>Zusätzliche Beschreibung:</span></dt><dd><textarea id="descActual"></textarea></dd></dl>'),
    ('wrapping label','<label>Zusätzliche Beschreibung:<textarea id="descActual"></textarea></label>'),
    ('NBSP and decomposed umlaut','<span>Zusa\u0308tzliche\u00a0Beschreibung :</span><textarea id="descActual"></textarea>')]
   for title,html in layouts:
    root=reset(html);apply(root);written();assert page.locator('#descActual').input_value()=='USC 10/ PP+';quiet();mark('Semantic layout: '+title)
   root=reset(extra='<form id="other"><label for="wrong">Zusätzliche Beschreibung:</label><textarea id="wrong"></textarea></form>');apply(root);written();assert page.locator('#wrong').input_value()=='';quiet();mark('Other form ignored even with identical description label')
  if GROUP in (0,3):
   root=reset(PLAIN)
   assert code_of("MCR_MAIL.bindDescription(document.getElementById('comment'))")=='DESCRIPTION_BIND_CONFLICT';no_write();mark('Explicit binding rejects separately labelled Kommentar')
   assert code_of('MCR_MAIL.bindDescription(f)')=='DESCRIPTION_BIND_TARGET';no_write();mark('Explicit binding rejects member input and cannot write an ID')
   assert code_of('MCR_MAIL.bindDescription(document.body)')=='DESCRIPTION_BIND_TARGET';no_write();mark('Body/label marking is not an editable target')
   page.evaluate("document.getElementById('foreignArea').innerHTML='<form><textarea id=wrong></textarea></form>'")
   assert code_of("MCR_MAIL.bindDescription(document.getElementById('wrong'))")=='DESCRIPTION_BIND_TARGET';no_write();mark('Explicit binding rejects foreign-form textarea')
   page.evaluate("document.getElementById('foreignArea').innerHTML='<iframe id=mailFrame srcdoc=\"<textarea id=bodyText></textarea>\"></iframe>'")
   page.frame_locator('#mailFrame').locator('#bodyText').wait_for()
   assert code_of("MCR_MAIL.bindDescription(document.getElementById('mailFrame').contentDocument.getElementById('bodyText'))")=='DESCRIPTION_BIND_TARGET';no_write();mark('Mail/editor iframe cannot become description target')
   root=reset(PLAIN);page.evaluate('MCR_MAIL.bindDescription(t)');page.evaluate('t.replaceWith(t.cloneNode(true));window.t=document.getElementById("descActual")');apply(root)
   assert diag()['lastError']=='DESCRIPTION_FIELD';assert diag()['flow']['lookupReady'];no_write();mark('Bound node replaced with same ID is stale, not silently rebound or overwritten')
   root=reset('<label for="descActual">Zusätzliche Beschreibung</label><textarea id="descActual"></textarea><label for="second">Zusätzliche Beschreibung</label><textarea id="second"></textarea>');apply(root)
   assert diag()['description']['target']['state']=='AMBIGUOUS';assert diag()['flow']['lookupReady'];no_write();mark('Two same-labelled targets block automatic insertion')
   page.evaluate('MCR_MAIL.bindDescription(t)');apply(root);written();assert page.locator('#second').input_value()=='';quiet();mark('Explicit binding disambiguates duplicate labels without writing the other textarea')
  if GROUP in (0,4):
   for setting,code in [('t.readOnly=true','DESCRIPTION_READONLY'),('t.disabled=true','DESCRIPTION_READONLY'),('t.maxLength=4','DESCRIPTION_TOO_LONG'),("t.value='vorhandener Text'",'DESCRIPTION_EXISTS')]:
    root=reset();page.evaluate(setting);apply(root);assert diag()['lastError']==code;assert diag()['flow']['lookupReady'];no_write();mark('Protected without losing lookup: '+code)
   root=reset();page.evaluate("()=>{t.oninput=()=>setTimeout(()=>{t.value='app reset'},150);}");apply(root);page.wait_for_function("MCR_MAIL.diagnostic().lastError==='DESCRIPTION_VERIFY'");assert diag()['flow']['lookupReady'];assert not diag()['flow']['descriptionWritten'];assert page.evaluate('[inputs,changes]')==[1,1];quiet();mark('Delayed application reset detected; no rewrite, valid preview retained')
   root=reset();page.evaluate("()=>{t.oninput=()=>{f.value='Andermann Anna (INTL01-99900002)'};}");apply(root);assert not diag()['flow']['lookupReady'];assert page.evaluate('[inputs,changes]')==[1,0];quiet();mark('Identity change during input invalidates lookup and blocks change event')
   root=reset();apply(root);written();page.locator('#descActual').fill('manuelle Änderung');page.wait_for_function("MCR_MAIL.diagnostic().lastError==='DESCRIPTION_CHANGED_AFTER_INSERT'");assert diag()['flow']['lookupReady'];assert not diag()['flow']['descriptionWritten'];assert page.locator('#descActual').input_value()=='manuelle Änderung';quiet();mark('Later manual edit cancels inserted-status but is not overwritten')
   root=reset();page.evaluate("document.getElementById('ticket').textContent='90000002'");apply(root);assert not diag()['flow']['lookupReady'];no_write();mark('Ticket change before insertion blocks every write')
   root=reset();apply(root);page.evaluate('MCR_MAIL.close()');page.wait_for_timeout(1200);assert not page.locator('#__mcr_mail_assistant_v3').count();assert page.evaluate('[inputs,changes]')==[1,1];quiet();mark('Close cancels pending verification without extra events or uncaught error')
  assert not errors,errors
  report={'group':GROUP,'testedBundleSha256':hashlib.sha256((R/'COMARCH_MAIL_ASSISTENT.js').read_bytes()).hexdigest(),'environment':{'os':'Linux','browser':browser.version,'origin':'about:blank','shaBridge':'test-only','clipboard':'test-only stub','nativeWebCrypto':False,'actualCOMARCH':False},'tests':RESULT,'passed':len(RESULT),'pageErrors':errors}
  (R/f'docs/DESCRIPTION_BROWSER_{GROUP}.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print('TOTAL PASS',len(RESULT),flush=True)
 except Exception as e:
  try:print(json.dumps(diag(),indent=2),flush=True);page.screenshot(path=str(R/'docs/DESCRIPTION_FAILED.png'),full_page=True)
  except:pass
  (R/f'docs/DESCRIPTION_BROWSER_{GROUP}.json').write_text(json.dumps({'passedBeforeFailure':len(RESULT),'tests':RESULT,'error':str(e),'pageErrors':errors},indent=2)+'\n');raise
 finally:browser.close()
