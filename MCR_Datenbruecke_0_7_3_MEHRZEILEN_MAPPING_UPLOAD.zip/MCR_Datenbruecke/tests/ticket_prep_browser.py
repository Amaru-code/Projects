from pathlib import Path
import json,hashlib,io,zipfile
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1]
HTML='''<!doctype html><html><meta charset="utf-8"><style>body{font:16px Arial;margin:20px}form{width:900px}label{display:block;margin-top:12px}input,select{width:420px;padding:6px}.pop{position:absolute;background:white;border:1px solid #888;width:420px}.pop div{padding:6px}iframe{width:700px;height:180px;margin-top:20px}</style><form id=f onsubmit="window.submits++;return false"><label>Member</label><input id="mainForm:member-value-id" value="Mustermann Max (INTL01-99900001)"><label>Zuständigkeit</label><select id="mainForm:responsibility-value-id"><option>Bitte wählen</option><option value="SL">Second Level</option></select><label>Kategorie</label><input id="mainForm:category-value-id"><div id=cat class=pop hidden></div><label>Unterkategorie</label><input id="mainForm:category-sub-value-id"><div id=sub class=pop hidden></div><label>Signatur</label><input id="mainForm:signature-value-id"><div id=sig class=pop hidden></div><textarea id=desc>USC 20/ PP+</textarea><iframe id=editor></iframe><button id=send type=button>Senden</button><button id=save type=button>Ticket speichern</button></form></html>'''
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);page=b.new_page(viewport={'width':1500,'height':1100});errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.set_content(HTML)
 page.evaluate('''()=>{window.sends=0;window.saves=0;window.submits=0;send.onclick=()=>sends++;save.onclick=()=>saves++;function wire(inputId,popId,value){const f=document.getElementById(inputId),p=document.getElementById(popId);f.onfocus=()=>{p.hidden=false;const r=document.createElement('div');r.textContent=value;r.onmousedown=()=>{f.value=value;p.hidden=true;window['commit_'+popId]=(window['commit_'+popId]||0)+1;};p.replaceChildren(r);};}wire('mainForm:category-value-id','cat','Allgemeine Schriftwechsel');wire('mainForm:category-sub-value-id','sub','Personenschriftwechsel');wire('mainForm:signature-value-id','sig','INTL01 - Intel Deutschland GmbH');const d=editor.contentDocument;d.open();d.write('<html contenteditable="true"><body></body></html>');d.close();}''')
 page.evaluate((R/'COMARCH_TICKET_VORBEREITER.js').read_text())
 root=page.locator('#__mcr_ticket_preparer_v4')
 root.get_by_role('button',name='Feste Felder vorbereiten',exact=True).click();page.wait_for_timeout(3500)
 assert page.locator('#mainForm\\:responsibility-value-id').input_value()=='SL'
 assert page.locator('#mainForm\\:category-value-id').input_value()=='Allgemeine Schriftwechsel'
 assert page.locator('#mainForm\\:category-sub-value-id').input_value()=='Personenschriftwechsel'
 assert page.locator('#mainForm\\:signature-value-id').input_value()=='INTL01 - Intel Deutschland GmbH'
 assert page.evaluate('[commit_cat,commit_sub,commit_sig]')==[1,1,1]
 root.get_by_label('Ich habe die vier Werte',exact=False).check();root.get_by_label('Anrede').select_option('Herr');root.get_by_label('Nachname').fill('Mustermann');root.get_by_role('button',name='Antworttext erzeugen',exact=True).click();root.get_by_role('button',name='Antwort in COMARCH einsetzen',exact=True).click();page.wait_for_timeout(1200)
 text=page.frame_locator('#editor').locator('html').inner_text();assert text.startswith('Sehr geehrter Herr Mustermann,');assert 'bestmöglichen Support' in text
 root.get_by_label('Die zusätzliche Beschreibung',exact=False).check();root.get_by_label('Den Empfänger',exact=False).check();root.get_by_role('button',name='Vor Versand prüfen',exact=True).click();d=page.evaluate('MCR_PREP.diagnostic()');assert d['readyBeforeSend'] is True;assert d['capabilities']['automaticSend'] is False and d['capabilities']['automaticSave'] is False;assert page.evaluate('[sends,saves,submits]')==[0,0,0]
 # Diagnostic has no personal values/reply text/URLs.
 page.evaluate("Object.defineProperty(crypto,'subtle',{configurable:true,value:{digest:async(_,data)=>new Uint8Array(await (async()=>{const a=Array.from(new Uint8Array(data));return await window.__hash(a)})()).buffer}})") if False else None
 for forbidden in ['Mustermann','99900001','USC 20/ PP+','Sehr geehrter','http://','https://']:
  assert forbidden not in json.dumps(d,ensure_ascii=False)
 assert not errors,errors
 report={'environment':{'os':'Linux','browser':b.version,'origin':'about:blank','actualCOMARCH':False},'passed':12,'diagnostic':d,'pageErrors':errors};(R/'docs/TICKET_PREP_BROWSER.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 page.screenshot(path=str(R/'docs/TICKET_PREP_READY.png'),full_page=True);print('TOTAL PASS 12')
 b.close()
