import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import Widget from '../lib/member-widget.cjs';
// Unit-level interface double; full DOM/browser tests are separate.
// 0.3.3 fixture includes the actual popup ID for DOM identity validation.
function fixture(count=1){
 const win={getComputedStyle:n=>({visibility:n.hidden?'hidden':'visible',display:n.hidden?'none':'block'})};
 const doc={defaultView:win,getElementById:id=>id===field.id+'_div'?list:null};
 const node=(tag)=>({tagName:tag,isConnected:true,ownerDocument:doc,hidden:false,getClientRects(){return this.hidden?[]:[{}];}});
 const field={...node('INPUT'),id:'mainForm:member-value-id'};
 const nodes=Array.from({length:count},(_,i)=>({...node('DIV'),autocompleteIndex:i}));
 const wrap={children:nodes};const list={...node('DIV'),id:field.id+'_div',children:[wrap],firstElementChild:wrap,contains:n=>nodes.includes(n)};
 const instance={element:field,update:list,entryCount:count,getEntry:i=>nodes[i],active:true,changed:false,inTransit:false,hasFocus:true};
 win.Ice={Scriptaculous:{Autocompleter:{Finder:{find:id=>id===field.id?instance:null}}}};
 return {win,doc,field,nodes,list,instance};
}
test('ICE adapter discovers exact field, update container and entry index',()=>{const x=fixture(),r=Widget.inspect(x.field);assert.equal(r.safe.state,'SINGLE_RENDERED');assert.equal(r.entries[0],x.nodes[0]);});
test('ICE adapter counts all delivered entries',()=>{const x=fixture(2);assert.equal(Widget.inspect(x.field).safe.state,'MULTIPLE_RENDERED');});
for(const k of ['changed','inTransit'])test('ICE does not select while '+k,()=>{const x=fixture();x.instance[k]=true;assert.equal(Widget.inspect(x.field).safe.state,'BUSY');});
for(const k of ['active','hasFocus'])test('ICE needs active/focused live dropdown '+k,()=>{const x=fixture();x.instance[k]=false;assert.equal(Widget.inspect(x.field).safe.state,'CLOSED');});
test('ICE readiness with missing inTransit metadata rejected',()=>{const x=fixture();delete x.instance.inTransit;assert.equal(Widget.inspect(x.field).safe.state,'READINESS_UNKNOWN');});
test('ICE unrelated same-looking list cannot bind',()=>{const x=fixture();x.instance.update={...x.list};assert.equal(Widget.inspect(x.field).safe.state,'BINDING_MISMATCH');});
test('ICE cannot use replaced input instance',()=>{const x=fixture();x.instance.element={...x.field};assert.equal(Widget.inspect(x.field).safe.state,'BINDING_MISMATCH');});
test('ICE hidden duplicate is not reduced to one',()=>{const x=fixture(2);x.nodes[1].hidden=true;assert.equal(Widget.inspect(x.field).safe.state,'HIDDEN_ENTRY');});
test('ICE invisible popup blocked',()=>{const x=fixture();x.list.hidden=true;assert.equal(Widget.inspect(x.field).safe.state,'CLOSED');});
test('ICE registry count must agree with rendered entries',()=>{const x=fixture(2);x.instance.entryCount=1;assert.equal(Widget.inspect(x.field).safe.state,'COUNT_MISMATCH');});
test('ICE entry property required, not just text',()=>{const x=fixture();delete x.nodes[0].autocompleteIndex;assert.equal(Widget.inspect(x.field).safe.state,'ENTRY_SHAPE_MISMATCH');});
test('ICE two registries may share identical instance',()=>{const x=fixture();x.win.Autocompleter={Finder:{find:()=>x.instance}};assert.equal(Widget.inspect(x.field).safe.state,'SINGLE_RENDERED');});
test('ICE conflicting registries blocked',()=>{const x=fixture();x.win.Autocompleter={Finder:{find:()=>({...x.instance})}};assert.equal(Widget.inspect(x.field).safe.state,'AMBIGUOUS_REGISTRY');});
test('ICE safe report contains no field IDs, URLs, names or text',()=>{const x=fixture();const r=JSON.stringify(Widget.inspect(x.field).safe);for(const s of ['mainForm','INTL01','99900001','Mustermann','http'])assert.ok(!r.includes(s));});
test('ICE no registry is a readable blocked state',()=>{const x=fixture();delete x.win.Ice;assert.equal(Widget.inspect(x.field).safe.state,'REGISTRY_UNAVAILABLE');});
test('0.3.2 identity candidate no longer calls inventory lookup',()=>{const s=fs.readFileSync(new URL('../browser/mail-ui.js',import.meta.url),'utf8');const part=s.split('function candidateIdentity')[1].split('function tick')[0];assert.ok(!part.includes('Core.lookup('));assert.ok(part.includes('REVIEWED_ID_REQUIRED'));assert.ok(part.includes('COMMIT_PROFILE_REQUIRED'));});
test('0.3.2 only one click per search, no hidden idx edits or forced selector',()=>{const s=fs.readFileSync(new URL('../browser/mail-ui.js',import.meta.url),'utf8');assert.ok(s.includes('autoAttempted=true;autoClickAt=Date.now()'));assert.ok(s.includes('one.element.click()'));assert.ok(!s.includes("'_idx'"));assert.ok(!s.includes('selectEntry('));});
