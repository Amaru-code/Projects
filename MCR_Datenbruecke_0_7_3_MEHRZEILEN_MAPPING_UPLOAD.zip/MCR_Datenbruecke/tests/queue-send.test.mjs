import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
const Q=require('../lib/queue-send.cjs');

test('member search transliterates German umlauts only for query',()=>{
  assert.equal(Q.memberSearchQuery('Jürgen','Müller'),'Mueller Juergen');
  assert.equal(Q.memberSearchQuery('Groß','Bär'),'Baer Gross');
});

test('name comparison treats umlaut and ae/oe/ue/ss as equivalent',()=>{
  assert.equal(Q.namesEquivalent('Mueller Juergen (INTL01-123)','Jürgen','Müller'),true);
  assert.equal(Q.namesEquivalent('Müller Jürgen (INTL01-123)','Jürgen','Müller'),true);
  assert.equal(Q.namesEquivalent('Meier Juergen (INTL01-123)','Jürgen','Müller'),false);
});

test('queue eligibility requires blank description and email when source is known',()=>{
  const rows=[
    {ticketId:'1',descriptionBlank:false,source:'E-MAIL'},
    {ticketId:'2',descriptionBlank:true,source:'POST'},
    {ticketId:'3',descriptionBlank:true,source:'E-MAIL'},
  ];
  assert.equal(Q.chooseFirstEligible(rows).ticketId,'3');
});
