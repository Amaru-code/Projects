/** Synthetic test inputs only. No personal workbook data. */
import fs from 'node:fs';
import {readZip,writeZip} from '../lib/zip.mjs';
export const key='99900001';
export const sourceRow=(x={})=>({row:10,B:key,C:'',D:'1',E:'0',F:'1',L:'20',O:'M',formulas:[],errors:{},...x});
export const book=(rows)=>({meta:{filename:'FIKTIV.xlsx',sheet:'output',sha256:'a'.repeat(64),headerRow:2,headers:{B:'ClientEEID',C:'IsEligible_DC',D:'IsEligible_IPP',E:'IsEligible_PensIntel',F:'IsEligible_TPP',L:'USC',O:'Gender'}},allRows:()=>structuredClone(rows)});
const esc=v=>String(v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
export function workbookBytes(rows,options={}){
  const archive=readZip(fs.readFileSync(new URL('../examples/DEMO_Datenbestand.xlsx',import.meta.url)));
  const h={row:2,...book([]).meta.headers,...(options.headers??{})};
  let contents='';for(const r of [h,...rows]){
    contents+='<row r="'+r.row+'">';
    for(const c of ['B','C','D','E','F','L','O']){
      if(r.xml?.[c]){contents+=r.xml[c];continue;}
      if(r[c]===undefined||r[c]===null||r[c]==='')continue;
      contents+='<c r="'+c+r.row+'" t="inlineStr"><is><t>'+esc(r[c])+'</t></is></c>';
    }
    contents+='</row>';
  }
  const xml='<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>'+contents+'</sheetData></worksheet>';
  return writeZip(archive.names.map(name=>({name,data:name==='xl/worksheets/sheet1.xml'?xml:archive.get(name)})));
}
