import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import Suggest from '../lib/member-suggest.cjs';

const root=new URL('../',import.meta.url);
const read=p=>fs.readFileSync(new URL(p,root),'utf8');

function fixture(rows){
  const win={getComputedStyle:()=>({visibility:'visible',display:'block'})};
  const doc={
    defaultView:win,
    baseURI:'https://comarchecm.mercer.com/DMSWWW/main.jspx',
    location:{origin:'https://comarchecm.mercer.com'},
    querySelectorAll(sel){
      if(sel==='script[src]') return [{src:'https://comarchecm.mercer.com/DMSWWW/js/suggestions.js'}];
      if(sel==='div,li,tr,button,a') return rows;
      return [];
    }
  };
  const field={tagName:'INPUT',id:'mainForm:member-value-id',isConnected:true,ownerDocument:doc,
    getClientRects:()=>[{}],contains:()=>false};
  for(const r of rows){
    Object.assign(r,{tagName:r.tagName??'DIV',isConnected:true,ownerDocument:doc,getClientRects:()=>[{}],contains:()=>false,onmousedown:r.onmousedown??function(){}});
  }
  return {doc,field};
}

test('exact fallback finds one visible mousedown suggestion by reviewed name and ID',()=>{
  const rows=[{innerText:'Wu Xiaofeng (INTL01-11368577) - 1962-06-25'}];
  const {field}=fixture(rows);
  const r=Suggest.exactExpected(field,'11368577','Wu Xiaofeng');
  assert.equal(r.safe.state,'SINGLE_EXACT');
  assert.equal(r.entry,rows[0]);
});

test('exact fallback refuses duplicate exact rows',()=>{
  const rows=[{innerText:'Wu Xiaofeng (INTL01-11368577)'},{innerText:'Wu Xiaofeng (INTL01-11368577)'}];
  const {field}=fixture(rows);
  assert.equal(Suggest.exactExpected(field,'11368577','Wu Xiaofeng').safe.state,'AMBIGUOUS_EXACT');
});

test('exact fallback refuses wrong ID or wrong name',()=>{
  let x=fixture([{innerText:'Wu Xiaofeng (INTL01-99999999)'}]);
  assert.equal(Suggest.exactExpected(x.field,'11368577','Wu Xiaofeng').safe.state,'NO_EXACT_MATCH');
  x=fixture([{innerText:'Wu Andere (INTL01-11368577)'}]);
  assert.equal(Suggest.exactExpected(x.field,'11368577','Wu Xiaofeng').safe.state,'NO_EXACT_MATCH');
});

test('one-script runner parses and contains mail + prep modules',()=>{
  const b=read('COMARCH_RUNNER.js');
  new vm.Script(b);
  assert.ok(b.includes('MCR Ticket Runner 0.4.1'));
  assert.ok(b.includes('MCR Mail-Assistent 0.3.6'));
  assert.ok(b.includes('MCR Ticket-Vorbereiter 0.4.1'));
  assert.ok(b.includes('descriptionWritten'));
  assert.ok(b.includes('automaticSend:false'));
  assert.ok(b.includes('automaticSave:false'));
});

test('Windows launchers detect direct execution from ZIP/temp extraction',()=>{
  for(const f of ['RUNNER_OEFFNEN.cmd','MAIL_ASSISTENT_OEFFNEN.cmd','TICKET_VORBEREITER_OEFFNEN.cmd']){
    const s=read(f);
    assert.match(s,/if not exist/);
    assert.match(s,/entpack/i);
    assert.match(s,/notepad\.exe/i);
  }
});
