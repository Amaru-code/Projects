import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import Core from '../lib/data-core.cjs';import Person from '../lib/person.cjs';
import {makeMapping} from '../src/mapping.mjs';import {sha256} from '../lib/core.mjs';
import {checkMapText,compareSource,safeMemberReport} from '../lib/member-diagnostic.mjs';
const row=(extra={})=>({row:17,B:'99900001',C:'0',D:'1',E:'0',L:'10',formulas:[],errors:{},...extra});
const meta={filename:'PRIVATE_SOURCE_NAME.xlsx',sheet:'output',sha256:'a'.repeat(64),headers:{B:'ClientEEID',C:'IsEligible_DC',D:'IsEligible_IPP',E:'IsEligible_PensIntel',L:'USC'}};
const book=rows=>({meta,allRows:()=>structuredClone(rows)});
const mapping=rows=>makeMapping(book(rows),{headerLConfirmed:true});
const err=(fn,code)=>assert.throws(fn,e=>e.code===code);
for(const [extra,code,column,state] of [
 [{C:''},'FLAG_INVALID','C','EMPTY'],[{D:' '},'FLAG_INVALID','D','EMPTY'],[{E:'2'},'FLAG_INVALID','E','NOT_BINARY'],
 [{L:''},'USC_INVALID','L','EMPTY'],[{L:'text'},'USC_INVALID','L','NOT_NUMERIC'],[{errors:{C:'CUSTOM PRIVATE ERROR'}},'CELL_ERROR','C','ERROR_OR_CACHE'],
 [{D:'0'},'NO_PLAN','CDE','ALL_ZERO']])test('Blocked lookup reports '+code+' '+column+' '+state,()=>{
 const m=mapping([row(extra)]);assert.throws(()=>Core.lookup(m,'99900001'),e=>e.code==='ID_BLOCKED'&&e.blocking.codes.includes(code)&&e.blocking.issues.some(i=>i.column===column&&i.state===state));
 assert.ok(!JSON.stringify(Core.blockInfo(m,'99900001')).includes('CUSTOM PRIVATE ERROR'));
});
test('Existing blocked JSON with no issues remains readable',()=>{const m=mapping([row({C:''})]);delete m.payload.blocked['99900001'].issues;Core.validateMap(m);assert.equal(Core.blockInfo(m,'99900001').legacyDetails,true);});
test('Duplicate ID keeps both source rows and stays blocked',()=>{const m=mapping([row(),row({row:21})]);assert.deepEqual(Core.blockInfo(m,'99900001').sourceRows,[17,21]);err(()=>Core.lookup(m,'99900001'),'ID_BLOCKED');});
test('Diagnostic sanitizes arbitrary code and issue strings',()=>{const m=mapping([row({C:''})]);m.payload.blocked['99900001'].codes=['PRIVATE_PERSON'];m.payload.blocked['99900001'].issues=[{code:'FLAG_INVALID',column:'SECRET_COLUMN',state:'PRIVATE_VALUE'}];const b=Core.blockInfo(m,'99900001');assert.deepEqual(b.codes,['INVALID_ROW']);assert.equal(b.issues.length,0);});
test('No change to a valid description',()=>assert.equal(Core.lookup(mapping([row()]),'99900001').description,'USC 10/ PP+'));
test('Blocked ID distinct from unknown ID',()=>{const m=mapping([row({C:''})]);err(()=>Core.lookup(m,'90000001'),'ID_NOT_FOUND');err(()=>Core.lookup(m,'99900001'),'ID_BLOCKED');});
for(const [input,want] of [['INTL01-99900001','99900001'],['99900001','99900001'],['  INTL01-001234  ','001234'],['',null]])test('Person ID input '+JSON.stringify(input),()=>assert.equal(Person.personId(input),want));
for(const input of ['Ticket-ID: 90000001','113.68','INTL01-000','AB123','99900001@intel.com'])test('Reject non-person-ID shape '+input,()=>err(()=>Person.personId(input),'PERSON_ID_INVALID'));
const mail=extra=>({subject:'',senderName:'Max Mustermann',body:'Mit freundlichen Grüßen\nMax Mustermann',...extra});
const hints=x=>Person.identifierHints(x,Core.analyzeMail([x.subject,x.body].join('\n')).idHints,Person.candidates(x));
for(const m of [mail({subject:'Fwd: AW: Anfrage / Max Mustermann, 99900001'}),mail({body:'Mit freundlichen Grüßen\nMax Mustermann\nBetreff: Anfrage / Max Mustermann\n99900001\nDatum: heute'})])test('Name-adjacent subject number is only a contextual candidate '+m.subject,()=>{const h=hints(m);assert.equal(h.length,1);assert.equal(h[0].clientId,'99900001');assert.equal(h[0].strength,'CONTEXTUAL');});
test('Explicit subject ClientEEID is picked up separately',()=>{const h=hints(mail({subject:'ClientEEID: 99900001'}));assert.equal(h[0].strength,'EXPLICIT');});
test('Repeated contextual occurrences deduplicated',()=>assert.equal(hints(mail({subject:'Max Mustermann, 99900001',body:'Max Mustermann, 99900001\nMit freundlichen Grüßen\nMax Mustermann'})).length,1));
for(const text of ['Ticket 90000001\nTelefon 0891234567','Max Mustermann, 31.12.1960','Max Mustermann, 99900001@example.invalid','Max Mustermann, 99900001-123','Max Mustermann, 99900001.25','Andere Person, 99900001'])test('Do not guess contextual customer ID from '+text,()=>assert.equal(hints(mail({body:text+'\nMit freundlichen Grüßen\nMax Mustermann'})).length,0));
test('Multiple contextual IDs retained as ambiguous',()=>assert.equal(hints(mail({subject:'Max Mustermann, 99900001',body:'Max Mustermann, 99900002\nMit freundlichen Grüßen\nMax Mustermann'})).length,2));
test('Local checker verifies hash before using selected key',()=>{const m=mapping([row()]);assert.equal(checkMapText(JSON.stringify(m),'INTL01-99900001').status,'FOUND');m.payload.entries['99900001'].usc='11';m.payload.entries['99900001'].description='USC 11/ PP+';err(()=>checkMapText(JSON.stringify(m),'99900001'),'MAP_HASH_MISMATCH');});
test('Local checker diagnoses blocked row without modifying snapshot',()=>{const m=mapping([row({C:''})]);const raw=JSON.stringify(m),c=checkMapText(raw,'99900001'),r=compareSource(c,book([row({C:''})]));assert.equal(c.status,'BLOCKED');assert.deepEqual(r.issues,[{code:'FLAG_INVALID',column:'C',state:'EMPTY'}]);assert.equal(JSON.stringify(c.map),raw);});
test('Local checker refuses different XLSX source',()=>{const m=mapping([row({C:''})]);const c=checkMapText(JSON.stringify(m),'99900001');err(()=>compareSource(c,{meta:{...meta,sha256:'b'.repeat(64)},allRows:()=>[row()]}),'SOURCE_CHANGED');});
test('Export report includes reasons but not identifiers, rows, paths or cell values',()=>{const c=checkMapText(JSON.stringify(mapping([row({C:''})])),'99900001'),r=safeMemberReport(c,compareSource(c,book([row({C:''})])));const raw=JSON.stringify(r);for(const text of ['99900001','PRIVATE_SOURCE_NAME','sourceRows','USC 10/ PP+','a'.repeat(64)])assert.ok(!raw.includes(text));assert.deepEqual(r.blockedCodes,['FLAG_INVALID']);});
test('Ticket ID is read-only and is not the key passed to Core.lookup',()=>{const s=fs.readFileSync(new URL('../browser/mail-ui.js',import.meta.url),'utf8');assert.ok(s.includes('ui.ticket.readOnly=true'));assert.ok(s.includes('Core.lookup(map,s.clientId)'));assert.ok(!s.includes('Core.lookup(map,context.id)'));assert.ok(s.includes("lookupKeySource:lookupAttempted?'SELECTED_MEMBER':null"));});
test('Profile label present but empty cannot silently count as committed selection',()=>{const s=fs.readFileSync(new URL('../browser/mail-ui.js',import.meta.url),'utf8');assert.ok(s.includes('MEMBER_COMMIT_PENDING'));assert.ok(s.includes('profile.labelFound&&!profile.clientId'));});
