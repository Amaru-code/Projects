from pathlib import Path
import json,hashlib
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1]
HTML='''<!doctype html><html lang="de"><meta charset="utf-8"><style>body{font:16px Arial;margin:20px}form{width:800px}input,textarea{display:block;margin:8px;width:520px}textarea{height:90px}</style>
<form id="caseForm"><p>Ticket-ID: <span>90000001</span></p>
<label>Member</label><input id="mainForm:member-value-id" value="Mustermann Max (INTL01-99900001)">
<div><span>MercerID:</span><b>INTL01-99900001</b></div>
<label for="mainForm:j_id7019">Zusätzliche Beschreibung:</label><textarea id="mainForm:j_id7019"></textarea>
<select id="mainForm:responsibility-value-id"><option>Second Level</option></select>
<input id="mainForm:category-value-id"><input id="mainForm:category-sub-value-id"><input id="mainForm:signature-value-id">
</form>'''
base=json.loads((R/'examples/DEMO_mapping.json').read_text())
base['payload']['flagPolicy']='ONE_ONLY_BLANK_OMIT_V1'
for e in base['payload']['entries'].values():
    e.update(flagPolicy='ONE_ONLY_BLANK_OMIT_V1',blankColumns=[])
with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True)
    page=browser.new_page(viewport={'width':1500,'height':1000})
    page.set_content(HTML)
    page.expose_function('__testSha',lambda v:list(hashlib.sha256(bytes(v)).digest()))
    page.evaluate("Object.defineProperty(crypto,'subtle',{configurable:true,value:{digest:async(_,data)=>new Uint8Array(await __testSha(Array.from(new Uint8Array(data)))).buffer}})")
    page.evaluate((R/'COMARCH_RUNNER.js').read_text())
    assert page.evaluate('MCR_RUNNER.version')=='0.4.1'
    page.evaluate('''async raw=>{const m=JSON.parse(raw);const d=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(m.payload)));m.payloadSha256=Array.from(new Uint8Array(d),x=>x.toString(16).padStart(2,'0')).join('');await MCR_MAIL.loadMapText(JSON.stringify(m));}''',json.dumps(base))
    root=page.locator('#__mcr_mail_assistant_v3')
    root.get_by_label('Diese Bestandsversion',exact=False).check()
    page.evaluate("MCR_MAIL.setMail({format:'MANUAL',subject:'Frage',senderName:'Max Mustermann',senderEmail:'',body:'Mit freundlichen Grüßen\\nMax Mustermann',warnings:[]})")
    root.get_by_label('Mail gehört zu diesem Ticket',exact=False).check()
    # Selected member already exists; search path validates it instead of clearing it.
    root.get_by_role('button',name='Member suchen',exact=True).click()
    page.wait_for_function('MCR_MAIL.diagnostic().flow.lookupReady',timeout=8000)
    root.get_by_role('button',name='Beschreibung in COMARCH einsetzen',exact=True).click()
    page.wait_for_function('MCR_MAIL.diagnostic().flow.descriptionWritten',timeout=8000)
    page.wait_for_function('window.MCR_PREP && MCR_PREP.version === "0.4.1"',timeout=8000)
    assert not page.locator('#__mcr_mail_assistant_v3').count()
    assert page.locator('#__mcr_ticket_preparer_v4').count()==1
    assert page.locator('#mainForm\\:j_id7019').input_value()=='USC 10/ PP+'
    assert page.evaluate('MCR_RUNNER.diagnostic().phase')=='PREP'
    browser.close()
print('PASS one-injection runner transitions after verified description; no send/save invoked')
