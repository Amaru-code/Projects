"""0.3.2 synthetic browser qualification. No Windows/COMARCH endpoint used.
ICEfaces is a minimal interface/DOM double based on the pinned source contract,
not a loaded production library. About:blank tests have a SHA256-only Python
bridge since native secure-context SubtleCrypto is unavailable in this runtime.
No shipping code is relaxed and browser/security policy is left unchanged.
"""
import hashlib,json,re,pathlib,io,zipfile,copy,sys
# Run groups in fresh browser processes to bound synthetic-page lifetime.
if len(sys.argv)==1:
 import subprocess
 for group in (1,2,3,4):
  subprocess.run([sys.executable,__file__,str(group)],check=True)
 sys.exit(0)
GROUP=int(sys.argv[1])
if GROUP not in (1,2,3,4):raise SystemExit('Group must be 1, 2, 3 or 4')
from playwright.sync_api import sync_playwright
R=pathlib.Path(__file__).resolve().parents[1]
results=[]
def mark(name):
 results.append({'name':name,'status':'PASS'});print('PASS',name,flush=True)
HTML='''<!doctype html><html lang="de"><meta charset="utf-8"><style>
body{font:16px Arial;margin:30px}form{width:660px}label{display:block;margin-top:22px}input{width:600px;padding:6px}textarea{width:600px;height:100px}#profileArea{margin:20px 0}#optionsOuter{background:white} .candidate{padding:12px;border:1px solid #aac;cursor:pointer}button{padding:9px}</style>
<h1>Fiktiver ICEfaces-Auswahltest</h1><p>Kein COMARCH-Endpunkt. Kein Versand.</p><form onsubmit="return false">
<p><b>Ticket-ID:</b> <span>90000001</span></p>
<label for="mainForm:member-value-id">Member</label><input id="mainForm:member-value-id" autocomplete="off">
<div id="mainForm:member-value-id_div" style="display:none"><div></div></div>
<input type="hidden" name="mainForm:member-value-id_idx" value="">
<div id="profileArea"><span>MercerID:</span><strong id="profileId"></strong></div>
<label for="mainForm:j_id7019">Zusätzliche Beschreibung:</label><textarea id="mainForm:j_id7019"></textarea>
<button id="send" type="button">Senden</button><button id="save" type="button">Ticket speichern</button>
</form><div id="outsideCandidate">Mustermann Max (INTL01-99900001)</div></html>'''
JS='''(()=>{
window.demoMode='one';window.demoClicks=0;window.demoSends=0;window.demoSaves=0;window.demoOutside=0;
const f=document.getElementById('mainForm:member-value-id'),list=document.getElementById(f.id+'_div');
const ac={element:f,update:list,entryCount:0,active:false,inTransit:false,changed:false,hasFocus:false,
 getEntry(i){return list.firstElementChild.children[i];}};
window.testAC=ac;window.Ice={Scriptaculous:{Autocompleter:{Finder:{find:id=>id===f.id?ac:null}}}};
window.renderIce=()=>{
 const wrapper=list.firstElementChild;wrapper.replaceChildren();
 if(!f.value.trim()||f.value.includes('INTL01-')){list.style.display='none';ac.active=false;return;}
 list.style.display='block';ac.active=true;ac.hasFocus=true;ac.changed=false;ac.inTransit=demoMode==='busy';
 ac.entryCount=['many','hiddenMany'].includes(demoMode)?2:1;
 for(let i=0;i<ac.entryCount;i++){
 const n=document.createElement('div');n.className='candidate';n.autocompleteIndex=i;
 n.textContent='Mustermann Max (INTL01-9990000'+(i+1)+') - 1970-01-01';
 if(demoMode==='wrongId')n.textContent='Mustermann Max (INTL01-99900002)';
 if(demoMode==='wrongName')n.textContent='Andermann Anna (INTL01-99900001)';
 if(demoMode==='facet'){n.replaceChildren();let a=document.createElement('span');a.className='informal';a.textContent='Mustermann Max (INTL01-99900001) - 1970-01-01';let hidden=document.createElement('span');hidden.style.display='none';hidden.textContent='Mustermann Max (INTL01-99900001)';n.append(a,hidden);}
 if(demoMode==='hiddenMany'&&i===1)n.style.display='none';
 n.addEventListener('click',()=>{
 window.demoClicks++;f.value='Mustermann Max (INTL01-9990000'+(i+1)+')';
 ac.inTransit=true;ac.active=false;list.style.display='none';
 if(demoMode!=='neverCommit')setTimeout(()=>{const p=document.getElementById('profileId');if(p)p.textContent='INTL01-9990000'+(i+1);ac.inTransit=false;},400);
 });wrapper.append(n);
 }
};
f.addEventListener('input',renderIce);
document.getElementById('send').onclick=()=>demoSends++;
document.getElementById('save').onclick=()=>demoSaves++;
document.getElementById('outsideCandidate').onclick=()=>demoOutside++;
})();'''
base=json.loads((R/'examples/DEMO_mapping.json').read_text())
P='ONE_ONLY_BLANK_OMIT_V1'
new=copy.deepcopy(base);new['payload']['flagPolicy']=P
for entry in new['payload']['entries'].values():entry.update(flagPolicy=P,blankColumns=[])
new['payload']['entries']['99900001'].update(dc=None,blankColumns=['C'])
new['payload']['summary']['blankOmittedRows']=1
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True)
 page=b.new_page(viewport={'width':1550,'height':1120});page.set_default_timeout(10000)
 native_wait=page.wait_for_function
 page.wait_for_function=lambda expr,**kw:native_wait(expr,polling=100,**kw)
 page.expose_function('__testSha',lambda data:list(hashlib.sha256(bytes(data)).digest()))
 def reset(mode='one',snapshot=None,has_id=True,profile=True,approve=True):
  page.evaluate('window.MCR_MAIL?.close()')
  page.set_content(HTML);page.evaluate(JS)
  page.evaluate("Object.defineProperty(crypto,'subtle',{configurable:true,value:{digest:async(_,data)=>new Uint8Array(await __testSha(Array.from(new Uint8Array(data)))).buffer}})")
  page.evaluate('(mode)=>demoMode=mode',mode)
  if not profile:page.evaluate("document.getElementById('profileArea').remove()")
  page.evaluate((R/'COMARCH_MAIL_ASSISTENT.js').read_text())
  page.evaluate("async raw=>{const m=JSON.parse(raw);const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(m.payload)));m.payloadSha256=Array.from(new Uint8Array(digest),x=>x.toString(16).padStart(2,'0')).join('');await MCR_MAIL.loadMapText(JSON.stringify(m));}",json.dumps(snapshot or new))
  root=page.locator('#__mcr_mail_assistant_v3')
  root.get_by_label('Diese Bestandsversion',exact=False).check()
  subject='Fwd: Anfrage / Max Mustermann, 99900001' if has_id else 'Anfrage zum Bestand'
  page.evaluate("subject=>MCR_MAIL.setMail({format:'MANUAL',subject,senderName:'Max Mustermann',senderEmail:'',body:'Mit freundlichen Grüßen\\nMax Mustermann',warnings:[]})",subject)
  if approve:root.get_by_label('Mail gehört zu diesem Ticket',exact=False).check()
  return root
 def start(root):root.get_by_role('button',name='Member suchen',exact=True).click()
 def ready():page.wait_for_function('MCR_MAIL.diagnostic().flow.lookupReady',timeout=10000)
 def status():return page.evaluate('MCR_MAIL.diagnostic()')
 def noclick():assert page.evaluate('demoClicks')==0
 def controls():assert page.evaluate('[demoSends,demoSaves,demoOutside]')==[0,0,0]
 if GROUP in (0,1):
  root=reset();assert root.locator('#expectedClientId').input_value()=='99900001';start(root);ready()
  assert page.evaluate('demoClicks')==1 and status()['flow']['selectionMode']=='ICE_SINGLE_ID'
  assert status()['flow']['selectionCommitted']
  assert 'USC 10/ PP+' in root.locator('.result').inner_text()
  assert 'leer → kein Kürzel' in root.locator('.step').nth(3).inner_text()
  mark('Bound ICE interface + reviewed name/ID: one real entry click, profile commit then sparse-flag lookup')
  assert page.locator('[id="mainForm:member-value-id_idx"]').count()==0 # hidden is name-only, untouched
  assert page.locator('[name="mainForm:member-value-id_idx"]').input_value()==''
  controls();assert page.locator('[id="mainForm:j_id7019"]').input_value()==''
  mark('Selection does not manufacture hidden index and does not write description/send/save by itself')
  page.wait_for_timeout(2100);assert page.evaluate('demoClicks')==1
  mark('No repeat selection after successful member commit')
  root.get_by_role('button',name='Beschreibung in COMARCH einsetzen',exact=True).click()
  assert page.locator('[id="mainForm:j_id7019"]').input_value()=='USC 10/ PP+'
  controls();mark('User-authorized insertion produces exact no-DC description; send/save untouched')
  page.screenshot(path=str(R/'docs/BLANKSELECT_RESULT_PREVIEW.png'),full_page=True)
  diag=bytes(page.evaluate('async()=>Array.from(await MCR_MAIL.diagnosticBytes())'))
  with zipfile.ZipFile(io.BytesIO(diag)) as z:
   assert z.testzip() is None
   for line in z.read('SHA256SUMS.txt').decode().splitlines():h,n=line.split('  ');assert hashlib.sha256(z.read(n)).hexdigest()==h
   data=z.read('diagnostic.json').decode()
   for f in ['99900001','90000001','Mustermann','Max','sourceRow','USC 10/ PP+','1970-01-01','http','mainForm']:assert f not in data,f
   assert 'ICE_SINGLE_ID' in data and P in data
  mark('Safe diagnostic ZIP hashes verify; adapter enums present but no names/person IDs/source values')
  root=reset('many');start(root);page.wait_for_timeout(2600);noclick()
  assert status()['widget']['ice']['state']=='MULTIPLE_RENDERED'
  mark('Two delivered people always wait for user, even when reviewed ID matches one')
  page.locator('[id="mainForm:member-value-id_div"] .candidate').first.click();ready()
  assert page.evaluate('demoClicks')==1 and status()['flow']['selectionMode']=='USER_CLICK'
  controls();mark('Trusted manual choice from many automatically resumes after profile commit')
  root=reset('hiddenMany');start(root);page.wait_for_timeout(2600);noclick();assert status()['widget']['ice']['state']=='HIDDEN_ENTRY'
  mark('Hidden second entry is counted, not silently reduced to a single result')
  root=reset('one',has_id=False);start(root);page.wait_for_timeout(2600);noclick()
  assert status()['widget']['ice']['state']=='REVIEWED_ID_REQUIRED'
  mark('ICE rendered-count alone is not identity authority: missing reviewed MercerID prevents auto choice')
  page.locator('[id="mainForm:member-value-id_div"] .candidate').first.click();ready();controls()
  mark('Without mail ID, user choice still works and uses selected Member ID only')
  root=reset('one',profile=False);start(root);page.wait_for_timeout(2600);noclick()
  assert status()['widget']['ice']['state']=='COMMIT_PROFILE_REQUIRED'
  mark('Auto ICE choice requires readable profile label for later commit verification')
 if GROUP in (0,2):
  root=reset('busy');start(root);page.wait_for_timeout(2600);noclick();assert status()['widget']['ice']['state']=='BUSY'
  page.evaluate('testAC.inTransit=false');ready();assert page.evaluate('demoClicks')==1
  mark('Busy AJAX state blocks selection; ready stable result can then be selected once')
  root=reset('one');page.evaluate('testAC.element=document.createElement("input")');start(root);page.wait_for_timeout(2600);noclick()
  assert status()['widget']['ice']['state']=='BINDING_MISMATCH'
  mark('Stale widget instance bound to a different field is rejected')
  root=reset('one');page.evaluate('delete window.Ice');start(root);page.wait_for_timeout(2600);noclick()
  assert status()['widget']['ice']['state']=='REGISTRY_UNAVAILABLE'
  root.get_by_role('button',name='Auswahlliste prüfen',exact=True).click()
  assert 'REGISTRY_UNAVAILABLE' in root.locator('.step').nth(2).inner_text()
  controls();mark('Unknown legacy registry gives actionable safe inspection instead of blind document-wide click')
  for mode in ['wrongId','wrongName']:
   root=reset(mode);start(root);page.wait_for_timeout(2600);noclick();controls();mark('Exact reviewed identity mismatch blocks auto '+mode)
 if GROUP in (0,3):
  root=reset('neverCommit');start(root)
  page.wait_for_function('window.demoClicks===1');page.wait_for_timeout(2300)
  assert not status()['flow']['lookupAttempted'];assert status()['flow']['lastSelectionState']=='WAITING_FOR_COMMIT'
  root.get_by_role('button',name='Meine Member-Auswahl bestätigen',exact=False).click()
  assert status()['lastError']=='MEMBER_COMMIT_PENDING';assert page.evaluate('demoClicks')==1;controls()
  mark('Text copied into member input is not enough: absent server/profile commit blocks lookup and no repeat click')
  root=reset('facet');start(root);ready();assert page.evaluate('demoClicks')==1
  mark('Legacy informal visible facet plus hidden canonical label handled without duplicate-text identity failure')
  root=reset('one');start(root);page.wait_for_timeout(600);page.evaluate("demoMode='many';renderIce()")
  page.wait_for_timeout(2400);noclick();mark('Late second suggestion invalidates pending single-entry stability before click')
  blocked=copy.deepcopy(base);blocked['payload']['entries'].pop('99900001');blocked['payload']['blocked']['99900001']={'sourceRows':[17],'codes':['FLAG_INVALID'],'issues':[{'code':'FLAG_INVALID','column':'C','state':'EMPTY'}]}
  root=reset('one',snapshot=blocked);start(root);page.wait_for_function("MCR_MAIL.diagnostic().lastError==='ID_BLOCKED'")
  assert page.evaluate('demoClicks')==1 and status()['flow']['selectionCommitted']
  assert status()['flow']['lookupAttempted'] and not status()['flow']['lookupReady']
  assert 'NEUE JSON' in root.locator('.step').nth(3).inner_text()
  controls();mark('Old blocked mapping does not prevent member selection; then instructs regeneration, never bypasses blocked values')
 if GROUP in (0,4):
  root=reset('one',approve=False)
  root.get_by_role('button',name='Member suchen',exact=True).click();noclick();assert status()['lastError']=='MAIL_REVIEW'
  mark('No search or choice without explicit current-mail/name/ID review')
  root=reset('one');start(root);ready();page.evaluate("document.getElementById('mainForm:member-value-id').value='Mustermann Max (INTL01-99900002)'")
  page.wait_for_function("MCR_MAIL.diagnostic().lastError==='MEMBER_CHANGED'");assert not status()['flow']['lookupReady']
  mark('Changing member after lookup invalidates result before description can be copied or inserted')
  root=reset('one');start(root);ready();root.get_by_role('button',name='Neuer Fall',exact=True).click();assert not status()['mail']['plainText'] and not status()['flow']['lookupReady'];controls()
  mark('New case clears mail, member proof and result but retains loaded mapping')
 b.close()
(R/('docs/BLANKSELECT_BROWSER_GROUP_'+str(GROUP)+'.json')).write_text(json.dumps({'environment':'Linux Chromium; injected about:blank DOM, minimal ICEfaces-compatible interface double, test-only SHA256 bridge; no Windows/actual COMARCH/real account or workbook validation','tests':results},ensure_ascii=False,indent=2)+'\n')
print('TOTAL',len(results),'PASS',flush=True)
