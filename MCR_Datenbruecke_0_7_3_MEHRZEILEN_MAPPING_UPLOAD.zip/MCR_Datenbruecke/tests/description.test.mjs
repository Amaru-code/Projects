import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import vm from 'node:vm';
import Desc from '../lib/description-field.cjs';
const root=new URL('../',import.meta.url),read=p=>fs.readFileSync(new URL(p,root),'utf8');
for(const [v,expected] of [['Zusätzliche Beschreibung:',true],[' Zusaetzliche Beschreibung ',true],['Zusätzliche\u00a0Beschreibung :',true],['Zusa\u0308tzliche Beschreibung',true],['Kommentar',false],['Beschreibung',false],['Nachricht: Zusätzliche Beschreibung',false],['Zusätzliche Beschreibung und Kommentar',false]])test('description label: '+v,()=>assert.equal(Desc.isLabel(v),expected));
test('description module and UI bundled exactly; bundle is parsable',()=>{const bundle=read('COMARCH_MAIL_ASSISTENT.js');assert.ok(bundle.includes(read('lib/description-field.cjs')));assert.ok(bundle.includes(read('browser/mail-ui.js')));new vm.Script(bundle);});
test('description resolver has no observed j_id, URLs or forced focus/submit',()=>{const s=read('lib/description-field.cjs');assert.ok(!/j_id7019|\bfetch\s*\(|XMLHttpRequest|\.submit\s*\(|\.requestSubmit\s*\(|\.click\s*\(|\.focus\s*\(|\.blur\s*\(|sessionStorage|localStorage|eval\s*\(/.test(s));});
function fixture(){
 const form={},doc={};class Area{set value(v){this.text=v;this.writes++;}get value(){return this.text;}}
 doc.defaultView={HTMLTextAreaElement:Area,Event:class {constructor(type,opts){this.type=type;Object.assign(this,opts);}},getComputedStyle:()=>({visibility:'visible',display:'block'})};
 const member={tagName:'INPUT',id:'mainForm:member-value-id',ownerDocument:doc,form},f=new Area();
 Object.assign(f,{text:'',writes:0,events:[],tagName:'TEXTAREA',isConnected:true,ownerDocument:doc,form,maxLength:-1,getRootNode:()=>doc,getClientRects:()=>[{}],closest:()=>null,getAttribute:()=>null,matches:()=>false,dispatchEvent(e){this.events.push(e.type);return true;}});
 return {member,f};
}
test('one native write emits input/change, each followed by identity guard',()=>{const {member,f}=fixture();let guards=0;const r=Desc.writeOnce(member,f,'USC 20/ PP+',()=>guards++);assert.deepEqual(r,{changed:true,events:2});assert.equal(f.writes,1);assert.deepEqual(f.events,['input','change']);assert.equal(guards,3);});
test('same value is idempotent without extra events',()=>{const {member,f}=fixture();f.text='USC 20/ PP+';assert.equal(Desc.writeOnce(member,f,f.text,()=>{}).changed,false);assert.equal(f.writes,0);assert.equal(f.events.length,0);});
test('conflicting existing text is not overwritten',()=>{const {member,f}=fixture();f.text='vorhandener Kommentar';assert.throws(()=>Desc.writeOnce(member,f,'USC 20/ PP+',()=>{}),e=>e.code==='DESCRIPTION_EXISTS');assert.equal(f.writes,0);});
test('length limit fails without truncating',()=>{const {member,f}=fixture();f.maxLength=3;assert.throws(()=>Desc.writeOnce(member,f,'USC 20/ PP+',()=>{}),e=>e.code==='DESCRIPTION_TOO_LONG');assert.equal(f.writes,0);});
for(const kind of ['disabled','readOnly'])test(kind+' prevents write',()=>{const {member,f}=fixture();f[kind]=true;assert.throws(()=>Desc.writeOnce(member,f,'USC 20/ PP+',()=>{}),e=>e.code==='DESCRIPTION_READONLY');assert.equal(f.writes,0);});
test('foreign form is never a target',()=>{const {member,f}=fixture();f.form={};assert.throws(()=>Desc.writeOnce(member,f,'USC 20/ PP+',()=>{}),e=>e.code==='DESCRIPTION_STALE');assert.equal(f.writes,0);});
test('disconnected original is rejected',()=>{const {member,f}=fixture();f.isConnected=false;assert.throws(()=>Desc.writeOnce(member,f,'USC 20/ PP+',()=>{}),e=>e.code==='DESCRIPTION_STALE');assert.equal(f.writes,0);});
test('input handler rewriting text prevents change event and retry',()=>{const {member,f}=fixture();f.dispatchEvent=e=>{f.events.push(e.type);f.text='changed by app';return true;};assert.throws(()=>Desc.writeOnce(member,f,'USC 20/ PP+',()=>{}),e=>e.code==='DESCRIPTION_VERIFY');assert.equal(f.writes,1);assert.deepEqual(f.events,['input']);});
test('input handler removing field prevents next event',()=>{const {member,f}=fixture();f.dispatchEvent=e=>{f.events.push(e.type);f.isConnected=false;return true;};assert.throws(()=>Desc.writeOnce(member,f,'USC 20/ PP+',()=>{}),e=>e.code==='DESCRIPTION_VERIFY');assert.equal(f.writes,1);assert.deepEqual(f.events,['input']);});
test('guard failing before assignment makes no write',()=>{const {member,f}=fixture();assert.throws(()=>Desc.writeOnce(member,f,'USC 20/ PP+',()=>{throw new Error('ticket changed');}));assert.equal(f.writes,0);});
test('guard failing after input blocks change event',()=>{const {member,f}=fixture();let calls=0;assert.throws(()=>Desc.writeOnce(member,f,'USC 20/ PP+',()=>{if(++calls>1)throw new Error('member changed');}));assert.deepEqual(f.events,['input']);});
test('no guard is refused',()=>{const {member,f}=fixture();assert.throws(()=>Desc.writeOnce(member,f,'USC 20/ PP+'),e=>e.code==='DESCRIPTION_GUARD');assert.equal(f.writes,0);});
test('Windows self-test includes description tests',()=>assert.ok(read('RUN.cmd').includes('tests\\description.test.mjs')));
