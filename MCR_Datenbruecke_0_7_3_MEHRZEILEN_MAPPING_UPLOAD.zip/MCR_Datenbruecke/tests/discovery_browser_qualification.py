"""0.3.3 integration checks on about:blank with a SHA256-only test bridge.
Loopback navigation is blocked by this runtime browser policy; policy is unchanged.
Only the synthetic test page receives the bridge; shipping code is not relaxed.
No real COMARCH, Outlook, corporate network, Windows or customer files used.
Fixtures model old/new registry keys, a popup under a different ID, and registry-
free local/portal DOM lists. This is not a production-library compatibility test.
"""
from pathlib import Path
import json,hashlib,threading,io,zipfile,time
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1]
RESULT=R/'docs/DISCOVERY_BROWSER_RESULT.json'
results=[]
HTML='''<!doctype html><html lang="de"><meta charset="utf-8"><style>
body{font:16px Arial;margin:28px;color:#1b3447;background:#f6f8fa}form{width:670px;padding:18px;background:white}label{display:block;margin-top:12px}input{width:570px;padding:7px}textarea{width:600px;height:100px}.iceSelInpTxtList{background:#e9f3f8;border:1px solid #abc}.candidate{padding:10px;cursor:pointer;border-bottom:1px solid #ccd}button{padding:8px}#profileArea{margin:20px 0}</style>
<h1>Fiktiver Auswahltest · MCR 0.3.3</h1><p>Kein COMARCH. Keine E-Mails. Nur Testdaten.</p>
<form onsubmit="return false"><p><b>Ticket-ID:</b> <span id="ticket">90000001</span></p>
<label for="mainForm:member-value-id">Member</label><div id="componentWrapper">
<input id="mainForm:member-value-id" autocomplete="off"><div id="actualPopup" class="iceSelInpTxtList" style="display:none"><div></div></div></div>
<div id="profileArea"><span>MercerID:</span> <strong id="profile"></strong></div>
<label for="mainForm:j_id7019">Zusätzliche Beschreibung:</label><textarea id="mainForm:j_id7019"></textarea>
<button type="button" id="send">Senden</button><button type="button" id="save">Ticket speichern</button></form>
<div id="unrelated">Mustermann Max (INTL01-99900001)</div></html>'''
JS='''(()=>{
window.mode='alias';window.countMode='one';window.clicks=0;window.sends=0;window.saves=0;
window.clickModes=[];window.changes=0;window.inputs=0;window.keyups=0;window.lastKey=null;
window.f=document.getElementById('mainForm:member-value-id');window.popup=document.getElementById('actualPopup');
const ac={element:f,update:popup,entryCount:0,getEntry(i){return popup.firstElementChild.children[i];},active:false,inTransit:false,changed:false,hasFocus:false};window.ac=ac;
const finder={list:{componentInstanceKey:ac},find(id){return this.list[id];}};
window.Ice={Scriptaculous:{Autocompleter:{Finder:finder}}};
window.configureMode=(m)=>{mode=m;if(m==='direct')finder.find=id=>id===f.id?ac:null;
 if(m==='absent'||m==='portal'||m==='neverCommit'){finder.list={};finder.find=()=>null;}
 if(m==='monitor'){finder.list={};Ice.StateMon={monitors:[{type:'Autocompleter',object:ac}]};}
 if(m==='portal')document.body.append(popup);
 if(m==='ambiguous')finder.list.second={...ac};
};
window.renderChoices=()=>{
 const wrap=popup.firstElementChild;wrap.replaceChildren();
 if(!f.value.trim()||f.value.includes('INTL01-')){popup.style.display='none';ac.active=false;return;}
 popup.style.display='block';ac.active=true;ac.changed=false;ac.hasFocus=true;ac.inTransit=countMode==='busy';
 ac.entryCount=['many','hiddenMany'].includes(countMode)?2:1;
 for(let i=0;i<ac.entryCount;i++){
  const n=document.createElement('div');n.className='candidate';n.autocompleteIndex=i;
  const id=countMode==='wrongId'?'99900002':'9990000'+(i+1);
  n.textContent=(countMode==='wrongName'?'Andermann Anna':'Mustermann Max')+' (INTL01-'+id+') - 1970-01-01';
  if(countMode==='hiddenMany'&&i===1)n.style.display='none';
  n.addEventListener('click',e=>{
   clicks++;clickModes.push(e.isTrusted);f.value='Mustermann Max (INTL01-'+id+')';popup.style.display='none';ac.active=false;ac.inTransit=true;
   if(mode!=='neverCommit')setTimeout(()=>{document.getElementById('profile').textContent='INTL01-'+id;ac.inTransit=false;},250);
  });wrap.append(n);
 }
};
f.addEventListener('input',()=>{inputs++;});
f.addEventListener('change',()=>{changes++;});
f.addEventListener('keyup',e=>{keyups++;lastKey={key:e.key,keyCode:e.keyCode};renderChoices();});
document.getElementById('send').onclick=()=>sends++;document.getElementById('save').onclick=()=>saves++;
})();'''
base=json.loads((R/'examples/DEMO_mapping.json').read_text())
# Deliberately keep an existing 0.3.2-compatible snapshot: no re-export is needed.
base['payload']['flagPolicy']='ONE_ONLY_BLANK_OMIT_V1'
for entry in base['payload']['entries'].values():entry.update(flagPolicy='ONE_ONLY_BLANK_OMIT_V1',blankColumns=[])
base['payload']['entries']['99900001'].update(dc=None,blankColumns=['C'])
def mark(name):
 results.append({'name':name,'status':'PASS'});print('PASS',name,flush=True)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True)
 page=b.new_page(viewport={'width':1600,'height':1150});page.set_default_timeout(10000)
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.expose_function('__testSha',lambda data:list(hashlib.sha256(bytes(data)).digest()))
 def reset(mode='alias',expected=True):
  page.evaluate('window.MCR_MAIL?.close()')
  page.set_content(HTML)
  page.evaluate("Object.defineProperty(crypto,'subtle',{configurable:true,value:{digest:async(_,data)=>new Uint8Array(await __testSha(Array.from(new Uint8Array(data)))).buffer}})")
  page.evaluate(JS);page.evaluate('configureMode',mode)
  page.evaluate((R/'COMARCH_MAIL_ASSISTENT.js').read_text())
  assert page.evaluate('!!crypto.subtle')
  page.evaluate('''async raw=>{const m=JSON.parse(raw);const hash=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(m.payload)));m.payloadSha256=Array.from(new Uint8Array(hash),x=>x.toString(16).padStart(2,'0')).join('');await MCR_MAIL.loadMapText(JSON.stringify(m));}''',json.dumps(base))
  root=page.locator('#__mcr_mail_assistant_v3');root.get_by_label('Diese Bestandsversion',exact=False).check()
  setmail(root,expected)
  return root
 def setmail(root,expected=True):
  page.evaluate('''yes=>MCR_MAIL.setMail({format:'MANUAL',subject:yes?'Fwd: Frage / Max Mustermann, 99900001':'Frage',senderName:'Max Mustermann',senderEmail:'',body:'Mit freundlichen Grüßen\\nMax Mustermann',warnings:[]})''',expected)
  root.get_by_label('Mail gehört zu diesem Ticket',exact=False).check()
 def start(root):root.get_by_role('button',name='Member suchen',exact=True).click()
 def diag():return page.evaluate('MCR_MAIL.diagnostic()')
 def ready():page.wait_for_function('MCR_MAIL.diagnostic().flow.lookupReady',polling=100)
 def zeros():assert page.evaluate('[sends,saves]')==[0,0]
 def noclick():assert page.evaluate('clicks')==0
 def choose():page.locator('#actualPopup .candidate').first.click()
 def delay():page.wait_for_timeout(2600)
 root=reset();start(root);ready();assert page.evaluate('clicks')==1
 assert diag()['widget']['ice']['bindingRoute']=='REGISTRY_FIELD_IDENTITY'
 assert diag()['flow']['selectionMode']=='ICE_SINGLE_ID'
 mark('Alternate registry key + real popup ID: exactly one click, committed profile, lookup ready')
 assert page.evaluate('[inputs,changes,keyups]')==[1,0,1]
 assert page.evaluate('lastKey.keyCode')>0 and page.evaluate('lastKey.key')!='Unidentified'
 mark('Search sends input then real-character keyup; no early change/blur/Enter')
 assert 'USC 10/ PP+' in root.locator('.result').inner_text();assert 'leer → kein Kürzel' in root.locator('.step').nth(3).inner_text()
 mark('Existing sparse-flag mapping consumed unchanged; source C remains null and DC omitted')
 zeros();assert page.locator('[id="mainForm:j_id7019"]').input_value()==''
 mark('Automatic selection does not write description or send/save a ticket')
 root.get_by_role('button',name='Beschreibung in COMARCH einsetzen',exact=True).click()
 assert page.locator('[id="mainForm:j_id7019"]').input_value()=='USC 10/ PP+';zeros()
 page.screenshot(path=str(R/'docs/DISCOVERY_READY_PREVIEW.png'),full_page=True)
 mark('Explicit description insertion produces correct output and no send/save')
 raw=bytes(page.evaluate('async()=>Array.from(await MCR_MAIL.diagnosticBytes())'))
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  assert z.testzip() is None
  for line in z.read('SHA256SUMS.txt').decode().splitlines():h,n=line.split('  ');assert hashlib.sha256(z.read(n)).hexdigest()==h
  text=z.read('diagnostic.json').decode()
  for forbidden in ['99900001','90000001','Mustermann','Max','actualPopup','componentInstanceKey','mainForm','http','USC 10/ PP+']:assert forbidden not in text,forbidden
 mark('Diagnostic zip checksums valid; no names, IDs, DOM IDs, source values or addresses')
 for mode,route in [('direct','REGISTRY_FIELD_IDENTITY'),('monitor','MONITOR_FIELD_IDENTITY')]:
  root=reset(mode);start(root);ready();assert diag()['widget']['ice']['bindingRoute']==route;zeros();mark('Discovery route '+mode+' works without fixed popup suffix')
 for mode in ['absent','portal']:
  root=reset(mode);start(root);delay();noclick()
  assert diag()['widget']['ice']['state']=='REGISTRY_UNAVAILABLE'
  mark(mode+': unknown registry does not cause a blind auto-selection')
  choose();ready();assert diag()['flow']['selectionMode']=='USER_CLICK' and diag()['widget']['learnedList']
  assert len(diag()['widget']['choiceStructure'])>0;zeros()
  mark(mode+': one genuine choice resumes lookup and learns only after matching profile commit')
  page.evaluate("MCR_MAIL.resetCase();f.value='';document.getElementById('profile').textContent='';clicks=0")
  setmail(root);start(root);ready()
  assert diag()['flow']['selectionMode']=='LEARNED_DOM_ID' and page.evaluate('clicks')==1;zeros()
  mark(mode+': later search reuses observed list with exact reviewed name/ID and one click')
 # Early confirmation used to kill the waiting workflow.
 root=reset('absent');start(root);root.get_by_role('button',name='Meine Member-Auswahl bestätigen',exact=False).click()
 assert diag()['flow']['waiting'] and diag()['lastError']=='MEMBER_NOT_SELECTED';noclick()
 choose();ready();assert diag()['flow']['selectionCommitted'];zeros()
 mark('Early Continue remains pending rather than stopping; subsequent real click completes lookup')
 root=reset('absent');start(root);choose();ready()
 page.evaluate("MCR_MAIL.resetCase();f.value='';document.getElementById('profile').textContent='';clicks=0;countMode='many'")
 setmail(root);start(root);delay();noclick()
 assert diag()['widget']['localList']['state']=='MULTIPLE_RENDERED';choose();ready();zeros()
 mark('Learned list still waits for user when multiple people are returned')
 # Registry and learned routes cannot ignore hidden duplicate rows.
 root=reset();page.evaluate("countMode='hiddenMany'");start(root);delay();noclick();assert diag()['widget']['ice']['state']=='HIDDEN_ENTRY';zeros()
 mark('Registry counts hidden additional rows rather than falsely declaring uniqueness')
 root=reset('absent');start(root);choose();ready()
 page.evaluate("MCR_MAIL.resetCase();f.value='';document.getElementById('profile').textContent='';clicks=0;countMode='hiddenMany'")
 setmail(root);start(root);delay();noclick();assert diag()['widget']['localList']['state']=='HIDDEN_ENTRY'
 mark('Learned DOM list also counts hidden additional rows')
 for mode in ['wrongId','wrongName']:
  root=reset();page.evaluate('m=>countMode=m',mode);start(root);delay();noclick();zeros();mark('Identity mismatch never auto-selected: '+mode)
 root=reset(expected=False);start(root);delay();noclick();assert diag()['widget']['ice']['state']=='REVIEWED_ID_REQUIRED'
 choose();ready();zeros();mark('Missing reviewed mail ID prevents automatic legacy selection; manual choice still works')
 root=reset();page.evaluate("countMode='many'");start(root);delay();noclick();choose();ready();zeros()
 mark('Multiple registry entries always require a real user choice')
 root=reset('ambiguous');start(root);delay();noclick();assert diag()['widget']['ice']['state']=='AMBIGUOUS_REGISTRY';zeros()
 mark('Conflicting instances are rejected, not resolved by a fallback guess')
 root=reset();page.evaluate("countMode='busy'");start(root);delay();noclick();page.evaluate('ac.inTransit=false');ready();zeros()
 mark('Pending component AJAX blocks click; stable ready result resumes once')
 root=reset('neverCommit');start(root);choose();delay();assert not diag()['flow']['lookupAttempted'] and not diag()['widget']['learnedList'];zeros()
 mark('Manual click without populated profile neither performs lookup nor learns a route')
 root=reset();start(root);page.wait_for_timeout(500);page.evaluate("countMode='many';renderChoices()");delay();noclick();zeros()
 mark('Late second suggestion cancels pending one-result click')
 root=reset('absent');start(root);choose();ready()
 page.evaluate("MCR_MAIL.resetCase();f.value='';document.getElementById('profile').textContent='';clicks=0")
 setmail(root);start(root);page.wait_for_timeout(400);page.evaluate("document.getElementById('ticket').textContent='90000002'")
 delay();noclick();assert diag()['lastError']=='TICKET_CHANGED';zeros()
 mark('Changed ticket context prevents reuse or click after learning')
 root=reset('absent');start(root);choose();ready()
 page.evaluate("MCR_MAIL.resetCase();f.value='';document.getElementById('profile').textContent='';clicks=0")
 setmail(root);start(root);page.wait_for_timeout(350);page.evaluate("popup.id='otherPopup'")
 delay();noclick();zeros();assert diag()['widget']['localList']['state']=='LEARNED_BINDING_CHANGED'
 mark('Learned popup ID replacement invalidates route instead of selecting similarly looking text')
 root=reset('absent');start(root);choose();ready()
 page.evaluate("MCR_MAIL.resetCase();f.value='';document.getElementById('profile').textContent='';clicks=0")
 setmail(root);start(root);page.evaluate("const footer=document.createElement('div');footer.textContent='Weitere Treffer werden geladen';popup.firstElementChild.append(footer)")
 delay();noclick();zeros();assert diag()['widget']['localList']['state']=='ROWS_UNQUALIFIED'
 mark('Unknown footer/loading row is not discarded to manufacture a single learned result')
 root=reset('absent');start(root);choose();ready()
 page.evaluate("MCR_MAIL.resetCase();f.value='';document.getElementById('profile').textContent='';clicks=0")
 setmail(root);start(root);page.evaluate("popup.setAttribute('aria-busy','true')")
 delay();noclick();zeros();assert diag()['widget']['localList']['state'] in ['ROWS_UNQUALIFIED','BUSY']
 mark('Explicit busy DOM list cannot be auto-selected through a learned route')
 root=reset('absent');start(root);delay()
 page.screenshot(path=str(R/'docs/DISCOVERY_WAIT_PREVIEW.png'),full_page=True)
 page.evaluate('MCR_MAIL.close()');page.evaluate("f.value='Mustermann Max';renderChoices()")
 delay();noclick();zeros();assert page.locator('#__mcr_mail_assistant_v3').count()==0
 mark('Close removes timers/listeners and no delayed selection is executed')
 assert not errors,errors
 mark('No browser page exceptions across the qualification suite')
 b.close()
RESULT.write_text(json.dumps({'version':'0.3.3','environment':'Linux / Chromium / about:blank; SHA256-only Python test bridge; synthetic DOM and registry doubles','realComarchTested':False,'windowsTested':False,'count':len(results),'results':results},indent=2)+'\n')
print('TOTAL',len(results),'PASS',flush=True)
