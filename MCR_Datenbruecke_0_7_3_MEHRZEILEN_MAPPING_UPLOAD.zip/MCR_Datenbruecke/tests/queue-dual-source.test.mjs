import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const src=fs.readFileSync(path.join(root,'src','local-bot-queue-send.mjs'),'utf8');
test('runner supports both observed COMARCH queue table ids',()=>{
  assert.match(src,/mainForm:tasksTableFor_MyTasksList/);
  assert.match(src,/mainForm:tasksTableFor_MyQueuesTasksList/);
  assert.match(src,/WARTESCHLANGE_INTL01/);
  assert.match(src,/IN_BEARBEITUNG/);
});
test('runner keeps numeric ticket and blank-description guards',()=>{
  assert.match(src,/\^\\d\{6,12\}\$/);
  assert.match(src,/descriptionBlank:desc===''/);
  assert.match(src,/r\.source\.toUpperCase\(\)==='E-MAIL'/);
});
