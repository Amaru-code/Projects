/** Regression for 0.2.2. All workbooks and IDs here are synthetic fixtures. */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import vm from 'node:vm';
import {fileURLToPath} from 'node:url';
import {spawn} from 'node:child_process';
import Core from '../lib/data-core.cjs';
import {readWorkbook,readWorkbookBuffer} from '../lib/xlsx.mjs';
import {readZip,writeZip} from '../lib/zip.mjs';
import {makeMapping,exportMapping} from '../src/mapping.mjs';
import {makeDescription,buildPlan,sha256} from '../lib/core.mjs';
const root=fileURLToPath(new URL('../',import.meta.url));
const original=fs.readFileSync(path.join(root,'examples','DEMO_Datenbestand.xlsx'));
const archive=readZip(original);
const xmlEscape=s=>s.replaceAll('&','&amp;').replaceAll('"','&quot;').replaceAll('<','&lt;').replaceAll('\n','&#10;').replaceAll('\r','&#13;').replaceAll('\t','&#9;');
function patched(patches={}){
 return writeZip(archive.names.map(name=>({name,data:patches[name]?patches[name](archive.get(name).toString('utf8')):archive.get(name)})));
}
function named(name,extra={}){
 return patched({...extra,'xl/workbook.xml':xml=>{const renamed=xml.replace('name="Output"',`name="${xmlEscape(name)}"`);return extra['xl/workbook.xml']?extra['xl/workbook.xml'](renamed):renamed;}});
}
const code=expected=>err=>err.code===expected;
const read=name=>readWorkbookBuffer(named(name),'FIKTIV.xlsx');
for(const name of ['Output','output','OUTPUT','oUtPuT',' Output','Output ','\u00a0OUTPUT\u00a0','\tOutput\r\n']) {
 test(`Sheetfix: ${JSON.stringify(name)} uniquely resolves without changing data`,()=>{
  const book=read(name);
  assert.equal(book.meta.sheet,name);
  assert.equal(book.meta.logicalSheet,'Output');
  assert.equal(book.meta.sheetMatch,name==='Output'?'EXACT':'CASE_OR_OUTER_SPACE');
  assert.equal(book.meta.headerRow,2);
  assert.equal(makeDescription(book.lookup('99900001')),'USC 10/ PP+');
  assert.deepEqual(book.allRows(),readWorkbookBuffer(original).allRows());
 });
}
for(const name of ['Output 2025','Output(2)','Out put','Out_put','Bestand','\u200bOutput']) {
 test(`Sheetfix: no fuzzy fallback for ${JSON.stringify(name)}`,()=>{
  assert.throws(()=>read(name),err=>err.code==='SHEET'&&err.message.includes(JSON.stringify(name)));
 });
}
test('Sheetfix: exact Output does not override a second normalized candidate',()=>{
 const bytes=patched({'xl/workbook.xml':x=>x.replace(/<\/(?:x:)?sheets>/,m=>'<x:sheet name="output" sheetId="3" r:id="fake"/>'+m)});
 assert.throws(()=>readWorkbookBuffer(bytes),err=>err.code==='SHEET'&&err.message.includes('Mehrere'));
});
test('Sheetfix: colliding outer-space names are ambiguous',()=>{
 const bytes=named('output',{'xl/workbook.xml':x=>x.replace(/<\/(?:x:)?sheets>/,m=>'<x:sheet name=" Output " sheetId="3" r:id="fake"/>'+m)});
 assert.throws(()=>readWorkbookBuffer(bytes),code('SHEET'));
});
test('Sheetfix: no duplicate exact sheet name is silently selected',()=>{
 const bytes=patched({'xl/workbook.xml':x=>x.replace(/<\/(?:x:)?sheets>/,m=>'<x:sheet name="Output" sheetId="3" r:id="fake"/>'+m)});
 assert.throws(()=>readWorkbookBuffer(bytes),code('SHEET'));
});
test('Sheetfix: unrelated first sheet is not used',()=>{
 const bytes=patched({'xl/workbook.xml':x=>x.replace(/<(?:x:)?sheets>/,m=>m+'<x:sheet name="Readme" sheetId="9" r:id="missing"/>')});
 const book=readWorkbookBuffer(bytes);
 assert.equal(book.meta.sheet,'Output');
 assert.equal(makeDescription(book.lookup('99900001')),'USC 10/ PP+');
});
test('Sheetfix: no sheets yields a diagnostic, not a random worksheet',()=>{
 const bytes=patched({'xl/workbook.xml':x=>x.replace(/<(?:x:)?sheets>[\s\S]*?<\/(?:x:)?sheets>/,'<x:sheets/>')});
 assert.throws(()=>readWorkbookBuffer(bytes),err=>err.code==='SHEET'&&err.message.includes('keine Blattnamen'));
});
test('Sheetfix: prefixed OOXML sheet nodes are recognized',()=>{
 const bytes=patched({'xl/workbook.xml':x=>x.replaceAll('x:','z:').replaceAll('xmlns:x=','xmlns:z=')});
 assert.equal(readWorkbookBuffer(bytes).meta.sheet,'Output');
});
for(const state of ['hidden','veryHidden'])test(`Sheetfix: ${state} Output is not silently used`,()=>{
 const bytes=patched({'xl/workbook.xml':x=>x.replace('name="Output"',`name="Output" state="${state}"`)});
 assert.throws(()=>readWorkbookBuffer(bytes),code('SHEET_HIDDEN'));
});
test('Sheetfix: observer receives only index, name and state',()=>{
 let call;
 readWorkbookBuffer(named('output'),'FIKTIV.xlsx',{onSheets:s=>{call=s;}});
 assert.deepEqual(call,[{index:1,name:'output',state:'visible'},{index:2,name:'Lesehilfe',state:'visible'}]);
 assert.ok(Object.isFrozen(call)&&Object.isFrozen(call[0]));
 assert.throws(()=>{call[0].name='Wrong';});
});
test('Sheetfix: inventory is available before missing-sheet rejection',()=>{
 let call;
 assert.throws(()=>readWorkbookBuffer(named('Bestand'),'FIKTIV.xlsx',{onSheets:s=>{call=s;}}),code('SHEET'));
 assert.equal(call[0].name,'Bestand');
});
test('Sheetfix: C/D/E header validation remains strict for lowercase output',()=>{
 const bytes=patched(Object.fromEntries(archive.names.filter(n=>n.endsWith('.xml')).map(n=>[n,x=>x.replace('name="Output"','name="output"').replaceAll('IsEligible_DC','WRONG_HEADER')])));
 assert.throws(()=>readWorkbookBuffer(bytes),code('HEADER_FLAGS'));
});
test('Sheetfix: external worksheet relationships are still rejected',()=>{
 const bytes=named('output',{'xl/_rels/workbook.xml.rels':x=>x.replace(/(<Relationship\b[^>]*Type="[^"]*\/worksheet")/,'$1 TargetMode="External"')});
 assert.throws(()=>readWorkbookBuffer(bytes),code('SHEET_REL'));
});
test('Sheetfix: map carries actual sheet name and unchanged business rules',()=>{
 const map=makeMapping(read('output'),{headerLConfirmed:true});
 assert.equal(map.payload.source.sheet,'output');
 assert.equal(map.payload.source.logicalSheet,'Output');
 assert.equal(map.payload.source.sheetMatch,'CASE_OR_OUTER_SPACE');
 assert.equal(Core.lookup(map,'99900001').description,'USC 10/ PP+');
 assert.equal(sha256(JSON.stringify(map.payload)),map.payloadSha256);
 assert.doesNotThrow(()=>Core.validateMap(map));
});
test('Sheetfix: old V1 demo mapping still passes',()=>{
 const map=JSON.parse(fs.readFileSync(path.join(root,'examples','DEMO_mapping.json'),'utf8'));
 assert.doesNotThrow(()=>Core.validateMap(map));
});
test('Sheetfix: mapping validator does not accept other sheets',()=>{
 const map=makeMapping(read('output'),{headerLConfirmed:true});
 map.payload.source.sheet='Output 2025';
 assert.throws(()=>Core.validateMap(map),code('MAP_SOURCE'));
});
test('Sheetfix: browser variant of the shared validator accepts actual lowercase sheet name',()=>{
 const ctx=vm.createContext({});
 vm.runInContext(fs.readFileSync(path.join(root,'lib','data-core.cjs'),'utf8'),ctx);
 const map=makeMapping(read('output'),{headerLConfirmed:true});
 assert.equal(ctx.MCRBridgeCore.validateMap(map).source.sheet,'output');
 assert.equal(ctx.MCRBridgeCore.lookup(map,'99900001').description,'USC 10/ PP+');
});
test('Sheetfix: generated console bundle uses the updated shared core',()=>{
 const bundle=fs.readFileSync(path.join(root,'COMARCH_DATENBRUECKE.js'),'utf8');
 assert.ok(bundle.includes(fs.readFileSync(path.join(root,'lib','data-core.cjs'),'utf8')));
 assert.ok(bundle.includes(fs.readFileSync(path.join(root,'browser','ui.js'),'utf8')));
});
test('Sheetfix: legacy plan helper preserves the actual sheet name',()=>{
 const book=read('output');
 const input={sourceConfirmed:true,identityConfirmed:true,recipientConfirmed:true,greetingConfirmed:true,sourceSha:book.meta.sha256,clientId:'99900001',ticketId:'90000001',recipient:'test@example.invalid',lastName:'Beispiel',salutation:'Neutral'};
 assert.equal(buildPlan(input,book.lookup,book.meta).excel.sheet,'output');
});
test('Sheetfix: read and full export leave source bytes unchanged',()=>{
 const temp=fs.mkdtempSync(path.join(os.tmpdir(),'mcr-sheetfix-'));
 try {
  const file=path.join(temp,'FIKTIV.xlsx'),bytes=named('output');fs.writeFileSync(file,bytes);
  const book=readWorkbook(file);
  const r=exportMapping(file,path.join(temp,'out'),{mode:'DEMO',headerLConfirmed:true,expectedSha:book.meta.sha256});
  const map=JSON.parse(fs.readFileSync(r.dest));
  assert.equal(map.payload.source.sheet,'output');
  assert.equal(Core.lookup(map,'99900001').description,'USC 10/ PP+');
  assert.deepEqual(fs.readFileSync(file),bytes);
 }finally{fs.rmSync(temp,{recursive:true,force:true});}
});
test('Sheetfix: source hash binds sheet name changes after review',()=>{
 const temp=fs.mkdtempSync(path.join(os.tmpdir(),'mcr-sheetfix-'));
 try {
  const file=path.join(temp,'FIKTIV.xlsx');fs.writeFileSync(file,named('Output'));
  const book=readWorkbook(file);fs.writeFileSync(file,named('output'));
  assert.throws(()=>exportMapping(file,path.join(temp,'out'),{mode:'DEMO',headerLConfirmed:true,expectedSha:book.meta.sha256}),code('SOURCE_CHANGED'));
  assert.ok(!fs.existsSync(path.join(temp,'out')));
 }finally{fs.rmSync(temp,{recursive:true,force:true});}
});
test('Sheetfix: no mapping is created for wrong-sheet failure',()=>{
 const temp=fs.mkdtempSync(path.join(os.tmpdir(),'mcr-sheetfix-'));
 try {
  const file=path.join(temp,'FIKTIV.xlsx');fs.writeFileSync(file,named('Bestand'));
  assert.throws(()=>exportMapping(file,path.join(temp,'out'),{headerLConfirmed:true}),code('SHEET'));
  assert.ok(!fs.existsSync(path.join(temp,'out')));
 }finally{fs.rmSync(temp,{recursive:true,force:true});}
});
test('Sheetfix: Windows selftest includes this new test file (static)',()=>{
 assert.ok(fs.readFileSync(path.join(root,'RUN.cmd'),'ascii').includes('tests\\sheetfix.test.mjs'));
});
// Real Node CLI test on this host. It is not a CMD/Windows qualification.
test('Sheetfix: CLI shows sheets, accepts a quoted path, confirms and creates lowercase snapshot',async()=>{
 const temp=fs.mkdtempSync(path.join(os.tmpdir(),'mcr-sheetfix-cli-'));
 let written;
 try {
  const file=path.join(temp,'FIKTIV Excel.xlsx');fs.writeFileSync(file,named('output'));
  const result=await new Promise((resolve,reject)=>{
   let out='',err='',sentFile=false,sentConfirm=false;
   const child=spawn(process.execPath,[path.join(root,'src','export-mapping.mjs')],{cwd:root,stdio:['pipe','pipe','pipe']});
   const timeout=setTimeout(()=>{child.kill();reject(new Error('CLI test timeout: '+out));},12000);
   child.stdout.on('data',chunk=>{
    out+=chunk.toString();
    if(!sentFile&&out.includes('bekannte K:-Datei]:')){sentFile=true;child.stdin.write('"'+file+'"\n');}
    if(!sentConfirm&&out.includes('bestaetigt? JA:')){sentConfirm=true;child.stdin.write('JA\n');}
   });
   child.stderr.on('data',chunk=>{err+=chunk.toString();});
   child.on('error',e=>{clearTimeout(timeout);reject(e);});
   child.on('close',status=>{clearTimeout(timeout);resolve({status,out,err});});
  });
  const match=result.out.match(/MAPPING ERZEUGT: (.+)/);written=match?.[1]?.trim();
  assert.equal(result.status,0,result.out+'\n'+result.err);
  assert.ok(result.out.includes('[1] "output"'));
  assert.ok(result.out.includes('Blattzuordnung OK: "output" -> Rolle Output (CASE_OR_OUTER_SPACE).'));
  assert.ok(written);
  assert.equal(JSON.parse(fs.readFileSync(written)).payload.source.sheet,'output');
 }finally{
  if(written){fs.rmSync(written,{force:true});fs.rmSync(written+'.sha256',{force:true});}
  fs.rmSync(temp,{recursive:true,force:true});
 }
});
