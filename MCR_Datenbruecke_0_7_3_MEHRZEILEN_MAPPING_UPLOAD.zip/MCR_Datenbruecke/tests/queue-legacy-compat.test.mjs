import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const src=fs.readFileSync(path.join(root,'src','local-bot-queue-send.mjs'),'utf8');

test('queue page callback avoids HTMLCollection entries iterator',()=>{
  const start=src.indexOf('async function queueTableSnapshot');
  const end=src.indexOf('async function detailTicketId',start);
  const block=src.slice(start,end);
  assert.equal(block.includes('.entries()'),false);
  assert.match(block,/for\(let index=0;index<body\.rows\.length;index\+\+\)/);
});

test('detail ticket id function exists before open verification',()=>{
  assert.match(src,/async function detailTicketId\(page\)/);
  assert.match(src,/return count===1\?last:null/);
});

test('demo exercises exact INTL01 queue table id',()=>{
  assert.match(src,/mainForm:tasksTableFor_MyQueuesTasksList/);
  assert.match(src,/Warteschlange INTL01/);
});
