/* Independent synthetic MS-CFB fixture writer for qualification, never customer data. */
const FREE=0xffffffff,END=0xfffffffe;
export function cfbFixture(streams,{sector=512,nested=null}={}){
 const chunks=[],fatLinks=[],miniBlocks=[],miniLinks=[];const version=sector===512?3:4;
 function put(raw){raw=Buffer.from(raw);if(!raw.length)return END;const start=chunks.length,n=Math.ceil(raw.length/sector);for(let i=0;i<n;i++){const b=Buffer.alloc(sector);raw.copy(b,0,i*sector,(i+1)*sector);chunks.push(b);fatLinks.push(i+1===n?END:start+i+1);}return start;}
 function mini(raw){raw=Buffer.from(raw);if(!raw.length)return END;const start=miniBlocks.length,n=Math.ceil(raw.length/64);for(let i=0;i<n;i++){const b=Buffer.alloc(64);raw.copy(b,0,i*64,(i+1)*64);miniBlocks.push(b);miniLinks.push(i+1===n?END:start+i+1);}return start;}
 const all=Object.entries(streams).map(([name,data])=>({name,data:Buffer.from(data),type:2}));
 if(nested){all.push({name:'__attach_version1.0_#00000000',type:1,data:Buffer.alloc(0),nested:true});all.push({name:nested.name,type:2,data:Buffer.from(nested.data),onlyNested:true});}
 for(const s of all)s.start=s.type===1?0:s.data.length<4096?mini(s.data):put(s.data);
 const miniRoot=Buffer.concat(miniBlocks),miniRootStart=put(miniRoot),miniFat=Buffer.alloc(Math.ceil(miniLinks.length*4/sector)*sector,0xff);miniLinks.forEach((x,i)=>miniFat.writeUInt32LE(x,i*4));const miniFatStart=put(miniFat);
 const dir=Buffer.alloc(Math.ceil((all.length+1)*128/sector)*sector);
 const root={name:'Root Entry',type:5,start:miniRootStart,data:miniRoot};const entries=[root,...all];
 entries.forEach((s,i)=>{s.index=i;s.left=FREE;s.right=FREE;s.child=FREE;s.color=1;});
 const sorted=all.filter(x=>!x.onlyNested).sort((a,b)=>a.name.length-b.name.length||(a.name.toUpperCase()<b.name.toUpperCase()?-1:1));
 let redLevel=0;for(let m=sorted.length-1;m>=0;m=Math.floor(m/2)-1)redLevel++;
 function tree(lo,hi,level){if(lo>hi)return FREE;const mid=(lo+hi)>>>1,e=sorted[mid];e.left=tree(lo,mid-1,level+1);e.right=tree(mid+1,hi,level+1);e.color=level===redLevel?0:1;return e.index;}
 root.child=tree(0,sorted.length-1,0);if(nested)all.find(x=>x.nested).child=all.find(x=>x.onlyNested).index;
 for(const e of entries){const o=e.index*128,name=Buffer.from(e.name+'\0','utf16le');name.copy(dir,o);dir.writeUInt16LE(name.length,o+64);dir[o+66]=e.type;dir[o+67]=e.color;dir.writeUInt32LE(e.left,o+68);dir.writeUInt32LE(e.right,o+72);dir.writeUInt32LE(e.child,o+76);dir.writeUInt32LE(e.start,o+116);if(e.type!==1)dir.writeBigUInt64LE(BigInt(e.data.length),o+120);}
 const dirStart=put(dir),base=chunks.length,words=sector/4;let nf=1,nd=0;
 for(let i=0;i<20;i++){const nnd=Math.max(0,Math.ceil((nf-109)/(words-1))),nnf=Math.ceil((base+nf+nnd)/words);if(nnf===nf&&nnd===nd)break;nf=nnf;nd=nnd;}
 const fatIds=Array.from({length:nf},(_,i)=>base+i),difIds=Array.from({length:nd},(_,i)=>base+nf+i);
 const fat=Buffer.alloc(nf*sector,0xff);fatLinks.forEach((x,i)=>fat.writeUInt32LE(x,i*4));for(const n of fatIds)fat.writeUInt32LE(0xfffffffd,n*4);for(const n of difIds)fat.writeUInt32LE(0xfffffffc,n*4);
 for(let i=0;i<nf;i++)chunks.push(fat.subarray(i*sector,(i+1)*sector));
 for(let i=0;i<nd;i++){const b=Buffer.alloc(sector,0xff),ids=fatIds.slice(109+i*(words-1),109+(i+1)*(words-1));ids.forEach((x,j)=>b.writeUInt32LE(x,j*4));b.writeUInt32LE(i+1===nd?END:difIds[i+1],sector-4);chunks.push(b);}
 const h=Buffer.alloc(sector);Buffer.from('d0cf11e0a1b11ae1','hex').copy(h);h.writeUInt16LE(0x3e,24);h.writeUInt16LE(version,26);h.writeUInt16LE(0xfffe,28);h.writeUInt16LE(sector===512?9:12,30);h.writeUInt16LE(6,32);h.writeUInt32LE(version===4?dir.length/sector:0,40);h.writeUInt32LE(nf,44);h.writeUInt32LE(dirStart,48);h.writeUInt32LE(4096,56);h.writeUInt32LE(miniFatStart,60);h.writeUInt32LE(miniFat.length/sector,64);h.writeUInt32LE(nd?difIds[0]:END,68);h.writeUInt32LE(nd,72);h.fill(0xff,76,512);fatIds.slice(0,109).forEach((x,i)=>h.writeUInt32LE(x,76+i*4));return Buffer.concat([h,...chunks]);
}
export function msgFixture({body='Sehr geehrte Damen und Herren,\n\nHier meine vollständige Adresse:\nMax Mustermann\nMusterstraße 1\n12345 Musterstadt\n\nMit freundlichen Grüßen\nMax Mustermann',sender='Max Mustermann',email='max@example.invalid',subject='Fiktiver Testfall',messageClass='IPM.Note',ansi=false,codePage=1252,extra={},omitBody=false,sector=512,nested=null}={}){
 const strings={0x001a:messageClass,0x0c1a:sender,0x0c1f:email,0x0037:subject};if(!omitBody)strings[0x1000]=body;
 const props=Buffer.alloc(32+16*(Object.keys(strings).length+(codePage==null?0:1))),streams={};let i=32;
 if(codePage!=null){props.writeUInt16LE(3,i);props.writeUInt16LE(0x3ffd,i+2);props.writeUInt32LE(codePage,i+8);i+=16;}
 for(const [p,v] of Object.entries(strings)){const tag=Number(p).toString(16).padStart(4,'0').toUpperCase(),type=ansi?'001E':'001F',data=Buffer.from(v+'\0',ansi?'latin1':'utf16le');streams['__substg1.0_'+tag+type]=data;props.writeUInt16LE(ansi?0x1e:0x1f,i);props.writeUInt16LE(Number(p),i+2);props.writeUInt32LE(6,i+4);props.writeUInt32LE(data.length,i+8);i+=16;}
 streams['__properties_version1.0']=props;Object.assign(streams,extra);return cfbFixture(streams,{sector,nested});
}
