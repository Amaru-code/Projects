# MCR Local Runner 0.7.0 – vollständige Queue-Schleife

Dieser Stand baut auf dem real bestätigten 0.6.3-Lauf auf.

## Reihenfolge

1. `Meine Vorgänge > In_Bearbeitung` automatisch öffnen.
2. Nur echte `E-MAIL`-Ticketzeilen mit **leerer `Zusätzlicher Beschreibung`** bearbeiten.
3. Ticket öffnen, `Bearbeiten` öffnen und den bestätigten Workflow ausführen.
4. Member-Suche normalisiert nur den COMARCH-Suchtext (`ä/ö/ü/ß -> ae/oe/ue/ss`).
5. Mapping, Gender, USC/Pläne, Beschreibung, Kategorien, Signatur und Antwort anwenden.
6. Nachricht genau einmal senden und nur bekannte OK-Dialoge bestätigen.
7. Versand gilt als bestätigt, wenn entweder der Nachrichtenverlauf wächst oder der Antworteditor nach bestätigten Dialogen serverseitig geleert wurde.
8. `Ticket speichern` genau einmal auslösen.
9. Speichern über die Arbeitslisten nachprüfen: ist dasselbe Ticket noch sichtbar, muss `Zusätzliche Beschreibung` nicht leer sein. Eine weiterhin leere Zeile stoppt den Lauf fail-closed.
10. Wieder `Meine Vorgänge > In_Bearbeitung` prüfen.
11. Wenn dort nichts mehr zulässig ist, `Warteschlange > INTL01` prüfen.
12. Nach jedem bearbeiteten Queue-Ticket wieder bei `Meine Vorgänge` beginnen.
13. Erst wenn **beide** Listen keine zulässigen Tickets mehr enthalten: `RUN COMPLETE`.

## Start

`START_FULL_QUEUE_RUN.cmd`

Vor dem ersten Versand des Laufs verlangt der Runner einmal `START`. Danach läuft er über alle aktuell zulässigen Tickets. Echte Mehrdeutigkeiten (z. B. mehrere Member-Kandidaten oder fehlende Daten) bleiben ein Human Gate bzw. stoppen fail-closed.

## Doppelversandschutz

- pro Ticket nur ein Send-Klick;
- unbekannte Dialoge stoppen den Lauf;
- verarbeitete Ticket-IDs werden innerhalb des Laufs nicht erneut verarbeitet;
- nach `Ticket speichern` darf ein noch sichtbares Ticket nicht weiterhin eine leere `Zusätzliche Beschreibung` haben;
- Sicherheitslimit standardmäßig 100 Tickets (`MCR_MAX_TICKETS`).

## Bekannte Grenze

Der neue Save-/Loop-Pfad ist synthetisch qualifiziert, aber noch nicht gegen den produktiven COMARCH-Speichervorgang bestätigt. Der erste reale 0.7.0-Lauf sollte beobachtet werden.
