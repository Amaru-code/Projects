# MCR Ticket Runner 0.4.1

## Wichtig: ZIP zuerst vollständig entpacken

Die `.cmd`-Dateien nicht direkt innerhalb der Windows-ZIP-Ansicht starten.
Windows kopiert dabei häufig nur den Starter in einen Temp-Ordner; die daneben
liegenden `.js`-Dateien fehlen dann. Die neuen Starter erkennen diesen Zustand
und brechen mit einer verständlichen Meldung ab.

## Empfohlener Start

1. ZIP vollständig entpacken.
2. `00_START_HIER.cmd` oder `RUNNER_OEFFNEN.cmd` starten.
3. Den kompletten Inhalt von `COMARCH_RUNNER.js` aus Notepad in die DevTools-
   Konsole des geöffneten COMARCH-Tickets kopieren und ausführen.
4. Mapping und Original-MSG wie bisher laden.
5. Bei eindeutigem, sichtbarem Member-Vorschlag wird nur dann automatisch
   ausgewählt, wenn der geprüfte Name UND die geprüfte MercerID exakt passen.
   Mehrere oder nicht eindeutig erkannte Treffer bleiben ein Human Gate.
6. Nach verifiziertem Einsetzen der zusätzlichen Beschreibung wechselt der
   Runner automatisch in die Ticket-Vorbereitung (feste Felder + Antworttext).
7. Vor `Senden` / `Ticket speichern` bleibt 0.4.1 weiterhin hart gestoppt.

## Sicherheitsgrenzen

- Kein automatisches Senden.
- Kein automatisches Ticket-Speichern.
- Keine automatische Geschlechtsableitung; Herr/Frau bleibt eine manuelle Wahl.
- Kein automatisches Überschreiben eines abweichend gefüllten Antworteditors.
- Bei mehreren Member-Treffern wählt der Benutzer selbst.
