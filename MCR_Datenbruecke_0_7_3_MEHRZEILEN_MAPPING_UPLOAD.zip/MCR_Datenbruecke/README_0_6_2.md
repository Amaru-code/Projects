# MCR Local Runner 0.6.2 – Dual Queue Detection

## Änderung gegenüber 0.6.1

Der Queue-/Send-Pilot erkennt nun beide real beobachteten COMARCH-Tabellen:

- `mainForm:tasksTableFor_MyTasksList` → **Meine Vorgänge > In_Bearbeitung**
- `mainForm:tasksTableFor_MyQueuesTasksList` → **Warteschlange > INTL01**

Für beide gilt unverändert die Zulässigkeitsregel:

1. echte Datenzeile im `tbody`;
2. Ticket-ID ausschließlich 6–12 Ziffern;
3. Quelle exakt `E-MAIL`;
4. `Zusätzliche Beschreibung` vollständig leer.

Der Pilot bearbeitet weiterhin genau **ein** Ticket und speichert das Ticket noch nicht. Versand bleibt nur nach den bereits vorhandenen expliziten Freigaben möglich.

## Test

1. `START_QUEUE_SEND_PILOT.cmd` starten.
2. Im MCR-Edge entweder `Meine Vorgänge > In_Bearbeitung` **oder** `Warteschlange > INTL01` öffnen.
3. ENTER drücken.
4. Im Terminal muss die erkannte Quelle ausdrücklich erscheinen, z. B. `Queue erkannt [Warteschlange INTL01]`.
