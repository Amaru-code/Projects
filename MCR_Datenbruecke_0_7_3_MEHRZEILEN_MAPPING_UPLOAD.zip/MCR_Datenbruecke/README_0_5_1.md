# MCR Local Runner 0.5.1

## Änderung gegenüber 0.5.0

Dieser Stand bleibt ein beaufsichtigter Einzelticket-Runner mit hartem Stopp vor `Senden` und `Ticket speichern`.

Neu:

- Wenn im Nachrichtenverlauf mehrere sichtbare Mail-Downloadpfeile vorhanden sind, wird gemäß der fachlichen Regel **immer die visuell unterste E-Mail-Zeile** automatisch gewählt.
- Befinden sich mehrere Download-Steuerelemente in derselben untersten Zeile, wird dort das **linkeste** verwendet (der Nachrichten-Downloadpfeil steht in COMARCH links). Falls kein sichtbarer Kandidat sicher erkannt wird oder der Klick keinen MSG-Download erzeugt, bleibt der manuelle Fallback erhalten.
- Die Erkennung des Felds `Zusätzliche Beschreibung` verwendet nun dieselbe semantische, formulargebundene Logik wie der zuvor erfolgreiche 0.3.5-Helfer. Sie ist nicht mehr von einer einzelnen dynamischen `j_id...` abhängig.
- Nach dem Schreiben wird die Beschreibung nach einer Seitenreaktion erneut aus dem sichtbaren DOM verifiziert.
- Diagnose erweitert um Mail-Auswahlregel und Beschreibungserkennungsroute, ohne Inhaltswerte zu exportieren.

## Start

1. ZIP vollständig entpacken bzw. mit dem bestehenden `MCR_Datenbruecke`-Ordner zusammenführen. `private_data` nicht löschen.
2. `START_LOCAL_BOT.cmd` starten.
3. Im eigenen MCR-Edge-Fenster ein INTL01-Ticket öffnen.
4. Der Runner verwendet automatisch das konfigurierte Mapping, lädt die **unterste sichtbare E-Mail im Nachrichtenverlauf** herunter und führt den bekannten Ablauf bis zum Pre-Send-Gate fort.

## Mail-Regel

Fachliche Regel dieses Releases:

> Gibt es mehrere sichtbare E-Mails im Nachrichtenverlauf, wird die unterste E-Mail verwendet.

Die Auswahl wird aus den sichtbaren `GetFile`-Download-Steuerelementen des aktuellen Tickets bestimmt. Es wird nicht pauschal die neueste Datei aus dem allgemeinen Windows-Downloads-Ordner verwendet.

## Beschreibung

Der Runner sucht `Zusätzliche Beschreibung` innerhalb desselben COMARCH-Formulars wie das Member-Feld anhand der sichtbaren Beschriftung. Unterstützt werden unter anderem Label-Verknüpfungen, alte Tabellen-/Wrapper-Strukturen und ein begrenzter geometrischer Fallback auf das eindeutig nächstgelegene Textfeld. Bei Mehrdeutigkeit wird fail-closed beendet.

Ein bereits abweichend gefülltes Feld wird nicht überschrieben.

## Unverändert

- Member-Suche bleibt automatisch, Auswahl bei nicht sicher erkannter Vorschlagsliste weiterhin Human-Gate.
- MercerID für den JSON-Lookup stammt aus dem tatsächlich von COMARCH übernommenen Member.
- Keine automatische Geschlechtsableitung.
- `Senden` und `Ticket speichern` sind weiterhin nicht implementiert.
