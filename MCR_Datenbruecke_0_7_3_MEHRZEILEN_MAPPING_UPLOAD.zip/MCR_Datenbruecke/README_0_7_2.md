# MCR Local Runner 0.7.2 – robuste Personenerkennung

0.7.2 basiert auf dem real erfolgreich gelaufenen 0.7.1-Vollrunner. Der Fix betrifft ausschließlich die Personenerkennung aus MSG/COMARCH-Nachrichten.

## Real beobachteter Fehler

Eine Secure-Mail-Nachricht enthielt als technische Absender-/Footer-Bezeichnung `Microsoft Outlook`. Der bisherige Kandidatenparser hielt dies formal für einen Personennamen. Aus `Microsoft Outlook` wurde dadurch die COMARCH-Suche `Outlook Microsoft`, obwohl im eigentlichen Nachrichtentext am Ende `Yours sincerely,` und anschließend der Kundenname stand.

## Fix

- technische Produkt-/Footer-Namen wie `Microsoft Outlook`, Outlook Mobile, iOS/Android sowie Secure-Mail-Bezeichnungen sind keine Personenkandidaten mehr;
- englische Abschlussformeln wie `Yours sincerely`, `Yours faithfully`, `Sincerely`, `Sincerely yours`, `Best wishes` und `Warm regards` werden als Signaturmarker erkannt;
- bestehende deutsche Signaturmarker bleiben erhalten;
- der eigentliche COMARCH-Workflow, Member-Profil-Fix, Mapping, Versand, Speichern und Queue-Schleife bleiben unverändert.

Bei einem Beispieltext `Yours sincerely,\nMark Brailey` wird `Mark Brailey` als Signaturkandidat erkannt; `Microsoft Outlook` wird verworfen.
