# 0.2.2 – Korrektur der Blattnamensuche

## Befund

Der Importer in 0.2.1 verwendete `s.attrs.name === 'Output'`. Der Vergleich unterschied Groß- und Kleinschreibung. In der gezeigten Excel-Oberfläche heißt der Reiter `output`. Die tatsächliche Kundendatei liegt hier nicht vor.

Der Fehler wurde mit der mitgelieferten fiktiven Arbeitsmappe reproduziert: Nur deren interner Blattname wurde in einer Testkopie von `Output` auf `output` geändert. 0.2.1 lieferte genau `SHEET: Das Blatt Output fehlt oder ist nicht eindeutig.`; 0.2.2 liest dieselben sieben Datensätze aus beiden Varianten. Einzelheiten: `docs/SHEETFIX_REPRODUCTION.json`.

## Änderungen

- Gemeinsamer enger Blattnamensvergleich im Node-Importer und im Browser-Mappingprüfer.
- Toleriert nur Groß-/Kleinschreibung sowie äußeren Leerraum, keine Teilwortsuche, kein automatisches erstes Blatt.
- Mehrdeutige Namen und ausgeblendete Zielblätter bleiben gesperrt.
- Gefundene Namen vor dem Lookup anzeigen; bei einem Fehler im Meldungstext wiederholen.
- Den tatsächlichen Namen unter `source.sheet` erhalten. `source.logicalSheet = Output` und `source.sheetMatch` dokumentieren zusätzlich die Zuordnung.
- 136 Node-Tests plus 20 synthetische Browser-Prüfungen. Kein echter Windows-/COMARCH-/Kundendaten-Test.

## Anwendung

Den Paketordner zusammenführen, nicht vorher löschen. `MAPPING_ERSTELLEN.cmd` starten und denselben Excel-Pfad verwenden. Quelle und L wie bisher mit JA bestätigen. Danach auch den aktuellen Konsolenblock aus `KONSOLE_OEFFNEN.cmd` erneut einsetzen. Vorhandene V1-Mappings mit `Output` funktionieren weiterhin.

Keine COMARCH-Schreib-, Sende- oder Speicherfunktion wurde hinzugefügt. Die Excel-Datei wird nur gelesen. Keine Installation und keine externe Verbindung für den Export.
