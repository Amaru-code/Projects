@echo off
start "" "%~dp0START_HIER.html"
