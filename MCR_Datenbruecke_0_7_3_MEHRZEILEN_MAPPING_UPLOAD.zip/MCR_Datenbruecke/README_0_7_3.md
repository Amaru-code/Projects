# MCR 0.7.3 — alle Bestandszeilen, explizit aktiviertes Mapping

## Was behoben wurde

Der Lauf des Nutzers lud nach einem erfolgreichen E/F-Export wieder das alte
`INTL01_mapping_gender_2026-09-30...json`. Der 0.7.2-Runner sortierte den in der
Konfiguration eingetragenen Pfad vor neueren Dateien ein. Das Entsperren im neuen
JSON konnte diesen Lauf deshalb nicht beeinflussen.

Zusätzlich enthielt das letzte E/F-Patch-ZIP ein eigenes `MANIFEST.json` am
Projektwurzelpfad. Nach dem Zusammenkopieren wurde nur noch ein Vier-Dateien-
Patch geprüft, nicht mehr das vollständige Botpaket. Dieses vollständige Paket
stellt die Anwendungsdateien und das vollständige Manifest wieder her. Die neue
Prüfung verlangt Paketname, Version und die kritischen Runner-/Mappingdateien.
Ein Vier-Dateien-Manifest wird nicht mehr als vollständiger Paketnachweis akzeptiert.

## Verbindliche neue Regel

Zu jeder bestätigten ClientEEID aus COMARCH werden **alle physischen Zeilen** im
Blatt `Output`/`output` über Spalte B zusammengefasst, in aufsteigender Excel-
Quellzeilennummer. Es wird keine erste Zeile bevorzugt und keine Zeile wegen
`TPP = 0` ausgelassen. Der frühere Einzelfall-Override `TPP = 1` entfällt.

Jede einzelne Zeile behält B/C/D/E/F/L/O und ihren Quellzeilenbeleg. Für jede Zeile
entsteht genau eine Beschreibung nach der vorhandenen Textregel:

- L: `USC {Wert}`
- C = 1: `DC`; D = 1: `PP+`; E = 1: `DB+`
- E bleibt zusätzlich als `pensIntel` gespeichert, F als `tpp`.
- F erzeugt **keinen neuen Textcode**. Das war keine angeforderte Textänderung.
- Leere Merkmale bleiben `null` und erzeugen kein Kürzel.

Die einzelnen Beschreibungen werden durch echte Zeilenumbrüche verbunden.
Auch identische Beschreibungszeilen bleiben bestehen. Es gibt **eine E-Mail pro
Ticket**, nicht eine pro Excel-Zeile. Die Auswahl unter mehreren COMARCH-Membern
ist von mehreren Bestandszeilen derselben bereits gewählten ClientEEID zu trennen.

Beispiel mit fiktiven Daten:

```
USC 20/ DB+
USC 20/ DB+
```

Es wird kein Vereinigungs-/OR-/Summenwert über die Merkmale verschiedener Zeilen
gebildet. Datenfehler, fehlender USC, fehlender Formelcache oder eine Zeile ohne
freigegebenes Kürzel sperren die ganze Person; es wird keine unvollständige
Teilbeschreibung verwendet. Mehr als 450 Zeichen einschließlich CRLF werden nicht
gekürzt, sondern zur Prüfung angehalten. Die reale `maxlength`-Grenze des
Zielfeldes wird beim Einsetzen ebenfalls berücksichtigt.

Gender wird nur dann automatisch für die Anrede genutzt, wenn alle Zeilen
durchgehend denselben nichtleeren M-/F-Wert tragen. Fehlende oder widersprüchliche
Angaben führen zur manuellen Anredewahl; andere O-Werte sind Datenfehler.
Formeln in den relevanten Spalten einschließlich F und O bleiben als solche
markiert. Gespeicherte Ergebnisse werden nicht neu berechnet und verlangen
vor Verwendung eine Bestätigung.

## Einmaliges Update — nichts installieren

1. Laufenden Bot beenden. Das ZIP vollständig entpacken. Den gelieferten Ordner
   `MCR_Datenbruecke` mit dem bisherigen gleichnamigen Projektordner zusammenführen
   und die gelieferten Dateien ersetzen. **Den Projektordner nicht vorher löschen.**
   `private_data`, `.runtime`, das Browserprofil und alte JSON-Dateien behalten.
2. **`MAPPING_MEHRZEILIG_AKTUALISIEREN.cmd`** starten. Das verwendet die bestehende
   Portable-Node-Installation. Es startet weder Edge noch einen Ticketlauf.
3. Der Exporter sucht die Original-XLSX neben dem Projektordner und prüft den
   Quellen-SHA256 gegen den vorhandenen Bestand. Sonst fragt er nach dem Pfad.
   Bestätige die angezeigten Spalten und die neue Regel mit **`JA`**.
4. Es entsteht ein neues `private_data/INTL01_mapping_multirow_....json` mit
   Dateiprüfsumme und `private_data/active-mapping.json` als Aktivierung. Der
   Kontrollfall `10102131` wird, falls vorhanden, mit ALLEN Zeilen lokal angezeigt.
5. Anschließend **`START_FULL_QUEUE_RUN.cmd`** starten. Es muss Version **0.7.3**
   anzeigen, danach `AKTIVES MEHRZEILEN-MAPPING: INTL01_mapping_multirow_...json`.
   Erst mit `START` wird der automatische Queue-/Versandlauf freigegeben.

Die neue Datei ist ausdrücklich ein **anderes Schema** und nicht für die alten
Konsolenpanels oder 0.7.2 gedacht. Das alte Gender-/E/F-Mapping allein enthält nicht
zwingend die unterdrückten Dublettenwerte; deshalb muss dieser Export die XLSX neu
lesen. Die XLSX wird nicht verändert. Der Node-Exporter vermeidet den früheren
PowerShell-5.1-JSON-Umweg einschließlich dessen BOM-/Depth-Problemen.

## Explizite Aktivierung statt Dateidatum-Raten

Der neue Vollrunner lädt nur den in `private_data/active-mapping.json` verzeichneten
Snapshot. Dateiname, Dateihash, Payload-Hash, Quellhash und Mehrzeilenregel müssen
zusammenpassen. Bei beschädigtem oder fehlendem aktivem Mapping stoppt er **vor
Edge-Start**. Er fällt nicht auf eine alte Datei zurück. Ein erneuter Export
aktiviert einen neuen Snapshot; alte JSONs und alte Aktivierungen bleiben erhalten.
Eine fehlgeschlagene Aktivierung lässt den vorher aktiven Zeiger bestehen.

Die frühere `config/local-runner-queue-send.json` bleibt für Browserpfade etc.
vorhanden, aber ihr historischer `mappingPath` wird im neuen Vollrunner nicht mehr
für die Bestandsauswahl verwendet. Alte Erweiterungspakete jetzt nicht erneut über
dieses vollständige Paket kopieren, insbesondere nicht deren `MANIFEST.json`.

## Umfang des Runner-Updates

PAGE_FETCH, Personenerkennung, Member-Anklicken, Umlautsuche, Kategorien, Signatur,
Antwortvorlage, Queue-Reihenfolge und der bestehende Versandpfad werden nicht neu
implementiert. Neu sind Mehrzeilen-Lookup, explizite Mappingaktivierung,
Formel-/Anredeprüfung über alle Zeilen, Prüfung der echten Zeilenumbrüche vor
Versand sowie Kontrolle des gesamten Beschreibungstextes nach Speichern in der
Arbeitsliste. Nur eine nichtleere Beschreibung genügt für die neue Speicherprüfung
nicht mehr. Ist das gespeicherte Ticket in beiden Listen nicht sichtbar, wird
`SAVE_UNVERIFIED` gemeldet, statt fehlende Sichtbarkeit als Speicherung auszugeben.

**Datenmehrfachzeilen sind keine Versandwiederholungen.** Der Runner enthält weiterhin
einen Sendeaufruf und einen Speichervorgang pro bearbeitetem Ticket. Seine bisherige
Versandbestätigung (neuer Verlaufseintrag oder Editor-Rücksetzung nach Dialogen)
wurde hier NICHT gegen einen Broker/Mailserver neu qualifiziert. Insbesondere ist
ein leerer Editor allein kein unabhängig bestätigter Zustellnachweis. Der bestehende
Schutz anhand bereits bearbeiteter Tickets gilt im laufenden Prozess; er ist kein
vollständiges dauerhaftes Versandjournal über alle Neustarts. Bei unklarem
Versandstatus daher nicht ohne manuelle Verlaufskontrolle erneut starten.

## Test und Grenzen

`docs/TESTBERICHT_0_7_3.md` enthält die im Container ausgeführten Tests.
Windows-CMD, die echte COMARCH-Instanz und die private Original-XLSX wurden hier
nicht ausgeführt. Es wird nicht behauptet, dass alle verbleibenden Bestandsfehler
verschwinden. Nur eine mehrfache B-Kennung allein ist nun kein Blocker mehr.

Im Rückmeldefall genügt der Terminalabschnitt mit Fehlercode und die automatisch
erstellte Diagnose-ZIP. Bestandsmapping, Original-Mail, Browserprofil und XLSX
bleiben lokal. Das neue Mapping enthält personenbezogene Kennungen und
Plan-/Gendermerkmale und darf nicht in Git aufgenommen werden.
