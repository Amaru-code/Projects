# MCR Local Runner 0.5.0

## Ziel

Erster lokaler Node.js/Edge-Runner. Keine DevTools-Injection mehr für den Standardlauf.
Der Runner bearbeitet **genau ein bereits ausgewähltes Ticket** bis zum Pre-Send-Gate.
`Senden` und `Ticket speichern` sind in dieser Version technisch nicht implementiert.

## Automatisiert

- gültiges INTL01-JSON-Mapping laden; der vom Benutzer genannte Pfad ist in `config/local-runner.json` gepinnt,
- eigenes persistentes Edge-Profil starten,
- Bearbeiten anklicken, falls der Button eindeutig sichtbar ist,
- Original-Mail des Tickets über den sichtbaren `GetFile`-Download automatisch herunterladen, wenn genau ein Download-Pfeil vorhanden ist,
- `.msg` lokal lesen,
- Person aus der Mail bestimmen; bei Mehrdeutigkeit Terminal-Human-Gate,
- Member-Suche `Nachname Vorname`,
- eindeutigen Vorschlag per **echtem Browser-Mausereignis** auswählen,
- bei mehreren/uneindeutigen Treffern Human-Gate,
- MercerID aus dem tatsächlich übernommenen COMARCH-Member lesen,
- JSON-Lookup und `USC ... / DC;PP+;DB+`,
- `Zusätzliche Beschreibung` einsetzen,
- Second Level / Allgemeine Schriftwechsel / Personenschriftwechsel / INTL01-Signatur vorbereiten,
- Herr/Frau bewusst abfragen,
- Antworttext in den COMARCH-Editor einsetzen,
- Stopp direkt vor Versand.

## Start

1. ZIP vollständig entpacken bzw. den Ordner mit dem bestehenden `MCR_Datenbruecke`-Ordner zusammenführen. `private_data` nicht löschen.
2. `START_LOCAL_BOT.cmd` starten.
3. Es öffnet sich ein **eigenes MCR-Edge-Fenster** mit persistentem Profil unter `.runtime\edge-profile`. Beim ersten Lauf dort ggf. anmelden.
4. Ein INTL01-Ticket öffnen. Der Runner klickt `Bearbeiten`, wenn der Button eindeutig gefunden wird.
5. Danach den Anweisungen im Terminal folgen. Normalerweise sind nur Human-Gates bei mehrdeutigem Namen/Member sowie die Anrede nötig.

## Mapping

In `config/local-runner.json` ist aktuell gepinnt:

`C:\Users\Amaru-Zegarra\projects\Aktive_Projekte\Ticket_bot\MCR_Datenbruecke\private_data\INTL01_mapping_2026-09-29T13-00-41-552Z_64ea2aec.json`

Ist diese Datei nicht vorhanden, wird im konfigurierten `private_data`-Ordner bzw. im lokalen `private_data` nach dem neuesten **gültigen** `INTL01_mapping_*.json` gesucht. Es gibt keinen Browser-Dateidialog mehr.

## Mail-Download

Der Runner verwendet einen eigenen Downloadordner `.runtime\downloads` und klickt den Downloadpfeil des aktuellen Tickets selbst, wenn genau einer erkannt wird. Das ist sicherer als pauschal die neueste Datei aus dem allgemeinen Windows-Downloads-Ordner zu nehmen. Bei mehreren Original-Mail-Downloads bleibt ein Human-Gate.

## Member

Die Member-Auswahl unterscheidet sich von normalen Feldern. COMARCH erzeugt dynamische Vorschläge und übernimmt sie über ein `mousedown`-Ereignis plus Server-Update. Der lokale Runner kann echte Browser-Mausereignisse senden. Bei genau einem passenden sichtbaren Namen wird automatisch geklickt; eine eindeutige MercerID aus der Mail wird nur als zusätzliche Kreuzprüfung verwendet. Die Lookup-ID stammt anschließend aus dem **tatsächlich ausgewählten COMARCH-Member**.

## Sicherheit

- kein automatisches `Senden`,
- kein automatisches `Ticket speichern`,
- keine automatische Geschlechtsableitung,
- kein Überschreiben eines bereits abweichend gefüllten Beschreibung-/Antwortfelds,
- mehrere Member-Treffer bleiben Human-Gate,
- Mapping, MSG und Browserprofil bleiben lokal,
- Diagnose-ZIPs enthalten keine Namen, IDs, Mailtexte, Mappingwerte, Cookies oder URLs.

## Demo

`DEMO_LOCAL_BOT.cmd` nutzt fiktive Daten. Die Release-Qualifikation lief zusätzlich mit einem echten CDP-Mausereignis in Chromium.
