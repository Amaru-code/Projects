# MCR Local Runner 0.5.3

## Neu

- Standardweg ohne Mail-Download: Der Runner liest die sichtbaren Nachrichtenzeilen direkt aus der COMARCH-Tabelle `Original / Von / An / Betreff / Inhalt / Datum`.
- Er beginnt mit der untersten/neuesten Zeile und kann auf eine ältere Zeile zurückfallen, wenn dort ein eindeutiger Namenshinweis vorhanden ist.
- Nur wenn keine sichtbare Nachrichtenzeile einen brauchbaren Namenshinweis liefert, wird die `.msg`-Downloadlogik als Fallback verwendet.
- Nach der Member-Übernahme und nach dem Setzen der Dokumentenkategorie wird das echte Feld `mainForm:member-value-id` erneut mit der Browsermaus angeklickt. Erst danach wird auf die Bearbeitbarkeit von `mainForm:category-sub-value-id` gewartet.
- `Personenschriftwechsel` wird danach wie ein echtes Vorschlagsfeld verarbeitet; bei Unsicherheit bleibt der manuelle Fallback.
- Die bereits funktionierende automatische eindeutige Member-Auswahl, MercerID-Übernahme, JSON-Lookup und Beschreibung bleiben erhalten.

## Start

ZIP vollständig entpacken und `START_LOCAL_BOT.cmd` starten.

## Sicherheitsgrenze

0.5.3 sendet keine E-Mail und klickt nicht auf `Ticket speichern`. Mehrdeutige Member bleiben ein Human Gate.
