@echo off
setlocal
cd /d "%~dp0"
set "NODE_EXE="
for %%N in ("C:\Users\Amaru-Zegarra\projects\Compiler\javascript\tools\node\node.exe" "%~dp0tools\node\node.exe") do if not defined NODE_EXE if exist "%%~N" set "NODE_EXE=%%~N"
if not defined NODE_EXE for /f "delims=" %%N in ('where node.exe 2^>nul') do if not defined NODE_EXE set "NODE_EXE=%%N"
if not defined NODE_EXE exit /b 3
"%NODE_EXE%" "%~dp0src\local-bot-full-run.mjs" --demo --auto --headless --close-browser --full-run
pause
