@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
echo ==============================================================
echo  MCR Vollautomatik 0.7.3 - ALLE Bestandszeilen
echo ==============================================================
echo.
if not exist "%~dp0src\local-bot-full-run.mjs" goto incomplete
if not exist "%~dp0lib\package-integrity.mjs" goto incomplete
call "%~dp0_MCR_NODE_073.cmd"
if not "%errorlevel%"=="0" goto nodeError
"%MCR_NODE%" "%~dp0src\verify-package.mjs"
if not "%errorlevel%"=="0" goto verifyError
"%MCR_NODE%" "%~dp0src\local-bot-full-run.mjs" --full-run
set "RC=%errorlevel%"
echo.
if not "%RC%"=="0" echo STOP: Nicht erneut senden, wenn ein Versand bereits versucht wurde. Fehler oben pruefen.
pause
exit /b %RC%
:incomplete
echo STOP: ZIP erst vollstaendig entpacken und Dateien des Ordners MCR_Datenbruecke zusammenfuehren.
echo private_data und .runtime NICHT loeschen.
pause
exit /b 2
:nodeError
echo STOP: Vorhandene node.exe ab 22.15 wird benoetigt.
pause
exit /b 3
:verifyError
echo STOP: Vollstaendiges 0.7.3-Paket ersetzen. Alte Patch-Manifeste nicht ueber dieses Paket kopieren.
pause
exit /b 4
