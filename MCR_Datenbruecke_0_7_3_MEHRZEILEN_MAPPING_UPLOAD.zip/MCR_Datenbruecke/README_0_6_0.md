# MCR Queue + Send Pilot 0.6.0

Pilot fuer genau **ein** Ticket.

Neu:

- waehlt in der sichtbaren `In_Bearbeitung`-Liste das erste E-MAIL-Ticket mit leerer `Zusaetzliche Beschreibung`;
- probiert mehrere voneinander unabhaengige Oeffnungsmethoden und stoppt nach dem ersten nachgewiesenen Erfolg;
- probiert fuer `Bearbeiten` mehrere Methoden und stoppt nach dem ersten nachgewiesenen Erfolg;
- normalisiert nur den COMARCH-Member-Suchtext: `ae/oe/ue/ss` statt `ä/ö/ü/ß`; Stammdaten und Antwort bleiben unveraendert;
- bevorzugt das neueste `INTL01_mapping_gender_*.json` und nutzt `M -> Herr`, `F -> Frau`;
- fuehrt den bestaetigten 0.5.5-Vorbereitungspfad aus;
- sendet **erst nach** den zwei Bedienfreigaben `JA` und `SENDEN`;
- bestaetigt nur eindeutig erkannte `OK`-Dialoge bzw. Browser-Alert/Confirm-Dialoge;
- weist den Versand durch eine zusaetzliche Zeile im Nachrichtenverlauf nach;
- **speichert das Ticket in 0.6.0 noch nicht** und startet noch kein naechstes Ticket.

## Start

1. ZIP vollstaendig entpacken bzw. mit dem bestehenden `MCR_Datenbruecke`-Ordner zusammenfuehren.
2. `private_data` und `.runtime\edge-profile` nicht loeschen.
3. Im MCR-Edge `Meine Vorgaenge > In_Bearbeitung` mit der Tabelle oeffnen.
4. `START_QUEUE_SEND_PILOT.cmd` starten.
5. Nach dem echten Pre-Send-Review `JA` und anschliessend `SENDEN` eingeben.

## Eligibility

Ein Ticket wird nur automatisch ausgewaehlt, wenn:

- `Zusaetzliche Beschreibung` leer ist; und
- `Quelle` entweder `E-MAIL` ist oder die Quelle in der Tabelle nicht lesbar ist.

Nicht-leere Zeilen werden uebersprungen.

## Fail-closed nach Senden

Nach einem Klick auf `Senden` gibt es **keinen zweiten Sendeversuch**. Wenn Dialog oder Versandnachweis unklar sind, beendet sich der Runner mit Fehler und fordert keinen Retry aus demselben Lauf an.
