@echo off
start "" notepad.exe "%~dp0COMARCH_MAIL_ASSISTENT.js"
