@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "MCR_JS=%~dp0COMARCH_RUNNER.js"
if not exist "%MCR_JS%" goto notExtracted
start "" notepad.exe "%MCR_JS%"
exit /b 0
:notExtracted
echo.
echo FEHLER: COMARCH_RUNNER.js wurde neben diesem Starter nicht gefunden.
echo Das passiert typischerweise, wenn die .cmd direkt IM ZIP gestartet wird.
echo.
echo Bitte das gesamte ZIP zuerst in einen normalen Ordner entpacken und
echo danach RUNNER_OEFFNEN.cmd aus dem entpackten Ordner starten.
echo.
pause
exit /b 2
