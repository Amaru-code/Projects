# MCR 0.6.1 – Queue-Erkennung korrigiert

Dieser Patch übernimmt die im echten COMARCH per DevTools bestätigte Queue-Regel.

## Eligibility
Eine Zeile wird nur als Ticket akzeptiert, wenn:

- sie im `tbody` der Task-Tabelle liegt,
- die Ticket-ID-Spalte ausschließlich 6–12 Ziffern enthält,
- `Quelle` exakt `E-MAIL` ist,
- `Zusätzliche Beschreibung` nach Whitespace-Normalisierung leer ist.

Die Such-/Filterzeile (`Suchen...`) ist damit ausgeschlossen.

Im Realtest vor diesem Patch wurden 13 echte Ticketzeilen und 3 zulässige Tickets erkannt; die erste zulässige Ticket-ID war 84560398. Dieser konkrete Wert ist **nicht** im Code hinterlegt.

Der Pilot bearbeitet weiterhin genau ein Ticket. Senden bleibt doppelt freigabepflichtig; Ticket speichern und Queue-Schleife bleiben deaktiviert.
