import test from 'node:test';
import assert from 'node:assert/strict';
import {choosePhase2Candidate} from '../src/phase2-run.mjs';
import {isAoSharedWriteBlock} from '../lib/phase2-ao-write-block.mjs';
import {describeTicketIssue,recoveryGroup} from '../lib/ticket-error-catalog.mjs';
const row=(ticketId,request)=>({ticketId,intelGroupVerified:true,descriptionValue:'USC 20/PP+\nStandardantwort versendet\n'+request});
const ao=row('99000001','Möchte Auszahlungsoption'),combined=row('99000002','Möchte Kontoauszug & Auszahlungsoption'),mark=row('99000003','Möchte Rentenberatung'),pp=row('99000004','Möchte Kontoauszug');
const block={ticketId:'99000000',reason:'MASTER_OPENED_READONLY'};
test('RC114 shared write fault pauses new AO and combined jobs, non-AO still selected',()=>{
 const selected=choosePhase2Candidate([ao,combined,mark,pp],{prepareMissingPdf:true,aoWriteBlock:block});
 assert.equal(selected.row.ticketId,mark.ticketId);assert.equal(selected.kind,'MARK_DIRECT');
 assert.deepEqual(selected.skipped.map(x=>x.reason),['AO_QUEUE_PAUSED_MASTER_WRITE','AO_QUEUE_PAUSED_MASTER_WRITE']);
 assert.equal(selected.skipped[0].technicalDetails.triggerTicketId,block.ticketId);
 const next=choosePhase2Candidate([ao,combined,pp],{prepareMissingPdf:true,aoWriteBlock:block,accountReady:()=>false});
 assert.equal(next.row.ticketId,pp.ticketId);assert.equal(next.pdfPreparationRequired,true);
});
test('RC114 pause reports every new AO if no other cases and new run has no sticky block',()=>{
 const selected=choosePhase2Candidate([ao,combined],{prepareMissingPdf:true,aoWriteBlock:block});
 assert.equal(selected.row,null);assert.equal(selected.skipped.length,2);
 assert.equal(choosePhase2Candidate([ao],{prepareMissingPdf:true}).pdfPreparationRequired,true);
});
test('RC114 prior PDF journal remains subject to existing recovery gate and never triggers regeneration',()=>{
 const result=choosePhase2Candidate([ao,mark],{prepareMissingPdf:true,aoWriteBlock:block,getPdfJournal:id=>id===ao.ticketId?{state:'UPLOAD_INTENT'}:null,accountReady:()=>false});
 assert.equal(result.row.ticketId,mark.ticketId);assert.equal(result.skipped[0].reason,'PDF_JOURNAL_NOT_RESUMABLE');
 const resume=choosePhase2Candidate([ao],{prepareMissingPdf:true,aoWriteBlock:block,getPdfJournal:()=>({state:'UPLOAD_VERIFIED'}),accountReady:()=>true});
 assert.equal(resume.row.ticketId,ao.ticketId);assert.equal(resume.pdfPreparationRequired,undefined);
});
test('RC114 only shared faults latch the pause; person/field issues are not global',()=>{
 for(const r of ['MASTER_OPENED_READONLY','MASTER_WORKBOOK_WRITE_LOCKED','MASTER_WRITE_PERMISSION_DENIED','MASTER_WRITE_OPEN_FAILED','MASTER_SAVE_IO_RETRY_REQUIRED','AO_CONTACT_SAVE_UNVERIFIED']){
  assert(isAoSharedWriteBlock(r));assert.equal(recoveryGroup(r),'DATENZUGRIFF');assert(!describeTicketIssue({reason:r}).errorCode.startsWith('MCR-P2-U'));
 }
 for(const r of ['AO_MASTER_PERSON_CHANGED','MASTER_CONTACT_UPDATE_FAILED','AO_CONTACT_INPUT_DEFERRED','AO_CONTACT_DATA_REQUIRED','P2_DOCUMENT_GENERATOR_CONTRACT_REQUIRED'])assert.equal(isAoSharedWriteBlock(r),false);
 assert.equal(recoveryGroup('AO_QUEUE_PAUSED_MASTER_WRITE'),'DATENZUGRIFF');
});
