# MCR Datenbrücke 0.8.1-rc.69 – kompaktes Komplettpaket

## Installation

Dieses ZIP separat entpacken. `START.cmd` öffnen, **Menü 1** wählen und den bestehenden Installationsordner `MCR_Datenbruecke` übernehmen. Danach nur die **installierte** `START.cmd` benutzen.

RC69 unterstützt einen direkt verifizierten Softwarewechsel von RC68 (sowie die im Integritätsmodul ausdrücklich gebundenen RC64/RC65/RC67-Versionen). Der Installer archiviert die vorhandene Software für den Rückweg. **Bestandsdaten, Konfiguration, Mapping, Browserprofil, Laufberichte und Ticketjournale verbleiben unverändert im vorhandenen Installationsordner.** Das ZIP enthält keine produktiven Bestandsdaten.

## Master Run und Phase 2

- **Menü 13:** Master Run, Phase 1 zuerst; bei vollständig und fehlerfrei als leer bestätigten Intel-Listen direkt zu Phase 2 – ohne neuen Versandpilot.
- **Menü 12:** Nur Phase 2 bearbeiten. Für eine Fortsetzung von MBC-Ticket `88449724` hier mit dieser Ticketnummer starten. Kein Phase-1-Neuversand.
- Phase 1 darf ausschließlich `In_Bearbeitung` und `INTL01` benutzen. Keine Navigation zu `Offene Vorgänge` oder fremden Tickets.
- Phase 2 verwendet die bisherigen geprüften DB-/MBC-/Kontoauszug-Regeln mit Mark-Baindl-Prüfung, Ticketjournalschutz und einem einzigen Ausführungsklick nach Freigabe.

## RC69 – Eingabe der zusätzlichen Beschreibung

Nach eindeutig bestätigtem Fokus wird vor `Input.insertText` geprüft, ob **der gesamte ursprüngliche Text ausgewählt** ist. Bleibt der native Eingabebefehl ohne jede Änderung, wird ausschließlich das zuvor eindeutig gebundene Textfeld mit demselben ereignisbasierten Setter bearbeitet, der auch in Phase 1 verwendet wird. Eine unklare, teilweise oder fremde Änderung wird **nicht** überschrieben. Nach dem Blur bleibt der separate Speicherklick samt Server-Readback zwingend; es wird weder automatisch eine E-Mail versendet noch eine Weiterleitung wiederholt.

Vollständige technische Änderungen und Grenzen: `docs/RC69_RELEASE.md`. Die produktive Windows-/COMARCH-Bestätigung ist noch ausstehend.
