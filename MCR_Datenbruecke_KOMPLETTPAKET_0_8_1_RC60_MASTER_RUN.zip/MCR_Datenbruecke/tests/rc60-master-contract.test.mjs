import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {ROOT} from './helpers.mjs';
import {VERSION} from '../lib/control.mjs';
import {verifyPackage,verifyPrevious} from '../tools/integrity.mjs';
import {sha256} from '../lib/core.mjs';

test('RC60 is sealed and supports direct intact RC59 predecessor',{timeout:15000},()=>{
 assert.equal(VERSION,'0.8.1-rc.60');
 assert.equal(verifyPackage(ROOT).version,VERSION);
 assert.equal(verifyPrevious(ROOT).version,VERSION);
 const original=JSON.parse(fs.readFileSync(path.join(ROOT,'tools/reference/complete-0.8.1-rc.59-manifest.json')));
 assert.equal(original.version,'0.8.1-rc.59');
 const permitted=new Set(['lib/control.mjs','tools/cli.mjs','tools/integrity.mjs','package.json','README_DE.md']);
 for(const r of original.payload.filter(x=>/^(src|lib|tools)\//.test(x.path))){
  if(permitted.has(r.path))continue;
  assert.equal(sha256(fs.readFileSync(path.join(ROOT,r.path))),r.sha256,'modified working RC59 module: '+r.path);
 }
});
test('master reuses existing guarded runners, has no automatic resend or phase2 email',()=>{
 const s=fs.readFileSync(path.join(ROOT,'tools/cli.mjs'),'utf8');
 const block=s.slice(s.indexOf('export async function masterRun('),s.indexOf('async function completionOnly('));
 for(const part of ['runPhase1(true)','runPhase1(false,{masterLimit:cap})','runPhase2({root:rootDir})','STOP_REVIEW_REQUIRED','PARTIAL_PHASE1_LIMIT','COMPLETE_VISIBLE_SCOPE','MASTER_START'])assert(block.includes(part),part);
 assert(!/sendOnce\(|sendEmail\(|sendPhase2Mail\(|\.click\(/.test(block));
 assert(s.includes('13  MASTER RUN: Standardantworten -> Phase 2'));
});
