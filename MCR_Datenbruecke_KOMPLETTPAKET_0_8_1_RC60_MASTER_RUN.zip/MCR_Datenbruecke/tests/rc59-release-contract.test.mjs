import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {ROOT} from './helpers.mjs';
import {VERSION} from '../lib/control.mjs';
import {sha256} from '../lib/core.mjs';
import {verifyPackage,verifyPrevious} from '../tools/integrity.mjs';
const baseline='563f241d2aad2b2fb2acaefc2b25aeaf64345a8a0f126c278be6ce57954715ca';

test('RC59 pins exact published RC58 and changes only review SELECT focus, its route callsite, version and release tooling',{timeout:15000},()=>{
 assert.equal(VERSION,'0.8.1-rc.60');
 const f=path.join(ROOT,'tools/reference/complete-0.8.1-rc.58-manifest.json');
 assert.equal(sha256(fs.readFileSync(f)),baseline);
 const prev=JSON.parse(fs.readFileSync(f));assert.equal(prev.version,'0.8.1-rc.58');
 const allowed=new Set(['lib/control.mjs','lib/phase2-comarch-actions.mjs','lib/phase2-review-flow.mjs','tools/cli.mjs','tools/integrity.mjs']);
 for(const x of prev.payload.filter(r=>/^(lib|src|tools)\//.test(r.path))){
  const current=path.join(ROOT,x.path);assert(fs.existsSync(current),x.path);
  if(allowed.has(x.path))continue;
  assert.equal(sha256(fs.readFileSync(current)),x.sha256,'Regression to previously working module: '+x.path);
 }
 assert.equal(verifyPackage(ROOT).version,VERSION);
 assert.equal(verifyPrevious(ROOT).version,VERSION);
});

test('RC59 review SELECT cannot use DOM click, write a SELECT value, send email or skip Mark and execution proof',()=>{
 const action=fs.readFileSync(path.join(ROOT,'lib/phase2-comarch-actions.mjs'),'utf8');
 const flow=fs.readFileSync(path.join(ROOT,'lib/phase2-review-flow.mjs'),'utf8');
 for(const x of ['REVIEW_DROPDOWN_OCCLUDED','P2_REVIEW_SELECT_OPERATOR_FOCUS','PASSIVE_REPOSITION_HIT_TEST','P2_REVIEW_SELECT_MOVED'])
  assert(action.includes(x),x);
 for(const x of ['BEREIT_PRUEFSCHRITT','P2_REVIEW_ASSIGNEE_BEGIN','reviewAssignmentState','EXECUTE_INTENT'])assert(flow.includes(x),x);
 assert(flow.indexOf('reviewAssignmentState')<flow.indexOf("journal.advance('EXECUTE_INTENT')"));
 assert(!/\.click\(\)|\.focus\(\)|\.value\s*=\s*['"]FORWARD_TO_REVIEW/.test(action.slice(action.indexOf('async function reviewSelectPoint'),action.indexOf('export async function reviewAssignmentState'))));
 assert(!/sendOnce\(|sendPhase2Mail\(|sendEmail\(/.test(flow));
});
