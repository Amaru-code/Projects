# MCR Datenbrücke 0.8.1-rc.59

## RC59: Prüfschritt-Auswahl nach Signatur/Entwurf sicher fokussieren

RC58 hat Ticket `87160524` nach bestätigter Signaturauswahl mit
`REVIEW_DROPDOWN_OCCLUDED` beendet. Die Ursache war ein einziger
Hit-Test auf der Mittelpunktkoordinate des nativen COMARCH-SELECT.
RC59 prüft dieselbe eindeutige Auswahlliste an mehreren sicheren Punkten
und Scrollpositionen. Nur wenn der ganze Bereich verdeckt bleibt, kann
sie nach **BEREIT_PRUEFSCHRITT** vom Bediener im Edge physisch fokussiert
werden; der Bot prüft den tatsächlichen Fokus, bevor er Tastatureingaben sendet.

Der gespeicherte MBC-Entwurf, die INTL01-Signatur, GEVO und Beschreibung
werden nicht wiederholt. Vor Mark Baindl und genau einem „Schritt ausführen“
bleiben alle bestehenden Empfänger-/Journal-/Speicherprüfungen bestehen.
Kein E-Mail-Versand im Phase-2-Lauf.

**Installation:** RC59 separat entpacken, neue START.cmd, Menü 1.
Anschließend installierte START.cmd, Menü 12, Ticket 87160524.
Details in `docs/RC59_PRUEFSCHRITT_FOKUS.md`.

---

# MCR Datenbrücke 0.8.1-rc.58

## RC58: COMARCH-Signatur im MBC-Entwurf ohne E-Mail-Versand

Beim Fall MBC_PRIVATE_EMAIL wird die echte COMARCH-Signatur
`INTL01 - Intel Deutschland GmbH` in `mainForm:signature-value-id`
über die eindeutig bestätigte INTL01-Vorschlagsliste ausgewählt.
**Kein HTML-Footer wird händisch in den Nachrichtentext eingetragen und keine E-Mail versendet.**
Die Signatur wird vor `Entwurf speichern` festgelegt und nach dem Speichern
überprüft. Für das bereits vorbereitete MBC-Ticket 87160524 (Journalstatus
`REVIEW_VERIFIED`, noch kein `EXECUTE_INTENT`) wählt RC58 die fehlende
Signatur aus, speichert denselben vorhandenen Entwurf einmal zusätzlich und
setzt erst anschließend die bestehende Weiterleitung mit manueller/Auto-Freigabe
fort. Ist die Signatur bereits exakt vorhanden, erfolgt kein unnötiges
Entwurfsspeichern. Unklare Signatur-/Speicherzustände werden nicht wiederholt.

Menü 1: Schnellinstallation, Menü 12 mit Ticket 87160524.
Details und Prüfgrenzen: `docs/RC58_INTL01_SIGNATURE_MBC.md`.

---

## RC57: Verdecktes Beschreibungsfeld und RC56-Fokusabbruch

Die aus RC56 bekannte Fehlermeldung `DESCRIPTION_FOCUS` (Ticket 87160524)
tritt vor dem neuen Ticket-Speicherklick auf. Das bereits gesicherte MBC-Entwurfsfeld
bleibt unverändert. RC57 versucht denselben beschrifteten Textbereich an mehreren
sichtbaren Stellen durch passives Scrollen und Hit-Test anzuklicken.
Falls die Fläche vollständig verdeckt bleibt, darf der Benutzer den richtigen
Textbereich im Edge manuell fokussieren: **zuerst** im Terminal
`BEREIT_BESCHREIBUNG`, **anschließend** im Bot-Edge in die sichtbare
"Zusätzliche Beschreibung" klicken. Der Bot prüft selbstständig den
TEXAREA-Fokus, bevor er Text einfügt, und fragt dazu nicht erneut im Terminal.

Das offene RC56-Journal mit `SAVE_REPAIR_AUTHORIZED` ohne nachfolgenden
Speicher- oder Weiterleitungsversuch kann nach frischem Serverabgleich und
Ticket-bestätigter Freigabe fortgeführt werden; kein nochmaliges Entwurfsspeichern,
kein automatischer zweiter Speicherklick nach bereits gestarteter Aktion,
keine Weiterleitung ohne nachgewiesenen gespeicherten Status.

Menü 1 bleibt Schnellinstallation; Menü 12 für Ticket 87160524. Kein E-Mail-Versand.
Details: `docs/RC57_FOKUS_UND_WIEDERAUFNAHME.md`.

---


## RC56: MBC erst Entwurf, dann Ticketfelder, dann Prüfer

Realer RC55-Befund: MBC-Entwurf im Editor eingesetzt, der Abschluss der
Ticketbeschreibung wurde nach einem manuell bestätigten Speicherklick nicht
serverseitig nachgewiesen (`P2_WORK_SERVER_DESCRIPTION`). Die Weiterleitung
wurde nicht ausgeführt; das ist **kein** Prüfer-/Schritt-ausführen-Fehler.

Neue MBC-Reihenfolge: **GEVO Anfrage Member auswählen, MBC-Entwurf einsetzen und speichern**, danach
Formular neu prüfen, GEVO erneut bestätigen und **Bearbeitet not reviewed** setzen,
Ticket genau einmal speichern, im erneut geöffneten COMARCH-Ticket serverseitig
prüfen, **dann** die bestehende Überprüfungs-Weiterleitung nach mark.baindl.
Die Prüf-/Zuweisungs-/Ausführungslogik wurde nicht verändert.

Ein altes `TICKET_SAVE_INTENT` für Ticket 87160524 bleibt im Journal. RC56
kontrolliert zunächst den tatsächlich gespeicherten Zustand einschließlich
MBC-Entwurf; bei vollständiger Speicherung wird ohne weiteren Speicherklick
weitergeleitet. Bei nachweislich fehlender Speicherung ist eine einzige
**gesondert bestätigte** Reparatur der Ticketfelder möglich, ohne den Entwurf
neu zu erzeugen. Ein erneut fehlgeschlagener Versuch wird nicht automatisch
wiederholt. Kein E-Mail-Versand in Menü 12.

**Installation:** neues ZIP getrennt entpacken, `START.cmd` ausführen, Menü 1.
Danach installierte `START.cmd`, Menü 12, Ticket 87160524. Menü 1 bleibt die
Schnellinstallation ohne lange Testläufe. Originale Laufjournale, private Daten,
Mapping, PDF-Dateien und Browserprofil bleiben erhalten. Prüfgrenzen:
`docs/RC56_MBC_TICKET_SPEICHERN_UND_WIEDERAUFNAHME.md`.

---

# MCR Datenbrücke 0.8.1-rc.55

## RC55: MBC-Entwurf statt pauschalem Abbruch

Menü 1 bleibt Schnellinstallation ohne automatische Langtests/Demos.
Menü 12 kann direkt gestartet werden; seine Inventur wird frisch eingelesen.

Vorhandener identischer MBC-Text wird beibehalten. Ein leerer Editor wird befüllt.
Abweichender Entwurf (auch Signatur/Vorlage) wird NICHT stillschweigend ersetzt:
Der bisherige visuelle HTML-Inhalt UND der Textarea-Quellinhalt werden unter
`.runtime/phase2/draft-backups` lokal und mit Prüfsumme gesichert. Dann im
Ticketfenster **MBC-Text einsetzen** oder **Unverändert lassen** wählen.
Die Ersetzung ist auch im AUTO-Modus eine eigene manuelle Entscheidung.
Der zweite Knopf lässt den Vorgang unverändert und setzt mit dem nächsten
zulässigen Ticket fort. Ein übersprungenes Ticket zählt nicht als weitergeleitet.
Bei fehlendem Bedienfenster: `ERSETZEN <Ticketnummer>` / `UEBERSPRINGEN`.
Keine neue E-Mail. Keine Freigabe offener früherer Versandversuche.

Die Sicherungen enthalten sensible Ticketdaten: lokal belassen, nicht ungeprüft teilen.
Details und Prüfgrenzen: `docs/RC55_MBC_ENTWURF_PRUEFUNG.md`.

---

# MCR Datenbruecke 0.8.1-rc.55

Vollständiges Softwarepaket. Software nur über die separat entpackte START.cmd,
Menü 1, in die bestehende Installation übernehmen. Mapping, Konfiguration,
Browserprofil, PDF-Prüfbelege und Ticketjournale bleiben am Ort.

## Bedienung
- Menü 1: Schnellinstallation mit Integritätsprüfung, Sicherung und Prozesskontrolle.
- Menü 3/4: Echte Standardbearbeitung ohne automatische fiktive Demos.
  Jeder neue Lauf startet MANUELL. Das Fenster unten links bietet Manuell/Auto
  und die einmalige Freigabe des angezeigten Tickets. Pilot plus bis zu fünf
  Folgetickets in Menü 3; Menü 4 weiterhin erst nach verifiziertem Piloten.
- Menü 5: Ein offenes Versandticket ohne Neuversand fertigstellen oder bisherigen
  Lauf prüfen. Bei unklarem Ausgang niemals erneut senden.
- Menü 12: Phase 2 mit Kontoauszügen, DB/DB+-Direktweiterleitung und privatem
  MBC-Login-Entwurf. Kein E-Mail-Versand, kein automatischer Generatorstart.
- Menü 2: optionale fiktive Browserproben. Menü 6: optionale vollständige Selbsttests.

Prüferzuweisung und direkte Weiterleitung bleiben getrennte Wege. Nach jeder
bestätigten Bearbeitung wird gespeichert und der Abschluss geprüft, bevor das
nächste passende Ticket beginnt. Die grüne FERTIG-Anzeige bestätigt den
abgeschlossenen Lauf, nicht pauschal alle Tickets im COMARCH-System.

Aktuelle Anleitung: docs/RC53_BEARBEITER_UND_VERSANDSTEUERUNG.md.
Prüfstand: docs/RC53_PRUEFBERICHT.json. Reale Windows-/COMARCH-Abnahme bleibt offen.
Historische RC-Dokumente im docs-Ordner sind keine aktuellen Startanleitungen.

## Aktuell: RC54

Menü 12 hat ein eigenes Ticketfenster unten links, Manuell/Auto und einen Knopf vor der Abschlussweiterleitung. Abgeschlossene Karten wandern über fünf Sekunden nach oben links und blenden aus. MBC erkennt die beiden exakten Schreibweisen E-Mail und Email. Details und bekannte Prüfgrenzen: `docs/RC54_PHASE2_TICKETFENSTER.md`; Prüfergebnisse: `docs/RC54_PRUEFBERICHT.json`. Die Schnellinstallation bleibt ohne automatische Langtests.


RC60: Menü 13 = Master Run für neue Standardantworten und anschließend Phase 2. Grenzen, Journale und Stoppregeln: docs/RC60_MASTER_RUN.md.
