@echo off
call "%~dp0START_LOCAL_BOT.cmd"
