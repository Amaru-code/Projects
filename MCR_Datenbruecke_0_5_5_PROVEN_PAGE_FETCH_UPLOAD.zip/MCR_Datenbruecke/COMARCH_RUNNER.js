/* MCR Ticket Runner 0.4.1. One console injection. No send/save. */
(()=>{
const __runnerTop=(()=>{try{return window.top}catch{return window}})();
function __startPrep(){if(__runnerTop.MCR_PREP)return __runnerTop.MCR_PREP;
const Prep=(()=>{const module={exports:{}};
/* MCR 0.4.1: pure ticket-preparation rules. No DOM/network/I/O. */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.MCRTicketPrep=factory();})(globalThis,function(){
 'use strict';
 const FIXED=Object.freeze({
  responsibility:'Second Level',
  category:'Allgemeine Schriftwechsel',
  subcategory:'Personenschriftwechsel',
  signature:'INTL01 - Intel Deutschland GmbH'
 });
 const clean=v=>String(v??'').normalize('NFC').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();
 function fail(code,message){throw Object.assign(new Error(message),{code});}
 function surname(value){const s=clean(value);if(!s||s.length>100||!/^[\p{L}\p{M}][\p{L}\p{M} .'’\-]*$/u.test(s))fail('REPLY_SURNAME','Nachnamen prüfen. Keine Nummer, Mailadresse oder freie Nachricht eintragen.');return s;}
 function salutation(kind,last){last=surname(last);if(kind==='Herr')return `Sehr geehrter Herr ${last},`;if(kind==='Frau')return `Sehr geehrte Frau ${last},`;fail('REPLY_SALUTATION','Anrede Herr oder Frau manuell auswählen. Keine automatische Geschlechtsableitung.');}
 function replyText(kind,last){return [
  salutation(kind,last),
  '',
  'vielen Dank, dass Sie sich mit uns in Verbindung gesetzt haben.',
  '',
  'Mit dieser E-Mail möchten wir Ihnen bestätigen, dass wir Ihr Ticket erhalten haben und unser Team derzeit daran arbeitet. Wir wissen Ihre Geduld und Ihr Verständnis zu schätzen, da wir uns bemühen, Ihnen den bestmöglichen Support zu bieten.',
  'Seien Sie versichert, dass Ihr Anliegen für uns wichtig ist und wir uns bemühen, es so schnell wie möglich zu lösen. Unser engagiertes Team arbeitet aktiv an Ihrem Ticket und wird Sie über den aktuellen Stand der Dinge informieren.',
  'Wenn Sie weitere Informationen oder Fragen zu Ihrem Ticket haben, können Sie gerne auf diese E-Mail antworten.'
 ].join('\n');}
 function sameText(a,b){const n=v=>String(v??'').replace(/\r\n?/g,'\n').replace(/[\t\u00a0]+/g,' ').replace(/[ ]+\n/g,'\n').replace(/\n[ ]+/g,'\n').trim();return n(a)===n(b);}
 return Object.freeze({FIXED,clean,surname,salutation,replyText,sameText});
});

return module.exports;})();
/* MCR 0.4.1 Ticket-Vorbereiter: categories/signature/reply, hard stop before send. */
'use strict';
const W=window;let T=W;try{void W.top.document.body;T=W.top;}catch{}
const demo=location.protocol==='file:'||location.href==='about:blank'||['localhost','127.0.0.1','[::1]'].includes(location.hostname);
if(!demo&&location.hostname!=='comarchecm.mercer.com')throw new Error('MCR: Ticket-Vorbereiter nur im freigegebenen COMARCH-Fenster oder in der lokalen Demo verwenden.');
let upstream=false;try{upstream=!!T.MCR_MAIL?.diagnostic?.().flow?.descriptionWritten;}catch{}
// The data assistant is no longer needed after description insertion. Close it
// so its mail/mapping state is cleared and the panels do not overlap.
try{T.MCR_MAIL?.close?.();}catch{}
try{T.MCR_PREP?.close();W.MCR_PREP?.close();}catch{}
const D=T.document,HID='__mcr_ticket_preparer_v4';D.getElementById(HID)?.remove();
const host=D.createElement('div');host.id=HID;Object.assign(host.style,{position:'fixed',top:'12px',right:'12px',zIndex:'2147483647',width:'470px',maxWidth:'96vw'});
const shadow=host.attachShadow({mode:'open'}),style=D.createElement('style');style.textContent=`:host{font:14px/1.45 'Segoe UI',Arial,sans-serif;color:#172d40}*{box-sizing:border-box}section{background:#fff;border:2px solid #275875;border-radius:12px;box-shadow:0 6px 30px #0005;max-height:94vh;overflow:auto;padding:16px}h2{font-size:19px;margin:0 0 6px}details{margin:12px 0;border:1px solid #beced9;border-radius:7px;padding:10px}summary{font-weight:700;cursor:pointer}.status{padding:10px;border-left:4px solid #23747c;background:#edf7f6;font-weight:600}.error{border-color:#b24033;background:#fff0e9}.ready{border-color:#278344;background:#eaf8ef}.note{font-size:12px;color:#485c6a}label{display:block;margin:8px 0}input,select,textarea,button{font:inherit}input[type=text],select,textarea{width:100%;padding:7px;border:1px solid #91a5b5;border-radius:4px}button{padding:8px 11px;margin:4px 5px 4px 0;cursor:pointer;border:1px solid #6c899d;border-radius:5px;background:#edf3f8;color:#15354b}button:disabled{opacity:.5;cursor:not-allowed}.primary{background:#1d5778;color:white}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:12px/1.5 Consolas,monospace;padding:8px;background:#eff4f8;max-height:230px;overflow:auto}.row{display:flex;gap:10px}.row>label{flex:1;min-width:0}`;shadow.append(style);
const panel=D.createElement('section');shadow.append(panel);D.body.append(host);
const ui={},listeners=new Map();let alive=true,pickMode=null,pickUntil=0,replyBinding=null,replyText=null,replyWritten=false,recipientOK=false,descriptionOK=upstream,fixedReview=false,ready=false,lastError=null,lastOutcome=null;let fixed={responsibility:'NOT_RUN',category:'NOT_RUN',subcategory:'NOT_RUN',signature:'NOT_RUN'};let fixedEvents={responsibility:0,category:0,subcategory:0,signature:0};let replyReadback='NOT_RUN',lastReplyWrite=null;
function el(tag,text,parent=panel){const n=D.createElement(tag);if(text!==undefined)n.textContent=text;parent.append(n);return n;}
function btn(text,fn,parent=panel){const n=el('button',text,parent);n.type='button';n.onclick=()=>Promise.resolve().then(fn).catch(error);return n;}
function check(text,parent,checked=false){const l=el('label',undefined,parent),n=D.createElement('input');n.type='checkbox';n.checked=checked;l.append(n,D.createTextNode(' '+text));return n;}
function input(label,parent){const l=el('label',label,parent),n=el('input',undefined,l);n.type='text';return n;}
function visible(n){try{return !!n?.isConnected&&n.getClientRects().length>0&&n.ownerDocument.defaultView.getComputedStyle(n).visibility!=='hidden'&&n.ownerDocument.defaultView.getComputedStyle(n).display!=='none';}catch{return false;}}
function status(text,bad=false,good=false){ui.status.textContent=text;ui.status.className='status'+(bad?' error':good?' ready':'');}
function fail(code,message){throw Object.assign(new Error(message),{code});}
function need(ok,code,message){if(!ok)fail(code,message);}
function error(e){lastError=/^[A-Z0-9_]+$/.test(e.code??'')?e.code:'ERROR';ready=false;status(lastError+': '+(e.message||'Vorgang fehlgeschlagen.'),true);}
function documents(){const out=[];function walk(doc,depth){if(!doc||depth>6||out.length>=40||out.includes(doc))return;out.push(doc);for(const f of doc.querySelectorAll('iframe,frame'))try{walk(f.contentDocument,depth+1);}catch{}}walk(D,0);return out;}
function field(id,tag){const hits=documents().map(d=>d.getElementById(id)).filter(n=>n&&visible(n)&&(!tag||n.tagName===tag));need(hits.length===1,'FIELD_NOT_FOUND','Benötigtes COMARCH-Feld nicht eindeutig gefunden: '+id);return hits[0];}
function memberField(){return field('mainForm:member-value-id','INPUT');}
function memberReady(){const f=memberField();need(/\bINTL01-\d{1,15}\b/.test(f.value),'MEMBER_REQUIRED','Zuerst den richtigen COMARCH-Member auswählen.');return f;}
function caseGuard(){memberReady();need(alive,'CLOSED','Helfer wurde geschlossen.');}
function norm(v){return Prep.clean(v);}
function nativeSet(n,value){const w=n.ownerDocument.defaultView,p=n.tagName==='SELECT'?w.HTMLSelectElement.prototype:w.HTMLInputElement.prototype,set=Object.getOwnPropertyDescriptor(p,'value')?.set;need(set,'FIELD_SETTER','Browser-Feldsetter nicht verfügbar.');set.call(n,value);}
function emit(n,type){fixedEvents[Object.keys(Prep.FIXED).find(k=>Prep.FIXED[k]===n.value)??'category']??=0;n.dispatchEvent(new n.ownerDocument.defaultView.Event(type,{bubbles:true}));}
function exactSelect(select,text){caseGuard();need(!select.disabled,'FIELD_READONLY','Zuständigkeit ist nicht bearbeitbar.');const options=[...select.options].filter(o=>norm(o.textContent)===text);need(options.length===1,'OPTION_NOT_FOUND','Option nicht eindeutig gefunden: '+text);const before=select.value;nativeSet(select,options[0].value);select.dispatchEvent(new select.ownerDocument.defaultView.Event('input',{bubbles:true}));caseGuard();select.dispatchEvent(new select.ownerDocument.defaultView.Event('change',{bubbles:true}));caseGuard();need(norm(select.selectedOptions?.[0]?.textContent)===text,'FIELD_VERIFY','Zuständigkeit konnte nicht bestätigt werden.');return before===select.value?'ALREADY_VISIBLE':'DOM_SELECTED';}
function setText(field,value){const w=field.ownerDocument.defaultView,set=Object.getOwnPropertyDescriptor(w.HTMLInputElement.prototype,'value')?.set;need(set,'FIELD_SETTER','Input-Setter nicht verfügbar.');set.call(field,value);field.dispatchEvent(new w.Event('input',{bubbles:true}));const key=value.slice(-1)||'x',code=key.toUpperCase().charCodeAt(0);field.dispatchEvent(new w.KeyboardEvent('keyup',{key,keyCode:code,which:code,bubbles:true}));}
function near(a,b){const x=a.getBoundingClientRect(),y=b.getBoundingClientRect();return Math.abs(x.left-y.left)<700&&y.top>=x.top-20&&y.top<=x.bottom+450;}
function exactSuggestionRows(f,expected){const doc=f.ownerDocument,all=[...doc.querySelectorAll('div,li,tr,button,a')];if(all.length>16000)return[];return all.filter(n=>visible(n)&&n!==f&&typeof n.onmousedown==='function'&&near(f,n)&&norm(n.innerText??n.textContent)===expected);}
async function suggestExact(id,expected,key){caseGuard();let f=field(id,'INPUT');need(!f.disabled&&!f.readOnly,'FIELD_READONLY',expected+' ist nicht bearbeitbar.');f.scrollIntoView({block:'center',behavior:'instant'});f.focus();setText(f,expected);let row=null;for(let i=0;i<16;i++){await new Promise(r=>setTimeout(r,160));caseGuard();f=field(id,'INPUT');const rows=exactSuggestionRows(f,expected);if(rows.length===1){row=rows[0];break;}if(rows.length>1){fixed[key]='MANUAL_REQUIRED';return {state:'MANUAL_REQUIRED',reason:'Mehrere identische Vorschläge'};}}
 if(!row){fixed[key]=norm(f.value)===expected?'TEXT_ONLY_MANUAL_SELECTION_REQUIRED':'MANUAL_REQUIRED';return {state:fixed[key]};}
 const w=row.ownerDocument.defaultView;row.dispatchEvent(new w.MouseEvent('mousedown',{bubbles:true,cancelable:true,view:w,button:0,buttons:1}));fixedEvents[key]++;await new Promise(r=>setTimeout(r,650));caseGuard();f=field(id,'INPUT');need(norm(f.value)===expected,'FIELD_VERIFY',expected+' wurde nach Auswahl nicht im Feld bestätigt.');fixed[key]='AUTO_MOUSEDOWN';return {state:fixed[key]};}
function inspectFixed(){const out={};try{const s=field('mainForm:responsibility-value-id','SELECT');out.responsibility=norm(s.selectedOptions?.[0]?.textContent)===Prep.FIXED.responsibility;}catch{out.responsibility=false;}for(const [k,id] of [['category','mainForm:category-value-id'],['subcategory','mainForm:category-sub-value-id'],['signature','mainForm:signature-value-id']])try{out[k]=norm(field(id,'INPUT').value)===Prep.FIXED[k];}catch{out[k]=false;}return out;}
async function prepareFixed(){caseGuard();ready=false;fixedReview=false;ui.fixedReview.checked=false;status('Feste Felder werden vorbereitet. COMARCH kann dabei reguläre AJAX-Anfragen auslösen.');fixed.responsibility=exactSelect(field('mainForm:responsibility-value-id','SELECT'),Prep.FIXED.responsibility);await new Promise(r=>setTimeout(r,450));fixed.category=(await suggestExact('mainForm:category-value-id',Prep.FIXED.category,'category')).state;await new Promise(r=>setTimeout(r,450));fixed.subcategory=(await suggestExact('mainForm:category-sub-value-id',Prep.FIXED.subcategory,'subcategory')).state;await new Promise(r=>setTimeout(r,450));fixed.signature=(await suggestExact('mainForm:signature-value-id',Prep.FIXED.signature,'signature')).state;renderFixed();const check=inspectFixed();if(Object.values(check).every(Boolean))status('Vier feste Werte sind sichtbar. Bitte im echten COMARCH-Formular prüfen und das Kontrollkästchen bestätigen.');else status('Mindestens ein Feld braucht manuelle Auswahl. Exakte Sollwerte stehen im Panel; anschließend „Feste Felder prüfen“.',true);}
function renderFixed(){ui.fixedInfo.textContent=[`Zuständigkeit: ${Prep.FIXED.responsibility} — ${fixed.responsibility}`,`Dokumentenkategorie: ${Prep.FIXED.category} — ${fixed.category}`,`Unterkategorie: ${Prep.FIXED.subcategory} — ${fixed.subcategory}`,`Signatur: ${Prep.FIXED.signature} — ${fixed.signature}`].join('\n');}
function verifyFixed(){caseGuard();const c=inspectFixed();for(const k of Object.keys(c))if(c[k]&&fixed[k]==='NOT_RUN')fixed[k]='VISIBLE_VERIFIED';renderFixed();need(Object.values(c).every(Boolean),'FIXED_FIELDS','Nicht alle vier festen Werte sind im COMARCH-Formular sichtbar korrekt. Fehlende Vorschläge manuell auswählen und erneut prüfen.');status('Vier feste Werte sichtbar korrekt. Jetzt manuell im Formular gegenprüfen und bestätigen.');return c;}
function memberSurnameHint(){try{const v=memberField().value.match(/^(.+?)\s*\(INTL01-/)?.[1]?.trim();if(!v)return'';const parts=v.split(/\s+/);return parts.length===2?parts[0]:'';}catch{return'';}}
function editorCandidates(){const out=[];for(const doc of documents()){for(const n of doc.querySelectorAll('[contenteditable="true"],html[contenteditable="true"],body[contenteditable="true"]'))if(visible(n)&&n.isContentEditable&&!host.contains(n))out.push(n);if(doc.designMode==='on'&&visible(doc.documentElement))out.push(doc.body||doc.documentElement);}return [...new Set(out)];}
function editorTarget(){if(replyBinding?.isConnected&&replyBinding.isContentEditable)return replyBinding;const c=editorCandidates();need(c.length===1,'REPLY_EDITOR','Antworteditor nicht eindeutig erkannt. „Antworteditor verbinden“ verwenden.');return c[0];}
function armEditor(){caseGuard();need(replyText,'REPLY_TEXT','Zuerst Antworttext erzeugen.');pickMode='REPLY';pickUntil=Date.now()+30000;for(const doc of documents())attach(doc);status('ALT halten und direkt in den leeren COMARCH-Nachrichteneditor klicken. Das verbindet nur; noch kein Text wird eingesetzt.');}
function editorFromNode(n){if(!n)return null;if(n.isContentEditable)return n;const p=n.closest?.('[contenteditable="true"]');if(p?.isContentEditable)return p;const doc=n.ownerDocument;if(doc?.documentElement?.isContentEditable)return doc.documentElement;if(doc?.body?.isContentEditable)return doc.body;return null;}
function capture(event){if(!pickMode||!event.isTrusted||!event.altKey||event.button!==0||event.composedPath().includes(host))return;if(Date.now()>pickUntil){pickMode=null;return;}event.preventDefault();event.stopImmediatePropagation();const mode=pickMode;pickMode=null;if(mode==='REPLY'){const e=editorFromNode(event.target);if(!e){error(Object.assign(new Error('Bitte direkt in den bearbeitbaren Nachrichteneditor klicken.'),{code:'REPLY_BIND'}));return;}replyBinding=e;const old=e.style.outline;e.style.outline='3px solid #1d5778';setTimeout(()=>{if(e.isConnected)e.style.outline=old;},1400);status('Antworteditor verbunden. Noch nichts geschrieben.');}}
function cancelPick(e){if(e.key==='Escape'&&pickMode){pickMode=null;status('Element-Verbindung abgebrochen.');}}
function attach(doc){if(listeners.has(doc))return;doc.addEventListener('pointerdown',capture,true);doc.addEventListener('mousedown',capture,true);doc.addEventListener('keydown',cancelPick,true);listeners.set(doc,true);}
function editorText(n){return String(n.innerText??n.textContent??'').replace(/\r\n?/g,'\n').replace(/\u00a0/g,' ').replace(/[ \t]+\n/g,'\n').replace(/\n[ \t]+/g,'\n').trim();}
function htmlEscape(s){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
function generateReply(){caseGuard();const sal=ui.salutation.value,last=Prep.surname(ui.surname.value);replyText=Prep.replyText(sal,last);ui.preview.textContent=replyText;replyWritten=false;replyReadback='NOT_RUN';ready=false;status('Antworttext erzeugt. Inhalt prüfen; danach in den COMARCH-Editor einsetzen.');return replyText;}
async function writeReply(){caseGuard();need(replyText,'REPLY_TEXT','Zuerst Antworttext erzeugen.');const e=editorTarget();need(e.isContentEditable,'REPLY_EDITOR','Ziel ist nicht bearbeitbar.');const existing=editorText(e);need(!existing||Prep.sameText(existing,replyText),'REPLY_EXISTS','Nachrichteneditor enthält bereits abweichenden Text. Nichts wird überschrieben.');if(!Prep.sameText(existing,replyText)){e.innerHTML=replyText.split('\n').map(htmlEscape).join('<br>');e.dispatchEvent(new e.ownerDocument.defaultView.Event('input',{bubbles:true}));lastReplyWrite={changed:true,event:'input'};}else lastReplyWrite={changed:false,event:null};replyReadback='VERIFYING';for(let i=0;i<6;i++){await new Promise(r=>setTimeout(r,150));caseGuard();need(e.isConnected&&Prep.sameText(editorText(e),replyText),'REPLY_VERIFY','COMARCH hat den Antworttext verändert oder den Editor ersetzt. Keine Wiederholung.');}replyBinding=e;replyWritten=true;replyReadback='DOM_VERIFIED';ready=false;status('Antworttext steht im Editor. Noch kein Versand. Empfänger und finale Vorschau prüfen.');}
function finalCheck(){caseGuard();const c=verifyFixed();need(descriptionOK,'DESCRIPTION_REVIEW','Zusätzliche Beschreibung im echten COMARCH-Ticket prüfen und bestätigen.');need(fixedReview,'FIXED_REVIEW','Feste Felder im echten COMARCH-Formular prüfen und bestätigen.');need(recipientOK,'RECIPIENT_REVIEW','Empfänger im Feld „An“ manuell prüfen und bestätigen.');need(replyWritten&&replyReadback==='DOM_VERIFIED','REPLY_REVIEW','Antworttext muss im echten COMARCH-Editor stehen und lokal nachgelesen sein.');need(Object.values(c).every(Boolean),'FIXED_FIELDS','Feste Felder sind nicht mehr vollständig.');ready=true;lastOutcome='READY_BEFORE_SEND';lastError=null;ui.finalInfo.textContent='BEREIT VOR VERSAND\n✓ Zuständigkeit / Kategorien / Signatur sichtbar geprüft\n✓ Member bereits ausgewählt\n✓ Zusätzliche Beschreibung geprüft\n✓ Antworttext im Editor nachgelesen\n✓ Empfänger manuell geprüft\n\nSTOPP: „Senden“ und „Ticket speichern“ bleiben absichtlich manuell.';status('BEREIT VOR VERSAND — jetzt das echte Formular noch einmal prüfen. Der Helfer sendet und speichert nicht.',false,true);}
el('h2','MCR Ticket-Vorbereiter 0.4.1');el('p','Feste Felder + Antworttext · harter Stopp vor Versand').className='note';ui.status=el('p',upstream?'Beschreibung wurde vom vorherigen Helfer lokal bestätigt.':'Beschreibung bitte im echten Ticket prüfen.');ui.status.className='status';
const s1=el('details',undefined);s1.open=true;el('summary','1 · Feste Ticketfelder vorbereiten',s1);el('p','Sollwerte: Second Level · Allgemeine Schriftwechsel · Personenschriftwechsel · INTL01 - Intel Deutschland GmbH',s1).className='note';btn('Feste Felder vorbereiten',prepareFixed,s1).className='primary';btn('Feste Felder prüfen',verifyFixed,s1);ui.fixedInfo=el('pre','Noch nicht ausgeführt.',s1);ui.fixedReview=check('Ich habe die vier Werte im echten COMARCH-Formular geprüft.',s1);ui.fixedReview.onchange=()=>{fixedReview=ui.fixedReview.checked;ready=false;};
const s2=el('details',undefined);s2.open=true;el('summary','2 · Antwort vorbereiten',s2);const salLabel=el('label','Anrede',s2);ui.salutation=el('select',undefined,salLabel);for(const v of [['','Bitte wählen'],['Herr','Herr'],['Frau','Frau']]){const o=el('option',v[1],ui.salutation);o.value=v[0];}ui.surname=input('Nachname',s2);ui.surname.value=memberSurnameHint();btn('Antworttext erzeugen',generateReply,s2);ui.preview=el('pre','Noch kein Antworttext erzeugt.',s2);btn('Antworteditor verbinden',armEditor,s2);btn('Antwort in COMARCH einsetzen',writeReply,s2).className='primary';
const s3=el('details',undefined);s3.open=true;el('summary','3 · Vor Versand prüfen',s3);ui.descriptionOK=check('Die zusätzliche Beschreibung im echten COMARCH-Ticket ist korrekt.',s3,descriptionOK);ui.descriptionOK.onchange=()=>{descriptionOK=ui.descriptionOK.checked;ready=false;};ui.recipientOK=check('Den Empfänger im COMARCH-Feld „An“ habe ich manuell geprüft.',s3);ui.recipientOK.onchange=()=>{recipientOK=ui.recipientOK.checked;ready=false;};btn('Vor Versand prüfen',finalCheck,s3).className='primary';ui.finalInfo=el('pre','Noch nicht bereit. Der Helfer besitzt keine Funktion zum Senden oder Speichern.',s3);el('p','Dieses Modul klickt weder „Senden“ noch „Ticket speichern“ und bestätigt keine Versanddialoge.',s3).className='note';
btn('Diagnose-ZIP',downloadDiagnostic);btn('Schließen',close);for(const doc of documents())attach(doc);
function diagnostic(){return {schema:'MCR_TICKET_PREP_DIAGNOSTIC_V1',version:'0.4.1',createdAt:new Date().toISOString(),capabilities:{automaticSend:false,automaticSave:false,setsFixedFields:true,writesReplyEditor:true},precondition:{upstreamDescriptionConfirmed:upstream,descriptionReviewed:descriptionOK},fixed:{states:{...fixed},visible:inspectFixed(),operatorReviewed:fixedReview,selectionEvents:{...fixedEvents}},reply:{generated:!!replyText,bound:!!replyBinding,written:replyWritten,readback:replyReadback,lastWrite:lastReplyWrite,salutationChosen:!!ui.salutation.value,surnamePresent:!!ui.surname.value.trim()},recipientReviewed:recipientOK,readyBeforeSend:ready,lastOutcome,lastError,privacy:'No names, IDs, email addresses, reply text, field values, URLs, selectors, cookies or DOM exported.'};}
function crc32(bytes){let c=0xffffffff;for(const b of bytes){c^=b;for(let k=0;k<8;k++)c=(c&1)?0xedb88320^(c>>>1):c>>>1;}return(c^0xffffffff)>>>0;}
function storeZip(files){let offset=0;const local=[],central=[],enc=new TextEncoder(),concat=parts=>{const all=new Uint8Array(parts.reduce((n,p)=>n+p.length,0));let i=0;for(const p of parts){all.set(p,i);i+=p.length;}return all;};for(const [name,text] of files){const n=enc.encode(name),data=enc.encode(text),crc=crc32(data),h=new Uint8Array(30),v=new DataView(h.buffer);v.setUint32(0,0x04034b50,true);v.setUint16(4,20,true);v.setUint16(6,0x800,true);v.setUint16(12,33,true);v.setUint32(14,crc,true);v.setUint32(18,data.length,true);v.setUint32(22,data.length,true);v.setUint16(26,n.length,true);const c=new Uint8Array(46),cv=new DataView(c.buffer);cv.setUint32(0,0x02014b50,true);cv.setUint16(4,20,true);cv.setUint16(6,20,true);cv.setUint16(8,0x800,true);cv.setUint16(14,33,true);cv.setUint32(16,crc,true);cv.setUint32(20,data.length,true);cv.setUint32(24,data.length,true);cv.setUint16(28,n.length,true);cv.setUint32(42,offset,true);local.push(h,n,data);central.push(c,n);offset+=h.length+n.length+data.length;}const cd=concat(central),end=new Uint8Array(22),ev=new DataView(end.buffer);ev.setUint32(0,0x06054b50,true);ev.setUint16(8,files.length,true);ev.setUint16(10,files.length,true);ev.setUint32(12,cd.length,true);ev.setUint32(16,offset,true);return concat([...local,cd,end]);}
async function sha(value){const b=typeof value==='string'?new TextEncoder().encode(value):value;return [...new Uint8Array(await crypto.subtle.digest('SHA-256',b))].map(x=>x.toString(16).padStart(2,'0')).join('');}
async function diagnosticBytes(){const report=JSON.stringify(diagnostic(),null,2)+'\n',hash=await sha(report),manifest=JSON.stringify({schema:'MCR_DIAGNOSTIC_MANIFEST_V1',payload:[{path:'diagnostic.json',sha256:hash}],privacy:'No personal values or page content.'},null,2)+'\n';return storeZip([['diagnostic.json',report],['manifest.json',manifest],['SHA256SUMS.txt',hash+'  diagnostic.json\n'+await sha(manifest)+'  manifest.json\n']]);}
async function downloadDiagnostic(){const bytes=await diagnosticBytes(),hash=await sha(bytes),url=URL.createObjectURL(new Blob([bytes],{type:'application/zip'})),a=D.createElement('a');a.href=url;a.download='MCR_PREP_'+new Date().toISOString().replace(/[:.]/g,'-')+'_UPLOAD.zip';a.click();setTimeout(()=>URL.revokeObjectURL(url),20000);status('Diagnose-ZIP erstellt. ZIP-SHA256: '+hash);}
function close(){alive=false;pickMode=null;for(const [doc] of listeners){doc.removeEventListener('pointerdown',capture,true);doc.removeEventListener('mousedown',capture,true);doc.removeEventListener('keydown',cancelPick,true);}listeners.clear();replyBinding=null;replyText=null;host.remove();if(T.MCR_PREP===api)delete T.MCR_PREP;if(W.MCR_PREP===api)delete W.MCR_PREP;}
const api=Object.freeze({version:'0.4.1',prepareFixed,verifyFixed,generateReply,writeReply,finalCheck,diagnostic,diagnosticBytes,close});T.MCR_PREP=api;W.MCR_PREP=api;console.info('MCR Ticket-Vorbereiter 0.4.1 aktiv. Kein Senden, kein Ticket-Speichern.');

return __runnerTop.MCR_PREP;}
const Core=(()=>{const module={exports:{}};
/* Pure business rules used identically in Node and the console bundle. No I/O. */
(function(root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.MCRBridgeCore = factory();
})(globalThis, function() {
  'use strict';
  const SCHEMA = 'MCR_INTL01_LOOKUP_V1';
  const STRICT_FLAGS = 'STRICT_BINARY_V1';
  const BLANK_OMIT_FLAGS = 'ONE_ONLY_BLANK_OMIT_V1';
  const validPolicy = p => p === STRICT_FLAGS || p === BLANK_OMIT_FLAGS;
  const policyOf = value => value?.flagPolicy ?? STRICT_FLAGS;
  const RULE = 'B=ClientEEID;L=USC;C=DC;D=PP+;E=DB+;order=DC,PP+,DB+';
  function fail(code, message) { throw Object.assign(new Error(message), {code}); }
  function need(ok, code, message) { if (!ok) fail(code, message); }
  const text = v => String(v ?? '').replace(/\u00a0/g, ' ').trim();
  // Logical source role stays Output; the real sheet name is preserved in metadata.
  // Only case and outer whitespace are tolerated; no fuzzy/prefix matching.
  function isOutputSheet(value) {
    return typeof value === 'string' && text(value).toLowerCase() === 'output';
  }
  function id(v) {
    need(typeof v === 'string', 'ID_TYPE', 'Kennungen muessen Zeichenketten sein.');
    const s = text(v);
    need(/^\d{1,15}$/.test(s) && !/^0+$/.test(s), 'ID_INVALID', 'Keine gueltige ClientEEID. Keine Rundung oder automatische Entfernung fuehrender Nullen.');
    return s;
  }
  function selectedMember(value) {
    const s = text(value), matches = [...s.matchAll(/\bINTL01-(\d{1,15})(?![\w.-])/g)];
    need(matches.length === 1, 'MEMBER_NOT_SELECTED', 'Im Member-Feld fehlt eine eindeutige INTL01-Kennung. Den echten Vorschlag auswaehlen, nicht nur einen Namen eintippen.');
    return {clientId: id(matches[0][1]), display: s};
  }
  function flag(v, col, policy = STRICT_FLAGS) {
    need(validPolicy(policy), 'FLAG_POLICY', 'Unbekannte Merkmalsregel.');
    const s = text(v);
    if (policy === BLANK_OMIT_FLAGS && s === '') return null; // Preserve EMPTY; omit its code, do not assert ineligibility.
    need(s === '0' || s === '1', 'FLAG_INVALID', `${col}: nur 0 oder 1, leer wird nicht zu 0.`);
    return Number(s);
  }
  function description(entry) {
    const policy=policyOf(entry);
    need(validPolicy(policy), 'FLAG_POLICY', 'Unbekannte Merkmalsregel.');
    const usc = text(entry.usc);
    need(/^\d{1,6}(?:[.,]\d{1,6})?$/.test(usc), 'USC_INVALID', 'L: fehlender/ungueltiger USC-Wert.');
    const plans = [['dc','DC'],['ppPlus','PP+'],['dbPlus','DB+']].filter(([key]) => flag(entry[key], key, policy) === 1).map(([,code]) => code);
    need(plans.length > 0, 'NO_PLAN', 'Keines der drei Merkmale ist 1; manuelle Klaerung.');
    return `USC ${usc}/ ${plans.join(';')}`;
  }
  function validateMap(map) {
    need(map && map.schema === SCHEMA, 'MAP_SCHEMA', 'Falsches Mapping-Format. Mit MAPPING_ERSTELLEN.cmd erzeugen.');
    need(/^[a-f0-9]{64}$/.test(map.payloadSha256 ?? ''), 'MAP_HASH', 'Payload-Pruefsumme fehlt.');
    const p = map.payload;
    need(p && p.rule === RULE && ['DEMO','LOCAL_WORKBOOK'].includes(p.mode), 'MAP_RULE', 'Unbekannte Mapping-Regel.');
    need(validPolicy(policyOf(p)), 'MAP_FLAG_POLICY', 'Unbekannte Merkmalsregel im Snapshot.');
    need(isOutputSheet(p.source?.sheet) && /^[a-f0-9]{64}$/.test(p.source.sha256 ?? ''), 'MAP_SOURCE', 'Quellbindung fehlt.');
    need(Number.isFinite(Date.parse(p.generatedAt)) && p.source.headerLConfirmed === true, 'MAP_META', 'Zeitstempel oder Spaltenfreigabe fehlt.');
    need(p.entries && typeof p.entries === 'object' && !Array.isArray(p.entries), 'MAP_ENTRIES', 'Eintraege fehlen.');
    need(p.blocked && typeof p.blocked === 'object' && !Array.isArray(p.blocked), 'MAP_BLOCKED', 'Sperrliste fehlt.');
    need(Object.keys(p.entries).length <= 200000, 'MAP_SIZE', 'Zu viele Mapping-Eintraege.');
    for (const [key, e] of Object.entries(p.entries)) {
      id(key);
      need(e && e.clientId === key && !Object.hasOwn(p.blocked, key), 'MAP_KEY', 'Kennung oder Sperrstatus widerspruechlich.');
      need(Number.isInteger(e.sourceRow) && e.sourceRow >= 1, 'MAP_ROW', 'Quellzeile fehlt.');
      need(Array.isArray(e.formulas) && e.formulas.every(c => ['B','C','D','E','L'].includes(c)), 'MAP_FORMULAS', 'Formelmetadaten ungueltig.');
      need(policyOf(e) === policyOf(p), 'MAP_FLAG_POLICY', 'Zeile und Mapping haben verschiedene Merkmalsregeln.');
      if(policyOf(p) === BLANK_OMIT_FLAGS) {
        need(Array.isArray(e.blankColumns), 'MAP_BLANK_PROVENANCE', 'Metadaten zu leeren Merkmalen fehlen.');
        const blanks = [['C','dc'],['D','ppPlus'],['E','dbPlus']].filter(([,k])=>e[k]===null).map(([c])=>c);
        need(JSON.stringify(e.blankColumns)===JSON.stringify(blanks), 'MAP_BLANK_PROVENANCE', 'Leere Zellen und Spaltenmetadaten widersprechen sich.');
        need(['dc','ppPlus','dbPlus'].every(k=>e[k]===null || e[k]===0 || e[k]===1), 'FLAG_INVALID', 'Snapshot-Merkmale muessen null, 0 oder 1 sein.');
      }
      need(e.description === description(e), 'MAP_DESCRIPTION', 'Beschreibung stimmt nicht mit Merkmalen ueberein.');
    }
    for (const [key, e] of Object.entries(p.blocked)) {
      id(key);need(Array.isArray(e.codes) && e.codes.length > 0, 'MAP_BLOCKED', 'Ungueltiger gesperrter Datensatz.');
    }
    return p;
  }
  // Legacy snapshots remain strict. New explicit policy preserves blank flags as null.
  const BLOCK_CODES = Object.freeze(['DUPLICATE_ID','FLAG_INVALID','USC_INVALID','NO_PLAN','CELL_ERROR','INVALID_ROW']);
  const BLOCK_TEXT = Object.freeze({
    DUPLICATE_ID:'Spalte B enthält die Kennung mehrfach. Keine Zeile wird automatisch gewählt.',
    FLAG_INVALID:'Ein Merkmal in C/D/E ist nicht verwendbar. Ältere STRICT_BINARY-Mappings sperren auch leere Zellen; mit 0.3.2 aus der XLSX neu exportieren, nicht das JSON entsperren.',
    USC_INVALID:'Spalte L enthält keinen gültigen numerischen USC-Wert.',
    NO_PLAN:'Keines der Merkmale C/D/E ist 1. Für diese Kombination fehlt eine freigegebene Beschreibung.',
    CELL_ERROR:'Eine relevante Zelle enthält einen Excel-Fehler, einen nicht unterstützten Zelltyp oder eine Formel ohne gespeichertes Ergebnis.',
    INVALID_ROW:'Die Bestandszeile ist nicht verwendbar. Quelle lokal prüfen.'
  });
  function rowIssues(row, policy = STRICT_FLAGS) {
    need(validPolicy(policy), 'FLAG_POLICY', 'Unbekannte Merkmalsregel.');
    const out=[];
    for(const c of ['B','C','D','E','L'])if(row.errors?.[c])out.push({code:'CELL_ERROR',column:c,state:'ERROR_OR_CACHE'});
    for(const c of ['C','D','E'])if(!row.errors?.[c]&&!['0','1',...(policy===BLANK_OMIT_FLAGS?['']:[])].includes(text(row[c])))out.push({code:'FLAG_INVALID',column:c,state:text(row[c])?'NOT_BINARY':'EMPTY'});
    if(!row.errors?.L&&!/^\d{1,6}(?:[.,]\d{1,6})?$/.test(text(row.L)))out.push({code:'USC_INVALID',column:'L',state:text(row.L)?'NOT_NUMERIC':'EMPTY'});
    if(['C','D','E'].every(c=>!row.errors?.[c]&&['0',...(policy===BLANK_OMIT_FLAGS?['']:[])].includes(text(row[c]))))out.push({code:'NO_PLAN',column:'CDE',state:'ALL_ZERO'});
    return out;
  }
  function blockInfo(map,key) {
    key=id(key);if(!Object.hasOwn(map.payload.blocked,key))return null;
    const raw=map.payload.blocked[key];
    // Never copy arbitrary strings from a JSON file into the upload diagnostic.
    const codes=[...new Set((raw.codes??[]).map(c=>BLOCK_CODES.includes(c)?c:'INVALID_ROW'))];
    const sourceRows=[...new Set((raw.sourceRows??[]).filter(n=>Number.isInteger(n)&&n>=1&&n<=1048576))].sort((a,b)=>a-b);
    const issues=(Array.isArray(raw.issues)?raw.issues:[]).filter(i=>i&&BLOCK_CODES.includes(i.code)&&['B','C','D','E','L','CDE'].includes(i.column)&&['ERROR_OR_CACHE','NOT_BINARY','NOT_NUMERIC','EMPTY','ALL_ZERO'].includes(i.state)).map(i=>({code:i.code,column:i.column,state:i.state}));
    return {codes,sourceRows,issues,messages:codes.map(c=>BLOCK_TEXT[c]),legacyDetails:!issues.length};
  }
  function lookup(map, key) {
    key = id(key);
    const blocking=blockInfo(map,key);
    if(blocking)throw Object.assign(new Error('MercerID im Bestandsmapping gesperrt. '+blocking.codes.join(', ')+': '+blocking.messages.join(' ')),{code:'ID_BLOCKED',blocking});
    need(Object.hasOwn(map.payload.entries, key), 'ID_NOT_FOUND', 'MercerID / ClientEEID nicht in diesem Mapping gefunden. Die Ticketnummer wird dafür nicht verwendet.');
    const e = map.payload.entries[key];
    need(policyOf(e)===policyOf(map.payload), 'MAP_FLAG_POLICY', 'Zeile/Mapping-Merkmalsregel widerspricht sich.');
    need(e.description === description(e), 'MAP_DESCRIPTION', 'Beschreibung ungueltig.');
    return e;
  }
  function analyzeMail(value) {
    const s = text(value);
    need(s.length >= 3 && s.length <= 120000, 'MAIL_SIZE', 'Mailtext fehlt/zu lang (maximal 120.000 Zeichen).');
    const emails = [...new Set((s.match(/[A-Z0-9.!#$%&'*+/=?^_`{|}~-]{1,64}@[A-Z0-9.-]{1,253}\.[A-Z]{2,63}/gi) ?? []).map(v => v.toLowerCase()))];
    const hints = [];
    const add = (key, source) => {try {key = id(key);if (!hints.some(h => h.clientId === key && h.source === source)) hints.push({clientId:key,source});} catch {} };
    for (const m of s.matchAll(/\bINTL01-(\d{1,15})(?![\w.-])/g)) add(m[1], 'INTL01-Kennung im Text');
    for (const m of s.matchAll(/\b(?:ClientEEID|Employee\s*ID|EmployeeID\s*Number|Personalnummer|MercerID|Username|Benutzername)\s*[:=#]?\s*(\d{1,15})(?!\d)/gi)) add(m[1], 'Beschriftete Kennung im Text');
    for (const email of emails) {
      const m = email.match(/^(\d{1,15})@intel\.com$/i);
      if (m) add(m[1], 'Numerischer Intel-Login im Text (nur Kandidat)');
    }
    const names = [], lines = s.split(/\r?\n/).map(text);
    const addName = (raw, source) => {
      const v = text(raw).replace(/<[^>]*>/g, '').replace(/\([^)]*@[^)]*\)/g, '').trim();
      if (v.length <= 100 && !/@|https?:|\d/i.test(v) && /^[\p{L}][\p{L}\p{M} .,'’\-]{2,}$/u.test(v) && /\s/.test(v) && !names.some(n=>n.name===v)) names.push({name:v,source});
    };
    lines.forEach((line, i) => {
      const m = line.match(/^(?:Von|From|Absender|Name)\s*:\s*(.+)$/i);
      if (m) addName(m[1], 'Beschriftung');
      if (/^(?:Mit freundlichen Gr[üu](?:ß|ss)en|Viele Gr[üu](?:ß|ss)e|Freundliche Gr[üu](?:ß|ss)e|Best regards|Kind regards|Regards|Best|Cheers|Br|MfG)[,.!]?$/i.test(line)) {
        let j=i+1;while(j<lines.length&&!lines[j])j++;if(lines[j]) addName(lines[j], 'Signatur (nur Kandidat)');
      }
    });
    const warnings = [];
    if (emails.length > 1) warnings.push('MEHRERE_ADRESSEN: Absender, Signatur und Antwortziel unterscheiden.');
    if (/private?\s+(?:e-?mail|address|adresse)|(?:do not|don.t|nicht mehr).{0,70}(?:address|adresse|mail)|k[üu]nftig.{0,60}(?:adresse|mail)|weitere.{0,30}kontakte/i.test(s)) warnings.push('ADRESSHINWEIS: Antwortziel manuell pruefen.');
    if (/forwarded message|weitergeleitete nachricht|urspr[üu]ngliche nachricht|original message|on behalf of|im auftrag/i.test(s)) warnings.push('WEITERLEITUNG: Absender ist nicht zwingend die betroffene Person.');
    if (new Set(hints.map(h=>h.clientId)).size > 1) warnings.push('MEHRERE_KENNUNGEN: Keine automatische Personenzuordnung.');
    return {emails, names, idHints:hints, warnings, characters:s.length, automaticIdentity:false, automaticRecipient:false};
  }
  return Object.freeze({SCHEMA,RULE,STRICT_FLAGS,BLANK_OMIT_FLAGS,policyOf,validPolicy,need,fail,text,isOutputSheet,id,flag,selectedMember,description,validateMap,lookup,blockInfo,rowIssues,analyzeMail});
});

return module.exports;})();
const Msg=(()=>{const module={exports:{}};
/* Bounded, read-only MSG subset. MS-CFB + MS-OXMSG. No rendering, network or attachments.
 * Supported: top-level IPM.Note, PR_BODY Unicode or String8 with explicit code page.
 * Unsupported bodies (HTML-only/RTF-only/encrypted) fail; never interpret binary as text.
 */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.MCRMsg=factory();})(globalThis,function(){
 'use strict';
 const FREE=0xffffffff,END=0xfffffffe,FATSECT=0xfffffffd,DIFSECT=0xfffffffc;
 const MAX_FILE=32*1024*1024,MAX_TEXT=120000,MAX_STREAM=8*1024*1024;
 function fail(code,message){throw Object.assign(new Error(message),{code});}
 function need(ok,code,message){if(!ok)fail(code,message);}
 function compound(input){
  const b=input instanceof Uint8Array?input:new Uint8Array(input);
  need(b.byteLength>=512&&b.byteLength<=MAX_FILE,'MSG_SIZE','MSG muss zwischen 512 Byte und 32 MiB gross sein.');
  need([0xd0,0xcf,0x11,0xe0,0xa1,0xb1,0x1a,0xe1].every((x,i)=>b[i]===x),'MSG_FORMAT','Keine Outlook-MSG im Compound-File-Format. Die Originaldatei speichern, nicht umbenennen.');
  const h=new DataView(b.buffer,b.byteOffset,b.byteLength),u32=o=>h.getUint32(o,true),u16=o=>h.getUint16(o,true);
  const version=u16(26),shift=u16(30),sector=2**shift;
  need(u16(28)===0xfffe&&((version===3&&shift===9)||(version===4&&shift===12))&&u16(32)===6&&u32(56)===4096,'MSG_HEADER','Nicht unterstuetzter Compound-File-Header.');
  need(b.length%sector===0,'MSG_TRUNCATED','MSG ist abgeschnitten oder hat eine ungueltige Sektorlaenge.');
  const sectors=b.length/sector-1,words=sector/4;
  need(sectors>0,'MSG_TRUNCATED','MSG enthaelt keine Datensektoren.');
  const getSector=n=>{need(Number.isInteger(n)&&n>=0&&n<sectors,'MSG_SECTOR','Ungueltiger MSG-Sektor.');return b.subarray((n+1)*sector,(n+2)*sector);};
  const ints=data=>{const v=new DataView(data.buffer,data.byteOffset,data.byteLength),a=new Uint32Array(data.length/4);for(let i=0;i<a.length;i++)a[i]=v.getUint32(i*4,true);return a;};
  const nfat=u32(44),ndif=u32(72),fatIds=[];
  need(nfat>0&&nfat<=sectors&&ndif<=sectors,'MSG_FAT','Ungueltige FAT-Laenge.');
  for(let o=76;o<512;o+=4){const n=u32(o);if(n!==FREE)fatIds.push(n);}
  let did=u32(68);const difIds=new Set();
  for(let j=0;j<ndif;j++){
   need(!difIds.has(did),'MSG_CYCLE','Zyklische DIFAT-Kette.');difIds.add(did);
   const arr=ints(getSector(did));for(let i=0;i<words-1;i++)if(arr[i]!==FREE)fatIds.push(arr[i]);did=arr[words-1];
  }
  need((ndif===0?(did===END||did===FREE):did===END)&&fatIds.length===nfat&&new Set(fatIds).size===nfat,'MSG_FAT','Widerspruechliche FAT/DIFAT.');
  const fat=new Uint32Array(nfat*words);
  fatIds.forEach((n,i)=>fat.set(ints(getSector(n)),i*words));
  need(fat.length>=sectors,'MSG_FAT','FAT deckt die Datei nicht ab.');
  for(const n of fatIds)need(fat[n]===FATSECT&&!difIds.has(n),'MSG_FAT','FAT-Sektor falsch markiert.');
  for(const n of difIds)need(fat[n]===DIFSECT,'MSG_FAT','DIFAT-Sektor falsch markiert.');
  let totalRead=0;
  function chain(start,size,unit,table,get,limit,max=MAX_STREAM){
   if(size===0){need(start===END||start===FREE,'MSG_CHAIN','Leerer Stream mit ungueltigem Start.');return new Uint8Array(0);}
   need(size===null||(Number.isSafeInteger(size)&&size>=0&&size<=max),'MSG_STREAM_SIZE','MSG-Textstream zu gross.');
   let n=start;const seen=new Set(),parts=[],expected=size===null?null:Math.ceil(size/unit);
   while(n!==END){
    need(n<limit&&n<table.length,'MSG_CHAIN','Abgebrochene Stream-Kette.');
    need(!seen.has(n),'MSG_CYCLE','Zyklische Stream-Kette.');seen.add(n);
    need(seen.size*unit<=max+unit&&(expected===null||seen.size<=expected),'MSG_CHAIN','Stream-Kette laenger als erlaubt.');
    parts.push(get(n));n=table[n];
   }
   need(expected===null||parts.length===expected,'MSG_TRUNCATED','MSG-Stream ist abgeschnitten.');
   const length=size===null?parts.length*unit:size;totalRead+=length;
   need(totalRead<=MAX_FILE*3,'MSG_BUDGET','MSG-Leselimit erreicht.');
   const out=new Uint8Array(length);let at=0;for(const p of parts){const n=Math.min(p.length,length-at);out.set(p.subarray(0,n),at);at+=n;}return out;
  }
  const directory=chain(u32(48),null,sector,fat,getSector,sectors,4*1024*1024);
  need(directory.length>=128,'MSG_DIRECTORY','MSG-Verzeichnis fehlt.');
  const d=new DataView(directory.buffer),count=directory.length/128;
  const entry=index=>{
   need(Number.isInteger(index)&&index>=0&&index<count,'MSG_DIRECTORY','Ungueltiger Verzeichniseintrag.');
   const o=index*128,n=d.getUint16(o+64,true),type=d.getUint8(o+66);
   need(n>=2&&n<=64&&n%2===0,'MSG_DIRECTORY','Ungueltiger Streamname.');
   const name=new TextDecoder('utf-16le',{fatal:true}).decode(directory.subarray(o,o+n-2));
   return {name,type,left:d.getUint32(o+68,true),right:d.getUint32(o+72,true),child:d.getUint32(o+76,true),start:d.getUint32(o+116,true),size:d.getUint32(o+120,true)+d.getUint32(o+124,true)*4294967296};
  };
  const root=entry(0);need(root.type===5,'MSG_DIRECTORY','Root-Storage fehlt.');
  const rootEntries=new Map(),stack=[root.child],seen=new Set();
  while(stack.length){
   const index=stack.pop();if(index===FREE)continue;
   need(index!==0&&!seen.has(index),'MSG_DIRECTORY_CYCLE','Zyklisches MSG-Verzeichnis.');seen.add(index);
   const e=entry(index);need([1,2].includes(e.type),'MSG_DIRECTORY','Ungueltiger Eintrag im Root-Storage.');
   const key=e.name.toUpperCase();need(!rootEntries.has(key),'MSG_DUPLICATE','Doppelte MSG-Eigenschaft.');rootEntries.set(key,e);
   stack.push(e.left,e.right); // Intentionally never follow e.child (attachment/message storage).
  }
  const nmini=u32(64);need(nmini<=sectors,'MSG_MINIFAT','Ungueltige MiniFAT-Laenge.');
  const miniFat=ints(chain(u32(60),nmini*sector,sector,fat,getSector,sectors));
  const miniStream=chain(root.start,root.size,sector,fat,getSector,sectors,MAX_FILE);
  const read=name=>{
   const e=rootEntries.get(name.toUpperCase());if(!e||e.type!==2)return null;
   if(e.size>=4096)return chain(e.start,e.size,sector,fat,getSector,sectors);
   const total=Math.floor(miniStream.length/64);
   return chain(e.start,e.size,64,miniFat,n=>miniStream.subarray(n*64,(n+1)*64),total);
  };
  return {read,has:name=>rootEntries.has(name.toUpperCase()),version,rootStreams:[...rootEntries.values()].filter(e=>e.type===2).length};
 }
 function parseMsg(input){
  const c=compound(input),warnings=[];
  const props=c.read('__properties_version1.0');
  need(props&&props.length>=32&&(props.length-32)%16===0,'MSG_PROPERTIES','MSG-Eigenschaftstabelle fehlt oder ist beschaedigt.');
  const view=new DataView(props.buffer,props.byteOffset,props.byteLength),fixed=new Map();
  for(let i=32;i+16<=props.length;i+=16){const type=view.getUint16(i,true),pid=view.getUint16(i+2,true);if(type===3){need(!fixed.has(pid),'MSG_DUPLICATE','Doppelte feste MSG-Eigenschaft.');fixed.set(pid,view.getUint32(i+8,true));}}
  const page=fixed.get(0x3ffd)??fixed.get(0x3fde),encodings={65001:'utf-8',1250:'windows-1250',1251:'windows-1251',1252:'windows-1252',1253:'windows-1253',1254:'windows-1254',1255:'windows-1255',1256:'windows-1256',1257:'windows-1257',1258:'windows-1258',932:'shift_jis',936:'gbk',949:'euc-kr',950:'big5',20127:'utf-8'};
  const trim=value=>value.replace(/\0+$/g,'').replace(/\r\n?/g,'\n');
  function string(pid,limit=MAX_TEXT){
   const tag=pid.toString(16).padStart(4,'0').toUpperCase(),u=c.read('__substg1.0_'+tag+'001F');let raw,result;
   try{
    if(u!==null){need(u.length%2===0,'MSG_UNICODE','Ungueltige Unicode-Laenge.');result=new TextDecoder('utf-16le',{fatal:true}).decode(u);}
    else if((raw=c.read('__substg1.0_'+tag+'001E'))!==null){
     const ascii=raw.every(x=>x<128);need(ascii||encodings[page],'MSG_CODEPAGE','ANSI-MSG ohne unterstuetzte Zeichensatzangabe. Mailtext manuell als Text uebernehmen.');
     result=new TextDecoder(ascii?'utf-8':encodings[page],{fatal:true}).decode(raw);
    }else return '';
   }catch(e){if(e.code)throw e;fail('MSG_ENCODING','Zeichensatz konnte nicht eindeutig gelesen werden.');}
   result=trim(result);need(!result.includes('\0')&&!result.includes('\ufffd'),'MSG_ENCODING','Ungueltige Zeichen im MSG-Text.');
   need(result.length<=limit,'MSG_TEXT_SIZE','Nachricht/Metadaten zu lang fuer diesen Helfer.');return result;
  }
  const messageClass=string(0x001a,256);
  need(/^IPM\.Note(?:$|\.)/i.test(messageClass),'MSG_CLASS','Keine unterstuetzte E-Mail-MSG (IPM.Note).');
  need(!/SMIME|Secure|Encrypted/i.test(messageClass),'MSG_ENCRYPTED','Geschuetzte/verschluesselte MSG wird nicht automatisch ausgewertet.');
  const body=string(0x1000);
  if(!body.trim()){
   if(c.has('__substg1.0_10090102'))fail('MSG_RTF_ONLY','Nur RTF/komprimierter Inhalt vorhanden. Im Helfer alternativ Mailtext selbst einfuegen oder als UTF-8 .txt auswaehlen.');
   if(c.has('__substg1.0_10130102')||c.has('__substg1.0_1013001F'))fail('MSG_HTML_ONLY','Nur HTML-Inhalt vorhanden. Keine HTML-Ausfuehrung; Mailtext im Helfer manuell uebernehmen.');
   fail('MSG_BODY_MISSING','Kein lesbarer Klartext in der MSG. Mailtext manuell uebernehmen.');
  }
  const senderName=string(0x0c1a,512),senderEmail=string(0x5d01,512)||string(0x0c1f,512),subject=string(0x0037,2048);
  // Do not return attachment names/data, transport headers, entry IDs or body HTML.
  return {format:'MSG',subject,senderName,senderEmail,body,warnings,diagnostic:{cfbVersion:c.version,rootStreams:c.rootStreams,plainText:true,attachmentsRead:false}};
 }
 function parseText(input){
  const b=input instanceof Uint8Array?input:new Uint8Array(input);need(b.length<=512000,'MAIL_SIZE','Textdatei zu gross.');let body;
  try{body=new TextDecoder('utf-8',{fatal:true}).decode(b).replace(/^\ufeff/,'');}catch{fail('TEXT_ENCODING','TXT bitte als UTF-8 speichern.');}
  need(body.trim().length>=3&&body.length<=MAX_TEXT&&!body.includes('\0'),'MAIL_SIZE','Kein gueltiger UTF-8-Mailtext (max. 120.000 Zeichen).');
  return {format:'TXT',subject:'',senderName:'',senderEmail:'',body,warnings:['TXT_OHNE_DATEIHEADER'],diagnostic:{plainText:true,attachmentsRead:false}};
 }
 return Object.freeze({parseMsg,parseText,MAX_FILE,MAX_TEXT});
});

return module.exports;})();
const Person=(()=>{const module={exports:{}};
/* Conservative name hints, not identity or gender inference. All splits need review. */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.MCRPerson=factory();})(globalThis,function(){
 'use strict';
 const clean=v=>String(v??'').normalize('NFC').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();
 const norm=v=>clean(v).toLocaleLowerCase('de-DE').replace(/[.,]/g,'').replace(/\s+/g,' ');
 const reject=/\b(?:gmbh|support|team|service|deutschland|kundendienst|beratung|damen|herren|adresse|anschrift|straße|strasse|street|geburtsdatum|freundlichen|grüßen|grüssen|regards|danke|please|kindly|mitteilen|können|meine|ihre|hier|leaving|intel|mercer)\b/i;
 function plausible(raw){const v=clean(raw);return v.length>=3&&v.length<=100&&!reject.test(v)&&/^[\p{L}\p{M}][\p{L}\p{M} .,'’\-]+$/u.test(v)&&v.split(/\s+/).length>=2&&v.split(/\s+/).length<=7&&!/\b[A-ZÄÖÜ]{1}\.$/.test(v);}
 function split(raw){
  const display=clean(raw).replace(/^(?:(?:Dr|Prof)\.?\s+)+/i,'').replace(/^(?:Herr|Frau|Mr|Ms|Mrs)\.?\s+/i,'');
  let firstName='',lastName='',needsSplit=false;
  if(display.split(',').length===2){[lastName,firstName]=display.split(',').map(clean);}
  else {const tokens=display.split(' ');if(tokens.length===2){[firstName,lastName]=tokens;}else if(tokens.length>2&&/^(?:von|van|de|del|der|den|du|le|la|zu|zur)$/i.test(tokens[1])){firstName=tokens[0];lastName=tokens.slice(1).join(' ');}else needsSplit=true;}
  return {display,firstName,lastName,needsSplit,reviewRequired:true};
 }
 function candidates(mail){
  const names=[],lines=String(mail.body??'').split(/\r?\n/).map(clean);
  const add=(raw,source)=>{
   const v=clean(raw).replace(/<[^>]*>/g,'').replace(/^"|"$/g,'').trim();if(!plausible(v))return;
   let e=names.find(n=>norm(n.name)===norm(v));if(e){if(!e.sources.includes(source))e.sources.push(source);}else names.push({name:v,sources:[source],...split(v)});
  };
  lines.forEach((line,i)=>{
   const m=line.match(/^(?:Name|Kunde|Kundin|Versicherte(?:r)?|Mitarbeiter(?:in)?)\s*:\s*(.+)$/i);if(m)add(m[1],'Beschrifteter Name');
   if(/^(?:hier\s+)?(?:ist\s+)?(?:meine\s+)?(?:vollst[äa]ndige\s+)?(?:adresse|anschrift)\s*:\s*$/i.test(line)){
    let j=i+1;while(j<lines.length&&!lines[j])j++;if(lines[j])add(lines[j],'Adressblock');
   }
   if(/^(?:Mit freundlichen Gr[üu](?:ß|ss)en|Viele Gr[üu](?:ß|ss)e|Freundliche Gr[üu](?:ß|ss)e|Best regards|Kind regards|Regards|Best|Cheers|Br|MfG)[,.!]?$/i.test(line)){
    let j=i+1;while(j<lines.length&&!lines[j])j++;if(lines[j])add(lines[j],'Signatur');
   }
   const from=line.match(/^(?:Von|From|Absender)\s*:\s*(.+)$/i);if(from)add(from[1],'Header im Text (kann weitergeleitet sein)');
  });
  add(mail.senderName,'Absendername der MSG (nicht zwingend Kunde)');
  return names.slice(0,24);
 }
 function query(first,last){
  first=clean(first);last=clean(last);
  if(!first||!last||first.length>80||last.length>100||![first,last].every(x=>/^[\p{L}\p{M}][\p{L}\p{M} .'’\-]*$/u.test(x)))throw Object.assign(new Error('Vorname und Nachname bitte getrennt prüfen. Nur Namen, keine Kennung eingeben.'),{code:'NAME_REQUIRED'});
  return {firstName:first,lastName:last,query:last+' '+first};
 }
 function memberMatches(display,person){
  const prefix=clean(display).split(/\s*\(?INTL01-/)[0].replace(/[\s(]+$/,'');
  return [person.lastName+' '+person.firstName,person.lastName+', '+person.firstName].some(x=>norm(prefix)===norm(x));
 }

 // Explicit identifiers stay separate from contextual candidates. A bare number
 // anywhere in a message is never treated as a customer identifier.
 function identifierHints(mail,explicit,names){
  const out=[];
  const add=(clientId,source,strength)=>{
   if(!/^\d{1,15}$/.test(clientId)||/^0+$/.test(clientId))return;
   const old=out.find(x=>x.clientId===clientId&&x.strength===strength);
   if(!old)out.push({clientId,source,strength});
  };
  for(const h of explicit??[])add(h.clientId,h.source,'EXPLICIT');
  const escape=v=>v.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
  const text=[mail.subject??'',mail.body??''].join('\n').normalize('NFC');
  for(const name of names??[]){
   if(!name.firstName||!name.lastName)continue;
   for(const order of [[name.firstName,name.lastName],[name.lastName,name.firstName]]){
    const pattern=order.map(v=>v.split(/\s+/).map(escape).join('\\s+')).join('\\s*,?\\s+');
    // Include wrapped subject lines, but no dates/phone fragments/email localparts.
    const re=new RegExp('(?:^|[^\\p{L}\\p{M}])'+pattern+'\\s*(?:[,;/]\\s*|\\r?\\n\\s*)([0-9]{7,10})(?![0-9.@/\\-])','gimu');
    for(const m of text.matchAll(re))add(m[1],'Ziffernfolge neben einem Namenshinweis (manuell prüfen)','CONTEXTUAL');
   }
  }
  return out;
 }
 function personId(value){
  const s=clean(value);if(!s)return null;
  const m=s.match(/^(?:INTL01-)?(\d{1,15})$/i);
  if(!m||/^0+$/.test(m[1]))throw Object.assign(new Error('MercerID bitte als Ziffern oder INTL01-Ziffern angeben. Keine Ticket-/Dokumentnummer.'),{code:'PERSON_ID_INVALID'});
  return m[1];
 }
 return Object.freeze({clean,norm,plausible,split,candidates,query,memberMatches,identifierHints,personId});
});

return module.exports;})();
const Widget=(()=>{const module={exports:{}};
/* MCR 0.3.3: bounded discovery of an ICEfaces widget by live INPUT identity.
 * The field ID need not be the registry key; the popup ID is never invented.
 * Reads only known registry/monitor slots. No eval, hidden writes or submission.
 * Delivered count is NOT database-wide uniqueness: reviewed name AND ID needed.
 */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.MCRMemberWidget=factory();})(globalThis,function(){
 'use strict';
 const LIMIT=512;
 function visible(n){try{return !!n?.isConnected&&n.getClientRects().length>0&&n.ownerDocument.defaultView.getComputedStyle(n).visibility!=='hidden'&&n.ownerDocument.defaultView.getComputedStyle(n).display!=='none';}catch{return false;}}
 // Do not run arbitrary getters while enumerating registry entries.
 function values(object,meta){
  if(!object||!['object','function'].includes(typeof object))return [];
  const keys=Object.getOwnPropertyNames(object);
  if(keys.length>LIMIT){meta.scanLimited=true;return [];}
  const out=[];
  for(const key of keys){const d=Object.getOwnPropertyDescriptor(object,key);if(d&&Object.hasOwn(d,'value')&&d.value&&typeof d.value==='object')out.push(d.value);}
  return out;
 }
 function inspect(field){
  const safe={adapter:'ICE_COMPAT_V2',state:'NO_FIELD',registryPresent:false,registryUnambiguous:false,fieldBound:false,listPresent:false,listBound:false,entryAccessor:false,entryCount:null,domEntryCount:null,indicesConsistent:false,active:null,inTransit:null,changed:null,hasFocus:null,registrySlots:0,directMatches:0,identityMatches:0,monitorMatches:0,scanLimited:false,bindingRoute:null};
  const done=(state,extra={})=>({safe:{...safe,state},...extra});
  if(field?.tagName!=='INPUT'||field.id!=='mainForm:member-value-id'||!visible(field))return done('NO_FIELD');
  try{
   const w=field.ownerDocument.defaultView;
   const registries=[w.Ice?.Scriptaculous?.Autocompleter?.Finder,w.Autocompleter?.Finder,w.Ice?.Autocompleter?.Finder];
   const found=new Set(),direct=new Set(),identity=new Set(),monitor=new Set();
   const aliases=new Set([field.id,field.name,field.getAttribute?.('name')].filter(x=>typeof x==='string'&&x));
   // Only actual DOM aliases, no guessed component ID substitutions.
   let parent=field.parentElement;
   for(let i=0;parent&&i<2;i++,parent=parent.parentElement){if(['BODY','HTML','FORM'].includes(parent.tagName))break;if(parent.id)aliases.add(parent.id);}
   for(const finder of new Set(registries.filter(Boolean))){
    safe.registryPresent=true;
    if(typeof finder.find==='function')for(const alias of aliases){
     let instance;try{instance=finder.find(alias);}catch{continue;}
     if(instance){direct.add(instance);if(instance.element===field)found.add(instance);}
    }
    for(const instance of values(finder.list,safe)){
     safe.registrySlots++;
     if(instance.element===field){identity.add(instance);found.add(instance);}
    }
   }
   const monitors=w.Ice?.StateMon?.monitors;
   for(const m of values(monitors,safe))if(m?.type==='Autocompleter'&&m.object?.element===field){monitor.add(m.object);found.add(m.object);}
   safe.directMatches=direct.size;safe.identityMatches=identity.size;safe.monitorMatches=monitor.size;
   if(safe.scanLimited)return done('SCAN_LIMIT');
   // A conflicting object returned by an EXACT input-ID lookup is unsafe.
   for(const finder of new Set(registries.filter(Boolean)))if(typeof finder.find==='function'){
    let object;try{object=finder.find(field.id);}catch{continue;}
    if(object&&object.element!==field)return done('BINDING_MISMATCH');
   }
   if(found.size!==1)return done(found.size?'AMBIGUOUS_REGISTRY':'REGISTRY_UNAVAILABLE');
   safe.registryUnambiguous=true;const instance=[...found][0];
   safe.bindingRoute=identity.has(instance)?'REGISTRY_FIELD_IDENTITY':monitor.has(instance)?'MONITOR_FIELD_IDENTITY':'DIRECT_FIELD_IDENTITY';
   safe.fieldBound=instance.element===field;
   const list=instance.update;safe.listPresent=!!list;
   safe.listBound=!!list&&list.tagName==='DIV'&&list.ownerDocument===field.ownerDocument&&!!list.isConnected&&!!list.id&&field.ownerDocument.getElementById(list.id)===list;
   safe.entryAccessor=typeof instance.getEntry==='function';
   if(!safe.fieldBound||!safe.listBound||!safe.entryAccessor)return done('BINDING_MISMATCH');
   for(const k of ['active','inTransit','changed','hasFocus'])safe[k]=typeof instance[k]==='boolean'?instance[k]:null;
   const count=instance.entryCount;
   if(!Number.isInteger(count)||count<0||count>200)return done('INVALID_COUNT');
   safe.entryCount=count;
   const wrapper=list.firstElementChild,nodes=wrapper?[...wrapper.children]:[];safe.domEntryCount=nodes.length;
   if(safe.inTransit===true||safe.changed===true)return done('BUSY');
   if(!visible(list)||safe.active!==true||safe.hasFocus!==true)return done('CLOSED');
   if(safe.inTransit!==false||safe.changed!==false)return done('READINESS_UNKNOWN');
   if(count!==nodes.length||list.children.length!==1)return done('COUNT_MISMATCH');
   const entries=[];
   for(let i=0;i<count;i++){
    const n=instance.getEntry(i);
    if(n!==nodes[i]||n.tagName!=='DIV'||n.autocompleteIndex!==i||!list.contains(n))return done('ENTRY_SHAPE_MISMATCH');
    entries.push(n);
   }
   safe.indicesConsistent=true;
   if(entries.some(n=>!visible(n)))return done('HIDDEN_ENTRY');
   return done(count===1?'SINGLE_RENDERED':count>1?'MULTIPLE_RENDERED':'EMPTY',{instance,list,entries});
  }catch{return done('ADAPTER_UNAVAILABLE');}
 }
 return Object.freeze({inspect});
});

return module.exports;})();
const ListDOM=(()=>{const module={exports:{}};
/* 0.3.3 local DOM fallback. No page-wide name search and no click in this module.
 * It can describe a list only if linked by ARIA, a known ICE list next to the
 * field, or a one-input component wrapper. A learned route additionally requires
 * a genuine user choice followed by the populated matching MercerID profile.
 * Bindings live in memory, tied to the current document/field parent, never JSON.
 */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.MCRMemberList=factory();})(globalThis,function(){
 'use strict';
 const MAX=200,containers=new Set(['DIV','UL','OL','TABLE','TBODY']),rowTags=new Set(['DIV','LI','TR','BUTTON']);
 function visible(n){try{return !!n?.isConnected&&n.getClientRects().length>0&&n.ownerDocument.defaultView.getComputedStyle(n).display!=='none'&&n.ownerDocument.defaultView.getComputedStyle(n).visibility!=='hidden';}catch{return false;}}
 function keys(text){return [...String(text??'').matchAll(/\bINTL01-(\d{1,15})(?![\w.-])/g)].map(m=>m[1]);}
 function rowText(n){return visible(n)?n.innerText??n.textContent??'':n.textContent??'';}
 function shape(root){
  const out={state:'ROWS_UNQUALIFIED',count:null,hidden:false};
  if(root.getAttribute?.('aria-busy')==='true'||root.querySelector?.('[aria-busy="true"]'))return {...out,state:'BUSY'};
  // Descend structural single-child wrappers, but NEVER accept an outer row
  // merely because a deeper footer/loading/unknown row failed validation.
  let wrapper=root;
  for(let depth=0;wrapper&&depth<5;depth++){
   const children=[...wrapper.children];
   if(children.length>MAX)return {...out,state:'LIST_LIMIT'};
   if(children.length===1&&containers.has(children[0].tagName)){
    const child=children[0],directText=[...child.childNodes].some(n=>n.nodeType===3&&n.textContent.trim());
    const nestedRows=[...child.children].some(n=>containers.has(n.tagName)||rowTags.has(n.tagName));
    if(!directText&&nestedRows){wrapper=child;continue;}
   }
   if(!children.length||!children.every(n=>rowTags.has(n.tagName)&&keys(rowText(n)).length===1))return out;
   const hidden=children.some(n=>!visible(n));
   return {state:hidden?'HIDDEN_ENTRY':children.length===1?'SINGLE_RENDERED':'MULTIPLE_RENDERED',count:children.length,hidden,wrapper,entries:children};
  }
  return out;
 }
 function roots(field){
  const doc=field.ownerDocument,out=new Map();
  const add=(n,route,anchor)=>{if(n&&containers.has(n.tagName)&&n!==field&&!n.contains(field)&&n.isConnected&&!out.has(n))out.set(n,{root:n,route,anchor});};
  for(const ref of (field.getAttribute('aria-controls')||field.getAttribute('aria-owns')||'').split(/\s+/).filter(Boolean))add(doc.getElementById(ref),'ARIA_LINK',field.parentElement);
  let p=field.parentElement;
  for(let depth=0;p&&depth<3;depth++,p=p.parentElement){
   if(['FORM','BODY','HTML','MAIN','SECTION'].includes(p.tagName))break;
   const controls=[...p.querySelectorAll('input:not([type="hidden"]),select,textarea')];
   if(controls.length!==1||controls[0]!==field)break;
   // Only this small component wrapper, not the rest of the COMARCH form.
   for(const n of p.querySelectorAll('.iceSelInpTxtList,[role="listbox"]'))add(n,'COMPONENT_LIST',p);
   if(depth===0){for(const n of p.children)if(n!==field&&containers.has(n.tagName))add(n,'ONE_INPUT_SIBLING',p);}
  }
  return [...out.values()].slice(0,12);
 }
 function inspect(field,binding=null){
  const safe={adapter:'LOCAL_DOM_V1',state:'NO_FIELD',candidateContainers:0,qualifiedContainers:0,entryCount:null,route:null,learned:false,hiddenEntries:false};
  const done=(state,more={})=>({safe:{...safe,state},...more});
  if(!field||field.tagName!=='INPUT'||field.id!=='mainForm:member-value-id'||!visible(field))return done('NO_FIELD');
  try{
   let candidates=roots(field);safe.candidateContainers=candidates.length;
   if(binding){
    if(binding.doc!==field.ownerDocument||binding.field!==field||!binding.anchor.isConnected)return done('LEARNED_BINDING_CHANGED');
    const n=binding.rootId?field.ownerDocument.getElementById(binding.rootId):binding.root;
    if(binding.route==='OBSERVED_POPUP'){
     const semantic=n&&(n.getAttribute?.('role')==='listbox'||n.classList?.contains('iceSelInpTxtList'));
     candidates=semantic&&binding.anchor===field.parentElement&&n.ownerDocument===field.ownerDocument&&!n.contains(field)?[{root:n,route:'OBSERVED_POPUP',anchor:binding.anchor}]:[];
    }
    candidates=candidates.filter(x=>x.root===n&&x.anchor===binding.anchor&&x.route===binding.route);
    if(candidates.length!==1)return done('LEARNED_BINDING_CHANGED');
    safe.learned=true;
   }
   const present=candidates.filter(x=>visible(x.root));
   if(!present.length)return done('NO_OPEN_BOUND_LIST');
   const recognized=present.map(x=>({...x,...shape(x.root)})).filter(x=>x.entries);
   // Nested descriptions of the very same rows are one list, not two.
   const unique=[];for(const x of recognized)if(!unique.some(y=>y.entries.length===x.entries.length&&y.entries.every((n,i)=>n===x.entries[i])))unique.push(x);
   safe.qualifiedContainers=unique.length;
   if(unique.length!==1)return done(unique.length?'AMBIGUOUS_LIST':'ROWS_UNQUALIFIED');
   const hit=unique[0];safe.entryCount=hit.count;safe.route=hit.route;safe.hiddenEntries=hit.hidden;
   return done(hit.state,{list:hit.root,entries:hit.entries,binding:{doc:field.ownerDocument,field,anchor:hit.anchor,route:hit.route,root:hit.root,rootId:hit.root.id||null}});
  }catch{return done('DOM_INSPECTION_ERROR');}
 }
 // A portal popup may not be adjacent to its input. Learn ONLY after a real
 // user click and subsequent matching populated profile (enforced by caller).
 function capture(field,target){
  const local=inspect(field);
  if(local.entries?.some(row=>row===target||row.contains(target)))return local;
  if(target?.ownerDocument!==field?.ownerDocument)return local;
  for(let n=target,depth=0;n&&depth<7;n=n.parentElement,depth++){
   if(['FORM','HTML','BODY'].includes(n.tagName))break;
   if(n.getAttribute?.('role')!=='listbox'&&!n.classList?.contains('iceSelInpTxtList'))continue;
   if(n.contains(field)||!visible(n))continue;
   const shaped=shape(n);
   if(!shaped.entries?.some(row=>row===target||row.contains(target)))continue;
   return {safe:{adapter:'LOCAL_DOM_V1',state:shaped.state,candidateContainers:1,qualifiedContainers:1,entryCount:shaped.count,route:'OBSERVED_POPUP',learned:false,hiddenEntries:shaped.hidden},list:n,entries:shaped.entries,binding:{doc:field.ownerDocument,field,anchor:field.parentElement,route:'OBSERVED_POPUP',root:n,rootId:n.id||null}};
  }
  return local;
 }
 function clickShape(target){
  const tags=new Set(['DIV','SPAN','LABEL','LI','UL','OL','TABLE','TBODY','TR','TD','BUTTON','INPUT','A','P']);
  const out=[];let n=target;
  for(let i=0;n&&i<6;i++,n=n.parentElement){if(['HTML','BODY','FORM'].includes(n.tagName))break;
   out.push({tag:tags.has(n.tagName)?n.tagName:'OTHER',children:Math.min(n.children?.length??0,201),hasId:!!n.id,roleList:n.getAttribute?.('role')==='listbox',roleOption:n.getAttribute?.('role')==='option',iceList:!!n.classList?.contains('iceSelInpTxtList'),iceRow:!!n.classList?.contains('iceSelInpTxtRow'),indexed:Number.isInteger(n.autocompleteIndex)});
  }return out;
 }
 return Object.freeze({inspect,capture,clickShape});
});

return module.exports;})();
const Profile=(()=>{const module={exports:{}};
/* 0.3.4. Bounded semantic profile reader, not a search for numbers in the page.
 * Reads only the visible output paired with a MercerID label. Supports nested
 * table cells, label/value wrappers and text nodes. No input writes or I/O.
 * An explicit per-page output binding is supported when markup is unfamiliar.
 */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.MCRMemberProfile=factory();})(globalThis,function(){
 'use strict';
 const norm=v=>String(v??'').replace(/[\u00a0\u202f]/g,' ').replace(/[\u200b\ufeff]/g,'').replace(/\s+/g,' ').trim();
 const isLabel=v=>/^Mercer\s*ID\s*:?$/i.test(norm(v));
 function visible(n){try{return !!n?.isConnected&&n.getClientRects().length>0&&n.ownerDocument.defaultView.getComputedStyle(n).visibility!=='hidden'&&n.ownerDocument.defaultView.getComputedStyle(n).display!=='none';}catch{return false;}}
 function atomic(value){const m=norm(value).match(/^(?:Mercer\s*ID\s*:\s*)?(?:INTL01\s*-\s*)?(\d{1,15})$/i);return m&&!/^0+$/.test(m[1])?m[1]:null;}
 function excluded(n,field){
  if(!n||n===field||n.contains?.(field)||!visible(n)||n.ownerDocument!==field.ownerDocument)return true;
  if(n.closest?.('[role="listbox"],[role="option"],.iceSelInpTxtList,#__mcr_mail_assistant_v3'))return true;
  if(n.isContentEditable)return true;
  if(n.matches?.('input:not([readonly]),textarea:not([readonly]),button,select,script,style,iframe,frame'))return true;
  // Custom suggestion rows have an actual mousedown callback, unlike output.
  for(let p=n,depth=0;p&&depth<5;p=p.parentElement,depth++){
   if(['BODY','HTML','FORM'].includes(p.tagName))break;
   if(typeof p.onmousedown==='function'||p.getAttribute?.('role')==='option')return true;
  }
  return false;
 }
 function read(n,field){
  if(excluded(n,field))return null;
  if(n.querySelector?.('input:not([readonly]),textarea:not([readonly]),select,button,iframe,frame'))return null;
  return atomic(n.value??n.innerText??n.textContent);
 }
 function inspect(field,binding=null){
  const safe={state:'NO_FIELD',labelCount:0,pairCount:0,validOutputCount:0,route:null,bound:false};
  const ids=new Set(),values=new Set(),routes=new Set();let labelFound=false;
  const done=()=>({labelFound,ambiguous:ids.size>1,clientId:ids.size===1?[...ids][0]:null,safe:{...safe,state:ids.size>1?'AMBIGUOUS':ids.size===1?'PROFILE_READY':labelFound?'PROFILE_EMPTY_OR_UNBOUND':'NO_PROFILE_LABEL',validOutputCount:values.size,route:routes.size===1?[...routes][0]:routes.size?'MULTIPLE_PATHS':null}});
  if(field?.tagName!=='INPUT'||field.id!=='mainForm:member-value-id'||!visible(field))return done();
  const doc=field.ownerDocument,scope=field.closest('form')??doc;
  if(binding&&binding.doc===doc&&binding.scope===scope&&binding.field===field){
   const n=binding.element;
   if(n?.isConnected&&!excluded(n,field)&&scope.contains(n)){
    const key=read(n,field);labelFound=true;safe.bound=true;safe.pairCount++;
    if(key){ids.add(key);values.add(n);routes.add('USER_BOUND_OUTPUT');}
   }
  }
  const take=(n,route)=>{if(!n||excluded(n,field))return;safe.pairCount++;const key=read(n,field);if(key){ids.add(key);values.add(n);routes.add(route);}};
  // Hard bounds, and no descent into any iframe (especially the mail preview).
  const nodes=[...scope.querySelectorAll('label,span,td,th,div,b,strong,dt,dd,p')];
  if(nodes.length>15000){safe.state='SCAN_LIMIT';return {labelFound:false,ambiguous:true,clientId:null,safe};}
  for(const label of nodes){
   if(!isLabel(label.textContent)||excluded(label,field))continue;
   if([...label.children].some(child=>isLabel(child.textContent)))continue;
   labelFound=true;safe.labelCount++;
   if(label.htmlFor)take(doc.getElementById(label.htmlFor),'LABEL_FOR');
   let n=label;
   for(let depth=0;n&&depth<6;depth++){
    // Only cross wrappers that contain exactly this label, not an entire row.
    take(n.nextElementSibling,depth?'WRAPPED_LABEL_VALUE':'LABEL_NEXT');
    let next=n.nextSibling;
    while(next?.nodeType===3&&!norm(next.textContent))next=next.nextSibling;
    if(next?.nodeType===3){const key=atomic(next.textContent);if(key&&visible(n.parentElement)){ids.add(key);values.add(next);routes.add('LABEL_TEXT_NODE');}}
    const parent=n.parentElement;if(!parent||parent===scope||['BODY','HTML','FORM'].includes(parent.tagName))break;
    if(parent.firstElementChild===n&&!n.nextElementSibling)take(parent,'LABEL_INLINE_VALUE');
    if(!isLabel(parent.textContent))break;
    n=parent;
   }
  }
  return done();
 }
 function bind(field,element){
  if(!field||!element||excluded(element,field))throw Object.assign(new Error('Bitte die sichtbare MercerID-Ausgabe anklicken, nicht Member-Suchfeld, Vorschlag oder Mail.'),{code:'PROFILE_BIND_TARGET'});
  const scope=field.closest('form')??field.ownerDocument;
  const a=field.getBoundingClientRect(),b=element.getBoundingClientRect();
  if(b.top<a.top-80||b.top>a.bottom+600||b.right<a.left-200||b.left>a.right+300)throw Object.assign(new Error('Bitte die MercerID-Stammdaten direkt beim Member-Feld wählen, nicht den Nachrichtenverlauf.'),{code:'PROFILE_BIND_TARGET'});
  if(!scope.contains(element)||!read(element,field))throw Object.assign(new Error('Dieses Element ist keine eindeutige MercerID-Ausgabe im gleichen Formular.'),{code:'PROFILE_BIND_TARGET'});
  return {doc:field.ownerDocument,scope,field,element};
 }
 return Object.freeze({inspect,bind,atomic});
});

return module.exports;})();
const Suggest=(()=>{const module={exports:{}};
/* 0.3.4: COMARCH suggestions.js probe. No registry assumption, request, eval,
 * hidden-ID assignment, bulk-response capture or invocation of iceSubmit.
 * Candidates must be field-bound or explicitly bound by the operator.
 * First-use portal discovery additionally needs the known field initializer,
 * suggestions.js, a near-field popup and per-row mousedown submission handlers.
 * This is rendered-list evidence, never proof of database-wide uniqueness.
 */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.MCRCustomSuggest=factory();})(globalThis,function(){
 'use strict';
 const containers=new Set(['DIV','UL','OL','TABLE','TBODY']),rowTags=new Set(['DIV','LI','TR','BUTTON']);
 function visible(n){try{return !!n?.isConnected&&n.getClientRects().length>0&&n.ownerDocument.defaultView.getComputedStyle(n).visibility!=='hidden'&&n.ownerDocument.defaultView.getComputedStyle(n).display!=='none';}catch{return false;}}
 function source(f){try{return typeof f==='function'?Function.prototype.toString.call(f):'';}catch{return '';}}
 function rowKey(n){const s=n.innerText??n.textContent??'';if(s.length>350)return null;const a=[...s.matchAll(/\bINTL01-(\d{1,15})(?![\w.-])/g)];return a.length===1?a[0][1]:null;}
 function shape(root){
  if(!root||!containers.has(root.tagName)||root.querySelector('input:not([type="hidden"]),textarea,select,iframe,frame')||root.getAttribute('aria-busy')==='true'||root.querySelector('[aria-busy="true"]'))return null;
  let p=root;
  for(let depth=0;p&&depth<4;depth++){
   const rows=[...p.children];if(!rows.length||rows.length>200)return null;
   // A row may have several spans: do not descend into a valid row's details.
   if(rows.every(n=>rowTags.has(n.tagName)&&rowKey(n)&&typeof n.onmousedown==='function'))return {entries:rows,hidden:rows.some(n=>!visible(n))};
   if(rows.length!==1||!containers.has(rows[0].tagName)||typeof rows[0].onmousedown==='function')return null;
   p=rows[0];
  }
  return null;
 }
 function near(field,popup){
  const a=field.getBoundingClientRect(),b=popup.getBoundingClientRect();
  return Math.abs(a.left-b.left)<=32&&b.top>=a.top-4&&b.top<=a.bottom+40&&b.width>=30&&b.width<=Math.max(a.width*2,900)&&b.height<=700;
 }
 function signatures(field){
  const scriptPresent=[...field.ownerDocument.querySelectorAll('script[src]')].some(n=>{try{const u=new URL(n.src,field.ownerDocument.baseURI);return /(?:^|\/)suggestions\.js$/i.test(u.pathname)&&u.origin===field.ownerDocument.location.origin;}catch{return false;}});
  const fieldInitializer=/\b(?:initWithShowAllOption|suggestionsInvokeFromEvent)\s*\(/.test(source(field.onfocus)+' '+source(field.onmouseup)+' '+source(field.onkeyup));
  return {scriptPresent,fieldInitializer};
 }
 function inspect(field,binding=null){
  const safe={adapter:'COMARCH_MOUSEDOWN_V1',state:'NO_FIELD',scriptPresent:false,fieldInitializer:false,candidateContainers:0,entryCount:null,hiddenEntries:false,route:null,event:'mousedown',operatorBound:false};
  const done=(state,rest={})=>({safe:{...safe,state},...rest});
  if(field?.tagName!=='INPUT'||field.id!=='mainForm:member-value-id'||!visible(field))return done('NO_FIELD');
  try{
   Object.assign(safe,signatures(field));const doc=field.ownerDocument,roots=new Set();let route='FIELD_BOUND';
   if(binding){
    if(binding.doc!==doc||binding.field!==field||binding.anchor!==field.parentElement||!binding.root?.isConnected)return done('BINDING_CHANGED');
    roots.add(binding.root);route='USER_BOUND_POPUP';safe.operatorBound=true;
   }else{
    for(const ref of (field.getAttribute('aria-controls')||field.getAttribute('aria-owns')||'').split(/\s+/).filter(Boolean)){
     const n=doc.getElementById(ref);if(n&&!n.contains(field))roots.add(n);
    }
    const parent=field.parentElement;
    if(parent&&!['BODY','HTML','FORM','MAIN','SECTION'].includes(parent.tagName)&&parent.querySelectorAll('input:not([type="hidden"]),textarea,select').length===1){for(const n of parent.children)if(n!==field&&containers.has(n.tagName))roots.add(n);}
    if(!roots.size&&safe.scriptPresent&&safe.fieldInitializer){
     route='SIGNATURE_AND_NEAR_FIELD';
     // Geometry only narrows discovery; activation always targets an actual DOM row.
     const divs=[...doc.querySelectorAll('div')];if(divs.length>4000)return done('SCAN_LIMIT');
     for(const n of divs)if(!n.contains(field)&&visible(n)&&near(field,n)&&shape(n))roots.add(n);
    }
   }
   safe.candidateContainers=roots.size;
   const hits=[];
   for(const n of roots){
    if(!containers.has(n.tagName)||n.contains(field)||!visible(n))continue;
    const s=shape(n);if(!s)continue;
    if(!safe.operatorBound){
     if(!safe.scriptPresent||!safe.fieldInitializer)continue;
     if(!s.entries.every(row=>/\biceSubmit(?:Partial)?\s*\(/.test(source(row.onmousedown))))continue;
    }
    if(!hits.some(x=>x.entries.length===s.entries.length&&x.entries.every((r,i)=>r===s.entries[i])))hits.push({list:n,...s});
   }
   if(hits.length!==1)return done(hits.length?'AMBIGUOUS_POPUP':roots.size?'ROWS_UNQUALIFIED':'NO_BOUND_POPUP');
   const hit=hits[0];safe.entryCount=hit.entries.length;safe.hiddenEntries=hit.hidden;safe.route=route;
   return done(hit.hidden?'HIDDEN_ENTRY':hit.entries.length===1?'SINGLE_RENDERED':'MULTIPLE_RENDERED',{...hit});
  }catch{return done('INSPECTION_ERROR');}
 }
 function capture(field,target){
  if(target?.ownerDocument!==field?.ownerDocument)return null;
  for(let row=target,depth=0;row&&depth<5;row=row.parentElement,depth++){
   if(['HTML','BODY','FORM'].includes(row.tagName)||row.contains(field))return null;
   if(!rowTags.has(row.tagName)||typeof row.onmousedown!=='function'||!rowKey(row))continue;
   for(let p=row.parentElement,d=0;p&&d<3;p=p.parentElement,d++){
    if(!containers.has(p.tagName)||p.contains(field)||!visible(p))break;
    const s=shape(p);
    if(s?.entries.includes(row))return {binding:{doc:field.ownerDocument,field,anchor:field.parentElement,root:p},row,entries:s.entries};
   }
  }
  return null;
 }
 function activate(row){
  if(!visible(row)||typeof row.onmousedown!=='function'||!rowKey(row))throw Object.assign(new Error('Vorschlagszeile wurde verändert. Keine Auswahl ausgelöst.'),{code:'SUGGESTION_CHANGED'});
  const w=row.ownerDocument.defaultView,r=row.getBoundingClientRect();
  // Dispatch exactly the event observed in the user's COMARCH trace. No second
  // click/mouseup/blur and no direct server/iceSubmit call. isTrusted stays false.
  return row.dispatchEvent(new w.MouseEvent('mousedown',{bubbles:true,cancelable:true,button:0,buttons:1,detail:1,view:w,clientX:r.left+r.width/2,clientY:r.top+r.height/2}));
 }
 function exactExpected(field,expectedId,expectedQuery){
  const safe={adapter:'EXACT_MOUSEDOWN_V1',state:'NO_FIELD',scanned:0,matches:0,event:'mousedown'};
  const done=(state,rest={})=>({safe:{...safe,state},...rest});
  if(field?.tagName!=='INPUT'||field.id!=='mainForm:member-value-id'||!visible(field))return done('NO_FIELD');
  try{
   const id=String(expectedId??'').trim(),q=String(expectedQuery??'').normalize('NFC').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim().toLocaleLowerCase('de-DE');
   if(!/^\d{1,15}$/.test(id)||!q)return done('EXPECTED_REQUIRED');
   const doc=field.ownerDocument;
   const scriptPresent=[...doc.querySelectorAll('script[src]')].some(n=>{try{const u=new URL(n.src,doc.baseURI);return /(?:^|\/)suggestions\.js$/i.test(u.pathname)&&u.origin===doc.location.origin;}catch{return false;}});
   if(!scriptPresent)return done('SUGGESTIONS_SCRIPT_MISSING');
   const nodes=[...doc.querySelectorAll('div,li,tr,button,a')];if(nodes.length>16000)return done('SCAN_LIMIT');
   const hits=[];
   for(const n of nodes){
    safe.scanned++;
    if(!visible(n)||typeof n.onmousedown!=='function'||n.contains(field)||field.contains(n))continue;
    const text=(n.innerText??n.textContent??'').normalize('NFC').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();
    if(!text||text.length>350)continue;
    const ids=[...text.matchAll(/\bINTL01-(\d{1,15})(?![\w.-])/g)].map(m=>m[1]);
    if(ids.length!==1||ids[0]!==id)continue;
    const prefix=text.split(/\s*\(?INTL01-/)[0].replace(/[\s(]+$/,'').toLocaleLowerCase('de-DE');
    if(prefix!==q)continue;
    hits.push(n);
   }
   safe.matches=hits.length;
   if(hits.length!==1)return done(hits.length?'AMBIGUOUS_EXACT':'NO_EXACT_MATCH');
   return done('SINGLE_EXACT',{entry:hits[0]});
  }catch{return done('INSPECTION_ERROR');}
 }
 return Object.freeze({inspect,capture,activate,exactExpected});
});

return module.exports;})();
const Description=(()=>{const module={exports:{}};
/* 0.3.5. Field-scoped description binding and one-shot textarea write.
 * No dynamic ID guess, cross-frame scan, submit, focus/blur or storage.
 * Explicit binding is ephemeral and never selects a replacement node by ID.
 */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.MCRDescriptionField=factory();})(globalThis,function(){
 'use strict';
 const norm=v=>String(v??'').normalize('NFC').replace(/[\u00a0\u202f]/g,' ').replace(/[\u200b\ufeff]/g,'').replace(/\s+/g,' ').trim();
 const isLabel=v=>/^Zus(?:ä|ae)tzliche Beschreibung\s*:?$/i.test(norm(v));
 const fail=(code,message)=>{throw Object.assign(new Error(message),{code});};
 const need=(ok,code,message)=>{if(!ok)fail(code,message);};
 const owner=n=>n?.form??n?.closest?.('form')??n?.ownerDocument;
 function visible(n){try{const s=n.ownerDocument.defaultView.getComputedStyle(n);return !!n.isConnected&&n.getClientRects().length>0&&s.visibility!=='hidden'&&s.visibility!=='collapse'&&s.display!=='none'&&!n.closest('[hidden],[inert]');}catch{return false;}}
 function sameScope(member,n){return !!member&&!!n&&member.ownerDocument===n.ownerDocument&&owner(member)===owner(n)&&n.getRootNode()===member.ownerDocument;}
 function shape(member,n){return n?.tagName==='TEXTAREA'&&sameScope(member,n)&&visible(n)&&!n.isContentEditable&&!n.closest('[contenteditable="true"],[role="listbox"],[role="option"],#__mcr_mail_assistant_v3');}
 function editable(n){return !n.disabled&&!n.readOnly&&!n.matches(':disabled')&&n.getAttribute('aria-disabled')!=='true'&&n.getAttribute('aria-readonly')!=='true';}
 // Text of a label/container, deliberately excluding all field values, scripts,
 // hidden nodes and embedded documents. It is never retained in diagnostics.
 function caption(n){
  if(!n||!visible(n))return '';
  let count=0,out='';
  function walk(p){
   if(++count>150||out.length>180)return;
   if(p.nodeType===3){out+=' '+p.textContent;return;}
   if(p.nodeType!==1||p.matches('input,textarea,select,button,script,style,iframe,frame,[hidden],[inert],[contenteditable="true"]')||!visible(p))return;
   for(const child of p.childNodes)walk(child);
  }
  walk(n);return count>150||out.length>180?'':norm(out);
 }
 function linkedNames(n){
  const out=[];for(const label of n.labels??[]){const text=caption(label);if(text)out.push(text);}
  const a=norm(n.getAttribute('aria-label'));if(a)out.push(a);
  const refs=norm(n.getAttribute('aria-labelledby')).split(' ').filter(Boolean);
  if(refs.length&&refs.length<=8){const labels=refs.map(id=>n.ownerDocument.getElementById(id));if(labels.every(Boolean)){const v=norm(labels.map(caption).join(' '));if(v)out.push(v);}}
  return [...new Set(out)];
 }
 function inspect(member,binding=null){
  const safe={adapter:'DESCRIPTION_FIELD_V1',state:'NO_MEMBER_FIELD',route:null,textareaCount:0,labelCount:0,matchCount:0,bound:false,readOnly:false,disabled:false};
  const done=(state,element=null,route=null)=>({element,safe:{...safe,state,route,readOnly:!!element?.readOnly,disabled:!!element&&(element.disabled||element.matches(':disabled'))}});
  if(member?.tagName!=='INPUT'||member.id!=='mainForm:member-value-id'||!visible(member))return done('NO_MEMBER_FIELD');
  const doc=member.ownerDocument,scope=owner(member);
  if(binding){
   safe.bound=true;
   if(binding.member!==member||binding.doc!==doc||binding.scope!==scope||!shape(member,binding.element))return done('BINDING_STALE');
   const names=linkedNames(binding.element);
   if(names.some(n=>!isLabel(n)))return done('BINDING_LABEL_CONFLICT');
   safe.matchCount=1;return done(editable(binding.element)?'BOUND_READY':'NOT_EDITABLE',binding.element,'USER_BOUND_TEXTAREA');
  }
  const all=[...doc.querySelectorAll('textarea')].filter(n=>sameScope(member,n));
  if(all.length>128)return done('SCAN_LIMIT');
  const areas=all.filter(n=>shape(member,n));safe.textareaCount=areas.length;
  const hits=new Map();
  const take=(n,route)=>{if(shape(member,n)&&!linkedNames(n).some(t=>!isLabel(t))&&!hits.has(n))hits.set(n,route);};
  for(const n of areas){if(linkedNames(n).some(isLabel))take(n,'LABEL_ASSOCIATION');}
  const nodes=[...scope.querySelectorAll('label,span,td,th,div,b,strong,dt,dd,p')];
  if(nodes.length>15000)return done('SCAN_LIMIT');
  function takeContainer(n,route){
   if(!n||n===scope||!visible(n)||['FORM','BODY','HTML'].includes(n.tagName))return;
   if(n.tagName==='TEXTAREA'){take(n,route);return;}
   if(n.querySelector('input:not([type="hidden"]),select,button,iframe,frame,[contenteditable="true"]'))return;
   const text=caption(n);if(text&&!isLabel(text))return;
   const targets=[...n.querySelectorAll('textarea')].filter(x=>shape(member,x));
   if(targets.length===1)take(targets[0],route);
  }
  for(const label of nodes){
   if(!visible(label)||!isLabel(caption(label))||label.querySelector('textarea,input,select,iframe,frame'))continue;
   if([...label.children].some(n=>isLabel(caption(n))))continue;
   safe.labelCount++;
   if(label.htmlFor){const target=doc.getElementById(label.htmlFor);take(target,'LABEL_FOR');}
   let n=label;
   for(let depth=0;n&&depth<6;depth++){
    takeContainer(n.nextElementSibling,depth?'WRAPPED_LABEL_VALUE':'LABEL_NEXT');
    const parent=n.parentElement;if(!parent||parent===scope||['FORM','BODY','HTML'].includes(parent.tagName))break;
    takeContainer(parent,'LABEL_LOCAL_CONTAINER');
    // Only cross label-only wrappers, never a row containing another field.
    if(!isLabel(caption(parent))||parent.querySelector('textarea,input,select,button,iframe,frame'))break;
    n=parent;
   }
  }
  safe.matchCount=hits.size;
  if(hits.size!==1)return done(hits.size?'AMBIGUOUS':'NOT_FOUND');
  const [element,route]=[...hits][0];return done(editable(element)?'AUTO_READY':'NOT_EDITABLE',element,route);
 }
 function bind(member,element){
  need(shape(member,element),'DESCRIPTION_BIND_TARGET','Bitte direkt das Textfeld „Zusätzliche Beschreibung“ im gleichen COMARCH-Formular anklicken, nicht die Beschriftung, den Kommentar oder Nachrichteneditor.');
  need(editable(element),'DESCRIPTION_READONLY','Das gewählte Textfeld ist nicht bearbeitbar.');
  need(!linkedNames(element).some(n=>!isLabel(n)),'DESCRIPTION_BIND_CONFLICT','Die technische Beschriftung weist auf ein anderes Feld. Nicht verbunden.');
  const auto=inspect(member);
  need(!auto.element||auto.element===element,'DESCRIPTION_BIND_CONFLICT','Ein anderes Textfeld ist eindeutig als zusätzliche Beschreibung beschriftet. Keine Verbindung zum abweichenden Feld.');
  return {member,element,doc:member.ownerDocument,scope:owner(member)};
 }
 function assertWritable(member,element,value){
  need(shape(member,element),'DESCRIPTION_STALE','Zielfeld wurde ersetzt, verborgen oder gehört nicht mehr zu diesem Formular. Neu verbinden; kein automatischer Wiederholungsversuch.');
  need(editable(element),'DESCRIPTION_READONLY','Beschreibungsfeld nicht bearbeitbar.');
  need(typeof value==='string'&&value.length>0&&value.length<=2000,'DESCRIPTION_VALUE','Ungültige Beschreibung.');
  need(element.maxLength<0||value.length<=element.maxLength,'DESCRIPTION_TOO_LONG','Die Beschreibung überschreitet die maximale Feldlänge. Nicht gekürzt.');
  need(!element.value.trim()||element.value===value,'DESCRIPTION_EXISTS','Vorhandene abweichende Beschreibung bleibt unverändert. Bitte manuell prüfen.');
 }
 function writeOnce(member,element,value,guard){
  need(typeof guard==='function','DESCRIPTION_GUARD','Identitätsprüfung fehlt.');guard();assertWritable(member,element,value);
  if(element.value===value)return {changed:false,events:0};
  const w=element.ownerDocument.defaultView,set=Object.getOwnPropertyDescriptor(w.HTMLTextAreaElement.prototype,'value')?.set;
  need(typeof set==='function','DESCRIPTION_SETTER','Textfeld kann nicht sicher gesetzt werden.');
  set.call(element,value);
  // A page handler may update the DOM; verify before dispatching any next event.
  element.dispatchEvent(new w.Event('input',{bubbles:true}));guard();
  need(shape(member,element)&&element.value===value,'DESCRIPTION_VERIFY','Der Wert wurde von der Seite geändert oder das Feld ersetzt. Nicht erneut geschrieben.');
  element.dispatchEvent(new w.Event('change',{bubbles:true}));guard();
  need(shape(member,element)&&element.value===value,'DESCRIPTION_VERIFY','Einsetzen nicht bestätigt. Bitte das echte Formular prüfen; kein automatischer Wiederholungsversuch.');
  return {changed:true,events:2};
 }
 return Object.freeze({norm,isLabel,inspect,bind,shape,writeOnce});
});

return module.exports;})();
/* Guided single-ticket data assistant. No send/save/categorisation/queue traversal. */
'use strict';
const W=window;let T=W;try{void W.top.document.body;T=W.top;}catch{}
const demo=location.protocol==='file:'||location.href==='about:blank'||['localhost','127.0.0.1','[::1]'].includes(location.hostname);
if(!demo&&location.hostname!=='comarchecm.mercer.com')throw new Error('MCR: Nur im freigegebenen COMARCH-Fenster oder in der lokalen Demo verwenden.');
try{T.MCR_MAIL?.close();W.MCR_MAIL?.close();T.MCR_DATA?.close();W.MCR_DATA?.close();}catch{}
try{if(T.__mcrInspectorTimer)T.clearInterval(T.__mcrInspectorTimer);T.__mcrInspectorTimer=null;if(T.__MCR_CAPTURE_CLICK)T.__MCR_CAPTURE_CLICK=()=>{};T.document.getElementById('__mcr_comarch_inspector')?.remove();}catch{}
const D=T.document,HID='__mcr_mail_assistant_v3';D.getElementById(HID)?.remove();
const host=D.createElement('div');host.id=HID;
Object.assign(host.style,{position:'fixed',top:'12px',right:'12px',zIndex:'2147483647',width:'450px',maxWidth:'96vw'});
const shadow=host.attachShadow({mode:'open'}),style=D.createElement('style');
style.textContent=`:host{font:14px/1.45 'Segoe UI',Arial,sans-serif;color:#172d40}*{box-sizing:border-box}section{background:#fff;border:2px solid #275875;border-radius:12px;box-shadow:0 6px 30px #0005;max-height:94vh;overflow:auto;padding:16px}h2{font-size:19px;margin:0 0 6px}details.step{margin:12px 0;border:1px solid #beced9;border-radius:7px;padding:10px}summary{font-weight:700;cursor:pointer}p{margin:7px 0}.note{font-size:12px;color:#485c6a}label{display:block;margin:8px 0}input,textarea,select,button{font:inherit}input[type=text],select,textarea{width:100%;padding:7px;border:1px solid #91a5b5;border-radius:4px}input[type=file]{max-width:100%;font-size:12px}textarea{min-height:110px}button{padding:8px 11px;margin:4px 5px 4px 0;cursor:pointer;border:1px solid #6c899d;border-radius:5px;background:#edf3f8;color:#15354b}button:disabled{opacity:.5;cursor:not-allowed}.primary{background:#1d5778;color:white}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:12px/1.5 Consolas,monospace;padding:8px;background:#eff4f8;max-height:170px;overflow:auto}.status{padding:10px;border-left:4px solid #23747c;background:#edf7f6;font-weight:600}.error{border-color:#b24033;background:#fff0e9}.result{font:700 20px/1.4 'Segoe UI',Arial,sans-serif;background:#e7f4ef;padding:12px}.row{display:flex;gap:10px}.row>label{flex:1;min-width:0}small{font-size:12px}`;
shadow.append(style);const panel=D.createElement('section');shadow.append(panel);D.body.append(host);
let map=null,mail=null,analysis=null,candidates=[],chosen=null,context=null,waiting=false,member=null,result=null;
let alive=true,caseEpoch=0,mapEpoch=0,lastError=null,lastOutcome=null,proof=null,stable=null,autoCandidate=null,autoAttempted=false;
let waitStarted=0,selectionMode=null,descriptionWritten=false,format=null,fieldAtSearch=null;
let lastWidgetScan=null,autoClickAt=0;
let lastDomScan=null,learnedList=null,pendingLearning=null,lastManualShape=[];
let profileBinding=null,lastProfileScan=null,customBinding=null,pendingCustom=null,lastCustomScan=null;
let descriptionBinding=null,lastDescriptionScan=null,lastDescriptionWrite=null,descriptionAppliedNode=null;
let descriptionWritePending=false,descriptionWriteToken=0,descriptionReadback='NOT_RUN';
let pickMode=null,pickUntil=0,pickSuppress=null,manualRequest=false;
let fieldSignals={input:0,keyup:0,change:0},selectionTrace=[];
function recordState(state){if(selectionTrace.at(-1)?.state!==state){selectionTrace.push({state,elapsedMs:waiting?Math.min(120000,Math.max(0,Date.now()-waitStarted)):0});if(selectionTrace.length>16)selectionTrace.shift();}}
function inspectLive(field){const r=Widget.inspect(field);lastWidgetScan=r.safe;const dom=ListDOM.inspect(field,learnedList);lastDomScan=dom.safe;const custom=Suggest.inspect(field,customBinding);lastCustomScan=custom.safe;return {r,dom,custom};}

let lastBlocking=null,idHints=[],selectionCommitted=false,lookupAttempted=false,lastSelectionState="NOT_STARTED";
const listeners=new Map(),ui={};
function el(tag,text,parent=panel){const n=D.createElement(tag);if(text!==undefined)n.textContent=text;parent.append(n);return n;}
function safe(fn){return async()=>{try{return await fn();}catch(e){error(e);}};}
function btn(text,fn,parent=panel){const n=el('button',text,parent);n.type='button';n.onclick=safe(fn);return n;}
function check(text,parent){const l=el('label',undefined,parent),n=D.createElement('input');n.type='checkbox';l.append(n,D.createTextNode(' '+text));return n;}
function input(label,id,parent){const l=el('label',label,parent),n=el('input',undefined,l);n.type='text';n.id=id;return n;}
function step(title){const n=el('details',undefined,panel);n.className='step';el('summary',title,n);return n;}
function status(text,bad=false){ui.status.textContent=text;ui.status.className='status'+(bad?' error':'');}
function go(n){[ui.s1,ui.s2,ui.s3,ui.s4].forEach((e,i)=>e.open=i===n-1);}
function clearResult(){++descriptionWriteToken;descriptionWritePending=false;descriptionAppliedNode=null;descriptionReadback='NOT_RUN';result=null;descriptionWritten=false;ui.result.textContent='Noch kein Ergebnis.';ui.copy.disabled=true;ui.apply.disabled=true;ui.row.textContent='';if(ui.descriptionInfo)ui.descriptionInfo.textContent='Zielfeld wird erst beim Einsetzen geprüft.';}
function invalidate(reason){descriptionBinding=null;lastDescriptionScan=null;lastDescriptionWrite=null;pickMode=null;manualRequest=false;pendingCustom=null;lastCustomScan=null;lastProfileScan=null;pendingLearning=null;lastDomScan=null;fieldSignals={input:0,keyup:0,change:0};selectionTrace=[];lastManualShape=[];lastBlocking=null;selectionCommitted=false;lookupAttempted=false;lastSelectionState='NOT_STARTED';lastWidgetScan=null;autoClickAt=0;waiting=false;proof=null;stable=null;autoCandidate=null;autoAttempted=false;context=null;chosen=null;member=null;selectionMode=null;clearResult();if(reason)status(reason);}
function error(e){
 if(!alive)return;
 // A target-field/clipboard error is not a data error. Keep a still-valid
 // member-bound lookup and its copy button; identity changes still invalidate it.
 const writeError=/^DESCRIPTION_[A-Z_]+$/.test(e.code??'')||e.code==='COPY_FAILED';
 if(result&&writeError){
  try{checkCurrentResult();}catch(changed){error(changed);return;}
  lastError=e.code;descriptionWritten=false;
  if(e.code.startsWith('DESCRIPTION_')){descriptionReadback='NOT_CONFIRMED';lastDescriptionWrite={state:'ERROR',code:e.code};}
  ui.copy.disabled=false;ui.apply.disabled=descriptionWritePending;go(4);
  ui.descriptionInfo.textContent=e.message+(e.code==='COPY_FAILED'?'\nDie gültige Vorschau bleibt angezeigt. Text dort markieren und selbst kopieren.':'\nBerechnung bleibt gültig und kopierbar. Das Zielfeld bei Bedarf verbinden; danach Einsetzen erneut ausdrücklich anklicken.');
  status(lastError+': '+e.message,true);return;
 }
 lastError=/^[A-Z_0-9]+$/.test(e.code??'')?e.code:'ERROR';
 // An early Continue click is NOT a fatal error and must not disable watching.
 if(['MEMBER_NOT_SELECTED','MEMBER_COMMIT_PENDING'].includes(lastError)&&chosen&&context&&mail&&map&&ui.mailOK.checked&&ui.sourceOK.checked){
  waiting=true;if(!waitStarted||Date.now()-waitStarted>120000)waitStarted=Date.now();
  go(3);lastSelectionState=lastError==='MEMBER_COMMIT_PENDING'?'WAITING_FOR_COMMIT':'WAITING_FOR_REAL_CHOICE';recordState(lastSelectionState);
  ui.memberInfo.textContent=lastError==='MEMBER_COMMIT_PENDING'?'Die MercerID-Ausgabe ist noch leer oder technisch nicht gebunden. Wenn sie in COMARCH bereits gefüllt ist: „MercerID-Anzeige verbinden“ verwenden.':'Noch kein übernommener Member. Den echten Vorschlag anklicken; die Beobachtung läuft weiter.';
  status('Warte auf die nachgewiesene MercerID-Ausgabe. Bereits gefüllte Anzeige bei Bedarf gezielt verbinden.');return;
 }
 waiting=false;clearResult();
 status(lastError+': '+(e.message||'Vorgang fehlgeschlagen.'),true);
 if(lastError==='ID_BLOCKED'){
  lastBlocking=e.blocking??null;go(4);ui.result.textContent='Member zugeordnet · Bestandszeile gesperrt';
  ui.row.textContent=[...(lastBlocking?.messages??[]),'Grund: '+(lastBlocking?.codes??[]).join(', '),'Excel-Quellzeile(n): '+(lastBlocking?.sourceRows??[]).join(', '),
   ...(lastBlocking?.issues??[]).map(x=>'Spalte '+x.column+': '+x.state+' ('+x.code+')'),
   lastBlocking?.legacyDetails?'Dieses ältere Mapping speichert keine Spaltendetails. MAPPING_PRUEFEN.cmd zeigt lokal die betroffene Originalzeile.':'Quelle gezielt prüfen. Danach Mapping neu erzeugen, nicht die JSON-Datei von Hand ändern.',
   Core.policyOf(map?.payload)===Core.STRICT_FLAGS?'Altes Mapping: MAPPING_ERSTELLEN.cmd 0.3.6 starten und das NEUE JSON laden. Leere C/D/E bleiben darin als leer dokumentiert; kein Kürzel.':'Quelle gezielt prüfen: Nur leere C/D/E sind ohne Kürzel zulässig, andere Fehler bleiben gesperrt.'].join('\n');
  ui.retry.textContent='Bestand erneut prüfen';
 }else if(lastError==='ID_NOT_FOUND'){
  go(4);ui.result.textContent='Member zugeordnet · nicht im geladenen Bestand';ui.row.textContent=e.message;
 }else if(lastError.startsWith('MEMBER_')||lastError==='SELECTION_REVIEW'){
  go(3);ui.memberInfo.textContent=e.message;
 }
}
function visible(n){try{return n.isConnected&&n.getClientRects().length>0&&n.ownerDocument.defaultView.getComputedStyle(n).visibility!=='hidden'&&n.ownerDocument.defaultView.getComputedStyle(n).display!=='none';}catch{return false;}}
function documents(){const out=[];function walk(doc,depth){if(!doc||depth>5||out.length>=32||out.includes(doc))return;out.push(doc);for(const f of doc.querySelectorAll('iframe,frame'))try{walk(f.contentDocument,depth+1);}catch{}}walk(D,0);return out;}
function memberField(){const all=documents().flatMap(d=>[...d.querySelectorAll('input[id="mainForm:member-value-id"]')]).filter(visible);Core.need(all.length===1,'MEMBER_FIELD','Bitte EIN Ticket öffnen, unten Bearbeiten anklicken und das Member-Feld anzeigen.');Core.need(!all[0].disabled&&!all[0].readOnly,'MEMBER_READONLY','Member-Feld ist noch nicht bearbeitbar.');return all[0];}
function detectedTicket(){
 const found=new Set();
 for(const doc of [D])for(const n of [...doc.querySelectorAll('label,span,td,div,b,strong,p')].slice(0,12000)){
  if(!visible(n))continue;const s=n.textContent?.trim()??'';if(s.length>70)continue;
  let m=s.match(/^Ticket[\s-]*ID\s*:?\s*(\d{4,15})$/i);if(m){found.add(m[1]);continue;}
  if(/^Ticket[\s-]*ID\s*:?$/i.test(s)){
   const next=n.nextElementSibling?.textContent?.trim();if(/^\d{4,15}$/.test(next??''))found.add(next);
   const p=n.parentElement?.textContent?.trim()??'';if(p.length<90&&(m=p.match(/^Ticket[\s-]*ID\s*:?\s*(\d{4,15})$/i)))found.add(m[1]);
  }
 }
 return found.size===1?[...found][0]:null;
}
// The ticket/document anchor protects against switching cases. It is NEVER
// used as the JSON lookup key and never needs to be replaced with a MercerID.
function documentKey(field){
 const scope=field.closest('form')??field.ownerDocument;const ids=new Set();
 for(const a of scope.querySelectorAll('a[href]'))try{
  const u=new URL(a.getAttribute('href'),field.ownerDocument.baseURI);
  if(u.origin!==field.ownerDocument.location.origin||!/(?:^|\/)GetFile\/?$/i.test(u.pathname))continue;
  for(const [k,v] of u.searchParams)if(/^docid$/i.test(k)&&/^\d{1,15}$/.test(v))ids.add(v);
 }catch{}
 return ids.size?[...ids].sort().join('|'):null;
}
function bindContext(){
 const actual=detectedTicket(),field=memberField(),docKey=documentKey(field);
 ui.ticket.value=actual??'nicht automatisch erkannt';
 ui.caseInfo.textContent=actual?'Vorgang erkannt. Diese Nummer wird NICHT im Bestand gesucht.':docKey?'Aktuelles Dokument als Fallgrenze erkannt. Keine Ticketnummer eingeben.':'Fall nur an dieses Formular gebunden. Bei Seitenwechsel oder Formularersetzung neu bestätigen.';
 return {id:actual,detected:!!actual,documentKey:docKey,url:T.location.href,field,mode:actual?'TICKET':docKey?'DOCUMENT':'FORM_ONLY'};
}
function contextOK(){
 Core.need(context&&context.url===T.location.href,'TICKET_CHANGED','Seite gewechselt. Mit Neuer Fall beginnen.');
 const actual=detectedTicket();
 Core.need(context.detected?actual===context.id:!actual,'TICKET_CHANGED','Vorgangskennung hat sich geändert. Neu beginnen.');
 const field=memberField(),key=documentKey(field);
 Core.need(key===context.documentKey,'TICKET_CHANGED','Originaldokumente des Tickets haben sich geändert. Neu beginnen.');
 if(!context.detected&&!context.documentKey)Core.need(field===context.field,'TICKET_REBIND','Ohne verlässliche Fallkennung wurde das Formular ersetzt. Person und Ticket erneut bestätigen.');
 return field;
}
// Distinguish an autocomplete suggestion from the populated MercerID profile.
// Only read short semantic values in the same form, never the mail iframe.
function committedProfile(field){const result=Profile.inspect(field,profileBinding);lastProfileScan=result.safe;return result;}
// Explicitly bind a selected output, never by writing a number into a data field.
function bindProfileOutput(element){
 if(!chosen){chosen={...freezeName(),expectedId:expectedId()};gates();context=bindContext();}
 gates();const f=contextOK(),selected=Core.selectedMember(f.value);checkExpected(selected);
 Core.need(Person.memberMatches(selected.display,chosen),'MEMBER_NAME_CONFLICT','Name stimmt nicht mit dem ausgewählten COMARCH-Member überein.');
 const binding=Profile.bind(f,element);const p=Profile.inspect(f,binding);
 Core.need(!p.ambiguous&&p.clientId===selected.clientId,'MEMBER_PROFILE_CONFLICT','Gewählte MercerID-Anzeige passt nicht eindeutig zum Member.');
 profileBinding=binding;recordState('PROFILE_OUTPUT_BOUND');lastError=null;
 return acceptMember(true);
}
function armPick(mode){
 if(!chosen){chosen={...freezeName(),expectedId:expectedId()};gates();context=bindContext();}
 gates();contextOK();pickMode=mode;pickUntil=Date.now()+30000;waiting=true;waitStarted=Date.now();
 // ALT is mandatory, so ordinary COMARCH clicks never become unintended bindings.
 status(mode==='PROFILE'?'ALT gedrückt halten und die bereits gefüllte MercerID-Anzeige unter dem Member-Feld anklicken (nicht den Vorschlag).':'ALT gedrückt halten und eine echte Vorschlagszeile anklicken. Das markiert die Liste, wählt aber noch keine Person.');
}
function capturePick(event){
 if(pickSuppress&&Date.now()<pickSuppress.until&&event.isTrusted&&(pickSuppress.target===event.target||pickSuppress.target.contains?.(event.target))){event.preventDefault();event.stopImmediatePropagation();return;}
 if(!pickMode||!event.isTrusted||!event.altKey||event.button!==0||event.composedPath().includes(host))return;
 if(Date.now()>pickUntil){pickMode=null;return;}
 event.preventDefault();event.stopImmediatePropagation();
 const mode=pickMode;pickMode=null;pickSuppress={target:event.target,until:Date.now()+650};
 try{
  if(mode==='DESCRIPTION'){bindDescriptionOutput(event.target);return;}
  if(mode==='PROFILE'){bindProfileOutput(event.target);return;}
  gates();const f=contextOK(),hit=Suggest.capture(f,event.target);
  Core.need(hit,'SUGGESTION_BIND_TARGET','Keine Vorschlagszeile mit mousedown-Ereignis erkannt. Keine Aktion ausgeführt.');
  Core.need(chosen.expectedId,'PERSON_ID_REQUIRED','Für die automatische Auswahl eine MercerID aus der Mail prüfen. Sonst den echten Vorschlag selbst anklicken.');
  Core.need(!!candidateIdentity(hit.row,'COMARCH_MOUSEDOWN_ID'),'SELECTION_REVIEW','Diese Zeile passt nicht zum geprüften Namen und zur MercerID.');
  customBinding=hit.binding;lastCustomScan=Suggest.inspect(f,customBinding).safe;autoCandidate=null;
  waiting=true;waitStarted=Date.now();status('Vorschlagsliste verbunden. Ein passender Einzeltreffer wird einmal ausgewählt; mehrere Treffer bleiben manuell.');
 }catch(e){error(e);}
}

function expectedId(){return Person.personId(ui.expected.value);}
function checkExpected(selected){
 const expected=expectedId();Core.need(expected===chosen.expectedId,'PERSON_ID_CHANGED','Personenkennung wurde geändert. Identität erneut bestätigen.');
 Core.need(!expected||expected===selected.clientId,'MAIL_MEMBER_CONFLICT','Geprüfte MercerID aus der Mail passt nicht zum ausgewählten COMARCH-Member. Nicht die Ticketnummer umschreiben.');
}
function freezeName(){return Person.query(ui.first.value,ui.last.value);}
function gates(){Core.need(map&&ui.sourceOK.checked,'MAPPING_REVIEW','JSON aus private_data laden und Quellenstand bestätigen.');Core.need(mail&&ui.mailOK.checked,'MAIL_REVIEW','Original-Mail laden und Zuordnung zu diesem Ticket bestätigen.');const p=freezeName();Core.need(chosen&&p.query===chosen.query&&expectedId()===chosen.expectedId,'NAME_CHANGED','Name wurde geändert. Suche neu starten.');return p;}
async function sha(value){Core.need(crypto?.subtle,'CRYPTO_REQUIRED','SHA-256 ist in diesem Browserkontext nicht verfügbar. HTTPS-COMARCH verwenden.');const b=typeof value==='string'?new TextEncoder().encode(value):value;return [...new Uint8Array(await crypto.subtle.digest('SHA-256',b))].map(x=>x.toString(16).padStart(2,'0')).join('');}
el('h2','MCR Mail-Assistent 0.3.6');
el('p','Original-Mail → geprüfter Name → Member → USC / Pläne').className='note';
ui.status=el('p','1 · Deine vorhandene JSON-Datei laden.');ui.status.className='status';
ui.s1=step('1 · Bestand laden (einmal pro Sitzung)');ui.s1.open=true;
el('p','JSON aus private_data auswählen — NICHT die Excel-Datei.',ui.s1);
ui.mapFile=el('input',undefined,ui.s1);ui.mapFile.type='file';ui.mapFile.accept='.json';ui.mapFile.id='mapFile';
ui.mapInfo=el('pre','Noch kein Mapping geladen.',ui.s1);
ui.sourceOK=check('Diese Bestandsversion und Spalte L als USC sind fachlich richtig und aktuell genug.',ui.s1);
ui.s2=step('2 · Original-Mail dieses Tickets laden');
el('p','Im COMARCH-Nachrichtenverlauf die Original-Mail herunterladen und Speichern wählen. Die .msg hier auswählen; Outlook muss nicht geöffnet werden.',ui.s2);
ui.mailFile=el('input',undefined,ui.s2);ui.mailFile.type='file';ui.mailFile.accept='.msg,.txt';ui.mailFile.id='mailFile';
ui.mailInfo=el('pre','Noch keine Mail geladen.',ui.s2);
const alternative=el('details',undefined,ui.s2);el('summary','Alternative: Mailtext selbst einfügen',alternative);
ui.raw=el('textarea',undefined,alternative);ui.raw.setAttribute('aria-label','Alternativer Mailtext');
btn('Diesen Text analysieren',()=>setMail({format:'MANUAL',subject:'',senderName:'',senderEmail:'',body:ui.raw.value,warnings:[],diagnostic:{plainText:true,attachmentsRead:false}}),alternative);
const review=el('details',undefined,ui.s2);el('summary','Gelesenen Text lokal prüfen',review);ui.body=el('pre','Noch kein Text.',review);
ui.s3=step('3 · Name prüfen und Member auswählen');
el('p','Der Name ist ein Vorschlag, kein Identitätsnachweis. Absender und betroffene Person können verschieden sein.',ui.s3).className='note';
const namesLabel=el('label','Namensvorschläge aus der Mail',ui.s3);ui.names=el('select',undefined,namesLabel);ui.names.id='nameCandidates';
const row=el('div',undefined,ui.s3);row.className='row';ui.first=input('Vorname','firstName',row);ui.last=input('Nachname','lastName',row);
btn('Vorname / Nachname tauschen',()=>{[ui.first.value,ui.last.value]=[ui.last.value,ui.first.value];nameChanged();},ui.s3);
ui.expected=input('MercerID / ClientEEID der Person (optional, aus der Mail)','expectedClientId',ui.s3);
ui.expected.placeholder='z. B. INTL01-12345678 oder 12345678';
ui.idInfo=el('pre','Kein Kennungshinweis aus der Mail.',ui.s3);
el('p','Nur die Kennung des tatsächlich ausgewählten COMARCH-Members wird in Excel/JSON gesucht.',ui.s3).className='note';
const technical=el('details',undefined,ui.s3);el('summary','Vorgangsnummer · nur zur Absicherung',technical);
ui.ticket=input('Ticket-ID (nicht MercerID, nur lesen)','ticketId',technical);ui.ticket.readOnly=true;
ui.caseInfo=el('p','Keine Ticketnummer eintippen. Der Assistent bindet den geöffneten Fall separat.',technical);ui.caseInfo.className='note';
ui.mailOK=check('Mail gehört zu diesem Ticket; Vorname, Nachname und ein ggf. angezeigter MercerID-Hinweis sind geprüft. Member-Suche freigeben.',ui.s3);
ui.autoOne=check('Einen technisch gebundenen Einzeltreffer automatisch auswählen. Bei ICEfaces zusätzlich nur mit oben geprüfter MercerID. Mehrere Treffer wähle ich selbst.',ui.s3);ui.autoOne.checked=true;
ui.search=btn('Member suchen',startSearch,ui.s3);ui.search.className='primary';
btn('Suchnamen kopieren',async()=>{const p=freezeName();await navigator.clipboard.writeText(p.query);status('Suchname kopiert: im Member-Feld bei Bedarf selbst einfügen.');},ui.s3);
ui.memberInfo=el('pre','Noch keine Member-Suche gestartet.',ui.s3);
ui.inspect=btn('Auswahlliste prüfen',()=>{const f=memberField(),r=inspectLive(f),p=committedProfile(f);ui.memberInfo.textContent='COMARCH-Auswahl: '+r.custom.safe.state+' | Ereignis: mousedown\nGelieferte Zeilen: '+(r.custom.safe.entryCount??r.r.safe.entryCount??'unbekannt')+'\nMercerID-Ausgabe: '+p.safe.state+' | Pfad: '+(p.safe.route??'noch nicht erkannt')+'\nBei unbekannter Struktur die tatsächliche Zeile/Anzeige einmal verbinden.';},ui.s3);
btn('Member-Suchfeld anzeigen (keine Auswahl)',()=>{const f=memberField();f.scrollIntoView({block:'center',behavior:'instant'});const before=f.style.outline;f.style.outline='3px solid #1d5778';setTimeout(()=>{if(f.isConnected)f.style.outline=before;},1800);status('Member-Suchfeld markiert. Das Anzeigen wählt keine Person und löst keine neue Suche aus.');},ui.s3);
el('p','Unbekannte Liste? Einmal den richtigen echten Vorschlag anklicken. Der Helfer beobachtet den Klick und die übernommenen Stammdaten. Eine sicher gebundene Liste kann er für diese Seite lernen.',ui.s3).className='note';
// Preserve the COMARCH dropdown focus while inspecting it.
ui.inspect.addEventListener('pointerdown',event=>event.preventDefault());
ui.inspect.addEventListener('mousedown',event=>event.preventDefault());
ui.confirm=btn('Übernommene Person prüfen → Schritt 4',()=>acceptMember(true),ui.s3);ui.confirm.className='primary';
const repair=el('details',undefined,ui.s3);el('summary','Nur bei Erkennungsproblemen: Element einmal verbinden',repair);
ui.bindProfile=btn('MercerID-Anzeige verbinden',()=>armPick('PROFILE'),repair);
ui.bindChoice=btn('Vorschlagszeile verbinden',()=>armPick('CHOICE'),repair);
for(const b of [ui.bindProfile,ui.bindChoice])for(const type of ['pointerdown','mousedown'])b.addEventListener(type,e=>e.preventDefault());
el('p','Nach dem Klick ALT halten und das echte Element in COMARCH anklicken. Kein Eintragen von Kennungen, kein Speichern/Versand. Escape beendet das Verbinden.',repair).className='note';
btn('Suche / Warten stoppen',()=>invalidate('Gestoppt. Kein Versand, kein Speichern.'),ui.s3);
ui.s4=step('4 · Beschreibung übernehmen');
ui.result=el('div','Noch kein Ergebnis.',ui.s4);ui.result.className='result';ui.row=el('pre','',ui.s4);
ui.retry=btn('Bestand erneut prüfen',()=>acceptMember(true),ui.s4);
ui.formulaOK=check('Falls die Quellzeile Formeln enthält: gespeicherte Berechnungswerte geprüft.',ui.s4);
ui.copy=btn('Beschreibung kopieren',async()=>{
 checkCurrentResult();const value=result.description;
 try{await navigator.clipboard.writeText(value);}catch{Core.fail('COPY_FAILED','Zwischenablage nicht erreichbar. Den angezeigten Beschreibungstext markieren und selbst kopieren.');}
 lastError=null;status('Beschreibung kopiert. Noch kein Ticket gespeichert.');
},ui.s4);ui.copy.disabled=true;
ui.apply=btn('Beschreibung in COMARCH einsetzen',applyDescription,ui.s4);ui.apply.disabled=true;
ui.bindDescription=btn('Beschreibungsfeld verbinden',armDescriptionPick,ui.s4);
for(const type of ['pointerdown','mousedown'])ui.bindDescription.addEventListener(type,e=>e.preventDefault());
ui.descriptionInfo=el('pre','Zielfeld wird erst beim Einsetzen geprüft.',ui.s4);
el('p','Nur wenn das Zielfeld nicht erkannt wird: „Beschreibungsfeld verbinden“, dann ALT halten und direkt in das echte Feld „Zusätzliche Beschreibung“ klicken. Das Verbinden schreibt nichts. Danach „Beschreibung in COMARCH einsetzen“.',ui.s4).className='note';
el('p','Kein automatischer Versand, kein „Ticket speichern“. Kategorien, Signatur und Antwort sind weiterhin separat zu prüfen.',ui.s4).className='note';
btn('Neuer Fall',resetCase);btn('Diagnose-ZIP',downloadDiagnostic);btn('Schließen',close);
el('p','Nur im betrieblich freigegebenen Kontext verwenden. Mail und Mapping liegen im Speicher dieser COMARCH-Seite; keine isolierte Datenschutz-Sandbox.',panel).className='note';
async function loadMapText(value){
 const epoch=++mapEpoch;invalidate();map=null;go(1);ui.sourceOK.checked=false;ui.mapInfo.textContent='Mapping wird geprüft …';
 Core.need(value.length<=32*1024*1024,'MAP_SIZE','Mapping zu groß.');const obj=JSON.parse(value);Core.validateMap(obj);
 Core.need(demo||obj.payload.mode!=='DEMO','DEMO_NOT_IN_COMARCH','Demo-Mapping nicht in COMARCH einsetzen.');
 Core.need(await sha(JSON.stringify(obj.payload))===obj.payloadSha256,'MAP_HASH_MISMATCH','Mapping-Prüfsumme stimmt nicht.');Core.need(alive&&mapEpoch===epoch,'CANCELLED','Import ersetzt/geschlossen.');map=obj;
 const p=obj.payload;ui.mapInfo.textContent=[p.mode==='DEMO'?'DEMO · fiktive Daten':'Bestand geladen',p.source.filename,'Blatt: '+p.source.sheet+' | L: '+p.source.headers.L,'Stand: '+(p.source.modifiedAt??'unbekannt'),'Export: '+p.generatedAt,'Gültige Kennungen: '+Object.keys(p.entries).length,'Gesperrte Kennungen: '+Object.keys(p.blocked).length,'Merkmalsregel: '+(Core.policyOf(p)===Core.BLANK_OMIT_FLAGS?'Nur 1 → Kürzel; 0 / leer → kein Kürzel (leer bleibt null)':'ALTES STRICT-Mapping: auch leer gesperrt; für Leerzellen mit 0.3.6 neu exportieren')].join('\n');
 lastError=null;status('Mapping geprüft. Quellenstand bestätigen, dann Original-Mail laden.');return {validKeys:Object.keys(p.entries).length};
}
ui.mapFile.onchange=safe(async()=>{const f=ui.mapFile.files?.[0];if(!f)return;const epoch=++mapEpoch;invalidate();map=null;ui.sourceOK.checked=false;Core.need(f.size<=32*1024*1024,'MAP_SIZE','Mapping zu groß.');const text=await f.text();Core.need(alive&&epoch===mapEpoch,'CANCELLED','Import ersetzt/geschlossen.');await loadMapText(text);});
ui.sourceOK.onchange=()=>{invalidate();if(map&&ui.sourceOK.checked){go(2);status('2 · Original-Mail (.msg) auswählen. Dein Mapping bleibt geladen.');}};
function setMail(data){
 ++caseEpoch;invalidate();mail=null;analysis=null;candidates=[];ui.mailOK.checked=false;ui.formulaOK.checked=false;ui.first.value='';ui.last.value='';ui.names.replaceChildren();ui.body.textContent='';ui.mailInfo.textContent='';format=data.format;lastOutcome=null;
 analysis=Core.analyzeMail((data.subject?'Betreff: '+data.subject+'\n':'')+data.body);if(/^(?:WG|FW|FWD)\s*:/i.test(data.subject??''))analysis.warnings.push('WEITERLEITUNG: Absender und betroffene Person getrennt prüfen.');candidates=Person.candidates(data);mail=data;
 idHints=Person.identifierHints(data,analysis.idHints,candidates);const uniqueIds=[...new Set(idHints.map(x=>x.clientId))];
 ui.expected.value=uniqueIds.length===1?uniqueIds[0]:'';
 ui.idInfo.textContent=idHints.length?idHints.map(x=>x.clientId+' — '+(x.strength==='EXPLICIT'?'beschriftete Kennung':'Namensnähe: nur Hinweis, prüfen')).join('\n'):'Kein Kennungshinweis. Die spätere ausgewählte MercerID reicht für den Bestandsabgleich.';
 ui.body.textContent=data.body;
 ui.mailInfo.textContent=['Format: '+data.format,'Betreff: '+(data.subject||'(nicht vorhanden)'),'Absender: '+(data.senderName||'(nicht vorhanden)'),...data.warnings,...analysis.warnings].join('\n');
 el('option','Bitte Namensvorschlag wählen oder unten selbst eingeben',ui.names).value='';
 candidates.forEach((c,i)=>{const o=el('option',c.name+' — '+c.sources.join(', '),ui.names);o.value=String(i);});
 if(candidates.length===1){ui.names.value='0';chooseName(0);}else ui.names.value='';
 const ticket=detectedTicket();ui.ticket.value=ticket??'nicht automatisch erkannt';
 go(3);lastError=null;status(candidates.length===1?'3 · Name und ggf. MercerID-Hinweis prüfen, dann „Member suchen“.':candidates.length?'3 · Mehrere Namenshinweise: richtige Person auswählen.':'3 · Kein eindeutiger Name erkannt. Vorname und Nachname aus dem Text selbst eintragen.');
 return {nameCandidates:candidates.length,idCandidates:new Set(idHints.map(x=>x.clientId)).size};
}
async function loadMailBytes(bytes,extension){
 const epoch=++caseEpoch;invalidate();mail=null;analysis=null;ui.mailOK.checked=false;ui.mailInfo.textContent='Original-Mail wird lokal gelesen …';
 Core.need(alive,'CLOSED','Helfer ist geschlossen.');
 const item=extension.toLowerCase()==='.msg'?Msg.parseMsg(bytes):extension.toLowerCase()==='.txt'?Msg.parseText(bytes):Core.fail('MAIL_FORMAT','Bitte die Original-.msg oder UTF-8-.txt verwenden. .eml ist hier noch nicht unterstützt.');
 Core.need(alive&&epoch===caseEpoch,'CANCELLED','Mailimport ersetzt.');return setMail(item);
}
ui.mailFile.onchange=safe(async()=>{const f=ui.mailFile.files?.[0];if(!f)return;const epoch=++caseEpoch;invalidate();mail=null;analysis=null;ui.mailOK.checked=false;Core.need(f.size<=Msg.MAX_FILE,'MSG_SIZE','Maildatei zu groß (32 MiB).');const bytes=await f.arrayBuffer();Core.need(alive&&epoch===caseEpoch,'CANCELLED','Mailimport durch anderen Fall ersetzt.');await loadMailBytes(bytes,(/\.[^.]+$/.exec(f.name)??[''])[0]);});
function chooseName(i){const c=candidates[i];if(!c)return;ui.first.value=c.firstName;ui.last.value=c.lastName;nameChanged();if(c.needsSplit)status('Mehrteiliger Name: Vorname und vollständigen Nachnamen bitte selbst zuordnen.');}
ui.names.onchange=()=>{if(ui.names.value!=='')chooseName(Number(ui.names.value));};
function nameChanged(){invalidate();ui.mailOK.checked=false;}
ui.first.oninput=nameChanged;ui.last.oninput=nameChanged;ui.expected.oninput=nameChanged;ui.mailOK.onchange=()=>{if(!ui.mailOK.checked)invalidate();};
function setNativeValue(field,value,withChange=true){const owner=field.ownerDocument.defaultView;const p=field.tagName==='TEXTAREA'?owner.HTMLTextAreaElement.prototype:owner.HTMLInputElement.prototype;Object.getOwnPropertyDescriptor(p,'value').set.call(field,value);field.dispatchEvent(new owner.Event('input',{bubbles:true}));if(withChange)field.dispatchEvent(new owner.Event('change',{bubbles:true}));}
function startSearch(){
 invalidate();chosen={...freezeName(),expectedId:expectedId()};gates();context=bindContext();const f=memberField();
 if(/INTL01-\d/.test(f.value))return acceptMember(true);
 attachDocument(f.ownerDocument);fieldAtSearch=f;waiting=true;waitStarted=Date.now();lastError=null;lastSelectionState='WAITING_FOR_CHOICE';autoAttempted=false;ui.memberInfo.textContent='Suche: '+chosen.query+'\nTrefferliste in COMARCH abwarten. Bei mehreren Treffern selbst anklicken.';
 f.focus();setNativeValue(f,chosen.query,false);
 // No change/blur before the search key: old AJAX controls may replace the field.
 // A real character key (never Enter/Tab) supplies legacy keyCode/which metadata.
 const key=chosen.query.slice(-1),keyCode=key.toUpperCase().charCodeAt(0),owner=f.ownerDocument.defaultView;
 if(f.isConnected&&f===contextOK())f.dispatchEvent(new owner.KeyboardEvent('keyup',{key,keyCode,which:keyCode,bubbles:true}));
 recordState('SEARCH_INPUT_SENT');
 status('Warte auf COMARCH-Treffer. Falls keine Liste erscheint: im Member-Feld ein Zeichen löschen und neu tippen. Kein Enter auf Senden.');
}
function observeChoice(event){
 if(!waiting||!event.isTrusted||!chosen||event.button!==0)return;
 if(event.composedPath().includes(host))return;
 let f;try{f=contextOK();}catch{return;}
 if(event.target?.ownerDocument!==f.ownerDocument)return;
 lastManualShape=ListDOM.clickShape(event.target);
 const custom=Suggest.capture(f,event.target);
 const scan=ListDOM.capture(f,event.target);lastDomScan=scan.safe;
 let n=event.target;for(let i=0;n&&i<6;i++,n=n.parentElement){
  if(n.nodeType!==1||['BODY','HTML','FORM'].includes(n.tagName))break;
  const text=n.innerText??n.textContent??'';if(text.length>350)continue;
  try{const selected=Core.selectedMember(text);if(Person.memberMatches(text,chosen)&&(!chosen.expectedId||selected.clientId===chosen.expectedId)){
   proof={id:selected.clientId,until:Date.now()+30000,mode:'USER_CLICK'};recordState('REAL_CHOICE_OBSERVED');
   if(custom)pendingCustom={binding:custom.binding,clientId:selected.clientId};
   const row=scan.entries?.find(row=>row===event.target||row.contains(event.target));
   if(row&&scan.binding)pendingLearning={binding:scan.binding,clientId:selected.clientId};
   return;
  }}catch{}
 }
}
function observeFieldSignal(event){
 if(!waiting||event.target?.id!=='mainForm:member-value-id')return;
 if(Object.hasOwn(fieldSignals,event.type))fieldSignals[event.type]=Math.min(99,fieldSignals[event.type]+1);
}
function cancelPick(event){if(event.key==='Escape'&&pickMode){pickMode=null;status('Element-Verbindung abgebrochen. Keine Daten verändert.');}}
function attachDocument(doc){
 if(listeners.has(doc))return;
 doc.addEventListener('pointerdown',capturePick,true);doc.addEventListener('mousedown',capturePick,true);doc.addEventListener('click',capturePick,true);doc.addEventListener('mouseup',capturePick,true);
 doc.addEventListener('keydown',cancelPick,true);doc.addEventListener('pointerdown',observeChoice,true);doc.addEventListener('mousedown',observeChoice,true);
 for(const type of ['input','change','keyup'])doc.addEventListener(type,observeFieldSignal,true);
 listeners.set(doc,true);
}
function candidateIdentity(element,kind,extra={}){
 const text=element.innerText??'';
 if(text.length>350||!Person.memberMatches(text,chosen))return null;
 try{
  const selected=Core.selectedMember(text);
  if(chosen.expectedId&&chosen.expectedId!==selected.clientId)return null;
  const ids=[...new Set(analysis.idHints.map(x=>x.clientId))];
  if(ids.length>1||(ids.length===1&&ids[0]!==selected.clientId))return null;
  // Identity selection and plan lookup are separate. Even a blocked map row
  // must reach the explicit diagnostics AFTER COMARCH commits the member.
  return {element,id:selected.clientId,text,kind,...extra};
 }catch{return null;}
}
function strictSingle(f){
 if(!ui.autoOne.checked||autoAttempted||context?.mode==='FORM_ONLY')return null;
 const refs=(f.getAttribute('aria-controls')||f.getAttribute('aria-owns')||'').trim().split(/\s+/).filter(Boolean);
 if(refs.length===1){
  const list=f.ownerDocument.getElementById(refs[0]);
  if(list&&visible(list)&&list.getAttribute('role')==='listbox'&&list.getAttribute('aria-busy')==='false'){
   const options=[...list.querySelectorAll('[role="option"]')];
   if(options.length!==1)return null;
   const o=options[0];
   if(visible(o)&&o.getAttribute('aria-setsize')==='1'&&o.getAttribute('aria-posinset')==='1'&&o.getAttribute('aria-disabled')!=='true')return candidateIdentity(o,'LINKED_SINGLE');
  }
 }
 const exact=chosen.expectedId?Suggest.exactExpected(f,chosen.expectedId,chosen.query):null;
 if(exact?.safe?.state==='AMBIGUOUS_EXACT')return null;
 if(exact?.safe?.state==='SINGLE_EXACT'){
  const found=candidateIdentity(exact.entry,'COMARCH_EXACT_MOUSEDOWN_ID');
  if(found)return found;
 }
 const {r:scan,dom,custom}=inspectLive(f);
 if(custom.safe.state==='MULTIPLE_RENDERED'||custom.safe.state==='HIDDEN_ENTRY'||custom.safe.state==='AMBIGUOUS_POPUP')return null;
 if(custom.safe.state==='SINGLE_RENDERED'){
  if(!chosen.expectedId){lastCustomScan={...custom.safe,state:'REVIEWED_ID_REQUIRED'};return null;}
  const profile=committedProfile(f);
  if(!profile.labelFound||profile.ambiguous){lastCustomScan={...custom.safe,state:'COMMIT_PROFILE_REQUIRED'};return null;}
  return candidateIdentity(custom.entries[0],'COMARCH_MOUSEDOWN_ID',{list:custom.list});
 }
 // Never override an existing conflicting/busy/multiple registry result.
 if(scan.safe.state!=='SINGLE_RENDERED'){
  if(!['REGISTRY_UNAVAILABLE'].includes(scan.safe.state)||!learnedList||dom.safe.state!=='SINGLE_RENDERED')return null;
  if(!chosen.expectedId){lastDomScan={...dom.safe,state:'REVIEWED_ID_REQUIRED'};return null;}
  const profile=committedProfile(f);if(!profile.labelFound||profile.ambiguous)return null;
  return candidateIdentity(dom.entries[0],'LEARNED_DOM_ID',{list:dom.list});
 }
 // Legacy component only declares the number it rendered. A confirmed exact ID
 // plus an exact name is mandatory; no automatic identity inference from names.
 if(!chosen.expectedId){lastWidgetScan={...scan.safe,state:'REVIEWED_ID_REQUIRED'};return null;}
 // Need a readable committed-profile field before any automatic ICE selection.
 // Otherwise we could not distinguish its synchronous label from server commit.
 const profile=committedProfile(f);
 if(!profile.labelFound||profile.ambiguous){lastWidgetScan={...scan.safe,state:'COMMIT_PROFILE_REQUIRED'};return null;}
 return candidateIdentity(scan.entries[0],'ICE_SINGLE_ID',{instance:scan.instance,list:scan.list});
}

function tick(){
 if(!alive)return;
 for(const doc of documents())attachDocument(doc);
 if(pickMode&&Date.now()>pickUntil){pickMode=null;status('Element-Verbindung abgelaufen. Erneut starten.');}
 if(result){try{
  checkCurrentResult();
  if(descriptionWritten&&!descriptionWritePending&&(!Description.shape(member.element,descriptionAppliedNode)||descriptionAppliedNode.value!==result.description)){
   descriptionWritten=false;descriptionReadback='CHANGED_AFTER_INSERT';lastError='DESCRIPTION_CHANGED_AFTER_INSERT';
   lastDescriptionWrite={state:'CHANGED_AFTER_INSERT',code:lastError};
   ui.descriptionInfo.textContent='Der zuvor eingesetzte Text wurde geändert oder das Zielfeld ersetzt. Keine automatische Wiederholung. Vorschau bleibt kopierbar.';
   status('Beschreibung im Formular ist nicht mehr bestätigt. Bitte prüfen; keine automatische Wiederholung.',true);
  }
 }catch(e){error(e);}return;}
 if(!waiting)return;
 if(pickMode){if(Date.now()>pickUntil){pickMode=null;status('Element-Verbindung abgelaufen. Erneut starten.');}else return;}
 try{
  gates();const f=contextOK();
  if(autoAttempted&&autoClickAt&&Date.now()-autoClickAt>30000){waiting=false;lastSelectionState='AUTO_COMMIT_UNCONFIRMED';status('Auswahl einmal ausgelöst, aber nicht rechtzeitig bestätigt. Kein zweiter Klick. COMARCH-Zuordnung prüfen und anschließend manuell bestätigen.',true);return;}
  if(Date.now()-waitStarted>120000){waiting=false;status('Warten pausiert. Person auswählen und mit „Übernommene Person prüfen → Schritt 4“ fortfahren.');return;}
  let value=null;try{value=Core.selectedMember(f.value);}catch{}
  if(value){
   if(!Person.memberMatches(value.display,chosen)){error(Object.assign(new Error('Ausgewählter Name passt nicht zum bestätigten Suchnamen. Vorname/Nachname und Person prüfen.'),{code:'MEMBER_NAME_CONFLICT'}));return;}
   checkExpected(value);const profile=committedProfile(f);
   Core.need(!profile.ambiguous,'MEMBER_PROFILE_AMBIGUOUS','MercerID-Stammdaten sind nicht eindeutig. Nicht automatisch fortfahren.');
   if(profile.clientId&&profile.clientId!==value.clientId){stable=null;lastSelectionState='WAITING_FOR_COMMIT';recordState('WAITING_FOR_COMMIT');status('COMARCH verarbeitet die Auswahl: MercerID-Stammdaten passen noch nicht. Kein Lookup, bis beide Kennungen übereinstimmen.');return;}
   ui.memberInfo.textContent='Member-Feld: '+value.display+'\nMercerID-Ausgabe: '+profile.safe.state;
   if(profile.labelFound&&!profile.clientId){stable=null;lastSelectionState='WAITING_FOR_COMMIT';recordState('WAITING_FOR_COMMIT');ui.memberInfo.textContent+='\nIst die MercerID darunter bereits ausgefüllt? Dann „MercerID-Anzeige verbinden“ verwenden.';status('Warte auf erkannte MercerID-Stammdaten. Sichtbar gefüllte Daten können über „Element einmal verbinden“ zugeordnet werden.');return;}
   if(!stable||stable.value!==f.value||stable.profileId!==profile.clientId)stable={value:f.value,profileId:profile.clientId,since:Date.now()};
   lastSelectionState='MEMBER_VALUE_READY';
   if(manualRequest&&Date.now()-stable.since>=900){acceptMember(true);return;}
   if(Date.now()-stable.since>=900&&(!['ICE_SINGLE_ID','LEARNED_DOM_ID','COMARCH_MOUSEDOWN_ID','COMARCH_EXACT_MOUSEDOWN_ID'].includes(proof?.mode)||profile.clientId===value.clientId)&&proof?.id===value.clientId&&proof.until>Date.now()&&(context.detected||context.documentKey))acceptMember(false);
   else status('Member erkannt. Falls es nicht automatisch weitergeht: „Übernommene Person prüfen → Schritt 4“.');
   return;
  }
  stable=null;const one=strictSingle(f);
  if(!one){autoCandidate=null;lastSelectionState='WAITING_FOR_USER_OR_UNQUALIFIED_LIST';recordState('WAITING_FOR_REAL_CHOICE');ui.memberInfo.textContent='Vorschlag noch nicht ausgewählt. '+(lastWidgetScan?.state==='MULTIPLE_RENDERED'?'Mehrere Treffer: richtigen COMARCH-Vorschlag selbst anklicken.':lastWidgetScan?.state==='REVIEWED_ID_REQUIRED'?'ICEfaces-Liste erkannt, aber geprüfte MercerID fehlt. Person selbst auswählen.':lastWidgetScan?.state==='COMMIT_PROFILE_REQUIRED'?'Liste erkannt, aber Übernahmeprüfung nicht eindeutig. Person selbst auswählen.':'Keine sichere automatische Auswahlbindung. Den echten Vorschlag einmal selbst anklicken; ich beobachte die Übernahme.')+'\nKomponente: '+(lastWidgetScan?.state??'ARIA_PRUEFUNG')+' | Lokale Liste: '+(lastDomScan?.state??'unbekannt')+' | COMARCH: '+(lastCustomScan?.state??'unbekannt');return;}
  if(!autoCandidate||autoCandidate.element!==one.element||autoCandidate.text!==one.text||autoCandidate.kind!==one.kind||autoCandidate.instance!==one.instance){autoCandidate={...one,since:Date.now()};return;}
  if(Date.now()-autoCandidate.since>=1500){
   // Revalidate linkage, query, names, count and ID immediately before one click.
   gates();const field=contextOK();const fresh=strictSingle(field);
   if(!fresh||fresh.element!==one.element||fresh.id!==one.id||fresh.text!==one.text||fresh.kind!==one.kind||fresh.instance!==one.instance){autoCandidate=null;return;}
   Core.need(field.value===chosen.query,'SEARCH_CHANGED','Suchfeld wurde geändert. Erneut prüfen.');
   autoAttempted=true;autoClickAt=Date.now();proof={id:one.id,until:Date.now()+30000,mode:one.kind};lastSelectionState='AUTO_CLICK_SENT';
   status('Eindeutigen Vorschlag einmal angeklickt. Warte auf die von COMARCH übernommenen MercerID-Stammdaten.');
   if(['COMARCH_MOUSEDOWN_ID','COMARCH_EXACT_MOUSEDOWN_ID'].includes(one.kind)){Suggest.activate(one.element);recordState('MOUSEDOWN_DISPATCHED');}
   else one.element.click();
  }
 }catch(e){error(e);}
}
function acceptMember(explicit){
 if(explicit&&!chosen){chosen={...freezeName(),expectedId:expectedId()};gates();context=bindContext();}
 gates();const f=contextOK(),s=Core.selectedMember(f.value);checkExpected(s);
 const profile=committedProfile(f);Core.need(!profile.ambiguous,'MEMBER_PROFILE_AMBIGUOUS','MercerID-Stammdaten nicht eindeutig.');
 if(explicit){manualRequest=true;waiting=true;if(!waitStarted||Date.now()-waitStarted>120000)waitStarted=Date.now();}
 Core.need(!profile.labelFound||profile.clientId,'MEMBER_COMMIT_PENDING','Vorschlag noch nicht übernommen: In COMARCH den Treffer anklicken und warten, bis MercerID/Vorname/Nachname ausgefüllt sind.');
 Core.need(!profile.clientId||profile.clientId===s.clientId,'MEMBER_PROFILE_CONFLICT','Member-Feld und MercerID-Stammdaten widersprechen sich.');
 Core.need(Person.memberMatches(s.display,chosen),'MEMBER_NAME_CONFLICT','COMARCH-Member stimmt nicht mit geprüftem Vor-/Nachnamen überein. Namen prüfen, nicht die Kennung erraten.');
 Core.need(explicit||(proof?.id===s.clientId&&proof.until>Date.now()),'SELECTION_REVIEW','Person aus der tatsächlichen Trefferliste auswählen und bestätigen.');
 const ids=[...new Set(analysis.idHints.map(x=>x.clientId))];Core.need(ids.length<=1,'MAIL_AMBIGUOUS','Mehrere Personenkennungen in der Mail. Dieser Fall braucht manuelle Klärung.');Core.need(!ids.length||ids[0]===s.clientId,'MAIL_MEMBER_CONFLICT','Mail-Kennung und ausgewählter Member widersprechen sich.');
 // Defer even explicit confirmation until the same field/profile values stayed
 // stable. COMARCH may replace its form nodes after a blur/full iceSubmit.
 if(explicit&&(!stable||stable.value!==f.value||stable.profileId!==profile.clientId||Date.now()-stable.since<900)){
  if(!stable||stable.value!==f.value||stable.profileId!==profile.clientId)stable={value:f.value,profileId:profile.clientId,since:Date.now()};
  status('Übernommene Person wird geprüft. Warte kurz auf stabile MercerID-Daten …');return null;
 }
 if(pendingCustom?.clientId===s.clientId&&profile.clientId===s.clientId&&proof?.mode==='USER_CLICK'&&proof.until>Date.now()){
  customBinding=pendingCustom.binding;recordState('CUSTOM_LIST_LEARNED');
 }
 manualRequest=false;pendingCustom=null;
 if(pendingLearning?.clientId===s.clientId&&profile.clientId===s.clientId&&proof?.mode==='USER_CLICK'&&proof.until>Date.now()){
  learnedList=pendingLearning.binding;recordState('LOCAL_LIST_LEARNED');
 }
 pendingLearning=null;member={...s,element:f};waiting=false;selectionMode=explicit?'USER_CONFIRMATION':proof.mode;selectionCommitted=true;lastSelectionState='MEMBER_CONFIRMED';
 lookupAttempted=true;recordState('LOOKUP_ATTEMPTED');lastBlocking=null;go(4);const entry=Core.lookup(map,s.clientId);
 if(entry.formulas.length&&!ui.formulaOK.checked){status('Quellzeile enthält Formeln. Gespeicherte Werte prüfen und unten bestätigen.');ui.row.textContent='Quellzeile '+entry.sourceRow+' | Formeln in '+entry.formulas.join(', ');return null;}
 result={...entry,description:Core.description(entry),ticket:context.id,memberDisplay:s.display};ui.result.textContent=result.description;
 const showFlag=v=>v===null?'leer → kein Kürzel':String(v);
 ui.row.textContent=['ClientEEID: '+s.clientId,'Excel-Zeile: '+entry.sourceRow,'L / USC: '+entry.usc,'C / DC: '+showFlag(entry.dc)+' | D / PP+: '+showFlag(entry.ppPlus)+' | E / DB+: '+showFlag(entry.dbPlus)].join('\n');
 ui.copy.disabled=false;ui.apply.disabled=false;lastError=null;lastOutcome='LOOKUP_READY';status('4 · Beschreibung bereit. Nur auf deinen Klick wird sie in COMARCH eingesetzt. Noch kein Versand oder Speichern.');return {sourceRow:entry.sourceRow,description:result.description};
}
ui.formulaOK.onchange=safe(()=>{if(member&&ui.formulaOK.checked)return acceptMember(true);clearResult();});
function checkCurrentResult(){Core.need(result&&member,'RESULT_REQUIRED','Zuerst den Member bestätigen und Bestandsabgleich durchführen.');gates();const f=contextOK();Core.need(f===member.element&&f.value===result.memberDisplay,'MEMBER_CHANGED','Member oder Formular wurde nach dem Lookup geändert. Neu bestätigen.');const profile=committedProfile(f);Core.need(!profile.ambiguous&&(!profile.labelFound||profile.clientId===result.clientId),'MEMBER_PROFILE_CONFLICT','MercerID-Stammdaten nach dem Lookup geändert. Neu prüfen.');Core.need(!result.formulas.length||ui.formulaOK.checked,'FORMULA_CACHE_REVIEW','Gespeicherte Formelwerte nicht bestätigt.');return f;}
function descriptionField(){
 const f=checkCurrentResult(),scan=Description.inspect(f,descriptionBinding);lastDescriptionScan=scan.safe;
 Core.need(scan.element,'DESCRIPTION_FIELD',scan.safe.state==='BINDING_STALE'?'Die Feldverbindung ist veraltet. „Beschreibungsfeld verbinden“ erneut verwenden.':'Beschreibungsfeld nicht eindeutig erkannt. „Beschreibungsfeld verbinden“ verwenden oder die Beschreibung kopieren.');
 ui.descriptionInfo.textContent='Zielfeld erkannt: '+scan.safe.route+'. Es wird nur diese Textarea im gleichen Formular verwendet.';
 return scan.element;
}
function armDescriptionPick(){
 checkCurrentResult();Core.need(!descriptionWritePending,'DESCRIPTION_BUSY','Die aktuelle Einfügeprüfung läuft noch.');
 pickMode='DESCRIPTION';pickUntil=Date.now()+30000;
 for(const doc of documents())attachDocument(doc);
 go(4);status('ALT halten und direkt IN das Textfeld „Zusätzliche Beschreibung“ in COMARCH klicken. Nicht in den Kommentar oder Nachrichteneditor. Dieser Markierungsklick schreibt nichts.');
}
function bindDescriptionOutput(element){
 const f=checkCurrentResult();Core.need(!descriptionWritePending,'DESCRIPTION_BUSY','Die aktuelle Einfügeprüfung läuft noch.');
 descriptionBinding=Description.bind(f,element);lastDescriptionScan=Description.inspect(f,descriptionBinding).safe;
 lastError=null;pickMode=null;
 const old=element.style.outline;element.style.outline='3px solid #1d5778';
 setTimeout(()=>{if(element.isConnected)element.style.outline=old;},1600);
 go(4);ui.descriptionInfo.textContent='Beschreibungsfeld verbunden. Noch nichts eingetragen. Jetzt „Beschreibung in COMARCH einsetzen“ klicken.';
 status('Zielfeld verbunden. Das Einsetzen benötigt deinen nächsten Klick.');return {bound:true,writePerformed:false};
}
async function applyDescription(){
 const field=checkCurrentResult();Core.need(!descriptionWritePending,'DESCRIPTION_BUSY','Einfügeprüfung läuft bereits. Kein zweiter Schreibvorgang.');
 const target=descriptionField(),snapshot=result,token=++descriptionWriteToken;
 const guard=()=>{Core.need(alive&&token===descriptionWriteToken&&result===snapshot,'DESCRIPTION_CANCELLED','Einfügen abgebrochen: Fall oder Vorschau wurde geändert.');checkCurrentResult();};
 descriptionWritePending=true;descriptionReadback='VERIFYING';descriptionWritten=false;ui.apply.disabled=true;
 try{
  const written=Description.writeOnce(field,target,snapshot.description,guard);
  lastDescriptionWrite={state:'VERIFYING',events:written.events,changed:written.changed};
  status('Beschreibung eingesetzt; sichtbarer Feldwert wird geprüft. Noch nicht gespeichert.');
  // Delayed readback catches common immediate AJAX resets. It is not proof of
  // server persistence, and it never writes again or presses Save/Enter/blur.
  for(let i=0;i<6;i++){
   await new Promise(resolve=>setTimeout(resolve,150));guard();
   Core.need(Description.shape(field,target)&&target.value===snapshot.description,'DESCRIPTION_VERIFY','COMARCH hat den Text verändert oder das Feld ersetzt. Kein erneutes Schreiben. Das echte Formular prüfen.');
  }
  descriptionAppliedNode=target;descriptionWritten=true;descriptionReadback='DOM_VERIFIED';lastError=null;lastOutcome='DESCRIPTION_INSERTED';
  lastDescriptionWrite={state:'DOM_VERIFIED',events:written.events,changed:written.changed};
  ui.descriptionInfo.textContent=(written.changed?'Text einmal eingesetzt und nachgelesen.':'Der identische Text war bereits vorhanden; nichts erneut geschrieben.')+'\nNur der sichtbare Formularwert ist geprüft, keine Speicherung auf dem Server.';
  status('Beschreibung steht im Formular. Der Helfer hat weder „Ticket speichern“ noch „Senden“ betätigt. Restlichen Ablauf selbst abschließen.');
  return {domVerified:true,serverSaveVerified:false,changed:written.changed};
 }catch(e){
  if(!alive||token!==descriptionWriteToken)return {cancelled:true};
  throw e;
 }finally{
  if(token===descriptionWriteToken){descriptionWritePending=false;ui.apply.disabled=!result;ui.copy.disabled=!result;}
 }
}
function resetCase(){profileBinding=null;customBinding=null;++caseEpoch;invalidate();mail=null;analysis=null;candidates=[];ui.mailFile.value='';ui.raw.value='';ui.body.textContent='Noch kein Text.';ui.mailInfo.textContent='Noch keine Mail geladen.';ui.names.replaceChildren();ui.first.value='';ui.last.value='';ui.expected.value='';idHints=[];ui.idInfo.textContent='Kein Kennungshinweis aus der Mail.';ui.ticket.value='';ui.mailOK.checked=false;ui.formulaOK.checked=false;ui.memberInfo.textContent='Noch keine Member-Suche gestartet.';lastError=null;lastOutcome=null;format=null;lastWidgetScan=null;go(map&&ui.sourceOK.checked?2:1);status('Neuer Fall. Mapping bleibt geladen. Jetzt die Original-Mail des nächsten Tickets auswählen.');}
function diagnostic(){
 let widget={fieldPresent:false,linkedList:false,declaredCompleteSingle:false,profileLabelFound:false,profileIdPresent:false};
 try{const f=memberField(),p=committedProfile(f);widget={fieldPresent:true,linkedList:!!(f.getAttribute('aria-controls')||f.getAttribute('aria-owns')),declaredCompleteSingle:!!autoCandidate,profileLabelFound:p.labelFound,profileIdPresent:!!p.clientId};}catch{}
 return {schema:'MCR_MAIL_DIAGNOSTIC_V1',version:'0.3.6',createdAt:new Date().toISOString(),
 capabilities:{readsMsg:true,networkUpload:false,automaticSend:false,automaticSave:false,confirmedMemberSearch:true,confirmedDescriptionInsert:true},
 mapping:{loaded:!!map,flagPolicy:map?Core.policyOf(map.payload):null,sourceConfirmed:ui.sourceOK.checked,selectedKeyBlocked:!!lastBlocking,blockedCodes:lastBlocking?.codes??[],blockedIssues:lastBlocking?.issues??[],blockedSourceRowCount:lastBlocking?.sourceRows.length??0},
 mail:{format,nameCandidates:candidates.length,idCandidates:new Set(idHints.map(x=>x.clientId)).size,explicitIdCandidates:analysis?.idHints.length??0,plainText:!!mail},
 description:{target:lastDescriptionScan,bound:!!descriptionBinding,writePending:descriptionWritePending,readback:descriptionReadback,lastWrite:lastDescriptionWrite},
 flow:{waiting,selectionMode,selectionCommitted,lastSelectionState,ticketAutoBound:context?.detected??false,caseBinding:context?.mode??null,lookupAttempted,lookupKeySource:lookupAttempted?'SELECTED_MEMBER':null,lookupReady:!!result,descriptionWritten,lastOutcome,autoClickAttempted:autoAttempted,selectionEvent:['COMARCH_MOUSEDOWN_ID','COMARCH_EXACT_MOUSEDOWN_ID'].includes(proof?.mode)?'mousedown':autoAttempted?'click':null,manualConfirmationPending:manualRequest},widget:{...widget,profile:lastProfileScan,custom:lastCustomScan,ice:lastWidgetScan,localList:lastDomScan,learnedList:!!learnedList,fieldSignals:{...fieldSignals},choiceStructure:lastManualShape},selectionTrace:selectionTrace.map(x=>({...x})),lastError};
}
function crc32(bytes){let c=0xffffffff;for(const b of bytes){c^=b;for(let k=0;k<8;k++)c=(c&1)?0xedb88320^(c>>>1):c>>>1;}return(c^0xffffffff)>>>0;}
function storeZip(files){
 let offset=0;const local=[],central=[],enc=new TextEncoder();
 const concat=parts=>{const all=new Uint8Array(parts.reduce((n,p)=>n+p.length,0));let i=0;for(const p of parts){all.set(p,i);i+=p.length;}return all;};
 for(const [name,text] of files){
  const n=enc.encode(name),data=enc.encode(text),crc=crc32(data),h=new Uint8Array(30),v=new DataView(h.buffer);
  v.setUint32(0,0x04034b50,true);v.setUint16(4,20,true);v.setUint16(6,0x800,true);v.setUint16(12,33,true);v.setUint32(14,crc,true);v.setUint32(18,data.length,true);v.setUint32(22,data.length,true);v.setUint16(26,n.length,true);
  const c=new Uint8Array(46),cv=new DataView(c.buffer);cv.setUint32(0,0x02014b50,true);cv.setUint16(4,20,true);cv.setUint16(6,20,true);cv.setUint16(8,0x800,true);cv.setUint16(14,33,true);cv.setUint32(16,crc,true);cv.setUint32(20,data.length,true);cv.setUint32(24,data.length,true);cv.setUint16(28,n.length,true);cv.setUint32(42,offset,true);
  local.push(h,n,data);central.push(c,n);offset+=h.length+n.length+data.length;
 }
 const cd=concat(central),end=new Uint8Array(22),ev=new DataView(end.buffer);ev.setUint32(0,0x06054b50,true);ev.setUint16(8,files.length,true);ev.setUint16(10,files.length,true);ev.setUint32(12,cd.length,true);ev.setUint32(16,offset,true);
 return concat([...local,cd,end]);
}

async function diagnosticBytes(){
 const report=JSON.stringify(diagnostic(),null,2)+'\n',hash=await sha(report);
 const manifest=JSON.stringify({schema:'MCR_DIAGNOSTIC_MANIFEST_V1',payload:[{path:'diagnostic.json',sha256:hash}],privacy:'No mail bytes/text, names, identifiers, filenames, addresses, URLs, cookies, mapping values or document HTML.'},null,2)+'\n';
 return storeZip([['diagnostic.json',report],['manifest.json',manifest],['SHA256SUMS.txt',hash+'  diagnostic.json\n'+await sha(manifest)+'  manifest.json\n']]);
}
async function downloadDiagnostic(){const bytes=await diagnosticBytes(),hash=await sha(bytes),url=URL.createObjectURL(new Blob([bytes],{type:'application/zip'})),a=D.createElement('a');a.href=url;a.download='MCR_MAIL_'+new Date().toISOString().replace(/[:.]/g,'-')+'_UPLOAD.zip';a.click();setTimeout(()=>URL.revokeObjectURL(url),20000);status('Diagnose-ZIP erstellt (ohne Mail/Mapping). ZIP-SHA256: '+hash);}
function close(){alive=false;++descriptionWriteToken;descriptionWritePending=false;descriptionBinding=null;descriptionAppliedNode=null;++caseEpoch;++mapEpoch;clearInterval(timer);for(const doc of listeners.keys()){doc.removeEventListener('pointerdown',capturePick,true);doc.removeEventListener('mousedown',capturePick,true);doc.removeEventListener('click',capturePick,true);doc.removeEventListener('mouseup',capturePick,true);doc.removeEventListener('keydown',cancelPick,true);doc.removeEventListener('pointerdown',observeChoice,true);doc.removeEventListener('mousedown',observeChoice,true);for(const type of ['input','change','keyup'])doc.removeEventListener(type,observeFieldSignal,true);}listeners.clear();map=null;mail=null;analysis=null;candidates=[];member=null;result=null;proof=null;chosen=null;context=null;ui.raw.value='';ui.body.textContent='';ui.first.value='';ui.last.value='';ui.expected.value='';idHints=[];lastBlocking=null;learnedList=null;pendingLearning=null;lastManualShape=[];profileBinding=null;customBinding=null;pendingCustom=null;pickMode=null;host.remove();if(T.MCR_MAIL===api)delete T.MCR_MAIL;if(W.MCR_MAIL===api)delete W.MCR_MAIL;}
const timer=setInterval(tick,350);
const api=Object.freeze({version:'0.3.6',loadMapText,loadMailBytes,setMail,startSearch,acceptMember,bindProfile:bindProfileOutput,bindDescription:bindDescriptionOutput,resetCase,diagnostic,diagnosticBytes,close});
T.MCR_MAIL=api;W.MCR_MAIL=api;
console.info('MCR Mail-Assistent 0.3.6 aktiv. Keine Mail-/Personenwerte in der Konsole. Kein Versand, kein Ticket-Speichern.');

let __runnerSwitched=false;const __runnerWatch=setInterval(()=>{try{const d=__runnerTop.MCR_MAIL?.diagnostic?.();if(!__runnerSwitched&&d?.flow?.descriptionWritten){__runnerSwitched=true;clearInterval(__runnerWatch);setTimeout(__startPrep,250);}}catch{}},400);
__runnerTop.MCR_RUNNER=Object.freeze({version:"0.4.1",startPrep:__startPrep,diagnostic:()=>({schema:"MCR_RUNNER_DIAGNOSTIC_V1",version:"0.4.1",phase:__runnerTop.MCR_PREP?"PREP":__runnerTop.MCR_MAIL?"MAIL":"IDLE",automaticSend:false,automaticSave:false})});
console.info("MCR Ticket Runner 0.4.1 aktiv. Ein Skript bis zum Pre-Send-Gate; kein Senden, kein Ticket-Speichern.");
})();
