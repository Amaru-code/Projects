using System.IO.Compression;
using System.Security.Cryptography;
using System.Xml.Linq;

namespace Mcr.Ipp.Core;

public sealed class TemplateAudit
{
    public string Schema { get; set; } = "MCR_IPP_TEMPLATE_AUDIT_V1";
    public string SourceSha256 { get; set; } = "";
    public bool MatchesKnownIppTemplate { get; set; }
    public List<string> Sheets { get; set; } = new();
    public List<string> ExternalFileNames { get; set; } = new();
    public List<string> BrokenFormulaAddresses { get; set; } = new();
    public List<string> ActiveParts { get; set; } = new();
    public List<string> Blockers { get; set; } = new();
    public bool AutomaticMappingAuthorized { get; set; } = false;
    public bool ProductionPdfAuthorized { get; set; } = false;
}
public static class TemplatePreparation
{
    public const string KnownIppHash = "A9F51A8CC0614A96903AE8975F6967D26549011CD8EDFB0DA0F028EABD0C591B";
    public static TemplateAudit Inspect(SourceBlob blob)
    {
        if (Convert.ToHexString(SHA256.HashData(blob.Bytes)) != blob.Info.Sha256) throw new IppException("SOURCE_HASH_MISMATCH", "Inhalt und Quellenidentitaet stimmen nicht ueberein.");
        using var reader = new SpreadsheetReader(blob.Bytes);
        var audit = new TemplateAudit { SourceSha256 = blob.Info.Sha256, MatchesKnownIppTemplate = blob.Info.Sha256 == KnownIppHash, Sheets = reader.Sheets.Select(s => s.Name).ToList() };
        var active = new[] { "xl/macrosheets/", "xl/intlmacrosheets/", "xl/activeX/", "xl/embeddings/", "xl/connections.xml", "xl/queryTables/", "xl/model/", "xl/pivotCache/", "_xmlsignatures/" };
        audit.ActiveParts = reader.Parts.Where(p => active.Any(a => p.StartsWith(a, StringComparison.OrdinalIgnoreCase))).ToList();
        audit.ActiveParts.AddRange(reader.Sheets.Where(s => !s.Kind.EndsWith("/worksheet", StringComparison.Ordinal)).Select(s => "NON_WORKSHEET:" + s.Name));
        if (!audit.MatchesKnownIppTemplate) audit.Blockers.Add("IPP_TEMPLATE_IDENTITY_NOT_MATCHED");
        if (reader.Sheets.Any(s => s.Name.StartsWith("LNW DC", StringComparison.OrdinalIgnoreCase) || s.Name == "Import DC")) audit.Blockers.Add("DC_TEMPLATE_EXCLUDED");
        foreach (var required in new[] { "Import Austritte UVA", "Import verfallbar", "Eckwerte und Zins", "Planabhängige Tabelle", "LE" })
            if (!audit.Sheets.Contains(required)) audit.Blockers.Add("MISSING_SHEET:" + required);
        var refs = reader.Workbook.Descendants(SpreadsheetReader.Main + "externalReference").ToList();
        foreach (var ext in refs)
        {
            var rel = reader.Relationship("xl/workbook.xml", (string?)ext.Attribute(SpreadsheetReader.Rel + "id") ?? "");
            var part = SpreadsheetReader.Resolve("xl/workbook.xml", rel);
            var book = reader.Xml(part).Root?.Element(SpreadsheetReader.Main + "externalBook");
            if (book is null) { audit.Blockers.Add("NON_WORKBOOK_EXTERNAL_REFERENCE"); continue; }
            var tr = reader.Relationship(part, (string?)book.Attribute(SpreadsheetReader.Rel + "id") ?? "");
            var target = (string?)tr.Attribute("Target") ?? "";
            if (Uri.TryCreate(target, UriKind.Absolute, out var u) && (u.Scheme == "https" || u.Scheme == "http")) target = u.AbsolutePath;
            audit.ExternalFileNames.Add(Uri.UnescapeDataString(target).Replace('\\','/').Split('/').Last());
        }
        foreach (var sheet in reader.Sheets.Where(s => s.Kind.EndsWith("/worksheet", StringComparison.Ordinal)))
        {
            foreach (var c in reader.Cells(sheet).Where(c => c.Formula is not null))
            {
                if (c.Formula!.Contains("#REF!", StringComparison.Ordinal)) audit.BrokenFormulaAddresses.Add(sheet.Name + "!" + c.Address);
                var formula = c.Formula.ToUpperInvariant();
                if (new[] { "WEBSERVICE(", "RTD(", "REGISTER.ID(", "CALL(", "|" }.Any(formula.Contains)) audit.ActiveParts.Add("ACTIVE_FORMULA:" + sheet.Name + "!" + c.Address);
            }
        }
        if (audit.ExternalFileNames.Count > 0) audit.Blockers.Add("EXTERNAL_DATA_AND_UDF_DEPENDENCIES_UNQUALIFIED");
        if (audit.BrokenFormulaAddresses.Count > 0) audit.Blockers.Add("BROKEN_FORMULAS_EXIST");
        if (audit.ActiveParts.Count > 0) audit.Blockers.Add("ACTIVE_CONTENT_OR_PACKAGE_SIGNATURE_REQUIRES_REVIEW");
        audit.Blockers.AddRange(new[] { "BEITRAGSBEREITSTELLUNG_PERIOD_AND_AGGREGATION_NOT_BOUND", "CLIENTID_TO_WWID_NOT_CERTIFIED", "BALANCES_AND_SHADOW_INTEREST_SOURCE_NOT_BOUND", "DOCUMENT_SELECTION_AND_VESTING_NOT_BOUND" });
        return audit;
    }
    public static object CreateStagingCopy(SourceBlob source, ContributionResult result, string destination)
    {
        var audit = Inspect(source);
        if (!audit.MatchesKnownIppTemplate || audit.Blockers.Contains("DC_TEMPLATE_EXCLUDED")) throw new IppException("IPP_TEMPLATE_IDENTITY", "Nur die bekannte IPP-Arbeitsmappe darf vorbereitet werden. Kein DC-/Benchmark-Ersatz.");
        using var reader = new SpreadsheetReader(source.Bytes);
        if (reader.Parts.Any(p => p.StartsWith("_xmlsignatures/", StringComparison.OrdinalIgnoreCase))) throw new IppException("SIGNED_PACKAGE", "Signiertes Office-Paket wird nicht veraendert.");
        var newSheets = new[]
        {
            new OutputSheet("MCR_Status", new(){"Status", "Bedeutung"}, new()
            {
                new(){"NICHT_FREIGEGEBEN", "Nur technische IPP-Vorbereitung; keine aktualisierte/fachlich gepruefte LNW."},
                new(){"Monatsdaten", "MCR_Beitraege enthaelt die C#-Beitraege. Bestehende Importdaten/Formeln wurden NICHT neu befuellt."},
                new(){"PDF", "Keine automatische PDF-Freigabe; Datenzuordnung und externe Funktionen offen."},
                new(){"Quelle SHA256", source.Info.Sha256},
                new(){"Profil", result.Profile},
                new(){"Offene Personenfaelle", result.PersonReview?.OpenCases ?? 0},
                new(){"Bestaetigte Neueintritte", result.PersonReview?.AddedPersons ?? 0},
                new(){"Personenstatus", result.PersonReview is { OpenCases: > 0 } ? "TEILERGEBNIS: Offene Personen NICHT in MCR_Beitraege; Prueffaelle.xlsx beachten." : "Keine offenen Kennungsfaelle in diesem Lauf; keine fachliche Gesamtfreigabe."},
                new(){"Offene Tarifmonate", result.TariffReview?.OpenMonthCases ?? 0},
                new(){"Personen mit Tarifpruefung", result.TariffReview?.AffectedPersons ?? 0},
                new(){"Tarifstatus", result.TariffReview is { OpenMonthCases: > 0 } ? "TEILERGEBNIS: ATTC/Fallback erhalten; nur Betrag offener Tarifmonate leer, nicht 0 Euro; Tarifpruefung.xlsx beachten." : "Keine offenen Tarifmonate gemeldet; keine fachliche Gesamtfreigabe."},
                new(){"Zeitraum", result.Year + ": " + string.Join(", ", result.Months)},
                new(){"Finanzielle Aussage", "Keine Beitragsbereitstellung/Jahressumme erfunden. Originalvorlage unveraendert."}
            }),
            SpreadsheetWriter.Contributions(result, "MCR_Beitraege")
        };
        foreach (var s in newSheets) if (reader.Sheets.Any(old => old.Name == s.Name)) throw new IppException("STAGING_ALREADY_PRESENT", "MCR-Staging-Blaetter existieren bereits; unveraenderte Originalvorlage verwenden.");
        var workbook = reader.Xml("xl/workbook.xml");
        var relationships = reader.Xml("xl/_rels/workbook.xml.rels");
        var types = reader.Xml("[Content_Types].xml");
        var wbSheets = workbook.Root!.Element(SpreadsheetReader.Main + "sheets")!;
        int maxId = wbSheets.Elements().Select(s => (int?)s.Attribute("sheetId") ?? 0).DefaultIfEmpty().Max();
        var added = new Dictionary<string, XDocument>(StringComparer.Ordinal);
        int i = 0;
        foreach (var s in newSheets)
        {
            i++; string id = "rIdMcrIpp" + i, part = "xl/worksheets/mcrIpp" + i + ".xml";
            if (reader.Has(part) || relationships.Root!.Elements().Any(r => (string?)r.Attribute("Id") == id)) throw new IppException("STAGING_COLLISION", "Paketname schon vergeben.");
            wbSheets.Add(new XElement(SpreadsheetReader.Main + "sheet", new XAttribute("name", s.Name), new XAttribute("sheetId", maxId + i), new XAttribute(SpreadsheetReader.Rel + "id", id)));
            relationships.Root!.Add(new XElement(SpreadsheetReader.Pkg + "Relationship", new XAttribute("Id", id), new XAttribute("Type", SpreadsheetReader.Rel.NamespaceName + "/worksheet"), new XAttribute("Target", "worksheets/mcrIpp" + i + ".xml")));
            types.Root!.Add(new XElement(types.Root.Name.Namespace + "Override", new XAttribute("PartName", "/" + part), new XAttribute("ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml")));
            // No new style dependencies are injected into the source .xlsm.
            added.Add(part, SpreadsheetWriter.SheetXml(s, styled:false));
        }
        var view = workbook.Descendants(SpreadsheetReader.Main + "workbookView").FirstOrDefault();
        if (view is not null) view.SetAttributeValue("activeTab", reader.Sheets.Count);
        var replacements = new Dictionary<string, XDocument> { ["xl/workbook.xml"] = workbook, ["xl/_rels/workbook.xml.rels"] = relationships, ["[Content_Types].xml"] = types };
        using (var originalStream = new MemoryStream(source.Bytes, false))
        using (var original = new ZipArchive(originalStream, ZipArchiveMode.Read))
        using (var file = new FileStream(destination, FileMode.CreateNew, FileAccess.Write, FileShare.None))
        using (var output = new ZipArchive(file, ZipArchiveMode.Create))
        {
            foreach (var entry in original.Entries)
            {
                if (replacements.TryGetValue(entry.FullName, out var xml)) { SpreadsheetWriter.Put(output, entry.FullName, xml); continue; }
                var copy = output.CreateEntry(entry.FullName, CompressionLevel.Optimal); using var src = entry.Open(); using var dst = copy.Open(); src.CopyTo(dst);
            }
            foreach (var pair in added) SpreadsheetWriter.Put(output, pair.Key, pair.Value);
        }
        // Verify unchanged uncompressed payloads, including VBA, all old sheets, styles, external links.
        using var srcZip = new ZipArchive(new MemoryStream(source.Bytes, false), ZipArchiveMode.Read);
        using var dstZip = ZipFile.OpenRead(destination);
        int verified = 0;
        foreach (var old in srcZip.Entries.Where(e => !replacements.ContainsKey(e.FullName)))
        {
            var fresh = dstZip.GetEntry(old.FullName) ?? throw new IppException("STAGING_VERIFY", "Originalbestandteil verloren.");
            using var a = old.Open(); using var b = fresh.Open();
            if (!SHA256.HashData(a).SequenceEqual(SHA256.HashData(b))) throw new IppException("STAGING_VERIFY", "Originalbestandteil veraendert: " + old.FullName);
            verified++;
        }
        return new { schema = "MCR_IPP_STAGING_PROOF_V1", source = source.Info, outputSha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(destination))), unchangedPayloadsVerified = verified, modifiedParts = replacements.Keys, newParts = added.Keys, existingImportDataChanged = false, vbaExecuted = false, excelRecalculated = false, productionAuthorized = false };
    }
}
