using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace Mcr.Ipp.Core;

public sealed class ContributionDocumentItem
{
    public string ClientId { get; set; } = "";
    public string Name { get; set; } = "";
    public string Status { get; set; } = "PLANNED";
    public string? File { get; set; }
    public string? Sha256 { get; set; }
    public long Bytes { get; set; }
    public int Pages { get; set; }
    public int OpenTariffMonths { get; set; }
    public int MonthsWithoutAmount { get; set; }
    public string Note { get; set; } = "";
}
public sealed class ContributionDocumentReport
{
    public string Schema { get; set; } = "MCR_IPP_CONTRIBUTION_DRAFTS_V1";
    public string Status { get; set; } = "NOT_REQUESTED";
    public string Mode { get; set; } = "INTERNAL_MONTHLY_CONTRIBUTION_DRAFT_ONLY";
    public string ContributionSha256 { get; set; } = "";
    public bool ProductionAuthorized { get; set; } = false;
    public bool IppMappingPerformed { get; set; } = false;
    public List<ContributionDocumentItem> Items { get; set; } = new();
    public int Created => Items.Count(i => i.Status == "DRAFT_CREATED");
    public int Failed => Items.Count(i => i.Status == "DRAFT_FAILED");
    public int PersonsNotAdmitted => Items.Count(i => i.Status == "NOT_CREATED_PERSON_REVIEW_OPEN");
}
/// <summary>Person-specific PDF drafts of the current contribution result. Never writes
/// pension balances, never selects UVA versus LNW, never interprets new external sources.</summary>
public static class ContributionDocuments
{
    public const string FolderName = "PDF_Entwuerfe";
    private static readonly CultureInfo De = CultureInfo.GetCultureInfo("de-DE");
    public static string DisplayName(PersonResult p)
    {
        string name = string.Join(" ", new[] { Parse.Text(p.Master.GetValueOrDefault("FirstName")), Parse.Text(p.Master.GetValueOrDefault("Surname")) }.Where(value => value is not null));
        return name.Length > 0 ? name : "NAME_NICHT_GELIEFERT";
    }
    private static string Number(double? value, int width)
    {
        if (value is { } d && !double.IsFinite(d)) throw new IppException("PDF_NUMBER", "Nichtendliche Zahl im PDF-Ergebnis.");
        string text = value is null ? "--" : value.Value.ToString("N2", De);
        if (text.Length > width) throw new IppException("PDF_VALUE_WIDTH", "Zahl zu breit fuer die PDF-Tabelle; kein Abschneiden.");
        return text.PadLeft(width);
    }
    public static string AmountLabel(MonthlyResult r) => r.AmountStatus switch
    {
        "BEFORE_DAT_AD2" => "VOR EINTRITT",
        "AFTER_AUGUAN_EXIT" => "NACH AUSTRITT",
        "EXCLUDED_TARIFF_98_99" => "TARIF 98/99",
        "HELD_TARIFF_REVIEW" => "TARIF OFFEN",
        "CALCULATED_NOT_BUSINESS_APPROVED" => "BERECHNET*",
        _ => r.TariffReviewRequired ? "TARIF OFFEN" : r.Amount is not null ? "BERECHNET*" : "DATEN FEHLEN / TZG=0"
    };
    private static string Origin(string source) => source switch
    {
        "BASE_SALARY_1" => "Bestand: BaseSalary_1",
        "PREVIOUS_MONTH" => "direkter Vormonat",
        "TXT_ATTC_BAV_AKTAN" => "TXT: ATTC_BAV / AKTAN",
        "MISSING" => "keine Gehaltsquelle",
        _ => source
    };
    public static List<DraftLine> PersonLines(ContributionResult result, PersonResult p, string sourceHash)
    {
        var lines = new List<DraftLine>();
        void Add(string text = "", bool bold = false, bool alert = false) => lines.AddRange(DraftPdf.Wrap(text, bold, alert));
        Add("Person: " + DisplayName(p), true);
        Add("Ausgewaehlte Monate: " + string.Join(", ", result.Months.Select(m => new DateOnly(result.Year, m, 1).ToString("yyyy-MM", Parse.Inv))));
        int held = p.Months.Values.Count(m => m.TariffReviewRequired);
        Add(held > 0 ? $"PRUEFSTATUS: {held} Tarifmonate offen. Gehalt sichtbar, Beitrag zurueckgehalten."
            : "PRUEFSTATUS: Keine offene Tarifpruefung; keine fachliche Gesamtfreigabe.", true, held > 0);
        Add("Die Angaben zeigen Monatsbeitraege, keine Leistungs- oder Rentenberechnung.");
        Add();
        Add("MONAT          ATTC EUR       TZG**      BEITRAG EUR  STATUS", true);
        Add(new string('-', 88));
        foreach (int m in result.Months)
        {
            var r = p.Months[m];
            Add(r.SalaryDate.ToString("yyyy-MM", Parse.Inv).PadRight(10) + Number(r.Attc, 15) + " " + Number(r.Tzg, 10)
                + " " + Number(r.Amount, 16) + "  " + AmountLabel(r), false, r.TariffReviewRequired);
        }
        Add(new string('-', 88));
        // Never present a subtotal as the entire contractual contribution provision.
        if (p.Months.Values.All(m => m.Amount is not null && !m.TariffReviewRequired))
        {
            decimal sum = p.Months.Values.Sum(m => decimal.Parse(m.Amount!.Value.ToString("F2", Parse.Inv), Parse.Inv));
            Add("Summe genau dieser ausgewiesenen Monatsbetraege: " + sum.ToString("N2", De) + " EUR", true);
            Add("Nur Rechensumme; KEINE Beitragsbereitstellung, kein Jahres- oder Kontosaldo.");
        }
        else Add("Keine Gesamtsumme: mindestens ein Monat fehlt, ist gesperrt oder ausgenommen.", true, true);
        Add();
        Add("HERKUNFT UND MONATSPRUEFUNG", true);
        foreach (int m in result.Months)
        {
            var r = p.Months[m];
            string tariff = r.EffectiveTariff?.ToString("0", Parse.Inv) ?? "unbekannt";
            Add($"{r.SalaryDate:yyyy-MM} | ATTC: {Origin(r.AttcSource)} | Tarif: {tariff}");
            if (r.Reasons.Count > 0) Add("  Hinweise: " + string.Join("; ", r.Reasons));
        }
        Add();
        Add("* Berechnet bedeutet NICHT fachlich freigegeben. -- ist leer, nicht 0 EUR.");
        Add("** TZG wird wie in Ergebnis.xlsx gezeigt; Faktor-/Prozenteinheit lokal pruefen.");
        Add("ATTC aus Bestand/TXT/Vormonat ist ein Gehaltswert, keine Tarifbestaetigung.");
        Add("Salden, Zinsen, Initialbausteine und Garantierenten sind hier NICHT berechnet.");
        Add("Offene TXT-Personen wurden nicht aufgenommen; siehe Prueffaelle.xlsx.");
        Add();
        Add("QUELLENBINDUNG: Contribution_Result.json / SHA256", true);
        Add(sourceHash);
        Add("Detaillierte Herkunft: Monatsprotokoll.csv / Tarif_Pruefung.json im selben Lauf.");
        return lines;
    }
    public static ContributionDocumentReport Write(string runDirectory, ContributionResult result, bool createPdfs,
        Action<string>? progress = null, CancellationToken cancel = default)
    {
        cancel.ThrowIfCancellationRequested();
        if (result.PdfAuthorized || result.IppMappingStatus != "NOT_BOUND")
            throw new IppException("DRAFT_SCOPE", "Dieser Adapter erlaubt ausschliesslich interne Beitragsentwuerfe ohne IPP-Mapping.");
        if (result.Persons.Count == 0 || result.Months.Count is < 1 or > 12 || result.Year is < 2012 or > 9998
            || result.Months.Any(m => m is < 1 or > 12) || !result.Months.SequenceEqual(result.Months.Distinct().OrderBy(m => m)))
            throw new IppException("DRAFT_SCHEMA", "Ungueltiger Ergebnisumfang.");
        if (result.Persons.Select(p => p.ClientId).Distinct(StringComparer.Ordinal).Count() != result.Persons.Count)
            throw new IppException("DRAFT_DUPLICATE_ID", "Doppelte Person im Dokumentenplan.");
        foreach (var p in result.Persons)
        {
            if (Parse.Id(p.ClientId) != p.ClientId || !p.Months.Keys.SequenceEqual(result.Months)
                || p.Months.Any(x => x.Value.Month != x.Key || x.Value.SalaryDate != new DateOnly(result.Year, x.Key, 1)))
                throw new IppException("DRAFT_SCHEMA", "Person/Monate stimmen nicht mit dem Ergebnisumfang ueberein.");
            if (p.Months.Values.Any(m => m.TariffReviewRequired && m.Amount is not null))
                throw new IppException("DRAFT_UNSAFE_AMOUNT", "Offener Tarifmonat enthaelt einen freizugebenden Betrag.");
        }
        byte[] serialized = JsonSerializer.SerializeToUtf8Bytes(result, JsonFiles.Options);
        byte[] saved = File.ReadAllBytes(Path.Combine(runDirectory, "Contribution_Result.json"));
        if (!serialized.AsSpan().SequenceEqual(saved)) throw new IppException("DRAFT_SOURCE_CHANGED", "Beitrags-Snapshot stimmt nicht mit dem aktuellen Rechenergebnis ueberein.");
        var report = new ContributionDocumentReport { ContributionSha256 = Convert.ToHexString(SHA256.HashData(saved)) };
        string pdfFinal = Path.Combine(runDirectory, FolderName);
        string? staging = null;
        if (createPdfs)
        {
            if (Directory.Exists(pdfFinal)) throw new IppException("DRAFT_OUTPUT_EXISTS", "PDF-Ordner existiert bereits; keine Ueberschreibung.");
            staging = Path.Combine(runDirectory, ".pdf_inprogress_" + Guid.NewGuid().ToString("N")); Directory.CreateDirectory(staging);
        }
        bool moved = false;
        try
        {
            int processed = 0;
            foreach (var p in result.Persons)
            {
                cancel.ThrowIfCancellationRequested();
                var item = new ContributionDocumentItem { ClientId = p.ClientId, Name = DisplayName(p),
                    OpenTariffMonths = p.Months.Values.Count(m => m.TariffReviewRequired),
                    MonthsWithoutAmount = p.Months.Values.Count(m => m.Amount is null),
                    Status = createPdfs ? "PLANNED" : "DRAFT_NOT_REQUESTED",
                    Note = "Nur interne Monatsuebersicht. IPP/LNW-Produktion und Versand NICHT freigegeben." };
                if (createPdfs)
                {
                    string filename = $"ENTWURF_IPP_Beitraege_{p.ClientId}_{result.Year}.pdf";
                    try
                    {
                        var pdf = DraftPdf.Render(p.ClientId, PersonLines(result, p, report.ContributionSha256));
                        cancel.ThrowIfCancellationRequested();
                        using (var stream = new FileStream(Path.Combine(staging!, filename), FileMode.CreateNew, FileAccess.Write, FileShare.None))
                            stream.Write(pdf.Bytes, 0, pdf.Bytes.Length);
                        item.File = FolderName + "/" + filename; item.Sha256 = Convert.ToHexString(SHA256.HashData(pdf.Bytes));
                        item.Bytes = pdf.Bytes.LongLength; item.Pages = pdf.Pages; item.Status = "DRAFT_CREATED";
                    }
                    catch (IppException ex) when (ex.Code is "PDF_TEXT_UNSUPPORTED" or "PDF_TEXT_TOO_LONG" or "PDF_LAYOUT_LIMIT" or "PDF_LAYOUT_WIDTH" or "PDF_VALUE_WIDTH" or "PDF_NUMBER")
                    { item.Status = "DRAFT_FAILED"; item.Note = ex.Code + ": " + ex.Message; }
                }
                report.Items.Add(item);
                if (++processed % 100 == 0 || processed == result.Persons.Count)
                    progress?.Invoke($"Dokumentenplan: {processed}/{result.Persons.Count}; {report.Created} interne PDF-Entwuerfe, {report.Failed} PDF-Prueffaelle.");
            }
            foreach (var c in result.PersonReview?.Cases.Where(c => !c.Added) ?? Enumerable.Empty<PersonCase>())
                report.Items.Add(new() { ClientId = c.ClientId, Name = c.DisplayName, Status = "NOT_CREATED_PERSON_REVIEW_OPEN", Note = "Person nicht aufgenommen. Kein PDF; siehe Prueffaelle.xlsx." });
            report.Status = !createPdfs ? "DRAFT_NOT_REQUESTED" : report.Failed > 0 ? "PARTIAL_DRAFTS_WITH_ERRORS"
                : report.PersonsNotAdmitted > 0 || report.Items.Any(i => i.OpenTariffMonths > 0 || i.MonthsWithoutAmount > 0)
                    ? "DRAFTS_CREATED_WITH_REVIEW" : "DRAFTS_CREATED_NOT_BUSINESS_APPROVED";
            cancel.ThrowIfCancellationRequested();
            if (staging is not null) { Directory.Move(staging, pdfFinal); moved = true; }
            JsonFiles.Write(Path.Combine(runDirectory, "Dokumentenplan.json"), report);
            var rows = report.Items.Select(i => new List<object?> { i.ClientId, i.Name, i.Status, i.File, i.OpenTariffMonths, i.MonthsWithoutAmount, i.Pages, i.Note, i.Sha256 }).ToList();
            foreach (var row in rows)
                for (int i = 0; i < row.Count; i++)
                    if (row[i] is string text && text.Length > 30000) row[i] = text[..30000] + " [GEKUERZT; siehe JSON]";
            SpreadsheetWriter.Write(Path.Combine(runDirectory, "Dokumentenplan.xlsx"), new OutputSheet("Dokumente", new()
                { "ClientID", "Name", "Entwurfsstatus", "PDF-Datei relativ", "Tarifmonate offen", "Monate ohne Betrag", "PDF-Seiten", "Hinweis", "PDF SHA256" }, rows)
                { ReviewLayout = true, ColumnWidths = new() { 16, 27, 32, 40, 18, 18, 12, 40, 40 } });
            return report;
        }
        finally
        {
            // Only our own incomplete draft directory may be removed. Source and completed runs are untouched.
            if (!moved && staging is not null && Directory.Exists(staging)) Directory.Delete(staging, true);
        }
    }
}
