# Beitragskern: Referenzvertrag und Grenzen

Stand: 29.09.2026. Quelle ist der zuletzt im Chat gepostete Python-Code des Nutzers.
Es handelt sich nicht um eine neue Auslegung von IPP oder des Betriebsrentenrechts.
Keine DC-Formeln werden verwendet.

## Referenzkern und technische Änderungen

Der Ausdruck `8116,67, 12158,33` erzeugt im letzten Python-Tupel insgesamt sechs
Elemente. Die Schleife verlangt vier. Der enthaltene Referenzgenerator reproduziert
beim Erreichen dieses Tupels den Unpacking-Fehler. T01 schreibt zwei Dezimalzahlen
`8116.67`, `12158.33`. Die wirtschaftliche Richtigkeit dieser Eckwerte ist nicht geprüft.
T02 stellt das offene Ende als `DateOnly? To = null` dar. Die Testreferenz verwendet für
Datum/NA eine eng begrenzte Standardbibliotheks-Attrappe, nicht pandas.

Die Periode ab Juli 2025 endet im aktualisierten Nutzercode am 31.03.2026. Diese
bereits korrigierte Grenze wurde unverändert übernommen. Die Perioden ab 2012 sind
lückenlos geprüft. Außerhalb des ersten gültigen Zeitraums liefert der Kern keinen
Beitrag. Künftige Parameteränderungen brauchen neue Evidenz und Tests.

Es liegt nur ein unveränderter **Kernauszug** des empfangenen Python-Texts im Paket,
nicht eine behauptete vollständige Bytekopie der gesamten Chatnachricht.

## Berechnung

Der Kern verwendet binary64 (`double`) und dieselbe Reihenfolge der Rechenoperationen
wie `calculate_contibution_ipp`. Eine pauschale Umstellung auf `decimal` würde nicht
automatisch Parität beweisen. `PythonRound.Round` rundet die exakt repräsentierte
Binärzahl mit BigInteger und ties-to-even auf Dezimalstellen. Dadurch wird etwa
`2.675 → 2.67` erhalten; `Math.Round` nach vorheriger Gleitkommaskalierung genügt nicht
als allgemeiner Ersatz.

TZG > 1 wird zur Berechnung durch 100 dividiert. Positive Werte bis 1 gelten als Faktor.
`ATTC/TZG` wird auf zwei Stellen gerundet. Stufe 2 besitzt den Offset 62,5 und die
Steigerung 42, Stufe 3 die Steigerung 80, Stufe 1 den Faktor 7,5; jeweils gemäß
vorhandener Division durch 12. Endbeitrag = gerundeter Beitrag × TZG, auf zwei Stellen.
Die Zwischengröße am oberen Eckwert wird bereits auf zwei Stellen gerundet.

## Personen- und Monatsverarbeitung

Die Basistabelle ist führend. Die Anwendung liest genau ein passendes Blatt mit
`ClientID`, `BaseSalary_1`, `PartTimeFactor_1` in Zeile 1. Mehrdeutige Arbeitsmappen
werden nicht, wie im alten Python-Code, blind über alle Blätter zusammengeführt.
Das optionale `BaselineSheet` kann das Blatt explizit benennen.

Die ID-Domäne ist im V0.1-Kern eingeschränkt: reine nichtnegative Ganzzahlen bis
15 Stellen. Führende Nullen werden für den numerischen Referenzvergleich entfernt;
die Rohkennung bleibt im JSON erhalten. Die Ergebnis-Excel speichert IDs als Text.
Alphanumerische Versorgungsteile, Brüche, sehr lange Kennungen und Kollisionen werden
abgewiesen, nicht als NaN verschluckt. Dies zertifiziert keine ClientID/WWID-Zuordnung.

Monate werden aus `_MMJJJJ` im TXT-Dateinamen gelesen. Ein Lauf umfasst genau ein Jahr
und höchstens eine Datei je Monat. Reihenfolge der ausgewählten Dateien ist irrelevant,
weil chronologisch sortiert wird. Lücken erzeugen Warnungen: Ein nicht vorhandener
Monat wird nicht still nacherzeugt. Der Fallback prüft ausschließlich Monat m−1,
bzw. für Januar die beiden Basisspalten. Ein April-only-Lauf füllt fehlendes ATTC
nicht automatisch aus Januarwerten.

Semikolon-CSV wird mit dem .NET TextFieldParser gelesen (auch gequotete Felder).
Default ist Windows-1252; UTF-8 ist explizit konfigurierbar, ein BOM kann erkannt werden.
Leere Zeilen werden ausgelassen. Defekte Zeilen, doppelte Header, fehlende Pflichtspalten
oder ungültige nichtleere Zahlen führen zu einem Fehler, nicht zu `continue`/skip.
Tausendertrenner werden nicht erraten. Dezimalkomma und Dezimalpunkt sind möglich.

## Reihenfolge im Referenz-/Strict-Modus (Review-Abweichungen weiter unten)

1. Tarifstatus je Person/Monat aufbauen: letzter nichtleerer lesbarer Tarif aus den
   entsprechenden Zeilen; bei fehlendem Monatswert letzten Status weitertragen.
2. `Tarifklasse_alt` = erste erkannte Klasse. `Tarifklasse_neu`/`DAT_Änderung` = letzter
   Wechsel, auch wenn später wieder die Ausgangsklasse erreicht wird. Ohne Wechsel leer.
3. ANSPRUCHSTYP/DAT_AUSTRITT/TZG verwenden die jeweilige letzte Personenzeile. Leeres
   Austrittsdatum löscht einen vorhandenen Austritt nicht. Der letzte nichtleere Claim
   bleibt für den abschließenden Cutoff erhalten.
4. Neues ATTC ausschließlich aus passenden Zeilen mit `BETRAG1_TYP=ATTC_BAV`,
   `ANSPRUCHSTYP=AKTAN` und nicht gesperrtem Monatstarif. Letzte passende Zeile gewinnt.
5. Fallback aus Januar-Basis oder direktem Vormonat. Danach wird ATTC bei 98/99 wieder
   geleert. TZG wird durch diese Tarifsperre nicht geleert.
6. Bei vorhandenem DAT_AD2 werden frühere Monate geleert; Eintrittsmonat bleibt ganz.
   JoiningDate wird nicht als Ersatz für DAT_AD2 verwendet.
7. Monatsbetrag berechnen; fehlendes ATTC, fehlendes/0 TZG ergeben keinen Betrag.
8. Nur bei finalem Claim AUGUAN werden Monate nach dem Austrittsmonat geleert. Andere
   Claims erhalten keinen neuen, erfundenen Austritts-Cutoff.

Die ATTC-Fallback-Kaskade arbeitet auch dann, wenn kein AKTAN-Satz für den Monat
gefunden wurde. Das entspricht dem Code, nicht einer neu behaupteten fachlichen
Freigabe. Nach einem gesperrten Monat ist ATTC leer; bei Entsperrung ohne neues ATTC
kann der direkte Vormonat keine ältere Gehaltshistorie wiederherstellen.

## Bewusste Schutzmaßnahmen, die nicht als 1:1-Verhalten ausgegeben werden

- Leere TXT-Auswahl, Mehrjahresmischung, doppelte Monatslieferung und ungültige Header
  werden abgebrochen.
- V0.2.0: Die Pipeline sammelt Personen außerhalb des Bestands vorab in Prüffällen.
  Nur bekannte bzw. ausdrücklich bestätigte Neueintritte gelangen zum Rechenkern.
  Offene Personen werden NICHT still ignoriert und erzeugen einen Teilergebnisstatus.
  Der niedrigere ContributionEngine-Kern behält den alten Strict/Ignore-Schalter nur
  für isolierte Kompatibilitätstests T15/T16; die Oberfläche bietet kein Ignore mehr.
- V0.3.0: Der normale Pipelinepfad isoliert unbekannte, unlesbare oder widersprüchliche
  Tarifmonate statt den gesamten Lauf abzubrechen. ATTC aus TXT/Fallback bleibt
  erhalten; nur der Beitrag dieser Monate bleibt leer. Vor explizit bekanntem DAT_AD2 ist kein Tarif nötig. Kein Eintrittsdatum wird
  dazu ersetzt oder erfunden. Der gesonderte Strict-Modus und der explizite historische
  AllowMissingTariff-Modus bleiben für Entwickler-Referenztests erhalten.
- Nichtleere ungültige Zahlen/Datumsangaben, negative Gehälter oder TZG außerhalb 0..100
  blockieren. Unterstützte Datenformate werden ausdrücklich im Parser benannt.
- Vorhandene Formeln in der Bestandsdatei werden nicht aus einem möglicherweise alten
  Cache als frische Ergebnisse übernommen. Bereits verarbeitete Monats-Outputs sind
  als neue Bestandsvorlage nicht zugelassen.
- Eine besonders wichtige Altcode-Eigenheit bleibt sichtbar: raw ARBZEIT_PROZ=0.01 wird
  zu TZG=1, und der Rechenkern interpretiert 1 als 100%. Das wird nicht still repariert;
  es erscheint `TZG_ONE_AMBIGUOUS`. Die Einheitenregel muss fachlich geklärt werden.
- Die Anwendung erzeugt eindeutige Laufordner statt immer `Ergebnis.xlsx` im Quellordner
  zu überschreiben. Datumsfelder im Ergebnis bleiben, analog dem Script, Darstellungstext.

## Referenzbeweis

`tests/golden_vectors.json` enthält 6684 Formelfälle sowie 5030 Rundungsfälle.
Die Vektoren prüfen u.a. Periodengrenzen, Eckwerte, TZG und negative Rundungswerte.
Der C#-Runner prüft die reinen Zahlen exakt sowie ausgewählte Workflow-Eigenschaften.
Eine vollständige Parität aller pandas-Parser-/Merge-Sonderfälle und aller Realdateien
ist damit ausdrücklich nicht zertifiziert. Sie gehört zur nächsten Qualifikation.

## Personenprüfung V0.2.0

Siehe `../PERSONENPRUEFUNG_LESEN.md`. Neue Mitgliedschaft/Neueintritt wird nicht allein
aus TXT-Präsenz abgeleitet. Bestätigungen sind lokale Entscheidungen, keine externe
HR-Quelle. Die Geldformel und die 11.714 Referenzvektoren sind unverändert.


## Tarifprüfung seit V0.2.1, ATTC-Korrektur V0.3.0

Siehe `../TARIFPRUEFUNG_LESEN.md`. Dies ist eine ausdrücklich dokumentierte
Schutz-/Workflowänderung, keine behauptete volle pandas-Parität. Bei gültigen,
nicht widersprüchlichen Tarifdaten bleibt die bisherige Rechenreihenfolge bestehen.
Leere Folgewerte tragen nur bekannte frühere Tarife vor. Unlesbare/konfligierende
Updates unterbrechen die Fortschreibung bis zu neuer eindeutiger Evidenz. Anders
als der alte last-wins-Pfad wird nicht eine widersprüchliche Zeile bevorzugt.
Nach einer solchen Lücke wird kein genauer früherer Tarifwechselzeitpunkt behauptet.
Unbekannter Tarif sperrt seit V0.3.0 nicht mehr den ATTC-Fallback, sondern nur
den Beitrag. Eine tatsächliche 98/99-Sperre leert ATTC hingegen weiterhin;
dieser geleerte Wert kann nicht in die Fallback-Kette eingesetzt werden.
