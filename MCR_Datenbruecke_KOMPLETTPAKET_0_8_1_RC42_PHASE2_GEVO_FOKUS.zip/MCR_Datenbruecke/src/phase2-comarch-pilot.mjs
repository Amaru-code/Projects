/** RC39 independent PHASE-2 supervised ONE-TICKET pilot. No Phase-1 send
 * orchestration, no automatic rerun, no arbitrary PDF generation.
 * Supports only an earlier operator-reviewed proof for DC and/or PP+.
 */
import fs from 'node:fs';import path from 'node:path';import readline from 'node:readline/promises';
import {fileURLToPath} from 'node:url';
import {requireThat as need} from '../lib/core.mjs';
import {readJSON,writeJSON,plainPath,ledger,stamp} from '../lib/control.mjs';
import {resolveConfig} from '../lib/config.mjs';import {loadActiveMapping} from '../lib/active-mapping.mjs';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachFreshPage,sleep} from '../lib/cdp.mjs';
import {phase2Inventory,readPhase2Queue} from '../lib/phase2-readonly.mjs';
import {inspectExistingStatements} from '../lib/phase2-pdf-evidence.mjs';
import {phase2DraftPreview} from '../lib/phase2-draft-preview.mjs';
import {readPhase2MemberEvidence} from '../lib/phase2-member-evidence.mjs';
import {phase2Journal,digestDescription} from '../lib/phase2-write-journal.mjs';
import {setPhase2Gevo,uploadControl,attachLocalFiles,observedAttachments,selectReviewMode,
 selectReviewAssignee,savePhase2Draft,savePhase2Ticket,executeReview,phase2FieldSnapshot,reviewAssignmentState} from '../lib/phase2-comarch-actions.mjs';
import {forwardingNotices,forwardConfirmed} from '../lib/forwarding.mjs';
import * as UI from '../lib/browser-workflow.mjs';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const normalize=s=>String(s??'').replace(/\r\n?/g,'\n').trim();
async function ask(rl,q){return String(await rl.question(q)).trim();}
function phase2Dir(root){const p=path.join(root,'.runtime','phase2');plainPath(p);return p;}
function proofForTicket(root,id){
 const dir=phase2Dir(root),files=fs.readdirSync(dir).filter(f=>f.startsWith('MCR_PHASE2_PDF_BELEG_'+id+'_')&&f.endsWith('.json')).sort().reverse();
 need(files.length,'P2_PDF_PROOF_REQUIRED','Erst Menue 11 mit lokaler Inhaltspruefung abschliessen.');
 const proof=readJSON(path.join(dir,files[0]),256*1024);
 need(proof.schema==='MCR_PHASE2_PDF_PROOF_V1'&&proof.ticketId===id&&proof.operatorContentReviewed===true&&proof.operatorPersonTicketBindingReviewed===true,
  'P2_PDF_PROOF_INVALID','PDFs nicht ausreichend geprueft.');
 need(Date.now()-Date.parse(proof.verifiedAt)<7*24*60*60*1000,'P2_PDF_PROOF_OLD','PDF-Inhaltspruefung veraltet, Menue 11 erneut ausfuehren.');
 const ids=(proof.artifacts||[]).map(x=>/^(\d{4,15})_Kontoauszug_(DC|PP\+)\.pdf$/i.exec(x.name));
 need(ids.length===proof.artifacts.length&&ids.every(Boolean)&&new Set(ids.map(m=>m[1])).size===1,
  'P2_WWID_FILENAMES','Nur exakte WWID-Dateinamen mit identischer Personkennung.');
 const wwid=ids[0][1],verified=inspectExistingStatements(root,proof.targets,wwid);
 need(verified.artifacts.length===proof.artifacts.length&&verified.artifacts.every((a,i)=>{
  const expected=proof.artifacts.find(x=>x.plan===a.plan);return expected&&expected.sha256===a.sha256&&expected.bytes===a.bytes&&expected.name===a.name;
 }), 'P2_PDF_CHANGED','Pruefbelege oder PDFs wurden seit Menue 11 veraendert.');
 return {proof,verified,wwid};
}
export function preflightPhase2Write(root,ticketId){
 const inventory=readJSON(path.join(phase2Dir(root),'MCR_PHASE2_LETZTE_INVENTUR.json'),2*1024*1024);
 need(inventory?.schema==='MCR_PHASE2_INVENTORY_V1'&&inventory.readOnly,'P2_INVENTORY_REQUIRED','Menue 9 erneut ausfuehren.');
 need(Date.now()-Date.parse(inventory.generatedAt)<60*60*1000,'P2_INVENTORY_STALE','Bitte frische Inventur ueber Menue 9.');
 const item=inventory.items.find(x=>x.ticketId===ticketId);
 need(item?.kind==='NEEDS_VERIFIED_WWID','P2_TICKET_BLOCKED','Kein eindeutig vorbereiteter Kontoauszug-Kandidat.');
 need(!ledger(root).pending.some(x=>x.ticketId===ticketId),'P2_PHASE1_JOURNAL_PENDING','Phase-1-Journal noch ungeklärt.');
 const {proof,verified,wwid}=proofForTicket(root,ticketId);
 need(item.targets.length===proof.targets.length&&item.targets.every(x=>proof.targets.includes(x)),
  'P2_PLAN_CONFLICT','COMARCH-Planarten und PDF-Pruefung widersprechen sich.');
 const preview=phase2DraftPreview({ticketId,source:item.source,description:item.descriptionValue,pdfProof:proof});
 const initial={ticketId,descriptionSha256:digestDescription(item.descriptionValue),pdfHashes:proof.artifacts.map(x=>({plan:x.plan,sha256:x.sha256}))};
 const journal=phase2Journal(root,ticketId,{initial});
 const existing=journal.read();
 // RC42: existing GEVO_INTENT may be inspected for ONE audited pre-upload
 // focus retry. All other open write intents remain permanently blocked.
 const recoveryNeeded=!!existing;
 need(!existing||journal.mayRetryGevoFocus(initial),'P2_ALREADY_ATTEMPTED',
  'Phase-2-Aktion begonnen oder abgeschlossen. Nur GEVO_INTENT ohne weitere Aktion ist kontrolliert fortsetzbar.');
 return {item,proof,verified,wwid,preview,journal,initial,recoveryNeeded};
}

/** Intentionally every stage is a distinct monotonic ledger state.
 * Browser/OS crashes leave the last INTENT state requiring manual review.
 */
export async function phase2ComarchPilot({root=ROOT,askFn=ask,log=console.log,memberLookup=readPhase2MemberEvidence}={}){
 loadActiveMapping(root);
 const rl=readline.createInterface({input:process.stdin,output:process.stdout});
 let browser=null,cdp=null,armed=false;
 try{
  log('\nPHASE 2: Einzelticket-Pilot. KEINE E-MAIL, keine Generatorausfuehrung.');
  const id=await askFn(rl,'Vorbereitetes Kontoauszug-Ticket (z.B. 87278094): ');
  need(/^\d{6,12}$/.test(id),'P2_TICKET_ID','Ticketnummer erforderlich.');
  const {item,proof,verified,wwid,preview,journal,initial:journalInput,recoveryNeeded}=preflightPhase2Write(root,id);
  log('TICKET '+id+' | '+item.targets.join('+')+' | '+wwid+' | '+verified.artifacts.map(x=>x.name).join(' + '));
  const cfg=resolveConfig(root),exe=findEdgeExecutable(cfg.edgePath);need(exe,'P2_EDGE','Edge fehlt.');
  browser=await launchBrowser({executable:exe,userDataDir:cfg.profileDirectory,startUrl:'about:blank'});
  ({cdp}=await connectBrowser(browser.port));const page=await attachFreshPage(cdp,cfg.comarchUrl);
  need((await askFn(rl,'In Bot-Edge anmelden. COMARCH bereit? START / ABBRUCH: ')).toUpperCase()==='START',
   'P2_OPERATOR_ABORT','Keine Bearbeitung gestartet.');
  await UI.navigateToScope(page,'IN_BEARBEITUNG',{startup:true});
  const raw=await readPhase2Queue(page);need(raw.ok,'P2_QUEUE',raw.reason||'COMARCH-Vorgangsliste nicht lesbar.');
  const row=raw.rows.find(x=>x.ticketId===id);need(row,'P2_NOT_IN_TASKS','Ticket ist nicht mehr in Meine Vorgaenge.');
  const same=phase2Inventory([row],{pendingIds:ledger(root).pending.map(x=>x.ticketId)}).items[0];
  need(same.kind==='NEEDS_VERIFIED_WWID'&&normalize(row.descriptionValue)===normalize(item.descriptionValue),
   'P2_TICKET_CHANGED','Ticketstatus/Anfrage veraendert. Bitte Menue 9 erneut.');
  await UI.openTicket(page,row);await UI.assertTicket(page,id);
  const member=await memberLookup(page);
  need(member.profileVerified&&member.profile?.first&&member.profile?.last,'P2_MEMBER_NOT_BOUND','Kein eindeutiges COMARCH-Memberprofil.');
  need(!member.wwid||member.wwid===wwid,'P2_WWID_MISMATCH','COMARCH-WWID unterscheidet sich von beiden PDFs.');
  await UI.ensureEdit(page);await UI.assertTicket(page,id);
  const expectedFixed={responsibility:'Second Level',category:'Allgemeine Schriftwechsel',subcategory:'Personenschriftwechsel'};
  const fixedOkay=f=>Object.entries(expectedFixed).every(([k,v])=>String(f?.[k]||'').trim()===v);
  if(!fixedOkay(await UI.fixedFieldValues(page))){
   log('PFLICHTFELDER: In COMARCH Second Level / Allgemeine Schriftwechsel / Personenschriftwechsel exakt setzen. Keine E-Mail senden.');
   need((await askFn(rl,'Pflichtfelder geprueft? ENTER / ABBRUCH: ')).toUpperCase()!=='ABBRUCH',
    'P2_OPERATOR_ABORT','Pflichtfelder nicht freigegeben.');
  }
  need(fixedOkay(await UI.fixedFieldValues(page)),'P2_FIXED_FIELDS','COMARCH-Pflichtfelder nicht eindeutig eingestellt.');
  const initial=await UI.additionalDescriptionState(page);
  need(initial.ok&&initial.editable&&normalize(initial.value)===normalize(item.descriptionValue),
   'P2_DESCRIPTION_CHANGED','Die vorhandenen drei Beschreibungszeilen sind nicht unveraendert editierbar.');
  const f=await phase2FieldSnapshot(page);
  need(f.gevo.count===1&&f.gevo.visible&&f.gevo.enabled,'P2_GEVO_MISSING','Anfrage-Art-Feld fehlt.');
  // The upload element can appear only AFTER changing the request type.
  // It is therefore verified after the guarded GEVO step, not yet required.
  const existingAttachments=await observedAttachments(page,verified.artifacts.map(a=>a.name));
  need(existingAttachments.present.every(x=>!x),'P2_ATTACHMENT_ALREADY_PRESENT','Eine Anlage steht bereits im Ticket. Keine doppelte Anlage.');
  log('COMARCH-PROFIL: '+member.profile.first+' '+member.profile.last+' | MercerID '+member.profile.mercerId+' (NICHT WWID).');
  log('GEPLANT: Anfrage Member; '+item.targets.join('+')+'; Bearbeitet not reviewed; Entwurf/Ticket speichern; Pruefung mark.baindl.');
  log('Vorbereitung nur fuer dieses Ticket. Noch keine Aktion ausgefuehrt.');
  need((await askFn(rl,'Originalvorgang, Member, WWID, beide PDFs und Bearbeitungsauftrag geprueft? PHASE2_FREIGABE / ABBRUCH: '))==='PHASE2_FREIGABE',
   'P2_OPERATOR_ABORT','Keine Bearbeitung gestartet.');
  // Never store the person name in a new metadata log; only ticket ID and hashes.
  if(recoveryNeeded){
   log('P2_GEVO_FOCUS_RECOVERY: Vorheriger RC41-Lauf stoppte bei GEVO_INTENT, noch vor Upload-/Speicher-/Weiterleitungsabsicht.');
   log('COMARCH ausserhalb des Bots kontrollieren: keine neue Anlage, kein gespeicherter Entwurf, kein Ticket-Speicherklick, keine Weiterleitung.');
   need((await askFn(rl,'Ausschliesslich GEVO-Fokus fehlgeschlagen, KEINE andere Aktion erfolgt? GEVO_OHNE_AKTIONEN_GEPRUEFT / ABBRUCH: '))==='GEVO_OHNE_AKTIONEN_GEPRUEFT',
    'P2_GEVO_RECOVERY_DECLINED','Altes Journal bleibt gesperrt. Keine Wiederholung.');
   journal.approveGevoFocusRetry({...journalInput,operatorConfirmed:true,ticketUnchanged:true,noAttachments:true});
   log('PASS P2_GEVO_FOCUS_RECOVERY_AUTHORIZED: Ein Fokus-Wiederanlauf im bestehenden Journal dokumentiert.');
  }else journal.begin();
  armed=true;
  const advance=next=>{const val=journal.advance(next);log('P2_JOURNAL '+next);return val;};
  const bound=()=>UI.assertTicket(page,id);
  if(!recoveryNeeded)advance('GEVO_INTENT');
  await bound();
  await setPhase2Gevo(page,{
   manualFocus:async(reason)=>{
    log('P2_GEVO_MANUAL_FOCUS: '+reason+'. Nur das Feld Anfrageart/GEVO im EIGENEN Bot-Edge anklicken. Weder Auswahl noch Speichern oder Senden betaetigen.');
    need((await askFn(rl,'GEVO-Eingabefeld angeklickt? FOKUS / ABBRUCH: ')).toUpperCase()==='FOKUS',
     'P2_OPERATOR_ABORT','GEVO-Fokus nicht bestaetigt. Keine weiteren Aktionen.');
   },
   manualSelect:async()=>{
    log('Anfrage Member im COMARCH-Auswahlmenue selbst anklicken, keine andere Option.');
    need((await askFn(rl,'Anfrage Member ausgewaehlt? AUSGEWAEHLT / ABBRUCH: ')).toUpperCase()==='AUSGEWAEHLT',
     'P2_OPERATOR_ABORT','Auswahl abgebrochen.');
   }
  });advance('GEVO_VERIFIED');
  if(!(await uploadControl(page)).ok){
   log('ANHANGS-BEREICH: Im Bot-Edge den normalen E-Mail-Anhangsbereich oeffnen (NICHT SENDEN).');
   need((await askFn(rl,'Anhangsbereich geoeffnet? ENTER / ABBRUCH: ')).toUpperCase()!=='ABBRUCH',
    'P2_OPERATOR_ABORT','Upload-Bereich nicht geoeffnet.');
  }
  need((await uploadControl(page)).ok,'P2_UPLOAD_GONE','COMARCH Anhangsfeld nach Anfrageart nicht sichtbar.');
  // The file input may be single-file. Each upload is preceded by INTENT,
  // with no retry of an unknown upload. One attempt for the entire batch.
  advance('UPLOAD_INTENT');await bound();
  const files=verified.artifacts.map(a=>a.file),names=verified.artifacts.map(a=>a.name);
  const assertUnchanged=()=>{const now=inspectExistingStatements(root,item.targets,wwid);
   need(now.artifacts.length===verified.artifacts.length&&now.artifacts.every(a=>{
    const p=verified.artifacts.find(x=>x.plan===a.plan);return p?.sha256===a.sha256&&p?.bytes===a.bytes;
   }),'P2_PDF_CHANGED','PDF-Dateien seit Freigabe geaendert. Keine weitere COMARCH-Aktion.');};
  assertUnchanged();
  const input=await uploadControl(page);
  if(input.multiple)await attachLocalFiles(page,files);
  else for(let i=0;i<files.length;i++){
   need((await uploadControl(page)).ok,'P2_UPLOAD_REPLACED','COMARCH Uploadfeld verschwand nach erster Anlage. Keine Wiederholung.');
   await attachLocalFiles(page,[files[i]]);
   let found=false;for(let z=0;z<40;z++){const e=await observedAttachments(page,[names[i]]);if(e.present[0]){found=true;break;}await sleep(200);}
   need(found,'P2_UPLOAD_UNVERIFIED','Anlage im COMARCH-DOM nicht belegt. Nicht erneut hochladen; manuell pruefen.');
  }
  let confirmed=false;for(let z=0;z<50;z++){const e=await observedAttachments(page,names);if(e.present.every(Boolean)){confirmed=true;break;}await sleep(200);}
  need(confirmed,'P2_UPLOAD_UNVERIFIED','Beide Anlagen werden in COMARCH nicht eindeutig angezeigt. Keine erneute Anlage.');
  assertUnchanged();advance('UPLOAD_VERIFIED');log('P2_UPLOAD_UI_VERIFIED: Beide Dateinamen in COMARCH sichtbar (Server-Speicherung noch ausstehend).');
  advance('DESCRIPTION_INTENT');await bound();
  const before=await UI.additionalDescriptionState(page);
  need(before.ok&&before.editable&&normalize(before.value)===normalize(item.descriptionValue),
   'P2_DESCRIPTION_CHANGED','Originaltext vor Statusaenderung nicht mehr identisch.');
  const update=await UI.appendStandardAnswerMarker(page,'Bearbeitet not reviewed');
  need(update.ok&&normalize(update.value)===normalize(preview.descriptionAfter),'P2_MARKER_WRITE','Vierte Zeile nicht sicher angehaengt.');
  need(await UI.verifyDescription(page,preview.descriptionAfter),'P2_MARKER_VERIFY','Mehrzeiliger Tickettext nicht eindeutig im Editor.');
  advance('DESCRIPTION_VERIFIED');
  advance('DRAFT_SAVE_INTENT');await bound();await savePhase2Draft(page);
  // A draft click alone does NOT prove server persistence. Require both names
  // in the COMARCH attachment area before permitting the final ticket save.
  need((await observedAttachments(page,names)).present.every(Boolean),'P2_DRAFT_ATTACHMENTS_UNVERIFIED',
   'Entwurf nicht als dauerhaft angehaengt nachgewiesen; keine weitere Aktion.');
  advance('DRAFT_SAVE_VERIFIED');
  advance('TICKET_SAVE_INTENT');await bound();await savePhase2Ticket(page);
  let saved=false;for(let z=0;z<70;z++){
   try{await UI.navigateToScope(page,'IN_BEARBEITUNG',{refresh:true});const r=await readPhase2Queue(page);
    if(r.ok){const current=r.rows.find(x=>x.ticketId===id);
     if(current&&normalize(current.descriptionValue)===normalize(preview.descriptionAfter)){saved=true;break;}}
   }catch{}await sleep(300);
  }
  need(saved,'P2_SAVE_UNVERIFIED','Ticketbeschreibung nach einem Speicherklick nicht bestaetigt. Keinen zweiten Speicherklick ausfuehren.');
  advance('TICKET_SAVE_VERIFIED');
  log('PASS P2_DRAFT_AND_TICKET_SAVED: Tickettext gespeichert, Dateien im Entwurf sichtbar.');
  // Review is explicitly gated and performed separately from saving.
  log('Pruefung: Beide Anhaenge und Entwurf in COMARCH jetzt visuell pruefen. Nicht selbst weiterleiten.');
  const choice=await askFn(rl,'An Mark Baindl zur Ueberpruefung weiterleiten? WEITERLEITEN / OFFEN_LASSEN: ');
  if(choice!=='WEITERLEITEN'){
   log('P2_OFFEN: Ticket gespeichert, Review noch nicht ausgefuehrt. Journal bleibt auf TICKET_SAVE_VERIFIED; kein automatischer Neustart.');
   return {ticketId:id,status:'SAVED_PENDING_REVIEW',journal:journal.file};
  }
  const current=await readPhase2Queue(page);const sameRow=current.rows?.find(r=>r.ticketId===id);
  need(sameRow,'P2_REVIEW_BIND','Nach Speichern ist das Ticket nicht mehr in Meine Vorgaenge.');
  await UI.openTicket(page,sameRow);await UI.assertTicket(page,id);
  need(fixedOkay(await UI.fixedFieldValues(page)),'P2_FIXED_NOT_SAVED','Pflichtfelder nach Speichern nicht mehr exakt. Keine Weiterleitung.');
  // Reopen from server-backed task view to verify attachments survive save.
  const attachmentAfterReopen=await observedAttachments(page,names);
  need(attachmentAfterReopen.present.every(Boolean),'P2_SAVED_ATTACHMENTS_NOT_VISIBLE',
   'Nach erneutem Oeffnen sind nicht alle PDF-Anlagen nachweisbar. Keine Weiterleitung.');
  const savedDescription=await UI.additionalDescriptionState(page);
  need(!savedDescription.ok||normalize(savedDescription.value)===normalize(preview.descriptionAfter),
   'P2_SAVED_DESCRIPTION_CHANGED','Tickettext nach erneutem Oeffnen veraendert.');
  assertUnchanged();
  advance('REVIEW_INTENT');await selectReviewMode(page);
  let visible=false;for(let z=0;z<35;z++){const a=await phase2FieldSnapshot(page);if(a.nextPersona.count===1&&a.nextPersona.visible&&a.nextPersona.enabled){visible=true;break;}await sleep(200);}
  need(visible,'P2_REVIEW_TARGET_FIELD','Prueferfeld mainForm:next-persona-assignment-id fehlt.');
  await selectReviewAssignee(page,{manualSelect:async()=>{
   log('Im Bot-Edge EXAKT Baindl Mark (mark.baindl) als Pruefer auswaehlen.');
   need((await askFn(rl,'Mark Baindl ausgewaehlt? ENTER / ABBRUCH: ')).toUpperCase()!=='ABBRUCH','P2_OPERATOR_ABORT','Pruefer abgebrochen.');
  }});
  need((await reviewAssignmentState(page)).ok,'P2_REVIEW_TARGET_CHANGED','Pruefer-Zuordnung nicht eindeutig.');
  advance('REVIEW_VERIFIED');
  const notices=await forwardingNotices(page);
  advance('EXECUTE_INTENT');await bound();await executeReview(page);
  let evidence={ok:false};for(let z=0;z<40;z++){
   evidence=await forwardConfirmed(page,{display:'Baindl Mark',account:'mark.baindl'},notices);
   if(evidence.ok)break;await sleep(300);
  }
  need(evidence.ok,'P2_REVIEW_UNVERIFIED','Nach einem Schritt-Ausfuehren-Klick keine neue Erfolgsmeldung. Nicht wiederholen.');
  let absent=false;for(let z=0;z<25;z++){
   try{await UI.navigateToScope(page,'IN_BEARBEITUNG',{refresh:true});const r=await readPhase2Queue(page);if(r.ok&&!r.rows.some(x=>x.ticketId===id)){absent=true;break;}}catch{}
   await sleep(300);
  }
  need(absent,'P2_REVIEW_NOT_REMOVED','Weiterleitungsmeldung vorhanden, Ticket aber weiter in eigenen Vorgängen. Manuell prüfen.');
  advance('ROUTED_VERIFIED');
  const receipt={schema:'MCR_PHASE2_REVIEW_RECEIPT_V1',ticketId:id,status:'ROUTED_VERIFIED',reviewer:'mark.baindl',pdfHashes:proof.artifacts.map(x=>({plan:x.plan,sha256:x.sha256})),createdAt:new Date().toISOString()};
  const rec=path.join(phase2Dir(root),'MCR_PHASE2_ABSCHLUSS_'+id+'_'+stamp()+'.json');writeJSON(rec,receipt);
  log('PASS P2_REVIEW_ROUTE_VERIFIED | '+id+' | mark.baindl | '+rec);
  return receipt;
 }finally{rl.close();try{cdp?.close();}catch{}try{browser?.child?.kill();}catch{}if(armed)log('P2_AUDIT: Schreibjournal bleibt dauerhaft erhalten. Bei Unterbrechung keine automatische Wiederholung.');}
}
