using System.Globalization;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace Mcr.Ipp.Core;

public sealed class IppException : Exception
{
    public string Code { get; }
    public IppException(string code, string message) : base(message) { Code = code; }
}
public static class JsonFiles
{
    public static readonly JsonSerializerOptions Options = new()
    {
        WriteIndented = true, PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        PropertyNameCaseInsensitive = true, Converters = { new JsonStringEnumConverter() }
    };
    public static void Write<T>(string path, T obj) => File.WriteAllText(path, JsonSerializer.Serialize(obj, Options), new System.Text.UTF8Encoding(false));
    public static T Read<T>(string path) => JsonSerializer.Deserialize<T>(File.ReadAllText(path), Options) ?? throw new IppException("JSON_EMPTY", "Leere Konfiguration.");
}
public sealed record SourceInfo(string Name, string Sha256, long Bytes);
public sealed record SourceBlob(byte[] Bytes, SourceInfo Info)
{
    public static SourceBlob Read(string path)
    {
        if (!File.Exists(path)) throw new IppException("INPUT_MISSING", $"Datei fehlt: {Path.GetFileName(path)}");
        using var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
        if (fs.Length > 256L * 1024 * 1024) throw new IppException("INPUT_TOO_LARGE", "Eingabedatei ueber 256 MiB.");
        using var ms = new MemoryStream(); fs.CopyTo(ms);
        var bytes = ms.ToArray();
        return new(bytes, new(Path.GetFileName(path), Convert.ToHexString(SHA256.HashData(bytes)), bytes.LongLength));
    }
}
public sealed record RulePeriod(DateOnly From, DateOnly? To, double Eckwert1, double Eckwert2);
public sealed class ContributionOptions
{
    public string Profile { get; set; } = "PYTHON_COMPAT_STRICT_V1";
    public bool AllowUnknownTxtPersons { get; set; } = false;
    public bool AllowMissingTariff { get; set; } = false;
    public string? BaselineSheet { get; set; }
    public string TextEncoding { get; set; } = "cp1252";
}
public sealed record Warning(string Code, string Message, string? ClientId = null, int? Month = null);
public sealed class MonthlyResult
{
    public int Month { get; set; }
    public DateOnly SalaryDate { get; set; }
    public double? Attc { get; set; }
    public double? Tzg { get; set; }
    public double? Amount { get; set; }
    public double? RawTariff { get; set; }
    public double? EffectiveTariff { get; set; }
    public string AttcSource { get; set; } = "MISSING";
    public string TzgSource { get; set; } = "MISSING";
    public List<string> Reasons { get; set; } = new();
}
public sealed class PersonResult
{
    public string ClientId { get; set; } = "";
    public string OriginalClientId { get; set; } = "";
    public Dictionary<string, object?> Master { get; set; } = new(StringComparer.Ordinal);
    public double? TariffOld { get; set; }
    public double? TariffNew { get; set; }
    public DateOnly? TariffChangeDate { get; set; }
    public DateOnly? TerminationDate { get; set; }
    public string? Claim { get; set; }
    public SortedDictionary<int, MonthlyResult> Months { get; set; } = new();
}
public sealed class ContributionResult
{
    public string Schema { get; set; } = "MCR_IPP_CONTRIBUTION_V1";
    public string Profile { get; set; } = "PYTHON_COMPAT_STRICT_V1";
    public int Year { get; set; }
    public List<int> Months { get; set; } = new();
    public List<string> MasterColumns { get; set; } = new();
    public List<PersonResult> Persons { get; set; } = new();
    public List<Warning> Warnings { get; set; } = new();
    public List<SourceInfo> Inputs { get; set; } = new();
    public PersonReviewReport? PersonReview { get; set; }
    public string IppMappingStatus { get; set; } = "NOT_BOUND";
    public bool PdfAuthorized { get; set; } = false;
}
public static class Parse
{
    public static readonly CultureInfo Inv = CultureInfo.InvariantCulture;
    public static string? Text(object? value)
    {
        var s = Convert.ToString(value, Inv)?.Trim();
        return s is null or "" || s.Equals("nan", StringComparison.OrdinalIgnoreCase) || s.Equals("none", StringComparison.OrdinalIgnoreCase) || s.Equals("<NA>", StringComparison.OrdinalIgnoreCase) ? null : s;
    }
    public static double? Number(object? value, string field)
    {
        if (value is double d && double.IsFinite(d)) return d;
        var s = Text(value); if (s is null) return null;
        if (!double.TryParse(s.Replace(',', '.'), NumberStyles.Float, Inv, out d) || !double.IsFinite(d))
            throw new IppException("INVALID_NUMBER", $"Ungueltige Zahl im Feld {field}; keine Tausendertrenner verwenden.");
        return d;
    }
    public static string Id(object? value)
    {
        var s = Text(value) ?? throw new IppException("ID_MISSING", "Leere ClientID/KDMA_IDENT.");
        // Python's numeric matching is retained on an explicit, safe identifier domain.
        if (System.Text.RegularExpressions.Regex.IsMatch(s, @"^\d+\.0+$")) s = s.Split('.')[0];
        if (!System.Text.RegularExpressions.Regex.IsMatch(s, @"^\d{1,15}$"))
            throw new IppException("ID_UNSUPPORTED", "ClientID/KDMA_IDENT muss ganzzahlig und maximal 15 Stellen sein; Kennungen mit Zusatzen werden nicht umgedeutet.");
        s = s.TrimStart('0'); return s.Length == 0 ? "0" : s;
    }
    public static DateOnly? Date(object? value, string field, bool date1904 = false)
    {
        var s = Text(value);
        if (s is null || s is "0" or "00000000" or "00.00.0000") return null;
        if (value is DateOnly date) return date;
        if (value is DateTime time) return DateOnly.FromDateTime(time);
        if (value is double n)
        {
            if (date1904) n += 1462;
            if (n <= 0 || n >= 2958466 || n == 60) throw new IppException("INVALID_DATE", $"Ungueltiges Excel-Datum: {field}.");
            return DateOnly.FromDateTime(DateTime.FromOADate(n < 60 ? n + 1 : n));
        }
        string[] patterns = { "dd.MM.yyyy", "d.M.yyyy", "yyyy-MM-dd", "yyyyMMdd", "dd/MM/yyyy", "d/M/yyyy", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-ddTHH:mm:ss" };
        if (DateTime.TryParseExact(s, patterns, Inv, DateTimeStyles.None, out var dt)) return DateOnly.FromDateTime(dt);
        throw new IppException("INVALID_DATE", $"Datum nicht lesbar: {field}; erwartet TT.MM.JJJJ oder JJJJ-MM-TT.");
    }
    public static string Header(string s) => System.Text.RegularExpressions.Regex.Replace(s.Trim().ToUpperInvariant().Replace("Ä", "AE").Replace("Ö", "OE").Replace("Ü", "UE").Replace("ß", "SS"), "[^A-Z0-9]", "");
    public static double? Tariff(object? value)
    {
        var s = Text(value); if (s is null) return null;
        var match = System.Text.RegularExpressions.Regex.Match(s, @"-?\d+(?:[.,]\d+)?");
        if (!match.Success) throw new IppException("TARIFF_INVALID", "Tarifklasse nicht numerisch lesbar.");
        var v = Number(match.Value, "Tarifklasse")!.Value;
        if (v < 0 || v != Math.Truncate(v)) throw new IppException("TARIFF_INVALID", "Tarifklasse muss eine nichtnegative Ganzzahl sein.");
        return v;
    }
}
