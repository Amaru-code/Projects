# MCR IPP V0.2.0 · Personenprüfung statt Ignorieren

## Was sich ändert

Unbekannte TXT-Kennungen stoppen nicht mehr pauschal den gesamten Beitragslauf.
Alle Fundstellen werden vor der Beitragsberechnung gesammelt. Der bekannte Bestand
läuft weiter; die offenen Personen fehlen ausdrücklich im Ergebnis. Solange solche
Fälle bestehen, ist der Lauf `PARTIAL_PERSON_REVIEW_REQUIRED`, nicht vollständig.

Die Oberfläche besitzt jetzt **„Personen prüfen / Neuaufnahme...“**. Das bisherige
Ignore-Kontrollkästchen entfällt. `Prueffaelle.xlsx` hat die Blätter „Personen“ und
„Fundstellen“. Eine Kennung wird monatsübergreifend zusammengefasst; leere Kennungen
bleiben aus Sicherheitsgründen je Fundstelle separate Fälle.

Pro Fall: Originalkennung, normalisierte ID, gelieferter Name, Klassifikation,
Geburtsdatum-/DAT_AD2-Hinweis, alle TXT-Dateien, Monatsangaben und logische
Datensatznummern. **Die Datensatznummer ist keine physische Textzeilennummer.**

## Wie neu / nicht neu entschieden wird

Das bloße Fehlen im Bestand ist KEIN Nachweis für einen Neueintritt. Es gibt hier
keinen Zugriff auf HR-Systeme, keine erfundene Vollständigkeit der Stammdaten und
keine automatische Zusammenführung unterschiedlicher IDs.

- `NEUEINTRITT_KANDIDAT`: ein erkanntes DAT_AD2 liegt im Auswahljahr/-horizont.
  Dies ist nur ein Hinweis. Kein Datum wird aus der ersten TXT-Beobachtung erfunden.
- `MOEGLICHER_BESTANDSTREFFER_ANDERE_ID`: Vor-/Nachname stimmen normalisiert mit
  einem anderen Bestandsdatensatz überein. Nur ein Hinweis, kein Identitätsnachweis.
- `IDENTITAETSDATEN_KONFLIKT`: unterschiedliche Namen/Daten oder unlesbare erfasste
  Datumsangaben. Kein automatisches „letzter Wert gewinnt“ für die Identität.
- `UNBEKANNT_NEUEINTRITT_NICHT_BELEGT`: Herkunft offen, Bestandsnachpflege oder
  abweichender Personenkreis möglich. ID und Fundstellen untersuchen.
- `KENNUNG_UNGUELTIG`: nicht in der unterstützten numerischen ID-Domäne oder leer.
  Nicht in eine andere Kennung umdeuten; separat klären.

### Namen: Daten vorhanden oder ausdrücklich fehlend

Angezeigt werden erkannte, tatsächlich gelieferte Identitätsfelder. Unterstützte
Aliasnamen stehen im Quelltext `PersonReview.cs` (u.a. Surname/Nachname, FirstName/
Vorname, Name/FullName/KDMA_NAME, BirthDate/Geburtsdatum, DAT_AD2). Diese Aliasnamen
sind **noch kein fachlich bestätigter Feldkatalog der realen TXT-Dateien**. Ein
Vollname wird nicht in Vor-/Nachnamen zerlegt. Bei fehlenden/unerkannten Namen steht
`NAME_NICHT_GELIEFERT`; die JSON-Datei enthält zusätzlich die tatsächlichen TXT-Header.
Namen werden nicht aus dem Internet, DC-Dateien oder anderen Kundenprojekten ergänzt.

## Bestätigten Neueintritt aufnehmen

1. Lauf mit Bestandsvorlage und Monatsdateien starten. Bekannte Personen werden
   berechnet; offene Fälle bleiben in der Prüfliste.
2. „Personen prüfen / Neuaufnahme...“ öffnen. Den tatsächlich geprüften Neueintritt
   auswählen und dessen Vor-/Nachnamen, Geburtsdatum und **DAT_AD2** bestätigen.
   Prüfer und Beleg/Grund sind Pflicht. Keine Passwörter oder unnötigen HR-Akten kopieren.
3. Die ausdrückliche Identitäts-/Neueintritts-/Dublettenprüfung bestätigen, speichern.
4. Mit denselben Eingaben erneut „Beiträge erstellen“. Nur bei bestandenen
   Identitäts-/Dubletten-/Monatsdatenprüfungen wird die Person jetzt aufgenommen.

Die Prüfung erfordert den Eintrittsmonat unter den ausgewählten Monaten. Alte,
außerhalb des Auswahljahres liegende Bestandslücken sind keine Neueintritte. Auch
TXT-Fundstellen vor dem bestätigten Eintrittsmonat, fehlende Monatsdaten, widersprüchliche
Stammdaten oder gleiche Namen unter mehreren neuen IDs werden nicht automatisch zugelassen.

Eine gespeicherte Bestätigung ist **noch keine erfolgreiche Aufnahme**. Scheitert die
erneute Prüfung, bleibt der Fall `FREIGABE_NICHT_ANWENDBAR` mit konkretem Grund offen.

Die Bestätigung wird in `MCR_IPP/local/Personenfreigaben.json` mit Fall-ID und Hash des
Bestands-/Monatsdatenkontexts gespeichert. Bei Änderungen an Quelldateien gilt sie
nicht automatisch weiter. Keine digitale Signatur oder externe HR-Autorisierung:
es ist eine nachvollziehbare lokale Benutzerentscheidung. Backups bleiben im selben
lokalen Ordner. Diesen Ordner beim Update behalten und nicht ungeprüft weitergeben.

## Verarbeitung und Ausgaben

`Ergebnis.xlsx` und `Contribution_Result.json` enthalten den bekannten Bestand plus
in diesem Lauf bestätigte und prüfbare Neueintritte. Offene Fälle sind nicht enthalten.
Die Anzahl offener Fälle/Neuaufnahmen wird in Oberfläche, Laufbericht, JSON und
optionalem IPP-Statusblatt ausgewiesen.

Nach erfolgreicher Aufnahme entstehen zusätzlich:
- `Bestand_Fortgeschrieben.xlsx`: neuer exportierter Bestand mit aufgenommenen Personen.
  Keine originalgetreue Format-/Mehrblattkopie; das eingelesene Bestandsblatt als Werte.
- `Neuaufnahmen_Verwendet.json`: verwendete Benutzerbestätigungen.

Originalbestände und TXT-Dateien werden nicht überschrieben. Ein erneuter Lauf mit
demselben ursprünglichen Bestand und derselben Bestätigung erzeugt keine Doppelanlage.
Der fortgeschriebene Bestand kann nach Prüfung als neuer Bestand verwendet werden.
Die Rechenstufe setzt DAT_AD2 nicht mit JoiningDate oder einer ersten TXT-Zeile gleich.
Vor bekanntem DAT_AD2 muss kein unbekannter Tarif freigegeben werden; diese Monate
bleiben beitragsleer. Sonstige Rechen-, Rundungs- und Eintrittsmonatsregeln bleiben gleich.

Strukturfehler (z.B. unlesbare TXT, fehlende Pflichtspalten, doppelte Bestands-IDs)
bleiben Laufabbrüche. Andere Pflichtfeldfehler bei bekannten Personen können den
Beitragslauf weiterhin blockieren. Eine schon abgeschlossene Personenprüfung bleibt
bei späterem Fehler in `.inprogress_...` mit FAILED.json erhalten und ist über die UI
zugänglich. Es wird dann kein fertiger Beitragsexport behauptet.

## Unveränderte Grenzen

Keine automatische Jahres-/Bereitstellungssumme, kein erratenes AF-Mapping, keine
Saldenänderung in den alten IPP-Imports. Keine neue Unverfallbarkeitsentscheidung,
keine produktiven PDFs. Nur IPP; DC-/Benchmark-Dateien sind ausgeschlossen.

## Teststatus

Die Vorgängerversion 0.1.1 wurde vom Nutzer auf Windows mit 56/56 Tests und 11.714
Referenzvergleichen erfolgreich ausgeführt. Das ist NICHT der Testlauf dieser Version.

V0.2.0 enthält 34 zusätzliche Tests (T57–T90), insgesamt 90. Hier wurden statische
Quell-/Projekt-/ZIP-Prüfungen ausgeführt. Mangels .NET-SDK/Windows/Excel in dieser
Umgebung wurden der neue C#-Build, die neuen Tests und die neue Oberfläche hier
NICHT ausgeführt. START.cmd baut und testet lokal mit dem vorhandenen gemeinsamen SDK.
Eine vollständige pandas-/Realdatenparität ist weiterhin nicht zertifiziert.

Eine Änderung von Farben/Statuszellen in Prueffaelle.xlsx ist keine Freigabe.
Bestätigungen werden ausschließlich über die Oberfläche bzw. das dokumentierte
Entscheidungs-JSON eingelesen. Die Prüfliste selbst wird nicht als Eingabe verwendet.
