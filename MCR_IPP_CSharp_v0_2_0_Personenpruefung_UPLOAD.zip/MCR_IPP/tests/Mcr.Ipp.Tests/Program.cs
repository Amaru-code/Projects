using Mcr.Ipp.Core;
using System.Text;
using System.Text.Json;
using System.Xml.Linq;
using System.Security.Cryptography;

string root = args.Length > 0 ? Path.GetFullPath(args[0]) : Directory.GetCurrentDirectory();
var results = new List<(string Name, string? Error)>();
int vectorComparisons = 0;
void Check(bool condition, string message) { if (!condition) throw new Exception(message); }
void Equal(double? actual, double? expected) => Check(actual == expected, $"Erwartet {expected}, erhalten {actual}");
void Throws(string code, Action action) { try { action(); } catch (IppException e) { Check(e.Code==code,$"Erwartet {code}, erhalten {e.Code}: {e.Message}"); return; } throw new Exception("Erwarteter Fehler fehlt: "+code); }
void Test(string name, Action action) { try { action(); results.Add((name,null)); Console.WriteLine("PASS " + name); } catch(Exception e) { results.Add((name,e.ToString())); Console.WriteLine("FAIL " + name + ": " + e.Message); } }
Dictionary<string,object?> BaseRow() => new() { ["ClientID"]="1001", ["Surname"]="Demo", ["FirstName"]="Test", ["BirthDate"]="01.01.1980", ["BaseSalary_1"]=8000d, ["PartTimeFactor_1"]=100d, ["DAT_AD2"]=null, ["TerminationDate"]=null };
InputTable Base(Dictionary<string,object?>? row=null) { row ??= BaseRow(); return new("Tabelle1",row.Keys.ToList(),new(){row},false); }
Dictionary<string,string?> Row(string? tariff="10", string? attc="8000",string? tzg="100",string? claim="AKTAN",string? term=null,string type="ATTC_BAV",string id="1001") => new() { ["KDMA_IDENT"]=id,["Tarifklasse"]=tariff,["BETRAG1"]=attc,["ARBZEIT_PROZ"]=tzg,["ANSPRUCHSTYP"]=claim,["DAT_AUSTRITT"]=term,["BETRAG1_TYP"]=type };
MonthFile Month(int month, params Dictionary<string,string?>[] rows) => new($"Change_{month:D2}2026.txt",new(2026,month,1),rows.ToList(),"Tarifklasse",new("synthetic",new string('0',64),0));
ContributionResult Run(InputTable? baseline, params MonthFile[] months) => new ContributionEngine().Run(baseline ?? Base(),months,new());

Test("T01_intervals_are_contiguous",()=> { for(int i=0;i<ContributionFormula.Periods.Count;i++) { var p=ContributionFormula.Periods[i]; Check(p.Eckwert1>0&&p.Eckwert2>p.Eckwert1,"Eckwerte"); if(i>0)Check(ContributionFormula.Periods[i-1].To!.Value.AddDays(1)==p.From,"Intervalluebergang"); } });
Test("T02_reference_known_rounding",()=> { Equal(PythonRound.Round(2.675,2),2.67); Equal(PythonRound.Round(-2.675,2),-2.67); Equal(PythonRound.Round(.125,2),.12); });
Test("T03_all_python_rounding_vectors",()=> { using var j=JsonDocument.Parse(File.ReadAllText(Path.Combine(root,"tests","golden_vectors.json"))); foreach(var v in j.RootElement.GetProperty("rounding").EnumerateArray()) { Equal(PythonRound.Round(v.GetProperty("value").GetDouble(),v.GetProperty("digits").GetInt32()),v.GetProperty("expected").GetDouble()); vectorComparisons++; } });
Test("T04_all_python_formula_vectors",()=> { using var j=JsonDocument.Parse(File.ReadAllText(Path.Combine(root,"tests","golden_vectors.json"))); double? N(JsonElement e)=>e.ValueKind==JsonValueKind.Null?null:e.GetDouble(); foreach(var v in j.RootElement.GetProperty("contributions").EnumerateArray()) { Equal(ContributionFormula.Calculate(N(v.GetProperty("attc")),N(v.GetProperty("tzg")),DateOnly.Parse(v.GetProperty("date").GetString()!,Parse.Inv)),N(v.GetProperty("expected"))); vectorComparisons++; } });
Test("T05_normal_month",()=> { var r=Run(null,Month(1,Row())); Equal(r.Persons[0].Months[1].Attc,8000); Equal(r.Persons[0].Months[1].Tzg,100); Check(r.Persons[0].Months[1].Amount>0,"Beitrag fehlt"); });
Test("T06_january_fallback",()=> { var r=Run(null,Month(1,Row(attc:null,tzg:null))); Equal(r.Persons[0].Months[1].Attc,8000); Equal(r.Persons[0].Months[1].Tzg,100); });
Test("T07_previous_month_fallback",()=> { var r=Run(null,Month(1,Row(attc:"9000",tzg:"80")),Month(2,Row(attc:null,tzg:null))); Equal(r.Persons[0].Months[2].Attc,9000); Equal(r.Persons[0].Months[2].Tzg,80); });
Test("T08_tariff_99_only_current_month",()=> { var r=Run(null,Month(1,Row(tariff:"99")),Month(2,Row(tariff:"10"))); Equal(r.Persons[0].Months[1].Amount,null); Equal(r.Persons[0].Months[2].Attc,8000); Check(r.Persons[0].TariffOld==99&&r.Persons[0].TariffNew==10,"Tarifhistorie"); });
Test("T09_tariff_98_only_current_month",()=> { var r=Run(null,Month(1,Row(tariff:"10")),Month(2,Row(tariff:"98")),Month(3,Row(tariff:"10"))); Check(r.Persons[0].Months[1].Amount>0&&r.Persons[0].Months[3].Amount>0,"Monatssperre"); Equal(r.Persons[0].Months[2].Amount,null); });
Test("T10_no_restore_of_blocked_attc_without_new_value",()=> { var p=Run(null,Month(1,Row(tariff:"99")),Month(2,Row(tariff:"10",attc:null))).Persons[0]; Equal(p.Months[2].Attc,null); });
Test("T11_latest_change_can_return_to_original_tariff",()=> { var p=Run(null,Month(1,Row(tariff:"10")),Month(2,Row(tariff:"20")),Month(3,Row(tariff:"10"))).Persons[0]; Check(p.TariffOld==10&&p.TariffNew==10&&p.TariffChangeDate==new DateOnly(2026,3,1),"Rueckwechsel"); });
Test("T12_missing_monthly_tariff_carried_forward",()=> { var p=Run(null,Month(1,Row(tariff:"99")),Month(2,Row(tariff:null))).Persons[0]; Equal(p.Months[2].EffectiveTariff,99); Equal(p.Months[2].Attc,null); });
Test("T13_unknown_initial_tariff_blocks",()=>Throws("TARIFF_UNKNOWN",()=>Run(null,Month(1,Row(tariff:null)))));
Test("T14_unknown_tariff_opt_in_is_visible",()=> { var r=new ContributionEngine().Run(Base(),new[]{Month(1,Row(tariff:null))},new(){AllowMissingTariff=true}); Check(r.Warnings.Any(w=>w.Code=="UNKNOWN_TARIFF_ALLOWED"),"Warnung fehlt"); });
Test("T15_new_person_blocks",()=>Throws("TXT_PERSON_MISSING",()=>Run(null,Month(1,Row(id:"9999")))));
Test("T16_unknown_person_ignore_matches_left_join",()=> { var r=new ContributionEngine().Run(Base(),new[]{Month(1,Row(),Row(id:"9999"))},new(){AllowUnknownTxtPersons=true}); Check(r.Persons.Count==1&&r.Warnings.Any(w=>w.Code=="TXT_PERSON_IGNORED"),"Left join"); });
Test("T17_duplicate_baseline_blocks",()=> { var b=Base(); b.Rows.Add(BaseRow()); Throws("DUPLICATE_BASELINE_ID",()=>Run(b,Month(1,Row()))); });
Test("T18_duplicate_normalized_ids_block",()=> { var b=Base(); var r=BaseRow();r["ClientID"]="001001";b.Rows.Add(r); Throws("DUPLICATE_BASELINE_ID",()=>Run(b,Month(1,Row()))); });
Test("T19_baseline_alphanumeric_ids_block",()=> { var b=BaseRow();b["ClientID"]="1001 W";Throws("ID_UNSUPPORTED",()=>Run(Base(b),Month(1,Row()))); });
Test("T20_akta_filter_then_fallback",()=> { var p=Run(null,Month(1,Row(attc:"9999",claim:"AUGUAN"))).Persons[0]; Equal(p.Months[1].Attc,8000); });
Test("T21_last_matching_salary_row",()=> { var p=Run(null,Month(1,Row(attc:"8500"),Row(attc:"100",tzg:"80",type:"OTHER"))).Persons[0]; Equal(p.Months[1].Attc,8500); Equal(p.Months[1].Tzg,80); });
Test("T22_last_row_salary_wins",()=>Equal(Run(null,Month(1,Row(attc:"8500"),Row(attc:"9000"))).Persons[0].Months[1].Attc,9000));
Test("T23_factor_to_percent",()=>Equal(Run(null,Month(1,Row(tzg:"0,5"))).Persons[0].Months[1].Tzg,50));
Test("T24_one_means_full_time_in_raw_txt",()=>Equal(Run(null,Month(1,Row(tzg:"1"))).Persons[0].Months[1].Tzg,100));
Test("T25_one_percent_legacy_ambiguity_reported",()=>Check(Run(null,Month(1,Row(tzg:"0.01"))).Warnings.Any(w=>w.Code=="TZG_ONE_AMBIGUOUS"),"Warnung fehlt"));
Test("T26_zero_tzg_empty_amount",()=>Equal(Run(null,Month(1,Row(tzg:"0"))).Persons[0].Months[1].Amount,null));
Test("T27_negative_salary_blocks",()=>Throws("ATTC_NEGATIVE",()=>Run(null,Month(1,Row(attc:"-1")))));
Test("T28_negative_tzg_blocks",()=>Throws("TZG_RANGE",()=>Run(null,Month(1,Row(tzg:"-1")))));
Test("T29_entry_month_allowed_not_prorated",()=> { var b=BaseRow();b["DAT_AD2"]="15.02.2026";var p=Run(Base(b),Month(1,Row()),Month(2,Row())).Persons[0]; Equal(p.Months[1].Attc,null); Check(p.Months[2].Amount>0,"Eintrittsmonat"); });
Test("T30_entry_after_all_selected_months",()=> { var b=BaseRow();b["DAT_AD2"]="01.04.2026";var p=Run(Base(b),Month(1,Row()),Month(2,Row())).Persons[0]; Check(p.Months.Values.All(m=>m.Attc is null&&m.Tzg is null&&m.Amount is null),"Vor Eintritt"); });
Test("T31_no_entry_substitution",()=> { var b=BaseRow();b.Remove("DAT_AD2");b["JoiningDate"]="15.02.2026";var r=Run(Base(b),Month(1,Row())); Check(r.Persons[0].Months[1].Amount>0&&r.Warnings.Any(w=>w.Code=="ENTRY_DATE_ABSENT"),"DAT_AD2 ersetzt"); });
Test("T32_auguan_exit_after_month_cleared",()=> { var p=Run(null,Month(1,Row()),Month(2,Row(claim:"AUGUAN",term:"15.01.2026"))).Persons[0]; Check(p.Months[1].Amount>0,"Austrittsmonat"); Equal(p.Months[2].Amount,null); });
Test("T33_aktan_does_not_cut_exit",()=> { var p=Run(null,Month(1,Row()),Month(2,Row(term:"15.01.2026"))).Persons[0]; Check(p.Months[2].Amount>0,"Unzulassiger Cutoff"); });
Test("T34_blank_termination_not_a_deletion",()=> { var p=Run(null,Month(1,Row(term:"15.01.2026")),Month(2,Row(term:null))).Persons[0]; Check(p.TerminationDate==new DateOnly(2026,1,15),"Termination overwritten"); });
Test("T35_reordered_files_same_results",()=> { var a=Run(null,Month(2,Row()),Month(1,Row())); var b=Run(null,Month(1,Row()),Month(2,Row())); Check(JsonSerializer.Serialize(a,JsonFiles.Options)==JsonSerializer.Serialize(b,JsonFiles.Options),"Order parity"); });
Test("T36_duplicate_months_block",()=>Throws("DUPLICATE_MONTH",()=>Run(null,Month(1,Row()),Month(1,Row()))));
Test("T37_mixed_years_block",()=> { var m=Month(2,Row()) with { Month=new DateOnly(2027,2,1) };Throws("MULTI_YEAR",()=>Run(null,Month(1,Row()),m)); });
Test("T38_empty_selection_blocks",()=>Throws("TXT_SELECTION_EMPTY",()=>Run(null)));
Test("T39_month_filename",()=>Check(MonthReader.ExtractMonth("change_042026.txt")==new DateOnly(2026,4,1),"Month parse"));
Test("T40_bad_month_filename",()=>Throws("MONTH_FILENAME",()=>MonthReader.ExtractMonth("data.txt")));
Test("T41_bad_month_number",()=>Throws("MONTH_INVALID",()=>MonthReader.ExtractMonth("data_132026.txt")));
Test("T42_parse_german_date",()=>Check(Parse.Date("29.02.2024","date")==new DateOnly(2024,2,29),"Datum"));
Test("T43_bad_date_rejected",()=>Throws("INVALID_DATE",()=>Parse.Date("31.02.2026","date")));
Test("T44_excel_date_serial",()=>Check(Parse.Date(45808d,"date")==new DateOnly(2025,5,31),"Excelserial"));
Test("T45_decimal_comma",()=>Equal(Parse.Number("8116,67","x"),8116.67));
Test("T46_thousands_separator_rejected",()=>Throws("INVALID_NUMBER",()=>Parse.Number("8.116,67","x")));
Test("T47_id_leading_zero_reference_normalization",()=>Check(Parse.Id("001001")=="1001","ID"));
Test("T48_csv_semicolon_and_quoting",()=> { var text="KDMA_IDENT;ARBZEIT_PROZ;BETRAG1;BETRAG1_TYP;ANSPRUCHSTYP;Tarifklasse\n1001;100;8000;ATTC_BAV;AKTAN;10\n";var b=new SourceBlob(Encoding.UTF8.GetBytes(text),new("change_012026.txt",new string('0',64),0));Check(MonthReader.Read(b,new(){TextEncoding="utf-8"}).Rows.Count==1,"CSV"); });
Test("T49_missing_claim_column_blocks",()=> { var b=new SourceBlob(Encoding.UTF8.GetBytes("KDMA_IDENT;ARBZEIT_PROZ;BETRAG1;BETRAG1_TYP;Tarifklasse\n1001;100;8000;ATTC_BAV;10"),new("change_012026.txt",new string('0',64),0));Throws("TXT_SCHEMA",()=>MonthReader.Read(b,new())); });
Test("T50_output_id_is_text_formula_injection_safe",()=> { var r=Run(null,Month(1,Row()));r.Persons[0].Master["Surname"]="=HYPERLINK(\"https://invalid\")";var doc=SpreadsheetWriter.SheetXml(SpreadsheetWriter.Contributions(r));Check(!doc.Descendants(SpreadsheetReader.Main+"f").Any(),"Formula injection"); });
Test("T51_result_roundtrip",()=> { string file=Path.Combine(Path.GetTempPath(),Guid.NewGuid()+".xlsx");try { var r=Run(null,Month(1,Row()));SpreadsheetWriter.Write(file,SpreadsheetWriter.Contributions(r));using var reader=new SpreadsheetReader(File.ReadAllBytes(file));Check(reader.Sheets.Single().Name=="Ergebnis","Sheet");Check(reader.Cells(reader.Sheets[0]).Any(c=>c.Address=="A2"&&Convert.ToString(c.Value)=="1001"),"ID roundtrip"); } finally { File.Delete(file); } });
Test("T52_source_missing_rejected",()=>Throws("INPUT_MISSING",()=>SourceBlob.Read(Path.Combine(Path.GetTempPath(),Guid.NewGuid()+".xlsx"))));
Test("T53_template_unknown_cannot_be_staged",()=> { string file=Path.Combine(Path.GetTempPath(),Guid.NewGuid()+".xlsx");try {SpreadsheetWriter.Write(file,new OutputSheet("Tabelle1",new(){"ClientID"},new(){new(){"1001"}}));var b=SourceBlob.Read(file);Check(!TemplatePreparation.Inspect(b).MatchesKnownIppTemplate,"Identity");Throws("IPP_TEMPLATE_IDENTITY",()=>TemplatePreparation.CreateStagingCopy(b,Run(null,Month(1,Row())),file+".xlsm"));}finally{File.Delete(file);} });
Test("T54_raw_monthly_result_not_accepted_as_baseline",()=> {var b=Base();b.Columns.Add("ATTC_1");Throws("BASELINE_NOT_PRISTINE",()=>Run(b,Month(1,Row())));});
Test("T55_full_demo_pipeline_and_no_pdf_claim",()=>
{
    string output=Path.Combine(Path.GetTempPath(),"MCR_IPP_TEST_"+Guid.NewGuid());
    string baseline=Path.Combine(root,"examples","Bestand_Synthetisch.xlsx");
    var hash=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(baseline)));
    try
    {
        var result=new Pipeline().Execute(new RunRequest { BaselinePath=baseline,TxtPaths=Directory.GetFiles(Path.Combine(root,"examples","Monatsdaten"),"*.txt").ToList(),OutputDirectory=output });
        Check(result.Persons==12&&result.Months==6,"Demoumfang");Check(File.Exists(Path.Combine(result.Directory,"Ergebnis.xlsx")),"Output");Check(result.PdfStatus=="NOT_AUTHORIZED","False readiness");
        Check(hash==Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(baseline))),"Input changed");
    }
    finally { if(Directory.Exists(output))Directory.Delete(output,true); }
});
Test("T56_cancellation_prevents_successful_publish",()=> { using var c=new CancellationTokenSource();c.Cancel();try{new ContributionEngine().Run(Base(),new[]{Month(1,Row())},new(),cancel:c.Token);}catch(OperationCanceledException){return;}throw new Exception("Cancellation ignored");});


// V0.2: nonblocking person reconciliation is an orchestration layer; T15/T16 still test strict legacy core modes.
Dictionary<string,string?> Named(string id="9999",string surname="Neumann",string first="Nora",string birth="02.02.1990",string? entry=null)
{
    var r=Row(id:id);r["Surname"]=surname;r["FirstName"]=first;r["BirthDate"]=birth;r["DAT_AD2"]=entry;return r;
}
SourceInfo BSource(string hash="A") => new("synthetic.xlsx",new string(hash[0],64),100);
PreparedPersons PrepareTest(IReadOnlyList<MonthFile> months,IReadOnlyList<NewPersonDecision>? decisions=null,InputTable? b=null) => PersonReview.Prepare(b??Base(),BSource(),months,decisions);
NewPersonDecision Approve(PreparedPersons p,string id="9999",string entry="01.02.2026")
{
    var c=p.Report.Cases.Single(c=>c.ClientId==id);
    return new(){ContextSha256=p.Report.ContextSha256,CaseId=c.CaseId,ClientId=id,Surname=c.Surname??"Neumann",FirstName=c.FirstName??"Nora",BirthDate=c.BirthDate??new DateOnly(1990,2,2),DatAd2=Parse.Date(entry,"DAT_AD2")!.Value,Reviewer="synthetic-test",Evidence="synthetic HR fixture - no real person",ConfirmedUtc=new DateTimeOffset(2026,9,29,0,0,0,TimeSpan.Zero),IdentityAndNewEntryVerified=true};
}
Test("T57_unknown_collected_and_known_continue",()=> {var m=new[]{Month(1,Row(),Named())};var p=PrepareTest(m);Check(p.Report.OpenCases==1&&p.Report.Cases[0].DisplayName=="Nora Neumann","Case missing");Check(p.Months[0].Rows.Count==1,"Unknown not isolated");var r=new ContributionEngine().Run(p.Baseline,p.Months,new());Check(r.Persons.Count==1&&r.Persons[0].Months[1].Amount>0,"Known did not continue");});
Test("T58_all_months_same_unknown_one_case",()=> {var p=PrepareTest(new[]{Month(2,Row(),Named()),Month(1,Named(),Row(),Named())});Check(p.Report.Cases.Count==1&&p.Report.Cases[0].Occurrences.Count==3,"Dedup lost findings");Check(p.Report.Cases[0].Occurrences[0].Month=="2026-01","Chronology");});
Test("T59_missing_name_never_invented",()=> {var p=PrepareTest(new[]{Month(1,Row(),Row(id:"9999"))});Check(p.Report.Cases.Single().DisplayName=="NAME_NICHT_GELIEFERT","Name invented");});
Test("T60_found_record_and_raw_id_preserved",()=> {var p=PrepareTest(new[]{Month(1,Row(),Named(id:"009999"))});var o=p.Report.Cases.Single().Occurrences.Single();Check(o.DataRecord==2&&o.OriginalId=="009999"&&p.Report.Cases[0].ClientId=="9999","Provenance");});
Test("T61_invalid_id_is_case_not_whole_run_failure",()=> {var p=PrepareTest(new[]{Month(1,Row(),Named(id:"1001 W"))});Check(p.Report.Cases[0].Classification=="KENNUNG_UNGUELTIG"&&p.Months[0].Rows.Count==1,"Unsupported ID ignored or normalized");});
Test("T62_empty_ids_not_merged_as_one_person",()=> {var p=PrepareTest(new[]{Month(1,Row(),Named(id:""),Named(id:""))});Check(p.Report.Cases.Count==2,"Empty IDs merged");});
Test("T63_same_name_other_id_flagged_not_merged",()=> {var p=PrepareTest(new[]{Month(1,Row(),Named(surname:"Demo",first:"Test",birth:"01.01.1980"))});Check(p.Report.Cases[0].Classification=="MOEGLICHER_BESTANDSTREFFER_ANDERE_ID"&&p.Report.Cases[0].PossibleBaselineIds.Single()=="1001","Match hint");});
Test("T64_identity_conflict_remains_open",()=> {var p=PrepareTest(new[]{Month(1,Row(),Named()),Month(2,Row(),Named(first:"Andere"))});Check(p.Report.Cases[0].Classification=="IDENTITAETSDATEN_KONFLIKT","Conflict lost");});
Test("T65_entry_hint_is_not_approval",()=> {var p=PrepareTest(new[]{Month(1,Row()),Month(2,Row(),Named(entry:"01.02.2026"))});Check(p.Report.Cases[0].Classification=="NEUEINTRITT_KANDIDAT"&&p.Report.AddedPersons==0&&p.Report.OpenCases==1,"False auto approval");});
Test("T66_confirmed_entry_added_and_before_entry_blank",()=> {var m=new[]{Month(1,Row()),Month(2,Row(),Named(entry:"15.02.2026"))};var p=PrepareTest(m);var q=PrepareTest(m,new[]{Approve(p,entry:"15.02.2026")});Check(q.Report.AddedPersons==1&&q.Report.OpenCases==0,"Not admitted: "+q.Report.Cases[0].Note);var r=new ContributionEngine().Run(q.Baseline,q.Months,new());var n=r.Persons.Single(p=>p.ClientId=="9999");Check(n.Months[1].Amount is null&&n.Months[2].Amount>0,"Entry timing");});
Test("T67_stale_context_approval_not_applied",()=> {var m=new[]{Month(1,Row()),Month(2,Row(),Named())};var p=PrepareTest(m);var d=Approve(p);d.ContextSha256=new string('B',64);var q=PrepareTest(m,new[]{d});Check(q.Report.OpenCases==1&&q.Report.AddedPersons==0&&q.Report.Notices.Count>0,"Stale approval accepted");});
Test("T68_no_explicit_confirmation_no_admission",()=> {var m=new[]{Month(1,Row()),Month(2,Row(),Named())};var p=PrepareTest(m);var d=Approve(p);d.IdentityAndNewEntryVerified=false;var q=PrepareTest(m,new[]{d});Check(q.Report.AddedPersons==0&&q.Report.Cases[0].Resolution=="FREIGABE_NICHT_ANWENDBAR","Unconfirmed accepted");});
Test("T69_missing_payroll_blocks_only_new_admission",()=> {var row=Named();row["BETRAG1"]=null;var m=new[]{Month(1,Row()),Month(2,Row(),row)};var p=PrepareTest(m);var q=PrepareTest(m,new[]{Approve(p)});Check(q.Report.AddedPersons==0&&q.Months[1].Rows.Count==1,"Incomplete new salary admitted");});
Test("T70_duplicate_decisions_visible_no_admission",()=> {var m=new[]{Month(1,Row()),Month(2,Row(),Named())};var p=PrepareTest(m);var d=Approve(p);var q=PrepareTest(m,new[]{d,d});Check(q.Report.AddedPersons==0&&q.Report.Cases[0].Note.Contains("DECISION_CONFLICT"),"Duplicate decisions accepted");});
Test("T71_confirmation_conflicting_txt_rejected",()=> {var m=new[]{Month(1,Row()),Month(2,Row(),Named())};var p=PrepareTest(m);var d=Approve(p);d.Surname="Anders";var q=PrepareTest(m,new[]{d});Check(q.Report.AddedPersons==0&&q.Report.Cases[0].Note.Contains("MASTER_CONFLICT"),"Mismatch admitted");});
Test("T72_missing_evidence_not_admitted",()=> {var m=new[]{Month(1,Row()),Month(2,Row(),Named())};var p=PrepareTest(m);var d=Approve(p);d.Evidence="";Check(PrepareTest(m,new[]{d}).Report.AddedPersons==0,"Missing evidence");});
Test("T73_two_new_same_name_not_both_added",()=> {var m=new[]{Month(1,Row()),Month(2,Row(),Named(),Named(id:"9998"))};var p=PrepareTest(m);var q=PrepareTest(m,new[]{Approve(p),Approve(p,id:"9998")});Check(q.Report.AddedPersons==0&&q.Report.OpenCases==2&&q.Baseline.Rows.Count==1,"Double new person");});
Test("T74_baseline_not_mutated_by_new_admission",()=> {var b=Base();var m=new[]{Month(1,Row()),Month(2,Row(),Named())};var p=PrepareTest(m,b:b);var q=PrepareTest(m,new[]{Approve(p)},b);Check(b.Rows.Count==1&&q.Baseline.Rows.Count==2,"Baseline mutation");});
Test("T75_old_entry_not_invented_as_current_new",()=> {var m=new[]{Month(1,Row(),Named(entry:"01.01.2010"))};var p=PrepareTest(m);Check(p.Report.Cases[0].Classification=="UNBEKANNT_NEUEINTRITT_NICHT_BELEGT","Old becomes new");var d=Approve(p,entry:"01.01.2010");Check(PrepareTest(m,new[]{d}).Report.AddedPersons==0,"Old admitted");});
Test("T76_joining_date_not_used_as_dat_ad2",()=> {var row=Named();row["JoiningDate"]="01.01.2026";var p=PrepareTest(new[]{Month(1,Row(),row)});Check(p.Report.Cases[0].DatAd2 is null&&p.Report.Cases[0].Classification=="UNBEKANNT_NEUEINTRITT_NICHT_BELEGT","Date substitution");});
Test("T77_id_normalized_known_not_new",()=> {var p=PrepareTest(new[]{Month(1,Row(id:"001001"))});Check(p.Report.Cases.Count==0&&p.Months[0].Rows.Count==1,"Known normalization");});
Test("T78_header_inventory_available_without_identity_values",()=> {var row=Row(id:"9999");row["PAYROLL_CUSTOM_NAME"]="Test";var p=PrepareTest(new[]{Month(1,Row(),row)});Check(p.Report.TxtHeaders.Values.Single().Contains("PAYROLL_CUSTOM_NAME")&&p.Report.Cases[0].DisplayName=="NAME_NICHT_GELIEFERT","Header inventory");});
Test("T79_review_workbook_injection_safe",()=> {var p=PrepareTest(new[]{Month(1,Row(),Named(surname:"=HYPERLINK(1)"))});string dir=Path.Combine(Path.GetTempPath(),"IPP_review_"+Guid.NewGuid());Directory.CreateDirectory(dir);try {PersonReview.Write(dir,p.Report);using var r=new SpreadsheetReader(File.ReadAllBytes(Path.Combine(dir,"Prueffaelle.xlsx")));Check(r.Sheets.All(s=>!r.Cells(s).Any(c=>c.Formula is not null)),"Formula injected");Check(r.Sheets.Count==2,"Review sheets");}finally{Directory.Delete(dir,true);}});
Test("T80_context_order_independent",()=> {var a=Month(1,Row(),Named());var b=Month(2,Row(),Named());var p=PrepareTest(new[]{a,b});var q=PrepareTest(new[]{b,a});Check(p.Report.ContextSha256==q.Report.ContextSha256&&p.Report.Cases[0].CaseId==q.Report.Cases[0].CaseId,"Context input order");});
Test("T81_baseline_hash_change_requires_reconfirmation",()=> {var m=new[]{Month(1,Row()),Month(2,Row(),Named())};var p=PrepareTest(m);var q=PersonReview.Prepare(Base(),BSource("C"),m,new[]{Approve(p)});Check(q.Report.OpenCases==1&&q.Report.AddedPersons==0,"Baseline hash not bound");});
Test("T82_month_hash_change_requires_reconfirmation",()=> {var m=new[]{Month(1,Row()),Month(2,Row(),Named())};var p=PrepareTest(m);var changed=new[]{m[0],m[1] with {Source=new("synthetic",new string('C',64),0)}};Check(PrepareTest(changed,new[]{Approve(p)}).Report.AddedPersons==0,"TXT hash not bound");});
Test("T83_earlier_observation_requires_manual_review",()=> {var m=new[]{Month(1,Row(),Named()),Month(2,Row(),Named())};var p=PrepareTest(m);var q=PrepareTest(m,new[]{Approve(p)});Check(q.Report.Cases[0].Note.Contains("EARLIER_OBSERVATION")&&q.Report.AddedPersons==0,"Earlier occurrence ignored");});
Test("T84_invalid_tariff_new_candidate_does_not_stop_known",()=> {var row=Named();row["Tarifklasse"]="invalid";var m=new[]{Month(1,Row()),Month(2,Row(),row)};var p=PrepareTest(m);var q=PrepareTest(m,new[]{Approve(p)});Check(q.Report.OpenCases==1&&q.Report.AddedPersons==0,"Bad tariff new admission");Check(new ContributionEngine().Run(q.Baseline,q.Months,new()).Persons.Count==1,"Known failed");});
Test("T85_review_cancellation_respected",()=> {using var c=new CancellationTokenSource();c.Cancel();try{PersonReview.Prepare(Base(),BSource(),new[]{Month(1,Row())},cancel:c.Token);}catch(OperationCanceledException){return;}throw new Exception("Cancellation ignored");});
Test("T86_empty_result_never_means_all_persons_processed",()=> {var m=new[]{Month(1,Named())};var p=PrepareTest(m);Check(p.Report.OpenCases==1&&p.Baseline.Rows.Count==1,"Review lost absent base");});
Test("T87_same_names_in_confirmation_checked_even_if_txt_names_absent",()=> {var m=new[]{Month(1,Row()),Month(2,Row(),Row(id:"9999"))};var p=PrepareTest(m);var d=Approve(p);d.Surname="Demo";d.FirstName="Test";Check(PrepareTest(m,new[]{d}).Report.AddedPersons==0,"Manual duplicate creation");});
Test("T88_full_pipeline_partial_status_and_persistent_cases",()=>
{
    string dir=Path.Combine(Path.GetTempPath(),"IPP_partial_"+Guid.NewGuid());Directory.CreateDirectory(dir);
    try
    {
        string b=Path.Combine(dir,"base.xlsx"),t=Path.Combine(dir,"change_012026.txt");
        var br=BaseRow();SpreadsheetWriter.Write(b,new OutputSheet("Bestand",br.Keys.ToList(),new(){br.Values.ToList()}));
        File.WriteAllText(t,"KDMA_IDENT;ARBZEIT_PROZ;BETRAG1;BETRAG1_TYP;ANSPRUCHSTYP;Tarifklasse;Surname;FirstName;BirthDate\n1001;100;8000;ATTC_BAV;AKTAN;10;Demo;Test;01.01.1980\n9999;100;8000;ATTC_BAV;AKTAN;10;Neumann;Nora;02.02.1990\n",Encoding.UTF8);
        var outcome=new Pipeline().Execute(new RunRequest{BaselinePath=b,TxtPaths=new(){t},OutputDirectory=Path.Combine(dir,"out")});
        Check(outcome.Persons==1&&outcome.OpenPersonCases==1&&outcome.ContributionStatus=="PARTIAL_PERSON_REVIEW_REQUIRED","False completion");
        Check(File.Exists(Path.Combine(outcome.Directory,"Prueffaelle.xlsx"))&&File.Exists(Path.Combine(outcome.Directory,"Ergebnis.xlsx")),"Published files missing");
        Check(outcome.PdfStatus=="NOT_AUTHORIZED","PDF authority changed");
    }
    finally{Directory.Delete(dir,true);}
});
Test("T89_later_known_error_keeps_person_findings",()=>
{
    string dir=Path.Combine(Path.GetTempPath(),"IPP_failed_review_"+Guid.NewGuid());Directory.CreateDirectory(dir);
    try
    {
        string b=Path.Combine(dir,"base.xlsx"),t=Path.Combine(dir,"change_012026.txt");
        var br=BaseRow();SpreadsheetWriter.Write(b,new OutputSheet("Bestand",br.Keys.ToList(),new(){br.Values.ToList()}));
        File.WriteAllText(t,"KDMA_IDENT;ARBZEIT_PROZ;BETRAG1;BETRAG1_TYP;ANSPRUCHSTYP;Tarifklasse\n1001;100;-1;ATTC_BAV;AKTAN;10\n9999;100;8000;ATTC_BAV;AKTAN;10\n",Encoding.UTF8);
        try {new Pipeline().Execute(new RunRequest{BaselinePath=b,TxtPaths=new(){t},OutputDirectory=Path.Combine(dir,"out")});throw new Exception("Expected failure");}
        catch(IppException ex){Check(ex.Code=="ATTC_NEGATIVE","Unexpected failure");Check(ex.Data["RunDirectory"] is string p&&File.Exists(Path.Combine(p,"Personen_Pruefung.json"))&&File.Exists(Path.Combine(p,"FAILED.json")),"Findings lost");}
    }
    finally{Directory.Delete(dir,true);}
});
Test("T90_full_pipeline_confirmed_entry_and_updated_baseline",()=>
{
    string dir=Path.Combine(Path.GetTempPath(),"IPP_new_"+Guid.NewGuid());Directory.CreateDirectory(dir);
    try
    {
        string b=Path.Combine(dir,"base.xlsx"),t=Path.Combine(dir,"change_012026.txt"),decisions=Path.Combine(dir,"decisions.json");
        var br=BaseRow();SpreadsheetWriter.Write(b,new OutputSheet("Bestand",br.Keys.ToList(),new(){br.Values.ToList()}));
        File.WriteAllText(t,"KDMA_IDENT;ARBZEIT_PROZ;BETRAG1;BETRAG1_TYP;ANSPRUCHSTYP;Tarifklasse;Surname;FirstName;BirthDate;DAT_AD2\n1001;100;8000;ATTC_BAV;AKTAN;10;Demo;Test;01.01.1980;\n9999;100;8000;ATTC_BAV;AKTAN;10;Neumann;Nora;02.02.1990;01.01.2026\n",Encoding.UTF8);
        var request=new RunRequest{BaselinePath=b,TxtPaths=new(){t},OutputDirectory=Path.Combine(dir,"out"),PersonDecisionsPath=decisions};
        var first=new Pipeline().Execute(request);var report=JsonFiles.Read<PersonReviewReport>(Path.Combine(first.Directory,"Personen_Pruefung.json"));
        var c=report.Cases.Single();JsonFiles.Write(decisions,new List<NewPersonDecision>{new(){ContextSha256=report.ContextSha256,CaseId=c.CaseId,ClientId=c.ClientId,Surname="Neumann",FirstName="Nora",BirthDate=new(1990,2,2),DatAd2=new(2026,1,1),Reviewer="test",Evidence="Synthetic fixture",ConfirmedUtc=DateTimeOffset.UtcNow,IdentityAndNewEntryVerified=true}});
        var second=new Pipeline().Execute(request);Check(second.Persons==2&&second.NewPersonsAdded==1&&second.OpenPersonCases==0,"Admission failed");
        using var reader=new SpreadsheetReader(File.ReadAllBytes(Path.Combine(second.Directory,"Bestand_Fortgeschrieben.xlsx")));Check(reader.Baseline(null).Rows.Count==2,"Baseline copy missing new person");
        var third=new Pipeline().Execute(request);Check(third.Persons==2&&third.NewPersonsAdded==1,"Repeat duplicates person");
    }
    finally{Directory.Delete(dir,true);}
});

Directory.CreateDirectory(Path.Combine(root,"evidence","local"));
string report=Path.Combine(root,"evidence","local","csharp_tests.json");
var failures=results.Count(r=>r.Error is not null);
JsonFiles.Write(report,new { status=failures==0?"PASS":"FAIL",utc=DateTimeOffset.UtcNow,runtime=System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription,operatingSystem=System.Runtime.InteropServices.RuntimeInformation.OSDescription,tests=results.Count,passed=results.Count-failures,failed=failures,vectorComparisons,fullPythonWorkflowParityCertified=false,realExcelComTested=false,details=results.Select(r=>new{name=r.Name,passed=r.Error is null,error=r.Error}) });
var junit=new XDocument(new XElement("testsuite",new XAttribute("name","MCR_IPP"),new XAttribute("tests",results.Count),new XAttribute("failures",failures),results.Select(r=>new XElement("testcase",new XAttribute("name",r.Name),r.Error is null?null:new XElement("failure",r.Error)))));
junit.Save(Path.Combine(root,"evidence","local","csharp_tests.junit.xml"));
Console.WriteLine($"\n{results.Count-failures}/{results.Count} tests; {vectorComparisons} vector comparisons; failures={failures}");
return failures==0?0:1;
