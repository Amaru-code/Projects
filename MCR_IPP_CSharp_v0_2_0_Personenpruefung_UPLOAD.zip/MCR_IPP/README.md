# MCR IPP

C#/.NET 10 · IPP only · offline-first · Paket 0.2.0 / Personenprüfung mit bestätigten Neueintritten

**Personenprüfung:** Unbekannte Kennungen werden gesammelt statt ignoriert; bekannte
Personen laufen weiter. Geprüfte Neueintritte können über die Oberfläche bestätigt
und im nächsten Lauf aufgenommen werden. Siehe `PERSONENPRUEFUNG_LESEN.md`.

**SDK:** vorhandener gemeinsamer Compiler unter
`%USERPROFILE%\projects\Compiler\csharp\tools\dotnet\dotnet.exe` wird zuerst geprüft.
Keine Neuinstallation. Siehe `SDK_FIX_LESEN.md`.

Beginnen Sie mit **[START_HIER.md](START_HIER.md)** und `START.cmd`.

Keine NuGet-Pakete und kein Python im Betriebsweg. Vorhandenes .NET-10-Windows-SDK
wird für den lokalen Build benötigt. Keine DC-Integration. Keine produktive IPP-/PDF-
Freigabe, solange die dokumentierten fachlichen Lücken offen sind.

| Projekt | Zweck |
|---|---|
| `Mcr.Ipp.Core` | Sicheres OpenXML-Lesen, TXT-Parser, Beitragskern, Ergebnis-XLSX, Audit, IPP-Staging |
| `Mcr.Ipp.Cli` | Headless-Beitragslauf und statische Vorlagenprüfung |
| `Mcr.Ipp.Desktop` | Windows-Oberfläche und separater Excel-PDF-Entwurfsadapter |
| `Mcr.Ipp.Tests` | Eigenständiger Test-Runner ohne Online-Testframework |

Die Container-Prüfung ist in `evidence/verification.json` dokumentiert. C#-Build/Excel-
Lauf wurden in der Erstellungsumgebung nicht ausgeführt. Die Startdatei baut und testet
vor dem ersten Bedienlauf lokal; sie verändert dafür keine globalen Systemeinstellungen.
