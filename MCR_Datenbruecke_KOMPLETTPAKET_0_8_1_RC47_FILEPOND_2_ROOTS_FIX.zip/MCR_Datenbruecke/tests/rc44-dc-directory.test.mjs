import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {PHASE2_SCRIPTS} from '../lib/phase2-account-statement-plan.mjs';
import {generatorPaths,localGeneratorInventory,inspectExistingStatements} from '../lib/phase2-pdf-evidence.mjs';
import {verifyPackage,verifyPrevious} from '../tools/integrity.mjs';
import {sha256} from '../lib/core.mjs';
import {ROOT} from './helpers.mjs';
import {VERSION} from '../lib/control.mjs';

function syntheticPdf(file){fs.writeFileSync(file,Buffer.concat([Buffer.from('%PDF-1.7\n'),Buffer.alloc(250,0x20),Buffer.from('\n%%EOF\n')]));}
function fixture(){
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC44-DC-PATH-'));
 const root=path.join(dir,'MCR_Datenbruecke');fs.mkdirSync(root);
 for(const plan of ['DC','PP+']){
  const spec=PHASE2_SCRIPTS[plan],folder=path.join(dir,spec.subfolder);fs.mkdirSync(path.join(folder,spec.output),{recursive:true});
  fs.writeFileSync(path.join(folder,spec.start),'@echo off\r\n');
  syntheticPdf(path.join(folder,spec.output,'11368989_Kontoauszug_'+plan+'.pdf'));
 }
 return {dir,root,clean:()=>fs.rmSync(dir,{recursive:true,force:true})};
}

test('RC44 DC directory uses Kontoauszug_DC and real PP+ counterpart; two existing PDF files resolve',()=>{
 assert.equal(PHASE2_SCRIPTS.DC.subfolder,'Kontoauszug_DC');
 assert.equal(PHASE2_SCRIPTS['PP+'].subfolder,'Kontoauszug_pp+');
 const a=fixture();try{
  const loc=generatorPaths(a.root,'DC');assert.equal(path.basename(loc.folder),'Kontoauszug_DC');
  assert.equal(path.basename(loc.start),'START_KONTOAUSZUG_DC.bat');
  assert(fs.existsSync(loc.output));
  const inventory=localGeneratorInventory(a.root);
  assert.equal(inventory.plans.length,2);
  assert(inventory.plans.every(p=>p.scriptPresent&&p.outputPresent&&p.existingPdfCount===1));
  const proof=inspectExistingStatements(a.root,['DC','PP+'],'11368989');
  assert.deepEqual(proof.artifacts.map(p=>p.name).sort(),['11368989_Kontoauszug_DC.pdf','11368989_Kontoauszug_PP+.pdf'].sort());
  assert(proof.artifacts.every(x=>x.file.startsWith(a.dir)));
  assert.equal(proof.comarchEffects,0);
 }finally{a.clean();}
});

test('RC44 ignores legacy space-named DC folder, without silently selecting wrong PDF',()=>{
 const a=fixture();try{
  const dc=path.join(a.dir,'Kontoauszug_DC'),legacy=path.join(a.dir,'Kontoauszug DC');
  fs.mkdirSync(legacy);fs.mkdirSync(path.join(legacy,'Ausgabe_PDF'));
  syntheticPdf(path.join(legacy,'Ausgabe_PDF','11368989_Kontoauszug_DC.pdf'));
  const p=inspectExistingStatements(a.root,['DC','PP+'],'11368989');
  assert.equal(p.artifacts[0].file,path.join(dc,'Ausgabe_PDF','11368989_Kontoauszug_DC.pdf'));
  fs.renameSync(dc,path.join(a.dir,'REMOVED_FOR_TEST'));
  assert.throws(()=>inspectExistingStatements(a.root,['DC','PP+'],'11368989'),e=>e.code==='P2_OUTPUT_FOLDER_MISSING');
 }finally{a.clean();}
});

test('RC44 pinned original RC43 package manifest and exact version of current package',()=>{
 assert.equal(VERSION,'0.8.1-rc.47');
 const ref=path.join(ROOT,'tools/reference/complete-0.8.1-rc.43-manifest.json');
 const r=fs.readFileSync(ref);assert.equal(JSON.parse(r).version,'0.8.1-rc.43');
 assert.match(fs.readFileSync(path.join(ROOT,'tools/integrity.mjs'),'utf8'),new RegExp(sha256(r)));
 assert.equal(verifyPackage(ROOT).version,VERSION);
});
