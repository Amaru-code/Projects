/** RC5 upgrade qualification against byte-identical published RC4 ZIP. */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {sha256} from '../lib/core.mjs';
import {readZip} from '../lib/zip.mjs';
import {ROOT,temp,putActive} from './helpers.mjs';
import {verifyPackage,verifyPrevious,treeDigest} from '../tools/integrity.mjs';
import {planInstall,installSoftware,journals,restoreSoftware} from '../tools/deploy.mjs';
import {VERSION} from '../lib/control.mjs';
const ZIP=fs.readFileSync(path.join(ROOT,'tests/fixtures/complete-0.8.1-rc.4.zip'));
const RC4_SHA='a0dce96e34862b5c19a93413ab6f5e6b254b7ce0118dbd3b3664e3eeb41da1ad';
function makeFixture(){
 const parent=temp(),target=path.join(parent,'MCR_Datenbruecke');fs.mkdirSync(target);
 const z=readZip(ZIP);
 for(const name of z.names){assert.ok(name.startsWith('MCR_Datenbruecke/'));const rel=name.slice('MCR_Datenbruecke/'.length);const f=path.join(target,rel);fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,z.get(name));}
 putActive(target);const profile=path.join(target,'.runtime/edge-profile');fs.mkdirSync(profile,{recursive:true});fs.writeFileSync(path.join(profile,'profile.sentinel'),'do-not-modify');
 const ctrl=path.join(target,'.runtime/beta-control');fs.mkdirSync(ctrl,{recursive:true});fs.writeFileSync(path.join(ctrl,'last-run.json'),JSON.stringify({schema:'MCR_BETA_RUN_V1',state:'INTERRUPTED_REVIEW_REQUIRED',operation:'REAL_RUN'})+'\n');
 const diag=path.join(target,'diagnostics');fs.mkdirSync(diag);fs.writeFileSync(path.join(diag,'old.sentinel'),'unchanged');
 return {parent,target,protected:{private:treeDigest(path.join(target,'private_data')),profile:treeDigest(profile),run:sha256(fs.readFileSync(path.join(ctrl,'last-run.json'))),diagnostic:treeDigest(diag)},cleanup(){fs.rmSync(parent,{recursive:true,force:true});}};
}
function preserved(f){assert.equal(treeDigest(path.join(f.target,'private_data')),f.protected.private);assert.equal(treeDigest(path.join(f.target,'.runtime/edge-profile')),f.protected.profile);assert.equal(sha256(fs.readFileSync(path.join(f.target,'.runtime/beta-control/last-run.json'))),f.protected.run);assert.equal(treeDigest(path.join(f.target,'diagnostics')),f.protected.diagnostic);}
test('original RC4 archive is pinned; RC4 -> RC5 keeps mapping, profile and pending run',()=>{
 assert.equal(sha256(ZIP),RC4_SHA);
 const f=makeFixture();try{
  assert.equal(verifyPrevious(f.target).version,'0.8.1-rc.4');
  const plan=planInstall(ROOT,f.target),result=installSoftware(plan,{guard:()=>{}});
  assert.equal(result.state,'COMPLETE');assert.equal(verifyPackage(f.target).version,VERSION);
  preserved(f);
  assert.equal(restoreSoftware(journals(f.target)[0]).state,'ROLLED_BACK');
  assert.equal(verifyPrevious(f.target).version,'0.8.1-rc.4');preserved(f);
 }finally{f.cleanup();}
});
