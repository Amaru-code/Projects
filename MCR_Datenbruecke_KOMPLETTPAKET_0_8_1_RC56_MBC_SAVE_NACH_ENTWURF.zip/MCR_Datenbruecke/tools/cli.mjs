import fs from 'node:fs';import path from 'node:path';import os from 'node:os';import {fileURLToPath} from 'node:url';import {spawn} from 'node:child_process';import readline from 'node:readline/promises';
import {sha256,requireThat as need} from '../lib/core.mjs';import {VERSION,stamp,plainPath,readJSON,writeJSON,controlDir,lock,ledger,runState,assertNoReview,processAlive,assertNoMigrationPriority} from '../lib/control.mjs';import {loadActiveMapping} from '../lib/active-mapping.mjs';import {resolveConfig} from '../lib/config.mjs';import {verifyPackage,verifyPrevious} from './integrity.mjs';import {planInstall,installSoftware,journals,restoreSoftware} from './deploy.mjs';import {windowsIdle} from './process-guard.mjs';import {certifyDemo,certifyPrefixDemo,certifyForwardDemo,certifyManualNameDemo,certifyPilot,certifyForwardWithoutEmail} from './proof.mjs';
import {beginMigrationPriority,recoverOrphanedMigrationPriority} from '../lib/migration-priority.mjs';
import {releaseProvenPreActionAbort} from '../lib/preaction-recovery.mjs';
import {inventoryLive,generatorPreflight,manualPdfPilot} from '../src/phase2-supervised.mjs';
import {phase2Run} from '../src/phase2-run.mjs';
import {prepareFreshRun,pendingSnapshot,assertPendingUnchanged} from '../lib/run-reset.mjs';import {authorizeChainedContinuation} from '../lib/continuation-policy.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),defaultTarget=()=>path.join(os.homedir(),'projects/Aktive_Projekte/Ticket_bot/MCR_Datenbruecke');
const log=s=>console.log(s);async function ask(text){const rl=readline.createInterface({input:process.stdin,output:process.stdout});try{return String(await rl.question(text)).trim();}finally{rl.close();}}
function outDir(){const d=path.join(root,'Ergebnis');fs.mkdirSync(d,{recursive:true});plainPath(d);return d;}
function cleanEnv(extra={}){const e={...process.env};for(const k of Object.keys(e))if(k.startsWith('MCR_'))delete e[k];delete e.NODE_OPTIONS;delete e.NODE_PATH;return {...e,...extra};}
export async function runChild(file,args=[],options={}){
 // RC30: mirror the complete real runner stream, including the pilot AND its
 // continuation, to a local append-only daily transcript. Console stays fast.
 const {logFile,...spawnOptions}=options;
 return new Promise((resolve,reject)=>{
  if(logFile){plainPath(path.dirname(logFile));if(fs.existsSync(logFile))plainPath(logFile);
   fs.appendFileSync(logFile,'\n=== MCR '+VERSION+' '+new Date().toISOString()+' ===\n',{mode:0o600});}
  const child=spawn(process.execPath,[file,...args],{cwd:root,stdio:logFile?['inherit','pipe','pipe']:'inherit',env:cleanEnv(),windowsHide:false,...spawnOptions});
  if(logFile)for(const [stream,destination] of [[child.stdout,process.stdout],[child.stderr,process.stderr]]){
   stream?.on('data',bytes=>{destination.write(bytes);try{fs.appendFileSync(logFile,bytes,{mode:0o600});}
    catch{destination.write('\nWARN MCR_LOG_WRITE: Lokale Laufprotokoll-Datei nicht beschreibbar.\n');}});
  }
  child.once('error',reject);child.once('close',(code,signal)=>resolve({code,signal}));
 });
}
// The old immutable release ZIPs are *development qualification fixtures*.
// Do not copy archived full releases into each new production release: doing so
// previously doubled the distributed ZIP on every version (7 -> 14 -> 28 MiB).
const HISTORICAL_ARCHIVE_TESTS=new Set([
 'rc4-windows-install.test.mjs','rc5-upgrade.test.mjs',
 'rc6-upgrade.test.mjs','rc7-upgrade.test.mjs',
 'rc8-upgrade.test.mjs','rc9-upgrade.test.mjs',
 'rc10-upgrade.test.mjs','rc11-upgrade.test.mjs','rc12-upgrade.test.mjs','rc13-upgrade.test.mjs','rc14-upgrade.test.mjs','rc15-upgrade.test.mjs','rc16-upgrade.test.mjs','rc17-upgrade.test.mjs','rc18-upgrade.test.mjs','rc19-upgrade.test.mjs','rc20-upgrade.test.mjs','rc21-upgrade.test.mjs','rc22-upgrade.test.mjs','rc23-upgrade.test.mjs','rc24-upgrade.test.mjs','rc25-upgrade.test.mjs','rc26-upgrade.test.mjs','rc27-upgrade.test.mjs','rc28-upgrade.test.mjs','rc45-upgrade.test.mjs','rc46-upgrade.test.mjs','rc47-upgrade.test.mjs','rc48-upgrade.test.mjs','rc49-upgrade.test.mjs','rc50-upgrade.test.mjs','rc51-upgrade.test.mjs','rc52-upgrade.test.mjs','rc53-upgrade.test.mjs','rc54-upgrade.test.mjs','rc55-upgrade.test.mjs','rc56-upgrade.test.mjs','upgrade-residuals.test.mjs']);
export async function selftest(){
 verifyPackage(root);
 const all=fs.readdirSync(path.join(root,'tests')).filter(n=>n.endsWith('.test.mjs')).sort();
 for(const n of HISTORICAL_ARCHIVE_TESTS)need(all.includes(n),'TESTS_MISSING','Archivtest fehlt: '+n);
 const tests=all.filter(n=>!HISTORICAL_ARCHIVE_TESTS.has(n)).map(n=>path.join(root,'tests',n));
 need(tests.length>=8,'TESTS_MISSING','Betriebstests fehlen.');
 log('QA-PROFIL: Betriebs-, Sicherheits-, Installer- und aktuelle Regressions-Selbsttests ('+tests.length+' Suites).');
 log('INFO: '+HISTORICAL_ARCHIVE_TESTS.size+' historische Upgrade-Suites sind separat mit Original-ZIPs qualifiziert; keine alten Komplettpakete im Download.');
 const r=await runChild('--test',['--test-concurrency=4',...tests]);
 need(r.code===0&&!r.signal,'SELFTEST_FAILED','Selbsttest fehlgeschlagen.');
 log('PASS SELFTEST_SLIM_RUNTIME');return true;
}
export async function demo(){
 const pkg=verifyPackage(root),proofs=[];
 for(const scenario of ['normal','prefixed-member','missing-member','manual-name']){
  const temp=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-Komplett-Demo-')),runId=stamp();
  for(const d of ['src','lib','examples','config'])fs.cpSync(path.join(root,d),path.join(temp,d),{recursive:true,errorOnExist:true,force:false,dereference:false});
  const config=readJSON(path.join(root,'config/local-runner-queue-send.json'));
  writeJSON(path.join(temp,'config/local-runner-queue-send.json'),{...config,profileDirectory:'.runtime/edge-profile',downloadDirectory:'.runtime/downloads',runtimeDirectory:'.runtime',diagnosticDirectory:'diagnostics'});
  log('\nFiktive Browserprobe ['+scenario+'] - eigener Tempordner, keine COMARCH-Anmeldung.');
  const r=await runChild(path.join(temp,'src/local-bot-full-run.mjs'),['--demo','--auto','--headless','--close-browser'],{cwd:temp,env:cleanEnv({MCR_RUN_ID:runId,MCR_DEMO_SCENARIO:scenario}),timeout:120000});
  const reportPath=path.join(temp,'diagnostics/last-result.json');need(fs.existsSync(reportPath),'DEMO_DIAGNOSTIC_MISSING','Demobericht fehlt.');
  const d=readJSON(reportPath);writeJSON(path.join(outDir(),'DEMO_'+scenario.toUpperCase().replace(/-/g,'_')+'_ERGEBNIS.json'),d);
  for(const n of fs.readdirSync(path.join(temp,'diagnostics')))if(n.endsWith('_UPLOAD.zip'))fs.copyFileSync(path.join(temp,'diagnostics',n),path.join(outDir(),n));
  need(r.code===0&&!r.signal&&d.runId===runId,'DEMO_FAILED','Demo ['+scenario+'] abgebrochen. Ergebnis pruefen.');
  if(scenario==='normal')certifyDemo(d);
  else if(scenario==='prefixed-member')certifyPrefixDemo(d);
  else if(scenario==='manual-name')certifyManualNameDemo(d);
  else certifyForwardDemo(d);
  proofs.push(scenario);
  log('PASS DEMO_'+scenario.toUpperCase().replace(/-/g,'_'));
 }
 const receipt={schema:'MCR_COMPLETE_DEMO_PASS_V2',version:VERSION,manifestSha256:pkg.manifestSha256,passedAt:new Date().toISOString(),scenarios:proofs,trustedMouseSends:2,trustedMouseSaves:2,trustedPrefixSends:2,trustedForwardsNoEmail:2};
 writeJSON(path.join(controlDir(root),'complete-demo-pass.json'),receipt);log('PASS DEMO_GESAMTPAKET_4_SCENARIOS');return receipt;
}

function demoPassed(pkg){const f=path.join(root,'.runtime/beta-control/complete-demo-pass.json');if(!fs.existsSync(f))return false;const d=readJSON(f);return d.schema==='MCR_COMPLETE_DEMO_PASS_V2'&&d.manifestSha256===pkg.manifestSha256&&d.trustedMouseSends===2&&d.trustedMouseSaves===2&&d.trustedPrefixSends===2&&d.trustedForwardsNoEmail===2&&JSON.stringify(d.scenarios)===JSON.stringify(['normal','prefixed-member','missing-member','manual-name']);}
async function status(target=root){const pkg=verifyPackage(target),state=runState(target);let map=null,error=null;try{const a=loadActiveMapping(target);map={valid:true,fileHash:a.fileHash,schema:a.map.schema,validKeys:a.map.payload.summary.validKeys};}catch(e){error=e.code||'MAPPING_ERROR';}const pending=fs.existsSync(path.join(target,'.runtime/beta-control/ticket-ledger.json'))?ledger(target).pending.length:0;const report={schema:'MCR_COMPLETE_STATUS_V1',package:pkg,mapping:map,mappingError:error,previousRun:state,unreviewedTickets:pending,liveReady:false,note:'Status alone does not authorize a send.'};writeJSON(path.join(outDir(),'STATUS.json'),report);log(JSON.stringify(report,null,2));return report;}
async function setup(){let target=defaultTarget();if(path.resolve(root)===path.resolve(target)){log('Bereits installierte Version. Selbsttests: Menue 6, fiktive Browserproben: Menue 2.');await status();return;}
 const input=await ask('Vorhandene Installation [ENTER = '+target+']: ');if(input)target=path.resolve(input.replace(/^"|"$/g,''));
 recoverOrphanedMigrationPriority(target,{verifyOld:verifyPrevious,log});
 let p=planInstall(root,target);
 if(p.old.legacyResiduals?.length){log('\nPASS BEKANNTE_BETA4_ALTDATEIEN_VERIFIZIERT: '+p.old.legacyResiduals.length);log('Diese Altdateien werden mit der bisherigen Software gesichert, nicht in den neuen Lauf uebernommen:');for(const f of p.old.legacyResiduals)log('  '+f.path);}
 log('\nZiel: '+target+'\nAlt: '+p.old.version+' -> '+VERSION+'\nNur Software wird archiviert/ersetzt. private_data, Config, Browserprofil und bisherige Laufdaten bleiben am Ort.\nEinrichtung versendet keine Nachrichten.');
 const migration=beginMigrationPriority(p,{log});
 try{
  // Freeze the data binding only AFTER the owned old execution has stopped.
  p=planInstall(root,target,{migration});
  // RC49 quick install: verifyPackage + planInstall + migration barrier +
  // independently verified rollback remain mandatory. Expensive 480+ tests
  // and four Chromium demos are explicitly available via Menu 6/2, not every
  // time the operator updates software. No claim of runtime pilot approval.
  log('SCHNELLINSTALLATION: Paket-Hash/Altversion verifiziert; Prozesssperre, Staging, Rueckweg und Datenbindung bleiben aktiv.');
  log('LANGTESTS: Menue 6 (Selbsttests), Menue 2 (fiktive Browserproben), NICHT bei jeder Installation.');
  migration.check();const r=installSoftware(p,{migration});
  log('PASS INSTALLATION_COMPLETE\nSicherung: '+r.archive);
  // No fabricated or stale demo receipt. Real pilot menus still require the version-bound demo proof.
 }finally{migration.release();}
 log('\nAb jetzt nur '+path.join(target,'START.cmd'));log('Das neue Hauptmenue der installierten Version wird geoeffnet.');
 await runChild(path.join(target,'tools/cli.mjs'),['--menu'],{cwd:target});return 'EXIT';
}
async function real(pilot,{automaticContinuation=false,limitAfterPilot=5,pilotRunId=null,initialDeliveryMode='MANUAL'}={}){need(process.platform==='win32','WINDOWS_REQUIRED','COMARCH-Echtlauf nur auf Windows.');const pkg=verifyPackage(root);need(fs.existsSync(path.join(root,'private_data')),'LIVE_FROM_DOWNLOAD_BLOCKED','Dieses Downloadpaket enthaelt keine produktiven Bestandsdaten. Echter Ticketlauf ausschliesslich aus der installierten MCR_Datenbruecke starten.');need(!fs.existsSync(path.join(root,'BETA_UMSTELLUNG_LAEUFT.txt')),'MIGRATION_INCOMPLETE','Softwareumstellung nicht abgeschlossen.');const active=loadActiveMapping(root);windowsIdle(root);const recovery=releaseProvenPreActionAbort(root);if(recovery.released)log('PASS AUTO_REVIEW_PRE_ACTION: Kein vom Bot begonnener Versand/keine Weiterleitung. Vorheriger Abbruch automatisch dokumentiert ('+recovery.phase+').');const fresh=prepareFreshRun(root,{guard:windowsIdle});if(fresh.oldRunClosed||fresh.lockReleased)log('PASS AUTO_CLOSE_OLD_RUN: Vergangener Bot-Lauf archiviert; keine alten Prozesse aktiv.');if(fresh.pending.length)log('PASS UNRESOLVED_TICKETS_EXCLUDED: '+fresh.pending.map(x=>x.ticketId).join(', ')+'. Diese Tickets erhalten KEINE automatische neue E-Mail.');assertNoReview(root);const journal=ledger(root);const previousPending=pendingSnapshot(root);log('ECHTLAUF_DIREKT: Keine fiktiven Demos. Freiwillige Browserproben ausschliesslich unter Menue 2.');
 if(!pilot){const f=path.join(root,'.runtime/beta-control/complete-pilot-pass.json');need(fs.existsSync(f),'PILOT_REQUIRED','Menue 4 bleibt gesperrt: Erst nach einem echt abgeschlossenen Piloten mit nachgewiesenem Versand UND Speicherung wird der reguläre Lauf freigegeben (Menue 3).');const p=readJSON(f);need(p.manifestSha256===pkg.manifestSha256&&p.mappingSha256===active.fileHash,'PILOT_REQUIRED','Die vorhandene Pilotfreigabe gehoert zu einer anderen Programm- oder Mapping-Version. Menue 3 erneut mit nachgewiesenem Versand UND Speicherung abschliessen.');}
 let limit=1;if(!pilot){if(automaticContinuation){
  limit=limitAfterPilot;
  const receipt=readJSON(path.join(root,'.runtime/beta-control/complete-pilot-pass.json'),65536);
  authorizeChainedContinuation({runId:pilotRunId,receipt,manifestSha:pkg.manifestSha256,mappingSha:active.fileHash,ticketLimit:limit});
  log('AUTO_FORTSETZUNG: Zertifizierter Pilot beendet; maximal 5 weitere Tickets unter derselben Menue-3-Freigabe.');
 }else{const s=await ask('Maximal wie viele Tickets (1 bis 100; ENTER=100): ');limit=s?Number(s):100;need(Number.isInteger(limit)&&limit>=1&&limit<=100,'TICKET_LIMIT','Ungueltiges Limit.');}}
 windowsIdle(root);const l=lock(root,'REAL_RUN'),dir=controlDir(root),runId=stamp(),sf=path.join(dir,'last-run.json'),state={schema:'MCR_BETA_RUN_V1',version:VERSION,operation:'REAL_RUN',state:'RUNNING',pid:process.pid,startedAt:new Date().toISOString(),runId,ticketDeliveryVerified:false,pilot};writeJSON(sf,state);
 const interrupt=()=>{state.state='INTERRUPTED_REVIEW_REQUIRED';try{writeJSON(sf,state);}catch{}};process.on('SIGINT',interrupt);process.on('SIGTERM',interrupt);
 try{
 const cfgForLog=resolveConfig(root);
 const reports=path.join(cfgForLog.runtimeDirectory,'reports');fs.mkdirSync(reports,{recursive:true});plainPath(reports);
 const day=new Date().toLocaleDateString('sv-SE');
 const transcript=path.join(reports,'MCR_ECHTLAUF_'+day+'.log');
 log('VOLLSTAENDIGES_LAUFPROTOKOLL: '+transcript+' (beide Pilot-/Folgelauf-Prozesse werden angehaengt)');
 const r=await runChild(path.join(root,'src/local-bot-full-run.mjs'),[pilot?'--pilot':'--full-run','--inspect-browser',...(automaticContinuation?['--chained-after-pilot']:[])],{logFile:transcript,env:cleanEnv({MCR_SESSION_TOKEN:l.token,MCR_RUN_ID:runId,MCR_MAX_TICKETS:String(limit),...(automaticContinuation?{MCR_CHAINED_PILOT_RUN_ID:pilotRunId,MCR_DELIVERY_MODE:initialDeliveryMode}:{})})});const cfg=resolveConfig(root),f=path.join(cfg.diagnosticDirectory,'last-result.json');need(fs.existsSync(f),'LIVE_DIAGNOSTIC_MISSING','Frischer Laufbericht fehlt.');const d=readJSON(f);need(d.runId===runId&&d.mode==='REAL','LIVE_DIAGNOSTIC_STALE','Bericht gehoert nicht zum aktuellen Lauf.');writeJSON(path.join(outDir(),'LETZTER_ECHTLAUF.json'),d);need(r.code===0&&!r.signal&&!d.lastError&&d.loop?.completed&&state.state==='RUNNING','LIVE_NOT_VERIFIED','Echtlauf nicht sauber bestaetigt. Verlauf pruefen; kein blinder Neustart.');assertPendingUnchanged(root,previousPending);state.state='RUNNER_EXIT_0';state.finishedAt=new Date().toISOString();state.processed=d.loop.processed;writeJSON(sf,state);
 if(pilot&&d.loop.processed===1&&d.loop.forwarded===1){certifyForwardWithoutEmail(d);log('PASS PILOT_ROUTED_WITHOUT_EMAIL - kein E-Mail-Pilotnachweis; regulärer Versand bleibt gesperrt.');}else if(pilot&&d.loop.processed===1){certifyPilot(d);writeJSON(path.join(dir,'complete-pilot-pass.json'),{schema:'MCR_COMPLETE_PILOT_PASS_V1',manifestSha256:pkg.manifestSha256,mappingSha256:active.fileHash,runId,passedAt:new Date().toISOString()});log('PASS LIVE_PILOT_SEND_AND_SAVE_VERIFIED | MENU_4_NOW_ENABLED');return {pilotVerified:true,runId,deliveryMode:d.deliveryMode==='AUTO'?'AUTO':'MANUAL'};}else if(pilot){log('Kein passendes Ticket vorhanden. Noch keine Pilotfreigabe.');return {pilotVerified:false};}else log('PASS LIVE_RUN_VERIFIED');
 }catch(e){if(state.state!=='INTERRUPTED_REVIEW_REQUIRED')state.state='STOP_REVIEW_REQUIRED';state.errorCode=/^[A-Z0-9_]+$/.test(e.code||'')?e.code:'RUN_ERROR';state.finishedAt=new Date().toISOString();writeJSON(sf,state);throw e;}
 finally{process.removeListener('SIGINT',interrupt);process.removeListener('SIGTERM',interrupt);try{l.release();}catch{}}
}
async function completionOnly(target,id){
 verifyPackage(target);loadActiveMapping(target);windowsIdle(target);
 prepareFreshRun(target,{guard:windowsIdle});assertNoReview(target);
 const before=pendingSnapshot(target);need(before.some(t=>t.ticketId===id&&t.kind==='SEND'),'REPAIR_PENDING_MISSING','Ticket ist kein offener Versand.');
 const l=lock(target,'REAL_RUN'),runId=stamp(),sf=path.join(controlDir(target),'last-run.json');
 let state={schema:'MCR_BETA_RUN_V1',version:VERSION,operation:'REAL_RUN',state:'RUNNING',pid:process.pid,startedAt:new Date().toISOString(),runId};writeJSON(sf,state);
 try{
  const cfg=resolveConfig(target),reports=path.join(cfg.runtimeDirectory,'reports');fs.mkdirSync(reports,{recursive:true});
  const r=await runChild(path.join(target,'src/local-bot-full-run.mjs'),['--complete-pending','--inspect-browser'],{cwd:target,logFile:path.join(reports,'MCR_ABSCHLUSS_OHNE_NEUVERSAND_'+runId+'.log'),env:cleanEnv({MCR_SESSION_TOKEN:l.token,MCR_RUN_ID:runId,MCR_MAX_TICKETS:'1',MCR_REPAIR_TICKET:id})});
  const d=readJSON(path.join(cfg.diagnosticDirectory,'last-result.json'));
  need(r.code===0&&!r.signal&&d.runId===runId&&!d.lastError&&d.completionOnly?.id===id&&d.completionOnly?.status==='COMPLETE'&&d.send?.clicked===false,'REPAIR_NOT_VERIFIED','Nachbearbeitung nicht bestaetigt. Kein Neuversand.');
  assertPendingUnchanged(target,before.filter(t=>t.ticketId!==id));state.state='RUNNER_EXIT_0';
  log('PASS ABSCHLUSS_OHNE_NEUVERSAND: '+id+'; andere offene Tickets unveraendert.');
 }catch(e){state.state='STOP_REVIEW_REQUIRED';state.errorCode=e.code||'ERROR';throw e;}
 finally{state.finishedAt=new Date().toISOString();writeJSON(sf,state);l.release();}
}
async function review(target=root){plainPath(target);const dir=controlDir(target),lf=path.join(dir,'operation.lock.json'),sf=path.join(dir,'last-run.json');windowsIdle(target);const recovery=releaseProvenPreActionAbort(target);if(recovery.released){log('PASS AUTO_REVIEW_PRE_ACTION: Kein Bot-Versand oder -Weiterleitungsversuch begonnen. Keine manuelle SICHER_KEIN_VERSAND-Bestaetigung notwendig.');return;}if(fs.existsSync(lf))need(!processAlive(readJSON(lf).pid),'OPERATION_ALIVE','Sperrbesitzer laeuft noch.');const j=ledger(target);log('Vorheriger Lauf: '+JSON.stringify(runState(target)));log('Offene Sende-/Weiterleitungsabsichten: '+j.pending.length);log('Nur lokale Anzeige offener Tickets:');for(const t of j.pending)log('Ticket '+t.ticketId+' | '+t.state);
 if(j.pending.some(t=>t.kind==='SEND')){
  log('NEU: Einzelnes bereits versendetes Ticket abschliessen, OHNE neue E-Mail. Empfohlen fuer SEND_UNVERIFIED.');
  const chosen=await ask('Ticket-ID fuer Status-/Speichernachtrag (z.B. 88149870), ENTER = bisherige manuelle Pruefung: ');
  if(chosen){need(/^\d{6,12}$/.test(chosen),'REPAIR_TICKET_ID','Genau eine Ticketnummer.');return completionOnly(target,chosen);}
 }
 const pendingKinds=[...new Set(j.pending.map(p=>p.kind==='FORWARD'?'FORWARD':'SEND'))];need(pendingKinds.length<=1,'REVIEW_MIXED_ACTIONS','Gemischte offene Sendungen und Weiterleitungen muessen einzeln extern geklaert werden.');const forwarding=pendingKinds[0]==='FORWARD';
 log('\nCOMARCH manuell pruefen. Weitergeleitet ist NICHT gleich gesendet. Bei Unsicherheit abbrechen.');
 const prompt=forwarding?'WEITERGELEITET_GEPRUEFT oder SICHER_NICHT_WEITERGELEITET; sonst ENTER: ':'SICHER_KEIN_VERSAND oder VERSAND_UND_SPEICHERUNG_GEPRUEFT; sonst ENTER: ';
 const answer=await ask(prompt);const allowed=forwarding?['WEITERGELEITET_GEPRUEFT','SICHER_NICHT_WEITERGELEITET']:['SICHER_KEIN_VERSAND','VERSAND_UND_SPEICHERUNG_GEPRUEFT'];if(!allowed.includes(answer)){log('Sperre bleibt bestehen.');return;}
 windowsIdle(target);if(fs.existsSync(lf)){const old=readJSON(lf);need(!processAlive(old.pid),'OPERATION_ALIVE','Sperrbesitzer aktiv.');const a=path.join(dir,'lock_archive');fs.mkdirSync(a,{recursive:true});plainPath(a);fs.copyFileSync(lf,path.join(a,'review_'+stamp()+'.json'),fs.constants.COPYFILE_EXCL);fs.unlinkSync(lf);}
 j.review(forwarding?(answer==='WEITERGELEITET_GEPRUEFT'?'OPERATOR_CONFIRMED_ROUTED':'OPERATOR_CONFIRMED_NOT_ROUTED_RETRY_ALLOWED'):(answer==='SICHER_KEIN_VERSAND'?'OPERATOR_CONFIRMED_NO_SEND_RETRY_ALLOWED':'OPERATOR_CONFIRMED_SENT_SAVED'));if(fs.existsSync(sf)){const old=readJSON(sf);writeJSON(path.join(dir,'review_'+stamp()+'.json'),old);writeJSON(sf,{...old,state:'OPERATOR_REVIEWED_NOT_RETRIED',reviewedAt:new Date().toISOString(),ticketDeliveryVerified:false});}log('Pruefentscheidung dokumentiert. Keine Nachricht versendet.');
}
async function rollback(){const input=await ask('Ziel der Wiederherstellung [ENTER = '+defaultTarget()+']: '),target=input?path.resolve(input.replace(/^"|"$/g,'')):defaultTarget();recoverOrphanedMigrationPriority(target,{forRollback:true,verifyOld:verifyPrevious,log});windowsIdle(target);const all=journals(target);need(all.length,'NO_ROLLBACK','Kein passendes Gesamtpaket-Archiv gefunden.');const j=all[0];log('Software-Rueckweg: '+j.archive+'\nKeine Tickets, Nachrichten oder Daten werden rueckgaengig gemacht.');need((await ask('ZURUECK: ')).toUpperCase()==='ZURUECK','ROLLBACK_ABORT','Keine Freigabe.');const l=lock(target,'ROLLBACK');try{restoreSoftware(j);log('PASS SOFTWARE_RESTORED');}finally{l.release();}}
async function mappingMaintenance(){verifyPackage(root);loadActiveMapping(root);assertNoReview(root);ledger(root).assertClear();windowsIdle(root);need((await ask('Mappingwartung ist fuer die Reparatur NICHT erforderlich. Fortfahren? WARTUNG: ')).toUpperCase()==='WARTUNG','ABORT','Keine Mappingwartung.');const l=lock(root,'REAL_RUN');try{const r=await runChild(path.join(root,'src/export-multirow.mjs'),[],{env:cleanEnv({MCR_SESSION_TOKEN:l.token})});need(r.code===0&&!r.signal,'MAPPING_MAINTENANCE_FAILED','Mappingwartung nicht abgeschlossen. Aktivierungszeiger vor Ticketlauf pruefen.');}finally{l.release();}}
async function menu(){for(;;){log('\n==============================================================\n MCR DATENBRUECKE '+VERSION+'\n==============================================================\n 1  Schnellinstallation / aktualisieren (kein Echtversand)\n 2  Vier fiktive Szenarien (je 2 Tickets)\n 3  Ein Pilot, danach automatisch bis zu 5 weitere Tickets bei PASS\n 4  Regulaerer Ticketlauf (erst nach erfolgreichem Piloten)\n 5  Vorherigen Lauf pruefen / Wiederanlauf freigeben\n 6  Status und Selbsttests\n 7  Software-Rueckweg (Bestandsdaten bleiben erhalten)\n 8  Mappingwartung (nicht fuer die Reparatur erforderlich)\n 9  PHASE 2: COMARCH-Kontoauszug-Inventur (nur lesen)\n10  PHASE 2: Generatoren pruefen (nicht starten)\n11  PHASE 2: Kontoauszug-PDF-Pilot (Generatoren manuell)\n12  PHASE 2: Bearbeiten und weiterleiten, danach naechstes Ticket\n 0  Beenden');try{const a=await ask('Auswahl: ');if(a==='0')return;assertNoMigrationPriority(root);if(a==='1'){if(await setup()==='EXIT')return;}else if(a==='2')await demo();else if(a==='3'){
 const result=await real(true);
 if(result?.pilotVerified){
  log('PASS PILOT -> FORTSETZUNG: Das naechste Ticket wird automatisch gesucht. Keine erneute Antwort an das Pilotticket.');
  // A new guarded process and owned Edge instance are started ONLY AFTER
  // an independent sent-and-saved pilot receipt has been sealed.
  await new Promise(r=>setTimeout(r,850));
  await real(false,{automaticContinuation:true,limitAfterPilot:5,pilotRunId:result.runId,initialDeliveryMode:result.deliveryMode});
 }
}else if(a==='4')await real(false);else if(a==='5'){let t=root;if(!fs.existsSync(path.join(root,'private_data'))){const s=await ask('Vorhandener Bot-Ordner [ENTER = '+defaultTarget()+']: ');t=s?path.resolve(s.replace(/^"|"$/g,'')):defaultTarget();}await review(t);}else if(a==='6'){await status();await selftest();}else if(a==='7')await rollback();else if(a==='8')await mappingMaintenance();else if(a==='9'){windowsIdle(root);const l=lock(root,'PHASE2_READONLY');try{await inventoryLive({root});}finally{l.release();}}else if(a==='10')generatorPreflight({root});else if(a==='11'){windowsIdle(root);const l=lock(root,'PHASE2_MANUAL_PDF');try{await manualPdfPilot({root});}finally{l.release();}}else if(a==='12'){windowsIdle(root);const l=lock(root,'PHASE2_COMARCH_PILOT');try{await phase2Run({root});}finally{l.release();}}else log('Bitte 0 bis 12 waehlen.');}catch(e){console.error('STOP '+(e.code||'ERROR')+': '+e.message);if(e.rollback)log('Rueckweg: '+e.rollback); }await ask('\nENTER zum Hauptmenue: ');}}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){try{const [major,minor]=process.versions.node.split('.').map(Number);need(major>22||major===22&&minor>=15,'NODE_VERSION','Vorhandenes Node.js ab 22.15 erforderlich.');assertNoMigrationPriority(root);verifyPackage(root);const action=process.argv[2]||'--menu';if(action==='--selftest')await selftest();else if(action==='--demo')await demo();else if(action==='--status')await status();else if(action==='--menu')await menu();else need(false,'ARGUMENT','Nur --menu, --status, --selftest, --demo erlaubt.');}catch(e){console.error('STOP '+(e.code||'ERROR')+': '+e.message);process.exitCode=1;}}
