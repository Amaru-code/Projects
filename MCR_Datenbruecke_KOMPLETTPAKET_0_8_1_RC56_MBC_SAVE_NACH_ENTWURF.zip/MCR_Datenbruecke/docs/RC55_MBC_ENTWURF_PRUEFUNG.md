# RC55 – MBC-Entwurfsentscheidung und sichere Fortsetzung

## Beobachtung
Im RC54-Lauf wurde Ticket 87160524 als MBC_PRIVATE_EMAIL geöffnet. Danach
P2_MBC_EXISTING_DRAFT. Der Quellcode stoppt, wenn der sichtbare Editor nicht
leer oder nicht textgleich mit dem MBC-Sollentwurf ist. Das Protokoll enthält
keinen Entwurfstext. Ob der Inhalt Signatur, Vorlage oder manueller Entwurf ist,
ist daher NICHT festgestellt. Keine dieser Kategorien wird pauschal gelöscht.

## Umsetzung
* Nur MBC verwendet den neuen Adapter. Der Phase-1-Editor bleibt bytegleich.
* Sichtbares Editor-HTML und CKEditor-Textarea werden zusammen gelesen.
  Blockelemente/HTML-Entities werden für den Textvergleich berücksichtigt.
  Nichttext-Elemente (z. B. Signaturbild) sind kein leeres Feld.
* Identischer MBC-Inhalt wird ohne Ersetzung verwendet. Formatierung bleibt.
* Abweichender Inhalt: lokale JSON-Sicherung mit beiden ursprünglichen HTML-
  Strings, Ticketnummer und SHA-256; vor dem Schreiben zurückgelesen.
* MBC-Text einsetzen ist ausdrücklich **Ersetzen**, nicht Anhängen. Ein alter
  Text einschließlich Signatur wird dabei durch den vollständigen vorgegebenen
  MBC-Text ersetzt; der alte HTML-Stand bleibt in der lokalen Sicherung.
* Manueller Knopf auch bei AUTO; keine allgemeine Überschreibfreigabe.
* Unverändert lassen überspringt das Ticket ohne neues Aktionsjournal, GEVO-
  Änderung, Speicherung, Versand oder Weiterleitung. Der nächste zulässige Fall
  wird gesucht; das übersprungene Ticket erhält keine Erfolgsanimation.
* Vor Ersetzung: Ticketbindung, Sicherungs-Hash und unveränderte Roh-HTML-
  Momentaufnahme erneut prüfen. Vergleich + Mutation in derselben Browser-
  Auswertung. Zwischenzeitlich geänderte Texte werden nicht überschrieben.
* Schreibabsicht vor Editoränderung im vorhandenen Journal. Unsichere spätere
  Speichervorgänge bleiben gesperrt; kein allgemeiner Journalreset/Retry.
* Sichtbarer Editor und Quell-Textarea werden synchronisiert. Entwurf und GEVO
  werden wie bisher gespeichert, erneut geöffnet und geprüft, bevor Mark
  Baindl als Prüfer ausgewählt und der bestehende Abschlussschritt freigegeben wird.

## Bedienung
Neues ZIP separat entpacken; START.cmd, Menü 1, bestehendes Ziel übernehmen.
Dann installierte START.cmd, Menü 12. Startticket 87160524 oder leer lassen.
Bei einer Entwurfsentscheidung vorhandenen Text im Bot-Edge prüfen und wählen:
MBC-Text einsetzen / Unverändert lassen. Ohne Fenster: ERSETZEN 87160524 oder
UEBERSPRINGEN. STOP/ABBRUCH beendet den Lauf ohne Ersetzungsfreigabe.

## Unverändert
Schnellinstallation, Migration, PDFs, DB-Vorrang, MBC-Antwortwortlaut,
Prüferfelder, Versandverbot in Phase 2 und offene Phase-1-Journale.
Die bestehende Empfängerfreigabe gilt unabhängig von der Entwurfsentscheidung.

## Prüfgrenzen
Tests verwenden Chromium mit nachgebildetem COMARCH-DOM und modellierter
Speicher-/Weiterleitungsreaktion. Kein Zugriff auf die produktive COMARCH-
Instanz. Native Windows-Fenster/PowerShell-Kompilierung hier nicht ausführbar.
Der erste produktive RC55-MBC-Lauf bleibt zu bestätigen.
