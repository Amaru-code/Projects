# RC56 – MBC-Entwurf, Ticketbeschreibung und kontrollierte Weiterleitung

## Originalfehler (RC55, Ticket 87160524)
- MBC-Editor befüllt; Entwurf-Speichern-Klick ausgelöst.
- `DESCRIPTION_NATIVE_INPUT_AND_BLUR` vor Entwurf-Speichern ist keine serverseitige Persistenzgarantie.
- Manuelle Ticket-Speichern-Bestätigung, danach nur `NETWORK_QUIET`.
- `P2_WORK_SERVER_DESCRIPTION`: der erwartete vollständige Beschreibungstext war in der neu gelesenen eigenen Vorgangsliste nicht vorhanden.
- Keine Überprüfungszuweisung/Schritt-ausführen-Aktion; die Ursache ist vorher gelagert.

## Änderungen
- `Anfrage Member` wie zuvor vor dem Entwurf wählen; **MBC-Entwurf speichern**, *danach* COMARCH-Editor neu binden, GEVO nochmals prüfen/gegebenenfalls erneut wählen und Zusatzbeschreibung setzen, mit nativer Texteingabe und Blur.
- Den benutzten Formularzustand unmittelbar vor dem Ticket-Speichern erneut verifizieren, einschließlich Entwurf.
- Einen einzelnen Speicherklick beobachten und anschließend die Liste und dasselbe frisch geöffnete Ticket getrennt lesen. Eine nackte Netzwerkantwort, ein sichtbarer alter Feldwert oder ein manuell bestätigter Klick ist **kein** Servernachweis.
- Sichtbare Diskrepanz zwischen Listen-Textarea und neu geöffnetem Ticket wird gemeldet; ein dauerhaft gespeicherter Text im frischen Ticket wird nicht erneut überschrieben.
- Das alte RC55-Ticketjournal wird weder zurückgesetzt noch automatisch wiederholt: Bei einem offenen `TICKET_SAVE_INTENT` den unveränderten MBC-Entwurf lesen und entweder bereits gespeicherte Serverwerte akzeptieren oder nur nach ausdrücklicher Bestätigung genau einen Reparaturversuch erlauben.
- Keine erneute Draft-Edit-Aktion bei Wiederanlauf; keine neue E-Mail in Phase 2, keine Doppelweiterleitung.
- Bereits erfolgreiche Prüferauswahl und „Schritt ausführen“ bleiben bytegleich (lib/phase2-review-flow.mjs und lib/phase2-assignee.mjs).

## Bedienung
1. Neue RC56 separat entpacken; Menü 1 auf vorhandene Installation.
2. Menü 12, Startticket **87160524** und `START`.
3. Falls `NICHT_GESPEICHERT_87160524` abgefragt wird, NUR nach Prüfung von tatsächlichem gespeicherten COMARCH-Ticket, MBC-Entwurf, Original-/Sollbeschreibung und noch ausstehender Weiterleitung bestätigen.
4. Bei erfolgreicher erneuter Serverprüfung wird der bereits bewährte Weg `FORWARD_TO_REVIEW` → `next-persona-assignment-id` = `Baindl Mark (mark.baindl)` → „Schritt ausführen“ aufgerufen. Im manuellen Modus Freigabeknopf benutzen; AUTO gilt nur nach bewusstem Umschalten.

## QA-Grenzen
Chromium-Browsertests mit nachgebildetem ICEfaces-Formular und modellierter Backend-Persistenz, darunter Reset von GEVO/Beschreibung nach Entwurf-Speichern, altes RC55-Journal, falsch bestätigter Speicherklick und widersprechende Daten. Keine COMARCH-Live-Verbindung und keine nativen Windows-Fenstertests in dieser Umgebung. Ein fehlender Servernachweis bleibt ein Stop und kein Erfolg.
