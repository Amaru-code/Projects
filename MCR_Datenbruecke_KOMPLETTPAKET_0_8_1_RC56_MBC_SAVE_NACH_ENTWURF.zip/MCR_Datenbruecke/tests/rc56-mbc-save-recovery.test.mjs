import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {temp,mapping} from './helpers.mjs';
import {withPhase2Browser,installPhase2Fixture} from './rc52-browser-fixture.mjs';
import {handlePhase2Work} from '../src/phase2-work-handler.mjs';
import {phase2WorkJournal} from '../lib/phase2-work-journal.mjs';
import {privateMbcDraft,PRIVATE_MBC_REQUEST,markedPhase2Description} from '../lib/phase2-work-rules.mjs';
import {readPhase2Queue} from '../lib/phase2-readonly.mjs';
const id='87160524',original='USC 100/ DC\nStandardantwort versendet\n'+PRIVATE_MBC_REQUEST,after=markedPhase2Description(original),draft=privateMbcDraft({lastName:'Mustermann',gender:'M'});
const member=async()=>({profileVerified:true,profile:{first:'Max',last:'Mustermann',mercerId:'99900001'}});
const deny=async prompt=>{throw Error('Unsolicited prompt: '+prompt);};
const row={ticketId:id,descriptionValue:original};
function priorJournal(root){const j=phase2WorkJournal(root,id);j.begin({rule:'MBC_PRIVATE_EMAIL',descriptionBefore:original,descriptionAfter:after,draft,memberId:'99900001'});
 for(const state of ['EDIT_INTENT','EDIT_VERIFIED','DRAFT_SAVE_INTENT','DRAFT_SAVE_VERIFIED','TICKET_SAVE_INTENT'])j.advance(state);
 j.observe('TICKET_SAVE_MANUAL_CLICK_INTENT');j.observe('TICKET_SAVE_NETWORK_OBSERVED',{status:'NETWORK_QUIET',writeStarts:0});return j;}
async function fixture(page,{description=original,gevo='',savedDraft='',draftReset=false,saveSwallow=false}={}){
 await installPhase2Fixture(page,[{ticketId:id,description,gevo,draft:savedDraft}]);
 if(draftReset||saveSwallow)await page.call(({draftReset,saveSwallow})=>{
  const show=window.showDetail;window.showDetail=id=>{
   show(id);
   if(draftReset){const link=document.getElementById('mainForm:j_id6190'),orig=link.onclick;
    link.onclick=e=>{orig(e);if(e.isTrusted){document.getElementById('additional').value=_server.find(x=>x.ticketId===id).description;
     document.getElementById('mainForm:gevo-value-id').value='';_order.push('ICE_RESET_AFTER_DRAFT');}};}
   if(saveSwallow){const link=document.getElementById('save-ticket');link.onclick=e=>{e.preventDefault();if(e.isTrusted){_counts.save++;_order.push('SAVE_CLICK_BUT_UNPERSISTED');}};}
  };
 },{draftReset,saveSwallow});
}
test('RC56 Chromium: partial ICEfaces update resets GEVO and description on draft save; both are committed AFTER draft and single ticket save precedes review',{timeout:48000},()=>withPhase2Browser(async page=>{
 const root=temp();try{await fixture(page,{draftReset:true});const logs=[];
  const result=await handlePhase2Work({root,page,row,mapping:mapping(),memberLookup:member,ask:deny,log:x=>logs.push(x)});
  assert.equal(result.status,'ROUTED_VERIFIED');assert.equal(await page.eval('_server[0].description'),after);assert.equal(await page.eval('_server[0].gevo'),'Anfrage Member');
  const order=await page.eval('_order');assert(order.indexOf('ICE_RESET_AFTER_DRAFT')<order.lastIndexOf('suggestion:mainForm:gevo-value-id'));
  assert(order.indexOf('draft')<order.indexOf('save')&&order.indexOf('save')<order.indexOf('review'));
  assert.deepEqual(await page.eval('_counts'),{open:2,save:1,draft:1,review:1,direct:0,send:0,upload:0});
  assert(logs.some(x=>x.includes('P2_RC56_DRAFT_FIRST')));
  assert.equal(phase2WorkJournal(root,id).read().state,'ROUTED_VERIFIED');
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));
test('RC56 Chromium: original RC55 TICKET_SAVE_INTENT; saved MBC draft is preserved and only the missing ticket save is authorized once',{timeout:48000},()=>withPhase2Browser(async page=>{
 const root=temp();try{const j=priorJournal(root),originalEvents=j.read().events;
  await fixture(page,{savedDraft:draft});const asks=[];
  const result=await handlePhase2Work({root,page,row,mapping:mapping(),memberLookup:()=>{throw Error('no new member lookup');},ask:async q=>{asks.push(q);assert(q.includes('NICHT_GESPEICHERT_'+id));return 'NICHT_GESPEICHERT_'+id;},log:()=>{}});
  assert.equal(result.status,'ROUTED_VERIFIED');assert.equal(asks.length,1);assert.deepEqual(j.read().events.slice(0,originalEvents.length),originalEvents);
  assert.equal(await page.eval('_counts.draft'),0);assert.equal(await page.eval('_counts.save'),1);assert.equal(await page.eval('_counts.review'),1);assert.equal(await page.eval('_counts.send'),0);
  assert.equal(await page.eval('_server[0].draft'),draft);assert.equal(j.read().events.filter(x=>x.state==='SAVE_REPAIR_AUTHORIZED').length,1);
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));
test('RC56 Chromium: previous save already persisted, stale queue record cannot trigger a second save or draft write',{timeout:35000},()=>withPhase2Browser(async page=>{
 const root=temp();try{const j=priorJournal(root);await fixture(page,{description:after,gevo:'Anfrage Member',savedDraft:draft});
  const result=await handlePhase2Work({root,page,row,mapping:mapping(),memberLookup:member,ask:deny,log:()=>{}});
  assert.equal(result.status,'ROUTED_VERIFIED');assert.equal(await page.eval('_counts.save'),0);assert.equal(await page.eval('_counts.draft'),0);assert.equal(await page.eval('_counts.review'),1);
  assert.equal(j.read().events.filter(x=>x.state==='SAVE_REPAIR_AUTHORIZED').length,0);
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));
test('RC56 Chromium: a clicked but unsaved Ticket speichern is not proof; no Mark routing and journal stays open',{timeout:34000},()=>withPhase2Browser(async page=>{
 const root=temp();try{await fixture(page,{saveSwallow:true});
  await assert.rejects(()=>handlePhase2Work({root,page,row,mapping:mapping(),memberLookup:member,ask:deny,log:()=>{}}),e=>e.code==='P2_WORK_SERVER_DESCRIPTION');
  assert.equal(await page.eval('_counts.save'),1);assert.equal(await page.eval('_counts.review'),0);assert.equal(await page.eval('_server[0].description'),original);
  assert.equal(phase2WorkJournal(root,id).read().state,'TICKET_SAVE_INTENT');
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));
test('RC56 Chromium: unexpected server description or changed existing MBC draft blocks repair before any writes',{timeout:35000},()=>withPhase2Browser(async page=>{
 const root=temp();try{const j=priorJournal(root);await fixture(page,{description:'Fremde Bearbeitung',savedDraft:draft});
  await assert.rejects(()=>handlePhase2Work({root,page,row,mapping:mapping(),memberLookup:member,ask:deny,log:()=>{}}),e=>e.code==='P2_WORK_READBACK_CONFLICT');
  assert.equal(await page.eval('_counts.save+_counts.draft+_counts.review'),0);assert.equal(j.read().state,'TICKET_SAVE_INTENT');
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));
test('RC56 Chromium: interruption just AFTER MBC draft save resumes without a second draft or prior Ticket Save click',{timeout:44000},()=>withPhase2Browser(async page=>{
 const root=temp();try{
  const j=phase2WorkJournal(root,id);j.begin({rule:'MBC_PRIVATE_EMAIL',descriptionBefore:original,descriptionAfter:after,draft,memberId:'99900001'});
  for(const s of ['EDIT_INTENT','DRAFT_SAVE_INTENT','DRAFT_SAVE_VERIFIED'])j.advance(s);
  await fixture(page,{savedDraft:draft});const result=await handlePhase2Work({root,page,row,mapping:mapping(),memberLookup:member,ask:deny,log:()=>{}});
  assert.equal(result.status,'ROUTED_VERIFIED');assert.equal(await page.eval('_counts.draft'),0);assert.equal(await page.eval('_counts.save'),1);
  assert.equal(await page.eval('_counts.review'),1);assert.equal(j.read().events.filter(x=>x.state==='POST_DRAFT_RESUME_VERIFIED').length,1);
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));
test('RC56 Chromium: already persisted ticket fields after draft blur allow zero save clicks but exactly one review',{timeout:34000},()=>withPhase2Browser(async page=>{
 const root=temp();try{
  const j=phase2WorkJournal(root,id);j.begin({rule:'MBC_PRIVATE_EMAIL',descriptionBefore:original,descriptionAfter:after,draft,memberId:'99900001'});
  for(const s of ['EDIT_INTENT','DRAFT_SAVE_INTENT','DRAFT_SAVE_VERIFIED'])j.advance(s);
  await fixture(page,{description:after,gevo:'Anfrage Member',savedDraft:draft});
  const result=await handlePhase2Work({root,page,row,mapping:mapping(),memberLookup:member,ask:deny,log:()=>{}});
  assert.equal(result.status,'ROUTED_VERIFIED');assert.equal(await page.eval('_counts.save'),0);assert.equal(await page.eval('_counts.draft'),0);
  assert.equal(await page.eval('_counts.review'),1);assert(j.read().events.some(x=>x.state==='SERVER_PERSISTED_NO_TICKET_CLICK'));
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));
