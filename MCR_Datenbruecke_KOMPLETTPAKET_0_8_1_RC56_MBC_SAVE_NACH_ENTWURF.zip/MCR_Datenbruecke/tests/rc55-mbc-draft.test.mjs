import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';
import {temp} from './helpers.mjs';
import {classifyMbcDraft,backupMbcDraft} from '../lib/phase2-mbc-draft.mjs';
import {DeliveryGate,createDeliveryConsole} from '../lib/delivery-console.mjs';
import {createPhase2TicketConsole} from '../lib/phase2-ticket-console.mjs';
import {sha256} from '../lib/core.mjs';
const id='87160524',draft='Sehr geehrter Herr Mustermann,\n\nvielen Dank für Ihre Nachricht.';
const snap=(visual='',source='')=>({schema:'MCR_MBC_EDITOR_SNAPSHOT_V1',ticketId:id,editor:{id:'editor',html:visual,text:visual,assets:false},source:{id:'mainForm:emailMessageBodyRichEditor',html:source,text:source,assets:false}});
const msg=(event,more={})=>({schema:'MCR_CONTROL_V1',event,...more});
test('RC55 recognizes empty/equivalent MBC text but never guesses a signature or hidden content disposable',()=>{
 assert.equal(classifyMbcDraft(snap(),draft),'EMPTY');
 assert.equal(classifyMbcDraft(snap(draft,draft.replaceAll('\n',' ')),draft),'MATCH');
 assert.equal(classifyMbcDraft(snap(draft,''),draft),'MATCH');
 for(const s of [snap('Mit freundlichen Grüßen\nMercer',''),snap('', 'Wichtiger fremder Entwurf'),snap(draft,'Anderer Text'),snap('', '')]){
  if(!s.editor.text&&!s.source.text)s.editor.assets=true;
  assert.equal(classifyMbcDraft(s,draft),'REVIEW_REQUIRED');
 }
});
test('RC55 local backup preserves source+visual HTML byte strings with hash and ticket binding',()=>{
 const root=temp();try{
  const s=snap('<p>Entwurf &amp; Grüße</p>','<div>Andere Quelle\r\n&nbsp;</div>');const backup=backupMbcDraft(root,s);
  assert.equal(sha256(fs.readFileSync(backup.file)),backup.sha256);
  const body=JSON.parse(fs.readFileSync(backup.file,'utf8'));assert.deepEqual(body.snapshot,s);assert.equal(body.snapshotSha256,sha256(JSON.stringify(s)));
  assert(backup.relativeFile.startsWith('.runtime/phase2/draft-backups/'));assert.equal(body.ticketId,id);
  assert.notEqual(backupMbcDraft(root,s).file,backup.file);
  assert.throws(()=>backupMbcDraft(root,{...s,ticketId:'../other'}));
 }finally{fs.rmSync(root,{recursive:true,force:true});}
});
test('RC55 backup refuses a symlink parent instead of writing outside the installation',{skip:process.platform==='win32'},()=>{
 const root=temp(),other=temp();try{fs.symlinkSync(other,path.join(root,'.runtime'),'dir');assert.throws(()=>backupMbcDraft(root,snap()),e=>e.code==='LINK_BLOCKED');assert.deepEqual(fs.readdirSync(other),[]);}finally{fs.rmSync(root,{recursive:true,force:true});fs.rmSync(other,{recursive:true,force:true});}
});
test('RC55 AUTO never authorizes draft replacement; skip is ticket/challenge bound and one use',()=>{
 const g=new DeliveryGate('AUTO'),r=g.request(id,{manualOnly:true,action:'REPLACE_MBC_DRAFT',allowSkip:true});assert.equal(g.lease(),null);
 assert(!g.accept(msg('skip',{ticket:'87160525',challenge:r.challenge})));assert(!g.accept(msg('skip',{ticket:id,challenge:'wrong'})));
 assert(g.accept(msg('skip',r)));const lease=g.lease();assert.equal(lease.decision,'SKIP');g.consume(lease);assert.throws(()=>g.consume(lease));
 g.request('87160525',{action:'FORWARD_REVIEW'});assert(!g.accept(msg('skip',r)));assert(g.lease());
});
test('RC55 skip is not offered for send/routing, and switching choice invalidates prior lease',()=>{
 const g=new DeliveryGate();assert.throws(()=>g.request(id,{action:'SEND',allowSkip:true,manualOnly:true}));
 const r=g.request(id,{action:'REPLACE_MBC_DRAFT',allowSkip:true,manualOnly:true});g.accept(msg('skip',r));const skipped=g.lease();g.accept(msg('approve',r));assert.throws(()=>g.consume(skipped));assert(!g.lease().decision);g.consume(g.lease());
});
test('RC55 terminal fallback requires ERSETZEN plus exact ticket, or explicit skip; AUTO alone is refused',async()=>{
 const x=createDeliveryConsole({platform:'linux'});
 const opt={ticketId:id,action:'REPLACE_MBC_DRAFT',manualOnly:true,allowSkip:true};
 await assert.rejects(()=>x.authorize({...opt,ask:async()=> 'AUTO'}));
 await assert.rejects(()=>x.authorize({...opt,ask:async()=> 'ERSETZEN 87160525'}));
 const l=await x.authorize({...opt,ask:async q=>{assert(q.includes('ERSETZEN '+id));return 'UEBERSPRINGEN';}});assert.equal(l.decision,'SKIP');await x.commitAuthorization(l);x.close();
});
test('RC55 Phase2 controller exposes a separate draft decision without consuming routing approval',async()=>{
 const c=createPhase2TicketConsole({platform:'linux'});c.start({ticketId:id,kind:'MBC_PRIVATE_EMAIL',description:'USC 1/ DC'});
 assert.equal(await c.reviewDraft({ticketId:id,ask:async()=> 'ERSETZEN '+id}),'REPLACE');assert.equal(c.gate.lease(),null);
 await assert.rejects(()=>c.authorize({ticketId:id,route:'REVIEW',ask:async()=> ''}));
 c.gate.accept(msg('abort'));assert.throws(()=>c.assertActive(),e=>e.code==='OPERATOR_ABORT');c.close();
});
