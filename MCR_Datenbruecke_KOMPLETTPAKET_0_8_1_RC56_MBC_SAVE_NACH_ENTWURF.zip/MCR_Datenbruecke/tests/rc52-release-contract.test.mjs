import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';
import {ROOT} from './helpers.mjs';import {VERSION} from '../lib/control.mjs';import {sha256} from '../lib/core.mjs';import {verifyPackage} from '../tools/integrity.mjs';
test('RC52 exact published RC51 manifest pinned; all shipped source bytes sealed, no private runtime/ZIP payload',()=>{
 assert.match(VERSION,/^0\.8\.1-rc\.\d+$/);assert.equal(sha256(fs.readFileSync(path.join(ROOT,'tools/reference/complete-0.8.1-rc.51-manifest.json'))),'564af25ee98c178143ba962a2e7efe0a41aca5dd9d7b131b6329e738ed86b74c');
 assert.equal(verifyPackage(ROOT).version,VERSION);
 const m=JSON.parse(fs.readFileSync(path.join(ROOT,'MANIFEST.json')));
 for(const f of ['lib/phase2-navigation.mjs','lib/phase2-review-flow.mjs','lib/phase2-work-rules.mjs','lib/phase2-work-journal.mjs','src/phase2-run.mjs','src/phase2-work-handler.mjs','tests/rc52-flow-browser.test.mjs','tests/rc52-rules-and-journal.test.mjs','tests/rc52-upgrade.test.mjs'])assert(m.payload.some(x=>x.path===f),f);
 assert(m.payload.every(x=>!/^private_data\/|^\.runtime\/|\.zip$/i.test(x.path)));
});
test('RC52 preserves RC48 two-file chooser byte-for-byte; quick install remains separate from full QA',()=>{
 const original=JSON.parse(fs.readFileSync(path.join(ROOT,'tools/reference/complete-0.8.1-rc.51-manifest.json')));
 for(const file of ['lib/phase2-filepond.mjs','tools/deploy.mjs','lib/migration-priority.mjs'])assert.equal(sha256(fs.readFileSync(path.join(ROOT,file))),original.payload.find(x=>x.path===file).sha256,file);
 const cli=fs.readFileSync(path.join(ROOT,'tools/cli.mjs'),'utf8'),setup=cli.slice(cli.indexOf('async function setup()'),cli.indexOf('async function real('));
 assert(!setup.includes('await selftest()'));assert(!setup.includes('await demo()'));assert(cli.includes('await phase2Run({root})'));
});
