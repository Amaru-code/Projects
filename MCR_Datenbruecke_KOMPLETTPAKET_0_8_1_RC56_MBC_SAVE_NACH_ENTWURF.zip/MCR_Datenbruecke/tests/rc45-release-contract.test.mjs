import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {ROOT} from './helpers.mjs';
import {sha256} from '../lib/core.mjs';
import {VERSION} from '../lib/control.mjs';
import {verifyPackage} from '../tools/integrity.mjs';

test('RC45 pins the exact published RC44 manifest and validates the executable package',()=>{
 assert.match(VERSION,/^0\.8\.1-rc\.\d+$/);
 assert.equal(JSON.parse(fs.readFileSync(path.join(ROOT,'package.json'))).version,VERSION);
 const bytes=fs.readFileSync(path.join(ROOT,'tools/reference/complete-0.8.1-rc.44-manifest.json'));
 assert.equal(sha256(bytes),'31d1f1c31f209cedce3cbd51faea6324d5ef9bfd08b9e051fb5b8b668348dec8');
 const previous=JSON.parse(bytes);assert.equal(previous.version,'0.8.1-rc.44');
 assert.equal(previous.payload.length,293);
 const code=fs.readFileSync(path.join(ROOT,'tools/integrity.mjs'),'utf8');
 assert.match(code,/m\.version==='0\.8\.1-rc\.44'/);
 assert.match(code,new RegExp(sha256(bytes)));
 // Installed user configuration is intentionally preserved by the installer.
 // The final distribution ZIP is checked with strictConfig separately.
 const current=verifyPackage(ROOT);
 assert.equal(current.version,VERSION);
});

test('RC45 payload excludes private records, runtime outputs and nested complete release ZIPs',()=>{
 const current=JSON.parse(fs.readFileSync(path.join(ROOT,'MANIFEST.json')));
 assert(current.payload.every(x=>! /^(?:private_data|\.runtime|diagnostics|Ergebnis|reports)\//i.test(x.path)));
 assert(current.payload.every(x=>! /(?:^|\/)complete-0\.8\.1-rc\.\d+\.zip$/i.test(x.path)));
 for(const file of ['tests/rc45-filepond-browser.test.mjs','tests/rc45-filepond-model.test.mjs','tests/rc45-upload-recovery.test.mjs',
  'tests/rc45-release-contract.test.mjs','tests/rc45-upgrade.test.mjs']){
  assert(current.payload.some(x=>x.path===file),'Release omits required regression: '+file);
 }
});
