import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';
import {ROOT} from './helpers.mjs';import {VERSION} from '../lib/control.mjs';import {sha256} from '../lib/core.mjs';import {verifyPackage,verifyPrevious} from '../tools/integrity.mjs';
test('RC56 original RC55 manifest is byte-pinned; successful routing/upload/Phase1 remain unchanged',()=>{
 assert.equal(VERSION,'0.8.1-rc.56');const content=fs.readFileSync(path.join(ROOT,'tools/reference/complete-0.8.1-rc.55-manifest.json'));assert.equal(sha256(content),'4280c14a84d1b4b36c1e643c91b7bf7c9802670c7b795ecd1bb02b14b3c46696');
 const old=JSON.parse(content);for(const file of ['lib/phase2-review-flow.mjs','lib/phase2-assignee.mjs','lib/phase2-filepond.mjs','lib/phase2-mbc-draft.mjs','lib/phase2-work-rules.mjs','src/local-bot-full-run.mjs','tools/deploy.mjs','lib/migration-priority.mjs','tools/delivery-window.ps1']){
  assert.equal(sha256(fs.readFileSync(path.join(ROOT,file))),old.payload.find(x=>x.path===file).sha256,file);
 }
 assert.equal(verifyPackage(ROOT).version,VERSION);
});
test('RC56 MBC draft is saved before GEVO/description, while prior journal and routes remain fail-closed',()=>{
 const src=fs.readFileSync(path.join(ROOT,'src/phase2-work-handler.mjs'),'utf8');
 assert(src.indexOf('await savePhase2Draft(page)') < src.lastIndexOf('await ensureGevo();'));
 assert(src.indexOf('P2_RC56_GEVO_PRE_DRAFT:')<src.indexOf('await savePhase2Draft(page)'));
 assert(src.includes('P2_RC56_SERVER_READBACK:'));assert(src.includes('P2_WORK_SERVER_DESCRIPTION'));
 assert(!/sendOnce\(|sendPhase2Mail\(|attachLocalFiles\(/.test(src));
});
