import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';import {EventEmitter} from 'node:events';
import {temp,mapping,putActive} from './helpers.mjs';import {withPhase2Browser,installPhase2Fixture} from './rc52-browser-fixture.mjs';
import {readMbcDraft,prepareMbcDraft,applyMbcDraft,verifyMbcDraft,classifyMbcDraft} from '../lib/phase2-mbc-draft.mjs';
import {phase2WorkJournal} from '../lib/phase2-work-journal.mjs';import {privateMbcDraft,PRIVATE_MBC_REQUEST} from '../lib/phase2-work-rules.mjs';
import {handlePhase2Work} from '../src/phase2-work-handler.mjs';import {phase2Run} from '../src/phase2-run.mjs';import {createPhase2TicketConsole} from '../lib/phase2-ticket-console.mjs';
const id='87160524',description='USC 100/ DC\nStandardantwort versendet\n'+PRIVATE_MBC_REQUEST;
const draft=privateMbcDraft({lastName:'Mustermann',gender:'M'});
const member=async()=>({profileVerified:true,profile:{first:'Max',last:'Mustermann',mercerId:'99900001'}});
async function detail(page,existing=''){await installPhase2Fixture(page,[{ticketId:id,description,draft:existing}]);await page.call(id=>showDetail(id),id);}
const noAsk=async q=>{throw Error('UNEXPECTED: '+q);};
test('RC55 Chromium actual RC54 branch: existing draft is backed up, explicitly replaced in BOTH editor layers, saved and routed exactly once',{timeout:55000},()=>withPhase2Browser(async page=>{
 const root=temp();try{
  const old='Bestehender Entwurf\nMit freundlichen Grüßen\nMercer';await installPhase2Fixture(page,[{ticketId:id,description,draft:old}]);let asked=0;
  const result=await handlePhase2Work({root,page,row:{ticketId:id,descriptionValue:description},mapping:mapping(),memberLookup:member,log:()=>{},ask:async q=>{
   assert(q.includes('ERSETZEN '+id));asked++;assert.equal(phase2WorkJournal(root,id).read(),null);assert.equal(await page.eval('_counts.save+_counts.draft+_counts.review'),0);return 'ERSETZEN '+id;
  }});
  assert.equal(asked,1);assert.equal(result.status,'ROUTED_VERIFIED');assert.deepEqual(await page.eval('_counts'),{open:2,save:1,draft:1,review:1,direct:0,send:0,upload:0});
  assert.equal((await page.eval('_server[0].draft')).replace(/\n{3,}/g,'\n\n'),draft);
  const files=fs.readdirSync(path.join(root,'.runtime/phase2/draft-backups'));assert.equal(files.length,1);
  const backup=JSON.parse(fs.readFileSync(path.join(root,'.runtime/phase2/draft-backups',files[0])));assert.equal(backup.snapshot.source.html,old);
  const j=phase2WorkJournal(root,id).read();assert.equal(j.state,'ROUTED_VERIFIED');const intent=j.events.find(e=>e.state==='MBC_DRAFT_WRITE_INTENT');assert.equal(intent.decision,'REPLACE');assert(intent.backupSha256);
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));
test('RC55 Chromium formatting-equivalent existing MBC is reused without erasing paragraph HTML or asking',{timeout:18000},()=>withPhase2Browser(async page=>{
 const root=temp();try{await detail(page);const html=draft.split('\n\n').map(p=>'<p>'+p+'</p>').join('');await page.call(h=>{document.getElementById('editor').innerHTML=h;document.getElementById('mainForm:emailMessageBodyRichEditor').value=h;},html);
  const plan=await prepareMbcDraft({root,page,ticketId:id,draft,ask:noAsk});assert.equal(plan.kind,'MATCH');
  const before=await readMbcDraft(page,id);const out=await applyMbcDraft(page,{ticketId:id,plan});assert.equal(out.method,'EXISTING_MBC_REUSED');assert.deepEqual(await readMbcDraft(page,id),before);assert(await verifyMbcDraft(page,id,draft));
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));
test('RC55 Chromium source-only old content and image-only signatures demand explicit consent; blank refusal never writes',{timeout:16000},()=>withPhase2Browser(async page=>{
 const root=temp();try{await detail(page);await page.call(()=>{document.getElementById('mainForm:emailMessageBodyRichEditor').value='<p>Nur im Quellfeld</p>';});
  assert.equal(classifyMbcDraft(await readMbcDraft(page,id),draft),'REVIEW_REQUIRED');const before=await readMbcDraft(page,id);
  await assert.rejects(()=>prepareMbcDraft({root,page,ticketId:id,draft,ask:async()=>''}),e=>e.code==='P2_MBC_DRAFT_NOT_AUTHORIZED');assert.deepEqual(await readMbcDraft(page,id),before);
  await page.call(()=>{document.getElementById('editor').innerHTML='<img alt="Signatur">';document.getElementById('mainForm:emailMessageBodyRichEditor').value='';});assert.equal(classifyMbcDraft(await readMbcDraft(page,id),draft),'REVIEW_REQUIRED');
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));
test('RC55 Chromium changed draft after consent or before write is never overwritten; tampered backup also blocks',{timeout:18000},()=>withPhase2Browser(async page=>{
 const root=temp();try{await detail(page,'Alt');
  await assert.rejects(()=>prepareMbcDraft({root,page,ticketId:id,draft,ask:async()=>{await page.call(()=>document.getElementById('editor').innerText='Inzwischen geaendert');return 'ERSETZEN '+id;}}),e=>e.code==='P2_MBC_DRAFT_CHANGED');
  let plan=await prepareMbcDraft({root,page,ticketId:id,draft,ask:async()=> 'ERSETZEN '+id});
  await assert.rejects(()=>applyMbcDraft(page,{ticketId:id,plan,beforeWrite:async()=>page.call(()=>document.getElementById('editor').innerText='Neuere Bearbeitung')}),e=>e.code==='P2_MBC_DRAFT_WRITE');assert.equal(await page.eval('document.getElementById("editor").innerText'),'Neuere Bearbeitung');
  plan=await prepareMbcDraft({root,page,ticketId:id,draft,ask:async()=> 'ERSETZEN '+id});fs.appendFileSync(plan.backup.file,' ');await assert.rejects(()=>applyMbcDraft(page,{ticketId:id,plan}),e=>e.code==='P2_MBC_BACKUP_CHANGED');
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));
test('RC55 Chromium same-evaluation ticket binding and failed write-ahead callback block ALL editor changes',{timeout:16000},()=>withPhase2Browser(async page=>{
 const root=temp();try{await detail(page);const plan=await prepareMbcDraft({root,page,ticketId:id,draft,ask:noAsk});
  await assert.rejects(()=>applyMbcDraft(page,{ticketId:id,plan,beforeWrite:()=>{throw Error('journal failure');}}),/journal failure/);assert.equal(await page.eval('document.getElementById("editor").innerText'),'');
  await assert.rejects(()=>applyMbcDraft(page,{ticketId:id,plan,beforeWrite:async()=>page.call(()=>{document.querySelector('form > div').textContent='Ticket-ID: 99999999';})}),e=>e.code==='P2_MBC_DRAFT_WRITE');assert.equal(await page.eval('document.getElementById("editor").innerText'),'');
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));
test('RC55 Chromium CKEditor iframe and backing textarea synchronize without send/save, then strict readback accepts only MBC',{timeout:16000},()=>withPhase2Browser(async page=>{
 const root=temp();try{await detail(page,'Alter Iframe-Entwurf');await page.call(()=>{
   document.getElementById('editor').remove();const frame=document.createElement('iframe');frame.id='cke-frame';document.getElementById('mainForm').appendChild(frame);frame.contentDocument.body.contentEditable='true';frame.contentDocument.body.innerHTML='<p>Alter Iframe-Entwurf</p>';
   window._updates=0;window.CKEDITOR={instances:{'mainForm:emailMessageBodyRichEditor':{editable:()=>({$:frame.contentDocument.body}),fire(){},updateElement(){window._updates++;document.getElementById('mainForm:emailMessageBodyRichEditor').value=frame.contentDocument.body.innerHTML;}}}};
  });const plan=await prepareMbcDraft({root,page,ticketId:id,draft,ask:async()=> 'ERSETZEN '+id});await applyMbcDraft(page,{ticketId:id,plan});assert(await verifyMbcDraft(page,id,draft));assert.equal(await page.eval('_updates'),1);assert.equal(await page.eval('_counts.save+_counts.draft+_counts.send'),0);
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));
function controller(records){let child;const respond=m=>queueMicrotask(()=>child.stdout.emit('data',JSON.stringify({schema:'MCR_CONTROL_V1',...m})+'\n'));
 return options=>createPhase2TicketConsole({...options,platform:'win32',env:{},launcher:()=>{
  child=new EventEmitter();child.stdout=new EventEmitter();child.stdout.setEncoding=()=>{};child.unref=()=>{};child.kill=()=>{};child.stdin=new EventEmitter();child.stdin.writable=true;child.stdin.end=()=>{};
  child.stdin.write=line=>{const m=JSON.parse(line);records.push(m);if(m.event==='suspend')respond({event:'hidden',seq:m.seq});if(m.event==='approval')respond({event:m.action==='REPLACE_MBC_DRAFT'?'skip':'approve',ticket:m.ticket,challenge:m.challenge});};respond({event:'ready'});return child;
 }});
}
test('RC55 Chromium explicit first-ticket SKIP keeps draft+description unchanged and processes next DB ticket, no success card for skip',{timeout:65000},()=>withPhase2Browser(async page=>{
 const root=temp();putActive(root);try{await installPhase2Fixture(page,[{ticketId:id,description,draft:'Bitte diesen fremden Entwurf beibehalten'},{ticketId:'87316993',description:'USC 100/ DB+\nStandardantwort versendet'}]);const records=[];
  const result=await phase2Run({root,session:{page,rl:{}},memberLookup:member,log:()=>{},consoleFactory:controller(records),askFn:async(_rl,q)=>{if(q.startsWith('Start-Ticket'))return id;if(q.includes('Weiterleitung starten?'))return 'START';throw Error(q);}});
  assert.equal(result.processed,1);assert.deepEqual(result.receipts.map(x=>x.ticketId),['87316993']);assert(result.skipped.some(x=>x.ticketId===id&&x.reason==='MBC_EXISTING_DRAFT_RETAINED'));
  assert.equal(await page.eval('_server[0].description'),description);assert.equal(await page.eval('_server[0].draft'),'Bitte diesen fremden Entwurf beibehalten');assert.equal(phase2WorkJournal(root,id).read(),null);
  assert.equal(await page.eval('_counts.send+_counts.draft'),0);assert.equal(await page.eval('_counts.save'),1);
  assert.deepEqual(records.filter(x=>x.event==='ticket_deferred').map(x=>x.ticket),[id]);assert.deepEqual(records.filter(x=>x.event==='ticket_complete').map(x=>x.ticket),['87316993']);
  const consent=records.find(x=>x.event==='approval');assert.equal(consent.action,'REPLACE_MBC_DRAFT');assert.equal(consent.manualOnly,true);assert.equal(consent.allowSkip,true);
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));
