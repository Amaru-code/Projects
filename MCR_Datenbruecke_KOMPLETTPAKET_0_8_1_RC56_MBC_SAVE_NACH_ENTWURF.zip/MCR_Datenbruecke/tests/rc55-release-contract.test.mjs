import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';
import {ROOT} from './helpers.mjs';import {VERSION} from '../lib/control.mjs';import {sha256} from '../lib/core.mjs';import {verifyPackage,verifyPrevious} from '../tools/integrity.mjs';
const read=f=>fs.readFileSync(path.join(ROOT,f),'utf8');
test('RC55 pins original RC54; no changes to file upload, Phase1 editor, draft template, routing receipt or installer',()=>{
 assert.match(VERSION,/^0\.8\.1-rc\.\d+$/);const text=read('tools/reference/complete-0.8.1-rc.54-manifest.json');assert.equal(sha256(text),'8b98cbefa6eca19cdfaf1314dfadaa36f817d78a69e53f04a07409836f172481');
 const prior=JSON.parse(text);for(const f of ['lib/phase2-filepond.mjs','tools/deploy.mjs','lib/migration-priority.mjs','src/local-bot-full-run.mjs','tools/delivery-window.ps1','lib/browser-workflow.mjs','lib/phase2-work-rules.mjs','lib/phase2-review-flow.mjs','lib/phase2-route-receipt.mjs'])assert.equal(sha256(fs.readFileSync(path.join(ROOT,f))),prior.payload.find(x=>x.path===f).sha256,f);
 assert.equal(verifyPackage(ROOT).version,VERSION);
});
test('RC55 explicit draft choice is manual-only, scoped to exact ticket; deferred card has no completion ghost',()=>{
 const c=read('lib/phase2-ticket-console.mjs');assert(c.includes("action:'REPLACE_MBC_DRAFT',manualOnly:true,allowSkip:true"));
 const ps=read('tools/phase2-ticket-window.ps1');assert(ps.includes("$skip.Text='Unveraendert lassen'"));assert(ps.includes("event='skip';ticket=$script:ticket;challenge=$script:challenge"));
 const branch=ps.split("elseif($m.event -eq 'ticket_deferred')")[1].split("elseif($m.event -eq 'ticket_complete')")[0];assert(!branch.includes('McrTicketGhost'));assert(branch.includes('$form.Hide()'));
 assert(!/Invoke-WebRequest|HttpClient|Set-Content|WriteAllText|SendKeys/i.test(ps));
 const source=read('src/phase2-work-handler.mjs');assert(source.indexOf("draftPlan.kind==='SKIP'")<source.indexOf('journal.begin('));
 const editor=read('lib/phase2-mbc-draft.mjs');assert(!/sendOnce\(|savePhase2|finishPhase2Route|attachLocalFiles\(/.test(editor));
});
