# MCR Mail-Assistent 0.3.3 — Auswahlbindung und Klickbeobachtung

## Für dieses Update: KEIN neuer Excel-Export

Dein mit 0.3.2 erzeugtes JSON mit `ONE_ONLY_BLANK_OMIT_V1` bleibt verwendbar. Der Excel-Importer, die Blank-Regel, USC-Berechnung, der MSG-Leser und die Namensregeln sind in diesem Update unverändert. Die Paketänderung betrifft die Browserauswahl und ihre Diagnose.

Ein erfolgreicher Mapping-Export bestätigt **nicht**, dass jede Kennung freigegeben ist. Die verbleibenden gesperrten Kennungen werden weiterhin nach der tatsächlichen Member-Auswahl geprüft. `selectedKeyBlocked=false` vor `lookupAttempted=true` ist kein erfolgreicher Einzeldatensatz-Test.

## Aktualisieren

1. Das ZIP vollständig entpacken. Den enthaltenen Ordner **MCR_Datenbruecke** mit dem vorhandenen gleichnamigen Ordner zusammenführen. Paketdateien ersetzen, den bisherigen Ordner **nicht löschen**. Eigene Mails, Excel, `private_data` und Node-Runtime behalten.
2. `MAIL_ASSISTENT_OEFFNEN.cmd` starten. Den gesamten geöffneten Code in die Edge-DevTools-Konsole der COMARCH-Seite einsetzen (Kontext `top`). Keine betrieblichen Schutzrichtlinien umgehen. Im Panel steht **0.3.3**. Die vorige aktive Panelversion wird geschlossen.
3. Deine bereits erzeugte JSON-Datei aus `private_data` laden und den Quellenstand bestätigen. Keine XLSX ins Panel laden. Danach die Original-MSG des geöffneten Tickets laden.
4. Im Ticket selbst **Bearbeiten** wählen, falls noch nicht geschehen. Dies kann reale Ticketdaten ändern. Genau einen freigegebenen Testfall verwenden. Namen und MercerID-Hinweis prüfen; die Vorgangsnummer ist nur eine separate Fallgrenze.
5. Die Identitätsprüfung bestätigen und **Member suchen** klicken. Der Suchtext bleibt **Nachname Vorname**.

## Was bei der Auswahl passiert

Der Helfer versucht nun, eine Komponenteninstanz anhand ihres **tatsächlichen Eingabefeldes** zu finden. Der Registry-Schlüssel muss nicht mehr identisch mit der Feld-ID sein. Das Listen-DIV wird aus der gefundenen Instanz gelesen, nicht aus dem geratenen Suffix `_div` zusammengesetzt.

Eine automatische Auswahl benötigt weiterhin einen sicher gebundenen Einzeltreffer, passenden geprüften Namen und — bei ICEfaces oder einer gelernten DOM-Liste — die geprüfte MercerID. Nach höchstens einem Klick wartet der Helfer auf die tatsächlich befüllten MercerID-Stammdaten. **Mehrere gelieferte Zeilen werden nicht eigenständig auf einen bevorzugten Treffer reduziert.**

### Falls weiterhin keine automatische Auswahl erfolgt

**Nicht die MercerID in das normale Member-Suchfeld tippen und nicht wieder Excel exportieren.**

Klicke auf **COMARCH-Member-Feld zeigen**. Falls noch keine Vorschlagsliste sichtbar ist, lösche im **echten COMARCH-Member-Feld** ein Zeichen und tippe es wieder ein. Warte auf die Liste und klicke den richtigen **echten COMARCH-Vorschlag** einmal selbst an.

Der Helfer beobachtet den echten Klick und die anschließende Übernahme. Sobald Memberfeld und MercerID-Stammdaten übereinstimmen, kann der Lookup weiterlaufen. Nach ungefähr zwei Sekunden sollte Schritt 4 das Ergebnis oder einen konkreten Bestandssperrgrund zeigen. Andernfalls nach sichtbarer Übernahme **Meine Member-Auswahl bestätigen → weiter** verwenden.

Ein zu früher Klick auf **weiter** beendet die Auswahlbeobachtung jetzt nicht mehr. Er ersetzt aber niemals die echte Member-Auswahl.

### Beobachtetes Listenlernen

Kann der Helfer die angeklickte Liste strukturell eindeutig abgrenzen, merkt er sich ihre Bindung erst **nach** dem echten Benutzerklick **und** einer passenden ausgefüllten MercerID-Anzeige. Das funktioniert für lokale Ein-Input-Komponenten sowie klar erkennbare Listbox-/ICEfaces-Popups, auch wenn die Liste außerhalb des Eingabefeld-Wrappers liegt.

Eine gelernte Bindung gilt nur im Speicher dieses Helfers und nur für das zugehörige Dokument/Eingabefeld bzw. dessen Struktur. Keine Datei, keine dauerhafte globale Freigabe, kein Lernen aus Namen. Bei Seitenwechsel, ausgetauschtem Feld, verändertem Popup oder unklarer Struktur bleibt die manuelle Auswahl erforderlich. Eine zuvor gelernte Liste erlaubt bei späteren Suchen ebenfalls nur einen stabilen Einzeltreffer mit geprüftem exaktem Namen und geprüfter ID. Versteckte zusätzliche Zeilen zählen mit.

**Nicht jede unbekannte COMARCH-Liste wird dadurch automatisch bedienbar.** Ein Erfolg mit der lokalen Demo ist kein Nachweis über die ausgelieferte COMARCH-Version.

## Ergebnis übernehmen

Schritt 4 liest weiterhin ausschließlich die Kennung des zugeordneten Members aus dem geladenen JSON. Beschreibung: `USC {L}/ {Kürzel}`, C=1 → DC, D=1 → PP+, E=1 → DB+; Reihenfolge DC;PP+;DB+. Leer/0 erzeugen kein Kürzel, echte Leerwerte bleiben als `null` dokumentiert.

Die Beschreibung wird nicht von selbst geschrieben. **Beschreibung kopieren** oder **Beschreibung in COMARCH einsetzen** ist ein eigener Klick. Ein vorhandener abweichender Beschreibungstext bleibt geschützt. Formelwerte benötigen ggf. die separate Quellenprüfung. Senden, Ticket speichern, Kategorie, Signatur, Anrede, Empfänger und Queue-Durchlauf bleiben **manuell**.

Ist der richtige Member schon ausgewählt, muss er nicht entfernt werden: Mapping/Mail laden und prüfen, dann **Meine Member-Auswahl bestätigen → weiter**.

## Diagnose statt kompletter Konsole

Bleibt die Auswahl unklar, den richtigen Vorschlag einmal selbst anklicken. Das ist gleichzeitig eine gezielte Klickbeobachtung. Danach **Diagnose-ZIP** drücken. Es enthält Statuswerte, begrenzte Anzahlen und Strukturmerkmale (z. B. Elementtyp, eine Listbox-Rolle vorhanden), keine Namen, Kennungen, Zellwerte, Mailtexte, Cookies, DOM-IDs oder HTML.

Das Ergebnis heißt `MCR_MAIL_..._UPLOAD.zip`. Nur dieses ZIP weitergeben, nicht die komplette Konsole, Original-Mail oder das Mapping. Ein Klick auf **Auswahlliste prüfen** ist weiterhin möglich; der Knopf versucht, den bestehenden Listenfokus zu erhalten.

## Unveränderte Voraussetzungen und Grenzen

Node >=22.15 ist nur für die vorhandenen lokalen CLI-Funktionen/Selbsttests nötig. Keine npm-Abhängigkeiten oder automatische Installation. Die bisherige portable Runtime wird wiederverwendet. Der unveränderte Excel-Exporter nennt intern weiterhin seinen Datenregelstand 0.3.2; das Browser-Panel dieses Pakets ist 0.3.3.

MSG mit gespeichertem Klartext wird unterstützt; RTF-only/HTML-only, verschlüsselte und andere Varianten bleiben ggf. unlesbar. Kein Anhangsaufruf, keine externe KI-Auswertung. Absender und betroffene Person können verschieden sein; Namens- und ID-Hinweise bedürfen der Kontrolle. Keine Geschlechtsableitung oder automatische Änderung des Antwortempfängers.

Mail und Mapping gelangen bei Auswahl in den Speicher der COMARCH-Seite: **keine isolierte Datenschutz-Sandbox**. Nur im betrieblich freigegebenen Kontext verwenden. Die Member-Suche und -Auswahl können normale COMARCH-Serveranfragen auslösen. `private_data` ist nicht verschlüsselt und gehört nicht in Git oder einen Chat-Upload.

Vor dem nächsten Ticket **Neuer Fall**, nach Nutzung **Schließen**. Bei einem vollen Seitenwechsel den Code ggf. erneut einsetzen und das Mapping neu auswählen.

## Nachweise

Aktueller Prüfbericht: `docs/DISCOVERY_TESTBERICHT.md`. Frühere Berichte unter `docs` betreffen ältere Releases. `SELBSTTEST.cmd` prüft das aktuelle Paket und die Node-Tests. Python-/Playwright-Testdateien sind Entwicklernachweise; beim Anwender ist dafür keine Installation nötig.
