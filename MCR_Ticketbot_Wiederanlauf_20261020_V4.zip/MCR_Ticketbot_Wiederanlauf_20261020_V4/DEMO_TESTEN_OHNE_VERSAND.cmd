@echo off
setlocal DisableDelayedExpansion
echo.
echo ==============================================================
echo  MCR TICKETBOT: ZWEI FIKTIVE TICKETS, KEIN ECHTVERSAND
echo ==============================================================
call "%~dp0tools\run.cmd" demo-only
set "MCR_EXIT=%ERRORLEVEL%"
echo.
if not "%MCR_EXIT%"=="0" echo STOPP - Exitcode %MCR_EXIT%. Kein Erfolg behauptet.
echo Das Fenster bleibt offen. Ergebnisbericht: Ergebnis\REPARATUR_ERGEBNIS.json
echo.
pause
exit /b %MCR_EXIT%
