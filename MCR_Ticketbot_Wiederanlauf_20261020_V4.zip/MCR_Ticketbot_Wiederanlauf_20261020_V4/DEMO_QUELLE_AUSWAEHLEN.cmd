@echo off
setlocal DisableDelayedExpansion
echo.
echo ==============================================================
echo  MCR: FIKTIVE DEMO_MAPPING.JSON AUSWAEHLEN - KEIN ECHTVERSAND
echo ==============================================================
echo.
call "%~dp0tools\run.cmd" demo-source-select "%~1"
echo.
if not "%ERRORLEVEL%"=="0" echo STOPP - Die Demo-Datei wurde nicht ausgewaehlt.
pause
