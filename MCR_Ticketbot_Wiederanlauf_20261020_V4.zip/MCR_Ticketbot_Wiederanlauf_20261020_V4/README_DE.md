# MCR Ticketbot – Wiederanlauf V4 (20.10.2026)

## Was V4 behebt

Der User-Lauf von V3 stoppte mit `DEMO_MAPPING_HASH_MISMATCH`. Das war ein Fehler des Reparaturpakets: `c147a9eb9c93d5c6d4a47f208c9f98c2afd0b0144cbf63b2c50b1c06676fdc40` aus dem früheren erfolgreichen DEMO-Protokoll ist **nicht** der SHA-256 der Datei `examples/DEMO_mapping.json`. Es ist `map.payloadSha256` des durch den Runner **neu erzeugten Mehrzeilenmappings**. Die Eingabedatei ist dagegen ein **Legacy-Mapping**, deren eigener SHA `sha256(JSON.stringify(obj.payload)) === obj.payloadSha256` erfüllt. Die alte V3-Datei-SHA-Sperre musste folglich auch bei intakter Eingabedatei fehlschlagen.

V4 ersetzt diese falsche Prüfung durch zwei korrekt getrennte Nachweise:

1. **Vor der Demo:** Die lokale Legacy-JSON muss `schema`, `payload`, `payloadSha256` und begrenzte `payload.entries` enthalten; ihre *eigene* Payload-SHA muss stimmen. Die Einträge müssen klar fiktive Personennamen enthalten und dürfen keine produktiven Mercer-/Bestandsverweise haben. Weder aktives Mapping noch persönliche Konfiguration werden als Ersatz genommen.
2. **Nach Start des vollständig isolierten Original-Runners:** Der vom Originalrunner protokollierte Mehrzeilen-Payload-SHA muss **exakt** `c147a9...76fdc40` sein; anschließend müssen **2 fiktive Tickets** mit Sende- und Speichernachweis den Diagnosevertrag erfüllen. Andernfalls **kein** Start eines echten Tickets.

Das ursprüngliche RC1.1-Runnerfile, Beta-4-Baseline, Identity-Fix-Hash, Sicherheitsgate, feste Felder, INTL01-Reihenfolge, Mehrzeilen/TPP-Logik und aktives produktives Mapping bleiben unverändert.

## Schnellstart

1. ZIP **vollständig in einen neuen Ordner** entpacken. Nicht in `MCR_Datenbruecke` installieren oder den V3-Ordner mit V4-Dateien mischen.
2. `DEMO_TESTEN_OHNE_VERSAND.cmd` doppelklicken. Es gibt dabei keine COMARCH-Anmeldung, keine produktive Dateiübernahme und **keinen echten Versand**. Zielmeldungen:
   - `PASS  PINNED_IDENTITY_RUNNER_FOUND`
   - `PASS  FICTIONAL_LEGACY_MAPPING_VERIFIED`
   - `PASS  HISTORIC_DEMO_MULTIROW_SHA256_MATCH`
   - `PASS  OFFLINE_DEMO_2_TICKETS_VERIFIED`
   - Abschluss im Ergebnis: `OFFLINE_DEMO_VERIFIED_NO_INSTALL_NO_SEND`
3. **Erst nach erfolgreicher isolierter Demo und bei ausdrücklichem Wunsch nach einem echten Ticketversand:** `JETZT_REPARIEREN_UND_STARTEN.cmd` ausführen. Nach erneuten Prüfungen und einer weiteren isolierten Demo werden höchstens **ein echtes E-MAIL-Ticket** gesendet und gespeichert. Ein erfolgreiches `LIVE_PILOT_SEND_AND_SAVE_VERIFIED` ist erforderlich, bevor die Queue freigeschaltet wird.
4. Erst dann `TICKETBOT_STARTEN.cmd` für die bestehende kontrollierte Bearbeitung nutzen (max. 100 Tickets, zuerst „Meine Vorgänge > In_Bearbeitung“, danach INTL01).

**Wichtig:** Den bisherigen `START.cmd` nicht ersetzen. Der V4-Start ist bewusst eine separate, kontrollierte Wiedereinführung. Kein automatisches erneutes Senden nach `REVIEW_REQUIRED` oder ungeklärtem COMARCH-Versandstatus.

## Falls mehrere Demo-Dateien vorhanden sind

Optional `DEMO_QUELLE_AUSWAEHLEN.cmd` starten und die **ursprüngliche fiktive** `examples/DEMO_mapping.json` aus dem alten RC1.1-Ordner auswählen. Diese Dateiauswahl validiert den internen JSON-Payload-SHA und fiktive Identitäten, installiert nichts und verschickt nichts. Danach die isolierte Demo wiederholen. Für einen verifizierten RC1.1-ZIP-Runner samt gebundener Demo-Datei hat die signierte Archivquelle Vorrang.

Ändert sich die Datei oder stimmt das erzeugte Mehrzeilenmapping nicht mit dem alten Demo-Hash überein, blockiert V4 einen echten Ticketlauf. Niemals produktive Excel-Bestände, `private_data/active-mapping.json` oder COMARCH-Exporte als Ersatz verwenden.

Die optionale manuelle Runner-Auswahl `QUELLE_AUSWAEHLEN.cmd` bleibt erhalten; V4 speichert Pfade in **`recovery-settings.local.json`**, getrennt vom per Paketmanifest geprüften `recovery-settings.json`. Bei nichtstandardisierten Pfaden kann auch in `recovery-settings.local.json` der `installRoot` bzw. `demoMappingPath` gesetzt werden (JSON-Pfade mit doppelten Backslashes). Dieses lokale Einstellungsfile enthält ggf. lokale Pfade; **nicht hochladen**.

## Status-/Fehlercodes

| Code | Bedeutung / Maßnahme |
| --- | --- |
| `DEMO_MAPPING_MISSING` | Keine lokale synthetische Legacy-JSON gefunden; andere Original-Demokopie auswählen. |
| `DEMO_MAPPING_JSON_INVALID` / `DEMO_MAPPING_LEGACY_SCHEMA` | Keine gültige Legacy-JSON nach Runner-Vertrag. |
| `DEMO_MAPPING_PAYLOAD_INTEGRITY` | Interne JSON-Payload-SHA falsch; nicht verwenden. |
| `DEMO_MAPPING_NOT_FICTIONAL` / `DEMO_MAPPING_PRIVATE_REFERENCE` | Quelle ist nicht nachweislich fiktiv oder verweist auf Echtdaten; keine Übernahme. |
| `DEMO_MULTIROW_RESULT_MISMATCH` | Originalrunner produzierte nicht den nachgewiesenen historischen Mehrzeilenhash; ursprüngliches Demo-Asset auswählen. |
| `OFFLINE_DEMO_NOT_VERIFIED` | Zwei Demo-Tickets nicht erfolgreich gesendet und gespeichert (nur lokal); keine Live-Installation. |
| `PILOT_REQUIRED` | Erst echten Einzelticket-Lauf nachweisen, bevor Queue aktiv werden darf. |
| `REVIEW_REQUIRED` / `PREVIOUS_SEND_UNCERTAIN` | Echten COMARCH-Nachrichtenverlauf prüfen, nicht erneut senden. |

Datensparsamer Bericht: `Ergebnis\REPARATUR_ERGEBNIS.json` direkt im **V4-Ordner**. Er enthält keine Personen- oder Mailinhalte. Der ursprüngliche Runner kann sensible Daten in die Konsole schreiben; vollständige Original-Logs nicht ungeprüft versenden.

## Prüfnachweis und Grenzen

V4: **138/138 Node.js-Offline-Tests bestanden, 0 Fehler, 0 übersprungen** unter Linux mit Node 22.16.0. Prüfungen beinhalten Verwechslung von Raw- und Runtime-Hashes, Legacy-Payload-Validierung, JSON-Formatänderungen, Fake-/Echtdatenabgrenzung, aktive-Mapping-Isolation, Quellenauswahl, Sperren, Rollback, Prozesse und das Auslesen des Mehrzeilenhashes aus einer **synthetischen** Runnerausgabe. Die vollständige originale Windows-RC1.1-Demo und ein echter COMARCH-Versand **konnten hier nicht** ausgeführt werden (Desktop-Verbindung offline); sie müssen am Windows-Rechner belegt werden.

Der neue Start fügt im bestehenden Bot nur die bereits festgelegten drei Recovery-Zusatzdateien hinzu; er überschreibt den ursprünglichen Runner, `START.cmd`, Konfiguration, Bestandsmapping oder Browserprofil nicht. `ZURUECK_ZUM_ALTEN_STAND.cmd` entfernt nur unverändert nachgewiesene Recovery-Zusatzdateien, nicht den ursprünglichen Bot.

### Unveränderte Kandidaten-Prüfsummen

- Beta-4-Originalrunner: `6777ca3b806f0a5085f31e5e371eaa5c6d2caa45e11cb20e475d02ae8b353d72`
- RC1.1-Identity-Runner: `e63c12081c0b6991af3ad2f9cf60a96c1203e592b6d83de63c59f0a7d52789ed`
- Original Identity Helper: `fe9e1afbca8ec4b5e3c8d7eb5bc53c741bfedc16d45429cfc2bda9a4dc5cd97a`
- Reparierter Identity Helper: `9283decde920ace1c2487504c542a2a0b0079f789637666396eb15419860d2d8`

`evidence/DEMO_ASSET_ROOT_CAUSE.md` enthält die technische Root-Cause-Analyse und Testabgrenzung.
