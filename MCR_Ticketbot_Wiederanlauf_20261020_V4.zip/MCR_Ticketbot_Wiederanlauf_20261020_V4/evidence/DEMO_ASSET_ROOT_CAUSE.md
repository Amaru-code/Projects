# V4 Root Cause and Corrective Evidence, 2026-10-20

## Observed user Windows diagnostics

- V2: `PINNED_IDENTITY_RUNNER_FOUND`; `BASELINE_AND_IDENTITY_HASHES`; active mapping and local syntax gates pass; DEMO stops `ENOENT examples/DEMO_mapping.json`. No live files were installed and no send occurred.
- V3: fixture is discovered, but the code rejects it with `DEMO_MAPPING_HASH_MISMATCH` before demo execution. No evidence of modification to the active installation or real sending.

## False equivalence in V3

V3 incorrectly enforced `sha256(bytes of examples/DEMO_mapping.json) == c147a9eb...76fdc40`.

The actual original RC1.1 runner logic:

1. `const legacy = validateMappingObject(readJson(root/examples/DEMO_mapping.json))`
2. `validateMappingObject` checks `Core.validateMap(obj)` and `sha256(JSON.stringify(obj.payload)) === obj.payloadSha256`.
3. `autoMapping()` converts `Object.values(legacy.payload.entries)` into synthetic B/C/D/E/F/L/O rows and invokes `makeMultirowMapping(...)`.
4. It returns `fileHash: map.payloadSha256` where `map` is the NEW multirow mapping.
5. The console therefore prints the NEW multirow payload fingerprint `c147a9eb9c93d5c6d4a47f208c9f98c2afd0b0144cbf63b2c50b1c06676fdc40`. It is **not** the raw legacy file hash and **not** the legacy payload hash.

The V3 hash check was a logic error introduced by the recovery package, not evidence of source corruption.

## Correct V4 gates

Before isolation: bound, regular JSON file; legacy schema/payload/payloadSha256; payload internal integrity using JSON.stringify canonical JSON semantics; 1–48 demo entries each carrying explicit fictional-person markers; prohibit real Mercer/active-mapping references; no `private_data` or browser profile read into DEMO.

After isolation: original pinned runner, `--demo` and `--auto`, newly computed runtime multirow SHA scraped only from ASCII-tagged `Mapping-Datei-SHA256:` in stdout and matched to the historic expected value; full runner diagnostic `mode=DEMO`, exactly 2 processed and send+save verified, zero error. Otherwise stop before any live installation.

All original binaries, SHA pins, original START, active mapping, send/state locks and same max-real-ticket policy stay unchanged. No SHA pin was removed from actual original code artifacts.

## Additional V4 robustness

V2 source picker wrote into `recovery-settings.json`, which is included in signed kit manifest. V4 writes user-selected paths only into untracked `recovery-settings.local.json`, and separately checks the delivered factory settings. V4 allows explicit selection of a separately validated fictional legacy DEMO file, taking priority over other local demo file candidates; no raw private information is exported.

## Test boundary

The original entire runner and genuine demo JSON bytes are not available in this container; assertions use the previously described loader contract and newly constructed fictional legacy fixtures. 138/138 synthetic Node tests passed under Linux; that is not a Windows COMARCH pilot PASS. The Windows user must first run `DEMO_TESTEN_OHNE_VERSAND.cmd`, and only afterwards may deliberately run the one-real-ticket startup, whose send+save proof is required before queue.
