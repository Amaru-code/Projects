import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {secureDemoMapping,verifyLegacyFictionalDemo,DEMO_MAPPING_REL,HISTORIC_DEMO_MULTIROW_SHA256} from '../tools/demo-assets.mjs';
import {runControlled} from '../tools/runner-control.mjs';

const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const legacyPayload={source:{type:'DEMO',name:'DEMO_mapping.json'},entries:{'10':{firstName:'Max',lastName:'Mustermann',clientId:'10',usc:'10',dc:0,ppPlus:1,dbPlus:1,gender:'M'}}};
function mapping(payload=legacyPayload,spacing=2){return Buffer.from(JSON.stringify({schema:'MCR_LEGACY_MAPPING_TEST_V1',payload,payloadSha256:sha(Buffer.from(JSON.stringify(payload)))},null,spacing)+'\n');}
const fixture=mapping();
function tmp(t){const root=fs.mkdtempSync(path.join(os.tmpdir(),'mcr-v4-demo-'));t.after(()=>fs.rmSync(root,{recursive:true,force:true}));return root;}
function writeFixture(root,content=fixture){const p=path.join(root,...DEMO_MAPPING_REL.split('/'));fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,content);return p;}
function source(installRoot,candidate={entries:null}){return secureDemoMapping({installRoot,candidate,preloaded:new Map()});}

// Pin is the output from makeMultirowMapping, not the original legacy file hash.
test('historical runtime digest is not falsely treated as original file sha256',()=>{
 assert.equal(HISTORIC_DEMO_MULTIROW_SHA256,'c147a9eb9c93d5c6d4a47f208c9f98c2afd0b0144cbf63b2c50b1c06676fdc40');
 assert.notEqual(sha(fixture),HISTORIC_DEMO_MULTIROW_SHA256);
 assert.equal(verifyLegacyFictionalDemo(fixture).legacyPayloadSha256,sha(Buffer.from(JSON.stringify(legacyPayload))));
});
test('accepts self-consistent, fictional legacy demo even if complete file raw SHA differs',t=>{
 const base=tmp(t);writeFixture(base);const r=source(base);
 assert.equal(r.source,'VALIDATED_LOCAL_FICTIONAL_LEGACY_DEMO');
 assert.deepEqual(r.bytes,fixture);
 assert.notEqual(r.integrity.fileSha256,HISTORIC_DEMO_MULTIROW_SHA256);
});
test('formatting, CRLF and BOM do not change validated payload semantics',t=>{
 const a=mapping(legacyPayload,0), b=Buffer.from('\uFEFF'+mapping(legacyPayload,4).toString('utf8').replaceAll('\n','\r\n'));
 assert.notEqual(sha(a),sha(b));assert.equal(verifyLegacyFictionalDemo(a).legacyPayloadSha256,verifyLegacyFictionalDemo(b).legacyPayloadSha256);
 const base=tmp(t);writeFixture(base,b);assert.equal(source(base).integrity.legacyPayloadSha256,sha(Buffer.from(JSON.stringify(legacyPayload))));
});
test('old legacy payloadSha256 cannot be faked with altered entry content',()=>{
 const o=JSON.parse(fixture);o.payload.entries['10'].lastName='PrivateRealPerson';
 assert.throws(()=>verifyLegacyFictionalDemo(Buffer.from(JSON.stringify(o))),{code:'DEMO_MAPPING_PAYLOAD_INTEGRITY'});
});
test('even correct embedded payload checksum cannot authorize a real identity',()=>{
 const p={...legacyPayload,entries:{'10':{firstName:'Real',lastName:'Unknown',clientId:'123'}}};
 assert.throws(()=>verifyLegacyFictionalDemo(mapping(p)),{code:'DEMO_MAPPING_NOT_FICTIONAL'});
});
test('rejects production UNC or personal mapping reference before demo run',()=>{
 const p={...legacyPayload,source:'\\\\mercer.com\\eu_data\\INTL01_Gesamtdatenbestand.xlsx'};
 assert.throws(()=>verifyLegacyFictionalDemo(mapping(p)),{code:'DEMO_MAPPING_PRIVATE_REFERENCE'});
});
test('valid mapping does not read/copy existing active mapping',t=>{
 const base=tmp(t);writeFixture(base);
 const secret=Buffer.from('private content not for demo');const p=path.join(base,'private_data','active-mapping.json');
 fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,secret);
 const r=source(base);assert.deepEqual(r.bytes,fixture);assert.deepEqual(fs.readFileSync(p),secret);
});
test('rejects missing demo without resorting to active mapping',t=>{assert.throws(()=>source(tmp(t)),{code:'DEMO_MAPPING_MISSING'});});
test('rejects invalid json',()=>{assert.throws(()=>verifyLegacyFictionalDemo(Buffer.from('{invalid')),{code:'DEMO_MAPPING_JSON_INVALID'});});
test('rejects unrelated synthetic rows without original legacy contract',()=>{assert.throws(()=>verifyLegacyFictionalDemo(Buffer.from('{"testOnly":true,"rows":[]}')),{code:'DEMO_MAPPING_LEGACY_SCHEMA'});});
test('rejects empty or overlarge legacy entry collections',()=>{
 assert.throws(()=>verifyLegacyFictionalDemo(mapping({...legacyPayload,entries:{}})),{code:'DEMO_MAPPING_ENTRIES'});
 const many=Object.fromEntries(Array.from({length:49},(_,i)=>[String(i),{name:'Max Mustermann'}]));
 assert.throws(()=>verifyLegacyFictionalDemo(mapping({...legacyPayload,entries:many})),{code:'DEMO_MAPPING_ENTRIES'});
});
test('rejects bogus claims to valid file identity without valid internal checksum',t=>{
 const base=tmp(t), p=JSON.parse(fixture);p.payloadSha256='0'.repeat(64);writeFixture(base,Buffer.from(JSON.stringify(p)));
 assert.throws(()=>source(base),{code:'DEMO_MAPPING_PAYLOAD_INTEGRITY'});
});
test('pinned release archive carries exact matching bytes, but still has to pass legacy integrity',t=>{
 const base=tmp(t);writeFixture(base,Buffer.from('modified'));const prefix='release/';
 const candidate={prefix,entries:new Map([[prefix+DEMO_MAPPING_REL,fixture]])};
 const got=secureDemoMapping({installRoot:base,candidate,preloaded:new Map([[DEMO_MAPPING_REL,fixture]])});
 assert.equal(got.source,'PINNED_RELEASE_ARCHIVE');assert.deepEqual(got.bytes,fixture);
});
test('preloaded mapping without matching pinned release archive is denied',t=>{
 const base=tmp(t);assert.throws(()=>secureDemoMapping({installRoot:base,candidate:{entries:null},preloaded:new Map([[DEMO_MAPPING_REL,fixture]])}),{code:'DEMO_ASSET_UNTRUSTED'});
});
test('archive preloaded data differing from pinned archive contents is denied',t=>{
 const base=tmp(t), candidate={prefix:'r/',entries:new Map([['r/'+DEMO_MAPPING_REL,fixture]])};
 assert.throws(()=>secureDemoMapping({installRoot:base,candidate,preloaded:new Map([[DEMO_MAPPING_REL,Buffer.from('changed')]])}),{code:'DEMO_ASSET_UNTRUSTED'});
});
test('rejects symlink demo file and parent directory',t=>{
 const base=tmp(t), x=tmp(t);writeFixture(x);const target=path.join(x,...DEMO_MAPPING_REL.split('/'));
 fs.mkdirSync(path.join(base,'examples'));
 try{fs.symlinkSync(target,path.join(base,'examples','DEMO_mapping.json'));}catch(e){if(e.code==='EPERM')return t.skip('symlink privilege missing');throw e;}
 assert.throws(()=>source(base),{code:'PATH_LINK'});
});
test('isolated child opens DEMO_mapping.json and no private mapping was materialized',t=>{
 const base=tmp(t), scratch=tmp(t);writeFixture(base);const result=source(base);writeFixture(scratch,result.bytes);
 const code="const fs=require('fs');const x=JSON.parse(fs.readFileSync('examples/DEMO_mapping.json','utf8'));if(x.payload.entries['10'].lastName!=='Mustermann')process.exit(2);";
 const p=spawnSync(process.execPath,['-e',code],{cwd:scratch,encoding:'utf8'});
 assert.equal(p.status,0,p.stderr);assert.equal(fs.existsSync(path.join(scratch,'private_data')),false);
});

test('runtime digest capture reads transformed mapping SHA and is independent of legacy file digest',async t=>{
 const base=tmp(t), files={
  'src/local-bot-recovery-20261020.mjs':`import fs from 'node:fs';\nconsole.log('Mapping-Datei-SHA256: ${HISTORIC_DEMO_MULTIROW_SHA256}');\nfs.writeFileSync('demo-diagnostic.json',JSON.stringify({schema:'MCR_LOCAL_RUNNER_DIAGNOSTIC_V1',mode:'DEMO',createdAt:new Date().toISOString(),loop:{processed:2},send:{verified:true},save:{verified:true},lastError:null}));`,
  'src/reference.mjs':'export const demo=true;',
  'lib/a.cjs':'module.exports=1;',
  'lib/b.cjs':'module.exports=2;'
 };
 const hashes={};for(const [rel,txt] of Object.entries(files)){const p=path.join(base,rel);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,txt);hashes[rel]=sha(Buffer.from(txt));}
 const r=await runControlled(base,'DEMO',hashes);
 assert.equal(r.exit,0);assert.equal(r.demoMultirowSha256,HISTORIC_DEMO_MULTIROW_SHA256);assert.equal(r.diagnostic?.loop?.processed,2);
});

test('explicitly selected fictional demo takes precedence over another local valid demo',t=>{
 const base=tmp(t), other=tmp(t);
 const alt=mapping({...legacyPayload,source:{type:'DEMO',name:'another synthetic asset'}});
 writeFixture(base,alt);const selected=writeFixture(other,fixture);
 const r=secureDemoMapping({installRoot:base,candidate:{entries:null,demoMappingPath:selected},preloaded:new Map()});
 assert.deepEqual(r.bytes,fixture);
});
test('explicitly selected missing demo is not silently replaced by another valid one',t=>{
 const base=tmp(t);writeFixture(base,fixture);
 assert.throws(()=>secureDemoMapping({installRoot:base,candidate:{entries:null,demoMappingPath:path.join(base,'nowhere','DEMO_mapping.json')},preloaded:new Map()}),{code:'DEMO_SELECTED_FILE_UNAVAILABLE'});
});
