import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {loadRecoverySettings,saveUserSettings} from '../tools/user-settings.mjs';
const factory=JSON.stringify({installRoot:'',candidateRunner:''});
function workspace(t){const p=fs.mkdtempSync(path.join(os.tmpdir(),'mcr-settings-v4-'));t.after(()=>fs.rmSync(p,{recursive:true,force:true}));fs.writeFileSync(path.join(p,'recovery-settings.json'),factory);return p;}
test('factory signed settings remain immutable after local selection',t=>{
 const p=workspace(t), orig=fs.readFileSync(path.join(p,'recovery-settings.json'));
 saveUserSettings(p,{candidateRunner:'C:\\original\\rc1.zip'});
 assert.deepEqual(fs.readFileSync(path.join(p,'recovery-settings.json')),orig);
 assert.equal(loadRecoverySettings(p).candidateRunner,'C:\\original\\rc1.zip');
});
test('local choices update only the explicitly named dimension',t=>{
 const p=workspace(t);saveUserSettings(p,{installRoot:'C:\\MCR'});saveUserSettings(p,{candidateRunner:'C:\\rc1.zip'});
 assert.deepEqual(loadRecoverySettings(p),{installRoot:'C:\\MCR',candidateRunner:'C:\\rc1.zip'});
});
test('local demo path remains optional and never changes factory',t=>{
 const p=workspace(t);saveUserSettings(p,{demoMappingPath:'C:\\sample\\examples\\DEMO_mapping.json'});
 assert.equal(loadRecoverySettings(p).demoMappingPath,'C:\\sample\\examples\\DEMO_mapping.json');
 assert.equal(fs.readFileSync(path.join(p,'recovery-settings.json'),'utf8'),factory);
});
test('unknown settings and wrong types fail closed',t=>{
 const p=workspace(t);assert.throws(()=>saveUserSettings(p,{sendReal:true}),{code:'SETTINGS_INVALID'});
 assert.throws(()=>saveUserSettings(p,{installRoot:42}),{code:'SETTINGS_INVALID'});
});
