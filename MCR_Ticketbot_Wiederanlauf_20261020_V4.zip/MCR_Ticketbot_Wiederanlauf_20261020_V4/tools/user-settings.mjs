/* V4 user choices are UNTRACKED local data, not part of the sealed release.
 * Signed factory recovery-settings.json must remain unchanged for kit integrity.
 * Only known path fields are accepted and never copied into reports.
 */
import fs from 'node:fs';
import path from 'node:path';
import {atomicJson,readJson,demand} from './recovery-core.mjs';
const ALLOWED=new Set(['candidateRunner','installRoot','demoMappingPath']);
const valid=v=>typeof v==='string'&&v.length<=2048&&!v.includes('\0');
function validate(obj) {
  demand(obj && typeof obj==='object' && !Array.isArray(obj),'SETTINGS_INVALID','Einstellungen muessen ein JSON-Objekt sein.');
  for(const [k,v] of Object.entries(obj))demand(ALLOWED.has(k)&&valid(v),'SETTINGS_INVALID','Nicht unterstuetzte oder ungueltige Einstellung.');
  return obj;
}
export function loadRecoverySettings(kit) {
  const factory=validate(readJson(path.join(kit,'recovery-settings.json')));
  const localFile=path.join(kit,'recovery-settings.local.json');
  const user=fs.existsSync(localFile)?validate(readJson(localFile)):{};
  return {...factory,...user};
}
export function saveUserSettings(kit,update) {
  const localFile=path.join(kit,'recovery-settings.local.json');
  const before=fs.existsSync(localFile)?validate(readJson(localFile)):{};
  atomicJson(localFile,validate({...before,...validate(update)}));
}
