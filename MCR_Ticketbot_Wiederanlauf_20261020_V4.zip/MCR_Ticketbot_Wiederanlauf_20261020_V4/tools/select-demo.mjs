/* Optional fictional DEMO JSON picker. No live modifications or sending. */
import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {readJson,hashFile,inside,demand,readBytes} from './recovery-core.mjs';
import {verifyLegacyFictionalDemo} from './demo-assets.mjs';
import {saveUserSettings} from './user-settings.mjs';
const kit=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
function verifyKit(){const manifest=readJson(path.join(kit,'MANIFEST_SHA256.json'));
 demand(manifest.schema==='MCR_RECOVERY_KIT_MANIFEST_V1','KIT_MANIFEST');
 for(const [rel,expected]of Object.entries(manifest.files))demand(hashFile(inside(kit,rel))===expected,'KIT_CHANGED','Starterdateien wurden veraendert.');
}
function pick(){
 demand(process.platform==='win32','FILE_SELECTION_REQUIRED','Datei als Argument angeben.');
 const ps=path.join(process.env.SystemRoot||'C:\\Windows','System32','WindowsPowerShell','v1.0','powershell.exe');
 const script=["Add-Type -AssemblyName System.Windows.Forms",
 "$d = New-Object System.Windows.Forms.OpenFileDialog",
 "$d.Title = 'Urspruengliche FIKTIVE DEMO_mapping.json auswaehlen'",
 "$d.Filter = 'DEMO Mapping (DEMO_mapping.json)|DEMO_mapping.json|JSON (*.json)|*.json'",
 "$d.Multiselect = $false",
 "if ($d.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { [Console]::Out.Write($d.FileName) }"];
 const r=spawnSync(ps,['-NoProfile','-STA','-Command',script.join('; ')],{encoding:'utf8',windowsHide:false,timeout:180000,maxBuffer:1024*1024});
 demand(!r.error&&r.status===0,'PICKER_UNAVAILABLE','Dateiauswahl nicht verfuegbar. JSON auf DEMO_QUELLE_AUSWAEHLEN.cmd ziehen.');
 return r.stdout.replace(/^\uFEFF/,'').trim();
}
try{
 verifyKit();const selected=process.argv[2]||pick();
 demand(selected,'DEMO_SOURCE_NOT_SELECTED','Keine Datei ausgewaehlt. Kein Versand.');
 const file=path.resolve(selected);
 demand(path.basename(file).toLowerCase()==='demo_mapping.json','DEMO_SOURCE_INVALID','Nur eine Datei namens DEMO_mapping.json.');
 const s=fs.lstatSync(file);
 demand(s.isFile()&&!s.isSymbolicLink(),'DEMO_SOURCE_INVALID','Datei muss regulaer sein.');
 verifyLegacyFictionalDemo(readBytes(file,1024*1024));
 saveUserSettings(kit,{demoMappingPath:file});
 console.log('PASS  FICTIONAL_DEMO_PAYLOAD_SHA256_VERIFIED');
 console.log('PASS  DEMO_FILE_SELECTED');
 console.log('Keine Installation und kein echter Versand. Jetzt DEMO_TESTEN_OHNE_VERSAND.cmd starten.');
}catch(e){const code=/^[A-Z0-9_]+$/.test(e?.code||'')?e.code:'DEMO_FILE_SELECTION_FAILED';
 console.error('STOPP '+code+': '+String(e?.message||'Fehler').replace(/(?:[A-Z]:\\|\/Users\/|\/home\/)[^\r\n]*/gi,'[lokaler Pfad]'));
 console.error('Keine neue Demo-Quelle hinterlegt, kein Versand.');process.exitCode=1;}
