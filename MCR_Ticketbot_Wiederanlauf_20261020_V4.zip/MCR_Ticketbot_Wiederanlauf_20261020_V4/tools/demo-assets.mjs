/* MCR recovery V4: inspect only bounded, fictional LEGACY demo mapping bytes.
 * The historical c147... digest is NOT a hash of DEMO_mapping.json.
 * It is the runtime digest of makeMultirowMapping(...)'s NEW payload.
 * The input file contains its own payloadSha256, calculated over the ORIGINAL
 * legacy payload using JSON.stringify(obj.payload) (Node semantics).
 * No active mapping/Excel/browser/profile is ever copied into demo.
 */
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {sha,demand,inside,readBytes,walk} from './recovery-core.mjs';

export const DEMO_MAPPING_REL='examples/DEMO_mapping.json';
export const HISTORIC_DEMO_MULTIROW_SHA256='c147a9eb9c93d5c6d4a47f208c9f98c2afd0b0144cbf63b2c50b1c06676fdc40';
const MAX_FIXTURE_BYTES=1024*1024;
const FAKE_PERSON=/(?:mustermann|musterfrau|musterperson|beispiel|testperson|demoperson|fiktiv|fictional|sample|john\s+doe|jane\s+doe)/i;
const PRIVATE_SOURCE=/(?:mercer\.com|\\\\mercer\.|[A-Za-z]:\\[^"\r\n]*\b(?:INTL01_Gesamtdatenbestand|Bestand\s*Intel)|\bprivate_data[/\\]|\bactive-mapping\.json\b)/i;

function reject(code,message) {throw Object.assign(new Error(message),{code});}

/* The actual format used by the legacy runner's validateMappingObject:
 * Core.validateMap(obj) plus sha256(JSON.stringify(obj.payload)) === obj.payloadSha256.
 * We preflight that contract and verify fictional identity data; the original
 * runner performs its own validation once the file is in the isolated DEMO.
 */
export function verifyLegacyFictionalDemo(bytes) {
  demand(Buffer.isBuffer(bytes) && bytes.length>0 && bytes.length<=MAX_FIXTURE_BYTES,
    'DEMO_MAPPING_SIZE','Die Demo-Datei muss eine kleine, regulaere JSON-Datei sein.');
  let obj;
  try {obj=JSON.parse(bytes.toString('utf8').replace(/^\uFEFF/,''));}
  catch {reject('DEMO_MAPPING_JSON_INVALID','Die Demo-Datei enthaelt kein gueltiges JSON.');}
  if(!obj || typeof obj!=='object' || Array.isArray(obj) || typeof obj.schema!=='string' || !obj.schema.trim() ||
     !obj.payload || typeof obj.payload!=='object' || Array.isArray(obj.payload) ||
     !/^[a-f0-9]{64}$/i.test(String(obj.payloadSha256||''))) {
    reject('DEMO_MAPPING_LEGACY_SCHEMA','Die Demo-Datei hat nicht den erforderlichen alten Mapping-Vertrag schema/payload/payloadSha256.');
  }
  const actualPayloadSha256=sha(Buffer.from(JSON.stringify(obj.payload),'utf8'));
  if(actualPayloadSha256!==obj.payloadSha256.toLowerCase()) {
    reject('DEMO_MAPPING_PAYLOAD_INTEGRITY','Die interne Payload-SHA256 der Demo-Datei stimmt nicht. Nichts wurde uebernommen.');
  }
  // We require *fictional* persons throughout the fixture. A valid embedded
  // checksum by itself proves only consistency, not that the data is fake.
  const entries=obj.payload.entries;
  if(!entries || typeof entries!=='object' || Array.isArray(entries) ||
     Object.keys(entries).length<1 || Object.keys(entries).length>48) {
    reject('DEMO_MAPPING_ENTRIES','Die Demo-Eintraege entsprechen nicht dem kleinen fiktiven Legacy-Demoformat.');
  }
  const text=JSON.stringify(obj.payload);
  if(PRIVATE_SOURCE.test(text)) {
    reject('DEMO_MAPPING_PRIVATE_REFERENCE','Die Demo enthaelt einen Verweis auf private oder produktive Bestandsquellen.');
  }
  for(const [key,entry] of Object.entries(entries)) {
    if(!entry || typeof entry!=='object' || Array.isArray(entry) || !FAKE_PERSON.test(key+' '+JSON.stringify(entry))) {
      reject('DEMO_MAPPING_NOT_FICTIONAL','Nicht jeder Demo-Eintrag ist eindeutig als fiktive Person erkennbar. Keine Uebernahme.');
    }
  }
  return {fileSha256:sha(bytes),legacyPayloadSha256:actualPayloadSha256,entryCount:Object.keys(entries).length};
}

/**
 * V4 verifies a legacy demo's OWN payload integrity; never compares its raw
 * file SHA to HISTORIC_DEMO_MULTIROW_SHA256. The latter is tested against the
 * demo runner's freshly computed *transformed* mapping fingerprint.
 */
export function secureDemoMapping({installRoot,candidate,preloaded}) {
  if(preloaded.has(DEMO_MAPPING_REL)) {
    demand(candidate?.entries instanceof Map && candidate.entries.has(candidate.prefix+DEMO_MAPPING_REL),
      'DEMO_ASSET_UNTRUSTED','Vorab geladene Demo-Datei ist nicht an ein freigegebenes Originalarchiv gebunden.');
    const trusted=candidate.entries.get(candidate.prefix+DEMO_MAPPING_REL);
    demand(preloaded.get(DEMO_MAPPING_REL).equals(trusted),'DEMO_ASSET_UNTRUSTED',
      'Demo-Datei weicht vom Originalarchiv ab.');
    return {bytes:Buffer.from(trusted),source:'PINNED_RELEASE_ARCHIVE',integrity:verifyLegacyFictionalDemo(trusted)};
  }
  const pinnedSource=String(candidate?.filePath||'').trim();
  const previewRoot=pinnedSource && path.basename(pinnedSource).toLowerCase()==='local-bot-full-run.mjs'
    ? path.dirname(path.dirname(pinnedSource)) : null;
  const chosen=String(candidate?.demoMappingPath||'').trim();
  const hints=[inside(installRoot,DEMO_MAPPING_REL),
    ...(previewRoot?[path.join(previewRoot,DEMO_MAPPING_REL)]:[])];
  const home=os.homedir();
  const roots=[path.join(home,'Downloads'),path.join(home,'Documents'),path.join(home,'Desktop'),
    path.join(home,'projects','Aktive_Projekte','Ticket_bot')];
  const visited=new Set(); let bad=null; let observed=0;
  function accept(file) {
    const resolved=path.resolve(file),k=process.platform==='win32'?resolved.toLowerCase():resolved;
    if(visited.has(k))return null;visited.add(k);
    let stat;
    try {
      const parent=fs.lstatSync(path.dirname(file));stat=fs.lstatSync(file);
      if(!parent.isDirectory()||parent.isSymbolicLink()||!stat.isFile()||stat.isSymbolicLink()||
         stat.size<1||stat.size>MAX_FIXTURE_BYTES)return null;
    }catch{return null;}
    let bytes;try{bytes=readBytes(file,MAX_FIXTURE_BYTES);}catch{return null;}
    observed++;
    try {return {bytes,source:'VALIDATED_LOCAL_FICTIONAL_LEGACY_DEMO',integrity:verifyLegacyFictionalDemo(bytes)};}
    catch(e){bad=bad||e;return null;}
  }
  // An explicit operator-selected synthetic fixture wins over auto-discovery.
  // It is still fully checked; invalid choices are not silently ignored.
  if(chosen) {
    const selected=accept(path.resolve(chosen));
    if(selected)return selected;
    if(bad)throw bad;
    reject('DEMO_SELECTED_FILE_UNAVAILABLE','Die explizit ausgewaehlte Demo-Datei fehlt oder ist keine regulaere lokale Datei.');
  }
  for(const file of hints){const found=accept(file);if(found)return found;}
  for(const root of roots) {
    if(!fs.existsSync(root))continue;
    let list=[];
    try {list=walk(root,{maxDepth:9,maxFiles:20000});}
    catch(e){if(['SCAN_LIMIT','EACCES','EPERM'].includes(e.code))continue;throw e;}
    for(const file of list)if(path.basename(file).toLowerCase()==='demo_mapping.json') {
      const found=accept(file);if(found)return found;
    }
  }
  if(observed>0)throw bad;
  reject('DEMO_MAPPING_MISSING','Keine synthetische examples\\DEMO_mapping.json gefunden. Keinesfalls produktive Bestandsdaten verwenden.');
}
