[CmdletBinding()]
param(
    [string]$Level05Root = "C:\Users\Amaru-Zegarra\projects\Aktive_Projekte\New_Language_Benchmark\Level_05",
    [int]$Workers = 4
)

$ErrorActionPreference = 'Stop'
$PackageRoot = $PSScriptRoot
$ExpectedInputSha  = '5534444df25e1050e18012b78661ac6f9069f0c26d8f866c9d2344643d938c36'
$ExpectedGoldenSha = '078fdf618634632de329ebf250bede8b3a84ba7d7b604d8ec49f277ee2095e32'

Write-Host ''
Write-Host '======================================================================' -ForegroundColor Cyan
Write-Host ' LEVEL 05A.2 - R PARITY v0.1.10 QUICK START' -ForegroundColor Cyan
Write-Host '======================================================================' -ForegroundColor Cyan
Write-Host ''

$SpecPath = Join-Path $Level05Root 'tools\benchmark_spec.json'
$StatePath = Join-Path $Level05Root 'BENCHMARK_STATE.json'
$GoldenPath = Join-Path $Level05Root 'data\reference\MCR_LNW_001\GOLDEN_REFERENCE.json'
foreach ($p in @($Level05Root,$SpecPath,$StatePath,$GoldenPath)) {
    if (-not (Test-Path $p)) { throw "Benchmark-Basis fehlt: $p" }
}

$Spec = Get-Content $SpecPath -Raw | ConvertFrom-Json
$State = Get-Content $StatePath -Raw | ConvertFrom-Json
$Golden = Get-Content $GoldenPath -Raw | ConvertFrom-Json
if ($State.status -ne 'COMMON_INFRASTRUCTURE_READY') { throw '5A.1 ist nicht READY.' }
if ($Spec.case.input_sha256 -ne $ExpectedInputSha) { throw 'Frozen Input SHA stimmt nicht.' }
if ($Golden.overall_semantic_sha256 -ne $ExpectedGoldenSha) { throw 'Golden Semantic SHA stimmt nicht.' }
Write-Host '[1/4] Benchmark-Basis: PASS' -ForegroundColor Green

Write-Host '[2/4] Repariere Windows-PowerShell Argument-Forwarding im Common Harness...' -ForegroundColor Yellow
& (Join-Path $PackageRoot 'PATCH_HARNESS_5A2.ps1') -Level05Root $Level05Root

Write-Host '[3/4] Installiere + baue + starte Candidate...' -ForegroundColor Yellow
$OldPreference = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
try {
    & (Join-Path $PackageRoot 'INSTALL_5A2_R.ps1') -Level05Root $Level05Root -Workers $Workers -RunAfterInstall
    $InstallerExit = $LASTEXITCODE
}
finally { $ErrorActionPreference = $OldPreference }

Write-Host ''
Write-Host '[4/4] Letzten Result-Ordner auswerten...' -ForegroundColor Yellow
$ResultsRoot = Join-Path $Level05Root 'results\parity\r'
$Latest = Get-ChildItem $ResultsRoot -Directory -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -like 'run_*' } |
    Sort-Object LastWriteTime -Descending |
    Select-Object -First 1

if (-not $Latest) { throw "Kein R Result erzeugt. Installer ExitCode=$InstallerExit" }

$MetricsPath = Join-Path $Latest.FullName 'run_metrics.json'
$ValidationPath = Join-Path $Latest.FullName 'validation.json'
$StdoutPath = Join-Path $Latest.FullName 'stdout.log'
$StderrPath = Join-Path $Latest.FullName 'stderr.log'
$CandidateResultPath = Join-Path $Latest.FullName 'output\candidate_result.json'
$LauncherPath = Join-Path $Latest.FullName 'candidate_launcher.ps1'

Write-Host ''
Write-Host '======================================================================'
Write-Host ' R 5A.2 RESULT'
Write-Host '======================================================================'
Write-Host "Result: $($Latest.FullName)"

if (Test-Path $MetricsPath) {
    $M = Get-Content $MetricsPath -Raw | ConvertFrom-Json
    Write-Host "Status:       $($M.status)"
    Write-Host "Exit Code:    $($M.exit_code)"
    Write-Host "Wall Clock:   $($M.wall_clock_seconds) s"
    Write-Host "Peak RSS:     $($M.peak_candidate_process_tree_rss_mib) MiB"
    Write-Host "Validation:   $($M.validation_pass)"
    Write-Host "Semantic SHA: $($M.overall_semantic_sha256)"
}

if (Test-Path $ValidationPath) {
    $V = Get-Content $ValidationPath -Raw | ConvertFrom-Json
    Write-Host ''
    foreach ($Name in @('du_master','dp_master','lnw_excel','lnw_csv')) {
        $A = $V.artifacts.$Name
        if ($null -ne $A) {
            $S = if ($A.pass) { 'PASS' } else { 'FAIL' }
            Write-Host ('{0,-12} {1}' -f $Name,$S)
            if (-not $A.pass) {
                Write-Host "  Expected: $($A.expected_semantic_sha256)"
                Write-Host "  Actual:   $($A.actual_semantic_sha256)"
            }
        }
    }
    Write-Host ''
    Write-Host "Expected Overall: $($V.expected_overall_semantic_sha256)"
    Write-Host "Actual Overall:   $($V.overall_semantic_sha256)"
    Write-Host "FINAL:             $(if ($V.pass) {'PASS'} else {'FAIL'})"
}
else {
    Write-Host "validation.json: MISSING"
    Write-Host "candidate_result.json: $(if (Test-Path $CandidateResultPath) {'EXISTS'} else {'MISSING'})"
}

Write-Host ''
Write-Host "Launcher: $LauncherPath"
Write-Host '========================= STDOUT TAIL ========================='
if (Test-Path $StdoutPath) { Get-Content $StdoutPath -Tail 160 }
Write-Host ''
Write-Host '========================= STDERR TAIL ========================='
if ((Test-Path $StderrPath) -and ((Get-Item $StderrPath).Length -gt 0)) { Get-Content $StderrPath -Tail 200 }

# If only CSV parity still fails, produce a post-timer cell-level diagnostic.
if ((Test-Path $ValidationPath) -and (Test-Path $CandidateResultPath)) {
    $V2 = Get-Content $ValidationPath -Raw | ConvertFrom-Json
    if ((-not $V2.pass) -and $V2.artifacts.du_master.pass -and $V2.artifacts.dp_master.pass -and $V2.artifacts.lnw_excel.pass -and (-not $V2.artifacts.lnw_csv.pass)) {
        Write-Host ''
        Write-Host '====================== CSV PARITY DIAGNOSTIC ======================' -ForegroundColor Yellow
        $Python = & (Join-Path $Level05Root 'tools\harness\Resolve-ValidatorPython.ps1')
        & $Python (Join-Path $PackageRoot 'DIAGNOSE_CSV.py') --level05-root $Level05Root --result-root $Latest.FullName --max 30
        Write-Host '=================================================================='
    }
}
Write-Host '======================================================================'
Write-Host ''
