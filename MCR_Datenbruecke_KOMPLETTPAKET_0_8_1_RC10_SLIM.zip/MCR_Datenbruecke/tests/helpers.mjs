import fs from 'node:fs';import path from 'node:path';import os from 'node:os';import {fileURLToPath} from 'node:url';import {makeMultirowMapping,POLICY} from '../lib/multirow-tpp-mapping.mjs';import {sha256} from '../lib/core.mjs';
export const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
export const temp=()=>fs.mkdtempSync(path.join(os.tmpdir(),'MCR-UNIT-'));
export const row=(overrides={})=>({row:2,B:'99900001',C:0,D:1,E:0,F:1,L:'10',O:'M',formulas:[],errors:{},...overrides});
export function mapping(rows=[row(),row({row:10002,D:0,E:1,F:0})],options={}){return makeMultirowMapping({meta:{filename:'synthetic.xlsx',sheet:'Output',sha256:'a'.repeat(64)},allRows:()=>rows},{headerConfirmed:true,generatedAt:'2026-01-01T00:00:00.000Z',...options});}
export function putActive(root,map=mapping()){const d=path.join(root,'private_data');fs.mkdirSync(d,{recursive:true});const name='INTL01_mapping_multirow_test.json',raw=JSON.stringify(map,null,2)+'\n';fs.writeFileSync(path.join(d,name),raw);fs.writeFileSync(path.join(d,'active-mapping.json'),JSON.stringify({schema:'MCR_ACTIVE_MULTIROW_V1',mappingSchema:map.schema,duplicatePolicy:POLICY,file:name,sha256:sha256(raw),payloadSha256:map.payloadSha256,sourceSha256:map.payload.source.sha256}));return {name,map};}
export function demoProof(){return {mode:'DEMO',lastError:null,send:{htmlDialogs:2,jsDialogs:0},loop:{completed:true,finishReason:'NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS',processed:2,myTasksProcessed:1,queueProcessed:1,processedTickets:[{source:'IN_BEARBEITUNG',save:'MY_TASKS_ALL_DESCRIPTION_CONTENT_MATCH',sendAck:'HISTORY_INCREMENT',sourceRowCount:2,descriptionLineCount:2},{source:'WARTESCHLANGE_INTL01',save:'QUEUE_ALL_DESCRIPTION_CONTENT_MATCH',sendAck:'HISTORY_INCREMENT',sourceRowCount:2,descriptionLineCount:2}]},demoBrowser:{sendClicks:2,saveClicks:2,savedDescriptionsMatch:true,savedLineCounts:[2,2],trustedSends:[true,true],trustedSaves:[true,true]}};}

/** Historical release ZIPs are optional independent QA data, never runtime payload. */
export function historyFixture(name){
 const base=process.env.MCR_TEST_FIXTURE_DIR||path.join(ROOT,'tests','fixtures');
 return fs.readFileSync(path.join(base,name));
}
