"""Static checks only. Does not claim to compile or execute C#. Python stdlib only."""
from pathlib import Path
import csv, json, re, zipfile, xml.etree.ElementTree as ET, hashlib
ROOT=Path(__file__).resolve().parents[1]

def delimiter_check(text):
    stack=[];i=0;n=len(text)
    while i<n:
        if text.startswith('//',i):
            end=text.find('\n',i);i=n if end<0 else end+1;continue
        if text.startswith('/*',i):
            end=text.find('*/',i+2)
            if end<0:raise ValueError('Unterminated comment')
            i=end+2;continue
        # Raw triple-quoted literals used for XML/help text.
        if text.startswith('"""',i):
            end=text.find('"""',i+3)
            if end<0:raise ValueError('Unterminated raw string')
            i=end+3;continue
        if text[i] in ('"',"'"):
            quote=text[i];verbatim=i>0 and text[i-1]=='@';i+=1
            while i<n:
                if text[i]==quote:
                    if verbatim and i+1<n and text[i+1]==quote:i+=2;continue
                    i+=1;break
                if text[i]=='\\' and not verbatim:i+=2
                else:i+=1
            else:raise ValueError('Unterminated string/char')
            continue
        c=text[i]
        if c in '({[':stack.append((c,i))
        elif c in ')}]':
            if not stack or '({['[')}]'.index(c)]!=stack[-1][0]:raise ValueError(f'Unbalanced {c} at {i}')
            stack.pop()
        i+=1
    if stack:raise ValueError('Unclosed delimiters '+repr(stack))

cs=list(ROOT.rglob('*.cs'))
for path in cs:delimiter_check(path.read_text(encoding='utf-8'))
xml=list(ROOT.rglob('*.csproj'))+list(ROOT.glob('*.props'))+list(ROOT.glob('*.slnx'))+list(ROOT.glob('NuGet.Config'))+list(ROOT.rglob('*.manifest'))
for p in xml:ET.parse(p)
for p in ROOT.rglob('*.json'):json.loads(p.read_text(encoding='utf-8'))
for p in ROOT.rglob('*.cmd'):
    b=p.read_bytes();b.decode('ascii');assert not b.startswith(b'\xef\xbb\xbf');assert b'\n' not in b.replace(b'\r\n',b'')
for p in ROOT.rglob('*.csproj'):
    assert 'PackageReference' not in p.read_text(),p
for p in ROOT.rglob('*.cs'):
    assert not any(x in p.read_text() for x in ['HttpClient(', 'WebClient(', 'Process.Start("python', 'Kill(entireProcessTree', 'Registry.SetValue'])
# Validate synthetic fixture without running Excel.
ns={'x':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
with zipfile.ZipFile(ROOT/'examples/Bestand_Synthetisch.xlsx') as z:
    assert z.testzip() is None
    for name in z.namelist():
        if name.endswith('.xml') or name.endswith('.rels'):ET.fromstring(z.read(name))
    sh=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
    assert len(sh.findall('x:sheetData/x:row',ns))==13
    assert len(sh.findall('.//x:f',ns))==0
for p in (ROOT/'examples/Monatsdaten').glob('*.txt'):
    with p.open(encoding='cp1252',newline='') as f:
        rows=list(csv.DictReader(f,delimiter=';'))
    assert len(rows)==13 and len({r['KDMA_IDENT'] for r in rows})==12
v=json.loads((ROOT/'tests/golden_vectors.json').read_text())
assert len(v['contributions'])==6684 and len(v['rounding'])==5030
named=re.findall(r'Test\("(T\d+_[^"]+)"',(ROOT/'tests/Mcr.Ipp.Tests/Program.cs').read_text())
assert len(named)==180 and len(set(named))==180
# Pattern scan, not a guarantee of anonymization or security.
patterns=[r'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----',r'(?i)(?:api[_-]?key|password|secret)\s*[:=]\s*["\'][A-Za-z0-9_\-/+]{20,}']
findings=[]
for p in ROOT.rglob('*'):
    if not p.is_file() or p.suffix.lower() not in ['.cs','.cmd','.md','.json','.txt','.py']:continue
    if p.name=='check_package_sources.py':continue
    content=p.read_text(encoding='utf-8',errors='replace')
    for pattern in patterns:
        if re.search(pattern,content):findings.append(str(p.relative_to(ROOT)))
assert not findings,findings
report={'schema':'MCR_IPP_STATIC_CHECKS_V1','status':'PASS_STATIC_ONLY','csharpFilesChecked':len(cs),'csharpDelimiterBalance':'PASS_NOT_A_COMPILER','projectXmlParsed':len(xml),'batchEncoding':'ASCII_CRLF_NO_BOM','packageReferences':0,'namedCSharpTests':len(named),'formulaVectors':len(v['contributions']),'roundingVectors':len(v['rounding']),'syntheticWorkbookXmlAndZip':'PASS','syntheticTxtFiles':6,'secretPatternFindings':findings,'compilerExecuted':False,'cSharpTestsExecuted':False,'windowsUiExecuted':False,'excelComExecuted':False}
(ROOT/'evidence/static_checks.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
