# MCR IPP 0.3.1 - PDF-Abschlussfix (ATTC-Fix bleibt erhalten)

## Update / Start

1. MCR IPP schliessen. Bei eigenen Codeaenderungen vorher eine Sicherung anlegen.
2. ZIP in den bisherigen Projekt-Elternordner entpacken. `MCR_IPP` mit `MCR_IPP`
   zusammenfuehren und enthaltene Dateien ersetzen, KEIN `MCR_IPP/MCR_IPP` erzeugen.
3. `local`, `Output`, eigene Eingaben und den gemeinsamen Compiler behalten.
4. `START.cmd` doppelklicken. Kein PowerShell-Copy/Paste und keine Neuinstallation.
   Der gepruefte SDK-Resolver wird weiterverwendet:
   `%USERPROFILE%\projects\Compiler\csharp\tools\dotnet\dotnet.exe`.
5. Build + 180 C#-Tests laufen vor dem Start. Bei Fehlern: `evidence/local/DIAGNOSE.txt`.

## PDF-Abschlussfix

PDFs werden direkt unter `.inprogress_IPP_Run_.../PDF_Entwuerfe` geschrieben.
Ein zusätzlicher `.pdf_inprogress_...`-Ordner wird nicht mehr umbenannt oder gelöscht.
Erst nach Ergebnis-/Dokumentenplan-/Manifest-Erstellung wird der gesamte Lauf
unter `IPP_Run_...` abgeschlossen. Vorübergehende Zugriffsfehler an dieser letzten
Grenze werden begrenzt wiederholt; dauerhafte Fehler bleiben ausdrücklich Fehler.
Siehe **PDF_ABSCHLUSSFIX_LESEN.md**. Alten fehlgeschlagenen Lauf nicht manuell
als fertig umbenennen; mit den korrigierten Eingaben einen neuen Lauf starten.

## Ein neuer Lauf

- Bestandsvorlage mit ClientID, BaseSalary_1 und PartTimeFactor_1 auswaehlen.
- Monats-TXT-Dateien desselben Jahres auswaehlen.
- IPP-Dokumentvorlage ist separat OPTIONAL; nicht als Bestandsvorlage einsetzen.
- Checkbox `PDF-Beitragsentwuerfe je Bestandsperson` ist im Desktop aktiviert.
  Sie kann ausgeschaltet werden. Es sind INTERN gekennzeichnete Monatsberichte,
  KEINE Leistungsnachweise oder Unverfallbarkeitsbescheinigungen.
- `Beitraege erstellen` startet die gesamte Auswahl in einem neuen Laufordner.

ATTC bleibt bei offener Tarifpruefung erhalten: zuerst passende TXT-Zeile,
sonst im Januar BaseSalary_1, sonst der vorhandene direkte Vormonat.
Bekannte Tarifklassen 98/99 sowie Eintritts-/Austrittsfilter bleiben wirksam.
Ein unbekannter Tarif wird NICHT ergaenzt. Der Betrag dieses Monats bleibt leer.
Das ist eine bewusste Abweichung vom Python-Betrag bei unbekanntem Tarif,
aber keine Gehaltsloeschung mehr. Vollstaendige Python-Paritaet ist nicht zertifiziert.

## Ergebnisse

- Ergebnis.xlsx: ATTC-Fallback korrigiert; gelb markierte Gehalts-/Betragsfelder
  stehen weiterhin unter Tarifpruefung. Gelbes ATTC kann jetzt einen Wert enthalten.
- Contribution_Result.json: Gehalt, Herkunft, Betragstatus, Eingabehashes und Prueffaelle.
- Monatsprotokoll.csv: ATTC-/TZG-Herkunft, Tarifstatus und neuer `Betrag_Status`.
- Prueffaelle.xlsx / Personen_Pruefung.json: Unbekannte Personen unveraendert pruefen.
- Tarifpruefung.xlsx / Tarif_Pruefung.json: Tarifklaerung getrennt vom Gehaltswert.
- Dokumentenplan.xlsx / .json: eine dokumentierte Zuordnung je Ergebnisperson sowie
  Eintraege fuer nicht aufgenommene Personen; PDF-Datei, Status und Hash.
- PDF_Entwuerfe/ENTWURF_IPP_Beitraege_<ClientID>_<Jahr>.pdf:
  interne Monatsuebersicht je Ergebnisperson, auch bei offenen Tarifmonaten.
- 00_LAUF_LESEN.txt: Laufstatus, offene Faelle, Entwurfszahl und PDF-Fehler.
- Manifest.json: rekursive Dateihashes einschliesslich aller PDF-Entwuerfe.

Nicht aufgenommene TXT-Personen erhalten KEIN PDF. Sie bleiben im Dokumentenplan.
Nicht darstellbare Namenszeichen werden nicht ersetzt: der betreffende PDF-Fall
wird mit Fehler ausgewiesen, andere PDFs laufen weiter. JSON und Excel bleiben erhalten.

Die PDF-Entwuerfe benoetigen kein Excel, keinen Druckertreiber und keine neue Bibliothek.
Schriftumfang: Windows-1252. Mehrseitige Dokumente behalten auf jeder Seite den
Entwurfs-/Nichtversenden-Hinweis. Nicht PDF/A und nicht barrierefrei zertifiziert.

Eine Summe gibt es nur, wenn ALLE ausgewaehlten Monatsbetraege numerisch vorliegen.
Sie heisst Rechensumme dieser Monatsbetraege und ist KEINE Beitragsbereitstellung.
Bei einem leeren/gesperrten/ausgenommenen Monatsbetrag wird KEINE Gesamtsumme gebildet.

## IPP-Vorlage und echte Bescheinigungen

Eine optional erstellte IPP_VORBEREITUNG-Kopie enthaelt weiterhin nur zusaetzliche
MCR_Beitraege-/MCR_Status-Blaetter. Bestehende Imports/Formeln/Salden werden NICHT
neu befuellt. Keine offizielle LNW-Excel ist dadurch aktualisiert.
Die neuen PDFs lesen KEINE alten Importdaten dieser Vorlagenkopie.
Sie werden ausschliesslich aus dem frischen Beitrags-Snapshot dieses Laufs erstellt.

Der vorhandene Excel-COM-Entwickleradapter bleibt separat und unveraendert gesperrt,
solange seine Voraussetzungen nicht erfuellt sind. `PDF_VORSCHAU_ENTWICKLUNG.cmd`
ist NICHT der neue normale PDF-Beitragsentwurfsweg.

Siehe `ATTC_FIX_UND_PDF_LESEN.md` und `docs/NAECHSTER_WORKSTREAM.md`.

## Was hier getestet wurde

Statische Quell-/XML-Pruefungen, unabhängige Modelltests, PDF-Modell-Rendering und
ZIP-Integritaet. In der Erstellungsumgebung konnte C# nicht kompiliert werden:
kein .NET-SDK; Downloadversuch scheiterte am Netzwerk. Keine Tests auf Ihrem Rechner
wurden aus der Ferne gestartet. `START.cmd` muss den lokalen Build/Testnachweis liefern.
180 enthaltene Tests sind KEINE Behauptung von 180 hier bestandenen C#-Tests.

Nur erfundene Demo-Daten im Paket. Pruefberichte von echten Laeufen enthalten
personenbezogene Daten und duerfen nicht ungeprueft weitergegeben werden.
