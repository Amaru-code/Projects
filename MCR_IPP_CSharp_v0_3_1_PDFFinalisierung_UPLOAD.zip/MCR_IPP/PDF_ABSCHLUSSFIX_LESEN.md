# MCR IPP 0.3.1 – Abschluss nach PDF-Erstellung

## Anlass und nachgewiesene Grenze

Das Nutzerfoto meldet 1040/1040 interne Entwürfe und 0 PDF-Prüffälle, danach
`IOException: Access to the path ... .pdf_inprogress_... is denied`.
Das ist kein Nachweis eines abgeschlossenen Gesamtlaufs. Der genaue Prozess oder
die genaue Windows-Berechtigung hinter dem Zugriffsfehler ist nicht identifiziert.

V0.3.0 schrieb die PDFs in einen Unterordner `.pdf_inprogress_...` und benannte
anschließend diesen Ordner in `PDF_Entwuerfe` um. Zusätzlich wurde später der
äußere `.inprogress_IPP_Run_...`-Ordner umbenannt. Die innere Umbenennung war
für die äußere Veröffentlichung unnötig. Bei ihrem Scheitern versuchte ein
`finally` zusätzlich, den inneren Ordner rekursiv zu löschen; das konnte fertige
Entwürfe entfernen oder die ursprüngliche Fehlermeldung durch einen Löschfehler
verdecken. Ein solcher Zugriff ist in .NET u.a. bei anderweitig geöffneten
Verzeichnissen/Dateien oder unzureichenden Rechten möglich:
https://learn.microsoft.com/en-us/dotnet/api/system.io.directory.move?view=net-10.0

## Änderung

1. Direktes Schreiben nach `PDF_Entwuerfe` innerhalb des weiterhin unfertigen
   `.inprogress_IPP_Run_...`. Kein inneres `Directory.Move`, kein inneres Löschen.
2. PDF-Schreibhandles werden vor dem nächsten Schritt geflusht und geschlossen.
3. Bei Fehler/Abbruch bleibt vorhandene PDF-Evidenz erhalten. Ein verfügbarer
   `Dokumentenplan_Zwischenstand.json` wird als `INTERRUPTED_NOT_PUBLISHED`
   gespeichert. Ein Fehler beim Schreiben dieser Diagnose verdeckt den ersten
   Fehler nicht.
4. Der äußere Laufabschluss erfolgt weiterhin erst nach allen Ergebnisdateien
   und dem rekursiven Hashmanifest. Zugriffs-/Sharing-/Lockcodes 5/32/33 werden
   maximal sechsmal versucht; insgesamt 4,65 s Wartezeit. Andere Fehler sowie
   vorhandene Ziele führen ohne Umgehung zum Abbruch. Abbruch ist während der
   Wartezeit möglich.
5. Hash-Lesefehler haben ebenfalls begrenzte Wiederholungen. Fehlende Hashes werden
   nicht als Erfolg behandelt.
6. FAILED.json enthält nun Phase, ursprünglichen Stacktrace, HRESULT und
   verfügbare Quell-/Ziel-/Versuchsinformationen. Bei Dauerfehler kein PASS.
7. Ein reiner Anzeige-/Logcallback nach erfolgreichem Abschluss darf keinen
   zweiten Fehlstatus erzeugen oder ein bereits abgeschlossenes Stage-Verzeichnis
   wieder anlegen.

`1040 PDF-Entwürfe geschrieben` bedeutet weiterhin nicht `1040 freigegebene LNW`.
Keine Dateien verschicken. Tarif-/Personenfälle und das offene IPP-Mapping bleiben
unverändert.

## Nicht geändert

Beitragsformeln, Rundungen, BaseSalary_1-/Vormonats-Fallback, negative-ATTC-Prüfung,
Tarifregeln, Personenbestätigungen, PDF-Inhalte/-Layout, SDK-Resolver und die
IPP/Produktionsgrenzen. Der Nutzer hat den zuvor gefundenen negativen ATTC als
Datenfehler eingeordnet. Es wird keine negative Korrekturrechnung eingeführt.

## Installation und nächster Lauf

MCR schließen. Den ZIP-Ordner `MCR_IPP` mit dem vorhandenen gleichnamigen Ordner
zusammenführen; enthaltene Projektdateien ersetzen. Eigene Codeänderungen sichern.
`local`, `Output`, Eingaben und gemeinsamen Compiler behalten. Kein verschachtelter
`MCR_IPP/MCR_IPP`-Ordner. `START.cmd` baut und führt 180 Tests aus.
Danach dieselben korrigierten Eingaben in einem neuen Lauf verwenden.

Laufdateien während des Schreibens nicht im Vorschau-/Editorfenster offen halten.
Ein dauerhaftes Berechtigungsproblem wird dadurch nicht automatisch repariert:
Keine Administratorrechte/ACL-Änderungen, kein Abschalten von Sicherheitssoftware.
Bei erneuter Störung bleibt der noch unfertige Ordner zur Diagnose erhalten.

V0.3.1 rekonstruiert keine möglicherweise von V0.3.0 gelöschten Entwürfe. Alte
`.inprogress_`-Ordner nicht als fertige Läufe umbenennen. Ein Neulauf liest die
Eingaben erneut und schreibt neue, eindeutig zugeordnete Ausgaben.

## Prüfstatus

180 C#-Testdefinitionen enthalten, hier nicht kompiliert oder ausgeführt.
163/164 alte Testblöcke unverändert; T158 erhält die neue, explizite
Beweiserhaltungs-Erwartung. 16 neue Tests, darunter simulierte temporäre/permanente
I/O-Fehler, Kollisionen, Abbruch, Planfehler, Hashprüfung und ein In-Memory-
PDF-Stresstest. Die injizierten Fehler sind keine Windows-Locks.

Hier geprüft: statische C#-Delimiter-/Projekt-/Syntaxform-Prüfungen, unveränderte
Kern-/Referenzdateien, unabhängiges Python-Veröffentlichungsmodell und ZIP-
Integrität. Das Modell führt den C#-Code nicht aus. Der gemeinsame lokale
.NET-10-SDK wird nicht ersetzt oder automatisch heruntergeladen.
