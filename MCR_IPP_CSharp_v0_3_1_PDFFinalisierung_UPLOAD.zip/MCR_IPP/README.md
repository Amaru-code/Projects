# MCR IPP 0.3.1 – PDF-Abschlussfix

C#/.NET 10, WinForms + CLI, gemeinsame portable SDK-Installation, keine NuGet-Pakete
und kein Python im Produktionspfad. Nur IPP, nicht DC.

Siehe **PDF_ABSCHLUSSFIX_LESEN.md** für die technische Änderung nach dem PDF-Lauf.
Negative ATTC-Werte werden weiterhin abgewiesen; keine neue Korrekturregel.

Siehe **START_HIER.md** fuer Update/Start und **ATTC_FIX_UND_PDF_LESEN.md** fuer die
korrigierte ATTC-Logik und die Grenzen der neuen Monats-PDF-Entwuerfe.

Desktop: `START.cmd`. Vor dem Start: Offline-Restore, Build, 180 Testdefinitionen
mit 11.714 Geld-/Rundungsreferenzvektoren. Das sind lokale Pruefungen, keine Garantie
vollstaendiger Realdaten- oder fachlicher Paritaet.

CLI-Beispiel nach Build:
```
dotnet exec src/Mcr.Ipp.Cli/bin/Release/net10.0/Mcr.Ipp.Cli.dll contribute --baseline Bestand.xlsx --txt Aenderungen_012026.txt --out Output --draft-pdfs true
```

Nutzen Sie auf Ihrem Rechner die vom Starter aufgeloeste gemeinsame dotnet.exe.
CLI-Code 0 = technisch exportiert, 4 = Export mit offenen Personen-/Tarif-/PDF-Faellen,
3 = gesperrte IPP-Vorlage, 2 = Fehler. Keine dieser Zahlen ist eine Versandfreigabe.

Originaldateien bleiben unveraendert. Die vorbereitete IPP-Datei hat nur Zusatzblaetter;
keine produktive LNW-Excel-Aktualisierung. PDFs sind interne Beitragsuebersichten
mit Entwurfskennzeichnung, kein Ersatz fuer IPP-Bescheinigungen.

## Erstellungsnachweis

`evidence/verification.json` beschreibt exakt die hier ausgefuehrten Pruefungen.
Hier fehlte das .NET-SDK. Ein Downloadversuch war wegen nicht verfuegbarer
Netzwerkaufloesung erfolglos. Der neue C#-Build und die WinForms-Ausfuehrung sind
NICHT hier erfolgt. Keine Software wird auf dem Benutzerrechner heruntergeladen.
Die beigestellte PDF-Modellpruefung ist eine Layout-/Syntax-Modellpruefung, kein C#-Test.

`evidence/history` enthaelt historische Angaben, nicht den aktuellen Buildnachweis.
Neue lokale Buildberichte liegen unter `evidence/local`.
