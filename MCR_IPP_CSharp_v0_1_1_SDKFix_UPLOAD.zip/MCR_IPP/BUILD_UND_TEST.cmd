@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "ERRORLEVEL="
cd /d "%~dp0"
if not "%errorlevel%"=="0" exit /b 1
set "IPP_STAGE=INIT"
set "IPP_RC=1"
set "IPP_SDK_RC=NOT_RUN"
set "IPP_RESTORE_RC=NOT_RUN"
set "IPP_BUILD_RC=NOT_RUN"
set "IPP_TEST_RC=NOT_RUN"
set "IPP_DOTNET_IN_USE=NOT_SELECTED"
set "IPP_SDK_IN_USE=NOT_SELECTED"
if not exist "evidence\local\runs" mkdir "evidence\local\runs"
if not exist "evidence\local\runs" goto init_failed
:new_run
set "IPP_RUN_ID=%RANDOM%_%RANDOM%_%RANDOM%"
set "IPP_LOG_DIR=%CD%\evidence\local\runs\%IPP_RUN_ID%"
if exist "%IPP_LOG_DIR%" goto new_run
mkdir "%IPP_LOG_DIR%"
if not "%errorlevel%"=="0" goto init_failed
>"evidence\local\LATEST_RUN.txt" echo %IPP_LOG_DIR%
>"evidence\local\DIAGNOSE.txt" echo STATUS=RUNNING
>>"evidence\local\DIAGNOSE.txt" echo RUN_ID=%IPP_RUN_ID%
>"%IPP_LOG_DIR%\build.log" echo BUILD_STEPS=NOT_STARTED
>"%IPP_LOG_DIR%\tests.log" echo TESTS=NOT_RUN

set "IPP_STAGE=SDK"
call scripts\SDK.cmd
set "IPP_RC=%errorlevel%"
set "IPP_SDK_RC=%IPP_RC%"
if not "%IPP_RC%"=="0" goto failed
set "IPP_DOTNET_IN_USE=%IPP_DOTNET%"
set "IPP_SDK_IN_USE=%IPP_SDK_VERSION%"

set "IPP_STAGE=RESTORE"
echo MCR IPP: Offline-Restore mit dem geprueften vorhandenen SDK...
"%IPP_DOTNET%" restore MCR_IPP.slnx --configfile NuGet.Config --ignore-failed-sources -p:NuGetAudit=false >"%IPP_LOG_DIR%\build.log" 2>&1
set "IPP_RC=%errorlevel%"
set "IPP_RESTORE_RC=%IPP_RC%"
if not "%IPP_RC%"=="0" goto failed

set "IPP_STAGE=BUILD"
echo MCR IPP: CSharp-Build...
"%IPP_DOTNET%" build MCR_IPP.slnx --no-restore --configuration Release --nologo -p:UseSharedCompilation=false >>"%IPP_LOG_DIR%\build.log" 2>&1
set "IPP_RC=%errorlevel%"
set "IPP_BUILD_RC=%IPP_RC%"
if not "%IPP_RC%"=="0" goto failed

set "IPP_STAGE=TESTS"
if not exist "tests\Mcr.Ipp.Tests\bin\Release\net10.0\Mcr.Ipp.Tests.dll" goto missing_test
rem Preserve prior CSharp reports; never present them as this run's test result.
if exist "evidence\local\csharp_tests.json" move /y "evidence\local\csharp_tests.json" "%IPP_LOG_DIR%\previous_csharp_tests.json" >nul
if exist "evidence\local\csharp_tests.json" goto stale_test
if exist "evidence\local\csharp_tests.junit.xml" move /y "evidence\local\csharp_tests.junit.xml" "%IPP_LOG_DIR%\previous_csharp_tests.junit.xml" >nul
if exist "evidence\local\csharp_tests.junit.xml" goto stale_test
echo MCR IPP: CSharp-Tests und Referenzvektoren...
"%IPP_DOTNET%" exec "tests\Mcr.Ipp.Tests\bin\Release\net10.0\Mcr.Ipp.Tests.dll" "%CD%" >"%IPP_LOG_DIR%\tests.log" 2>&1
set "IPP_RC=%errorlevel%"
set "IPP_TEST_RC=%IPP_RC%"
if not "%IPP_RC%"=="0" goto failed
if not exist "evidence\local\csharp_tests.json" goto missing_report
if not exist "evidence\local\csharp_tests.junit.xml" goto missing_report
set "IPP_STAGE=COMPLETE"
set "IPP_STATUS=BUILD_AND_TESTS_PASS"
call :report
type "%IPP_LOG_DIR%\tests.log"
echo.
echo Build und enthaltene Tests PASS. Keine wirtschaftliche IPP/PDF-Freigabe.
echo Bericht: %CD%\evidence\local\DIAGNOSE.txt
rem Keep the validated host for START/DEMO; do not resolve a different host again.
endlocal & set "IPP_DOTNET=%IPP_DOTNET%" & set "DOTNET_ROOT=%DOTNET_ROOT%" & set "DOTNET_HOST_PATH=%IPP_DOTNET%" & exit /b 0

:missing_test
set "IPP_RC=2"
>>"%IPP_LOG_DIR%\tests.log" echo TEST_DLL_MISSING
 goto failed
:stale_test
set "IPP_RC=2"
>>"%IPP_LOG_DIR%\tests.log" echo PREVIOUS_TEST_REPORT_COULD_NOT_BE_ARCHIVED
 goto failed
:missing_report
set "IPP_RC=2"
>>"%IPP_LOG_DIR%\tests.log" echo CURRENT_TEST_REPORT_MISSING
 goto failed
:failed
set "IPP_STATUS=FAILED"
call :report
echo.
echo ABBRUCH: %IPP_STAGE% - Exitcode %IPP_RC%
echo Nachfolgende Build-/Test-/UI-Schritte werden nicht gestartet.
echo Diagnose: %CD%\evidence\local\DIAGNOSE.txt
type "%IPP_LOG_DIR%\build.log"
type "%IPP_LOG_DIR%\tests.log"
exit /b 1
:init_failed
echo Diagnoseordner konnte nicht erstellt werden. Kein Build und kein UI-Start.
exit /b 1

:report
>"evidence\local\DIAGNOSE.txt" echo MCR_IPP_BUILD_LAUNCHER=0.1.1
>>"evidence\local\DIAGNOSE.txt" echo STATUS=%IPP_STATUS%
>>"evidence\local\DIAGNOSE.txt" echo RUN_ID=%IPP_RUN_ID%
>>"evidence\local\DIAGNOSE.txt" echo TIME=%DATE% %TIME%
>>"evidence\local\DIAGNOSE.txt" echo STAGE=%IPP_STAGE%
>>"evidence\local\DIAGNOSE.txt" echo DOTNET_EXE=%IPP_DOTNET_IN_USE%
>>"evidence\local\DIAGNOSE.txt" echo SDK_VERSION=%IPP_SDK_IN_USE%
>>"evidence\local\DIAGNOSE.txt" echo SDK_EXIT=%IPP_SDK_RC%
>>"evidence\local\DIAGNOSE.txt" echo RESTORE_EXIT=%IPP_RESTORE_RC%
>>"evidence\local\DIAGNOSE.txt" echo BUILD_EXIT=%IPP_BUILD_RC%
>>"evidence\local\DIAGNOSE.txt" echo TESTS_EXIT=%IPP_TEST_RC%
>>"evidence\local\DIAGNOSE.txt" echo LAST_EXIT=%IPP_RC%
>>"evidence\local\DIAGNOSE.txt" echo IPP_PRODUCTION_PDF_AUTHORIZED=false
>>"evidence\local\DIAGNOSE.txt" echo LOG_DIR=%IPP_LOG_DIR%
>>"evidence\local\DIAGNOSE.txt" echo.
>>"evidence\local\DIAGNOSE.txt" echo === SDK ===
if exist "%IPP_LOG_DIR%\sdk_resolution.log" type "%IPP_LOG_DIR%\sdk_resolution.log" >>"evidence\local\DIAGNOSE.txt"
>>"evidence\local\DIAGNOSE.txt" echo === RESTORE / BUILD ===
type "%IPP_LOG_DIR%\build.log" >>"evidence\local\DIAGNOSE.txt"
>>"evidence\local\DIAGNOSE.txt" echo === CSHARP TESTS ===
type "%IPP_LOG_DIR%\tests.log" >>"evidence\local\DIAGNOSE.txt"
copy /y "evidence\local\DIAGNOSE.txt" "%IPP_LOG_DIR%\DIAGNOSE.txt" >nul
rem Compatibility copies; source of truth is the uniquely named current run.
copy /y "%IPP_LOG_DIR%\build.log" "evidence\local\build.log" >nul
copy /y "%IPP_LOG_DIR%\tests.log" "evidence\local\tests.log" >nul
if not "%IPP_TEST_RC%"=="NOT_RUN" if exist "evidence\local\csharp_tests.json" copy /y "evidence\local\csharp_tests.json" "%IPP_LOG_DIR%\csharp_tests.json" >nul
if not "%IPP_TEST_RC%"=="NOT_RUN" if exist "evidence\local\csharp_tests.junit.xml" copy /y "evidence\local\csharp_tests.junit.xml" "%IPP_LOG_DIR%\csharp_tests.junit.xml" >nul
exit /b 0
