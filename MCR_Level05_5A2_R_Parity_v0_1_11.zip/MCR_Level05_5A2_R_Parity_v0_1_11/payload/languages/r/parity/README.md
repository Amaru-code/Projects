# Level 05A.2 – R Mode 1 Parity v0.1.0

Independent base-R implementation of the frozen LNW DC pipeline.

- existing `Rscript.exe`
- base/recommended R only; no external R packages
- no generated native candidate EXE
- no Python/C#/Rust/Node/Ruby/Julia/Java worker
- DU/DP parsing, company filtering, WWID mapping, merge and LNW aggregation in R
- PowerShell/.NET is used only as a workbook-I/O bridge for XLSX serialization and Excel COM recalculation/CSV output

The converted DU/DP files and both masters are materialized as XLSX files using a minimal OOXML writer in the I/O bridge; business rules remain in R.


## v0.1.1

Runtime bootstrap fix.

If no `Rscript.exe` is installed, the build now downloads the portable Windows
R 4.6.1 ZIP from Posit's R builds CDN and extracts it under:

`~/projects/Compiler/r/tools/R-4.6.1`

No installer is executed, no registry entries are required, and no new native
candidate executable is compiled. The benchmark still executes `main.R` through
the prebuilt `Rscript.exe` runtime and uses only base/recommended R.


## v0.1.2

Portable R runtime-detection fix.

The v0.1.1 bootstrap successfully downloaded and extracted R 4.6.1, but its
runtime test accepted only banners containing `R scripting front-end` or the
literal contiguous text `R version`. Some Windows R builds report
`Rscript (R) version ...`, which caused a false negative even when
`Rscript.exe --version` succeeded.

v0.1.2 accepts the normal R/Rscript version-banner variants and additionally
prints the direct exit code/banner if a genuine runtime launch failure occurs.

No R business logic, benchmark data, Golden Reference, validator, or output
contract changed.


## v0.1.4

Windows PowerShell 5.1 BOM fix for the temporary R source-check script.

The R 4.6.1 runtime itself is healthy and `main.R` is already plain UTF-8
without BOM. The failure came from `_source_check.R`: Windows PowerShell 5.1
writes `Set-Content -Encoding UTF8` with a UTF-8 BOM, and this R build rejected
that BOM as an unexpected input character.

v0.1.4 writes the tiny ASCII-only checker as ASCII (and the runtime pointer as
ASCII). No R business logic, benchmark data, Golden Reference, validator,
Excel bridge, or output contract changed.


## v0.1.5 – parser performance architecture fix

The first complete R execution attempt proved the implementation was
functionally progressing, but the DU parser was far too slow: it processed
every input line character-by-character in interpreted R and repeatedly
concatenated strings with `paste0`.

v0.1.5 replaces the normal delimited-text path with native R parsing:

- `utils::count.fields()` determines row width.
- `utils::read.table(..., colClasses="character")` performs quote-aware parsing.
- cell cleanup is vectorized over a character matrix.
- the previous parser remains as a fail-safe fallback for malformed edge cases.
- `parse_delimited_line()` also has a native `strsplit()` fast path when no
  quotes are present.

No business rules, company filter, WWID mapping, merge semantics, LNW logic,
Golden Reference, validator, Excel bridge, or output contract changed.


## v0.1.6 – full-run performance + TSV robustness

The v0.1.5 run proved that R reached all 252 DU inputs but still spent about
79 minutes before failing on the first empty intermediate TSV/XLSX conversion.

v0.1.6 changes architecture without changing business semantics:

1. **Early vectorized company filtering**: raw files are read into a character
   matrix, company-ID rows are selected in vectorized/native R code, and only
   the tiny retained subset enters expensive row-by-row normalization and WWID
   mapping.
2. **No 252 intermediate XLSX files**: conversion and merge remain logically
   separate but the converted tables stay in memory; only the validated
   `DU_MASTER.xlsx` and `DP_MASTER.xlsx` are materialized.
3. **Legacy parser fallback** remains active for malformed edge cases.
4. **25-file performance guard** aborts automatically if the optimized parser
   still projects an excessive runtime (>5 s/file after 25 files).
5. **Zero-row TSV headers** are parsed directly in PowerShell, fixing the
   `Could not parse TSV header` failure.
6. The build preflight no longer prints the entire parsed R expression.

Golden Reference, company rules, WWID mapping, merge alignment, LNW logic,
Excel recalculation and validator contracts are unchanged.


## v0.1.7 – raw-line prefilter

v0.1.6 still measured ~26.7 s/file, which showed that fully parsing each raw
daily extract remained the dominant cost.

v0.1.7 changes the hot path before parsing:
- read the raw text once;
- retain the first 120 non-empty lines for exact metadata/header discovery;
- retain every line containing any allowed company ID (case-insensitive);
- parse only that small shortlist;
- then pass the shortlisted rows through the existing `extract_table()` logic,
  including the exact field-level `find_allowed_company_id()` check, WWID
  mapping, header rules and target mapping.

The substring scan cannot change company-filter semantics: it is only a
superset shortlist. False positives are rejected by the original exact field
check; an exact allowed company field cannot be missed because it contains the
literal company ID.

The complete legacy parser remains the fallback and now prints
`[R-PARSER-FALLBACK]` with the reason if it is ever used.

Performance guards:
- after 5 files: abort if >10 s/file;
- after 25 files: abort if >5 s/file.

The build source-check output is also fully redirected, eliminating the giant
parsed-expression console dump.


## v0.1.8 – connection I/O + PSOCK parallel parsing

The v0.1.7 guard measured 8.873 s/file wall after 25 files. The remaining hot
path still read each file as one giant raw/string object and then split it.

v0.1.8:
- uses connection-based `readLines()` I/O with UTF-8 -> CP1252 fallback;
- scans only the first 1000 physical lines for header/noise context;
- shortlists candidate rows with two fixed-prefix scans (`MERCER_`, `INTEL`);
- keeps the original exact field-level allowed-company check authoritative;
- actually uses the benchmark's four workers via base-R PSOCK
  `parallel::parLapplyLB`;
- merges results in deterministic original source order;
- reports performance after the first parallel batch and aborts immediately
  if wall-time is still excessive;
- retains the full legacy parser as correctness fallback and reports every
  fallback explicitly.

No native candidate executable is created.


## v0.1.9 – complete certification run policy

v0.1.8 reached 200/252 DU files at 4.211 s/file wall with a projected DU parse
time of ~17.7 minutes, but the diagnostic guard still aborted because its
post-25-file threshold was intentionally too strict.

v0.1.9 keeps the exact v0.1.8 parser and four-worker PSOCK implementation
unchanged. Only the diagnostic policy changes:

- early abort only if the first parallel batch exceeds 10 s/file wall;
- during the full run, abort only if projected DU parse time exceeds 30 minutes;
- progress/performance is reported every 32 parsed DU files.

This lets R finish once so correctness can finally be validated, while still
protecting against a regression back to the 60–100 minute behavior seen in the
earlier prototypes.

No business logic, parser semantics, company rules, WWID mapping, merge logic,
Excel bridge, Golden Reference, or validator contract changed.


## v0.1.10 – case-insensitive shortlist correctness fix

The first complete v0.1.9 run finally reached semantic validation and exposed
the real defect:

- DU master: 1511 rows instead of 2872
- DP master: 2 rows instead of 2096
- DU/DP/LNW Excel hashes: FAIL
- LNW CSV: PASS

The runtime also printed the decisive warning:
`ignore.case = TRUE` is ignored when `grep(..., fixed=TRUE)` is used.

That made the optimized company shortlist accidentally case-sensitive, so
lowercase/mixed-case company-ID rows were discarded before the exact business
filter could inspect them.

v0.1.10 upper-cases the raw lines once and then performs the same fixed scans.
The existing exact field-level company validation remains authoritative.

Frozen row-count gates (2872 DU / 2096 DP) are now checked before LNW. If the
parser is still wrong, the run stops before Excel/LNW instead of wasting more
time.

No Golden Reference, WWID mapping, LNW business logic, Excel formulas, or
validator contract changed.


## v0.1.11 – legacy newline semantics + DP-first canary

v0.1.10 proved that case normalization was not the root cause: the exact same
1511 DU / 2 DP rows remained.

The remaining architectural difference from the certified Python/JavaScript
parsers was newline handling. v0.1.8-v0.1.10 used R `readLines()`, while the
certified implementations read the complete text and normalize both CRLF and
**lone CR** record separators before splitting. Legacy Mercer exports can use
non-LF line endings, so treating such a file as one/few giant lines destroys
row semantics before company filtering.

v0.1.11 therefore:
- reuses the existing encoding-fallback reader;
- normalizes `CRLF -> LF` and `CR -> LF`;
- then performs the optimized company shortlist;
- keeps the v0.1.8+ four-worker PSOCK path for DU;
- runs the single DP file **first** as a frozen semantic canary;
- requires exactly 2096 DP rows before the 252-file DU stage may start;
- prints DP normalized-line / shortlist counts for diagnosis.

If DP still does not produce 2096 rows, the run now stops after the DP canary
instead of spending ~25 minutes on DU.

No business rules, exact company-ID validation, WWID mapping, target mapping,
LNW logic, Golden Reference, Excel formulas, or validator contract changed.
