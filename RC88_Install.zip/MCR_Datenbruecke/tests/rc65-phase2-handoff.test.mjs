import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';
import {sha256} from '../lib/core.mjs';
import {ledger} from '../lib/control.mjs';
import {phase2HandoffStatus,phase2IntakeSummary} from '../lib/phase2-handoff.mjs';
import {completeVerifiedPhase1Handoff} from '../lib/phase2-handoff-ledger.mjs';
import {masterRun} from '../tools/cli.mjs';
import {ROOT} from './helpers.mjs';
const id='88478801',descr='USC 11/ DB+\nStandardantwort versendet';
const row={ticketId:id,descriptionValue:descr,source:'E-MAIL'};
const prior={ticketId:id,kind:'SEND',state:'SEND_INTENT',descriptionSha256:sha256(descr)};
const content='Sehr geehrter Herr Beispiel, mit dieser E-Mail möchten wir Ihnen bestätigen, dass wir Ihr Ticket erhalten haben und unser Team derzeit daran arbeitet. Wir werden uns bald melden.';
const incoming={direction:'INCOMING',sender:'secureemail@mmc.com',recipient:'servicelineintel@mercer.com',subject:'RE: [MERCER#76338482] Login after departure from Intel and vesting statement follow-up',content:'Dear Mercer team, I would like to follow up on the outstanding vesting statement after my departure from the company.',date:'05.11.2026 10:10',documentId:'12398433'};
const outgoing={direction:'OUTGOING',sender:'servicelineintel@mercer.com',recipient:'secureemail@mmc.com',subject:'[MARSH#88478801] RE: [MERCER#76338482] Login after departure from Intel and vesting statement follow-up',content,date:'06.11.2026 10:25',documentId:'12398434'};
const valid={row,prior,detailDescription:descr,history:{ok:true,rows:[incoming,outgoing]}};
const fixture=()=>{const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC65-'));const root=path.join(tmp,'MCR_Datenbruecke');fs.cpSync(ROOT,root,{recursive:true,filter:p=>!p.includes('/.runtime/')&&!p.includes('/diagnostics/')});return {root,done:()=>fs.rmSync(tmp,{recursive:true,force:true})};};
test('RC65: old exact SHA, persisted USC/status and one bound outgoing make handoff eligible',()=>{
 const p=phase2HandoffStatus(valid);assert.equal(p.verified,true,p.reason);assert.equal(p.outgoingDocumentId,outgoing.documentId);
});
test('RC65: sender, recipient, original subject, ticket tag, and outbound document remain bound',()=>{
 const corrupt=[{...outgoing,recipient:'someone@external.test'},{...outgoing,sender:'someone@external.test'},
 {...outgoing,subject:'[MARSH#88478802] something else'},
 {...outgoing,documentId:incoming.documentId},
 {...outgoing,content:'Hello, not a standard acknowledgement'},
 {...outgoing,direction:'INCOMING'}];
 for(const wrong of corrupt){const r=phase2HandoffStatus({...valid,history:{ok:true,rows:[incoming,wrong]}});assert.equal(r.verified,false,r.reason);}
});
test('RC65: no automatic release with a missing status, SHA mismatch, changed detail or multiple replies',()=>{
 for(const change of [
  {row:{...row,descriptionValue:'USC 11/ DB+'}},
  {row:{...row,descriptionValue:'USC 11/ DB+\nStandardantwort versendet\nStandardantwort versendet'}},
  {prior:{...prior,descriptionSha256:'f'.repeat(64)}},
  {detailDescription:'USC 11/ DB+\nUnbekannte Notiz'},
  {detailDescription:null},
  {history:{ok:true,rows:[incoming,outgoing,{...outgoing,documentId:'12398435'}]}},
  {history:{ok:false,rows:[]}},
 ]){const r=phase2HandoffStatus({...valid,...change});assert.equal(r.verified,false,r.reason);}
});
test('RC65: non-standard incoming mail, no supported Phase2 rule or FORWARD journal stay blocked',()=>{
 assert.equal(phase2HandoffStatus({...valid,row:{...row,descriptionValue:'USC 11/ PP+\nStandardantwort versendet'}}).verified,false);
 assert.equal(phase2HandoffStatus({...valid,prior:{...prior,kind:'FORWARD'}}).verified,false);
 assert.equal(phase2HandoffStatus({...valid,history:{ok:true,rows:[{...incoming,subject:'Delivery status notification - failed'},outgoing]}}).verified,false);
});
test('RC65: one old SEND_INTENT is closed after exact proof, every other pending ticket stays untouched',()=>{
 const f=fixture();try{
  const j=ledger(f.root);j.begin(id,descr);j.begin('88149870','USC 22/ DC\nStandardantwort versendet');
  const old=ledger(f.root).pending.find(x=>x.ticketId===id);const proof=phase2HandoffStatus({...valid,prior:old});assert.equal(proof.verified,true);
  const receipt=completeVerifiedPhase1Handoff(f.root,old,proof);assert.equal(receipt.ticketId,id);
  assert.deepEqual(ledger(f.root).pending.map(x=>x.ticketId),['88149870']);
  assert(ledger(f.root).completedIds().includes(id));
  assert.throws(()=>completeVerifiedPhase1Handoff(f.root,old,proof),/Altes Versandjournal/);
 }finally{f.done();}
});
test('RC65: SENT_CONFIRMED and SAVE_INTENT complete only with grounded proof, never new send',()=>{
 for(const state of ['SENT_CONFIRMED','SAVE_INTENT']){
  const f=fixture();try{const j=ledger(f.root);j.begin(id,descr);j.set(id,'SENT_CONFIRMED');if(state==='SAVE_INTENT')j.set(id,'SAVE_INTENT');
   const old=ledger(f.root).pending[0],proof=phase2HandoffStatus({...valid,prior:old});assert.equal(proof.verified,true);
   completeVerifiedPhase1Handoff(f.root,old,proof);assert.equal(ledger(f.root).pending.length,0);
  }finally{f.done();}
 }
});
test('RC76 policy: intake uses saved status, retains SEND evidence and separates Phase1 work',()=>{
 const rows=[row,{ticketId:'88503774',source:'E-MAIL',descriptionValue:'USC 22/ DC\nStandardantwort versendet'},
  {ticketId:'87393963',descriptionValue:'USC 22/ DC\nMöchte Kontoauszug'},{ticketId:'87160524',descriptionValue:'USC 33/ PP+\nStandardantwort versendet\nMöchte Log-in MBC mit privater E-Mail'}];
 const audit=phase2IntakeSummary(rows,{pending:[{ticketId:id,kind:'SEND'}]});
 assert.equal(audit.stats.visible,4);assert.equal(audit.stats.blockedPhase1,0);assert.equal(audit.stats.readyWithoutBlock,2);assert.equal(audit.stats.retainedPhase1Journals,1);
 assert.equal(audit.stats.unclassified,1);assert.equal(audit.stats.missingStatusOrPlan,0);assert.equal(audit.stats.phase1Required,1);
});
test('RC65: master with zero Phase2 completions and unresolved work reports PARTIAL not complete',async()=>{
 const f=fixture();try{
  const result=await masterRun({rootDir:f.root,confirm:async()=> 'MASTER_START',output:()=>{},
   runPhase1:async(pilot)=>pilot?{pilotVerified:true,runId:'test-pilot',processed:1}:{verified:true,runId:'test-full',processed:1},
   runPhase2:async()=>({status:'COMPLETED_VISIBLE_SCOPE',processed:0,scope:'VISIBLE_MY_TASKS_NO_PAGINATION',skipped:[{ticketId:id,reason:'UNRESOLVED_PHASE1_JOURNAL'}],runId:'test-phase2'})});
  assert.equal(result.state,'PARTIAL_PHASE2_NO_ELIGIBLE');
  assert.equal(result.phase1.status,'VERIFIED');
 }finally{f.done();}
});
