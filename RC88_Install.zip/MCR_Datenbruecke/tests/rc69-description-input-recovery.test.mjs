import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
import {commitDescription,recoverUnchangedDescriptionInput} from '../lib/trusted-description.mjs';
import {additionalDescriptionState} from '../lib/browser-workflow.mjs';

const ticket='88449724',before='USC 44/ PP+\nStandardantwort versendet\nMöchte Log-in MBC mit privater E-Mail',expected=before+'\nBearbeitet not reviewed';
async function withPage(fn){const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-P2-DOM-RC69-'));let browser,cdp;
 try{browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,extraArgs:process.platform==='linux'?['--no-sandbox','--disable-dev-shm-usage']:[]});({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.type==='page'&&t.url==='about:blank');return await fn(page);}
 finally{await cleanupTemporaryTestBrowser({profile,browser,cdp});}}
async function makePage(page,{blockNative=false,preventCtrlA=false,alterNative=false,modal=false,overlay=true}={}){
 await page.call(function({ticket,before,blockNative,preventCtrlA,alterNative,modal,overlay}){
  document.body.innerHTML='';const label=document.createElement('span');label.textContent='Ticket-ID: '+ticket;document.body.appendChild(label);
  const section=document.createElement('section');section.id='mainForm:document-data-section';section.innerHTML='<label for="mainForm:description">Zusätzliche Beschreibung</label><textarea id="mainForm:description" style="display:block;margin:40px 8px;width:410px;height:145px;"></textarea>';
  const field=section.querySelector('textarea');field.value=before;document.body.appendChild(section);
  // These listeners simulate real ICEfaces keyboard normalization, a swallowed
  // CDP insertion and an unexpected partial client-side editor mutation.
  if(preventCtrlA)field.addEventListener('keydown',e=>{if(e.ctrlKey&&e.key.toLowerCase()==='a')e.preventDefault()});
  if(blockNative)field.addEventListener('beforeinput',e=>{if(e.inputType==='insertText')e.preventDefault()});
  if(alterNative)field.addEventListener('beforeinput',e=>{if(e.inputType==='insertText'){e.preventDefault();field.value='UNEXPECTED_PARTIAL_EDIT'}});
  if(overlay){const blocker=document.createElement('div');blocker.id='full-overlay';blocker.style='position:fixed;inset:0;z-index:5000;pointer-events:auto;background:rgba(20,20,20,.02)';if(modal){blocker.setAttribute('role','dialog');blocker.setAttribute('aria-modal','true')}document.body.appendChild(blocker)}
 },{ticket,before,blockNative,preventCtrlA,alterNative,modal,overlay});
}

test('RC69 native focus plus Ctrl+A interception: verified full selection, exactly one correct description, no click on overlay', {timeout:25000},()=>withPage(async page=>{
 await makePage(page,{preventCtrlA:true});const logs=[];
 const done=await commitDescription(page,{ticketId:ticket,expected,allowedBefore:[before],log:m=>logs.push(m)});
 assert.equal(done.ok,true);assert.equal((await additionalDescriptionState(page)).value,expected);
 assert(logs.some(m=>m==='PASS P2_DESCRIPTION_INPUT_VERIFIED: NATIVE_CDP_INPUT'));
 assert.equal(await page.eval('document.getElementById("full-overlay")!==document.activeElement'),true);
}));

test('RC69 native insertion swallowed: ONLY the identical ticket-bound description receives event-setter fallback, no form submit', {timeout:25000},()=>withPage(async page=>{
 await makePage(page,{blockNative:true});const logs=[];
 const r=await commitDescription(page,{ticketId:ticket,expected,allowedBefore:[before],log:m=>logs.push(m)});
 assert.equal(r.ok,true);assert.equal((await additionalDescriptionState(page)).value,expected);
 assert(logs.some(m=>m.startsWith('PASS P2_DESCRIPTION_BOUND_EVENT_INPUT')));
 assert(logs.some(m=>m.endsWith('BOUND_NATIVE_SETTER_AND_EVENTS')));
}));

test('RC69 unexpected partial text stops without a second write; no hidden save', {timeout:25000},()=>withPage(async page=>{
 await makePage(page,{alterNative:true});const logs=[];
 await assert.rejects(()=>commitDescription(page,{ticketId:ticket,expected,allowedBefore:[before],log:m=>logs.push(m)}),e=>e.code==='DESCRIPTION_NATIVE_TEXT_DIVERGED');
 assert.equal((await additionalDescriptionState(page)).value,'UNEXPECTED_PARTIAL_EDIT');
 assert(logs.some(m=>m.includes('INHALT_ABWEICHEND')));
 assert.equal(logs.some(m=>m.includes('BOUND_EVENT_INPUT')),false);
}));

test('RC69 event-setter fallback refused when a visible modal is active, despite matching old text', {timeout:20000},()=>withPage(async page=>{
 await makePage(page,{modal:true});
 const r=await recoverUnchangedDescriptionInput(page,{ticketId:ticket,id:'mainForm:description',before,expected});
 assert.equal(r.ok,false);assert.equal(r.reason,'MODAL_ACTIVE');
 assert.equal((await additionalDescriptionState(page)).value,before);
}));

test('RC69 event-setter fallback refused if description mutated or bound ticket is not the current ticket', {timeout:20000},()=>withPage(async page=>{
 await makePage(page,{overlay:false});
 const wrong=await recoverUnchangedDescriptionInput(page,{ticketId:'99999999',id:'mainForm:description',before,expected}).then(()=>null,e=>e);
 assert(wrong?.code);
 await page.call(function(){document.getElementById('mainForm:description').value+='\nFOREIGN NOTE'});
 const r=await recoverUnchangedDescriptionInput(page,{ticketId:ticket,id:'mainForm:description',before,expected});
 assert.equal(r.ok,false);assert.equal(r.reason,'ORIGINAL_NOT_VERIFIED');
 assert.equal((await additionalDescriptionState(page)).value,before+'\nFOREIGN NOTE');
}));
