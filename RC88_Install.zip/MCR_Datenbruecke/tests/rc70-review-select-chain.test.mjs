import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage,sleep} from '../lib/cdp.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
import {selectReviewMode,phase2FieldSnapshot,focusBoundReviewSelectNatively,selectReviewAssignee,reviewAssignmentState,executeReview} from '../lib/phase2-comarch-actions.mjs';

const id='88449724',fieldId='mainForm:j_id7870';
async function withPage(fn){const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-P2-DOM-RC70-'));let browser,cdp;
 try{browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,extraArgs:process.platform==='linux'?['--no-sandbox','--disable-dev-shm-usage']:[]});({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.type==='page'&&t.url==='about:blank');return await fn(page);}
 finally{await cleanupTemporaryTestBrowser({profile,browser,cdp});}}
async function fixture(page,{already=false,modal=false,cover=false,duplicate=false}={}){
 await page.call(function({id,fieldId,already,modal,cover,duplicate}){
  document.body.innerHTML='<span>Ticket-ID: '+id+'</span><input id="unrelated" value="DO_NOT_TOUCH"/>';
  const area=document.createElement('section');area.id='area';area.style='margin:60px 20px;padding:10px';
  const sel=document.createElement('select');sel.id=fieldId;sel.name=fieldId;sel.style='width:230px;height:35px;';
  sel.innerHTML='<option value=""> </option><option value="CLOSED">Geschlossen</option><option value="FORWARD_TO_REVIEW">Weiterleiten zur Überprüfung</option><option value="NOT_ASSIGNABLE">Nicht zuordenbar</option>';
  if(already)sel.value='FORWARD_TO_REVIEW';
  sel.addEventListener('change',()=>{
   const found=document.getElementById('mainForm:next-persona-assignment-id');if(found)found.remove();
   if(sel.value==='FORWARD_TO_REVIEW'){
    const input=document.createElement('input');input.id='mainForm:next-persona-assignment-id';input.value='';area.appendChild(input);
   }
  });area.appendChild(sel);document.body.appendChild(area);
  if(already){sel.dispatchEvent(new Event('change',{bubbles:true}));}
  if(duplicate){const other=sel.cloneNode(true);other.id='mainForm:j_id7777';area.appendChild(other);}
  if(cover||modal){const over=document.createElement('div');over.id='foreign-overlay';over.style='position:fixed;inset:0;z-index:10000;pointer-events:auto;background:rgba(40,10,10,.03)';if(modal){over.setAttribute('role','dialog');over.setAttribute('aria-modal','true');}document.body.appendChild(over);}
 },{id,fieldId,already,modal,cover,duplicate});
}

test('RC70: ICEfaces loses focus after valid native click; rebind the SAME SELECT and choose review, no unrelated edit', {timeout:30000},()=>withPage(async page=>{
 await fixture(page);const original=page.mouseClick.bind(page);let clicks=0,manual=0;const logs=[];
 page.mouseClick=async(...args)=>{clicks++;await original(...args);await page.call(function(){document.getElementById('unrelated').focus()});};
 const r=await selectReviewMode(page,{ticketId:id,log:m=>logs.push(m),manualFocus:async()=>{manual++;throw Error('should use native focus');}});
 assert.equal(r.ok,true);assert.equal(clicks,1);assert.equal(manual,0);
 assert.equal((await phase2FieldSnapshot(page)).reviewValue,'FORWARD_TO_REVIEW');
 assert.equal((await phase2FieldSnapshot(page)).nextPersona.count,1);
 assert(logs.some(s=>s.includes('P2_REVIEW_SELECT_ICE_REBIND')));
 assert(logs.some(s=>s.includes('PASS P2_REVIEW_SELECT_BOUND_NATIVE_FOCUS')));
 assert.equal(await page.eval('document.getElementById("unrelated").value'),'DO_NOT_TOUCH');
}));

test('RC70: ICEfaces replaces SELECT between click and focus check; native focus on the exact re-rendered ID', {timeout:30000},()=>withPage(async page=>{
 await fixture(page);const original=page.mouseClick.bind(page);let clicks=0;
 page.mouseClick=async(...args)=>{clicks++;await original(...args);await page.call(function(fid){const old=document.getElementById(fid);const replacement=old.cloneNode(true);replacement.value='';replacement.addEventListener('change',()=>{if(replacement.value==='FORWARD_TO_REVIEW'&&!document.getElementById('mainForm:next-persona-assignment-id')){const n=document.createElement('input');n.id='mainForm:next-persona-assignment-id';document.querySelector('#area').appendChild(n);}});old.replaceWith(replacement);document.getElementById('unrelated').focus();},fieldId);};
 await selectReviewMode(page,{ticketId:id,manualFocus:async()=>{throw Error('operator not required')}});
 assert.equal(clicks,1);assert.equal((await phase2FieldSnapshot(page)).reviewValue,'FORWARD_TO_REVIEW');
 assert.equal((await phase2FieldSnapshot(page)).nextPersona.count,1);
}));

test('RC70: already selected after a prior run does not click or overwrite anything', {timeout:25000},()=>withPage(async page=>{
 await fixture(page,{already:true});page.mouseClick=async()=>{throw Error('unexpected second click')};
 const r=await selectReviewMode(page,{ticketId:id});assert.equal(r.reason,'REVIEW_ALREADY_SELECTED');
 assert.equal((await phase2FieldSnapshot(page)).reviewValue,'FORWARD_TO_REVIEW');
}));

test('RC70: visible modal forbids native focus and wrong-element keyboard entry', {timeout:25000},()=>withPage(async page=>{
 await fixture(page,{modal:true});const r=await focusBoundReviewSelectNatively(page,{ticketId:id,fieldId});
 assert.equal(r.ok,false);assert.equal(r.reason,'REVIEW_MODAL_ACTIVE');
 let clicked=0;page.mouseClick=async()=>clicked++;
 await assert.rejects(()=>selectReviewMode(page,{ticketId:id,manualFocus:async()=>{throw Error('not approved')}}));
 assert.equal(clicked,0);assert.equal((await phase2FieldSnapshot(page)).reviewValue,'');
}));

test('RC70: covered select can be natively focused without clicking a foreign overlay', {timeout:25000},()=>withPage(async page=>{
 await fixture(page,{cover:true});page.mouseClick=async()=>{throw Error('no click should be attempted')};
 const r=await selectReviewMode(page,{ticketId:id,manualFocus:async()=>{throw Error('not required')}});
 assert.equal(r.ok,true);assert.equal((await phase2FieldSnapshot(page)).reviewValue,'FORWARD_TO_REVIEW');
}));

test('RC70: wrong ticket fails before any mouse or keyboard operation', {timeout:25000},()=>withPage(async page=>{
 await fixture(page);let clicks=0;page.mouseClick=async()=>clicks++;
 await assert.rejects(()=>selectReviewMode(page,{ticketId:'00000000'}),e=>e.code==='TICKET_BINDING');
 assert.equal(clicks,0);assert.equal((await phase2FieldSnapshot(page)).reviewValue,'');
}));

test('RC70: ambiguous review controls never pick one arbitrarily', {timeout:25000},()=>withPage(async page=>{
 await fixture(page,{duplicate:true});let clicks=0;page.mouseClick=async()=>clicks++;
 await assert.rejects(()=>selectReviewMode(page,{ticketId:id}),e=>e.code==='REVIEW_DROPDOWN_NOT_UNIQUE');
 assert.equal(clicks,0);
}));


test('RC70 integration: persisted MBC state -> review -> exact Mark -> one execute click, no email or re-save', {timeout:30000},()=>withPage(async page=>{
 await fixture(page);
 await page.call(function(){
  const area=document.getElementById('area');
  const gevo=document.createElement('input');gevo.id='mainForm:gevo-value-id';gevo.value='Anfrage Member';area.appendChild(gevo);
  const status=document.createElement('textarea');status.id='mainForm:description';status.value='USC 11/ PP+\nStandardantwort versendet\nMöchte Log-in MBC mit privater E-Mail\nBearbeitet not reviewed';area.appendChild(status);
  const run=document.createElement('input');run.type='submit';run.value='Schritt ausführen';run.id='mainForm:j_id7894';run.onclick=e=>{e.preventDefault();window.__routeClicks=(window.__routeClicks||0)+1;window.__routeWasBound=!!(document.getElementById('mainForm:next-persona-assignment-id')?.value==='Baindl Mark (mark.baindl)'&&document.getElementById('mainForm:j_id7870').value==='FORWARD_TO_REVIEW');};area.appendChild(run);
  window.__sendClicks=0;window.__saveClicks=0;
  const sel=document.getElementById('mainForm:j_id7870');sel.addEventListener('change',()=>{if(sel.value==='FORWARD_TO_REVIEW'){const n=document.getElementById('mainForm:next-persona-assignment-id');if(n){n.setAttribute('value','Baindl Mark (mark.baindl)');n.defaultValue='Baindl Mark (mark.baindl)';n.value='Baindl Mark (mark.baindl)';}}});
 });
 const rawClick=page.mouseClick.bind(page);let mouse=0;page.mouseClick=async(...args)=>{mouse++;await rawClick(...args);if(mouse===1)await page.call(function(){document.getElementById('unrelated').focus();});};
 await selectReviewMode(page,{ticketId:id});
 assert.equal((await phase2FieldSnapshot(page)).reviewValue,'FORWARD_TO_REVIEW');
 await selectReviewAssignee(page,{});
 assert.equal((await reviewAssignmentState(page)).ok,true);
 await executeReview(page);
 const after=await page.call(function(){return {route:window.__routeClicks||0,bound:!!window.__routeWasBound,send:window.__sendClicks,save:window.__saveClicks,selected:document.getElementById('mainForm:j_id7870').value,description:document.getElementById('mainForm:description').value};});
 assert.equal(after.route,1);assert.equal(after.bound,true);assert.equal(after.send,0);assert.equal(after.save,0);assert.match(after.description,/Bearbeitet not reviewed/);
}));
