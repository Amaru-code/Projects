import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
import {savePhase2Ticket} from '../lib/phase2-comarch-actions.mjs';

const ticket='87647759';
async function withPage(run){const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-P2-DOM-RC71-SAVE-'));let browser,cdp;
 try{browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,extraArgs:process.platform==='linux'?['--no-sandbox','--disable-dev-shm-usage']:[]});({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.type==='page'&&t.url==='about:blank');return await run(page);}
 finally{await cleanupTemporaryTestBrowser({profile,browser,cdp});}}
async function fixture(page,{covered=true,modal=false,duplicate=false,resetOnFocus=false}={}){await page.call(function({ticket,covered,modal,duplicate,resetOnFocus}){
 document.body.innerHTML='<span>Ticket-ID: '+ticket+'</span><input id="foreign" value="SAFE"><input id="mainForm:gevo-value-id" value="Anfrage Member"><div id="mainForm:document-data-section"><label>Zusätzliche Beschreibung<textarea id="mainForm:desc"></textarea></label></div>';
 document.getElementById('mainForm:desc').value='USC 12/ PP+\nStandardantwort versendet\nMöchte Log-in MBC mit privater E-Mail\nBearbeitet not reviewed';
 const a=document.createElement('a');a.id='mainForm:j_id7171';a.href='javascript:;';a.textContent='Ticket speichern';a.style='display:block;width:200px;height:35px;margin:50px 10px';
 a.addEventListener('click',e=>{e.preventDefault();window.__saveClicks=(window.__saveClicks||0)+1;window.__saveGevo=document.getElementById('mainForm:gevo-value-id').value;window.__saveDesc=document.getElementById('mainForm:desc').value;});
 if(resetOnFocus)a.addEventListener('focus',()=>{document.getElementById('mainForm:gevo-value-id').value='';});
 document.body.appendChild(a);if(duplicate){const b=a.cloneNode(true);b.id='mainForm:j_id7172';document.body.appendChild(b);}
 if(covered){const over=document.createElement('div');over.style='position:fixed;inset:0;z-index:9000;background:rgba(0,0,0,.08);pointer-events:auto';if(modal){over.setAttribute('role','dialog');over.setAttribute('aria-modal','true');}document.body.appendChild(over);}
 window.__saveClicks=0;window.__saveGevo=null;
 },{ticket,covered,modal,duplicate,resetOnFocus});}
async function read(page){return page.call(()=>({clicks:window.__saveClicks,gevo:document.getElementById('mainForm:gevo-value-id').value,foreign:document.getElementById('foreign').value,sent:document.getElementById('mainForm:desc').value,saveGevo:window.__saveGevo}));}
const check=async page=>{const g=await read(page);assert.equal(g.gevo,'Anfrage Member');assert.match(g.sent,/Bearbeitet not reviewed/);};

test('RC71: occluded exact save anchor activated once by native keyboard, never manual text confirmation', {timeout:30000},()=>withPage(async page=>{
 await fixture(page);let intents=0,manual=0,prechecks=0;
 const result=await savePhase2Ticket(page,{ticketId:ticket,preActionCheck:async()=>{prechecks++;await check(page);},beforeAutoClick:()=>{intents++;},manualClick:()=>{manual++;}});
 assert.equal(result.method,'BOUND_NATIVE_KEYBOARD_ENTER');assert.equal(intents,1);assert.equal(manual,0);assert.equal(prechecks,2);
 const r=await read(page);assert.equal(r.clicks,1);assert.equal(r.saveGevo,'Anfrage Member');assert.equal(r.foreign,'SAFE');
}));

test('RC71: unobstructed exact save uses one mouse click and one pre-save validation', {timeout:30000},()=>withPage(async page=>{
 await fixture(page,{covered:false});let intents=0;
 const result=await savePhase2Ticket(page,{ticketId:ticket,preActionCheck:()=>check(page),beforeAutoClick:()=>intents++});
 assert.equal(result.automaticClicks,1);assert.equal(intents,1);assert.equal((await read(page)).clicks,1);
}));

test('RC71: visible modal prohibits native key activation, no auto save', {timeout:30000},()=>withPage(async page=>{
 await fixture(page,{covered:true,modal:true});let intents=0,manual=0;
 await assert.rejects(()=>savePhase2Ticket(page,{ticketId:ticket,beforeAutoClick:()=>intents++,manualClick:()=>{manual++;throw Error('manual only');}}),/manual only/);
 assert.equal(intents,0);assert.equal(manual,1);assert.equal((await read(page)).clicks,0);
}));

test('RC71: pre-save guard sees a changed GEVO and blocks any save action', {timeout:30000},()=>withPage(async page=>{
 await fixture(page);let intents=0,manual=0;
 await assert.rejects(()=>savePhase2Ticket(page,{ticketId:ticket,
  preActionCheck:async()=>{await page.call(()=>{document.getElementById('mainForm:gevo-value-id').value='';});await check(page);},
  beforeAutoClick:()=>intents++,manualClick:()=>manual++}));
 assert.equal(intents,0);assert.equal(manual,0);assert.equal((await read(page)).clicks,0);
}));

test('RC71: if COMARCH resets GEVO during the save action, the outcome stays unverified until server readback', {timeout:30000},()=>withPage(async page=>{
 await fixture(page,{resetOnFocus:true});let intents=0;
 const outcome=await savePhase2Ticket(page,{ticketId:ticket,preActionCheck:()=>check(page),beforeAutoClick:()=>intents++});
 const server=await read(page);assert.equal(outcome.independentlySaved,false);
 assert.equal(intents,1);assert.equal(server.clicks,1);
 assert.equal(server.saveGevo,''); // A live persisted-value check MUST reject this, never route.
}));

test('RC71: duplicate save buttons fail before any click or journal attempt', {timeout:30000},()=>withPage(async page=>{
 await fixture(page,{duplicate:true});let intents=0,manual=0;
 await assert.rejects(()=>savePhase2Ticket(page,{ticketId:ticket,preActionCheck:()=>check(page),beforeAutoClick:()=>intents++,manualClick:()=>manual++}));
 assert.equal(intents,0);assert.equal(manual,0);assert.equal((await read(page)).clicks,0);
}));

test('RC71: wrong ticket binding prevents native save activation', {timeout:30000},()=>withPage(async page=>{
 await fixture(page);let intents=0;
 await assert.rejects(()=>savePhase2Ticket(page,{ticketId:'12345678',beforeAutoClick:()=>intents++}),e=>e.code==='TICKET_BINDING');
 assert.equal(intents,0);assert.equal((await read(page)).clicks,0);
}));
