import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';
import {fileURLToPath} from 'node:url';
import {statementDraft,saveStatementDraftAndAcknowledge,statementDialogTextEligible} from '../lib/phase2-statement-draft.mjs';
import {phase2Journal,digestDescription} from '../lib/phase2-write-journal.mjs';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
const id='87393963';
const root=path.dirname(fileURLToPath(import.meta.url));
test('RC81: exact requested Kontoauszug text with verified salutation',()=>{
 assert.equal(statementDraft({lastName:'Goris',gender:'M'}),
  'Sehr geehrter Herr Goris, anbei erhalten Sie die gewünschten Kontoauszüge. Die Dateien sind mit dem gewohnten Passwort verschlüsselt, Sie erhalten es nochmals in der nächsten Nachricht.');
 assert.match(statementDraft({lastName:'Müller',gender:'F'}),/^Sehr geehrte Frau Müller, anbei erhalten Sie/);
 assert.throws(()=>statementDraft({lastName:'Goris',gender:null}),e=>e.code==='P2_KA_DRAFT_SALUTATION');
 assert.throws(()=>statementDraft({lastName:'<img src=x>',gender:'M'}),e=>e.code==='P2_KA_DRAFT_NAME');
});
test('RC81: unknown/send/delete dialog is not an account-statement draft receipt',()=>{
 for(const x of ['Nachricht senden','Schritt weiterleiten','Wirklich löschen?','Bitte bestätigen Sie den Versand',''])assert(!statementDialogTextEligible(x));
 for(const x of ['Entwurf gespeichert.','Der Entwurf wurde gespeichert','OK'])assert(statementDialogTextEligible(x));
});
async function withBrowser(run){
 const executable=findEdgeExecutable();if(!executable){console.log('SKIP Chromium unavailable');return;}
 const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-P2-DOM-RC81-DRAFT-'));
 let browser,cdp;
 try{
  browser=await launchBrowser({executable,userDataDir:profile,startUrl:'about:blank',headless:true,
   extraArgs:process.platform==='linux'?['--no-sandbox','--disable-dev-shm-usage']:[]});
  ({cdp}=await connectBrowser(browser.port));
  const page=await attachPage(cdp,t=>t.type==='page'&&t.url==='about:blank');
  return await run(page);
 }finally{await cleanupTemporaryTestBrowser({profile,browser,cdp});}
}
async function setupPage(page,scenario='html'){
 await page.call(function(id,mode){
  document.body.innerHTML='<div>Ticket-ID: '+id+'</div><form id="mainForm"><button id="draft" type="button">Entwurf speichern</button></form>';
  window.__draftClicks=0;window.__okClicks=0;
  document.getElementById('draft').onclick=()=>{
   window.__draftClicks++;
   if(mode==='html'){
    const d=document.createElement('div');d.setAttribute('role','dialog');
    d.style.cssText='position:fixed;top:130px;left:100px;background:white;border:2px solid black;z-index:1000;padding:16px';
    d.innerHTML='<p>Entwurf wurde gespeichert</p><button type="button">OK</button>';
    d.querySelector('button').onclick=()=>{window.__okClicks++;d.remove();};document.body.append(d);
   }else if(mode==='js')window.alert('Entwurf gespeichert');
   else if(mode==='unsafe')window.alert('Nachricht senden?');
  };
 },id,scenario);
}
test('RC81 Chromium: one draft click acknowledges one HTML OK, no second click',{timeout:50000},()=>withBrowser(async page=>{
 await setupPage(page,'html');let intents=0;const r=await saveStatementDraftAndAcknowledge(page,{ticketId:id,beforeClick:()=>{intents++;}});
 assert.equal(intents,1);assert.equal(r.htmlOkCount,1);assert.equal(await page.eval('window.__draftClicks'),1);
 assert.equal(await page.eval('window.__okClicks'),1);assert.equal((await page.eval('document.querySelectorAll("[role=dialog]").length')),0);
}));
test('RC81 Chromium: JS alert from draft is acknowledged once',{timeout:50000},()=>withBrowser(async page=>{
 await setupPage(page,'js');const r=await saveStatementDraftAndAcknowledge(page,{ticketId:id});
 assert.equal(r.jsDialogCount,1);assert.equal(await page.eval('window.__draftClicks'),1);
}));
test('RC81 Chromium: unexpected send dialog rejected; no repeat',{timeout:50000},()=>withBrowser(async page=>{
 await setupPage(page,'unsafe');
 await assert.rejects(saveStatementDraftAndAcknowledge(page,{ticketId:id}),e=>e.code==='P2_KA_DRAFT_DIALOG_UNVERIFIED');
 assert.equal(await page.eval('window.__draftClicks'),1);
}));
test('RC81 Chromium: pre-existing dialog prevents draft-click',{timeout:50000},()=>withBrowser(async page=>{
 await setupPage(page,'html');await page.call(()=>{const d=document.createElement('div');d.setAttribute('role','dialog');d.style.cssText='position:absolute;top:10px;left:10px';d.innerHTML='<button>OK</button>';document.body.appendChild(d);});
 await assert.rejects(saveStatementDraftAndAcknowledge(page,{ticketId:id}),e=>e.code==='P2_KA_DRAFT_PREEXISTING_DIALOG');
 assert.equal(await page.eval('window.__draftClicks'),0);
}));
test('RC81: journal refuses draft replay after click or completed event',()=>{
 const base=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC81-JOURNAL-'));
 try{
  const input={ticketId:id,descriptionSha256:digestDescription('USC 20/DC;PP+\nStandardantwort versendet\nMöchte Kontoauszug'),pdfHashes:[{plan:'DC',sha256:'a'.repeat(64)}]};
  const j=phase2Journal(base,id,{initial:input});j.begin();
  for(const s of ['UPLOAD_INTENT','UPLOAD_VERIFIED','GEVO_INTENT','GEVO_VERIFIED','DESCRIPTION_INTENT','DESCRIPTION_VERIFIED'])j.advance(s);
  j.recordStatementDraftEvent('KA_DRAFT_WRITE_INTENT',{draftSha256:'b'.repeat(64)});
  j.advance('DRAFT_SAVE_INTENT');j.recordStatementDraftEvent('KA_DRAFT_CLICK_INTENT');
  assert.throws(()=>j.recordStatementDraftEvent('KA_DRAFT_CLICK_INTENT'),e=>e.code==='P2_KA_DRAFT_EVENT_REPLAY');
  j.recordStatementDraftEvent('KA_DRAFT_OK_VERIFIED');
  j.recordStatementDraftEvent('KA_POST_DRAFT_DESCRIPTION_RESTORE_INTENT');
  j.recordStatementDraftEvent('KA_POST_DRAFT_DESCRIPTION_RESTORED');
  j.advance('DRAFT_SAVE_VERIFIED');j.advance('TICKET_SAVE_INTENT');
  assert.throws(()=>j.recordStatementDraftEvent('KA_LEGACY_DRAFT_WRITE_INTENT',{draftSha256:'b'.repeat(64),confirmed:true}),e=>e.code==='P2_KA_DRAFT_EVENT_REPLAY');
 }finally{fs.rmSync(base,{recursive:true,force:true});}
});
test('RC81: new draft/text verification precedes Ticket speichern; no Send action introduced',()=>{
 const s=fs.readFileSync(new URL('../src/phase2-comarch-pilot.mjs',import.meta.url),'utf8');
 assert(s.includes('await saveStatementReply();'));
 assert(s.includes('if(statementReply)need(await verifyMbcDraft'));
 assert(s.includes('KA_POST_DRAFT_DESCRIPTION_RESTORE_INTENT'));
 assert(s.includes("id==='87393963'&&recoveryMode==='TICKET_SAVE_ONLY'"));
 const draft=fs.readFileSync(new URL('../lib/phase2-statement-draft.mjs',import.meta.url),'utf8');
 assert(!draft.includes('send-new-message-button'));
 assert(!draft.includes('Senden klicken'));
});
