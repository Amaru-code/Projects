import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {sha256} from '../lib/core.mjs';
import {inspectPhase2Tickets} from '../lib/phase2-intake-audit.mjs';
import {phase2IntakeSummary} from '../lib/phase2-handoff.mjs';
import {choosePhase2Candidate} from '../src/phase2-run.mjs';
import {readPhase2Queue} from '../lib/phase2-readonly.mjs';
import {phase2ReadOnlyInventory} from '../src/phase2-inventory-run.mjs';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
const row=(id,desc,extra={})=>({ticketId:id,descriptionValue:desc,source:'E-MAIL',groupName:'Intel Deutschland',intelGroupVerified:true,...extra});
const db='USC 10/ DB+\nStandardantwort versendet';
const mbc='USC 20/ PP+\nStandardantwort versendet\nMöchte Log-in MBC mit privater E-Mail';
const open={ticketId:'88149870',kind:'SEND',state:'SEND_INTENT',descriptionSha256:sha256(db)};

test('RC76 policy on RC73 inventory: stored status routes, old SEND ledger retained',()=>{
 const rows=[row('88149870',db),row('88449724',mbc),row('87647759',mbc),row('87393963','USC 20/ DC\nMöchte Kontoauszug'),
  row('82976755','Möchte Kontoauszug'),row('88530248',db,{groupName:'Other Company',intelGroupVerified:false})];
 const result=inspectPhase2Tickets(rows,{pending:[open],getWorkJournal:id=>id==='87647759'?{
  state:'REVIEW_VERIFIED',descriptionAfter:mbc,descriptionBefore:'USC 20/ PP+',events:[]}:null});
 assert.equal(result.counts.visible,6);assert.equal(result.counts.ready,2);
 assert.equal(result.counts.resume,1);assert.equal(result.counts.phase1EvidenceToCheck,0);assert.equal(result.counts.retainedPhase1Journals,1);
 assert.equal(result.counts.reviewBlocked,2);assert.equal(result.counts.phase1Required,1);
 assert.equal(result.items.find(x=>x.ticketId==='88149870').reason,'STORED_DESCRIPTION_ROUTING');
 assert.equal(result.items.find(x=>x.ticketId==='88530248').reason,'OUTSIDE_INTEL_GROUP');
 assert.equal(result.noMailActions,true);assert.equal(result.noTicketWrites,true);
 const legacy=phase2IntakeSummary(rows,{pending:[open],getWorkJournal:id=>id==='87647759'?{state:'REVIEW_VERIFIED'}:null});
 assert.equal(legacy.stats.outsideIntelGroup,1);assert.equal(legacy.stats.readyWithoutBlock,2);
 assert(!JSON.stringify(result).includes('Möchte Log-in'),'raw confidential request must not be copied into report');
});
test('RC76: old SEND SHA is not falsified or needed for internal no-mail Phase2 routing',()=>{
 const audit=inspectPhase2Tickets([row('88149870',db)],{pending:[{...open,descriptionSha256:'f'.repeat(64)}]});
 assert.equal(audit.counts.phase1EvidenceToCheck,0);
 assert.equal(audit.items[0].reason,'STORED_DESCRIPTION_ROUTING');assert.equal(audit.items[0].phase1JournalRetained,true);
});
test('RC73 never selects a foreign-company ticket even with a supported DB rule',()=>{
 const rows=[row('88530248',db,{groupName:'Other Company',intelGroupVerified:false}),row('88503774',db)];
 const selection=choosePhase2Candidate(rows);assert.equal(selection.row.ticketId,'88503774');
 assert.deepEqual(selection.skipped,[{ticketId:'88530248',reason:'OUTSIDE_INTEL_GROUP'}]);
});
test('RC73 a previous verified route is never considered a fresh candidate',()=>{
 const rows=[row('88449724',mbc),row('88503774',db)];
 const result=inspectPhase2Tickets(rows,{getWorkJournal:id=>id==='88449724'?{state:'ROUTED_VERIFIED'}:null});
 assert.equal(result.items[0].stage,'COMPLETED');
 assert.equal(result.counts.ready,1);
 assert.equal(choosePhase2Candidate(rows,{getWorkJournal:id=>id==='88449724'?{state:'ROUTED_VERIFIED'}:null}).row.ticketId,'88503774');
});
test('RC73 duplicate ids are flagged by the standalone audit, never silently counted as two eligible',()=>{
 const result=inspectPhase2Tickets([row('88503774',db),row('88503774',db)]);
 assert.equal(result.items[1].reason,'DUPLICATE_TICKET_ID');assert.equal(result.counts.ready,1);
});
async function withPage(fn){const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-P2-DOM-RC73-'));let browser,cdp;
 try{browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,
  extraArgs:process.platform==='linux'?['--no-sandbox','--disable-dev-shm-usage']:[]});({cdp}=await connectBrowser(browser.port));
  const page=await attachPage(cdp,t=>t.type==='page'&&t.url==='about:blank');return await fn(page);}
 finally{await cleanupTemporaryTestBrowser({profile,browser,cdp});}}

test('RC73 Chromium binds group names to exact own-table rows; unrelated table and company are excluded', {timeout:45000},()=>withPage(async page=>{
 await page.call(()=>{
  const row=(id,group)=>`<tr><td>${id}</td><td>${group}</td><td>E-MAIL</td><td>USC 10/ DB+<div>Standardantwort versendet</div></td></tr>`;
  const table=(id,rows)=>`<table id="${id}"><thead><tr><th>Ticket-ID</th><th>Group Name</th><th>Quelle</th><th>Zusätzliche Beschreibung</th></tr></thead><tbody>${rows}</tbody></table>`;
  document.body.innerHTML=table('mainForm:tasksTableFor_MyTasksList',row('88503774','Intel Deutschland')+row('88530248','Other Company'))+
   table('mainForm:tasksTableFor_JobAndExecutions',row('88599999','Other Company'));
 });
 const read=await readPhase2Queue(page);assert.equal(read.ok,true);assert.equal(read.rows.length,2);
 assert.equal(read.rows[0].intelGroupVerified,true);assert.equal(read.rows[1].intelGroupVerified,false);
 const pick=choosePhase2Candidate(read.rows);assert.equal(pick.row.ticketId,'88503774');
}));
test('RC73 Chromium read-only inventory navigates exact two Intel menus, never clicks other-menu or ticket controls',{timeout:60000},()=>withPage(async page=>{
 const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC73-INVENTORY-'));let own;
 try{
  await page.call(()=>{
   const table=(id,ticket)=>`<table id="${id}"><thead><tr><th>Ticket-ID</th><th>Group Name</th><th>Quelle</th><th>Zusätzliche Beschreibung</th></tr></thead><tbody><tr><td onclick="window.__clicks.ticket++">${ticket}</td><td>Intel Deutschland</td><td>E-MAIL</td><td>USC 10/ DB+<div>Standardantwort versendet</div></td></tr></tbody></table>`;
   window.__clicks={mine:0,other:0,tasks:0,queues:0,ticket:0,save:0,send:0,forward:0};
   document.body.innerHTML=`<a id="mine">Meine Vorgänge</a><a id="other">Offene Vorgänge</a><div id="storedSearchesContainer_MY_TASKS"><a id="own"><span>In_Bearbeitung</span></a></div><div id="storedSearchesContainer_MY_QUEUES"><a id="int"><span>INTL01</span></a></div><div id="content"></div>`;
   document.getElementById('mine').onclick=()=>window.__clicks.mine++;
   document.getElementById('other').onclick=()=>window.__clicks.other++;
   document.getElementById('own').onclick=()=>{window.__clicks.tasks++;document.querySelector('#own span').style.fontWeight='bold';document.querySelector('#int span').style.fontWeight='normal';document.querySelector('#content').innerHTML=table('mainForm:tasksTableFor_MyTasksList','88503774');};
   document.getElementById('int').onclick=()=>{window.__clicks.queues++;document.querySelector('#int span').style.fontWeight='bold';document.querySelector('#own span').style.fontWeight='normal';document.querySelector('#content').innerHTML=table('mainForm:tasksTableFor_MyQueuesTasksList','88507393');};
  });
  own=await phase2ReadOnlyInventory({root:tmp,page,askFn:async()=> 'START',log:()=>{}});
  assert.equal(own.counts.visible,1);assert.equal(own.counts.ready,1);
  assert.equal(own.intelQueue.status,'BOUND_VISIBLE_PAGE');assert.equal(own.intelQueue.visibleRows,1);
  assert(fs.existsSync(path.join(tmp,'.runtime/phase2/MCR_PHASE2_TICKETBESTAND_LETZTE.json')));
  const clicks=await page.eval('window.__clicks');assert.equal(clicks.mine,0);assert.equal(clicks.other,0);assert.equal(clicks.ticket,0);
  assert.equal(clicks.tasks,1);assert.equal(clicks.queues,1);
 }finally{fs.rmSync(tmp,{recursive:true,force:true});}
}));
