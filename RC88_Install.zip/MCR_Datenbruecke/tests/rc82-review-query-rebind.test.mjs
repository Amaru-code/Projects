import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
import {selectExactPhase2Mark,exactPhase2Assignee,phase2MarkQueryRetryState} from '../lib/phase2-assignee.mjs';
const fieldId='mainForm:next-persona-assignment-id',ticket='82976755';
async function withPage(fn){const exe=findEdgeExecutable();if(!exe)return;
 const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-P2-DOM-RC82-'));let browser,cdp;
 try{browser=await launchBrowser({executable:exe,userDataDir:profile,startUrl:'about:blank',headless:true,extraArgs:process.platform==='linux'?['--no-sandbox','--disable-dev-shm-usage']:[]});({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.type==='page'&&t.url==='about:blank');return await fn(page);}finally{await cleanupTemporaryTestBrowser({profile,browser,cdp});}}
async function setup(page,mode='normal'){
 await page.call(function({fieldId,ticket,mode}){
  document.body.innerHTML='<span>Ticket-ID: '+ticket+'</span><div id="area" style="margin:55px 25px"><input id="mainForm:next-persona-assignment-id" autocomplete="off" style="width:280px;height:34px;display:block"/><input id="unrelated" value="UNMODIFIED" style="display:block"/></div>';
  const f=document.getElementById(fieldId),area=document.getElementById('area');
  window.__markSelected=0;window.__forwardClicks=0;window.__saveClicks=0;window.__sendClicks=0;
  const makeOption=()=>{const n=document.createElement('div');n.id='mark-option';n.textContent='Baindl Mark (mark.baindl)';n.setAttribute('role','option');n.style='width:270px;height:35px;background:#edf;cursor:pointer';n.onmousedown=()=>{f.value='Baindl Mark (mark.baindl)';f.defaultValue='Baindl Mark (mark.baindl)';window.__markSelected++;};area.insertBefore(n,document.getElementById('unrelated'));return n;};
  if(['mismatch-option','normal','once-reset','two-options'].includes(mode))makeOption();
  if(mode==='two-options'){const copy=makeOption();copy.id='mark-option-second';}
  if(mode==='mismatch-option')f.addEventListener('keyup',()=>{f.value='unexpected keyboard result';});
  if(mode==='once-reset'){
   const n=document.getElementById('mark-option');n.style.display='none';let first=true;
   f.addEventListener('keyup',ev=>{if(ev.key!=='l')return;if(first){first=false;f.value='';}else n.style.display='block';});
  }
  if(mode==='mismatch-no-option'||mode==='manual-other')f.addEventListener('keyup',()=>{f.value='Other Person (other.account)';});
  if(mode==='ready-server'){f.value='Baindl Mark (mark.baindl)';f.defaultValue='Baindl Mark (mark.baindl)';}
 },{fieldId,ticket,mode});
}

test('RC82 Chromium: changed query can still use one EXACT trusted suggestion, without a save/forward',{timeout:45000},()=>withPage(async page=>{
 await setup(page,'mismatch-option');const logs=[];const r=await selectExactPhase2Mark(page,{fieldId,ticketId:ticket,log:s=>logs.push(s),manualSelect:async()=>{throw Error('manual not necessary')}});
 assert.equal(r.ok,true);assert.equal(r.account,'mark.baindl');assert(logs.some(x=>x.includes('P2_PRUEFER_QUERY_INSTABIL')));
 assert.equal((await exactPhase2Assignee(page,fieldId)).ok,true);
 assert.equal(await page.eval('window.__markSelected'),1);
 assert.deepEqual(await page.call(function(){return [window.__sendClicks,window.__saveClicks,window.__forwardClicks,document.getElementById('unrelated').value];}),[0,0,0,'UNMODIFIED']);
}));

test('RC82 Chromium: field emptied once by ICEfaces is retyped at most once',{timeout:45000},()=>withPage(async page=>{
 await setup(page,'once-reset');const logs=[];
 const r=await selectExactPhase2Mark(page,{fieldId,ticketId:ticket,log:s=>logs.push(s),manualSelect:async()=>{throw Error('manual not needed')}});
 assert.equal(r.ok,true);assert(logs.some(x=>x.includes('P2_PRUEFER_QUERY_NEU_BINDEN')));
 assert.equal(await page.eval('window.__markSelected'),1);
}));

test('RC82 Chromium: changed query with no suggestion asks operator, then verifies chosen account',{timeout:45000},()=>withPage(async page=>{
 await setup(page,'mismatch-no-option');let manual=0;const logs=[];
 const r=await selectExactPhase2Mark(page,{fieldId,ticketId:ticket,log:s=>logs.push(s),manualSelect:async(id)=>{
  manual++;assert.equal(id,fieldId);await page.call(function(id){const f=document.getElementById(id);f.value='Baindl Mark (mark.baindl)';f.defaultValue='Baindl Mark (mark.baindl)';},id);
 }});
 assert.equal(r.ok,true);assert.equal(r.method,'OPERATOR_EXACT_ACCOUNT_OPTION');assert.equal(manual,1);
 assert(logs.some(x=>x.includes('P2_PRUEFER_MANUELLE_AUSWAHL')));
 assert.equal(await page.eval('window.__markSelected'),0);
}));

test('RC82 Chromium: query mismatch without operator and without exact suggestion must stop',{timeout:45000},()=>withPage(async page=>{
 await setup(page,'mismatch-no-option');await assert.rejects(
  ()=>selectExactPhase2Mark(page,{fieldId,ticketId:ticket}),e=>e.code==='P2_REVIEW_QUERY_UNSTABLE');
 assert.equal(await page.eval('window.__forwardClicks'),0);
}));

test('RC82 Chromium: wrong ticket binding prevents any reviewer input',{timeout:45000},()=>withPage(async page=>{
 await setup(page,'normal');await assert.rejects(
  ()=>selectExactPhase2Mark(page,{fieldId,ticketId:'12345678'}),e=>e.code==='TICKET_BINDING');
 assert.equal(await page.eval('document.getElementById("mainForm:next-persona-assignment-id").value'),'');
}));

test('RC82 Chromium: two exact suggestions never trigger automatic click',{timeout:45000},()=>withPage(async page=>{
 await setup(page,'two-options');await assert.rejects(
  ()=>selectExactPhase2Mark(page,{fieldId,ticketId:ticket}),e=>e.code==='P2_REVIEW_AMBIGUOUS');
 assert.equal(await page.eval('window.__markSelected'),0);
}));

test('RC82 Chromium: existing exact server-bound account is preserved; no query typed',{timeout:45000},()=>withPage(async page=>{
 await setup(page,'ready-server');const r=await selectExactPhase2Mark(page,{fieldId,ticketId:ticket});
 assert.equal(r.ok,true);assert.equal(r.method,'EXISTING_EXACT_SERVER_FIELD');
 assert.equal(await page.eval('window.__markSelected'),0);
}));

test('RC82 policy: unexpected assignee cannot be silently overwritten by query retry',{timeout:45000},()=>withPage(async page=>{
 await setup(page,'manual-other');const r=await phase2MarkQueryRetryState(page,fieldId);
 assert.equal(r.safe,true); // initial blank may be re-typed once
 await page.call(function(id){document.getElementById(id).value='Other Person (other.account)';},fieldId);
 const x=await phase2MarkQueryRetryState(page,fieldId);
 assert.equal(x.safe,false);assert.equal(x.selectedOther,true);
}));
