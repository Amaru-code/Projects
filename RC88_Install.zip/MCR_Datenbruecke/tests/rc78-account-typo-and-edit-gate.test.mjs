/** RC78 incident regression, based on 87917040 screenshot / ACTION_NOT_UNIQUE log.
 * Synthetic browser only; never sends, saves, forwards or connects to COMARCH. */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {descriptionPhase2Rule,parsePhase2Description} from '../lib/phase2-description.mjs';
import {choosePhase2Candidate} from '../src/phase2-run.mjs';
import {ensurePhase2Edit} from '../lib/phase2-edit-mode.mjs';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
const desc=request=>`USC 20/ DC;PP+\nStandardantwort versendet\n${request}`;
const row=(ticketId,descriptionValue)=>({ticketId,descriptionValue,intelGroupVerified:true});
test('RC78: actual photographed typo Kontoasuzug triggers PDF path (not direct Mark)',()=>{
 const text=desc('Möchte Kontoasuzug'),r=row('87917040',text),rule=descriptionPhase2Rule(r);
 assert.equal(rule.kind,'ACCOUNT_STATEMENT');assert.deepEqual(rule.targets,['DC','PP+']);
 assert(rule.warnings.includes('LEGACY_KONTOASUZUG_TYPO'));
 assert.equal(r.descriptionValue,text,'source text must remain unchanged');
 assert.equal(choosePhase2Candidate([r]).kind,'ACCOUNT_STATEMENT');
});
test('RC78: correct spelling and KA still work; typo alias is exact, not guessed',()=>{
 for(const request of ['Möchte Kontoauszug','Möchte KA','möchte kontoasuzug.','MOECHTE KONTOASUZUG']){
  assert.equal(descriptionPhase2Rule(row('87917040',desc(request))).kind,'ACCOUNT_STATEMENT');
 }
 for(const request of ['Möchte keinen Kontoasuzug','Möchte Kontoasuzug und Beratung','Möchte Kontauszug','Möchte anderen Service']){
  assert.equal(descriptionPhase2Rule(row('87917040',desc(request))).kind,'MARK_DIRECT');
 }
});
test('RC78: DB has precedence even with the historical Kontoasuzug typo',()=>{
 assert.equal(descriptionPhase2Rule(row('99100001',`USC 20/DB+\nStandardantwort versendet\nMöchte Kontoasuzug`)).kind,'DB_DIRECT');
});
test('RC78: unverified Phase1 still blocks despite typo',()=>{
 assert.equal(descriptionPhase2Rule(row('99100001',`USC 20/DC;PP+\nUnbekannt\nMöchte Kontoasuzug`)).kind,'PHASE1_REQUIRED');
});
async function withPage(fn){const exe=findEdgeExecutable();if(!exe){console.log('SKIP: Chromium not available');return;}
 const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-P2-DOM-RC78-'));let browser,cdp;
 try{browser=await launchBrowser({executable:exe,userDataDir:profile,startUrl:'about:blank',headless:true,extraArgs:process.platform==='linux'?['--no-sandbox','--disable-dev-shm-usage']:[]});
  ({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.type==='page'&&t.url==='about:blank');return await fn(page);
 }finally{await cleanupTemporaryTestBrowser({profile,browser,cdp});}}
async function setFixture(page,{id='87917040',buttons=2}={}){await page.call(function(id,buttons){
  document.body.innerHTML=`<span>Ticket-ID: ${id}</span><section style="margin:35px"><input id="mainForm:member-value-id" readOnly style="width:140px;height:36px"></section>`+
   Array.from({length:buttons},(_,i)=>`<button style="margin:15px;width:130px;height:35px">Bearbeiten</button>`).join('');
  window.__clicks=0;for(const b of document.querySelectorAll('button'))b.addEventListener('click',()=>{window.__clicks++;document.getElementById('mainForm:member-value-id').readOnly=false;});
 },id,buttons);}
test('RC78 Chromium: two Bearbeiten buttons => no auto click, operator then verified edit',{timeout:45000},()=>withPage(async page=>{
 await setFixture(page,{buttons:2});const logs=[];let asked=0;
 await ensurePhase2Edit(page,{ticketId:'87917040',log:s=>logs.push(s),ask:async()=>{asked++;
  await page.call(()=>{document.getElementById('mainForm:member-value-id').readOnly=false;});return 'BEARBEITEN_GEOEFFNET';}});
 assert.equal(asked,1);assert.equal(await page.eval('window.__clicks'),0);
 assert(logs.some(s=>s.includes('ACTION_NOT_UNIQUE')&&s.includes('Treffer=2')));
 assert(logs.some(s=>s.includes('PASS P2_EDIT_MODE_VERIFIED')));
}));
test('RC78 Chromium: missing Bearbeiten => precise reason, operator can open verified edit',{timeout:45000},()=>withPage(async page=>{
 await setFixture(page,{buttons:0});const logs=[];
 await ensurePhase2Edit(page,{ticketId:'87917040',log:s=>logs.push(s),ask:async()=>{
  await page.call(()=>{document.getElementById('mainForm:member-value-id').readOnly=false;});return 'BEARBEITEN_GEOEFFNET';}});
 assert(logs.some(s=>s.includes('Treffer=0')));assert.equal(await page.eval('window.__clicks'),0);
}));
test('RC78 Chromium: operator refusal never opens edit or clicks',{timeout:45000},()=>withPage(async page=>{
 await setFixture(page,{buttons:2});
 await assert.rejects(ensurePhase2Edit(page,{ticketId:'87917040',ask:async()=> 'ABBRUCH'}),e=>e.code==='P2_EDIT_OPERATOR_ABORT');
 assert.equal(await page.eval('window.__clicks'),0);
 assert.equal(await page.eval("document.getElementById('mainForm:member-value-id').readOnly"),true);
}));
test('RC78 Chromium: one unique Bearbeiten remains one guarded browser click',{timeout:45000},()=>withPage(async page=>{
 await setFixture(page,{buttons:1});let asked=0;
 await ensurePhase2Edit(page,{ticketId:'87917040',ask:async()=>{asked++;throw Error('Must not be asked');}});
 assert.equal(asked,0);assert.equal(await page.eval('window.__clicks'),1);
}));
test('RC78 Chromium: wrong ticket identity blocks before any edit click or operator prompt',{timeout:45000},()=>withPage(async page=>{
 await setFixture(page,{id:'99999999',buttons:1});let asked=0;
 await assert.rejects(ensurePhase2Edit(page,{ticketId:'87917040',ask:async()=>{asked++;return 'BEARBEITEN_GEOEFFNET';}}),e=>e.code==='TICKET_BINDING');
 assert.equal(asked,0);assert.equal(await page.eval('window.__clicks'),0);
}));
