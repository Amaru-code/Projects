import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
import {queueTableSnapshot,openTicket,detailTicketId} from '../lib/browser-workflow.mjs';

async function withPage(fn){const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC20-NOTE-RC84-NAV-'));let browser,cdp;
 try{browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,extraArgs:process.platform==='linux'?['--no-sandbox','--disable-dev-shm-usage']:[]});({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.type==='page'&&t.url==='about:blank');return await fn(page);}
 finally{await cleanupTemporaryTestBrowser({profile,browser,cdp});}}

async function fixture(page,{header='Ticket-ID',mask=false,extraAction=false}={}){await page.call(function(opts){
 window.__clicked=0;window.__foreign=0;
 const button=`<a id="the-ticket" href="#" onclick="window.__open(event)">88900122</a>`;
 document.body.innerHTML=`<style>body{font:16px Arial;padding:20px}table{border-collapse:collapse}td,th{padding:15px;border:1px solid #aaa}</style>
 <div id="storedSearchesContainer_MY_TASKS"><a id="my">In_Bearbeitung</a></div>
 <table id="mainForm:tasksTableFor_JobAndExecutions"><thead><tr><th>Ticket-ID</th><th>Quelle</th><th>Zusätzliche Beschreibung</th></tr></thead><tbody><tr><td><a onclick="window.__foreign++">88900000</a></td><td>E-MAIL</td><td></td></tr></tbody></table>
 <table id="mainForm:tasksTableFor_MyTasksList"><thead><tr><th>${opts.header}</th><th>Quelle</th><th>Zusätzliche Beschreibung</th></tr></thead><tbody><tr><td>${button}${opts.extraAction?'<a id="extra" href="#"></a>':''}</td><td>E-MAIL</td><td></td></tr></tbody></table>
 <div id="detail"></div>${opts.mask?'<div id="cover" style="position:fixed;inset:0;background:rgba(20,30,40,.1);z-index:200"></div>':''}`;
 window.__open=e=>{e?.preventDefault?.();window.__clicked++;document.getElementById('detail').textContent='Ticket-ID: 88900122';};
 document.getElementById('my').style.fontWeight='bold';
}, {header,mask,extraAction});}

const open = async page=>{
 const snap=await queueTableSnapshot(page);assert.equal(snap.ok,true);assert.equal(snap.scope,'IN_BEARBEITUNG');assert.equal(snap.rows.length,1);
 return snap.rows[0];
};

test('RC84 sortable header: inventory and open click use matching Ticket-ID handling', {timeout:30000},()=>withPage(async page=>{
 await fixture(page,{header:'Ticket-ID ▼'});const row=await open(page);
 const result=await openTicket(page,row,{scope:'IN_BEARBEITUNG'});
 assert.equal(result.mode,'AUTO');assert.equal(await detailTicketId(page),'88900122');
 const x=await page.eval('({clicked:window.__clicked,foreign:window.__foreign})');assert.equal(x.clicked,1);assert.equal(x.foreign,0);
}));

test('RC84 obstructed ticket: exactly bound manual opening, no automatic click', {timeout:30000},()=>withPage(async page=>{
 await fixture(page,{header:'Ticket-ID ▼',mask:true});const row=await open(page);
 let called=0;const result=await openTicket(page,row,{scope:'IN_BEARBEITUNG',manualOpen:async x=>{
   called++;assert.equal(x.ticketId,'88900122');assert.equal(x.scope,'IN_BEARBEITUNG');assert.equal(x.state,'TICKET_ACTION_OCCLUDED');
   await page.call(()=>window.__open());
 }});
 assert.equal(result.mode,'MANUAL');assert.equal(called,1);
 assert.equal((await page.eval('window.__clicked')),1);
}));

test('RC84 no manual authorization: same blocked target still stops without clicking', {timeout:30000},()=>withPage(async page=>{
 await fixture(page,{mask:true});const row=await open(page);
 await assert.rejects(()=>openTicket(page,row,{scope:'IN_BEARBEITUNG'}),e=>e.code==='INTL_TICKET_OPEN_BLOCKED'&&e.openTicketState.state==='TICKET_ACTION_OCCLUDED');
 assert.equal(await page.eval('window.__clicked'),0);
}));

test('RC84 wrong list or ticket ID cannot be manually opened', {timeout:30000},()=>withPage(async page=>{
 await fixture(page,{mask:true});const row=await open(page);
 await assert.rejects(()=>openTicket(page,{ticketId:'88900123'},{scope:'IN_BEARBEITUNG',manualOpen:async()=>{throw Error('Must not reach');}}),e=>e.code==='INTL_TABLE_CHANGED');
 await assert.rejects(()=>openTicket(page,row,{scope:'WARTESCHLANGE_INTL01',manualOpen:async()=>{throw Error('Must not reach');}}),e=>e.code==='INTL_TABLE_CHANGED');
 assert.equal(await page.eval('window.__clicked'),0);
}));
