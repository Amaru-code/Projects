import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';
import {phase2Journal,digestDescription} from '../lib/phase2-write-journal.mjs';
import {restorePendingSaveCandidate} from '../src/phase2-comarch-pilot.mjs';
import {phase2WorkRule} from '../lib/phase2-work-rules.mjs';
const id='87917040',original='USC 20/DC;PP+\nStandardantwort versendet\nMöchte Kontoasuzug';
const withMarker=original+'\nBearbeitet not reviewed';
const initial={ticketId:id,descriptionSha256:digestDescription(original),pdfHashes:[{plan:'DC',sha256:'a'.repeat(64)},{plan:'PP+',sha256:'b'.repeat(64)}]};
function withJournal(run,{ticket=id}={}){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'mcr-rc80-ledger-'));
 try{
  const j=phase2Journal(root,ticket,{initial:{...initial,ticketId:ticket}});
  j.begin();for(const state of ['UPLOAD_INTENT','UPLOAD_VERIFIED','GEVO_INTENT','GEVO_VERIFIED','DESCRIPTION_INTENT','DESCRIPTION_VERIFIED','DRAFT_SAVE_INTENT','DRAFT_SAVE_VERIFIED','TICKET_SAVE_INTENT'])j.advance(state);
  j.recordTicketSaveManualIntent();j.recordTicketSaveNetworkObservation({status:'NETWORK_QUIET',writeStarts:2});
  return run(j);
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}
test('RC80: exact old row is still an account-statement candidate; appended row is already prepared',()=>{
 assert.equal(phase2WorkRule({ticketId:id,descriptionValue:original}).kind,'ACCOUNT_STATEMENT');
 assert.equal(phase2WorkRule({ticketId:id,descriptionValue:withMarker}).kind,'ALREADY_PREPARED');
});
test('RC80: journal can reconstruct exact original only from one appended marker',()=>withJournal(j=>{
 const old=j.read();const row={kind:'ALREADY_PREPARED',ticketId:id,descriptionValue:withMarker};
 const r=restorePendingSaveCandidate(row,old);
 assert.equal(r.kind,'NEEDS_VERIFIED_WWID');assert.equal(r.descriptionValue,original);assert.equal(r.preexistingSavedMarker,true);
 assert.throws(()=>restorePendingSaveCandidate({...row,descriptionValue:withMarker+'\nBearbeitet not reviewed'},old),e=>e.code==='P2_SAVE_RECOVERY_MARKER');
 assert.throws(()=>restorePendingSaveCandidate({...row,descriptionValue:original.replace('20','25')+'\nBearbeitet not reviewed'},old),e=>e.code==='P2_SAVE_RECOVERY_DESCRIPTION_HASH');
}));
test('RC80: exactly one old click and network observation required',()=>withJournal(j=>{
 assert.equal(j.mayRepairMissingMarker(initial),true);
 assert.equal(j.mayRepairMissingMarker({...initial,descriptionSha256:'0'.repeat(64)}),false);
 assert.equal(j.mayRepairMissingMarker({...initial,pdfHashes:[{plan:'DC',sha256:'c'.repeat(64)}]}),false);
}));
test('RC80: never authorize marker-only repair for another ticket',()=>withJournal(j=>{
 assert.equal(j.mayRepairMissingMarker({...initial,ticketId:'87917041'}),false);
}, {ticket:'87917041'}));
test('RC80: operator approval needs independent server evidence',()=>withJournal(j=>{
 assert.throws(()=>j.approveRc80MarkerRepair({...initial,operatorConfirmed:true,serverOriginalExact:true,serverGevoExact:true,attachmentsReviewed:false,notForwarded:true}),e=>e.code==='P2_RC80_REPAIR_NOT_AUTHORIZED');
 assert.equal(j.mayRepairMissingMarker(initial),true);
}));
test('RC80: authorized one-click repair is recorded and cannot be replayed',()=>withJournal(j=>{
 j.approveRc80MarkerRepair({...initial,operatorConfirmed:true,serverOriginalExact:true,serverGevoExact:true,attachmentsReviewed:true,notForwarded:true});
 assert.equal(j.mayRepairMissingMarker(initial),false);
 assert.throws(()=>j.approveRc80MarkerRepair({...initial,operatorConfirmed:true,serverOriginalExact:true,serverGevoExact:true,attachmentsReviewed:true,notForwarded:true}),e=>e.code==='P2_RC80_REPAIR_NOT_AUTHORIZED');
 j.recordRc80MarkerRepairClickIntent('AUTO');
 j.recordRc80RepairNetworkObservation({status:'NETWORK_QUIET',writeStarts:2});
 assert.throws(()=>j.recordRc80RepairNetworkObservation({status:'NETWORK_QUIET',writeStarts:2}),e=>e.code==='P2_RC80_REPAIR_NETWORK_REPLAY');
 assert.equal(j.rc80RepairClickPending(initial),true);
 assert.throws(()=>j.recordRc80MarkerRepairClickIntent('AUTO'),e=>e.code==='P2_RC80_REPAIR_CLICK_REPLAY');
 assert.throws(()=>j.reconcilePersistedSave({...initial,serverDescriptionVerified:true,serverGevoVerified:true,attachmentsReviewed:true}),e=>e.code==='P2_RC80_REPAIR_MUST_BE_AUDITED');
 assert.throws(()=>j.reconcileRc80MarkerRepair({...initial,serverDescriptionVerified:true,serverGevoVerified:false,attachmentsReviewed:true}),e=>e.code==='P2_RC80_REPAIR_PERSISTENCE_REQUIRED');
 j.reconcileRc80MarkerRepair({...initial,serverDescriptionVerified:true,serverGevoVerified:true,attachmentsReviewed:true});
 assert.equal(j.read().state,'TICKET_SAVE_VERIFIED');
 assert.equal(j.read().events.filter(e=>e.state==='RC80_MARKER_REPAIR_CLICK_INTENT').length,1);
 assert.equal(j.read().events.filter(e=>e.state==='RC80_MARKER_REPAIR_SERVER_VERIFIED').length,1);
 assert.equal(j.read().events.filter(e=>e.state==='TICKET_SAVE_MANUAL_CLICK_INTENT').length,1);
 assert.throws(()=>j.reconcileRc80MarkerRepair({...initial,serverDescriptionVerified:true,serverGevoVerified:true,attachmentsReviewed:true}),e=>e.code==='P2_RC80_REPAIR_PERSISTENCE_REQUIRED');
}));
test('RC80: crash after approval (no click yet) must never trigger blind retry',()=>withJournal(j=>{
 j.approveRc80MarkerRepair({...initial,operatorConfirmed:true,serverOriginalExact:true,serverGevoExact:true,attachmentsReviewed:true,notForwarded:true});
 assert.equal(j.mayRepairMissingMarker(initial),false);
 assert.equal(j.rc80RepairClickPending(initial),false);
}));
test('RC80: source never uploads or sends in the missing-marker branch',()=>{
 const source=fs.readFileSync(new URL('../src/phase2-comarch-pilot.mjs',import.meta.url),'utf8');
 const a=source.indexOf("if(recoveryMode==='SERVER_READBACK_ONLY')"),b=source.indexOf('}else if(saveRecoveryMode)',a);
 assert(a>0&&b>a);
 const block=source.slice(a,b);
 assert(block.includes('journal.approveRc80MarkerRepair'));
 assert(block.includes('await saveAndVerify({rc80Repair:true})'));
 assert(!block.includes('attachPhase2Files('));
 assert(!block.includes('savePhase2Draft('));
 assert(!block.includes('sendMail('));
});
