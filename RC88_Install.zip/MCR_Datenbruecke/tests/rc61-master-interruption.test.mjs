import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {ROOT} from './helpers.mjs';
import {ledger,writeJSON} from '../lib/control.mjs';
import {interruptedPilotCandidate} from '../lib/master-pilot-recovery.mjs';
import {masterRun} from '../tools/cli.mjs';

function fixture(){
 const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC61-PILOT-'));
 const root=path.join(tmp,'MCR_Datenbruecke');
 fs.cpSync(ROOT,root,{recursive:true,filter:p=>!p.includes('/.runtime/')&&!p.includes('/Ergebnis/')&&!p.includes('/diagnostics/')});
 return {tmp,root,cleanup:()=>fs.rmSync(tmp,{recursive:true,force:true,maxRetries:6,retryDelay:100})};
}
function last(root,{pilot=true,state='INTERRUPTED_REVIEW_REQUIRED',startedAt=new Date(Date.now()-60000).toISOString()}={}){
 fs.mkdirSync(path.join(root,'.runtime/beta-control'),{recursive:true});
 writeJSON(path.join(root,'.runtime/beta-control/last-run.json'),{schema:'MCR_BETA_RUN_V1',operation:'REAL_RUN',pilot,state,startedAt,runId:'interrupted-pilot'});
}
function verifiedStatus(root,ticket){
 const j=ledger(root);j.set(ticket,'SENT_CONFIRMED');j.set(ticket,'SAVE_INTENT');j.set(ticket,'COMPLETE');
}
test('RC61: last interrupted pilot SEND_INTENT is selected but older unresolved tickets are excluded',()=>{
 const start='2026-11-05T10:14:13.000Z';const rows=[
  {ticketId:'88149870',kind:'SEND',state:'SEND_INTENT',startedAt:'2026-11-04T09:00:00Z'},
  {ticketId:'88296387',kind:'SEND',state:'SEND_INTENT',startedAt:'2026-11-05T10:16:00Z'}];
 assert.deepEqual(interruptedPilotCandidate({schema:'MCR_BETA_RUN_V1',operation:'REAL_RUN',pilot:true,state:'INTERRUPTED_REVIEW_REQUIRED',startedAt:start},rows),{ticketId:'88296387',state:'SEND_INTENT',startedAt:'2026-11-05T10:16:00Z'});
 assert.equal(interruptedPilotCandidate({schema:'MCR_BETA_RUN_V1',operation:'REAL_RUN',pilot:false,state:'INTERRUPTED_REVIEW_REQUIRED',startedAt:start},rows),null);
 assert.equal(interruptedPilotCandidate({schema:'MCR_BETA_RUN_V1',operation:'REAL_RUN',pilot:true,state:'RUNNER_EXIT_0',startedAt:start},rows),null);
 assert.equal(interruptedPilotCandidate({schema:'MCR_BETA_RUN_V1',operation:'REAL_RUN',pilot:true,state:'RUNNING',startedAt:start},[...rows,{ticketId:'88299999',kind:'SEND',state:'SEND_INTENT',startedAt:'2026-11-05T10:17:00Z'}]),null);
});
test('RC61: Master first completes interrupted pilot without another send, then NEW certified pilot, full run, phase2', {timeout:30000},async()=>{
 const f=fixture(),id='88296387',calls=[];
 try{
  last(f.root);ledger(f.root).begin('88149870','USC 1/ PP+\nStandardantwort versendet');ledger(f.root).begin(id,'USC 2/ DC\nStandardantwort versendet');
  // Older intent must not match the date of the just interrupted pilot.
  const file=path.join(f.root,'.runtime/beta-control/ticket-ledger.json');const data=JSON.parse(fs.readFileSync(file));
  for(const obj of Object.values(data.tickets))if(obj.ticketId==='88149870')obj.startedAt='2026-11-04T10:00:00Z';
  writeJSON(file,data);let prompted=0;
  const run=await masterRun({rootDir:f.root,output:()=>{},confirm:async()=>{prompted++;return prompted===1?'MASTER_START':`PRUEFEN ${id}`;},
   recoverPilot:async(_root,ticket)=>{calls.push('REPAIR:'+ticket);verifiedStatus(f.root,ticket);},
   runPhase1:async(pilot)=>{calls.push(pilot?'PILOT':'BATCH');return pilot?{pilotVerified:true,runId:'new-pilot',processed:1}:{verified:true,processed:2,runId:'new-batch'};},
   runPhase2:async()=>{calls.push('PHASE2');return {status:'COMPLETED_VISIBLE_SCOPE',processed:1,skipped:[],runId:'mock-phase2'};}});
  assert.deepEqual(calls,['REPAIR:'+id,'PILOT','BATCH','PHASE2']);
  assert.equal(run.state,'COMPLETE_VISIBLE_SCOPE');
  assert.equal(run.phase1.interruptedPilot.status,'SENT_AND_SAVED_VERIFIED_NO_NEW_EMAIL');
  assert.deepEqual(ledger(f.root).pending.map(x=>x.ticketId),['88149870']);
 }finally{f.cleanup();}
});
test('RC61: denied recovery stops without starting ANY new pilot, old ledger unchanged',{timeout:30000},async()=>{
 const f=fixture();try{
  last(f.root);ledger(f.root).begin('88296387','USC 2/ DC\nStandardantwort versendet');
  const file=path.join(f.root,'.runtime/beta-control/ticket-ledger.json');const before=fs.readFileSync(file);let ran=false;
  await assert.rejects(()=>masterRun({rootDir:f.root,output:()=>{},confirm:async text=>text.includes('Sicher starten')?'MASTER_START':'ABBRUCH',runPhase1:async()=>{ran=true;},runPhase2:async()=>{ran=true;}}),e=>e.code==='MASTER_RECOVERY_NOT_APPROVED');
  assert.equal(ran,false);assert.deepEqual(fs.readFileSync(file),before);
 }finally{f.cleanup();}
});
test('RC61: recovery must actually COMPLETE ticket and keep older pending journal unchanged',{timeout:30000},async()=>{
 const f=fixture();try{
  last(f.root);ledger(f.root).begin('88296387','USC 2/ DC\nStandardantwort versendet');let ran=false;
  await assert.rejects(()=>masterRun({rootDir:f.root,output:()=>{},confirm:async text=>text.includes('Sicher starten')?'MASTER_START':'PRUEFEN 88296387',recoverPilot:async()=>{},runPhase1:async()=>{ran=true;}}),e=>e.code==='RUN_PENDING_CHANGED'||e.code==='MASTER_RECOVERY_NOT_COMPLETED');
  assert.equal(ran,false);assert.equal(ledger(f.root).pending.length,1);
 }finally{f.cleanup();}
});
test('RC61: no new valid pilot means no automatic phase2',{timeout:30000},async()=>{
 const f=fixture();let phase2=false;
 try{
  const r=await masterRun({rootDir:f.root,output:()=>{},confirm:async()=> 'MASTER_START',runPhase1:async()=>({pilotVerified:false,processed:0}),runPhase2:async()=>{phase2=true;}});
  assert.equal(phase2,false);assert.equal(r.state,'PARTIAL_PHASE1_NO_PILOT');
 }finally{f.cleanup();}
});
