import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {queueTableSnapshot,navigateToScope,openTicket,ensureEdit,assertTicket} from '../lib/browser-workflow.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
async function withPage(fn){const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC20-NOTE-RC63-INTEL-'));let browser,cdp;
 try{browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,extraArgs:process.platform==='linux'?['--no-sandbox','--disable-dev-shm-usage']:[]});({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.type==='page'&&t.url==='about:blank');return await fn(page);}
 finally{await cleanupTemporaryTestBrowser({profile,browser,cdp});}}
const table=(id,ticket)=>`<table id="${id}"><thead><tr><th>Ticket-ID</th><th>Quelle</th><th>Zusätzliche Beschreibung</th></tr></thead><tbody><tr><td onclick="window.__ticketOpened(this)">${ticket}</td><td>E-MAIL</td><td></td></tr></tbody></table>`;
test('RC63 only In_Bearbeitung/INTL01 are clicked, even with visible Offene Vorgaenge unrelated ticket',{timeout:30000},()=>withPage(async page=>{
 await page.call(()=>{
  const table=(id,ticket)=>`<table id="${id}"><thead><tr><th>Ticket-ID</th><th>Quelle</th><th>Zusätzliche Beschreibung</th></tr></thead><tbody><tr><td onclick="window.__ticketOpened(this)">${ticket}</td><td>E-MAIL</td><td></td></tr></tbody></table>`;
  window.__clicks={tasks:0,queues:0,mine:0,other:0,opened:0};
  document.body.innerHTML=`<a id="mine">Meine Vorgänge</a><a id="other">Offene Vorgänge</a><div id="storedSearchesContainer_MY_TASKS"><a id="in"><span>In_Bearbeitung</span></a></div><div id="storedSearchesContainer_MY_QUEUES"><a id="intel"><span title="INTL01">INTL01</span></a></div><div id="foreign">${table('mainForm:tasksTableFor_JobAndExecutions','88530248')}</div><div id="current"></div>`;
  window.__ticketOpened=cell=>{window.__clicks.opened++;document.querySelector('#current').innerHTML='<div>Ticket-ID: '+cell.textContent.trim()+'</div><a id="edit">Bearbeiten</a>';document.getElementById('edit').onclick=()=>document.querySelector('#current').insertAdjacentHTML('beforeend','<input id="mainForm:member-value-id">');};
  document.getElementById('mine').onclick=()=>window.__clicks.mine++;
  document.getElementById('other').onclick=()=>window.__clicks.other++;
  document.getElementById('in').onclick=()=>{window.__clicks.tasks++;document.querySelector('#in span').style.fontWeight='bold';document.querySelector('#intel span').style.fontWeight='normal';document.querySelector('#current').innerHTML=table('mainForm:tasksTableFor_MyTasksList','88503774');};
  document.getElementById('intel').onclick=()=>{window.__clicks.queues++;document.querySelector('#intel span').style.fontWeight='bold';document.querySelector('#in span').style.fontWeight='normal';document.querySelector('#current').innerHTML=table('mainForm:tasksTableFor_MyQueuesTasksList','88507393');};
 });
 assert.equal((await queueTableSnapshot(page)).ok,false,'unrelated JobAndExecutions must be ignored');
 const work=await navigateToScope(page,'IN_BEARBEITUNG');assert.equal(work.scope,'IN_BEARBEITUNG');assert.equal(work.rows[0].ticketId,'88503774');
 await assert.rejects(()=>openTicket(page,{ticketId:'88530248'},{scope:'IN_BEARBEITUNG'}),e=>e.code==='INTL_TABLE_CHANGED');
 await openTicket(page,work.rows[0],{scope:'IN_BEARBEITUNG'});await assertTicket(page,'88503774');await ensureEdit(page);
 let clicks=await page.eval('window.__clicks');assert.equal(clicks.opened,1);assert.equal(clicks.mine,0);assert.equal(clicks.other,0);
 const queue=await navigateToScope(page,'WARTESCHLANGE_INTL01');assert.equal(queue.rows[0].ticketId,'88507393');
 clicks=await page.eval('window.__clicks');assert.equal(clicks.mine,0);assert.equal(clicks.other,0);assert.equal(clicks.tasks,1);assert.equal(clicks.queues,1);
 }));
test('RC63 unknown scope is forbidden and cannot click the foreign table',()=>withPage(async page=>{
 await page.call(()=>{document.body.innerHTML='<table id="mainForm:tasksTableFor_JobAndExecutions"><thead><tr><th>Ticket-ID</th><th>Quelle</th><th>Zusätzliche Beschreibung</th></tr></thead><tbody><tr><td>88530248</td><td>E-MAIL</td><td></td></tr></tbody></table>';});
 await assert.rejects(()=>navigateToScope(page,'OFFENE_VORGAENGE'),e=>e.code==='INTL_SCOPE_FORBIDDEN');
 await assert.rejects(()=>openTicket(page,{ticketId:'88530248'},{scope:'WARTESCHLANGE_INTL01'}),e=>e.code==='INTL_TABLE_CHANGED');
 }));
