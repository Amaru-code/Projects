import test from 'node:test';
import assert from 'node:assert/strict';
import {approveOperatorReply,assessReplyEdit,approvedEditorStillMatches} from '../lib/phase1-edited-reply.mjs';
import {verifiedNewOutgoingAcknowledgement} from '../lib/mail-history-audit.mjs';
const ticket='89112070',recipient='original@example.invalid';
const original='Sehr geehrter Herr Test,\n\nvielen Dank.\nMit dieser E-Mail möchten wir Ihnen bestätigen, dass wir Ihr Ticket erhalten haben und unser Team derzeit daran arbeitet.';
const edited=original.replace('vielen Dank.','vielen Dank für Ihre Nachricht und Ihre Geduld.');
const snap=rows=>({ok:true,rows});
const inbound={direction:'INCOMING',sender:recipient,recipient:'serviceline@example.invalid',subject:'[MERCER#89112070] Rückfrage',content:'Bitte helfen',documentId:'1',date:'before'};
const outgoing=content=>({direction:'OUTGOING',sender:'serviceline@example.invalid',recipient,subject:'Re: [MERCER#89112070] Rückfrage',content,documentId:'2',date:'after'});
const config=(text,ask=async()=>`TEXT_${ticket}_FREIGEBEN`)=>({ticketId:ticket,expectedText:original,recipient,
 readEditor:async()=>({ok:true,empty:!text,text}),readRecipient:async()=>({ok:true,address:recipient}),assertTicket:async id=>assert.equal(id,ticket),ask,log:()=>{}});

test('RC85 old unchanged template needs no additional operator confirmation',async()=>{
 let prompts=0;const r=await approveOperatorReply(config(original,async()=>{prompts++;return 'ABBRUCH';}));
 assert.equal(prompts,0);assert.equal(r.edited,false);assert.equal(r.operatorApproved,false);
});
test('RC85 manual minor edit can be approved without replacing or losing text',async()=>{
 let prompts=0;const r=await approveOperatorReply(config(edited,async q=>{prompts++;assert.match(q,/TEXT_89112070_FREIGEBEN/);return 'TEXT_89112070_FREIGEBEN';}));
 assert.equal(prompts,1);assert.equal(r.edited,true);assert.equal(r.operatorApproved,true);assert.equal(r.text,edited);
 assert.equal(approvedEditorStillMatches({editor:{ok:true,text:edited},approvedText:r.text}),true);
 assert.equal(approvedEditorStillMatches({editor:{ok:true,text:edited+' NOCH EINE AENDERUNG'},approvedText:r.text}),false);
});
test('RC85 AUTO mode cannot silently approve a modified reply',async()=>{
 let prompts=0;await approveOperatorReply(config(edited,async()=>{prompts++;return `TEXT_${ticket}_FREIGEBEN`;}));assert.equal(prompts,1);
});
test('RC85 invalid confirmation is re-asked, not an immediate program termination',async()=>{
 const inputs=['FREIGEBEN','TEXT_89112070_FREIGEBEN'];let ix=0;
 const r=await approveOperatorReply(config(edited,async()=>inputs[ix++]));assert.equal(r.edited,true);assert.equal(ix,2);
});
test('RC85 edit during manual approval invalidates old consent and asks again',async()=>{
 const next=edited+' Noch ein Satz.',edits=[edited,next,next,next,next,next];let index=0,approvals=0;
 const r=await approveOperatorReply({...config(edited),readEditor:async()=>({ok:true,text:edits[Math.min(index++,edits.length-1)]}),ask:async()=>{approvals++;return `TEXT_${ticket}_FREIGEBEN`;}});
 assert.equal(r.text,next);assert.equal(approvals,2);
});
test('RC85 no approval on wrong recipient or blank/unreadable editor',async()=>{
 await assert.rejects(()=>approveOperatorReply({...config(edited),readRecipient:async()=>({ok:true,address:'other@example.invalid'})}),{code:'REPLY_REVIEW_RECIPIENT'});
 await assert.rejects(()=>approveOperatorReply(config('')),{code:'REPLY_REVIEW_EDITOR'});
 await assert.rejects(()=>approveOperatorReply({...config(edited),readEditor:async()=>({ok:false})}),{code:'REPLY_REVIEW_EDITOR'});
});
test('RC85 explicit operator cancellation causes no authorization',async()=>{
 await assert.rejects(()=>approveOperatorReply(config(edited,async()=> 'ABBRUCH')),{code:'REPLY_OPERATOR_ABORT'});
});
test('RC85 customized outgoing reply verified only against exact approved body and original sender',()=>{
 const proof=verifiedNewOutgoingAcknowledgement(snap([inbound]),snap([inbound,outgoing(edited)]),ticket,recipient,{approvedReply:edited,operatorApproved:true});
 assert.equal(proof.verified,true,proof.reason);assert.equal(proof.reason,'ONE_OPERATOR_APPROVED_REPLY_ON_BOUND_TICKET');
 const errors=[
  verifiedNewOutgoingAcknowledgement(snap([inbound]),snap([inbound,outgoing(edited+' extra')]),ticket,recipient,{approvedReply:edited,operatorApproved:true}),
  verifiedNewOutgoingAcknowledgement(snap([inbound]),snap([inbound,{...outgoing(edited),recipient:'other@example.invalid'}]),ticket,recipient,{approvedReply:edited,operatorApproved:true}),
  verifiedNewOutgoingAcknowledgement(snap([inbound]),snap([inbound,{...outgoing(edited),subject:'[MERCER#12345678] Falsch'}]),ticket,recipient,{approvedReply:edited,operatorApproved:true}),
  verifiedNewOutgoingAcknowledgement(snap([inbound]),snap([inbound,outgoing('Hallo, hier die individuelle Antwort ohne Standardklausel.')]),ticket,recipient),
  verifiedNewOutgoingAcknowledgement(snap([inbound,outgoing(edited)]),snap([inbound,outgoing(edited)]),ticket,recipient,{approvedReply:edited,operatorApproved:true}),
  verifiedNewOutgoingAcknowledgement(snap([inbound]),snap([inbound,outgoing('')]),ticket,recipient,{approvedReply:edited,operatorApproved:true})
 ];
 assert(errors.every(x=>!x.verified),JSON.stringify(errors));
});
test('RC85 operator version must not be accepted with a forged flag or missing approved text',()=>{
 assert.equal(verifiedNewOutgoingAcknowledgement(snap([inbound]),snap([inbound,outgoing('custom-only text')]),ticket,recipient,{approvedReply:'custom-only text',operatorApproved:false}).verified,false);
 assert.equal(verifiedNewOutgoingAcknowledgement(snap([inbound]),snap([inbound,outgoing('custom-only text')]),ticket,recipient,{operatorApproved:true}).verified,false);
});

