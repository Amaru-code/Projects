import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {canReuseCurrentPdfApproval} from '../lib/phase2-pdf-approval.mjs';
import {phase2SaveReadbackStatus} from '../lib/phase2-save-readback.mjs';
import {savePhase2Ticket} from '../lib/phase2-comarch-actions.mjs';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
import os from 'node:os';
const __dirname=path.dirname(fileURLToPath(import.meta.url));
const ticketId='87917040',wwid='11368763';
const hash=s=>createHash('sha256').update(s).digest('hex');
const member={profileVerified:true,profile:{first:'Lars',last:'Lemke',mercerId:wwid},wwid:null,memberReferenceWwid:wwid};
const proof={ticketId,operatorContentReviewed:true,operatorPersonTicketBindingReviewed:true,memberProfileVerified:true,
 memberId:wwid,memberName:{first:'Lars',last:'Lemke'},wwidSha256:hash(wwid),verifiedAt:new Date().toISOString(),
 artifacts:[{plan:'DC',name:wwid+'_Kontoauszug_DC.pdf',sha256:'a'.repeat(64)},
 {plan:'PP+',name:wwid+'_Kontoauszug_PP+.pdf',sha256:'b'.repeat(64)}]};
const input=()=>({pdfReviewedThisRun:true,sessionPresent:true,ticketId,wwid,member,proof});
test('RC79 PDF approval: operator review performed this run is sufficient for the SECOND identical prompt',()=>assert.equal(canReuseCurrentPdfApproval(input()),true));
test('RC79 PDF approval: no approval from prior run or external invocation',()=>{
 assert.equal(canReuseCurrentPdfApproval({...input(),pdfReviewedThisRun:false}),false);
 assert.equal(canReuseCurrentPdfApproval({...input(),sessionPresent:false}),false);
});
test('RC79 PDF approval: wrong ticket or member is never sufficient',()=>{
 assert.equal(canReuseCurrentPdfApproval({...input(),ticketId:'87917041'}),false);
 assert.equal(canReuseCurrentPdfApproval({...input(),member:{...member,profile:{...member.profile,last:'Other'}}}),false);
 assert.equal(canReuseCurrentPdfApproval({...input(),wwid:'11368764'}),false);
});
test('RC79 PDF approval: old approval / changed content / unchecked rights cannot bypass gate',()=>{
 assert.equal(canReuseCurrentPdfApproval({...input(),proof:{...proof,verifiedAt:new Date(Date.now()-3600000).toISOString()}}),false);
 assert.equal(canReuseCurrentPdfApproval({...input(),proof:{...proof,operatorContentReviewed:false}}),false);
 assert.equal(canReuseCurrentPdfApproval({...input(),proof:{...proof,artifacts:[{...proof.artifacts[0],sha256:'invalid'}]}}),false);
});
const original='USC 20/ DC;PP+\nStandardantwort versendet\nMöchte Kontoauszug',expected=original+'\nBearbeitet not reviewed';
const state=(rows,ok=true)=>phase2SaveReadbackStatus({ticketId,rows,queueOk:ok,expectedDescription:expected,originalDescription:original});
test('RC79 readback: only exact persisted marker proves save',()=>{
 assert.deepEqual(state([{ticketId,descriptionValue:expected}]),{status:'PERSISTED_EXACT'});
 assert.deepEqual(state([{ticketId,descriptionValue:original}]),{status:'ORIGINAL_UNCHANGED'});
});
test('RC79 readback: moved/hidden/unreadable row never proves a save',()=>{
 assert.equal(state([]).status,'TICKET_NOT_IN_VISIBLE_LIST');
 assert.equal(state([],false).status,'QUEUE_NOT_READABLE');
 assert.equal(state([{ticketId,descriptionValue:expected},{ticketId,descriptionValue:expected}]).status,'DUPLICATE_TICKET_ROW');
 assert.equal(state([{ticketId,descriptionValue:original+'\nBearbeitet reviewed'}]).status,'UNEXPECTED_DESCRIPTION');
});
test('RC79 wiring: unique Ticket speichern gets ticket ID and a strict pre-action check',()=>{
 const source=fs.readFileSync(path.join(__dirname,'..','src','phase2-comarch-pilot.mjs'),'utf8');
 assert(source.includes('savePhase2Ticket(page,{ticketId:id,preActionCheck:beforeSave,log,'));
 assert(source.includes("'P2_SAVE_GEVO_CHANGED'"));
 assert(source.includes("'P2_SAVE_ATTACHMENT_STAGE_CHANGED'"));
 assert(source.includes('journal.recordTicketSaveAutoClickIntent()'));
 assert(!source.includes('savePhase2Ticket(page,{manualClick:saveManual,'));
});
test('RC79 wiring: initial PDF review only reused for same-session newly prepared ticket',()=>{
 const source=fs.readFileSync(path.join(__dirname,'..','src','phase2-run.mjs'),'utf8');
 assert(source.includes("pdfReviewedThisRun=prepared.status==='PDF_PROOF_READY'&&prepared.ticketId===id"));
 assert(source.includes('phase2ComarchPilot({root,ticketId:id,session:{page,rl},reviewAuthorized:true,pdfReviewedThisRun'));
});
async function withPage(run){const exe=findEdgeExecutable();if(!exe){console.log('SKIP: Chromium not available');return;}
 const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-P2-DOM-RC79-SAVE-'));let browser,cdp;
 try{browser=await launchBrowser({executable:exe,userDataDir:profile,startUrl:'about:blank',headless:true,
  extraArgs:process.platform==='linux'?['--no-sandbox','--disable-dev-shm-usage']:[]});
  ({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.type==='page'&&t.url==='about:blank');return await run(page);
 }finally{await cleanupTemporaryTestBrowser({profile,browser,cdp});}}
test('RC79 Chromium: occluded unique save anchor activates once without manual confirmation',{timeout:45000},()=>withPage(async page=>{
 await page.call(function(id){
  document.body.innerHTML='<span>Ticket-ID: '+id+'</span>';
  const btn=document.createElement('a');btn.href='javascript:;';btn.id='mainForm:j_idSave';btn.style='display:block;margin:30px;width:180px;height:34px';
  btn.textContent='Ticket speichern';window.__activations=0;btn.addEventListener('click',e=>{e.preventDefault();window.__activations++;});document.body.appendChild(btn);
  const shield=document.createElement('div');shield.style='position:fixed;inset:0;z-index:999999;background:rgba(0,0,0,.1)';document.body.appendChild(shield);
 },ticketId);
 let manual=0,journalIntent=0;const result=await savePhase2Ticket(page,{ticketId,preActionCheck:async()=>{},
  beforeAutoClick:async()=>journalIntent++,manualClick:async()=>manual++});
 assert.equal(result.method,'BOUND_NATIVE_KEYBOARD_ENTER');assert.equal(manual,0);assert.equal(journalIntent,1);
 assert.equal(await page.eval('window.__activations'),1);
}));
test('RC79 Chromium: invalid ticket blocks save and does not ask for manual confirmation',{timeout:45000},()=>withPage(async page=>{
 await page.call(id=>{document.body.innerHTML='<span>Ticket-ID: '+id+'</span><button id="mainForm:save">Ticket speichern</button>';
  window.__activations=0;document.querySelector('button').onclick=()=>window.__activations++;},ticketId);
 let manual=0,intent=0;
 await assert.rejects(savePhase2Ticket(page,{ticketId:'99999999',manualClick:async()=>manual++,beforeAutoClick:async()=>intent++}),e=>e.code==='TICKET_BINDING');
 assert.equal(manual,0);assert.equal(intent,0);assert.equal(await page.eval('window.__activations'),0);
}));
