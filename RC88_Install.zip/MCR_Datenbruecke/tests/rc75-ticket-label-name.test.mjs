/** RC75 tests: exact user-supplied read-only COMARCH name labels, verified
 * ticket binding, original manual fallback, and exact operator approval.
 * These tests never contact COMARCH or send/save an e-mail. */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {candidateFromNameLabels,discoverCurrentTicketNameLabels,NAME_LABEL_IDS,NAME_LABEL_SOURCE,readCurrentTicketNameLabels} from '../lib/comarch-name-labels.mjs';
import {confirmMemberCorrection} from '../lib/member-review.mjs';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';

const good={ok:true,firstName:'Christian',lastName:'Baumgart'};
test('RC75: two supplied values produce ONLY a name-search hint (never authorization)',()=>{
 const r=candidateFromNameLabels(good);assert.equal(r.status,'CANDIDATE');
 assert.deepEqual([r.person.firstName,r.person.lastName],['Christian','Baumgart']);
 assert.equal(r.person.name,'Christian Baumgart');
 assert.deepEqual(r.person.sources,[NAME_LABEL_SOURCE]);
 assert.equal(r.person.manualConfirmed,false);
 for(const field of ['identityVerified','memberVerified','sendAuthorized','send','save','click'])assert.equal(Object.hasOwn(r,field),false);
});
test('RC75: Umlauts, double first name and hyphenated surname are retained',()=>{
 for(const [firstName,lastName] of [['Jürgen Michael','Wiedemann'],['Anne-Marie',"O’Connor"],['Karl','von der Meer']]){
  const r=candidateFromNameLabels({ok:true,firstName,lastName});assert.equal(r.status,'CANDIDATE');
  assert.deepEqual([r.person.firstName,r.person.lastName],[firstName,lastName]);
 }
});
test('RC75: missing/ambiguous/hidden labels do not invent an identity',()=>{
 for(const reason of ['FIRST_NOT_UNIQUE','LAST_HIDDEN','FIRST_WRONG_FIELD_SHAPE','FORM_MISSING']){
  assert.deepEqual(candidateFromNameLabels({ok:false,reason}),{status:'NO_CANDIDATE',reason});
 }
});
test('RC75: invalid names and labels do not become candidates',()=>{
 for(const value of ['', 'V', '12345', 'Vorname', 'Unbekannt','Max99','Christian@example.org','<script>','GmbH', 'Support']){
  assert.equal(candidateFromNameLabels({...good,firstName:value}).status,'NO_CANDIDATE',value);
 }
});
function makePage(snapshot,ids=['88814831','88814831']){
 const page={calls:0,async call(fn,arg){this.calls++;assert.equal(fn,readCurrentTicketNameLabels);assert.deepEqual(arg,NAME_LABEL_IDS);if(snapshot instanceof Error)throw snapshot;return snapshot;}};
 let step=0;return {page,readTicketId:async()=>ids[Math.min(step++,ids.length-1)]};
}
test('RC75: exact ticket binding before+after the read permits one hint only',async()=>{
 const f=makePage(good);const lines=[];
 const r=await discoverCurrentTicketNameLabels(f.page,'88814831',{readTicketId:f.readTicketId,log:x=>lines.push(x)});
 assert.equal(r.status,'CANDIDATE');assert.equal(r.person.name,'Christian Baumgart');assert.equal(f.page.calls,1);
 assert(lines.some(x=>x.startsWith('NAME_DISCOVERY: '+NAME_LABEL_SOURCE)));
});
test('RC75: wrong ticket BEFORE lookup never even accesses the labels',async()=>{
 const f=makePage(good,['88814832']);const r=await discoverCurrentTicketNameLabels(f.page,'88814831',{readTicketId:f.readTicketId});
 assert.equal(r.reason,'TICKET_BINDING_BEFORE_MISMATCH');assert.equal(f.page.calls,0);
});
test('RC75: changed ticket AFTER lookup discards previous values',async()=>{
 const f=makePage(good,['88814831','88814832']);const r=await discoverCurrentTicketNameLabels(f.page,'88814831',{readTicketId:f.readTicketId});
 assert.equal(r.reason,'TICKET_BINDING_AFTER_MISMATCH');assert.equal(f.page.calls,1);
});
test('RC75: missing ID, browser error and no label retain original manual fallback',async()=>{
 const f=makePage(good);assert.equal((await discoverCurrentTicketNameLabels(f.page,null,{readTicketId:f.readTicketId})).status,'NO_CANDIDATE');assert.equal(f.page.calls,0);
 const g=makePage(new Error('CDP unavailable'));assert.equal((await discoverCurrentTicketNameLabels(g.page,'88814831',{readTicketId:g.readTicketId})).reason,'BROWSER_READ_FAILED');
 const h=makePage({ok:false,reason:'FIRST_NOT_UNIQUE'});assert.equal((await discoverCurrentTicketNameLabels(h.page,'88814831',{readTicketId:h.readTicketId})).reason,'FIRST_NOT_UNIQUE');
});

async function withPage(fn){const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-P2-DOM-RC75-LABEL-'));let browser,cdp;
 try{browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,extraArgs:process.platform==='linux'?['--no-sandbox','--disable-dev-shm-usage']:[]});({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.type==='page'&&t.url==='about:blank');return await fn(page);}
 finally{await cleanupTemporaryTestBrowser({profile,browser,cdp});}
}
async function fixture(page,{duplicate=false,wrongForm=false,hideFirst=false,wrongClass=false,ticketId='88814831',missingLast=false}={}){
 await page.call(function(opts){
  document.body.innerHTML='';
  const title=document.createElement('div');title.textContent='Ticket-ID: '+opts.ticketId;document.body.appendChild(title);
  const form=document.createElement('form');form.id='mainForm';document.body.appendChild(form);
  const outside=document.createElement('form');outside.id='otherForm';document.body.appendChild(outside);
  function make(id,value,parent){const n=document.createElement('label');n.id=id;n.className=opts.wrongClass?'different-class':'iceOutLbl mercer-value-180';n.textContent=value;parent.appendChild(n);return n;}
  const first=make('mainForm:j_id5899','Christian',form);
  if(opts.hideFirst)first.hidden=true;
  if(!opts.missingLast)make('mainForm:j_id5919','Baumgart',opts.wrongForm?outside:form);
  if(opts.duplicate)make('mainForm:j_id5899','Andere Person',form);
 },{duplicate,wrongForm,hideFirst,wrongClass,ticketId,missingLast});
}
test('RC75: real Chromium DOM reads precisely the supplied labels, never stale/hidden/foreign fields', {timeout:60000},()=>withPage(async page=>{
 await fixture(page);
 let r=await discoverCurrentTicketNameLabels(page,'88814831');assert.equal(r.person?.name,'Christian Baumgart');
 for(const [opts,reason] of [[{duplicate:true},'FIRST_NOT_UNIQUE'],[{wrongForm:true},'LAST_WRONG_FIELD_SHAPE'],[{hideFirst:true},'FIRST_HIDDEN'],[{wrongClass:true},'FIRST_WRONG_FIELD_SHAPE'],[{missingLast:true},'LAST_NOT_UNIQUE']]){
  await fixture(page,opts);r=await discoverCurrentTicketNameLabels(page,'88814831');assert.equal(r.status,'NO_CANDIDATE');assert.equal(r.reason,reason);
 }
 await fixture(page,{ticketId:'88814832'});r=await discoverCurrentTicketNameLabels(page,'88814831');assert.equal(r.reason,'TICKET_BINDING_BEFORE_MISMATCH');
}));

function correctionInputs(gate){const inputs=['11375424','James Michael','Curran',gate];return async()=>inputs.shift();}
const member={id:'11375424',source:'MEMBER_PROFILE_VERIFIED',profileIdMatches:true,firstName:'James Michael',lastName:'Curran'};
const mailPerson={firstName:'James',lastName:'Curran',sources:['SENDER_DISPLAY']};
test('RC75: explicit operator confirmation with UNDERSCORE is accepted after ID+both names',async()=>{
 for(const gate of ['ZUORDNUNG_GEPRUEFT','zuordnung_GEPRUEFT','ZUORDNUNG GEPRUEFT']){
  const r=await confirmMemberCorrection({member,mailPerson,evidence:{expectedId:null},ask:correctionInputs(gate)});
  assert.equal(r.reviewed,true);
 }
});
test('RC75: weak confirmations remain forbidden even with matching ID + both names',async()=>{
 for(const gate of ['JA','GEPRUEFT','ZUORDNUNGGEPRUEFT','ZUORDNUNG_GERPUFT','ZUORDNUNG_GEPRUEFT UND WEITER']){
  await assert.rejects(()=>confirmMemberCorrection({member,mailPerson,evidence:{expectedId:null},ask:correctionInputs(gate)}),{code:'MEMBER_REVIEW_NOT_AUTHORIZED'});
 }
});
test('RC75: explicit current MercerID conflict still blocks name correction before any questions',async()=>{
 let calls=0;await assert.rejects(()=>confirmMemberCorrection({member,mailPerson,evidence:{expectedId:'99900001'},ask:async()=>{calls++;return 'ZUORDNUNG_GEPRUEFT';}}),{code:'MEMBER_ID_CONFLICT'});assert.equal(calls,0);
});
