import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {ROOT} from './helpers.mjs';
import {confirmMemberCorrection} from '../lib/member-review.mjs';
import {masterRun,OPERATOR_MENU} from '../tools/cli.mjs';
import {authorizeMasterBatch} from '../lib/continuation-policy.mjs';
import {reactivateMemberAutocomplete} from '../lib/browser-workflow.mjs';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';

const member={id:'11375424',source:'MEMBER_PROFILE_VERIFIED',profileIdMatches:true,firstName:'James Michael',lastName:'Curran'};
const mail={firstName:'James',lastName:'Curran',sources:['SENDER_DISPLAY']};
test('RC86 ENTER accepts verified ID plus both names, but not incomplete identity',async()=>{
 const input=['11375424','James Michael','Curran',''];let ix=0;
 const reply=await confirmMemberCorrection({member,mailPerson:mail,evidence:{expectedId:null},ask:async()=>input[ix++]});
 assert.equal(reply.reviewed,true);assert.equal(ix,4);
 await assert.rejects(()=>confirmMemberCorrection({member,mailPerson:mail,evidence:{expectedId:null},ask:async()=>''}),{code:'MEMBER_REVIEW_CANCELLED'});
});
test('RC86 ENTER authorization does not bypass a wrong MercerID',async()=>{
 await assert.rejects(()=>confirmMemberCorrection({member,mailPerson:mail,evidence:{expectedId:'11888888'},ask:async()=>''}),{code:'MEMBER_ID_CONFLICT'});
});
test('RC86 normal menu has only install, mapping, phase1, phase2, master and exit',()=>{
 assert.equal(OPERATOR_MENU.length,6);
 assert(OPERATOR_MENU[2].includes('3  PHASE 1'));
 assert(OPERATOR_MENU[3].includes('4  PHASE 2'));
 assert(OPERATOR_MENU[4].includes('5  MASTER RUN'));
 assert(!OPERATOR_MENU.join(' ').includes('Fiktive Szenarien'));
});
const fixture=()=>{const t=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC86-FLOW-'));const root=path.join(t,'MCR_Datenbruecke');fs.cpSync(ROOT,root,{recursive:true,filter:p=>!p.includes('/.runtime/')&&!p.includes('/Ergebnis/')&&!p.includes('/diagnostics/')});return {root,close:()=>fs.rmSync(t,{recursive:true,force:true})};};
test('RC86 phase1 standalone processes more than six tickets and never starts phase2', {timeout:30000},async()=>{
 const f=fixture();let phase2=0,round=0;const n=[];
 try{
  const res=await masterRun({rootDir:f.root,phase1Only:true,confirm:async()=> 'PHASE1_START',output:x=>n.push(x),
   runPhase1:async(pilot,o)=>pilot?{pilotVerified:true,runId:'p-2026-11-12-long',processed:1}:({verified:true,runId:'b-2026-11-12-long',processed:round++===0?100:6,finishReason:round===2?'NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS':undefined}),
   runPhase2:async()=>{phase2++;throw Error('Phase 2 must never run');}});
  assert.equal(phase2,0);assert.equal(res.state,'PHASE1_COMPLETE_VISIBLE_SCOPE');
  assert.equal(res.phase1.batches.length,2);assert.deepEqual(res.phase1.batches.map(x=>x.processed),[100,6]);
  assert.equal(res.phase2.status,'NOT_REQUESTED');
  assert.equal(res.explicitMasterStart,false);assert.equal(res.explicitPhase1Start,true);
 }finally{f.close();}
});
test('RC86 phase1-only with no tickets finishes without phase2, but never forges pilot', {timeout:30000},async()=>{
 const f=fixture();let phase2=false;
 try{
  const r=await masterRun({rootDir:f.root,phase1Only:true,confirm:async()=> 'PHASE1_START',output:()=>{},
   runPhase1:async()=>({noEligible:true,processed:0,reason:'NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS',runId:'no-2026-11-12'}),runPhase2:async()=>{phase2=true;}});
  assert.equal(r.state,'PHASE1_COMPLETE_VISIBLE_SCOPE');assert.equal(phase2,false);
  assert.equal(r.phase1.noSendPilot,true);
 }finally{f.close();}
});
test('RC86 phase1 batch authorization still needs an exact send pilot and valid approval',()=>{
 const hash='a'.repeat(64),id='2026-11-12T08-11-15_123';
 const report={schema:'MCR_MASTER_RUN_V1',id,state:'PHASE1',phase1:{status:'RUNNING'},explicitPhase1Start:true,explicitMasterStart:false,manifestSha256:hash,mappingSha256:hash};
 const receipt={schema:'MCR_COMPLETE_PILOT_PASS_V1',runId:'pilot-2026-11-12T08-11-15',manifestSha256:hash,mappingSha256:hash};
 assert.equal(authorizeMasterBatch({masterId:id,masterReport:report,receipt,manifestSha:hash,mappingSha:hash,ticketLimit:100}),true);
 assert.throws(()=>authorizeMasterBatch({masterId:id,masterReport:{...report,explicitPhase1Start:false},receipt,manifestSha:hash,mappingSha:hash,ticketLimit:100}),{code:'MASTER_BATCH_NOT_AUTHORIZED'});
 assert.throws(()=>authorizeMasterBatch({masterId:id,masterReport:report,receipt:{...receipt,mappingSha256:'b'.repeat(64)},manifestSha:hash,mappingSha:hash,ticketLimit:100}),{code:'MASTER_SEND_PILOT_REQUIRED'});
});
test('RC86 Member filter: one trusted click on the same input reactivates suggestions without changing text', {timeout:30000},async()=>{
 const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC20-NOTE-RC86-MEMBER-'));let browser,cdp;
 try{
  browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,extraArgs:process.platform==='linux'?['--no-sandbox','--disable-dev-shm-usage']:[]});
  ({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.type==='page'&&t.url==='about:blank');
  await page.call(()=>{document.body.innerHTML='<div style="margin:45px"><label>Member<input id="mainForm:member-value-id" value="Strobl Stefan"/></label><output id="state"></output><input id="foreign" /></div>';window.__clicks=0;document.getElementById('mainForm:member-value-id').addEventListener('click',()=>{window.__clicks++;document.getElementById('state').textContent='FILTER_ACTIVE';});});
  assert.equal(await reactivateMemberAutocomplete(page,'Strobl Stefan'),true);
  const state=await page.eval("({value:document.getElementById('mainForm:member-value-id').value,clicks:window.__clicks,result:document.getElementById('state').textContent})");
  assert.equal(state.value,'Strobl Stefan');assert.equal(state.clicks,1);assert.equal(state.result,'FILTER_ACTIVE');
  assert.equal(await reactivateMemberAutocomplete(page,'Fremde Person'),false);
  assert.equal(await page.eval('window.__clicks'),1);
 }finally{await cleanupTemporaryTestBrowser({profile,browser,cdp});}
});
