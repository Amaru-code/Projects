import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {ROOT} from './helpers.mjs';
import {menu3Flow,masterRun} from '../tools/cli.mjs';
import {authorizeForwardPilotContinuation,authorizeChainedContinuation,authorizeMasterBatch} from '../lib/continuation-policy.mjs';
import {resumableLegacyDirectJournal} from '../lib/phase2-legacy-direct-admission.mjs';
import {choosePhase2Candidate} from '../src/phase2-run.mjs';
import {inspectPhase2Tickets} from '../lib/phase2-intake-audit.mjs';

const fwd=i=>({pilotVerified:false,forwardVerified:true,processed:1,runId:'2026-11-11T'+String(i).padStart(2,'0')+'-00-00_forward'});
const sent={pilotVerified:true,processed:1,runId:'2026-11-11T08-00-00_send',deliveryMode:'MANUAL'};
const empty={pilotVerified:false,noEligible:true,processed:0,runId:'2026-11-11T09-00-00_empty',reason:'NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS'};
const done={status:'COMPLETED_VISIBLE_SCOPE',processed:1,skipped:[],scope:'VISIBLE_MY_TASKS_NO_PAGINATION',runId:'phase2-test-run'};
function fixture(){const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC83-MASTER-')),root=path.join(tmp,'MCR_Datenbruecke');
 fs.cpSync(ROOT,root,{recursive:true,filter:p=>!p.includes('/.runtime/')&&!p.includes('/diagnostics/')&&!p.includes('/Ergebnis/')});return {root,close:()=>fs.rmSync(tmp,{recursive:true,force:true})};}

test('RC83: menu 3, forward/forward/send then only THREE additional tickets, not 5 extra',async()=>{
 const calls=[],pilot=[fwd(1),fwd(2),sent];let idx=0;
 const result=await menu3Flow({runPhase1:async(pilotFlag,opts)=>{assert.equal(pilotFlag,true);calls.push(opts);return pilot[idx++];},
  runFull:async(flag,opts)=>{assert.equal(flag,false);calls.push(opts);return {verified:true};},output:()=>{}});
 assert.equal(result.status,'SUCCESS');assert.equal(result.processedByPilots,3);assert.equal(result.pilotVerified,true);
 assert.deepEqual(calls[0],{});assert.deepEqual(calls[1],{forwardChainRunId:fwd(1).runId});
 assert.deepEqual(calls[2],{forwardChainRunId:fwd(2).runId});
 assert.equal(calls[3].limitAfterPilot,3);assert.equal(calls[3].pilotRunId,sent.runId);
});
test('RC83: menu 3, six verified forwards terminate at 6; never fabricate a send pilot',async()=>{
 let n=0,bulks=0;const r=await menu3Flow({runPhase1:async()=>fwd(++n),runFull:async()=>{bulks++;},output:()=>{}});
 assert.equal(n,6);assert.equal(bulks,0);assert.equal(r.status,'LIMIT');assert.equal(r.pilotVerified,false);
});
test('RC83: menu 3, forward then two lists exhausted; stop without sending or bulk permission',async()=>{
 let n=0;const r=await menu3Flow({runPhase1:async()=>[fwd(1),empty][n++],runFull:async()=>{throw Error('no bulk');},output:()=>{}});
 assert.equal(r.status,'NO_MORE_ELIGIBLE');assert.equal(r.processedByPilots,1);
});
test('RC83: menu 3 invalid result or empty route id cannot authorize follow-on',async()=>{
 const invalid=await menu3Flow({runPhase1:async()=>({forwardVerified:true,processed:1,runId:''}),output:()=>{}}).then(()=>null,e=>e);
 assert.equal(invalid?.code,'MENU3_FORWARD_PROOF');
});

test('RC83: forward-only continuation bound to one pilot, exact manifest, map, and run id',()=>{
 const hash='a'.repeat(64),mapping='b'.repeat(64),runId='2026-11-11T13-00-00_forward';
 const receipt={schema:'MCR_COMPLETE_FORWARD_PILOT_PASS_V1',runId,manifestSha256:hash,mappingSha256:mapping,noEmail:true,forwardVerified:true,ticketLimit:1};
 const input={runId,receipt,manifestSha:hash,mappingSha:mapping,ticketLimit:1};
 assert.equal(authorizeForwardPilotContinuation(input),true);
 for(const patch of [{ticketLimit:5},{runId:'unmatched-long-ticket'},{receipt:{...receipt,noEmail:false}},
  {receipt:{...receipt,forwardVerified:false}},{receipt:{...receipt,schema:'MCR_COMPLETE_PILOT_PASS_V1'}},
  {manifestSha:'c'.repeat(64)},{mappingSha:'d'.repeat(64)}]){
  assert.throws(()=>authorizeForwardPilotContinuation({...input,...patch}),patch.toString());
 }
 assert.equal(authorizeChainedContinuation({runId,receipt:{schema:'MCR_COMPLETE_PILOT_PASS_V1',runId,manifestSha256:hash,mappingSha256:mapping},manifestSha:hash,mappingSha:mapping,ticketLimit:3}),true);
 assert.throws(()=>authorizeChainedContinuation({runId,receipt,manifestSha:hash,mappingSha:mapping,ticketLimit:3}));
});
test('RC83: a forward receipt alone NEVER authorizes master bulk emails',()=>{
 const h='a'.repeat(64),m='b'.repeat(64),id='2026-11-11T08-00-00_master';
 const masterReport={schema:'MCR_MASTER_RUN_V1',id,state:'PHASE1',phase1:{status:'RUNNING'},explicitMasterStart:true,manifestSha256:h,mappingSha256:m};
 const receipt={schema:'MCR_COMPLETE_PILOT_PASS_V1',runId:'2026-11-11T08-01-00_send',manifestSha256:h,mappingSha256:m};
 const input={masterId:id,masterReport,receipt,manifestSha:h,mappingSha:m,ticketLimit:100};
 assert.equal(authorizeMasterBatch(input),true);
 for(const patch of [{ticketLimit:101},{receipt:{...receipt,schema:'MCR_COMPLETE_FORWARD_PILOT_PASS_V1'}},
  {masterReport:{...masterReport,state:'PHASE2'}},{masterReport:{...masterReport,explicitMasterStart:false}},
  {masterId:'no'}, {mappingSha:'c'.repeat(64)}])assert.throws(()=>authorizeMasterBatch({...input,...patch}));
});

test('RC83 real master sequencing: two no-email forwards, certified send, batch, independent phase2',async()=>{
 const f=fixture(),calls=[];let n=0;
 try{
  const report=await masterRun({rootDir:f.root,confirm:async()=> 'MASTER_START',output:()=>{},
   runPhase1:async(pilot,opts)=>{
    if(pilot){calls.push('pilot'+n);const p=[fwd(1),fwd(2),sent][n++];if(n>1)assert.equal(opts.forwardChainRunId,fwd(n-1).runId);return p;}
    calls.push('batch');assert.equal(opts.masterLimit,100);assert.ok(opts.masterId);return {verified:true,processed:3,runId:'2026-11-11T08-10-00_batch',finishReason:'NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS'};},
   runPhase2:async({masterApproved})=>{calls.push('phase2');assert.equal(masterApproved,true);return done;}});
  assert.deepEqual(calls,['pilot0','pilot1','pilot2','batch','phase2']);
  assert.equal(report.state,'COMPLETE_VISIBLE_SCOPE');assert.equal(report.phase1.forwardedBeforeSendPilot,2);
  assert.deepEqual(report.phase1.pilotAttempts.map(x=>x.outcome),['FORWARD_NO_EMAIL','FORWARD_NO_EMAIL','SEND_SAVED']);
  assert.equal(report.phase1.status,'VERIFIED');
 }finally{f.close();}
});
test('RC83 master: forwards then no more Phase-1 cases => Phase2 without ever granting bulk send',async()=>{
 const f=fixture();let n=0,batches=0,p2=0;
 try{const r=await masterRun({rootDir:f.root,confirm:async()=> 'MASTER_START',output:()=>{},runPhase1:async(pilot,opts)=>{
   assert.equal(pilot,true);if(n===1)assert.equal(opts.forwardChainRunId,fwd(1).runId);return [fwd(1),empty][n++];},
  runPhase2:async()=>{p2++;return done;}});
  assert.equal(n,2);assert.equal(batches,0);assert.equal(p2,1);
  assert.equal(r.phase1.noSendPilot,true);assert.equal(r.phase1.forwardedBeforeSendPilot,1);
  assert.equal(r.phase1.status,'NO_ELIGIBLE_TICKETS');
 }finally{f.close();}
});
test('RC83 master: failed forward or spoofed pilot stops before Phase-2',async()=>{
 const f=fixture();let phase2=false;try{
  const r=await masterRun({rootDir:f.root,confirm:async()=> 'MASTER_START',output:()=>{},runPhase1:async()=>({forwardVerified:true,processed:1,runId:''}),runPhase2:async()=>{phase2=true;}});
  assert.equal(r.state,'PARTIAL_PHASE1_NO_PILOT');assert.equal(phase2,false);
 }finally{f.close();}
});

test('RC83: only exact RC76 DB direct journal pre-execution can resume on restored original description',()=>{
 const before='USC 20/ DB+\nStandardantwort versendet\nMöchte Unterlagen',after=before+'\nBearbeitet not reviewed',ticketId='88078437';
 const work={schema:'MCR_PHASE2_WORK_JOURNAL_V1',ticketId,rule:'DB_DIRECT',state:'REVIEW_VERIFIED',descriptionBefore:before,descriptionAfter:after,
  events:[{state:'TICKET_SAVE_VERIFIED'},{state:'REVIEW_VERIFIED'}]};
 const row={ticketId,descriptionValue:before,intelGroupVerified:true};
 assert.equal(resumableLegacyDirectJournal(work,before),true);
 assert.equal(choosePhase2Candidate([row],{getWorkJournal:()=>work}).row?.ticketId,ticketId);
 const a=inspectPhase2Tickets([row],{getWorkJournal:()=>work});assert.equal(a.counts.resume,1);
 assert.equal(resumableLegacyDirectJournal({...work,state:'EXECUTE_INTENT'},before),false);
 assert.equal(resumableLegacyDirectJournal({...work,events:[...work.events,{state:'EXECUTE_INTENT'}]},before),false);
 assert.equal(resumableLegacyDirectJournal(work,before+'\nUnbekannt'),false);
 assert.equal(resumableLegacyDirectJournal({...work,descriptionAfter:before+'\nOther'},before),false);
 assert.equal(resumableLegacyDirectJournal({...work,rule:'MBC_PRIVATE_EMAIL'},before),false);
 const blocked=choosePhase2Candidate([row],{getWorkJournal:()=>({...work,events:[...work.events,{state:'EXECUTE_INTENT'}]})});
 assert.equal(blocked.row,null);assert.equal(blocked.skipped[0].reason,'WORK_JOURNAL_REVIEW_REQUIRED');
});
test('RC83 master never labels full completion while identity cases still require manual review',async()=>{
 const f=fixture();try{
  const r=await masterRun({rootDir:f.root,confirm:async()=> 'MASTER_START',output:()=>{},
   runPhase1:async pilot=>pilot?{...sent,skippedIdentity:1}:{verified:true,processed:2,runId:'2026-11-11T08-10-00_batch',finishReason:'NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS',skippedIdentity:1},
   runPhase2:async()=>done});
  assert.equal(r.state,'PARTIAL_PHASE1_MANUAL_IDENTITY_REVIEW');
  assert.equal(r.phase1.manualIdentityReviewObserved,2);
 }finally{f.close();}
});
