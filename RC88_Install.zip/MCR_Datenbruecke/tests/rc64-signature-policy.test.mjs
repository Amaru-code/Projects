import test from 'node:test';
import assert from 'node:assert/strict';
import {phase1SignatureState as state,mayChoosePhase1Signature,mayRetryPhase1Signature} from '../lib/phase1-signature-policy.mjs';
const expected='INTL01 - Intel Deutschland GmbH';
test('RC64 exact COMARCH signature is stable readback',()=>{
 assert.equal(state(expected,expected),'EXACT');
 assert.equal(mayChoosePhase1Signature('EXACT'),true);
 assert.equal(mayRetryPhase1Signature('EXACT'),false);
});
test('RC64 ICEfaces blank after exact option may be reselected once',()=>{
 assert.equal(state('',expected),'EMPTY');
 assert.equal(mayChoosePhase1Signature('EMPTY'),true);
 assert.equal(mayRetryPhase1Signature('EMPTY'),true);
});
test('RC64 foreign, search-prefix and unbound field are never automatically overwritten or accepted',()=>{
 for(const value of ['INTL01 - Intel', 'Fremde Signatur', ' INTL01 - Intel Deutschland GmbH ']){
  assert.equal(state(value,expected),'CONFLICT');
  assert.equal(mayChoosePhase1Signature(state(value,expected)),false);
  assert.equal(mayRetryPhase1Signature(state(value,expected)),false);
 }
 for(const value of [null,undefined,42])assert.equal(state(value,expected),'UNBOUND');
 assert.equal(mayChoosePhase1Signature('UNBOUND'),false);
});
