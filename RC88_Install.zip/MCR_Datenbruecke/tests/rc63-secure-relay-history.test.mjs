import test from 'node:test';
import assert from 'node:assert/strict';
import {verifiedNewOutgoingAcknowledgement,subjectOfSameConversation} from '../lib/mail-history-audit.mjs';
const id='88503774',relay='secureemail@mmc.com';
const standard='Sehr geehrter Herr Beispiel, vielen Dank. Mit dieser E-Mail möchten wir Ihnen bestätigen, dass wir Ihr Ticket erhalten haben und unser Team derzeit daran arbeitet. Wir helfen Ihnen weiter.';
const incoming={direction:'INCOMING',sender:relay,recipient:'servicelineintel@mercer.com',subject:'RE: [MERCER#79983720][SEND SECURE] Re: [MERCER#77760076] Login after departure from Intel',content:'Dear Mercer Serviceteam, I would like to follow up on the previous response about the vesting statement. Regards, Ken',documentId:'12998433',date:'06.11.2026 10:20'};
const outgoing={direction:'OUTGOING',sender:'servicelineintel@mercer.com',recipient:relay,subject:'[MARSH#88503774] RE: [MERCER#79983720] Re: [MERCER#77760076] Login after departure from Intel',content:standard,documentId:'13001796',date:'06.11.2026 11:34'};
const snap=rows=>({ok:true,rows});
test('RC63 exact new outgoing email under MARSH ticket tag and secure relay is verified automatically',()=>{
 const result=verifiedNewOutgoingAcknowledgement(snap([incoming]),snap([incoming,outgoing]),id,relay);
 assert.equal(result.verified,true,result.reason);assert.equal(result.subjectBinding,'EXACT_TICKET_SUBJECT');
 assert.equal(subjectOfSameConversation(incoming.subject,outgoing.subject,id).ok,true);
});
test('RC63 no send proof from changed original, old outgoing or two new rows',()=>{
 assert.equal(verifiedNewOutgoingAcknowledgement(snap([incoming]),snap([incoming]),id,relay).verified,false);
 assert.equal(verifiedNewOutgoingAcknowledgement(snap([incoming,outgoing]),snap([incoming,outgoing]),id,relay).verified,false);
 assert.equal(verifiedNewOutgoingAcknowledgement(snap([incoming]),snap([{...incoming,documentId:'1'},outgoing]),id,relay).verified,false);
 assert.equal(verifiedNewOutgoingAcknowledgement(snap([incoming]),snap([incoming,outgoing,{...outgoing,documentId:'13001800'}]),id,relay).verified,false);
});
test('RC63 wrong ticket, wrong recipient, missing standard text or unknown sender are blocked',()=>{
 for(const other of [
  {...outgoing,subject:'[MARSH#88530248] Different ticket'},
  {...outgoing,recipient:'other@example.invalid'},
  {...outgoing,content:'Andere Nachricht'},
  {...outgoing,sender:'external@example.invalid'},
  {...outgoing,direction:'INCOMING'},
 ])assert.equal(verifiedNewOutgoingAcknowledgement(snap([incoming]),snap([incoming,other]),id,relay).verified,false,JSON.stringify(other));
 assert.equal(verifiedNewOutgoingAcknowledgement(snap([incoming]),snap([incoming,outgoing]),'88530248',relay).verified,false);
});
test('RC63 delivery bounce or unrelated gateway sender cannot count as an original customer message',()=>{
 const bounce={...incoming,subject:'Delivery status notification - failed'};
 assert.equal(verifiedNewOutgoingAcknowledgement(snap([bounce]),snap([bounce,outgoing]),id,relay).verified,false);
 assert.equal(verifiedNewOutgoingAcknowledgement(snap([{...incoming,sender:'postmaster@mmc.com'}]),snap([{...incoming,sender:'postmaster@mmc.com'},outgoing]),id,relay).verified,false);
 assert.equal(verifiedNewOutgoingAcknowledgement(snap([incoming]),snap([incoming,outgoing]),id,'other@example.invalid').verified,false);
});
