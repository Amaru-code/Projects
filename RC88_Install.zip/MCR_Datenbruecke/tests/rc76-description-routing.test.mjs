/** Operator-provided nine-ticket regression. Ticket IDs exist ONLY in these
 * fixtures; no production routing uses hardcoded person or ticket exceptions. */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';
import {phase2WorkRule,markedPhase2Description} from '../lib/phase2-work-rules.mjs';
import {parsePhase2Description} from '../lib/phase2-description.mjs';
import {phase2Admission,phase2BlockingIds} from '../lib/phase2-admission.mjs';
import {inspectPhase2Tickets} from '../lib/phase2-intake-audit.mjs';
import {phase2IntakeSummary} from '../lib/phase2-handoff.mjs';
import {classifyPhase2Row,phase2Inventory,readPhase2Queue} from '../lib/phase2-readonly.mjs';
import {choosePhase2Candidate} from '../src/phase2-run.mjs';
import {phase2WorkJournal} from '../lib/phase2-work-journal.mjs';
import {phase2DraftPreview} from '../lib/phase2-draft-preview.mjs';
import {accountStatementPlan} from '../lib/phase2-account-statement-plan.mjs';
import {ledger} from '../lib/control.mjs';
import {verifyLegacyPlanAlias,reviewedPdfProof} from '../src/phase2-pdf-prepare.mjs';
import {generatorPaths,inspectExistingStatements} from '../lib/phase2-pdf-evidence.mjs';
import {mapping,row as sourceRow,temp} from './helpers.mjs';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
const row=(ticketId,descriptionValue)=>({ticketId,descriptionValue,source:'E-MAIL',groupName:'Intel Deutschland GmbH',intelGroupVerified:true});
const std='Standardantwort versendet';
const fixtures=[
 ['88733447','','PHASE1_REQUIRED'],['88643702','','PHASE1_REQUIRED'],
 ['88149870',`USC 20/ DB+\n${std}\nMöcht eine Bestätigung das sie Firmenrente erhält`,'DB_DIRECT'],
 ['88078437',`USC 10/ DB+\n${std}\nMöchte wissen was er zu tun hat zu seinen Austritt`,'DB_DIRECT'],
 ['87813639',`USC 20/ DB+\n${std}\nMöchte wissen wann er wie für seine Auszahlung kontaktiert wird`,'DB_DIRECT'],
 ['87810926',`USC 20/ DB+\n${std}\nMöchte mehr über seinen Rentenplan erfahren`,'DB_DIRECT'],
 ['87917040',`USC 20/ DC;PP+\n${std}\nMöchte Kontoauszug`,'ACCOUNT_STATEMENT'],
 ['87393963','USC 20/ DC;PP+\nStansardantwort versendet\nMöchte Kontoauszug','ACCOUNT_STATEMENT'],
 ['82976755',`DC,IPP,USC 20\n${std}\nMöchte Kontoauszug`,'ACCOUNT_STATEMENT']];
for(const [id,description,expected] of fixtures)test('RC76 user case '+id+' => '+expected,()=>{
 const r=row(id,description);assert.equal(phase2WorkRule(r).kind,expected);
 assert.equal(r.descriptionValue,description,'classification is read-only');
 if(expected==='ACCOUNT_STATEMENT'){
  const c=classifyPhase2Row(r);assert.equal(c.kind,'NEEDS_VERIFIED_WWID');assert.deepEqual(c.targets,['DC','PP+']);
  assert.equal(accountStatementPlan({ticketId:id,description,memberName:'Max Beispiel',wwid:'12345678'}).kind,'READY_FOR_SEPARATE_SUPERVISED_PILOT');
 }
});
test('RC76 aggregate: nine visible, seven Phase2 rules, two Phase1, five old journals not falsified',()=>{
 const rows=fixtures.map(([id,d])=>row(id,d)),pending=rows.slice(2,7).map(r=>({ticketId:r.ticketId,kind:'SEND',state:'SEND_INTENT',descriptionSha256:'f'.repeat(64)}));
 const before=JSON.stringify({rows,pending}),audit=inspectPhase2Tickets(rows,{pending});
 assert.equal(audit.counts.visible,9);assert.equal(audit.counts.ready,7);assert.equal(audit.counts.phase1Required,2);
 assert.equal(audit.counts.phase1Blocked,0);assert.equal(audit.counts.retainedPhase1Journals,5);
 assert.equal(phase2IntakeSummary(rows,{pending}).stats.readyWithoutBlock,7);
 assert.equal(JSON.stringify({rows,pending}),before);
});
for(const plan of ['DB','DB+','DC;DB+;PP+'])for(const request of ['Möchte Kontoauszug','Möchte Log-in MBC mit privater Email','Freie Nachricht',''])
 test('RC76 DB priority '+plan+' / '+request,()=>assert.equal(phase2WorkRule(row('99100001',`USC 20/${plan}\n${std}`+(request?'\n'+request:''))).kind,'DB_DIRECT'));
for(const request of ['Möchte Log-in MBC mit privater Email','Möchte Log-in MBC mit privater E-Mail','moechte log-in MBC mit privater e-mail'])
 test('RC76 private MBC => unchanged review draft / '+request,()=>{
  const x=phase2WorkRule(row('99100001',`USC 20/PP+\n${std}\n${request}`));assert.equal(x.kind,'MBC_PRIVATE_EMAIL');assert.equal(x.route,'REVIEW');
 });
for(const request of ['Möchte KA','Möchte Kontoauszug','Möchte einen Kontoauszug.','MOECHTE KA'])test('RC76 account keyword '+request,()=>{
 assert.equal(phase2WorkRule(row('99100001',`USC 20/DC;PP+\n${std}\n${request}`)).kind,'ACCOUNT_STATEMENT');
});
for(const request of ['Möchte Adresse ändern','Möchte keinen Kontoauszug','Möchte KA und weitere Beratung','Möchte Rentenberatung'])test('RC76 unmapped whole request => Mark, never invented processing / '+request,()=>{
 const x=phase2WorkRule(row('99100001',`USC 20/PP+\n${std}\n${request}`));assert.equal(x.kind,'MARK_DIRECT');assert.equal(x.route,'DIRECT');
});
for(const marker of ['Bearbeitet not reviewed','Bearbeitet reviewed','Bearbeitet und reviewed','Reviewed'])test('RC76 completed status prevents new processing / '+marker,()=>{
 const r=row('99100001',`USC 20/DB+\n${std}\nMöchte Kontoauszug\n${marker}`);
 assert.equal(phase2WorkRule(r).kind,'ALREADY_PREPARED');assert.equal(choosePhase2Candidate([r]).row,null);
});
test('RC76 phase1 status must precede ALL new routes; no matching in body, no NOT-sent match',()=>{
 for(const d of ['USC 20/DB+','USC 20/DB+\nNicht versendet\nMöchte KA',`USC 20/PP+\nMöchte KA\n${std}`,`USC 20/PP+\nStandardantwort nicht versendet\nMöchte Log-in MBC mit privater Email`]){
  assert.equal(phase2WorkRule(row('99100001',d)).kind,'PHASE1_REQUIRED');assert.equal(choosePhase2Candidate([row('99100001',d)]).row,null);
 }
});
test('RC76 exact legacy aliases are bounded; arbitrary typos are not silently inferred',()=>{
 for(const spelling of ['Stansardantwort versendet','Standartantwort versendet']){
  const x=phase2WorkRule(row('99100001',`USC 20/DC\n${spelling}\nMöchte KA`));assert.equal(x.kind,'ACCOUNT_STATEMENT');assert(x.warnings.includes('LEGACY_STANDARD_STATUS_SPELLING'));
 }
 assert.equal(phase2WorkRule(row('99100001','USC 20/DC\nStandardantwort vielleicht versendet\nMöchte KA')).kind,'PHASE1_REQUIRED');
});
test('RC76 no DB substring rule; header and complete plan token only',()=>{
 const x=phase2WorkRule(row('99100001',`USC 20/PP+\n${std}\nMöchte DB Beratung`));assert.equal(x.kind,'MARK_DIRECT');
 assert.notEqual(phase2WorkRule(row('99100001',`USC 20/XDB+\n${std}\nMöchte KA`)).kind,'DB_DIRECT');
});
test('RC76 physical lines, duplicate status and unknown fourth line do not create work',()=>{
 for(const tail of [`${std}\nMöchte KA\n${std}`,`${std}\nMöchte KA\nMöchte Adresse`,`${std}\n\nMöchte KA`,`${std}\nMöchte KA\nUnklarer Abschluss`])
  assert.equal(phase2WorkRule(row('99100001','USC 20/DC\n'+tail)).kind,'BLOCKED');
});
test('RC76 multirow mapping headers and NBSP are parsed, never rewritten',()=>{
 const text=`USC 10/ DC\r\nUSC 20/ PP+\r\n Standardantwort\u00a0versendet \r\nMöchte KA`;
 const r=row('99100001',text),p=parsePhase2Description(text);assert.equal(p.headerLines,2);
 assert.deepEqual(phase2WorkRule(r).targets,['DC','PP+']);assert.equal(r.descriptionValue,text);
});
test('RC76 unknown direct work uses existing state machine, never a draft/email',()=>{
 const root=temp();try{const d=`USC 20/PP+\n${std}\nMöchte Rente beantragen`,j=phase2WorkJournal(root,'99100001');
 j.begin({rule:'MARK_DIRECT',descriptionBefore:d,descriptionAfter:markedPhase2Description(d)});
 for(const next of ['EDIT_INTENT','EDIT_VERIFIED','TICKET_SAVE_INTENT','TICKET_SAVE_VERIFIED','REVIEW_INTENT','REVIEW_VERIFIED','EXECUTE_INTENT','ROUTED_VERIFIED'])j.advance(next);
 assert.equal(j.read().draft,null);assert.equal(j.read().state,'ROUTED_VERIFIED');assert.throws(()=>j.advance('EXECUTE_INTENT'));
 assert.equal(choosePhase2Candidate([row('99100001',d)],{getWorkJournal:()=>j.read()}).row,null);
 }finally{fs.rmSync(root,{recursive:true,force:true});}
});
test('RC76 stored-status routing leaves actual immutable SEND ledger bytes unchanged',()=>{
 const root=temp();try{const r=row('99100001',`USC 20/DB+\n${std}\nMöchte Rente`);ledger(root).begin(r.ticketId,'USC 99/DB+\n'+std);
 const pending=ledger(root).pending,before=JSON.stringify(pending);
 assert.equal(phase2Admission(r,pending).allowed,true);assert.equal(choosePhase2Candidate([r],{pending}).kind,'DB_DIRECT');
 assert.equal(phase2BlockingIds([r],pending).length,0);assert.equal(JSON.stringify(ledger(root).pending),before);
 assert(!ledger(root).completedIds().includes(r.ticketId));
 }finally{fs.rmSync(root,{recursive:true,force:true});}
});
test('RC76 pending forwarding and ambiguous actions STILL block a duplicate route',()=>{
 const r=row('99100001',`USC 20/DB+\n${std}`);
 for(const pending of [[{ticketId:r.ticketId,kind:'FORWARD'}],[{ticketId:r.ticketId,kind:'SEND'},{ticketId:r.ticketId,kind:'SEND'}]]){
  assert.equal(phase2Admission(r,pending).allowed,false);assert.equal(choosePhase2Candidate([r],{pending}).row,null);
  assert.equal(inspectPhase2Tickets([r],{pending}).counts.ready,0);
 }
});
test('RC76 PDF candidate reaches in-run preparation; no new prep after uncertain upload',()=>{
 const r=row('99100001',`USC 20/DC\n${std}\nMöchte KA`);
 const next=choosePhase2Candidate([r],{accountReady:()=>false,prepareMissingPdf:true});assert.equal(next.pdfPreparationRequired,true);
 assert.equal(choosePhase2Candidate([r],{accountReady:()=>false,prepareMissingPdf:true,getPdfJournal:()=>({state:'UPLOAD_INTENT'})}).row,null);
});
test('RC76 IPP legacy is confirmed against bound member mapping, not guessed',()=>{
 const r=phase2WorkRule(row('99100001',`DC,IPP,USC 20\n${std}\nMöchte KA`));
 const member={profileVerified:true,profile:{mercerId:'99900001',first:'Max',last:'Beispiel'}};
 assert.equal(verifyLegacyPlanAlias(r,member,mapping([sourceRow({C:1,D:1,E:0,F:0})])).verified,true);
 assert.throws(()=>verifyLegacyPlanAlias(r,member,mapping([sourceRow({C:1,D:0,E:0,F:0})])),e=>e.code==='P2_LEGACY_IPP_PLAN_CONFLICT');
});
test('RC76 PDF proof reuses original checks and rejects file mutation after operator review',()=>{
 const parent=temp(),root=path.join(parent,'MCR_Datenbruecke');fs.mkdirSync(root);
 try{const p=generatorPaths(root,'DC');fs.mkdirSync(p.output,{recursive:true});const file=path.join(p.output,'12345678_Kontoauszug_DC.pdf');
 fs.writeFileSync(file,'%PDF-1.4\n'+('fixture only\n'.repeat(30))+'%%EOF');
 const before=inspectExistingStatements(root,['DC'],'12345678'),args={root,ticketId:'99100001',rule:{targets:['DC']},wwid:'12345678',member:{profile:{mercerId:'99900001',first:'Max',last:'Beispiel'}},before,wwidOrigin:'OPERATOR_ENTRY',planEvidence:{verified:true}};
 const proof=reviewedPdfProof(args);assert.equal(proof.operatorContentReviewed,true);assert.equal(proof.ticketId,'99100001');
 const preview=phase2DraftPreview({ticketId:'99100001',description:`USC 20/DC\n${std}\nMöchte KA`,pdfProof:proof});
 assert.equal(preview.reviewAssignee,'mark.baindl');assert.equal(preview.finalActionLabel,'Schritt ausführen');
 fs.appendFileSync(file,'\nmutated');assert.throws(()=>reviewedPdfProof(args),e=>e.code==='P2_PDF_MUTATED');
 }finally{fs.rmSync(parent,{recursive:true,force:true});}
});
async function withPage(fn){const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-P2-DOM-RC76-'));let browser,cdp;
 try{browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,
 extraArgs:process.platform==='linux'?['--no-sandbox','--disable-dev-shm-usage']:[]});({cdp}=await connectBrowser(browser.port));
 const page=await attachPage(cdp,t=>t.type==='page'&&t.url==='about:blank');return await fn(page);}
 finally{await cleanupTemporaryTestBrowser({profile,browser,cdp});}}
test('RC76 real Chromium reads all nine descriptions and picks 4 direct + 3 PDF without any write',{timeout:45000},()=>withPage(async page=>{
 await page.call(function(fixtures){document.body.innerHTML='<table id="mainForm:tasksTableFor_MyTasksList"><thead><tr><th>Ticket-ID</th><th>Group Name</th><th>Quelle</th><th>Zusätzliche Beschreibung</th></tr></thead><tbody></tbody></table>';
 const body=document.querySelector('tbody');for(const [id,desc] of fixtures){const tr=document.createElement('tr');for(const text of [id,'Intel Deutschland GmbH','E-MAIL']){const td=document.createElement('td');td.textContent=text;tr.append(td);}const td=document.createElement('td'),ta=document.createElement('textarea');ta.value=desc;td.append(ta);tr.append(td);body.append(tr);}
 window.clicks=0;document.addEventListener('click',()=>window.clicks++);},fixtures);
 const read=await readPhase2Queue(page);assert.equal(read.ok,true);assert.equal(read.rows.length,9);
 const audit=inspectPhase2Tickets(read.rows);assert.equal(audit.counts.ready,7);assert.equal(audit.counts.phase1Required,2);
 const visited=new Set(),kinds=[];for(let i=0;i<9;i++){const next=choosePhase2Candidate(read.rows,{visited});if(!next.row)break;kinds.push(next.kind);visited.add(next.row.ticketId);}
 assert.equal(kinds.filter(k=>k==='DB_DIRECT').length,4);assert.equal(kinds.filter(k=>k==='ACCOUNT_STATEMENT').length,3);
 assert.equal(await page.eval('window.clicks'),0);
}));

test('RC76 Chromium integrated PDF preparation creates proof and passes original pilot preflight with old SEND untouched',{timeout:45000},()=>withPage(async page=>{
 const {preparePhase2PdfEvidence}=await import('../src/phase2-pdf-prepare.mjs');
 const {preflightPhase2Write}=await import('../src/phase2-comarch-pilot.mjs');
 const parent=temp(),root=path.join(parent,'MCR_Datenbruecke');fs.mkdirSync(root);
 const r=row('99100001',`USC 20/DC\n${std}\nMöchte KA`),member={profileVerified:true,profile:{mercerId:'99900001',first:'Max',last:'Beispiel'},wwid:'12345678',memberReferenceWwid:null};
 try{
  const p=generatorPaths(root,'DC');fs.mkdirSync(p.output,{recursive:true});fs.writeFileSync(path.join(p.output,'12345678_Kontoauszug_DC.pdf'),'%PDF-1.4\n'+('fictional test\n'.repeat(30))+'%%EOF');
  fs.mkdirSync(path.join(root,'.runtime','phase2'),{recursive:true});
  fs.writeFileSync(path.join(root,'.runtime','phase2','MCR_PHASE2_LETZTE_INVENTUR.json'),JSON.stringify(phase2Inventory([r])));
  ledger(root).begin(r.ticketId,'USC 99/DB+\n'+std);const old=JSON.stringify(ledger(root).pending);
  await page.call(function(id){window.effects={open:0,save:0,send:0,forward:0};
   document.body.innerHTML='<table id="mainForm:tasksTableFor_MyTasksList"><thead><tr><th>Ticket-ID</th></tr></thead><tbody><tr><td id="pick">'+id+'</td></tr></tbody></table>';
   document.querySelector('#pick').onclick=()=>{window.effects.open++;document.body.innerHTML='<div>Ticket-ID: '+id+'</div>';};
  },r.ticketId);
  const answers=[],result=await preparePhase2PdfEvidence({root,page,row:r,mapping:mapping(),memberLookup:async()=>member,
   ask:async q=>{answers.push(q);return 'JA';},log:()=>{}});
  assert.equal(result.status,'PDF_PROOF_READY');assert.equal(answers.length,1);
  assert.equal(JSON.stringify(ledger(root).pending),old);
  const preflight=preflightPhase2Write(root,r.ticketId);assert.equal(preflight.wwid,'12345678');assert.equal(preflight.preview.reviewAssignee,'mark.baindl');
  assert.equal(preflight.recoveryNeeded,false);assert.deepEqual(await page.eval('window.effects'),{open:1,save:0,send:0,forward:0});
 }finally{fs.rmSync(parent,{recursive:true,force:true});}
}));

test('RC76 Chromium missing PDF can be deferred: no generator execution, proof, upload or ticket write',{timeout:45000},()=>withPage(async page=>{
 const {preparePhase2PdfEvidence}=await import('../src/phase2-pdf-prepare.mjs');
 const parent=temp(),root=path.join(parent,'MCR_Datenbruecke');fs.mkdirSync(root);
 const r=row('99100001',`USC 20/DC\n${std}\nMöchte KA`),member={profileVerified:true,profile:{mercerId:'99900001',first:'Max',last:'Beispiel'},wwid:'12345678'};
 try{
  await page.call(function(id){document.body.innerHTML='<table id="mainForm:tasksTableFor_MyTasksList"><thead><tr><th>Ticket-ID</th></tr></thead><tbody><tr><td id="pick">'+id+'</td></tr></tbody></table>';
   document.querySelector('#pick').onclick=()=>{document.body.innerHTML='<div>Ticket-ID: '+id+'</div>';};
  },r.ticketId);
  const logs=[],result=await preparePhase2PdfEvidence({root,page,row:r,mapping:mapping(),memberLookup:async()=>member,
   ask:async q=>{assert(q.includes('PDFS_BEREIT'));return 'UEBERSPRINGEN';},log:s=>logs.push(s)});
  assert.equal(result.status,'SKIPPED_UNCHANGED');assert.equal(result.noWrite,true);assert.equal(result.reason,'PDF_CREATION_REQUIRED');
  assert(logs.some(s=>s.includes('START_KONTOAUSZUG_DC.bat')));assert(!fs.existsSync(path.join(root,'.runtime','phase2','actions','MCR_PHASE2_'+r.ticketId+'.json')));
  assert(!fs.existsSync(generatorPaths(root,'DC').output));
 }finally{fs.rmSync(parent,{recursive:true,force:true});}
}));
