import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';
import {ROOT} from './helpers.mjs';
import {masterRun,phase1QueueExhaustedProof} from '../tools/cli.mjs';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
import {focusBoundDescriptionNatively,commitDescription} from '../lib/trusted-description.mjs';
import {additionalDescriptionState} from '../lib/browser-workflow.mjs';

function fixture(){const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC68-MASTER-')),root=path.join(tmp,'MCR_Datenbruecke');fs.cpSync(ROOT,root,{recursive:true,filter:p=>!p.includes('/.runtime/')&&!p.includes('/diagnostics/')});return {root,close:()=>fs.rmSync(tmp,{recursive:true,force:true})};}
const done={status:'COMPLETED_VISIBLE_SCOPE',processed:2,skipped:[],scope:'VISIBLE_MY_TASKS_NO_PAGINATION',runId:'mock-no-send-phase2'};

test('RC68 empty Phase-1 proof requires a real, error-free, finished scan and zero send actions',()=>{
 const good={mode:'REAL',lastError:null,loop:{completed:true,finishReason:'NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS',processed:0,forwarded:0,processedTickets:[]},send:{clicked:false,verified:false}};
 assert.equal(phase1QueueExhaustedProof(good),true);
 const bad=[{mode:'DEMO'},{lastError:'SEND_UNVERIFIED'},{loop:{completed:false}},{loop:{finishReason:'STOP_REVIEW_REQUIRED'}},{loop:{processed:1}},{loop:{forwarded:1}},{loop:{processedTickets:[{ticketId:'88478801'}]}},{send:{clicked:true}},{send:{verified:true}},{send:null},{loop:{processedTickets:null}}];
 for(const patch of bad){const d={...good,...patch,loop:{...good.loop,...patch.loop},send:patch.send===null?null:{...good.send,...patch.send}};assert.equal(phase1QueueExhaustedProof(d),false,JSON.stringify(patch));}
 assert.equal(phase1QueueExhaustedProof(null),false);
});

test('RC68 empty, independently verified Phase-1 lists go directly to Phase-2 without certifying a new send pilot',async()=>{
 const f=fixture(),calls=[];try{
  const r=await masterRun({rootDir:f.root,output:()=>{},confirm:async()=> 'MASTER_START',runPhase1:async pilot=>{
   calls.push(pilot?'PILOT_EMPTY':'UNEXPECTED_BATCH');return {pilotVerified:false,noEligible:true,reason:'NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS',processed:0,runId:'empty-run'};},runPhase2:async()=>{calls.push('PHASE2');return done;}});
  assert.deepEqual(calls,['PILOT_EMPTY','PHASE2']);assert.equal(r.state,'COMPLETE_VISIBLE_SCOPE');assert.equal(r.phase1.status,'NO_ELIGIBLE_TICKETS');assert.equal(r.phase1.noSendPilot,true);
  assert.equal(fs.existsSync(path.join(f.root,'.runtime/beta-control/complete-pilot-pass.json')),false);
 }finally{f.close();}
});

test('RC68 empty Phase-1 can produce partial Phase-2 report without inventing full completion',async()=>{
 const f=fixture();try{
  const r=await masterRun({rootDir:f.root,output:()=>{},confirm:async()=> 'MASTER_START',runPhase1:async()=>({pilotVerified:false,noEligible:true,processed:0,reason:'NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS'}),runPhase2:async()=>({...done,processed:0,skipped:[{ticketId:'88149870',reason:'UNRESOLVED_PHASE1_JOURNAL'}]})});
  assert.equal(r.state,'PARTIAL_PHASE2_NO_ELIGIBLE');assert.equal(r.phase2.skipped.length,1);
 }finally{f.close();}
});

test('RC68 a missing, unverifiable or contradictory pilot MUST NOT authorize Phase-2',async()=>{
 for(const p of [
  {pilotVerified:false,processed:0},
  {pilotVerified:false,noEligible:true,processed:1,reason:'NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS'},
  {pilotVerified:false,noEligible:true,processed:0,reason:'UNVERIFIED_STOP'},
  {pilotVerified:false,noEligible:false,processed:0,reason:'NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS'},
 ]){
  const f=fixture();let phase2=false;try{const r=await masterRun({rootDir:f.root,output:()=>{},confirm:async()=> 'MASTER_START',runPhase1:async()=>p,runPhase2:async()=>{phase2=true;return done;}});
   assert.equal(phase2,false);assert.equal(r.state,'PARTIAL_PHASE1_NO_PILOT');
  }finally{f.close();}
 }
});

async function withPage(fn){const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-P2-DOM-RC68-'));let browser,cdp;
 try{browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,extraArgs:process.platform==='linux'?['--no-sandbox','--disable-dev-shm-usage']:[]});({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.type==='page'&&t.url==='about:blank');return await fn(page);}
 finally{await cleanupTemporaryTestBrowser({profile,browser,cdp});}}
const original='USC 44/ PP+\nStandardantwort versendet\nMöchte Log-in MBC mit privater E-Mail',expected=original+'\nBearbeitet not reviewed';
async function makePage(page,{modal=false}={}){
 await page.call(function(before,modal){
  const a=document.createElement('span');a.textContent='Ticket-ID: 88478801';a.id='current-ticket';document.body.appendChild(a);
  const section=document.createElement('section');section.id='mainForm:document-data-section';section.innerHTML='<label for="mainForm:description">Zusätzliche Beschreibung</label><textarea id="mainForm:description" style="display:block;margin:40px 8px;width:410px;height:145px;"></textarea>';
  section.querySelector('textarea').value=before;document.body.appendChild(section);
  const overlay=document.createElement('div');overlay.id='foreign-overlay';overlay.style='position:fixed;inset:0;z-index:100000;background:rgba(0,0,0,.08);pointer-events:auto';
  if(modal){overlay.setAttribute('role','dialog');overlay.setAttribute('aria-modal','true');}document.body.appendChild(overlay);
 },original,modal);
}

test('RC68 fully occluded MBC description gets exact native field focus, then input and blur, without a click on overlay', {timeout:40000},()=>withPage(async page=>{
 await makePage(page);const logs=[];let prompted=0;
 const p=await commitDescription(page,{ticketId:'88478801',expected,allowedBefore:[original],log:m=>logs.push(m),manualFocus:async()=>{prompted++;throw Error('should not need manual focus');}});
 assert.equal(p.ok,true);assert.equal(prompted,0);assert(logs.some(x=>x.startsWith('PASS P2_DESCRIPTION_BOUND_NATIVE_FOCUS')));
 const state=await additionalDescriptionState(page);assert.equal(state.value,expected);
 assert.equal(await page.eval('document.querySelector("#foreign-overlay") !== document.activeElement'),true);
}));

test('RC68 an active modal blocks native focus and editing; never bypass it', {timeout:40000},()=>withPage(async page=>{
 await makePage(page,{modal:true});
 const r=await focusBoundDescriptionNatively(page,{ticketId:'88478801',id:'mainForm:description',before:original});
 assert.equal(r.ok,false);assert.equal(r.reason,'MODAL_ACTIVE');
 await assert.rejects(()=>commitDescription(page,{ticketId:'88478801',expected,allowedBefore:[original]}),e=>e.code==='DESCRIPTION_FOCUS');
 const state=await additionalDescriptionState(page);assert.equal(state.value,original);
}));
