import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import Prep from '../lib/ticket-prep.cjs';
import {detectTicketLanguage,resolveTicketLanguage} from '../lib/phase1-language.mjs';
import {applyEnterApproval} from '../lib/operator-enter.mjs';
import {isStandardAcknowledgement,verifiedNewOutgoingAcknowledgement} from '../lib/mail-history-audit.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const originalDE='Guten Tag, ich möchte einen Kontoauszug erhalten. Können Sie mir die entsprechenden Unterlagen bitte zusenden?';
const originalEN='Hello, I would like to receive an account statement. Could you please send me the documents? Thank you.';

test('RC88: full English request yields English even with German UI and German quoted prior message',()=>{
 const x=detectTicketLanguage({body:originalEN+'\n\nOn Tuesday someone wrote:\n'+originalDE,subject:'Account statement - support'});
 assert.equal(x.language,'EN',JSON.stringify(x));
});
test('RC88: German message with English footer remains German',()=>{
 const x=detectTicketLanguage({body:originalDE+'\n\nKind regards\nGlobal Support Team',subject:'Kontoauszug'});
 assert.equal(x.language,'DE',JSON.stringify(x));
});
test('RC88: request language never inferred from names, addresses, UI labels or empty body',()=>{
 const x=detectTicketLanguage({body:'',subject:'Request',senderName:'John Smith',senderEmail:'john@example.org'});
 assert.equal(x.language,null);
});
test('RC88: one ambiguous original request requires D/E explicit human choice',async()=>{
 let prompts=0;
 const x=await resolveTicketLanguage({body:'Kontoauszug account',subject:'Neutral'},{choose:async q=>{assert.match(q,/D=Deutsch/);prompts++;return 'E';}});
 assert.equal(x.language,'EN');assert.equal(x.manual,true);assert.equal(prompts,1);
 assert.equal(detectTicketLanguage({body:'',subject:'English'}).language,null);
 await assert.rejects(()=>resolveTicketLanguage({body:'Hi / Hallo'},{choose:async()=> 'ABBRUCH'}),{code:'P1_LANGUAGE_UNVERIFIED'});
});
test('RC88: German original reply unchanged and English template matches operator specification',()=>{
 const german=Prep.replyText('Herr','Schmidt');
 assert.match(german,/^Sehr geehrter Herr Schmidt,/);
 assert.match(german,/Mit dieser E-Mail möchten wir Ihnen bestätigen/);
 const english=Prep.replyText(null,'Schmidt',{language:'EN',firstName:'John'});
 assert.match(english,/^Dear John Schmidt,\nthank you for reaching out to us\./);
 assert.match(english,/This email is to confirm that we have received your ticket/);
 assert.match(english,/If you have any additional information or questions regarding your ticket, please feel free to reply to this email\.$/);
 assert.equal(english.includes('Sehr geehrter'),false);
 assert.throws(()=>Prep.replyText(null,'Schmidt',{language:'EN'}),{code:'REPLY_SURNAME'});
});
test('RC88: both German and English standard acknowledgment are recognized, unrelated content is not',()=>{
 assert.equal(isStandardAcknowledgement(Prep.replyText('Frau','Meyer')),true);
 assert.equal(isStandardAcknowledgement(Prep.replyText(null,'Meyer',{language:'EN',firstName:'Anna'})),true);
 assert.equal(isStandardAcknowledgement('Thank you for contacting us. We will reply soon.'),false);
 assert.equal(isStandardAcknowledgement('Please see attached account statement.'),false);
});
test('RC88: English outgoing proof verifies one new bound message, rejects duplicates and wrong recipients',()=>{
 const id='88873431',sender='origin@example.test',reply=Prep.replyText(null,'Meyer',{language:'EN',firstName:'Anna'});
 const incoming={documentId:'1',direction:'INCOMING',sender,recipient:'service@mercer.com',subject:'[MERCER#88873431] Account statement needed please',content:originalEN,date:'2026-11-12'};
 const outgoing={documentId:'2',direction:'OUTGOING',sender:'service@mercer.com',recipient:sender,subject:'Re: [MERCER#88873431] Account statement needed please',content:reply,date:'2026-11-12'};
 const before={ok:true,rows:[incoming]},after={ok:true,rows:[incoming,outgoing]};
 assert.equal(verifiedNewOutgoingAcknowledgement(before,after,id,sender).verified,true);
 assert.equal(verifiedNewOutgoingAcknowledgement(before,{ok:true,rows:[incoming,{...outgoing,recipient:'wrong@example.test'}]},id,sender).verified,false);
 assert.equal(verifiedNewOutgoingAcknowledgement(before,{ok:true,rows:[incoming,outgoing,{...outgoing,documentId:'3'}]},id,sender).verified,false);
 assert.equal(verifiedNewOutgoingAcknowledgement(after,after,id,sender).verified,false);
});
test('RC88: ENTER on start confirmations and operator language selection stays strict',()=>{
 assert.equal(applyEnterApproval('MASTER RUN: ENTER = bestaetigen. MASTER_START / ABBRUCH: ',''),'MASTER_START');
 assert.equal(applyEnterApproval('PHASE 1: ENTER = bestaetigen. PHASE1_START / ABBRUCH: ',''),'PHASE1_START');
 assert.equal(applyEnterApproval('Echter Pilot: ENTER = vorbereiten. START / ABBRUCH: ',''),'START');
 assert.equal(applyEnterApproval('Sprache D=Deutsch / E=English / ABBRUCH: ',''),'');
});
test('RC88: no automatic browser download in the read-only original MSG fetch path',()=>{
 const source=fs.readFileSync(path.join(root,'src/local-bot-full-run.mjs'),'utf8');
 const slice=source.slice(source.indexOf('async function downloadMail'),source.indexOf('async function mailAndPerson'));
 assert.equal((slice.match(/Browser\.setDownloadBehavior/g)||[]).length,1);
 assert.ok(slice.indexOf('if(automaticOnly)return null;')<slice.indexOf('Browser.setDownloadBehavior'));
 assert.match(slice,/application\/pdf/);
 assert.match(slice,/0xd0,0xcf,0x11,0xe0/);
});
