import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';
import {enterApprovalToken,applyEnterApproval} from '../lib/operator-enter.mjs';
import {mayDeferPhase2Readback} from '../lib/phase2-safe-defer.mjs';
import {DeliveryGate,createDeliveryConsole} from '../lib/delivery-console.mjs';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
import {reactivateMarkAutocomplete,exactPhase2Assignee} from '../lib/phase2-assignee.mjs';

const confirmations=[
 ['MASTER RUN: Sicher starten? MASTER_START / ABBRUCH: ','MASTER_START'],
 ['PHASE 1 alle Tickets? PHASE1_START / ABBRUCH: ','PHASE1_START'],
 ['In COMARCH angemeldet? START / ABBRUCH: ','START'],
 ['Im Bot-Edge markieren. Danach AUSGEWAEHLT / ABBRUCH: ','AUSGEWAEHLT'],
 ['Originalticket und Inhalt geprueft? JA / UEBERSPRINGEN / ABBRUCH: ','JA'],
 ['Ticket 89114387? TEXT_89114387_FREIGEBEN / WEITER_BEARBEITEN / ABBRUCH: ','TEXT_89114387_FREIGEBEN'],
 ['Bitte erst Dateien erstellen. PDFS_BEREIT / UEBERSPRINGEN / ABBRUCH: ','PDFS_BEREIT'],
 ['Ticket 88078437 im Editor? BEARBEITEN_GEOEFFNET / ABBRUCH: ','BEARBEITEN_GEOEFFNET'],
 ['Nur einmal physisch klicken. EINMAL_GEKLICKT / ABBRUCH: ','EINMAL_GEKLICKT'],
];
test('RC87 ENTER only for explicit positive confirm prompts; preserves old tokens',()=>{
 for(const [p,token] of confirmations){assert.equal(enterApprovalToken(p),token,p);assert.equal(applyEnterApproval(p,' \n'),token,p);assert.equal(applyEnterApproval(p,token),token,p);assert.equal(applyEnterApproval(p,'ABBRUCH'),'ABBRUCH',p);}
});
test('RC87 no ENTER authorization for choice, identity, destination, ambiguous prior actions or normal input',()=>{
 for(const p of ['Vorname (oder ABBRUCH): ','MercerID: ','Auswahl: ','Start-Ticket, ENTER = alle: ',
  'Anrede: HERR / FRAU / ABBRUCH: ','SICHER_KEIN_VERSAND / VERSAND_UND_SPEICHERUNG_GEPRUEFT / ABBRUCH: ',
  'ZURUECK / ABBRUCH: ','NACHNAME / ID / ABBRUCH: ',
  'Wie viele Tickets (ENTER=100): ','SICHER_NICHT_WEITERGELEITET / ABBRUCH: ']){
  assert.equal(applyEnterApproval(p,''),'',p);
 }
});
const old=()=>({schema:'MCR_PHASE2_WORK_JOURNAL_V1',ticketId:'88078437',state:'REVIEW_VERIFIED',rule:'DB_DIRECT',
 descriptionBefore:'USC20 / DB\nStandardantwort versendet\nMöchte etwas',descriptionAfter:'USC20 / DB\nStandardantwort versendet\nMöchte etwas',
 events:[{state:'TICKET_SAVE_VERIFIED',at:'2026-11-01'},{state:'REVIEW_VERIFIED',at:'2026-11-02'}]});
test('RC87 only unchanged old pre-execute DB readback may be deferred',()=>{
 const before=old(),after=structuredClone(before);
 assert.equal(mayDeferPhase2Readback({code:'P2_WORK_SERVER_VALUES',kind:'DB_DIRECT',beforeWork:before,afterWork:after}),true);
 assert.equal(mayDeferPhase2Readback({code:'P2_WORK_SERVER_VALUES',kind:'MARK_DIRECT',beforeWork:before,afterWork:after}),false);
 assert.equal(mayDeferPhase2Readback({code:'P2_WORK_SERVER_DESCRIPTION',kind:'DB_DIRECT',beforeWork:before,afterWork:after}),false);
 after.events.push({state:'EXECUTE_INTENT',at:'2026-11-03'});
 assert.equal(mayDeferPhase2Readback({code:'P2_WORK_SERVER_VALUES',kind:'DB_DIRECT',beforeWork:before,afterWork:after}),false);
 after.events.pop();after.events.push({state:'RC77_DIRECT_CLEANUP_SAVE_CLICK_INTENT',at:'2026-11-03'});
 assert.equal(mayDeferPhase2Readback({code:'P2_WORK_SERVER_VALUES',kind:'DB_DIRECT',beforeWork:before,afterWork:after}),false);
 assert.equal(mayDeferPhase2Readback({code:'P2_WORK_SERVER_VALUES',kind:'DB_DIRECT',beforeWork:before,afterWork:before,beforePdf:{state:'UPLOAD_VERIFIED'}}),false);
});
test('RC87 never defer first-run save or post-intent ambiguity',()=>{
 const newer={...old(),state:'TICKET_SAVE_INTENT'};
 assert.equal(mayDeferPhase2Readback({code:'P2_WORK_SERVER_VALUES',kind:'DB_DIRECT',beforeWork:null,afterWork:newer}),false);
 assert.equal(mayDeferPhase2Readback({code:'P2_WORK_SERVER_VALUES',kind:'DB_DIRECT',beforeWork:newer,afterWork:newer}),false);
 const completed={...old(),state:'EXECUTE_INTENT',events:[...old().events,{state:'EXECUTE_INTENT'}]};
 assert.equal(mayDeferPhase2Readback({code:'P2_WORK_SERVER_VALUES',kind:'DB_DIRECT',beforeWork:completed,afterWork:completed}),false);
});
test('RC87 native panel keeps safe suspended clickthrough and draggable title (static Windows checks)',()=>{
 const s=fs.readFileSync(new URL('../tools/phase2-ticket-window.ps1',import.meta.url),'utf8');
 for(const x of ['SetMousePassThrough(bool enable)','VirtualScreen','Add_MouseDown($dragStart)','Add_MouseMove($dragMove)',
  "if($form.SetMousePassThrough($true))",'Send-Control @{event=\'hidden\';seq=[int]$m.seq}',
  '$form.SetMousePassThrough($false)'])assert(s.includes(x),x);
 assert(s.includes('$form.Hide();[System.Windows.Forms.Application]::DoEvents()'),'Safe Hide fallback is retained');
});
async function withPage(fn){const exe=findEdgeExecutable();if(!exe)return;
 const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-P2-DOM-RC87-'));let browser,cdp;
 try{browser=await launchBrowser({executable:exe,userDataDir:profile,startUrl:'about:blank',headless:true,extraArgs:process.platform==='linux'?['--no-sandbox','--disable-dev-shm-usage']:[]});({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.type==='page'&&t.url==='about:blank');return await fn(page);}finally{await cleanupTemporaryTestBrowser({profile,browser,cdp});}}
test('RC87 Chromium: trusted repeated Bearbeiter click opens existing suggestion without writing or forwarding',{timeout:45000},()=>withPage(async page=>{
 const fieldId='mainForm:persona-assignment-id';
 await page.call(function(id){
  document.body.innerHTML='<div>Ticket-ID: 88078437</div><div style="margin:40px"><input id="mainForm:persona-assignment-id" style="width:260px;height:30px" value="mark.baindl"/><div id="suggest" style="display:none">Baindl Mark (mark.baindl)</div></div>';
  const f=document.getElementById(id);window.__clicks=0;window.__writes=0;
  f.addEventListener('click',()=>{window.__clicks++;document.getElementById('suggest').style.display='block';});
 },fieldId);
 assert.equal(await reactivateMarkAutocomplete(page,{fieldId,ticketId:'88078437'}),true);
 assert.equal(await page.eval('window.__clicks'),1);
 assert.equal(await page.eval('window.__writes'),0);
 assert.equal(await page.eval('document.getElementById("suggest").style.display'),'block');
 assert.equal((await exactPhase2Assignee(page,fieldId)).ok,false);
 assert.equal(await reactivateMarkAutocomplete(page,{fieldId,ticketId:'88078438'}).then(()=>false,()=>true),true);
 assert.equal(await page.eval('window.__clicks'),1);
}));
