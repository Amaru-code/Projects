import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {sha256} from '../lib/core.mjs';
import {ledger} from '../lib/control.mjs';
import {phase2HandoffStatus,phase2HandoffAudit,phase2HandoffDescription,phase2IntakeSummary} from '../lib/phase2-handoff.mjs';
import {completeVerifiedPhase1Handoff,beginVerifiedPhase1StatusRepair,finishVerifiedPhase1StatusRepair} from '../lib/phase2-handoff-ledger.mjs';
import {choosePhase2Candidate} from '../src/phase2-run.mjs';
const ticket='88478801',source='USC 11/ DB+';
const intended=source+'\nStandardantwort versendet';
const content='Sehr geehrter Herr Beispiel, mit dieser E-Mail möchten wir Ihnen bestätigen, dass wir Ihr Ticket erhalten haben und unser Team derzeit daran arbeitet. Wir werden uns bald melden.';
const incoming={direction:'INCOMING',sender:'secureemail@mmc.com',recipient:'servicelineintel@mercer.com',subject:'RE: [MERCER#76338482] Vesting statement after departure and open annual benefit statement',content:'Dear Mercer, I would like to follow up on my Intel vesting statement from the pension scheme.',date:'05.11.2026 10:10',documentId:'12398433'};
const outgoing={direction:'OUTGOING',sender:'servicelineintel@mercer.com',recipient:'secureemail@mmc.com',subject:'[MARSH#88478801] RE: [MERCER#76338482] Vesting statement after departure and open annual benefit statement',content,date:'06.11.2026 10:25',documentId:'12398434'};
const history={ok:true,rows:[incoming,outgoing]};
const prior={ticketId:ticket,kind:'SEND',state:'SEND_INTENT',descriptionSha256:sha256(intended)};
const make=(desc=source)=>({row:{ticketId:ticket,descriptionValue:desc,source:'E-MAIL'},prior,history,detailDescription:desc});
function sandbox(){const dir=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC67-'));return {root:dir,close:()=>fs.rmSync(dir,{recursive:true,force:true})};}
test('RC67: trailing supported MBC request does not invalidate already stored single status',()=>{
 const d='USC 44/ PP+\nStandardantwort versendet\nMöchte Log-in MBC mit privater E-Mail';
 const p={...prior,descriptionSha256:sha256('USC 44/ PP+\nStandardantwort versendet')};
 const a=phase2HandoffStatus({...make(d),prior:p});
 assert.equal(a.verified,true,a.reason);assert.equal(a.requiresSave,false);assert.equal(a.rule,'MBC_PRIVATE_EMAIL');
});
test('RC67: English spelling without hyphen and KA text after status remain valid',()=>{
 for(const [source,request,rule] of [['USC 44/ PP+','Möchte Log-in MBC mit privater Email','MBC_PRIVATE_EMAIL'],['USC 44/ DC','Möchte Kontoauszug','ACCOUNT_STATEMENT']]){
  const d=source+'\nStandardantwort versendet\n'+request,p={...prior,descriptionSha256:sha256(source+'\nStandardantwort versendet')};
  const result=phase2HandoffStatus({...make(d),prior:p});assert.equal(result.verified,true,`${rule}: ${result.reason}`);assert.equal(result.rule,rule);
 }
});
test('RC67: intact DB status can be verified with a known MBC request after it',()=>{
 const d=intended+'\nMöchte Log-in MBC mit privater E-Mail';const x=phase2HandoffStatus(make(d));
 assert.equal(x.verified,true,x.reason);assert.equal(x.rule,'DB_DIRECT');
});
test('RC67: missing status is a repair proposal only, not an already saved receipt',()=>{
 const a=phase2HandoffAudit({...make(),allowRepair:true});assert.equal(a.verified,true,a.reason);
 assert.equal(a.requiresSave,true);assert.equal(a.expectedDescription,intended);
 assert.equal(phase2HandoffStatus(make()).verified,false);
 const eligible=phase2HandoffDescription({row:make().row,prior});assert.equal(eligible.verified,true);
 const report=phase2IntakeSummary([make().row],{pending:[prior]});assert.equal(report.stats.oldJournalCandidates,0);assert.equal(report.stats.phase1Required,1); // RC76 no automatic Phase1 repair during Phase2
});
test('RC67: missing MBC status can be added BEFORE intact request, without overwriting it',()=>{
 const d='USC 44/ PP+\nMöchte Log-in MBC mit privater E-Mail';
 const p={...prior,descriptionSha256:sha256('USC 44/ PP+\nStandardantwort versendet')};
 const a=phase2HandoffAudit({...make(d),prior:p,allowRepair:true});
 assert.equal(a.verified,true,a.reason);assert.equal(a.requiresSave,true);
 assert.equal(a.expectedDescription,'USC 44/ PP+\nStandardantwort versendet\nMöchte Log-in MBC mit privater E-Mail');
});
test('RC67: unknown notes, internal blank lines, duplicates, reordered status and changed USC stay blocked',()=>{
 for(const d of [
 'USC 11/ DB+\nNote: other benefit plan',
 'USC 11/ DB+\n\nMöchte Log-in MBC mit privater E-Mail',
 intended+'\nStandardantwort versendet',
 'USC 11/ DB+\nMöchte Log-in MBC mit privater E-Mail\nStandardantwort versendet',
 'USC 99/ DB+',
 source+'\nMöchte Log-in MBC mit privater E-Mail\nUnknown request',
 ]){const r=phase2HandoffAudit({...make(d),allowRepair:true});assert.equal(r.verified,false,d+' -> '+r.reason);}
});
test('RC67: never repair after earlier SAVE_INTENT or using unrelated outgoing',()=>{
 const a=phase2HandoffAudit({...make(),prior:{...prior,state:'SAVE_INTENT'},allowRepair:true});
 assert.equal(a.verified,false);assert.equal(a.reason,'PREVIOUS_SAVE_INTENT_UNVERIFIED');
 for(const bad of [
  {...outgoing,documentId:incoming.documentId},{...outgoing,recipient:'foreign@example.com'},
  {...outgoing,subject:'[MARSH#88478802] unrelated subject'},
  {...outgoing,content:'Different email'},
 ]){const p=phase2HandoffAudit({...make(),history:{ok:true,rows:[incoming,bad]},allowRepair:true});assert.equal(p.verified,false,p.reason);}
});
test('RC67: logging a verified status-save intent prevents an unsafe second save',()=>{
 const f=sandbox();try{
  ledger(f.root).begin(ticket,intended);ledger(f.root).begin('88149870','USC 22/ DC\nStandardantwort versendet');
  const old=ledger(f.root).pending.find(x=>x.ticketId===ticket),proof=phase2HandoffAudit({...make(),prior:old,allowRepair:true});
  const start=beginVerifiedPhase1StatusRepair(f.root,old,proof);
  assert.equal(start.expectedDescription,intended);
  assert.equal(ledger(f.root).pending.find(x=>x.ticketId===ticket).state,'SAVE_INTENT');
  assert.throws(()=>beginVerifiedPhase1StatusRepair(f.root,old,proof),/geaendert|geändert|geandert/iu);
  assert.equal(ledger(f.root).pending.length,2);
  assert.deepEqual(ledger(f.root).pending.map(x=>x.ticketId).sort(),['88149870',ticket].sort());
  const done=finishVerifiedPhase1StatusRepair(f.root,ticket,intended);assert.equal(done.receipt,'STATUS_SAVED_WITH_BOUND_OLD_OUTGOING');
  assert.deepEqual(ledger(f.root).pending.map(x=>x.ticketId),['88149870']);
  assert.throws(()=>finishVerifiedPhase1StatusRepair(f.root,ticket,intended));
 }finally{f.close();}
});
test('RC67: no success journal without an exact bound outgoing and matching digest',()=>{
 const f=sandbox();try{
  ledger(f.root).begin(ticket,intended);const old=ledger(f.root).pending[0];
  for(const bad of [{...phase2HandoffAudit({...make(),prior:old,allowRepair:true}),outgoingDocumentId:'abc'},
   {...phase2HandoffAudit({...make(),prior:old,allowRepair:true}),originalIntentSha256:'0'.repeat(64)}]){
   assert.throws(()=>beginVerifiedPhase1StatusRepair(f.root,old,bad));
  }
  assert.equal(ledger(f.root).pending[0].state,'SEND_INTENT');
 }finally{f.close();}
});
test('RC67: a freed DB ticket is selected after the old SEND journal completes',()=>{
 const f=sandbox();try{
  ledger(f.root).begin(ticket,intended);const old=ledger(f.root).pending[0];
  const p=phase2HandoffStatus({...make(intended),prior:old});assert(p.verified);
  const before=choosePhase2Candidate([{ticketId:ticket,descriptionValue:intended}],{blockedIds:[ticket]});assert.equal(before.row,null);
  completeVerifiedPhase1Handoff(f.root,old,p);
  const after=choosePhase2Candidate([{ticketId:ticket,descriptionValue:intended}],{blockedIds:ledger(f.root).pending.map(x=>x.ticketId)});
  assert.equal(after.kind,'DB_DIRECT');
 }finally{f.close();}
});
