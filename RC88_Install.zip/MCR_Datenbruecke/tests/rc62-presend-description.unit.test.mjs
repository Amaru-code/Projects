import test from 'node:test';
import assert from 'node:assert/strict';
import {preSendDescriptionDecision,ensurePreSendDescription} from '../lib/pre-send-description.mjs';
const target='USC 1/ DC\nUSC 2/ PP+';
const describe=value=>({ok:true,editable:true,id:'mainForm:j_Description',value});

test('RC62: exact bound description stays intact; no extra write',async()=>{
 let repairs=0;
 const result=await ensurePreSendDescription({ticketId:'88503774',expected:target,initialValue:'',botWriteProven:true,
  read:async()=>describe(target),assertTicket:async()=>{},restore:async()=>{repairs++;}});
 assert.equal(result.restored,false);assert.equal(repairs,0);
});
test('RC62: blank after verified write can be restored exactly once before send',async()=>{
 let value='',repairs=0,visits=0;
 const result=await ensurePreSendDescription({ticketId:'88503774',expected:target,initialValue:'',botWriteProven:true,
  read:async()=>describe(value),assertTicket:async()=>{visits++;},restore:async()=>{repairs++;value=target;}});
 assert.equal(result.restored,true);assert.equal(repairs,1);assert.equal(visits,2);
});
test('RC62: conflicts, unbound description, unproven writes and non-empty originals block; never overwrite',async()=>{
 const examples=[
  {state:describe('Dritte Person: fremde Notiz'),initialValue:'',botWriteProven:true,reason:'PRESEND_DESCRIPTION_CONFLICT'},
  {state:describe(''),initialValue:'ALTE NOTIZ',botWriteProven:true,reason:'PRESEND_DESCRIPTION_CONFLICT'},
  {state:describe(''),initialValue:'',botWriteProven:false,reason:'PRESEND_DESCRIPTION_CONFLICT'},
  {state:{ok:false},initialValue:'',botWriteProven:true,reason:'PRESEND_DESCRIPTION_UNBOUND'},
 ];
 for(const {state,initialValue,botWriteProven,reason} of examples){
  let writes=0;
  await assert.rejects(()=>ensurePreSendDescription({ticketId:'88503774',expected:target,initialValue,botWriteProven,
   read:async()=>state,assertTicket:async()=>{},restore:async()=>{writes++;}}),e=>e.code===reason);
  assert.equal(writes,0);
 }
});
test('RC62: repaired field must remain exact after COMARCH settles; no send after re-reset',async()=>{
 let reads=0;
 await assert.rejects(()=>ensurePreSendDescription({ticketId:'88503774',expected:target,initialValue:'',botWriteProven:true,
  read:async()=>describe(reads++===0?'':''),assertTicket:async()=>{},restore:async()=>{}}),
  e=>e.code==='PRESEND_DESCRIPTION_RESTORE_UNVERIFIED');
});
test('RC62: normalized CRLF accepted, wrong text not normalized into acceptance',()=>{
 assert.equal(preSendDescriptionDecision({state:describe('USC 1/ DC\r\nUSC 2/ PP+'),expected:target,initialValue:'',botWriteProven:true}),'EXACT');
 assert.equal(preSendDescriptionDecision({state:describe('USC 1/ DC\nUSC 2/ DB+'),expected:target,initialValue:'',botWriteProven:true}),'CONFLICT');
});
