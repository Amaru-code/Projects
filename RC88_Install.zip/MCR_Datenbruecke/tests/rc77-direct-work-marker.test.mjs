/** RC77: no 'Bearbeitet' for internal forwarding without subject-matter work. */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {phase2WorkRule,phase2WorkDescription,markedPhase2Description,legacyDirectMarkerJournal} from '../lib/phase2-work-rules.mjs';
import {directMarkerRecoveryDecision} from '../src/phase2-direct-marker-recovery.mjs';
import {phase2WorkJournal} from '../lib/phase2-work-journal.mjs';
import * as UI from '../lib/browser-workflow.mjs';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
const s='Standardantwort versendet';
const row=(ticketId,descriptionValue)=>({ticketId,descriptionValue,intelGroupVerified:true});
const sources=[
 [`USC 20/ DB+\n${s}\nMöchte eine Bestätigung der Firmenrente erhalten`,'DB_DIRECT'],
 [`USC 20/ DB\n${s}\nMöchte KA`,'DB_DIRECT'],
 [`USC 20/ PP+\n${s}\nMöchte eine unbekannte Bearbeitung`,'MARK_DIRECT'],
 [`USC 20/ DC\n${s}\nMöchte Log-in MBC mit privater Email`,'MBC_PRIVATE_EMAIL'],
];
for(const [source,kind] of sources)test('RC77 route description policy: '+kind+' with '+source.slice(0,12),()=>{
 const parsed=phase2WorkRule(row('99100001',source));assert.equal(parsed.kind,kind);
 const after=phase2WorkDescription(kind,source);
 if(kind==='MBC_PRIVATE_EMAIL')assert.equal(after,source+'\nBearbeitet not reviewed');
 else{assert.equal(after,source);assert.equal(after.includes('Bearbeitet not reviewed'),false);}
});
test('RC77 direct description preserves CRLF, whitespace, and all existing customer text byte-exact',()=>{
 const raw='USC 20/ DB+\r\nStandardantwort versendet\r\nMöchte etwas Unbekanntes  ';
 assert.equal(phase2WorkDescription('DB_DIRECT',raw),raw);
 assert.equal(phase2WorkDescription('MARK_DIRECT',raw),raw);
});
test('RC77 statement and MBC retain unchanged existing work-marker policy',()=>{
 const v=`USC 20/ DC;PP+\n${s}\nMöchte KA`;
 assert.equal(markedPhase2Description(v),v+'\nBearbeitet not reviewed');
 const withMarker=v+'\nBearbeitet not reviewed';assert.equal(markedPhase2Description(withMarker),withMarker);
});
test('RC77 no new marker for unknown request, even if wording contains Bearbeitet',()=>{
 const raw=`USC 1/ PP+\n${s}\nMöchte bearbeitet werden`;
 assert.equal(phase2WorkRule(row('99100001',raw)).kind,'MARK_DIRECT');
 assert.equal(phase2WorkDescription('MARK_DIRECT',raw),raw);
});
const orig=`USC 10/ DB+\n${s}\nMöchte wissen was er zu tun hat`;
const after=orig+'\nBearbeitet not reviewed';
const legacy={rule:'DB_DIRECT',state:'REVIEW_VERIFIED',descriptionBefore:orig,descriptionAfter:after,events:[]};
const decision=(storedDescription,extra={})=>directMarkerRecoveryDecision({old:{...legacy,...extra},storedDescription,gevo:'Anfrage Member',priorEvents:extra.events||[]});
test('RC77 legacy correction only for EXACT bot-appended marker in an unfinished direct case',()=>{
 assert.equal(legacyDirectMarkerJournal(legacy),true);
 assert.equal(decision(after).action,'REMOVE_RC76_MARKER');
 assert.equal(decision(orig).action,'ALREADY_ORIGINAL');
 assert.equal(legacyDirectMarkerJournal({...legacy,descriptionAfter:after+'\nextra'}),false);
 assert.equal(legacyDirectMarkerJournal({...legacy,rule:'MBC_PRIVATE_EMAIL'}),false);
 assert.equal(legacyDirectMarkerJournal({...legacy,descriptionAfter:orig+'\nBearbeitet not reviewed\nBearbeitet not reviewed'}),false);
});
test('RC77 legacy correction blocks unsafe or repeated side effects',()=>{
 assert.equal(decision('An arbitrary other person').ok,false);
 assert.equal(directMarkerRecoveryDecision({old:legacy,storedDescription:after,gevo:'',priorEvents:[]}).ok,false);
 assert.equal(decision(after,{state:'EXECUTE_INTENT'}).ok,false);
 assert.equal(decision(after,{events:[{state:'EXECUTE_INTENT'}]}).ok,false);
 assert.equal(decision(after,{events:[{state:'RC77_DIRECT_CLEANUP_SAVE_CLICK_INTENT'}]}).ok,false);
 assert.equal(decision(after,{events:[{state:'RC77_DIRECT_CLEANUP_INTENT'}]}).action,'RETRY_BEFORE_SAVE');
 assert.equal(decision(after,{events:[{state:'RC77_DIRECT_CLEANUP_INTENT'},{state:'RC77_DIRECT_CLEANUP_INTENT'}]}).ok,false);
 assert.equal(decision(orig,{events:[{state:'RC77_DIRECT_CLEANUP_SAVE_CLICK_INTENT'}]}).action,'ALREADY_ORIGINAL');
});
test('RC77 no implicit journal migration: old phase-2 and send journals remain byte-identical',()=>{
 const parent=fs.mkdtempSync(path.join(os.tmpdir(),'mcr-rc77-journal-'));try{
  const id='99100001',j=phase2WorkJournal(parent,id);
  j.begin({rule:'DB_DIRECT',descriptionBefore:orig,descriptionAfter:after});j.advance('EDIT_INTENT');j.advance('EDIT_VERIFIED');j.advance('TICKET_SAVE_INTENT');j.advance('TICKET_SAVE_VERIFIED');j.advance('REVIEW_INTENT');j.advance('REVIEW_VERIFIED');
  const before=fs.readFileSync(j.file,'utf8');
  assert.equal(legacyDirectMarkerJournal(j.read()),true);
  assert.equal(decision(after).action,'REMOVE_RC76_MARKER');
  assert.equal(fs.readFileSync(j.file,'utf8'),before);
 }finally{fs.rmSync(parent,{recursive:true,force:true});}
});
async function withPage(fn){const browserPath=findEdgeExecutable();if(!browserPath)return;
 const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-P2-DOM-RC77-'));let browser,cdp;
 try{browser=await launchBrowser({executable:browserPath,userDataDir:profile,startUrl:'about:blank',headless:true,extraArgs:process.platform==='linux'?['--no-sandbox','--disable-dev-shm-usage']:[]});({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.type==='page'&&t.url==='about:blank');return await fn(page);}
 finally{await cleanupTemporaryTestBrowser({profile,browser,cdp});}}
test('RC77 Chromium: direct Mark selection may rerender a textarea to ORIGINAL with no marker; that is the expected final text',{timeout:45000},()=>withPage(async page=>{
 await page.call(function({orig,after}){
  document.body.innerHTML='<span>Ticket-ID: 99100001</span><div id="mainForm:document-data-section"><label>Zusätzliche Beschreibung <textarea id="mainForm:description"></textarea></label></div><input id="mainForm:persona-assignment-id">';
  document.getElementById('mainForm:description').value=after;
  window.rerender=()=>{const n=document.createElement('textarea');n.id='mainForm:description';n.value=orig;
   document.querySelector('#mainForm\\:document-data-section textarea').replaceWith(n);};
 },{orig,after});
 assert.equal(await UI.verifyDescription(page,after),true);
 await page.call(()=>window.rerender());
 assert.equal(await UI.verifyDescription(page,orig),true);
 assert.equal(await UI.verifyDescription(page,after),false);
 const d=await UI.additionalDescriptionState(page);assert.equal(d.ok,true);assert.equal(d.value,orig);
}));
test('RC77 Chromium: previously corrected direct journal is read-only when original status is already on screen',{timeout:45000},()=>withPage(async page=>{
 const {restoreLegacyDirectMarker}=await import('../src/phase2-direct-marker-recovery.mjs');
 await page.call(function(original){
  document.body.innerHTML='<span>Ticket-ID: 99100001</span><div id="mainForm:document-data-section"><label>Zusätzliche Beschreibung<textarea id="mainForm:description" style="width:300px;height:90px"></textarea></label></div><input id="mainForm:gevo-value-id" value="Anfrage Member" style="width:120px">';
  document.querySelector('textarea').value=original;window.__writes=0;
  document.querySelector('textarea').addEventListener('input',()=>window.__writes++);
 },orig);
 const fakeJournal={read:()=>({...legacy,ticketId:'99100001',events:[]}),observe:()=>{throw Error('No journal update expected');}};
 const result=await restoreLegacyDirectMarker({page,ticketId:'99100001',old:fakeJournal.read(),journal:fakeJournal,
  ask:async()=>{throw Error('No operator prompt expected');},log:()=>{},open:()=>{throw Error('No re-open expected');}});
 assert.equal(result.changed,false);
 assert.equal(await UI.verifyDescription(page,orig),true);
 assert.equal(await page.eval('window.__writes'),0);
}));
