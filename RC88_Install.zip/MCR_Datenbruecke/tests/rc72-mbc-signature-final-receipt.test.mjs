import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {assessMbcReviewSignature,mbcSignatureState,MBC_SIGNATURE_VALUE} from '../lib/phase2-mbc-signature.mjs';
import {finishPhase2Route} from '../lib/phase2-review-flow.mjs';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';

const ticket='87647759';
const signedSaveJournal=()=>({state:'REVIEW_VERIFIED',ticketId:ticket,
 events:[{state:'MBC_SIGNATURE_SELECTION_INTENT'},{state:'MBC_SIGNATURE_SELECTED_EXACT'},
 {state:'DRAFT_SAVE_INTENT'},{state:'DRAFT_NETWORK_OBSERVED'},
 {state:'MBC_SIGNATURE_DRAFT_SAVE_VERIFIED'},{state:'DRAFT_SAVE_VERIFIED'},
 {state:'TICKET_SAVE_INTENT'},{state:'TICKET_SAVE_VERIFIED'},
 {state:'REVIEW_INTENT'},{state:'REVIEW_VERIFIED'}]});
const sig=(value,overrides={})=>({count:1,visible:true,enabled:true,value,...overrides});
const check=(value,journal=signedSaveJournal(),opts={})=>assessMbcReviewSignature({signature:sig(value),journal,draftVerified:true,serverVerified:true,...opts});

test('RC72: exact selected INTL01 remains acceptable with verified draft and ticket',()=>{
 assert.equal(check(MBC_SIGNATURE_VALUE).method,'LIVE_INTL01_EXACT');
});
test('RC72: COMARCH clears volatile signature chooser after review, but signed saved draft is independently documented',()=>{
 assert.equal(check('').method,'SAVED_INTL01_PROOF_AFTER_ICE_CLEARED_FIELD');
});
test('RC72: COMARCH removes chooser on review, durable prior signed-draft receipt suffices',()=>{
 const x=check('',signedSaveJournal(),{signature:{count:0,visible:false,enabled:false,value:null}});
 assert.equal(x.method,'SAVED_INTL01_PROOF_AFTER_ICE_REMOVED_FIELD');
});
test('RC72: foreign or duplicate signature always refuses forwarding, even with saved receipt',()=>{
 assert.equal(check('Fremde Signatur').reason,'SIGNATURE_FOREIGN_VALUE');
 assert.equal(check('',signedSaveJournal(),{signature:{count:2,value:''}}).reason,'SIGNATURE_FIELD_AMBIGUOUS');
});
test('RC72: old draft with no exact signed-save witness is NOT sufficient',()=>{
 const j=signedSaveJournal();j.events=j.events.filter(e=>e.state!=='MBC_SIGNATURE_DRAFT_SAVE_VERIFIED');
 assert.equal(check('',j).reason,'SIGNATURE_DRAFT_SAVE_PROOF_MISSING');
});
test('RC72: operator approval or old already-exact selection is no replacement for signed draft save',()=>{
 const j=signedSaveJournal();j.events=j.events.filter(e=>e.state!=='MBC_SIGNATURE_DRAFT_SAVE_VERIFIED');
 j.events.push({state:'MBC_SIGNATURE_DRAFT_SAVE_VERIFIED',method:'SIGNATURE_ALREADY_EXACT'});
 assert.equal(check('',j).reason,'SIGNATURE_DRAFT_SAVE_PROOF_MISSING');
});
test('RC72: in-flight new signature selection/save after prior receipt blocks stale proof',()=>{
 const j=signedSaveJournal();j.events.push({state:'MBC_SIGNATURE_SELECTION_INTENT'});
 assert.equal(check('',j).reason,'SIGNATURE_DRAFT_SAVE_PROOF_MISSING');
});
test('RC72: no server or draft confirmation means stop before approval',()=>{
 assert.equal(check('',signedSaveJournal(),{draftVerified:false}).reason,'MBC_PERSISTENCE_NOT_RECONFIRMED');
 assert.equal(check('',signedSaveJournal(),{serverVerified:false}).reason,'MBC_PERSISTENCE_NOT_RECONFIRMED');
});
test('RC72: an earlier forwarding intent can never be replayed on blank signature',()=>{
 const j=signedSaveJournal();j.events.push({state:'EXECUTE_INTENT'});
 assert.equal(check('',j).reason,'SIGNATURE_ROUTE_ALREADY_ATTEMPTED');
});
test('RC72: exact signature from an incomplete old journal can still be used only with current draft/server readback',()=>{
 const j=signedSaveJournal();j.events=[];
 assert.equal(check(MBC_SIGNATURE_VALUE,j).method,'LIVE_INTL01_EXACT');
});

async function withPage(fn){const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-P2-DOM-RC72-'));let browser,cdp;
 try{browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,
  extraArgs:process.platform==='linux'?['--no-sandbox','--disable-dev-shm-usage']:[]});
  ({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.type==='page'&&t.url==='about:blank');return await fn(page);}
 finally{await cleanupTemporaryTestBrowser({profile,browser,cdp});}}
async function fixture(page,{foreign=false}={}){await page.call(function({ticket,foreign}){
 document.body.innerHTML='<span>Ticket-ID: '+ticket+'</span><input id="foreign" value="SAFE">';
 const area=document.createElement('div');area.id='area';area.style='margin:40px 15px';document.body.appendChild(area);
 const s=document.createElement('input');s.id='mainForm:signature-value-id';s.value='INTL01 - Intel Deutschland GmbH';area.appendChild(s);
 const gevo=document.createElement('input');gevo.id='mainForm:gevo-value-id';gevo.value='Anfrage Member';area.appendChild(gevo);
 const sel=document.createElement('select');sel.id='mainForm:j_id7870';sel.style='width:230px;height:36px;';
 sel.innerHTML='<option value=""></option><option value="FORWARD_TO_REVIEW">Weiterleiten zur Überprüfung</option>';
 sel.addEventListener('change',()=>{
   // Simulate the COMARCH ICEfaces rerender that caused the live RC71 failure.
   s.value=foreign?'FREMDE SIGNATUR':'';
   if(sel.value==='FORWARD_TO_REVIEW'){
    let reviewer=document.getElementById('mainForm:next-persona-assignment-id');
    if(!reviewer){reviewer=document.createElement('input');reviewer.id='mainForm:next-persona-assignment-id';area.appendChild(reviewer);}
    reviewer.value='Baindl Mark (mark.baindl)';reviewer.defaultValue='Baindl Mark (mark.baindl)';
   }
 });area.appendChild(sel);
 const save=document.createElement('a');save.id='saveTicket';save.textContent='Ticket speichern';save.onclick=()=>{window.__saveClicks++};area.appendChild(save);
 const send=document.createElement('input');send.value='Senden';send.type='button';send.onclick=()=>{window.__sendClicks++};area.appendChild(send);
 window.__saveClicks=0;window.__sendClicks=0;window.__routeClicks=0;
 },{ticket,foreign});}

test('RC72 Chromium: workflow clears signed chooser; signed draft receipt is checked BEFORE manual forwarding approval', {timeout:30000},()=>withPage(async page=>{
 await fixture(page);let approvals=0,receiptChecks=0;
 const j=signedSaveJournal();j.state='TICKET_SAVE_VERIFIED';
 const journal={read:()=>j,advance:state=>{j.state=state;j.events.push({state})}};
 await assert.rejects(()=>finishPhase2Route(page,{ticketId:ticket,journal,route:'REVIEW',ask:async()=>{throw Error('NO_TERMINAL_INPUT')},
  beforeAuthorize:async()=>{receiptChecks++;const s=await mbcSignatureState(page);const x=assessMbcReviewSignature({signature:s,journal:j,draftVerified:true,serverVerified:true});assert.equal(x.ok,true);assert.match(x.method,/SAVED_INTL01_PROOF/);},
  controls:{authorize:()=>{approvals++;throw Error('APPROVAL_REACHED_AFTER_RECEIPT')}}}),/APPROVAL_REACHED_AFTER_RECEIPT/);
 assert.equal(receiptChecks,1);assert.equal(approvals,1);
 const r=await page.call(()=>({signature:document.getElementById('mainForm:signature-value-id').value,
  save:window.__saveClicks,send:window.__sendClicks,foreign:document.getElementById('foreign').value}));
 assert.equal(r.signature,'');assert.equal(r.save,0);assert.equal(r.send,0);assert.equal(r.foreign,'SAFE');
}));

test('RC72 Chromium: foreign signature after review stops BEFORE authorization or execute', {timeout:30000},()=>withPage(async page=>{
 await fixture(page,{foreign:true});let approvals=0;
 const j=signedSaveJournal();j.state='TICKET_SAVE_VERIFIED';
 const journal={read:()=>j,advance:state=>{j.state=state;j.events.push({state})}};
 await assert.rejects(()=>finishPhase2Route(page,{ticketId:ticket,journal,route:'REVIEW',ask:async()=>{throw Error('NO_TERMINAL_INPUT')},
  beforeAuthorize:async()=>{const s=await mbcSignatureState(page);const x=assessMbcReviewSignature({signature:s,journal:j,draftVerified:true,serverVerified:true});
   assert.equal(x.reason,'SIGNATURE_FOREIGN_VALUE');assert.equal(x.ok,false);throw Error('FOREIGN_SIGNATURE_BLOCKED')},
  controls:{authorize:()=>{approvals++}}}),/FOREIGN_SIGNATURE_BLOCKED/);
 assert.equal(approvals,0);
 const r=await page.call(()=>({save:window.__saveClicks,send:window.__sendClicks,foreign:document.getElementById('foreign').value}));
 assert.equal(r.save,0);assert.equal(r.send,0);assert.equal(r.foreign,'SAFE');
}));

test('RC72 Chromium: sign changed to foreign AFTER approval is rejected before Schritt ausfuehren', {timeout:30000},()=>withPage(async page=>{
 await fixture(page);let approvals=0,before=0,after=0;
 const j=signedSaveJournal();j.state='TICKET_SAVE_VERIFIED';
 const journal={read:()=>j,advance:state=>{j.state=state;j.events.push({state})}};
 const checkReceipt=async()=>{
  const s=await mbcSignatureState(page),receipt=assessMbcReviewSignature({signature:s,journal:j,draftVerified:true,serverVerified:true});
  if(!receipt.ok)throw Error('SIGNATURE_CHANGED_AFTER_AUTHORIZATION: '+receipt.reason);
 };
 await assert.rejects(()=>finishPhase2Route(page,{ticketId:ticket,journal,route:'REVIEW',ask:async()=>{throw Error('NO_TERMINAL_INPUT')},
  beforeAuthorize:async()=>{before++;await checkReceipt()},
  beforeExecute:async()=>{after++;await checkReceipt()},
  controls:{authorize:async()=>{approvals++;await page.call(()=>{document.getElementById('mainForm:signature-value-id').value='FREMDE SIGNATUR';})}}}),
  /SIGNATURE_CHANGED_AFTER_AUTHORIZATION: SIGNATURE_FOREIGN_VALUE/);
 assert.equal(before,1);assert.equal(after,1);assert.equal(approvals,1);
 const result=await page.call(()=>({save:window.__saveClicks,send:window.__sendClicks,foreign:document.getElementById('foreign').value}));
 assert.equal(result.save,0);assert.equal(result.send,0);assert.equal(result.foreign,'SAFE');
 assert.equal(j.events.some(e=>e.state==='EXECUTE_INTENT'),false);
}));
