/** RC76 orchestration of the EXISTING local PDF checks in the active run.
 * No invented generator arguments, formulas or statements. Missing PDFs must
 * be created with the existing interactive programs. No COMARCH mutation here. */
import fs from 'node:fs';
import path from 'node:path';
import {requireThat as need} from '../lib/core.mjs';
import {writeJSON,stamp,ledger} from '../lib/control.mjs';
import {phase2Admission} from '../lib/phase2-admission.mjs';
import {approvedWwid,inspectExistingStatements,generatorPaths} from '../lib/phase2-pdf-evidence.mjs';
import {readPhase2MemberEvidence} from '../lib/phase2-member-evidence.mjs';
import {resolveMemberMapping} from '../lib/member-mapping.mjs';
import {openPhase2Ticket} from '../lib/phase2-navigation.mjs';
import * as UI from '../lib/browser-workflow.mjs';

export function verifyLegacyPlanAlias(rule,member,mapping){
 if(!rule.requiresPlanConfirmation)return {verified:true,method:'CANONICAL_DESCRIPTION_PLANS'};
 need(member.profileVerified&&member.profile?.mercerId,'P2_LEGACY_IPP_MEMBER','IPP-Alteintrag ohne gebundenes Memberprofil.');
 const resolved=resolveMemberMapping(mapping,member.profile.mercerId);
 need(resolved.kind==='FOUND'&&Array.isArray(resolved.entry?.records),'P2_LEGACY_IPP_MAPPING','IPP-Alteintrag nicht eindeutig im Bestand.');
 const plans=new Set(resolved.entry.records.flatMap(r=>[...(r.dc===1?['DC']:[]),...(r.ppPlus===1?['PP+']:[])]));
 need(rule.targets.every(t=>plans.has(t)),'P2_LEGACY_IPP_PLAN_CONFLICT','IPP-Alteintrag passt nicht zu DC/PP+ im gebundenen Bestand. Keine Anlage geraten.');
 return {verified:true,method:'LEGACY_IPP_CONFIRMED_BY_MEMBER_MAPPING'};
}

export function reviewedPdfProof({root,ticketId,rule,wwid,member,before,wwidOrigin,planEvidence}){
 const fresh=inspectExistingStatements(root,rule.targets,wwid);
 need(fresh.artifacts.length===before.artifacts.length&&fresh.artifacts.every(a=>{
  const p=before.artifacts.find(x=>x.plan===a.plan);return p&&p.name===a.name&&p.sha256===a.sha256&&p.bytes===a.bytes;
 }),'P2_PDF_MUTATED','PDFs seit Inhaltspruefung veraendert. Keine Anlage.');
 return {...fresh,ticketId,wwidOrigin,memberProfileVerified:true,
  memberId:member.profile.mercerId,memberName:{first:member.profile.first,last:member.profile.last},
  operatorContentReviewed:true,operatorPersonTicketBindingReviewed:true,
  operatorNameOnlyRecheckCompleted:false,planEvidence,
  automaticAttachmentAuthorized:false,comarchStatus:'NOT_ATTACHED_NOT_SAVED_NOT_FORWARDED'};
}

export async function preparePhase2PdfEvidence({root,page,row,mapping,ask,log=console.log,memberLookup=readPhase2MemberEvidence,controls=null}){
 const id=String(row.ticketId),admission=phase2Admission(row,ledger(root).pending),rule=admission.rule;
 need(admission.allowed&&rule.kind==='ACCOUNT_STATEMENT','P2_PDF_PREP_RULE','Kein Kontoauszug-Auftrag.');
 const actions=path.join(root,'.runtime','phase2','actions');
 need(!fs.existsSync(path.join(actions,'MCR_PHASE2_'+id+'.json'))&&!fs.existsSync(path.join(actions,'MCR_PHASE2_WORK_'+id+'.json')),
  'P2_PDF_PREP_PREVIOUS_ACTION','Schon begonnene Phase-2-Aktion: keine neue PDF-Vorbereitung.');
 await openPhase2Ticket(page,row,{log,manualOpen:async ticket=>{
  need(String(await ask('Nur Ticket '+ticket+' im Bot-Edge oeffnen. OFFEN / ABBRUCH: ')).toUpperCase()==='OFFEN','P2_OPEN_ABORT','Abgebrochen.');
 }});
 await UI.assertTicket(page,id);await controls?.readDetail?.(page,id);
 const member=await memberLookup(page);
 need(member.profileVerified&&member.profile?.first&&member.profile?.last&&member.profile?.mercerId,
  'P2_MEMBER_NOT_BOUND','Kein eindeutiges COMARCH-Memberprofil fuer Kontoauszuege.');
 const planEvidence=verifyLegacyPlanAlias(rule,member,mapping);
 need(!member.wwid||!member.memberReferenceWwid||member.wwid===member.memberReferenceWwid,
  'P2_WWID_CONFLICT','WWID-Feld widerspricht gebundener INTL01-Memberreferenz.');
 // Never use a generic MercerID or scan unrelated PDFs for a person ID.
 let wwid=member.wwid||member.memberReferenceWwid;
 const wwidOrigin=member.wwid?'EXPLICIT_COMARCH_FIELD':member.memberReferenceWwid?'BOUND_INTL01_MEMBER_REFERENCE':'OPERATOR_ENTRY';
 if(!wwid)wwid=approvedWwid(await ask('Verifizierte WWID dieser Person (nicht pauschal MercerID): '));
 wwid=approvedWwid(wwid);
 log('P2_PDF_PERSON: '+id+' | '+member.profile.first+' '+member.profile.last+' | WWID '+wwid+' | '+wwidOrigin);
 const missing=[];
 for(const plan of rule.targets){
  try{inspectExistingStatements(root,[plan],wwid);}
  catch(e){if(!['P2_EXACT_PDF_MISSING','P2_OUTPUT_FOLDER_MISSING'].includes(e.code))throw e;missing.push(plan);}
 }
 if(missing.length){
  log('P2_PDF_ERSTELLUNG_ERFORDERLICH: '+id+' | '+missing.join('+')+' | bestehende Generatoren bedienen; keine erfundenen Startparameter.');
  for(const plan of missing){const p=generatorPaths(root,plan);log('GENERATOR '+plan+': '+p.start);log('ERWARTETE_PDF: '+path.join(p.output,wwid+'_Kontoauszug_'+plan+'.pdf'));}
  const answer=String(await ask('Fehlende PDFs im bestehenden Generator fuer diese Person erstellen. PDFS_BEREIT / UEBERSPRINGEN / ABBRUCH: ')).trim().toUpperCase();
  if(answer==='UEBERSPRINGEN')return {status:'SKIPPED_UNCHANGED',ticketId:id,noWrite:true,reason:'PDF_CREATION_REQUIRED'};
  need(answer==='PDFS_BEREIT','P2_OPERATOR_ABORT','Keine neuen PDFs freigegeben.');
 }
 const before=inspectExistingStatements(root,rule.targets,wwid);
 for(const a of before.artifacts)log('P2_PDF_INHALT_PRUEFEN: '+a.plan+' | '+a.file);
 const response=String(await ask('Ticket '+id+': Person, WWID, Zeitraum, Berechtigung und Inhalte ALLER '+before.artifacts.length+' PDFs geprueft? JA / UEBERSPRINGEN / ABBRUCH: ')).trim().toUpperCase();
 if(response==='UEBERSPRINGEN')return {status:'SKIPPED_UNCHANGED',ticketId:id,noWrite:true,reason:'PDF_CONTENT_REVIEW_DEFERRED'};
 need(response==='JA','P2_CONTENT_REVIEW_REQUIRED','Keine Anlage ohne Inhaltspruefung.');
 await UI.assertTicket(page,id);
 const afterMember=await memberLookup(page);
 need(afterMember.profileVerified&&afterMember.profile.mercerId===member.profile.mercerId&&
  afterMember.profile.first===member.profile.first&&afterMember.profile.last===member.profile.last&&
  (!afterMember.wwid||afterMember.wwid===wwid)&&(!afterMember.memberReferenceWwid||afterMember.memberReferenceWwid===wwid),
  'P2_PDF_MEMBER_CHANGED','Member/WWID waehrend der PDF-Pruefung geaendert.');
 const proof=reviewedPdfProof({root,ticketId:id,rule,wwid,member,before,wwidOrigin,planEvidence});
 const file=path.join(root,'.runtime','phase2','MCR_PHASE2_PDF_BELEG_'+id+'_'+stamp()+'.json');
 writeJSON(file,proof);log('PASS P2_PDF_BELEGE_IM_LAUF: '+id+' | '+rule.targets.join('+')+' | keine COMARCH-Aenderung bisher.');
 return {status:'PDF_PROOF_READY',ticketId:id,proof,file};
}
