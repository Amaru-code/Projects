/** RC77: one-time, strictly bound removal of RC76's incorrect work marker.
 * Only unfinished DIRECT work with a byte-derived original may be corrected.
 * No email, no routing action and no duplicate ticket save on uncertain proof.
 */
import {requireThat as need,sha256} from '../lib/core.mjs';
import {sleep} from '../lib/cdp.mjs';
import * as UI from '../lib/browser-workflow.mjs';
import {ensurePhase2Edit} from '../lib/phase2-edit-mode.mjs';
import {commitDescription} from '../lib/trusted-description.mjs';
import {phase2FieldSnapshot,savePhase2Ticket} from '../lib/phase2-comarch-actions.mjs';
import {watchPhase2Save} from '../lib/phase2-save-settle.mjs';
import {readPhase2Queue} from '../lib/phase2-readonly.mjs';
const norm=s=>String(s??'').replace(/\r\n?/g,'\n').trim();

export function directMarkerRecoveryDecision({old,storedDescription,gevo,priorEvents=[]}){
 const sameBefore=norm(storedDescription)===norm(old?.descriptionBefore);
 const sameMarked=norm(storedDescription)===norm(old?.descriptionAfter);
 if(!['DB_DIRECT','MARK_DIRECT'].includes(old?.rule)||!old||!['TICKET_SAVE_INTENT','TICKET_SAVE_VERIFIED','REVIEW_INTENT','REVIEW_VERIFIED'].includes(old.state))
  return {ok:false,reason:'DIRECT_RECOVERY_STATE_UNSUPPORTED'};
 if(priorEvents.some(x=>x.state==='EXECUTE_INTENT'||x.state==='ROUTED_VERIFIED'))
  return {ok:false,reason:'DIRECT_RECOVERY_ROUTE_ALREADY_STARTED'};
 if(!['Anfrage Member'].includes(gevo))return {ok:false,reason:'DIRECT_RECOVERY_GEVO_UNVERIFIED'};
 if(!sameBefore&&!sameMarked)return {ok:false,reason:'DIRECT_RECOVERY_DESCRIPTION_CONFLICT'};
 if(sameBefore)return {ok:true,action:'ALREADY_ORIGINAL'};
 if(priorEvents.some(x=>x.state==='RC77_DIRECT_CLEANUP_SAVE_CLICK_INTENT'))return {ok:false,reason:'DIRECT_RECOVERY_PREVIOUS_CLICK_UNCERTAIN'};
 const attempts=priorEvents.filter(x=>x.state==='RC77_DIRECT_CLEANUP_INTENT').length;
 // RC57-style one pre-click recovery: an interrupted focus/typing attempt
 // may be retried only when the fresh SERVER still has the exact old text,
 // no save click was ever attempted, and an operator authorizes again.
 if(attempts>1)return {ok:false,reason:'DIRECT_RECOVERY_PRECLICK_RETRY_LIMIT'};
 return {ok:true,action:attempts===1?'RETRY_BEFORE_SAVE':'REMOVE_RC76_MARKER'};
}

export async function restoreLegacyDirectMarker({page,ticketId,old,journal,ask,log,open,controls=null}){
 await UI.assertTicket(page,ticketId);
 const [field,snapshot]=await Promise.all([UI.additionalDescriptionState(page),phase2FieldSnapshot(page)]);
 need(field.ok&&typeof field.value==='string'&&snapshot.gevo.count===1,'P2_DIRECT_RECOVERY_UNBOUND','Tickettext/GEVO nicht eindeutig gebunden.');
 const decision=directMarkerRecoveryDecision({old,storedDescription:field.value,gevo:snapshot.gevo.value,priorEvents:journal.read()?.events||[]});
 need(decision.ok,decision.reason||'P2_DIRECT_RECOVERY_BLOCKED','Bereinigung des frueheren Direktfall-Markers nicht sicher. Keine Weiterleitung.');
 if(decision.action==='ALREADY_ORIGINAL'){
  log('PASS P2_RC77_DIRECT_ORIGINAL_VERIFIED: '+ticketId+' | kein Bearbeitet-Marker, keine weitere Speicherung.');
  return {changed:false};
 }
 const confirmation='MARKER_ENTFERNEN_'+ticketId;
 log('P2_RC77_DIRECT_MARKER_ALTFALL: RC76 hat bei einer blossen Direktweiterleitung einen Bearbeitungsvermerk gespeichert. Nur diesen nachweislich vom Bot angehaengten Vermerk entfernen; USC, Phase-1-Status und Kundenwunsch bleiben unveraendert.');
 if(decision.action==='RETRY_BEFORE_SAVE')log('P2_RC77_DIRECT_PRECLICK_RECOVERY: Fruehere Bereinigung endete nach Freigabe aber VOR jeglichem Speicherklick. Server enthaelt weiterhin exakt den alten Status; maximal ein weiterer fokussierter Eingabeversuch.');
 need((await ask('Ticket '+ticketId+': Vermerk vor Weiterleitung gezielt entfernen? '+confirmation+' / ABBRUCH: ')).toUpperCase()===confirmation,
  'P2_DIRECT_CLEANUP_DECLINED','Keine Aenderung ohne Freigabe.');
 controls?.assertActive?.();
 journal.observe('RC77_DIRECT_CLEANUP_INTENT',{oldSha256:sha256(old.descriptionAfter),newSha256:sha256(old.descriptionBefore),retryBeforeSave:decision.action==='RETRY_BEFORE_SAVE'});
 await ensurePhase2Edit(page,{ticketId,ask,log});
 await commitDescription(page,{ticketId,expected:old.descriptionBefore,allowedBefore:[old.descriptionAfter],log,
  assertActive:()=>controls?.assertActive?.(),manualFocus:async()=>{
   need((await ask('Beschreibung verdeckt: zuerst BEREIT_BESCHREIBUNG, dann im Bot-Edge das Feld Zusaetzliche Beschreibung anklicken: ')).toUpperCase()==='BEREIT_BESCHREIBUNG',
    'P2_DIRECT_CLEANUP_FOCUS','Kein sicheres Beschreibungsfeld.');
  }});
 const preSaveCheck=async()=>{
  await UI.assertTicket(page,ticketId);
  const [v,g]=await Promise.all([UI.additionalDescriptionState(page),phase2FieldSnapshot(page)]);
  need(v.ok&&v.editable&&norm(v.value)===norm(old.descriptionBefore)&&g.gevo.count===1&&g.gevo.value==='Anfrage Member',
   'P2_DIRECT_CLEANUP_FORM_RESET','Beschreibung/GEVO vor Korrekturspeicherung geaendert. Kein Speicherklick.');
 };
 const watcher=await watchPhase2Save(page);let click;
 try{
  click=await savePhase2Ticket(page,{ticketId,log,preActionCheck:preSaveCheck,
   beforeAutoClick:()=>journal.observe('RC77_DIRECT_CLEANUP_SAVE_CLICK_INTENT'),
   manualClick:async()=>{
    journal.observe('RC77_DIRECT_CLEANUP_SAVE_CLICK_INTENT',{manual:true});
    need((await ask('Ticketbeschreibung einmal physisch gespeichert? EINMAL_GEKLICKT / ABBRUCH: ')).toUpperCase()==='EINMAL_GEKLICKT',
     'P2_DIRECT_CLEANUP_SAVE_UNCLEAR','Korrekturspeicherung nicht bestaetigt.');
   }});
 }catch(e){watcher.cancel();throw e;}
 const settled=await watcher.settle();
 journal.observe('RC77_DIRECT_CLEANUP_NETWORK_OBSERVED',{status:settled.status,writeStarts:settled.writeStarts,method:click.method});
 need(!['WRITE_REQUEST_ERROR','NETWORK_STILL_ACTIVE'].includes(settled.status),'P2_DIRECT_CLEANUP_NETWORK','Korrekturspeicherung unklar; kein Zweitklick.');
 await UI.navigateToScope(page,'IN_BEARBEITUNG',{refresh:true});
 const queue=await readPhase2Queue(page),persisted=queue.rows?.find(x=>x.ticketId===ticketId);
 need(queue.ok&&persisted,'P2_DIRECT_CLEANUP_TICKET_MISSING','Ticket nach Korrekturspeicherung nicht mehr in eigener Liste. Keine Weiterleitung.');
 need([norm(old.descriptionAfter),norm(old.descriptionBefore)].includes(norm(persisted.descriptionValue)),
  'P2_DIRECT_CLEANUP_QUEUE_CONFLICT','Listenbeschreibung wurde von anderer Stelle geaendert.');
 await open(persisted);await UI.assertTicket(page,ticketId);
 const [fresh,ge]=await Promise.all([UI.additionalDescriptionState(page),phase2FieldSnapshot(page)]);
 need(fresh.ok&&norm(fresh.value)===norm(old.descriptionBefore)&&ge.gevo.count===1&&ge.gevo.value==='Anfrage Member',
  'P2_DIRECT_CLEANUP_SERVER_READBACK','Bereinigung auf Server nicht bestaetigt. Kein zweiter Speicherklick.');
 journal.observe('RC77_DIRECT_CLEANUP_VERIFIED',{serverReadback:true,originalDescriptionSha256:sha256(old.descriptionBefore)});
 log('PASS P2_RC77_DIRECT_MARKER_REMOVED: '+ticketId+' | Server-Readback exakt | einmal gespeichert | kein E-Mail-Versand.');
 return {changed:true};
}
