/** RC52 DB and private-MBC draft actions. No PDF generation or mail sending. */
import {prepareMbcDraft,applyMbcDraft,verifyMbcDraft} from '../lib/phase2-mbc-draft.mjs';
import {commitDescription} from '../lib/trusted-description.mjs';
import {requireThat as need} from '../lib/core.mjs';
import {sleep} from '../lib/cdp.mjs';
import * as UI from '../lib/browser-workflow.mjs';
import {ensurePhase2Edit} from '../lib/phase2-edit-mode.mjs';
import {readPhase2Queue} from '../lib/phase2-readonly.mjs';
import {readPhase2MemberEvidence} from '../lib/phase2-member-evidence.mjs';
import {resolveMemberMapping} from '../lib/member-mapping.mjs';
import {phase2WorkRule,phase2WorkDescription,legacyDirectMarkerJournal,privateMbcDraft} from '../lib/phase2-work-rules.mjs';
import {phase2WorkJournal} from '../lib/phase2-work-journal.mjs';
import {restoreLegacyDirectMarker} from './phase2-direct-marker-recovery.mjs';
import {setPhase2Gevo,phase2FieldSnapshot,savePhase2Draft,savePhase2Ticket} from '../lib/phase2-comarch-actions.mjs';
import {openPhase2Ticket} from '../lib/phase2-navigation.mjs';
import {watchPhase2Save} from '../lib/phase2-save-settle.mjs';
import {finishPhase2Route} from '../lib/phase2-review-flow.mjs';
import {selectMbcSignature,mbcSignatureState,MBC_SIGNATURE_VALUE,assessMbcReviewSignature} from '../lib/phase2-mbc-signature.mjs';
const norm=s=>String(s??'').replace(/\r\n?/g,'\n').trim();

export async function handlePhase2Work({root,page,row,mapping,ask,log=console.log,memberLookup=readPhase2MemberEvidence,controls=null,routeListBefore=null}){
 const id=row.ticketId,journal=phase2WorkJournal(root,id),old=journal.read();
 const candidate=phase2WorkRule(old?{...row,descriptionValue:old.descriptionBefore}:row);
 const direct=candidate.kind==='DB_DIRECT'||candidate.kind==='MARK_DIRECT';
 const legacyDirect=!!old&&legacyDirectMarkerJournal(old);
 const draftSavedWithoutTicket=!!(old?.draft&&['DRAFT_SAVE_VERIFIED','EDIT_VERIFIED'].includes(old.state)&&old.events?.some(e=>e.state==='DRAFT_SAVE_VERIFIED')&&!old.events?.some(e=>e.state==='TICKET_SAVE_INTENT'));
 need(['DB_DIRECT','MARK_DIRECT','MBC_PRIVATE_EMAIL'].includes(candidate.kind),'P2_WORK_RULE','Kein freigegebener neuer Bearbeitungstyp.');
 if(old){
  need(old.schema==='MCR_PHASE2_WORK_JOURNAL_V1'&&old.ticketId===id&&old.rule===candidate.kind&&
   (['TICKET_SAVE_INTENT','TICKET_SAVE_VERIFIED','REVIEW_INTENT','REVIEW_VERIFIED'].includes(old.state)||draftSavedWithoutTicket)&&
   (norm(row.descriptionValue)===norm(old.descriptionAfter)||((old.state==='TICKET_SAVE_INTENT'||draftSavedWithoutTicket||legacyDirect)&&norm(row.descriptionValue)===norm(old.descriptionBefore))),
   'P2_WORK_PENDING','Vorheriger Schritt ungeklaert. Keine Wiederholung von Speichern/Entwurf/Weiterleitung.');
 }
 const open=async r=>openPhase2Ticket(page,r,{log,manualOpen:async ticket=>{
  need((await ask('Im Bot-Edge nur Ticket '+ticket+' oeffnen. OFFEN / ABBRUCH: ')).toUpperCase()==='OFFEN','P2_OPEN_ABORT','Abgebrochen.');
 }});
 await open(row);await UI.assertTicket(page,id);await controls?.readDetail?.(page,id);
 // RC56: A freshly reopened ticket is the independent server readback.
 // Draft Save is NOT Ticket Save. Do not infer a persisted marker from an
 // earlier successful browser edit or from the operator's click confirmation.
 let repair=false,alreadyPersisted=false;
 // RC77: old RC76 DIRECT work may already have saved the incorrect marker.
 // Restore only that exact bot-added suffix, using a separate one-click
 // correction and independent server readback before any route action.
 if(legacyDirect)await restoreLegacyDirectMarker({page,ticketId:id,old,journal,ask,log,open,controls});
 const descriptionAfter=legacyDirect?old.descriptionBefore:old?.descriptionAfter||phase2WorkDescription(candidate.kind,row.descriptionValue);
 if(old){
  const stored=await phase2FieldSnapshot(page),storedDesc=await UI.additionalDescriptionState(page);
  need(storedDesc.ok&&typeof storedDesc.value==='string','P2_WORK_READBACK_UNCLEAR','Ticketbeschreibung nach Wiederaufnahme nicht lesbar. Keine Aenderung.');
  need([norm(old.descriptionBefore),norm(old.descriptionAfter)].includes(norm(storedDesc.value)),
   'P2_WORK_READBACK_CONFLICT','Fremde gespeicherte Beschreibung. Keine Ersetzung.');
  // For old MBC journals the draft was already saved. It must still be
  // available, byte/text-equivalent, before we touch GEVO or description.
  if(old.draft)need(await verifyMbcDraft(page,id,old.draft),'P2_MBC_RESUME_DRAFT_CHANGED',
   'Gespeicherter MBC-Entwurf nicht exakt vorhanden. Kein weiterer Schreibschritt.');
  alreadyPersisted=norm(storedDesc.value)===norm(descriptionAfter)&&stored.gevo.value==='Anfrage Member';
  repair=!alreadyPersisted&&(old.state==='TICKET_SAVE_INTENT'||draftSavedWithoutTicket);
  log('P2_RC56_SERVER_READBACK: '+(alreadyPersisted?'ALREADY_PERSISTED':repair?'UNSAVED_REPAIR_REQUIRED':'INCOMPLETE_STOP')+' | GEVO='+
   (stored.gevo.value==='Anfrage Member'?'EXACT':stored.gevo.value===''?'EMPTY':'OTHER')+' | Beschreibung='+
   (norm(storedDesc.value)===norm(descriptionAfter)?'EXPECTED':legacyDirect&&norm(storedDesc.value)===norm(old.descriptionAfter)?'RC76_LEGACY_MARKER':'ORIGINAL'));
  if(repair){
   // RC57: the real RC56 incident stopped at DESCRIPTION_FOCUS after an
   // authorization, before ANY second Ticket-save click or route action.
   // An older, pre-authorization RC55 save click is not evidence of a second
   // click. Inspect the append-only suffix after the latest authorization.
   const previousAuthorizations=old.events.filter(e=>['SAVE_REPAIR_AUTHORIZED','SAVE_REPAIR_FOCUS_RETRY_AUTHORIZED'].includes(e.state));
   const lastAuthorizationIndex=old.events.findLastIndex(e=>['SAVE_REPAIR_AUTHORIZED','SAVE_REPAIR_FOCUS_RETRY_AUTHORIZED'].includes(e.state));
   const tail=lastAuthorizationIndex<0?[]:old.events.slice(lastAuthorizationIndex+1);
   need(!old.events.some(e=>['EXECUTE_INTENT','REVIEW_INTENT'].includes(e.state))&&
    previousAuthorizations.length<3&&tail.length===0,
    'P2_WORK_REPAIR_LIMIT','Voriger Reparatur-/Weiterleitungsschritt unklar oder bereits ein weiterer Klick begonnen. Keine Wiederholung.');
   need(['','Anfrage Member','Anfrage Membe'].includes(stored.gevo.value),
    'P2_WORK_GEVO_CONFLICT','Anderer GEVO-Wert. Kein Ueberschreiben.');
   log('P2_WORK_SAVE_REPAIR: MBC-Entwurf bleibt unveraendert; nur noch fehlende GEVO-/Beschreibungs-Speicherung wird geprueft.');
   if(old.state==='TICKET_SAVE_INTENT'){
    need((await ask('Ticket '+id+': gespeicherte Beschreibung FEHLT und KEINE Weiterleitung ausgefuehrt? NICHT_GESPEICHERT_'+id+' / ABBRUCH: ')).toUpperCase()==='NICHT_GESPEICHERT_'+id,
     'P2_WORK_REPAIR_DECLINED','Kein erneuter Speicherklick.');
    journal.observe(previousAuthorizations.length?'SAVE_REPAIR_FOCUS_RETRY_AUTHORIZED':'SAVE_REPAIR_AUTHORIZED');
    if(previousAuthorizations.length)log('P2_RC57_PRECLICK_FOCUS_RECOVERY: Kein Speicherklick nach der letzten Reparaturfreigabe; neue Freigabe nach Serverpruefung.');
   }else{
    // No previous ticket-save intent: the draft has already been saved and
    // reread from this ticket. Complete only the missing ticket fields.
    journal.observe('POST_DRAFT_RESUME_VERIFIED',{previousState:old.state});
   }
  }
 }
 await ensurePhase2Edit(page,{ticketId:id,ask,log});
 const d=await UI.additionalDescriptionState(page);
 need(d.ok&&d.editable&&[norm(row.descriptionValue),norm(old?.descriptionBefore),norm(old?.descriptionAfter)].includes(norm(d.value)),
  'P2_WORK_DESCRIPTION_CHANGED','Ticketbeschreibung seit Listenauswahl geaendert.');
 let draft=old?.draft||null,draftPlan=null;
 if(!old||repair){
  let memberId=null;
  if(!old&&candidate.kind==='MBC_PRIVATE_EMAIL'){
   const member=await memberLookup(page);
   need(member.profileVerified&&member.profile?.last&&member.profile?.mercerId,'P2_MBC_MEMBER','Kein verifizierter Member fuer die persoenliche Anrede.');
   memberId=member.profile.mercerId;
   const resolved=resolveMemberMapping(mapping,memberId);
   let gender=resolved.entry?.genderStatus==='CONSISTENT'?resolved.entry.gender:null;
   if(!['M','F'].includes(gender)){
    log('Anrede fuer '+member.profile.last+' nicht eindeutig im Bestand. Keine Ableitung aus dem Vornamen.');
    const answer=(await ask('Anrede aus Originalunterlagen: HERR / FRAU / ABBRUCH: ')).toUpperCase();
    need(['HERR','FRAU'].includes(answer),'P2_MBC_SALUTATION','Keine bestaetigte Anrede.');gender=answer==='HERR'?'M':'F';
   }
   draft=privateMbcDraft({lastName:member.profile.last,gender});
   draftPlan=await prepareMbcDraft({root,page,ticketId:id,draft,ask,controls,log});
   if(draftPlan.kind==='SKIP')return {status:'SKIPPED_UNCHANGED',ticketId:id,reason:'MBC_EXISTING_DRAFT_RETAINED',noWrite:true};
  }
  controls?.assertActive?.();
  const ensureGevo=()=>setPhase2Gevo(page,{manualFocus:async()=>{
   need((await ask('GEVO-Feld fokussiert? FOKUS / ABBRUCH: ')).toUpperCase()==='FOKUS','P2_OPERATOR_ABORT','Kein GEVO-Fokus.');
  },manualSelect:async()=>{
   need((await ask('Anfrage Member im Vorschlag ausgewaehlt? AUSGEWAEHLT / ABBRUCH: ')).toUpperCase()==='AUSGEWAEHLT','P2_OPERATOR_ABORT','Kein GEVO.');
  }});
  if(!old){journal.begin({rule:candidate.kind,descriptionBefore:row.descriptionValue,descriptionAfter,draft,memberId});journal.advance('EDIT_INTENT');}
  // Preserve COMARCH's working RC55 order for selecting GEVO before draft.
  // After Entwurf speichern, revalidate it because ICEfaces may reset it.
  // The additional description is deliberately written only AFTER the draft.
  if(draft&&!old){
   await ensureGevo();
   log('P2_RC56_GEVO_PRE_DRAFT: Anfrage Member vor Entwurf speichern gewaehlt.');
   const result=await applyMbcDraft(page,{ticketId:id,plan:draftPlan,beforeWrite:data=>{controls?.assertActive?.();journal.observe('MBC_DRAFT_WRITE_INTENT',data);}});
   journal.observe('MBC_DRAFT_EDITOR_VERIFIED',{method:result.method});log('PASS P2_MBC_ENTWURF_EDITOR: '+result.method);
   // RC58: select COMARCH's standard INTL01 signature BEFORE saving the
   // draft; never append an improvised footer or send the message.
   await selectMbcSignature(page,{ticketId:id,log,beforeSelect:()=>journal.observe('MBC_SIGNATURE_SELECTION_INTENT'),
    manualFocus:async()=>{need((await ask('Signaturfeld INTL01 fokussiert? FOKUS / ABBRUCH: ')).toUpperCase()==='FOKUS','P2_OPERATOR_ABORT','Signaturfeld nicht fokussiert.');},
    manualSelect:async()=>{need((await ask('Exakt INTL01 - Intel Deutschland GmbH ausgewaehlt? AUSGEWAEHLT / ABBRUCH: ')).toUpperCase()==='AUSGEWAEHLT','P2_OPERATOR_ABORT','Signatur nicht ausgewaehlt.');}});
   journal.observe('MBC_SIGNATURE_SELECTED_EXACT');
   need(await verifyMbcDraft(page,id,draft),'P2_MBC_SIGNATURE_DRAFT_CHANGED','Signaturauswahl hat den MBC-Text veraendert. Kein Speichern.');
   journal.advance('DRAFT_SAVE_INTENT');
   const watcher=await watchPhase2Save(page);
   try{await savePhase2Draft(page);}catch(e){watcher.cancel();throw e;}
   const observed=await watcher.settle();journal.observe('DRAFT_NETWORK_OBSERVED',observed);
   need(!['WRITE_REQUEST_ERROR','NETWORK_STILL_ACTIVE'].includes(observed.status),'P2_MBC_DRAFT_NETWORK','Entwurfstatus unklar; kein weiterer Schreibschritt.');
   await UI.assertTicket(page,id);
   need(await verifyMbcDraft(page,id,draft),'P2_MBC_DRAFT_CHANGED','Entwurf nach Klick geaendert.');
   const signed=await mbcSignatureState(page);
   need(signed.count===1&&signed.value===MBC_SIGNATURE_VALUE,'P2_MBC_SIGNATURE_AFTER_DRAFT','INTL01 Signatur nach Entwurf speichern nicht bestaetigt.');
   journal.observe('MBC_SIGNATURE_DRAFT_SAVE_VERIFIED');
   journal.advance('DRAFT_SAVE_VERIFIED');
   log('P2_RC56_DRAFT_FIRST: Entwurf ausgefuehrt; GEVO/Beschreibung werden jetzt im aktualisierten Formular gesetzt.');
  }
  await ensurePhase2Edit(page,{ticketId:id,ask,log});
  await ensureGevo();
  // Read the description again after the draft's ICEfaces partial update.
  const current=await UI.additionalDescriptionState(page);
  need(current.ok&&current.editable&&[norm(row.descriptionValue),norm(descriptionAfter)].includes(norm(current.value)),
   'P2_WORK_AFTER_DRAFT_CONFLICT','COMARCH hat die Beschreibung geaendert. Kein Ueberschreiben.');
  if(direct){
   // No subject-matter processing: the original customer text remains exact.
   // GEVO is still selected/saved for the existing bound COMARCH route.
   const bound=await UI.additionalDescriptionState(page);
   need(bound.ok&&norm(bound.value)===norm(descriptionAfter),
    'P2_DIRECT_DESCRIPTION_UNCHANGED','Beschreibung einer Direktweiterleitung wurde veraendert.');
   log('PASS P2_RC77_DIRECT_DESCRIPTION_UNCHANGED: Kein Bearbeitet-Vermerk, keine Beschreibungseingabe.');
  }else await commitDescription(page,{ticketId:id,expected:descriptionAfter,
   allowedBefore:[row.descriptionValue,old?.descriptionBefore].filter(x=>typeof x==='string'),log,
   assertActive:()=>controls?.assertActive?.(),manualFocus:async()=>{
    need((await ask('Beschreibung ist verdeckt. Im Terminal BEREIT_BESCHREIBUNG eingeben, DANN im Bot-Edge das Feld "Zusaetzliche Beschreibung" anklicken (kein weiterer Terminaltext): ')).toUpperCase()==='BEREIT_BESCHREIBUNG',
     'P2_DESCRIPTION_FOCUS_DECLINED','Keine manuelle Fokussierung freigegeben.');
   }});
  if(!old||journal.read().state==='DRAFT_SAVE_VERIFIED')journal.advance('EDIT_VERIFIED');
  await UI.assertTicket(page,id);
  need(await UI.verifyDescription(page,descriptionAfter)&&(await phase2FieldSnapshot(page)).gevo.value==='Anfrage Member',
   'P2_WORK_BEFORE_SAVE','GEVO oder Status vor Speicherung geaendert.');
  if(draft)need(await verifyMbcDraft(page,id,draft),'P2_MBC_DRAFT_BEFORE_SAVE','MBC-Entwurf nach Formular-Update nicht mehr exakt.');
  if(journal.read().state==='EDIT_VERIFIED')journal.advance('TICKET_SAVE_INTENT');
  const watcher=await watchPhase2Save(page);
  let click;
  const preSaveCheck=async()=>{
   await UI.assertTicket(page,id);
   const [field,ge]=await Promise.all([UI.additionalDescriptionState(page),phase2FieldSnapshot(page)]);
   need(field.ok&&field.editable&&norm(field.value)===norm(descriptionAfter)&&ge.gevo.count===1&&ge.gevo.value==='Anfrage Member',
    'P2_SAVE_FORM_RESET','COMARCH hat Beschreibung oder GEVO beim Fokussieren des Speichern-Knopfs zurueckgesetzt. KEIN Speicherklick.');
   if(draft)need(await verifyMbcDraft(page,id,draft),'P2_SAVE_DRAFT_CHANGED','MBC-Entwurf vor Speichern geaendert. Kein Klick.');
  };
  try{click=await savePhase2Ticket(page,{ticketId:id,log,beforeAutoClick:()=>journal.observe('TICKET_SAVE_AUTO_CLICK_INTENT'),preActionCheck:preSaveCheck,manualClick:async()=>{
   journal.observe('TICKET_SAVE_MANUAL_CLICK_INTENT');
   log('P2_SAVE_MANUELL: Kein sicherer automatischer Knopf. Im Bot-Edge genau einmal Ticket speichern klicken; erst danach den Klick bestaetigen.');
   need((await ask('Einmal physisch geklickt? EINMAL_GEKLICKT / ABBRUCH: ')).toUpperCase()==='EINMAL_GEKLICKT',
    'P2_WORK_SAVE_UNCLEAR','Speicherstatus unklar.');
  }});}catch(e){watcher.cancel();throw e;}
  const observed=await watcher.settle();journal.observe('TICKET_SAVE_NETWORK_OBSERVED',observed);
  need(!['WRITE_REQUEST_ERROR','NETWORK_STILL_ACTIVE'].includes(observed.status),'P2_WORK_SAVE_NETWORK',
   'Speicherstatus unklar. Kein Zweitklick.');
  log('P2_WORK_SAVE_SETTLED: '+observed.status+' | POST_gesamt='+observed.writeStarts+' (kein Speichernachweis) | Methode='+click.method+'; nur Server-Readback entscheidet; kein zweiter Klick.');
  await UI.navigateToScope(page,'IN_BEARBEITUNG',{refresh:true});
  let q=await readPhase2Queue(page),persisted=q.rows?.find(r=>r.ticketId===id);
  need(q.ok&&persisted,'P2_WORK_SERVER_TICKET_NOT_FOUND','Ticket nach Speichern nicht eindeutig in der eigenen Liste. Keine Wiederholung.');
  const queueMatches=norm(persisted.descriptionValue)===norm(descriptionAfter);
  const queueOriginal=norm(persisted.descriptionValue)===norm(old?.descriptionBefore??row.descriptionValue);
  need(queueMatches||queueOriginal,'P2_WORK_SERVER_DESCRIPTION_CONFLICT','Fremde Beschreibung nach Speichern. Keine Wiederholung.');
  await open(persisted);await UI.assertTicket(page,id);
  const fresh=await UI.additionalDescriptionState(page),freshGevo=await phase2FieldSnapshot(page);
  const detailMatches=fresh.ok&&norm(fresh.value)===norm(descriptionAfter)&&freshGevo.gevo.value==='Anfrage Member';
  if(!detailMatches){
   log('P2_WORK_SAVE_READBACK: NOT_PERSISTED | Liste='+(queueMatches?'EXPECTED':'ORIGINAL')+ ' | Ticket='+
    (fresh.ok&&norm(fresh.value)===norm(descriptionAfter)?'EXPECTED':'ORIGINAL_OR_UNKNOWN')+ ' | GEVO='+
    (freshGevo.gevo.value==='Anfrage Member'?'EXACT':'NOT_EXACT')+' | Kein Weiterleitungsklick.');
   need(false,'P2_WORK_SERVER_DESCRIPTION',
    'Ticketbeschreibung/GEVO im erneut geoeffneten Server-Ticket nicht gespeichert. Keine automatische Wiederholung.');
  }
  if(!queueMatches)log('P2_RC56_QUEUE_DETAIL_DIVERGENCE: Listenfeld unveraendert, aber frisch geoeffnetes Server-Ticket mit GEVO und Beschreibung exakt.');
 }
 let g=await phase2FieldSnapshot(page),verified=g.gevo.count===1&&g.gevo.value==='Anfrage Member'&&await UI.verifyDescription(page,descriptionAfter);
 if(!verified){
  // Read-only: a COMARCH ICEfaces re-render after entering edit mode can
  // temporarily return an empty GEVO despite an exact initial server read.
  // Never click Save/Forward during this bounded observation.
  for(let i=0;i<3&&!verified;i++){
   await sleep(220);await UI.assertTicket(page,id);
   g=await phase2FieldSnapshot(page);
   verified=g.gevo.count===1&&g.gevo.value==='Anfrage Member'&&await UI.verifyDescription(page,descriptionAfter);
  }
  if(!verified)log('P2_WORK_READBACK_DIAG: '+id+' | initialPersisted='+alreadyPersisted+' | GEVO='+
   (g.gevo.count!==1?'NOT_UNIQUE':g.gevo.value==='Anfrage Member'?'EXACT':'NOT_EXACT')+
   ' | Beschreibung='+(await UI.verifyDescription(page,descriptionAfter)?'EXPECTED':'NOT_EXACT')+
   ' | kein neuer Speicher- oder Weiterleitungsklick.');
 }
 need(verified,'P2_WORK_SERVER_VALUES','GEVO/Status nach erneutem Oeffnen nicht bestaetigt. Kein neuer Klick; Altfall zur Pruefung zurueckstellen.');
 if(draft){need(await verifyMbcDraft(page,id,draft),'P2_MBC_SAVED_DRAFT','MBC-Entwurf nach erneutem Oeffnen nicht bestaetigt. Keine Weiterleitung.');}
 if(alreadyPersisted&&draftSavedWithoutTicket){
  // Draft-related blur may have already committed both ticket fields. Only
  // journal those independently observed facts; do not click Ticket speichern.
  if(journal.read().state==='DRAFT_SAVE_VERIFIED')journal.advance('EDIT_VERIFIED');
  if(journal.read().state==='EDIT_VERIFIED')journal.advance('TICKET_SAVE_INTENT');
  journal.observe('SERVER_PERSISTED_NO_TICKET_CLICK');
 }
 if(journal.read().state==='TICKET_SAVE_INTENT')journal.advance('TICKET_SAVE_VERIFIED');
 log('PASS P2_WORK_SERVER_PERSISTENCE | '+candidate.kind+' | '+id);
 // RC58: a previously prepared MBC ticket (RC57 REVIEW_VERIFIED, no
 // EXECUTE_INTENT) can receive the missing signature without rewriting
 // its message, additional description or GEVO. Re-saving that same draft
 // is journaled independently; it is NOT a new email or ticket-save click.
 if(draft){
  const current=journal.read();
  need(!current.events.some(e=>e.state==='EXECUTE_INTENT'),'P2_MBC_SIGNATURE_AFTER_EXECUTE','Weiterleitung bereits begonnen. Keine erneute Aktion.');
  if(!current.events.some(e=>e.state==='MBC_SIGNATURE_DRAFT_SAVE_VERIFIED')){
   need(!current.events.some(e=>e.state==='MBC_SIGNATURE_SELECTION_INTENT')&&!current.events.some(e=>e.state==='MBC_SIGNATURE_DRAFT_SAVE_INTENT'),
    'P2_MBC_SIGNATURE_PREVIOUS_UNCERTAIN', 'Frueherer INTL01 Signaturauswahl-/Speicherversuch ungeklaert. Kein automatischer Wiederholungsversuch.');
   const selected=await selectMbcSignature(page,{ticketId:id,log,beforeSelect:()=>journal.observe('MBC_SIGNATURE_SELECTION_INTENT'),
    manualFocus:async()=>{need((await ask('Signaturfeld INTL01 fokussiert? FOKUS / ABBRUCH: ')).toUpperCase()==='FOKUS','P2_OPERATOR_ABORT','Signaturfeld nicht fokussiert.');},
    manualSelect:async()=>{need((await ask('Exakt INTL01 - Intel Deutschland GmbH ausgewaehlt? AUSGEWAEHLT / ABBRUCH: ')).toUpperCase()==='AUSGEWAEHLT','P2_OPERATOR_ABORT','Signatur nicht ausgewaehlt.');}});
   need(await verifyMbcDraft(page,id,draft),'P2_MBC_SIGNATURE_DRAFT_CHANGED','Der gespeicherte MBC-Entwurf wurde durch die Signaturauswahl geaendert. Kein neuer Entwurf.');
   journal.observe('MBC_SIGNATURE_SELECTED_EXACT',{method:selected.changed?'TRUSTED_OPTION':'ALREADY_EXACT'});
   if(selected.changed){
    journal.observe('MBC_SIGNATURE_DRAFT_SAVE_INTENT');
    const watcher=await watchPhase2Save(page);
    try{await savePhase2Draft(page);}catch(e){watcher.cancel();throw e;}
    const network=await watcher.settle();
    journal.observe('MBC_SIGNATURE_DRAFT_NETWORK_OBSERVED',{status:network.status,writeStarts:network.writeStarts});
    need(!['WRITE_REQUEST_ERROR','NETWORK_STILL_ACTIVE'].includes(network.status),'P2_MBC_SIGNATURE_SAVE_UNCLEAR',
     'Signatur-Entwurfsspeicherung noch unklar; keine Weiterleitung.');
    await UI.assertTicket(page,id);
    need(await verifyMbcDraft(page,id,draft),'P2_MBC_SIGNATURE_SAVED_DRAFT_CHANGED','MBC-Antwort nach Signatur-Entwurfsspeicherung veraendert.');
    const afterSign=await mbcSignatureState(page);
    need(afterSign.count===1&&afterSign.value===MBC_SIGNATURE_VALUE,'P2_MBC_SIGNATURE_SAVE_NOT_VERIFIED','INTL01 Auswahl nach Entwurf speichern nicht bestaetigt.');
    need(await UI.verifyDescription(page,descriptionAfter)&&(await phase2FieldSnapshot(page)).gevo.value==='Anfrage Member',
     'P2_MBC_SIGNATURE_OTHER_FIELDS_CHANGED','GEVO oder Beschreibung nach Signatur-Entwurfsspeichern veraendert.');
   }
   journal.observe('MBC_SIGNATURE_DRAFT_SAVE_VERIFIED',{method:selected.changed?'DRAFT_RESAVED_WITH_INTL01':'SIGNATURE_ALREADY_EXACT'});
   log('PASS P2_MBC_SIGNATURE_DRAFT_READY: INTL01 ausgewaehlt; vorhandener MBC-Text erhalten; KEIN EMAILVERSAND');
  }
 }
 // RC72: ICEfaces can reset the *live signature chooser* as the already
 // saved MBC ticket enters the review workflow. Do not treat a volatile blank
 // chooser as proof the saved signature vanished. Conversely, never route on
 // a blank chooser without the prior signed draft-save receipt, unchanged
 // editor text and independent ticket-field readback.
 const checkFinalMbc=async(stage)=>{
  await UI.assertTicket(page,id);
  need(await UI.verifyDescription(page,descriptionAfter),
   direct?'P2_DIRECT_DESCRIPTION_CHANGED':'P2_WORK_FINAL_MARKER',
   direct?'Originalbeschreibung vor Weiterleitung veraendert. Keine neue Markierung.':'Status vor Weiterleitung geaendert.');
  if(!draft)return;
  const [draftOK,fields,sig]=await Promise.all([
   verifyMbcDraft(page,id,draft),phase2FieldSnapshot(page),mbcSignatureState(page)]);
  need(draftOK,'P2_MBC_FINAL_DRAFT','Entwurf vor Weiterleitung geaendert.');
  const receipt=assessMbcReviewSignature({signature:sig,journal:journal.read(),draftVerified:draftOK,
   serverVerified:fields.gevo.count===1&&fields.gevo.value==='Anfrage Member'});
  need(receipt.ok,'P2_MBC_FINAL_SIGNATURE','INTL01-Signatur-Nachweis fehlt oder widerspricht dem COMARCH-Feld ('+receipt.reason+'). Kein Schritt ausfuehren.');
  log('PASS P2_MBC_FINAL_SIGNATURE_RECEIPT: '+stage+' | '+receipt.method+' | gespeicherter MBC-Text unveraendert | KEIN EMAILVERSAND');
 };
 return finishPhase2Route(page,{ticketId:id,journal,ask,log,route:candidate.route,controls,routeListBefore,
  beforeAuthorize:()=>checkFinalMbc('VOR_FREIGABE'),
  beforeExecute:()=>checkFinalMbc('VOR_AUSFUEHRUNG')});
}
