# MCR DATENBRUECKE 0.8.1-rc.82 – pruefersichere COMARCH-Teilaktualisierung

Ausgangsbasis: vollstaendiges, hashgeprueftes RC81-Komplettpaket. Alle Phase-1-, Kontoauszug-, Entwurf-, PDF-, Speicher- und DB-/DB+-Regeln bleiben unveraendert.

## Beobachteter RC81-Echtlauf (11.11.2026)
- Ticket 87393963: Kontoauszug-PDFs/GEVO/Entwurf gespeichert, Review an mark.baindl `ROUTED_VERIFIED`.
- Ticket 82976755: DC- und PP+-PDFs vom Operator nach erneuter Oeffnung geprueft, GEVO und vierte Beschreibung serverseitig bestaetigt, Kontoauszug-Entwurf durch OK-Dialog behandelt.
- In der Review-Bearbeiterauswahl endete die Browsersteuerung mit `FIXED_QUERY_MISMATCH`, **vor** `REVIEW_VERIFIED`, `EXECUTE_INTENT` und `ROUTED_VERIFIED`. Kein Weiterleitungsnachweis fuer 82976755.

## Aenderung
`lib/phase2-assignee.mjs` behandelt `FIXED_QUERY_MISMATCH`/Fokusverlust bei der **reinen Mark-Suche** als moegliche ICEfaces-Teilaktualisierung, nicht als fertig ausgewaehlten Pruefer:
1. Exakt dieselbe Ticket-ID wird geprueft.
2. Ein bereits serverseitig exakt gebundener Bearbeiter `Baindl Mark (mark.baindl)` darf unveraendert bleiben.
3. Ein eindeutiger, sichtbarer und physisch anklickbarer exakter Vorschlag kann verwendet werden; mehrfach passende Vorschlaege brechen ab.
4. Nur wenn das gleiche eindeutige Eingabefeld leer ist oder den unveraenderten erwarteten Praefix enthaelt, ist **maximal eine** erneute Texteingabe zulaessig.
5. Ist keine eindeutige automatische Auswahl moeglich, soll die Person Mark einmalig manuell im richtigen Feld auswaehlen. Danach prueft der Bot den vollstaendigen COMARCH-Bearbeiterwert sowie den Fokuswechsel. Ein bestaetigter Suchbegriff allein ist KEIN Zuordnungsbeleg.
6. Ohne diese Verifikation darf weder `Schritt ausfuehren` noch eine Direktweiterleitung ausgelöst werden.

Die bereits gespeicherten PDF-Anhaenge, der Entwurf, die Statuszeile und das unveraenderte Write-Ahead-Journal bleiben erhalten. RC82 fuehrt keine erneute PDF-Auswahl, keine neue Entwurfsspeicherung und keinen erneuten Ticket-Speicherklick allein wegen dieses Suchfehlers aus.

## Betrieb
ZIP in separaten Ordner entpacken und ueber Menue 1 RC81 aktualisieren. Danach im **installierten** Projekt Menue 12, Start-Ticket `82976755`. Vorher im gespeicherten COMARCH-Ticket pruefen, dass beide Anhaenge, `Anfrage Member`, Entwurf und vierte Zeile vorhanden sind. Nie manuell `Schritt ausfuehren` klicken, bevor der Bot den Pruefer bestaetigt.

Die RC82-Funktion wurde in Chromium simuliert, aber noch nicht im produktiven COMARCH bestaetigt.
