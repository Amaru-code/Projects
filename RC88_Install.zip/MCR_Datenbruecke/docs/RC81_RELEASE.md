# MCR DATENBRUECKE 0.8.1-rc.81 – Kontoauszug-Anschreiben + Entwurf-OK

Ausgangsbasis: vollstaendiges, hashgeprueftes RC80-Komplettpaket; nur gezielte Erweiterungen an der Phase-2-Kontoauszug-Bearbeitung. Phase-1-Versand, DB-/DB+-Direktweiterleitung und bestehender MBC-Text bleiben unveraendert.

## Nachgewiesener RC80-Echtlauf, 11.11.2026

- 87917040: Reparatur der Statuszeile serverseitig bestaetigt; an mark.baindl weitergeleitet.
- 87813639 und 87810926: direkte Mark-Weiterleitung ohne E-Mail erfolgreich.
- 87393963: zwei PDFs in der COMARCH-Anlagenanzeige bestaetigt, GEVO und Beschreibung im Editor vorbereitet, `DRAFT_SAVE_VERIFIED`, danach `STOP P2_SAVE_DESCRIPTION_CHANGED` vor jedem Ticket-Speicherklick. Kein nachgewiesener Review-Abschluss dieses Tickets.

## Neuer Kontoauszug-Entwurf (KEINE E-Mail)

Bei einer verifizierten Kontoauszug-Anfrage wird im echten COMARCH-Haupttexteditor ein individueller Entwurf vorbereitet:

`Sehr geehrter Herr <Nachname>, anbei erhalten Sie die gewünschten Kontoauszüge. Die Dateien sind mit dem gewohnten Passwort verschlüsselt, Sie erhalten es nochmals in der nächsten Nachricht.`

Die weibliche Form lautet `Sehr geehrte Frau <Nachname>, ...`. Nachname stammt nur aus dem gebundenen COMARCH-Memberprofil; Anrede M/F aus dem aktiven verifizierten Bestandsmapping. Fehlt eine eindeutige Anrede, wird diese anhand der Originalunterlagen abgefragt – keine Geschlechtsableitung aus dem Namen.

Das Schreiben ist **nur ein Entwurf**. Ein Passwort wird nicht erzeugt und keine Passwortnachricht versandt. Die Verschluesselung der PDFs und die spaetere separate Passwortmitteilung muessen im betrieblichen Review geprueft werden; die vorhandene Inhalts-/WWID-Pruefung beweist beides nicht.

Ein bereits vorhandener fremder Entwurf wird nicht stillschweigend ersetzt: zuerst wird der Originalinhalt lokal gesichert und die Ersetzung explizit genehmigt. Der zugrunde liegende, bereits getestete CAS-Editor aus dem MBC-Ablauf bleibt in seiner Logik unveraendert.

## Entwurf-Speichern / COMARCH OK

- Vor genau einem `Entwurf speichern`-Klick werden Ticket-ID, exakter Antworttext, Beschreibung und PDFs geprueft und das Klick-Intent protokolliert.
- Ein einzelner eindeutig zugeordneter COMARCH-Speicher-OK-Dialog wird einmalig per vertrautem Browser-Mausereignis geschlossen; ein JS-Dialog nur bei eindeutigem Entwurfs-/Speicherbezug.
- Unbekannte, doppelte oder als Versand erkennbare Dialoge blockieren die Fortsetzung. Kein automatisches Wiederholen des Entwurfsklicks.
- Nach dem Dialog werden Kontoauszug-Entwurf, GEVO, Anlagen und vierte Beschreibungszeile erneut geprueft. Wenn COMARCH durch ICEfaces exakt zur urspruenglichen Beschreibung zurueckgekehrt ist, wird nur `Bearbeitet not reviewed` erneut in den Editor gesetzt, **ohne** einen weiteren Draft-Speicherklick. Anschliessend erfolgt der bisherige getrennte, einmalige Ticket-Speicherversuch mit Server-Readback.

## Wiederaufnahme des konkret betroffenen Altfalles

RC80 hatte bei 87393963 den `TICKET_SAVE_INTENT` nach `DRAFT_SAVE_VERIFIED` erreicht, jedoch vor dem Klick mit `P2_SAVE_DESCRIPTION_CHANGED` gestoppt. RC81 kann diesen Fall ausschliesslich im bestehenden `TICKET_SAVE_ONLY`-Wiederaufnahmepfad nach neuer Einzelfreigabe `RC81_ENTWURF_87393963` mit dem neuen Schreiben aktualisieren. PDF-Anhaenge werden dabei nicht erneut hochgeladen, alte Journale bleiben erhalten. Der neue Draft-Intent und -Klick stehen gesondert im unveraenderbaren Journal. Nach diesem Klick ist niemals eine automatische zweite Draft-Speicherung erlaubt.

## Betrieb

ZIP separat entpacken, `MCR_Datenbruecke/START.cmd` aus der ZIP, Menue 1 fuer Update von RC80. Danach im installierten Projekt Menue 12 und Startticket `87393963` fuer den kontrollierten Pilot nutzen. Installation veraendert weder `private_data` noch Browserprofil, Config, Journale oder Reports.

Eine erfolgreiche COMARCH-Echtlaufverifikation von RC81 steht noch aus; Browser-/Unit-Tests zeigen nur die lokale Funktionsweise.
