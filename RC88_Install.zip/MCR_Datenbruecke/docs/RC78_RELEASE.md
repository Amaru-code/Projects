# RC78 – beobachteter Kontoauszug-Tippfehler und COMARCH-Bearbeiten-Schaltfläche

Ausgangspunkt: Unverändertes, verifiziertes RC77-Komplettpaket vom 10.11.2026. Die Laufmeldung zum Ticket 87917040 war `MARK_DIRECT`, danach `PASS P2_TICKET_OPEN_BOUND` und `STOP ACTION_NOT_UNIQUE`. Das Stoppsignal belegt keinen Klick, keine Speicherung und keine Weiterleitung in diesem Lauf.

## Ticketzuordnung

Die Originalbeschreibung aus dem zuvor bereitgestellten COMARCH-Screenshot lautet `Möchte Kontoasuzug` (Buchstabenfolge **asuzug**, nicht **auszug**). Dieses konkrete bereits vorliegende Alias wird neben `Möchte Kontoauszug` und `Möchte KA` als Kontoauszug-Fall erkannt. Die Erkennung ist exakt auf diesen vollständigen Antrag begrenzt. Andere, nur ähnliche oder komplexere Anfragen führen weiterhin zum definierten unbekannten Workflow und werden nicht frei interpretiert. Das ursprüngliche Textfeld wird niemals stillschweigend korrigiert. Das Protokoll weist die konkrete Ausnahme als `LEGACY_KONTOASUZUG_TYPO` aus.

DB/DB+ hat weiterhin Vorrang, wenn die erste USC-Zeile DB/DB+ enthält. Ohne bestätigten Phase-1-Status erfolgt keine neue Phase-2-Aktion. Kontoauszüge nutzen weiterhin die bestehenden Generator-/PDF-Prüfungen: Generatorausführung bleibt manuell, PDF-Inhalt muss verifiziert werden, keine neue E-Mail.

## Bearbeiten-Schaltfläche (ACTION_NOT_UNIQUE)

Aus dem bisherigen RC77-Log ist nur ersichtlich, dass der `Bearbeiten`-Knopf nicht eindeutig anklickbar war, nicht ob **null** oder **mehrere** Treffer sichtbar waren. Die Ursache am Live-DOM ist ohne aktuelle DOM-Diagnose nicht belegbar. RC78 ändert deshalb **nicht** die Automatik durch einen geratenen Klick: Es protokolliert bei einem fehlenden/mehrdeutigen Knopf `P2_EDIT_BUTTON_MANUELL: ACTION_NOT_UNIQUE | Treffer=<Zahl>` und bittet den Bediener, genau den `Bearbeiten`-Knopf im aktuellen, bereits anhand seiner Ticket-ID gebundenen Ticket zu öffnen. Nach der Eingabe `BEARBEITEN_GEOEFFNET` überprüft der Bot selbst, dass dasselbe Ticket weiterhin geöffnet und der Member-Eingabebereich tatsächlich bearbeitbar ist. Andernfalls stoppt der Lauf ohne Schreiben und Weiterleitung.

Diese beaufsichtigte Alternative greift nur in den vorhandenen Phase-2-Arbeits-, PDF- und Markerreparaturwegen. Die Phase-1-Bearbeiten-Navigation und alle Versand-/Save-/Weiterleitungsklicks bleiben unverändert. Es wird weder automatisch ein zweiter Bearbeiten-Klick versucht noch eine nicht sichtbare Aktion per JavaScript ausgelöst.

## Einordnung des vorherigen Laufs

- Die Installation `RC76 -> RC77` war erfolgreich.
- `87917040` wurde aufgrund des `Kontoasuzug`-Tippfehlers als unbekannter Wunsch `MARK_DIRECT` klassifiziert.
- Die Ticket-ID war erfolgreich gebunden, aber `Bearbeiten` führte zu `ACTION_NOT_UNIQUE` vor der ersten sichtbaren Schreib-/Weiterleitungsaktion.
- Kein Nachweis für Bearbeitung/Weiterleitung dieses Tickets in dem angezeigten RC77-Lauf.

## Tests und Grenzen

Neue isolierte Unit- und Chromium-Tests prüfen die Alias-Erkennung, konservative Ablehnung anderer Anfragen, unveränderten Originaltext, DB-Vorrang, Phase-1-Sperre sowie null/zwei/einen Bearbeiten-Knopf, menschlichen Abbruch und Ticket-ID-Bindung. Automatische Regressionstests sind keine Bestätigung durch den produktiven COMARCH-Server. Der tatsächliche Button-Zustand und die kontoauszugsbezogenen Aufgaben müssen beim nächsten beaufsichtigten Echtlauf beobachtet werden.

## Update

ZIP separat entpacken, darin `MCR_Datenbruecke/START.cmd` öffnen, Menü 1 ausführen und unveränderte RC77-Bestandsinstallation als Ziel übernehmen. `private_data`, lokale Konfiguration, Browserprofil, Laufjournale und Archiv bleiben erhalten. Anschließend **die installierte** `START.cmd` verwenden. Menü 12 führt echte Phase-2-Aktionen aus; Menü 14 ist nur lesend.
