# MCR DATENBRUECKE 0.8.1-rc.79 – weniger redundante Bestaetigungen, sicherer Speicherpfad

Ausgangsbasis: Original RC78-Vollpaket mit unveraenderten Phase-1- und Phase-2-Fachregeln.
Dieser Patch baut auf dem echten COMARCH-Lauf vom 10.11.2026 zu Ticket 87917040 auf.

## Nachweisgrenze aus dem Echtlauf

- `ACCOUNT_STATEMENT`, gebundene WWID und vorhandene DC+PP+ PDFs: PASS.
- Beide Dateiauswahldialoge ausgefuehrt, Dateinamen im Uploadbereich sichtbar, manuell bestaetigt.
- Entwurf/GEVO/Beschreibung im Editor vorbereitet, aber serverseitige Speicherung des finalen Tickets blieb unbestaetigt (`P2_SAVE_UNVERIFIED`).
- Zwei COMARCH-Schreibrequests und `NETWORK_QUIET` sind **kein Speichernachweis**. Ticket 87917040 darf NICHT erneut automatisch gespeichert, hochgeladen oder weitergeleitet werden.

## RC79 – technisch geaendert

1. Der vorhandene sichere Native-Keyboard-Weg fuer `Ticket speichern` war im Kontoauszug-Pilot faktisch deaktiviert, weil der Aufruf die Ticket-ID nicht uebergab. Der Aufruf bindet jetzt die unveraenderte Ticket-ID und prueft vor jeder einmaligen Aktion erneut Ticket, exakt geforderte Beschreibung, `Anfrage Member`, PDF-Dateihashes und Sichtbarkeit der Anlagen. Erst danach darf der Browser automatisch klicken beziehungsweise ein einziges gebundenes Tastatur-Enter ausloesen. Wenn der Button nicht eindeutig ist oder eine andere Kontrolle den Fokus hat, erfolgt kein ungesicherter Klick.
2. Eine im *gleichen* Menue-12-Lauf bereits bestaetigte Inhalts-/Berechtigungspruefung der beiden PDF-Dokumente wird nach erneuter Ticket-, Member-, WWID- und SHA256-Bindung wiederverwendet. `PHASE2_FREIGABE` wird in diesem exakt gebundenen Fall nicht ein zweites Mal verlangt. Bei einem frueheren Beleg, abweichenden Personen-/PDF-Daten, einem Wiederanlauf oder einem gesonderten Menue-11-Pilot bleibt die Freigabe erforderlich.
3. Nach dem einmaligen Ticket-Speicherversuch wird die neu geladene servergestuetzte Vorgangsliste nur gelesen. RC79 unterscheidet jetzt `ORIGINAL_UNCHANGED`, `UNEXPECTED_DESCRIPTION`, `TICKET_NOT_IN_VISIBLE_LIST`, `QUEUE_NOT_READABLE` und `PERSISTED_EXACT`. Nur `PERSISTED_EXACT` erlaubt Fortsetzung. Ein fehlgeschlagener Readback erzeugt weiter den STOP `P2_SAVE_UNVERIFIED` **ohne zweiten Speicherklick**. Diagnosecodes enthalten keine Kundentexte.

## Welche menschlichen Freigaben erhalten bleiben

- Erstellung fehlender PDFs erfolgt weiterhin manuell im vorhandenen Generator. `PDFS_BEREIT` signalisiert anschliessend die Bereitstellung, oder es wird uebersprungen.
- Einmalige Pruefung von PDF-Inhalt, Person, Zeitraum und Berechtigung vor dem ersten Upload; Dateinamen allein genuegen nicht.
- Wenn COMARCH einen ausgewaehlten Dateinamen nur frei und nicht als eindeutige FilePond-Anhangszeile zeigt (`UNBOUND_NAME`), wird vor dem Speichern eine visuelle Anlagenkontrolle gefordert. Der Bot behauptet keine serverseitige Persistenz allein aufgrund des Dateinamens.
- Bei nicht verifizierbarer Speicherung/Weiterleitung nie automatische Wiederholung; manuelle Freigabe nur fuer sicher nachgewiesene Fallbacks.

## Behandlung des bestehenden Tickets 87917040

Der bisherige RC78-Lauf hat einen Speicherklick im lokalen Journal vermerkt. RC79 liest den Serverzustand bei Wiederaufnahme erneut, wiederholt aber den Klick NICHT automatisch. Wenn die exakte vierte Zeile nicht in der servergestuetzten Vorgangsliste erscheint, bleibt der Fall blockiert. Vor weiteren Schreibaktionen muss der echte gespeicherte Zustand in COMARCH beziehungsweise anhand der lokalen Diagnose verifiziert werden; kein Reset von Journaldaten, keine erneute Standardantwort oder doppelter Upload.

## Installation und QA

ZIP getrennt entpacken, neue `MCR_Datenbruecke\START.cmd` oeffnen, Menue 1. Die alte Installation RC78 muss SHA-gebunden verifiziert sein. Konfiguration, `.runtime`, private Daten, Browserprofil und Rueckwegarchive bleiben am Installationsort. Ein erfolgreicher synthetischer Chromium-Test ist kein COMARCH-Echtlauf.
