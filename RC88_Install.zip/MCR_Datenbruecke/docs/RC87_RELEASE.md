# RC87 – Bedienkomfort und sichere Wiederaufnahme

Basis: vollständiges, unverändertes RC86-Installationspaket. Nur Softwaredateien geändert.

- ENTER als Bestätigung für *eindeutige* positiv formulierte Freigaben, bestehende Langbefehle bleiben erlaubt. Keine leeren Eingaben für Namen, IDs, Anrede-Auswahl, unklare Versandzustände, Rollback oder sonstige gegensätzliche Entscheidungen.
- Bei Phase-2-Bearbeitersuche ohne Vorschlag klickt der Bot das eindeutig gebundene Feld genau einmal erneut, wartet auf das Dropdown und prüft anschließend weiterhin exakt `Baindl Mark (mark.baindl)`.
- Das Phase-2-Fenster kann am Kopf verschoben werden; Browser-Eingaben werden weiterhin gegen Fensterüberlagerung gesichert. Beim browserseitigen Input wird das Fenster vorübergehend klickdurchlässig statt komplett verborgen; bei OS-Fehlern bleibt der bisherige sichere Hide-Fallback erhalten.
- Beim alten DB-Ticket mit `P2_WORK_SERVER_VALUES` gibt es bis zu drei zusätzliche **rein lesende** Prüfungen. Bleibt der Wert unklar und ist ein bereits vorhandenes Arbeitsjournal exakt unverändert (und noch kein Weiterleitungsklick begonnen), wird dieses Ticket begrenzt zurückgestellt und der Rest der Warteschlange darf weiterlaufen. Sonstige oder nach Schreibabsicht unklare Fehler bleiben Stop-Gates.
- Keine veränderte E-Mail-, Identitäts-, PDF- oder Sendelogik; keine automatischen Doppelversuche bei Senden/Speichern/Weiterleiten.

Die nächste COMARCH-Praxisprobe soll zuerst die Erkennung eines bereits gespeicherten DB-Altfalles verifizieren. Ein nicht abschließend nachweisbarer Altfall bleibt in der Ausnahmeliste, nicht als erfolgreich abgeschlossen.
