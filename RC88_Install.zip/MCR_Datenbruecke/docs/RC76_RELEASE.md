# RC76 – Phase 2 anhand der gespeicherten Beschreibung

Basis: unveraendertes hochgeladenes RC75-Komplettpaket. Kein Neuaufbau der Browsersteuerung.

## Verbindliche Reihenfolge

1. Fehlende Phase-1-Statuszeile bzw. leere Beschreibung: `PHASE1_REQUIRED`. Keine Phase-2-Aktion.
2. Bereits bearbeitet / reviewed: keine neue Bearbeitung; eine exakt gebundene, fortsetzbare lokale Phase-2-Aktion kann wie bisher fortgesetzt werden.
3. DB oder DB+ als vollstaendiger Plantyp im USC-Kopf: direkte interne Weiterleitung an Baindl Mark (`mark.baindl`), unabhaengig vom Anfragewortlaut.
4. `Moechte KA` / `Moechte Kontoauszug`: vorhandener DC-/PP+-Kontoauszug-Ablauf, Speichern und Weiterleitung zur Ueberpruefung an Mark.
5. Privater MBC-Login: unveraenderter Antworttext und INTL01-Signatur aus RC75, als Entwurf, dann Review bei Mark.
6. Andere `Moechte ...`-Anfrage: direkte interne Weiterleitung an Mark; keine erfundene Antwort oder neue Fachbearbeitung.

Es wird keine neue E-Mail versendet. Der bisherige Speichern-/Weiterleitungsnachweis bleibt erhalten; ein Klick allein gilt weiterhin nicht als erfolgreicher Abschluss.

## Beschreibungsformat und Altfaelle

Ein zentraler Parser wird fuer Zuordnung, Inventur und PDF-Vorschau verwendet. Mehrere bestehende USC-Zeilen aus dem Mehrzeilen-Mapping bleiben moeglich. Leerraum, CRLF, Gross-/Kleinschreibung und NBSP werden nur fuer die Erkennung normalisiert. Die gespeicherte Originalbeschreibung wird nicht umgeschrieben; wie bisher wird beim Abschluss nur `Bearbeitet not reviewed` angehaengt.

Die bekannten historischen Schreibweisen `Stansardantwort versendet` und `Standartantwort versendet` werden als Phase-1-Arbeitsstatus gelesen und mit `LEGACY_STANDARD_STATUS_SPELLING` ausgewiesen. Andere beliebige Schreibfehler werden nicht geraten. Das ist kein nachtraeglich erzeugter E-Mail-Versandbeleg.

Die im Screenshot gezeigte Altform `DC,IPP,USC 20` wird erkannt. Fuer die PDF-Zuordnung von IPP zu PP+ wird zusaetzlich das gebundene COMARCH-Memberprofil mit dem vorhandenen aktiven Mapping abgeglichen. Ein widerspruechlicher Bestand wird nicht durch geratene Anlagen ersetzt.

Alte offene Phase-1-SEND-Journale bleiben bytegleich erhalten. Sie verhindern nicht mehr allein die interne Phase-2-Arbeit, wenn der gespeicherte Status vorhanden ist. RC76 schliesst diese Journale NICHT nachtraeglich als erfolgreich, aendert keinen alten Hash und erlaubt keinen neuen Versand. Offene FORWARD-Aktionen und unklare Phase-2-Schreibaktionen bleiben wegen moeglicher Doppelweiterleitung gesperrt.

## Erwartete Zuordnung der neun gelieferten Beschreibungen

- 88733447, 88643702: Phase 1 erforderlich.
- 88149870, 88078437, 87813639, 87810926: direkt an Mark.
- 87917040, 87393963, 82976755: Kontoauszug-Ablauf fuer DC und PP+ entsprechend den Planzeilen; bei 82976755 mit dem beschriebenen Altformat-Abgleich.

Diese Ticketnummern dienen ausschliesslich Tests/Dokumentation. Es gibt keine hartcodierten Ticket-Ausnahmen im produktiven Parser.

## PDFs: bestehende Funktion und klare Grenze

RC75 enthielt keine automatische Generatorausfuehrung, sondern die Pruefung vorhandener PDFs und deren Anhaenge-/Review-Ablauf. Die eigentlichen Kontoauszug-Generatorprogramme sind nicht Bestandteil der hochgeladenen Bot-Pakete. RC76 erfindet deshalb keine Generatorargumente oder Berechnungen.

Menue 12 nimmt Kontoauszug-Auftraege jetzt auch ohne vorherigen PDF-Beleg an und fuehrt die bestehende Inhaltspruefung im selben Lauf durch. Das vermeidet den separaten Umweg ueber Menue 9 und 11. Verifizierte WWID bzw. gebundene INTL01-Memberreferenz bestimmen die Dateisuche. Ein generischer MercerID-Wert oder irgendeine vorhandene PDF wird niemals ersatzweise als Personenkennung verwendet.

Fehlen Ausgaben, zeigt der Lauf die bestehenden Generatorpfade und exakten erwarteten Dateien. Die Erzeugung erfolgt weiterhin durch den Bediener im jeweiligen vorhandenen Programm; nach `PDFS_BEREIT` und Inhaltspruefung setzt der Bot mit Anhaengen/Speichern/Review fort. `UEBERSPRINGEN` laesst das Ticket unveraendert, dokumentiert es im Bericht und setzt die anderen Tickets fort. Ein unbekannter oder bereits begonnener Phase-2-Schreibvorgang wird nicht wiederholt.

## Installation und Betrieb

Neue ZIP separat entpacken, neue `MCR_Datenbruecke/START.cmd`, Menue 1, vorhandenen Installationspfad uebernehmen. Danach die installierte `START.cmd` benutzen.

Menue 14 ist nur lesend. Menue 12 ist der echte Phase-2-Lauf. Es werden keine neuen Phase-1-Tickets und kein neuer Phase-1-Pilot benoetigt, um Menue 12 zu benutzen. Die lokale Datenhaltung, Konfiguration, Browserprofile und Journale bleiben beim Update erhalten.

## Testgrenze

Lokale automatische Tests und Chromium-Testseiten sind keine COMARCH-Echtlaufbestaetigung. Produktive Weiterleitungen, echte PDF-Inhalte und Windows-Generatorausfuehrung werden nicht als bereits erfolgreich behauptet.
