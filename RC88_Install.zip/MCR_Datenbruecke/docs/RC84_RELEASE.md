# MCR DATENBRUECKE 0.8.1-rc.84 – Phase-1 Ticket-Navigation

Ursprung: Ein COMARCH-Echtlauf des RC83 Master-Runs stoppte bei `INTL_TICKET_OPEN_BLOCKED` vor dem ersten Ticketklick. Das privacy-gefilterte Diagnose-JSON zeigt keinen Grund innerhalb der Click-Probe.

## Änderung

- Listenanalyse und Ticket-Klick verwenden gleiche Normalisierung der Ticket-ID-Spalte, inklusive sortierter Überschriften.
- Eine eindeutig gebundene Zeile wird maximal dreimal **gelesen**; nur ein sicherer Punkt erhält höchstens einen automatischen Klick.
- Bei verdecktem/mehrdeutigem Treffer darf der Operator genau das gebundene Ticket selbst in `In_Bearbeitung` bzw. `INTL01` öffnen. Der Bot prüft danach unverändert die ausgewählte Ticket-ID, bevor irgendein Bearbeitungs-/Versandschritt ausgeführt werden kann.
- Bei unberechtigtem oder falschem Ticket: STOP, kein Versand. Kein Fallback auf allgemeine/offene Vorgänge oder beliebige andere Tabellen.
- Ausfall-Diagnose gibt für den Klick nur neutrale Ursachencodes/Anzahlen aus, keine Personendaten.

## Erhalten

Bestehender RC83 Master-Run, Empfängerkontrolle, Versandjournal, Phase 2 und RC76-DB-Altfallwiederaufnahme bleiben unverändert. Eine funktionierende Offline-Demo oder Tests ersetzen keinen produktiven COMARCH-Lauf.

## Test

Neue Chromium-Tests: sortierte Spalten, verdeckte Klickfläche mit gebundener manueller Auswahl, abgelehnter blind-automatischer Klick und fremde Ticket-ID. Die komplette Originalsuite wird zusätzlich durchgeführt.
