# MCR DATENBRUECKE 0.8.1-rc.80 – einmalige Status-Reparatur

Basis: unveraendertes RC79-Komplettpaket plus enger Reparaturpfad fuer **Ticket 87917040**.

## Unabhaengig erhobener COMARCH-Zustand (Nutzer, 10.11.2026)

- DC-PDF und PP+-PDF im Ticket gespeichert und nach erneutem Oeffnen vorhanden.
- GEVO `Anfrage Member` gespeichert.
- Vierte Zeile `Bearbeitet not reviewed` fehlt.
- Weiterleitung an Mark nicht nachgewiesen.

## Exakte erlaubte Aktion

1. RC79-Schreibjournal existiert, gebundene Ticket-ID, Beschreibungshash und beide PDF-SHA256 unveraendert.
2. Nur ein frueherer protokollierter Ticket-Speicherklick mit Netzwerkbeobachtung. Keine Weiterleitung, kein altes Review-Intent.
3. Im frischen, wieder geoeffneten COMARCH-Ticket muessten Originalbeschreibung, GEVO und beide gespeicherten Anlagen bestehen. Unklare Anlagen erfordern eine **einmalige** Sichtpruefung.
4. Einmalige Freigabe `REPARATUR_87917040`. Vor Bearbeitung wird `RC80_MARKER_REPAIR_OPERATOR_AUTHORIZED` im bestehenden Journal angehaengt.
5. Der Bot ergaenzt ausschliesslich `Bearbeitet not reviewed`, prueft vor dem Speicherversuch erneut Ticket, GEVO, Dateihashes, Anlagen und exakte Beschreibung.
6. Vor **genau einem** neuen Speicherklick wird `RC80_MARKER_REPAIR_CLICK_INTENT` protokolliert. Netzwerkbeobachtung und frisch neu geladener Serverstatus werden getrennt gespeichert. Kein Upload, keine E-Mail, kein Entwurf-Speichern. Erst bei erfolgreich nachgewiesener vierter Zeile und GEVO wird `TICKET_SAVE_VERIFIED` dokumentiert und der bestehende Review-Ablauf benutzt.
7. Bei Unterbrechung nach dem zweiten Klick: naechster Lauf darf **nur lesen und abgleichen**, niemals den Klick erneut ausloesen. Bei fehlender Markierung bleibt der Fall fuer weitere manuelle Untersuchung blockiert. Kein Journal-Reset.

Der RC80-Reparaturpfad gilt **nur fuer 87917040**, nicht pauschal fuer andere Tickets. Er ersetzt keine COMARCH-Echtlaufverifikation; fiktive und Unit-Tests pruefen nur die Softwarelogik.

## Installation und naechster Test

ZIP separat entpacken, neue `MCR_Datenbruecke\START.cmd`, Menue 1. Danach installierte START.cmd -> Menue 12 -> Start-Ticket `87917040` -> START. Bei klaren, gespeicherten PDFs / GEVO und unveraenderter Beschreibung wird genau eine Reparaturfreigabe angeboten. Keine Eingriffe in `private_data`, `.runtime`, Browserprofil, Laufjournale oder Bestandsarchiv.
