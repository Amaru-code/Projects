# RC74 – DB+-Altfälle mit individueller Anfragezeile sicher abgleichen

## Reproduzierter Fehler in RC73

Die Intel-Inventur hatte mehrere DB-/DB+-Tickets als `SAVED_DESCRIPTION_NOT_EXACT` verworfen, obwohl die erste Beschreibungzeile USC/DB+, die zweite den Versandstatus und die dritte das eigentliche Anliegen zeigte. Der Code erlaubte als dritte Zeile nur einen vordefinierten MBC- oder Kontoauszugswortlaut – auch für DB-Direktfälle, bei denen laut Fachregel der Inhalt der dritten Zeile keine Voraussetzung ist.

## RC74

RC74 lässt für DB-/DB+-Fälle **eine** individuelle dritte Anliegenzeile zu, die mit `Möchte ` beginnt. Die ursprünglichen USC/Planzeilen und der Status müssen weiterhin exakt zur unveränderlichen SHA-256-Bindung des alten SEND_INTENT passen. Die gesamte zusätzliche Beschreibung muss im eigenen COMARCH-Ticket beim erneuten Öffnen mit dem Listenstand übereinstimmen. Vor einer journaltechnischen Freigabe müssen zudem genau eine geeignete ausgehende Standardantwort mit eigener Dokument-ID, richtiger Absender/Empfänger sowie der gebundene Gesprächs-/Ticketbetreff im Verlauf vorhanden sein. Eine solche Freigabe sendet **keine neue E-Mail**, speichert **keinen schon gespeicherten Status** und berührt keine anderen offenen Versandjournale.

Mit fehlendem Versandstatus bleibt ein expliziter, einmaliger, journaling-gesicherter Speicherweg erforderlich. Mit fremder/zusätzlicher Notiz, mehreren Anliegenzeilen, mehreren ausgehenden Standardantworten, verändertem USC-Hash, anderer Absenderadresse oder unklarem Serverzustand wird weiterhin gesperrt. Kontoauszüge und MBC behalten ihre spezifischen Anfrage- und Nachweispflichten; neue Antwortvorlagen werden nicht eingeführt.

Neu in Menü 14: Für blockierte Tickets erscheint eine separate rein **strukturelle**, datensparsame Textdiagnose (`P2_TEXTSTRUKTUR`): Anzahl physischer Zeilen, USC-/Statuszeilen und Formatabweichungen. Persönliche Anfrage- und Nachrichtentexte werden nicht in die Konsolenausgabe oder den Bestandsbericht kopiert.

## Bedienung

1. ZIP separat entpacken, START.cmd > Menü 1, vorhandene unveränderte RC73-Installation aktualisieren. `.runtime`, `private_data`, Browserprofil, Config, Mapping und Softwarearchiv bleiben erhalten.
2. In der **installierten** Version Menü 14 zur reinen Intel-Inventur (optional), danach Menü 12 ohne Startticket für den bestehenden Phase-2-Lauf. So ist kein erneuter Phase-1-Versand notwendig.
3. Jeder alte SEND_INTENT wird erst durch einen tatsächlichen nachweisbaren Ausgang und die aktuelle Serverbeschreibung geklärt. Anschließend greift die bisherige DB-Weiterleitung an Mark. Unbelegte Fälle verbleiben in der Sperrliste.

## Verbleibende Grenzen

`ORIGINAL_LEDGER_SHA_MISMATCH` ist keine Format-Lappalie und wird **nicht automatisch entsperrt**. `STANDARD_MARKER_UNCERTAIN` und `USC_MISSING` bleiben ohne zusätzlichen unabhängigen Nachweis ebenfalls gesperrt. Die Diagnose erfasst die sichtbare eigene Intel-Tabellenseite, nicht alle Seiten der Warteschlange. Browser- und Integrationstests mit nachgebildeten COMARCH-Seiten sind kein produktiver Windows-/COMARCH-Nachweis.
