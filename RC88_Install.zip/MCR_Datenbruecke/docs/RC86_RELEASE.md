# RC86 – Einfaches Bedienmenü / durchgängige Phase 1 / COMARCH Member-Filter

Basis ist RC85, mit unverändert übernommenen produktiven Versand-, Speicher-, Journal- und Phase-2-Abläufen. Eine produktive COMARCH-Abnahme von RC86 liegt noch nicht vor.

## Menü (die bisherigen Funktionen bleiben intern erhalten)

- 1: Schnellinstallation/Update
- 2: Bestandsdaten/Mapping aktualisieren (nur wenn notwendig; nicht automatisch)
- 3: Phase 1 – alle geeigneten Tickets aus den erlaubten Listen durchlaufen
- 4: Phase 2 – bearbeiten und weiterleiten
- 5: Master-Run – Phase 1, dann Phase 2
- 0: Beenden

Die früheren Menüpunkte 3 + 4 sind in Phase 1 vereinigt. Der Phase-1-Lauf verwendet die bereits vorhandene Master-Pilot-/Batch-Orchestrierung, ohne Phase 2 aufzurufen. Das Ergebnis ist nicht auf 1+5 Tickets begrenzt. Aus Sicherheitsgründen bleiben **100 Tickets pro Batch, höchstens 10 Batches je Start**; ein weiterer Start ist möglich. Ein real versendeter und gespeicherter Pilot bleibt für Batches Pflicht; ein bloß weitergeleitetes Ticket erlaubt nur den nächsten Einzelpilot. Der Master-Run bleibt jederzeit verfügbar und durchläuft Phase 1, danach Phase 2, soweit freigegeben.

Selbsttest und Browserdemo sind über `node tools/cli.mjs --selftest` bzw. `--demo` erreichbar, Status über `--status`, Nachbearbeitung über `--review`, Software-Rückweg über `--rollback` (nur bei gezieltem Bedarf). Nichts davon wird beim normalen Ticketlauf automatisch gestartet.

## Quellen der Personennamen

- Original-E-Mail und COMARCH-Mailhistorie: Absendername, Signatur, beschriftete Namen, Betreff/Kontext, Alias nur als schwacher Suchhinweis
- COMARCH-Ticket: sichtbare Vorname-/Nachname-Felder als zusätzliche rein lesende Fallback-Quelle
- Ausgewähltes COMARCH-Memberprofil: verifizierte ID, Vorname und Nachname
- Manuelle Ergänzung/Korrektur bei Uneindeutigkeit
- `private_data`: Bestandsmapping über numerische Kennung für USC/DC/PP+/DB+, **keine primäre verifizierte Namensquelle**

Nach dem Setzen einer COMARCH-Member-Suchanfrage ohne Vorschlag führt RC86 einmal einen weiteren, sichtbaren, hit-getesteten Klick auf **dasselbe** Member-Eingabefeld aus und wartet erneut. Das ist kein automatischer Member-Auswahlklick und kein Identitätsnachweis. Bei weiterhin unklarem Suchergebnis verbleibt die manuelle Auswahl beziehungsweise die bisherige kontrollierte Weiterleitung ohne E-Mail.

## Bestätigung mit ENTER

Bei einem tatsächlichen Namenskonflikt bleibt die Prüfung von MercerID, Vorname und Nachname sowie Original-Ticket und Berechtigung unverändert erforderlich. **Nur die letzte Bestätigung** kann nach dieser Prüfung mit leerem ENTER erfolgen. `ABBRUCH` und falsche Eingaben werden nicht akzeptiert. Die älteren expliziten Eingaben `ZUORDNUNG GEPRUEFT`/`ZUORDNUNG_GEPRUEFT` funktionieren weiterhin.

## Sicherheit

- Keine neue Nachricht ohne gültige Versandprüfung und erneute Empfänger-/Editor-Bindung
- Kein doppelter Versandklick; bestehende Journale und Sperren bleiben erhalten
- Nur sichere eigene Ticketlisten, ausgewählter COMARCH-Member bleibt Pflicht
- User-Textänderungen aus RC85 bleiben zulässig mit einzeln bestätigtem Versand
- Phase-2-Fachregeln und PDF-Prüfungen unverändert
- Mapping- und Rückweg-Code bleiben im Paket
