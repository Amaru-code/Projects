# MCR DATENBRUECKE 0.8.1-rc.85 – Benutzerbearbeitete Phase-1-Antworten

## Anlass

RC84: Ticket 89112070 wurde vor dem Versand mit `REPLY_CHANGED` gestoppt, nachdem der Operator den Standardantwort-Text manuell leicht angepasst hatte. Bis dahin gab es keinen Versandklick fuer dieses Ticket.

## Neuer Ablauf

- Bei unveraenderter Antwort bleibt die bestehende Versand- und Speicherlogik unveraendert.
- Wenn das sichtbare COMARCH-Haupttextfeld vom Standardentwurf abweicht, wird es **nicht** zurueckgesetzt. Stattdessen kann der Operator den Text weiter bearbeiten oder fuer genau das Ticket nach Sichtpruefung freigeben (`TEXT_<Ticket-ID>_FREIGEBEN`). Auch im AUTO-Modus ist diese Freigabe verpflichtend.
- Aendert sich der Inhalt waehrend der Freigabe, wird die alte Freigabe verworfen und der aktuelle Text erneut zur Pruefung angezeigt. Eine unerkannte Eingabe fuehrt zu erneuter Abfrage statt sofortigem Laufabbruch.
- Unmittelbar vor dem EINEN irreversiblen Versandklick werden Ticket-ID, originaler Empfaenger, exakt freigegebener Text und zusaetzliche Beschreibung nochmals gebunden geprueft. Bei Abweichung: STOP OHNE VERSAND.
- Nach dem Versand wird bei bearbeiteter Antwort eine neue ausgehende COMARCH-Nachricht nur anerkannt, wenn sie in demselben Ticket an den Originalabsender ging und inhaltlich dem freigegebenen Text entspricht. Wenn die Anzeige nicht exakt pruefbar ist, gilt der bisherige manuelle Nachweis und KEIN zweiter Versandklick.
- Die Freigabe dokumentiert ausschliesslich einen Hash des freigegebenen Textes im lokalen Versandjournal, niemals den eigentlichen Inhalt. Bestehende Identitaets-, USC-, Signatur-, Nachweis-, Speicher- und Duplex-Sperren bleiben bestehen.

## Bereits geoeffnete Tickets

Ticket 89112070 wurde in RC84 laut Konsolenprotokoll nicht gesendet. Vor einer Wiederaufnahme sind Original-Nachrichtenverlauf, Bearbeiter und gegebenenfalls lokale Journale erneut zu pruefen. Der Bot darf niemals aus einem frueheren Abbruch einen Versand ableiten.

## Umfang der Tests

Neue reine Tests fuer manuelle Aenderung, erneute Aenderung waehrend Freigabe, falsche Empfaenger, Ablehnung, nicht exakte Ausgangsnachricht und ohne Freigabe fehlende Beweiskraft. Produktiver COMARCH-Nachweis steht aus.
