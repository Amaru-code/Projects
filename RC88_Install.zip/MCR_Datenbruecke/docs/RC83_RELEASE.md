# MCR DATENBRUECKE 0.8.1-rc.83 – Master-Run-Fortsetzung

Basis: vollstaendiges, unveraendertes RC82-Komplettpaket. Fachlogik, PDFs, E-Mail-Texte, COMARCH-Member-Regeln und Versand-Nachweispruefungen unveraendert.

## Grund fuer den bisherigen Stopp
Menue 3 und Menue 13 endeten nach einem echten Einzelpilot mit gepruefter **interner Weiterleitung OHNE E-Mail**, obwohl weitere geeignete Tickets vorhanden sein konnten. Das alte `PILOT_ROUTED_WITHOUT_EMAIL` war absichtlich **keine** gueltige E-Mail-Pilotfreigabe, aber das Programm erfasste es nicht als Ketten-Fortsetzung.

## RC83
1. Jede verifizierte interne Weiterleitung wird als eigenes abgeschlossenes Ticket protokolliert. Ein **einzeln begrenzter** neuer Pilot darf folgen; er benoetigt eine frische, SHA- und Mapping-gebundene `complete-forward-pilot-pass.json` und eine neue Bot-Prozesssperre. Keine pauschale Versandfreigabe.
2. Menue 3 kann unter der urspruenglichen Lauf-Freigabe **maximal sechs** erfolgreich bearbeitete Tickets nacheinander abschliessen (reine Weiterleitungen + ein echter Versandpilot + gegebenenfalls verbleibende Folgetickets). Erst ein echter Versand-UND-Speicher-Pilot schaltet die Mehrticket-Phase frei.
3. Menue 13 setzt nach jeder verifizierten Weiterleitung den naechsten Einzelpilot fort, bis ein echter E-Mail-Pilot vorliegt oder die beiden sichtbaren Phase-1-Listen keinen neuen geeigneten Fall mehr zeigen. Der Master-Batch ist ausdruecklich an `MASTER_START`, ein exaktes Paket/Mapping und den verifizierten Versandpilot gebunden. Die bisherige 10x100-Batch-Grenze bleibt bestehen.
4. Phase 2 startet nach der Phase-1-Pruefung innerhalb des freigegebenen Masters ohne nochmalige allgemeine START-Bestaetigung, behaelt aber PDF-Inhalts- und Identitaetsfreigaben, sichere COMARCH-Server-Readbacks und keine E-Mail-Aktion bei Phase 2.
5. Der alte DB-Fall (z.B. 88078437) kann auf dem kontrollierten RC77-Wiederaufnahmepfad weitergehen, **nur** falls das unveraenderte RC76-Journal eine reine Mark-Weiterleitung dokumentiert, die urspruengliche Beschreibung noch exakt auf dem Server steht und **keine Ausfuehrung** begonnen wurde. Bei Abweichung STOP, keine Journalmanipulation.

## Wichtige Grenzen
- **Kein produktiver COMARCH-Echtlauf** in der Entwicklungsumgebung; alle automatisierten Tests sind Simulationen/Offline-Pruefungen.
- Ein bereits laufender, ungepruefter Versand, ein mehrdeutiger Member oder ein unsicherer Bearbeiter darf den Master weiterhin unterbrechen oder das betroffene Ticket zur manuellen Pruefung offenlassen. `MASTER_COMPLETE_VISIBLE_SCOPE` bezieht sich ausschliesslich auf die belegten sichtbaren Seiten, nicht auf das gesamte COMARCH-System.
- Phase 2 erzeugt keine PDFs automatisch; der Operator nutzt weiterhin die vorhandenen Generatoren und bestaetigt erforderliche PDF-Inhalte.
- Der Bot schickt keine zweite E-Mail an ein bereits im Versandjournal dokumentiertes Ticket.

## Betrieb
ZIP separat entpacken, START.cmd aus dem Paket, Menue 1, danach nur aus dem installierten Ordner starten. Menue 13 und `MASTER_START` fuer den kombinierten Lauf; der erste Phase-1-Pilot benoetigt START. Danach werden verifizierte reine Weiterleitungen ohne erneutes generisches Startsignal verkettet. Bei einem STOP keine Zweitaktion; Bericht und Journale aufbewahren.
