# MCR DATENBRUECKE 0.8.1-rc.88

Basis: vollständige Originalsoftware RC87. Enthält keine Bestandsdaten.

## Änderungen

- Phase-1-Standardantwort wählt DE/EN anhand des aktuellen originalen Eingangs-Mailtexts (nicht anhand Namen, UI, Signatur oder früherer Korrespondenz); unklare Sprache verlangt D/E und kann nicht per ENTER geraten werden.
- DE-Standardtext bleibt unverändert, EN-Standardtext ist die vom Operator übergebene Fassung mit Dear [verifizierter Vor- und Nachname]. Bereits vorhandene manuelle Antwortkorrektur und ticket-/empfängergebundene Freigabe bleiben aktiv.
- Erkennung einer gesendeten Standardantwort in den Nachrichtenprotokollen erkennt jetzt beide Sprachfassungen. Nur genau ein neuer, gebundener ausgehender Verlauf kann den Versand bestätigen; keine zweite Versandaktion bei unklarem Nachweis.
- Startfragen in Phase 1, Phase 2 und MASTER werden verständlich mit „ENTER = starten“ angezeigt. ENTER erteilt keinerlei Freigabe bei unklaren Identitäten oder widersprüchlichen Voraktionen.
- Automatischer Lesezugriff auf Original-MSG aktiviert nicht mehr den Browser-Downloadmodus; ein PDF- oder Nicht-MSG-Inhalt wird vor einer Interpretation abgewiesen. Nur ein ausdrücklich erforderlicher manueller Original-MSG-Download kann den Downloadmodus aktivieren.
- Phase-2-Altfall 88078437: bestehender gesicherter Stopp und kontrollierte Rückstellung erhalten. 89112070 bleibt bei nicht unterstützter Anfrage bis zur manuellen fachlichen Klärung offen.

## Grenzen

- Keine echten COMARCH-Zugänge im Testsystem; Produktivverhalten von Sprache/Versand vor Rollout mit beaufsichtigtem Pilot bestätigen.
- Der frühere vermeintliche PDF-Download lässt sich aus dem vom Operator übermittelten Textlog nicht beweisen. Die neue Sperre betrifft nur einen belegten potenziellen Download-Freigabepfad des Bots.
- Unklare gespeicherte GEVO-/Beschreibungswerte und unsichere irreversible Aktionen bleiben gesperrt. Nicht als fehlerfreier Gesamtabschluss behaupten.
