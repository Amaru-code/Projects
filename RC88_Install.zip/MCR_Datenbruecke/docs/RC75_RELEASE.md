# MCR DATENBRUECKE 0.8.1-rc.75 – gezielter Phase-1-Namensfallback

Basis: unveraendertes, vom Nutzer hochgeladenes Komplettpaket 0.8.1-rc.74. RC71, RC72 und RC73 dienten ausschliesslich als Version-/Historienvergleich.

## Zwei eng begrenzte Aenderungen

1. **Namenshinweis aus dem aktuell geoeffneten COMARCH-Ticket:** Erst wenn alle bestehenden Namensquellen und die Original-MSG keinen Namen ergeben haetten, werden die sichtbaren Labels `mainForm:j_id5899` (Vorname) und `mainForm:j_id5919` (Nachname) aus `mainForm` ausgelesen. Beide Felder muessen genau einmal vorhanden, sichtbar und plausibel sein. Vor und nach dieser Lesepruefung muss die bereits vorhandene `detailTicketId` exakt dieselbe aktuelle Ticketnummer ergeben. Die Daten sind nur ein Suchhinweis. Die bisherige COMARCH-Member-Suche, Profil-/MercerID-Gegenpruefung und gegebenenfalls manuelle Identitaetsentscheidung bleiben Pflicht. Bei fehlenden/veraenderten Labels unveraendertes `NAME_MANUAL_GATE`. Die JSF-ID-Werte sind bewusst nicht geraten oder dynamisch auf aehnlich aussehende Labels erweitert worden.
2. **Eindeutige manuelle Namenskonflikt-Freigabe:** Nach erneuter Eingabe der verifizierten MercerID und von Vor- und Nachnamen wird entweder `ZUORDNUNG GEPRUEFT` oder `ZUORDNUNG_GEPRUEFT` akzeptiert (Gross-/Kleinschreibung egal). `JA`, freie Texte oder eine unvollstaendige Pruefung werden weiterhin abgewiesen. Diese Loesung laesst die Member-/Berechtigungsbarriere bestehen.

## Unveraendert

Alle Produktivaktionen, COMARCH-Selektoren fuer Send/Save/Weiterleitung, Versandjournal, Anti-Doppelversand, Zwei-Spalten-Status, USC/Plan-Abgleich, Phase-2-Logik, Hauptmenue sowie bestehende Test-/Demo-Szenarien sind auf RC74-Basis belassen. Hinzugekommen ist ausschliesslich ein neues fiktives optionales Test-Szenario fuer den Namensfallback.

## Update

Die ZIP separat und vollstaendig entpacken, **die START.cmd aus der neuen ZIP** oeffnen und **Menue 1** aufrufen. Als Ziel die bestehende `MCR_Datenbruecke`-Installation (in der Regel durch ENTER) waehlen. Eingebaute Pruefung akzeptiert nur eine unveraenderte SHA-256-gepruefte RC74-Vorgaengerversion oder die bereits gelisteten unveraenderten aelteren Versionen. Bestandsdaten (`private_data`, lokale `config`), `.runtime`, Bot-Browserprofil und alte Sicherungen bleiben am Ort. Danach nur die START.cmd der installierten Software benutzen.

Wichtig: Nach einer neuen Code-Version koennen an die alte Paket-SHA gebundene Pilotfreigaben zu Recht ungueltig sein. Einen neuen verifizierten Pilotlauf verwenden, bevor der regulaere Versand laeuft. Kein echter COMARCH-Versand wurde bei der Paketherstellung ausgeloest.

## Tests

`node --test tests/rc75-ticket-label-name.test.mjs` testet beide Namen, fehlende/geaenderte/verdeckte Labels, Ticketwechsel, Member-Konflikt und die geforderte Freigabeschreibweise. Fuer den vollstaendigen bisherigen Testkatalog: Hauptmenue 6; fuer die bisherigen vier fiktiven Browserablaeufe: Hauptmenue 2. Ein optionaler einmaliger Offline-End-to-End-Test laeuft ueber `MCR_DEMO_SCENARIO=rc75-label-fallback` mit dem vorhandenen `src/local-bot-full-run.mjs --demo --headless --close-browser`; dieses Szenario ist kein Echtversand.
