# RC77 – Phase-2-Vermerk nur bei tatsächlich vorbereiteter Bearbeitung

Ausgangsbasis: vollständig hochgeladenes RC76-Komplettpaket. Kein Ersatz der bestehenden COMARCH-Automation, Phase-1-Verarbeitung, Kontoauszug-Anhänge oder MBC-Draft-Verfahren.

## Entscheidung anhand der zusätzlichen Beschreibung

- `DB` oder `DB+` in der USC-Planzeile: `DB_DIRECT`; intern an Baindl Mark weiterleiten. **Kein** `Bearbeitet not reviewed`, denn der Bot bereitet keine Fachbearbeitung vor.
- Unbekannte `Möchte …`-Anfrage: `MARK_DIRECT`; intern an Mark weiterleiten. **Kein** Bearbeitungsvermerk und kein erfundener Antworttext.
- `Möchte KA` oder `Möchte Kontoauszug`: bestehende Kontoauszug-Vorbereitung mit echten, überprüften DC-/PP+-PDFs; die vorhandene Markierung `Bearbeitet not reviewed` bleibt für diesen tatsächlich vorbereiteten Fall erhalten.
- `Möchte Log-in MBC mit privater E-Mail`: bestehender MBC-Antwortentwurf mit INTL01-Signatur und Review; `Bearbeitet not reviewed` bleibt erhalten, wenn die Bearbeitung vorbereitet ist.
- Fehlende Phase-1-Bearbeitung: weiterhin keine Phase-2-Aktion.

Für Direktweiterleitungen bleibt die ursprüngliche Beschreibung **exakt unverändert** (auch Whitespaces und alte Schreibweisen). `Anfrage Member` wird weiterhin als GEVO im bestehenden COMARCH-Pfad vor der Weiterleitung gebunden und gespeichert; sie wird nicht als bearbeiteter Kundenwunsch bezeichnet. Der finale Beschreibungsschutz prüft für DIRECT nun die ursprüngliche Beschreibung statt eines unnötigen Statussuffixes. Bei Widerspruch wird ohne Weiterleitung abgebrochen; ein reines visuelles Neurendern gilt nicht als Versand- oder Speicherbeleg.

## Bereits angefangener RC76-Direktfall (88078437)

RC76 hatte für direkte DB-Fälle teilweise schon `Bearbeitet not reviewed` **serverseitig gespeichert**, obwohl noch keine Weiterleitung ausgeführt wurde. RC77 erkennt diesen Altfall ausschließlich anhand des vorhandenen exakt zum Ticket passenden lokalen Work-Journals und des **exakt angehängten** Textsuffixes. Nur solange kein `EXECUTE_INTENT` / `ROUTED_VERIFIED` existiert, darf er den falsch hinzugefügten Suffix nach einer konkreten Bedienerfreigabe entfernen.

Vorgehen: originalen Tickettext prüfen -> `MARKER_ENTFERNEN_<Ticket-ID>` bestätigen -> gebundene Beschreibung einmal korrigieren -> genau ein kontrollierter Ticket-Speicherklick -> frischer COMARCH-Server-Readback -> erst dann bestehende Weiterleitung an Mark mit separater Freigabe. Ist bereits ein Korrektur-Speicherklick ausgelöst worden, ist ein weiterer Klick gesperrt. Bei einem nachweislich vor jedem Speicherklick abgebrochenen Fokus-/Eingabeversuch ist maximal ein erneuter, ausdrücklich freigegebener Versuch nach frischem Server-Readback zulässig. Die alten Journale werden nicht gelöscht oder still umgeschrieben; Korrekturschritte werden als neue Ereignisse dokumentiert. Keine E-Mail.

Ein **bereits weitergeleitetes** Ticket (z. B. 88149870 aus dem RC76-Protokoll) wird niemals nachträglich vom Bot neu geöffnet, geändert oder doppelt weitergeleitet. Eine etwaige manuelle Textkorrektur am bereits übertragenen Ticket ist Sache des zuständigen Bearbeiters.

## Vorherige RC76-Meldung

`STOP P2_WORK_FINAL_MARKER` wurde bei Ticket 88078437 ausgelöst, nachdem die nachträgliche Bearbeiterauswahl den angehängten Text im aktuellen Browserformular nicht mehr bestätigt hat. Es war **kein** `EXECUTE_INTENT` für dieses Ticket protokolliert. Die reine Zuweisungsauswahl ist kein Nachweis einer Weiterleitung. RC77 entfernt für direkte Fälle die Ursache des unnötigen Marker-Abgleichs, behält aber die Kontrolle des Originaltexts bei.

## Installation

ZIP separat entpacken; die enthaltene `MCR_Datenbruecke/START.cmd` mit Menüpunkt 1 ausführen. Unterstützt die vollständige, unveränderte RC76-Installation und die unveränderten früheren, im Code freigegebenen Versionen; lokale Bestandsdaten, Browserprofil, Konfiguration, historische Journale und Rückweg bleiben erhalten.

Menü 14 liest ausschließlich; Menü 12 führt echte interne Weiterleitungen aus. Lokal bestandene Tests ersetzen keinen COMARCH-Produktionsnachweis. Die Kontoauszuggeneratoren sind weiterhin nicht Teil des Pakets und werden nicht automatisch bedient.
