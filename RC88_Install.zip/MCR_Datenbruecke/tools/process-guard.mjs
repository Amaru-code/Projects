/** RC46: ordinary checks are read-only; only migration may stop owned PIDs. */
import path from 'node:path';import {fileURLToPath} from 'node:url';import {execFileSync} from 'node:child_process';
import {requireThat as need,McrError} from '../lib/core.mjs';
import {resolveConfig} from '../lib/config.mjs';
import {classifyWindowsProcesses,processProof,sameProcessIdentity} from './process-policy.mjs';
const script=name=>fileURLToPath(new URL('./'+name,import.meta.url));
const powershell=()=>path.join(process.env.SystemRoot||'C:\\Windows','System32/WindowsPowerShell/v1.0/powershell.exe');
function runPowerShell(name,input=null,timeout=8000){
 let raw;
 try{raw=execFileSync(powershell(),['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',script(name)],{
  ...(input===null?{}:{input:JSON.stringify(input)}),encoding:'utf8',timeout,windowsHide:true,maxBuffer:16*1024*1024});}
 catch{throw new McrError('PROCESS_CHECK_UNAVAILABLE','Windows-Prozesspruefung/-beendigung nicht verfuegbar. Keine Softwaredatei wurde dadurch freigegeben.');}
 try{return JSON.parse(raw.trim().replace(/^\uFEFF/,''));}
 catch{throw new McrError('PROCESS_CHECK_UNAVAILABLE','Windows-Prozesspruefung liefert keinen vollstaendigen JSON-Nachweis.');}
}
export function readWindowsProcessSnapshot({timeout=8000}={}){return runPowerShell('process-guard.ps1',null,timeout);}
function optionsFor(root,{profileDirectory,excludePid=process.pid,extraProtectedPids=[]}={}){
 return {root,profileDirectory:profileDirectory??resolveConfig(root).profileDirectory,excludePid,extraProtectedPids};
}
function details(proof){return [...proof.targetProcesses,...proof.unknownProcesses].map(p=>'PID '+p.pid+' '+p.name+' ('+p.reason+')').join('; ');}
function checkIdle(proof){
 if(proof.blockedCount||proof.unknownCount)throw Object.assign(new McrError('MCR_PROCESSES_ACTIVE',
  'Zur Installation gehoerende Prozesse: '+details(proof)+'. Fuer ein Softwareupdate Menue 1 des neuen Pakets verwenden.'),{processProof:proof});
 return proof;
}
export function windowsIdle(root,{platform=process.platform,readSnapshot=readWindowsProcessSnapshot,...options}={}){
 need(platform==='win32','WINDOWS_REQUIRED','Echte Einrichtung/Echtlauf nur auf Windows.');
 return checkIdle(processProof(classifyWindowsProcesses(readSnapshot(),optionsFor(root,options))));
}
/** Caller first reserves migration priority. Every batch is classified from
 * a new complete snapshot; stale PIDs are never silently retried. */
export function windowsStopForMigration(root,{log=()=>{},platform=process.platform,readSnapshot=readWindowsProcessSnapshot,
 stopProcesses=(plan,{timeout})=>runPowerShell('process-stop.ps1',plan,timeout),...options}={}){
 need(platform==='win32','WINDOWS_REQUIRED','Automatisches Beenden fuer Migration nur auf Windows.');
 const cfg={...optionsFor(root,options),blockProtectedTargetAncestors:true},stopped=[],knownTargets=new Map();
 const deadline=Date.now()+30000;
 const remaining=limit=>{
  const available=deadline-Date.now();
  need(available>0,'MIGRATION_PROCESS_TIMEOUT','Prozessbeendigung nach 30 Sekunden ohne sicheren Leerlauf abgebrochen. Software noch nicht ersetzt.');
  return Math.min(limit,available);
 };
 const collect=()=>{
  const snapshot=readSnapshot({timeout:remaining(8000)}),classified=classifyWindowsProcesses(snapshot,cfg);
  // An exited parent does not make an identical surviving worker unrelated.
  // Keep its original ownership until that exact process instance is gone.
  for(const expected of knownTargets.values()){
   const current=snapshot.processes.find(p=>p.pid===expected.pid);
   if(!current||!sameProcessIdentity(expected,current)||classified.owned.some(p=>p.pid===current.pid))continue;
   need(!classified.protectedPids.includes(current.pid),'MIGRATION_PROCESS_PROTECTED','Ehemals zugeordneter Prozess ist jetzt Teil des Installers. Keine Beendigung.');
   classified.unknown=classified.unknown.filter(p=>p.pid!==current.pid);
   classified.owned.push({...expected,reason:'PREVIOUSLY_VERIFIED_OWNED_INSTANCE'});
   const item=classified.inspectedProcesses.find(p=>p.pid===current.pid);if(item){item.relation='OWNED';item.reason='PREVIOUSLY_VERIFIED_OWNED_INSTANCE';}
  }
  return classified;
 };
 for(let round=0;round<2;round++){
  const classified=collect(),proof=processProof(classified);
  if(proof.unknownCount)throw Object.assign(new McrError('MIGRATION_PROCESS_UNCLEAR',
   'Target-Prozess nicht sicher zuordenbar: '+proof.unknownProcesses.map(p=>'PID '+p.pid+' '+p.name+' ('+p.reason+')').join('; ')+'. Keine fremden Prozesse beendet.'),{processProof:proof});
  if(!proof.blockedCount){
   log('PASS MIGRATION_PROCESSES_IDLE: '+stopped.filter(p=>p.status==='STOPPED'||p.status==='CLOSED').length+' zugehoerige Prozesse beendet; '+proof.ignoredUnrelatedUnreadableCount+' fremde unlesbare Prozesse ohne MCR-Zuordnung ignoriert.');
   return {...proof,stoppedProcesses:stopped};
  }
  for(const p of classified.owned)log('MIGRATION_STOP_OWNED: PID '+p.pid+' '+p.name+' | '+p.reason);
  for(const p of classified.owned)knownTargets.set(p.pid+'|'+p.createdAt,p);
  const result=stopProcesses({schema:'MCR_MIGRATION_PROCESS_STOP_V1',callerPid:cfg.excludePid,
   protectedPids:classified.protectedPids,targets:classified.owned.map(({pid,parentPid,name,createdAt,executablePath,commandLine,reason})=>
    ({pid,parentPid,name,createdAt,executablePath,commandLine,reason}))},{timeout:remaining(16000)});
  need(result?.schema==='MCR_MIGRATION_PROCESS_STOP_RESULT_V1'&&Array.isArray(result.results)&&result.results.length===classified.owned.length,
   'PROCESS_STOP_UNVERIFIED','Prozessbeendigung hat keinen vollstaendigen Nachweis.');
  for(let i=0;i<result.results.length;i++){
   const r=result.results[i],expected=classified.owned[i];
   need(r?.pid===expected.pid&&['GONE','CLOSED','STOPPED','IDENTITY_CHANGED','PROTECTED','FAILED'].includes(r.status),
    'PROCESS_STOP_UNVERIFIED','Prozessbeendigung passt nicht zur geprueften Zielliste.');
   stopped.push({pid:r.pid,name:expected.name,status:r.status});
  }
  const problems=result.results.filter(r=>!['GONE','CLOSED','STOPPED'].includes(r.status));
  if(problems.length)throw new McrError('MIGRATION_PROCESS_STOP_FAILED',
   'Zugehoeriger Prozess konnte nicht sicher beendet werden: '+problems.map(r=>'PID '+r.pid+' '+r.status).join('; ')+'. Software noch nicht ersetzt.');
 }
 const proof=processProof(collect());checkIdle(proof);
 log('PASS MIGRATION_PROCESSES_IDLE: Zugehoerige Prozesse beendet und durch neue Prozessliste bestaetigt.');
 return {...proof,stoppedProcesses:stopped};
}
