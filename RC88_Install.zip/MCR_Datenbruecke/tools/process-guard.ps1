# RC46: collect a complete snapshot. No substring ownership inference here.
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$items = @(Get-CimInstance -ClassName Win32_Process -ErrorAction Stop | ForEach-Object {
    $created = $null
    if ($null -ne $_.CreationDate) { $created = $_.CreationDate.ToUniversalTime().ToString('o') }
    [ordered]@{
        pid = [int]$_.ProcessId
        parentPid = [int]$_.ParentProcessId
        name = [string]$_.Name
        createdAt = $created
        executablePath = $(if ($null -eq $_.ExecutablePath) { $null } else { [string]$_.ExecutablePath })
        commandLine = $(if ($null -eq $_.CommandLine) { $null } else { [string]$_.CommandLine })
    }
})
[ordered]@{schema='MCR_WINDOWS_PROCESS_SNAPSHOT_V1';checked=$true;processes=$items} | ConvertTo-Json -Depth 5 -Compress
