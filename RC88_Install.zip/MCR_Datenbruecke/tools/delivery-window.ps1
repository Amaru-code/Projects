# RC53: local two-way anonymous pipes; no files, no browser/OS input injection.
# Panel is hidden and acknowledges that fact before any automated CDP input.
$ErrorActionPreference = 'Stop'
try {
 [Console]::InputEncoding = New-Object System.Text.UTF8Encoding($false)
 [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
 Add-Type -AssemblyName System.Windows.Forms
 Add-Type -AssemblyName System.Drawing
 Add-Type -ReferencedAssemblies System.Windows.Forms,System.Drawing @'
using System;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
// Console.In.ReadLineAsync is synchronous on .NET Framework. Keep all reads
// on one background thread, never on the Forms message pump.
public sealed class McrPipeReader {
 private readonly System.Collections.Generic.Queue<string> lines=new System.Collections.Generic.Queue<string>();
 public volatile bool Done;
 public bool Empty { get { lock(lines){return lines.Count==0;} } }
 public McrPipeReader(){var t=new System.Threading.Thread(Read);t.IsBackground=true;t.Name="MCR anonymous pipe reader";t.Start();}
 private void Read(){try{string line;while((line=Console.In.ReadLine())!=null){lock(lines){if(lines.Count>=512||line.Length>8192)break;lines.Enqueue(line);}}}catch{}finally{Done=true;}}
 public string Take(){lock(lines){return lines.Count==0?null:lines.Dequeue();}}
}
public class McrControlForm : Form {
 protected override bool ShowWithoutActivation { get { return true; } }
 protected override CreateParams CreateParams { get { var p=base.CreateParams; p.ExStyle |= 0x08000000 | 0x00000080; return p; } }
 [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr h, int n);
 [DllImport("user32.dll")] public static extern int SetWindowLong(IntPtr h, int n, int v);
 public void MakeTransparentToMouse() { SetWindowLong(Handle,-20,GetWindowLong(Handle,-20)|0x00000020); }
}
public class McrModeSwitch : Control {
 private bool value;
 public event EventHandler CheckedChanged;
 public bool Checked { get { return value; } set { if(this.value==value)return;this.value=value;Invalidate();if(CheckedChanged!=null)CheckedChanged(this,EventArgs.Empty); } }
 public McrModeSwitch(){ SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer,true);Cursor=Cursors.Hand;AccessibleName="Versandmodus Manuell oder Auto"; }
 protected override void OnClick(EventArgs e){ Checked=!Checked;base.OnClick(e); }
 protected override void OnPaint(PaintEventArgs e){
  base.OnPaint(e);var g=e.Graphics;g.SmoothingMode=SmoothingMode.AntiAlias;
  using(var pen=new SolidBrush(Color.White)){
   g.DrawString("MANUELL",Font,pen,0,9);g.DrawString("AUTO",Font,pen,163,9);
  }
  using(var track=new SolidBrush(value?Color.FromArgb(25,142,76):Color.FromArgb(90,105,126)))
  using(var knob=new SolidBrush(Color.White)){
   g.FillEllipse(track,87,4,27,27);g.FillRectangle(track,100,4,31,27);g.FillEllipse(track,118,4,27,27);
   g.FillEllipse(knob,value?121:90,7,21,21);
  }
 }
}
'@
 function Send-Control($data) {
  $data.schema = 'MCR_CONTROL_V1'
  [Console]::Out.WriteLine(($data | ConvertTo-Json -Compress))
  [Console]::Out.Flush()
 }
 $form=New-Object McrControlForm
 $form.Text='MCR Ticketsteuerung'
 $form.FormBorderStyle='None';$form.StartPosition='Manual';$form.ShowInTaskbar=$false;$form.TopMost=$true
 $form.ClientSize=New-Object System.Drawing.Size(370,285)
 $form.BackColor=[System.Drawing.Color]::FromArgb(22,32,46);$form.ForeColor=[System.Drawing.Color]::White
 $work=[System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
 $form.Location=New-Object System.Drawing.Point(($work.Left+16),($work.Bottom-301))
 $font=New-Object System.Drawing.Font('Segoe UI',9)
 $bold=New-Object System.Drawing.Font('Segoe UI',10,[System.Drawing.FontStyle]::Bold)
 $form.Font=$font
 $title=New-Object System.Windows.Forms.Label
 $title.Text='MCR | TICKETSTEUERUNG';$title.Font=$bold;$title.Location=New-Object System.Drawing.Point(13,10);$title.Size=New-Object System.Drawing.Size(320,24);$form.Controls.Add($title)
 $values=@{};$n=0
 foreach($key in @('ticket','name','id','usc','answered','phase')){
  $lab=New-Object System.Windows.Forms.Label;$lab.Text=@('Ticket','Person','MercerID','USC / Plaene','Antwort','Schritt')[$n]
  $lab.Location=New-Object System.Drawing.Point(13,(40+23*$n));$lab.Size=New-Object System.Drawing.Size(90,22);$form.Controls.Add($lab)
  $val=New-Object System.Windows.Forms.Label;$val.Text='-';$val.AutoEllipsis=$true;$val.Location=New-Object System.Drawing.Point(105,(40+23*$n));$val.Size=New-Object System.Drawing.Size(252,22);$form.Controls.Add($val);$values[$key]=$val;$n++
 }
 $toggle=New-Object McrModeSwitch
 $toggle.Location=New-Object System.Drawing.Point(13,184);$toggle.Size=New-Object System.Drawing.Size(210,33);$toggle.Checked=$false
 $form.Controls.Add($toggle)
 $modeLabel=New-Object System.Windows.Forms.Label;$modeLabel.Location=New-Object System.Drawing.Point(232,193);$modeLabel.Size=New-Object System.Drawing.Size(120,20);$modeLabel.Text='MANUELL aktiv';$form.Controls.Add($modeLabel)
 $ok=New-Object System.Windows.Forms.Button;$ok.Text='Dieses Ticket senden';$ok.Location=New-Object System.Drawing.Point(13,228);$ok.Size=New-Object System.Drawing.Size(250,38);$ok.Enabled=$false;$form.Controls.Add($ok)
 $stop=New-Object System.Windows.Forms.Button;$stop.Text='STOP';$stop.Location=New-Object System.Drawing.Point(274,228);$stop.Size=New-Object System.Drawing.Size(80,38);$form.Controls.Add($stop)
 $script:ticket='';$script:challenge='';$script:syncing=$false;$script:finishing=$false;$script:finishAt=[DateTime]::MinValue;$script:resumeAt=[DateTime]::MaxValue
 $toggle.Add_CheckedChanged({
  $mode=if($toggle.Checked){'AUTO'}else{'MANUAL'}
  $modeLabel.Text=if($toggle.Checked){'AUTO aktiv'}else{'MANUELL aktiv'}
  $toggle.Invalidate()
  if(-not $script:syncing){Send-Control @{event='mode';mode=$mode}}
 })
 $ok.Add_Click({if($script:challenge){Send-Control @{event='approve';ticket=$script:ticket;challenge=$script:challenge};$ok.Enabled=$false}})
 $stop.Add_Click({Send-Control @{event='abort'};$form.Close()})
 $reader=New-Object McrPipeReader
 $timer=New-Object System.Windows.Forms.Timer;$timer.Interval=35
 $timer.Add_Tick({
  for($budget=0;$budget -lt 32;$budget++){
   $line=$reader.Take()
   if($null -eq $line){break}
   try {
     $m=$line|ConvertFrom-Json -ErrorAction Stop
     if($m.schema -eq 'MCR_PROGRESS_V2'){
      if($m.event -eq 'suspend'){$form.Hide();$script:resumeAt=[DateTime]::MaxValue;[System.Windows.Forms.Application]::DoEvents();Send-Control @{event='hidden';seq=[int]$m.seq}}
      elseif($m.event -eq 'resume'){$script:resumeAt=[DateTime]::UtcNow.AddMilliseconds(700)}
      elseif($m.event -eq 'mode'){$script:syncing=$true;$toggle.Checked=($m.mode -eq 'AUTO');$script:syncing=$false}
      elseif($m.event -eq 'approval'){$script:ticket=[string]$m.ticket;$script:challenge=[string]$m.challenge;$ok.Enabled=$true;$form.Show()}
      elseif($m.event -eq 'approval_consumed'){$ok.Enabled=$false;$script:challenge=''}
      elseif($m.event -eq 'error'){$title.Text='MCR | PRUEFUNG ERFORDERLICH';$title.ForeColor=[System.Drawing.Color]::Orange;$ok.Enabled=$false}
      elseif($m.event -eq 'finish'){
       $script:finishing=$true;$script:finishAt=[DateTime]::UtcNow;$form.Hide();$form.Controls.Clear()
       $form.BackColor=[System.Drawing.Color]::Black;$form.TransparencyKey=[System.Drawing.Color]::Black
       $form.Location=$work.Location;$form.Size=$work.Size;$form.Opacity=1.0
       $big=New-Object System.Windows.Forms.Label;$big.Text=[string]$m.title;$big.ForeColor=[System.Drawing.Color]::LimeGreen;$big.BackColor=[System.Drawing.Color]::Black
       $big.Font=New-Object System.Drawing.Font('Segoe UI',([Math]::Max(24,[Math]::Min(58,$work.Width/33))),[System.Drawing.FontStyle]::Bold)
       $big.TextAlign='MiddleCenter';$big.Location=New-Object System.Drawing.Point(20,([int]($work.Height/2)-110));$big.Size=New-Object System.Drawing.Size(($work.Width-40),150);$form.Controls.Add($big)
       $sub=New-Object System.Windows.Forms.Label;$sub.Text=[string]$m.subtitle;$sub.Font=$bold;$sub.ForeColor=[System.Drawing.Color]::LightGreen;$sub.TextAlign='MiddleCenter'
       $sub.Location=New-Object System.Drawing.Point(20,([int]($work.Height/2)+40));$sub.Size=New-Object System.Drawing.Size(($work.Width-40),50);$form.Controls.Add($sub)
       $form.MakeTransparentToMouse();$form.Show()
      }
      elseif($m.event -eq 'close' -and -not $script:finishing){$form.Close()}
      if(-not $script:finishing){foreach($key in @('ticket','name','id','usc','answered','phase')){if($null -ne $m.$key){$values[$key].Text=[string]$m.$key}}}
     }
   }catch{}
  }
  if($reader.Done -and $reader.Empty -and -not $script:finishing){$form.Close()}
  if($script:finishing){
   $t=[Math]::Min(1.0,([DateTime]::UtcNow-$script:finishAt).TotalMilliseconds/5000.0)
   $form.Opacity=[Math]::Max(0.0,1.0-(3*$t*$t-2*$t*$t*$t))
   if($t -ge 1.0){$timer.Stop();$form.Close()}
  }elseif([DateTime]::UtcNow -ge $script:resumeAt){$script:resumeAt=[DateTime]::MaxValue;$form.Show()}
 })
 $form.Add_Shown({Send-Control @{event='ready'}})
 $timer.Start();[System.Windows.Forms.Application]::Run($form)
 $timer.Dispose();$form.Dispose();$font.Dispose();$bold.Dispose()
}catch{exit 1}
