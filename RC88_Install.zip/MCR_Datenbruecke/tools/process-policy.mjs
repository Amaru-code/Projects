/** RC46: exact Windows process ownership; pure classification, no termination. */
import path from 'node:path';
import {requireThat as need} from '../lib/core.mjs';
const browsers=new Set(['msedge.exe','chrome.exe','chromium.exe','chromium-browser.exe']);
const win=path.win32;
const abs=p=>typeof p==='string'&&/^(?:[a-z]:[\\/]|\\\\[^\\]+\\[^\\]+)/i.test(p)&&!/[\x00-\x1f]/.test(p);
export function windowsPath(value){return abs(value)?win.normalize(value).replace(/[\\/]+$/,'').toLowerCase():null;}
export function pathWithin(candidate,root){const p=windowsPath(candidate),r=windowsPath(root);return !!p&&!!r&&(p===r||p.startsWith(r+'\\'));}

/** Windows argv quoting; malformed quoting is never guessed. Shell programs
 * have additional syntax, so only restricted command shapes are admitted. */
export function splitWindowsCommandLine(value){
 if(typeof value!=='string'||!value.trim())return null;
 const args=[];let i=0;
 while(i<value.length){
  while(i<value.length&&/[\t ]/.test(value[i]))i++;
  if(i===value.length)break;
  let arg='',quoted=false;
  while(i<value.length){
   if(!quoted&&/[\t ]/.test(value[i]))break;
   let slashes=0;while(value[i]==='\\'){slashes++;i++;}
   if(value[i]==='"'){
    arg+='\\'.repeat(Math.floor(slashes/2));
    if(slashes%2){arg+='"';i++;}
    else if(quoted&&value[i+1]==='"'){arg+='"';i+=2;}
    else {quoted=!quoted;i++;}
   }else{
    arg+='\\'.repeat(slashes);
    if(i>=value.length)break;
    if(!quoted&&/[\t ]/.test(value[i]))break;
    arg+=value[i++];
   }
  }
  if(quoted)return null;
  args.push(arg);while(i<value.length&&/[\t ]/.test(value[i]))i++;
 }
 return args.length?args:null;
}
function nodeEntry(args){
 const noValue=new Set(['--no-warnings','--trace-warnings','--enable-source-maps','--no-deprecation','--trace-deprecation','--unhandled-rejections=strict']);
 for(let i=1;i<args.length;i++){
  const a=args[i];if(a==='--')return args[i+1]||null;
  if(noValue.has(a)||/^--(?:inspect|inspect-brk)(?:=|$)/.test(a))continue;
  if(a.startsWith('-'))return null;return a;
 }return null;
}
function entryUnderRoot(entry,root){
 if(!abs(entry)||!pathWithin(entry,root))return false;
 return /^(?:src|tools|tests|examples)\/[^\x00-\x1f]+\.(?:mjs|cjs|js)$/i.test(win.relative(root,entry).replace(/\\/g,'/'));
}
function browserProfile(args){
 const profiles=[];
 for(let i=1;i<args.length;i++){
  if(args[i].toLowerCase()==='--user-data-dir')profiles.push(args[++i]??'');
  else if(args[i].toLowerCase().startsWith('--user-data-dir='))profiles.push(args[i].slice(16));
 }return profiles;
}
// CMD's outer quotes are not ordinary Windows argv quotes. Admit only a
// single absolute launcher path, including Explorer's /c ""...START.cmd" ".
// Never interpret variables, redirection, chaining, or an arbitrary shell.
function cmdOwnership(commandLine,root){
 const m=typeof commandLine==='string'&&commandLine.match(/^[ \t]*(?:"([^"]+)"|([^ \t"]+))[ \t]+(?:\/[dsq][ \t]+)*\/[ck][ \t]+([\s\S]*?)[ \t]*$/i);
 if(!m)return {owned:false,targetMention:false,decidable:false,reason:'CMD_COMMAND_UNRESOLVED'};
 if(win.basename(m[1]||m[2]).toLowerCase()!=='cmd.exe')return {owned:false,targetMention:false,decidable:false,reason:'EXECUTABLE_COMMAND_CONFLICT'};
 let tail=m[3].trim();
 if(tail.startsWith('""')&&tail.endsWith('"'))tail=tail.slice(1,-1).trim();
 const exact=tail.match(/^"([^"]+)"$/)||tail.match(/^([^ \t"]+)$/);
 const candidate=exact?.[1]||(tail.match(/^"([^"]+)"/)||tail.match(/^([^ \t"&|<>^]+)/))?.[1];
 const plain=!!exact&&!/[\r\n&|<>^%!]/.test(tail)&&!(tail[0]!=='"'&&/[()]/.test(tail));
 const owned=plain&&windowsPath(candidate)===windowsPath(win.join(root,'START.cmd'));
 return {owned,targetMention:!!candidate&&pathWithin(candidate,root),decidable:plain&&abs(candidate),reason:owned?'EXACT_START_LAUNCHER':'CMD_COMMAND_UNRESOLVED'};
}
function directOwnership(p,root,profile){
 const name=p.name.toLowerCase();
 if(name==='cmd.exe')return cmdOwnership(p.commandLine,root);
 const args=splitWindowsCommandLine(p.commandLine);
 if(!args)return {owned:false,targetMention:false,decidable:false,reason:'COMMAND_LINE_UNREADABLE'};
 if(win.basename(args[0]).toLowerCase()!==name)return {owned:false,targetMention:args.some(a=>pathWithin(a,root)),decidable:false,reason:'EXECUTABLE_COMMAND_CONFLICT'};
 if(name==='node.exe'){
  if(args.includes('--test')){
   const scripts=args.slice(1).filter(a=>!a.startsWith('-'));
   const flags=args.slice(1).filter(a=>a.startsWith('-'));
   const knownFlags=flags.every(a=>a==='--test'||/^--test-(?:concurrency|reporter|timeout)=/.test(a));
   const owned=knownFlags&&scripts.length>0&&scripts.every(s=>entryUnderRoot(s,root));
   return {owned,targetMention:scripts.some(s=>pathWithin(s,root)),decidable:knownFlags&&scripts.length>0&&scripts.every(abs),reason:'EXACT_NODE_TEST_FILES'};
  }
  const entry=nodeEntry(args);return {owned:entryUnderRoot(entry,root),targetMention:entry?pathWithin(entry,root):args.slice(1).some(a=>entryUnderRoot(a,root)),decidable:abs(entry),reason:abs(entry)?'EXACT_NODE_ENTRY':'NODE_ENTRY_UNRESOLVED'};
 }
 if(browsers.has(name)){
  const profiles=browserProfile(args),matches=profiles.filter(p=>windowsPath(p)===profile);
  return {owned:profiles.length===1&&matches.length===1,targetMention:profiles.some(p=>pathWithin(p,root)),decidable:profiles.length===1&&abs(profiles[0]),reason:'EXACT_BROWSER_PROFILE'};
 }
 if(['powershell.exe','pwsh.exe'].includes(name)){
  const at=args.findIndex(a=>a.toLowerCase()==='-file'),entry=at>=0?args[at+1]:null;
  const owned=!!entry&&abs(entry)&&pathWithin(entry,root)&&/\.ps1$/i.test(entry)&&!args.slice(1,at).some(a=>/^-?(?:command|c|encodedcommand|enc)$/i.test(a));
  return {owned,targetMention:!!entry&&pathWithin(entry,root),decidable:!!entry&&abs(entry)&&!args.slice(1,at).some(a=>/^-?(?:command|c|encodedcommand|enc)$/i.test(a)),reason:'EXACT_POWERSHELL_FILE'};
 }
 return {owned:false,targetMention:false,decidable:!!windowsPath(p.executablePath)&&!pathWithin(p.executablePath,root),reason:'UNRELATED_EXECUTABLE'};
}
function hasIdentity(p){return Number.isSafeInteger(p.pid)&&p.pid>0&&typeof p.createdAt==='string'&&Number.isFinite(Date.parse(p.createdAt))&&
 typeof p.name==='string'&&p.name.length>0&&(!!windowsPath(p.executablePath)||typeof p.commandLine==='string'&&p.commandLine.trim().length>0);}
export function sameProcessIdentity(expected,current){
 return !!current&&hasIdentity(expected)&&hasIdentity(current)&&expected.pid===current.pid&&expected.parentPid===current.parentPid&&
  expected.name.toLowerCase()===current.name.toLowerCase()&&expected.createdAt===current.createdAt&&
  (expected.executablePath??null)===(current.executablePath??null)&&(expected.commandLine??null)===(current.commandLine??null);
}
function bornAfter(child,parent){return hasIdentity(child)&&hasIdentity(parent)&&Date.parse(child.createdAt)>=Date.parse(parent.createdAt);}

export function classifyWindowsProcesses(snapshot,{root,profileDirectory,excludePid,extraProtectedPids=[],blockProtectedTargetAncestors=false}={}){
 const normalizedRoot=windowsPath(root),profile=windowsPath(profileDirectory);
 need(normalizedRoot&&profile&&pathWithin(profile,normalizedRoot)&&profile!==normalizedRoot,'PROCESS_SCOPE_INVALID','Bot-Verzeichnis/Browserprofil fuer Prozesspruefung ungueltig.');
 need(snapshot?.schema==='MCR_WINDOWS_PROCESS_SNAPSHOT_V1'&&snapshot.checked===true&&Array.isArray(snapshot.processes)&&snapshot.processes.length<=32768,
  'PROCESS_CHECK_UNAVAILABLE','Vollstaendige Windows-Prozessliste fehlt.');
 const all=new Map();
 for(const x of snapshot.processes){
  need(x&&Number.isSafeInteger(x.pid)&&x.pid>=0&&Number.isSafeInteger(x.parentPid)&&x.parentPid>=0&&typeof x.name==='string'&&!all.has(x.pid),
   'PROCESS_CHECK_UNAVAILABLE','Prozessliste enthaelt ungueltige oder doppelte Kennungen.');
  all.set(x.pid,{pid:x.pid,parentPid:x.parentPid,name:x.name,createdAt:x.createdAt??null,executablePath:x.executablePath??null,commandLine:x.commandLine??null});
 }
 need(Number.isSafeInteger(excludePid)&&excludePid>0&&all.has(excludePid),'PROCESS_CHECK_UNAVAILABLE','Eigener Installer-Prozess nicht eindeutig in der Prozessliste.');
 const protectedPids=new Set([excludePid,...extraProtectedPids.filter(p=>Number.isSafeInteger(p)&&p>0)]);
 let p=all.get(excludePid),seen=new Set();
 while(p&&!seen.has(p.pid)){seen.add(p.pid);protectedPids.add(p.pid);p=all.get(p.parentPid);}
 // Only descendants of this caller are protected, not all descendants of
 // protected ancestors such as explorer.exe or a shared terminal host.
 const ownHelpers=new Set([excludePid]);let changed=true;
 while(changed){changed=false;for(const q of all.values())if(!ownHelpers.has(q.pid)&&ownHelpers.has(q.parentPid)&&q.pid!==q.parentPid){
  ownHelpers.add(q.pid);protectedPids.add(q.pid);changed=true;
 }}
 const owned=new Map(),unknown=new Map(),ignoredUnreadable=[],reasons=new Map(),decidable=new Map();
 for(const q of all.values()){
  if(q.pid===0)continue;
  if(protectedPids.has(q.pid)){
   // A target bot which launched this installer cannot safely be killed.
   // Ordinary in-place read-only checks still exempt their own caller family.
   if(blockProtectedTargetAncestors&&q.pid!==excludePid&&seen.has(q.pid)&&
     (q.name.toLowerCase()==='node.exe'||browsers.has(q.name.toLowerCase()))&&directOwnership(q,normalizedRoot,profile).owned)
    unknown.set(q.pid,{...q,reason:'PROTECTED_TARGET_ANCESTOR'});
   continue;
  }
  const direct=directOwnership(q,normalizedRoot,profile);reasons.set(q.pid,direct.reason||'UNRELATED');decidable.set(q.pid,direct.decidable===true);
  if(direct.owned){
   if(hasIdentity(q))owned.set(q.pid,{...q,reason:direct.reason,ownerPid:q.pid,depth:0});
   else unknown.set(q.pid,{...q,reason:'TARGET_PROCESS_IDENTITY_UNREADABLE'});
  }else if(direct.targetMention)unknown.set(q.pid,{...q,reason:direct.reason||'TARGET_ARGUMENT_AMBIGUOUS'});
  else if(['node.exe',...browsers].includes(q.name.toLowerCase())&&!q.commandLine)ignoredUnreadable.push(q.pid);
 }
 changed=true;
 while(changed){changed=false;
  for(const q of all.values())if(!protectedPids.has(q.pid)&&!owned.has(q.pid)&&!unknown.has(q.pid)){
   const parent=owned.get(q.parentPid);if(!parent)continue;
   if(bornAfter(q,parent)){owned.set(q.pid,{...q,reason:'VERIFIED_OWNED_DESCENDANT',ownerPid:parent.ownerPid,depth:parent.depth+1});changed=true;}
   else if(!hasIdentity(q))unknown.set(q.pid,{...q,reason:'OWNED_DESCENDANT_IDENTITY_UNREADABLE'});
  }
 }
 return {owned:[...owned.values()].sort((a,b)=>a.depth-b.depth||a.pid-b.pid),unknown:[...unknown.values()],protectedPids:[...protectedPids].sort((a,b)=>a-b),
  inspectedProcesses:[...all.values()].map(q=>({pid:q.pid,parentPid:q.parentPid,name:q.name,createdAt:q.createdAt,
   identityReadable:hasIdentity(q)&&typeof q.commandLine==='string'&&q.commandLine.trim().length>0,
   ownershipDecidable:hasIdentity(q)&&decidable.get(q.pid)===true,
   reason:owned.get(q.pid)?.reason||unknown.get(q.pid)?.reason||(protectedPids.has(q.pid)?'CURRENT_INSTALLER_FAMILY':reasons.get(q.pid)||'UNRELATED'),
   relation:protectedPids.has(q.pid)?'PROTECTED':owned.has(q.pid)?'OWNED':unknown.has(q.pid)?'UNKNOWN':'UNRELATED'})),
  ignoredUnrelatedUnreadableCount:ignoredUnreadable.filter(id=>!owned.has(id)&&!unknown.has(id)).length};
}
export function processProof(classified){
 const brief=p=>({pid:p.pid,name:p.name,reason:p.reason});
 return {schema:'MCR_PROCESS_GUARD_V1',checked:true,blockedCount:classified.owned.length,unknownCount:classified.unknown.length,
  targetProcesses:classified.owned.map(brief),unknownProcesses:classified.unknown.map(brief),protectedPids:classified.protectedPids,
  inspectedPids:classified.inspectedProcesses.map(p=>p.pid),inspectedProcesses:classified.inspectedProcesses,
  ignoredUnrelatedUnreadableCount:classified.ignoredUnrelatedUnreadableCount};
}
