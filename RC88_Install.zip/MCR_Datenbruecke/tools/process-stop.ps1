# RC46: explicit PID/creation identity only. No name wildcard, no taskkill /T.
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
[Console]::InputEncoding = New-Object System.Text.UTF8Encoding($false)
$request = [Console]::In.ReadToEnd() | ConvertFrom-Json
if ($request.schema -ne 'MCR_MIGRATION_PROCESS_STOP_V1' -or $request.callerPid -lt 1 -or
    @($request.targets).Count -gt 4096) { throw 'Invalid migration stop request.' }
function Get-Record([int]$ProcessNumber) {
    $records = @(Get-CimInstance -ClassName Win32_Process -Filter ('ProcessId = ' + $ProcessNumber) -ErrorAction Stop)
    if ($records.Count -eq 0) { return $null }
    if ($records.Count -ne 1) { throw 'Ambiguous process identity.' }
    $p = $records[0]
    $created = $null
    if ($null -ne $p.CreationDate) { $created = $p.CreationDate.ToUniversalTime().ToString('o') }
    return [pscustomobject]@{
        pid = [int]$p.ProcessId; parentPid = [int]$p.ParentProcessId; name = [string]$p.Name
        createdAt = $created
        executablePath = $(if ($null -eq $p.ExecutablePath) { $null } else { [string]$p.ExecutablePath })
        commandLine = $(if ($null -eq $p.CommandLine) { $null } else { [string]$p.CommandLine })
    }
}
function Same-Identity($Expected, $Current) {
    return $null -ne $Current -and $Expected.pid -eq $Current.pid -and
        $Expected.parentPid -eq $Current.parentPid -and $Expected.name -ieq $Current.name -and
        -not [string]::IsNullOrWhiteSpace($Expected.createdAt) -and $Expected.createdAt -ceq $Current.createdAt -and
        $Expected.executablePath -ceq $Current.executablePath -and $Expected.commandLine -ceq $Current.commandLine
}
$protected = New-Object 'System.Collections.Generic.HashSet[int]'
[void]$protected.Add([int]$PID)
[void]$protected.Add([int]$request.callerPid)
foreach ($n in @($request.protectedPids)) { [void]$protected.Add([int]$n) }
# Independently protect this helper's current parent chain as well.
$ancestor = [int]$PID
$visited = New-Object 'System.Collections.Generic.HashSet[int]'
while ($ancestor -gt 0 -and $visited.Add($ancestor)) {
    [void]$protected.Add($ancestor)
    $record = Get-Record $ancestor
    if ($null -eq $record) { break }
    $ancestor = [int]$record.parentPid
}
$results = New-Object 'System.Collections.Generic.List[object]'
$seenTargets = New-Object 'System.Collections.Generic.HashSet[int]'
$deadline = [DateTime]::UtcNow.AddSeconds(10)
foreach ($expected in @($request.targets)) {
    $number = [int]$expected.pid
    $status = 'FAILED'
    $process = $null
    try {
        if ($number -le 0 -or -not $seenTargets.Add($number)) { throw 'Invalid target PID.' }
        if ($protected.Contains($number)) { $status = 'PROTECTED' }
        elseif ([DateTime]::UtcNow -gt $deadline) { $status = 'FAILED' }
        else {
            $current = Get-Record $number
            if ($null -eq $current) { $status = 'GONE' }
            elseif (-not (Same-Identity $expected $current)) { $status = 'IDENTITY_CHANGED' }
            else {
                $process = Get-Process -Id $number -ErrorAction Stop
                # Explicitly retain the handle; StartTime alone may use a
                # transient handle. All later actions use this Process object.
                [void]$process.Handle
                # Check CIM creation time before CloseMainWindow/Stop-Process.
                $created = [DateTime]::Parse($expected.createdAt).ToUniversalTime()
                $delta = [Math]::Abs(($process.StartTime.ToUniversalTime() - $created).TotalMilliseconds)
                if ($delta -gt 2 -or $process.ProcessName -ine [IO.Path]::GetFileNameWithoutExtension($expected.name)) {
                    $status = 'IDENTITY_CHANGED'
                }
                else {
                    $closed = $false
                    if ($process.MainWindowHandle -ne [IntPtr]::Zero) {
                        [void]$process.CloseMainWindow()
                        $closed = $process.WaitForExit(700)
                    }
                    if ($closed) { $status = 'CLOSED' }
                    else {
                        $beforeStop = Get-Record $number
                        if ($null -eq $beforeStop) { $status = 'GONE' }
                        elseif (-not (Same-Identity $expected $beforeStop)) { $status = 'IDENTITY_CHANGED' }
                        elseif ($process.HasExited) { $status = 'GONE' }
                        else {
                            Stop-Process -InputObject $process -Force -ErrorAction Stop
                            if ($process.WaitForExit(1000)) { $status = 'STOPPED' }
                        }
                    }
                }
            }
        }
    }
    catch {
        # Access denied is not success. Only an independent PID absence can
        # turn the ordinary exit race into an already-gone result.
        try { if ($null -eq (Get-Record $number)) { $status = 'GONE' } } catch {}
    }
    finally { if ($null -ne $process) { $process.Dispose(); $process = $null } }
    $results.Add([pscustomobject]@{pid=$number;status=$status})
}
[ordered]@{schema='MCR_MIGRATION_PROCESS_STOP_RESULT_V1';results=@($results.ToArray())} | ConvertTo-Json -Depth 5 -Compress
