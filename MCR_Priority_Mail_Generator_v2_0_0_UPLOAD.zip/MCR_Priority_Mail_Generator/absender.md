﻿# Absender- und Betreff-Regeln

Eine Regel pro Zeile. Muster: Name, E-Mail-Adresse, Domain (@firma.de) oder Stichwort im Betreff. Diese Regeln haben Vorrang vor der eigenen Einschätzung des Modells.

## VIP – mindestens 🟡, bei Frage oder Frist 🔴
[Führungskraft: vorname.nachname@mercer.com]
[Wichtige Kolleg*innen im Team]
[Mandanten-Domains, z. B. @mandant1.de]

## Immer 🔵 Zur Kenntnis
[Team-Verteiler, z. B. team-xy@mercer.com]
[Projekt-Statusmails]

## Immer ⚪ Ignorieren – ohne Öffnen
Absender enthält: noreply, no-reply, donotreply, notifications, mailer
[HR-Rundmails: z. B. hr-info@...]
[Interne Newsletter: ...]
[IT-/System-Benachrichtigungen: SharePoint, Teams, Workday, ServiceNow ...]
Betreff enthält: Newsletter, Webinar, Umfrage, Survey, Abwesenheitsnotiz, Automatische Antwort, Out of Office

## Ausnahmen (stärker als "Ignorieren")
HR- oder IT-Mail mit persönlicher Frist an mich (Pflichtschulung, Zeiterfassung, Passwortablauf, Freigabe) → 🟡, bei Frist in ≤ 2 Arbeitstagen → 🔴
Einladung zu einem Termin, bei dem ich Pflichtteilnehmer*in bin → nie ⚪
