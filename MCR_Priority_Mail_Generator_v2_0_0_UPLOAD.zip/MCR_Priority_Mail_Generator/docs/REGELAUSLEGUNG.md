﻿# Auslegung für die Testmails – kein neuer Postfach-Scanner

## Vier Klassen
urgent = 🔴 Sofort beantworten; important = 🟡 Diese Woche; info = 🔵 Zur Kenntnis; ignore = ⚪ Ignorierbar.
Die V1-Klassen high / important / low werden nicht mehr verwendet. Alte Scanner-Auswertungen sind kein V2-Sollmaßstab.

## Offen benannte Überschneidungen in der Vorgabe
1. Eine direkte Frage/Aufforderung im An-Feld erfüllt die rote Regel, auch ohne Frist; die gelbe Regel kann sich damit überschneiden. Für diese Testfälle gilt die vom Nutzer vorgegebene Zweifelsregel: höhere Stufe, also Rot. Eine allgemeine direkte Bitte wird nicht stillschweigend zu Gelb gemacht. Die 12 live versendbaren gelben Grundvorlagen verwenden stattdessen die ausdrücklich beschriebene persönliche HR-/IT-Fristausnahme mit 3–9 Arbeitstagen. Dadurch sind sie weniger vielfältig als die gesamte gelbe Zieldefinition. Gruppenkoordination als eigene gelbe Fallgruppe bleibt bis zur eindeutigen fachlichen Abgrenzung ausgespart.
2. Vergangene Termine stehen unter Blau; abgelaufene Einladungen unter Weiß. Der Offline-Fall mit Pflichtteilnahme bleibt Blau, denn Pflichtteilnahme darf laut Vorgabe nie Weiß sein. Die weißen Live-Fälle sind freiwillige allgemeine Newsletter/Webinar-Angebote mit expliziter Betreffregel, keine vermeintlich echten Pflichttermine.
3. Mehrere widersprüchliche explizite Gruppen in absender.md (z. B. dieselbe Adresse zugleich VIP und Ignorieren) stoppen den Generator. Das Paket erfindet hierfür keine zusätzliche Rangfolge.
4. Die persönlichen HR-/IT-Ausnahmen übersteuern Ignorieren. Eine explizite Immer-Blau-Regel bleibt maßgeblich; eine VIP-Mail mit Frist bleibt Rot. Diese Kombinationen sind in den Generatorprüfungen getrennt erfasst.
5. Ob eine Ausnahme vorliegt, weiß der Generator aus den erklärten synthetischen Szenariodaten. Das ist KEIN Verfahren zum Erkennen von HR-/IT-Ausnahmen in unbekannten echten Mails. Ein zukünftiger Scanner muss sie z. B. aus Metadaten/Preview feststellen und darf nicht blind alle noreply-Mails wegwerfen.

## Stichtag und Arbeitstage
Alle Live-Fristen werden beim Generieren relativ zur lokalen Rechnerzeit als konkrete Daten in Betreff/Text eingefügt. Tag 0 ist heute, negative Offsets liegen davor. Ein vergangener Zeitpunkt wird in den Sollwerten als Overdue festgehalten. Nach Datumswechsel erzeugt die Oberfläche vor einem neuen Versand einen frischen Lauf; bei Mitternacht während des Versands wird gestoppt. Prioritäten sind nur für den protokollierten Stichtag garantiert, nicht für einen beliebig späteren Scannerlauf.
Arbeitstage: ausdrücklich gewählte TESTKONVENTION Montag–Freitag. Feiertage wurden nicht angegeben und werden nicht erfunden. Eigene Feiertage/arbeitsfreie Tage in config/generator_settings.json als YYYY-MM-DD ergänzen. Diese Konvention ist keine Aussage über einen gesetzlichen Feiertagskalender.

## Echte und simulierte Merkmale
Live: bestätigte Empfänger, echte An-/CC-Rolle, tatsächliches ausgewähltes Outlook-Absenderkonto, normale MailItems und aktuelle Empfangszeit nach tatsächlicher Zustellung. Keine künstlichen Absenderrollen, keine Send-as-Fälschung, keine rückdatierten Empfangszeiten.
Blau/erledigt: nur der Inhalt einer eigenständigen Abschlussnachricht wird erzeugt; keine echte mehrteilige Outlook-Konversation. Ein im Text genanntes Test-Team ist ein fiktiver Szenarioakteur, kein technisch verifizierter Absender.
Offline: 21 Fälle/24 künstliche Nachrichtendatensätze für VIP, automatische Sender, Ausnahmen, echte Thread-Metadaten innerhalb des Datensatzes, unterstützende Sent-Antworten, Scope-Grenzen, Einladung/Anhang als Metadaten. Kein Import, keine Kalenderänderung und kein Versand dieser Datensätze. Anhänge werden nur als Dateinamen deklariert, nicht erzeugt.
Inbox/Unread, Antwortprüfung, Abwesenheitszeitraum, Batch-Lesen und deutscher Rückblick sind Anforderungen an den künftigen Scanner, NICHT Funktionen dieses Generators. Die vorhandene Analyzer-Version 0.1.0 bleibt unverändert.
