﻿# Eigene Anpassungen

## 1. Persönliche Anrede
lib/PriorityMail.Core.psm1 → Get-RecipientName.
Das erste Segment vor dem Punkt wird zum Vornamen, alle Segmente zusammen zum Namen; Großschreibung wird normalisiert. Bindestriche bleiben erhalten, ein +Testzusatz wird für den Namen ignoriert. Aus joerg.mueller wird Joerg Mueller, nicht automatisch Jörg Müller. Geschlecht, Titel und abweichende Namensschreibweisen werden nicht erraten.
Bei mehreren Adressen: Hallo Amaru und Anna-Lena, usw. Jede erzeugte Nachricht geht weiterhin an ALLE eingegebenen Adressen. Anzahl 50 + zwei Adressen = 50 Nachrichten, jeder Empfänger erhält 50; nicht 100 separat personalisierte Nachrichten.

## 2. Texte und Szenarien
Aktive Datei: data/templates.json, schema_version 2.
Pro Vorlage: id, subject, body, rule, deadline_workdays, recipient_role, done.
Erlaubte Platzhalter: {greeting}, {name}, {full_name}, {email}, {case}, {project}, {due_date}, {past_date}, {today}.
Vorlagen sind Grundtexte: nach Verbrauch einer Klasse werden sie neu gemischt und wiederverwendet. Projekt-/Testnummern, Daten und Adressaten variieren. Keine KI-API und keine echten E-Mail-Texte als Laufzeitinput.
Regeln: DIRECT_TO, DUE_SOON, REMINDER, PERSONAL_HR_IT, STATUS, FINISHED, IGNORE_CONTENT.
Get-TestScenarioPriority in lib/PriorityMail.Core.psm1 bildet deklarierte Szenariofakten auf die Zielregel ab. Das ist ein Test-Oracle, kein Keyword-Scanner für unbekannte E-Mails. Wer Texte ändert, muss sie fachlich gegen rule und Sollklasse prüfen; ein technischer Test versteht keine beliebig umformulierte natürliche Sprache.
Die Entscheidungsklassen sind nicht mit den drei Outlook-Importance-Werten gleichzusetzen.

## 3. Absender und Betreff-Keywords
Aktive Datei: absender.md im Hauptordner. Überschriften ## VIP, ## Immer ... Zur Kenntnis, ## Immer ... Ignorieren beibehalten. Alle Einträge in eckigen Klammern sind INAKTIVE Platzhalter, keine erratenen realen VIPs.
Je Regelzeile in der passenden Gruppe:
  vorname.nachname@beispiel.de     → genaue Adresse
  @beispiel.de                    → Absender-Domain
  Absender enthält: Teamname      → Teilstring in SMTP/Absendername
  Betreff enthält: Newsletter     → Teilstring im Betreff
Mehrere Muster nach Absender enthält:/Betreff enthält: dürfen durch Komma getrennt werden. Ein nackter Name wird als Absender-Teilstring gelesen; Betreffbegriffe daher immer ausdrücklich mit Betreff enthält: schreiben. Groß-/Kleinschreibung spielt keine Rolle; kein RegEx-Code wird ausgeführt.
Neue Keywords unter der betreffenden Gruppe ergänzen. Steht ein komplettes Testkonto unter VIP, kann dieses Konto nicht gleichzeitig beliebige normale blaue/weiße Beispielsender darstellen: unpassende Vorlagen werden ausgeschlossen, fehlende angeforderte Klassen stoppen den Lauf. Nicht die eigene Firmenrichtlinie abschalten und keinen Absender fälschen; anderes tatsächlich berechtigtes Testkonto oder Offline-Datensatz verwenden.
Die fachlichen Ausnahmen im letzten Abschnitt bleiben menschlich lesbare Vorgaben; für eine geänderte Bedeutung auch Get-TestScenarioPriority und die Tests anpassen. Beliebige Änderungen am Fließtext werden nicht zu ausführbarem Code.

## 4. Vergleichbarkeit
plan.json, expected_priorities.csv, absender.snapshot.md bleiben unverändert. Ergebnisse entstehen separat in results.csv und summary.json. Senderregeln, Vorlagen und Einstellungen sind per SHA256 an den Lauf gebunden. Neue oder veränderte Konfiguration vor Versand führt in der Oberfläche zu einem neuen Plan und erneuter Bestätigung.
Die Datei expected_priorities.csv darf dem getesteten Scanner nicht als Input dienen: Sie enthält die erwarteten Antworten.
Die automatischen Selbsttests verwenden eingefrorene tests/fixtures für die Basisfälle, damit legitime Änderungen an der aktiven Konfiguration nicht an festen Baseline-Anzahlen scheitern. Aktive Dateien werden beim Erzeugen zusätzlich strukturell geprüft.
