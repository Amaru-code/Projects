﻿# Vom Nutzer gelieferte Zieldefinition

Der folgende Text ist die Vorgabe für den späteren READ-ONLY-Rückblick-Scanner, nicht die Anweisung an den Testmail-Versandadapter. Das Paket implementiert KEINEN solchen Scanner. Die Generator-Auslegung und Testgrenzen stehen separat in REGELAUSLEGUNG.md.

## Inbox catch-up after absence (Urlaubs-Rückblick)

Goal

When the user comes back from vacation or another absence, read the emails received during that time and give a prioritized overview in German: what needs an answer now, what can wait, what is just for information, and what can be ignored.

Hard rules

READ-ONLY. Never send, reply, forward, delete, move, flag, categorize or mark any email as read. Drafts only if the user asks for them afterwards, and only shown in the chat.
Output language is ALWAYS German, even if the user writes in English or the emails are in English.
Use only what is in the emails. Do not invent deadlines, intentions or facts. If something is unclear, write "unklar".
Before classifying anything, read the file absender.md from this skill (sender and subject rules). Its rules override your own judgment.

Step 1 – Scope

If the user gives a period (e.g. "Urlaub 22.09.–06.10."), use exactly that period.
Otherwise: all UNREAD emails in the Inbox from the last 14 days. State this assumption in the first line of the answer.
Inbox only, plus subfolders the user names explicitly. Skip Junk, Deleted Items and Archive.

Step 2 – Metadata first, full text only when needed

List for every email: sender, whether the user is in To or only in CC, subject, received date, importance flag, attachments yes/no, conversation/thread, short preview.
Apply absender.md: everything matching "Ignorieren" goes straight to ⚪ without opening it.
Group by conversation/thread. Judge each thread by its LATEST message. If the question in a thread was already answered or solved by someone else, put it under "Bereits erledigt" and name who solved it.
If possible, check Sent Items for the same period: if the user already replied to a thread, mark it as "bereits beantwortet".
Open the full text only for emails that cannot be clearly classified as 🔵 or ⚪ from the metadata.
Work in batches of about 20–30 emails. Do not stop early; process all emails in scope.

Step 3 – Priorities

🔴 Sofort beantworten (today):

a direct question or request to the user (user in To)
a deadline that has passed or is within the next 2 working days (mark passed ones as "ÜBERFÄLLIG")
anything from a VIP in absender.md that contains a question or a deadline
reminders and escalations ("Erinnerung", "dringend", "nochmals", 2nd follow-up)
meeting requests for the next days that still need a response

🟡 Diese Woche:

a request to the user without a tight deadline
a deadline within the next ~2 weeks
coordination where the user's input is expected

🔵 Zur Kenntnis:

user only in CC, status updates, decisions already made, finished threads, past meeting invitations

⚪ Ignorierbar:

newsletters, HR/IT mass mailings, marketing, automatic notifications, out-of-office replies, expired invitations
When in doubt between two levels, choose the higher one.

Step 4 – Output (German, short)

Start with one line: Zeitraum, Anzahl gelesener E-Mails, Verteilung (🔴 x / 🟡 x / 🔵 x / ⚪ x).

🔴 Sofort beantworten

Table: Nr. | Von | Betreff | Worum geht es (1 Satz) | Was wird von dir erwartet | Frist

🟡 Diese Woche

Same table.

🔵 Zur Kenntnis

One line per thread: Von – Betreff – Kernaussage in 1 Satz.

⚪ Ignorierbar

Counts by group only, no details (e.g. "HR-Rundmails: 4, Newsletter: 7, Systembenachrichtigungen: 12").

📅 Fristen und Termine

Chronological list of all deadlines and dates found: Datum – was – von wem.

✅ Bereits erledigt / beantwortet

One line each: Betreff – erledigt durch wen.

End with exactly one question: "Soll ich für die 🔴-Mails Antwortentwürfe vorbereiten?" Keep every summary to one sentence. No long quotes from emails.

## Absender- und Betreff-Regeln

Eine Regel pro Zeile. Muster: Name, E-Mail-Adresse, Domain (@firma.de) oder Stichwort im Betreff. Diese Regeln haben Vorrang vor der eigenen Einschätzung des Modells.

VIP – mindestens 🟡, bei Frage oder Frist 🔴

[Führungskraft: vorname.nachname@mercer.com]
[Wichtige Kolleg*innen im Team]
[Mandanten-Domains, z. B. @mandant1.de]

Immer 🔵 Zur Kenntnis

[Team-Verteiler, z. B. team-xy@mercer.com]
[Projekt-Statusmails]

Immer ⚪ Ignorieren – ohne Öffnen

Absender enthält: noreply, no-reply, donotreply, notifications, mailer
[HR-Rundmails: z. B. hr-info@...]
[Interne Newsletter: ...]
[IT-/System-Benachrichtigungen: SharePoint, Teams, Workday, ServiceNow ...]
Betreff enthält: Newsletter, Webinar, Umfrage, Survey, Abwesenheitsnotiz, Automatische Antwort, Out of Office

Ausnahmen (stärker als "Ignorieren")

HR- oder IT-Mail mit persönlicher Frist an mich (Pflichtschulung, Zeiterfassung, Passwortablauf, Freigabe) → 🟡, bei Frist in ≤ 2 Arbeitstagen → 🔴
Einladung zu einem Termin, bei dem ich Pflichtteilnehmer*in bin → nie ⚪
