@echo off
setlocal
cd /d "%~dp0"
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Export-OfflineCases.ps1"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" echo Offline-Export fehlgeschlagen. Keine Nachricht wurde versendet.
pause
exit /b %RC%
