﻿# Ausschließlich künstliches Offline-Testprofil; nicht in ein echtes Skill-Profil kopieren.
## VIP – mindestens 🟡, bei Frage oder Frist 🔴
leitung.vip@example.test
## Immer 🔵 Zur Kenntnis
projekt.status@example.test
## Immer ⚪ Ignorieren – ohne Öffnen
Absender enthält: noreply, no-reply, donotreply, notifications, mailer
Betreff enthält: Newsletter, Webinar, Umfrage, Survey, Abwesenheitsnotiz, Automatische Antwort, Out of Office
## Ausnahmen (stärker als Ignorieren)
Persönliche HR-/IT-Fristen und Pflichtteilnahme wie im unveränderten Nutzerauftrag.
