﻿#requires -Version 5.1
[CmdletBinding()]
param()
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$packageRoot = Split-Path $PSScriptRoot -Parent
$watch = [Diagnostics.Stopwatch]::StartNew()
Write-Host 'MCR Priority Mail Generator 2.0.0: Selbsttests ohne echten Versand'
Write-Host ('PowerShell: ' + $PSVersionTable.PSVersion.ToString())
Write-Host ('Betriebssystem: ' + [Environment]::OSVersion.ToString())
Write-Host ''

$fileCount = 0
foreach ($file in (Get-ChildItem -LiteralPath $packageRoot -Recurse -File | Where-Object { $_.Extension -in @('.ps1', '.psm1') })) {
    $tokens = $null
    $parseErrors = $null
    $null = [Management.Automation.Language.Parser]::ParseFile($file.FullName, [ref]$tokens, [ref]$parseErrors)
    if ($parseErrors.Count -gt 0) {
        throw ('Syntaxfehler in ' + $file.Name + ': ' + (($parseErrors | ForEach-Object { $_.Message }) -join '; '))
    }
    $fileCount++
}
Write-Host ('PASS  Syntaxpruefung fuer ' + $fileCount + ' PowerShell-Dateien')
& (Join-Path $PSScriptRoot 'Test-Core.ps1')
& (Join-Path $PSScriptRoot 'Test-Transport.ps1')
& (Join-Path $PSScriptRoot 'Test-Integration.ps1')
$watch.Stop()
Write-Host ''
Write-Host ('SELBSTTEST=PASS; REAL_MAILS_SENT=0; DAUER_SEKUNDEN=' + $watch.Elapsed.TotalSeconds.ToString('F2', [Globalization.CultureInfo]::InvariantCulture))
Write-Host 'Fensterdarstellung, Outlook-COM und echte Zustellung sind nicht Bestandteil dieser Offline-Tests.'
