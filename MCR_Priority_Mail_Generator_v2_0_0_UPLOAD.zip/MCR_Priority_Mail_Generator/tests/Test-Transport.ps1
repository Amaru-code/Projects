﻿#requires -Version 5.1
<#
    Independent transport fault tests. No COM object is created and no mail is sent.
    Every Outlook/MailItem/Recipient is a plain in-memory PowerShell object.
    Temporary journals are created below the system temporary directory and removed.
#>
[CmdletBinding()]
param(
    [string]$ProjectRoot = (Split-Path -Parent $PSScriptRoot)
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $ProjectRoot 'lib/PriorityMail.Outlook.psm1') -Force -ErrorAction Stop

$script:CheckCount = 0
$script:CaseCount = 0
$testRoot = Join-Path ([IO.Path]::GetTempPath()) ('MCR-Transport-Mock-' + [Guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($testRoot)

function Assert-Transport {
    param([bool]$Condition, [string]$Description)
    if (-not $Condition) { throw ('FAILED: ' + $Description) }
    $script:CheckCount++
}

function New-MockMessage {
    return [pscustomobject]@{
        TestId = ('MOCK-' + [Guid]::NewGuid().ToString('N'))
        Status = 'planned'
        Subject = 'Fictional local transport test'
        Body = 'This message only exists inside a local mock object.'
        OutlookImportance = 1
        SubmittedAt = ''
        Error = ''
    }
}

function New-MockOutlook {
    param([string]$CaseName)

    $caseRoot = Join-Path $testRoot $CaseName
    [void][IO.Directory]::CreateDirectory($caseRoot)
    $harness = [pscustomobject]@{
        EventPath = (Join-Path $caseRoot 'events.jsonl')
        CapturedSmtp = 'sender@example.invalid'
        Account = [pscustomobject]@{ SmtpAddress = 'sender@example.invalid' }
        CreateCalls = 0
        SendCalls = 0
        ResolveCalls = 0
        AddedRecipients = (New-Object 'System.Collections.Generic.List[object]')
        CreateThrows = $false
        AddThrows = $false
        ResolveResult = $true
        SendThrows = $false
        BreakJournalAfterSend = $false
        SawAttemptingBeforeSend = $false
        Mail = $null
        Outlook = $null
    }

    $recipients = [pscustomobject]@{ Harness = $harness }
    $recipients | Add-Member -MemberType ScriptMethod -Name Add -Value {
        param([string]$Address)
        if ($this.Harness.AddThrows) { throw 'Synthetic recipient creation failure.' }
        $recipient = [pscustomobject]@{ Address = $Address; Type = 0 }
        [void]$this.Harness.AddedRecipients.Add($recipient)
        return $recipient
    }
    $recipients | Add-Member -MemberType ScriptMethod -Name ResolveAll -Value {
        $this.Harness.ResolveCalls++
        return $this.Harness.ResolveResult
    }

    $mail = [pscustomobject]@{
        Harness = $harness
        Subject = ''
        BodyFormat = 0
        Body = ''
        Importance = -1
        SendUsingAccount = $null
        Recipients = $recipients
    }
    $mail | Add-Member -MemberType ScriptMethod -Name Send -Value {
        $this.Harness.SendCalls++
        if ([IO.File]::Exists($this.Harness.EventPath)) {
            $events = @([IO.File]::ReadAllLines($this.Harness.EventPath) | ForEach-Object { $_ | ConvertFrom-Json })
            $this.Harness.SawAttemptingBeforeSend = (@($events | Where-Object { $_.Status -eq 'attempting' }).Count -eq 1)
        }
        if ($this.Harness.SendThrows) { throw 'Synthetic Send failure: acceptance is deliberately unknown.' }
        if ($this.Harness.BreakJournalAfterSend) {
            [IO.File]::Move($this.Harness.EventPath, ($this.Harness.EventPath + '.before_failure'))
            [void][IO.Directory]::CreateDirectory($this.Harness.EventPath)
        }
    }
    $harness.Mail = $mail

    $outlook = [pscustomobject]@{ Harness = $harness }
    $outlook | Add-Member -MemberType ScriptMethod -Name CreateItem -Value {
        param([int]$ItemType)
        $this.Harness.CreateCalls++
        if ($ItemType -ne 0) { throw 'The transport requested a non-mail Outlook item.' }
        if ($this.Harness.CreateThrows) { throw 'Synthetic CreateItem failure.' }
        return $this.Harness.Mail
    }
    $harness.Outlook = $outlook
    return $harness
}

function Invoke-MockSubmission {
    param(
        $Harness,
        $Message,
        [string[]]$Recipients = @('recipient@example.invalid')
    )
    return Invoke-TestMailSubmission -Message $Message -Recipients $Recipients `
        -Outlook $Harness.Outlook -Account $Harness.Account `
        -AccountSmtp $Harness.CapturedSmtp -EventPath $Harness.EventPath
}

function Read-MockEvents {
    param($Harness)
    return @([IO.File]::ReadAllLines($Harness.EventPath) | ForEach-Object { $_ | ConvertFrom-Json })
}

function Complete-TransportCase {
    param([string]$Name)
    $script:CaseCount++
    Write-Host ('PASS: ' + $Name)
}

try {
    $h = New-MockOutlook 'cc_only'
    $m = New-MockMessage
    $m | Add-Member NoteProperty RecipientRole 'cc'
    $r = Invoke-MockSubmission $h $m @('first@example.invalid','second@example.invalid')
    Assert-Transport ($r.Status -eq 'submitted') 'CC-only mail can be submitted.'
    Assert-Transport (@($h.AddedRecipients | Where-Object { $_.Type -ne 2 }).Count -eq 0) 'CC recipients must really have olCC type.'
    Complete-TransportCase 'Real CC recipient type in mock'

    $h = New-MockOutlook 'invalid_role'
    $m = New-MockMessage
    $m | Add-Member NoteProperty RecipientRole 'bcc'
    $r = Invoke-MockSubmission $h $m
    Assert-Transport ($r.Status -eq 'failed' -and $h.SendCalls -eq 0) 'Unknown roles fail before Send.'
    Complete-TransportCase 'Invalid role fails before send'

    # Success must use the captured account, all recipients, and neutral priority.
    $h = New-MockOutlook 'success'
    $m = New-MockMessage
    $r = Invoke-MockSubmission $h $m @('first@example.invalid', 'second@example.invalid')
    Assert-Transport ($r.Status -eq 'submitted' -and $m.Status -eq 'submitted') 'Successful Send must be reported as submitted.'
    Assert-Transport (-not $r.Halt) 'Successful submission must permit the next message.'
    Assert-Transport ($h.SendCalls -eq 1 -and $h.CreateCalls -eq 1) 'Exactly one MailItem and one Send call are allowed.'
    Assert-Transport $h.SawAttemptingBeforeSend 'Durable attempting event must exist before Send executes.'
    Assert-Transport ([object]::ReferenceEquals($h.Mail.SendUsingAccount, $h.Account)) 'The selected account must be attached explicitly.'
    Assert-Transport ($h.AddedRecipients.Count -eq 2 -and @($h.AddedRecipients | Where-Object { $_.Type -ne 1 }).Count -eq 0) 'Both validated recipients must be To recipients.'
    Assert-Transport ($h.Mail.Subject -eq $m.Subject -and $h.Mail.Body -eq $m.Body -and $h.Mail.BodyFormat -eq 1) 'The intended plain-text message must be preserved.'
    Assert-Transport ($h.Mail.Importance -eq 1) 'Neutral Importance=1 must be preserved.'
    Assert-Transport (-not [string]::IsNullOrWhiteSpace($m.SubmittedAt) -and $m.Error -eq '') 'Successful submission must record its timestamp without an error.'
    $events = @(Read-MockEvents $h)
    Assert-Transport (($events.Status -join ',') -eq 'attempting,submitted') 'Success journal must record intent followed by submission.'
    $repeatBlocked = $false
    try { $null = Invoke-MockSubmission $h $m } catch { $repeatBlocked = $true }
    Assert-Transport ($repeatBlocked -and $h.SendCalls -eq 1) 'A submitted message must never be sent again.'
    Complete-TransportCase 'successful submission, write-ahead order, explicit account, and retry prevention'

    # Native Outlook priority values must reach the mail object unchanged.
    foreach ($importance in @(0, 2)) {
        $h = New-MockOutlook ('importance-' + $importance)
        $m = New-MockMessage
        $m.OutlookImportance = $importance
        $r = Invoke-MockSubmission $h $m
        Assert-Transport ($r.Status -eq 'submitted' -and $h.Mail.Importance -eq $importance) ('Native Importance=' + $importance + ' must be preserved.')
    }
    Complete-TransportCase 'optional native low and high priorities'

    # Account identity is checked again immediately before creating the mail.
    $h = New-MockOutlook 'account-changed'
    $m = New-MockMessage
    $h.Account.SmtpAddress = 'different@example.invalid'
    $r = Invoke-MockSubmission $h $m
    Assert-Transport ($r.Status -eq 'failed' -and $r.Halt) 'A changed account must stop as definitely not submitted.'
    Assert-Transport ($h.CreateCalls -eq 0 -and $h.SendCalls -eq 0) 'A changed account must never create or send a message.'
    Complete-TransportCase 'account mismatch blocks sending'

    $h = New-MockOutlook 'duplicate-recipient'
    $m = New-MockMessage
    $r = Invoke-MockSubmission $h $m @('same@example.invalid', 'SAME@example.invalid')
    Assert-Transport ($r.Status -eq 'failed' -and $h.CreateCalls -eq 0 -and $h.SendCalls -eq 0) 'Duplicate recipients must fail before MailItem creation.'
    Complete-TransportCase 'duplicate recipients block sending'

    $h = New-MockOutlook 'invalid-recipient'
    $m = New-MockMessage
    $r = Invoke-MockSubmission $h $m @('not-an-email-address')
    Assert-Transport ($r.Status -eq 'failed' -and $h.CreateCalls -eq 0 -and $h.SendCalls -eq 0) 'Invalid recipients must fail before MailItem creation.'
    Complete-TransportCase 'invalid recipients block sending'

    $h = New-MockOutlook 'create-fails'
    $m = New-MockMessage
    $h.CreateThrows = $true
    $r = Invoke-MockSubmission $h $m
    Assert-Transport ($r.Status -eq 'failed' -and $r.Halt -and $h.SendCalls -eq 0) 'CreateItem failure must be definitely not submitted.'
    $events = @(Read-MockEvents $h)
    Assert-Transport (($events.Status -join ',') -eq 'failed') 'CreateItem failure must not record an attempting event.'
    Complete-TransportCase 'MailItem creation failure'

    $h = New-MockOutlook 'add-fails'
    $m = New-MockMessage
    $h.AddThrows = $true
    $r = Invoke-MockSubmission $h $m
    Assert-Transport ($r.Status -eq 'failed' -and $r.Halt -and $h.SendCalls -eq 0) 'Recipient creation failure must be definitely not submitted.'
    Complete-TransportCase 'recipient creation failure'

    $h = New-MockOutlook 'resolve-fails'
    $m = New-MockMessage
    $h.ResolveResult = $false
    $r = Invoke-MockSubmission $h $m
    Assert-Transport ($r.Status -eq 'failed' -and $r.Halt -and $h.SendCalls -eq 0) 'Unresolved recipients must prevent Send.'
    Assert-Transport ($h.ResolveCalls -eq 1) 'Recipient resolution must be checked once.'
    Complete-TransportCase 'recipient resolution failure'

    # A directory in place of the journal reliably rejects the append.
    $h = New-MockOutlook 'intent-journal-fails'
    $m = New-MockMessage
    [void][IO.Directory]::CreateDirectory($h.EventPath)
    $r = Invoke-MockSubmission $h $m
    Assert-Transport ($r.Status -eq 'failed' -and $r.Halt) 'An unwritable write-ahead journal must stop the batch.'
    Assert-Transport ($h.SendCalls -eq 0) 'Send must never execute without a recorded intent.'
    Complete-TransportCase 'write-ahead journal failure prevents Send'

    # An exception from Send cannot establish whether Outlook accepted the mail.
    $h = New-MockOutlook 'send-ambiguous'
    $m = New-MockMessage
    $h.SendThrows = $true
    $r = Invoke-MockSubmission $h $m
    Assert-Transport ($r.Status -eq 'unknown' -and $m.Status -eq 'unknown' -and $r.Halt) 'A Send exception must be unknown and halt the batch.'
    Assert-Transport ($h.SendCalls -eq 1 -and $h.SawAttemptingBeforeSend) 'Ambiguous Send must still have exactly one attempt and prior intent.'
    Assert-Transport ([string]::IsNullOrWhiteSpace($m.SubmittedAt)) 'An ambiguous Send must not claim a confirmed submission timestamp.'
    $events = @(Read-MockEvents $h)
    Assert-Transport (($events.Status -join ',') -eq 'attempting,unknown') 'Ambiguous Send journal must preserve the uncertainty.'
    $repeatBlocked = $false
    try { $null = Invoke-MockSubmission $h $m } catch { $repeatBlocked = $true }
    Assert-Transport ($repeatBlocked -and $h.SendCalls -eq 1) 'An unknown message must never be retried automatically.'
    Complete-TransportCase 'ambiguous Send outcome and retry prevention'

    # Simulate a filesystem failure strictly after the fake Send has returned.
    $h = New-MockOutlook 'result-journal-fails'
    $m = New-MockMessage
    $h.BreakJournalAfterSend = $true
    $r = Invoke-MockSubmission $h $m
    Assert-Transport ($r.Status -eq 'submitted' -and $m.Status -eq 'submitted' -and $r.Halt) 'A post-Send journal failure must retain confirmed submission and halt.'
    Assert-Transport ($h.SendCalls -eq 1 -and $h.SawAttemptingBeforeSend) 'Post-Send failure must not invoke Send again.'
    Assert-Transport (-not [string]::IsNullOrWhiteSpace($m.SubmittedAt) -and -not [string]::IsNullOrWhiteSpace($m.Error)) 'Post-Send failure must preserve timestamp and a visible logging warning.'
    Assert-Transport ([IO.File]::Exists($h.EventPath + '.before_failure')) 'The injected fault must preserve the prior attempting evidence.'
    $repeatBlocked = $false
    try { $null = Invoke-MockSubmission $h $m } catch { $repeatBlocked = $true }
    Assert-Transport ($repeatBlocked -and $h.SendCalls -eq 1) 'Known submitted mail must remain protected after a logging failure.'
    Complete-TransportCase 'post-Send journal failure retains submission and prevents retry'

    Write-Host ('TRANSPORT_MOCK_TESTS=PASS; CASES=' + $script:CaseCount + '; ASSERTIONS=' + $script:CheckCount + '; REAL_MAILS_SENT=0')
} finally {
    if ([IO.Directory]::Exists($testRoot)) {
        Remove-Item -LiteralPath $testRoot -Recurse -Force -ErrorAction Stop
    }
}
