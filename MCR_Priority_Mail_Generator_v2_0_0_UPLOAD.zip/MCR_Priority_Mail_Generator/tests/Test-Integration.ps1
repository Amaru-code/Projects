﻿#requires -Version 5.1
[CmdletBinding()]
param()
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
Import-Module (Join-Path $root 'lib/PriorityMail.Core.psm1') -Force
Import-Module (Join-Path $root 'lib/PriorityMail.Outlook.psm1') -Force
$dir=Join-Path ([IO.Path]::GetTempPath()) ('MCR-V2-Integration-'+[guid]::NewGuid().ToString('N'))
function Check([bool]$Ok,[string]$Why){if(-not $Ok){throw ('FAIL Integration: '+$Why)}}
try{
    $batch=New-TestMailBatch -Total 50 -Recipients @('first.last@example.test','second.person@example.test') -TemplatePath (Join-Path $root 'tests/fixtures/templates.baseline.json') -SenderRulesPath (Join-Path $root 'tests/fixtures/absender.baseline.md') -SettingsPath (Join-Path $root 'tests/fixtures/generator_settings.baseline.json') -Seed 718 -SenderSmtp 'test.sender@example.test'
    $null=Save-TestMailPlan -Batch $batch -Directory $dir
    $hash=Get-FileSha256 (Join-Path $dir 'plan.json')
    $expectedHash=Get-FileSha256 (Join-Path $dir 'expected_priorities.csv')
    $capture=[pscustomobject]@{SendCalls=0;RecipientCount=0;ToCount=0;CcCount=0;LastBody='';LastImportance=0}
    $outlook=[pscustomobject]@{Capture=$capture}
    $outlook | Add-Member ScriptMethod CreateItem {
        param($kind)
        if($kind -ne 0){throw 'Only MailItem allowed'}
        $recipients=[pscustomobject]@{Capture=$this.Capture;Items=(New-Object 'System.Collections.Generic.List[object]')}
        $recipients | Add-Member ScriptMethod Add {param($a);$r=[pscustomobject]@{Address=$a;Type=0};[void]$this.Items.Add($r);return $r}
        $recipients | Add-Member ScriptMethod ResolveAll {return $true}
        $mail=[pscustomobject]@{Capture=$this.Capture;Subject='';Body='';BodyFormat=0;Importance=1;SendUsingAccount=$null;Recipients=$recipients}
        $mail | Add-Member ScriptMethod Send {
            $this.Capture.SendCalls++
            $this.Capture.LastBody=$this.Body;$this.Capture.LastImportance=$this.Importance
            foreach($r in $this.Recipients.Items){
                $this.Capture.RecipientCount++
                if($r.Type -eq 1){$this.Capture.ToCount++}elseif($r.Type -eq 2){$this.Capture.CcCount++}else{throw 'Invalid recipient role'}
            }
        }
        return $mail
    }
    $account=[pscustomobject]@{SmtpAddress='test.sender@example.test'}
    foreach($m in $batch.Messages){
        $o=Invoke-TestMailSubmission -Message $m -Recipients $batch.Recipients -Outlook $outlook -Account $account -AccountSmtp $account.SmtpAddress -EventPath (Join-Path $dir 'events.jsonl')
        Check (-not $o.Halt -and $m.Status -eq 'submitted') 'Successful mock submission'
    }
    $null=Save-TestMailResult $batch $dir
    $null=Save-TestMailResult $batch $dir
    $s=Get-TestMailSummary $batch
    Check ($capture.SendCalls -eq 50 -and $s.submitted -eq 50) 'Exactly 50 sends'
    Check ($capture.RecipientCount -eq 100) 'Only two authorized recipients per message'
    $ccMessages=@($batch.Messages | Where-Object {$_.RecipientRole -eq 'cc'}).Count
    Check ($capture.CcCount -eq $ccMessages*2) 'CC transport matches planned metadata'
    Check ($capture.ToCount -eq (50-$ccMessages)*2) 'TO transport matches planned metadata'
    Check (($s.UrgentSubmitted+$s.ImportantSubmitted+$s.InfoSubmitted+$s.IgnoreSubmitted) -eq 50) 'Four popup counters sum'
    Check ((Get-FileSha256 (Join-Path $dir 'plan.json')) -ceq $hash) 'Plan not changed by result writes'
    Check ((Get-FileSha256 (Join-Path $dir 'expected_priorities.csv')) -ceq $expectedHash) 'Expected labels remain immutable'
    $rows=@(Import-Csv -LiteralPath (Join-Path $dir 'results.csv') -Delimiter ';' -Encoding UTF8)
    Check ($rows.Count -eq 50) 'CSV roundtrip'
    Check (@($rows | Where-Object {$_.Status -ne 'submitted'}).Count -eq 0) 'CSV states'
    $events=@(Get-Content -LiteralPath (Join-Path $dir 'events.jsonl') | ForEach-Object {$_ | ConvertFrom-Json})
    Check ($events.Count -eq 100) 'Attempt and submission event per message'
    $replayBlocked=$false
    try{$null=Invoke-TestMailSubmission -Message $batch.Messages[0] -Recipients $batch.Recipients -Outlook $outlook -Account $account -AccountSmtp $account.SmtpAddress -EventPath (Join-Path $dir 'events.jsonl')}catch{$replayBlocked=$true}
    Check $replayBlocked 'No repeated send for processed message'
    Write-Host 'PASS Integration: 50 mock sends, two recipients, real TO/CC assignments on mocks, four counters, CSV and durable journal.'
    $offline=Join-Path $dir 'offline'
    & (Join-Path $root 'Export-OfflineCases.ps1') -Recipient 'first.last@example.test' -ReferenceDate ([datetime]'2026-10-09T12:00:00') -OutputDirectory $offline | Out-Null
    $inputs=@(ConvertFrom-Json -InputObject ([IO.File]::ReadAllText((Join-Path $offline 'offline_messages.json'))))
    $oracle=@(ConvertFrom-Json -InputObject ([IO.File]::ReadAllText((Join-Path $offline 'offline_expected.json'))))
    Check ($inputs.Count -eq 24 -and $oracle.Count -eq 21) 'Offline 24 messages / 21 cases'
    Check ([IO.File]::ReadAllText((Join-Path $offline 'offline_messages.json')) -notmatch 'ExpectedPriority|expected_priority|ExpectedReason') 'No oracle labels in scanner input'
    Check (@($inputs | Where-Object {$_.Body -notmatch '^Hallo First,'}).Count -eq 0) 'Offline personalization'
    Check (@($oracle | Where-Object {-not $_.ExpectedInScope}).Count -eq 5) 'Five out-of-scope cases'
    Write-Host 'PASS Offline export: VIP, sender exceptions, threads, Sent-reply evidence, scope and attachment metadata; no Outlook involved.'
} finally {
    if([IO.Directory]::Exists($dir)){Remove-Item -LiteralPath $dir -Recurse -Force}
}
