﻿#requires -Version 5.1
[CmdletBinding()]
param()
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
Import-Module (Join-Path $root 'lib/PriorityMail.Core.psm1') -Force
$script:checks=0
function Assert-True([bool]$Ok,[string]$Message) { if(-not $Ok){throw ('FAIL: '+$Message)};$script:checks++ }
function Assert-Throws([scriptblock]$Action,[string]$Message){$threw=$false;try{& $Action | Out-Null}catch{$threw=$true};Assert-True $threw $Message}
$tpath=Join-Path $root 'tests/fixtures/templates.baseline.json'
$rpath=Join-Path $root 'tests/fixtures/absender.baseline.md'
$spath=Join-Path $root 'tests/fixtures/generator_settings.baseline.json'
$before=Get-FileSha256 $rpath
$templates=Get-TestMailTemplates $tpath
$rules=Read-TestSenderRules $rpath
$settings=Get-GeneratorSettings $spath
$labels=@('urgent','important','info','ignore')
foreach($p in $labels){Assert-True (@($templates.classes.$p).Count -eq 12) ('12 templates: '+$p)}
foreach($p in $labels){foreach($t in $templates.classes.$p){
    $a=Get-TestScenarioPriority -Template $t -Rules $rules -Subject $t.subject -SenderSmtp 'test.sender@example.test'
    Assert-True ($a.Priority -eq $p) ('Default scenario oracle '+$t.id)
}}
foreach($pair in @(
    @('amaru.zegarra@example.test','Amaru','Amaru Zegarra'),
    @('anna-lena.muster@example.test','Anna-Lena','Anna-Lena Muster'),
    @('MAX.MUSTERMANN@example.test','Max','Max Mustermann'),
    @('lena.meyer+test@example.test','Lena','Lena Meyer'),
    @('hans.peter.meyer@example.test','Hans','Hans Peter Meyer'),
    @('joerg.mueller@example.test','Joerg','Joerg Mueller')
)) {
    $n=Get-RecipientName $pair[0]
    Assert-True ($n.FirstName -ceq $pair[1] -and $n.FullName -ceq $pair[2]) ('Name '+$pair[0])
}
Assert-Throws {Get-RecipientName 'team@example.test'} 'No guessed name for non-person address'
Assert-Throws {Get-RecipientName 'first.last@example.test;second.last@example.test'} 'Name accepts one address'
Assert-Throws {Get-RecipientName 'first.123@example.test'} 'Ambiguous numeric name rejected'
Assert-Throws {ConvertTo-TestRecipients 'x <first.last@example.test>'} 'No display-name injection'
Assert-Throws {ConvertTo-TestRecipients "first.last@example.test`r`nBcc: hidden@example.test"} 'Header injection rejected'
$a=@(ConvertTo-TestRecipients 'first.last@example.test;FIRST.LAST@EXAMPLE.TEST;other.person@example.test')
Assert-True ($a.Count -eq 2) 'Recipient deduplication'
Assert-True ((Add-TestWorkingDays ([datetime]'2026-10-09') 2 $settings).ToString('yyyy-MM-dd') -eq '2026-10-13') 'Friday +2 workdays is Tuesday'
$holidaySettings=[pscustomobject]@{working_days=@(1,2,3,4,5);holidays=@('2026-10-12')}
Assert-True ((Add-TestWorkingDays ([datetime]'2026-10-09') 2 $holidaySettings).ToString('yyyy-MM-dd') -eq '2026-10-14') 'Configured holiday is excluded'
Assert-True ((Add-TestWorkingDays ([datetime]'2026-10-12') -1 $settings).ToString('yyyy-MM-dd') -eq '2026-10-09') 'Negative working-day offset'
foreach($total in @(1,2,3,4,5,10,50,100,10000)){
    $previous=$null
    for($seed=0;$seed -lt 30;$seed++){
        $random=New-Object System.Random($seed)
        $c=Get-RandomPriorityCounts -Total $total -Random $random -PreviousCounts $previous
        $sum=0;$same=$null -ne $previous
        foreach($p in $labels){
            $sum+=$c.$p
            Assert-True ($c.$p -ge 0) 'No negative counts'
            if($total -ge 5){Assert-True ($c.$p -ge 1) 'All four classes for N>=5'}
            if($null -eq $previous -or $c.$p -ne $previous.$p){$same=$false}
        }
        Assert-True ($sum -eq $total) 'Counts sum exactly'
        Assert-True (-not $same) 'No immediate repeated distribution'
        $previous=$c
    }
}
$cases=@($templates.classes.urgent)
$vip=[pscustomobject]@{Rules=@([pscustomobject]@{Group='vip';Field='email';Pattern='vip.person@example.test'})}
$always=[pscustomobject]@{Rules=@([pscustomobject]@{Group='info';Field='email';Pattern='info.person@example.test'})}
$ignored=[pscustomobject]@{Rules=@([pscustomobject]@{Group='ignore';Field='sender';Pattern='noreply'})}
Assert-True ((Get-TestScenarioPriority $templates.classes.info[0] $vip 'vip.person@example.test' '' 'Status').Priority -eq 'important') 'VIP minimum yellow'
Assert-True ((Get-TestScenarioPriority $templates.classes.important[0] $vip 'vip.person@example.test' '' 'Frist').Priority -eq 'urgent') 'VIP deadline makes red'
Assert-True ((Get-TestScenarioPriority $cases[0] $always 'info.person@example.test' '' 'Frage').Priority -eq 'info') 'Always-blue override'
Assert-True ((Get-TestScenarioPriority $cases[0] $ignored 'noreply@example.test' '' 'Frage').Priority -eq 'ignore') 'Ignore sender before general direct request'
Assert-True ((Get-TestScenarioPriority $templates.classes.important[0] $ignored 'noreply@example.test' '' 'Persönliche Pflichtschulung').Priority -eq 'important') 'Personal distant HR deadline beats ignore'
Assert-True ((Get-TestScenarioPriority $templates.classes.urgent[5] $ignored 'noreply@example.test' '' 'Persönliche Pflichtschulung').Priority -eq 'urgent') 'Overdue personal HR deadline beats ignore'
$conflict=[pscustomobject]@{Rules=@($vip.Rules[0],[pscustomobject]@{Group='ignore';Field='email';Pattern='vip.person@example.test'})}
Assert-Throws {Get-TestScenarioPriority $cases[0] $conflict 'vip.person@example.test' '' 'Frage'} 'Conflicting explicit sender policies fail closed'
$batchArgs=@{Total=50;Recipients=@('amaru.zegarra@example.test');TemplatePath=$tpath;SenderRulesPath=$rpath;SettingsPath=$spath;Seed=29;ReferenceDate=[datetime]'2026-10-09T10:00:00';SenderSmtp='test.sender@example.test'}
$b=New-TestMailBatch @batchArgs
Assert-True ($b.Messages.Count -eq 50) 'Exactly 50 messages'
Assert-True (@($b.Messages.TestId | Select-Object -Unique).Count -eq 50) 'Unique message IDs'
foreach($p in $labels){Assert-True (@($b.Messages | Where-Object {$_.ExpectedPriority -eq $p}).Count -eq $b.Counts.$p) 'Message labels match counts'}
foreach($m in $b.Messages){
    Assert-True ($m.Body.StartsWith('Hallo Amaru,')) 'Every greeting personalized'
    Assert-True ($m.Body -notmatch '\{[a-z_]+\}') 'No unresolved placeholders'
    Assert-True ($m.OutlookImportance -eq 1) 'Neutral Outlook importance default'
    Assert-True ($m.Subject -notmatch '\bR[0-9]{2}\b|\bY[0-9]{2}\b|\bB[0-9]{2}\b|\bW[0-9]{2}\b') 'No answer label in subject'
    Assert-True ($m.RecipientRole -ne 'cc' -or $m.ExpectedPriority -eq 'info') 'CC-only scenarios are informational'
}
$batchArgs.Recipients=@('amaru.zegarra@example.test','anna-lena.muster@example.test');$batchArgs.Total=5
$b2=New-TestMailBatch @batchArgs
Assert-True ($b2.Messages[0].Body.StartsWith('Hallo Amaru und Anna-Lena,')) 'Multi-recipient greeting'
Assert-True ($b2.Messages.Count -eq 5 -and $b2.Recipients.Count -eq 2) 'N messages with all confirmed recipients, not N per recipient'
Assert-True ((Get-FileSha256 $rpath) -ceq $before) 'Sender policy not modified'
$raw=[IO.File]::ReadAllText((Join-Path $root 'lib/PriorityMail.Outlook.psm1'))
Assert-True ($raw -notmatch '(?im)\.\s*(?:Reply|ReplyAll|Forward|Delete|Move|Save|SendOnBehalfOfName|UnRead|Categories)\s*(?:\(|=)') 'Transport does not mutate existing messages or spoof sender'
Write-Host ('PASS Core: '+$script:checks+' assertions; no Outlook used.')
