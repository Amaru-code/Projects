﻿#requires -Version 5.1
[CmdletBinding()]
param([string]$Recipient='', [datetime]$ReferenceDate=(Get-Date), [string]$OutputDirectory='')
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSScriptRoot 'lib/PriorityMail.Core.psm1') -ErrorAction Stop
if(-not $Recipient){$Recipient=Read-Host 'Eine Testadresse im Format vorname.nachname@domain'}
$person=Get-RecipientName $Recipient
$rules=Read-TestSenderRules (Join-Path $PSScriptRoot 'data/absender.test.md')
$settings=Get-GeneratorSettings (Join-Path $PSScriptRoot 'config/generator_settings.json')
$root=ConvertFrom-Json -InputObject ([IO.File]::ReadAllText((Join-Path $PSScriptRoot 'data/offline_cases.json'),[Text.Encoding]::UTF8))
$run='OFFLINE-'+[datetime]::UtcNow.ToString('yyyyMMddTHHmmssfff')+'-'+[guid]::NewGuid().ToString('N').Substring(0,8)
if(-not $OutputDirectory){$OutputDirectory=Join-Path (Join-Path $PSScriptRoot 'Output') $run}
if([IO.Directory]::Exists($OutputDirectory) -and [IO.Directory]::GetFileSystemEntries($OutputDirectory).Length -gt 0){throw 'Ausgabeordner muss leer sein.'}
[void][IO.Directory]::CreateDirectory($OutputDirectory)
$messages=New-Object 'System.Collections.Generic.List[object]'
$expected=New-Object 'System.Collections.Generic.List[object]'
$number=0
foreach($case in $root.cases){
    $number++
    $threadId=$run+'-T'+$number.ToString('D3')
    $messageNumber=0
    foreach($m in $case.messages){
        $tokens=[ordered]@{greeting=('Hallo '+$person.FirstName+',');name=$person.FirstName;full_name=$person.FullName;email=$person.Email;due_date='unklar';meeting_date='unklar';past_date=$ReferenceDate.AddDays(-3).ToString('dd.MM.yyyy')}
        if($null -ne $m.deadline_workdays){$tokens.due_date=(Add-TestWorkingDays $ReferenceDate ([int]$m.deadline_workdays) $settings).ToString('dd.MM.yyyy')}
        if($null -ne $m.meeting_workdays){$tokens.meeting_date=(Add-TestWorkingDays $ReferenceDate ([int]$m.meeting_workdays) $settings).ToString('dd.MM.yyyy')}
        $to=@();$cc=@()
        if($m.folder -eq 'Sent'){$to=@('team.member@example.test')}
        elseif($m.role -eq 'cc'){$cc=@($person.Email)}else{$to=@($person.Email)}
        $stamp=$ReferenceDate.Date.AddDays(-[int]$m.days_ago).AddHours(10).AddMinutes($messageNumber)
        $internetId=$threadId+'-M'+$messageNumber+'@example.test'
        if($case.title -eq 'Original-Selbstversand ist keine Antwort'){
            $to=@($person.Email);$cc=@();$internetId=$threadId+'-original@example.test'
            if($m.folder -eq 'Sent'){$stamp=$stamp.AddMinutes(-2)}
        }
        $received='';$sent=''
        if($m.folder -eq 'Sent'){$sent=$stamp.ToString('s')}else{$received=$stamp.ToString('s')}
        $meetingStart=''
        if($null -ne $m.meeting_workdays){$meetingStart=(Add-TestWorkingDays $ReferenceDate ([int]$m.meeting_workdays) $settings).AddHours(10).ToString('s')}
        $reply=''
        if($null -ne $m.reply_to_message){$reply=$threadId+'-M'+[string]$m.reply_to_message}
        [void]$messages.Add([pscustomobject][ordered]@{
            MessageId=($threadId+'-M'+$messageNumber);ConversationId=$threadId;InternetMessageId=$internetId;
            Sender=(Expand-TestMailTokens $m.sender $tokens);To=$to;Cc=$cc;
            Subject=(Expand-TestMailTokens $m.subject $tokens);Body=(Expand-TestMailTokens $m.body $tokens);
            Folder=$m.folder;Unread=[bool]$m.unread;ReceivedAt=$received;SentAt=$sent;
            Importance=1;ItemClass=$m.item_class;Attachments=@($m.attachments);HasAttachments=(@($m.attachments).Count -gt 0);MeetingStartLocal=$meetingStart;RequiredAttendee=[bool]$m.required_attendee;InReplyTo=$reply
        })
        $messageNumber++
    }
    [void]$expected.Add([pscustomobject][ordered]@{
        ConversationId=$threadId;InternetMessageId=$internetId;ExpectedInScope=$case.expected_in_scope;ExpectedPriority=$case.expected_priority;
        ExpectedReason=$case.expected_reason;DoneBy=([string]$case.done_by).Replace('{full_name}',$person.FullName);AlreadyAnswered=$case.answered;CaseDescription=$case.title
    })
}
Write-DurableUtf8File (Join-Path $OutputDirectory 'offline_messages.json') (ConvertTo-Json -InputObject $messages.ToArray() -Depth 15)
Write-DurableUtf8File (Join-Path $OutputDirectory 'offline_expected.json') (ConvertTo-Json -InputObject $expected.ToArray() -Depth 12)
Write-DurableUtf8File (Join-Path $OutputDirectory 'absender.test.md') $rules.Text
$scope=[pscustomobject]@{UserEmail=$person.Email;AssessmentTime=$ReferenceDate.ToString('s');Scope='Default: unread Inbox, last 14 days; Sent only as supporting reply evidence';SenderRules='absender.test.md';InputFile='offline_messages.json';OracleMustBeWithheld='offline_expected.json';WorkingCalendar=$settings;RealEmailsSent=0;OutlookUsed=$false}
Write-DurableUtf8File (Join-Path $OutputDirectory 'offline_scope.json') (ConvertTo-Json $scope -Depth 12)
Write-Host ('OFFLINE_EXPORT=COMPLETE; CASES='+$expected.Count+'; MESSAGES='+$messages.Count+'; REAL_MAILS_SENT=0')
Write-Host ('Dateien: '+[IO.Path]::GetFullPath($OutputDirectory))
Write-Host 'JSON-Testdaten, KEIN Outlook-Import. Nur offline_messages.json + scope + absender.test.md an den Test-Scanner geben; Oracle separat vergleichen.'
