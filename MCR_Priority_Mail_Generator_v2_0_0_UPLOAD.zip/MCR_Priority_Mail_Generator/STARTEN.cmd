@echo off
setlocal
title MCR Priority Mail Generator
cd /d "%~dp0"
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0PriorityMailGenerator.ps1"
set "MCR_MAIL_EXIT=%ERRORLEVEL%"
if "%MCR_MAIL_EXIT%"=="0" exit /b 0
echo.
echo Das Tool konnte nicht vollstaendig ausgefuehrt werden.
echo Hinweise zur obigen Meldung stehen in LIES_MICH.txt.
echo Bitte das ZIP vollstaendig entpacken und klassisches Outlook verwenden.
pause
exit /b %MCR_MAIL_EXIT%
