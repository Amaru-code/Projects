[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][Alias('Case')][ValidateNotNullOrEmpty()][string]$CaseId,
    [Parameter(Mandatory=$true)][Alias('Input')][ValidateNotNullOrEmpty()][string]$InputPath,
    [Parameter(Mandatory=$true)][Alias('Template')][ValidateNotNullOrEmpty()][string]$TemplatePath,
    [Parameter(Mandatory=$true)][Alias('Output')][ValidateNotNullOrEmpty()][string]$OutputPath,
    [int]$Workers = 4
)

$ErrorActionPreference='Stop'
$ModeRoot=$PSScriptRoot
$BuildRoot=Join-Path $ModeRoot 'build'
$Publish=Join-Path $BuildRoot 'publish'
$JavaPointer=Join-Path $BuildRoot 'java_path.txt'
$MainClass=Join-Path $Publish 'Main.class'

if(-not(Test-Path $MainClass -PathType Leaf)){throw "Java Candidate wurde noch nicht gebaut: $MainClass"}
if(-not(Test-Path $JavaPointer -PathType Leaf)){throw 'java_path.txt fehlt. build.ps1 zuerst ausfuehren.'}
$Java=(Get-Content $JavaPointer -Raw).Trim()
if(-not(Test-Path $Java -PathType Leaf)){throw "Java Runtime fehlt: $Java"}

Write-Host 'Java Candidate Wrapper'
Write-Host "Case:     [$CaseId]"
Write-Host "Input:    [$InputPath]"
Write-Host "Template: [$TemplatePath]"
Write-Host "Output:   [$OutputPath]"
Write-Host "Workers:  [$Workers]"
Write-Host "Runtime:  [$Java]"

if(Test-Path $OutputPath){
    Get-ChildItem $OutputPath -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force
}else{
    New-Item -ItemType Directory -Force -Path $OutputPath | Out-Null
}

$Args = @(
    '-cp',[string]$Publish,
    'Main',
    '--case',[string]$CaseId,
    '--input',[string]$InputPath,
    '--template',[string]$TemplatePath,
    '--output',[string]$OutputPath,
    '--workers',[string]$Workers
)

& $Java @Args
$Code=$LASTEXITCODE
if($null -eq $Code){throw 'Java Candidate returned no exit code.'}
exit [int]$Code
