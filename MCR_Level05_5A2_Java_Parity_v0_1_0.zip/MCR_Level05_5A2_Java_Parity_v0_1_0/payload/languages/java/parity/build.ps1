[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$ModeRoot = $PSScriptRoot
$SrcRoot = Join-Path $ModeRoot 'src'
$BuildRoot = Join-Path $ModeRoot 'build'
$Publish = Join-Path $BuildRoot 'publish'
$JavaPointer = Join-Path $BuildRoot 'java_path.txt'
$JavacPointer = Join-Path $BuildRoot 'javac_path.txt'
$MainSource = Join-Path $SrcRoot 'Main.java'

function Test-JavaPair {
    param([string]$Java,[string]$Javac)
    if (-not $Java -or -not $Javac) { return $false }
    if (-not (Test-Path $Java -PathType Leaf) -or -not (Test-Path $Javac -PathType Leaf)) { return $false }
    $old=$ErrorActionPreference; $ErrorActionPreference='Continue'
    try {
        & $Java -version *> $null
        $j=$LASTEXITCODE
        & $Javac -version *> $null
        $c=$LASTEXITCODE
    } finally { $ErrorActionPreference=$old }
    return ($j -eq 0 -and $c -eq 0)
}

$Pairs = New-Object System.Collections.Generic.List[object]

$JavaCmd = Get-Command java.exe -ErrorAction SilentlyContinue
$JavacCmd = Get-Command javac.exe -ErrorAction SilentlyContinue
if ($JavaCmd -and $JavacCmd) {
    $Pairs.Add([PSCustomObject]@{java=$JavaCmd.Source; javac=$JavacCmd.Source})
}

if ($env:USERPROFILE) {
    $Compiler = Join-Path $env:USERPROFILE 'projects\Compiler\java'
    if (Test-Path $Compiler) {
        Get-ChildItem $Compiler -Recurse -Filter javac.exe -File -ErrorAction SilentlyContinue |
            ForEach-Object {
                $bin = Split-Path $_.FullName -Parent
                $java = Join-Path $bin 'java.exe'
                if (Test-Path $java -PathType Leaf) {
                    $Pairs.Add([PSCustomObject]@{java=$java; javac=$_.FullName})
                }
            }
    }
}

$Selected=$null
foreach($Pair in $Pairs) {
    if(Test-JavaPair $Pair.java $Pair.javac) { $Selected=$Pair; break }
}
if(-not $Selected) {
    throw 'Vorhandene Java/JDK Runtime mit java.exe + javac.exe wurde nicht gefunden. Es wird nichts heruntergeladen.'
}

$Java=$Selected.java
$Javac=$Selected.javac

Write-Host '============================================================'
Write-Host ' Level 05A.2 - Java Parity Build'
Write-Host '============================================================'
Write-Host "java:      $Java"
& $Java -version
Write-Host "javac:     $Javac"
& $Javac -version
Write-Host "Source:    $MainSource"
Write-Host "Publish:   $Publish"
Write-Host ''
Write-Host 'Dependencies: existing JDK + Java standard library only / OFFLINE'
Write-Host 'Native candidate EXE generation: NONE'
Write-Host ''

if(Test-Path $Publish){ Remove-Item $Publish -Recurse -Force }
New-Item -ItemType Directory -Force -Path $Publish | Out-Null

& $Javac -encoding UTF-8 -d $Publish $MainSource
$Code=$LASTEXITCODE
if($Code -ne 0){ throw "Java Build fehlgeschlagen. ExitCode=$Code" }

Copy-Item (Join-Path $SrcRoot 'excel_bridge.ps1') (Join-Path $Publish 'excel_bridge.ps1') -Force
New-Item -ItemType Directory -Force -Path (Join-Path $Publish 'resources') | Out-Null
Copy-Item (Join-Path $SrcRoot 'resources\settings.json') (Join-Path $Publish 'resources\settings.json') -Force
Copy-Item (Join-Path $SrcRoot 'resources\wwid_mapping.csv') (Join-Path $Publish 'resources\wwid_mapping.csv') -Force

New-Item -ItemType Directory -Force -Path $BuildRoot | Out-Null
Set-Content $JavaPointer $Java -Encoding UTF8
Set-Content $JavacPointer $Javac -Encoding UTF8

$MainClass = Join-Path $Publish 'Main.class'
if(-not(Test-Path $MainClass -PathType Leaf)){ throw "Java Build erzeugte kein Main.class: $MainClass" }

Write-Host ''
Write-Host 'JAVA PARITY BUILD: PASS' -ForegroundColor Green
Write-Host "MAIN CLASS: $MainClass"
Write-Host 'Runtime: existing java.exe (no new native EXE)' -ForegroundColor Green
exit 0
