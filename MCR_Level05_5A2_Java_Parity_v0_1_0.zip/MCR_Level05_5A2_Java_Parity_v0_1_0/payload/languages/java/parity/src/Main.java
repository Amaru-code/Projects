import java.io.*;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.charset.*;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;
import java.util.zip.*;

public class Main {
    static final String CASE_ID = "MCR_LNW_001";
    static final String SEP = "\u0000";

    static final class Options {
        String caseId = CASE_ID;
        Path inputDir, templatePath, outputDir;
        int workers = 4;
    }

    static final class Settings {
        List<String> allowedCompanyIds;
        int companyIdColumnIndex;
        List<String> duTargetHeaders;
        List<String> dpTargetHeaders;
    }

    static final class Table {
        List<String> header;
        List<List<String>> rows;
        String sourceName;
        Table(List<String> header, List<List<String>> rows, String sourceName) {
            this.header = header; this.rows = rows; this.sourceName = sourceName;
        }
    }

    static final class PipelineResult {
        Path duMaster, dpMaster, lnwExcel, lnwCsv;
        int duRows, dpRows;
    }

    static final class GroupResult {
        Table table;
        List<String> errors;
        GroupResult(Table t, List<String> e) { table=t; errors=e; }
    }

    static final class ValuePair {
        double shares, value;
        ValuePair() {}
        ValuePair(double s, double v) { shares=s; value=v; }
    }

    static final class SnapshotRow {
        int row; String wwid; double[] prev;
        SnapshotRow(int row, String wwid, double[] prev) { this.row=row; this.wwid=wwid; this.prev=prev; }
    }

    static final class Snapshot {
        int headerRow, lastRow; List<SnapshotRow> rows = new ArrayList<>();
    }

    static final class WwidMapping {
        final Map<String,String> exact = new HashMap<>();
        final Map<String,String> depotFallback = new HashMap<>();
        final Map<String,Set<String>> conflicts = new HashMap<>();

        static WwidMapping load(Path path) throws Exception {
            String text = readUtf8Bom(path);
            String[] lines = text.split("\\r?\\n", -1);
            WwidMapping result = new WwidMapping();
            if (lines.length == 0 || lines[0].trim().isEmpty()) return result;
            List<String> header = parseDelimitedLine(lines[0].replace("\uFEFF", ""), ';');
            Map<String,Integer> fields = new HashMap<>();
            for (int i=0;i<header.size();i++) fields.put(header.get(i).trim().toLowerCase(Locale.ROOT), i);
            int wwidIdx = findField(fields,"WWID");
            int dep1Idx = findField(fields,"Depot_01","Depo_01");
            int dep2Idx = findField(fields,"Depot_02","Depo_02");
            int dep3Idx = findField(fields,"Depot_03","Depo_03");
            if (wwidIdx < 0 || dep1Idx < 0 || dep2Idx < 0 || dep3Idx < 0) throw new RuntimeException("WWID mapping header is incomplete.");
            Map<String,Set<String>> candidates = new HashMap<>();
            Map<String,Set<String>> depotCandidates = new HashMap<>();
            int[] idxs = {dep1Idx,dep2Idx,dep3Idx};
            for (int li=1; li<lines.length; li++) {
                if (lines[li].trim().isEmpty()) continue;
                List<String> row = parseDelimitedLine(lines[li], ';');
                String wwid = normalizeMappingWwid(at(row, wwidIdx));
                if (wwid.isEmpty()) continue;
                for (int j=0;j<3;j++) {
                    String depot = normalizeDepot(at(row,idxs[j]));
                    if (depot.isEmpty()) continue;
                    String under = String.valueOf(j+1);
                    String key = depot + SEP + under;
                    candidates.computeIfAbsent(key,k->new LinkedHashSet<>()).add(wwid);
                    depotCandidates.computeIfAbsent(depot,k->new LinkedHashSet<>()).add(wwid);
                }
            }
            for (Map.Entry<String,Set<String>> e: candidates.entrySet()) {
                if (e.getValue().size()==1) result.exact.put(e.getKey(), e.getValue().iterator().next());
                else result.conflicts.put(e.getKey(), e.getValue());
            }
            for (Map.Entry<String,Set<String>> e: depotCandidates.entrySet()) {
                if (e.getValue().size()==1) result.depotFallback.put(e.getKey(), e.getValue().iterator().next());
            }
            return result;
        }
        String resolve(String depot, String underdepot, String existingWwid) {
            String depotKey = normalizeDepot(depot);
            String underKey = normalizeUnderdepot(underdepot);
            String existing = normalizeMappingWwid(existingWwid);
            if (depotKey.isEmpty()) return existing;
            String k = depotKey + SEP + underKey;
            if (!underKey.isEmpty() && exact.containsKey(k)) return exact.get(k);
            if (!underKey.isEmpty() && conflicts.containsKey(k)) return existing;
            return depotFallback.getOrDefault(depotKey, existing);
        }
    }

    static final class TextParser {
        final Settings settings;
        final WwidMapping mapping;
        final Set<String> allowedCompanyIds;
        static final List<String> MARKER_PREFIXES = Arrays.asList(">>>>","<<<<",">>>","<<<","====");
        static final Set<String> METADATA_LABELS = new HashSet<>(Arrays.asList(
            "dateiname","datei name","info","informationen","groesse","größe","dateigroesse","dateigröße","typ","dateityp","erstellungsdatum","erstellt am","geaendert am","geändert am","aenderungsdatum","änderungsdatum"));
        static final Set<String> KNOWN_HEADER_TERMS = new HashSet<>(Arrays.asList(
            "erstellungsdatum","vermittlerzentrale","vermittlernummer","kundenidentifikator","kunden_identifikator","depotnummer","unterdepot","wkn","isin","kag","fondsname","depotvariante","anteilspreis","waehrungpreis","währungpreis","produktart","bestandstuecke","bestand_stuecke","bestandbetrag","bestand_betrag","firmenid","dat","wwid","umsatzstuecke","umsatz_stuecke","abgerechneterpreis","anlbetrag","zahlbetrag","umsatzart","devisenkurs","kursdatum","zvf_id_alt","zvu_id_alt","eroeffnungsdatum","währung_bestand","waehrung_bestand","schlusstag","bonus","status","id-mercer"));
        static final Set<String> DU_PROFILE_MARKERS = new HashSet<>(Arrays.asList("umsatzstuecke","abgerechneterpreis","anlbetrag","zahlbetrag","umsatzart","devisenkurs","zvfidalt","zvuidalt"));
        static final Set<String> DP_PROFILE_MARKERS = new HashSet<>(Arrays.asList("anteilspreis","eroeffnungsdatum","bestandstuecke","bestandbetrag","waehrungbestand","schlusstag","idmercer"));

        TextParser(Settings s, WwidMapping m) {
            settings=s; mapping=m; allowedCompanyIds=new HashSet<>();
            for(String x:s.allowedCompanyIds) allowedCompanyIds.add(normalizeCompanyId(x));
        }

        Table parseFile(Path file) throws Exception {
            String content = readTextWithFallback(file);
            List<List<String>> rows = parseTextRows(content);
            return extractTable(rows,true,true,file.getFileName().toString());
        }

        String detectTargetProfile(List<String> sourceHeader, int fallbackWidth, String sourceName) {
            String fp = profileFromFilename(sourceName);
            if (fp != null) return fp;
            Set<String> normalized = new HashSet<>();
            for(String x:sourceHeader) if(!x.trim().isEmpty()) normalized.add(normalizeHeader(x));
            int du=0, dp=0;
            for(String x:DU_PROFILE_MARKERS) if(normalized.contains(x)) du++;
            for(String x:DP_PROFILE_MARKERS) if(normalized.contains(x)) dp++;
            if(du>=2 && du>dp) return "du";
            if(dp>=2 && dp>du) return "dp";
            return fallbackWidth>=30 ? "du" : "dp";
        }

        Table extractTable(List<List<String>> rawRows, boolean fixedTargetHeader, boolean applyCompanyFilter, String sourceName) {
            List<List<String>> rows = removeNoiseRows(splitPackedRows(rawRows));
            if(rows.isEmpty()) {
                if(!fixedTargetHeader) return new Table(new ArrayList<>(),new ArrayList<>(),sourceName);
                String profile=detectTargetProfile(Collections.emptyList(),0,sourceName);
                return new Table(new ArrayList<>(profile.equals("du")?settings.duTargetHeaders:settings.dpTargetHeaders),new ArrayList<>(),sourceName);
            }
            Integer headerIndex=null;
            for(int i=0;i<Math.min(30,rows.size());i++) {
                if(headerMatchScore(rows.get(i),null)>=5 || looksLikeHeader(rows.get(i))) { headerIndex=i; break; }
            }
            List<String> detected = headerIndex!=null ? new ArrayList<>(rows.get(headerIndex)) : new ArrayList<>();
            List<String> header, sourceHeader; List<List<String>> dataRows; Integer sourceCompanyIndex,targetCompanyIndex; List<Integer> targetMapping; int width;
            if(fixedTargetHeader) {
                int sourceWidth = !detected.isEmpty()?detected.size():rows.stream().mapToInt(List::size).max().orElse(0);
                String profile=detectTargetProfile(detected,sourceWidth,sourceName);
                header=new ArrayList<>(profile.equals("du")?settings.duTargetHeaders:settings.dpTargetHeaders);
                dataRows=new ArrayList<>(rows.subList(headerIndex!=null?headerIndex+1:0,rows.size())); width=header.size(); sourceHeader=detected;
                sourceCompanyIndex=findCompanyIdColumn(sourceHeader,sourceHeader.size(),false);
                targetCompanyIndex=findCompanyIdColumn(header,width,true);
                targetMapping=buildTargetMapping(sourceHeader,header);
            } else {
                if(headerIndex!=null) { header=makeUniqueHeaders(rows.get(headerIndex)); dataRows=new ArrayList<>(rows.subList(headerIndex+1,rows.size())); width=header.size(); }
                else { width=rows.stream().mapToInt(List::size).max().orElse(0); header=new ArrayList<>(); for(int i=0;i<width;i++) header.add(String.format("Feld_%02d",i+1)); dataRows=rows; }
                sourceHeader=new ArrayList<>(header); sourceCompanyIndex=findCompanyIdColumn(sourceHeader,width,false); targetCompanyIndex=sourceCompanyIndex; targetMapping=null;
            }
            List<String> normalizedHeader = mapNormalize(header), normalizedSourceHeader=mapNormalize(sourceHeader);
            List<List<String>> cleanData=new ArrayList<>();
            for(List<String> row:dataRows) {
                if(isEmptyRow(row)||isMarkerRow(row)||isMetadataRow(row)) continue;
                List<String> fittedHeader=normalizeRowWidth(row,Math.max(width,sourceHeader.size()));
                List<String> rowNorm=mapNormalize(fittedHeader);
                int targetOverlap=pairOverlap(rowNorm,normalizedHeader), sourceOverlap=pairOverlap(rowNorm,normalizedSourceHeader);
                if(targetOverlap>=Math.max(4,Math.min(8,width/3)) || sourceOverlap>=Math.max(4,Math.min(8,Math.max(1,sourceHeader.size())/3)) || headerMatchScore(row,header)>=5 || (!sourceHeader.isEmpty() && headerMatchScore(row,sourceHeader)>=5)) continue;
                String companyId=null;
                if(applyCompanyFilter) {
                    companyId=findAllowedCompanyId(row,Arrays.asList(sourceCompanyIndex,settings.companyIdColumnIndex));
                    if(companyId==null) continue;
                }
                List<String> fitted=mapRowToTarget(row,width,targetMapping);
                if(fixedTargetHeader) {
                    Map<String,Integer> idxMap=new HashMap<>();
                    for(int i=0;i<header.size();i++){String n=normalizeHeader(header.get(i)); if(!n.isEmpty()) idxMap.put(n,i);}
                    Integer wwidIdx=idxMap.get("wwid"), depotIdx=idxMap.get("depotnummer"), underIdx=idxMap.get("unterdepot");
                    if(wwidIdx!=null && depotIdx!=null) {
                        String existing=at(fitted,wwidIdx), depot=at(fitted,depotIdx), under=underIdx!=null?at(fitted,underIdx):"";
                        fitted.set(wwidIdx,mapping.resolve(depot,under,existing));
                    }
                }
                if(companyId!=null && targetCompanyIndex!=null && targetCompanyIndex<fitted.size()) fitted.set(targetCompanyIndex,companyId);
                boolean any=false; for(String x:fitted) if(!x.isEmpty()){any=true;break;} if(any) cleanData.add(fitted);
            }
            return new Table(header,cleanData,sourceName);
        }

        String findAllowedCompanyId(List<String> row,List<Integer> preferred) {
            Set<Integer> checked=new HashSet<>();
            for(Integer idx:preferred) {
                if(idx==null||idx<0||idx>=row.size()||checked.contains(idx)) continue;
                checked.add(idx); String c=normalizeCompanyId(row.get(idx)); if(allowedCompanyIds.contains(c)) return c;
            }
            for(int i=0;i<row.size();i++) { if(checked.contains(i)) continue; String c=normalizeCompanyId(row.get(i)); if(allowedCompanyIds.contains(c)) return c; }
            return null;
        }
        Integer findCompanyIdColumn(List<String> header,int width,boolean fixed) {
            List<String> norm=mapNormalize(header);
            for(String c:Arrays.asList("firmenid","companyid","firmen_id","company_id")) { int i=norm.indexOf(normalizeHeader(c)); if(i>=0)return i; }
            if(fixed && settings.companyIdColumnIndex<width) return settings.companyIdColumnIndex; return null;
        }
        String normalizeCompanyId(String v){return cleanCell(v).toUpperCase(Locale.ROOT);}
        int headerMatchScore(List<String> row,List<String> reference) {
            Set<String> rowNorm=new HashSet<>(); for(String x:row) if(!x.trim().isEmpty()) rowNorm.add(normalizeHeader(x));
            if(reference!=null){Set<String> ref=new HashSet<>(); for(String x:reference) if(!x.trim().isEmpty())ref.add(normalizeHeader(x)); int n=0; for(String x:ref)if(rowNorm.contains(x))n++; return n;}
            Set<String> du=new HashSet<>(),dp=new HashSet<>(); for(String x:settings.duTargetHeaders)du.add(normalizeHeader(x)); for(String x:settings.dpTargetHeaders)dp.add(normalizeHeader(x)); int a=0,b=0; for(String x:rowNorm){if(du.contains(x))a++; if(dp.contains(x))b++;} return Math.max(a,b);
        }
        boolean looksLikeHeader(List<String> row) {
            List<String> cells=new ArrayList<>(); for(String x:row){String c=cleanCell(x);if(!c.isEmpty())cells.add(c);} if(cells.size()<4)return false;
            Set<String> normalized=new HashSet<>();for(String x:cells)normalized.add(normalizeHeader(x)); Set<String> known=new HashSet<>();for(String x:KNOWN_HEADER_TERMS)known.add(normalizeHeader(x)); int hits=0;for(String x:normalized)if(known.contains(x))hits++; if(hits>=3)return true; if(headerMatchScore(cells,null)>=5)return true;
            int alpha=0,num=0;for(String x:cells){if(Pattern.compile("[A-Za-zÄÖÜäöüß]").matcher(x).find())alpha++;if(isNumericLike(x))num++;} boolean dateLikeFirst=cells.get(0).matches("\\d{8}"); if(dateLikeFirst||num>=Math.max(3,cells.size()/3))return false; return alpha>=Math.max(4,(int)Math.floor(cells.size()*0.65));
        }
    }

    static Settings loadSettings(Path path) throws Exception {
        String text=Files.readString(path,StandardCharsets.UTF_8);
        Settings s=new Settings(); s.allowedCompanyIds=jsonStringArray(text,"allowed_company_ids"); s.duTargetHeaders=jsonStringArray(text,"du_target_headers"); s.dpTargetHeaders=jsonStringArray(text,"dp_target_headers");
        Matcher m=Pattern.compile("\\\"company_id_column_index\\\"\\s*:\\s*(\\d+)").matcher(text); if(!m.find())throw new RuntimeException("company_id_column_index missing"); s.companyIdColumnIndex=Integer.parseInt(m.group(1)); return s;
    }
    static List<String> jsonStringArray(String text,String name) {
        Matcher m=Pattern.compile("\\\""+Pattern.quote(name)+"\\\"\\s*:\\s*\\[(.*?)\\]",Pattern.DOTALL).matcher(text); if(!m.find())throw new RuntimeException("JSON array missing: "+name); String body=m.group(1); List<String> out=new ArrayList<>(); Matcher q=Pattern.compile("\\\"((?:\\\\.|[^\\\"])*)\\\"").matcher(body); while(q.find())out.add(unescapeJson(q.group(1))); return out;
    }
    static String unescapeJson(String s) { StringBuilder o=new StringBuilder(); for(int i=0;i<s.length();i++){char c=s.charAt(i); if(c!='\\'){o.append(c);continue;} if(++i>=s.length())break; c=s.charAt(i); switch(c){case 'n':o.append('\n');break;case 'r':o.append('\r');break;case 't':o.append('\t');break;case 'b':o.append('\b');break;case 'f':o.append('\f');break;case '\\':o.append('\\');break;case '"':o.append('"');break;case '/':o.append('/');break;case 'u': if(i+4<s.length()){o.append((char)Integer.parseInt(s.substring(i+1,i+5),16));i+=4;}break;default:o.append(c);} } return o.toString(); }

    static Options parseArgs(String[] args) {
        Map<String,String> map=new HashMap<>(); for(int i=0;i<args.length;i++){String k=args[i]; if(!k.startsWith("--"))throw new IllegalArgumentException("Unexpected argument: "+k); if(i+1>=args.length)throw new IllegalArgumentException("Missing value for "+k);map.put(k.toLowerCase(Locale.ROOT),args[++i]);}
        Options o=new Options();o.caseId=map.getOrDefault("--case",CASE_ID);o.inputDir=Paths.get(need(map,"--input")).toAbsolutePath().normalize();o.templatePath=Paths.get(need(map,"--template")).toAbsolutePath().normalize();o.outputDir=Paths.get(need(map,"--output")).toAbsolutePath().normalize();try{o.workers=Math.max(1,Integer.parseInt(map.getOrDefault("--workers","4")));}catch(Exception e){throw new IllegalArgumentException("--workers must be integer");}return o;
    }
    static String need(Map<String,String> map,String key){String v=map.get(key);if(v==null||v.trim().isEmpty())throw new IllegalArgumentException("Required argument missing: "+key);return v;}

    static String cleanCell(Object value){return String.valueOf(value==null?"":value).replace('\u00A0',' ').trim();}
    static String normalizeHeader(Object value){return cleanCell(value).toLowerCase(Locale.ROOT).replace("ä","ae").replace("ö","oe").replace("ü","ue").replace("ß","ss").replaceAll("[^a-z0-9]+","");}
    static String normalizeText(Object value){return String.valueOf(value==null?"":value).replace('\u00A0',' ').trim().toLowerCase(Locale.ROOT).replaceAll("\\s+"," ");}
    static final Map<String,String> FUND_ALIASES = new HashMap<>(); static {FUND_ALIASES.put(normalizeText("DWS INV.FOC.EUROPE FC"),normalizeText("DWSI-EUR.EQ.HI.CO.FC"));FUND_ALIASES.put(normalizeText("DWSI-EUR.EQ.HI.CO.FC Anteile"),normalizeText("DWSI-EUR.EQ.HI.CO.FC"));}
    static String normalizeFund(Object v){String n=normalizeText(v);return FUND_ALIASES.getOrDefault(n,n);}
    static String normalizeWwid(Object value){if(value==null)return "";String s=String.valueOf(value).trim();if(s.matches("\\d+\\.0"))return s.substring(0,s.length()-2);return s;}
    static double asNumber(Object value){if(value==null)return 0;String t=String.valueOf(value).trim().replace(" ","");if(t.isEmpty())return 0;int c=t.lastIndexOf(','),d=t.lastIndexOf('.');if(c>=0&&d>=0){if(c>d)t=t.replace(".","").replace(',','.');else t=t.replace(",","");}else if(c>=0)t=t.replace(".","").replace(',','.');try{return Double.parseDouble(t);}catch(Exception e){return 0;}}
    static boolean isDistribution(Object value){String t=normalizeText(value);return t.startsWith("ertragsaussch")&&t.endsWith("ttung");}
    static String profileFromFilename(String name){String stem=name;int dot=stem.lastIndexOf('.');if(dot>0)stem=stem.substring(0,dot);stem=stem.trim().toLowerCase(Locale.ROOT);if(matchesPrefix(stem,"du"))return "du";if(matchesPrefix(stem,"dp"))return "dp";return null;}
    static boolean matchesPrefix(String s,String p){if(s.equals(p))return true;if(!s.startsWith(p))return false;if(s.length()==p.length())return true;char n=s.charAt(p.length());return n=='_'||n=='-'||Character.isWhitespace(n);}
    static Map<String,Integer> headerMap(List<String> header){Map<String,Integer> m=new HashMap<>();for(int i=0;i<header.size();i++){String n=normalizeHeader(header.get(i));if(!n.isEmpty())m.putIfAbsent(n,i);}return m;}
    static int findIndex(Map<String,Integer> map,String... aliases){for(String a:aliases){Integer i=map.get(normalizeHeader(a));if(i!=null)return i;}throw new RuntimeException("Required master header missing: "+String.join(" / ",aliases));}
    static String xmlEscape(String v){return v.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;");}
    static String cleanMapping(String v){String t=String.valueOf(v==null?"":v).replace('\u00A0',' ').trim().replaceAll("^'+|'+$","");if(t.matches("\\d+\\.0"))t=t.substring(0,t.length()-2);return t;}
    static String normalizeDepot(String v){return cleanMapping(v).replaceAll("\\s+","");}
    static String normalizeUnderdepot(String v){String t=cleanMapping(v);if(t.isEmpty())return "";String digits=t.replaceAll("\\D","");if(digits.isEmpty())return t;try{return new BigInteger(digits).toString();}catch(Exception e){return digits;}}
    static String normalizeMappingWwid(String v){return cleanMapping(v);}
    static int findField(Map<String,Integer> fields,String... names){for(String n:names){Integer i=fields.get(n.toLowerCase(Locale.ROOT));if(i!=null)return i;}return -1;}
    static String at(List<String> row,int i){return i>=0&&i<row.size()?row.get(i):"";}

    static List<Integer> buildTargetMapping(List<String> sourceHeader,List<String> targetHeader){if(sourceHeader.isEmpty())return null;Map<String,Integer> sourceIndex=new HashMap<>();for(int i=0;i<sourceHeader.size();i++){String n=normalizeHeader(sourceHeader.get(i));if(!n.isEmpty())sourceIndex.putIfAbsent(n,i);}List<String> targetNorm=mapNormalize(targetHeader);int overlap=0;for(String n:targetNorm)if(!n.isEmpty()&&sourceIndex.containsKey(n))overlap++;if(overlap<Math.max(5,(int)Math.floor(targetNorm.size()*0.35)))return null;List<Integer> out=new ArrayList<>();for(int i=0;i<targetNorm.size();i++){String n=targetNorm.get(i);out.add(sourceIndex.containsKey(n)?sourceIndex.get(n):(i<sourceHeader.size()?i:null));}return out;}
    static List<String> mapRowToTarget(List<String> row,int width,List<Integer> mapping){if(mapping==null)return normalizeRowWidth(row,width);List<String> out=new ArrayList<>();for(int i=0;i<width;i++){Integer s=i<mapping.size()?mapping.get(i):null;out.add(s!=null&&s>=0&&s<row.size()?cleanCell(row.get(s)):"");}return out;}
    static int pairOverlap(List<String>a,List<String>b){int n=0;for(int i=0;i<Math.min(a.size(),b.size());i++)if(!a.get(i).isEmpty()&&a.get(i).equals(b.get(i)))n++;return n;}
    static List<String> makeUniqueHeaders(List<String> headers){Map<String,Integer> counts=new HashMap<>();List<String> out=new ArrayList<>();for(int i=0;i<headers.size();i++){String name=cleanCell(headers.get(i));if(name.isEmpty())name=String.format("Feld_%02d",i+1);int c=counts.getOrDefault(name,0)+1;counts.put(name,c);out.add(c>1?name+"_"+c:name);}return out;}
    static List<String> trimTrailingEmpty(List<String> row){List<String> v=new ArrayList<>();for(String x:row)v.add(cleanCell(x));while(!v.isEmpty()&&v.get(v.size()-1).isEmpty())v.remove(v.size()-1);return v;}
    static List<List<String>> removeNoiseRows(List<List<String>> rows){List<List<String>> out=new ArrayList<>();for(List<String> r:rows){List<String> t=trimTrailingEmpty(r);if(!t.isEmpty()&&!isMarkerRow(t)&&!isMetadataRow(t))out.add(t);}return out;}
    static List<List<String>> splitPackedRows(List<List<String>> rows){List<List<String>> out=new ArrayList<>();for(List<String> r:rows){List<String> c=trimTrailingEmpty(r);List<String> ne=new ArrayList<>();for(String x:c)if(!x.isEmpty())ne.add(x);if(ne.size()==1&&countChar(ne.get(0),';')>=3){List<String> p=parseDelimitedLine(ne.get(0),';');List<String> q=new ArrayList<>();for(String x:p)q.add(cleanCell(x));out.add(q);}else out.add(c);}return out;}
    static int countChar(String s,char c){int n=0;for(int i=0;i<s.length();i++)if(s.charAt(i)==c)n++;return n;}
    static List<String> normalizeRowWidth(List<String> row,int width){List<String> out=new ArrayList<>();for(int i=0;i<width;i++)out.add(i<row.size()?cleanCell(row.get(i)):"");return out;}
    static boolean isEmptyRow(List<String> row){for(String x:row)if(!cleanCell(x).isEmpty())return false;return true;}
    static String firstNonempty(List<String> row){for(String x:row){String c=cleanCell(x);if(!c.isEmpty())return c;}return "";}
    static boolean isMarkerRow(List<String> row){String f=firstNonempty(row).stripLeading();if(f.isEmpty())return false;for(String p:TextParser.MARKER_PREFIXES)if(f.startsWith(p))return true;return false;}
    static boolean isMetadataRow(List<String> row){List<String> c=new ArrayList<>();for(String x:row){String y=cleanCell(x);if(!y.isEmpty())c.add(y);}if(c.isEmpty()||c.size()>3)return false;return TextParser.METADATA_LABELS.contains(c.get(0).toLowerCase(Locale.ROOT).trim().replaceAll(":$",""));}
    static boolean isNumericLike(String v){String t=v.trim();return t.matches("[-+]?\\d+(?:[.,]\\d+)?")||t.matches("\\d{6,14}")||t.matches("[A-Z]{2}\\d{9,12}");}
    static List<String> mapNormalize(List<String> list){List<String> o=new ArrayList<>();for(String x:list)o.add(normalizeHeader(x));return o;}

    static List<List<String>> parseTextRows(String content){Character sep=detectSeparator(content);String[] lines=content.replace("\r\n","\n").replace('\r','\n').split("\n",-1);List<List<String>> rows=new ArrayList<>();for(String raw:lines){if(raw.trim().isEmpty())continue;List<String> row=sep!=null?parseDelimitedLine(raw,sep):new ArrayList<>(Collections.singletonList(raw.trim()));List<String> cleaned=new ArrayList<>();boolean any=false;for(String x:row){String c=cleanCell(x);cleaned.add(c);if(!c.isEmpty())any=true;}if(any)rows.add(cleaned);}return rows;}
    static Character detectSeparator(String content){String[] all=content.replace("\r\n","\n").replace('\r','\n').split("\n",-1);List<String> lines=new ArrayList<>();for(String x:all)if(!x.trim().isEmpty()){lines.add(x);if(lines.size()==20)break;}if(lines.isEmpty())return null;char[] cs={';','\t','|',','};Character best=null;int bestScore=0;for(char c:cs){int score=0;for(String l:lines)score+=countOutsideQuotes(l,c);if(score>bestScore){best=c;bestScore=score;}}return bestScore>0?best:null;}
    static int countOutsideQuotes(String line,char delimiter){boolean quoted=false;int count=0;for(int i=0;i<line.length();i++){char c=line.charAt(i);if(c=='"'){if(quoted&&i+1<line.length()&&line.charAt(i+1)=='"')i++;else quoted=!quoted;}else if(c==delimiter&&!quoted)count++;}return count;}
    static List<String> parseDelimitedLine(String line,char delimiter){List<String> result=new ArrayList<>();StringBuilder field=new StringBuilder();boolean quoted=false;for(int i=0;i<line.length();i++){char c=line.charAt(i);if(c=='"'){if(quoted&&i+1<line.length()&&line.charAt(i+1)=='"'){field.append('"');i++;}else quoted=!quoted;}else if(c==delimiter&&!quoted){result.add(field.toString());field.setLength(0);}else field.append(c);}result.add(field.toString());return result;}
    static String readTextWithFallback(Path path)throws Exception{byte[] bytes=Files.readAllBytes(path);int off=(bytes.length>=3&&(bytes[0]&255)==0xEF&&(bytes[1]&255)==0xBB&&(bytes[2]&255)==0xBF)?3:0;byte[] body=Arrays.copyOfRange(bytes,off,bytes.length);CharsetDecoder d=StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT);try{return d.decode(ByteBuffer.wrap(body)).toString();}catch(CharacterCodingException e){return new String(body,Charset.forName("windows-1252"));}}
    static String readUtf8Bom(Path path)throws Exception{String s=Files.readString(path,StandardCharsets.UTF_8);return s.startsWith("\uFEFF")?s.substring(1):s;}

    static void writeXlsx(Path filePath,String sheetName,List<String> header,List<List<String>> rows)throws Exception{
        Files.createDirectories(filePath.getParent());
        String contentTypes="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>";
        String rootRels="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>";
        String workbook="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\""+xmlEscape(sheetName)+"\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>";
        String workbookRels="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/></Relationships>";
        String sheet=worksheetXml(header,rows);
        try(ZipOutputStream z=new ZipOutputStream(Files.newOutputStream(filePath))){zipEntry(z,"[Content_Types].xml",contentTypes);zipEntry(z,"_rels/.rels",rootRels);zipEntry(z,"xl/workbook.xml",workbook);zipEntry(z,"xl/_rels/workbook.xml.rels",workbookRels);zipEntry(z,"xl/worksheets/sheet1.xml",sheet);}
    }
    static void zipEntry(ZipOutputStream z,String name,String text)throws Exception{z.putNextEntry(new ZipEntry(name));z.write(text.getBytes(StandardCharsets.UTF_8));z.closeEntry();}
    static String worksheetXml(List<String> header,List<List<String>> rows){StringBuilder s=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>");writeXmlRow(s,1,header);for(int i=0;i<rows.size();i++)writeXmlRow(s,i+2,rows.get(i));s.append("</sheetData></worksheet>");return s.toString();}
    static void writeXmlRow(StringBuilder s,int r,List<String> values){s.append("<row r=\"").append(r).append("\">");for(int i=0;i<values.size();i++){String v=values.get(i)==null?"":values.get(i);if(v.isEmpty())continue;String ref=columnName(i+1)+r;s.append("<c r=\"").append(ref).append("\" t=\"inlineStr\"><is><t");if(v.matches("^\\s.*|.*\\s$"))s.append(" xml:space=\"preserve\"");s.append(">").append(xmlEscape(v)).append("</t></is></c>");}s.append("</row>");}
    static String columnName(int col){StringBuilder s=new StringBuilder();while(col>0){col--;s.insert(0,(char)('A'+(col%26)));col/=26;}return s.toString();}

    static PipelineResult runPipeline(TextParser parser,Options options)throws Exception{
        if(!Files.isDirectory(options.inputDir))throw new RuntimeException("Input directory missing: "+options.inputDir);if(!Files.isRegularFile(options.templatePath))throw new RuntimeException("Template missing: "+options.templatePath);Files.createDirectories(options.outputDir);
        Path work=options.outputDir.resolve("work"),convertRoot=work.resolve("01_convert_merge"),duConverted=convertRoot.resolve("DU"),dpConverted=convertRoot.resolve("DP"),lnwDir=work.resolve("02_LNW");Files.createDirectories(duConverted);Files.createDirectories(dpConverted);Files.createDirectories(lnwDir);
        List<Path> files=new ArrayList<>();try(var stream=Files.walk(options.inputDir)){stream.filter(Files::isRegularFile).forEach(files::add);}List<Path> filtered=new ArrayList<>();for(Path p:files)if(!p.getFileName().toString().startsWith("~$"))filtered.add(p);
        Comparator<Path> ci=Comparator.comparing(p->p.getFileName().toString().toLowerCase(Locale.ROOT));List<Path> duFiles=new ArrayList<>(),dpAll=new ArrayList<>();for(Path p:filtered){String prof=profileFromFilename(p.getFileName().toString());if("du".equals(prof))duFiles.add(p);else if("dp".equals(prof))dpAll.add(p);}duFiles.sort(ci);dpAll.sort(ci);
        System.out.printf("Quelldateien erkannt: %d DU | %d DP | %d ignoriert%n",duFiles.size(),dpAll.size(),filtered.size()-duFiles.size()-dpAll.size());if(duFiles.isEmpty())throw new RuntimeException("No DU raw files found.");if(dpAll.isEmpty())throw new RuntimeException("No DP raw files found.");List<Path> dpFiles=selectDp(dpAll,ci);
        Path duMaster=options.outputDir.resolve("DU_MASTER.xlsx"),dpMaster=options.outputDir.resolve("DP_MASTER.xlsx");GroupResult du=convertAndMerge(parser,"du",duFiles,duConverted,duMaster);GroupResult dp=convertAndMerge(parser,"dp",dpFiles,dpConverted,dpMaster);
        String fn=options.templatePath.getFileName().toString();String ext=fn.contains(".")?fn.substring(fn.lastIndexOf('.')):".xlsm";Path lnwExcel=options.outputDir.resolve("LNW_Output"+ext),lnwCsv=options.outputDir.resolve("LNW_Output.csv");System.out.println("[LNW] DU- und DP-Master werden an die Java LNW-Engine uebergeben ...");runLnw(options.templatePath,du.table,dp.table,lnwExcel,lnwCsv,lnwDir);
        PipelineResult r=new PipelineResult();r.duMaster=duMaster;r.dpMaster=dpMaster;r.lnwExcel=lnwExcel;r.lnwCsv=lnwCsv;r.duRows=du.table.rows.size();r.dpRows=dp.table.rows.size();return r;
    }
    static List<Path> selectDp(List<Path> files,Comparator<Path> ci){if(files.size()<=1)return new ArrayList<>(files);List<Path>s=new ArrayList<>(files);s.sort((a,b)->{int c=Integer.compare(filenameDate(a),filenameDate(b));return c!=0?c:ci.compare(a,b);});System.out.println("[DP] "+files.size()+" DP-Dateien erkannt. Verwendet wird "+s.get(0).getFileName()+".");return new ArrayList<>(Collections.singletonList(s.get(0)));}
    static int filenameDate(Path p){String stem=p.getFileName().toString();int dot=stem.lastIndexOf('.');if(dot>0)stem=stem.substring(0,dot);Matcher m=Pattern.compile("(?<!\\d)(20\\d{6})(?!\\d)").matcher(stem);int v=99999999;boolean found=false;while(m.find()){v=Integer.parseInt(m.group(1));found=true;}return found?v:99999999;}
    static GroupResult convertAndMerge(TextParser parser,String profile,List<Path> sourceFiles,Path convertedDir,Path masterPath)throws Exception{String label=profile.toUpperCase(Locale.ROOT);System.out.println("["+label+"] "+sourceFiles.size()+" Rohdatei(en) werden konvertiert und zusammengefuehrt ...");Files.createDirectories(convertedDir);Map<Path,Path> reservations=reserveOutputPaths(sourceFiles,convertedDir);Map<Path,Table> results=new LinkedHashMap<>();List<String> errors=new ArrayList<>();int completed=0;for(Path source:sourceFiles){try{Table t=parser.parseFile(source);writeXlsx(reservations.get(source),"Ziel 1",t.header,t.rows);results.put(source,t);completed++;System.out.println("["+label+"] "+completed+"/"+sourceFiles.size()+" | "+source.getFileName()+" | Datei abgeschlossen");}catch(Exception e){completed++;errors.add(source.getFileName()+": "+e.getMessage());System.out.println("["+label+"] "+completed+"/"+sourceFiles.size()+" | "+source.getFileName()+" | FEHLER: "+e.getMessage());}}
        List<Path> successful=new ArrayList<>();for(Path p:sourceFiles)if(results.containsKey(p))successful.add(p);if(successful.isEmpty())throw new RuntimeException("No "+label+" source could be converted.\n"+String.join("\n",errors.subList(0,Math.min(20,errors.size()))));System.out.println("["+label+"] Konvertierung fertig. "+successful.size()+" Datei(en) werden zum Master zusammengefuehrt ...");List<String> header=new ArrayList<>(results.get(successful.get(0)).header);List<List<String>> merged=new ArrayList<>();int pos=0;for(Path source:successful){pos++;Table table=results.get(source);try{merged.addAll(alignRows(table,header));System.out.println("["+label+"] Merge "+pos+"/"+(successful.size()+1)+" | "+reservations.get(source).getFileName()+" | Datei abgeschlossen | "+merged.size()+" Zeilen");}catch(Exception e){errors.add(reservations.get(source).getFileName()+": "+e.getMessage());System.out.println("["+label+"] Merge "+pos+"/"+(successful.size()+1)+" | "+reservations.get(source).getFileName()+" | FEHLER: "+e.getMessage()+" | "+merged.size()+" Zeilen");}}
        writeXlsx(masterPath,"Gesamtdaten",header,merged);System.out.println("["+label+"] Merge "+(successful.size()+1)+"/"+(successful.size()+1)+" | "+masterPath.getFileName()+" | Masterdatei gespeichert | "+merged.size()+" Zeilen");System.out.println("["+label+"] Master fertig: "+masterPath.getFileName()+" | "+merged.size()+" Datenzeilen");return new GroupResult(new Table(header,merged,masterPath.toString()),errors);
    }
    static Map<Path,Path> reserveOutputPaths(List<Path> sourceFiles,Path outputDir){Set<String> used=new HashSet<>();Map<Path,Path> map=new LinkedHashMap<>();for(Path source:sourceFiles){String name=source.getFileName().toString();int dot=name.lastIndexOf('.');String stem=dot>0?name.substring(0,dot):name;Path candidate=outputDir.resolve(stem+".xlsx");int counter=1;while(used.contains(candidate.toString().toLowerCase(Locale.ROOT)))candidate=outputDir.resolve(stem+"_"+(counter++)+".xlsx");used.add(candidate.toString().toLowerCase(Locale.ROOT));map.put(source,candidate);}return map;}
    static List<List<String>> alignRows(Table source,List<String> masterHeader){List<String> sn=mapNormalize(source.header),mn=mapNormalize(masterHeader);if(sn.size()==mn.size()&&sn.equals(mn)){List<List<String>> out=new ArrayList<>();for(List<String>r:source.rows)out.add(new ArrayList<>(r));return out;}Map<String,Integer> idx=new HashMap<>();for(int i=0;i<sn.size();i++)if(!sn.get(i).isEmpty())idx.put(sn.get(i),i);int common=0;for(String n:mn)if(idx.containsKey(n))common++;if(common<Math.max(4,(int)Math.floor(mn.size()*0.60)))throw new RuntimeException("Header weicht zu stark von den übrigen Dateien ab.");List<List<String>>out=new ArrayList<>();for(List<String>row:source.rows){List<String> nr=new ArrayList<>();for(String n:mn){Integer i=idx.get(n);nr.add(i!=null&&i<row.size()?row.get(i):"");}out.add(nr);}return out;}

    static Map<String,ValuePair> aggregateDu(Table table,boolean investment){Map<String,Integer> m=headerMap(table.header);int w=findIndex(m,"WWID"),f=findIndex(m,"Fondsname","Fonds Name"),mv=findIndex(m,"Umsatzart","Umsatz Art"),sh=findIndex(m,"UmsatzStuecke","Umsatzstücke","Umsatz Stücke"),val=investment?findIndex(m,"Anlbetrag","AnlBetrag","Anl Betrag","Anlagebetrag"):findIndex(m,"ZahlBetrag","Zahlbetrag","Zahl Betrag");Map<String,ValuePair>out=new HashMap<>();for(List<String>row:table.rows){String ww=normalizeWwid(at(row,w)),fund=normalizeFund(at(row,f)),mov=normalizeText(at(row,mv));if(ww.isEmpty()||fund.isEmpty()||mov.isEmpty())continue;String k=ww+SEP+fund+SEP+mov;ValuePair p=out.computeIfAbsent(k,x->new ValuePair());p.shares+=asNumber(at(row,sh));p.value+=asNumber(at(row,val));}return out;}
    static Map<String,ValuePair> aggregateDp(Table table){Map<String,Integer>m=headerMap(table.header);int w=findIndex(m,"WWID"),f=findIndex(m,"Fondsname","Fonds Name"),sh=findIndex(m,"Bestand_Stuecke","BestandStuecke","Bestand Stücke","Bestand_Stücke","Bestandstücke"),val=findIndex(m,"Bestand_Betrag","BestandBetrag","Bestand Betrag");Map<String,ValuePair>out=new HashMap<>();for(List<String>row:table.rows){String ww=normalizeWwid(at(row,w)),fund=normalizeFund(at(row,f));if(ww.isEmpty()||fund.isEmpty())continue;String k=ww+SEP+fund;ValuePair p=out.computeIfAbsent(k,x->new ValuePair());p.shares+=asNumber(at(row,sh));p.value+=asNumber(at(row,val));}return out;}
    static void runLnw(Path template,Table du,Table dp,Path outputExcel,Path outputCsv,Path workDir)throws Exception{Files.createDirectories(workDir);Files.copy(template,outputExcel,StandardCopyOption.REPLACE_EXISTING);Path snapPath=workDir.resolve("excel_snapshot.tsv"),planPath=workDir.resolve("excel_plan.tsv");System.out.println("[LNW] Output-Template wird ueber Microsoft Excel geoeffnet ...");runBridge(Arrays.asList("-Mode","Snapshot","-Workbook",outputExcel.toString(),"-SnapshotPath",snapPath.toString()));Snapshot snap=parseSnapshot(snapPath);System.out.println("[LNW] Zielblatt erkannt: WWID-Header Zeile "+snap.headerRow+", letzte WWID-Zeile "+snap.lastRow+".");System.out.println("[LNW] DU wird nach WWID, Fonds und Umsatzart aggregiert ...");Map<String,ValuePair> duAgg=aggregateDu(du,false),purchaseAgg=aggregateDu(du,true);System.out.println("[LNW] DP wird nach WWID und Fonds aggregiert ...");Map<String,ValuePair>dpAgg=aggregateDp(dp);List<String> lines=new ArrayList<>();lines.add("META\t"+(snap.headerRow+1)+"\t"+snap.lastRow);String[][] prev={{"AJ","0"},{"AK","1"},{"AL","2"},{"AM","3"},{"AN","4"},{"AO","5"},{"AP","6"},{"AQ","7"},{"AR","8"},{"AS","9"}};String[][] purchases={{"DWS EURORENTA","AV","AW"},{"DWS INS.-ESG EO MO.M.IC","AY","AZ"},{"DWSI-EUR.EQ.HI.CO.FC","BB","BC"}};String[][] funds={{"DWSI-EUR.EQ.HI.CO.FC","CL","CM","BI","BJ"},{"DWS EURORENTA","CN","CO","BK","BL"},{"DWS INS.-ESG EO MO.M.IC","CP","CQ","BM","BN"},{"SIEMENS EUROINVEST AKTIEN","CR","CS",null,null},{"SIEMENS EUROINVEST RENTEN","CT","CU",null,null}};String purchaseMovement=normalizeText("Kauf"),reallocMovement=normalizeText("Fondsportfolioanpassung"),distFund=normalizeFund("DWS EURORENTA");System.out.println("[LNW] Schreibplan fuer AJ:CU wird erzeugt ...");for(SnapshotRow s:snap.rows){if(s.wwid.isEmpty())continue;for(String[] x:prev)setPlan(lines,x[0]+s.row,s.prev[Integer.parseInt(x[1])]);for(String[] x:purchases){ValuePair v=purchaseAgg.getOrDefault(s.wwid+SEP+normalizeFund(x[0])+SEP+purchaseMovement,new ValuePair());setPlan(lines,x[1]+s.row,v.shares);setPlan(lines,x[2]+s.row,v.value);}double ds=0,dv=0;for(Map.Entry<String,ValuePair>e:duAgg.entrySet()){String[] k=e.getKey().split(SEP,-1);if(k.length==3&&k[0].equals(s.wwid)&&k[1].equals(distFund)&&isDistribution(k[2])){ds+=e.getValue().shares;dv+=e.getValue().value;}}setPlan(lines,"BF"+s.row,ds);setPlan(lines,"BG"+s.row,dv);for(String[] x:funds){String f=normalizeFund(x[0]);if(x[3]!=null&&x[4]!=null){ValuePair v=duAgg.getOrDefault(s.wwid+SEP+f+SEP+reallocMovement,new ValuePair());setPlan(lines,x[3]+s.row,v.shares);setPlan(lines,x[4]+s.row,v.value);}ValuePair d=dpAgg.getOrDefault(s.wwid+SEP+f,new ValuePair());setPlan(lines,x[1]+s.row,d.shares);setPlan(lines,x[2]+s.row,d.value);}}
        Files.write(planPath,(String.join("\r\n",lines)+"\r\n").getBytes(StandardCharsets.UTF_8));System.out.println("[LNW] Konstanten werden geloescht, Werte geschrieben und Excel neu berechnet ...");runBridge(Arrays.asList("-Mode","Apply","-Workbook",outputExcel.toString(),"-PlanPath",planPath.toString(),"-CsvPath",outputCsv.toString()));System.out.println("[LNW] Verarbeitung erfolgreich abgeschlossen.");}
    static void setPlan(List<String>lines,String addr,double v){lines.add("SET\t"+addr+"\t"+(Double.isFinite(v)?Double.toString(v):"0"));}
    static Path bridgePath(){try{Path p=Paths.get(Main.class.getProtectionDomain().getCodeSource().getLocation().toURI()).resolve("excel_bridge.ps1");if(!Files.exists(p))throw new RuntimeException("Excel bridge missing: "+p);return p;}catch(Exception e){throw new RuntimeException(e);}}
    static void runBridge(List<String>args)throws Exception{List<String>cmd=new ArrayList<>(Arrays.asList("powershell.exe","-NoProfile","-ExecutionPolicy","Bypass","-File",bridgePath().toString()));cmd.addAll(args);Process p=new ProcessBuilder(cmd).inheritIO().start();int c=p.waitFor();if(c!=0)throw new RuntimeException("Excel bridge failed with exit code "+c);}
    static Snapshot parseSnapshot(Path p)throws Exception{Snapshot s=new Snapshot();for(String line:Files.readAllLines(p,StandardCharsets.UTF_8)){if(line.isEmpty())continue;String[] a=line.split("\\t",-1);if(a[0].equals("META")&&a.length>=4){s.headerRow=Integer.parseInt(a[1]);s.lastRow=Integer.parseInt(a[3]);}else if(a[0].equals("ROW")&&a.length>=13){double[]prev=new double[10];for(int i=0;i<10;i++){try{prev[i]=Double.parseDouble(a[i+3]);}catch(Exception e){prev[i]=0;}}s.rows.add(new SnapshotRow(Integer.parseInt(a[1]),normalizeWwid(a[2]),prev));}}if(s.headerRow==0||s.lastRow<=s.headerRow)throw new RuntimeException("Snapshot metadata invalid");return s;}

    static String jsonEscape(String s){return s.replace("\\","\\\\").replace("\"","\\\"").replace("\r","\\r").replace("\n","\\n");}
    static void writeCandidateResult(Path out,Options o,PipelineResult r)throws Exception{String j="{\n  \"schema\": \"mcr.level05.candidate-result.v1\",\n  \"status\": \"success\",\n  \"case\": \""+jsonEscape(o.caseId)+"\",\n  \"language\": \"java\",\n  \"mode\": \"parity\",\n  \"artifacts\": {\n    \"du_master\": \""+jsonEscape(r.duMaster.getFileName().toString())+"\",\n    \"dp_master\": \""+jsonEscape(r.dpMaster.getFileName().toString())+"\",\n    \"lnw_excel\": \""+jsonEscape(r.lnwExcel.getFileName().toString())+"\",\n    \"lnw_csv\": \""+jsonEscape(r.lnwCsv.getFileName().toString())+"\"\n  },\n  \"diagnostics\": {\n    \"du_master_rows\": "+r.duRows+",\n    \"dp_master_rows\": "+r.dpRows+",\n    \"workers\": "+o.workers+",\n    \"runtime\": \""+jsonEscape(System.getProperty("java.runtime.version"))+"\"\n  }\n}\n";Files.writeString(out.resolve("candidate_result.json"),j,StandardCharsets.UTF_8);}

    public static void main(String[] args) {
        try {
            Options o=parseArgs(args);if(!CASE_ID.equals(o.caseId))throw new RuntimeException("This candidate is frozen to case MCR_LNW_001.");
            Path base=Paths.get(Main.class.getProtectionDomain().getCodeSource().getLocation().toURI());Path settingsPath=base.resolve("resources/settings.json"),mappingPath=base.resolve("resources/wwid_mapping.csv");if(!Files.exists(settingsPath)||!Files.exists(mappingPath))throw new RuntimeException("Candidate resources are missing from build output.");
            System.out.println("=".repeat(72));System.out.println("MCR LEVEL 05A.2 - JAVA MODE 1 PARITY CANDIDATE");System.out.println("=".repeat(72));System.out.println("Case:    "+o.caseId);System.out.println("Input:   "+o.inputDir);System.out.println("Template:"+o.templatePath);System.out.println("Output:  "+o.outputDir);System.out.println("Workers: "+o.workers);System.out.println();Files.createDirectories(o.outputDir);
            Settings settings=loadSettings(settingsPath);WwidMapping mapping=WwidMapping.load(mappingPath);TextParser parser=new TextParser(settings,mapping);PipelineResult r=runPipeline(parser,o);writeCandidateResult(o.outputDir,o,r);System.out.println();System.out.println("Java candidate completed successfully.");System.out.println("DU Master Rows: "+r.duRows);System.out.println("DP Master Rows: "+r.dpRows);System.out.println("candidate_result.json written.");
        } catch(Exception ex) {System.err.println();System.err.println("JAVA CANDIDATE FAILED");ex.printStackTrace();System.exit(1);}    }
}
