# Level 05A.2 – Java Mode 1 Parity v0.1.0

Independent Java implementation of the frozen LNW DC pipeline.

Runtime:
- existing `java.exe` + `javac.exe`
- Java standard library only
- no Maven/Gradle dependencies
- no generated native candidate EXE
- no Python/C#/Rust/Node/Ruby/Julia worker

The candidate implements raw DU/DP parsing, company filtering, WWID mapping,
XLSX generation, merge/alignment, LNW aggregation and output planning in Java.
Microsoft Excel is used only through the existing PowerShell COM bridge for
workbook I/O, recalculation and the frozen CSV export contract.
