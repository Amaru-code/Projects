# MCR Level 05A.2 – Java Mode 1 Parity v0.1.0

First Java parity candidate for the frozen LNW DC benchmark.

- existing JDK runtime/compiler only
- Java standard library only
- offline build
- no Maven/Gradle
- no new native candidate EXE
- full Java business implementation
- common Level-05 validator after the timed run

Run `START_5A2_JAVA.ps1`.
