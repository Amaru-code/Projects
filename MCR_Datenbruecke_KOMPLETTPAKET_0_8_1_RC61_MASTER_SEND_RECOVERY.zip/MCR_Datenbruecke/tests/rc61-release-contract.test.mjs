import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';
import {ROOT} from './helpers.mjs';import {VERSION} from '../lib/control.mjs';
import {verifyPackage,verifyPrevious} from '../tools/integrity.mjs';import {sha256} from '../lib/core.mjs';

test('RC61 sealed against exact published RC60, with bounded changed components',()=>{
 assert.equal(VERSION,'0.8.1-rc.61');assert.equal(verifyPackage(ROOT).version,VERSION);
 assert.equal(verifyPrevious(ROOT).version,VERSION);
 const previous=fs.readFileSync(path.join(ROOT,'tools/reference/complete-0.8.1-rc.60-manifest.json'));
 const original=JSON.parse(previous);assert.equal(original.version,'0.8.1-rc.60');
 const allowed=new Set(['tools/cli.mjs','tools/integrity.mjs','src/local-bot-full-run.mjs','lib/control.mjs','package.json','README_DE.md']);
 for(const item of original.payload.filter(x=>/^(src|lib|tools)\//.test(x.path)))if(!allowed.has(item.path))
  assert.equal(sha256(fs.readFileSync(path.join(ROOT,item.path))),item.sha256,'RC60 business code changed: '+item.path);
 const code=fs.readFileSync(path.join(ROOT,'tools/cli.mjs'),'utf8');
 assert(code.includes('MASTER_ABSCHLUSS_OHNE_NEUVERSAND'));
 assert(code.includes('MASTER_RECOVERY_NOT_COMPLETED'));
 assert(code.includes('PARTIAL_PHASE1_NO_PILOT'));
 assert(code.includes('13  MASTER RUN'));
 const send=fs.readFileSync(path.join(ROOT,'src/local-bot-full-run.mjs'),'utf8');
 assert(send.includes('SEND_WARTET_AUF_NACHWEIS'));
 assert(send.includes('SEND_AUTOMATISCHE_PRUEFUNG_OHNE_NACHWEIS'));
});
