MCR Gender-Patch 0.1.2

Zweck:
- liest Spalte O der bekannten XLSX read-only via installiertem Excel
- M -> Herr, F -> Frau, leer -> weiterhin manuelle Rueckfrage
- erstellt ein NEUES JSON-Mapping mit aktualisierter Payload-Pruefsumme
- erstellt src\local-bot-gender.mjs, config\local-runner-gender.json und START_LOCAL_BOT_GENDER.cmd
- ueberschreibt weder das bestehende Mapping noch src\local-bot.mjs

Benutzung:
1. ZIP entpacken.
2. GENDER_MAPPING_AKTUALISIEREN.cmd starten.
3. Header von Spalte O pruefen und JA eingeben.
4. Danach im MCR_Datenbruecke-Projekt START_LOCAL_BOT_GENDER.cmd starten.

Die Pfade sind auf das aktuelle Ticket_bot-Projekt voreingestellt und koennen in der PS1 bei Bedarf ueber Parameter ueberschrieben werden.

Kompatibilitaetsfix 0.1.2:
- Windows PowerShell 5.1: ConvertFrom-Json wird ohne den dort nicht vorhandenen Parameter -Depth aufgerufen.

0.1.2: Windows PowerShell 5.1 schreibt temporäre JSON-Datei explizit UTF-8 ohne BOM; Node-Reader toleriert zusätzlich vorhandenes BOM.
