import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

function fail(message){ console.error('STOP:', message); process.exit(1); }
const [rootArg,mappingArg,sidecarArg] = process.argv.slice(2);
if(!rootArg || !mappingArg || !sidecarArg) fail('Argumente fehlen.');
const root=path.resolve(rootArg), mappingPath=path.resolve(mappingArg), sidecarPath=path.resolve(sidecarArg);
const sha = data => crypto.createHash('sha256').update(data).digest('hex');
const readJson = p => JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''));
if(!fs.existsSync(mappingPath)) fail('Mapping fehlt: '+mappingPath);
const map=readJson(mappingPath), side=readJson(sidecarPath);
if(map?.schema!=='MCR_INTL01_LOOKUP_V1' || !map.payload?.entries) fail('Unbekanntes Mapping-Format.');
if(!/^[a-f0-9]{64}$/i.test(side.sourceSha256||'')) fail('Sidecar-Quellhash fehlt.');
if(String(map.payload?.source?.sha256||'').toLowerCase()!==String(side.sourceSha256).toLowerCase()) fail('Excel-Quelle stimmt nicht mit dem Mapping überein.');
if(side.column!=='O' || !side.header || !side.rows || typeof side.rows!=='object') fail('Gender-Sidecar ist unvollständig.');

let male=0,female=0,blank=0;
for(const [id,e] of Object.entries(map.payload.entries)){
  const r=side.rows[id];
  if(!r) fail('Keine Spalte-O-Zuordnung für eine gültige ClientEEID im Mapping.');
  if(Number(r.sourceRow)!==Number(e.sourceRow)) fail('Quellzeile stimmt zwischen Mapping und Excel nicht überein.');
  const g=r.gender===null?null:String(r.gender).toUpperCase();
  if(g!==null && g!=='M' && g!=='F') fail('Nicht unterstützter Wert in Spalte O. Erlaubt: M, F oder leer.');
  e.gender=g;
  e.genderSourceColumn='O';
  if(g==='M') male++; else if(g==='F') female++; else blank++;
}
map.payload.genderPolicy='M_HERR_F_FRAU_BLANK_MANUAL_V1';
map.payload.source.headers={...(map.payload.source.headers||{}),O:side.header};
map.payload.source.genderColumn='O';
map.payload.source.genderHeaderConfirmed=true;
map.payload.summary={...(map.payload.summary||{}),genderM:male,genderF:female,genderBlank:blank};
map.payloadSha256=sha(JSON.stringify(map.payload));

const stamp=new Date().toISOString().replace(/[:.]/g,'-');
const source8=String(map.payload.source.sha256).slice(0,8);
const outPath=path.join(path.dirname(mappingPath),`INTL01_mapping_gender_${stamp}_${source8}.json`);
const raw=JSON.stringify(map,null,2)+'\n';
fs.writeFileSync(outPath,raw,{flag:'wx',mode:0o600});
fs.writeFileSync(outPath+'.sha256',sha(raw)+'  '+path.basename(outPath)+'\n',{flag:'wx',mode:0o600});

const baseRunner=path.join(root,'src','local-bot.mjs');
if(!fs.existsSync(baseRunner)) fail('src/local-bot.mjs fehlt.');
let runner=fs.readFileSync(baseRunner,'utf8');
const configOld="const p = path.join(root,'config','local-runner.json');";
const configNew="const p = path.join(root,'config','local-runner-gender.json');";
if(!runner.includes(configOld)) fail('Runner-Konfigurationsstelle nicht gefunden; Paketversion unerwartet.');
runner=runner.replace(configOld,configNew);
const oldSal="    let sal='Herr';if(!AUTO){const s=clean(await rl.question('Anrede [H]err / [F]rau: ')).toLowerCase();sal=s.startsWith('f')?'Frau':'Herr';}";
const newSal=`    let sal=null;\n    if(entry.gender==='M'){sal='Herr';diag.reply.salutationSource='MAPPING_O_M';log('Anrede automatisch aus Spalte O: Herr (M).');}\n    else if(entry.gender==='F'){sal='Frau';diag.reply.salutationSource='MAPPING_O_F';log('Anrede automatisch aus Spalte O: Frau (F).');}\n    else if(!AUTO){const s=clean(await rl.question('Spalte O ist leer. Anrede [H]err / [F]rau: ')).toLowerCase();sal=s.startsWith('f')?'Frau':'Herr';diag.reply.salutationSource='MANUAL_FALLBACK';}\n    else fail('SALUTATION_REQUIRED','Spalte O enthält für diesen Member kein M/F. Keine automatische Anrede ohne Datenquelle.');`;
if(!runner.includes(oldSal)) fail('Anrede-Stelle im Runner nicht gefunden; Paketversion unerwartet.');
runner=runner.replace(oldSal,newSal);
runner=runner.replaceAll("version:'0.5.5'","version:'0.5.5-GENDER'");
runner=runner.replaceAll('MCR Local Runner 0.5.5 - PAGE_FETCH integriert','MCR Local Runner 0.5.5-GENDER - PAGE_FETCH + Spalte O');
runner=runner.replaceAll('Version 0.5.5 klickt NICHT','Version 0.5.5-GENDER klickt NICHT');
const genderRunner=path.join(root,'src','local-bot-gender.mjs');
fs.writeFileSync(genderRunner,runner,'utf8');
fs.writeFileSync(genderRunner+'.sha256',sha(runner)+'  '+path.basename(genderRunner)+'\n','utf8');

const baseCfg=readJson(path.join(root,'config','local-runner.json'));
baseCfg.mappingPath=outPath;
baseCfg.genderPolicy='M_HERR_F_FRAU_BLANK_MANUAL_V1';
const genderCfgPath=path.join(root,'config','local-runner-gender.json');
const genderCfgRaw=JSON.stringify(baseCfg,null,2)+'\n';
fs.writeFileSync(genderCfgPath,genderCfgRaw,'utf8');
fs.writeFileSync(genderCfgPath+'.sha256',sha(genderCfgRaw)+'  '+path.basename(genderCfgPath)+'\n','utf8');

const cmd=`@echo off\r\nsetlocal EnableExtensions DisableDelayedExpansion\r\ncd /d "%~dp0"\r\necho ==============================================================\r\necho  MCR Local Runner 0.5.5-GENDER - Spalte O M/F\r\necho ==============================================================\r\necho.\r\nset "NODE_EXE="\r\nfor %%N in (\r\n  "C:\\Users\\Amaru-Zegarra\\projects\\Compiler\\javascript\\tools\\node\\node.exe"\r\n  "%~dp0tools\\node\\node.exe"\r\n) do if not defined NODE_EXE if exist "%%~N" set "NODE_EXE=%%~N"\r\nif not defined NODE_EXE for /f "delims=" %%N in ('where node.exe 2^>nul') do if not defined NODE_EXE set "NODE_EXE=%%N"\r\nif not defined NODE_EXE (echo FEHLER: node.exe nicht gefunden.& pause & exit /b 3)\r\n"%NODE_EXE%" "%~dp0src\\verify-package.mjs"\r\nif errorlevel 1 (echo Basispaket-Integritaet fehlgeschlagen.& pause & exit /b 4)\r\n"%NODE_EXE%" "%~dp0src\\local-bot-gender.mjs"\r\nset "RC=%errorlevel%"\r\necho.\r\nif not "%RC%"=="0" echo Runner wurde fail-closed beendet.\r\npause\r\nexit /b %RC%\r\n`;
fs.writeFileSync(path.join(root,'START_LOCAL_BOT_GENDER.cmd'),cmd,'utf8');

console.log('NEW_MAPPING='+outPath);
console.log('GENDER_RUNNER='+genderRunner);
console.log('COUNTS='+JSON.stringify({M:male,F:female,blank}));
