@echo off
setlocal
title MCR Priority Mail Generator - Selbsttest ohne Versand
cd /d "%~dp0"
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -STA -ExecutionPolicy RemoteSigned -File "%~dp0PriorityMailGenerator.ps1" -SelfTest
set "MCR_MAIL_TEST_EXIT=%ERRORLEVEL%"
echo.
if "%MCR_MAIL_TEST_EXIT%"=="0" echo Selbsttests erfolgreich. Es wurden keine E-Mails versendet.
if not "%MCR_MAIL_TEST_EXIT%"=="0" echo Selbsttest fehlgeschlagen. Bitte die obige Fehlermeldung pruefen.
pause
exit /b %MCR_MAIL_TEST_EXIT%
