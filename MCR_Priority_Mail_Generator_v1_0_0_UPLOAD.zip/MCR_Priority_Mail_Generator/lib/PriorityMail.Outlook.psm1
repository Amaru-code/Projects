﻿#requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'PriorityMail.Core.psm1') -ErrorAction Stop

function Release-TestComObject {
    param([AllowNull()]$Value)
    if ($null -ne $Value -and [Runtime.InteropServices.Marshal]::IsComObject($Value)) {
        try { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($Value) } catch { }
    }
}

function Get-TestOutlookConnection {
    [CmdletBinding()]
    param()
    $application = $null
    $session = $null
    $collection = $null
    $accounts = New-Object 'System.Collections.Generic.List[object]'
    try {
        try { $application = [Runtime.InteropServices.Marshal]::GetActiveObject('Outlook.Application') }
        catch { $application = New-Object -ComObject Outlook.Application -ErrorAction Stop }
        $session = $application.Session
        $collection = $session.Accounts
        for ($i = 1; $i -le $collection.Count; $i++) {
            $account = $collection.Item($i)
            $smtp = [string]$account.SmtpAddress
            if ([string]::IsNullOrWhiteSpace($smtp)) {
                Release-TestComObject $account
                continue
            }
            [void]$accounts.Add([pscustomobject]@{
                Name = ('{0} <{1}>' -f $account.DisplayName, $smtp)
                Smtp = $smtp
                ComAccount = $account
            })
        }
        if ($accounts.Count -eq 0) { throw 'In klassischem Outlook wurde kein sendefaehiges Konto mit E-Mail-Adresse gefunden.' }
        return [pscustomobject]@{
            Application = $application
            Session = $session
            Accounts = $accounts.ToArray()
        }
    } catch {
        foreach ($entry in $accounts) { Release-TestComObject $entry.ComAccount }
        Release-TestComObject $session
        Release-TestComObject $application
        throw ('Outlook-Verbindung nicht moeglich. Klassisches Outlook unter Windows mit eingerichtetem Profil ist erforderlich. ' + $_.Exception.Message)
    } finally {
        Release-TestComObject $collection
    }
}

function Close-TestOutlookConnection {
    param([AllowNull()]$Connection)
    if ($null -eq $Connection) { return }
    foreach ($entry in $Connection.Accounts) { Release-TestComObject $entry.ComAccount }
    Release-TestComObject $Connection.Session
    Release-TestComObject $Connection.Application
    # Never call Quit: this is the user's Outlook session.
}

function Invoke-TestMailSubmission {
    <# One attempt per message. 'submitted' means Send returned, never delivery. #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]$Message,
        [Parameter(Mandatory = $true)][string[]]$Recipients,
        [Parameter(Mandatory = $true)]$Outlook,
        [Parameter(Mandatory = $true)]$Account,
        [Parameter(Mandatory = $true)][string]$AccountSmtp,
        [Parameter(Mandatory = $true)][string]$EventPath
    )
    if ($Message.Status -ne 'planned') {
        throw ('Diese Nachricht wurde bereits bearbeitet; erneuter Versand ist gesperrt: ' + $Message.TestId)
    }
    $mail = $null
    $recipientCollection = $null
    $sendEntered = $false
    $sendReturned = $false
    $halt = $false
    $detail = ''
    try {
        $checkedRecipients = @(ConvertTo-TestRecipients -Text ($Recipients -join ';'))
        if ($checkedRecipients.Count -ne $Recipients.Count) { throw 'Die Empfaengerliste hat sich geaendert oder enthaelt Duplikate.' }
        if (-not [string]::Equals([string]$Account.SmtpAddress, $AccountSmtp, [StringComparison]::OrdinalIgnoreCase)) {
            throw 'Das ausgewaehlte Absenderkonto hat sich geaendert. Bitte Outlook erneut verbinden.'
        }
        $mail = $Outlook.CreateItem(0) # olMailItem
        $mail.Subject = [string]$Message.Subject
        $mail.BodyFormat = 1 # olFormatPlain
        $mail.Body = [string]$Message.Body
        $mail.Importance = [int]$Message.OutlookImportance
        $mail.SendUsingAccount = $Account
        $recipientCollection = $mail.Recipients
        foreach ($address in $checkedRecipients) {
            $recipient = $null
            try {
                $recipient = $recipientCollection.Add($address)
                $recipient.Type = 1 # olTo
            } finally { Release-TestComObject $recipient }
        }
        if (-not $recipientCollection.ResolveAll()) {
            throw 'Outlook konnte nicht alle Empfaenger eindeutig aufloesen.'
        }
        # Persistent intent BEFORE the irreversible call. No implicit retries.
        $null = Write-TestMailEvent -Path $EventPath -TestId $Message.TestId -Status 'attempting' -Detail $AccountSmtp
        $sendEntered = $true
        $mail.Send()
        $sendReturned = $true
        $Message.Status = 'submitted'
        $Message.SubmittedAt = [DateTime]::UtcNow.ToString('o')
        $Message.Error = ''
        $null = Write-TestMailEvent -Path $EventPath -TestId $Message.TestId -Status 'submitted' -Detail 'Outlook Send returned; delivery unverified.'
    } catch {
        $reason = $_.Exception.Message
        $halt = $true
        if ($sendReturned) {
            $Message.Status = 'submitted'
            $detail = 'An Outlook uebergeben, aber das Ergebnisprotokoll konnte nicht geschrieben werden. ' + $reason
        } elseif ($sendEntered) {
            $Message.Status = 'unknown'
            $detail = 'Unklarer Ausgang beim Outlook-Sendeaufruf. Postausgang/Gesendete Elemente pruefen, bevor erneut gesendet wird. ' + $reason
        } else {
            $Message.Status = 'failed'
            $detail = 'Nicht an Outlook zum Versand uebergeben. ' + $reason
        }
        $Message.Error = $detail
        try {
            $null = Write-TestMailEvent -Path $EventPath -TestId $Message.TestId -Status $Message.Status -Detail $detail
        } catch {
            $detail += ' Auch das Ereignisprotokoll ist nicht beschreibbar.'
            $Message.Error = $detail
        }
    } finally {
        Release-TestComObject $recipientCollection
        Release-TestComObject $mail
    }
    return [pscustomobject]@{ Status = $Message.Status; Halt = $halt; Detail = $detail }
}

Export-ModuleMember -Function Get-TestOutlookConnection, Close-TestOutlookConnection, Invoke-TestMailSubmission
