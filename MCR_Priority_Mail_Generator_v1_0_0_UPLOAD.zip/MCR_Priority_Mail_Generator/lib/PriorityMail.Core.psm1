﻿#requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$script:PriorityNames = @('high', 'important', 'low')
$script:InvariantCulture = [System.Globalization.CultureInfo]::InvariantCulture
$script:Utf8Bom = New-Object System.Text.UTF8Encoding($true, $true)

function Get-PriorityCounts {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][ValidateRange(1, 10000)][int]$Total,
        [Parameter(Mandatory = $true)][ValidateRange(0, 100)][int]$HighPercent,
        [Parameter(Mandatory = $true)][ValidateRange(0, 100)][int]$ImportantPercent,
        [Parameter(Mandatory = $true)][ValidateRange(0, 100)][int]$LowPercent
    )

    if (($HighPercent + $ImportantPercent + $LowPercent) -ne 100) {
        throw 'Die drei Prozentwerte müssen zusammen genau 100 ergeben.'
    }
    $percentages = @($HighPercent, $ImportantPercent, $LowPercent)
    $counts = @(0, 0, 0)
    $remainders = @(0, 0, 0)
    $assigned = 0
    for ($i = 0; $i -lt 3; $i++) {
        $product = $Total * $percentages[$i]
        $counts[$i] = [int][Math]::Floor($product / 100.0)
        $remainders[$i] = $product % 100
        $assigned += $counts[$i]
    }
    # Largest remainder; strict 'greater than' retains high/important/low tie order.
    for ($remaining = $Total - $assigned; $remaining -gt 0; $remaining--) {
        $best = 0
        for ($i = 1; $i -lt 3; $i++) {
            if ($remainders[$i] -gt $remainders[$best]) { $best = $i }
        }
        $counts[$best]++
        $remainders[$best] = -1
    }
    [pscustomobject][ordered]@{
        high = [int]$counts[0]
        important = [int]$counts[1]
        low = [int]$counts[2]
    }
}

function ConvertTo-TestRecipients {
    [CmdletBinding()]
    param([Parameter(Mandatory = $true)][AllowEmptyString()][AllowNull()][string]$Text)

    if ([string]::IsNullOrWhiteSpace($Text)) {
        throw 'Bitte mindestens eine Empfängeradresse eingeben.'
    }
    foreach ($character in $Text.ToCharArray()) {
        if ([char]::IsControl($character) -and $character -ne [char]13 -and $character -ne [char]10) {
            throw 'Empfänger dürfen keine Steuerzeichen enthalten; als Trenner sind nur Komma, Semikolon und Zeilenumbruch erlaubt.'
        }
    }
    # Only ordinary ASCII addr-spec values, without display names, quotes or headers.
    $atom = '[A-Za-z0-9!#$%&''*+/=?^_`{|}~-]+'
    $localPattern = $atom + '(?:\.' + $atom + ')*'
    $label = '[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?'
    $pattern = '^(' + $localPattern + ')@(' + $label + '(?:\.' + $label + ')*)$'
    $seen = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    $recipients = New-Object 'System.Collections.Generic.List[string]'
    foreach ($part in [regex]::Split($Text, '[;,\r\n]+')) {
        $candidate = $part.Trim()
        if ($candidate.Length -eq 0) { continue }
        $match = [regex]::Match($candidate, $pattern, [System.Text.RegularExpressions.RegexOptions]::CultureInvariant)
        if (-not $match.Success -or $candidate.Length -gt 254 -or $match.Groups[1].Value.Length -gt 64 -or $match.Groups[2].Value.Length -gt 253) {
            throw ('Ungültige Empfängeradresse: "{0}". Bitte reine E-Mail-Adressen ohne Anzeigenamen verwenden.' -f $candidate)
        }
        $canonical = $match.Groups[1].Value + '@' + $match.Groups[2].Value.ToLowerInvariant()
        if ($seen.Add($canonical)) {
            [void]$recipients.Add($canonical)
            if ($recipients.Count -gt 20) { throw 'Pro Lauf sind höchstens 20 unterschiedliche Empfänger erlaubt.' }
        }
    }
    if ($recipients.Count -eq 0) { throw 'Bitte mindestens eine Empfängeradresse eingeben.' }
    foreach ($recipient in $recipients) { Write-Output $recipient }
}

function Get-RequiredJsonProperty {
    param([AllowNull()][object]$Object, [string]$Name, [string]$Context)
    if ($null -eq $Object -or -not ($Object -is [System.Management.Automation.PSCustomObject])) {
        throw ($Context + ' muss ein JSON-Objekt sein.')
    }
    $property = $Object.PSObject.Properties[$Name]
    if ($null -eq $property) { throw ($Context + ': Pflichtfeld "' + $Name + '" fehlt.') }
    # Return the value without unrolling arrays, including empty and one-element arrays.
    return ,$property.Value
}

function Assert-TemplateText {
    param([object]$Value, [string]$Context, [bool]$IsSubject = $false)
    if (-not ($Value -is [string]) -or [string]::IsNullOrWhiteSpace([string]$Value)) {
        throw ($Context + ' muss eine nicht leere Zeichenfolge sein.')
    }
    if ($IsSubject -and $Value.Length -gt 150) { throw ($Context + ' darf höchstens 150 Zeichen enthalten.') }
    foreach ($character in $Value.ToCharArray()) {
        if ([char]::IsControl($character)) {
            if ($IsSubject -or @([char]9, [char]10, [char]13) -notcontains $character) {
                throw ($Context + ' enthält unzulässige Steuerzeichen.')
            }
        }
    }
    $withoutTokens = [regex]::Replace($Value, '\{(?:case|project|time|next_date|name)\}', '')
    if ($withoutTokens.IndexOf('{') -ge 0 -or $withoutTokens.IndexOf('}') -ge 0) {
        throw ($Context + ' enthält einen unbekannten oder ungültigen Platzhalter. Erlaubt: {case}, {project}, {time}, {next_date}, {name}.')
    }
}

function Get-TestMailTemplates {
    [CmdletBinding()]
    param([Parameter(Mandatory = $true)][string]$Path)

    $fullPath = [System.IO.Path]::GetFullPath($Path)
    if (-not [System.IO.File]::Exists($fullPath)) { throw ('Vorlagendatei fehlt: ' + $fullPath) }
    try {
        $json = [System.IO.File]::ReadAllText($fullPath, (New-Object System.Text.UTF8Encoding($false, $true)))
        $root = ConvertFrom-Json -InputObject $json -ErrorAction Stop
    } catch {
        throw ('Vorlagendatei ist kein gültiges UTF-8-JSON: ' + $_.Exception.Message)
    }
    $version = Get-RequiredJsonProperty -Object $root -Name 'schema_version' -Context 'Vorlagendatei'
    if (-not ($version -is [int] -or $version -is [long]) -or $version -ne 1) {
        throw 'Vorlagendatei: schema_version muss die ganze Zahl 1 sein.'
    }
    $classes = Get-RequiredJsonProperty -Object $root -Name 'classes' -Context 'Vorlagendatei'
    if (-not ($classes -is [System.Management.Automation.PSCustomObject])) {
        throw 'Vorlagendatei: classes muss ein JSON-Objekt sein.'
    }
    foreach ($property in $classes.PSObject.Properties) {
        if ($script:PriorityNames -cnotcontains $property.Name) {
            throw ('Unbekannte Prioritätsklasse in der Vorlagendatei: ' + $property.Name)
        }
    }
    $ids = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    $validated = [ordered]@{}
    foreach ($priority in $script:PriorityNames) {
        $items = Get-RequiredJsonProperty -Object $classes -Name $priority -Context 'classes'
        if (-not ($items -is [array]) -or $items.Count -eq 0) {
            throw ('classes.' + $priority + ' muss eine nicht leere Liste von Vorlagen sein.')
        }
        $cleanItems = New-Object 'System.Collections.Generic.List[object]'
        foreach ($item in $items) {
            $context = 'Vorlage in classes.' + $priority
            $id = Get-RequiredJsonProperty -Object $item -Name 'id' -Context $context
            if (-not ($id -is [string]) -or [string]::IsNullOrWhiteSpace($id)) {
                throw ($context + ': id muss eine nicht leere Zeichenfolge sein.')
            }
            foreach ($character in $id.ToCharArray()) {
                if ([char]::IsControl($character)) { throw ($context + ': id darf keine Steuerzeichen enthalten.') }
            }
            $id = $id.Trim()
            if (-not $ids.Add($id)) { throw ('Vorlagen-ID doppelt vergeben: ' + $id) }
            $subject = Get-RequiredJsonProperty -Object $item -Name 'subject' -Context ($context + ' ' + $id)
            $body = Get-RequiredJsonProperty -Object $item -Name 'body' -Context ($context + ' ' + $id)
            Assert-TemplateText -Value $subject -Context ('Betreff ' + $id) -IsSubject $true
            Assert-TemplateText -Value $body -Context ('Text ' + $id)
            [void]$cleanItems.Add([pscustomobject][ordered]@{ id = $id; subject = $subject.Trim(); body = $body.Trim() })
        }
        $validated[$priority] = [object[]]$cleanItems.ToArray()
    }
    [pscustomobject][ordered]@{ schema_version = 1; classes = [pscustomobject]$validated }
}

function Invoke-ArrayShuffle {
    param([object[]]$Items, [System.Random]$Random)
    for ($i = $Items.Length - 1; $i -gt 0; $i--) {
        $j = $Random.Next($i + 1)
        $temporary = $Items[$i]
        $Items[$i] = $Items[$j]
        $Items[$j] = $temporary
    }
    return ,$Items
}

function Expand-TestMailTokens {
    param([string]$Text, [System.Collections.IDictionary]$Tokens)
    $expanded = $Text
    foreach ($key in @('case', 'project', 'time', 'next_date', 'name')) {
        $expanded = $expanded.Replace(('{' + $key + '}'), [string]$Tokens[$key])
    }
    return $expanded
}

function New-TestMailBatch {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][ValidateRange(1, 10000)][int]$Total,
        [Parameter(Mandatory = $true)][ValidateRange(0, 100)][int]$HighPercent,
        [Parameter(Mandatory = $true)][ValidateRange(0, 100)][int]$ImportantPercent,
        [Parameter(Mandatory = $true)][ValidateRange(0, 100)][int]$LowPercent,
        [Parameter(Mandatory = $true)][string[]]$Recipients,
        [Parameter(Mandatory = $true)][string]$TemplatePath,
        [int]$Seed = 0,
        [bool]$SetOutlookImportance = $false
    )

    $counts = Get-PriorityCounts -Total $Total -HighPercent $HighPercent -ImportantPercent $ImportantPercent -LowPercent $LowPercent
    $canonicalRecipients = @(ConvertTo-TestRecipients -Text ($Recipients -join ';'))
    $templates = Get-TestMailTemplates -Path $TemplatePath
    $created = [DateTimeOffset]::UtcNow
    $localDate = $created.LocalDateTime
    $runId = $created.ToString('yyyyMMddTHHmmssfffZ', $script:InvariantCulture) + '-' + [guid]::NewGuid().ToString('N').Substring(0, 12)
    $random = New-Object System.Random($Seed)
    $labels = New-Object 'System.Collections.Generic.List[object]'
    foreach ($priority in $script:PriorityNames) {
        for ($i = 0; $i -lt $counts.$priority; $i++) { [void]$labels.Add($priority) }
    }
    $shuffledLabels = Invoke-ArrayShuffle -Items $labels.ToArray() -Random $random
    $cycles = @{}
    $positions = @{}
    foreach ($priority in $script:PriorityNames) {
        $cycles[$priority] = @()
        $positions[$priority] = 0
    }
    $projects = @('Orion', 'Atlas', 'Linden', 'Nordstern', 'Brücke', 'Horizont', 'Sonnenfeld', 'Aster')
    $names = @('Mira Sommer', 'Jonas Winter', 'Lena Berg', 'Noah Falk', 'Emma Seidel', 'Tom Albrecht', 'Nora Blum', 'David Stern')
    $messages = New-Object 'System.Collections.Generic.List[object]'
    for ($offset = 0; $offset -lt $Total; $offset++) {
        $priority = [string]$shuffledLabels[$offset]
        if ($positions[$priority] -ge $cycles[$priority].Count) {
            $cycles[$priority] = Invoke-ArrayShuffle -Items ([object[]]$templates.classes.$priority.Clone()) -Random $random
            $positions[$priority] = 0
        }
        $template = $cycles[$priority][$positions[$priority]]
        $positions[$priority]++
        $index = $offset + 1
        $testId = $runId + '-' + $index.ToString('D5', $script:InvariantCulture)
        $tokens = [ordered]@{
            case = 'TEST-' + $random.Next(10000, 100000).ToString($script:InvariantCulture)
            project = $projects[$random.Next($projects.Length)]
            time = $localDate.AddMinutes($random.Next(20, 241)).ToString('HH:mm', $script:InvariantCulture) + ' Uhr'
            next_date = $localDate.AddDays(1).ToString('dd.MM.yyyy', $script:InvariantCulture)
            name = $names[$random.Next($names.Length)]
        }
        $subject = '[PRIO-TEST ' + $testId + '] ' + (Expand-TestMailTokens -Text $template.subject -Tokens $tokens)
        $body = Expand-TestMailTokens -Text $template.body -Tokens $tokens
        $body = [regex]::Replace($body, '\r\n|\r|\n', "`r`n")
        $body += "`r`n`r`n---`r`nSynthetische Testnachricht für den Priority-Scanner.`r`nTest-ID: " + $testId
        $importance = 1
        if ($SetOutlookImportance) {
            if ($priority -eq 'high') { $importance = 2 }
            elseif ($priority -eq 'low') { $importance = 0 }
        }
        [void]$messages.Add([pscustomobject][ordered]@{
            Index = $index
            TestId = $testId
            ExpectedPriority = $priority
            TemplateId = $template.id
            Subject = $subject
            Body = $body
            OutlookImportance = $importance
            Status = 'planned'
            Error = ''
            SubmittedAt = ''
        })
    }
    [pscustomobject][ordered]@{
        RunId = $runId
        CreatedAt = $created.ToString('o', $script:InvariantCulture)
        Seed = $Seed
        Counts = $counts
        Recipients = [string[]]$canonicalRecipients
        Messages = [object[]]$messages.ToArray()
    }
}

function ConvertTo-ExcelCsvCell {
    param([AllowNull()][object]$Value)
    $text = if ($null -eq $Value) { '' } else { [string]$Value }
    # CSV quoting alone does not prevent Excel from interpreting formula cells.
    if ($text -match '^[\s]*[=+\-@]' -or $text -match '^[\t\r\n]') { $text = "'" + $text }
    return '"' + $text.Replace('"', '""') + '"'
}

function Get-TestMailCsv {
    param([object]$Batch, [bool]$IncludeResults)
    $columns = @('TestId', 'ExpectedPriority', 'TemplateId', 'Subject', 'Recipients', 'Seed', 'OutlookImportance')
    if ($IncludeResults) { $columns += @('Status', 'Error', 'SubmittedAt') }
    $builder = New-Object System.Text.StringBuilder
    $header = @($columns | ForEach-Object { ConvertTo-ExcelCsvCell -Value $_ })
    [void]$builder.Append(($header -join ';') + "`r`n")
    $recipientsText = $Batch.Recipients -join '; '
    foreach ($message in $Batch.Messages) {
        $values = New-Object 'System.Collections.Generic.List[string]'
        foreach ($column in $columns) {
            if ($column -eq 'Recipients') { $value = $recipientsText }
            elseif ($column -eq 'Seed') { $value = $Batch.Seed }
            else { $value = $message.$column }
            [void]$values.Add((ConvertTo-ExcelCsvCell -Value $value))
        }
        [void]$builder.Append(($values.ToArray() -join ';') + "`r`n")
    }
    return $builder.ToString()
}

function Write-DurableUtf8File {
    param([string]$Path, [string]$Text, [bool]$Replace = $false)
    $target = [System.IO.Path]::GetFullPath($Path)
    $writePath = $target
    if ($Replace) { $writePath = $target + '.tmp-' + [guid]::NewGuid().ToString('N') }
    $stream = $null
    $writer = $null
    try {
        $stream = [System.IO.File]::Open($writePath, [System.IO.FileMode]::CreateNew, [System.IO.FileAccess]::Write, [System.IO.FileShare]::Read)
        $writer = New-Object System.IO.StreamWriter($stream, $script:Utf8Bom)
        $writer.Write($Text)
        $writer.Flush()
        $stream.Flush($true)
        $writer.Dispose()
        $writer = $null
        $stream = $null
        if ($Replace) {
            if ([System.IO.File]::Exists($target)) { [System.IO.File]::Replace($writePath, $target, [System.Management.Automation.Language.NullString]::Value) }
            else { [System.IO.File]::Move($writePath, $target) }
        }
    } finally {
        if ($null -ne $writer) { $writer.Dispose() }
        elseif ($null -ne $stream) { $stream.Dispose() }
        if ($Replace -and [System.IO.File]::Exists($writePath)) { [System.IO.File]::Delete($writePath) }
    }
}

function Save-TestMailPlan {
    [CmdletBinding()]
    param([Parameter(Mandatory = $true)][object]$Batch, [Parameter(Mandatory = $true)][string]$Directory)

    $fullDirectory = [System.IO.Path]::GetFullPath($Directory)
    if ([System.IO.Directory]::Exists($fullDirectory)) {
        if ([System.IO.Directory]::GetFileSystemEntries($fullDirectory).Length -ne 0) {
            throw 'Der Planordner ist nicht leer. Ein vorhandener Plan wird niemals überschrieben.'
        }
    } elseif ([System.IO.File]::Exists($fullDirectory)) {
        throw 'Der gewählte Planpfad ist bereits eine Datei.'
    } else {
        [void][System.IO.Directory]::CreateDirectory($fullDirectory)
    }
    $summary = Get-TestMailSummary -Batch $Batch
    if ($summary.planned -ne $summary.Total) { throw 'Ein neuer Versandplan darf nur Nachrichten im Zustand planned enthalten.' }
    $planPath = [System.IO.Path]::Combine($fullDirectory, 'plan.json')
    $expectedPath = [System.IO.Path]::Combine($fullDirectory, 'expected_priorities.csv')
    $previewPath = [System.IO.Path]::Combine($fullDirectory, 'mail_previews.txt')
    $previews = New-Object System.Text.StringBuilder
    [void]$previews.Append("MCR Priority Mail Generator – Nachrichtenvorschau`r`n")
    [void]$previews.Append(('Lauf: ' + $Batch.RunId + "`r`nErstellt (UTC): " + $Batch.CreatedAt + "`r`n") )
    foreach ($message in $Batch.Messages) {
        [void]$previews.Append("`r`n" + ('=' * 72) + "`r`n")
        [void]$previews.Append(('Nachricht ' + $message.Index + '/' + $summary.Total + "`r`n"))
        [void]$previews.Append(('An: ' + ($Batch.Recipients -join '; ') + "`r`n"))
        [void]$previews.Append(('Betreff: ' + $message.Subject + "`r`n"))
        [void]$previews.Append(('Outlook Importance: ' + $message.OutlookImportance + "`r`n`r`n"))
        [void]$previews.Append(($message.Body + "`r`n"))
    }
    Write-DurableUtf8File -Path $planPath -Text ((ConvertTo-Json -InputObject $Batch -Depth 20) + "`r`n")
    Write-DurableUtf8File -Path $expectedPath -Text (Get-TestMailCsv -Batch $Batch -IncludeResults $false)
    Write-DurableUtf8File -Path $previewPath -Text $previews.ToString()
    # Original intent remains unchanged when final result files are subsequently written.
    [System.IO.File]::SetAttributes($planPath, ([System.IO.File]::GetAttributes($planPath) -bor [System.IO.FileAttributes]::ReadOnly))
    [System.IO.File]::SetAttributes($expectedPath, ([System.IO.File]::GetAttributes($expectedPath) -bor [System.IO.FileAttributes]::ReadOnly))
    [pscustomobject][ordered]@{ Directory = $fullDirectory; PlanPath = $planPath; ExpectedPath = $expectedPath; PreviewPath = $previewPath }
}

function Get-TestMailSummary {
    [CmdletBinding()]
    param([Parameter(Mandatory = $true)][object]$Batch)

    $summary = [ordered]@{
        Total = @($Batch.Messages).Count
        planned = 0
        submitted = 0
        failed = 0
        unknown = 0
        cancelled = 0
        HighSubmitted = 0
        ImportantSubmitted = 0
        LowSubmitted = 0
    }
    foreach ($message in $Batch.Messages) {
        $status = [string]$message.Status
        if (@('planned', 'submitted', 'failed', 'unknown', 'cancelled') -cnotcontains $status) {
            throw ('Unbekannter Nachrichtenstatus: ' + $status)
        }
        if ($script:PriorityNames -cnotcontains [string]$message.ExpectedPriority) {
            throw ('Unbekannte erwartete Priorität: ' + $message.ExpectedPriority)
        }
        $summary[$status]++
        if ($status -eq 'submitted') {
            switch ($message.ExpectedPriority) {
                'high' { $summary.HighSubmitted++ }
                'important' { $summary.ImportantSubmitted++ }
                'low' { $summary.LowSubmitted++ }
            }
        }
    }
    return [pscustomobject]$summary
}

function Save-TestMailResult {
    [CmdletBinding()]
    param([Parameter(Mandatory = $true)][object]$Batch, [Parameter(Mandatory = $true)][string]$Directory)

    $fullDirectory = [System.IO.Path]::GetFullPath($Directory)
    $planPath = [System.IO.Path]::Combine($fullDirectory, 'plan.json')
    if (-not [System.IO.File]::Exists($planPath)) { throw 'Vor dem Ergebnis muss der unveränderliche Plan gespeichert sein.' }
    $originalPlan = ConvertFrom-Json -InputObject ([System.IO.File]::ReadAllText($planPath, $script:Utf8Bom)) -ErrorAction Stop
    if ($originalPlan.RunId -cne $Batch.RunId) { throw 'Ergebnis und Plan gehören nicht zum selben Lauf.' }
    $summary = Get-TestMailSummary -Batch $Batch
    $result = [ordered]@{
        RunId = $Batch.RunId
        CreatedAt = $Batch.CreatedAt
        UpdatedAt = [DateTimeOffset]::UtcNow.ToString('o', $script:InvariantCulture)
        Seed = $Batch.Seed
        Recipients = [string[]]$Batch.Recipients
        ExpectedCounts = $Batch.Counts
    }
    foreach ($property in $summary.PSObject.Properties) { $result[$property.Name] = $property.Value }
    $result['SubmittedMeaning'] = 'Vom lokalen Versandaufruf ohne Fehler an Outlook übergeben; keine Zustellbestätigung.'
    $resultsPath = [System.IO.Path]::Combine($fullDirectory, 'results.csv')
    $summaryPath = [System.IO.Path]::Combine($fullDirectory, 'summary.json')
    Write-DurableUtf8File -Path $resultsPath -Text (Get-TestMailCsv -Batch $Batch -IncludeResults $true) -Replace $true
    Write-DurableUtf8File -Path $summaryPath -Text ((ConvertTo-Json -InputObject ([pscustomobject]$result) -Depth 10) + "`r`n") -Replace $true
    [pscustomobject][ordered]@{ Directory = $fullDirectory; ResultsPath = $resultsPath; SummaryPath = $summaryPath; Summary = $summary }
}

function Write-TestMailEvent {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][string]$TestId,
        [Parameter(Mandatory = $true)][ValidateSet('planned', 'attempting', 'submitted', 'failed', 'unknown', 'cancelled')][string]$Status,
        [AllowEmptyString()][string]$Detail = ''
    )

    if ($TestId -match '[\r\n]') { throw 'Die Test-ID darf keine Zeilenumbrüche enthalten.' }
    $fullPath = [System.IO.Path]::GetFullPath($Path)
    $parentPath = [System.IO.Path]::GetDirectoryName($fullPath)
    if (-not [System.IO.Directory]::Exists($parentPath)) { throw 'Der Ordner für das Versandjournal fehlt.' }
    $entry = [pscustomobject][ordered]@{
        Timestamp = [DateTimeOffset]::UtcNow.ToString('o', $script:InvariantCulture)
        TestId = $TestId
        Status = $Status.ToLowerInvariant()
        Detail = $Detail
    }
    $line = (ConvertTo-Json -InputObject $entry -Depth 5 -Compress) + "`r`n"
    $stream = $null
    $writer = $null
    try {
        $stream = [System.IO.File]::Open($fullPath, [System.IO.FileMode]::Append, [System.IO.FileAccess]::Write, [System.IO.FileShare]::Read)
        $writer = New-Object System.IO.StreamWriter($stream, $script:Utf8Bom)
        $writer.Write($line)
        $writer.Flush()
        $stream.Flush($true)
    } finally {
        if ($null -ne $writer) { $writer.Dispose() }
        elseif ($null -ne $stream) { $stream.Dispose() }
    }
}

Export-ModuleMember -Function @(
    'Get-PriorityCounts', 'ConvertTo-TestRecipients', 'Get-TestMailTemplates',
    'New-TestMailBatch', 'Save-TestMailPlan', 'Get-TestMailSummary',
    'Save-TestMailResult', 'Write-TestMailEvent'
)
