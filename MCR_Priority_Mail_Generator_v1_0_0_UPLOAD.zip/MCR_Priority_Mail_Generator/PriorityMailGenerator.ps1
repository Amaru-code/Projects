﻿#requires -Version 5.1
<# MCR Priority Mail Generator 1.0.0. Start via STARTEN.cmd. #>
[CmdletBinding()]
param([switch]$SelfTest)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
if ($SelfTest) {
    & (Join-Path $PSScriptRoot 'tests/Run-Tests.ps1')
    exit 0
}
if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) {
    throw 'Das Eingabefenster benoetigt Windows. Die Kernpruefungen sind mit -SelfTest auch ohne Outlook moeglich.'
}
if ([Threading.Thread]::CurrentThread.ApartmentState -ne 'STA') {
    throw 'Bitte STARTEN.cmd verwenden. Das Fenster und Outlook benoetigen den STA-Modus.'
}
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()
Import-Module (Join-Path $PSScriptRoot 'lib/PriorityMail.Core.psm1') -ErrorAction Stop
Import-Module (Join-Path $PSScriptRoot 'lib/PriorityMail.Outlook.psm1') -ErrorAction Stop

$script:batch = $null
$script:connection = $null
$script:lastFolder = ''
$script:busy = $false
$script:cancelRequested = $false
$script:batchAttempted = $false
$script:activeAccount = $null
$script:nextIndex = 0
$script:templatePath = Join-Path $PSScriptRoot 'data/templates.json'
$script:outputRoot = Join-Path $PSScriptRoot 'Output'
$script:priorityNames = @{ high = 'High / urgent'; important = 'Important'; low = 'Unwichtig' }
$script:statusNames = @{ planned = 'Geplant'; submitted = 'Übergeben'; failed = 'Fehler'; unknown = 'Unklar'; cancelled = 'Nicht gestartet' }

function New-Label {
    param([string]$Text, [int]$X, [int]$Y, [int]$Width = 160, [int]$Height = 25)
    $control = New-Object Windows.Forms.Label
    $control.Text = $Text
    $control.Location = [Drawing.Point]::new($X, $Y)
    $control.Size = [Drawing.Size]::new($Width, $Height)
    return $control
}

function New-Number {
    param([int]$X, [int]$Y, [decimal]$Min, [decimal]$Max, [decimal]$Value, [int]$Width = 82)
    $control = New-Object Windows.Forms.NumericUpDown
    $control.Location = [Drawing.Point]::new($X, $Y)
    $control.Size = [Drawing.Size]::new($Width, 28)
    $control.Minimum = $Min
    $control.Maximum = $Max
    $control.Value = $Value
    return $control
}

function Show-UiError {
    param([string]$Text)
    $statusLabel.Text = $Text
    [void][Windows.Forms.MessageBox]::Show($form, $Text, 'Bitte prüfen', 'OK', 'Warning')
}

function Update-Distribution {
    try {
        $counts = Get-PriorityCounts -Total ([int]$countBox.Value) -HighPercent ([int]$highBox.Value) -ImportantPercent ([int]$importantBox.Value) -LowPercent ([int]$lowBox.Value)
        $distributionLabel.Text = '{0} High / urgent   ·   {1} Important   ·   {2} unwichtig' -f $counts.high, $counts.important, $counts.low
        $distributionLabel.ForeColor = [Drawing.Color]::FromArgb(30, 83, 103)
    } catch {
        $distributionLabel.Text = 'Die drei Prozentwerte müssen zusammen 100 % ergeben.'
        $distributionLabel.ForeColor = [Drawing.Color]::Firebrick
    }
}

function Invalidate-Plan {
    if ($script:busy) { return }
    $script:batch = $null
    $script:batchAttempted = $false
    $mailList.Items.Clear()
    $bodyBox.Clear()
    $progress.Value = 0
    $statusLabel.Text = 'Eingaben wählen, dann Vorschau erzeugen oder E-Mails senden.'
    Update-Distribution
}

function Set-UiBusy {
    param([bool]$Value)
    $script:busy = $Value
    $settingsPanel.Enabled = -not $Value
    $previewButton.Enabled = -not $Value
    $sendButton.Enabled = -not $Value
    $cancelButton.Enabled = $Value
}

function Connect-Outlook {
    if ($script:busy) { return }
    $statusLabel.Text = 'Klassisches Outlook verbinden …'
    $statusLabel.Refresh()
    if ($null -ne $script:connection) {
        Close-TestOutlookConnection -Connection $script:connection
        $script:connection = $null
    }
    $accountBox.Items.Clear()
    $script:connection = Get-TestOutlookConnection
    foreach ($entry in $script:connection.Accounts) { [void]$accountBox.Items.Add($entry) }
    if ($accountBox.Items.Count -eq 1) { $accountBox.SelectedIndex = 0 }
    else { $accountBox.SelectedIndex = -1 }
    $statusLabel.Text = 'Outlook verbunden. Absenderkonto und Empfänger prüfen, dann E-Mails senden.'
}

function New-BatchFromForm {
    $recipients = @(ConvertTo-TestRecipients -Text $toBox.Text)
    $batchArgs = @{
        Total = [int]$countBox.Value
        HighPercent = [int]$highBox.Value
        ImportantPercent = [int]$importantBox.Value
        LowPercent = [int]$lowBox.Value
        Recipients = $recipients
        TemplatePath = $script:templatePath
        Seed = Get-Random -Minimum 1 -Maximum ([int]::MaxValue)
        SetOutlookImportance = [bool]$importanceBox.Checked
    }
    $newBatch = New-TestMailBatch @batchArgs
    $folder = Join-Path $script:outputRoot $newBatch.RunId
    $null = Save-TestMailPlan -Batch $newBatch -Directory $folder
    $script:batch = $newBatch
    $script:lastFolder = $folder
    $script:batchAttempted = $false
    $folderButton.Enabled = $true
    $mailList.BeginUpdate()
    try {
        $mailList.Items.Clear()
        foreach ($message in $script:batch.Messages) {
            $item = New-Object Windows.Forms.ListViewItem([string]$message.Index)
            [void]$item.SubItems.Add($script:priorityNames[$message.ExpectedPriority])
            [void]$item.SubItems.Add('Geplant')
            [void]$item.SubItems.Add($message.Subject)
            $item.Tag = $message
            [void]$mailList.Items.Add($item)
        }
    } finally { $mailList.EndUpdate() }
    $bodyBox.Clear()
    if ($mailList.Items.Count -gt 0) { $mailList.Items[0].Selected = $true }
    $progress.Maximum = $script:batch.Messages.Count
    $progress.Value = 0
    $statusLabel.Text = '{0} Testmails erzeugt. Jede geht an alle {1} eingegebenen Empfänger. CSV und Texte sind im Ergebnisordner.' -f $script:batch.Messages.Count, $script:batch.Recipients.Count
}

function Finish-Sending {
    param([string]$Reason)
    $timer.Stop()
    foreach ($message in $script:batch.Messages) {
        if ($message.Status -eq 'planned') {
            $message.Status = 'cancelled'
            $message.Error = $Reason
            $mailList.Items[$message.Index - 1].SubItems[2].Text = 'Nicht gestartet'
        }
    }
    $saveError = ''
    try { $null = Save-TestMailResult -Batch $script:batch -Directory $script:lastFolder }
    catch { $saveError = "`r`nErgebnisdateien konnten nicht vollständig gespeichert werden: " + $_.Exception.Message }
    $summary = Get-TestMailSummary -Batch $script:batch
    Set-UiBusy -Value $false
    $statusLabel.Text = '{0} von {1} an Outlook übergeben. {2} Fehler, {3} unklar, {4} nicht gestartet.' -f $summary.submitted, $summary.Total, $summary.failed, $summary.unknown, $summary.cancelled
    $text = @"
An Outlook zum Versand übergeben: $($summary.submitted) von $($summary.Total) E-Mails

Davon:
  $($summary.HighSubmitted) High / urgent
  $($summary.ImportantSubmitted) Important
  $($summary.LowSubmitted) unwichtig

Fehler vor dem Sendeaufruf: $($summary.failed)
Unklarer Ausgang des Sendeaufrufs: $($summary.unknown)
Nicht gestartet: $($summary.cancelled)

$Reason

Outlook übernimmt den weiteren Versand. Die Zustellung beim Empfänger wird hier nicht bestätigt.

Ergebnisse: $($script:lastFolder)$saveError
"@
    $icon = [Windows.Forms.MessageBoxIcon]::Information
    if ($summary.failed -gt 0 -or $summary.unknown -gt 0 -or $summary.cancelled -gt 0 -or $saveError) {
        $icon = [Windows.Forms.MessageBoxIcon]::Warning
    }
    [void][Windows.Forms.MessageBox]::Show($form, $text, 'Ergebnis des Testmail-Laufs', [Windows.Forms.MessageBoxButtons]::OK, $icon)
}

function Start-Sending {
    if ($script:busy) { return }
    # Validate before connecting Outlook. No recipients are inferred.
    $null = @(ConvertTo-TestRecipients -Text $toBox.Text)
    $null = Get-PriorityCounts -Total ([int]$countBox.Value) -HighPercent ([int]$highBox.Value) -ImportantPercent ([int]$importantBox.Value) -LowPercent ([int]$lowBox.Value)
    if ($null -eq $script:connection) { Connect-Outlook }
    if ($null -eq $accountBox.SelectedItem) { throw 'Bitte das gewünschte Absenderkonto auswählen und erneut auf E-Mails senden klicken.' }
    if ($script:connection.Session.Offline) { throw 'Outlook ist offline. Bitte die Verbindung in Outlook herstellen und erneut starten.' }
    if ($null -eq $script:batch -or $script:batchAttempted) { New-BatchFromForm }
    $script:activeAccount = $accountBox.SelectedItem
    $senderInfo = [pscustomobject]@{
        RunId = $script:batch.RunId
        SenderSmtp = $script:activeAccount.Smtp
        Recipients = $script:batch.Recipients
        StartedAtUtc = [DateTime]::UtcNow.ToString('o')
        IntervalSeconds = [double]$delayBox.Value
        OutlookImportanceEnabled = [bool]$importanceBox.Checked
    }
    [IO.File]::WriteAllText((Join-Path $script:lastFolder 'sender.json'), ($senderInfo | ConvertTo-Json -Depth 5), [Text.UTF8Encoding]::new($false))
    $script:batchAttempted = $true
    $script:cancelRequested = $false
    $script:nextIndex = 0
    $timer.Interval = [int]($delayBox.Value * 1000)
    Set-UiBusy -Value $true
    $statusLabel.Text = 'Versand läuft. Ein Outlook-Hinweis kann eine Bestätigung im Outlook-Fenster erfordern.'
    $timer.Start()
}

$form = New-Object Windows.Forms.Form
$form.Text = 'MCR Priority Mail Generator 1.0.0'
$form.StartPosition = 'CenterScreen'
$form.ClientSize = [Drawing.Size]::new(1080, 810)
$form.MinimumSize = [Drawing.Size]::new(1080, 700)
$form.AutoScaleMode = 'Font'
$form.Font = [Drawing.Font]::new('Segoe UI', 10)
$form.BackColor = [Drawing.Color]::White

$layout = New-Object Windows.Forms.TableLayoutPanel
$layout.Dock = 'Fill'
$layout.Padding = [Windows.Forms.Padding]::new(18)
$layout.ColumnCount = 1
$layout.RowCount = 5
[void]$layout.RowStyles.Add([Windows.Forms.RowStyle]::new([Windows.Forms.SizeType]::Absolute, 65))
[void]$layout.RowStyles.Add([Windows.Forms.RowStyle]::new([Windows.Forms.SizeType]::Absolute, 264))
[void]$layout.RowStyles.Add([Windows.Forms.RowStyle]::new([Windows.Forms.SizeType]::Percent, 100))
[void]$layout.RowStyles.Add([Windows.Forms.RowStyle]::new([Windows.Forms.SizeType]::Absolute, 65))
[void]$layout.RowStyles.Add([Windows.Forms.RowStyle]::new([Windows.Forms.SizeType]::Absolute, 45))
$form.Controls.Add($layout)

$heading = New-Object Windows.Forms.Panel
$heading.Dock = 'Fill'
$title = New-Label -Text 'Testmails für euren Priority Scanner' -X 0 -Y 0 -Width 980 -Height 34
$title.Font = [Drawing.Font]::new('Segoe UI', 19, [Drawing.FontStyle]::Bold)
$title.ForeColor = [Drawing.Color]::FromArgb(20, 50, 78)
$heading.Controls.Add($title)
$heading.Controls.Add((New-Label -Text 'Anzahl wählen · Inhalte mischen · über dein Outlook-Konto versenden' -X 1 -Y 39 -Width 980))
$layout.Controls.Add($heading, 0, 0)

$settingsPanel = New-Object Windows.Forms.Panel
$settingsPanel.Size = [Drawing.Size]::new(1038, 264)
$settingsPanel.Dock = 'Fill'
$settingsPanel.Controls.Add((New-Label -Text 'Empfänger' -X 0 -Y 3 -Width 150))
$toBox = New-Object Windows.Forms.TextBox
$toBox.Location = [Drawing.Point]::new(160, 0)
$toBox.Size = [Drawing.Size]::new(845, 47)
$toBox.Anchor = 'Top, Left, Right'
$toBox.Multiline = $true
$toBox.ScrollBars = 'Vertical'
$settingsPanel.Controls.Add($toBox)
$settingsPanel.Controls.Add((New-Label -Text 'E-Mail-Adressen mit ; trennen. Jede erzeugte Mail geht an alle angegebenen Empfänger (max. 20).' -X 160 -Y 49 -Width 855 -Height 25))

$settingsPanel.Controls.Add((New-Label -Text 'Anzahl E-Mails' -X 0 -Y 85 -Width 150))
$countBox = New-Number -X 160 -Y 80 -Min 1 -Max 10000 -Value 50 -Width 90
$settingsPanel.Controls.Add($countBox)
$settingsPanel.Controls.Add((New-Label -Text 'High / urgent %' -X 280 -Y 85 -Width 130))
$highBox = New-Number -X 415 -Y 80 -Min 0 -Max 100 -Value 20 -Width 65
$settingsPanel.Controls.Add($highBox)
$settingsPanel.Controls.Add((New-Label -Text 'Important %' -X 503 -Y 85 -Width 116))
$importantBox = New-Number -X 623 -Y 80 -Min 0 -Max 100 -Value 70 -Width 65
$settingsPanel.Controls.Add($importantBox)
$settingsPanel.Controls.Add((New-Label -Text 'Unwichtig %' -X 711 -Y 85 -Width 108))
$lowBox = New-Number -X 827 -Y 80 -Min 0 -Max 100 -Value 10 -Width 65
$settingsPanel.Controls.Add($lowBox)
$distributionLabel = New-Label -Text '' -X 160 -Y 112 -Width 845
$settingsPanel.Controls.Add($distributionLabel)

$importanceBox = New-Object Windows.Forms.CheckBox
$importanceBox.Text = 'Outlook-Wichtigkeit passend setzen (Hoch / Normal / Niedrig)'
$importanceBox.Location = [Drawing.Point]::new(160, 144)
$importanceBox.Size = [Drawing.Size]::new(640, 25)
$importanceBox.Checked = $false
$settingsPanel.Controls.Add($importanceBox)
$importanceHint = New-Label -Text 'Ohne Häkchen: alle Mails technisch „Normal“; die drei Klassen unterscheiden sich durch ihren Inhalt.' -X 160 -Y 171 -Width 850
$importanceHint.ForeColor = [Drawing.Color]::DimGray
$settingsPanel.Controls.Add($importanceHint)

$settingsPanel.Controls.Add((New-Label -Text 'Absenderkonto' -X 0 -Y 209 -Width 150))
$accountBox = New-Object Windows.Forms.ComboBox
$accountBox.Location = [Drawing.Point]::new(160, 204)
$accountBox.Size = [Drawing.Size]::new(480, 28)
$accountBox.DropDownStyle = 'DropDownList'
$accountBox.DisplayMember = 'Name'
$settingsPanel.Controls.Add($accountBox)
$connectButton = New-Object Windows.Forms.Button
$connectButton.Text = 'Outlook verbinden'
$connectButton.Location = [Drawing.Point]::new(650, 202)
$connectButton.Size = [Drawing.Size]::new(157, 32)
$settingsPanel.Controls.Add($connectButton)
$settingsPanel.Controls.Add((New-Label -Text 'Pause (s)' -X 823 -Y 209 -Width 83))
$delayBox = New-Number -X 914 -Y 204 -Min 0.2 -Max 60 -Value 0.5 -Width 70
$delayBox.DecimalPlaces = 1
$delayBox.Increment = 0.1
$settingsPanel.Controls.Add($delayBox)
$layout.Controls.Add($settingsPanel, 0, 1)

$split = New-Object Windows.Forms.SplitContainer
$split.Dock = 'Fill'
$split.Orientation = 'Horizontal'
$split.Size = [Drawing.Size]::new(1030, 330)
$split.SplitterDistance = 175
$split.Panel1MinSize = 90
$split.Panel2MinSize = 70
$mailList = New-Object Windows.Forms.ListView
$mailList.Dock = 'Fill'
$mailList.View = 'Details'
$mailList.FullRowSelect = $true
$mailList.HideSelection = $false
$mailList.MultiSelect = $false
$mailList.GridLines = $true
[void]$mailList.Columns.Add('Nr.', 48)
[void]$mailList.Columns.Add('Erwartete Klasse', 140)
[void]$mailList.Columns.Add('Status', 130)
[void]$mailList.Columns.Add('Betreff', 680)
$split.Panel1.Controls.Add($mailList)
$bodyBox = New-Object Windows.Forms.TextBox
$bodyBox.Dock = 'Fill'
$bodyBox.Multiline = $true
$bodyBox.ReadOnly = $true
$bodyBox.ScrollBars = 'Vertical'
$bodyBox.BackColor = [Drawing.Color]::FromArgb(247, 249, 252)
$split.Panel2.Controls.Add($bodyBox)
$layout.Controls.Add($split, 0, 2)

$actions = New-Object Windows.Forms.FlowLayoutPanel
$actions.Dock = 'Fill'
$actions.Padding = [Windows.Forms.Padding]::new(0, 14, 0, 0)
$previewButton = New-Object Windows.Forms.Button
$previewButton.Text = 'Vorschau erzeugen'
$previewButton.Size = [Drawing.Size]::new(180, 38)
$actions.Controls.Add($previewButton)
$sendButton = New-Object Windows.Forms.Button
$sendButton.Text = 'E-Mails senden'
$sendButton.Size = [Drawing.Size]::new(180, 38)
$sendButton.BackColor = [Drawing.Color]::FromArgb(25, 93, 149)
$sendButton.ForeColor = [Drawing.Color]::White
$sendButton.FlatStyle = 'Flat'
$actions.Controls.Add($sendButton)
$cancelButton = New-Object Windows.Forms.Button
$cancelButton.Text = 'Abbrechen'
$cancelButton.Size = [Drawing.Size]::new(135, 38)
$cancelButton.Enabled = $false
$actions.Controls.Add($cancelButton)
$folderButton = New-Object Windows.Forms.Button
$folderButton.Text = 'Ergebnisordner öffnen'
$folderButton.Size = [Drawing.Size]::new(205, 38)
$folderButton.Enabled = $false
$actions.Controls.Add($folderButton)
$layout.Controls.Add($actions, 0, 3)

$footer = New-Object Windows.Forms.Panel
$footer.Dock = 'Fill'
$statusLabel = New-Label -Text 'Empfänger und Anzahl wählen. Mit „Vorschau erzeugen“ kannst du alle Texte vorab ansehen.' -X 0 -Y 0 -Width 1010 -Height 25
$statusLabel.Dock = 'Top'
$footer.Controls.Add($statusLabel)
$progress = New-Object Windows.Forms.ProgressBar
$progress.Dock = 'Bottom'
$progress.Height = 10
$footer.Controls.Add($progress)
$layout.Controls.Add($footer, 0, 4)

$timer = New-Object Windows.Forms.Timer
$timer.Add_Tick({
    $timer.Stop()
    if (-not $script:busy) { return }
    try {
        if ($script:cancelRequested) { Finish-Sending -Reason 'Der Lauf wurde abgebrochen. Bereits übergebene E-Mails bleiben versendet bzw. im Outlook-Postausgang.'; return }
        if ($script:nextIndex -ge $script:batch.Messages.Count) { Finish-Sending -Reason 'Alle geplanten E-Mails wurden an Outlook übergeben.'; return }
        $message = $script:batch.Messages[$script:nextIndex]
        $outcome = Invoke-TestMailSubmission -Message $message -Recipients $script:batch.Recipients -Outlook $script:connection.Application -Account $script:activeAccount.ComAccount -AccountSmtp $script:activeAccount.Smtp -EventPath (Join-Path $script:lastFolder 'events.jsonl')
        $mailList.Items[$script:nextIndex].SubItems[2].Text = $script:statusNames[$message.Status]
        $script:nextIndex++
        $progress.Value = $script:nextIndex
        $statusLabel.Text = '{0} von {1} bearbeitet. Letzte Mail: {2}.' -f $script:nextIndex, $script:batch.Messages.Count, $script:statusNames[$message.Status]
        if ($outcome.Halt) { Finish-Sending -Reason $outcome.Detail; return }
        if ($script:nextIndex -ge $script:batch.Messages.Count) { Finish-Sending -Reason 'Alle geplanten E-Mails wurden an Outlook übergeben.'; return }
        $timer.Start()
    } catch {
        Finish-Sending -Reason ('Der Lauf wurde wegen eines Fehlers angehalten: ' + $_.Exception.Message)
    }
})

$previewButton.Add_Click({ try { New-BatchFromForm } catch { Show-UiError $_.Exception.Message } })
$connectButton.Add_Click({ try { Connect-Outlook } catch { Show-UiError $_.Exception.Message } })
$sendButton.Add_Click({ try { Start-Sending } catch { Set-UiBusy -Value $false; Show-UiError $_.Exception.Message } })
$cancelButton.Add_Click({
    $script:cancelRequested = $true
    $cancelButton.Enabled = $false
    $statusLabel.Text = 'Abbruch angefordert. Weitere E-Mails werden nicht gestartet.'
})
$folderButton.Add_Click({
    try {
        if ($script:lastFolder -and [IO.Directory]::Exists($script:lastFolder)) { Start-Process -FilePath $script:lastFolder }
    } catch { Show-UiError $_.Exception.Message }
})
$mailList.Add_SelectedIndexChanged({
    if ($mailList.SelectedItems.Count -gt 0) {
        $selected = $mailList.SelectedItems[0].Tag
        $bodyBox.Text = $selected.Subject + "`r`n`r`n" + ($selected.Body -replace "\r?\n", "`r`n")
    }
})
$toBox.Add_TextChanged({ Invalidate-Plan })
$countBox.Add_ValueChanged({ Invalidate-Plan })
$highBox.Add_ValueChanged({ Invalidate-Plan })
$importantBox.Add_ValueChanged({ Invalidate-Plan })
$lowBox.Add_ValueChanged({ Invalidate-Plan })
$importanceBox.Add_CheckedChanged({ Invalidate-Plan })
$form.Add_FormClosing({
    param($sender, $eventArgs)
    if ($script:busy) {
        $eventArgs.Cancel = $true
        $script:cancelRequested = $true
        $statusLabel.Text = 'Lauf wird beendet. Danach kann das Fenster geschlossen werden.'
    }
})

Update-Distribution
try { [void]$form.ShowDialog() }
finally {
    $timer.Stop()
    $timer.Dispose()
    Close-TestOutlookConnection -Connection $script:connection
    $form.Dispose()
}
