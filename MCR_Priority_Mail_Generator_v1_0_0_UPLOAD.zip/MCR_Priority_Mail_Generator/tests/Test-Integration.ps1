﻿#requires -Version 5.1
<#
    One integrated 50-message run with the actual bundled templates and fake Outlook.
    This never activates Outlook, calls a network API, or sends a real email.
#>
[CmdletBinding()]
param(
    [string]$ProjectRoot = (Split-Path -Parent $PSScriptRoot)
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $ProjectRoot 'lib/PriorityMail.Core.psm1') -Force -ErrorAction Stop
Import-Module (Join-Path $ProjectRoot 'lib/PriorityMail.Outlook.psm1') -Force -ErrorAction Stop

$script:IntegrationChecks = 0
$testRoot = Join-Path ([IO.Path]::GetTempPath()) ('MCR-Integration-Mock-' + [Guid]::NewGuid().ToString('N'))

function Assert-Integration {
    param([bool]$Condition, [string]$Description)
    if (-not $Condition) { throw ('FAILED INTEGRATION: ' + $Description) }
    $script:IntegrationChecks++
}

try {
    $recipients = @('first@example.invalid', 'second@example.invalid')
    $batch = New-TestMailBatch -Total 50 -HighPercent 20 -ImportantPercent 70 -LowPercent 10 `
        -Recipients $recipients -TemplatePath (Join-Path $ProjectRoot 'data/templates.json') `
        -Seed 20261006 -SetOutlookImportance $false

    Assert-Integration ($batch.Messages.Count -eq 50) 'The real corpus must generate exactly 50 messages.'
    Assert-Integration ($batch.Counts.high -eq 10 -and $batch.Counts.important -eq 35 -and $batch.Counts.low -eq 5) 'The planned split must be exactly 10/35/5.'
    Assert-Integration (($batch.Recipients -join ';') -eq ($recipients -join ';')) 'Both intended recipients must survive generation unchanged.'

    $paths = Save-TestMailPlan -Batch $batch -Directory $testRoot
    $planHashBefore = (Get-FileHash -LiteralPath $paths.PlanPath -Algorithm SHA256).Hash
    $truthHashBefore = (Get-FileHash -LiteralPath $paths.ExpectedPath -Algorithm SHA256).Hash
    $eventPath = Join-Path $testRoot 'events.jsonl'

    $account = [pscustomobject]@{ SmtpAddress = 'sender@example.invalid' }
    $state = [pscustomobject]@{
        CreateCalls = 0
        SendCalls = 0
        RecipientAdds = 0
        ResolveCalls = 0
        Sent = (New-Object 'System.Collections.Generic.List[object]')
    }
    $outlook = [pscustomobject]@{ State = $state }
    $outlook | Add-Member -MemberType ScriptMethod -Name CreateItem -Value {
        param([int]$ItemType)
        if ($ItemType -ne 0) { throw 'A non-mail Outlook item was requested.' }
        $this.State.CreateCalls++
        $recipientCollection = [pscustomobject]@{
            State = $this.State
            Items = (New-Object 'System.Collections.Generic.List[object]')
        }
        $recipientCollection | Add-Member -MemberType ScriptMethod -Name Add -Value {
            param([string]$Address)
            $recipient = [pscustomobject]@{ Address = $Address; Type = 0 }
            [void]$this.Items.Add($recipient)
            $this.State.RecipientAdds++
            return $recipient
        }
        $recipientCollection | Add-Member -MemberType ScriptMethod -Name ResolveAll -Value {
            $this.State.ResolveCalls++
            return ($this.Items.Count -eq 2)
        }
        $mail = [pscustomobject]@{
            State = $this.State
            Subject = ''
            BodyFormat = 0
            Body = ''
            Importance = -1
            SendUsingAccount = $null
            Recipients = $recipientCollection
        }
        $mail | Add-Member -MemberType ScriptMethod -Name Send -Value {
            $this.State.SendCalls++
            [void]$this.State.Sent.Add([pscustomobject]@{
                Subject = $this.Subject
                Body = $this.Body
                BodyFormat = $this.BodyFormat
                Importance = $this.Importance
                Account = $this.SendUsingAccount
                Recipients = [string[]]@($this.Recipients.Items | ForEach-Object { $_.Address })
                RecipientTypes = [int[]]@($this.Recipients.Items | ForEach-Object { $_.Type })
            })
        }
        return $mail
    }

    foreach ($message in $batch.Messages) {
        $result = Invoke-TestMailSubmission -Message $message -Recipients $batch.Recipients `
            -Outlook $outlook -Account $account -AccountSmtp $account.SmtpAddress -EventPath $eventPath
        Assert-Integration ($result.Status -eq 'submitted' -and -not $result.Halt) ('Message ' + $message.Index + ' must submit exactly once.')
    }

    Assert-Integration ($state.CreateCalls -eq 50 -and $state.SendCalls -eq 50 -and $state.Sent.Count -eq 50) '50 requested messages must mean 50 Send calls, not 50 per recipient.'
    Assert-Integration ($state.RecipientAdds -eq 100 -and $state.ResolveCalls -eq 50) 'Each of the 50 separate messages must receive and resolve exactly two recipients.'

    for ($i = 0; $i -lt 50; $i++) {
        $sent = $state.Sent[$i]
        $planned = $batch.Messages[$i]
        Assert-Integration (($sent.Recipients -join ';') -eq ($recipients -join ';') -and @($sent.RecipientTypes | Where-Object { $_ -ne 1 }).Count -eq 0) ('Message ' + ($i + 1) + ' must address both recipients as To.')
        Assert-Integration ([object]::ReferenceEquals($sent.Account, $account)) ('Message ' + ($i + 1) + ' must use the selected account.')
        Assert-Integration ($sent.Subject -eq $planned.Subject -and $sent.Body -eq $planned.Body -and $sent.BodyFormat -eq 1) ('Message ' + ($i + 1) + ' must preserve the generated text.')
        Assert-Integration ($sent.Importance -eq 1) ('Message ' + ($i + 1) + ' must carry neutral Outlook importance.')
        Assert-Integration (($sent.Subject + "`n" + $sent.Body) -notmatch '(?im)\b(?:ExpectedPriority|TemplateId)\b|\b(?:H|I|L)\d{2}\b|^\s*(?:Priority|Prioritaet|Klasse)\s*:') ('Message ' + ($i + 1) + ' must not leak machine-readable truth labels or template IDs.')
    }

    $saved = Save-TestMailResult -Batch $batch -Directory $testRoot
    $summary = [IO.File]::ReadAllText($saved.SummaryPath) | ConvertFrom-Json
    $results = @(Import-Csv -LiteralPath $saved.ResultsPath -Delimiter ';' -Encoding UTF8)
    $truth = @(Import-Csv -LiteralPath $paths.ExpectedPath -Delimiter ';' -Encoding UTF8)
    Assert-Integration ($summary.Total -eq 50 -and $summary.submitted -eq 50) 'The saved summary must contain exactly 50 submitted messages.'
    Assert-Integration ($summary.HighSubmitted -eq 10 -and $summary.ImportantSubmitted -eq 35 -and $summary.LowSubmitted -eq 5) 'The saved submitted split must be exactly 10/35/5.'
    Assert-Integration ($summary.failed -eq 0 -and $summary.unknown -eq 0 -and $summary.cancelled -eq 0 -and $summary.planned -eq 0) 'The successful run must have no other outcomes.'
    Assert-Integration ($results.Count -eq 50 -and @($results | Where-Object { $_.Status -ne 'submitted' }).Count -eq 0) 'All 50 CSV rows must be submitted.'
    Assert-Integration (@($results | Where-Object { $_.ExpectedPriority -eq 'high' }).Count -eq 10 -and @($results | Where-Object { $_.ExpectedPriority -eq 'important' }).Count -eq 35 -and @($results | Where-Object { $_.ExpectedPriority -eq 'low' }).Count -eq 5) 'CSV class counts must agree with the summary.'
    Assert-Integration ($truth.Count -eq 50 -and ($results.TestId -join ';') -eq ($truth.TestId -join ';')) 'The results must match the original truth file one-to-one.'
    Assert-Integration ((Get-FileHash -LiteralPath $paths.PlanPath -Algorithm SHA256).Hash -eq $planHashBefore) 'The original plan must remain byte-for-byte unchanged.'
    Assert-Integration ((Get-FileHash -LiteralPath $paths.ExpectedPath -Algorithm SHA256).Hash -eq $truthHashBefore) 'The expected-priority CSV must remain byte-for-byte unchanged.'

    $events = @([IO.File]::ReadAllLines($eventPath) | ForEach-Object { $_ | ConvertFrom-Json })
    Assert-Integration ($events.Count -eq 100) '50 messages must produce exactly 100 intent/result events.'
    for ($i = 0; $i -lt 50; $i++) {
        $intent = $events[2 * $i]
        $submitted = $events[2 * $i + 1]
        Assert-Integration ($intent.Status -eq 'attempting' -and $submitted.Status -eq 'submitted' -and $intent.TestId -eq $batch.Messages[$i].TestId -and $submitted.TestId -eq $intent.TestId) ('Journal pair ' + ($i + 1) + ' must bind attempting then submitted to one message.')
    }

    Write-Host ('INTEGRATION_TEST=PASS; MESSAGES=50; SPLIT=10/35/5; FAKE_SEND_CALLS=50; RECIPIENT_ADDITIONS=100; JOURNAL_EVENTS=100; ASSERTIONS=' + $script:IntegrationChecks + '; REAL_MAILS_SENT=0')
} finally {
    if ([IO.Directory]::Exists($testRoot)) {
        Remove-Item -LiteralPath $testRoot -Recurse -Force -ErrorAction Stop
    }
}
