﻿#requires -Version 5.1
[CmdletBinding()]
param([string]$ModulePath = (Join-Path $PSScriptRoot '../lib/PriorityMail.Core.psm1'))

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module $ModulePath -Force -ErrorAction Stop
$script:Passed = 0
$script:Failures = New-Object 'System.Collections.Generic.List[string]'
$script:TestRoot = Join-Path ([System.IO.Path]::GetTempPath()) ('MCR-Priority-Core-Tests-' + [guid]::NewGuid().ToString('N'))
[void][System.IO.Directory]::CreateDirectory($script:TestRoot)
$script:Encoding = New-Object System.Text.UTF8Encoding($true, $true)

function Assert-Equal {
    param([object]$Actual, [object]$Expected, [string]$Because = '')
    if ($Actual -cne $Expected) { throw ('Erwartet: [{0}], erhalten: [{1}]. {2}' -f $Expected, $Actual, $Because) }
}
function Assert-True {
    param([bool]$Condition, [string]$Because)
    if (-not $Condition) { throw $Because }
}
function Assert-Throws {
    param([scriptblock]$Action, [string]$Because)
    $threw = $false
    try { $null = & $Action } catch { $threw = $true }
    if (-not $threw) { throw ('Erwarteter Fehler blieb aus: ' + $Because) }
}
function Invoke-Check {
    param([string]$Name, [scriptblock]$Body)
    try {
        & $Body
        $script:Passed++
        Write-Host ('PASS  ' + $Name)
    } catch {
        [void]$script:Failures.Add($Name + ': ' + $_.Exception.Message)
        Write-Host ('FAIL  ' + $Name + ': ' + $_.Exception.Message) -ForegroundColor Red
    }
}
function New-Fixture {
    $classes = [ordered]@{}
    foreach ($priority in @('high', 'important', 'low')) {
        $items = @()
        for ($i = 1; $i -le 3; $i++) {
            $items += [pscustomobject][ordered]@{
                id = $priority + '_' + $i
                subject = 'Projekt {project}: Rückmeldung zu {case}'
                body = "Hallo {name},`n`nbitte prüfe den Vorgang {case} für {project}. Termin: {next_date}, {time}.`nVielen Dank."
            }
        }
        $classes[$priority] = $items
    }
    return [pscustomobject][ordered]@{ schema_version = 1; classes = [pscustomobject]$classes }
}
function Save-Fixture {
    param([object]$Fixture, [string]$Name = '')
    if ([string]::IsNullOrEmpty($Name)) { $Name = [guid]::NewGuid().ToString('N') + '.json' }
    $path = Join-Path $script:TestRoot $Name
    [System.IO.File]::WriteAllText($path, (ConvertTo-Json -InputObject $Fixture -Depth 12), $script:Encoding)
    return $path
}
function New-FixtureBatch {
    param([int]$Total = 50, [int]$Seed = 42, [bool]$SetOutlookImportance = $false)
    return New-TestMailBatch -Total $Total -HighPercent 20 -ImportantPercent 70 -LowPercent 10 -Recipients @('tester@example.invalid', 'Second@Example.Invalid') -TemplatePath $script:FixturePath -Seed $Seed -SetOutlookImportance $SetOutlookImportance
}
function Assert-Utf8Bom {
    param([string]$Path)
    $bytes = [System.IO.File]::ReadAllBytes($Path)
    Assert-True ($bytes.Length -ge 3) ('Datei ist zu kurz: ' + $Path)
    Assert-Equal ($bytes[0..2] -join ',') '239,187,191' 'UTF-8-BOM fehlt.'
    $null = (New-Object System.Text.UTF8Encoding($false, $true)).GetString($bytes)
}

try {
    $script:FixturePath = Save-Fixture -Fixture (New-Fixture) -Name 'valid.json'

    Invoke-Check '50 Nachrichten ergeben exakt 10 high, 35 important, 5 low' {
        $counts = Get-PriorityCounts -Total 50 -HighPercent 20 -ImportantPercent 70 -LowPercent 10
        Assert-Equal $counts.high 10
        Assert-Equal $counts.important 35
        Assert-Equal $counts.low 5
    }
    Invoke-Check 'Größter Rest und deterministische Gleichstände' {
        $one = Get-PriorityCounts -Total 1 -HighPercent 50 -ImportantPercent 50 -LowPercent 0
        Assert-Equal ($one.high.ToString() + ',' + $one.important + ',' + $one.low) '1,0,0'
        $two = Get-PriorityCounts -Total 2 -HighPercent 34 -ImportantPercent 33 -LowPercent 33
        Assert-Equal ($two.high.ToString() + ',' + $two.important + ',' + $two.low) '1,1,0'
        $low = Get-PriorityCounts -Total 1 -HighPercent 33 -ImportantPercent 33 -LowPercent 34
        Assert-Equal $low.low 1
        $three = Get-PriorityCounts -Total 3 -HighPercent 20 -ImportantPercent 70 -LowPercent 10
        Assert-Equal ($three.high.ToString() + ',' + $three.important + ',' + $three.low) '1,2,0'
    }
    Invoke-Check '500 unabhängige Summen- und Rundungsinvarianten' {
        $random = New-Object System.Random(271828)
        for ($i = 0; $i -lt 500; $i++) {
            $total = $random.Next(1, 10001)
            $high = $random.Next(0, 101)
            $important = $random.Next(0, 101 - $high)
            $low = 100 - $high - $important
            $counts = Get-PriorityCounts -Total $total -HighPercent $high -ImportantPercent $important -LowPercent $low
            Assert-Equal ($counts.high + $counts.important + $counts.low) $total
            $percents = @($high, $important, $low)
            $names = @('high', 'important', 'low')
            for ($j = 0; $j -lt 3; $j++) {
                $quota = $total * $percents[$j] / 100.0
                $name = $names[$j]
                Assert-True ($counts.$name -ge [Math]::Floor($quota) -and $counts.$name -le [Math]::Ceiling($quota)) 'Rundungsquote verletzt.'
                Assert-True ($counts.$name -is [int]) 'Anzahlen müssen ganze Zahlen sein.'
            }
        }
    }
    Invoke-Check 'Null-Prozent-Klassen und obere Mengenbegrenzung' {
        $counts = Get-PriorityCounts -Total 10000 -HighPercent 0 -ImportantPercent 0 -LowPercent 100
        Assert-Equal $counts.high 0
        Assert-Equal $counts.important 0
        Assert-Equal $counts.low 10000
    }
    Invoke-Check 'Ungültige Anzahl und Prozentwerte werden abgelehnt' {
        Assert-Throws { Get-PriorityCounts -Total 0 -HighPercent 20 -ImportantPercent 70 -LowPercent 10 } 'Total=0'
        Assert-Throws { Get-PriorityCounts -Total 10001 -HighPercent 20 -ImportantPercent 70 -LowPercent 10 } 'Total>10000'
        Assert-Throws { Get-PriorityCounts -Total 50 -HighPercent 20 -ImportantPercent 70 -LowPercent 11 } 'Summe 101'
        Assert-Throws { Get-PriorityCounts -Total 50 -HighPercent -1 -ImportantPercent 91 -LowPercent 10 } 'Negative Prozentzahl'
    }
    Invoke-Check 'Empfänger normalisieren, trennen und ohne Duplikate ausgeben' {
        $items = @(ConvertTo-TestRecipients -Text " First@EXAMPLE.invalid ; second+tag@example.invalid, first@example.invalid`r`nThird@example.invalid; ")
        Assert-Equal $items.Count 3
        Assert-Equal ($items -join '|') 'First@example.invalid|second+tag@example.invalid|Third@example.invalid'
        Assert-True ($items[0] -is [string]) 'Pipeline muss einzelne Strings ausgeben.'
    }
    Invoke-Check 'Genau ein Empfänger bleibt ein einzelner String' {
        $items = @(ConvertTo-TestRecipients -Text 'a@example.invalid')
        Assert-Equal $items.Count 1
        Assert-Equal $items[0] 'a@example.invalid'
    }
    Invoke-Check 'Leere und syntaktisch falsche Empfänger werden abgelehnt' {
        foreach ($text in @('', ';,', 'ohne-at', 'x..y@example.invalid', '.x@example.invalid', 'x.@example.invalid', 'a@-example.invalid', 'a@example-.invalid', 'a@b..invalid', 'a@example.invalid b@example.invalid')) {
            Assert-Throws { ConvertTo-TestRecipients -Text $text } $text
        }
    }
    Invoke-Check 'Anzeigenamen und Header-Injektionen werden abgelehnt' {
        foreach ($text in @('Name <a@example.invalid>', 'a@example.invalid (Name)', 'a@example.invalid:25', "a@example.invalid`r`nBcc: b@example.invalid", "a@example.invalid`tb@example.invalid", ('a@example.invalid' + [char]0))) {
            Assert-Throws { ConvertTo-TestRecipients -Text $text } 'Anzeigename/Steuerzeichen/Header'
        }
    }
    Invoke-Check 'Maximal 20 einzigartige Empfänger; Wiederholungen zählen nicht doppelt' {
        $addresses = @(1..20 | ForEach-Object { 'user' + $_ + '@example.invalid' })
        Assert-Equal (@(ConvertTo-TestRecipients -Text ($addresses -join ';'))).Count 20
        Assert-Equal (@(ConvertTo-TestRecipients -Text (($addresses + $addresses) -join ';'))).Count 20
        Assert-Throws { ConvertTo-TestRecipients -Text (($addresses + 'last@example.invalid') -join ';') } '21 Empfänger'
    }
    Invoke-Check 'Gültige UTF-8-Vorlagen und alle drei Klassen' {
        $templates = Get-TestMailTemplates -Path $script:FixturePath
        Assert-Equal $templates.schema_version 1
        Assert-Equal $templates.classes.high.Count 3
        Assert-True ($templates.classes.high[0].subject.Contains('Rückmeldung')) 'Umlaut beschädigt.'
    }
    Invoke-Check 'Fehlende Datei, ungültiges JSON und ungültiges UTF-8' {
        Assert-Throws { Get-TestMailTemplates -Path (Join-Path $script:TestRoot 'missing.json') } 'Fehlende Datei'
        $path = Join-Path $script:TestRoot 'malformed.json'
        [System.IO.File]::WriteAllText($path, '{"schema_version":1,', $script:Encoding)
        Assert-Throws { Get-TestMailTemplates -Path $path } 'Ungültiges JSON'
        $path = Join-Path $script:TestRoot 'bad-utf8.json'
        [System.IO.File]::WriteAllBytes($path, [byte[]]@(123, 255, 125))
        Assert-Throws { Get-TestMailTemplates -Path $path } 'Ungültige UTF-8-Bytes'
    }
    Invoke-Check 'Falsche Schemaversion und fehlende Klasse werden abgelehnt' {
        $fixture = New-Fixture
        $fixture.schema_version = '1'
        $path = Save-Fixture $fixture
        Assert-Throws { Get-TestMailTemplates $path } 'String statt Ganzzahl'
        $fixture = New-Fixture
        $fixture.classes.PSObject.Properties.Remove('low')
        $path = Save-Fixture $fixture
        Assert-Throws { Get-TestMailTemplates $path } 'Fehlende low-Klasse'
    }
    Invoke-Check 'Leere und skalare Vorlagenklassen werden abgelehnt' {
        $fixture = New-Fixture
        $fixture.classes.high = @()
        $path = Save-Fixture $fixture
        Assert-Throws { Get-TestMailTemplates $path } 'Leere Klasse'
        $fixture = New-Fixture
        $fixture.classes.high = $fixture.classes.high[0]
        $path = Save-Fixture $fixture
        Assert-Throws { Get-TestMailTemplates $path } 'Objekt statt Liste'
    }
    Invoke-Check 'Vorlagen-ID muss über alle Klassen eindeutig sein' {
        $fixture = New-Fixture
        $fixture.classes.low[0].id = $fixture.classes.high[0].id.ToUpperInvariant()
        $path = Save-Fixture $fixture
        Assert-Throws { Get-TestMailTemplates $path } 'Klassenübergreifende doppelte ID'
    }
    Invoke-Check 'Leere Texte, lange Betreffe und Betreff-Zeilenumbrüche werden abgelehnt' {
        foreach ($subject in @('', ('x' * 151), "Betreff`r`nBcc: anderer@example.invalid")) {
            $fixture = New-Fixture
            $fixture.classes.high[0].subject = $subject
            $path = Save-Fixture $fixture
            Assert-Throws { Get-TestMailTemplates $path } 'Ungültiger Betreff'
        }
        $fixture = New-Fixture
        $fixture.classes.high[0].body = ' '
        $path = Save-Fixture $fixture
        Assert-Throws { Get-TestMailTemplates $path } 'Leerer Text'
    }
    Invoke-Check 'Unbekannte und unvollständige Platzhalter werden abgelehnt' {
        foreach ($token in @('{priority}', '{urgent}', '{case', '{{name}}', '{Name}')) {
            $fixture = New-Fixture
            $fixture.classes.high[0].body += $token
            $path = Save-Fixture $fixture
            Assert-Throws { Get-TestMailTemplates $path } ('Ungültiger Platzhalter ' + $token)
        }
    }
    Invoke-Check 'Generierung hält Mengen, Empfänger und eindeutige IDs ein' {
        $batch = New-FixtureBatch
        Assert-Equal $batch.Messages.Count 50
        Assert-Equal $batch.Recipients.Count 2
        Assert-Equal (@($batch.Messages | Where-Object { $_.ExpectedPriority -eq 'high' })).Count 10
        Assert-Equal (@($batch.Messages | Where-Object { $_.ExpectedPriority -eq 'important' })).Count 35
        Assert-Equal (@($batch.Messages | Where-Object { $_.ExpectedPriority -eq 'low' })).Count 5
        Assert-Equal (@($batch.Messages.TestId | Sort-Object -Unique)).Count 50
        Assert-Equal $batch.Messages[49].Index 50
        Assert-True ($batch.Messages[49].TestId.EndsWith('-00050')) 'Falsche Test-ID.'
    }
    Invoke-Check 'Neutraler Header und keine maschinellen Wahrheitslabels im Mailtext' {
        $batch = New-FixtureBatch
        foreach ($message in $batch.Messages) {
            Assert-Equal $message.OutlookImportance 1
            Assert-Equal $message.Status 'planned'
            Assert-True ($message.Subject.StartsWith('[PRIO-TEST ' + $message.TestId + '] ')) 'Test-ID fehlt im Betreff.'
            Assert-True ($message.Body.Contains('Test-ID: ' + $message.TestId)) 'Test-ID fehlt im Text.'
            Assert-True (-not (($message.Subject + $message.Body) -match '\{[^}]*\}')) 'Nicht gefüllter Platzhalter.'
            Assert-True (-not (($message.Subject + $message.Body) -match 'ExpectedPriority|TemplateId|high_|important_|low_')) 'Wahrheitslabel im Inhalt.'
            Assert-True ($message.Body.Contains('Synthetische Testnachricht für den Priority-Scanner.')) 'Testhinweis fehlt.'
        }
    }
    Invoke-Check 'Outlook-Klassenmarkierung nur nach ausdrücklicher Option' {
        $batch = New-FixtureBatch -SetOutlookImportance $true
        foreach ($message in $batch.Messages) {
            $expected = @{ high = 2; important = 1; low = 0 }[$message.ExpectedPriority]
            Assert-Equal $message.OutlookImportance $expected
        }
    }
    Invoke-Check 'Zufällige Reihenfolge ist reproduzierbar, aber nicht nach Klasse sortiert' {
        $first = New-FixtureBatch -Seed 42
        $second = New-FixtureBatch -Seed 42
        $third = New-FixtureBatch -Seed 43
        Assert-Equal ($first.Messages.ExpectedPriority -join ',') ($second.Messages.ExpectedPriority -join ',')
        Assert-Equal ($first.Messages.TemplateId -join ',') ($second.Messages.TemplateId -join ',')
        Assert-True (($first.Messages.ExpectedPriority -join ',') -cne ($third.Messages.ExpectedPriority -join ',')) 'Anderer Seed ohne Einfluss.'
        Assert-True ($first.RunId -cne $second.RunId) 'Lauf-IDs sind nicht eindeutig.'
        $transitions = 0
        for ($i = 1; $i -lt $first.Messages.Count; $i++) {
            if ($first.Messages[$i].ExpectedPriority -cne $first.Messages[$i - 1].ExpectedPriority) { $transitions++ }
        }
        Assert-True ($transitions -gt 2) 'Klassen wurden nur blockweise angeordnet.'
    }
    Invoke-Check 'Vorlagenauswahl nutzt jede Vorlage vor Wiederholung eines Zyklus' {
        $batch = New-FixtureBatch
        foreach ($priority in @('high', 'important', 'low')) {
            $items = @($batch.Messages | Where-Object { $_.ExpectedPriority -eq $priority })
            for ($offset = 0; $offset + 3 -le $items.Count; $offset += 3) {
                $ids = @($items[$offset..($offset + 2)].TemplateId | Sort-Object -Unique)
                Assert-Equal $ids.Count 3
            }
        }
    }
    Invoke-Check 'Ein-Nachrichten-Batch und Ein-Vorlagen-Klassen funktionieren' {
        $fixture = New-Fixture
        foreach ($priority in @('high', 'important', 'low')) { $fixture.classes.$priority = @($fixture.classes.$priority[0]) }
        $path = Save-Fixture $fixture
        $batch = New-TestMailBatch -Total 1 -HighPercent 100 -ImportantPercent 0 -LowPercent 0 -Recipients @('one@example.invalid') -TemplatePath $path -Seed 1
        Assert-Equal $batch.Messages.Count 1
        Assert-Equal $batch.Messages[0].ExpectedPriority 'high'
        Assert-Equal $batch.Recipients.Count 1
    }
    Invoke-Check 'Plan, Excel-CSV und vollständige Vorschau werden mit UTF-8-BOM gespeichert' {
        $batch = New-FixtureBatch
        $directory = Join-Path $script:TestRoot 'saved-plan'
        $saved = Save-TestMailPlan -Batch $batch -Directory $directory
        foreach ($path in @($saved.PlanPath, $saved.ExpectedPath, $saved.PreviewPath)) { Assert-Utf8Bom $path }
        $plan = ConvertFrom-Json -InputObject ([System.IO.File]::ReadAllText($saved.PlanPath, $script:Encoding))
        Assert-Equal $plan.Messages.Count 50
        $csv = @(Import-Csv -LiteralPath $saved.ExpectedPath -Delimiter ';' -Encoding UTF8)
        Assert-Equal $csv.Count 50
        Assert-Equal $csv[0].Recipients 'tester@example.invalid; Second@example.invalid'
        $previews = [System.IO.File]::ReadAllText($saved.PreviewPath, $script:Encoding)
        foreach ($message in $batch.Messages) {
            Assert-True ($previews.Contains($message.Subject) -and $previews.Contains($message.Body)) 'Unvollständige Vorschau.'
        }
        Assert-True (([System.IO.File]::GetAttributes($saved.PlanPath) -band [System.IO.FileAttributes]::ReadOnly) -ne 0) 'Plan nicht schreibgeschützt.'
    }
    Invoke-Check 'Leerer Zielordner erlaubt; vorhandener Plan wird niemals überschrieben' {
        $batch = New-FixtureBatch
        $directory = Join-Path $script:TestRoot 'preexisting-empty'
        [void][System.IO.Directory]::CreateDirectory($directory)
        $saved = Save-TestMailPlan -Batch $batch -Directory $directory
        $before = (Get-FileHash -LiteralPath $saved.PlanPath -Algorithm SHA256).Hash
        Assert-Throws { Save-TestMailPlan -Batch $batch -Directory $directory } 'Vorhandener Plan'
        Assert-Equal (Get-FileHash -LiteralPath $saved.PlanPath -Algorithm SHA256).Hash $before
        $other = Join-Path $script:TestRoot 'occupied'
        [void][System.IO.Directory]::CreateDirectory($other)
        [System.IO.File]::WriteAllText((Join-Path $other '.existing'), 'preserve')
        Assert-Throws { Save-TestMailPlan -Batch $batch -Directory $other } 'Versteckte bestehende Datei'
    }
    Invoke-Check 'Excel-Formeln und eingebettete Anführungszeichen werden sicher gespeichert' {
        $fixture = New-Fixture
        $fixture.classes.high[0].id = '=HYPERLINK("https://example.invalid")'
        $fixture.classes.high = @($fixture.classes.high[0])
        $path = Save-Fixture $fixture
        $batch = New-TestMailBatch -Total 1 -HighPercent 100 -ImportantPercent 0 -LowPercent 0 -Recipients @('+tester@example.invalid') -TemplatePath $path
        $directory = Join-Path $script:TestRoot 'formula-safe'
        $saved = Save-TestMailPlan -Batch $batch -Directory $directory
        $rows = @(Import-Csv -LiteralPath $saved.ExpectedPath -Delimiter ';' -Encoding UTF8)
        Assert-Equal $rows[0].TemplateId ("'" + $fixture.classes.high[0].id)
        Assert-Equal $rows[0].Recipients "'+tester@example.invalid"
        $batch.Messages[0].Status = 'failed'
        $batch.Messages[0].Error = "=SUM(1;2)`r`nFehler mit ""Anführungszeichen"""
        $result = Save-TestMailResult -Batch $batch -Directory $directory
        $rows = @(Import-Csv -LiteralPath $result.ResultsPath -Delimiter ';' -Encoding UTF8)
        Assert-Equal $rows[0].Error ("'" + $batch.Messages[0].Error)
    }
    Invoke-Check 'Gemischte Ergebnisse zählen nur tatsächlich submitted klassengenau' {
        $batch = New-FixtureBatch
        foreach ($priority in @('high', 'important', 'low')) {
            $message = @($batch.Messages | Where-Object { $_.ExpectedPriority -eq $priority })[0]
            $message.Status = 'submitted'
            $message.SubmittedAt = [DateTimeOffset]::UtcNow.ToString('o')
        }
        $remaining = @($batch.Messages | Where-Object { $_.Status -eq 'planned' })
        $remaining[0].Status = 'failed'
        $remaining[1].Status = 'unknown'
        $remaining[2].Status = 'cancelled'
        $summary = Get-TestMailSummary -Batch $batch
        Assert-Equal $summary.Total 50
        Assert-Equal $summary.submitted 3
        Assert-Equal $summary.failed 1
        Assert-Equal $summary.unknown 1
        Assert-Equal $summary.cancelled 1
        Assert-Equal $summary.planned 44
        Assert-Equal $summary.HighSubmitted 1
        Assert-Equal $summary.ImportantSubmitted 1
        Assert-Equal $summary.LowSubmitted 1
        Assert-Equal ($summary.planned + $summary.submitted + $summary.failed + $summary.unknown + $summary.cancelled) $summary.Total
    }
    Invoke-Check 'Unbekannte Statuswerte werden nicht stillschweigend unterschlagen' {
        $batch = New-FixtureBatch
        $batch.Messages[0].Status = 'delivered'
        Assert-Throws { Get-TestMailSummary -Batch $batch } 'Unbekannter Status'
        Assert-Throws { Save-TestMailPlan -Batch $batch -Directory (Join-Path $script:TestRoot 'bad-state') } 'Plan mit verändertem Status'
    }
    Invoke-Check 'Ergebnisdateien aktualisierbar; ursprünglicher Plan und Soll-CSV bleiben identisch' {
        $batch = New-FixtureBatch
        $directory = Join-Path $script:TestRoot 'results'
        $saved = Save-TestMailPlan -Batch $batch -Directory $directory
        $planHash = (Get-FileHash -LiteralPath $saved.PlanPath -Algorithm SHA256).Hash
        $expectedHash = (Get-FileHash -LiteralPath $saved.ExpectedPath -Algorithm SHA256).Hash
        $batch.Messages[0].Status = 'submitted'
        $batch.Messages[0].SubmittedAt = [DateTimeOffset]::UtcNow.ToString('o')
        $batch.Messages[1].Status = 'failed'
        $batch.Messages[1].Error = 'Vorbereitung fehlgeschlagen.'
        $result = Save-TestMailResult -Batch $batch -Directory $directory
        Assert-Utf8Bom $result.ResultsPath
        Assert-Utf8Bom $result.SummaryPath
        $batch.Messages[2].Status = 'unknown'
        $result = Save-TestMailResult -Batch $batch -Directory $directory
        $summary = ConvertFrom-Json -InputObject ([System.IO.File]::ReadAllText($result.SummaryPath, $script:Encoding))
        Assert-Equal $summary.submitted 1
        Assert-Equal $summary.failed 1
        Assert-Equal $summary.unknown 1
        Assert-Equal $summary.planned 47
        Assert-Equal (Get-FileHash -LiteralPath $saved.PlanPath -Algorithm SHA256).Hash $planHash
        Assert-Equal (Get-FileHash -LiteralPath $saved.ExpectedPath -Algorithm SHA256).Hash $expectedHash
        Assert-Equal (@(Import-Csv -LiteralPath $result.ResultsPath -Delimiter ';' -Encoding UTF8)).Count 50
    }
    Invoke-Check 'Ergebnis ohne Plan oder aus einem fremden Lauf wird abgelehnt' {
        $batch = New-FixtureBatch
        Assert-Throws { Save-TestMailResult -Batch $batch -Directory (Join-Path $script:TestRoot 'missing-directory') } 'Plan fehlt'
        $directory = Join-Path $script:TestRoot 'mismatched-result'
        $null = Save-TestMailPlan -Batch $batch -Directory $directory
        $otherBatch = New-FixtureBatch
        Assert-Throws { Save-TestMailResult -Batch $otherBatch -Directory $directory } 'Fremde RunId'
    }
    Invoke-Check 'Versandjournal schreibt gültige JSONL-Zeilen und schließt die Datei sofort' {
        $path = Join-Path $script:TestRoot 'events.jsonl'
        Write-TestMailEvent -Path $path -TestId 'test-1' -Status 'attempting' -Detail "Vorbereitung`r`nZweite Zeile"
        Write-TestMailEvent -Path $path -TestId 'test-1' -Status 'submitted' -Detail 'Übergabe'
        Assert-Utf8Bom $path
        $lines = [System.IO.File]::ReadAllLines($path, $script:Encoding)
        Assert-Equal $lines.Length 2
        $first = ConvertFrom-Json -InputObject $lines[0]
        $second = ConvertFrom-Json -InputObject $lines[1]
        Assert-Equal $first.Status 'attempting'
        Assert-Equal $first.Detail "Vorbereitung`r`nZweite Zeile"
        Assert-Equal $second.Status 'submitted'
        Assert-Equal $second.Detail 'Übergabe'
        $stream = [System.IO.File]::Open($path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::ReadWrite, [System.IO.FileShare]::None)
        $stream.Dispose()
        $bytes = [System.IO.File]::ReadAllBytes($path)
        $bomCount = 0
        for ($i = 0; $i -lt $bytes.Length - 2; $i++) {
            if ($bytes[$i] -eq 239 -and $bytes[$i + 1] -eq 187 -and $bytes[$i + 2] -eq 191) { $bomCount++ }
        }
        Assert-Equal $bomCount 1 'Beim Anhängen darf kein zusätzliches BOM entstehen.'
    }
    Invoke-Check 'Journal lehnt unbekannte Zustände und fehlende Verzeichnisse ab' {
        Assert-Throws { Write-TestMailEvent -Path (Join-Path $script:TestRoot 'other.jsonl') -TestId 'test' -Status 'delivered' } 'Status delivered'
        Assert-Throws { Write-TestMailEvent -Path (Join-Path $script:TestRoot 'absent/events.jsonl') -TestId 'test' -Status 'attempting' } 'Fehlender Journalordner'
    }

    Write-Host ("`nCore-Tests: {0} PASS, {1} FAIL. Keine Outlook- oder Netzwerkaufrufe." -f $script:Passed, $script:Failures.Count)
    if ($script:Failures.Count -gt 0) { throw ($script:Failures.ToArray() -join "`n") }
} finally {
    if ([System.IO.Directory]::Exists($script:TestRoot)) {
        Remove-Item -LiteralPath $script:TestRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}
