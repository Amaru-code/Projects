@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
echo ==============================================================
echo  MCR BETA 5 RC1 - REINE OFFLINE INTEGRATIONSPRUEFUNG
echo  Keine Migration, kein COMARCH, kein echter Versand
 echo ==============================================================
if not exist "%~dp0Paket	oolseta-cli.mjs" goto incomplete
call "%~dp0Paket	oolsind-node.cmd"
if not "%errorlevel%"=="0" goto nodeerror
"%MCR_NODE%" "%~dp0Paket	oolseta-cli.mjs" --selftest
if not "%errorlevel%"=="0" goto failtest
echo.
echo RC1_TESTS_PASS
echo.
echo Jetzt folgt eine vollstaendig FIKTIVE Demo im eigenen temporaeren Browserprofil.
"%MCR_NODE%" "%~dp0Paket	oolseta-cli.mjs" --demo
if not "%errorlevel%"=="0" goto faildemo
echo.
echo RC1_DEMO_PASS
echo ========================================
echo RC1_OFFLINE_QUALIFIED - kein Live-Release
echo ========================================
pause
exit /b 0
:incomplete
echo STOP: Komplettes ZIP zunaechst ausserhalb MCR_Datenbruecke entpacken.
pause
exit /b 2
:nodeerror
echo STOP: Node.js nicht gefunden oder nicht geeignet.
pause
exit /b 3
:failtest
echo STOP: RC1_TESTS_FAILED - keine Installation oder Echtaktion.
pause
exit /b 4
:faildemo
echo STOP: RC1_DEMO_FAILED - keine Installation oder Echtaktion.
pause
exit /b 5
