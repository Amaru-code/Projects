export function cleanCell(value: any): string {
  return String(value ?? "").replace(/\u00A0/g, " ").trim();
}

export function normalizeHeader(value: any): string {
  return cleanCell(value)
    .toLowerCase()
    .replace(/ä/g, "ae").replace(/ö/g, "oe").replace(/ü/g, "ue").replace(/ß/g, "ss")
    .replace(/[^a-z0-9]+/g, "");
}

export function normalizeText(value: any): string {
  return String(value ?? "")
    .replace(/\u00A0/g, " ")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, " ");
}

const FUND_ALIASES = new Map<string,string>([
  [normalizeText("DWS INV.FOC.EUROPE FC"), normalizeText("DWSI-EUR.EQ.HI.CO.FC")],
  [normalizeText("DWSI-EUR.EQ.HI.CO.FC Anteile"), normalizeText("DWSI-EUR.EQ.HI.CO.FC")],
]);

export function normalizeFund(value: any): string {
  const n = normalizeText(value);
  return FUND_ALIASES.get(n) ?? n;
}

export function normalizeWwid(value: any): string {
  if (value === null || value === undefined) return "";
  if (typeof value === "number" && Number.isFinite(value) && Math.trunc(value) === value) return String(Math.trunc(value));
  let s = String(value).trim();
  if (s.endsWith(".0") && /^\d+\.0$/.test(s)) s = s.slice(0, -2);
  return s;
}

export function asNumber(value: any): number {
  if (value === null || value === undefined || value === "") return 0;
  if (typeof value === "number") return Number.isFinite(value) ? value : 0;
  let text = String(value).trim().replace(/ /g, "");
  if (!text) return 0;
  const comma = text.lastIndexOf(",");
  const dot = text.lastIndexOf(".");
  if (comma >= 0 && dot >= 0) {
    if (comma > dot) text = text.replace(/\./g, "").replace(",", ".");
    else text = text.replace(/,/g, "");
  } else if (comma >= 0) {
    text = text.replace(/\./g, "").replace(",", ".");
  }
  const n = Number(text);
  return Number.isFinite(n) ? n : 0;
}

export function isDistribution(value: any): boolean {
  const t = normalizeText(value);
  return t.startsWith("ertragsaussch") && t.endsWith("ttung");
}

export function profileFromFilename(name: string): "du"|"dp"|null {
  const path = require("path");
  const stem = path.parse(name).name.trim().toLowerCase();
  const matchesPrefix = (s: string, p: string): boolean => {
    if (s === p) return true;
    if (!s.startsWith(p)) return false;
    const next = s.slice(p.length, p.length + 1);
    return next === "" || next === "_" || next === "-" || /\s/.test(next);
  };
  if (matchesPrefix(stem, "du")) return "du";
  if (matchesPrefix(stem, "dp")) return "dp";
  return null;
}

export function headerMap(header: string[]): Map<string,number> {
  const map = new Map<string,number>();
  header.forEach((h,i) => {
    const n = normalizeHeader(h);
    if (n && !map.has(n)) map.set(n, i);
  });
  return map;
}

export function findIndex(map: Map<string,number>, aliases: string[]): number {
  for (const a of aliases) {
    const i = map.get(normalizeHeader(a));
    if (i !== undefined) return i;
  }
  throw new Error("Required master header missing: " + aliases.join(" / "));
}

export function xmlEscape(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\"/g, "&quot;")
    .replace(/'/g, "&apos;");
}
