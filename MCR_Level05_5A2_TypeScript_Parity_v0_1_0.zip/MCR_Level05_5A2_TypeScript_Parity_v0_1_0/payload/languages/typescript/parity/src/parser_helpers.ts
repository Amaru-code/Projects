export function parseDelimitedLine(line: string, delimiter: string): string[] {
  const result: string[] = [];
  let field = "";
  let quoted = false;
  for (let i=0;i<line.length;i++) {
    const c = line[i];
    if (c === '"') {
      if (quoted && i+1 < line.length && line[i+1] === '"') { field += '"'; i++; }
      else quoted = !quoted;
    } else if (c === delimiter && !quoted) {
      result.push(field); field = "";
    } else field += c;
  }
  result.push(field);
  return result;
}
