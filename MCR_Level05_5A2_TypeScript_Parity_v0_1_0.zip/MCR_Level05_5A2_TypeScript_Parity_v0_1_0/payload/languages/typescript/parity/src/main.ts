import { MercerSettings, Options } from "./model";
import { WwidMapping } from "./mapping";
import { TextParser } from "./parser";
import { Pipeline } from "./pipeline";

const fs=require("fs"),pathMod=require("path");

function parseArgs():Options{
  const args=process.argv.slice(2),map=new Map<string,string>();for(let i=0;i<args.length;i++){const k=args[i];if(!k.startsWith("--"))throw new Error(`Unexpected argument: ${k}`);if(i+1>=args.length)throw new Error(`Missing value for ${k}`);map.set(k.toLowerCase(),args[++i]);}
  const need=(k:string)=>{const v=map.get(k);if(!v||!v.trim())throw new Error(`Required argument missing: ${k}`);return v;};
  const workers=Math.max(1,Number(map.get("--workers")??"4")||4);
  return{caseId:map.get("--case")??"MCR_LNW_001",inputDir:pathMod.resolve(need("--input")),templatePath:pathMod.resolve(need("--template")),outputDir:pathMod.resolve(need("--output")),workers};
}

function main():number{
  try{
    const options=parseArgs();if(options.caseId!=="MCR_LNW_001")throw new Error("This candidate is frozen to case MCR_LNW_001.");
    const settingsPath=pathMod.join(__dirname,"resources","settings.json"),mappingPath=pathMod.join(__dirname,"resources","wwid_mapping.csv");if(!fs.existsSync(settingsPath)||!fs.existsSync(mappingPath))throw new Error("Candidate resources are missing from build output.");
    console.log("=".repeat(72));console.log("MCR LEVEL 05A.2 - TYPESCRIPT MODE 1 PARITY CANDIDATE");console.log("=".repeat(72));console.log(`Case:    ${options.caseId}`);console.log(`Input:   ${options.inputDir}`);console.log(`Template:${options.templatePath}`);console.log(`Output:  ${options.outputDir}`);console.log(`Workers: ${options.workers}`);console.log();
    fs.mkdirSync(options.outputDir,{recursive:true});const settings:MercerSettings=JSON.parse(fs.readFileSync(settingsPath,"utf8"));const mapping=WwidMapping.load(mappingPath);const parser=new TextParser(settings,mapping);const result=new Pipeline(parser).run(options);
    const candidate={schema:"mcr.level05.candidate-result.v1",status:"success",case:options.caseId,language:"typescript",mode:"parity",artifacts:{du_master:pathMod.basename(result.duMaster),dp_master:pathMod.basename(result.dpMaster),lnw_excel:pathMod.basename(result.lnwExcel),lnw_csv:pathMod.basename(result.lnwCsv)},diagnostics:{du_master_rows:result.duRows,dp_master_rows:result.dpRows,workers:options.workers,runtime:process.version}};
    fs.writeFileSync(pathMod.join(options.outputDir,"candidate_result.json"),JSON.stringify(candidate,null,2),"utf8");console.log();console.log("TypeScript candidate completed successfully.");console.log(`DU Master Rows: ${result.duRows}`);console.log(`DP Master Rows: ${result.dpRows}`);console.log("candidate_result.json written.");return 0;
  }catch(e:any){console.error();console.error("TYPESCRIPT CANDIDATE FAILED");console.error(e?.stack??e);return 1;}
}
process.exitCode=main();
