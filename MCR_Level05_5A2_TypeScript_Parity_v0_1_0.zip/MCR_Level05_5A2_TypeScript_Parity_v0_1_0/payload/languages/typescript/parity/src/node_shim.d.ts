declare function require(name: string): any;
declare const process: any;
declare const __dirname: string;
declare const Buffer: any;
declare const console: { log: (...args:any[])=>void; error: (...args:any[])=>void; warn: (...args:any[])=>void; };
