[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [ValidateSet('Snapshot','Apply')]
    [string]$Mode,

    [Parameter(Mandatory=$true)]
    [string]$Workbook,

    [string]$SnapshotPath,
    [string]$PlanPath,
    [string]$CsvPath
)

$ErrorActionPreference = 'Stop'
$Invariant = [System.Globalization.CultureInfo]::InvariantCulture

function Release-Com([object]$Object) {
    if ($null -eq $Object) { return }
    try {
        if ([System.Runtime.InteropServices.Marshal]::IsComObject($Object)) {
            [void][System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($Object)
        }
    } catch {}
}

function Normalize-Header([object]$Value) {
    if ($null -eq $Value) { return '' }
    $s = [Convert]::ToString($Value, $Invariant).Replace([char]0x00A0,' ').Trim().ToLowerInvariant()
    $s = $s.Replace('ä','ae').Replace('ö','oe').Replace('ü','ue').Replace('ß','ss')
    return [regex]::Replace($s, '[^a-z0-9]+', '')
}

function Normalize-Wwid([object]$Value) {
    if ($null -eq $Value) { return '' }
    if ($Value -is [double]) {
        $d = [double]$Value
        if ([math]::Abs($d % 1.0) -lt [double]::Epsilon) { return ([long]$d).ToString($Invariant) }
    }
    $s = [Convert]::ToString($Value, $Invariant).Trim()
    if ($s.EndsWith('.0') -and $s.Substring(0,$s.Length-2) -match '^\d+$') { return $s.Substring(0,$s.Length-2) }
    return $s
}

function Number-Text([object]$Value) {
    if ($null -eq $Value) { return '0' }
    try { return ([Convert]::ToDouble($Value, $Invariant)).ToString('R',$Invariant) }
    catch { return '0' }
}

function Csv-Escape([string]$Value) {
    if ($null -eq $Value) { $Value = '' }
    if ($Value.Contains(';') -or $Value.Contains('"') -or $Value.Contains("`r") -or $Value.Contains("`n")) {
        return '"' + $Value.Replace('"','""') + '"'
    }
    return $Value
}

function Float-Text([double]$Value) {
    if ([double]::IsNaN($Value)) { return 'nan' }
    if ([double]::IsPositiveInfinity($Value)) { return 'inf' }
    if ([double]::IsNegativeInfinity($Value)) { return '-inf' }
    if ($Value -eq 0.0) { return '0.0' }
    return $Value.ToString('R',$Invariant).Replace('E','e')
}

function Csv-Value([object]$Value) {
    if ($null -eq $Value) { return '' }
    if ($Value -is [string]) { return [string]$Value }
    if ($Value -is [bool]) { if ($Value) { return 'True' } else { return 'False' } }
    if ($Value -is [System.Runtime.InteropServices.ErrorWrapper]) { return $Value.ErrorCode.ToString($Invariant) }
    if ($Value -is [double] -or $Value -is [float]) { return Float-Text ([double]$Value) }
    return [Convert]::ToString($Value,$Invariant)
}

$excel = $null
$book = $null
$sheet = $null
try {
    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $excel.DisplayAlerts = $false
    $excel.EnableEvents = $false
    $excel.ScreenUpdating = $false
    $excel.AskToUpdateLinks = $false
    $book = $excel.Workbooks.Open($Workbook,0,$false)
    $sheet = $book.Worksheets.Item('Import DC LNW')

    $usedCols = [math]::Max([int]$sheet.UsedRange.Columns.Count, 99)
    $headerRow = 0
    $wwidCol = 0
    for ($r=1; $r -le 30 -and $headerRow -eq 0; $r++) {
        for ($c=1; $c -le $usedCols; $c++) {
            if ((Normalize-Header $sheet.Cells.Item($r,$c).Value2) -eq 'wwid') {
                $headerRow = $r; $wwidCol = $c; break
            }
        }
    }
    if ($headerRow -eq 0) { throw 'WWID header not found.' }
    $lastRow = [int]$sheet.Cells.Item($sheet.Rows.Count,$wwidCol).End(-4162).Row
    if ($lastRow -le $headerRow) { throw 'No WWID rows found.' }

    if ($Mode -eq 'Snapshot') {
        if ([string]::IsNullOrWhiteSpace($SnapshotPath)) { throw 'SnapshotPath missing.' }
        $enc = [System.Text.UTF8Encoding]::new($false)
        $sw = [System.IO.StreamWriter]::new($SnapshotPath,$false,$enc)
        try {
            $sw.WriteLine("META`t$headerRow`t$wwidCol`t$lastRow")
            $prevCols = 90..99 # CL:CU
            for ($r=$headerRow+1; $r -le $lastRow; $r++) {
                $wwid = Normalize-Wwid $sheet.Cells.Item($r,$wwidCol).Value2
                $parts = New-Object System.Collections.Generic.List[string]
                $parts.Add('ROW'); $parts.Add([string]$r); $parts.Add($wwid)
                foreach ($c in $prevCols) { $parts.Add((Number-Text $sheet.Cells.Item($r,$c).Value2)) }
                $sw.WriteLine([string]::Join("`t",$parts))
            }
        } finally { $sw.Dispose() }
        Write-Host "[Excel] Snapshot: header=$headerRow wwidCol=$wwidCol lastRow=$lastRow"
        $book.Close($false)
    }
    else {
        if ([string]::IsNullOrWhiteSpace($PlanPath)) { throw 'PlanPath missing.' }
        if ([string]::IsNullOrWhiteSpace($CsvPath)) { throw 'CsvPath missing.' }
        $firstData = $headerRow + 1
        $planLast = $lastRow
        $lines = Get-Content $PlanPath
        if ($lines.Count -gt 0 -and $lines[0].StartsWith("META`t")) {
            $m = $lines[0].Split("`t")
            if ($m.Count -ge 3) { $firstData = [int]$m[1]; $planLast = [int]$m[2] }
        }
        try {
            $constants = $sheet.Range("AJ${firstData}:CU${planLast}").SpecialCells(2)
            $constants.ClearContents()
            Release-Com $constants
        } catch {}

        foreach ($line in $lines) {
            if (-not $line.StartsWith("SET`t")) { continue }
            $p = $line.Split("`t")
            if ($p.Count -lt 3) { continue }
            $cell = $null
            try {
                $cell = $sheet.Range($p[1])
                $hasFormula = $false
                try { $hasFormula = [Convert]::ToBoolean($cell.HasFormula,$Invariant) } catch {}
                if (-not $hasFormula) { $cell.Value2 = [double]::Parse($p[2],$Invariant) }
            } finally { Release-Com $cell }
        }

        $excel.CalculateFullRebuild()
        $book.Save()

        $after = $null; $found = $null
        try {
            $after = $sheet.Cells.Item(1,1)
            $found = $sheet.Cells.Find('*',$after,-4123,2,1,2,$false,[Type]::Missing,$false)
            if ($null -ne $found) { $csvLastRow = [int]$found.Row } else { $csvLastRow = $lastRow }
        } catch { $csvLastRow = $lastRow }
        finally { Release-Com $found; Release-Com $after }

        $enc = [System.Text.UTF8Encoding]::new($true)
        $sw = [System.IO.StreamWriter]::new($CsvPath,$false,$enc)
        $sw.NewLine = "`r`n"
        try {
            for ($r=1; $r -le $csvLastRow; $r++) {
                $a = Csv-Escape (Csv-Value $sheet.Cells.Item($r,1).Value2)
                $b = Csv-Escape (Csv-Value $sheet.Cells.Item($r,2).Value2)
                $sw.WriteLine($a + ';' + $b)
            }
        } finally { $sw.Dispose() }

        Write-Host "[Excel] Apply + Recalc + CSV abgeschlossen. Rows=$csvLastRow"
        $book.Close($false)
    }
}
finally {
    try { if ($null -ne $book) { $book.Close($false) } } catch {}
    try { if ($null -ne $excel) { $excel.Quit() } } catch {}
    Release-Com $sheet; Release-Com $book; Release-Com $excel
    [gc]::Collect(); [gc]::WaitForPendingFinalizers(); [gc]::Collect(); [gc]::WaitForPendingFinalizers()
}
