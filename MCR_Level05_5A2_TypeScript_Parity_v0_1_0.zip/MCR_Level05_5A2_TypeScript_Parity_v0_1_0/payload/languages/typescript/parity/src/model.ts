export interface Table {
  header: string[];
  rows: string[][];
  sourceName: string;
}

export interface Options {
  caseId: string;
  inputDir: string;
  templatePath: string;
  outputDir: string;
  workers: number;
}

export interface PipelineResult {
  duMaster: string;
  dpMaster: string;
  lnwExcel: string;
  lnwCsv: string;
  duRows: number;
  dpRows: number;
}

export interface MercerSettings {
  allowed_company_ids: string[];
  company_id_column_index: number;
  du_target_headers: string[];
  dp_target_headers: string[];
}
