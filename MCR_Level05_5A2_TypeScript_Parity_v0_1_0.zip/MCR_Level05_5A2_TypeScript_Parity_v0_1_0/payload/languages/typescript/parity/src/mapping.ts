import { parseDelimitedLine } from "./parser_helpers";

function clean(value: any): string {
  let text = String(value ?? "").replace(/\u00A0/g, " ").trim().replace(/^'+|'+$/g, "");
  if (/^\d+\.0$/.test(text)) text = text.slice(0, -2);
  return text;
}

export function normalizeDepot(value: any): string {
  return clean(value).replace(/\s+/g, "");
}

export function normalizeUnderdepot(value: any): string {
  const text = clean(value);
  if (!text) return "";
  const digits = (text.match(/\d/g) ?? []).join("");
  if (!digits) return text;
  try { return BigInt(digits).toString(); } catch { return digits; }
}

export function normalizeMappingWwid(value: any): string { return clean(value); }

export class WwidMapping {
  private exact = new Map<string,string>();
  private depotFallback = new Map<string,string>();
  private conflicts = new Map<string,Set<string>>();

  static load(path: string): WwidMapping {
    const fs = require("fs");
    const bytes = fs.readFileSync(path);
    let text = bytes.toString("utf8").replace(/^\uFEFF/, "");
    const lines = text.split(/\r?\n/);
    const result = new WwidMapping();
    if (!lines.length || !lines[0].trim()) return result;

    const header = parseDelimitedLine(lines[0].replace(/^\uFEFF/, ""), ";");
    const fields = new Map<string,number>();
    header.forEach((h,i) => fields.set(h.trim().toLowerCase(), i));
    const find = (...names: string[]): number => {
      for (const n of names) {
        const i = fields.get(n.toLowerCase());
        if (i !== undefined) return i;
      }
      return -1;
    };
    const wwidIdx = find("WWID");
    const dep1Idx = find("Depot_01","Depo_01");
    const dep2Idx = find("Depot_02","Depo_02");
    const dep3Idx = find("Depot_03","Depo_03");
    if ([wwidIdx,dep1Idx,dep2Idx,dep3Idx].some(x => x < 0)) throw new Error("WWID mapping header is incomplete.");

    const candidates = new Map<string,Set<string>>();
    const depotCandidates = new Map<string,Set<string>>();
    const key = (d:string,u:string) => d + "\u0000" + u;

    for (const line of lines.slice(1)) {
      if (!line.trim()) continue;
      const row = parseDelimitedLine(line, ";");
      const at = (i:number) => i >= 0 && i < row.length ? row[i] : "";
      const wwid = normalizeMappingWwid(at(wwidIdx));
      if (!wwid) continue;
      for (const [under, idx] of [["1",dep1Idx],["2",dep2Idx],["3",dep3Idx]] as Array<[string,number]>) {
        const depot = normalizeDepot(at(idx));
        if (!depot) continue;
        const k = key(depot, under);
        if (!candidates.has(k)) candidates.set(k, new Set<string>());
        candidates.get(k)!.add(wwid);
        if (!depotCandidates.has(depot)) depotCandidates.set(depot, new Set<string>());
        depotCandidates.get(depot)!.add(wwid);
      }
    }

    for (const [k,set] of candidates.entries()) {
      if (set.size === 1) result.exact.set(k, Array.from(set)[0]);
      else result.conflicts.set(k, set);
    }
    for (const [d,set] of depotCandidates.entries()) {
      if (set.size === 1) result.depotFallback.set(d, Array.from(set)[0]);
    }
    return result;
  }

  resolve(depot: string, underdepot: string, existingWwid: string): string {
    const depotKey = normalizeDepot(depot);
    const underKey = normalizeUnderdepot(underdepot);
    const existing = normalizeMappingWwid(existingWwid);
    if (!depotKey) return existing;
    const k = depotKey + "\u0000" + underKey;
    if (underKey && this.exact.has(k)) return this.exact.get(k)!;
    if (underKey && this.conflicts.has(k)) return existing;
    if (this.depotFallback.has(depotKey)) return this.depotFallback.get(depotKey)!;
    return existing;
  }
}
