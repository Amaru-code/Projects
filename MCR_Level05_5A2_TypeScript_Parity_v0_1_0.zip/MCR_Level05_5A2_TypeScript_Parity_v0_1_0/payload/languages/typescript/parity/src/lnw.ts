import { Table } from "./model";
import { asNumber, findIndex, headerMap, isDistribution, normalizeFund, normalizeText, normalizeWwid } from "./util";

const fs = require("fs");
const pathMod = require("path");
const cp = require("child_process");

interface SnapRow { row:number; wwid:string; prev:number[]; }
interface Snapshot { headerRow:number; lastRow:number; rows:SnapRow[]; }
interface Pair { shares:number; value:number; }

function at(row:string[],idx:number):string{return idx>=0&&idx<row.length?row[idx]:"";}
function duKey(wwid:string,fund:string,movement:string):string{return `${wwid}\u0000${fund}\u0000${movement}`;}
function dpKey(wwid:string,fund:string):string{return `${wwid}\u0000${fund}`;}

function aggregateDu(table:Table, investmentValue:boolean):Map<string,Pair>{
  const map=headerMap(table.header);
  const wwidIdx=findIndex(map,["WWID"]);
  const fundIdx=findIndex(map,["Fondsname","Fonds Name"]);
  const movementIdx=findIndex(map,["Umsatzart","Umsatz Art"]);
  const sharesIdx=findIndex(map,["UmsatzStuecke","Umsatzstücke","Umsatz Stücke"]);
  const valueIdx=investmentValue?findIndex(map,["Anlbetrag","AnlBetrag","Anl Betrag","Anlagebetrag"]):findIndex(map,["ZahlBetrag","Zahlbetrag","Zahl Betrag"]);
  const out=new Map<string,Pair>();
  for(const row of table.rows){
    const wwid=normalizeWwid(at(row,wwidIdx));const fund=normalizeFund(at(row,fundIdx));const movement=normalizeText(at(row,movementIdx));
    if(!wwid||!fund||!movement)continue;const k=duKey(wwid,fund,movement);const cur=out.get(k)??{shares:0,value:0};cur.shares+=asNumber(at(row,sharesIdx));cur.value+=asNumber(at(row,valueIdx));out.set(k,cur);
  }
  return out;
}
function aggregateDp(table:Table):Map<string,Pair>{
  const map=headerMap(table.header);
  const wwidIdx=findIndex(map,["WWID"]);const fundIdx=findIndex(map,["Fondsname","Fonds Name"]);
  const sharesIdx=findIndex(map,["Bestand_Stuecke","BestandStuecke","Bestand Stücke","Bestand_Stücke","Bestandstücke"]);
  const valueIdx=findIndex(map,["Bestand_Betrag","BestandBetrag","Bestand Betrag"]);
  const out=new Map<string,Pair>();
  for(const row of table.rows){const wwid=normalizeWwid(at(row,wwidIdx));const fund=normalizeFund(at(row,fundIdx));if(!wwid||!fund)continue;const k=dpKey(wwid,fund);const cur=out.get(k)??{shares:0,value:0};cur.shares+=asNumber(at(row,sharesIdx));cur.value+=asNumber(at(row,valueIdx));out.set(k,cur);}return out;
}

function bridgePath():string{const p=pathMod.join(__dirname,"excel_bridge.ps1");if(!fs.existsSync(p))throw new Error(`Excel bridge missing: ${p}`);return p;}
function runBridge(args:string[]):void{
  const full=["-NoProfile","-ExecutionPolicy","Bypass","-File",bridgePath(),...args];
  const r=cp.spawnSync("powershell.exe",full,{stdio:"inherit",windowsHide:true});
  if(r.error)throw new Error(`Excel bridge could not start: ${r.error.message}`);
  if(r.status!==0)throw new Error(`Excel bridge failed with exit code ${r.status}`);
}
function parseSnapshot(filePath:string):Snapshot{
  const text=fs.readFileSync(filePath,"utf8");let headerRow=0,lastRow=0;const rows:SnapRow[]=[];
  for(const line of text.split(/\r?\n/)){if(!line)continue;const p=line.split("\t");if(p[0]==="META"&&p.length>=4){headerRow=Number(p[1]);lastRow=Number(p[3]);}else if(p[0]==="ROW"&&p.length>=13){rows.push({row:Number(p[1]),wwid:normalizeWwid(p[2]),prev:p.slice(3,13).map((x:string)=>Number(x)||0)});}}
  if(!headerRow||lastRow<=headerRow)throw new Error("Snapshot metadata invalid");return{headerRow,lastRow,rows};
}
function numberText(v:number):string{return Number.isFinite(v)?String(v):"0";}

export function runLnw(templatePath:string,du:Table,dp:Table,outputExcel:string,outputCsv:string,workDir:string):void{
  fs.mkdirSync(workDir,{recursive:true});fs.copyFileSync(templatePath,outputExcel);
  const snapshotPath=pathMod.join(workDir,"excel_snapshot.tsv");const planPath=pathMod.join(workDir,"excel_plan.tsv");
  console.log("[LNW] Output-Template wird ueber Microsoft Excel geoeffnet ...");
  runBridge(["-Mode","Snapshot","-Workbook",outputExcel,"-SnapshotPath",snapshotPath]);
  const snap=parseSnapshot(snapshotPath);console.log(`[LNW] Zielblatt erkannt: WWID-Header Zeile ${snap.headerRow}, letzte WWID-Zeile ${snap.lastRow}.`);
  console.log("[LNW] DU wird nach WWID, Fonds und Umsatzart aggregiert ...");const duAgg=aggregateDu(du,false);const purchaseAgg=aggregateDu(du,true);
  console.log("[LNW] DP wird nach WWID und Fonds aggregiert ...");const dpAgg=aggregateDp(dp);

  const lines:string[]=[`META\t${snap.headerRow+1}\t${snap.lastRow}`];const set=(addr:string,val:number)=>lines.push(`SET\t${addr}\t${numberText(val)}`);
  const prevToCurrent:[string,number][]=[["AJ",0],["AK",1],["AL",2],["AM",3],["AN",4],["AO",5],["AP",6],["AQ",7],["AR",8],["AS",9]];
  const purchaseMaps:[string,string,string][]=[["DWS EURORENTA","AV","AW"],["DWS INS.-ESG EO MO.M.IC","AY","AZ"],["DWSI-EUR.EQ.HI.CO.FC","BB","BC"]];
  const funds:Array<[string,string,string,string|null,string|null]>=[
    ["DWSI-EUR.EQ.HI.CO.FC","CL","CM","BI","BJ"],["DWS EURORENTA","CN","CO","BK","BL"],["DWS INS.-ESG EO MO.M.IC","CP","CQ","BM","BN"],["SIEMENS EUROINVEST AKTIEN","CR","CS",null,null],["SIEMENS EUROINVEST RENTEN","CT","CU",null,null]
  ];
  const purchaseMovement=normalizeText("Kauf"),reallocMovement=normalizeText("Fondsportfolioanpassung"),distFund=normalizeFund("DWS EURORENTA");
  console.log("[LNW] Schreibplan fuer AJ:CU wird erzeugt ...");
  for(const s of snap.rows){if(!s.wwid)continue;for(const [col,i] of prevToCurrent)set(`${col}${s.row}`,s.prev[i]??0);
    for(const [fund,sc,vc] of purchaseMaps){const v=purchaseAgg.get(duKey(s.wwid,normalizeFund(fund),purchaseMovement))??{shares:0,value:0};set(`${sc}${s.row}`,v.shares);set(`${vc}${s.row}`,v.value);}
    let ds=0,dv=0;for(const [k,v] of duAgg.entries()){const [w,f,m]=k.split("\u0000");if(w===s.wwid&&f===distFund&&isDistribution(m)){ds+=v.shares;dv+=v.value;}}set(`BF${s.row}`,ds);set(`BG${s.row}`,dv);
    for(const [fund,endS,endV,rs,rv] of funds){const f=normalizeFund(fund);if(rs&&rv){const v=duAgg.get(duKey(s.wwid,f,reallocMovement))??{shares:0,value:0};set(`${rs}${s.row}`,v.shares);set(`${rv}${s.row}`,v.value);}const d=dpAgg.get(dpKey(s.wwid,f))??{shares:0,value:0};set(`${endS}${s.row}`,d.shares);set(`${endV}${s.row}`,d.value);}
  }
  fs.writeFileSync(planPath,lines.join("\r\n")+"\r\n","utf8");
  console.log("[LNW] Konstanten werden geloescht, Werte geschrieben und Excel neu berechnet ...");
  runBridge(["-Mode","Apply","-Workbook",outputExcel,"-PlanPath",planPath,"-CsvPath",outputCsv]);
  console.log("[LNW] Verarbeitung erfolgreich abgeschlossen.");
}
