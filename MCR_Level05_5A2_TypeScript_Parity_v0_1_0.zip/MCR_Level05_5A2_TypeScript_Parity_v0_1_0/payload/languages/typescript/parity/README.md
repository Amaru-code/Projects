# Level 05A.2 TypeScript Mode-1 Parity

Correctness-first independent TypeScript/Node port of the frozen LNW DC 1.0.3 business pipeline.

- TypeScript implements raw parsing, DU/DP classification, filtering, WWID mapping, merge, aggregation and LNW calculation.
- Microsoft Excel is accessed through a narrow PowerShell COM I/O bridge for the frozen XLSM template/recalculation/CSV output.
- No Python Oracle, C# worker or Rust worker is invoked.
- No new native candidate EXE is generated. The compiled TypeScript is JavaScript and runs inside the already installed `node.exe` runtime.
- v0.1.0 is correctness-first and processes source conversions sequentially. Optimization comes only after semantic parity is certified.
