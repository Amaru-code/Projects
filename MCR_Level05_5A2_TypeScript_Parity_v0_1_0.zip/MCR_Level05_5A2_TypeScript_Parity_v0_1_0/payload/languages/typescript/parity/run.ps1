[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][Alias('Case')][ValidateNotNullOrEmpty()][string]$CaseId,
    [Parameter(Mandatory=$true)][Alias('Input')][ValidateNotNullOrEmpty()][string]$InputPath,
    [Parameter(Mandatory=$true)][Alias('Template')][ValidateNotNullOrEmpty()][string]$TemplatePath,
    [Parameter(Mandatory=$true)][Alias('Output')][ValidateNotNullOrEmpty()][string]$OutputPath,
    [int]$Workers = 4
)
$ErrorActionPreference='Stop'
$ModeRoot=$PSScriptRoot
$BuildRoot=Join-Path $ModeRoot 'build'
$Publish=Join-Path $BuildRoot 'publish'
$Main=Join-Path $Publish 'main.js'
$NodePointer=Join-Path $BuildRoot 'node_path.txt'
if(-not(Test-Path $Main -PathType Leaf)){throw "TypeScript Candidate wurde noch nicht gebaut: $Main"}
if(-not(Test-Path $NodePointer -PathType Leaf)){throw 'node_path.txt fehlt. build.ps1 zuerst ausfuehren.'}
$Node=(Get-Content $NodePointer -Raw).Trim()
if(-not(Test-Path $Node -PathType Leaf)){throw "Node Runtime fehlt: $Node"}

Write-Host 'TypeScript Candidate Wrapper'
Write-Host "Case:     [$CaseId]"
Write-Host "Input:    [$InputPath]"
Write-Host "Template: [$TemplatePath]"
Write-Host "Output:   [$OutputPath]"
Write-Host "Workers:  [$Workers]"
Write-Host "Runtime:  [$Node]"

if(Test-Path $OutputPath){Get-ChildItem $OutputPath -Force -ErrorAction SilentlyContinue|Remove-Item -Recurse -Force}else{New-Item -ItemType Directory -Force -Path $OutputPath|Out-Null}
& $Node $Main --case $CaseId --input $InputPath --template $TemplatePath --output $OutputPath --workers $Workers
$Code=$LASTEXITCODE
if($null -eq $Code){throw 'TypeScript Candidate returned no Node exit code.'}
exit [int]$Code
