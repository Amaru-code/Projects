import test from 'node:test';
import assert from 'node:assert/strict';
import {makeManualPerson,promptManualPerson} from '../lib/manual-person.mjs';
import Identity from '../lib/identity-evidence.cjs';
import Person from '../lib/person.cjs';

const fixture=(answers)=>{
 const replies=[...answers],questions=[],logs=[];
 return {ask:async q=>{questions.push(q);assert.ok(replies.length,'unexpected prompt');return replies.shift();},log:m=>logs.push(m),questions,logs,replies};
};
test('no automatic candidate: operator enters first, surname and JA, kept separately',async()=>{
 const io=fixture([' Max ',' Mustermann ',' JA ']);
 const person=await promptManualPerson(io);
 assert.equal(person.firstName,'Max');assert.equal(person.lastName,'Mustermann');
 assert.equal(person.manualConfirmed,true);
 assert.equal(person.quotedOnly,false);
 assert.deepEqual(person.sources,['MANUELL_BESTAETIGT']);
 assert.equal(io.questions.length,3);assert.equal(io.replies.length,0);
});
test('blank / invalid name is prompted again, never passed to COMARCH',async()=>{
 const io=fixture(['','Mustermann','Max','Mustermann','JA']);
 const person=await promptManualPerson(io);
 assert.equal(person.name,'Max Mustermann');assert.equal(io.questions.length,5);
 assert.ok(io.logs.some(x=>x.startsWith('NAME_MANUAL_INVALID')));
});
test('negative review asks again; no accidental automatic approval',async()=>{
 const io=fixture(['Max','Mustermann','NEIN','Maria','Müller','JA']);
 const person=await promptManualPerson(io);
 assert.equal(person.firstName,'Maria');assert.equal(person.lastName,'Müller');
 assert.equal(io.questions.length,6);
});
test('operator can cancel before entering any name',async()=>{
 const io=fixture(['ABBRUCH']);
 await assert.rejects(promptManualPerson(io),{code:'NAME_MANUAL_ABORTED'});
});
test('operator can cancel at confirmation before any send',async()=>{
 const io=fixture(['Max','Mustermann','ABBRUCH']);
 await assert.rejects(promptManualPerson(io),{code:'NAME_MANUAL_ABORTED'});
});
test('five unconfirmed attempts end safely without any person',async()=>{
 const io=fixture(Array.from({length:5},()=>['Max','Mustermann','NEIN']).flat());
 await assert.rejects(promptManualPerson(io),{code:'NAME_MANUAL_NOT_CONFIRMED'});
 assert.equal(io.questions.length,15);
});
test('empty and unexpected names are not accepted as credentials',()=>{
 for(const [a,b] of [['','Mustermann'],['Max',''],['12345','Mustermann'],['Max','77'],['<script>','Mustermann'],['Max','name@example.invalid'],['Max','GmbH@example.invalid']])assert.throws(()=>makeManualPerson(a,b));
});
test('manual person does not disable COMARCH identity name guard',()=>{
 const person=makeManualPerson('Max','Mustermann');
 assert.equal(Identity.requireMatched({id:'99900001',source:'PROFILE_ROWS',firstName:'Max',lastName:'Mustermann'},person,{}),true);
 assert.throws(()=>Identity.requireMatched({id:'99900001',source:'PROFILE_ROWS',firstName:'Fremd',lastName:'Mustermann'},person,{}),{code:'MEMBER_NAME_MISMATCH'});
});
test('manual name does not override explicit MercerID in current email',()=>{
 const person=makeManualPerson('Max','Mustermann');
 const evidence=Identity.buildEvidence({body:'Bitte helfen Sie mir. MercerID: 111222333'});
 assert.throws(()=>Identity.requireMatched({id:'99900001',source:'PROFILE_ROWS',firstName:'Max',lastName:'Mustermann'},person,evidence),{code:'MEMBER_ID_CONFLICT'});
});
test('manual name is NOT derived from an email address or a guessed sender',()=>{
 assert.deepEqual(Person.candidates({body:'Bitte prüfen Sie meine Anfrage. Vielen Dank.',senderName:''}),[]);
 const p=makeManualPerson('Max','Mustermann');assert.equal(p.sources[0],'MANUELL_BESTAETIGT');
});
