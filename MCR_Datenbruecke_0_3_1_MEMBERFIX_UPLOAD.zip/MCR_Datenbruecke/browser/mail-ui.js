/* Guided single-ticket data assistant. No send/save/categorisation/queue traversal. */
'use strict';
const W=window;let T=W;try{void W.top.document.body;T=W.top;}catch{}
const demo=location.protocol==='file:'||location.href==='about:blank'||['localhost','127.0.0.1','[::1]'].includes(location.hostname);
if(!demo&&location.hostname!=='comarchecm.mercer.com')throw new Error('MCR: Nur im freigegebenen COMARCH-Fenster oder in der lokalen Demo verwenden.');
try{T.MCR_MAIL?.close();W.MCR_MAIL?.close();T.MCR_DATA?.close();W.MCR_DATA?.close();}catch{}
try{if(T.__mcrInspectorTimer)T.clearInterval(T.__mcrInspectorTimer);T.__mcrInspectorTimer=null;if(T.__MCR_CAPTURE_CLICK)T.__MCR_CAPTURE_CLICK=()=>{};T.document.getElementById('__mcr_comarch_inspector')?.remove();}catch{}
const D=T.document,HID='__mcr_mail_assistant_v3';D.getElementById(HID)?.remove();
const host=D.createElement('div');host.id=HID;
Object.assign(host.style,{position:'fixed',top:'12px',right:'12px',zIndex:'2147483647',width:'450px',maxWidth:'96vw'});
const shadow=host.attachShadow({mode:'open'}),style=D.createElement('style');
style.textContent=`:host{font:14px/1.45 'Segoe UI',Arial,sans-serif;color:#172d40}*{box-sizing:border-box}section{background:#fff;border:2px solid #275875;border-radius:12px;box-shadow:0 6px 30px #0005;max-height:94vh;overflow:auto;padding:16px}h2{font-size:19px;margin:0 0 6px}details.step{margin:12px 0;border:1px solid #beced9;border-radius:7px;padding:10px}summary{font-weight:700;cursor:pointer}p{margin:7px 0}.note{font-size:12px;color:#485c6a}label{display:block;margin:8px 0}input,textarea,select,button{font:inherit}input[type=text],select,textarea{width:100%;padding:7px;border:1px solid #91a5b5;border-radius:4px}input[type=file]{max-width:100%;font-size:12px}textarea{min-height:110px}button{padding:8px 11px;margin:4px 5px 4px 0;cursor:pointer;border:1px solid #6c899d;border-radius:5px;background:#edf3f8;color:#15354b}button:disabled{opacity:.5;cursor:not-allowed}.primary{background:#1d5778;color:white}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:12px/1.5 Consolas,monospace;padding:8px;background:#eff4f8;max-height:170px;overflow:auto}.status{padding:10px;border-left:4px solid #23747c;background:#edf7f6;font-weight:600}.error{border-color:#b24033;background:#fff0e9}.result{font:700 20px/1.4 'Segoe UI',Arial,sans-serif;background:#e7f4ef;padding:12px}.row{display:flex;gap:10px}.row>label{flex:1;min-width:0}small{font-size:12px}`;
shadow.append(style);const panel=D.createElement('section');shadow.append(panel);D.body.append(host);
let map=null,mail=null,analysis=null,candidates=[],chosen=null,context=null,waiting=false,member=null,result=null;
let alive=true,caseEpoch=0,mapEpoch=0,lastError=null,lastOutcome=null,proof=null,stable=null,autoCandidate=null,autoAttempted=false;
let waitStarted=0,selectionMode=null,descriptionWritten=false,format=null,fieldAtSearch=null;
let lastBlocking=null,idHints=[],selectionCommitted=false,lookupAttempted=false,lastSelectionState="NOT_STARTED";
const listeners=new Map(),ui={};
function el(tag,text,parent=panel){const n=D.createElement(tag);if(text!==undefined)n.textContent=text;parent.append(n);return n;}
function safe(fn){return async()=>{try{return await fn();}catch(e){error(e);}};}
function btn(text,fn,parent=panel){const n=el('button',text,parent);n.type='button';n.onclick=safe(fn);return n;}
function check(text,parent){const l=el('label',undefined,parent),n=D.createElement('input');n.type='checkbox';l.append(n,D.createTextNode(' '+text));return n;}
function input(label,id,parent){const l=el('label',label,parent),n=el('input',undefined,l);n.type='text';n.id=id;return n;}
function step(title){const n=el('details',undefined,panel);n.className='step';el('summary',title,n);return n;}
function status(text,bad=false){ui.status.textContent=text;ui.status.className='status'+(bad?' error':'');}
function go(n){[ui.s1,ui.s2,ui.s3,ui.s4].forEach((e,i)=>e.open=i===n-1);}
function clearResult(){result=null;descriptionWritten=false;ui.result.textContent='Noch kein Ergebnis.';ui.copy.disabled=true;ui.apply.disabled=true;ui.row.textContent='';}
function invalidate(reason){lastBlocking=null;selectionCommitted=false;lookupAttempted=false;lastSelectionState='NOT_STARTED';waiting=false;proof=null;stable=null;autoCandidate=null;autoAttempted=false;context=null;chosen=null;member=null;selectionMode=null;clearResult();if(reason)status(reason);}
function error(e){
 lastError=/^[A-Z_0-9]+$/.test(e.code??'')?e.code:'ERROR';waiting=false;clearResult();
 status(lastError+': '+(e.message||'Vorgang fehlgeschlagen.'),true);
 if(lastError==='ID_BLOCKED'){
  lastBlocking=e.blocking??null;go(4);ui.result.textContent='Member zugeordnet · Bestandszeile gesperrt';
  ui.row.textContent=[...(lastBlocking?.messages??[]),'Grund: '+(lastBlocking?.codes??[]).join(', '),'Excel-Quellzeile(n): '+(lastBlocking?.sourceRows??[]).join(', '),
   ...(lastBlocking?.issues??[]).map(x=>'Spalte '+x.column+': '+x.state+' ('+x.code+')'),
   lastBlocking?.legacyDetails?'Dieses ältere Mapping speichert keine Spaltendetails. MAPPING_PRUEFEN.cmd zeigt lokal die betroffene Originalzeile.':'Quelle gezielt prüfen. Danach Mapping neu erzeugen, nicht die JSON-Datei von Hand ändern.',
   'Keine automatische Entsperrung. Ticketnummer ändern hilft hier nicht.'].join('\n');
  ui.retry.textContent='Bestand erneut prüfen';
 }else if(lastError==='ID_NOT_FOUND'){
  go(4);ui.result.textContent='Member zugeordnet · nicht im geladenen Bestand';ui.row.textContent=e.message;
 }else if(lastError.startsWith('MEMBER_')||lastError==='SELECTION_REVIEW'){
  go(3);ui.memberInfo.textContent=e.message;
 }
}
function visible(n){try{return n.isConnected&&n.getClientRects().length>0&&n.ownerDocument.defaultView.getComputedStyle(n).visibility!=='hidden'&&n.ownerDocument.defaultView.getComputedStyle(n).display!=='none';}catch{return false;}}
function documents(){const out=[];function walk(doc,depth){if(!doc||depth>5||out.length>=32||out.includes(doc))return;out.push(doc);for(const f of doc.querySelectorAll('iframe,frame'))try{walk(f.contentDocument,depth+1);}catch{}}walk(D,0);return out;}
function memberField(){const all=documents().flatMap(d=>[...d.querySelectorAll('input[id="mainForm:member-value-id"]')]).filter(visible);Core.need(all.length===1,'MEMBER_FIELD','Bitte EIN Ticket öffnen, unten Bearbeiten anklicken und das Member-Feld anzeigen.');Core.need(!all[0].disabled&&!all[0].readOnly,'MEMBER_READONLY','Member-Feld ist noch nicht bearbeitbar.');return all[0];}
function detectedTicket(){
 const found=new Set();
 for(const doc of [D])for(const n of [...doc.querySelectorAll('label,span,td,div,b,strong,p')].slice(0,12000)){
  if(!visible(n))continue;const s=n.textContent?.trim()??'';if(s.length>70)continue;
  let m=s.match(/^Ticket[\s-]*ID\s*:?\s*(\d{4,15})$/i);if(m){found.add(m[1]);continue;}
  if(/^Ticket[\s-]*ID\s*:?$/i.test(s)){
   const next=n.nextElementSibling?.textContent?.trim();if(/^\d{4,15}$/.test(next??''))found.add(next);
   const p=n.parentElement?.textContent?.trim()??'';if(p.length<90&&(m=p.match(/^Ticket[\s-]*ID\s*:?\s*(\d{4,15})$/i)))found.add(m[1]);
  }
 }
 return found.size===1?[...found][0]:null;
}
// The ticket/document anchor protects against switching cases. It is NEVER
// used as the JSON lookup key and never needs to be replaced with a MercerID.
function documentKey(field){
 const scope=field.closest('form')??field.ownerDocument;const ids=new Set();
 for(const a of scope.querySelectorAll('a[href]'))try{
  const u=new URL(a.getAttribute('href'),field.ownerDocument.baseURI);
  if(u.origin!==field.ownerDocument.location.origin||!/(?:^|\/)GetFile\/?$/i.test(u.pathname))continue;
  for(const [k,v] of u.searchParams)if(/^docid$/i.test(k)&&/^\d{1,15}$/.test(v))ids.add(v);
 }catch{}
 return ids.size?[...ids].sort().join('|'):null;
}
function bindContext(){
 const actual=detectedTicket(),field=memberField(),docKey=documentKey(field);
 ui.ticket.value=actual??'nicht automatisch erkannt';
 ui.caseInfo.textContent=actual?'Vorgang erkannt. Diese Nummer wird NICHT im Bestand gesucht.':docKey?'Aktuelles Dokument als Fallgrenze erkannt. Keine Ticketnummer eingeben.':'Fall nur an dieses Formular gebunden. Bei Seitenwechsel oder Formularersetzung neu bestätigen.';
 return {id:actual,detected:!!actual,documentKey:docKey,url:T.location.href,field,mode:actual?'TICKET':docKey?'DOCUMENT':'FORM_ONLY'};
}
function contextOK(){
 Core.need(context&&context.url===T.location.href,'TICKET_CHANGED','Seite gewechselt. Mit Neuer Fall beginnen.');
 const actual=detectedTicket();
 Core.need(context.detected?actual===context.id:!actual,'TICKET_CHANGED','Vorgangskennung hat sich geändert. Neu beginnen.');
 const field=memberField(),key=documentKey(field);
 Core.need(key===context.documentKey,'TICKET_CHANGED','Originaldokumente des Tickets haben sich geändert. Neu beginnen.');
 if(!context.detected&&!context.documentKey)Core.need(field===context.field,'TICKET_REBIND','Ohne verlässliche Fallkennung wurde das Formular ersetzt. Person und Ticket erneut bestätigen.');
 return field;
}
// Distinguish an autocomplete suggestion from the populated MercerID profile.
// Only read short semantic values in the same form, never the mail iframe.
function committedProfile(field){
 const scope=field.closest('form')??field.ownerDocument,ids=new Set();let labelFound=false;
 for(const n of scope.querySelectorAll('label,span,td,div,b,strong')){
  if(!visible(n)||!/^Mercer\s*ID\s*:?$/i.test((n.textContent??'').trim()))continue;
  if(n.closest('[role="listbox"],[role="option"]'))continue;
  labelFound=true;const vals=[];
  if(n.htmlFor){const t=field.ownerDocument.getElementById(n.htmlFor);if(t&&t!==field)vals.push(t.value??t.textContent??'');}
  for(const t of [n.nextElementSibling,n.parentElement,n.parentElement?.nextElementSibling]){
   if(!t||t===field||t.contains(field)||!visible(t))continue;
   const text=(t.textContent??'').trim();if(text.length<=180)vals.push(text);
  }
  for(const text of vals){
   for(const m of text.matchAll(/\bINTL01-(\d{1,15})(?![\w.-])/g))ids.add(m[1]);
   const m=text.trim().match(/^(?:Mercer\s*ID\s*:?\s*)?(\d{4,15})$/i);if(m)ids.add(m[1]);
  }
 }
 return {labelFound,ambiguous:ids.size>1,clientId:ids.size===1?[...ids][0]:null};
}
function expectedId(){return Person.personId(ui.expected.value);}
function checkExpected(selected){
 const expected=expectedId();Core.need(expected===chosen.expectedId,'PERSON_ID_CHANGED','Personenkennung wurde geändert. Identität erneut bestätigen.');
 Core.need(!expected||expected===selected.clientId,'MAIL_MEMBER_CONFLICT','Geprüfte MercerID aus der Mail passt nicht zum ausgewählten COMARCH-Member. Nicht die Ticketnummer umschreiben.');
}
function freezeName(){return Person.query(ui.first.value,ui.last.value);}
function gates(){Core.need(map&&ui.sourceOK.checked,'MAPPING_REVIEW','JSON aus private_data laden und Quellenstand bestätigen.');Core.need(mail&&ui.mailOK.checked,'MAIL_REVIEW','Original-Mail laden und Zuordnung zu diesem Ticket bestätigen.');const p=freezeName();Core.need(chosen&&p.query===chosen.query&&expectedId()===chosen.expectedId,'NAME_CHANGED','Name wurde geändert. Suche neu starten.');return p;}
async function sha(value){Core.need(crypto?.subtle,'CRYPTO_REQUIRED','SHA-256 ist in diesem Browserkontext nicht verfügbar. HTTPS-COMARCH verwenden.');const b=typeof value==='string'?new TextEncoder().encode(value):value;return [...new Uint8Array(await crypto.subtle.digest('SHA-256',b))].map(x=>x.toString(16).padStart(2,'0')).join('');}
el('h2','MCR Mail-Assistent 0.3.1');
el('p','Original-Mail → geprüfter Name → Member → USC / Pläne').className='note';
ui.status=el('p','1 · Deine vorhandene JSON-Datei laden.');ui.status.className='status';
ui.s1=step('1 · Bestand laden (einmal pro Sitzung)');ui.s1.open=true;
el('p','JSON aus private_data auswählen — NICHT die Excel-Datei.',ui.s1);
ui.mapFile=el('input',undefined,ui.s1);ui.mapFile.type='file';ui.mapFile.accept='.json';ui.mapFile.id='mapFile';
ui.mapInfo=el('pre','Noch kein Mapping geladen.',ui.s1);
ui.sourceOK=check('Diese Bestandsversion und Spalte L als USC sind fachlich richtig und aktuell genug.',ui.s1);
ui.s2=step('2 · Original-Mail dieses Tickets laden');
el('p','Im COMARCH-Nachrichtenverlauf die Original-Mail herunterladen und Speichern wählen. Die .msg hier auswählen; Outlook muss nicht geöffnet werden.',ui.s2);
ui.mailFile=el('input',undefined,ui.s2);ui.mailFile.type='file';ui.mailFile.accept='.msg,.txt';ui.mailFile.id='mailFile';
ui.mailInfo=el('pre','Noch keine Mail geladen.',ui.s2);
const alternative=el('details',undefined,ui.s2);el('summary','Alternative: Mailtext selbst einfügen',alternative);
ui.raw=el('textarea',undefined,alternative);ui.raw.setAttribute('aria-label','Alternativer Mailtext');
btn('Diesen Text analysieren',()=>setMail({format:'MANUAL',subject:'',senderName:'',senderEmail:'',body:ui.raw.value,warnings:[],diagnostic:{plainText:true,attachmentsRead:false}}),alternative);
const review=el('details',undefined,ui.s2);el('summary','Gelesenen Text lokal prüfen',review);ui.body=el('pre','Noch kein Text.',review);
ui.s3=step('3 · Name prüfen und Member auswählen');
el('p','Der Name ist ein Vorschlag, kein Identitätsnachweis. Absender und betroffene Person können verschieden sein.',ui.s3).className='note';
const namesLabel=el('label','Namensvorschläge aus der Mail',ui.s3);ui.names=el('select',undefined,namesLabel);ui.names.id='nameCandidates';
const row=el('div',undefined,ui.s3);row.className='row';ui.first=input('Vorname','firstName',row);ui.last=input('Nachname','lastName',row);
btn('Vorname / Nachname tauschen',()=>{[ui.first.value,ui.last.value]=[ui.last.value,ui.first.value];nameChanged();},ui.s3);
ui.expected=input('MercerID / ClientEEID der Person (optional, aus der Mail)','expectedClientId',ui.s3);
ui.expected.placeholder='z. B. INTL01-12345678 oder 12345678';
ui.idInfo=el('pre','Kein Kennungshinweis aus der Mail.',ui.s3);
el('p','Nur die Kennung des tatsächlich ausgewählten COMARCH-Members wird in Excel/JSON gesucht.',ui.s3).className='note';
const technical=el('details',undefined,ui.s3);el('summary','Vorgangsnummer · nur zur Absicherung',technical);
ui.ticket=input('Ticket-ID (nicht MercerID, nur lesen)','ticketId',technical);ui.ticket.readOnly=true;
ui.caseInfo=el('p','Keine Ticketnummer eintippen. Der Assistent bindet den geöffneten Fall separat.',technical);ui.caseInfo.className='note';
ui.mailOK=check('Mail gehört zu diesem Ticket; Vorname, Nachname und ein ggf. angezeigter MercerID-Hinweis sind geprüft. Member-Suche freigeben.',ui.s3);
ui.autoOne=check('Genau einen technisch eindeutig nachgewiesenen Treffer automatisch auswählen. Sonst warte auf meine Auswahl.',ui.s3);ui.autoOne.checked=true;
ui.search=btn('Member suchen',startSearch,ui.s3);ui.search.className='primary';
btn('Suchnamen kopieren',async()=>{const p=freezeName();await navigator.clipboard.writeText(p.query);status('Suchname kopiert: im Member-Feld bei Bedarf selbst einfügen.');},ui.s3);
ui.memberInfo=el('pre','Noch keine Member-Suche gestartet.',ui.s3);
ui.confirm=btn('Meine Member-Auswahl bestätigen → weiter',()=>acceptMember(true),ui.s3);
btn('Suche / Warten stoppen',()=>invalidate('Gestoppt. Kein Versand, kein Speichern.'),ui.s3);
ui.s4=step('4 · Beschreibung übernehmen');
ui.result=el('div','Noch kein Ergebnis.',ui.s4);ui.result.className='result';ui.row=el('pre','',ui.s4);
ui.retry=btn('Bestand erneut prüfen',()=>acceptMember(true),ui.s4);
ui.formulaOK=check('Falls die Quellzeile Formeln enthält: gespeicherte Berechnungswerte geprüft.',ui.s4);
ui.copy=btn('Beschreibung kopieren',async()=>{checkCurrentResult();await navigator.clipboard.writeText(result.description);status('Beschreibung kopiert. Noch kein Ticket gespeichert.');},ui.s4);ui.copy.disabled=true;
ui.apply=btn('Beschreibung in COMARCH einsetzen',applyDescription,ui.s4);ui.apply.disabled=true;
el('p','Kein automatischer Versand, kein „Ticket speichern“. Kategorien, Signatur und Antwort sind weiterhin separat zu prüfen.',ui.s4).className='note';
btn('Neuer Fall',resetCase);btn('Diagnose-ZIP',downloadDiagnostic);btn('Schließen',close);
el('p','Nur im betrieblich freigegebenen Kontext verwenden. Mail und Mapping liegen im Speicher dieser COMARCH-Seite; keine isolierte Datenschutz-Sandbox.',panel).className='note';
async function loadMapText(value){
 const epoch=++mapEpoch;invalidate();map=null;go(1);ui.sourceOK.checked=false;ui.mapInfo.textContent='Mapping wird geprüft …';
 Core.need(value.length<=32*1024*1024,'MAP_SIZE','Mapping zu groß.');const obj=JSON.parse(value);Core.validateMap(obj);
 Core.need(demo||obj.payload.mode!=='DEMO','DEMO_NOT_IN_COMARCH','Demo-Mapping nicht in COMARCH einsetzen.');
 Core.need(await sha(JSON.stringify(obj.payload))===obj.payloadSha256,'MAP_HASH_MISMATCH','Mapping-Prüfsumme stimmt nicht.');Core.need(alive&&mapEpoch===epoch,'CANCELLED','Import ersetzt/geschlossen.');map=obj;
 const p=obj.payload;ui.mapInfo.textContent=[p.mode==='DEMO'?'DEMO · fiktive Daten':'Bestand geladen',p.source.filename,'Blatt: '+p.source.sheet+' | L: '+p.source.headers.L,'Stand: '+(p.source.modifiedAt??'unbekannt'),'Export: '+p.generatedAt,'Gültige Kennungen: '+Object.keys(p.entries).length,'Gesperrte Kennungen: '+Object.keys(p.blocked).length].join('\n');
 lastError=null;status('Mapping geprüft. Quellenstand bestätigen, dann Original-Mail laden.');return {validKeys:Object.keys(p.entries).length};
}
ui.mapFile.onchange=safe(async()=>{const f=ui.mapFile.files?.[0];if(!f)return;const epoch=++mapEpoch;invalidate();map=null;ui.sourceOK.checked=false;Core.need(f.size<=32*1024*1024,'MAP_SIZE','Mapping zu groß.');const text=await f.text();Core.need(alive&&epoch===mapEpoch,'CANCELLED','Import ersetzt/geschlossen.');await loadMapText(text);});
ui.sourceOK.onchange=()=>{invalidate();if(map&&ui.sourceOK.checked){go(2);status('2 · Original-Mail (.msg) auswählen. Dein Mapping bleibt geladen.');}};
function setMail(data){
 ++caseEpoch;invalidate();mail=null;analysis=null;candidates=[];ui.mailOK.checked=false;ui.formulaOK.checked=false;ui.first.value='';ui.last.value='';ui.names.replaceChildren();ui.body.textContent='';ui.mailInfo.textContent='';format=data.format;lastOutcome=null;
 analysis=Core.analyzeMail((data.subject?'Betreff: '+data.subject+'\n':'')+data.body);if(/^(?:WG|FW|FWD)\s*:/i.test(data.subject??''))analysis.warnings.push('WEITERLEITUNG: Absender und betroffene Person getrennt prüfen.');candidates=Person.candidates(data);mail=data;
 idHints=Person.identifierHints(data,analysis.idHints,candidates);const uniqueIds=[...new Set(idHints.map(x=>x.clientId))];
 ui.expected.value=uniqueIds.length===1?uniqueIds[0]:'';
 ui.idInfo.textContent=idHints.length?idHints.map(x=>x.clientId+' — '+(x.strength==='EXPLICIT'?'beschriftete Kennung':'Namensnähe: nur Hinweis, prüfen')).join('\n'):'Kein Kennungshinweis. Die spätere ausgewählte MercerID reicht für den Bestandsabgleich.';
 ui.body.textContent=data.body;
 ui.mailInfo.textContent=['Format: '+data.format,'Betreff: '+(data.subject||'(nicht vorhanden)'),'Absender: '+(data.senderName||'(nicht vorhanden)'),...data.warnings,...analysis.warnings].join('\n');
 el('option','Bitte Namensvorschlag wählen oder unten selbst eingeben',ui.names).value='';
 candidates.forEach((c,i)=>{const o=el('option',c.name+' — '+c.sources.join(', '),ui.names);o.value=String(i);});
 if(candidates.length===1){ui.names.value='0';chooseName(0);}else ui.names.value='';
 const ticket=detectedTicket();ui.ticket.value=ticket??'nicht automatisch erkannt';
 go(3);lastError=null;status(candidates.length===1?'3 · Name und ggf. MercerID-Hinweis prüfen, dann „Member suchen“.':candidates.length?'3 · Mehrere Namenshinweise: richtige Person auswählen.':'3 · Kein eindeutiger Name erkannt. Vorname und Nachname aus dem Text selbst eintragen.');
 return {nameCandidates:candidates.length,idCandidates:new Set(idHints.map(x=>x.clientId)).size};
}
async function loadMailBytes(bytes,extension){
 const epoch=++caseEpoch;invalidate();mail=null;analysis=null;ui.mailOK.checked=false;ui.mailInfo.textContent='Original-Mail wird lokal gelesen …';
 Core.need(alive,'CLOSED','Helfer ist geschlossen.');
 const item=extension.toLowerCase()==='.msg'?Msg.parseMsg(bytes):extension.toLowerCase()==='.txt'?Msg.parseText(bytes):Core.fail('MAIL_FORMAT','Bitte die Original-.msg oder UTF-8-.txt verwenden. .eml ist hier noch nicht unterstützt.');
 Core.need(alive&&epoch===caseEpoch,'CANCELLED','Mailimport ersetzt.');return setMail(item);
}
ui.mailFile.onchange=safe(async()=>{const f=ui.mailFile.files?.[0];if(!f)return;const epoch=++caseEpoch;invalidate();mail=null;analysis=null;ui.mailOK.checked=false;Core.need(f.size<=Msg.MAX_FILE,'MSG_SIZE','Maildatei zu groß (32 MiB).');const bytes=await f.arrayBuffer();Core.need(alive&&epoch===caseEpoch,'CANCELLED','Mailimport durch anderen Fall ersetzt.');await loadMailBytes(bytes,(/\.[^.]+$/.exec(f.name)??[''])[0]);});
function chooseName(i){const c=candidates[i];if(!c)return;ui.first.value=c.firstName;ui.last.value=c.lastName;nameChanged();if(c.needsSplit)status('Mehrteiliger Name: Vorname und vollständigen Nachnamen bitte selbst zuordnen.');}
ui.names.onchange=()=>{if(ui.names.value!=='')chooseName(Number(ui.names.value));};
function nameChanged(){invalidate();ui.mailOK.checked=false;}
ui.first.oninput=nameChanged;ui.last.oninput=nameChanged;ui.expected.oninput=nameChanged;ui.mailOK.onchange=()=>{if(!ui.mailOK.checked)invalidate();};
function setNativeValue(field,value){const owner=field.ownerDocument.defaultView;const p=field.tagName==='TEXTAREA'?owner.HTMLTextAreaElement.prototype:owner.HTMLInputElement.prototype;Object.getOwnPropertyDescriptor(p,'value').set.call(field,value);field.dispatchEvent(new owner.Event('input',{bubbles:true}));field.dispatchEvent(new owner.Event('change',{bubbles:true}));}
function startSearch(){
 invalidate();chosen={...freezeName(),expectedId:expectedId()};gates();context=bindContext();const f=memberField();
 Core.need(!/INTL01-\d/.test(f.value),'MEMBER_EXISTS','Ein Member ist bereits gesetzt. Richtigkeit prüfen und „Meine Member-Auswahl bestätigen → weiter“ benutzen; nichts automatisch überschreiben.');
 fieldAtSearch=f;waiting=true;waitStarted=Date.now();lastError=null;lastSelectionState='WAITING_FOR_CHOICE';autoAttempted=false;ui.memberInfo.textContent='Suche: '+chosen.query+'\nTrefferliste in COMARCH abwarten. Bei mehreren Treffern selbst anklicken.';
 f.focus();setNativeValue(f,chosen.query);f.dispatchEvent(new f.ownerDocument.defaultView.KeyboardEvent('keyup',{key:'Unidentified',bubbles:true}));
 status('Warte auf COMARCH-Treffer. Falls keine Liste erscheint: im Member-Feld ein Zeichen löschen und neu tippen. Kein Enter auf Senden.');
}
function observeChoice(event){
 if(!waiting||!event.isTrusted||!chosen)return;
 if(event.composedPath().includes(host))return;
 let n=event.target;for(let i=0;n&&i<6;i++,n=n.parentElement){
  if(n.nodeType!==1||['BODY','HTML','FORM'].includes(n.tagName))break;
  const text=n.innerText??n.textContent??'';if(text.length>300)continue;
  try{const selected=Core.selectedMember(text);if(Person.memberMatches(text,chosen)){proof={id:selected.clientId,until:Date.now()+10000,mode:'USER_CLICK'};return;}}catch{}
 }
}
function strictSingle(f){
 if(!ui.autoOne.checked||autoAttempted||context?.mode==='FORM_ONLY')return null;
 const refs=(f.getAttribute('aria-controls')||f.getAttribute('aria-owns')||'').trim().split(/\s+/).filter(Boolean);if(refs.length!==1)return null;
 const list=f.ownerDocument.getElementById(refs[0]);if(!list||!visible(list)||list.getAttribute('role')!=='listbox'||list.getAttribute('aria-busy')!=='false')return null;
 const options=[...list.querySelectorAll('[role="option"]')].filter(visible);if(options.length!==1)return null;
 const o=options[0];if(o.getAttribute('aria-setsize')!=='1'||o.getAttribute('aria-posinset')!=='1'||o.getAttribute('aria-disabled')==='true')return null;
 const text=o.innerText??'';if(text.length>300||!Person.memberMatches(text,chosen))return null;
 try{const s=Core.selectedMember(text);if(chosen.expectedId&&chosen.expectedId!==s.clientId)return null;const ids=[...new Set(analysis.idHints.map(x=>x.clientId))];if(ids.length>1||(ids.length===1&&ids[0]!==s.clientId))return null;Core.lookup(map,s.clientId);return {element:o,id:s.clientId,text};}catch{return null;}
}
function tick(){
 if(!alive)return;
 for(const doc of documents())if(!listeners.has(doc)){doc.addEventListener('pointerdown',observeChoice,true);listeners.set(doc,true);}
 if(result){try{checkCurrentResult();}catch(e){error(e);}return;}
 if(!waiting)return;
 try{
  gates();const f=contextOK();
  if(Date.now()-waitStarted>120000){waiting=false;status('Warten pausiert. Person auswählen und mit „Meine Member-Auswahl bestätigen → weiter“ fortfahren.');return;}
  let value=null;try{value=Core.selectedMember(f.value);}catch{}
  if(value){
   if(!Person.memberMatches(value.display,chosen)){error(Object.assign(new Error('Ausgewählter Name passt nicht zum bestätigten Suchnamen. Vorname/Nachname und Person prüfen.'),{code:'MEMBER_NAME_CONFLICT'}));return;}
   checkExpected(value);const profile=committedProfile(f);
   Core.need(!profile.ambiguous,'MEMBER_PROFILE_AMBIGUOUS','MercerID-Stammdaten sind nicht eindeutig. Nicht automatisch fortfahren.');
   if(profile.clientId)Core.need(profile.clientId===value.clientId,'MEMBER_PROFILE_CONFLICT','Member-Feld und MercerID-Stammdaten widersprechen sich. COMARCH-Verarbeitung abwarten.');
   ui.memberInfo.textContent='Member-Feld: '+value.display;
   if(profile.labelFound&&!profile.clientId){stable=null;lastSelectionState='WAITING_FOR_COMMIT';status('Vorschlag gefunden, aber noch nicht übernommen. Den echten Vorschlag anklicken; MercerID-Stammdaten sind noch leer.');return;}
   if(!stable||stable.value!==f.value)stable={value:f.value,since:Date.now()};
   lastSelectionState='MEMBER_VALUE_READY';
   if(Date.now()-stable.since>=900&&proof?.id===value.clientId&&proof.until>Date.now()&&(context.detected||context.documentKey))acceptMember(false);
   else status('Member erkannt. Falls es nicht automatisch weitergeht: „Meine Member-Auswahl bestätigen → weiter“.');
   return;
  }
  stable=null;const one=strictSingle(f);
  if(!one){autoCandidate=null;lastSelectionState='WAITING_FOR_USER_OR_UNQUALIFIED_LIST';ui.memberInfo.textContent='Suchname eingetragen. Der Vorschlag ist noch NICHT ausgewählt. Bei mehreren Treffern oder einer nicht eindeutig lesbaren Liste: richtigen Vorschlag in COMARCH anklicken, danach bei Bedarf Auswahl bestätigen.';return;}
  if(!autoCandidate||autoCandidate.element!==one.element||autoCandidate.text!==one.text){autoCandidate={...one,since:Date.now()};return;}
  if(Date.now()-autoCandidate.since>=1500){
   // Only an explicitly linked widget declaring the complete result size 1 may be clicked.
   gates();contextOK();autoAttempted=true;proof={id:one.id,until:Date.now()+10000,mode:'LINKED_SINGLE'};one.element.click();
  }
 }catch(e){error(e);}
}
function acceptMember(explicit){
 if(explicit&&!chosen){chosen={...freezeName(),expectedId:expectedId()};gates();context=bindContext();}
 gates();const f=contextOK(),s=Core.selectedMember(f.value);checkExpected(s);
 const profile=committedProfile(f);Core.need(!profile.ambiguous,'MEMBER_PROFILE_AMBIGUOUS','MercerID-Stammdaten nicht eindeutig.');
 Core.need(!profile.labelFound||profile.clientId,'MEMBER_COMMIT_PENDING','Vorschlag noch nicht übernommen: In COMARCH den Treffer anklicken und warten, bis MercerID/Vorname/Nachname ausgefüllt sind.');
 Core.need(!profile.clientId||profile.clientId===s.clientId,'MEMBER_PROFILE_CONFLICT','Member-Feld und MercerID-Stammdaten widersprechen sich.');
 Core.need(Person.memberMatches(s.display,chosen),'MEMBER_NAME_CONFLICT','COMARCH-Member stimmt nicht mit geprüftem Vor-/Nachnamen überein. Namen prüfen, nicht die Kennung erraten.');
 Core.need(explicit||(proof?.id===s.clientId&&proof.until>Date.now()),'SELECTION_REVIEW','Person aus der tatsächlichen Trefferliste auswählen und bestätigen.');
 const ids=[...new Set(analysis.idHints.map(x=>x.clientId))];Core.need(ids.length<=1,'MAIL_AMBIGUOUS','Mehrere Personenkennungen in der Mail. Dieser Fall braucht manuelle Klärung.');Core.need(!ids.length||ids[0]===s.clientId,'MAIL_MEMBER_CONFLICT','Mail-Kennung und ausgewählter Member widersprechen sich.');
 member={...s,element:f};waiting=false;selectionMode=explicit?'USER_CONFIRMATION':proof.mode;selectionCommitted=true;lastSelectionState='MEMBER_CONFIRMED';
 lookupAttempted=true;lastBlocking=null;go(4);const entry=Core.lookup(map,s.clientId);
 if(entry.formulas.length&&!ui.formulaOK.checked){status('Quellzeile enthält Formeln. Gespeicherte Werte prüfen und unten bestätigen.');ui.row.textContent='Quellzeile '+entry.sourceRow+' | Formeln in '+entry.formulas.join(', ');return null;}
 result={...entry,description:Core.description(entry),ticket:context.id,memberDisplay:s.display};ui.result.textContent=result.description;
 ui.row.textContent=['ClientEEID: '+s.clientId,'Excel-Zeile: '+entry.sourceRow,'L / USC: '+entry.usc,'C / DC: '+entry.dc+' | D / PP+: '+entry.ppPlus+' | E / DB+: '+entry.dbPlus].join('\n');
 ui.copy.disabled=false;ui.apply.disabled=false;lastError=null;lastOutcome='LOOKUP_READY';status('4 · Beschreibung bereit. Nur auf deinen Klick wird sie in COMARCH eingesetzt. Noch kein Versand oder Speichern.');return {sourceRow:entry.sourceRow,description:result.description};
}
ui.formulaOK.onchange=safe(()=>{if(member&&ui.formulaOK.checked)return acceptMember(true);clearResult();});
function checkCurrentResult(){Core.need(result&&member,'RESULT_REQUIRED','Zuerst den Member bestätigen und Bestandsabgleich durchführen.');gates();const f=contextOK();Core.need(f===member.element&&f.value===result.memberDisplay,'MEMBER_CHANGED','Member oder Formular wurde nach dem Lookup geändert. Neu bestätigen.');Core.need(!result.formulas.length||ui.formulaOK.checked,'FORMULA_CACHE_REVIEW','Gespeicherte Formelwerte nicht bestätigt.');return f;}
function descriptionField(){
 const found=new Set();
 for(const doc of documents()){
  for(const l of doc.querySelectorAll('label'))if(/^Zusätzliche Beschreibung\s*:?$/i.test(l.textContent.trim())&&l.htmlFor){const n=doc.getElementById(l.htmlFor);if(n?.tagName==='TEXTAREA'&&visible(n))found.add(n);}
  const candidate=doc.getElementById('mainForm:j_id7019');
  if(candidate?.tagName==='TEXTAREA'&&visible(candidate)){
   // Observed dynamic ID is accepted only with a nearby semantic label, never alone.
   const p=candidate.parentElement;let text=p?.textContent??'';if(text.length<500&&/Zusätzliche Beschreibung/i.test(text))found.add(candidate);
   const prev=candidate.previousElementSibling;if(prev&&/^Zusätzliche Beschreibung\s*:?$/i.test(prev.textContent.trim()))found.add(candidate);
  }
 }
 Core.need(found.size===1,'DESCRIPTION_FIELD','Beschreibungsfeld nicht eindeutig gebunden. „Beschreibung kopieren“ verwenden und selbst einsetzen.');return [...found][0];
}
function applyDescription(){
 checkCurrentResult();const f=descriptionField();Core.need(!f.disabled&&!f.readOnly,'DESCRIPTION_READONLY','Beschreibungsfeld nicht bearbeitbar.');
 Core.need(!f.value.trim()||f.value===result.description,'DESCRIPTION_EXISTS','Vorhandene Beschreibung wird nicht überschrieben. Bitte manuell prüfen.');
 setNativeValue(f,result.description);Core.need(f.value===result.description,'DESCRIPTION_VERIFY','Einsetzen konnte nicht geprüft werden.');descriptionWritten=true;lastOutcome='DESCRIPTION_INSERTED';status('Beschreibung eingesetzt. Noch NICHT gespeichert, keine Antwort versendet. Restlichen Ticketablauf selbst abschließen.');
}
function resetCase(){++caseEpoch;invalidate();mail=null;analysis=null;candidates=[];ui.mailFile.value='';ui.raw.value='';ui.body.textContent='Noch kein Text.';ui.mailInfo.textContent='Noch keine Mail geladen.';ui.names.replaceChildren();ui.first.value='';ui.last.value='';ui.expected.value='';idHints=[];ui.idInfo.textContent='Kein Kennungshinweis aus der Mail.';ui.ticket.value='';ui.mailOK.checked=false;ui.formulaOK.checked=false;ui.memberInfo.textContent='Noch keine Member-Suche gestartet.';lastError=null;lastOutcome=null;format=null;go(map&&ui.sourceOK.checked?2:1);status('Neuer Fall. Mapping bleibt geladen. Jetzt die Original-Mail des nächsten Tickets auswählen.');}
function diagnostic(){
 let widget={fieldPresent:false,linkedList:false,declaredCompleteSingle:false,profileLabelFound:false,profileIdPresent:false};
 try{const f=memberField(),p=committedProfile(f);widget={fieldPresent:true,linkedList:!!(f.getAttribute('aria-controls')||f.getAttribute('aria-owns')),declaredCompleteSingle:!!strictSingle(f),profileLabelFound:p.labelFound,profileIdPresent:!!p.clientId};}catch{}
 return {schema:'MCR_MAIL_DIAGNOSTIC_V1',version:'0.3.1',createdAt:new Date().toISOString(),
 capabilities:{readsMsg:true,networkUpload:false,automaticSend:false,automaticSave:false,confirmedMemberSearch:true,confirmedDescriptionInsert:true},
 mapping:{loaded:!!map,sourceConfirmed:ui.sourceOK.checked,selectedKeyBlocked:!!lastBlocking,blockedCodes:lastBlocking?.codes??[],blockedIssues:lastBlocking?.issues??[],blockedSourceRowCount:lastBlocking?.sourceRows.length??0},
 mail:{format,nameCandidates:candidates.length,idCandidates:new Set(idHints.map(x=>x.clientId)).size,explicitIdCandidates:analysis?.idHints.length??0,plainText:!!mail},
 flow:{waiting,selectionMode,selectionCommitted,lastSelectionState,ticketAutoBound:context?.detected??false,caseBinding:context?.mode??null,lookupAttempted,lookupKeySource:lookupAttempted?'SELECTED_MEMBER':null,lookupReady:!!result,descriptionWritten,lastOutcome},widget,lastError};
}
function crc32(bytes){let c=0xffffffff;for(const b of bytes){c^=b;for(let k=0;k<8;k++)c=(c&1)?0xedb88320^(c>>>1):c>>>1;}return(c^0xffffffff)>>>0;}
function storeZip(files){
 let offset=0;const local=[],central=[],enc=new TextEncoder();
 const concat=parts=>{const all=new Uint8Array(parts.reduce((n,p)=>n+p.length,0));let i=0;for(const p of parts){all.set(p,i);i+=p.length;}return all;};
 for(const [name,text] of files){
  const n=enc.encode(name),data=enc.encode(text),crc=crc32(data),h=new Uint8Array(30),v=new DataView(h.buffer);
  v.setUint32(0,0x04034b50,true);v.setUint16(4,20,true);v.setUint16(6,0x800,true);v.setUint16(12,33,true);v.setUint32(14,crc,true);v.setUint32(18,data.length,true);v.setUint32(22,data.length,true);v.setUint16(26,n.length,true);
  const c=new Uint8Array(46),cv=new DataView(c.buffer);cv.setUint32(0,0x02014b50,true);cv.setUint16(4,20,true);cv.setUint16(6,20,true);cv.setUint16(8,0x800,true);cv.setUint16(14,33,true);cv.setUint32(16,crc,true);cv.setUint32(20,data.length,true);cv.setUint32(24,data.length,true);cv.setUint16(28,n.length,true);cv.setUint32(42,offset,true);
  local.push(h,n,data);central.push(c,n);offset+=h.length+n.length+data.length;
 }
 const cd=concat(central),end=new Uint8Array(22),ev=new DataView(end.buffer);ev.setUint32(0,0x06054b50,true);ev.setUint16(8,files.length,true);ev.setUint16(10,files.length,true);ev.setUint32(12,cd.length,true);ev.setUint32(16,offset,true);
 return concat([...local,cd,end]);
}

async function diagnosticBytes(){
 const report=JSON.stringify(diagnostic(),null,2)+'\n',hash=await sha(report);
 const manifest=JSON.stringify({schema:'MCR_DIAGNOSTIC_MANIFEST_V1',payload:[{path:'diagnostic.json',sha256:hash}],privacy:'No mail bytes/text, names, identifiers, filenames, addresses, URLs, cookies, mapping values or document HTML.'},null,2)+'\n';
 return storeZip([['diagnostic.json',report],['manifest.json',manifest],['SHA256SUMS.txt',hash+'  diagnostic.json\n'+await sha(manifest)+'  manifest.json\n']]);
}
async function downloadDiagnostic(){const bytes=await diagnosticBytes(),hash=await sha(bytes),url=URL.createObjectURL(new Blob([bytes],{type:'application/zip'})),a=D.createElement('a');a.href=url;a.download='MCR_MAIL_'+new Date().toISOString().replace(/[:.]/g,'-')+'_UPLOAD.zip';a.click();setTimeout(()=>URL.revokeObjectURL(url),20000);status('Diagnose-ZIP erstellt (ohne Mail/Mapping). ZIP-SHA256: '+hash);}
function close(){alive=false;++caseEpoch;++mapEpoch;clearInterval(timer);for(const doc of listeners.keys())doc.removeEventListener('pointerdown',observeChoice,true);listeners.clear();map=null;mail=null;analysis=null;candidates=[];member=null;result=null;proof=null;chosen=null;context=null;ui.raw.value='';ui.body.textContent='';ui.first.value='';ui.last.value='';ui.expected.value='';idHints=[];lastBlocking=null;host.remove();if(T.MCR_MAIL===api)delete T.MCR_MAIL;if(W.MCR_MAIL===api)delete W.MCR_MAIL;}
const timer=setInterval(tick,350);
const api=Object.freeze({version:'0.3.1',loadMapText,loadMailBytes,setMail,startSearch,acceptMember,resetCase,diagnostic,diagnosticBytes,close});
T.MCR_MAIL=api;W.MCR_MAIL=api;
console.info('MCR Mail-Assistent 0.3.1 aktiv. Keine Mail-/Personenwerte in der Konsole. Kein Versand, kein Ticket-Speichern.');
