"""0.3.1 focused regression. Injected synthetic about:blank DOM only.
The container denies native navigation. Browser policy is not modified.
Test-only SHA256 bridge to hashlib; shipped code still requires native SubtleCrypto.
"""
import hashlib, json, re, pathlib, io, zipfile
from playwright.sync_api import sync_playwright
R=pathlib.Path(__file__).resolve().parents[1]
results=[]
def mark(name):
 results.append({'name':name,'status':'PASS'});print('PASS',name,flush=True)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True)
 page=b.new_page(viewport={'width':1550,'height':1100});page.set_default_timeout(8000)
 original_wait=page.wait_for_function
 page.wait_for_function=lambda expression,**kw: original_wait(expression,polling=100,**kw)
 html=(R/'MAIL_DEMO.html').read_text()
 page.set_content(re.sub(r'<script[^>]*>[\s\S]*?</script>','',html))
 for s in re.findall(r'<script>([\s\S]*?)</script>',html):page.evaluate(s+'\n;void 0;')
 page.expose_function('__testSha',lambda data:list(hashlib.sha256(bytes(data)).digest()))
 page.evaluate("Object.defineProperty(crypto,'subtle',{value:{digest:async (_,data)=>new Uint8Array(await __testSha(Array.from(new Uint8Array(data)))).buffer}})")
 page.evaluate((R/'COMARCH_MAIL_ASSISTENT.js').read_text())
 root=page.locator('#__mcr_mail_assistant_v3')
 base=json.loads((R/'examples/DEMO_mapping.json').read_text())
 def load_map(obj=None):
  text=json.dumps(obj or base,ensure_ascii=False)
  page.evaluate("async raw=>{const m=JSON.parse(raw);const h=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(m.payload)));m.payloadSha256=Array.from(new Uint8Array(h),x=>x.toString(16).padStart(2,'0')).join('');await MCR_MAIL.loadMapText(JSON.stringify(m));}",text)
  root.get_by_label('Diese Bestandsversion',exact=False).check()
 def clear():
  page.evaluate("MCR_MAIL.resetCase();document.getElementById('mainForm:member-value-id').value='';document.getElementById('suggestions').hidden=true;document.getElementById('mainForm:j_id7019').value='';document.getElementById('profileArea')?.remove();")
 def mail(subject='Fwd: Anfrage / Max Mustermann, 99900001'):
  page.evaluate("subject=>MCR_MAIL.setMail({format:'MANUAL',subject,senderName:'Max Mustermann',senderEmail:'',body:'Mit freundlichen Grüßen\\nMax Mustermann',warnings:[]})",subject)
 def approve():root.get_by_label('Mail gehört zu diesem Ticket',exact=False).check()
 def selected(value='Mustermann Max (INTL01-99900001)'):
  page.locator('[id="mainForm:member-value-id"]').evaluate('(el,value)=>el.value=value',value)
 def confirm():root.get_by_role('button',name='Meine Member-Auswahl bestätigen',exact=False).click()
 load_map();mail()
 assert root.locator('#expectedClientId').input_value()=='99900001'
 assert root.locator('#ticketId').input_value()=='90000001'
 assert root.locator('#ticketId').get_attribute('readonly') is not None
 assert page.evaluate('MCR_MAIL.diagnostic().mail.idCandidates')==1
 mark('Subject number adjacent to known name is reviewed MercerID hint; ticket remains separate and read-only')
 approve();selected();confirm()
 assert page.evaluate('MCR_MAIL.diagnostic().flow.lookupKeySource')=='SELECTED_MEMBER'
 assert 'USC 10/ PP+' in root.locator('.result').inner_text()
 mark('Lookup uses actual selected Member even though Ticket ID differs')
 clear();mail();root.locator('#expectedClientId').fill('90000001');approve();selected();confirm()
 assert page.evaluate('MCR_MAIL.diagnostic().lastError')=='MAIL_MEMBER_CONFLICT'
 assert not page.evaluate('MCR_MAIL.diagnostic().flow.lookupReady')
 mark('Entering ticket number in person hint blocks mismatch rather than selecting another mapping key')
 clear();mail('Keine Personennummer im Betreff');approve();selected();confirm()
 assert page.evaluate('MCR_MAIL.diagnostic().flow.lookupReady')
 mark('No ID in email is acceptable after actual Member and human name review')
 clear();mail();approve()
 page.evaluate("const p=document.createElement('div');p.id='profileArea';p.innerHTML='<span>MercerID:</span><strong id=profileId></strong>';document.querySelector('main').append(p)")
 selected();confirm()
 assert page.evaluate('MCR_MAIL.diagnostic().lastError')=='MEMBER_COMMIT_PENDING'
 assert not page.evaluate('MCR_MAIL.diagnostic().flow.lookupAttempted')
 mark('Formatted member suggestion with still-empty MercerID profile is NOT a committed selection')
 page.evaluate("document.getElementById('profileId').textContent='INTL01-99900001'");confirm()
 assert page.evaluate('MCR_MAIL.diagnostic().flow.lookupReady')
 mark('Lookup continues after actual MercerID profile is populated and selection confirmed')
 clear();mail();approve()
 page.evaluate("const p=document.createElement('div');p.id='profileArea';p.innerHTML='<span>MercerID:</span><strong>INTL01-99900002</strong>';document.querySelector('main').append(p)")
 selected();confirm();assert page.evaluate('MCR_MAIL.diagnostic().lastError')=='MEMBER_PROFILE_CONFLICT'
 mark('Different profile MercerID and member input are blocked')
 clear();mail();approve()
 # DOM frame without an automatically recognised ticket ID: manual path remains available.
 page.evaluate("document.querySelector('main p b').textContent='Vorgang:'")
 selected();confirm()
 assert page.evaluate('MCR_MAIL.diagnostic().flow.lookupReady')
 assert page.evaluate('MCR_MAIL.diagnostic().flow.caseBinding')=='FORM_ONLY'
 mark('No manually typed ticket ID is required in conservative same-form fallback')
 page.evaluate("const f=document.getElementById('mainForm:member-value-id');f.replaceWith(f.cloneNode(true))")
 page.wait_for_function("MCR_MAIL.diagnostic().lastError==='TICKET_REBIND'")
 mark('Same-form fallback invalidated when AJAX replaces an unbound form')
 # restore fixture listeners by re-running the demo in a fresh DOM/page.
 page.close();page=b.new_page(viewport={'width':1550,'height':1100});page.set_default_timeout(8000)
 original_wait=page.wait_for_function
 page.wait_for_function=lambda expression,**kw: original_wait(expression,polling=100,**kw)
 page.set_content(re.sub(r'<script[^>]*>[\s\S]*?</script>','',html))
 for s in re.findall(r'<script>([\s\S]*?)</script>',html):page.evaluate(s+'\n;void 0;')
 page.expose_function('__testSha',lambda data:list(hashlib.sha256(bytes(data)).digest()))
 page.evaluate("Object.defineProperty(crypto,'subtle',{value:{digest:async (_,data)=>new Uint8Array(await __testSha(Array.from(new Uint8Array(data)))).buffer}})")
 page.evaluate((R/'COMARCH_MAIL_ASSISTENT.js').read_text());root=page.locator('#__mcr_mail_assistant_v3')
 blocked=json.loads(json.dumps(base));del blocked['payload']['entries']['99900001']
 blocked['payload']['blocked']['99900001']={'sourceRows':[17],'codes':['FLAG_INVALID']}
 blocked['payload']['summary'].update(validKeys=6,blockedKeys=1)
 load_map(blocked);mail();approve();selected();confirm()
 d=page.evaluate('MCR_MAIL.diagnostic()')
 assert d['lastError']=='ID_BLOCKED' and d['mapping']['blockedCodes']==['FLAG_INVALID']
 assert d['flow']['selectionCommitted'] and d['flow']['lookupAttempted']
 assert d['flow']['lookupKeySource']=='SELECTED_MEMBER'
 assert root.locator('.result').inner_text()=='Member zugeordnet · Bestandszeile gesperrt'
 assert root.get_by_role('button',name='Beschreibung in COMARCH einsetzen',exact=True).is_disabled()
 assert '17' in root.locator('.step').nth(3).inner_text()
 mark('Exact supplied old-report pattern reproduces ID_BLOCKED independently of ticket identity')
 mark('Blocked reason and original row displayed in step 4, action buttons stay disabled')
 page.screenshot(path=str(R/'docs/MEMBERFIX_BLOCKED_PREVIEW.png'),full_page=True)
 diag=bytes(page.evaluate('async()=>Array.from(await MCR_MAIL.diagnosticBytes())'))
 with zipfile.ZipFile(io.BytesIO(diag)) as z:
  assert z.testzip() is None
  for line in z.read('SHA256SUMS.txt').decode().splitlines():h,n=line.split('  ');assert hashlib.sha256(z.read(n)).hexdigest()==h
  data=z.read('diagnostic.json').decode()
  for forbidden in ['99900001','90000001','Mustermann','Max','sourceRows','USC 10/ PP+']:
   assert forbidden not in data,forbidden
  assert 'FLAG_INVALID' in data
 mark('Extended diagnosis ZIP contains whitelist reason codes but no IDs, row numbers or customer values')
 blocked['payload']['blocked']['99900001']['issues']=[{'code':'FLAG_INVALID','column':'C','state':'EMPTY'}]
 clear();load_map(blocked);mail();approve();selected();confirm()
 assert 'Spalte C: EMPTY' in root.locator('.step').nth(3).inner_text()
 assert page.evaluate('MCR_MAIL.diagnostic().mapping.blockedIssues')[0]['column']=='C'
 mark('New mapping explains exact invalid column without automatically converting empty cells to zero')
 # A deliberately formula-bearing snapshot still needs the separate formula gate.
 formula=json.loads(json.dumps(base));formula['payload']['entries']['99900001']['formulas']=['L']
 clear();load_map(formula);mail();approve();selected();confirm()
 assert not page.evaluate('MCR_MAIL.diagnostic().flow.lookupReady')
 root.get_by_label('Falls die Quellzeile Formeln enthält',exact=False).check()
 assert page.evaluate('MCR_MAIL.diagnostic().flow.lookupReady')
 mark('Formula cache confirmation remains required after member/ticket UI changes')
 clear();load_map();mail();approve();page.evaluate("demoMode='legacy'")
 root.get_by_role('button',name='Member suchen',exact=True).click();page.wait_for_timeout(2200)
 assert not page.evaluate('MCR_MAIL.diagnostic().flow.lookupReady')
 assert page.evaluate('MCR_MAIL.diagnostic().flow.lastSelectionState')=='WAITING_FOR_USER_OR_UNQUALIFIED_LIST'
 assert 'NICHT ausgewählt' in root.locator('.step').nth(2).inner_text()
 page.locator('#suggestions [role=option]').first.click()
 page.wait_for_function('MCR_MAIL.diagnostic().flow.lookupReady',timeout=8000)
 assert page.evaluate('MCR_MAIL.diagnostic().flow.selectionMode')=='USER_CLICK'
 mark('Unknown legacy list waits clearly; trusted real user click automatically resumes on a bound ticket')
 assert page.evaluate('[demoSends,demoSaves]')==[0,0]
 assert page.locator('[id="mainForm:j_id7019"]').input_value()==''
 mark('All lookup/error paths leave send, save and description untouched')
 # Capture a real test result with the package version and separate IDs for visual QA.
 page.screenshot(path=str(R/'docs/MEMBERFIX_RESULT_PREVIEW.png'),full_page=True)
 b.close()
(R/'docs/MEMBERFIX_FOCUSED_BROWSER_TEST_RESULT.json').write_text(json.dumps({'environment':'Linux Chromium; injected synthetic DOM; native browser navigation blocked by container policy and left unchanged. Test-only SHA256 bridge to hashlib. Real Edge/COMARCH, native SubtleCrypto, native file navigation not qualified.','tests':results},indent=2)+'\n')
