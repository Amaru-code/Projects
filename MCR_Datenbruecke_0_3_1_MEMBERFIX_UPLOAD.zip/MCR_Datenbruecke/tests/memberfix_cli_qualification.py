from pathlib import Path
import subprocess,selectors,time,json,hashlib,zipfile,tempfile
R=Path(__file__).resolve().parents[1]
tmp=tempfile.TemporaryDirectory(prefix='mcr-member-cli-')
# Create a synthetic older blocked mapping; no actual customer mapping is used.
m=json.loads((R/'examples/DEMO_mapping.json').read_text())
del m['payload']['entries']['99900001'];m['payload']['blocked']['99900001']={'sourceRows':[3],'codes':['FLAG_INVALID']};m['payload']['summary'].update(validKeys=6,blockedKeys=1)
m['payloadSha256']=hashlib.sha256(json.dumps(m['payload'],ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
fp=Path(tmp.name)/'SYNTHETIC_BLOCKED.json';fp.write_text(json.dumps(m,ensure_ascii=False))
results=[]
def run(file,blocked):
 proc=subprocess.Popen(['node','src/check-member.mjs'],cwd=R,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 sel=selectors.DefaultSelector();sel.register(proc.stdout,selectors.EVENT_READ)
 buf=b'';todo=[(b'Mapping-Nummer',str(file)+'\n'),(b'(INTL01-... oder nur Ziffern):','INTL01-99900001\n')]
 if blocked:todo.append((b'[Enter = ohne Quellenpruefung]:','\n'))
 idx=0;deadline=time.time()+15
 while time.time()<deadline:
  for key,_ in sel.select(.2):
   chunk=key.fileobj.read1(4096)
   if chunk:buf+=chunk
  if idx<len(todo) and todo[idx][0] in buf:
   proc.stdin.write(todo[idx][1].encode());proc.stdin.flush();idx+=1
  if proc.poll() is not None:break
 else:
  proc.kill();raise AssertionError('CLI timeout '+buf.decode(errors='replace'))
 assert proc.returncode==0,buf.decode(errors='replace')
 text=buf.decode();assert 'DIAGNOSE-ZIP:' in text,text
 path=Path(text.split('DIAGNOSE-ZIP: ',1)[1].splitlines()[0]);assert path.exists()
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None
  for line in z.read('SHA256SUMS.txt').decode().splitlines():digest,name=line.split('  ');assert hashlib.sha256(z.read(name)).hexdigest()==digest
  d=z.read('diagnostic.json').decode();assert '99900001' not in d and 'DEMO_Datenbestand' not in d
  assert json.loads(d)['lookupStatus']==('BLOCKED' if blocked else 'FOUND')
 results.append({'case':'blocked old mapping' if blocked else 'valid mapping','status':'PASS','crc':'PASS','hashes':'PASS','privacy':'PASS'})
 path.unlink()
run(R/'examples/DEMO_mapping.json',False)
run(fp,True)
(R/'docs/MEMBERFIX_CLI_TEST_RESULT.json').write_text(json.dumps({'environment':'Linux Node 22.16.0; interactive stdin simulation; Windows CMD not executed','tests':results},indent=2)+'\n')
print(results)

tmp.cleanup()
