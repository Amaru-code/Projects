import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
import {createInterface} from 'node:readline/promises';import {stdin,stdout} from 'node:process';
import Core from '../lib/data-core.cjs';import {readWorkbook} from '../lib/xlsx.mjs';
import {checkMapText,compareSource,safeMemberReport} from '../lib/member-diagnostic.mjs';
import {writeZip} from '../lib/zip.mjs';import {sha256} from '../lib/core.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const rl=createInterface({input:stdin,output:stdout});
const unquote=s=>s.trim().replace(/^"|"$/g,'');
try {
 console.log('\nMCR 0.3.1 - eine MercerID im Bestandsmapping lokal pruefen');
 console.log('KEINE Ticketnummer angeben. Keine Aenderung von Excel/JSON. Kein Versand.');
 const dir=path.join(root,'private_data');
 const files=fs.readdirSync(dir).filter(s=>/^INTL01_mapping_.*\.json$/i.test(s)).sort();
 files.forEach((n,i)=>console.log('['+(i+1)+'] '+n));
 const answer=unquote(await rl.question(files.length===1?'Mapping-Nummer oder .json-Pfad [Enter = einzige Datei]: ':'Mapping-Nummer oder vollstaendiger .json-Pfad: '));
 let filename=answer;
 if(!answer&&files.length===1)filename=path.join(dir,files[0]);
 else if(/^\d+$/.test(answer)){const index=Number(answer)-1;Core.need(index>=0&&index<files.length,'FILE_CHOICE','Unbekannte Dateinummer.');filename=path.join(dir,files[index]);}
 Core.need(/\.json$/i.test(filename)&&fs.statSync(filename).size<=32*1024*1024,'MAP_FILE','Bitte eine Mapping-JSON-Datei waehlen.');
 const key=(await rl.question('MercerID / ClientEEID der Person (INTL01-... oder nur Ziffern): ')).trim();
 const check=checkMapText(fs.readFileSync(filename,'utf8'),key);
 console.log('\nStatus:',check.status);
 if(check.blocked){console.log('Sperrgrund:',check.blocked.codes.join(', '));console.log('Excel-Zeile(n):',check.blocked.sourceRows.join(', '));for(const m of check.blocked.messages)console.log(m);for(const i of check.blocked.issues)console.log('Spalte '+i.column+': '+i.state+' ('+i.code+')');}
 else if(check.status==='FOUND')console.log('Dieser Personenschluessel ist im JSON verwendbar. Ein Member-/Formularproblem waere davon getrennt zu untersuchen.');
 else console.log('Diese Personenkennung steht weder in entries noch blocked des geladenen JSON. Bestand und MercerID pruefen.');
 let source=null,sourceError=null;
 if(check.status==='BLOCKED'){
  console.log('\nOptional: die zu DIESEM JSON gehoerende Original-XLSX lesen, um die betroffene Spalte genau festzustellen.');
  console.log('Nur eine unveraenderte Quelldatei mit passendem SHA256 wird ausgewertet.');
  const xlsx=unquote(await rl.question('Excel-Pfad [Enter = ohne Quellenpruefung]: '));
  if(xlsx)try{
   source=compareSource(check,readWorkbook(xlsx));
   console.log('Quelle stimmt ueberein. Gefundene Zeile(n):',source.sourceRows.join(', '));
   for(const i of source.issues)console.log('Spalte '+i.column+': '+i.state+' ('+i.code+')');
   if(source.rowCount>1)console.log('Mehrere Zeilen mit gleicher ClientEEID: DUPLICATE_ID.');
  }catch(e){sourceError=e.code??'ERROR';console.log('QUELLPRUEFUNG STOP:',sourceError,e.message);}
 }
 const report=JSON.stringify(safeMemberReport(check,source,sourceError),null,2)+'\n';
 const manifest=JSON.stringify({schema:'MCR_DIAGNOSTIC_MANIFEST_V1',payload:[{path:'diagnostic.json',sha256:sha256(report)}],privacy:'Only predefined reason codes and counts; no person identifiers or actual cell values.'},null,2)+'\n';
 const bytes=writeZip([{name:'diagnostic.json',data:report},{name:'manifest.json',data:manifest},{name:'SHA256SUMS.txt',data:sha256(report)+'  diagnostic.json\n'+sha256(manifest)+'  manifest.json\n'}]);
 const out=path.join(root,'diagnostics');fs.mkdirSync(out,{recursive:true});
 const dest=path.join(out,'MCR_MEMBER_CHECK_'+new Date().toISOString().replace(/[:.]/g,'-')+'_UPLOAD.zip');
 fs.writeFileSync(dest,bytes,{flag:'wx',mode:0o600});
 console.log('\nDIAGNOSE-ZIP:',dest);console.log('ZIP-SHA256:',sha256(bytes));
 console.log('Nur dieses ZIP weitergeben. Nicht die XLSX, Mail oder das Bestandsmapping.');
 if(check.status!=='FOUND')console.log('Die Sperre bleibt bestehen. Nicht umgehen, keine fehlenden Werte erraten.');
} catch(e) {console.error('\nSTOP:',e.code??'ERROR',e.message);process.exitCode=1;}
finally {rl.close();}
