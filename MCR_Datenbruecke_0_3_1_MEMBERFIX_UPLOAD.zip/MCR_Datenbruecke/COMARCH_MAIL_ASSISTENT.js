/* MCR Mail-Assistent 0.3.1. Offline MSG parser and supervised member workflow. */
(()=>{
const Core=(()=>{const module={exports:{}};
/* Pure business rules used identically in Node and the console bundle. No I/O. */
(function(root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.MCRBridgeCore = factory();
})(globalThis, function() {
  'use strict';
  const SCHEMA = 'MCR_INTL01_LOOKUP_V1';
  const RULE = 'B=ClientEEID;L=USC;C=DC;D=PP+;E=DB+;order=DC,PP+,DB+';
  function fail(code, message) { throw Object.assign(new Error(message), {code}); }
  function need(ok, code, message) { if (!ok) fail(code, message); }
  const text = v => String(v ?? '').replace(/\u00a0/g, ' ').trim();
  // Logical source role stays Output; the real sheet name is preserved in metadata.
  // Only case and outer whitespace are tolerated; no fuzzy/prefix matching.
  function isOutputSheet(value) {
    return typeof value === 'string' && text(value).toLowerCase() === 'output';
  }
  function id(v) {
    need(typeof v === 'string', 'ID_TYPE', 'Kennungen muessen Zeichenketten sein.');
    const s = text(v);
    need(/^\d{1,15}$/.test(s) && !/^0+$/.test(s), 'ID_INVALID', 'Keine gueltige ClientEEID. Keine Rundung oder automatische Entfernung fuehrender Nullen.');
    return s;
  }
  function selectedMember(value) {
    const s = text(value), matches = [...s.matchAll(/\bINTL01-(\d{1,15})(?![\w.-])/g)];
    need(matches.length === 1, 'MEMBER_NOT_SELECTED', 'Im Member-Feld fehlt eine eindeutige INTL01-Kennung. Den echten Vorschlag auswaehlen, nicht nur einen Namen eintippen.');
    return {clientId: id(matches[0][1]), display: s};
  }
  function flag(v, col) {
    const s = text(v);
    need(s === '0' || s === '1', 'FLAG_INVALID', `${col}: nur 0 oder 1, leer wird nicht zu 0.`);
    return Number(s);
  }
  function description(entry) {
    const usc = text(entry.usc);
    need(/^\d{1,6}(?:[.,]\d{1,6})?$/.test(usc), 'USC_INVALID', 'L: fehlender/ungueltiger USC-Wert.');
    const plans = [['dc','DC'],['ppPlus','PP+'],['dbPlus','DB+']].filter(([key]) => flag(entry[key], key) === 1).map(([,code]) => code);
    need(plans.length > 0, 'NO_PLAN', 'Keines der drei Merkmale ist 1; manuelle Klaerung.');
    return `USC ${usc}/ ${plans.join(';')}`;
  }
  function validateMap(map) {
    need(map && map.schema === SCHEMA, 'MAP_SCHEMA', 'Falsches Mapping-Format. Mit MAPPING_ERSTELLEN.cmd erzeugen.');
    need(/^[a-f0-9]{64}$/.test(map.payloadSha256 ?? ''), 'MAP_HASH', 'Payload-Pruefsumme fehlt.');
    const p = map.payload;
    need(p && p.rule === RULE && ['DEMO','LOCAL_WORKBOOK'].includes(p.mode), 'MAP_RULE', 'Unbekannte Mapping-Regel.');
    need(isOutputSheet(p.source?.sheet) && /^[a-f0-9]{64}$/.test(p.source.sha256 ?? ''), 'MAP_SOURCE', 'Quellbindung fehlt.');
    need(Number.isFinite(Date.parse(p.generatedAt)) && p.source.headerLConfirmed === true, 'MAP_META', 'Zeitstempel oder Spaltenfreigabe fehlt.');
    need(p.entries && typeof p.entries === 'object' && !Array.isArray(p.entries), 'MAP_ENTRIES', 'Eintraege fehlen.');
    need(p.blocked && typeof p.blocked === 'object' && !Array.isArray(p.blocked), 'MAP_BLOCKED', 'Sperrliste fehlt.');
    need(Object.keys(p.entries).length <= 200000, 'MAP_SIZE', 'Zu viele Mapping-Eintraege.');
    for (const [key, e] of Object.entries(p.entries)) {
      id(key);
      need(e && e.clientId === key && !Object.hasOwn(p.blocked, key), 'MAP_KEY', 'Kennung oder Sperrstatus widerspruechlich.');
      need(Number.isInteger(e.sourceRow) && e.sourceRow >= 1, 'MAP_ROW', 'Quellzeile fehlt.');
      need(Array.isArray(e.formulas) && e.formulas.every(c => ['B','C','D','E','L'].includes(c)), 'MAP_FORMULAS', 'Formelmetadaten ungueltig.');
      need(e.description === description(e), 'MAP_DESCRIPTION', 'Beschreibung stimmt nicht mit Merkmalen ueberein.');
    }
    for (const [key, e] of Object.entries(p.blocked)) {
      id(key);need(Array.isArray(e.codes) && e.codes.length > 0, 'MAP_BLOCKED', 'Ungueltiger gesperrter Datensatz.');
    }
    return p;
  }
  // Diagnostics enrich existing fail-closed decisions. No blank=>0 conversion.
  const BLOCK_CODES = Object.freeze(['DUPLICATE_ID','FLAG_INVALID','USC_INVALID','NO_PLAN','CELL_ERROR','INVALID_ROW']);
  const BLOCK_TEXT = Object.freeze({
    DUPLICATE_ID:'Spalte B enthält die Kennung mehrfach. Keine Zeile wird automatisch gewählt.',
    FLAG_INVALID:'Mindestens ein Merkmal in C/D/E ist weder 0 noch 1. Auch eine leere Zelle wird bislang gesperrt.',
    USC_INVALID:'Spalte L enthält keinen gültigen numerischen USC-Wert.',
    NO_PLAN:'C/D/E sind alle 0. Für diese Kombination fehlt eine freigegebene Beschreibung.',
    CELL_ERROR:'Eine relevante Zelle enthält einen Excel-Fehler, einen nicht unterstützten Zelltyp oder eine Formel ohne gespeichertes Ergebnis.',
    INVALID_ROW:'Die Bestandszeile ist nicht verwendbar. Quelle lokal prüfen.'
  });
  function rowIssues(row) {
    const out=[];
    for(const c of ['B','C','D','E','L'])if(row.errors?.[c])out.push({code:'CELL_ERROR',column:c,state:'ERROR_OR_CACHE'});
    for(const c of ['C','D','E'])if(!row.errors?.[c]&&!['0','1'].includes(text(row[c])))out.push({code:'FLAG_INVALID',column:c,state:text(row[c])?'NOT_BINARY':'EMPTY'});
    if(!row.errors?.L&&!/^\d{1,6}(?:[.,]\d{1,6})?$/.test(text(row.L)))out.push({code:'USC_INVALID',column:'L',state:text(row.L)?'NOT_NUMERIC':'EMPTY'});
    if(['C','D','E'].every(c=>!row.errors?.[c]&&text(row[c])==='0'))out.push({code:'NO_PLAN',column:'CDE',state:'ALL_ZERO'});
    return out;
  }
  function blockInfo(map,key) {
    key=id(key);if(!Object.hasOwn(map.payload.blocked,key))return null;
    const raw=map.payload.blocked[key];
    // Never copy arbitrary strings from a JSON file into the upload diagnostic.
    const codes=[...new Set((raw.codes??[]).map(c=>BLOCK_CODES.includes(c)?c:'INVALID_ROW'))];
    const sourceRows=[...new Set((raw.sourceRows??[]).filter(n=>Number.isInteger(n)&&n>=1&&n<=1048576))].sort((a,b)=>a-b);
    const issues=(Array.isArray(raw.issues)?raw.issues:[]).filter(i=>i&&BLOCK_CODES.includes(i.code)&&['B','C','D','E','L','CDE'].includes(i.column)&&['ERROR_OR_CACHE','NOT_BINARY','NOT_NUMERIC','EMPTY','ALL_ZERO'].includes(i.state)).map(i=>({code:i.code,column:i.column,state:i.state}));
    return {codes,sourceRows,issues,messages:codes.map(c=>BLOCK_TEXT[c]),legacyDetails:!issues.length};
  }
  function lookup(map, key) {
    key = id(key);
    const blocking=blockInfo(map,key);
    if(blocking)throw Object.assign(new Error('MercerID im Bestandsmapping gesperrt. '+blocking.codes.join(', ')+': '+blocking.messages.join(' ')),{code:'ID_BLOCKED',blocking});
    need(Object.hasOwn(map.payload.entries, key), 'ID_NOT_FOUND', 'MercerID / ClientEEID nicht in diesem Mapping gefunden. Die Ticketnummer wird dafür nicht verwendet.');
    const e = map.payload.entries[key];
    need(e.description === description(e), 'MAP_DESCRIPTION', 'Beschreibung ungueltig.');
    return e;
  }
  function analyzeMail(value) {
    const s = text(value);
    need(s.length >= 3 && s.length <= 120000, 'MAIL_SIZE', 'Mailtext fehlt/zu lang (maximal 120.000 Zeichen).');
    const emails = [...new Set((s.match(/[A-Z0-9.!#$%&'*+/=?^_`{|}~-]{1,64}@[A-Z0-9.-]{1,253}\.[A-Z]{2,63}/gi) ?? []).map(v => v.toLowerCase()))];
    const hints = [];
    const add = (key, source) => {try {key = id(key);if (!hints.some(h => h.clientId === key && h.source === source)) hints.push({clientId:key,source});} catch {} };
    for (const m of s.matchAll(/\bINTL01-(\d{1,15})(?![\w.-])/g)) add(m[1], 'INTL01-Kennung im Text');
    for (const m of s.matchAll(/\b(?:ClientEEID|Employee\s*ID|EmployeeID\s*Number|Personalnummer|MercerID|Username|Benutzername)\s*[:=#]?\s*(\d{1,15})(?!\d)/gi)) add(m[1], 'Beschriftete Kennung im Text');
    for (const email of emails) {
      const m = email.match(/^(\d{1,15})@intel\.com$/i);
      if (m) add(m[1], 'Numerischer Intel-Login im Text (nur Kandidat)');
    }
    const names = [], lines = s.split(/\r?\n/).map(text);
    const addName = (raw, source) => {
      const v = text(raw).replace(/<[^>]*>/g, '').replace(/\([^)]*@[^)]*\)/g, '').trim();
      if (v.length <= 100 && !/@|https?:|\d/i.test(v) && /^[\p{L}][\p{L}\p{M} .,'’\-]{2,}$/u.test(v) && /\s/.test(v) && !names.some(n=>n.name===v)) names.push({name:v,source});
    };
    lines.forEach((line, i) => {
      const m = line.match(/^(?:Von|From|Absender|Name)\s*:\s*(.+)$/i);
      if (m) addName(m[1], 'Beschriftung');
      if (/^(?:Mit freundlichen Gr[üu](?:ß|ss)en|Viele Gr[üu](?:ß|ss)e|Freundliche Gr[üu](?:ß|ss)e|Best regards|Kind regards|Regards|Best|Cheers|Br|MfG)[,.!]?$/i.test(line)) {
        let j=i+1;while(j<lines.length&&!lines[j])j++;if(lines[j]) addName(lines[j], 'Signatur (nur Kandidat)');
      }
    });
    const warnings = [];
    if (emails.length > 1) warnings.push('MEHRERE_ADRESSEN: Absender, Signatur und Antwortziel unterscheiden.');
    if (/private?\s+(?:e-?mail|address|adresse)|(?:do not|don.t|nicht mehr).{0,70}(?:address|adresse|mail)|k[üu]nftig.{0,60}(?:adresse|mail)|weitere.{0,30}kontakte/i.test(s)) warnings.push('ADRESSHINWEIS: Antwortziel manuell pruefen.');
    if (/forwarded message|weitergeleitete nachricht|urspr[üu]ngliche nachricht|original message|on behalf of|im auftrag/i.test(s)) warnings.push('WEITERLEITUNG: Absender ist nicht zwingend die betroffene Person.');
    if (new Set(hints.map(h=>h.clientId)).size > 1) warnings.push('MEHRERE_KENNUNGEN: Keine automatische Personenzuordnung.');
    return {emails, names, idHints:hints, warnings, characters:s.length, automaticIdentity:false, automaticRecipient:false};
  }
  return Object.freeze({SCHEMA,RULE,need,fail,text,isOutputSheet,id,flag,selectedMember,description,validateMap,lookup,blockInfo,rowIssues,analyzeMail});
});

return module.exports;})();
const Msg=(()=>{const module={exports:{}};
/* Bounded, read-only MSG subset. MS-CFB + MS-OXMSG. No rendering, network or attachments.
 * Supported: top-level IPM.Note, PR_BODY Unicode or String8 with explicit code page.
 * Unsupported bodies (HTML-only/RTF-only/encrypted) fail; never interpret binary as text.
 */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.MCRMsg=factory();})(globalThis,function(){
 'use strict';
 const FREE=0xffffffff,END=0xfffffffe,FATSECT=0xfffffffd,DIFSECT=0xfffffffc;
 const MAX_FILE=32*1024*1024,MAX_TEXT=120000,MAX_STREAM=8*1024*1024;
 function fail(code,message){throw Object.assign(new Error(message),{code});}
 function need(ok,code,message){if(!ok)fail(code,message);}
 function compound(input){
  const b=input instanceof Uint8Array?input:new Uint8Array(input);
  need(b.byteLength>=512&&b.byteLength<=MAX_FILE,'MSG_SIZE','MSG muss zwischen 512 Byte und 32 MiB gross sein.');
  need([0xd0,0xcf,0x11,0xe0,0xa1,0xb1,0x1a,0xe1].every((x,i)=>b[i]===x),'MSG_FORMAT','Keine Outlook-MSG im Compound-File-Format. Die Originaldatei speichern, nicht umbenennen.');
  const h=new DataView(b.buffer,b.byteOffset,b.byteLength),u32=o=>h.getUint32(o,true),u16=o=>h.getUint16(o,true);
  const version=u16(26),shift=u16(30),sector=2**shift;
  need(u16(28)===0xfffe&&((version===3&&shift===9)||(version===4&&shift===12))&&u16(32)===6&&u32(56)===4096,'MSG_HEADER','Nicht unterstuetzter Compound-File-Header.');
  need(b.length%sector===0,'MSG_TRUNCATED','MSG ist abgeschnitten oder hat eine ungueltige Sektorlaenge.');
  const sectors=b.length/sector-1,words=sector/4;
  need(sectors>0,'MSG_TRUNCATED','MSG enthaelt keine Datensektoren.');
  const getSector=n=>{need(Number.isInteger(n)&&n>=0&&n<sectors,'MSG_SECTOR','Ungueltiger MSG-Sektor.');return b.subarray((n+1)*sector,(n+2)*sector);};
  const ints=data=>{const v=new DataView(data.buffer,data.byteOffset,data.byteLength),a=new Uint32Array(data.length/4);for(let i=0;i<a.length;i++)a[i]=v.getUint32(i*4,true);return a;};
  const nfat=u32(44),ndif=u32(72),fatIds=[];
  need(nfat>0&&nfat<=sectors&&ndif<=sectors,'MSG_FAT','Ungueltige FAT-Laenge.');
  for(let o=76;o<512;o+=4){const n=u32(o);if(n!==FREE)fatIds.push(n);}
  let did=u32(68);const difIds=new Set();
  for(let j=0;j<ndif;j++){
   need(!difIds.has(did),'MSG_CYCLE','Zyklische DIFAT-Kette.');difIds.add(did);
   const arr=ints(getSector(did));for(let i=0;i<words-1;i++)if(arr[i]!==FREE)fatIds.push(arr[i]);did=arr[words-1];
  }
  need((ndif===0?(did===END||did===FREE):did===END)&&fatIds.length===nfat&&new Set(fatIds).size===nfat,'MSG_FAT','Widerspruechliche FAT/DIFAT.');
  const fat=new Uint32Array(nfat*words);
  fatIds.forEach((n,i)=>fat.set(ints(getSector(n)),i*words));
  need(fat.length>=sectors,'MSG_FAT','FAT deckt die Datei nicht ab.');
  for(const n of fatIds)need(fat[n]===FATSECT&&!difIds.has(n),'MSG_FAT','FAT-Sektor falsch markiert.');
  for(const n of difIds)need(fat[n]===DIFSECT,'MSG_FAT','DIFAT-Sektor falsch markiert.');
  let totalRead=0;
  function chain(start,size,unit,table,get,limit,max=MAX_STREAM){
   if(size===0){need(start===END||start===FREE,'MSG_CHAIN','Leerer Stream mit ungueltigem Start.');return new Uint8Array(0);}
   need(size===null||(Number.isSafeInteger(size)&&size>=0&&size<=max),'MSG_STREAM_SIZE','MSG-Textstream zu gross.');
   let n=start;const seen=new Set(),parts=[],expected=size===null?null:Math.ceil(size/unit);
   while(n!==END){
    need(n<limit&&n<table.length,'MSG_CHAIN','Abgebrochene Stream-Kette.');
    need(!seen.has(n),'MSG_CYCLE','Zyklische Stream-Kette.');seen.add(n);
    need(seen.size*unit<=max+unit&&(expected===null||seen.size<=expected),'MSG_CHAIN','Stream-Kette laenger als erlaubt.');
    parts.push(get(n));n=table[n];
   }
   need(expected===null||parts.length===expected,'MSG_TRUNCATED','MSG-Stream ist abgeschnitten.');
   const length=size===null?parts.length*unit:size;totalRead+=length;
   need(totalRead<=MAX_FILE*3,'MSG_BUDGET','MSG-Leselimit erreicht.');
   const out=new Uint8Array(length);let at=0;for(const p of parts){const n=Math.min(p.length,length-at);out.set(p.subarray(0,n),at);at+=n;}return out;
  }
  const directory=chain(u32(48),null,sector,fat,getSector,sectors,4*1024*1024);
  need(directory.length>=128,'MSG_DIRECTORY','MSG-Verzeichnis fehlt.');
  const d=new DataView(directory.buffer),count=directory.length/128;
  const entry=index=>{
   need(Number.isInteger(index)&&index>=0&&index<count,'MSG_DIRECTORY','Ungueltiger Verzeichniseintrag.');
   const o=index*128,n=d.getUint16(o+64,true),type=d.getUint8(o+66);
   need(n>=2&&n<=64&&n%2===0,'MSG_DIRECTORY','Ungueltiger Streamname.');
   const name=new TextDecoder('utf-16le',{fatal:true}).decode(directory.subarray(o,o+n-2));
   return {name,type,left:d.getUint32(o+68,true),right:d.getUint32(o+72,true),child:d.getUint32(o+76,true),start:d.getUint32(o+116,true),size:d.getUint32(o+120,true)+d.getUint32(o+124,true)*4294967296};
  };
  const root=entry(0);need(root.type===5,'MSG_DIRECTORY','Root-Storage fehlt.');
  const rootEntries=new Map(),stack=[root.child],seen=new Set();
  while(stack.length){
   const index=stack.pop();if(index===FREE)continue;
   need(index!==0&&!seen.has(index),'MSG_DIRECTORY_CYCLE','Zyklisches MSG-Verzeichnis.');seen.add(index);
   const e=entry(index);need([1,2].includes(e.type),'MSG_DIRECTORY','Ungueltiger Eintrag im Root-Storage.');
   const key=e.name.toUpperCase();need(!rootEntries.has(key),'MSG_DUPLICATE','Doppelte MSG-Eigenschaft.');rootEntries.set(key,e);
   stack.push(e.left,e.right); // Intentionally never follow e.child (attachment/message storage).
  }
  const nmini=u32(64);need(nmini<=sectors,'MSG_MINIFAT','Ungueltige MiniFAT-Laenge.');
  const miniFat=ints(chain(u32(60),nmini*sector,sector,fat,getSector,sectors));
  const miniStream=chain(root.start,root.size,sector,fat,getSector,sectors,MAX_FILE);
  const read=name=>{
   const e=rootEntries.get(name.toUpperCase());if(!e||e.type!==2)return null;
   if(e.size>=4096)return chain(e.start,e.size,sector,fat,getSector,sectors);
   const total=Math.floor(miniStream.length/64);
   return chain(e.start,e.size,64,miniFat,n=>miniStream.subarray(n*64,(n+1)*64),total);
  };
  return {read,has:name=>rootEntries.has(name.toUpperCase()),version,rootStreams:[...rootEntries.values()].filter(e=>e.type===2).length};
 }
 function parseMsg(input){
  const c=compound(input),warnings=[];
  const props=c.read('__properties_version1.0');
  need(props&&props.length>=32&&(props.length-32)%16===0,'MSG_PROPERTIES','MSG-Eigenschaftstabelle fehlt oder ist beschaedigt.');
  const view=new DataView(props.buffer,props.byteOffset,props.byteLength),fixed=new Map();
  for(let i=32;i+16<=props.length;i+=16){const type=view.getUint16(i,true),pid=view.getUint16(i+2,true);if(type===3){need(!fixed.has(pid),'MSG_DUPLICATE','Doppelte feste MSG-Eigenschaft.');fixed.set(pid,view.getUint32(i+8,true));}}
  const page=fixed.get(0x3ffd)??fixed.get(0x3fde),encodings={65001:'utf-8',1250:'windows-1250',1251:'windows-1251',1252:'windows-1252',1253:'windows-1253',1254:'windows-1254',1255:'windows-1255',1256:'windows-1256',1257:'windows-1257',1258:'windows-1258',932:'shift_jis',936:'gbk',949:'euc-kr',950:'big5',20127:'utf-8'};
  const trim=value=>value.replace(/\0+$/g,'').replace(/\r\n?/g,'\n');
  function string(pid,limit=MAX_TEXT){
   const tag=pid.toString(16).padStart(4,'0').toUpperCase(),u=c.read('__substg1.0_'+tag+'001F');let raw,result;
   try{
    if(u!==null){need(u.length%2===0,'MSG_UNICODE','Ungueltige Unicode-Laenge.');result=new TextDecoder('utf-16le',{fatal:true}).decode(u);}
    else if((raw=c.read('__substg1.0_'+tag+'001E'))!==null){
     const ascii=raw.every(x=>x<128);need(ascii||encodings[page],'MSG_CODEPAGE','ANSI-MSG ohne unterstuetzte Zeichensatzangabe. Mailtext manuell als Text uebernehmen.');
     result=new TextDecoder(ascii?'utf-8':encodings[page],{fatal:true}).decode(raw);
    }else return '';
   }catch(e){if(e.code)throw e;fail('MSG_ENCODING','Zeichensatz konnte nicht eindeutig gelesen werden.');}
   result=trim(result);need(!result.includes('\0')&&!result.includes('\ufffd'),'MSG_ENCODING','Ungueltige Zeichen im MSG-Text.');
   need(result.length<=limit,'MSG_TEXT_SIZE','Nachricht/Metadaten zu lang fuer diesen Helfer.');return result;
  }
  const messageClass=string(0x001a,256);
  need(/^IPM\.Note(?:$|\.)/i.test(messageClass),'MSG_CLASS','Keine unterstuetzte E-Mail-MSG (IPM.Note).');
  need(!/SMIME|Secure|Encrypted/i.test(messageClass),'MSG_ENCRYPTED','Geschuetzte/verschluesselte MSG wird nicht automatisch ausgewertet.');
  const body=string(0x1000);
  if(!body.trim()){
   if(c.has('__substg1.0_10090102'))fail('MSG_RTF_ONLY','Nur RTF/komprimierter Inhalt vorhanden. Im Helfer alternativ Mailtext selbst einfuegen oder als UTF-8 .txt auswaehlen.');
   if(c.has('__substg1.0_10130102')||c.has('__substg1.0_1013001F'))fail('MSG_HTML_ONLY','Nur HTML-Inhalt vorhanden. Keine HTML-Ausfuehrung; Mailtext im Helfer manuell uebernehmen.');
   fail('MSG_BODY_MISSING','Kein lesbarer Klartext in der MSG. Mailtext manuell uebernehmen.');
  }
  const senderName=string(0x0c1a,512),senderEmail=string(0x5d01,512)||string(0x0c1f,512),subject=string(0x0037,2048);
  // Do not return attachment names/data, transport headers, entry IDs or body HTML.
  return {format:'MSG',subject,senderName,senderEmail,body,warnings,diagnostic:{cfbVersion:c.version,rootStreams:c.rootStreams,plainText:true,attachmentsRead:false}};
 }
 function parseText(input){
  const b=input instanceof Uint8Array?input:new Uint8Array(input);need(b.length<=512000,'MAIL_SIZE','Textdatei zu gross.');let body;
  try{body=new TextDecoder('utf-8',{fatal:true}).decode(b).replace(/^\ufeff/,'');}catch{fail('TEXT_ENCODING','TXT bitte als UTF-8 speichern.');}
  need(body.trim().length>=3&&body.length<=MAX_TEXT&&!body.includes('\0'),'MAIL_SIZE','Kein gueltiger UTF-8-Mailtext (max. 120.000 Zeichen).');
  return {format:'TXT',subject:'',senderName:'',senderEmail:'',body,warnings:['TXT_OHNE_DATEIHEADER'],diagnostic:{plainText:true,attachmentsRead:false}};
 }
 return Object.freeze({parseMsg,parseText,MAX_FILE,MAX_TEXT});
});

return module.exports;})();
const Person=(()=>{const module={exports:{}};
/* Conservative name hints, not identity or gender inference. All splits need review. */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.MCRPerson=factory();})(globalThis,function(){
 'use strict';
 const clean=v=>String(v??'').normalize('NFC').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();
 const norm=v=>clean(v).toLocaleLowerCase('de-DE').replace(/[.,]/g,'').replace(/\s+/g,' ');
 const reject=/\b(?:gmbh|support|team|service|deutschland|kundendienst|beratung|damen|herren|adresse|anschrift|straße|strasse|street|geburtsdatum|freundlichen|grüßen|grüssen|regards|danke|please|kindly|mitteilen|können|meine|ihre|hier|leaving|intel|mercer)\b/i;
 function plausible(raw){const v=clean(raw);return v.length>=3&&v.length<=100&&!reject.test(v)&&/^[\p{L}\p{M}][\p{L}\p{M} .,'’\-]+$/u.test(v)&&v.split(/\s+/).length>=2&&v.split(/\s+/).length<=7&&!/\b[A-ZÄÖÜ]{1}\.$/.test(v);}
 function split(raw){
  const display=clean(raw).replace(/^(?:(?:Dr|Prof)\.?\s+)+/i,'').replace(/^(?:Herr|Frau|Mr|Ms|Mrs)\.?\s+/i,'');
  let firstName='',lastName='',needsSplit=false;
  if(display.split(',').length===2){[lastName,firstName]=display.split(',').map(clean);}
  else {const tokens=display.split(' ');if(tokens.length===2){[firstName,lastName]=tokens;}else if(tokens.length>2&&/^(?:von|van|de|del|der|den|du|le|la|zu|zur)$/i.test(tokens[1])){firstName=tokens[0];lastName=tokens.slice(1).join(' ');}else needsSplit=true;}
  return {display,firstName,lastName,needsSplit,reviewRequired:true};
 }
 function candidates(mail){
  const names=[],lines=String(mail.body??'').split(/\r?\n/).map(clean);
  const add=(raw,source)=>{
   const v=clean(raw).replace(/<[^>]*>/g,'').replace(/^"|"$/g,'').trim();if(!plausible(v))return;
   let e=names.find(n=>norm(n.name)===norm(v));if(e){if(!e.sources.includes(source))e.sources.push(source);}else names.push({name:v,sources:[source],...split(v)});
  };
  lines.forEach((line,i)=>{
   const m=line.match(/^(?:Name|Kunde|Kundin|Versicherte(?:r)?|Mitarbeiter(?:in)?)\s*:\s*(.+)$/i);if(m)add(m[1],'Beschrifteter Name');
   if(/^(?:hier\s+)?(?:ist\s+)?(?:meine\s+)?(?:vollst[äa]ndige\s+)?(?:adresse|anschrift)\s*:\s*$/i.test(line)){
    let j=i+1;while(j<lines.length&&!lines[j])j++;if(lines[j])add(lines[j],'Adressblock');
   }
   if(/^(?:Mit freundlichen Gr[üu](?:ß|ss)en|Viele Gr[üu](?:ß|ss)e|Freundliche Gr[üu](?:ß|ss)e|Best regards|Kind regards|Regards|Best|Cheers|Br|MfG)[,.!]?$/i.test(line)){
    let j=i+1;while(j<lines.length&&!lines[j])j++;if(lines[j])add(lines[j],'Signatur');
   }
   const from=line.match(/^(?:Von|From|Absender)\s*:\s*(.+)$/i);if(from)add(from[1],'Header im Text (kann weitergeleitet sein)');
  });
  add(mail.senderName,'Absendername der MSG (nicht zwingend Kunde)');
  return names.slice(0,24);
 }
 function query(first,last){
  first=clean(first);last=clean(last);
  if(!first||!last||first.length>80||last.length>100||![first,last].every(x=>/^[\p{L}\p{M}][\p{L}\p{M} .'’\-]*$/u.test(x)))throw Object.assign(new Error('Vorname und Nachname bitte getrennt prüfen. Nur Namen, keine Kennung eingeben.'),{code:'NAME_REQUIRED'});
  return {firstName:first,lastName:last,query:last+' '+first};
 }
 function memberMatches(display,person){
  const prefix=clean(display).split(/\s*\(?INTL01-/)[0].replace(/[\s(]+$/,'');
  return [person.lastName+' '+person.firstName,person.lastName+', '+person.firstName].some(x=>norm(prefix)===norm(x));
 }

 // Explicit identifiers stay separate from contextual candidates. A bare number
 // anywhere in a message is never treated as a customer identifier.
 function identifierHints(mail,explicit,names){
  const out=[];
  const add=(clientId,source,strength)=>{
   if(!/^\d{1,15}$/.test(clientId)||/^0+$/.test(clientId))return;
   const old=out.find(x=>x.clientId===clientId&&x.strength===strength);
   if(!old)out.push({clientId,source,strength});
  };
  for(const h of explicit??[])add(h.clientId,h.source,'EXPLICIT');
  const escape=v=>v.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
  const text=[mail.subject??'',mail.body??''].join('\n').normalize('NFC');
  for(const name of names??[]){
   if(!name.firstName||!name.lastName)continue;
   for(const order of [[name.firstName,name.lastName],[name.lastName,name.firstName]]){
    const pattern=order.map(v=>v.split(/\s+/).map(escape).join('\\s+')).join('\\s*,?\\s+');
    // Include wrapped subject lines, but no dates/phone fragments/email localparts.
    const re=new RegExp('(?:^|[^\\p{L}\\p{M}])'+pattern+'\\s*(?:[,;/]\\s*|\\r?\\n\\s*)([0-9]{7,10})(?![0-9.@/\\-])','gimu');
    for(const m of text.matchAll(re))add(m[1],'Ziffernfolge neben einem Namenshinweis (manuell prüfen)','CONTEXTUAL');
   }
  }
  return out;
 }
 function personId(value){
  const s=clean(value);if(!s)return null;
  const m=s.match(/^(?:INTL01-)?(\d{1,15})$/i);
  if(!m||/^0+$/.test(m[1]))throw Object.assign(new Error('MercerID bitte als Ziffern oder INTL01-Ziffern angeben. Keine Ticket-/Dokumentnummer.'),{code:'PERSON_ID_INVALID'});
  return m[1];
 }
 return Object.freeze({clean,norm,plausible,split,candidates,query,memberMatches,identifierHints,personId});
});

return module.exports;})();
/* Guided single-ticket data assistant. No send/save/categorisation/queue traversal. */
'use strict';
const W=window;let T=W;try{void W.top.document.body;T=W.top;}catch{}
const demo=location.protocol==='file:'||location.href==='about:blank'||['localhost','127.0.0.1','[::1]'].includes(location.hostname);
if(!demo&&location.hostname!=='comarchecm.mercer.com')throw new Error('MCR: Nur im freigegebenen COMARCH-Fenster oder in der lokalen Demo verwenden.');
try{T.MCR_MAIL?.close();W.MCR_MAIL?.close();T.MCR_DATA?.close();W.MCR_DATA?.close();}catch{}
try{if(T.__mcrInspectorTimer)T.clearInterval(T.__mcrInspectorTimer);T.__mcrInspectorTimer=null;if(T.__MCR_CAPTURE_CLICK)T.__MCR_CAPTURE_CLICK=()=>{};T.document.getElementById('__mcr_comarch_inspector')?.remove();}catch{}
const D=T.document,HID='__mcr_mail_assistant_v3';D.getElementById(HID)?.remove();
const host=D.createElement('div');host.id=HID;
Object.assign(host.style,{position:'fixed',top:'12px',right:'12px',zIndex:'2147483647',width:'450px',maxWidth:'96vw'});
const shadow=host.attachShadow({mode:'open'}),style=D.createElement('style');
style.textContent=`:host{font:14px/1.45 'Segoe UI',Arial,sans-serif;color:#172d40}*{box-sizing:border-box}section{background:#fff;border:2px solid #275875;border-radius:12px;box-shadow:0 6px 30px #0005;max-height:94vh;overflow:auto;padding:16px}h2{font-size:19px;margin:0 0 6px}details.step{margin:12px 0;border:1px solid #beced9;border-radius:7px;padding:10px}summary{font-weight:700;cursor:pointer}p{margin:7px 0}.note{font-size:12px;color:#485c6a}label{display:block;margin:8px 0}input,textarea,select,button{font:inherit}input[type=text],select,textarea{width:100%;padding:7px;border:1px solid #91a5b5;border-radius:4px}input[type=file]{max-width:100%;font-size:12px}textarea{min-height:110px}button{padding:8px 11px;margin:4px 5px 4px 0;cursor:pointer;border:1px solid #6c899d;border-radius:5px;background:#edf3f8;color:#15354b}button:disabled{opacity:.5;cursor:not-allowed}.primary{background:#1d5778;color:white}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:12px/1.5 Consolas,monospace;padding:8px;background:#eff4f8;max-height:170px;overflow:auto}.status{padding:10px;border-left:4px solid #23747c;background:#edf7f6;font-weight:600}.error{border-color:#b24033;background:#fff0e9}.result{font:700 20px/1.4 'Segoe UI',Arial,sans-serif;background:#e7f4ef;padding:12px}.row{display:flex;gap:10px}.row>label{flex:1;min-width:0}small{font-size:12px}`;
shadow.append(style);const panel=D.createElement('section');shadow.append(panel);D.body.append(host);
let map=null,mail=null,analysis=null,candidates=[],chosen=null,context=null,waiting=false,member=null,result=null;
let alive=true,caseEpoch=0,mapEpoch=0,lastError=null,lastOutcome=null,proof=null,stable=null,autoCandidate=null,autoAttempted=false;
let waitStarted=0,selectionMode=null,descriptionWritten=false,format=null,fieldAtSearch=null;
let lastBlocking=null,idHints=[],selectionCommitted=false,lookupAttempted=false,lastSelectionState="NOT_STARTED";
const listeners=new Map(),ui={};
function el(tag,text,parent=panel){const n=D.createElement(tag);if(text!==undefined)n.textContent=text;parent.append(n);return n;}
function safe(fn){return async()=>{try{return await fn();}catch(e){error(e);}};}
function btn(text,fn,parent=panel){const n=el('button',text,parent);n.type='button';n.onclick=safe(fn);return n;}
function check(text,parent){const l=el('label',undefined,parent),n=D.createElement('input');n.type='checkbox';l.append(n,D.createTextNode(' '+text));return n;}
function input(label,id,parent){const l=el('label',label,parent),n=el('input',undefined,l);n.type='text';n.id=id;return n;}
function step(title){const n=el('details',undefined,panel);n.className='step';el('summary',title,n);return n;}
function status(text,bad=false){ui.status.textContent=text;ui.status.className='status'+(bad?' error':'');}
function go(n){[ui.s1,ui.s2,ui.s3,ui.s4].forEach((e,i)=>e.open=i===n-1);}
function clearResult(){result=null;descriptionWritten=false;ui.result.textContent='Noch kein Ergebnis.';ui.copy.disabled=true;ui.apply.disabled=true;ui.row.textContent='';}
function invalidate(reason){lastBlocking=null;selectionCommitted=false;lookupAttempted=false;lastSelectionState='NOT_STARTED';waiting=false;proof=null;stable=null;autoCandidate=null;autoAttempted=false;context=null;chosen=null;member=null;selectionMode=null;clearResult();if(reason)status(reason);}
function error(e){
 lastError=/^[A-Z_0-9]+$/.test(e.code??'')?e.code:'ERROR';waiting=false;clearResult();
 status(lastError+': '+(e.message||'Vorgang fehlgeschlagen.'),true);
 if(lastError==='ID_BLOCKED'){
  lastBlocking=e.blocking??null;go(4);ui.result.textContent='Member zugeordnet · Bestandszeile gesperrt';
  ui.row.textContent=[...(lastBlocking?.messages??[]),'Grund: '+(lastBlocking?.codes??[]).join(', '),'Excel-Quellzeile(n): '+(lastBlocking?.sourceRows??[]).join(', '),
   ...(lastBlocking?.issues??[]).map(x=>'Spalte '+x.column+': '+x.state+' ('+x.code+')'),
   lastBlocking?.legacyDetails?'Dieses ältere Mapping speichert keine Spaltendetails. MAPPING_PRUEFEN.cmd zeigt lokal die betroffene Originalzeile.':'Quelle gezielt prüfen. Danach Mapping neu erzeugen, nicht die JSON-Datei von Hand ändern.',
   'Keine automatische Entsperrung. Ticketnummer ändern hilft hier nicht.'].join('\n');
  ui.retry.textContent='Bestand erneut prüfen';
 }else if(lastError==='ID_NOT_FOUND'){
  go(4);ui.result.textContent='Member zugeordnet · nicht im geladenen Bestand';ui.row.textContent=e.message;
 }else if(lastError.startsWith('MEMBER_')||lastError==='SELECTION_REVIEW'){
  go(3);ui.memberInfo.textContent=e.message;
 }
}
function visible(n){try{return n.isConnected&&n.getClientRects().length>0&&n.ownerDocument.defaultView.getComputedStyle(n).visibility!=='hidden'&&n.ownerDocument.defaultView.getComputedStyle(n).display!=='none';}catch{return false;}}
function documents(){const out=[];function walk(doc,depth){if(!doc||depth>5||out.length>=32||out.includes(doc))return;out.push(doc);for(const f of doc.querySelectorAll('iframe,frame'))try{walk(f.contentDocument,depth+1);}catch{}}walk(D,0);return out;}
function memberField(){const all=documents().flatMap(d=>[...d.querySelectorAll('input[id="mainForm:member-value-id"]')]).filter(visible);Core.need(all.length===1,'MEMBER_FIELD','Bitte EIN Ticket öffnen, unten Bearbeiten anklicken und das Member-Feld anzeigen.');Core.need(!all[0].disabled&&!all[0].readOnly,'MEMBER_READONLY','Member-Feld ist noch nicht bearbeitbar.');return all[0];}
function detectedTicket(){
 const found=new Set();
 for(const doc of [D])for(const n of [...doc.querySelectorAll('label,span,td,div,b,strong,p')].slice(0,12000)){
  if(!visible(n))continue;const s=n.textContent?.trim()??'';if(s.length>70)continue;
  let m=s.match(/^Ticket[\s-]*ID\s*:?\s*(\d{4,15})$/i);if(m){found.add(m[1]);continue;}
  if(/^Ticket[\s-]*ID\s*:?$/i.test(s)){
   const next=n.nextElementSibling?.textContent?.trim();if(/^\d{4,15}$/.test(next??''))found.add(next);
   const p=n.parentElement?.textContent?.trim()??'';if(p.length<90&&(m=p.match(/^Ticket[\s-]*ID\s*:?\s*(\d{4,15})$/i)))found.add(m[1]);
  }
 }
 return found.size===1?[...found][0]:null;
}
// The ticket/document anchor protects against switching cases. It is NEVER
// used as the JSON lookup key and never needs to be replaced with a MercerID.
function documentKey(field){
 const scope=field.closest('form')??field.ownerDocument;const ids=new Set();
 for(const a of scope.querySelectorAll('a[href]'))try{
  const u=new URL(a.getAttribute('href'),field.ownerDocument.baseURI);
  if(u.origin!==field.ownerDocument.location.origin||!/(?:^|\/)GetFile\/?$/i.test(u.pathname))continue;
  for(const [k,v] of u.searchParams)if(/^docid$/i.test(k)&&/^\d{1,15}$/.test(v))ids.add(v);
 }catch{}
 return ids.size?[...ids].sort().join('|'):null;
}
function bindContext(){
 const actual=detectedTicket(),field=memberField(),docKey=documentKey(field);
 ui.ticket.value=actual??'nicht automatisch erkannt';
 ui.caseInfo.textContent=actual?'Vorgang erkannt. Diese Nummer wird NICHT im Bestand gesucht.':docKey?'Aktuelles Dokument als Fallgrenze erkannt. Keine Ticketnummer eingeben.':'Fall nur an dieses Formular gebunden. Bei Seitenwechsel oder Formularersetzung neu bestätigen.';
 return {id:actual,detected:!!actual,documentKey:docKey,url:T.location.href,field,mode:actual?'TICKET':docKey?'DOCUMENT':'FORM_ONLY'};
}
function contextOK(){
 Core.need(context&&context.url===T.location.href,'TICKET_CHANGED','Seite gewechselt. Mit Neuer Fall beginnen.');
 const actual=detectedTicket();
 Core.need(context.detected?actual===context.id:!actual,'TICKET_CHANGED','Vorgangskennung hat sich geändert. Neu beginnen.');
 const field=memberField(),key=documentKey(field);
 Core.need(key===context.documentKey,'TICKET_CHANGED','Originaldokumente des Tickets haben sich geändert. Neu beginnen.');
 if(!context.detected&&!context.documentKey)Core.need(field===context.field,'TICKET_REBIND','Ohne verlässliche Fallkennung wurde das Formular ersetzt. Person und Ticket erneut bestätigen.');
 return field;
}
// Distinguish an autocomplete suggestion from the populated MercerID profile.
// Only read short semantic values in the same form, never the mail iframe.
function committedProfile(field){
 const scope=field.closest('form')??field.ownerDocument,ids=new Set();let labelFound=false;
 for(const n of scope.querySelectorAll('label,span,td,div,b,strong')){
  if(!visible(n)||!/^Mercer\s*ID\s*:?$/i.test((n.textContent??'').trim()))continue;
  if(n.closest('[role="listbox"],[role="option"]'))continue;
  labelFound=true;const vals=[];
  if(n.htmlFor){const t=field.ownerDocument.getElementById(n.htmlFor);if(t&&t!==field)vals.push(t.value??t.textContent??'');}
  for(const t of [n.nextElementSibling,n.parentElement,n.parentElement?.nextElementSibling]){
   if(!t||t===field||t.contains(field)||!visible(t))continue;
   const text=(t.textContent??'').trim();if(text.length<=180)vals.push(text);
  }
  for(const text of vals){
   for(const m of text.matchAll(/\bINTL01-(\d{1,15})(?![\w.-])/g))ids.add(m[1]);
   const m=text.trim().match(/^(?:Mercer\s*ID\s*:?\s*)?(\d{4,15})$/i);if(m)ids.add(m[1]);
  }
 }
 return {labelFound,ambiguous:ids.size>1,clientId:ids.size===1?[...ids][0]:null};
}
function expectedId(){return Person.personId(ui.expected.value);}
function checkExpected(selected){
 const expected=expectedId();Core.need(expected===chosen.expectedId,'PERSON_ID_CHANGED','Personenkennung wurde geändert. Identität erneut bestätigen.');
 Core.need(!expected||expected===selected.clientId,'MAIL_MEMBER_CONFLICT','Geprüfte MercerID aus der Mail passt nicht zum ausgewählten COMARCH-Member. Nicht die Ticketnummer umschreiben.');
}
function freezeName(){return Person.query(ui.first.value,ui.last.value);}
function gates(){Core.need(map&&ui.sourceOK.checked,'MAPPING_REVIEW','JSON aus private_data laden und Quellenstand bestätigen.');Core.need(mail&&ui.mailOK.checked,'MAIL_REVIEW','Original-Mail laden und Zuordnung zu diesem Ticket bestätigen.');const p=freezeName();Core.need(chosen&&p.query===chosen.query&&expectedId()===chosen.expectedId,'NAME_CHANGED','Name wurde geändert. Suche neu starten.');return p;}
async function sha(value){Core.need(crypto?.subtle,'CRYPTO_REQUIRED','SHA-256 ist in diesem Browserkontext nicht verfügbar. HTTPS-COMARCH verwenden.');const b=typeof value==='string'?new TextEncoder().encode(value):value;return [...new Uint8Array(await crypto.subtle.digest('SHA-256',b))].map(x=>x.toString(16).padStart(2,'0')).join('');}
el('h2','MCR Mail-Assistent 0.3.1');
el('p','Original-Mail → geprüfter Name → Member → USC / Pläne').className='note';
ui.status=el('p','1 · Deine vorhandene JSON-Datei laden.');ui.status.className='status';
ui.s1=step('1 · Bestand laden (einmal pro Sitzung)');ui.s1.open=true;
el('p','JSON aus private_data auswählen — NICHT die Excel-Datei.',ui.s1);
ui.mapFile=el('input',undefined,ui.s1);ui.mapFile.type='file';ui.mapFile.accept='.json';ui.mapFile.id='mapFile';
ui.mapInfo=el('pre','Noch kein Mapping geladen.',ui.s1);
ui.sourceOK=check('Diese Bestandsversion und Spalte L als USC sind fachlich richtig und aktuell genug.',ui.s1);
ui.s2=step('2 · Original-Mail dieses Tickets laden');
el('p','Im COMARCH-Nachrichtenverlauf die Original-Mail herunterladen und Speichern wählen. Die .msg hier auswählen; Outlook muss nicht geöffnet werden.',ui.s2);
ui.mailFile=el('input',undefined,ui.s2);ui.mailFile.type='file';ui.mailFile.accept='.msg,.txt';ui.mailFile.id='mailFile';
ui.mailInfo=el('pre','Noch keine Mail geladen.',ui.s2);
const alternative=el('details',undefined,ui.s2);el('summary','Alternative: Mailtext selbst einfügen',alternative);
ui.raw=el('textarea',undefined,alternative);ui.raw.setAttribute('aria-label','Alternativer Mailtext');
btn('Diesen Text analysieren',()=>setMail({format:'MANUAL',subject:'',senderName:'',senderEmail:'',body:ui.raw.value,warnings:[],diagnostic:{plainText:true,attachmentsRead:false}}),alternative);
const review=el('details',undefined,ui.s2);el('summary','Gelesenen Text lokal prüfen',review);ui.body=el('pre','Noch kein Text.',review);
ui.s3=step('3 · Name prüfen und Member auswählen');
el('p','Der Name ist ein Vorschlag, kein Identitätsnachweis. Absender und betroffene Person können verschieden sein.',ui.s3).className='note';
const namesLabel=el('label','Namensvorschläge aus der Mail',ui.s3);ui.names=el('select',undefined,namesLabel);ui.names.id='nameCandidates';
const row=el('div',undefined,ui.s3);row.className='row';ui.first=input('Vorname','firstName',row);ui.last=input('Nachname','lastName',row);
btn('Vorname / Nachname tauschen',()=>{[ui.first.value,ui.last.value]=[ui.last.value,ui.first.value];nameChanged();},ui.s3);
ui.expected=input('MercerID / ClientEEID der Person (optional, aus der Mail)','expectedClientId',ui.s3);
ui.expected.placeholder='z. B. INTL01-12345678 oder 12345678';
ui.idInfo=el('pre','Kein Kennungshinweis aus der Mail.',ui.s3);
el('p','Nur die Kennung des tatsächlich ausgewählten COMARCH-Members wird in Excel/JSON gesucht.',ui.s3).className='note';
const technical=el('details',undefined,ui.s3);el('summary','Vorgangsnummer · nur zur Absicherung',technical);
ui.ticket=input('Ticket-ID (nicht MercerID, nur lesen)','ticketId',technical);ui.ticket.readOnly=true;
ui.caseInfo=el('p','Keine Ticketnummer eintippen. Der Assistent bindet den geöffneten Fall separat.',technical);ui.caseInfo.className='note';
ui.mailOK=check('Mail gehört zu diesem Ticket; Vorname, Nachname und ein ggf. angezeigter MercerID-Hinweis sind geprüft. Member-Suche freigeben.',ui.s3);
ui.autoOne=check('Genau einen technisch eindeutig nachgewiesenen Treffer automatisch auswählen. Sonst warte auf meine Auswahl.',ui.s3);ui.autoOne.checked=true;
ui.search=btn('Member suchen',startSearch,ui.s3);ui.search.className='primary';
btn('Suchnamen kopieren',async()=>{const p=freezeName();await navigator.clipboard.writeText(p.query);status('Suchname kopiert: im Member-Feld bei Bedarf selbst einfügen.');},ui.s3);
ui.memberInfo=el('pre','Noch keine Member-Suche gestartet.',ui.s3);
ui.confirm=btn('Meine Member-Auswahl bestätigen → weiter',()=>acceptMember(true),ui.s3);
btn('Suche / Warten stoppen',()=>invalidate('Gestoppt. Kein Versand, kein Speichern.'),ui.s3);
ui.s4=step('4 · Beschreibung übernehmen');
ui.result=el('div','Noch kein Ergebnis.',ui.s4);ui.result.className='result';ui.row=el('pre','',ui.s4);
ui.retry=btn('Bestand erneut prüfen',()=>acceptMember(true),ui.s4);
ui.formulaOK=check('Falls die Quellzeile Formeln enthält: gespeicherte Berechnungswerte geprüft.',ui.s4);
ui.copy=btn('Beschreibung kopieren',async()=>{checkCurrentResult();await navigator.clipboard.writeText(result.description);status('Beschreibung kopiert. Noch kein Ticket gespeichert.');},ui.s4);ui.copy.disabled=true;
ui.apply=btn('Beschreibung in COMARCH einsetzen',applyDescription,ui.s4);ui.apply.disabled=true;
el('p','Kein automatischer Versand, kein „Ticket speichern“. Kategorien, Signatur und Antwort sind weiterhin separat zu prüfen.',ui.s4).className='note';
btn('Neuer Fall',resetCase);btn('Diagnose-ZIP',downloadDiagnostic);btn('Schließen',close);
el('p','Nur im betrieblich freigegebenen Kontext verwenden. Mail und Mapping liegen im Speicher dieser COMARCH-Seite; keine isolierte Datenschutz-Sandbox.',panel).className='note';
async function loadMapText(value){
 const epoch=++mapEpoch;invalidate();map=null;go(1);ui.sourceOK.checked=false;ui.mapInfo.textContent='Mapping wird geprüft …';
 Core.need(value.length<=32*1024*1024,'MAP_SIZE','Mapping zu groß.');const obj=JSON.parse(value);Core.validateMap(obj);
 Core.need(demo||obj.payload.mode!=='DEMO','DEMO_NOT_IN_COMARCH','Demo-Mapping nicht in COMARCH einsetzen.');
 Core.need(await sha(JSON.stringify(obj.payload))===obj.payloadSha256,'MAP_HASH_MISMATCH','Mapping-Prüfsumme stimmt nicht.');Core.need(alive&&mapEpoch===epoch,'CANCELLED','Import ersetzt/geschlossen.');map=obj;
 const p=obj.payload;ui.mapInfo.textContent=[p.mode==='DEMO'?'DEMO · fiktive Daten':'Bestand geladen',p.source.filename,'Blatt: '+p.source.sheet+' | L: '+p.source.headers.L,'Stand: '+(p.source.modifiedAt??'unbekannt'),'Export: '+p.generatedAt,'Gültige Kennungen: '+Object.keys(p.entries).length,'Gesperrte Kennungen: '+Object.keys(p.blocked).length].join('\n');
 lastError=null;status('Mapping geprüft. Quellenstand bestätigen, dann Original-Mail laden.');return {validKeys:Object.keys(p.entries).length};
}
ui.mapFile.onchange=safe(async()=>{const f=ui.mapFile.files?.[0];if(!f)return;const epoch=++mapEpoch;invalidate();map=null;ui.sourceOK.checked=false;Core.need(f.size<=32*1024*1024,'MAP_SIZE','Mapping zu groß.');const text=await f.text();Core.need(alive&&epoch===mapEpoch,'CANCELLED','Import ersetzt/geschlossen.');await loadMapText(text);});
ui.sourceOK.onchange=()=>{invalidate();if(map&&ui.sourceOK.checked){go(2);status('2 · Original-Mail (.msg) auswählen. Dein Mapping bleibt geladen.');}};
function setMail(data){
 ++caseEpoch;invalidate();mail=null;analysis=null;candidates=[];ui.mailOK.checked=false;ui.formulaOK.checked=false;ui.first.value='';ui.last.value='';ui.names.replaceChildren();ui.body.textContent='';ui.mailInfo.textContent='';format=data.format;lastOutcome=null;
 analysis=Core.analyzeMail((data.subject?'Betreff: '+data.subject+'\n':'')+data.body);if(/^(?:WG|FW|FWD)\s*:/i.test(data.subject??''))analysis.warnings.push('WEITERLEITUNG: Absender und betroffene Person getrennt prüfen.');candidates=Person.candidates(data);mail=data;
 idHints=Person.identifierHints(data,analysis.idHints,candidates);const uniqueIds=[...new Set(idHints.map(x=>x.clientId))];
 ui.expected.value=uniqueIds.length===1?uniqueIds[0]:'';
 ui.idInfo.textContent=idHints.length?idHints.map(x=>x.clientId+' — '+(x.strength==='EXPLICIT'?'beschriftete Kennung':'Namensnähe: nur Hinweis, prüfen')).join('\n'):'Kein Kennungshinweis. Die spätere ausgewählte MercerID reicht für den Bestandsabgleich.';
 ui.body.textContent=data.body;
 ui.mailInfo.textContent=['Format: '+data.format,'Betreff: '+(data.subject||'(nicht vorhanden)'),'Absender: '+(data.senderName||'(nicht vorhanden)'),...data.warnings,...analysis.warnings].join('\n');
 el('option','Bitte Namensvorschlag wählen oder unten selbst eingeben',ui.names).value='';
 candidates.forEach((c,i)=>{const o=el('option',c.name+' — '+c.sources.join(', '),ui.names);o.value=String(i);});
 if(candidates.length===1){ui.names.value='0';chooseName(0);}else ui.names.value='';
 const ticket=detectedTicket();ui.ticket.value=ticket??'nicht automatisch erkannt';
 go(3);lastError=null;status(candidates.length===1?'3 · Name und ggf. MercerID-Hinweis prüfen, dann „Member suchen“.':candidates.length?'3 · Mehrere Namenshinweise: richtige Person auswählen.':'3 · Kein eindeutiger Name erkannt. Vorname und Nachname aus dem Text selbst eintragen.');
 return {nameCandidates:candidates.length,idCandidates:new Set(idHints.map(x=>x.clientId)).size};
}
async function loadMailBytes(bytes,extension){
 const epoch=++caseEpoch;invalidate();mail=null;analysis=null;ui.mailOK.checked=false;ui.mailInfo.textContent='Original-Mail wird lokal gelesen …';
 Core.need(alive,'CLOSED','Helfer ist geschlossen.');
 const item=extension.toLowerCase()==='.msg'?Msg.parseMsg(bytes):extension.toLowerCase()==='.txt'?Msg.parseText(bytes):Core.fail('MAIL_FORMAT','Bitte die Original-.msg oder UTF-8-.txt verwenden. .eml ist hier noch nicht unterstützt.');
 Core.need(alive&&epoch===caseEpoch,'CANCELLED','Mailimport ersetzt.');return setMail(item);
}
ui.mailFile.onchange=safe(async()=>{const f=ui.mailFile.files?.[0];if(!f)return;const epoch=++caseEpoch;invalidate();mail=null;analysis=null;ui.mailOK.checked=false;Core.need(f.size<=Msg.MAX_FILE,'MSG_SIZE','Maildatei zu groß (32 MiB).');const bytes=await f.arrayBuffer();Core.need(alive&&epoch===caseEpoch,'CANCELLED','Mailimport durch anderen Fall ersetzt.');await loadMailBytes(bytes,(/\.[^.]+$/.exec(f.name)??[''])[0]);});
function chooseName(i){const c=candidates[i];if(!c)return;ui.first.value=c.firstName;ui.last.value=c.lastName;nameChanged();if(c.needsSplit)status('Mehrteiliger Name: Vorname und vollständigen Nachnamen bitte selbst zuordnen.');}
ui.names.onchange=()=>{if(ui.names.value!=='')chooseName(Number(ui.names.value));};
function nameChanged(){invalidate();ui.mailOK.checked=false;}
ui.first.oninput=nameChanged;ui.last.oninput=nameChanged;ui.expected.oninput=nameChanged;ui.mailOK.onchange=()=>{if(!ui.mailOK.checked)invalidate();};
function setNativeValue(field,value){const owner=field.ownerDocument.defaultView;const p=field.tagName==='TEXTAREA'?owner.HTMLTextAreaElement.prototype:owner.HTMLInputElement.prototype;Object.getOwnPropertyDescriptor(p,'value').set.call(field,value);field.dispatchEvent(new owner.Event('input',{bubbles:true}));field.dispatchEvent(new owner.Event('change',{bubbles:true}));}
function startSearch(){
 invalidate();chosen={...freezeName(),expectedId:expectedId()};gates();context=bindContext();const f=memberField();
 Core.need(!/INTL01-\d/.test(f.value),'MEMBER_EXISTS','Ein Member ist bereits gesetzt. Richtigkeit prüfen und „Meine Member-Auswahl bestätigen → weiter“ benutzen; nichts automatisch überschreiben.');
 fieldAtSearch=f;waiting=true;waitStarted=Date.now();lastError=null;lastSelectionState='WAITING_FOR_CHOICE';autoAttempted=false;ui.memberInfo.textContent='Suche: '+chosen.query+'\nTrefferliste in COMARCH abwarten. Bei mehreren Treffern selbst anklicken.';
 f.focus();setNativeValue(f,chosen.query);f.dispatchEvent(new f.ownerDocument.defaultView.KeyboardEvent('keyup',{key:'Unidentified',bubbles:true}));
 status('Warte auf COMARCH-Treffer. Falls keine Liste erscheint: im Member-Feld ein Zeichen löschen und neu tippen. Kein Enter auf Senden.');
}
function observeChoice(event){
 if(!waiting||!event.isTrusted||!chosen)return;
 if(event.composedPath().includes(host))return;
 let n=event.target;for(let i=0;n&&i<6;i++,n=n.parentElement){
  if(n.nodeType!==1||['BODY','HTML','FORM'].includes(n.tagName))break;
  const text=n.innerText??n.textContent??'';if(text.length>300)continue;
  try{const selected=Core.selectedMember(text);if(Person.memberMatches(text,chosen)){proof={id:selected.clientId,until:Date.now()+10000,mode:'USER_CLICK'};return;}}catch{}
 }
}
function strictSingle(f){
 if(!ui.autoOne.checked||autoAttempted||context?.mode==='FORM_ONLY')return null;
 const refs=(f.getAttribute('aria-controls')||f.getAttribute('aria-owns')||'').trim().split(/\s+/).filter(Boolean);if(refs.length!==1)return null;
 const list=f.ownerDocument.getElementById(refs[0]);if(!list||!visible(list)||list.getAttribute('role')!=='listbox'||list.getAttribute('aria-busy')!=='false')return null;
 const options=[...list.querySelectorAll('[role="option"]')].filter(visible);if(options.length!==1)return null;
 const o=options[0];if(o.getAttribute('aria-setsize')!=='1'||o.getAttribute('aria-posinset')!=='1'||o.getAttribute('aria-disabled')==='true')return null;
 const text=o.innerText??'';if(text.length>300||!Person.memberMatches(text,chosen))return null;
 try{const s=Core.selectedMember(text);if(chosen.expectedId&&chosen.expectedId!==s.clientId)return null;const ids=[...new Set(analysis.idHints.map(x=>x.clientId))];if(ids.length>1||(ids.length===1&&ids[0]!==s.clientId))return null;Core.lookup(map,s.clientId);return {element:o,id:s.clientId,text};}catch{return null;}
}
function tick(){
 if(!alive)return;
 for(const doc of documents())if(!listeners.has(doc)){doc.addEventListener('pointerdown',observeChoice,true);listeners.set(doc,true);}
 if(result){try{checkCurrentResult();}catch(e){error(e);}return;}
 if(!waiting)return;
 try{
  gates();const f=contextOK();
  if(Date.now()-waitStarted>120000){waiting=false;status('Warten pausiert. Person auswählen und mit „Meine Member-Auswahl bestätigen → weiter“ fortfahren.');return;}
  let value=null;try{value=Core.selectedMember(f.value);}catch{}
  if(value){
   if(!Person.memberMatches(value.display,chosen)){error(Object.assign(new Error('Ausgewählter Name passt nicht zum bestätigten Suchnamen. Vorname/Nachname und Person prüfen.'),{code:'MEMBER_NAME_CONFLICT'}));return;}
   checkExpected(value);const profile=committedProfile(f);
   Core.need(!profile.ambiguous,'MEMBER_PROFILE_AMBIGUOUS','MercerID-Stammdaten sind nicht eindeutig. Nicht automatisch fortfahren.');
   if(profile.clientId)Core.need(profile.clientId===value.clientId,'MEMBER_PROFILE_CONFLICT','Member-Feld und MercerID-Stammdaten widersprechen sich. COMARCH-Verarbeitung abwarten.');
   ui.memberInfo.textContent='Member-Feld: '+value.display;
   if(profile.labelFound&&!profile.clientId){stable=null;lastSelectionState='WAITING_FOR_COMMIT';status('Vorschlag gefunden, aber noch nicht übernommen. Den echten Vorschlag anklicken; MercerID-Stammdaten sind noch leer.');return;}
   if(!stable||stable.value!==f.value)stable={value:f.value,since:Date.now()};
   lastSelectionState='MEMBER_VALUE_READY';
   if(Date.now()-stable.since>=900&&proof?.id===value.clientId&&proof.until>Date.now()&&(context.detected||context.documentKey))acceptMember(false);
   else status('Member erkannt. Falls es nicht automatisch weitergeht: „Meine Member-Auswahl bestätigen → weiter“.');
   return;
  }
  stable=null;const one=strictSingle(f);
  if(!one){autoCandidate=null;lastSelectionState='WAITING_FOR_USER_OR_UNQUALIFIED_LIST';ui.memberInfo.textContent='Suchname eingetragen. Der Vorschlag ist noch NICHT ausgewählt. Bei mehreren Treffern oder einer nicht eindeutig lesbaren Liste: richtigen Vorschlag in COMARCH anklicken, danach bei Bedarf Auswahl bestätigen.';return;}
  if(!autoCandidate||autoCandidate.element!==one.element||autoCandidate.text!==one.text){autoCandidate={...one,since:Date.now()};return;}
  if(Date.now()-autoCandidate.since>=1500){
   // Only an explicitly linked widget declaring the complete result size 1 may be clicked.
   gates();contextOK();autoAttempted=true;proof={id:one.id,until:Date.now()+10000,mode:'LINKED_SINGLE'};one.element.click();
  }
 }catch(e){error(e);}
}
function acceptMember(explicit){
 if(explicit&&!chosen){chosen={...freezeName(),expectedId:expectedId()};gates();context=bindContext();}
 gates();const f=contextOK(),s=Core.selectedMember(f.value);checkExpected(s);
 const profile=committedProfile(f);Core.need(!profile.ambiguous,'MEMBER_PROFILE_AMBIGUOUS','MercerID-Stammdaten nicht eindeutig.');
 Core.need(!profile.labelFound||profile.clientId,'MEMBER_COMMIT_PENDING','Vorschlag noch nicht übernommen: In COMARCH den Treffer anklicken und warten, bis MercerID/Vorname/Nachname ausgefüllt sind.');
 Core.need(!profile.clientId||profile.clientId===s.clientId,'MEMBER_PROFILE_CONFLICT','Member-Feld und MercerID-Stammdaten widersprechen sich.');
 Core.need(Person.memberMatches(s.display,chosen),'MEMBER_NAME_CONFLICT','COMARCH-Member stimmt nicht mit geprüftem Vor-/Nachnamen überein. Namen prüfen, nicht die Kennung erraten.');
 Core.need(explicit||(proof?.id===s.clientId&&proof.until>Date.now()),'SELECTION_REVIEW','Person aus der tatsächlichen Trefferliste auswählen und bestätigen.');
 const ids=[...new Set(analysis.idHints.map(x=>x.clientId))];Core.need(ids.length<=1,'MAIL_AMBIGUOUS','Mehrere Personenkennungen in der Mail. Dieser Fall braucht manuelle Klärung.');Core.need(!ids.length||ids[0]===s.clientId,'MAIL_MEMBER_CONFLICT','Mail-Kennung und ausgewählter Member widersprechen sich.');
 member={...s,element:f};waiting=false;selectionMode=explicit?'USER_CONFIRMATION':proof.mode;selectionCommitted=true;lastSelectionState='MEMBER_CONFIRMED';
 lookupAttempted=true;lastBlocking=null;go(4);const entry=Core.lookup(map,s.clientId);
 if(entry.formulas.length&&!ui.formulaOK.checked){status('Quellzeile enthält Formeln. Gespeicherte Werte prüfen und unten bestätigen.');ui.row.textContent='Quellzeile '+entry.sourceRow+' | Formeln in '+entry.formulas.join(', ');return null;}
 result={...entry,description:Core.description(entry),ticket:context.id,memberDisplay:s.display};ui.result.textContent=result.description;
 ui.row.textContent=['ClientEEID: '+s.clientId,'Excel-Zeile: '+entry.sourceRow,'L / USC: '+entry.usc,'C / DC: '+entry.dc+' | D / PP+: '+entry.ppPlus+' | E / DB+: '+entry.dbPlus].join('\n');
 ui.copy.disabled=false;ui.apply.disabled=false;lastError=null;lastOutcome='LOOKUP_READY';status('4 · Beschreibung bereit. Nur auf deinen Klick wird sie in COMARCH eingesetzt. Noch kein Versand oder Speichern.');return {sourceRow:entry.sourceRow,description:result.description};
}
ui.formulaOK.onchange=safe(()=>{if(member&&ui.formulaOK.checked)return acceptMember(true);clearResult();});
function checkCurrentResult(){Core.need(result&&member,'RESULT_REQUIRED','Zuerst den Member bestätigen und Bestandsabgleich durchführen.');gates();const f=contextOK();Core.need(f===member.element&&f.value===result.memberDisplay,'MEMBER_CHANGED','Member oder Formular wurde nach dem Lookup geändert. Neu bestätigen.');Core.need(!result.formulas.length||ui.formulaOK.checked,'FORMULA_CACHE_REVIEW','Gespeicherte Formelwerte nicht bestätigt.');return f;}
function descriptionField(){
 const found=new Set();
 for(const doc of documents()){
  for(const l of doc.querySelectorAll('label'))if(/^Zusätzliche Beschreibung\s*:?$/i.test(l.textContent.trim())&&l.htmlFor){const n=doc.getElementById(l.htmlFor);if(n?.tagName==='TEXTAREA'&&visible(n))found.add(n);}
  const candidate=doc.getElementById('mainForm:j_id7019');
  if(candidate?.tagName==='TEXTAREA'&&visible(candidate)){
   // Observed dynamic ID is accepted only with a nearby semantic label, never alone.
   const p=candidate.parentElement;let text=p?.textContent??'';if(text.length<500&&/Zusätzliche Beschreibung/i.test(text))found.add(candidate);
   const prev=candidate.previousElementSibling;if(prev&&/^Zusätzliche Beschreibung\s*:?$/i.test(prev.textContent.trim()))found.add(candidate);
  }
 }
 Core.need(found.size===1,'DESCRIPTION_FIELD','Beschreibungsfeld nicht eindeutig gebunden. „Beschreibung kopieren“ verwenden und selbst einsetzen.');return [...found][0];
}
function applyDescription(){
 checkCurrentResult();const f=descriptionField();Core.need(!f.disabled&&!f.readOnly,'DESCRIPTION_READONLY','Beschreibungsfeld nicht bearbeitbar.');
 Core.need(!f.value.trim()||f.value===result.description,'DESCRIPTION_EXISTS','Vorhandene Beschreibung wird nicht überschrieben. Bitte manuell prüfen.');
 setNativeValue(f,result.description);Core.need(f.value===result.description,'DESCRIPTION_VERIFY','Einsetzen konnte nicht geprüft werden.');descriptionWritten=true;lastOutcome='DESCRIPTION_INSERTED';status('Beschreibung eingesetzt. Noch NICHT gespeichert, keine Antwort versendet. Restlichen Ticketablauf selbst abschließen.');
}
function resetCase(){++caseEpoch;invalidate();mail=null;analysis=null;candidates=[];ui.mailFile.value='';ui.raw.value='';ui.body.textContent='Noch kein Text.';ui.mailInfo.textContent='Noch keine Mail geladen.';ui.names.replaceChildren();ui.first.value='';ui.last.value='';ui.expected.value='';idHints=[];ui.idInfo.textContent='Kein Kennungshinweis aus der Mail.';ui.ticket.value='';ui.mailOK.checked=false;ui.formulaOK.checked=false;ui.memberInfo.textContent='Noch keine Member-Suche gestartet.';lastError=null;lastOutcome=null;format=null;go(map&&ui.sourceOK.checked?2:1);status('Neuer Fall. Mapping bleibt geladen. Jetzt die Original-Mail des nächsten Tickets auswählen.');}
function diagnostic(){
 let widget={fieldPresent:false,linkedList:false,declaredCompleteSingle:false,profileLabelFound:false,profileIdPresent:false};
 try{const f=memberField(),p=committedProfile(f);widget={fieldPresent:true,linkedList:!!(f.getAttribute('aria-controls')||f.getAttribute('aria-owns')),declaredCompleteSingle:!!strictSingle(f),profileLabelFound:p.labelFound,profileIdPresent:!!p.clientId};}catch{}
 return {schema:'MCR_MAIL_DIAGNOSTIC_V1',version:'0.3.1',createdAt:new Date().toISOString(),
 capabilities:{readsMsg:true,networkUpload:false,automaticSend:false,automaticSave:false,confirmedMemberSearch:true,confirmedDescriptionInsert:true},
 mapping:{loaded:!!map,sourceConfirmed:ui.sourceOK.checked,selectedKeyBlocked:!!lastBlocking,blockedCodes:lastBlocking?.codes??[],blockedIssues:lastBlocking?.issues??[],blockedSourceRowCount:lastBlocking?.sourceRows.length??0},
 mail:{format,nameCandidates:candidates.length,idCandidates:new Set(idHints.map(x=>x.clientId)).size,explicitIdCandidates:analysis?.idHints.length??0,plainText:!!mail},
 flow:{waiting,selectionMode,selectionCommitted,lastSelectionState,ticketAutoBound:context?.detected??false,caseBinding:context?.mode??null,lookupAttempted,lookupKeySource:lookupAttempted?'SELECTED_MEMBER':null,lookupReady:!!result,descriptionWritten,lastOutcome},widget,lastError};
}
function crc32(bytes){let c=0xffffffff;for(const b of bytes){c^=b;for(let k=0;k<8;k++)c=(c&1)?0xedb88320^(c>>>1):c>>>1;}return(c^0xffffffff)>>>0;}
function storeZip(files){
 let offset=0;const local=[],central=[],enc=new TextEncoder();
 const concat=parts=>{const all=new Uint8Array(parts.reduce((n,p)=>n+p.length,0));let i=0;for(const p of parts){all.set(p,i);i+=p.length;}return all;};
 for(const [name,text] of files){
  const n=enc.encode(name),data=enc.encode(text),crc=crc32(data),h=new Uint8Array(30),v=new DataView(h.buffer);
  v.setUint32(0,0x04034b50,true);v.setUint16(4,20,true);v.setUint16(6,0x800,true);v.setUint16(12,33,true);v.setUint32(14,crc,true);v.setUint32(18,data.length,true);v.setUint32(22,data.length,true);v.setUint16(26,n.length,true);
  const c=new Uint8Array(46),cv=new DataView(c.buffer);cv.setUint32(0,0x02014b50,true);cv.setUint16(4,20,true);cv.setUint16(6,20,true);cv.setUint16(8,0x800,true);cv.setUint16(14,33,true);cv.setUint32(16,crc,true);cv.setUint32(20,data.length,true);cv.setUint32(24,data.length,true);cv.setUint16(28,n.length,true);cv.setUint32(42,offset,true);
  local.push(h,n,data);central.push(c,n);offset+=h.length+n.length+data.length;
 }
 const cd=concat(central),end=new Uint8Array(22),ev=new DataView(end.buffer);ev.setUint32(0,0x06054b50,true);ev.setUint16(8,files.length,true);ev.setUint16(10,files.length,true);ev.setUint32(12,cd.length,true);ev.setUint32(16,offset,true);
 return concat([...local,cd,end]);
}

async function diagnosticBytes(){
 const report=JSON.stringify(diagnostic(),null,2)+'\n',hash=await sha(report);
 const manifest=JSON.stringify({schema:'MCR_DIAGNOSTIC_MANIFEST_V1',payload:[{path:'diagnostic.json',sha256:hash}],privacy:'No mail bytes/text, names, identifiers, filenames, addresses, URLs, cookies, mapping values or document HTML.'},null,2)+'\n';
 return storeZip([['diagnostic.json',report],['manifest.json',manifest],['SHA256SUMS.txt',hash+'  diagnostic.json\n'+await sha(manifest)+'  manifest.json\n']]);
}
async function downloadDiagnostic(){const bytes=await diagnosticBytes(),hash=await sha(bytes),url=URL.createObjectURL(new Blob([bytes],{type:'application/zip'})),a=D.createElement('a');a.href=url;a.download='MCR_MAIL_'+new Date().toISOString().replace(/[:.]/g,'-')+'_UPLOAD.zip';a.click();setTimeout(()=>URL.revokeObjectURL(url),20000);status('Diagnose-ZIP erstellt (ohne Mail/Mapping). ZIP-SHA256: '+hash);}
function close(){alive=false;++caseEpoch;++mapEpoch;clearInterval(timer);for(const doc of listeners.keys())doc.removeEventListener('pointerdown',observeChoice,true);listeners.clear();map=null;mail=null;analysis=null;candidates=[];member=null;result=null;proof=null;chosen=null;context=null;ui.raw.value='';ui.body.textContent='';ui.first.value='';ui.last.value='';ui.expected.value='';idHints=[];lastBlocking=null;host.remove();if(T.MCR_MAIL===api)delete T.MCR_MAIL;if(W.MCR_MAIL===api)delete W.MCR_MAIL;}
const timer=setInterval(tick,350);
const api=Object.freeze({version:'0.3.1',loadMapText,loadMailBytes,setMail,startSearch,acceptMember,resetCase,diagnostic,diagnosticBytes,close});
T.MCR_MAIL=api;W.MCR_MAIL=api;
console.info('MCR Mail-Assistent 0.3.1 aktiv. Keine Mail-/Personenwerte in der Konsole. Kein Versand, kein Ticket-Speichern.');

})();
