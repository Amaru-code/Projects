# MCR Mail-Assistent 0.3.1 — MercerID, Auswahlstatus und Bestandsdiagnose

## Was dieses Update behebt

Die 0.3.0-Diagnose `ID_BLOCKED` entsteht im Bestands-Lookup, wenn die **im Member-Feld gelesene ClientEEID** bereits in `payload.blocked` des JSONs steht. Sie wird **nicht** durch die Ticketnummer ausgelöst. Die bisherige Diagnose enthielt den Untercode nicht. Deshalb konnte man aus dem Upload nicht unterscheiden, ob zum Beispiel eine leere Merkmalszelle, ein fehlender USC oder eine doppelte Kennung vorliegt.

0.3.1 trennt diese Dinge sichtbar:

* **Ticket-ID:** Vorgangsnummer zur Fallabsicherung, jetzt nur lesbar in einem eingeklappten Technikbereich. Keine Nummer mehr von Hand eingeben.
* **MercerID / ClientEEID:** optionaler, ausdrücklich zu prüfender Hinweis aus der Mail, mit oder ohne `INTL01-`. Der tatsächliche JSON-Schlüssel kommt weiterhin ausschließlich aus dem ausgewählten COMARCH-Member.
* **Vorschlag und Auswahl:** ein gefundener Vorschlag gilt nicht schon als übernommene Person. Ist das eigentliche MercerID-Stammdatenfeld noch leer, stoppt der Bestandsabgleich.
* **Gesperrte Bestandszeile:** Schritt 4 zeigt Grund und Quellzeile; das Diagnose-ZIP enthält nur fest definierte Fehlercodes und Anzahlen, keine Personenwerte.

**Keine Fachregel wurde gelockert.** Leere Flags werden weiterhin nicht zu 0 umgedeutet. Bei `ID_BLOCKED` ist zunächst zu klären, ob die Quelle wirklich fehlerhaft ist oder ob eine bisher nicht freigegebene Darstellung (zum Beispiel leere Zellen als „nein“) in dieser Datei fachlich zulässig ist.

## Aktualisieren

Das ZIP vollständig entpacken. Den Ordner **MCR_Datenbruecke** mit dem bisherigen gleichnamigen Ordner zusammenführen, gelieferte Paketdateien ersetzen. Den alten Ordner **nicht** vorher löschen. Das vorhandene JSON in `private_data`, lokale Runtime-Verzeichnisse und die Excel-Datei behalten.

Das bisherige JSON bleibt lesbar. Für die Diagnose muss es nicht erst neu exportiert werden. Bei einem späteren Export ergänzt 0.3.1 Informationen zur betroffenen Spalte, ohne die bisherigen Freigabe-/Sperrentscheidungen zu ändern.

Node ab 22.15 wird benötigt. Keine npm-Abhängigkeiten, keine Installation, kein Download. Die bekannten portablen Node-Pfade bleiben erhalten.

## Zuerst die gesperrte Person lokal prüfen

**MAPPING_PRUEFEN.cmd** starten.

1. Das aktuell verwendete Mapping per Dateinummer oder vollständigem `.json`-Pfad auswählen. Bei genau einer Mappingdatei übernimmt Enter diese Datei.
2. Die **MercerID der Person** eingeben, nicht die Ticket- oder Dokumentnummer. Erlaubt: `INTL01-12345678` oder `12345678` (fiktives Formatbeispiel).
3. Falls die Kennung gesperrt ist, wird deren Untercode und Excel-Quellzeile angezeigt.
4. Optional den Pfad der zu diesem JSON gehörenden `.xlsx` eingeben. Der Inhalt wird nur gelesen. Nur bei identischem Quellen-SHA256 werden die zu dieser Kennung gehörenden Zeilen zusätzlich untersucht.
5. Das Programm erzeugt **ein** `diagnostics/MCR_MEMBER_CHECK_..._UPLOAD.zip` und zeigt dessen SHA256 an. Nur dieses ZIP zur Fehlersuche weitergeben, keine Mail/Excel/Mappingdatei.

Das Programm repariert keine Zellen und hebt keine Sperren auf. Bei `SOURCE_CHANGED` stammt die XLSX nicht mehr aus genau dem eingefrorenen JSON-Stand. Nicht alte und neue Bestände vermischen; die beabsichtigte Quelle prüfen und bei Bedarf ein neues Mapping erstellen.

### Mögliche Gründe

| Code | Bedeutung / lokale Prüfung |
|---|---|
| `FLAG_INVALID` | C/D/E enthält etwas anderes als 0 oder 1. `EMPTY` kennzeichnet ausdrücklich eine leere Zelle. Nicht blind durch 0 ersetzen. |
| `USC_INVALID` | L fehlt oder enthält keinen zulässigen numerischen USC. |
| `DUPLICATE_ID` | Die Kennung kommt in B mehrfach vor. Keine willkürliche Zeile auswählen. |
| `NO_PLAN` | C, D, E sind 0. Dafür gibt es noch keine freigegebene Beschreibung. |
| `CELL_ERROR` | Relevanter Excel-Fehler, nicht unterstützter Zelltyp oder fehlender Formelcache. |
| `ID_NOT_FOUND` / `NOT_FOUND` | Die MercerID fehlt in diesem Bestand. Nicht durch eine ähnliche Kennung ersetzen. |

## Den Assistenten im Browser verwenden

Ein Ticket öffnen und dessen Original-Mail herunterladen (**Speichern**, nicht in Outlook weiterleiten). In COMARCH selbst auf **Bearbeiten** gehen. Dies kann bereits echte Ticketdaten/Status verändern.

**MAIL_ASSISTENT_OEFFNEN.cmd** starten. Den gesamten in Notepad geöffneten Code kopieren und in der Edge-DevTools-Konsole der COMARCH-Seite (möglichst Kontext `top`) ausführen. Bei Einfüge-/Unternehmensbeschränkungen keine Schutzrichtlinien umgehen.

Im Panel muss **MCR Mail-Assistent 0.3.1** stehen. Ein erneutes Einsetzen schließt die vorige Panelinstanz; Mapping und Mail danach neu auswählen.

### 1 — Bestand

Vorhandenes JSON aus `private_data` auswählen. Quelle und USC-Spalte fachlich bestätigen. Der Bestand ist ein Snapshot, nicht automatisch der neueste Datenstand.

### 2 — Original-Mail

Gespeicherte `.msg` laden. Der Leser unterstützt gespeicherten Klartext. HTML-/RTF-only, verschlüsselte/geschützte oder abweichende MSG-Varianten sind nicht umfassend unterstützt. Bei fehlendem Klartext gibt es eine ausdrückliche manuelle Texteingabe. Anhänge/Remote-Bilder werden nicht geöffnet.

### 3 — Person und Member

Namensvorschlag wählen und Vorname/Nachname prüfen. Absender, Weiterleitender und betroffene Person können verschieden sein. Geschlecht wird nicht aus dem Namen abgeleitet.

Neu: Auch ein Nummernhinweis neben einem erkannten Namen in Betreff oder Text kann angezeigt werden. Er ist **kein Identitätsnachweis**. Zahlen ohne passenden Kontext (Ticketnummer, Telefon, Datum) werden nicht pauschal als MercerID übernommen. Mehrere widersprüchliche Hinweise führen nicht zur automatischen Personenzuordnung.

Im optionalen Feld **MercerID / ClientEEID der Person** darf die bekannte Personenkennung geprüft oder ergänzt werden. Keine Ticketnummer hineinschreiben. Sie wird nach der Auswahl mit dem echten Member verglichen; sie ersetzt dessen Kennung nicht.

Mail-/Namensprüfung bestätigen, **Member suchen** klicken. Der Suchname wird in der Form `Nachname Vorname` eingetragen.

**Ein Treffer ist noch keine Auswahl.** In einer nicht qualifizierten COMARCH-Vorschlagsliste den richtigen Vorschlag anklicken. Bei mehreren Treffern wird niemals automatisch einer gewählt. Wenn das Panel danach nicht automatisch weitergeht: **Meine Member-Auswahl bestätigen → weiter**.

Soweit die semantisch beschrifteten Stammdaten auslesbar sind, muss dort eine ausgefüllte MercerID passend zum Member stehen. Ein formatiertes Suchfeld bei noch leerem MercerID-Profil genügt nicht.

Automatisches Anklicken bleibt auf eindeutig verknüpfte Listen beschränkt, die eine vollständig geladene Gesamtzahl von genau 1 ausweisen, einen passenden Namen und die richtige Kennung enthalten und zu einem gebundenen Vorgang gehören. **Die echte COMARCH-Trefferliste ist weiterhin nicht qualifiziert.** Bei der bisherigen Alt-Oberfläche ist daher ggf. weiterhin ein eigener Klick erforderlich.

Fehlt eine auslesbare Ticketnummer, versucht der Helfer die Originaldokument-Verknüpfungen als Fallgrenze zu verwenden. Fehlt auch das, gibt es nur einen engen formulargebundenen, manuell bestätigten Pfad. Eine Formularersetzung verlangt dann eine neue Bestätigung; automatische Auswahl wird in diesem schwachen Fall nicht ausgeführt.

### 4 — Beschreibung oder konkreter Grund

Der Schlüssel wird ausschließlich aus dem ausgewählten Member gelesen. Verwendet werden weiterhin B → ClientEEID, L → USC, C → DC, D → PP+, E → DB+. Beispiel mit fiktiven Daten: `USC 10/ PP+`.

Bei einem gesperrten Datensatz öffnet sich Schritt 4 mit Sperrgrund und Excel-Quellzeile statt nur „Noch kein Ergebnis“. **MAPPING_PRUEFEN.cmd** kann für ein älteres JSON die genaue Spalte anhand der identischen Original-XLSX feststellen.

Bei gültigen Daten kann die Beschreibung kopiert oder auf ausdrücklichen Klick in das eindeutig erkannte COMARCH-Feld eingesetzt werden. Vorhandener abweichender Text wird nicht überschrieben. Formelzeilen brauchen weiterhin eine gesonderte Bestätigung der gespeicherten Berechnungswerte.

**Kein automatischer Versand, kein Ticket-Speichern, keine Kategorien/Signatur/Antwortautomatik.** Diese Schritte bleiben manuell.

Vor dem nächsten Ticket **Neuer Fall** wählen. Mapping bleibt in derselben Seitensitzung geladen, Mail/Name/Auswahl/Ergebnis werden verworfen. Nach Navigation kann erneutes Einsetzen nötig sein.

## Dateien

| Datei | Zweck |
|---|---|
| `MAPPING_PRUEFEN.cmd` | Neues lokales Prüfprogramm für eine MercerID; erzeugt ein Diagnose-ZIP. |
| `MAIL_ASSISTENT_OEFFNEN.cmd` / `KONSOLE_OEFFNEN.cmd` | Aktuellen Konsolenhelfer in Notepad öffnen. |
| `MAIL_DEMO_STARTEN.cmd` | Fiktive interaktive Demo, keine echte COMARCH-Verbindung. |
| `MAPPING_ERSTELLEN.cmd` | XLSX → neuer Snapshot, falls Quelle neu/angepasst ist. |
| `SELBSTTEST.cmd` | Paketprüfung und Node-Tests. |
| `ALTES_PANEL_OEFFNEN.cmd` | Alter Datenbrücken-Helfer bleibt für Kompatibilität vorhanden. |

## Sicherheit, Grenzen, Tests

Mail und Mapping liegen im Speicher des COMARCH-Seitenkontexts; dies ist **keine isolierte Datenschutz-Sandbox**. Nur betrieblich freigegeben verwenden. Kein Upload an externe KI-Dienste; normale COMARCH-Feldereignisse können dessen Serveranfragen auslösen. Mail, XLSX und Mapping nicht in Git oder Chats übertragen.

Integritätshashes erkennen Abweichungen, sind aber keine Signatur oder automatische Vertrauensfreigabe. Ein vollständiges neu gehashtes JSON aus unbekannter Quelle bleibt unbekannter Herkunft.

Tests/Umgebung und verbleibende Grenzen stehen in `docs/MEMBERFIX_TESTBERICHT.md`. Historische Berichte zu 0.2.x/0.3.0 bleiben als solche erhalten; sie sind keine zusätzliche Live-Freigabe. Echte Windows-/Edge-/COMARCH-Ausführung und das persönliche Bestandsmapping wurden hier nicht geprüft.
