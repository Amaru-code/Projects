import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';
import {ROOT} from './helpers.mjs';import {sha256} from '../lib/core.mjs';
import {VERSION} from '../lib/control.mjs';
import {COMARCH_NOT_FOUND_DESCRIPTION} from '../lib/comarch-missing-member.mjs';
test('RC32 pinned previous original RC31 complete software manifest, update-only',()=>{
 assert.equal(VERSION,'0.8.1-rc.53');
 const p=path.join(ROOT,'tools/reference/complete-0.8.1-rc.31-manifest.json');
 assert.equal(JSON.parse(fs.readFileSync(p,'utf8')).version,'0.8.1-rc.31');
 assert.equal(sha256(fs.readFileSync(p)),'cdc9f8ec15623e37d6b253f0c41d90b513d54c74e34172b6cb44d19c869baa64');
});
test('RC32 no-COMARCH-Member path has distinct description, cannot send with missing member',()=>{
 const source=fs.readFileSync(path.join(ROOT,'src/local-bot-full-run.mjs'),'utf8');
 assert.equal(COMARCH_NOT_FOUND_DESCRIPTION,'Person nicht in COMARCH gefunden');
 assert.match(source,/if\(selection\.comarchNotFound\)/);
 assert.match(source,/description:COMARCH_NOT_FOUND_DESCRIPTION/);
 assert.match(source,/if\(reason==='NOT_IN_COMARCH'\)/);
 assert.match(source,/need\(!recheck,'COMARCH_MEMBER_NOW_SELECTED'/);
 assert.match(source,/journal\.beginForward\(row\.ticketId,description\)/);
 assert.match(source,/const resolved=resolveMemberMapping\(mapping\.map,member\.id\)/);
});
