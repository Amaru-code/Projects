import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';
import {ROOT} from './helpers.mjs';import {VERSION} from '../lib/control.mjs';import {sha256} from '../lib/core.mjs';
import {verifyPrevious} from '../tools/integrity.mjs';
test('RC34 previous RC33 intact and pinned for safe upgrade',()=>{
 assert.equal(VERSION,'0.8.1-rc.53');
 const ref=path.join(ROOT,'tools/reference/complete-0.8.1-rc.33-manifest.json');
 assert.equal(sha256(fs.readFileSync(ref)),'829d0f401ff8c2e21b7ae9608657b09be09d46f6fefbd5276f4fef7c4022556a');
 assert.equal(JSON.parse(fs.readFileSync(ref,'utf8')).version,'0.8.1-rc.33');
});
test('RC34 phase 2 never triggers scripts or mutates COMARCH',()=>{
 const src=fs.readFileSync(path.join(ROOT,'src/phase2-supervised.mjs'),'utf8');
 const proof=fs.readFileSync(path.join(ROOT,'lib/phase2-pdf-evidence.mjs'),'utf8');
 assert.doesNotMatch(src,/trustedAction\(|\.mouseClick\(|Input\.dispatch|uploadFile|setFileInputFiles|forwardOnce|spawn\(|execSync\(|shell:\s*true/);
 assert.doesNotMatch(proof,/spawn\(|execSync\(|shell:\s*true|\.writeFileSync\(/);
 assert.match(src,/readPhase2Queue/);assert.match(src,/inspectExistingStatements/);
});
