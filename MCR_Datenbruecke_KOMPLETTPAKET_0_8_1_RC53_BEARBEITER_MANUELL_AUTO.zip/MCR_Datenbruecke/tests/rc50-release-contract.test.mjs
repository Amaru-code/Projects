import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';
import {ROOT} from './helpers.mjs';import {VERSION} from '../lib/control.mjs';
import {sha256} from '../lib/core.mjs';import {verifyPackage} from '../tools/integrity.mjs';
test('RC50 exact RC49 manifest pinned; recovery source and no private data shipped',()=>{
 assert.equal(VERSION,'0.8.1-rc.53');
 assert.equal(sha256(fs.readFileSync(path.join(ROOT,'tools/reference/complete-0.8.1-rc.49-manifest.json'))),
  '3e4782c09f5eb504381e15ba19bbe1b618273075558887173e2b1d94d2530ba3');
 const m=JSON.parse(fs.readFileSync(path.join(ROOT,'MANIFEST.json')));
 assert.equal(m.version,VERSION);
 for(const name of ['tests/rc50-unsaved-gevoloss-browser.test.mjs','tests/rc50-upgrade.test.mjs',
  'lib/phase2-comarch-actions.mjs','lib/phase2-write-journal.mjs','src/phase2-comarch-pilot.mjs',
  'docs/RC50_UNGESPEICHERTE_GEVO_WIEDERAUFNAHME.md','tools/reference/complete-0.8.1-rc.49-manifest.json'])
  assert(m.payload.some(x=>x.path===name),name);
 assert(m.payload.every(x=>!/^(private_data|\.runtime|diagnostics|Ergebnis|reports)\//i.test(x.path)&&!x.path.endsWith('.zip')));
 assert.equal(verifyPackage(ROOT).version,VERSION);
});
