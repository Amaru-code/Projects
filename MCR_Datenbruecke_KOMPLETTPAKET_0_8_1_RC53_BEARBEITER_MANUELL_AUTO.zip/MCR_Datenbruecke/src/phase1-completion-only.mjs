/** RC53: finish a prior pending SEND ticket without any mail-send capability.
 * The exact intended description is bound by the OLD ledger SHA-256. A prior
 * SAVE_INTENT is read-back-only; no ambiguous second save is permitted. */
import {sha256,requireThat as need} from '../lib/core.mjs';
import * as UI from '../lib/browser-workflow.mjs';
import {descriptionWithStatus,sourceUSCLines} from '../lib/status-columns.mjs';
import {kindOfHistoryRow} from '../lib/mail-history-audit.mjs';
import {readPhase2MemberEvidence} from '../lib/phase2-member-evidence.mjs';
import {resolveMemberMapping} from '../lib/member-mapping.mjs';
import {commitDescription} from '../lib/trusted-description.mjs';
import {reviewUnverifiedSend} from '../lib/operator-send-review.mjs';
const norm=x=>String(x??'').replace(/\r\n?/g,'\n').trim();
export async function completePendingSentTicket({page,journal,id,mapping,ask,log=()=>{},save,verify,report=()=>{}}){
 const prior=journal.pending.find(t=>t.ticketId===id&&t.kind==='SEND');
 need(prior&&['SEND_INTENT','SENT_CONFIRMED','SAVE_INTENT'].includes(prior.state),'REPAIR_PENDING_MISSING','Kein passender offener Versandstand.');
 log('ABSCHLUSS_OHNE_NEUVERSAND: '+id+' | '+prior.state+' | KEIN Senden, keine neue Antwort, keine Weiterleitung.');
 let found=false;
 for(const scope of ['IN_BEARBEITUNG','WARTESCHLANGE_INTL01']){
  const snap=await UI.navigateToScope(page,scope,{refresh:true});const row=snap.rows.find(r=>r.ticketId===id);
  if(row){await UI.openTicket(page,row);found=true;break;}
 }
 need(found,'REPAIR_TICKET_NOT_FOUND','Exaktes offenes Ticket nicht in den gelesenen Listen.');
 await UI.assertTicket(page,id);await UI.ensureEdit(page);
 const state=await UI.additionalDescriptionState(page);need(state.ok,'REPAIR_DESCRIPTION','Beschreibung nicht eindeutig.');
 let source=sourceUSCLines(state.value).join('\n');
 if(!source){
  need(norm(state.value)==='','REPAIR_DESCRIPTION_CONFLICT','Vorhandene fremde Beschreibung bleibt erhalten.');
  const member=await readPhase2MemberEvidence(page);
  need(member.profileVerified&&member.profile?.mercerId,'REPAIR_MEMBER','Verifizierter Member zur alten Beschreibung fehlt.');
  const result=resolveMemberMapping(mapping,member.profile.mercerId);source=result.entry?.description;
 }
 const expected=descriptionWithStatus(source);
 need(sha256(expected)===prior.descriptionSha256,'REPAIR_DESCRIPTION_HASH','USC/Status stimmt nicht mit der alten Versandabsicht ueberein.');
 need(['',norm(source),norm(expected)].includes(norm(state.value)),'REPAIR_DESCRIPTION_CONFLICT','Andere Beschreibung/Arbeitsnotiz vorhanden. Kein Ueberschreiben.');
 if(prior.state==='SAVE_INTENT'){
  // Could already have saved. A new click is forbidden, even with a blank field.
  await verify(id,expected);journal.set(id,'COMPLETE');report(id,expected);
  log('PASS ABSCHLUSS_OHNE_NEUVERSAND: Vorhandene Speicherung nachgewiesen; null Schreibklicks.');return {status:'COMPLETE',mode:'READBACK_ONLY',id};
 }
 if(prior.state==='SEND_INTENT'){
  const history=await UI.historyMailSnapshots(page);
  const senders=[...new Set(history.rows?.filter(r=>kindOfHistoryRow(r)==='customer').map(r=>r.sender.toLowerCase())||[])];
  need(history.ok&&senders.length===1,'REPAIR_ORIGINAL_SENDER','Originalabsender nicht eindeutig im aktuellen Ticket.');
  await reviewUnverifiedSend({ticketId:id,recipient:senders[0],assertTicket:x=>UI.assertTicket(page,x),
   hasPendingDialogs:async()=>(await UI.htmlOkProbe(page)).state!=='NONE',ask,log,record:(e,d)=>journal.observe(id,e,d)});
  journal.set(id,'SENT_CONFIRMED');
 }
 await UI.assertTicket(page,id);await UI.ensureEdit(page);
 await commitDescription(page,{ticketId:id,expected,allowedBefore:[source,''],log});
 await save(id,journal);await verify(id,expected);journal.set(id,'COMPLETE');report(id,expected);
 log('PASS ABSCHLUSS_OHNE_NEUVERSAND: Standardantwort-Status und USC gespeichert, keine zweite E-Mail.');
 return {status:'COMPLETE',mode:'STATUS_AND_SAVE_ONLY',id};
}
