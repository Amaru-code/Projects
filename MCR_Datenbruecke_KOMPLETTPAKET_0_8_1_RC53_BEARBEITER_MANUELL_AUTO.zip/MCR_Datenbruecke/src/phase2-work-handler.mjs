/** RC52 DB and private-MBC draft actions. No PDF generation or mail sending. */
import {commitDescription} from '../lib/trusted-description.mjs';
import {requireThat as need} from '../lib/core.mjs';
import {sleep} from '../lib/cdp.mjs';
import * as UI from '../lib/browser-workflow.mjs';
import {readPhase2Queue} from '../lib/phase2-readonly.mjs';
import {readPhase2MemberEvidence} from '../lib/phase2-member-evidence.mjs';
import {resolveMemberMapping} from '../lib/member-mapping.mjs';
import {phase2WorkRule,markedPhase2Description,privateMbcDraft,PHASE2_MARKER} from '../lib/phase2-work-rules.mjs';
import {phase2WorkJournal} from '../lib/phase2-work-journal.mjs';
import {setPhase2Gevo,phase2FieldSnapshot,savePhase2Draft,savePhase2Ticket} from '../lib/phase2-comarch-actions.mjs';
import {openPhase2Ticket} from '../lib/phase2-navigation.mjs';
import {watchPhase2Save} from '../lib/phase2-save-settle.mjs';
import {finishPhase2Route} from '../lib/phase2-review-flow.mjs';
const norm=s=>String(s??'').replace(/\r\n?/g,'\n').trim();
const text=s=>String(s??'').normalize('NFC').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();

export async function handlePhase2Work({root,page,row,mapping,ask,log=console.log,memberLookup=readPhase2MemberEvidence}){
 const id=row.ticketId,journal=phase2WorkJournal(root,id),old=journal.read();
 const candidate=phase2WorkRule(old?{...row,descriptionValue:old.descriptionBefore}:row);
 need(['DB_DIRECT','MBC_PRIVATE_EMAIL'].includes(candidate.kind),'P2_WORK_RULE','Kein freigegebener neuer Bearbeitungstyp.');
 if(old){
  need(old.schema==='MCR_PHASE2_WORK_JOURNAL_V1'&&old.ticketId===id&&old.rule===candidate.kind&&
   ['TICKET_SAVE_INTENT','TICKET_SAVE_VERIFIED','REVIEW_INTENT','REVIEW_VERIFIED'].includes(old.state)&&
   (norm(row.descriptionValue)===norm(old.descriptionAfter)||(old.state==='TICKET_SAVE_INTENT'&&norm(row.descriptionValue)===norm(old.descriptionBefore))),
   'P2_WORK_PENDING','Vorheriger Schritt ungeklaert. Keine Wiederholung von Speichern/Entwurf/Weiterleitung.');
 }
 const open=async r=>openPhase2Ticket(page,r,{log,manualOpen:async ticket=>{
  need((await ask('Im Bot-Edge nur Ticket '+ticket+' oeffnen. OFFEN / ABBRUCH: ')).toUpperCase()==='OFFEN','P2_OPEN_ABORT','Abgebrochen.');
 }});
 await open(row);await UI.assertTicket(page,id);
 // Existing journals require a fresh readback BEFORE reopening edit mode.
 let repair=false;
 if(old){
  const stored=await phase2FieldSnapshot(page);
  repair=old.state==='TICKET_SAVE_INTENT'&&(norm(row.descriptionValue)!==norm(old.descriptionAfter)||stored.gevo.value!=='Anfrage Member');
  if(repair){
   need(!old.events.some(e=>e.state==='EXECUTE_INTENT')&&!old.events.some(e=>e.state==='SAVE_REPAIR_AUTHORIZED'),'P2_WORK_REPAIR_LIMIT','Voriger Reparatur-/Weiterleitungsschritt unklar. Keine Wiederholung.');
   need(['','Anfrage Member','Anfrage Membe'].includes(stored.gevo.value),'P2_WORK_GEVO_CONFLICT','Anderer GEVO-Wert. Kein Ueberschreiben.');
   log('P2_WORK_SAVE_REPAIR: Originalbeschreibung/GEVO noch nicht vollstaendig gespeichert. Keine neue E-Mail, kein neuer Entwurf.');
   need((await ask('Ticket '+id+': Speicherung nicht erfolgt und KEINE Weiterleitung manuell ausgefuehrt? NICHT_GESPEICHERT_'+id+' / ABBRUCH: ')).toUpperCase()==='NICHT_GESPEICHERT_'+id,'P2_WORK_REPAIR_DECLINED','Kein erneuter Speicherklick.');
   journal.observe('SAVE_REPAIR_AUTHORIZED');
  }else need(stored.gevo.value==='Anfrage Member','P2_WORK_SAVED_GEVO','GEVO im Server-Ticket nicht bestaetigt.');
 }
 await UI.ensureEdit(page);await UI.assertTicket(page,id);
 const d=await UI.additionalDescriptionState(page);
 need(d.ok&&d.editable&&norm(d.value)===norm(row.descriptionValue),'P2_WORK_DESCRIPTION_CHANGED','Ticketbeschreibung seit Listenauswahl geaendert.');
 let draft=old?.draft||null;
 const descriptionAfter=old?.descriptionAfter||markedPhase2Description(row.descriptionValue);
 if(!old||repair){
  let memberId=null;
  if(!old&&candidate.kind==='MBC_PRIVATE_EMAIL'){
   const member=await memberLookup(page);
   need(member.profileVerified&&member.profile?.last&&member.profile?.mercerId,'P2_MBC_MEMBER','Kein verifizierter Member fuer die persoenliche Anrede.');
   memberId=member.profile.mercerId;
   const resolved=resolveMemberMapping(mapping,memberId);
   let gender=resolved.entry?.genderStatus==='CONSISTENT'?resolved.entry.gender:null;
   if(!['M','F'].includes(gender)){
    log('Anrede fuer '+member.profile.last+' nicht eindeutig im Bestand. Keine Ableitung aus dem Vornamen.');
    const answer=(await ask('Anrede aus Originalunterlagen: HERR / FRAU / ABBRUCH: ')).toUpperCase();
    need(['HERR','FRAU'].includes(answer),'P2_MBC_SALUTATION','Keine bestaetigte Anrede.');gender=answer==='HERR'?'M':'F';
   }
   draft=privateMbcDraft({lastName:member.profile.last,gender});
   const existing=await UI.editor(page);
   need(existing.ok&&(existing.empty||text(existing.text)===text(draft)),'P2_MBC_EXISTING_DRAFT','Anderer vorhandener Entwurf bleibt unveraendert. Bitte separat pruefen.');
  }
  if(!old){journal.begin({rule:candidate.kind,descriptionBefore:row.descriptionValue,descriptionAfter,draft,memberId});journal.advance('EDIT_INTENT');}
  await setPhase2Gevo(page,{manualFocus:async()=>{
   need((await ask('GEVO-Feld fokussiert? FOKUS / ABBRUCH: ')).toUpperCase()==='FOKUS','P2_OPERATOR_ABORT','Kein GEVO-Fokus.');
  },manualSelect:async()=>{
   need((await ask('Anfrage Member im Vorschlag ausgewaehlt? AUSGEWAEHLT / ABBRUCH: ')).toUpperCase()==='AUSGEWAEHLT','P2_OPERATOR_ABORT','Kein GEVO.');
  }});
  if(draft&&!old){const result=await UI.editor(page,draft);need(result.ok,'P2_MBC_DRAFT_WRITE','Vorgegebener MBC-Entwurf nicht exakt eingefuegt.');}
  await commitDescription(page,{ticketId:id,expected:descriptionAfter,allowedBefore:[row.descriptionValue],log});
  if(!old)journal.advance('EDIT_VERIFIED');
  if(draft&&!old){
   journal.advance('DRAFT_SAVE_INTENT');
   const watcher=await watchPhase2Save(page);
   try{await savePhase2Draft(page);}catch(e){watcher.cancel();throw e;}
   const observed=await watcher.settle();journal.observe('DRAFT_NETWORK_OBSERVED',observed);
   need(!['WRITE_REQUEST_ERROR','NETWORK_STILL_ACTIVE'].includes(observed.status),'P2_MBC_DRAFT_NETWORK','Entwurfstatus unklar; kein weiterer Schreibschritt.');
   const e=await UI.editor(page);need(e.ok&&text(e.text)===text(draft),'P2_MBC_DRAFT_CHANGED','Entwurf nach Klick geaendert.');
   journal.advance('DRAFT_SAVE_VERIFIED');
  }
  await UI.assertTicket(page,id);
  need(await UI.verifyDescription(page,descriptionAfter)&&(await phase2FieldSnapshot(page)).gevo.value==='Anfrage Member','P2_WORK_BEFORE_SAVE','GEVO oder Status vor Speicherung geaendert.');
  if(!old)journal.advance('TICKET_SAVE_INTENT');
  const watcher=await watchPhase2Save(page);
  try{await savePhase2Ticket(page,{beforeAutoClick:()=>journal.observe('TICKET_SAVE_AUTO_CLICK_INTENT'),manualClick:async()=>{
   journal.observe('TICKET_SAVE_MANUAL_CLICK_INTENT');
   need((await ask('Ticket speichern genau einmal manuell geklickt? EINMAL_GEKLICKT / ABBRUCH: ')).toUpperCase()==='EINMAL_GEKLICKT','P2_WORK_SAVE_UNCLEAR','Speicherstatus unklar.');
  }});}catch(e){watcher.cancel();throw e;}
  const observed=await watcher.settle();journal.observe('TICKET_SAVE_NETWORK_OBSERVED',observed);
  need(!['WRITE_REQUEST_ERROR','NETWORK_STILL_ACTIVE'].includes(observed.status),'P2_WORK_SAVE_NETWORK','Speicherstatus unklar. Kein Zweitklick.');
  log('P2_WORK_SAVE_SETTLED: '+observed.status+'; lese Serverstand ohne zweiten Klick.');
  await UI.navigateToScope(page,'IN_BEARBEITUNG',{refresh:true});
  const q=await readPhase2Queue(page),persisted=q.rows?.find(r=>r.ticketId===id);
  need(q.ok&&persisted&&norm(persisted.descriptionValue)===norm(descriptionAfter),'P2_WORK_SERVER_DESCRIPTION','Beschreibung im frischen Server-Ticket nicht gespeichert.');
  await open(persisted);await UI.assertTicket(page,id);
 }
 const g=await phase2FieldSnapshot(page);
 need(g.gevo.count===1&&g.gevo.value==='Anfrage Member'&&await UI.verifyDescription(page,descriptionAfter),'P2_WORK_SERVER_VALUES','GEVO/Status nach erneutem Oeffnen nicht bestaetigt.');
 if(draft){const e=await UI.editor(page);need(e.ok&&text(e.text)===text(draft),'P2_MBC_SAVED_DRAFT','MBC-Entwurf nach erneutem Oeffnen nicht bestaetigt. Keine Weiterleitung.');}
 if(journal.read().state==='TICKET_SAVE_INTENT')journal.advance('TICKET_SAVE_VERIFIED');
 log('PASS P2_WORK_SERVER_PERSISTENCE | '+candidate.kind+' | '+id);
 return finishPhase2Route(page,{ticketId:id,journal,ask,log,route:candidate.route,beforeExecute:async()=>{
  need(await UI.verifyDescription(page,descriptionAfter),'P2_WORK_FINAL_MARKER','Status vor Weiterleitung geaendert.');
  if(draft){const e=await UI.editor(page);need(e.ok&&text(e.text)===text(draft),'P2_MBC_FINAL_DRAFT','Entwurf vor Weiterleitung geaendert.');}
 }});
}
