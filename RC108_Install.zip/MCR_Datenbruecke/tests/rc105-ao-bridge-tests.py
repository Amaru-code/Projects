"""Offline adapter tests: the financial workbook/Excel are never accessed."""
import importlib.util
import json
import os
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('ao_bridge', ROOT / 'tools' / 'ao-generator-bridge.py')
bridge = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bridge)

FIXTURE = '''from pathlib import Path
from datetime import datetime
import json, os
BASE=Path(__file__).resolve().parent
WORKBOOK=BASE/'IPP_Leistungsberechnungen_Arbeitsdatei.xlsm'
OUTPUT=BASE/'Ausgabe PDF'
AUDIT=BASE/'Audit_Logs'
def default_stichtag(today=None):
    today=today or datetime.now()
    return datetime(today.year,12,31)
def ask_stichtag():
    value=input('Stichtag (TT.MM.JJJJ) [31.12.2026]: ').strip()
    return datetime.strptime(value,'%d.%m.%Y') if value else default_stichtag()
def create_pdf(wwid):
    date=ask_stichtag()
    MODE
    name='Nachname Vorname'
    person={'WWID':int(wwid),'Name':name}
    OUTPUT.mkdir(exist_ok=True);AUDIT.mkdir(exist_ok=True)
    pdf=OUTPUT/f'{date:%Y-%m-%d}_Auszahlungsoption_{name}_{wwid}.pdf'
    pdf.write_bytes(b'%PDF-1.7\\n'+b'x'*500+b'\\n%%EOF')
    audit=AUDIT/f'current_{wwid}.json'
    payload={'timestamp':datetime.now().isoformat(timespec='seconds'),'status':'success','wwid':wwid,
      'name':name,'stichtag':date.strftime('%d.%m.%Y'),'record':7,'pdf':str(pdf)}
    MUTATION
    audit.write_text(json.dumps(payload),encoding='utf-8')
    AFTER
    return pdf,audit,7,person
'''


class DummyExcel:
    def install(self):
        pass
    def cleanup(self, grace_ms=5000):
        pass
    def restore(self):
        pass


class AoBridgeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.folder = Path(self.temp.name)
        self.script = self.folder / 'auszahlungsoption_generator.py'
        self.request_id = 'a' * 32

    def tearDown(self):
        self.temp.cleanup()

    def source(self, mode='pass', mutation='pass', after='pass'):
        self.script.write_text(FIXTURE.replace('MODE', mode).replace('MUTATION', mutation).replace('AFTER', after), encoding='utf-8')
        return bridge.sha(self.script.read_bytes())

    def run_fixture(self, source_sha=None):
        with patch.object(bridge, 'OwnedExcel', DummyExcel):
            return bridge.generate(self.script, '11412817', self.request_id,
                                   source_sha or bridge.sha(self.script.read_bytes()), 5, lambda value: None)

    def test_default_date_and_verified_wwid_yield_bound_fresh_proof(self):
        source_sha = self.source()
        result = self.run_fixture(source_sha)
        proof = result['proof']
        self.assertEqual(result['status'], 'SUCCESS')
        self.assertEqual(proof['wwid'], '11412817')
        self.assertEqual(proof['requestId'], self.request_id)
        self.assertEqual(proof['name'], 'Nachname Vorname')
        self.assertEqual(proof['stichtag'], bridge.datetime.now().strftime('31.12.%Y'))
        self.assertEqual(proof['sourceSha256'], source_sha)
        self.assertEqual(proof['sha256'], bridge.sha(Path(proof['file']).read_bytes()))
        self.assertEqual(proof['auditSha256'], bridge.sha(Path(proof['auditFile']).read_bytes()))
        self.assertNotIn('Saldovortrag', json.dumps(proof))

    def test_missing_address_is_not_answered_with_stichtag_or_wwid(self):
        self.source(mode="input('Adresse: ')")
        with self.assertRaisesRegex(bridge.BridgeError, 'Adresse oder PLZ') as error:
            self.run_fixture()
        self.assertEqual(error.exception.code, 'AO_CONTACT_DATA_REQUIRED')
        self.assertIn('Angefordertes Feld: Adresse', str(error.exception))
        self.assertFalse((self.folder / 'Ausgabe PDF').exists())

    def test_missing_postcode_is_reported_separately(self):
        self.source(mode="input('PLZ: ')")
        with self.assertRaises(bridge.BridgeError) as error:
            self.run_fixture()
        self.assertEqual(error.exception.code, 'AO_CONTACT_DATA_REQUIRED')
        self.assertIn('Angefordertes Feld: PLZ', str(error.exception))
        self.assertFalse((self.folder / 'Ausgabe PDF').exists())

    def test_unrecognized_prompt_is_not_guessed(self):
        self.source(mode="input('Menueauswahl: ')")
        with self.assertRaises(bridge.BridgeError) as error:
            self.run_fixture()
        self.assertEqual(error.exception.code, 'AO_UNEXPECTED_INPUT')

    def test_changed_source_after_probe_is_not_executed(self):
        old_sha = self.source()
        self.script.write_text(self.script.read_text() + '\n# changed\n')
        with self.assertRaises(bridge.BridgeError) as error:
            self.run_fixture(old_sha)
        self.assertEqual(error.exception.code, 'AO_SCRIPT_CHANGED')
        self.assertFalse((self.folder / 'Ausgabe PDF').exists())

    def test_wrong_audit_wwid_rejected(self):
        self.source(mutation="payload['wwid']='99999999'")
        with self.assertRaises(bridge.BridgeError) as error:
            self.run_fixture()
        self.assertEqual(error.exception.code, 'AO_AUDIT_MISMATCH')

    def test_stale_output_rejected(self):
        self.source(after='os.utime(pdf,(100,100))')
        with self.assertRaises(bridge.BridgeError) as error:
            self.run_fixture()
        self.assertEqual(error.exception.code, 'AO_RESULT_STALE')

    def test_global_lock_serializes_all_wwids_and_releases(self):
        with bridge.generator_lock(self.folder, wait_seconds=0):
            with self.assertRaises(bridge.BridgeError) as error:
                with bridge.generator_lock(self.folder, wait_seconds=0):
                    self.fail('second workbook owner acquired lock')
            self.assertEqual(error.exception.code, 'AO_GENERATOR_BUSY')
        with bridge.generator_lock(self.folder, wait_seconds=0):
            pass

    def test_manual_workbook_lock_prevents_export(self):
        self.source()
        (self.folder / '~$IPP_Leistungsberechnungen_Arbeitsdatei.xlsm').write_text('owner')
        with self.assertRaises(bridge.BridgeError) as error:
            self.run_fixture()
        self.assertEqual(error.exception.code, 'AO_WORKBOOK_BUSY')
        self.assertFalse((self.folder / 'Ausgabe PDF').exists())

    def test_existing_excel_process_is_not_quit_or_killed(self):
        events = []
        app = types.SimpleNamespace(Hwnd=1, Quit=lambda: events.append('quit'))
        client = types.ModuleType('win32com.client')
        client.DispatchEx = lambda *a, **k: app
        win32com = types.ModuleType('win32com')
        win32com.client = client
        process = types.ModuleType('win32process')
        process.EnumProcesses = lambda: [42]
        process.GetWindowThreadProcessId = lambda hwnd: (1, 42)
        api = types.ModuleType('win32api')
        api.OpenProcess = lambda *a: events.append('open')
        with patch.dict('sys.modules', {'win32com': win32com, 'win32com.client': client,
                                       'win32process': process, 'win32api': api}):
            owned = bridge.OwnedExcel()
            owned.install()
            with self.assertRaises(bridge.BridgeError):
                client.DispatchEx('Excel.Application')
            owned.restore()
        self.assertEqual(events, [])


if __name__ == '__main__':
    unittest.main()
