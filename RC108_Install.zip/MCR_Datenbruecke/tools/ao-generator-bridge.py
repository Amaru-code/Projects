"""RC105 AO adapter: execute the central generator without duplicating its math.

No Excel values are calculated here. The central create_pdf function owns all
business data and workbook changes. This adapter binds input, serializes bot
calls, owns only its new Excel process, and verifies the returned PDF/audit.
"""
from __future__ import annotations

import argparse
import ast
import builtins
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import re
import sys
import threading
import time
from datetime import datetime

MARKER = 'MCR_AO_BRIDGE_RESULT '
MAX_SOURCE = 2 * 1024 * 1024
MAX_PDF = 50 * 1024 * 1024


class BridgeError(Exception):
    def __init__(self, code, reason):
        super().__init__(reason)
        self.code = code


def require(condition, code, reason):
    if not condition:
        raise BridgeError(code, reason)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_source(generator, expected_sha=None):
    generator = Path(generator).resolve(strict=True)
    require(generator.is_file() and generator.name == 'auszahlungsoption_generator.py',
            'AO_SCRIPT_PATH', 'Unerwarteter zentraler AO-Skriptname.')
    data = generator.read_bytes()
    require(0 < len(data) <= MAX_SOURCE, 'AO_SCRIPT_SIZE', 'Zentraler AO-Generator ist leer oder zu gross.')
    source_sha = sha(data)
    require(expected_sha is None or source_sha == expected_sha,
            'AO_SCRIPT_CHANGED', 'Zentraler Generator wurde nach der Vorpruefung geaendert.')
    tree = ast.parse(data, filename=str(generator))
    functions = {node.name: node for node in tree.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}
    require({'create_pdf', 'ask_stichtag', 'default_stichtag'}.issubset(functions),
            'AO_SCRIPT_CONTRACT', 'AO-Generator hat nicht die bestaetigte create_pdf/Stichtag-Schnittstelle.')
    args = functions['create_pdf'].args
    require(len(args.args) == 1 and not args.vararg and not args.kwarg,
            'AO_SCRIPT_CONTRACT', 'create_pdf erwartet nicht genau eine WWID.')
    return generator, data, source_sha


def probe(generator):
    # Read-only: do not import or call the business module at preflight time.
    _, _, source_sha = read_source(generator)
    import win32com.client  # noqa: F401
    import win32api  # noqa: F401
    import win32event  # noqa: F401
    import win32process  # noqa: F401
    return {'status': 'PROBE_OK', 'sourceSha256': source_sha}


@contextlib.contextmanager
def generator_lock(folder, wait_seconds=30):
    # One lock for the shared workbook, not one lock per WWID. The OS releases
    # it on a process crash; an old lock filename cannot block later runs.
    lock_path = Path(folder) / '.mcr_ao_generation.lock'
    stream = open(lock_path, 'a+b', buffering=0)
    locked = False
    try:
        if lock_path.stat().st_size == 0:
            stream.write(b'\0')
        deadline = time.monotonic() + wait_seconds
        while not locked:
            stream.seek(0)
            try:
                if os.name == 'nt':
                    import msvcrt
                    msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                locked = True
            except OSError:
                if time.monotonic() >= deadline:
                    raise BridgeError('AO_GENERATOR_BUSY', 'Ein anderer Bot berechnet bereits eine AO in dieser Arbeitsdatei.')
                time.sleep(0.2)
        yield
    finally:
        if locked:
            stream.seek(0)
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(stream.fileno(), fcntl.LOCK_UN)
        stream.close()


class DiscardOutput(io.TextIOBase):
    # Generator output can contain personal or financial data. The final result
    # below carries only the metadata needed for the specific attachment proof.
    def write(self, text):
        return len(text)

    def flush(self):
        pass


class OwnedExcel:
    """Keep process handles to DispatchEx instances; never kill by name/PID reuse."""
    def __init__(self):
        self.handles = []
        self.guard = threading.Lock()
        self.original = None
        self.client = None

    def install(self):
        import win32com.client as client
        import win32api
        import win32process
        self.client = client
        self.original = client.DispatchEx

        def dispatch(name, *args, **kwargs):
            require(str(name).lower() == 'excel.application', 'AO_COM_CLASS', 'Unerwartete COM-Anwendung im AO-Generator.')
            before_pids = set(win32process.EnumProcesses())
            app = self.original(name, *args, **kwargs)
            try:
                _, pid = win32process.GetWindowThreadProcessId(int(app.Hwnd))
                require(pid not in before_pids, 'AO_EXCEL_OWNERSHIP', 'DispatchEx hat keine neue eigene Excel-Instanz erstellt.')
                # PROCESS_TERMINATE | SYNCHRONIZE. Keeping this handle prevents
                # a later recycled PID from pointing cleanup at another app.
                handle = win32api.OpenProcess(0x0001 | 0x00100000, False, pid)
                with self.guard:
                    self.handles.append(handle)
            except Exception:
                # If DispatchEx unexpectedly reused an existing Excel process,
                # neither Quit nor process termination may touch that process.
                if 'pid' in locals() and pid not in before_pids:
                    try:
                        app.Quit()
                    except Exception:
                        pass
                raise BridgeError('AO_EXCEL_OWNERSHIP', 'Eigene Excel-Instanz konnte nicht eindeutig fuer die Bereinigung gebunden werden.')
            return app

        client.DispatchEx = dispatch

    def cleanup(self, grace_ms=5000):
        import win32api
        import win32event
        with self.guard:
            handles, self.handles = self.handles, []
        for handle in handles:
            try:
                if win32event.WaitForSingleObject(handle, grace_ms) == 258:
                    win32api.TerminateProcess(handle, 3)
                    win32event.WaitForSingleObject(handle, 1000)
            finally:
                handle.Close()

    def restore(self):
        if self.client is not None and self.original is not None:
            self.client.DispatchEx = self.original


def verify_result(result, namespace, wwid, stichtag, started, source_sha, request_id):
    require(isinstance(result, tuple) and len(result) == 4,
            'AO_RESULT_SHAPE', 'Zentraler Generator hat kein vollstaendiges PDF/Audit-Ergebnis geliefert.')
    pdf, audit, record, person = result
    require(isinstance(person, dict) and str(person.get('WWID')) == str(int(wwid)),
            'AO_RESULT_WWID', 'Ergebnis-Person passt nicht zur freigegebenen WWID.')
    name = str(person.get('Name') or '').strip()
    require(bool(name) and len(name) <= 200, 'AO_RESULT_NAME', 'Membername fehlt im Generatorergebnis.')
    pdf = Path(pdf).resolve(strict=True)
    audit = Path(audit).resolve(strict=True)
    output = Path(namespace['OUTPUT']).resolve(strict=True)
    audits = Path(namespace['AUDIT']).resolve(strict=True)
    base = Path(namespace['BASE']).resolve(strict=True)
    require(output == base / 'Ausgabe PDF' and audits == base / 'Audit_Logs',
            'AO_OUTPUT_CONTRACT', 'Zentrale AO-Ausgabe-/Auditordner weichen vom bestaetigten Vertrag ab.')
    require(pdf.parent == output and audit.parent == audits and pdf.is_file() and audit.is_file(),
            'AO_RESULT_PATH', 'PDF oder Audit liegt ausserhalb des zentralen AO-Ausgabeordners.')
    expected_name = re.sub(r'[\\/:*?"<>|]+', '_', f'{stichtag:%Y-%m-%d}_Auszahlungsoption_{name}_{wwid}').strip(' ._') + '.pdf'
    require(pdf.name == expected_name, 'AO_RESULT_FILENAME', 'AO-Dateiname stimmt nicht mit WWID, Name und Stichtag ueberein.')
    require(pdf.stat().st_mtime >= started - 2 and audit.stat().st_mtime >= started - 2,
            'AO_RESULT_STALE', 'PDF oder Audit ist nicht eindeutig aus diesem Generatoraufruf.')
    require(128 <= pdf.stat().st_size <= MAX_PDF and 0 < audit.stat().st_size <= 1024 * 1024,
            'AO_RESULT_SIZE', 'PDF oder Audit hat keine gueltige Dateigroesse.')
    pdf_before = pdf.stat()
    pdf_data = pdf.read_bytes()
    require(pdf_data.startswith(b'%PDF-') and b'%%EOF' in pdf_data[-2048:],
            'AO_RESULT_PDF', 'PDF ist nicht vollstaendig geschrieben.')
    pdf_after = pdf.stat()
    require((pdf_before.st_size, pdf_before.st_mtime_ns) == (pdf_after.st_size, pdf_after.st_mtime_ns),
            'AO_RESULT_CHANGED', 'PDF wurde waehrend der Pruefung geaendert.')
    audit_data = audit.read_bytes()
    payload = json.loads(audit_data.decode('utf-8-sig'))
    require(payload.get('status') == 'success' and str(payload.get('wwid')) == wwid and
            payload.get('name') == name and payload.get('stichtag') == stichtag.strftime('%d.%m.%Y') and
            payload.get('record') == record and Path(payload.get('pdf', '')).resolve(strict=True) == pdf,
            'AO_AUDIT_MISMATCH', 'Audit bestaetigt diesen Member, Stichtag und diese PDF nicht vollstaendig.')
    audit_time = datetime.fromisoformat(payload.get('timestamp', ''))
    require(started - 2 <= audit_time.timestamp() <= time.time() + 2,
            'AO_AUDIT_STALE', 'AO-Audit stammt nicht aus diesem Aufruf.')
    return {'schema': 'MCR_AO_GENERATOR_PROOF_V1', 'requestId': request_id,
            'wwid': wwid, 'name': name, 'stichtag': stichtag.strftime('%d.%m.%Y'),
            'stichtagIso': stichtag.strftime('%Y-%m-%d'), 'file': str(pdf), 'auditFile': str(audit),
            'sha256': sha(pdf_data), 'bytes': len(pdf_data), 'auditSha256': sha(audit_data),
            'sourceSha256': source_sha, 'generatedAt': datetime.now().astimezone().isoformat(),
            'auditTimestamp': payload['timestamp']}


def generate(generator, wwid, request_id, expected_sha, timeout_seconds, emit):
    require(re.fullmatch(r'[0-9]{4,15}', wwid) is not None, 'AO_WWID', 'WWID muss numerisch sein.')
    require(re.fullmatch(r'[a-f0-9]{32}', request_id) is not None, 'AO_REQUEST_ID', 'Generatoraufruf ist nicht gebunden.')
    generator, source, source_sha = read_source(generator, expected_sha)
    started = time.time()
    finished = threading.Event()
    excel = OwnedExcel()

    def watchdog():
        if finished.wait(timeout_seconds):
            return
        try:
            excel.cleanup(0)
        finally:
            emit({'status': 'FAILED', 'requestId': request_id, 'error': 'AO_GENERATOR_TIMEOUT',
                  'reason': 'AO-Berechnung hat die Wartezeit ueberschritten. Eigene Excel-Instanz bereinigt; kein automatischer zweiter Aufruf.'})
            os._exit(4)

    timer = threading.Thread(target=watchdog, daemon=True)
    original_input = builtins.input
    phase = {'stichtag': False, 'answered': False}

    def controlled_input(prompt=''):
        if phase['stichtag'] and not phase['answered'] and re.match(r'^Stichtag\s*\(TT\.MM\.JJJJ\)', str(prompt)):
            phase['answered'] = True
            return ''
        contact_prompt = re.match(r'^(Adresse|PLZ)\s*:', str(prompt), re.IGNORECASE)
        if contact_prompt:
            field = 'PLZ' if contact_prompt.group(1).upper() == 'PLZ' else 'Adresse'
            raise BridgeError('AO_CONTACT_DATA_REQUIRED', f'Adresse oder PLZ fehlt im Gesamtdatenbestand. Angefordertes Feld: {field}. Bitte fachlich ergaenzen; keine erfundene Eingabe.')
        raise BridgeError('AO_UNEXPECTED_INPUT', 'Zentraler AO-Generator fordert eine nicht bestaetigte Eingabe an.')

    try:
        with generator_lock(generator.parent):
            # Manual Excel users do not participate in the bot lock. Respect the
            # workbook owner file instead of opening their working file read-only
            # and failing only after export/save.
            require(not (generator.parent / '~$IPP_Leistungsberechnungen_Arbeitsdatei.xlsm').exists(),
                    'AO_WORKBOOK_BUSY', 'AO-Arbeitsdatei ist bereits in Excel geoeffnet. Bitte die Arbeitsdatei schliessen.')
            excel.install()
            builtins.input = controlled_input
            namespace = {'__name__': '_mcr_central_ao_generator', '__file__': str(generator), '__package__': None}
            sys.path.insert(0, str(generator.parent))
            timer.start()
            with contextlib.redirect_stdout(DiscardOutput()), contextlib.redirect_stderr(DiscardOutput()):
                exec(compile(source, str(generator), 'exec'), namespace)
                require(Path(namespace['BASE']).resolve() == generator.parent,
                        'AO_BASE_CONTRACT', 'Zentraler Generator verwendet ein unerwartetes Arbeitsverzeichnis.')
                require(Path(namespace['OUTPUT']).resolve() == generator.parent / 'Ausgabe PDF' and
                        Path(namespace['AUDIT']).resolve() == generator.parent / 'Audit_Logs' and
                        Path(namespace['WORKBOOK']).resolve() == generator.parent / 'IPP_Leistungsberechnungen_Arbeitsdatei.xlsm',
                        'AO_OUTPUT_CONTRACT', 'Generator verwendet unerwartete Arbeits-/Ausgabedateien.')
                default = namespace['default_stichtag']()
                require(isinstance(default, datetime) and (default.month, default.day) == (12, 31) and
                        default.year == datetime.now().year, 'AO_STICHTAG_DEFAULT', 'Generator-Standardstichtag weicht vom bestaetigten Jahresende ab.')
                original_ask = namespace['ask_stichtag']

                def ask_default():
                    phase['stichtag'] = True
                    try:
                        selected = original_ask()
                    finally:
                        phase['stichtag'] = False
                    require(phase['answered'] and selected == default, 'AO_STICHTAG_MISMATCH', 'ENTER hat den erwarteten AO-Standardstichtag nicht gewaehlt.')
                    return selected

                namespace['ask_stichtag'] = ask_default
                result = namespace['create_pdf'](wwid)
                require(phase['answered'], 'AO_STICHTAG_MISSING', 'Zentraler Generator hat den Standardstichtag nicht bestaetigt.')
                proof = verify_result(result, namespace, wwid, default, started, source_sha, request_id)
            excel.cleanup()
            return {'status': 'SUCCESS', 'proof': proof}
    finally:
        builtins.input = original_input
        excel.restore()
        try:
            excel.cleanup()
        finally:
            finished.set()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--probe', action='store_true')
    parser.add_argument('--generator', required=True)
    parser.add_argument('--wwid')
    parser.add_argument('--request-id')
    parser.add_argument('--expected-source-sha256')
    parser.add_argument('--timeout-seconds', type=int, default=540)
    args = parser.parse_args()
    original_stdout = sys.stdout
    emit_lock = threading.Lock()

    def emit(payload):
        with emit_lock:
            original_stdout.write(MARKER + json.dumps(payload, ensure_ascii=True) + '\n')
            original_stdout.flush()

    try:
        if args.probe:
            result = probe(args.generator)
        else:
            require(5 <= args.timeout_seconds <= 1800, 'AO_TIMEOUT', 'Generator-Wartezeit ungueltig.')
            result = generate(args.generator, args.wwid or '', args.request_id or '',
                              args.expected_source_sha256, args.timeout_seconds, emit)
        emit(result)
        return 0
    except Exception as exc:
        emit({'status': 'FAILED', 'requestId': args.request_id,
              'error': getattr(exc, 'code', 'AO_GENERATOR_FAILED'),
              'reason': str(exc)[:500]})
        return 1


if __name__ == '__main__':
    sys.exit(main())
