/** RC105: central AO generation plus existing DC/PP+ preparation.
 * The calculator owns all financial formulas. No COMARCH mutation here. */
import fs from 'node:fs';
import path from 'node:path';
import {requireThat as need} from '../lib/core.mjs';
import {writeJSON,stamp,ledger} from '../lib/control.mjs';
import {phase2Admission} from '../lib/phase2-admission.mjs';
import {approvedWwid,inspectExistingStatements,generatorPaths} from '../lib/phase2-pdf-evidence.mjs';
import {runLocalStatementGenerator} from '../lib/phase2-local-generator.mjs';
import {verifyAoGeneratorProof,hasAutomaticAoPreparation} from '../lib/phase2-ao-proof.mjs';
import {reusableAoProof} from '../lib/phase2-ao-reuse.mjs';
import {beneficiaryBusinessFingerprint} from '../lib/phase2-post-generator-workbook.mjs';
import {readPhase2MemberEvidence} from '../lib/phase2-member-evidence.mjs';
import {resolveMemberMapping} from '../lib/member-mapping.mjs';
import {openPhase2Ticket} from '../lib/phase2-navigation.mjs';
import * as UI from '../lib/browser-workflow.mjs';

export function verifyLegacyPlanAlias(rule,member,mapping){
 if(!rule.requiresPlanConfirmation)return {verified:true,method:'CANONICAL_DESCRIPTION_PLANS'};
 need(member.profileVerified&&member.profile?.mercerId,'P2_LEGACY_IPP_MEMBER','IPP-Alteintrag ohne gebundenes Memberprofil.');
 const resolved=resolveMemberMapping(mapping,member.profile.mercerId);
 need(resolved.kind==='FOUND'&&Array.isArray(resolved.entry?.records),'P2_LEGACY_IPP_MAPPING','IPP-Alteintrag nicht eindeutig im Bestand.');
 const plans=new Set(resolved.entry.records.flatMap(r=>[...(r.dc===1?['DC']:[]),...(r.ppPlus===1?['PP+']:[])]));
 need(rule.targets.filter(t=>t!=='AO').every(t=>plans.has(t)),'P2_LEGACY_IPP_PLAN_CONFLICT','IPP-Alteintrag passt nicht zu DC/PP+ im gebundenen Bestand. Keine Anlage geraten.');
 return {verified:true,method:'LEGACY_IPP_CONFIRMED_BY_MEMBER_MAPPING'};
}

export function reviewedPdfProof({root,ticketId,rule,wwid,member,before,wwidOrigin,planEvidence,automaticAo=false,paths=generatorPaths}){
 const selectedArtifacts=before.artifacts.filter(a=>a.provenance==='CENTRAL_AO_GENERATOR_AUDIT');
 for(const a of selectedArtifacts)verifyAoGeneratorProof(root,a.generation,{wwid,first:member.profile.first,last:member.profile.last,paths});
 const fresh=inspectExistingStatements(root,rule.targets,wwid,{first:member.profile.first,last:member.profile.last,selectedArtifacts,paths});
 need(fresh.artifacts.length===before.artifacts.length&&fresh.artifacts.every(a=>{
  const p=before.artifacts.find(x=>x.plan===a.plan);return p&&p.name===a.name&&p.sha256===a.sha256&&p.bytes===a.bytes;
 }),'P2_PDF_MUTATED','PDFs seit Inhaltspruefung veraendert. Keine Anlage.');
 const proof={...fresh,ticketId,wwidOrigin,memberProfileVerified:true,
  memberId:member.profile.mercerId,memberName:{first:member.profile.first,last:member.profile.last},
  operatorContentReviewed:!automaticAo,operatorPersonTicketBindingReviewed:!automaticAo,
  ...(automaticAo?{systemPreparedForReview:true,requiresReviewerContentReview:true,preparationMethod:'CENTRAL_AO_GENERATOR_AUDIT'}:{}),
  operatorNameOnlyRecheckCompleted:false,planEvidence,
  automaticAttachmentAuthorized:false,comarchStatus:'NOT_ATTACHED_NOT_SAVED_NOT_FORWARDED'};
 if(automaticAo)need(hasAutomaticAoPreparation(proof),'P2_AO_AUTOMATIC_BINDING','Automatische AO-Vorbereitung nicht vollstaendig an den COMARCH-Member gebunden.');
 return proof;
}

export async function preparePhase2PdfEvidence({root,page,row,mapping,ask,log=console.log,memberLookup=readPhase2MemberEvidence,controls=null,
 generator=runLocalStatementGenerator,paths=generatorPaths,ui=UI,openTicket=openPhase2Ticket}){
 const id=String(row.ticketId),admission=phase2Admission(row,ledger(root).pending),rule=admission.rule;
 need(admission.allowed&&rule.kind==='ACCOUNT_STATEMENT','P2_PDF_PREP_RULE','Kein unterstuetzter Dokumentenauftrag (DC/PP+/AO).');
 const actions=path.join(root,'.runtime','phase2','actions');
 need(!fs.existsSync(path.join(actions,'MCR_PHASE2_'+id+'.json'))&&!fs.existsSync(path.join(actions,'MCR_PHASE2_WORK_'+id+'.json')),
  'P2_PDF_PREP_PREVIOUS_ACTION','Schon begonnene Phase-2-Aktion: keine neue PDF-Vorbereitung.');
 await openTicket(page,row,{log,manualOpen:async ticket=>{
  need(String(await ask('Nur Ticket '+ticket+' im Bot-Edge oeffnen. OFFEN / ABBRUCH: ')).toUpperCase()==='OFFEN','P2_OPEN_ABORT','Abgebrochen.');
 }});
 await ui.assertTicket(page,id);await controls?.readDetail?.(page,id);
 const member=await memberLookup(page);
 need(member.profileVerified&&member.profile?.first&&member.profile?.last&&member.profile?.mercerId,
  'P2_MEMBER_NOT_BOUND','Kein eindeutiges COMARCH-Memberprofil fuer Dokumente.');
 const planEvidence=verifyLegacyPlanAlias(rule,member,mapping);
 need(!member.wwid||!member.memberReferenceWwid||member.wwid===member.memberReferenceWwid,
  'P2_WWID_CONFLICT','WWID-Feld widerspricht gebundener INTL01-Memberreferenz.');
 // Never use a generic MercerID or scan unrelated PDFs for a person ID.
 let wwid=member.wwid||member.memberReferenceWwid;
 const wwidOrigin=member.wwid?'EXPLICIT_COMARCH_FIELD':member.memberReferenceWwid?'BOUND_INTL01_MEMBER_REFERENCE':'OPERATOR_ENTRY';
 if(!wwid)wwid=approvedWwid(await ask('Verifizierte WWID dieser Person (nicht pauschal MercerID): '));
 wwid=approvedWwid(wwid);
 log('P2_PDF_PERSON: '+id+' | '+member.profile.first+' '+member.profile.last+' | WWID '+wwid+' | '+wwidOrigin);
 await controls?.waitUntilResumed?.();
 const selectedArtifacts=[];
 if(rule.targets.includes('AO')){
  // A current AO is produced through the central calculator, even if a
  // previous-year file exists. Never choose the first filename from a folder.
  await ui.assertTicket(page,id);
  // An earlier run may have generated a verified PDF and stopped BEFORE
  // uploading. Reuse that immutable result; do not calculate the same
  // benefit again merely because COMARCH/Excel mapping needed recovery.
  const reused=reusableAoProof({root,ticketId:id,wwid,member,mapping,paths});
  if(reused.status==='REVIEW_REQUIRED'){
   log('P2_AO_ALTER_NACHWEIS_UNKLAR: '+id+' | '+reused.reason+' | kein erneuter Generatorstart.');
   return {status:'SKIPPED_UNCHANGED',ticketId:id,noWrite:true,reason:reused.reason};
  }
  if(reused.status==='AUTO_REUSE'){
   selectedArtifacts.push(reused.artifact);
   log('PASS P2_AO_VORHANDENE_ERZEUGUNG_WIEDERVERWENDET: '+id+' | gleiche WWID, Person, unveraenderter Fachdatensatz, PDF und Audit; keine neue Berechnung.');
  }else if(reused.status==='OPERATOR_REVIEW'){
   log((reused.olderThanDay?'P2_AO_AELTERER_BELEG_PRUEFEN: ':'P2_AO_WIEDERAUFNAHME_RC105: ')+id+' | '+reused.artifact.name+' | Erzeugt '+reused.artifact.generation.generatedAt+' | bisherige Berechnung/Original-PDF bleibt unveraendert.');
   const response=String(await ask('Vorhandene AO-PDF, Stichtag, Person und unveraenderte fachliche Berechnungsgrundlagen unabhaengig geprueft? JA = ohne Neuberechnung fortfahren / UEBERSPRINGEN: ')).trim().toUpperCase();
   if(response!=='JA')return {status:'SKIPPED_UNCHANGED',ticketId:id,noWrite:true,reason:'AO_PREVIOUS_PROOF_REVIEW_REQUIRED'};
   const checkedAgain=reusableAoProof({root,ticketId:id,wwid,member,mapping,paths});
   if(!['AUTO_REUSE','OPERATOR_REVIEW'].includes(checkedAgain.status)||checkedAgain.artifact.sha256!==reused.artifact.sha256||checkedAgain.artifact.generation.auditSha256!==reused.artifact.generation.auditSha256)return {status:'SKIPPED_UNCHANGED',ticketId:id,noWrite:true,reason:'AO_PREVIOUS_PROOF_CHANGED_DURING_REVIEW'};
   selectedArtifacts.push(checkedAgain.artifact);
   log('PASS P2_AO_VORHERIGE_PDF_NACH_PRUEFUNG_UEBERNOMMEN: Kein erneuter Generatorstart.');
  }else{
   log('P2_AO_ERSTELLEN: Ticket '+id+' | WWID '+wwid+' | Standardstichtag 31.12.'+new Date().getFullYear());
   let started;
   try{started=await generator(root,'AO',wwid,{log,paths});}
   catch(error){
    // No upload/save/route has started. A generator error concerns this one
    // document job; no speculative retries or old-PDF fallback.
    log('P2_AO_ERSTELLUNG_OFFEN: '+id+' | '+(error.code||'AO_GENERATOR_ERROR')+' | '+error.message);
    return {status:'SKIPPED_UNCHANGED',ticketId:id,noWrite:true,reason:error.code||'P2_AO_GENERATOR_FAILED'};
   }
   if(started.status!=='GENERATOR_EXECUTED'||!started.proof){
    const reason=started.error||'P2_AO_GENERATOR_FAILED';
    log('P2_AO_ERSTELLUNG_OFFEN: '+id+' | '+reason+' | '+(started.reason||started.status)+' | kein Upload; naechstes Ticket.');
    return {status:'SKIPPED_UNCHANGED',ticketId:id,noWrite:true,reason};
   }
   selectedArtifacts.push(verifyAoGeneratorProof(root,started.proof,{wwid,first:member.profile.first,last:member.profile.last,paths,fresh:true}));
   log('PASS P2_AO_ERZEUGT_UND_GEBUNDEN: '+id+' | '+selectedArtifacts[0].name+' | WWID, Name, Stichtag, Audit und PDF-Hash bestaetigt.');
  }
 }
 const missing=[];
 for(const plan of rule.targets.filter(plan=>plan!=='AO')){
  try{inspectExistingStatements(root,[plan],wwid,{first:member.profile.first,last:member.profile.last,paths});}
  catch(e){if(!['P2_EXACT_PDF_MISSING','P2_OUTPUT_FOLDER_MISSING'].includes(e.code))throw e;missing.push(plan);}
 }
 if(missing.length){
  log('P2_DOKUMENTE_FEHLEN: '+id+' | '+missing.join('+')+' | nur freigegebene WWID '+wwid+'.');
  for(const plan of missing){
   await controls?.waitUntilResumed?.();
   // RC102: AO has a fixed approved BAT path just like the DC/PP+ generators.
   // UVA is NOT a document target until its output and naming are confirmed.
   try{
    log('P2_GENERATOR_STARTPFAD: '+paths(root,plan).start);
    const started=await generator(root,plan,wwid,{log,paths});
    log('P2_GENERATOR '+plan+': '+started.status+' | '+started.contract);
    if(started.status==='GENERATOR_EXECUTED'){
     // A BAT may hand generation off to a separate child. Read the actual
     // file twice at a stable interval, never infer success from exit code.
     let accepted=null;
     for(let i=0;i<60;i++){
      await controls?.waitUntilResumed?.();
      try{
       const checked=inspectExistingStatements(root,[plan],wwid,{first:member.profile.first,last:member.profile.last,paths});
       const same=checked.artifacts[0].sha256;
       if(accepted===same){log('PASS P2_GENERATOR_PDF_BEREIT: '+plan+' | WWID-Datei mit stabilem SHA256 erkannt.');break;}
       accepted=same;
      }catch(e){if(!['P2_EXACT_PDF_MISSING','P2_OUTPUT_FOLDER_MISSING','P2_PDF_EOF','P2_PDF_SIZE'].includes(e.code))throw e;accepted=null;}
      await new Promise(r=>setTimeout(r,1000));
     }
    }
   }catch(e){
    if(!['P2_GENERATOR_NOT_FOUND','P2_GENERATOR_WINDOWS_ONLY','P2_GENERATOR_SCRIPT_SIZE'].includes(e.code))throw e;
    log('P2_GENERATOR_NICHT_VERFUEGBAR: '+plan+' | '+e.code);
   }
  }
  const remaining=[];
  for(const plan of missing){
   await controls?.waitUntilResumed?.();try{
    inspectExistingStatements(root,[plan],wwid,{first:member.profile.first,last:member.profile.last,paths});
   }catch(e){if(!['P2_EXACT_PDF_MISSING','P2_OUTPUT_FOLDER_MISSING'].includes(e.code))throw e;remaining.push(plan);}}
  if(remaining.length){
   log('P2_PDF_NOCH_OFFEN: '+remaining.join('+')+' | nur fehlende Dokumente manuell erstellen, bestehende Dateien unangetastet lassen.');
   const answer=String(await ask('Fehlende PDFs bereitstellen und WWID im Dokument pruefen. PDFS_BEREIT / UEBERSPRINGEN / ABBRUCH: ')).trim().toUpperCase();
   if(answer==='UEBERSPRINGEN')return {status:'SKIPPED_UNCHANGED',ticketId:id,noWrite:true,reason:'PDF_CREATION_REQUIRED'};
   need(answer==='PDFS_BEREIT','P2_OPERATOR_ABORT','Keine neuen PDFs freigegeben.');
  }
 }
 await controls?.waitUntilResumed?.();
 const before=inspectExistingStatements(root,rule.targets,wwid,{first:member.profile.first,last:member.profile.last,selectedArtifacts,paths});
 const automaticAo=rule.targets.length===1&&rule.targets[0]==='AO'&&selectedArtifacts.length===1&&wwidOrigin!=='OPERATOR_ENTRY';
 if(automaticAo){
  log('PASS P2_AO_AUTOMATISCH_VORBEREITET: Ergebnis des zentralen Generators wird angehaengt; fachliche Pruefung bei Mark.');
 }else{
  for(const a of before.artifacts)log('P2_PDF_INHALT_PRUEFEN: '+a.plan+' | '+a.file);
  const response=String(await ask('Ticket '+id+': Person, WWID, Zeitraum, Berechtigung und Inhalte ALLER '+before.artifacts.length+' PDFs geprueft? JA / UEBERSPRINGEN / ABBRUCH: ')).trim().toUpperCase();
  if(response==='UEBERSPRINGEN')return {status:'SKIPPED_UNCHANGED',ticketId:id,noWrite:true,reason:'PDF_CONTENT_REVIEW_DEFERRED'};
  need(response==='JA','P2_CONTENT_REVIEW_REQUIRED','Keine Anlage ohne Inhaltspruefung.');
 }
 await ui.assertTicket(page,id);
 const afterMember=await memberLookup(page);
 need(afterMember.profileVerified&&afterMember.profile.mercerId===member.profile.mercerId&&
  afterMember.profile.first===member.profile.first&&afterMember.profile.last===member.profile.last&&
  (!afterMember.wwid||afterMember.wwid===wwid)&&(!afterMember.memberReferenceWwid||afterMember.memberReferenceWwid===wwid)&&
  (wwidOrigin==='OPERATOR_ENTRY'||afterMember.wwid===wwid||afterMember.memberReferenceWwid===wwid),
  'P2_PDF_MEMBER_CHANGED','Member/WWID waehrend der PDF-Pruefung geaendert.');
 const proof=reviewedPdfProof({root,ticketId:id,rule,wwid,member,before,wwidOrigin,planEvidence,automaticAo,paths});
 if(rule.targets.includes('AO')){
  const fingerprint=beneficiaryBusinessFingerprint(mapping,wwid);
  if(fingerprint)proof.memberBusinessEvidence={schema:'MCR_AO_MEMBER_WORKBOOK_V1',wwid,fingerprint};
 }
 const file=path.join(root,'.runtime','phase2','MCR_PHASE2_PDF_BELEG_'+id+'_'+stamp()+'.json');
 writeJSON(file,proof);log('PASS P2_PDF_BELEGE_IM_LAUF: '+id+' | '+rule.targets.join('+')+' | keine COMARCH-Aenderung bisher.');
 return {status:'PDF_PROOF_READY',ticketId:id,proof,file};
}
