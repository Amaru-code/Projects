# MCR DATENBRUECKE 0.8.1-rc.103

Version **0.8.1-rc.103**, 20. November 2026.

**IN RC102 BEREITS ENTHALTEN:** Die BAT-Startdateien fuer DC, PP+, AO und UVA sind jetzt fest auf dem K:-Laufwerk registriert. AO wird bei fehlender PDF wie DC und PP+ ueber seinen Generator versucht. Die bisher dokumentierten lokalen PDF-Ausgabeordner bleiben getrennt von den neuen Startpfaden. UVA hat ohne bestaetigtes Ausgabeformat noch keine automatische Dokumentzuordnung oder Anlage. Details siehe `docs/RC102_RELEASE.md`.

**NEU IN RC103:** Reparatur der Windows-Prozesspruefung vor Master/Phase 1/Phase 2 und bei Installation. Der bisherige einzige Get-CimInstance-Aufruf (8s-Grenze) hat bei Timeout/Fehler den kompletten Lauf mit `PROCESS_CHECK_UNAVAILABLE` beendet. Jetzt mit erweiterter Zeitgrenze, zweitem unabhängigen Get-WmiObject-Abfrageweg, frischer Prozessliste und genauerer Ursache. Keine Aufhebung der Mehrfachlauf-/Doppelversandsperren. Details siehe `docs/RC103_RELEASE.md`.

**NEU IN RC101:** Die INTL01-Signatur verwendet wieder die bewährte neutrale COMARCH-Fokusbestätigung nach der Unterkategorie. Bei einer vor Versand manuell geänderten Empfängeradresse bzw. abweichenden Pflichtfeldern wird die Eingabe geprüft und kann korrigiert werden; das aktuelle Ticket kann ohne Wiederholungsversand zur Prüfung offen bleiben. Das Bedienfenster bietet **STOP (Pause) / CONTINUE**. Alte Freigaben erlöschen bei Pause.

**Dokumente in Phase 2:** Der Bot kann die beiden fest zugeordneten DC-/PP+-Kontoauszug-BAT-Dateien starten und eine unabhängig bestätigte WWID über eine erkannte `set /p`-Eingabe bzw. einen eindeutigen `%1`-Parameter übergeben. Eine unbekannte BAT-Benutzerführung bleibt eine manuelle Eingabe, **kein geratenes Tippen**. Neue PDFs werden nicht aufgrund eines Exitcodes angenommen, sondern aus dem Ausgabeordner verifiziert. Zusätzlich werden **Auszahlungsoptionen (AO)** anhand der **WWID am Dateiende** sowie des verifizierten Namens aus `Auszahlungsoption\Ausgabe PDF` geladen. Bis zu **DC + PP+ + AO** können aus einer kombinierten Anforderung entstehen. Details siehe `docs/RC101_RELEASE.md`.

**Member-Suche repariert:** RC100 prüft den vollständig zurückgelesenen Suchtext auch dann zuverlässig, wenn COMARCH danach den Fokus verschiebt. Bei einer wirklich unvollständigen Eingabe gibt es höchstens drei kontrollierte Eingabewege im eindeutig gebundenen Suchfeld. Bleibt ein nachweislich begrenzter Suchfehler vor einer Ticketaktion bestehen, kann dieses eine Ticket als offen zurückgestellt werden und der Lauf mit dem nächsten geeigneten Ticket fortfahren. Die vollständige Personen- und ID-Prüfung bleibt erforderlich. Einzelheiten stehen in `docs/RC100_RELEASE.md`.

**Der Browserstart aus RC99 bleibt erhalten.** Im inzwischen gemeldeten RC99-Lauf öffnete sich das eigene Botfenster erfolgreich. Der neue Fehler trat anschließend bei der Member-Suche auf.

**Automatische Bestandsprüfung bleibt aktiv:** Sobald die installierte `START.cmd` das Hauptmenü öffnet, wird der XLSX-Bestand von K: automatisch gelesen und bei geänderten fachlichen Daten als lokales Mapping aktualisiert. Die Anzeige meldet `PASS STARTUP_BESTAND_GEPRUEFT` oder einen konkreten Warncode. Diese Startprüfung schreibt keine FM/FN-Kontakte in Excel und beginnt keine Ticketbearbeitung.

Menü 3, 4 und 5 lesen die Quelle vor der Ticketbearbeitung erneut. **Menü 2 ist optional** für eine gesonderte Bestands-/Kontaktdatenwartung. Kann K: beim Start nicht gelesen werden, bleibt das Menü erreichbar; der Ticketlauf benötigt weiterhin eine erfolgreiche Quellenprüfung. Der Bot fällt nie still auf veraltete JSON-Daten zurück.

Die bisherigen Verbesserungen an Fokus, Pflichtfeldern, Profilübernahme, Excel-Bestand und Live-Karte bleiben enthalten.

## Installation und erster Start

1. `RC101_Install.zip` vollständig in einen separaten Ordner außerhalb der vorhandenen Installation entpacken.
2. Darin `MCR_Datenbruecke\START.cmd` öffnen, **1** wählen und die vorhandene Installation als Ziel übernehmen.
3. `PASS INSTALLATION_COMPLETE` abwarten. Danach ausschließlich die `START.cmd` der installierten Version verwenden. Der Titel muss **0.8.1-rc.103** anzeigen.
4. Die automatische Bestandsprüfung abwarten. Menü **2** kann für gesonderte Wartung verwendet werden; es ist kein Pflichtschritt vor dem Master Run.
5. Für den vollständigen Lauf **5** wählen und mit **ENTER** bestätigen. Das eigene Edge-Fenster soll sich öffnen. Falls erforderlich, dort bei COMARCH anmelden und den angezeigten Bedienhinweisen folgen. Menü **3** und **4** bleiben für die getrennten Phasen verfügbar.

Das Update bewahrt private_data, Konfiguration, Browserprofil und Laufjournale. Es versendet keine Nachrichten. Die zugelassenen RC96-, RC97-, RC98- und RC99-Ausgaben werden anhand ihrer fest gebundenen Manifest-Hashes und sämtlicher Programmdateien geprüft; die bisher unterstützten älteren Versionen bleiben zugelassen. Eine lokal abgeänderte Installation wird nicht ungeprüft ersetzt. Die Menüs 3 und 5 bearbeiten nach der Startbestätigung echte Tickets mit E-Mail-Versand in Phase 1; Phase 2 arbeitet weiterhin ohne E-Mail-Versand.

## 1. Member-Feld und Pflichtfelder

Seit RC97 wurde der Suchtext zunächst bis auf das letzte Zeichen und anschließend mit dem letzten Zeichen über native Tastatureingabe gesetzt. Die abschließende Prüfung verlangte zusätzlich den Fokus im Suchfeld. Dadurch konnte ein bereits vollständig übernommener Suchtext als Fehler gelten, wenn COMARCH den Fokus während der Aktualisierung verlagerte.

RC100 trennt diese Prüfungen: Vor einer Eingabe müssen Ticket und Suchfeld eindeutig gebunden sein. Danach entscheidet ein stabiler, exakter Rücklesewert, ob die Eingabe übernommen wurde; ein inzwischen verschobener Fokus allein widerlegt diesen Wert nicht.

Ist der Text tatsächlich nicht vollständig, sind höchstens drei begrenzte Eingabewege vorgesehen: der reguläre native Weg, die vollständige native Texteingabe und ein eingeschränkter Kompatibilitätsweg nach dem RC96-Verhalten. Vor jedem erneuten Eingriff werden die Bindung und der aktuelle Feldinhalt geprüft. Fremde Inhalte oder ein bereits ausgewähltes Personenprofil werden dabei nicht überschrieben. Derselbe Eingabeweg gilt für Namen und für die Suche mit WWID beziehungsweise MercerID.

Ein dauerhaft nicht bestätigter Suchtext kann nur mit dem besonderen Nachweis `MEMBER_QUERY_REVIEW_REQUIRED` zum Zurückstellen dieses einen Tickets führen. Der Nachweis muss bestätigen, dass der Fehler auf die gebundene Suche begrenzt blieb und keine zu prüfende Ticketaktion begonnen wurde. Das Ticket bleibt offen; der Bot sendet, speichert oder leitet es nicht weiter. Ohne diesen Nachweis bleiben unklare Zustände ein Abbruchgrund. Ein erfolgreich eingegebener Suchtext ist noch keine bestätigte Person: Die vollständigen Profil-, Namens- und ID-Nachweise bleiben unverändert erforderlich.

Der reguläre Pflichtfeldweg lautet:

**Kategorie wählen → Member-Fokus zur Übernahme → Unterkategorie wählen → Member-Fokus zur sicheren COMARCH-Übernahme → Signatur → Antworteditor.**

Der Member-Fokus nach der Unterkategorie ist in RC101 wieder der reguläre, bewährte Weg zur COMARCH-Übernahme vor der Signatur. Eine bereits vollständig bestätigte Pflichtfeldkombination wird bei späteren Prüfungen desselben Tickets und Members gelesen, ohne den ganzen Auswahlweg erneut auszuführen. Vor dem ersten Suchtext entfällt das bisherige Warten auf eine noch leere Vorschlagsliste.

Manuelle Hilfe bleibt möglich, wenn COMARCH das richtige Feld tatsächlich verdeckt oder keine eindeutigen Vorschläge liefert. Eine vollständige Beseitigung solcher Oberflächenprobleme lässt sich ohne Prüfung in der echten COMARCH-Sitzung nicht zusichern. Sende-, Speicher- und Weiterleitungsklicks werden dadurch nicht wiederholt.

## 2. Ein Bot-Tab

Der eigene Browserstart aus RC99 wurde im folgenden Benutzerlauf erfolgreich erreicht. RC100 behält diesen Startweg bei.

Im gemeldeten RC98-Lauf war die Browsersteuerung bereits erreichbar, aber die anschließende Suche nach der exakt markierten Startadresse fand keinen passenden Tab. Die Fehlerbehandlung beendete daraufhin den gestarteten Browser. Deshalb konnte das Botfenster kurz erscheinen oder wieder verschwinden, bevor die Ticketbearbeitung begann. Warum die Markierung im konkreten Windows-/Edge-Lauf fehlte, ist aus dem Protokoll nicht nachgewiesen.

RC99 startet den eigenen Edge-Prozess ohne automatisch erzeugtes Startfenster und ohne Startadresse. Danach erzeugt die Browsersteuerung ausdrücklich eine neue leere Seite in einem sichtbaren neuen Fenster und erhält deren eindeutige Tab-ID zurück. Der Bot prüft genau diese Seite und bindet sie an den Lauf. Eine Suche nach einer Startmarkierung oder die Übernahme eines schon vorhandenen Tabs ist dafür nicht mehr nötig.

Pilot, Folgelauf und Phase 2 verwenden im Master weiter dieselbe Tab-ID. Jeder Teillauf lädt darin COMARCH frisch und prüft, dass tatsächlich eine neue Ansicht geladen wurde. Derselbe ausdrückliche Seitenstart gilt für eigenständige Phasen ohne gemeinsamen Masterbrowser.

Am Ende eines Teillaufs wird die technische Verbindung getrennt, der Tab bleibt erhalten. Der Master beendet seinen Edge-Prozess am Laufende. Ein Ticketwechsel innerhalb eines Teillaufs nutzt weiterhin denselben Tab. Die Live-Karte ist ein separates Anzeigefenster im normalen Browser.

Fremde oder wiederhergestellte Browser-Tabs werden nicht übernommen. Fehler beim ersten Erzeugen oder Binden des Botfensters werden von einem späteren Verlust des bereits gebundenen Tabs unterschieden. Wird dieser Tab während der Bearbeitung geschlossen, hält der Bot weiterhin an; er ersetzt ihn nicht während einer Ticketaktion und wiederholt keinen Versand.

## 3. Gelesene Namen übernehmen

Wenn Vorname, Nachname und MercerID bereits aus dem eindeutig ausgewählten COMARCH-Profil lesbar sind, werden sie übernommen. Die bisherigen drei erneuten Eingaben von ID, Vorname und Nachname entfallen in diesem Fall.

Bei einem wirklichen Namenskonflikt zeigt der Bot das Profil an und fragt einmal:

- **ENTER:** Person und Berechtigung geprüft; der Originalabsender gehört zu dieser Person.
- **VERTRETER:** Berechtigte Vertretung bestätigt; E-Mail und Sprache werden nicht als persönlicher Kontakt des Members in FM/FN übernommen.
- **NEU SUCHEN:** Member erneut auswählen.
- **ABBRUCH:** Lauf anhalten.

Fehlt der Name in der Nachricht, versucht der Bot zuerst, das bereits ausgewählte Profil zu lesen. Andernfalls kann die Person im Member-Feld ausgewählt werden; danach liest der Bot die Profilwerte. Nur die ausdrückliche Alternative **NAMEN** verwendet die getrennte Namenseingabe.

Nach einer manuellen Pause werden Ticket und Profil erneut geprüft. WWID und MercerID bleiben getrennt. Ein ausdrücklich beschriftetes WWID-Feld wird zusätzlich mit dem Bestands-Lookup verglichen. Der bisherige Präfix-11-Lookup verändert nur den Suchschlüssel zum Bestand, niemals die COMARCH-ID.

## 4. Verbindliche Excel-Quelle

Voreingestellt ist:

```text
K:\INTL01\6_AU (Admin)\~ Data\~ Bestand Intel Gesamtübersicht\INTL01_Gesamtdatenbestand_30.09.2025.xlsx
```

Der bestehende Leser verwendet das Blatt **Output**. Bei fehlendem oder nicht eindeutigem Blatt und widersprüchlichen Spaltenüberschriften erscheint ein konkreter Fehler. Es wird kein anderes Blatt geraten.

| Spalte | Verwendung |
| --- | --- |
| B | WWID / bisheriger ClientEEID-Schlüssel |
| C | DC: 1 aktiv, 0 inaktiv, leer nicht gesetzt |
| D | PP+: 1/0/leer |
| E | PensIntel: 1/0/leer |
| F | TPP: 1/0/leer |
| G | JUB: 1/0/leer |
| H | UEB: 1/0/leer |
| I | ZW: 1/0/leer |
| L | USC |
| O | M/F für die Anrede; fehlende oder widersprüchliche Werte behalten den Prüfweg |
| FM | Ergänzte eigene E-Mail-Adressen |
| FN | Sprache der Originalnachricht: DE oder EN |

Die vorhandene Projektregel behandelt E/PensIntel bereits als `pensIntel` und `dbPlus`. RC97 behält deshalb die bestehende **DB+**-Anzeige und die zugehörige Phase-2-Regel bei. JUB, UEB und ZW werden zusätzlich gelesen und in den Planzeilen angezeigt. Sie erhalten keine erfundenen neuen Bearbeitungs- oder PDF-Regeln. Kontoauszugsziele bleiben DC/PP+.

Alle Bestandszeilen derselben WWID bleiben in ihrer Reihenfolge erhalten. Ein Fehler in einer zugehörigen fachlichen Zeile sperrt die vollständige Zuordnung; es wird keine scheinbar vollständige Teilmenge verwendet. Die Begrenzung der COMARCH-Beschreibung bleibt geprüft.

### Aktualität und JSON

Die XLSX ist die führende Quelle. JSON bleibt intern als überprüfter Lauf-Snapshot erhalten, damit Pilotfreigabe, Browser-Lease und Journale einen festen Bezug haben. Es muss kein JSON-Bestand von Hand nachgepflegt werden.

Vor dem Lauf wird die Quelle neu gelesen. Vor Tickets und entscheidenden Schreibgrenzen wird geprüft, ob WWID, Merkmale, USC oder Anrede seit dem Einlesen geändert wurden. Bei einer fachlichen Änderung hält der Bot vor der nächsten betroffenen Aktion an: **Menü 2**, anschließend neu starten. Bereits abgeschlossene Tickets bleiben geschützt. Ist K: nicht erreichbar, gibt es keinen stillen Rückfall auf ein altes JSON.

Änderungen nur in FM/FN oder anderen unbeteiligten Spalten lösen keine neue Pilotpflicht aus. Formelwerte werden aus den gespeicherten Excel-Ergebnissen gelesen; vorhandene Formelprüfungen bleiben erforderlich. Der Bot berechnet die Bestandsdatei nicht neu.

Ein abweichender Dateipfad kann in `config/local-runner-queue-send.json` über `stockWorkbookPath` gesetzt werden. In JSON sind Rückstriche doppelt zu schreiben. Die bestehende Konfiguration bleibt beim Update erhalten; fehlt dieser neue Schlüssel, gilt der oben angegebene Standardpfad.

## 5. E-Mail und Sprache ergänzen

Die Kontaktübernahme erfolgt nach nachgewiesenem Versand **und** Speichern des Tickets. Sie verwendet den gebundenen Originalabsender, den geprüften Antwortempfänger, das zuletzt bestätigte Memberprofil, die daraus aufgelöste WWID und die Originalsprache.

Bei der manuell geprüften Zuordnung genügt die oben beschriebene ENTER-Bestätigung auch bei einer undurchsichtigen E-Mail-Adresse. Ohne manuelle Prüfung muss ein eindeutiger passender Absender- oder aktueller Signaturbezug vorliegen. Ein Name, der lediglich im Nachrichtentext erwähnt wird, wird nicht als Inhaber der Absenderadresse angenommen.

FM ergänzt eine noch nicht enthaltene Adresse; bestehende Adressen bleiben erhalten. Deduplizierung berücksichtigt Groß-/Kleinschreibung. FN erhält DE/EN aus der Originalnachricht beziehungsweise der bereits vorgesehenen manuellen Sprachwahl. Eine verspätete ältere Ergänzung darf keine neuere, vom Bot protokollierte Sprachbeobachtung zurücksetzen. Unabhängige manuelle Änderungen in FN haben keinen auswertbaren Zellzeitstempel; sie werden nicht zeitlich verglichen. Bei mehrfacher WWID werden die passenden Zeilen gemeinsam aktualisiert, fremde WWIDs nicht.

Eine Adresse, die bereits bei einer anderen WWID steht, fremde FM/FN-Überschriften, Formeln, Zellfehler, geschützte oder verbundene Kontaktzellen und besondere Zellinhalte werden zur Prüfung zurückgestellt. Bestehende Fachspalten, Formeln, Formatierungen und andere ZIP-Bestandteile werden nicht durch einen vollständigen Excel-Neuaufbau ersetzt.

### Sperren, Sicherung und Wiederaufnahme

Der Windows-Schreibadapter hält die Datei vom Vergleich mit dem gelesenen Original über Sicherung und Schreibabsicht bis zum Schreiben und Zurücklesen exklusiv geöffnet. Vor der Änderung wird die vollständige Originaldatei unter `.runtime/workbook/backups` gesichert. Wird ein Schreibfehler erkannt, wird das Original nur innerhalb desselben gehaltenen Dateihandles zurückgeschrieben und geprüft.

Nach einem Prozess- oder Rechnerabbruch dient `.runtime/workbook/transactions` zur Klärung. Eine später fremd veränderte Datei wird nicht blind durch eine ältere Sicherung ersetzt. Das ist eine gesicherte Schreibtransaktion mit Wiederherstellungsnachweis, kein atomarer Dateiaustausch.

Ist Excel geöffnet oder die Datei gesperrt, bleibt die Ergänzung unter `.runtime/workbook/contacts` als **PENDING** erhalten. Nach dem Schließen der Datei wird sie beim nächsten Menü-2-, Phase-1-, Phase-2- oder Masterstart erneut versucht. Diese Wiederholung betrifft ausschließlich Excel. Sie kann keine E-Mail senden oder ein Ticket weiterleiten.

Typische Meldungen:

| Meldung | Bedeutung |
| --- | --- |
| BESTAND_EXCEL_NEU_EINGELESEN | Neuer fachlicher Bestand aktiviert |
| BESTAND_EXCEL_AKTUELL | Quelle erneut gelesen; fachliche Daten unverändert |
| BESTAND_KONTAKT_GESPEICHERT | FM/FN gespeichert und verifiziert oder bereits vorhanden |
| BESTAND_ERGAENZUNG_OFFEN | Ergänzung dauerhaft vorgemerkt; Grund wird angegeben |
| BESTAND_KONTAKT_NICHT_UEBERNOMMEN | Eigenkontakt nicht ausreichend belegt; keine FM/FN-Änderung |
| WORKBOOK_CONTACT_AFTER_COMPLETE | Kontaktupdate nicht bestätigt; Ticket bleibt abgeschlossen. Bei Speicherfehler kann auch die lokale Vormerkung fehlen. |

## Einordnung des gelieferten RC96-Protokolls

Der gezeigte Lauf ist technisch abgeschlossen: Phase 1 hat sieben Tickets mit Versand und Speicherung bestätigt, Phase 2 zwei Tickets ohne E-Mail weitergeleitet. Die sieben neuen Phase-1-Tickets hatten noch keinen Bearbeitungsauftrag in der zusätzlichen Beschreibung und wurden mit `NOT_REQUESTED` offengelassen. Sie sind damit nicht fachlich in Phase 2 erledigt. Die künftige LenX-Erstellung des Auftrags bleibt ein eigenes Phase-3-Thema.

## Prüfung und verbleibende Live-Abnahme

Der bestehende Testsatz deckt die Member-/Namensübernahme, Fokuszustände, Ein-Tab-Lifecycle, erweiterte Bestandsmerkmale, Quellaktualität, Mehrfachzeilen, E-Mail-/Sprachzuordnung, Warteschlange, ZIP-/OOXML-Erhaltung und die Trennung von Kontaktfehlern und abgeschlossenem Ticketversand ab. RC100 ergänzt die Prüfung des stabilen Suchtextes bei Fokuswechsel, der begrenzten Eingabewege und des Zurückstellens eines einzelnen nachweislich ungeänderten Tickets. Konkrete Testergebnisse beziehen sich auf den jeweils ausgeführten lokalen Prüflauf.

Der originale Fehlercode des Runners bleibt bei einer Weitergabe an den Master sichtbar, damit eine Sammelmeldung wie `LIVE_NOT_VERIFIED` die eigentliche Ursache nicht verdeckt. Der bestehende Wiederanlauf ordnet einen beendeten alten Lauf weiterhin anhand seiner lokalen Nachweise ein. Ungeklärte frühere Versandabsichten bleiben im Journal und sind vom automatischen Neuversand ausgeschlossen; abgeschlossene Tickets bleiben ebenfalls geschützt.

Zusätzlich enthält das Paket Windows-Tests für den nativen Dateischreibadapter mit ausschließlich temporären Testdateien; sie werden auf Linux übersprungen. Die erneute Prüfung der RC100-Member-Suche im produktiven Windows-/COMARCH-System steht aus. Dabei muss der vollständige Suchtext übernommen und anschließend das tatsächliche Personenprofil geprüft werden. Der erste Versandpilot bleibt an die neue Software-/Bestandsversion gebunden. Menü 2 ist dafür kein zusätzlicher Pflichtschritt.
