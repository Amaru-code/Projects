import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
import {requireThat as need,sha256} from '../lib/core.mjs';
import {
 createOwnedStartupTarget, connectBrowser, assertOwnedPageTarget,
 attachOwnedPage, detachOwnedPage,
} from '../lib/cdp.mjs';
import {browserLeaseEnvironment,validateBrowserLease} from '../lib/master-browser-lease.mjs';

const comarchUrl='https://comarchecm.mercer.com/';

/** Model a browser with restored tabs and a debugger that can publish a newly
 * created page later than the create response. No real COMARCH access. */
function startupBrowser({createdId='created-by-this-run',createdType='page',delayReads=0,
 missing=false,createError=null,activateError=null,createReply}={}){
 const calls=[],sessions=new Map(),loaders=new Map();let created=false,reads=0,nextSession=0;
 const targets=[
  {type:'page',targetId:'unrelated-blank',url:'about:blank'},
  {type:'page',targetId:'restored-comarch',url:comarchUrl},
  {type:'page',targetId:'old-marker',url:'about:blank',urlFragment:'#mcr-another-previous-run'},
 ];
 const original=structuredClone(targets);
 const cdp={calls,targets,sessions,original,async send(method,params={},sessionId=null){
  calls.push({method,params:structuredClone(params),sessionId});
  if(method==='Target.getTargets'){
   if(created&&!missing&&++reads>delayReads&&!targets.some(t=>t.targetId===createdId))
    targets.push({type:createdType,targetId:createdId,url:'about:blank'});
   return {targetInfos:structuredClone(targets)};
  }
  if(method==='Target.createTarget'){
   if(createError)throw createError;
   created=true;
   return createReply===undefined?{targetId:createdId}:createReply;
  }
  if(method==='Target.activateTarget'){
   if(activateError)throw activateError;
   assert.ok(targets.some(t=>t.targetId===params.targetId),'activate only an existing exact target');
   return {};
  }
  if(method==='Target.attachToTarget'){
   assert.ok(targets.some(t=>t.targetId===params.targetId&&t.type==='page'));
   const id='session-'+(++nextSession);sessions.set(id,params.targetId);
   if(!loaders.has(params.targetId))loaders.set(params.targetId,1);
   return {sessionId:id};
  }
  if(method==='Target.detachFromTarget'){sessions.delete(params.sessionId);return {};}
  if(['Runtime.enable','Page.enable','DOM.enable'].includes(method))return {};
  const target=targets.find(t=>t.targetId===sessions.get(sessionId));
  assert.ok(target,'page operation must have a bound session');
  if(method==='Page.getFrameTree')return {frameTree:{frame:{id:'frame-'+target.targetId,
   loaderId:'loader-'+loaders.get(target.targetId),url:target.url}}};
  if(method==='Page.navigate'){
   target.url=params.url;loaders.set(target.targetId,loaders.get(target.targetId)+1);
   return {frameId:'frame-'+target.targetId,loaderId:'loader-'+loaders.get(target.targetId)};
  }
  if(method==='Runtime.evaluate')return {result:{value:{ready:'complete',url:target.url}}};
  assert.fail('Unexpected CDP command: '+method);
 }};
 return cdp;
}
const count=(b,method)=>b.calls.filter(c=>c.method===method).length;
const foreignUnchanged=b=>assert.deepEqual(b.targets.filter(t=>b.original.some(o=>o.targetId===t.targetId)),b.original);


test('RC99: startup creates and binds an exact new page despite blank, restored and split-fragment tabs',async()=>{
 const b=startupBrowser();
 const id=await createOwnedStartupTarget(b,{intervalMs:0});
 assert.equal(id,'created-by-this-run');
 assert.equal(b.calls[0].method,'Target.getTargets');
 const create=b.calls.filter(c=>c.method==='Target.createTarget');
 assert.equal(create.length,1);
 assert.deepEqual(create[0].params,{url:'about:blank',newWindow:true,background:false});
 assert.deepEqual(b.calls.filter(c=>c.method==='Target.activateTarget').map(c=>c.params.targetId),[id]);
 assert.equal(count(b,'Target.attachToTarget'),0);
 assert.equal(count(b,'Page.navigate'),0);
 assert.equal(count(b,'Target.closeTarget'),0);
 foreignUnchanged(b);
});

test('RC99: an empty initial target list still gets one explicitly created startup window',async()=>{
 const b=startupBrowser();b.targets.length=0;
 const id=await createOwnedStartupTarget(b,{intervalMs:0});
 assert.equal(id,'created-by-this-run');assert.equal(count(b,'Target.createTarget'),1);
 assert.deepEqual(b.targets.map(t=>t.targetId),[id]);
});

test('RC99: delayed publication of the created target retries only readback, not window creation',async()=>{
 const b=startupBrowser({delayReads:3});
 const id=await createOwnedStartupTarget(b,{timeoutMs:1000,intervalMs:0});
 assert.equal(id,'created-by-this-run');assert.equal(count(b,'Target.createTarget'),1);
 assert.equal(count(b,'Target.getTargets'),5);
 assert.equal(count(b,'Target.activateTarget'),1);foreignUnchanged(b);
});

test('RC99: a create response reusing any pre-existing target cannot authorize that tab',async()=>{
 for(const existing of ['unrelated-blank','restored-comarch','old-marker']){
  const b=startupBrowser({createdId:existing});
  await assert.rejects(createOwnedStartupTarget(b,{timeoutMs:0}),{code:'BROWSER_OWNED_STARTUP_INVALID'});
  assert.equal(count(b,'Target.createTarget'),1);assert.equal(count(b,'Target.activateTarget'),0);
  assert.equal(count(b,'Page.navigate'),0);foreignUnchanged(b);
 }
});

test('RC99: missing or malformed creation IDs never select an existing page or create a second one',async()=>{
 for(const createReply of [{},{targetId:null},{targetId:''},{targetId:'has spaces'},{targetId:'x'.repeat(161)}]){
  const b=startupBrowser({createReply});
  await assert.rejects(createOwnedStartupTarget(b,{timeoutMs:0}),{code:'BROWSER_OWNED_STARTUP_INVALID'});
  assert.equal(count(b,'Target.createTarget'),1);assert.equal(count(b,'Target.activateTarget'),0);
  assert.equal(count(b,'Target.attachToTarget'),0);foreignUnchanged(b);
 }
});

test('RC99: a never-published created ID produces a startup-specific error and no replacement',async()=>{
 const b=startupBrowser({missing:true});
 await assert.rejects(createOwnedStartupTarget(b,{timeoutMs:0,intervalMs:0}),{code:'BROWSER_OWNED_STARTUP_MISSING'});
 assert.equal(count(b,'Target.createTarget'),1);assert.equal(count(b,'Target.activateTarget'),0);
 assert.equal(count(b,'Target.attachToTarget'),0);foreignUnchanged(b);
});

test('RC99: a returned service-worker target cannot be accepted as the startup page',async()=>{
 const b=startupBrowser({createdType:'service_worker'});
 await assert.rejects(createOwnedStartupTarget(b,{timeoutMs:0,intervalMs:0}),{code:'BROWSER_OWNED_STARTUP_INVALID'});
 assert.equal(count(b,'Target.createTarget'),1);assert.equal(count(b,'Target.activateTarget'),0);
 foreignUnchanged(b);
});

test('RC99: uncertain create failure is reported with its cause and is never retried',async()=>{
 const cause=Object.assign(new Error('No reply after create request'),{code:'CDP_TIMEOUT'});
 const b=startupBrowser({createError:cause});
 await assert.rejects(createOwnedStartupTarget(b,{timeoutMs:0}),error=>{
  assert.equal(error.code,'BROWSER_OWNED_STARTUP_FAILED');assert.equal(error.cause,cause);return true;
 });
 assert.equal(count(b,'Target.createTarget'),1);assert.equal(count(b,'Target.activateTarget'),0);
 foreignUnchanged(b);
});

test('RC99: activation failure keeps the original error and cannot launch another startup window',async()=>{
 const cause=Object.assign(new Error('Target closed during activation'),{code:'CDP_ERROR'});
 const b=startupBrowser({activateError:cause});
 await assert.rejects(createOwnedStartupTarget(b,{timeoutMs:0}),error=>{
  assert.equal(error.code,'BROWSER_OWNED_STARTUP_FAILED');assert.equal(error.cause,cause);return true;
 });
 assert.equal(count(b,'Target.createTarget'),1);assert.equal(count(b,'Target.activateTarget'),1);
 assert.equal(count(b,'Target.closeTarget'),0);foreignUnchanged(b);
});

test('RC99: transient localhost readiness failure retries the connection before any page operation',async()=>{
 const port=38999,requested=[],retries=[],connections=[];let fetches=0;
 const connected=await connectBrowser(port,{attempts:3,timeoutMs:100,delayMs:0,
  onRetry:r=>retries.push(r),
  fetchImpl:async url=>{
   requested.push(url);
   if(++fetches<3)throw Object.assign(new Error('Connection refused'),{cause:{code:'ECONNREFUSED'}});
   return {ok:true,json:async()=>({webSocketDebuggerUrl:`ws://127.0.0.1:${port}/devtools/browser/startup-test`})};
  },
  connectionFactory:url=>{
   const c={url,async connect(){connections.push('connect');},close(){connections.push('close');},send(){assert.fail('No page action while connecting');}};
   return c;
  },
 });
 assert.equal(fetches,3);assert.equal(retries.length,2);
 assert.ok(requested.every(url=>url===`http://127.0.0.1:${port}/json/version`));
 assert.deepEqual(connections,['connect']);assert.equal(connected.cdp.url,`ws://127.0.0.1:${port}/devtools/browser/startup-test`);
});

test('RC99: one created startup ID survives pilot, batch and Phase 2 with fresh sessions and lease binding',async()=>{
 const b=startupBrowser();const targetId=await createOwnedStartupTarget(b,{intervalMs:0});
 const masterId='2026-11-19T15-00-00_rc99',lease={port:38999,masterId,ownerPid:1234,targetId};
 const report={schema:'MCR_MASTER_RUN_V1',id:masterId,state:'PHASE1',manifestSha256:'a'.repeat(64),mappingSha256:'b'.repeat(64),browser:{port:lease.port,targetId}};
 const env=browserLeaseEnvironment(lease),claims={parentPid:1234,report,manifestSha:report.manifestSha256,mappingSha:report.mappingSha256};
 const sessions=[];
 for(const phase of ['pilot','batch','phase2']){
  if(phase==='phase2')report.state='PHASE2';
  assert.deepEqual(validateBrowserLease(env,{...claims,phase:phase==='phase2'?'PHASE2':'PHASE1'}),lease);
  const page=await attachOwnedPage(b,comarchUrl,{targetId,intervalMs:0});
  assert.equal(page.targetId,targetId);assert.equal(page.reusedOwnedTarget,true);sessions.push(page.sessionId);
  assert.deepEqual(await detachOwnedPage(page),{detached:true,targetRetained:true});
 }
 assert.equal(new Set(sessions).size,3);assert.equal(b.sessions.size,0);
 assert.equal(count(b,'Target.createTarget'),1);assert.equal(count(b,'Page.navigate'),3);
 assert.equal(count(b,'Target.closeTarget'),0);assert.equal(count(b,'Browser.close'),0);
 assert.ok(b.calls.filter(c=>c.method==='Target.attachToTarget').every(c=>c.params.targetId===targetId));
 foreignUnchanged(b);
});

test('RC99: losing a bound tab after startup still stops without adopting or creating a replacement',async()=>{
 const b=startupBrowser();const targetId=await createOwnedStartupTarget(b,{intervalMs:0});
 // Disable the simulated delayed target publisher after the successful startup.
 b.targets.splice(b.targets.findIndex(t=>t.targetId===targetId),1);
 const send=b.send.bind(b);
 b.send=async(method,...args)=>{
  if(method==='Target.getTargets'){
   b.calls.push({method,params:{},sessionId:null});
   return {targetInfos:structuredClone(b.targets)};
  }
  return send(method,...args);
 };
 const begin=b.calls.length;
 await assert.rejects(assertOwnedPageTarget(b,targetId),{code:'BROWSER_OWNED_TARGET_MISSING'});
 await assert.rejects(attachOwnedPage(b,comarchUrl,{targetId}),{code:'BROWSER_OWNED_TARGET_MISSING'});
 assert.ok(b.calls.slice(begin).every(c=>c.method==='Target.getTargets'));
 assert.equal(count(b,'Target.createTarget'),1);foreignUnchanged(b);
});


/** Execute the actual coordinator startup function, with only process and
 * transport boundaries replaced. This catches call-site wiring regressions
 * that a direct helper unit test cannot see. */
function masterStartup({createError=null}={}){
 const source=fs.readFileSync(new URL('../tools/cli.mjs',import.meta.url),'utf8');
 const start=source.indexOf(' async function launchOwnedBrowser(){');
 const end=source.indexOf(' async function browserReady(){',start);
 assert.ok(start>=0&&end>start,'master startup function can be isolated');
 const b=startupBrowser({createError}),result={},launches=[],logs=[],checkpoints=[];
 let killed=0,closed=0;
 b.close=()=>{closed++;};
 const child={kill:()=>{killed++;},exitCode:null,signalCode:null};
 const cfg={edgePath:'auto',profileDirectory:'/test/permanent-profile'};
 const context={result,rootDir:'/test/rc99',id:'2026-11-19T15-00-00_master99',process:{pid:1234},need,
  resolveConfig:root=>{assert.equal(root,'/test/rc99');return cfg;},
  findEdgeExecutable:input=>{assert.equal(input,'auto');return '/test/msedge.exe';},
  output:s=>logs.push(s),checkpoint:()=>checkpoints.push(structuredClone(result)),
  launchBrowser:async options=>{launches.push(structuredClone(options));return {port:38999,child};},
  connectBrowser:async port=>{assert.equal(port,38999);return {cdp:b};},
  createOwnedStartupTarget,browserLeaseEnvironment,
 };
 const harness=vm.runInNewContext('let ownedBrowser=null;\n'+source.slice(start,end)+
  '\n({run:launchOwnedBrowser,owned:()=>ownedBrowser})',context);
 return {harness,b,result,launches,logs,checkpoints,counts:()=>({killed,closed})};
}

test('RC99: actual master startup launches without a URL and records the directly created tab lease',async()=>{
 const h=masterStartup();await h.harness.run();
 assert.equal(h.launches.length,1);
 assert.deepEqual(h.launches[0],{executable:'/test/msedge.exe',userDataDir:'/test/permanent-profile',extraArgs:['--no-startup-window']});
 assert.equal(h.harness.owned().lease.targetId,'created-by-this-run');
 assert.equal(h.harness.owned().lease.masterId,'2026-11-19T15-00-00_master99');
 assert.equal(h.harness.owned().lease.ownerPid,1234);
 assert.equal(h.result.browser.targetId,'created-by-this-run');
 assert.equal(h.result.browser.ownership,'EXPLICIT_CDP_CREATE_TARGET');
 assert.equal(h.checkpoints.length,1);assert.deepEqual(h.counts(),{killed:0,closed:1});
 assert.equal(count(h.b,'Target.createTarget'),1);foreignUnchanged(h.b);
});

test('RC99: actual master startup failure kills only its launched child and preserves the cause',async()=>{
 const cause=Object.assign(new Error('Create response was lost'),{code:'CDP_TIMEOUT'});
 const h=masterStartup({createError:cause});
 await assert.rejects(h.harness.run(),error=>{
  assert.equal(error.code,'BROWSER_OWNED_STARTUP_FAILED');assert.equal(error.cause,cause);return true;
 });
 assert.equal(h.launches.length,1);assert.equal(count(h.b,'Target.createTarget'),1);
 assert.deepEqual(h.counts(),{killed:1,closed:1});
 assert.equal(h.harness.owned(),null);assert.equal(h.result.browser,undefined);assert.equal(h.checkpoints.length,0);
 foreignUnchanged(h.b);
});

test('RC99: actual standalone Phase 2 startup creates its own target before navigation',async()=>{
 const source=fs.readFileSync(new URL('../src/phase2-run.mjs',import.meta.url),'utf8');
 const start=source.indexOf('  let page=session?.page;');
 const end=source.indexOf("  say('Nach jedem verifizierten Abschluss",start);
 assert.ok(start>=0&&end>start,'Phase 2 startup block can be isolated');
 const b=startupBrowser(),launches=[],logs=[];
 const context={session:null,root:'/test/rc99',need,
  resolveConfig:()=>({edgePath:'auto',profileDirectory:'/test/permanent-profile',comarchUrl}),
  findEdgeExecutable:()=>'/test/msedge.exe',
  launchBrowser:async options=>{launches.push(structuredClone(options));return {port:38999};},
  connectBrowser:async port=>{assert.equal(port,38999);return {cdp:b};},
  createOwnedStartupTarget,attachOwnedPage,say:s=>logs.push(s),
 };
 const run=vm.runInNewContext('(async()=>{let browser,cdp,sharedPage=null;\n'+source.slice(start,end)+
  '\nreturn {browser,cdp,page,sharedPage};})',context);
 const result=await run();
 assert.equal(launches.length,1);
 assert.deepEqual(launches[0],{executable:'/test/msedge.exe',userDataDir:'/test/permanent-profile',extraArgs:['--no-startup-window']});
 assert.equal(result.page.targetId,'created-by-this-run');assert.equal(result.sharedPage,null);
 assert.equal(count(b,'Target.createTarget'),1);assert.equal(count(b,'Page.navigate'),1);
 assert.ok(b.calls.filter(c=>c.method==='Target.attachToTarget').every(c=>c.params.targetId==='created-by-this-run'));
 foreignUnchanged(b);
});


function phase1Startup({leased=false}={}){
 const source=fs.readFileSync(new URL('../src/local-bot-full-run.mjs',import.meta.url),'utf8');
 const start=source.indexOf('  const hasMasterLease=');
 const end=source.indexOf(' if(DEMO){await injectDemo(page',start);
 assert.ok(start>=0&&end>start,'Phase 1 startup block can be isolated');
 const b=startupBrowser(),launches=[],logs=[];let protectedInput=0;
 const root='/test/rc99',masterId='2026-11-19T15-00-00_master99';
 const lease={port:38999,masterId,ownerPid:1234,targetId:'leased-master-tab'};
 const manifest=Buffer.from('RC99 test manifest'),mapping={fileHash:'b'.repeat(64)};
 const report={schema:'MCR_MASTER_RUN_V1',id:masterId,state:'PHASE1',manifestSha256:sha256(manifest),mappingSha256:mapping.fileHash,browser:{port:lease.port,targetId:lease.targetId}};
 if(leased)b.targets.push({type:'page',targetId:lease.targetId,url:comarchUrl});
 const diag={browser:{launched:false}};
 const context={DEMO:false,root,path,need,sha256,mapping,diag,exe:'/test/msedge.exe',
  cfg:{profileDirectory:'/test/permanent-profile',comarchUrl},
  process:{env:leased?browserLeaseEnvironment(lease):{},ppid:1234,platform:'win32'},
  fs:{existsSync:file=>file===path.join(root,'.runtime/master','MCR_MASTER_RUN_'+masterId+'.json'),
   readFileSync:file=>{assert.equal(file,path.join(root,'MANIFEST.json'));return manifest;}},
  readJSON:file=>{assert.equal(file,path.join(root,'.runtime/master','MCR_MASTER_RUN_'+masterId+'.json'));return report;},
  validateBrowserLease,
  launchBrowser:async options=>{launches.push(structuredClone(options));return {port:38999};},
  connectBrowser:async port=>{assert.equal(port,38999);return {cdp:b};},
  createOwnedStartupTarget,attachOwnedPage,
  attachPage:()=>assert.fail('Real Phase 1 must not adopt a blank page using a URL predicate'),
  overlay:{protectInput:cdp=>{assert.equal(cdp,b);protectedInput++;}},log:s=>logs.push(s),
 };
 const run=vm.runInNewContext('(async()=>{let browser=null,cdp=null,sharedBrowser=false,ownedPage=null;\n'+source.slice(start,end)+
  '\nreturn {browser,cdp,sharedBrowser,ownedPage,page};})',context);
 return {run,b,launches,logs,diag,lease,protectedInput:()=>protectedInput};
}

test('RC99: actual standalone Phase 1 startup creates one owned target without a positional URL',async()=>{
 const h=phase1Startup();const result=await h.run();
 assert.equal(h.launches.length,1);
 assert.deepEqual(h.launches[0],{executable:'/test/msedge.exe',userDataDir:'/test/permanent-profile',headless:false,extraArgs:['--no-startup-window']});
 assert.equal(result.page.targetId,'created-by-this-run');assert.equal(result.sharedBrowser,false);assert.equal(result.ownedPage,null);
 assert.equal(count(h.b,'Target.createTarget'),1);assert.equal(count(h.b,'Page.navigate'),1);
 assert.equal(h.diag.browser.launched,true);assert.equal(h.diag.browser.freshBoundTarget,true);
 assert.equal(h.diag.browser.sharedMaster,false);assert.equal(h.protectedInput(),1);foreignUnchanged(h.b);
});

test('RC99: actual leased Phase 1 startup reuses its validated target without a second launch or creation',async()=>{
 const h=phase1Startup({leased:true});const result=await h.run();
 assert.equal(h.launches.length,0);assert.equal(count(h.b,'Target.createTarget'),0);
 assert.equal(result.page.targetId,h.lease.targetId);assert.equal(result.ownedPage,result.page);assert.equal(result.sharedBrowser,true);
 assert.equal(count(h.b,'Page.navigate'),1);assert.equal(h.diag.browser.launched,false);
 assert.equal(h.diag.browser.freshBoundTarget,false);assert.equal(h.diag.browser.reusedOwnedTab,true);
 assert.equal(h.diag.browser.sharedMaster,true);assert.equal(h.protectedInput(),1);foreignUnchanged(h.b);
});

function launcherAtProcessBoundary(){
 const source=fs.readFileSync(new URL('../lib/cdp.mjs',import.meta.url),'utf8');
 const start=source.indexOf('export async function launchBrowser(');
 const end=source.indexOf('export async function connectBrowser(',start);
 assert.ok(start>=0&&end>start,'browser process launcher can be isolated');
 const launches=[],child={exitCode:null,on:()=>{},kill:()=>assert.fail('No failed-start cleanup expected')};
 const context={path,
  fs:{mkdirSync:()=>{},rmSync:()=>{},existsSync:()=>true,readFileSync:()=> '38999\n/devtools/browser/test\n'},
  spawn:(executable,args,options)=>{launches.push({executable,args:structuredClone(args),options:structuredClone(options)});return child;},
  sleep:()=>assert.fail('The fake ready port should not wait'),
 };
 const launch=vm.runInNewContext(source.slice(start,end).replace(/^export /,'')+';launchBrowser',context);
 return {launch,launches,child};
}

test('RC99: actual process launcher omits an undefined URL argument completely',async()=>{
 const h=launcherAtProcessBoundary();
 const browser=await h.launch({executable:'/test/msedge.exe',userDataDir:'/test/profile',extraArgs:['--no-startup-window']});
 assert.equal(browser.port,38999);assert.equal(browser.child,h.child);assert.equal(h.launches.length,1);
 const call=h.launches[0];assert.ok(call.args.every(value=>typeof value==='string'));
 assert.equal(call.args.at(-1),'--no-startup-window');assert.ok(!call.args.includes('undefined'));
 assert.ok(!call.args.includes('about:blank'));assert.equal(call.options.windowsHide,false);
});

test('RC99: actual process launcher preserves the explicit about:blank headless demo argument',async()=>{
 const h=launcherAtProcessBoundary();
 await h.launch({executable:'/test/chromium',userDataDir:'/test/profile',startUrl:'about:blank',headless:true,extraArgs:['--disable-sync']});
 const args=h.launches[0].args;
 assert.equal(args.at(-1),'about:blank');assert.equal(args.filter(arg=>arg==='about:blank').length,1);
 assert.ok(args.includes('--headless=new'));assert.ok(args.includes('--disable-gpu'));
 assert.ok(args.includes('--disable-sync'));assert.ok(!args.includes('--no-startup-window'));
});
