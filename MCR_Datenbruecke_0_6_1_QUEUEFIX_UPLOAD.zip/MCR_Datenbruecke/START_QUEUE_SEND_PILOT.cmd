@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
echo ==============================================================
echo  MCR Queue + Send Pilot 0.6.1 - echte Ticketzeilen
Echo ==============================================================
echo.
set "NODE_EXE="
for %%N in (
  "C:\Users\Amaru-Zegarra\projects\Compiler\javascript\tools\node\node.exe"
  "%~dp0tools\node\node.exe"
) do if not defined NODE_EXE if exist "%%~N" set "NODE_EXE=%%~N"
if not defined NODE_EXE for /f "delims=" %%N in ('where node.exe 2^>nul') do if not defined NODE_EXE set "NODE_EXE=%%N"
if not defined NODE_EXE (
  echo FEHLER: node.exe nicht gefunden.
  pause
  exit /b 3
)
"%NODE_EXE%" "%~dp0src\verify-package.mjs"
if errorlevel 1 (
  echo Paketintegritaet fehlgeschlagen.
  pause
  exit /b 4
)
"%NODE_EXE%" "%~dp0src\local-bot-queue-send.mjs"
set "RC=%errorlevel%"
echo.
if not "%RC%"=="0" echo Runner wurde fail-closed beendet. Eine gesendete Nachricht NICHT erneut senden, wenn der Versandstatus unklar ist.
pause
exit /b %RC%
