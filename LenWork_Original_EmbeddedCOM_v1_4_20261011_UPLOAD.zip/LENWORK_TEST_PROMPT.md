# LenWork: Test der eingebetteten PowerShell-Quelle

Bitte benutze eine **Testkopie** des Skills `inbox-urlaub-rueckblicke-v2` mit der neuen `SKILL.md`. Lies die Skill-Datei einschließlich Step 1c vollständig.

Es gibt bewusst **keine separate ausführbare PS1-Datei**; die PowerShell-Quelle steht vollständig im SKILL.md und bleibt fachlich unverändert gegenüber der zuvor lokal getesteten Exportquelle.

## Phase A (ohne E-Mails)
1. Finde ein tatsächlich freigegebenes Tool, das `powershell.exe` unter Windows PowerShell 5.1 im Kontext des laufenden Outlook ausführt.
2. Führe einen harmlosen Inline-Befehl `Write-Output 'INLINE_PS_OK'` aus. Bestätige die echte PS-Version.
3. Prüfe lesend `GetActiveObject('Outlook.Application')`, MAPI und Inbox-Objektanzahl. Keine neuen COM-Instanzen starten.
4. Stelle fest, ob derselbe Toolkanal den vollständigen **im SKILL.md eingebetteten** Quelltext an die echte PowerShell übertragen darf und ob der SHA256-Hash stimmt. Führe für diesen Transporttest den Exporter noch nicht aus.
5. Berichte eindeutige tatsächlich beobachtete Werte für `INLINE_PS_TEST`, `MAPI_READ`, `SOURCE_HASH`, `CODE_TRANSPORT`; keine Vermutungen als PASS.

## Phase B (nur nach A=PASS und erlaubtem Zugriff)
1. Starte den eingebetteten PowerShell-Export für einen 1-Tages-Testzeitraum mit `-UnreadOnly` und `-PreviewChars 0`, bevor der eigentliche Klassifizierungslauf ausgeführt wird. Lies nur Inbox und bleibe READ-ONLY.
2. Übernimm den durch das Programm gemeldeten echten Laufordner. Prüfe Manifest, alle JSONL-Batches, Checksummen und Message-ID-Eindeutigkeit **über denselben erlaubten PowerShell-Kanal**.
3. Melde `LOCAL_EXPORT_STATUS`, `UNIQUE`, `BATCHES`, `ISSUES`, `MANIFEST_VERIFIED`, `BATCHES_INGESTED`, `LENWORK_IMPORT_STATUS`. Gib keine E-Mail-Inhalte, Absender oder IDs aus.
4. `READY_FOR_100PLUS_GENERATOR=YES` nur bei tatsächlich abgeschlossener Shell-Ausführung, validiertem Manifest und erfolgreicher Batch-Übernahme in LenWork. Andernfalls `BLOCKED` mit präzisem technischen Grund.

**Verboten:** Sicherheitsrichtlinien ändern, `ExecutionPolicy Bypass`, versteckte Tokens sammeln, Mailobjekte schreiben, fremde Systeme bedienen, frühere synthetische Dateien als echte Inbox-Ergebnisse ausgeben.
