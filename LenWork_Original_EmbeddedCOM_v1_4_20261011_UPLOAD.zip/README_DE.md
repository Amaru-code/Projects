# LenWork – Original-Skill + eingebetteter Outlook-Direktabruf (v1.4)

**Ziel:** Ein über LenWork teilbarer Skill, der auch bei 100+ ungelesenen E-Mails **am selben Kalendertag** potenziell Outlook COM verwenden kann, ohne dass jeder Empfänger eine `.ps1` selbst in Downloads installieren muss. Die fachlichen Priorisierungsabschnitte (Steps 2–4) und die Absenderregeln sind unverändert.

## Warum unterscheidet sich der Ansatz vom Kollegen?
Der Kollege arbeitet mit einer **echten PowerShell-Datei in seinem Arbeitsverzeichnis**, die lokal gegen das bereits laufende klassische Outlook ausgeführt wird. Unser bisheriger Versuch scheiterte daran, eine **virtuelle LenWork-Skill-Datei** über denselben Pfad an Windows PowerShell zu übergeben. Deshalb ist die getestete Exportquelle **zusätzlich als wörtlicher Codeblock in SKILL.md** eingebettet. LenWork muss ihn aus seinem Skill-Kontext über ein explizit freigegebenes Ausführungstool an die lokale PowerShell übertragen. Die konkrete Host-zu-LenWork-Datenübergabe bleibt live zu verifizieren.

## Dateien
- `SKILL.md`: komplette Steuerung und **genau eine eingebettete** `.ps1`-Exportquelle.
- `absender.md`: unverändert.
- `LENWORK_TEST_PROMPT.md`: erst harmloser Inline-Hosttest, dann bei PASS der echte Export.
- `MANIFEST_SHA256.json`: Prüfsummen der ausgelieferten Dateien.

In LenWork selbst nur **SKILL.md und absender.md** installieren. Keine bisherigen alten .ps1-/.py-Dateien, synthetischen Testmails oder SHA-Manifeste in den produktiven Skill übernehmen. Die Skriptquelle steht in SKILL.md und ist keine neue Priorisierungslogik.

## Kritische Grenze
Noch **kein nachgewiesener** End-to-End-PASS für Inline-Code→PowerShell→Outlook→LenWork. Die bisherigen Berichte belegen COM-Zugriff aus bestimmten Ausführungsumgebungen und 78 lokale exportierte Mails, aber nicht die erfolgreiche autonome Ausführung des eingebetteten Codeblocks. Wenn das benötigte Ausführungstool nur virtuelle Dateien lesen, jedoch keinen Code an den Host senden darf, kann kein Skill das ohne offizielle LenWork-/IT-Freigabe aufheben. Der Microsoft-365-Datums-Fallback bleibt.

## Nach erfolgreichem Test
- Outlook im klassischen Desktopmodus geöffnet lassen.
- Nutzer: „Priorisiere alle meine ungelesenen E-Mails.“
- LenWork: Vorbedingung prüfen, alle lokalen Inbox-Nachrichten abrufen (ohne 50er-Tool-Grenze), 25er Batches verifizieren, Originalpriorisierung anwenden.
- 100+ E-Mails am selben Tag nach dem erfolgreichen technischen Vorabtest qualifizieren.
