# Inbox catch-up after absence (Urlaubs-Rückblick)

## Goal
When the user comes back from vacation or another absence, read the emails received during that time and give a prioritized overview in German: what needs an answer now, what can wait, what is just for information, and what can be ignored.

## Hard rules
- READ-ONLY. Never send, reply, forward, delete, move, flag, categorize or mark any email as read. Drafts only if the user asks for them afterwards, and only shown in the chat.
- Output language is ALWAYS German, even if the user writes in English or the emails are in English.
- Use only what is in the emails. Do not invent deadlines, intentions or facts. If something is unclear, write "unklar".
- Before classifying anything, read the file absender.md from this skill (sender and subject rules). Its rules override your own judgment.

## Abrufvertrag – COM_HOST_BRIDGE v1.7.2 (vor jeder E-Mail-Abfrage)

**Für den normalen Satz „Priorisiere alle meine ungelesenen Emails“ MUSS der echte Reader laufen.**
Die ursprünglichen Steps 2–4 und `absender.md` bleiben unverändert; die Bridge verändert nur den Transport der `.ps1` zum Windows-Host.

- **COM zuerst, Graph niemals automatisch.** Kein `msgraph_email` vor oder anstelle eines erfolgreichen aktuellen COM-Laufs. Nach echtem COM-Blocker höchstens eine ausdrückliche Opt-in-Frage für unvollständigen Graph-Abruf; keine 50 E-Mails still als vollständig ausgeben.
- **Keine erfundenen Ausführungen.** Die Datei unter virtuellem `skills/...` existiert **nicht automatisch** auf Windows. Eine aus der SKILL.md abgelesene SHA256-Zeichenfolge ist **kein** durchgeführter Dateihash. `COM_STATUS=OK` ist ein Host-Nachweis, noch kein Export.
- **Windows PowerShell 5.1**, kein `pwsh`, kein Pyodide-`subprocess`, kein Download, keine Dateien aus früheren Testprojekten/Downloads, keine `ExecutionPolicy Bypass`-Schalter. Native Windows-Hostbefehle nur über den im Unternehmenskontext zugelassenen lokalen Hostkanal. Klassisches Outlook geöffnet lassen.
- **Bei „alle meine ungelesenen E-Mails“** `StartDate=1900-01-01`, `EndDate=lokaler heutiger Tag`; sonst exakt genannter Zeitraum bzw. standardmäßig letzte 14 Tage. Achtung: Nur der lokal synchronisierte Outlook-Inbox-Store ist erreichbar, nicht eine garantierte vollständige Cloud-Historie.
- **Schrittfolge:** Host-Cache prüfen → falls fehlend komprimierte, bytegenaue Reader-Quelle aus *diesem* Skill auf Windows materialisieren → Original-Reader über den stillen Host-Wrapper starten → *alle* verifizierten JSONL-Batches tatsächlich in LenWork lesen → Originalpriorisierung. Nie direkt den 17-KB-PowerShell-Code aus einer Chatantwort neu abtippen oder aus einem unvollständigen Textausschnitt rekonstruieren.
- **Fail closed:** Beim ersten echten Fehler `FETCH_STATUS=COM_BLOCKED`, dazu `BLOCKED_STAGE` und Exitcode, danach stoppen. Keine Encoding-Ursache behaupten, wenn nur `Command failed` bekannt ist. Keine weitere allgemeine COM-/UTF-8-Probe. Keine 50er-Fallback-Liste ohne ausdrückliche Zustimmung.

### Host-Bridge: verbindliche Ausführung (nur autorisierter Windows-Bash/Hostkanal)

**A. Einen einzigen schnellen Cachetest ausführen:**

```bash
powershell.exe -NoProfile -NonInteractive -Command 'try{$p=Join-Path $env:LOCALAPPDATA "LenWorkInboxReader\v1_7_0\Export-InboxReadOnly.ps1";if([IO.File]::Exists($p)-and (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()-eq"f2e696628536125fe5fb9f0f08da49328cdc54525626d7e72afa93bf852098ef"){[Console]::WriteLine("READER_CACHE=VALID")}else{[Console]::WriteLine("READER_CACHE=MISSING")}}catch{[Console]::WriteLine("READER_CACHE=ERROR");exit 20}'
```

Wenn `READER_CACHE=VALID`, sofort mit D fortfahren. Sonst B und C durchführen. Die lokale Cachedatei darf ausschließlich nach erneuter Prüfung auf exakt **f2e696628536125fe5fb9f0f08da49328cdc54525626d7e72afa93bf852098ef** verwendet werden; ein frischer Skill ist auf einem anderen PC auch ohne Cache ausführbar, *wenn* der Hostkanal eine Datei mit den folgenden erlaubten Schreibaufrufen erzeugen kann.

**B. Exakte Transportblöcke unten aus `SKILL.md` kopieren; NICHT umschreiben.** Ersetze in den beiden Befehlen exakt `__PART_1__` und `__PART_2__` mit dem jeweils vollständigen Inhalt zwischen den Datenmarkern. Nur die Base64-Zeichen übernehmen, **keine** Markdown-Anführungszeichen, Leerzeichen oder Zeilenumbrüche. Ein kaputter Transfer wird vor jeder Codeausführung durch die SHA256-Prüfung abgefangen. Die Befehle selbst enthalten nur ASCII und keine E-Mail-Daten.

```bash
powershell.exe -NoProfile -NonInteractive -Command '$p=Join-Path $env:LOCALAPPDATA "LenWorkInboxReader\transport_v1_7_0.b64";[IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($p))|Out-Null;[IO.File]::WriteAllText($p,"__PART_1__",[Text.Encoding]::ASCII);[Console]::WriteLine("TRANSFER_PART_1=OK")'
```

```bash
powershell.exe -NoProfile -NonInteractive -Command '$p=Join-Path $env:LOCALAPPDATA "LenWorkInboxReader\transport_v1_7_0.b64";[IO.File]::AppendAllText($p,"__PART_2__",[Text.Encoding]::ASCII);[Console]::WriteLine("TRANSFER_PART_2=OK")'
```

**C. Komprimierte Quelle dekomprimieren, per SHA256 attestieren und als physische `.ps1` unter dem eigenen `%LOCALAPPDATA%` speichern.** Kein Admin, keine Policy-Änderung; die im Skill unverändert mitgelieferte Datei ist die einzige autoritative Quelle. Ohne `MATERIALIZATION=PASS` nicht weiter.

```bash
powershell.exe -NoProfile -NonInteractive -Command '$ErrorActionPreference="Stop";try{$src=Join-Path $env:LOCALAPPDATA "LenWorkInboxReader\transport_v1_7_0.b64";$text=[IO.File]::ReadAllText($src,[Text.Encoding]::ASCII);if($text.Length -ne 7392){throw "WRONG_LENGTH"};$z=[Convert]::FromBase64String($text);$inputStream=[IO.MemoryStream]::new($z);$gzip=[IO.Compression.GZipStream]::new($inputStream,[IO.Compression.CompressionMode]::Decompress);$outStream=[IO.MemoryStream]::new();$gzip.CopyTo($outStream);$raw=$outStream.ToArray();$gzip.Dispose();$inputStream.Dispose();$outStream.Dispose();$sha=[BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash($raw)).Replace("-","").ToLowerInvariant();if($sha -ne "f2e696628536125fe5fb9f0f08da49328cdc54525626d7e72afa93bf852098ef"){throw "SHA_MISMATCH"};$dir=Join-Path $env:LOCALAPPDATA "LenWorkInboxReader\v1_7_0";[IO.Directory]::CreateDirectory($dir)|Out-Null;$target=Join-Path $dir "Export-InboxReadOnly.ps1";[IO.File]::WriteAllBytes($target,$raw);if((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $sha){throw "WRITE_MISMATCH"};[IO.File]::Delete($src);[Console]::WriteLine("MATERIALIZATION=PASS")}catch{[Console]::WriteLine("MATERIALIZATION=FAIL");exit 31}'
```

**D. Reader über isolierten Windows-Host-Unterprozess starten.** Der Unterprozess schreibt alle seine Textausgaben/Fehler direkt in lokale Dateien; der äußere Host gibt **nur ASCII-Maschinenstatus** an LenWork zurück. Das trennt die potenziell lokalisierte Windows-Fehlerausgabe vom UTF-8-dekodierenden Bash-Tool. Keine stillen Wiederholungen, kein Legacy-/Graph-Export.

Der folgende Befehl gilt für **„alle ungelesenen“**. Für einen expliziten Zeitraum nur die konstanten `$start`/`$end`-Werte korrekt setzen. Für den 14-Tage-Default denselben Zeitraum semantisch identisch wählen; keine Mailfilter-Regel ändern.

```bash
powershell.exe -NoProfile -NonInteractive -Command '$ErrorActionPreference="Stop";try{$reader=Join-Path $env:LOCALAPPDATA "LenWorkInboxReader\v1_7_0\Export-InboxReadOnly.ps1";if(-not [IO.File]::Exists($reader)-or (Get-FileHash -LiteralPath $reader -Algorithm SHA256).Hash.ToLowerInvariant() -ne "f2e696628536125fe5fb9f0f08da49328cdc54525626d7e72afa93bf852098ef"){throw "INVALID_READER"};$base=Join-Path $env:LOCALAPPDATA ("LenWorkInboxExports\LW_"+[guid]::NewGuid().ToString("N"));[IO.Directory]::CreateDirectory($base)|Out-Null;$stdout=Join-Path $base "child_stdout.txt";$stderr=Join-Path $base "child_stderr.txt";$end=(Get-Date).ToString("yyyy-MM-dd");$start="1900-01-01";$argsText=("-NoProfile -NonInteractive -File `""+$reader+"`" -StartDate "+$start+" -EndDate "+$end+" -UnreadOnly -ScanMode Auto -BatchSize 25 -PreviewChars 350 -OutputDir `""+$base+"`"");$psHost=Join-Path $env:WINDIR "System32\WindowsPowerShell\v1.0\powershell.exe";$clock=[Diagnostics.Stopwatch]::StartNew();$child=Start-Process -FilePath $psHost -ArgumentList $argsText -PassThru -Wait -RedirectStandardOutput $stdout -RedirectStandardError $stderr;$clock.Stop();if($child.ExitCode -ne 0){[Console]::WriteLine("READER_CHILD_EXIT="+$child.ExitCode);exit 41};$runs=@(Get-ChildItem -LiteralPath $base -Directory | Where-Object {$_.Name -like "InboxExport_*"});if($runs.Count -ne 1){throw "RUN_DIRECTORY_COUNT"};$r=$runs[0];$m=Get-Content -LiteralPath (Join-Path $r.FullName "manifest.json") -Raw -Encoding UTF8 | ConvertFrom-Json;if($m.status -ne "COMPLETE_LOCAL_STORE" -or $m.source -ne "classic_outlook_local_com" -or $m.reader_version -ne "1.7.0") {throw "INVALID_MANIFEST"};if(@($m.issue_codes|Where-Object {$_}).Count -ne 0 -or $m.unique_records -ne $m.readback_records){throw "INCOMPLETE_MANIFEST"};$files=@($m.files|Where-Object {$_.format -eq "jsonl"});if($files.Count -ne [int]$m.batch_count){throw "BATCH_COUNT"};$count=0;foreach($f in $files){$p=Join-Path $r.FullName ($f.path.Replace("/","\"));if(-not [IO.File]::Exists($p)){throw "BATCH_MISSING"};if((Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant() -ne $f.sha256){throw "BATCH_HASH"};$count += [int]$f.records};if($count -ne [int]$m.unique_records){throw "RECORD_COUNT"};[Console]::WriteLine("READER_EXEC=PASS");[Console]::WriteLine("SOURCE=CLASSIC_OUTLOOK_COM");[Console]::WriteLine("SCAN_STRATEGY="+$m.scan_strategy_used);[Console]::WriteLine("RUN_ID="+$r.Name);[Console]::WriteLine("EXPORTED_COUNT="+$m.unique_records);[Console]::WriteLine("BATCH_COUNT="+$m.batch_count);[Console]::WriteLine("READBACK_COUNT="+$m.readback_records);[Console]::WriteLine("COM_SCAN_MS="+$m.scan_duration_ms);[Console]::WriteLine("POWERSHELL_TOTAL_MS="+$m.total_duration_ms);[Console]::WriteLine("HOST_CHILD_WALL_MS="+$clock.ElapsedMilliseconds);[Console]::WriteLine("OUTPUT_PATH_UTF8_B64="+[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($r.FullName)));}catch{[Console]::WriteLine("READER_EXEC=FAIL");exit 42}'
```

Nur bei `READER_EXEC=PASS`, einer **neuen** Run-ID und `SOURCE=CLASSIC_OUTLOOK_COM` weiter. Manifest und Batches liegen im als UTF-8-Base64 gelieferten `OUTPUT_PATH_UTF8_B64`; keine alten Run-Verzeichnisse raten oder wiederverwenden. Ein `COM_STATUS=OK` ohne diese Daten ist kein Erfolg.

**E. Verbindlicher LenWork-Import:** Öffne nur das neue Manifest und alle dort aufgeführten JSONL-Dateien. Prüfe jede `sha256`, Datensatzanzahl, JSON-Lesbarkeit, eindeutige `message_id`, `is_unread=true`, Scope und `readback_records=unique_records`. Verwende einen durch den Host tatsächlich erreichbaren Dateizugriff; falls Textübertragung UTF-8-Probleme verursacht, sende den **Dateiinhalt** vom Windows-Host ausschließlich als UTF-8-Base64 und dekodiere ihn innerhalb der LenWork-Sandbox (Dekodieren benötigt keinen Pyodide-subprocess). Bei großen Batches dürfen die Daten *verlustfrei* in kleinere Teile zerlegt werden, mit Hash-Prüfung nach Zusammensetzen. Nie nur Dateinamen oder ein Manifest als `IMPORTED_COUNT` deklarieren. Keine Ausgabe der einzelnen Mailinhalte in technische Diagnoseprotokolle.

**F. Abschluss:** Priorisiere erst nach einem vollständig und nachweislich importierten Batchbestand gemäß den unten unveränderten Steps 2–4. Bericht: `SKILL_CONTRACT=COM_HOST_BRIDGE_v1.7.2`, `FETCH_SOURCE`, `READER_VERSION=1.7.0`, `RUN_ID`, `SCAN_STRATEGY`, `EXPORTED_COUNT`, `IMPORTED_COUNT`, `ANALYZED_COUNT`, `MISSING_COUNT`, `ISSUES`, `END_TO_END_RESULT`. `COMPLETE` nur wenn die drei Counts tatsächlich gleich sind und `MISSING_COUNT=0`; andernfalls `IMPORT_INCOMPLETE` oder `COM_BLOCKED` statt einer irreführenden Prioritätenliste.

### Komprimierte, kanonische Reader-Quelle (GZIP→Base64; nur TRANSPORT, keine neue Logik)

SHA256 nach Dekompression: `f2e696628536125fe5fb9f0f08da49328cdc54525626d7e72afa93bf852098ef`. Erwartete komprimierte Base64-Zeichen: `7392`; die zusammengefügten Teile geben exakt die gebündelte `Export-InboxReadOnly.ps1` v1.7.0 wieder.

BEGIN_READER_GZIP_B64_PART_1
H4sIAAAAAAAC/7U8a3PbRpLf+SumyqwCuRYhyom9Pnl1FYqkbCZ8HUHFyWl1CAQMRdggwAVAPeLVf9/unsFg8KAevoo/pERguqe7p9/TyD9eXZjW79PZ3BpZl40Fd7xOFAb3jN9tozhl0Yq5gZMkvstmuzSIoq9sFF5Fd8xP+SZht366ZmHE3nY7G54kzjVnWx53XCcIWOBv/NQElP/a+TFP2Gc/9KLbhM2jWx5baw5L3ppHzAk99rfSHn9j8S4M/fCa7UKPxyxd+wnbJTw2GzMkLgYyEzbpzUcsuvrC3TQhNLcxUJWwIIL92coPeGKyUcpCfgM4kKaEWc4NP2AWD70DNuABT/lBYxLhs/MQmT8xTRPe+Mk2cO4P2FngXFupk+4S8SKKWd9J+XUU+5wemY3GwEkdto2jFOjwo/CYRbt0u0sFAcyNwtTxQ7Zx/IBteOp4uByp3QJEmPpA1j2A8xuf3x5eRd695HG3DSLHA9b5hqURQDBnC7vccA9wxnA4QAcb8/BzFH9lPLzx4yjcAEKz8eq/Gxf9jQfMnYLIQYqt9mVj68TOptVg8O9ijn8D63FrAoQ4aRTfsxPWTOMdh5W05Fcn8OENnzsprAtbxv/90/v240MH/vtG/rdpZIuTNIZdLpsgqTgFcYBM/9qNhqGnb5OAGrrry+Z5iIqB0jsorp/dhj3PAyVMYHvDKL2dwNGASk+B1LrXp3AmIy85g+PUX2eEL5zwmreODthRt9u+vPDDFEAcoMfy/0SAN29rAboH7E03h5gLBeivnRhp/OFttwRl8bRl9HZpZBww49RJeOCHHASTC991wknkEY1iXVE4n9E4Jk78FYwwLMuHNHbgx8Rgo91oNIdxHMU90migbcVjHrqE20qjrdFo9ndBuovxyYV1n4AzMD8G0RUQ+6eDMKZ8PwpX0eXx8Si8cWLfCVP5uNEEA/+MUtIQDHznOoyS1HcTE3e5xfcATGo15betduMV67Er8AkB9w79EEXAEjf2tynzIjC2MEJrd9ETxT7Y0BqsnTnoOVa7gM0ti9YuogisxF+xVgcBcu7b7BsryOLnyA87oJlr1gQLOx7P+r1xbz4f9JY9ZkjbI3c4JG+ZGOyB8Dbn1q88TkAOS+cq4Kb6aU6cL+BDOkD3W9iNToEOpkPyZsYeJxkLJ+qZBoHwOz9lbxoPjRQMSmBpJm605SQqFCmqTOpvOIgPjDDhwzvHTVuahTLjHv51JpOO54FKZefZ1pCBlQ3v3GCX+Df8EZyZMe7DaILpDZz7pHUkkJOANGo7EDSqG+JZpOs4ukWNk0SzzS5J2RVn/zhhclcTRf4Azh1VqUaeqHhgQAxpZ2BpPIbfH1AjMIgEGBUgFjgxLUhgBfsd/iETgwFbRfHGScsybzRvQZG5Bz5BU95+FAQiACTmRx7y2HfNT06yBrvNzAzkFoIWZxAWPe1HG3DNPIaXsxictRO0hQrpbgf1xTAyhVGa21ryJBX62RkD07ETCGUtwOKj5f0Wg4WzamdIKpLSYZQxAdNJJgBNCPjnA/0XRMQdEH2r6XtjNEeQYMbgaGYiNuAMI2svCHBB0moteBIFN/wJwtsmPirQm+1xkv1lLmN/02qrBSQ4uUjJjF3cRL53mZ8aKmS2rC35eMhVM1/Xj3Yh6Cf/F+s+S2yQpPDNNr3/gCnRDoIRHrwLyBi4n6CDwT3LqyDqg4V7+0T70GhuhC/frwuw92zwu22dz+fj4WQ4XYIpMB6AZsOr0fR09ps9GS576KzQSHRfEclUDtR3ASyCTZsjtI1oa4GB+OBAwVHFydoJ4PA+8hTjwA2fUarVMmSSZva228B3yd0b0m9snK2PxyM3AEtIMawmW8flLQMTNkNzAlrgLRxzAokCRy+NqEIQnXqVqxtEO8+XVi32Nc+iAJLFREeVbaUinQIzKdzj2e4jo6BUSAWJPidO81C9zZV/vYt2iUqSaRULASV5qDLOIouKqMK6HOqhUUMLUl5Hi7Xlrr/yQekyWjaCv0NJE+y5AsX2CoQ1fcrqH5H32g88krXa9HkCRzhzwFcOhIMRuAVyRUi90TVYBzivCKcMrE7KoFgLUGB4e9fMIYPg8AayLKNdd545qwRaeX8FLH996UkQzvJu8kREwbQiYeXiR1lCFsfJP5BMRViChJ95Qlyy1AJunQTqriXWAVBPrEDXYrGQ4DQnIp2ZdAM1p0uGAlYpD0ScYOtdm7FXLArET9q17BWrrGbs9Z0QmcLUu0j4U7EZ3CuoFMICU5C2pVTnqNKvP+5Z1qiv1NgPk9TBJBSLJx9KPrEJg8wwW3N4y6/QCyPOZLdFT1vMmX7A+P2KyQgkROhfh9zrwGk4skS4XXP4cQNWg8kbayG2ILq+hnMCAhEG6AUE/HDjhP4KvHy7kE6qYiPTh9zz0mHwO3eNNcA5FLTqTPq7GFLsFJ+ZEnwYAiAe1lADKEe73DHpaMuaWKyAlO3oIOYcYqkT31ubdCuXVtRKHqUIUAWU2i8ZlM1lNMYkVqX+QDmIvg/uhGMU5CHllRlvzIP81qUKEU9yt4WS3o0jQC4bC7LZQEeGxg6r/a0PIkvMRlMUAZBnyGfIhNjphP307aGx2oWUmzGQZketmgcQlrBmltISNTLFg4NcSNlhFnOvZn7GQAokuiEzduHXEIqrzK82107Sd1E4KwfssUYVcvcak2vFnU1FXsWxNiHf3kHSSkVa4cVXfl99Sntl7xQ7Sr0K51n234JHAK3zoAXEBkc1PTbY65o9hAqPBnv3qu5MaDEusP2nCpkZdVWSX/g9AdQ7eiUuRdhejBeI5bJIWtmLZv9eMWuynGfuAjNlztGPVVT4Axv+pi3bOPdiaQSZa32akfMOfykuW8ZPFMo0jmhlNa/YQ3FV8yqy4hQenu17nkiS+F2RXM3j1PiZGkbK/qbyrlZ+QmvFrs+SVyZ0WvyEciAWie9JHRbr9ntCEUlLYaKSQ1FnKDZVxnSkO5s0MvYwVIF7Q+wpb4Ttt70slF39Ht9GXBJGnSbXzd6XwTDuKidsOSvemW3xbydY8ruS/8UsUfO/cyhLeJzet3MHmqFXaxDEVCtryKdUBEp3bEyfYMrQEdUM5Mv76/cxFL8XosF8aUCQ4Tz864r+JmWF2C2HhAKcxF+0i58ksMELZSB3QRlArRISdV0oUVHI2Q9vJ6pBQt7FUI9dSIYACaMrBQzdossOydlVwlORaamSSSRsCWZnVDebgCPrdDIe7jY8JvSI53YN+ZfMj9FfOnQHIN75occhvfAwsIMAfFCIKHbcgJuC/u/oOxIcSBV7/xT0TnvWcDyaDlEkmINTq6CXZv03kEcS7WK3+lyrwimRHtE9yon8ZdLPRl4iluCFaeeAokUh0RUw5YjIVFV3mGok6g/LQJM3zc1RMgd/BGLTPVI1bjS1xkZhOzM7uZZxIQ4aneYS3I1RjBwiUmTs5Og0dvLSJWMrX1ZcUD6a8+li2BvYi6G1XIz6S604KpQieTTvMS9yd5gHcu+A3fiJj2k/5GzBleN+pbQTkrP+bPJBXiU57GPsbNdqibmH4tJB7KU4UyZFs30+7f3aG417p+NhpbiT2lGnXlI9SpoBWSa2xeD90QcginUCXgeP716/LjZihLW/fv2YNtDN1olkmxQYNms39mQHGPcIgop4ohd/mn28AaTk4ccfMKTgvZkfVgIVaIHL/RvhH1VD
END_READER_GZIP_B64_PART_1

BEGIN_READER_GZIP_B64_PART_2
WqBYyFdLeFTdXgF2oD4t9J+BEO3t3m70Por8RJgQUnQVRYGkRhhAlY46exOmKNOXDF+7tGlxV8q6R7hpNZp28BAyMaugaFBONxqUSgdqioc8JVylCiLPqeR2e6uB2gSuiFsFaxJPRlbPxeuaKMZcM3vWMtZpuj0+PEwgvGycxNz4WApGq9R0o80h1suHW1ibOteH3buj7g9vu92jM6OanT6v6mj6XtZozdlkhuxhdvL6RgldlAai26xYJKDsp1iv8Z+3Zo295ZZfK1/ZvhaBm3rXLWMysqzR9KM9Gti9pT1aDie22LBdFUKmQk/lrBsVHip9ZV099fa4LE+Q8PZjJiITBc2PFBmXmVXWmBe1Tp5QvH79YR/qJyjX2v/F9EptVTGshNPIwQvsyiKIIT6WGb2xl09cKYqN79wGG51GxSlGt2hgUQwLuHf5U1WJZBPF9kXIrnY9MwdoO6ktBihOcq8IFYxIKVvaHd/y06fjzeYYuC1fH+r/FJ+S46r7iOBl69lSWEY1du66L8LR79fgUP0ke6vaQoB0T8Oog62aDHNWxuqtv6ogdiLZfgmhloCpodbfYK7siDt5LYyO1PMKCFRrcLgpFLTIASYoLQ2wl7/J7r2uU9atdSeQAyV07SPU6QWC12AhENWwldi7LJiqQFhZJVvpJ+hu8UKgKmtKbnCBHCyypTMXqm1DFDGe7w7Ld2kiby5MbAhZ1fWgYucWb+9eYui4vspTEwoYJ5S74qHH/Jrf0eUqKWwr2+qAGf9MXuOYCDPa5RvSAos6RnPMw2u8jwVOCryRtyrtXYQELRWhHYdaSrA1V1/grC4MvAu15dSTcVlGWdOHe9rRP7IT7VDMP1BSz2v37SHYeEyDsM9AIeZibvV3UMltRKl9icjaT1Yk0wjH6BJUFAp86HEgS4UDZvzO5aRDLEUVgsJEXkbIsbNiLVKXO0AhY1OFNFwsZov9+UPlYrxakGK6rpWkplaT6gdSpULaFG3cn51Pl3b/U2/6cTiwB+cLTGyGv81ni6X0EDoN1bJHI+LZ21uz80V/+Pz9iwdVg/BsNh4MF4hw0VuOZlMhXIB/0HoO1F1oyfmOp9KtcsIinTJ2V0sTCu39ZE1nS7s3HttQXw77S2CP9hoNLPsMuB4QfY0mzU1+T1fkykn4WeaMtbEPnNwQkwNnUPThr5Y2ZUXDX6Lc0IanSAEp3NKoT+eMhm/EUNFk4nn2p0+bDSQbbVhm0OKL6x3we3wMxHyEv6jRmqUpU3B9Bb/0XmyrqNVGuzQuBGXIGDBbtzZHYdAaDrmexvgguwEAsvoQu1KunrR0pG32b+x7daZ42d7cpav3mgAxNpjny7P3w9CNcH5TdvfENRI2o+heE6+2WuRollEvjp37FmK14F3W18tjSjW76wx44nIaD21jJ09cZJ7RzOr3Nkhd1EaSWLchmg7RaoV9PnjwgWU/RP0trmZJf/NXryEOqNnJTK0ztLJ6ED9RXBOhZRM/bOVQB0XcrJMhlxMq4MJXPt51tAyMAzYdiv2tezz48QEsb6W2k+tjHjg4/PIzeGPUWHnqh+QuJTJQSPMLvA9ESGji36QuJTXLdapVBW3nsDQn9b0tWuUqCwOf9b295sb7f++leR6JTcaZV6WJ8VPhQbsPx+zb0QOqJNQrSUHmB/IvLQrVoDbOoQzfUZOcUiecqP6ASWEAZRB1mq1fRuOxufFEa/hKVB74G2cI4p3kqRBdhL5+kar6RWipK9XzS6kv9kUog9S0C6W+8OYSbFCkueky6pDWgKltQQHesw525AsX65I7deiiLMWfpWv+ZxzmPmn98ccfiLCUbdespH3NLJ3MTvnChUzu8r/eYVq563bfdY12+zl7GvWZRHU4kFhT04HKeA40W8g9HDxFb6nGzTS3VZtvaaXwFpCeFOz5g5zwPDGECX7IlPJEnLwCTdbOm7fvTig64V54+1KaXFQ23+kF+HlAut4w61MPwNp0WVM3DkFSab/MYjP6J95j3mjjGbqRv8AZAaRmfE8dlkB9oBzJnoN6+WFVD2zi5ccFRO49q2eelxTKC09LO7GHbJTI8eiawE/UlDa74jjZwXAwahe6NMw0m0B6txwe0GzSF5xjhijs7pA3eJ1A5MI5llhi+wuvGbMtFkJ8WbCWcygrmmMNS6elQvG2okh5QiSATVyinIhxCHXoRZ4RqmzI4njZC39hndguzdZc5Po2xAFkULRteRa4JtmdnS/n50v7bDQe2rJBqulyoQ0qL1HENb21drJOzx5l2X6HqmhzALgBJe4kIKGcWmeyhgexAXIx6S37n4y2XgMRFmEKYhpYJhDVBmwzkNH9Ys8sNnFWMFXagcC0ikOUV7SvtLo95P9szaZj+xRplnVVhYVc1wI5Ly62e/zOUZ8pPT4eJZg4z+LPazgli4aLCUlbG0scTubL3226o61vl8oofRZHGxmnRyFUKDIJEtR1tM9gGFZBLyMqH4iKbs28BauTmXfy998LaF5B+M2n0Q7O5+NRv7cc7kH85DWUvMrCHVRTTt8AK0tx01oVb9HDaF3/+n7HXj1C7Ke9/i/2aPprbzzCO93+bDGoySzkZzdl3yYGtrVy4FG1Xc6WvXGd2hZwax8GvAj7+XT0P+dDqr0LyLXqO+sPNBP65DC7lJK4ar5GeMbth5FFHvuRrwXUGvrCybaWs8VQDO/m3xOU1lB/w8JF6lMuRX4WO2ruJMSNHqYu4+H082zxiz1bjD6OpoBRtIRE48X+9ciQc0QOwNs34vMphDsy/252xUv5iQRJQGDP5CYlSA9dqsM9dauhegztF15r4FWz/WcU6h+94V3z/8Ij+Z3bGPcwR57kFapvO5F38/m3V9pLKExsP8y/sco+pqIlwuhsqmjU3XKd3Tb23F/YcvbQjsW8c35F3dKnd+UXJY0Xdc5re/DY6bLxNOxYm2NSwyf5mkROP9i7RCzRRyLUshBOLfu+90RNIwjNx01tyvywpyGRSklXGpX5xupTCw1WgVV6i0LLxOWlTol8JE/JB1btWKVTBZdAS9RNJjhpPIxNJM5Cu+KkdaIXkYjvRvOWhvYu631kBbMkUFQM9sanwXqlK3vqCWVY6M50wkvuM5eat4vFfc9GHYSw+GHgbOEEJ34Q+AlAhRJK9KLLcJqn2weYRiloWQlOOZh9UOQhQTgeJTs/KZepqpG25FkqpU3dfDwMJdBST1Xq+C6sW1vXmRUAsn0GFBSrHY2Qh9w/zh/Jpo1sEbWHCk3GUimG7cJWAecBy3/vbUccdfMaDeqYCeRkkPF0UAfos4ee1R+NxP8LoHjDcMwcjHHyO3vQT+8wjMIONixBS8FCY6hkxIcenyIgoGVYy97y3DqhIlU45nZpAbXjT+QXHzYkwePZ7BcIxROjvLLfm0J8WkBm8/F3iVFzHaXVIqRQRM92L3mGGvTT4SBHDP6mtIQid7ZEOoLSEhHqJRI9PyguozR5KOWiuo6FJVkGJNaU7LPMrGWdZ9j0lKFOghMrZ3GvaZUARXqUQT5mk2UmzqeQ9iiwkYffcVNvG0vke4baQ9qm/hcRVG8l4lubNSIB5eq8Zx5HmBjD/H0CjtdZrejzKSicEeL0XgyfXlADXWueo2rifBEtaOVGVqJT1l7z3vKTjSD26bsfieoLaUGAahnhROq7H2XekO/bltc6xWRNXguLj4/eQrL0H/FiVTRvQwAA
END_READER_GZIP_B64_PART_2

## Step 1 – Scope
- If the user gives a period (e.g. "Urlaub 22.09.–06.10."), use exactly that period.
- If the user explicitly requests **alle meine ungelesenen E-Mails**, use the entire unread Inbox history available in the local store, not only the last 14 days.
- Otherwise: all UNREAD emails in the Inbox from the last 14 days. State this assumption in the first line of the answer.
- Inbox only, plus subfolders the user names explicitly. Skip Junk, Deleted Items and Archive.

## Step 1c – Microsoft-365-Mehrfachabruf (nur nach Opt-in; eingeschränkter Fallback)
**Nur nach expliziter Zustimmung des Nutzers zu einem eingeschränkten Alternativabruf und nur nach nachgewiesenem COM-Blocker.** Der Graph-Abruf ist kein normaler Ausführungszweig und darf bei der Standardanfrage nicht automatisch aufgerufen werden.


Wenn ein **zulässiger und verifizierter** lokaler COM-Export nicht verfügbar ist, darf `msgraph_email` **nur nach transparenter Meldung des COM-Blockers** als eingeschränkte Alternative verwendet werden. Der Benutzer kann diese Alternative wählen. Ein solcher Abruf ist **kein** COM-Erfolg und darf nie als COM-/100+-Einzeltag-Test gemeldet werden.

Nutze `msgraph_email`, `action: list`, `folder: inbox`, `count: 50`, korrektes `unread_only`, und das durch Step 1 bestimmte Datum. Sobald ein Intervall 50 Treffer zurückliefert, zerlege es in zwei **lückenlose, disjunkte** Kalendertagsintervalle. Rekursiv weiterteilen; nur ungesättigte Blattintervalle zählen, IDs deduplizieren. Ein einzelner Tag mit 50 Treffern bleibt `UNRESOLVED`, nicht `COMPLETE`. Niemals mehr als 50 an einem Tag als vollständig behaupten, solange die tatsächliche Abdeckung nicht unabhängig belegt ist. Keine fingierten `nextLink`-/`skip`-Parameter. `FETCH_SOURCE=MSGRAPH_FALLBACK`, `FETCH_STATUS=COMPLETE_UNDER_TOOL_CONTRACT` oder `INCOMPLETE`, entsprechend der tatsächlichen Nachweise.

## Step 2 – Metadata first, full text only when needed
1. List for every email: sender, whether the user is in To or only in CC, subject, received date, importance flag, attachments yes/no, conversation/thread, short preview.
2. Apply absender.md: everything matching "Ignorieren" goes straight to ⚪ without opening it.
3. Group by conversation/thread. Judge each thread by its LATEST message. If the question in a thread was already answered or solved by someone else, put it under "Bereits erledigt" and name who solved it.
4. If possible, check Sent Items for the same period: if the user already replied to a thread, mark it as "bereits beantwortet".
5. Open the full text only for emails that cannot be clearly classified as 🔵 or ⚪ from the metadata.
6. Work in batches of about 20–30 emails. Do not stop early; process all emails in scope.

## Step 3 – Priorities
🔴 Sofort beantworten (today):
- a direct question or request to the user (user in To)
- a deadline that has passed or is within the next 2 working days (mark passed ones as "ÜBERFÄLLIG")
- anything from a VIP in absender.md that contains a question or a deadline
- reminders and escalations ("Erinnerung", "dringend", "nochmals", 2nd follow-up)
- meeting requests for the next days that still need a response

🟡 Diese Woche:
- a request to the user without a tight deadline
- a deadline within the next ~2 weeks
- coordination where the user's input is expected

🔵 Zur Kenntnis:
- user only in CC, status updates, decisions already made, finished threads, past meeting invitations

⚪ Ignorierbar:
- newsletters, HR/IT mass mailings, marketing, automatic notifications, out-of-office replies, expired invitations

When in doubt between two levels, choose the higher one.

## Step 4 – Output (German, short)
Start with one line: Zeitraum, Anzahl gelesener E-Mails, Verteilung (🔴 x / 🟡 x / 🔵 x / ⚪ x).

### 🔴 Sofort beantworten
Table: Nr. | Von | Betreff | Worum geht es (1 Satz) | Was wird von dir erwartet | Frist

### 🟡 Diese Woche
Same table.

### 🔵 Zur Kenntnis
One line per thread: Von – Betreff – Kernaussage in 1 Satz.

### ⚪ Ignorierbar
Counts by group only, no details (e.g. "HR-Rundmails: 4, Newsletter: 7, Systembenachrichtigungen: 12").

### 📅 Fristen und Termine
Chronological list of all deadlines and dates found: Datum – was – von wem.

### ✅ Bereits erledigt / beantwortet
One line each: Betreff – erledigt durch wen.

End with exactly one question: "Soll ich für die 🔴-Mails Antwortentwürfe vorbereiten?"
Keep every summary to one sentence. No long quotes from emails.
