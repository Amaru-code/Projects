# Absender- und Betreff-Regeln

Eine Regel pro Zeile. Muster: Name, E-Mail-Adresse, Domain (@firma.de) oder Stichwort im Betreff.
Diese Regeln haben Vorrang vor der eigenen Einschätzung des Modells.

## VIP – mindestens 🟡, bei Frage oder Frist 🔴
- [Führungskraft]
- [Wichtige Kolleg*innen im Team]
- [Mandanten-Domains]

## Immer 🔵 Zur Kenntnis
- [Team-Verteiler]
- [Projekt-Statusmails]

## Immer ⚪ Ignorieren – ohne Öffnen
- Absender enthält: noreply, no-reply, donotreply, notifications, mailer
- [HR-Rundmails: z. B. hr-info@...]
- [Interne Newsletter: ...]
- [IT-/System-Benachrichtigungen: SharePoint, Teams, Workday, ServiceNow ...]
- Betreff enthält: Newsletter, Webinar, Umfrage, Survey, Abwesenheitsnotiz, Automatische Antwort, Out of Office
- HRDeutschland.MMC@mmc.com
- HRservices@mmc.com
- KM-Deutschland@mercer.com
- MarshDeutschland@marsh.com
- europe@marsh.com
- europe.update@marsh.com
- marshupdate@marsh.com
- Tech.Support@mmc.com
- CTVOICESupport@mmc.com
- ESSOperationSupport@mercer.com
- CentralEuropeServiceDesk@mercer.com


## Ausnahmen (stärker als "Ignorieren")
- HR- oder IT-Mail mit persönlicher Frist an mich (Pflichtschulung, Zeiterfassung, Passwortablauf, Freigabe) → 🟡, bei Frist in ≤ 2 Arbeitstagen → 🔴
- Einladung zu einem Termin, bei dem ich Pflichtteilnehmer*in bin → nie ⚪
