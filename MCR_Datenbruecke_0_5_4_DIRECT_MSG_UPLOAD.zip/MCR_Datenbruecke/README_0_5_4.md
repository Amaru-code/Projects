# MCR Local Runner 0.5.4

## Ziel

0.5.4 schließt die letzte manuelle Dateiauswahl im normalen Einzelticket-Lauf: Die Original-Mail wird aus den `GetFile?docId=...`-Links des geöffneten COMARCH-Tickets direkt über die bereits angemeldete Edge-Sitzung geladen.

## Mail-Regel

1. Im Nachrichtenverlauf werden alle sichtbaren Mailzeilen mit `GetFile?docId=...` ermittelt.
2. Die visuell unterste / neueste Mail wird zuerst versucht.
3. Der Abruf erfolgt zuerst im authentifizierten COMARCH-Seitenkontext.
4. Falls das nicht möglich ist, verwendet der lokale Node-Runner die Cookie-Sitzung des gestarteten Edge-Browsers für denselben `GetFile`-URL.
5. Nur eine echte Outlook-MSG mit Compound-File-Magic wird akzeptiert.
6. Falls die neueste Mail nicht abrufbar ist, wird die vorherige Mail desselben Tickets versucht. Für diesen Workstream dient die Mail nur der Personenzuordnung.
7. Erst wenn kein direkter Abruf funktioniert, bleiben Browserklick und manueller Download als letzte Fallbacks bestehen.

Kein allgemeiner `Downloads`-Ordner wird als Datenquelle verwendet.

## Unverändert

- eindeutiger Member: automatischer echter Browser-Mausklick
- mehrere Member: menschliche Auswahl
- MercerID aus dem tatsächlich übernommenen COMARCH-Member
- JSON-Bestandslookup
- Beschreibung, Second Level, Kategorien, Signatur und Antwortvorbereitung
- harter Stopp vor `Senden` und `Ticket speichern`

## Start

ZIP vollständig entpacken und `START_LOCAL_BOT.cmd` ausführen.

## Qualifikation

- 379/379 Node-Tests PASS
- vollständiger headless Chromium-Demolauf PASS
- Demo bestätigt direkten MSG-Abruf ohne Browser-Downloaddialog
- ZIP/Manifest/Hashes werden vor Auslieferung neu erzeugt und geprüft

Der echte Windows-/COMARCH-Lauf bleibt die maßgebliche Produktionsqualifikation.
