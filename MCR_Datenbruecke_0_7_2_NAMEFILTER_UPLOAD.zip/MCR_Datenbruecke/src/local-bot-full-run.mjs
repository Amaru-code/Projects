import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import http from 'node:http';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
import readline from 'node:readline/promises';
import {stdin as input, stdout as output} from 'node:process';
import {findEdgeExecutable, launchBrowser, connectBrowser, attachPage, sleep} from '../lib/cdp.mjs';
import {sha256} from '../lib/core.mjs';
import {writeZip} from '../lib/zip.mjs';

const require = createRequire(import.meta.url);
const Core = require('../lib/data-core.cjs');
const Msg = require('../lib/msg.cjs');
const Person = require('../lib/person.cjs');
const Prep = require('../lib/ticket-prep.cjs');
const MailDownload = require('../lib/mail-download.cjs');
const QueueSend = require('../lib/queue-send.cjs');
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

const argv = new Set(process.argv.slice(2));
const DEMO = argv.has('--demo');
const AUTO = argv.has('--auto');
const HEADLESS = argv.has('--headless');
const KEEP_BROWSER = !argv.has('--close-browser');
const FULL_RUN = argv.has('--full-run') || DEMO;
const MAX_TICKETS = Number(process.env.MCR_MAX_TICKETS || 100);

const diag = {
  schema:'MCR_LOCAL_RUNNER_DIAGNOSTIC_V1', version:'0.7.2-FULL-QUEUE-LOOP-NAMEFILTER', createdAt:new Date().toISOString(),
  mode: DEMO?'DEMO':'REAL', mapping:{loaded:false,sourceConfirmed:false}, browser:{launched:false,connected:false,comarchReady:false},
  mail:{downloaded:false,parsed:false,personAuto:false,personManual:false,downloadPolicy:null,downloadMethod:null,downloadCandidates:0,downloadAutoClicked:false,downloadFallbackManual:false,directFetch:false,historyRows:0,source:null,historyContentUsed:false}, member:{searchStarted:false,autoClicked:false,manualGate:false,selected:false,commitSource:null,profileMatched:false},
  queue:{scanned:false,method:null,scope:null,validTicketRows:0,eligible:0,skippedNonBlank:0,selected:false,openMethod:null,ticketBound:false}, edit:{attempted:false,method:null,ready:false},
  lookup:{attempted:false,ready:false}, description:{written:false,verified:false,route:null,candidates:null}, fixed:{responsibility:false,category:false,subcategory:false,signature:false},
  reply:{generated:false,written:false,verified:false,salutationSource:null},
  send:{armed:false,clicked:false,jsDialogs:0,htmlDialogs:0,historyBefore:null,historyAfter:null,verified:false,acknowledged:false,ackMode:null,refreshAttempted:false},
  save:{clicked:false,verified:false,verification:null},
  loop:{armed:false,processed:0,myTasksProcessed:0,queueProcessed:0,completed:false,finishReason:null,maxTickets:MAX_TICKETS,processedTickets:[]},
  readyBeforeSend:false, automaticSend:true, automaticSave:true, lastError:null,
  privacy:'No names, IDs, email addresses, mail text, mapping values, paths, URLs, selectors, cookies or page content.'
};

function log(s=''){console.log(s);}
function heading(s){console.log('\n==============================================================\n '+s+'\n==============================================================');}
function fail(code,message){const e=new Error(message);e.code=code;throw e;}
function need(ok,code,message){if(!ok)fail(code,message);}
function clean(v){return String(v??'').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();}
function norm(v){return clean(v).toLocaleLowerCase('de-DE').replace(/[.,]/g,'').replace(/\s+/g,' ');}
function escHtml(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
function nowStamp(){return new Date().toISOString().replace(/[:.]/g,'-');}

function readJson(p){return JSON.parse(fs.readFileSync(p,'utf8'));}
function resolveConfig(){
  const p = path.join(root,'config','local-runner-queue-send.json');
  const cfg = fs.existsSync(p)?readJson(p):{};
  const localRel = v => String(v).split(/[\\/]+/).join(path.sep);
  const runtime = path.resolve(root, localRel(cfg.runtimeDirectory || '.runtime'));
  return {
    ...cfg,
    runtimeDirectory:runtime,
    profileDirectory:path.resolve(root,localRel(cfg.profileDirectory || path.join('.runtime','edge-profile'))),
    downloadDirectory:path.resolve(root,localRel(cfg.downloadDirectory || path.join('.runtime','downloads'))),
    diagnosticDirectory:path.resolve(root,localRel(cfg.diagnosticDirectory || 'diagnostics')),
    comarchUrl:cfg.comarchUrl || 'https://comarchecm.mercer.com/DMSWWW/main.jspx'
  };
}

function validateMappingObject(obj){
  Core.validateMap(obj);
  need(sha256(JSON.stringify(obj.payload))===obj.payloadSha256,'MAP_HASH_MISMATCH','Mapping-Payload-Prüfsumme stimmt nicht.');
  return obj;
}
function autoMapping(cfg){
  if (DEMO) return {path:path.join(root,'examples','DEMO_mapping.json'),map:validateMappingObject(readJson(path.join(root,'examples','DEMO_mapping.json')))};
  const candidates=[];
  if(cfg.mappingPath) candidates.push(cfg.mappingPath);
  const dirs=[cfg.mappingDirectory, path.join(root,'private_data')].filter(Boolean);
  for(const d of dirs){
    if(!fs.existsSync(d))continue;
    for(const name of fs.readdirSync(d))if(/^INTL01_mapping_.*\.json$/i.test(name)){
      const p=path.join(d,name);try{candidates.push(p);}catch{}
    }
  }
  const unique=[...new Set(candidates.map(p=>path.resolve(p)))].filter(fs.existsSync).sort((a,b)=>{
    const ag=/INTL01_mapping_gender_/i.test(path.basename(a)), bg=/INTL01_mapping_gender_/i.test(path.basename(b));
    if(ag!==bg)return ag?-1:1;
    if(cfg.mappingPath && path.resolve(cfg.mappingPath)===a)return -1;if(cfg.mappingPath&&path.resolve(cfg.mappingPath)===b)return 1;
    return fs.statSync(b).mtimeMs-fs.statSync(a).mtimeMs;
  });
  for(const p of unique){try{return {path:p,map:validateMappingObject(readJson(p))};}catch(e){log('Mapping übersprungen: '+path.basename(p)+' ('+(e.code||e.message)+')');}}
  fail('MAP_NOT_FOUND','Kein gültiges INTL01-Mapping gefunden. config/local-runner.json oder private_data prüfen.');
}

function docsHelper(){
  const out=[];function walk(doc,depth){if(!doc||depth>6||out.length>=40||out.includes(doc))return;out.push(doc);for(const f of doc.querySelectorAll('iframe,frame'))try{walk(f.contentDocument,depth+1)}catch{}}walk(document,0);return out;
}
function visibleHelper(n){try{return !!n?.isConnected&&n.getClientRects().length>0&&getComputedStyle(n).visibility!=='hidden'&&getComputedStyle(n).display!=='none'}catch{return false}}

async function pageHost(page){return await page.eval('location.hostname');}
async function waitComarch(page){
  if(DEMO)return;
  log('\nEdge wurde als eigener MCR-Browser gestartet.');
  log('Falls nötig: dort anmelden. Öffne anschließend EIN Ticket. Der Runner wartet automatisch.');
  const deadline=Date.now()+180000;
  while(Date.now()<deadline){
    const host=await pageHost(page).catch(()=>null);
    if(host==='comarchecm.mercer.com'){diag.browser.comarchReady=true;return;}
    await sleep(500);
  }
  fail('COMARCH_LOGIN_TIMEOUT','COMARCH wurde im Runner-Browser nicht innerhalb von 3 Minuten erreicht.');
}


async function queueTableSnapshot(page){return await page.call(function(){
  const clean=v=>String(v??'').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();
  const low=v=>clean(v).toLocaleLowerCase('de-DE');
  const visible=n=>{try{const w=n.ownerDocument.defaultView,s=w.getComputedStyle(n);return !!n.isConnected&&n.getClientRects().length>0&&s.display!=='none'&&s.visibility!=='hidden'}catch{return false}};
  const aliases={ticket:['ticket-id','ticket id'],source:['quelle'],description:['zusätzliche beschreibung','zusaetzliche beschreibung']};
  const headerIndex=(headers,names)=>headers.findIndex(h=>names.some(a=>low(h)===a||low(h).includes(a)));

  // COMARCH uses different physical tables for the two work sources we support:
  // - Meine Vorgänge > In_Bearbeitung
  // - Warteschlange > INTL01
  // Prefer these observed IDs and only fall back to semantic header discovery.
  // A filter/search row must never become a ticket.
  const known=[
    {id:'mainForm:tasksTableFor_MyTasksList',method:'EXACT_MY_TASKS',scope:'IN_BEARBEITUNG'},
    {id:'mainForm:tasksTableFor_MyQueuesTasksList',method:'EXACT_INTL01_QUEUE',scope:'WARTESCHLANGE_INTL01'}
  ];
  const candidates=[];
  for(const k of known){const t=document.getElementById(k.id);if(t&&visible(t))candidates.push({table:t,method:k.method,scope:k.scope});}
  if(!candidates.length){
    for(const table of document.querySelectorAll('table')){
      if(!visible(table))continue;
      const txt=low(table.tHead?.innerText||table.tHead?.textContent||'');
      if((txt.includes('ticket-id')||txt.includes('ticket id'))&&txt.includes('quelle')&&(txt.includes('zusätzliche beschreibung')||txt.includes('zusaetzliche beschreibung'))){
        const id=table.id||'';
        const scope=id.includes('MyQueuesTasksList')?'WARTESCHLANGE_INTL01':id.includes('MyTasksList')?'IN_BEARBEITUNG':'HEADER_DISCOVERY';
        candidates.push({table,method:'HEADER_DISCOVERY',scope});
      }
    }
  }
  if(candidates.length!==1)return {ok:false,state:candidates.length?'AMBIGUOUS_QUEUE':'NO_QUEUE',tableCount:candidates.length,rows:[]};
  const {table,method,scope}=candidates[0];

  // Keep this callback deliberately ES5-style for COMARCH/ICEfaces pages.
  // Old Prototype/ICEfaces code can interfere with iterator helpers such as
  // HTMLCollection -> spread -> entries(). Use only numeric loops/array-like access.
  const headRows=[];
  const theadRows=(table.tHead&&table.tHead.rows)?table.tHead.rows:[];
  for(let hi=0;hi<theadRows.length;hi++)headRows.push(theadRows[hi]);
  const headerCandidates=[];
  for(let hi=0;hi<headRows.length;hi++){
    const tr=headRows[hi],headers=[];
    for(let ci=0;ci<tr.cells.length;ci++)headers.push(clean(tr.cells[ci].innerText||tr.cells[ci].textContent));
    const hc={index:hi,headers,ticketIndex:headerIndex(headers,aliases.ticket),sourceIndex:headerIndex(headers,aliases.source),descriptionIndex:headerIndex(headers,aliases.description)};
    if(hc.ticketIndex>=0&&hc.sourceIndex>=0&&hc.descriptionIndex>=0)headerCandidates.push(hc);
  }
  if(headerCandidates.length!==1)return {ok:false,state:'HEADER_NOT_UNIQUE',tableCount:1,headerCount:headerCandidates.length,rows:[]};
  const h=headerCandidates[0],body=table.tBodies&&table.tBodies.length?table.tBodies[0]:null;
  if(!body)return {ok:false,state:'NO_TBODY',tableCount:1,rows:[]};

  const rows=[];
  for(let index=0;index<body.rows.length;index++){
    const tr=body.rows[index];
    if(!visible(tr))continue;
    const cells=[];
    for(let ci=0;ci<tr.children.length;ci++){const child=tr.children[ci];if(child&&child.tagName==='TD')cells.push(child);}
    const max=Math.max(h.ticketIndex,h.sourceIndex,h.descriptionIndex);
    if(cells.length<=max)continue;
    const ticketCell=cells[h.ticketIndex];
    const sourceCell=cells[h.sourceIndex];
    const descriptionCell=cells[h.descriptionIndex];
    const ticketId=clean(ticketCell&&(ticketCell.innerText||ticketCell.textContent));
    // Critical guard: only real task rows have a numeric ticket ID. Search/filter rows
    // ("Suchen…") and decorative rows are excluded here.
    if(!/^\d{6,12}$/.test(ticketId))continue;
    const source=clean(sourceCell&&(sourceCell.innerText||sourceCell.textContent));
    const desc=clean(descriptionCell&&(descriptionCell.innerText||descriptionCell.textContent));
    const r=tr.getBoundingClientRect(),tc=ticketCell&&ticketCell.getBoundingClientRect?ticketCell.getBoundingClientRect():null;
    let action=null;
    const actionNodes=tr.querySelectorAll('a,input,button,img,label,span');
    for(let ai=0;ai<actionNodes.length;ai++){
      const n=actionNodes[ai];if(!visible(n))continue;const rr=n.getBoundingClientRect();if(rr.width<1||rr.height<1)continue;
      action={x:rr.left+rr.width/2,y:rr.top+rr.height/2};break;
    }
    rows.push({index,ticketId,descriptionBlank:desc==='',source,row:{x:r.left+r.width/2,y:r.top+r.height/2},ticket:{x:tc?tc.left+tc.width/2:r.left+r.width/2,y:tc?tc.top+tc.height/2:r.top+r.height/2},action});
  }
  return {ok:true,state:rows.length?'READY':'READY_EMPTY',method,scope,tableId:table.id||'',headerRow:h.index,indexes:{ticket:h.ticketIndex,source:h.sourceIndex,description:h.descriptionIndex},tbodyRows:body.rows.length,validTicketRows:rows.length,tableCount:1,rows};
});}

async function detailTicketId(page){return await page.call(function(){
  const clean=v=>String(v??'').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();
  const visible=n=>{try{const s=getComputedStyle(n);return !!n&&n.getClientRects().length>0&&s.display!=='none'&&s.visibility!=='hidden'}catch{return false}};
  const found={};let count=0,last=null;
  const nodes=document.querySelectorAll('label,span,b,strong,h1,h2,td,div');
  for(let i=0;i<nodes.length;i++){
    const n=nodes[i];if(!visible(n))continue;const t=clean(n.textContent);if(!t||t.length>120)continue;
    let m=t.match(/^Ticket[\s-]*ID\s*:?\s*(\d{6,12})$/i);
    if(m&&!found[m[1]]){found[m[1]]=true;count++;last=m[1];continue;}
    if(/^Ticket[\s-]*ID\s*:?$/i.test(t)){
      const candidates=[];
      if(n.nextElementSibling)candidates.push(n.nextElementSibling);
      if(n.parentElement&&n.parentElement.nextElementSibling)candidates.push(n.parentElement.nextElementSibling);
      for(let j=0;j<candidates.length;j++){
        const v=clean(candidates[j]&&candidates[j].textContent);if(/^\d{6,12}$/.test(v)&&!found[v]){found[v]=true;count++;last=v;}
      }
    }
  }
  return count===1?last:null;
});}

async function detailOpened(page,expected,timeoutMs=4500){
  const until=Date.now()+timeoutMs;while(Date.now()<until){
    const id=await detailTicketId(page).catch(()=>null);if(id&&(!expected||id===expected))return true;
    const has=await page.call(function(){const m=document.getElementById('mainForm:member-value-id');if(m&&m.getClientRects().length)return true;return [...document.querySelectorAll('input,button,a')].some(n=>n.getClientRects().length&&String(n.value||n.textContent||'').trim()==='Bearbeiten');}).catch(()=>false);
    if(has)return true;await sleep(180);
  }return false;
}

async function clickQueueRowByDom(page,ticketId,mode){return await page.call(function(ticketId,mode){
  const clean=v=>String(v??'').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();
  let tr=null;for(const row of document.querySelectorAll('tbody tr')){if([...row.cells].some(td=>clean(td.textContent).includes(ticketId))){tr=row;break;}}
  if(!tr)return {ok:false};
  const exact=[...tr.querySelectorAll('a,input,button,label,span,td')].find(n=>clean(n.textContent||n.value)===ticketId);
  const target=exact?.closest('a,button,input')||exact||tr;
  if(mode==='CLICK'){target.click();return {ok:true};}
  if(mode==='MOUSE'){const w=target.ownerDocument.defaultView;for(const type of ['mousedown','mouseup','click'])target.dispatchEvent(new w.MouseEvent(type,{bubbles:true,cancelable:true,view:w,button:0,buttons:type==='mousedown'?1:0}));return {ok:true};}
  if(mode==='DBLCLICK'){target.dispatchEvent(new target.ownerDocument.defaultView.MouseEvent('dblclick',{bubbles:true,cancelable:true,view:target.ownerDocument.defaultView,button:0}));return {ok:true};}
  return {ok:false};
},ticketId,mode);}

async function openNextEligibleTicket(page,skipTicketIds=new Set()){
  const snap=await queueTableSnapshot(page);need(snap.ok,'QUEUE_NOT_FOUND','Ticketübersicht mit echter Ticket-ID, Quelle und „Zusätzliche Beschreibung“ nicht eindeutig gefunden.');diag.queue.scanned=true;diag.queue.method=snap.method??null;diag.queue.scope=snap.scope??null;diag.queue.validTicketRows=snap.validTicketRows??snap.rows.length;
  const eligible=snap.rows.filter(r=>r.descriptionBlank&&(!r.source||r.source.toUpperCase()==='E-MAIL')&&!skipTicketIds.has(r.ticketId));
  diag.queue.eligible=eligible.length;diag.queue.skippedNonBlank=snap.rows.filter(r=>!r.descriptionBlank).length;
  if(!eligible.length)return null;
  const row=eligible[0];const scopeLabel=snap.scope==='WARTESCHLANGE_INTL01'?'Warteschlange INTL01':snap.scope==='IN_BEARBEITUNG'?'Meine Vorgänge > In_Bearbeitung':(snap.scope??'unbekannte Liste');log(`Queue erkannt [${scopeLabel}] (${snap.method??'UNBEKANNT'}): ${snap.validTicketRows??snap.rows.length} echte Ticketzeile(n), ${eligible.length} zulässige E-MAIL-Ticket(s) ohne zusätzliche Beschreibung → erstes Ticket wird geöffnet${row.ticketId?' ('+row.ticketId+')':''}.`);
  const attempts=[
    ['TRUSTED_TICKET_CELL',async()=>page.mouseClick(row.ticket.x,row.ticket.y)],
    ['TRUSTED_ACTION_ELEMENT',async()=>{if(!row.action)throw new Error('kein Action-Element');await page.mouseClick(row.action.x,row.action.y)}],
    ['DOM_CLICK',async()=>{const r=await clickQueueRowByDom(page,row.ticketId,'CLICK');if(!r.ok)throw new Error('DOM-Ziel fehlt')}],
    ['DOM_MOUSE_SEQUENCE',async()=>{const r=await clickQueueRowByDom(page,row.ticketId,'MOUSE');if(!r.ok)throw new Error('DOM-Ziel fehlt')}],
    ['TRUSTED_ROW_CENTER',async()=>page.mouseClick(row.row.x,row.row.y)],
    ['DOM_DBLCLICK',async()=>{const r=await clickQueueRowByDom(page,row.ticketId,'DBLCLICK');if(!r.ok)throw new Error('DOM-Ziel fehlt')}]
  ];
  for(const [name,fn] of attempts){
    log(`Ticket öffnen: Methode ${name} ...`);try{await fn();}catch(e){log(`  ${name}: nicht anwendbar.`);continue;}
    if(await detailOpened(page,row.ticketId,5000)){diag.queue.selected=true;diag.queue.openMethod=name;diag.queue.ticketBound=!!row.ticketId;log(`Ticket geöffnet: ${name} PASS.`);return row;}
    log(`  ${name}: keine Detailansicht erkannt → nächste Methode.`);
  }
  fail('QUEUE_OPEN','Zulässiges Ticket konnte mit keiner getesteten Methode geöffnet werden.');
}

async function isEditReady(page){return await page.call(function(){const f=document.getElementById('mainForm:member-value-id');return !!(f&&f.getClientRects().length&&!f.disabled&&!f.readOnly);});}
async function findBearbeitenTarget(page){return await page.call(function(){
  const visible=n=>{try{return n.getClientRects().length>0&&getComputedStyle(n).display!=='none'&&getComputedStyle(n).visibility!=='hidden'}catch{return false}};
  const clean=v=>String(v??'').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();const xs=[];
  for(const n of document.querySelectorAll('input,button,a')){if(!visible(n)||clean(n.value||n.textContent)!=='Bearbeiten')continue;const r=n.getBoundingClientRect();xs.push({x:r.left+r.width/2,y:r.top+r.height/2,right:r.right,bottom:r.bottom});}
  xs.sort((a,b)=>b.bottom-a.bottom||b.right-a.right);return {count:xs.length,target:xs[0]??null};
});}
async function bearbeitenDom(page,mode){return await page.call(function(mode){
  const visible=n=>n.getClientRects().length>0;const clean=v=>String(v??'').replace(/\s+/g,' ').trim();const xs=[...document.querySelectorAll('input,button,a')].filter(n=>visible(n)&&clean(n.value||n.textContent)==='Bearbeiten');if(xs.length!==1)return {ok:false,count:xs.length};const n=xs[0],w=n.ownerDocument.defaultView;
  if(mode==='CLICK'){n.click();return {ok:true};}
  if(mode==='MOUSE'){for(const t of ['mousedown','mouseup','click'])n.dispatchEvent(new w.MouseEvent(t,{bubbles:true,cancelable:true,view:w,button:0,buttons:t==='mousedown'?1:0}));return {ok:true};}
  if(mode==='ENTER'){n.focus();n.dispatchEvent(new w.KeyboardEvent('keydown',{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true}));n.dispatchEvent(new w.KeyboardEvent('keyup',{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true}));return {ok:true};}
  return {ok:false};
},mode);}
async function waitEditReady(page,timeoutMs=9000){const end=Date.now()+timeoutMs;while(Date.now()<end){if(await isEditReady(page))return true;await sleep(180)}return false;}
async function ensureEditModeMulti(page){
  if(await isEditReady(page)){diag.edit.ready=true;diag.edit.method='ALREADY_EDIT';return;}
  diag.edit.attempted=true;const t=await findBearbeitenTarget(page);need(t.count>=1&&t.target,'EDIT_BUTTON','„Bearbeiten“ nicht gefunden.');
  const attempts=[['TRUSTED_MOUSE',async()=>page.mouseClick(t.target.x,t.target.y)],['DOM_CLICK',async()=>bearbeitenDom(page,'CLICK')],['DOM_MOUSE_SEQUENCE',async()=>bearbeitenDom(page,'MOUSE')],['DOM_ENTER',async()=>bearbeitenDom(page,'ENTER')]];
  for(const [name,fn] of attempts){log(`Bearbeiten öffnen: Methode ${name} ...`);try{await fn();}catch{}if(await waitEditReady(page,9000)){diag.edit.ready=true;diag.edit.method=name;log(`Bearbeiten geöffnet: ${name} PASS.`);return;}log(`  ${name}: Bearbeitungsmodus noch nicht erkannt → nächste Methode.`);}
  fail('EDIT_OPEN','Bearbeitungsmodus konnte mit keiner getesteten Methode geöffnet werden.');
}

async function historyRowCount(page){return await page.call(function(){const tb=document.getElementById('mainForm:j_id6065:tbody');if(tb)return tb.rows.length;for(const table of document.querySelectorAll('table')){const h=[...table.querySelectorAll('thead th')].map(n=>String(n.textContent||'').trim().toLowerCase());if(['original','von','an','betreff','inhalt','datum'].every(x=>h.some(v=>v===x)))return table.tBodies?.[0]?.rows.length??0;}return 0;});}
async function sendButtonCenter(page){return await page.call(function(){const n=document.getElementById('mainForm:send-new-message-button')||[...document.querySelectorAll('input,button')].find(x=>x.getClientRects().length&&String(x.value||x.textContent||'').trim()==='Senden');if(!n||!n.getClientRects().length)return {ok:false};n.scrollIntoView({block:'center',inline:'nearest'});const r=n.getBoundingClientRect();return {ok:true,x:r.left+r.width/2,y:r.top+r.height/2};});}
async function handleOneHtmlOk(page){return await page.call(function(){
  const visible=n=>{try{const s=getComputedStyle(n);return n.getClientRects().length>0&&s.display!=='none'&&s.visibility!=='hidden'}catch{return false}};const clean=v=>String(v??'').replace(/\s+/g,' ').trim();const containers=[...document.querySelectorAll('[role="dialog"],.icePnlPop,.ui-dialog,.modal')].filter(visible);if(!containers.length)return {state:'NONE'};
  const oks=[];for(const c of containers)for(const b of c.querySelectorAll('input,button,a'))if(visible(b)&&/^ok$/i.test(clean(b.value||b.textContent||'')))oks.push(b);
  if(oks.length===1){oks[0].click();return {state:'OK_CLICKED'};}if(oks.length>1)return {state:'AMBIGUOUS_OK',count:oks.length};
  return {state:'UNKNOWN_DIALOG',count:containers.length};
});}
async function refreshHistoryOnce(page){const t=await page.call(function(){const sec=[...document.querySelectorAll('div')].find(n=>n.textContent?.trim()==='Nachrichtenverlauf');const root=sec?.closest('.icePnlClpsbl,.defaultSectionPanelGroup')||sec?.parentElement;if(!root)return {ok:false};const b=[...root.querySelectorAll('input[type="image"]')].find(n=>/arrow_refresh_small/i.test(n.getAttribute('src')||''));if(!b||!b.getClientRects().length)return {ok:false};const r=b.getBoundingClientRect();return {ok:true,x:r.left+r.width/2,y:r.top+r.height/2};});if(t.ok){await page.mouseClick(t.x,t.y);return true}return false;}
async function replyEditorState(page){
  return await page.call(function(){
    const docs=[];(function walk(doc,d){if(!doc||d>6||docs.includes(doc))return;docs.push(doc);for(const f of doc.querySelectorAll('iframe,frame'))try{walk(f.contentDocument,d+1)}catch{}})(document,0);
    const vis=n=>{try{return !!n&&n.getClientRects().length>0&&n.ownerDocument.defaultView.getComputedStyle(n).display!=='none'&&n.ownerDocument.defaultView.getComputedStyle(n).visibility!=='hidden'}catch{return false}};
    const norm=s=>String(s??'').replace(/\r\n?/g,'\n').replace(/\u00a0/g,' ').replace(/[ \t]+\n/g,'\n').replace(/\n[ \t]+/g,'\n').trim();
    const hits=[];
    for(let di=0;di<docs.length;di++){
      const nodes=docs[di].querySelectorAll('[contenteditable="true"],body[contenteditable="true"],html[contenteditable="true"]');
      for(let i=0;i<nodes.length;i++)if(vis(nodes[i]))hits.push(nodes[i]);
    }
    const uniq=[];for(let i=0;i<hits.length;i++){let nested=false;for(let j=0;j<hits.length;j++)if(i!==j&&hits[i].contains(hits[j])){nested=true;break;}if(!nested)uniq.push(hits[i]);}
    if(uniq.length!==1)return {ok:false,count:uniq.length,empty:false};
    const text=norm(uniq[0].innerText??uniq[0].textContent);
    return {ok:true,count:1,empty:text==='',length:text.length};
  });
}

async function sendAndConfirm(page,rl,{preArmed=false}={}){
  if(!preArmed&&!DEMO&&!AUTO){
    const arm=clean(await rl.question('\nVERSAND: Tippe SENDEN, um diese vorbereitete Nachricht jetzt wirklich zu versenden: '));
    need(/^senden$/i.test(arm),'SEND_NOT_ARMED','Versand nicht freigegeben.');
  }
  diag.send.armed=true;
  const before=await historyRowCount(page);diag.send.historyBefore=before;
  const editorBefore=await replyEditorState(page).catch(()=>({ok:false,empty:false}));
  need(editorBefore.ok&&!editorBefore.empty,'SEND_EDITOR','Antworteditor ist vor dem Versand leer oder nicht eindeutig. Kein Versand.');
  let sendWindow=true,jsErr=null;
  const off=page.cdp.on('Page.javascriptDialogOpening',(params,sid)=>{
    if(!sendWindow||sid!==page.sessionId)return;
    if(!['alert','confirm'].includes(params.type)){jsErr='UNEXPECTED_JS_DIALOG';return;}
    diag.send.jsDialogs++;
    page.cdp.send('Page.handleJavaScriptDialog',{accept:true},sid).catch(()=>{jsErr='JS_DIALOG_ACCEPT_FAILED';});
  });
  try{
    const c=await sendButtonCenter(page);need(c.ok,'SEND_BUTTON','Senden-Schaltfläche nicht gefunden.');
    log('Senden → ein einziger echter Browser-Mausklick.');
    diag.send.clicked=true;
    if(DEMO){await page.call(()=>document.getElementById('mainForm:send-new-message-button')?.click());}
    else await page.mouseClick(c.x,c.y);

    const start=Date.now();let lastCount=before,stableSince=0,editorResetSince=0;
    while(Date.now()-start<45000){
      if(jsErr)fail(jsErr,'Unerwarteter JavaScript-Dialog beim Versand. Nachricht NICHT erneut senden.');
      const d=await handleOneHtmlOk(page);
      if(d.state==='OK_CLICKED'){diag.send.htmlDialogs++;log('Versanddialog → OK wird bestätigt.');await sleep(450);continue;}
      if(d.state==='AMBIGUOUS_OK'||d.state==='UNKNOWN_DIALOG')fail('UNEXPECTED_DIALOG','Unerwarteter/mehrdeutiger HTML-Dialog nach Senden. Nachricht NICHT erneut senden.');

      const n=await historyRowCount(page).catch(()=>before);
      if(n>before){
        if(n===lastCount){
          if(!stableSince)stableSince=Date.now();
          if(Date.now()-stableSince>900){
            diag.send.historyAfter=n;diag.send.verified=true;diag.send.acknowledged=true;diag.send.ackMode='HISTORY_INCREMENT';
            log(`Versandnachweis PASS: Nachrichtenverlauf ${before} → ${n} Zeile(n).`);
            return;
          }
        }else{lastCount=n;stableSince=Date.now();}
      }

      const ed=await replyEditorState(page).catch(()=>({ok:false,empty:false}));
      const dialogCount=diag.send.jsDialogs+diag.send.htmlDialogs;
      if(ed.ok&&ed.empty&&dialogCount>=1){
        if(!editorResetSince)editorResetSince=Date.now();
        if(Date.now()-editorResetSince>1000){
          diag.send.historyAfter=n;diag.send.verified=true;diag.send.acknowledged=true;diag.send.ackMode='EDITOR_RESET_AFTER_CONFIRMED_DIALOGS';
          log(`Versandnachweis PASS: Antworteditor wurde nach ${dialogCount} bestätigten Dialog(en) serverseitig zurückgesetzt.`);
          return;
        }
      }else editorResetSince=0;

      if(!diag.send.refreshAttempted&&Date.now()-start>10000){
        diag.send.refreshAttempted=true;
        if(await refreshHistoryOnce(page)){log('Nachrichtenverlauf einmal aktualisiert, um Versand nachzuweisen.');await sleep(900);}
      }
      await sleep(250);
    }
    fail('SEND_UNVERIFIED','Versand konnte weder über Nachrichtenverlauf noch über serverseitig zurückgesetzten Antworteditor bestätigt werden. NICHT erneut senden.');
  } finally {sendWindow=false;off?.();}
}


async function queueScope(page){
  const snap=await queueTableSnapshot(page).catch(()=>null);
  return snap?.ok?snap.scope:null;
}

async function menuTarget(page,scope,kind){
  return await page.call(function(scope,kind){
    function clean(v){return String(v??'').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();}
    function visible(n){try{const s=n.ownerDocument.defaultView.getComputedStyle(n);return !!n&&n.isConnected&&n.getClientRects().length>0&&s.display!=='none'&&s.visibility!=='hidden';}catch{return false;}}
    function targetOf(n){if(!n)return null;let t=n;for(let i=0;i<5&&t;i++,t=t.parentElement){if(['A','BUTTON','INPUT'].includes(t.tagName)&&visible(t))return t;}return visible(n)?n:null;}
    const isMy=scope==='IN_BEARBEITUNG';
    if(kind==='CHILD'){
      const root=document.getElementById(isMy?'storedSearchesContainer_MY_TASKS':'storedSearchesContainer_MY_QUEUES');
      if(!root)return {ok:false,state:'NO_CONTAINER'};
      const wanted=isMy?'In_Bearbeitung':'INTL01',nodes=root.querySelectorAll('a,span,label,div');
      let hit=null,count=0;
      for(let i=0;i<nodes.length;i++){if(!visible(nodes[i]))continue;if(clean(nodes[i].textContent)===wanted){const t=targetOf(nodes[i]);if(t){hit=t;count++;}}}
      if(count!==1||!hit)return {ok:false,state:count?'AMBIGUOUS_CHILD':'NO_CHILD',count};
      hit.scrollIntoView({block:'center',inline:'nearest'});const r=hit.getBoundingClientRect();return {ok:true,x:r.left+r.width/2,y:r.top+r.height/2};
    }
    const wanted=isMy?'Meine Vorgänge':'Warteschlange',nodes=document.querySelectorAll('a');
    let hit=null,count=0;
    for(let i=0;i<nodes.length;i++){const n=nodes[i];if(!visible(n))continue;const title=clean(n.getAttribute('title'));const text=clean(n.textContent);if(title===wanted||text===wanted){hit=n;count++;}}
    if(count!==1||!hit)return {ok:false,state:count?'AMBIGUOUS_HEADER':'NO_HEADER',count};
    hit.scrollIntoView({block:'center',inline:'nearest'});const r=hit.getBoundingClientRect();return {ok:true,x:r.left+r.width/2,y:r.top+r.height/2};
  },scope,kind);
}

async function menuDomClick(page,scope,kind){
  return await page.call(function(scope,kind){
    function clean(v){return String(v??'').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();}
    function visible(n){try{const s=n.ownerDocument.defaultView.getComputedStyle(n);return !!n&&n.isConnected&&n.getClientRects().length>0&&s.display!=='none'&&s.visibility!=='hidden';}catch{return false;}}
    const isMy=scope==='IN_BEARBEITUNG';
    if(kind==='CHILD'){
      const root=document.getElementById(isMy?'storedSearchesContainer_MY_TASKS':'storedSearchesContainer_MY_QUEUES');if(!root)return false;
      const wanted=isMy?'In_Bearbeitung':'INTL01',nodes=root.querySelectorAll('a,span,label,div');
      const hits=[];for(let i=0;i<nodes.length;i++)if(visible(nodes[i])&&clean(nodes[i].textContent)===wanted)hits.push(nodes[i]);
      if(hits.length!==1)return false;let t=hits[0];for(let i=0;i<5&&t;i++,t=t.parentElement)if(['A','BUTTON','INPUT'].includes(t.tagName)&&visible(t)){t.click();return true;}hits[0].click();return true;
    }
    const wanted=isMy?'Meine Vorgänge':'Warteschlange',nodes=document.querySelectorAll('a'),hits=[];
    for(let i=0;i<nodes.length;i++)if(visible(nodes[i])&&(clean(nodes[i].getAttribute('title'))===wanted||clean(nodes[i].textContent)===wanted))hits.push(nodes[i]);
    if(hits.length!==1)return false;hits[0].click();return true;
  },scope,kind);
}

async function waitForScope(page,scope,timeoutMs=12000){
  const end=Date.now()+timeoutMs;
  while(Date.now()<end){
    const snap=await queueTableSnapshot(page).catch(()=>null);
    if(snap?.ok&&snap.scope===scope)return snap;
    await sleep(220);
  }
  return null;
}

async function navigateToScope(page,scope){
  const current=await waitForScope(page,scope,500).catch(()=>null);
  if(current)return current;
  for(const kind of ['CHILD','HEADER','CHILD']){
    const t=await menuTarget(page,scope,kind).catch(()=>({ok:false}));
    if(t.ok){await page.mouseClick(t.x,t.y);await sleep(kind==='HEADER'?900:450);}
    else await menuDomClick(page,scope,kind).catch(()=>false);
    const snap=await waitForScope(page,scope,kind==='CHILD'?8000:1800);
    if(snap){log(`Navigation → ${scope==='IN_BEARBEITUNG'?'Meine Vorgänge > In_Bearbeitung':'Warteschlange > INTL01'} PASS.`);return snap;}
  }
  fail('QUEUE_NAVIGATION','Zielansicht konnte nicht automatisch geöffnet werden: '+scope);
}

async function recipientAddress(page){
  return await page.call(function(){
    function clean(v){return String(v??'').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();}
    function visible(n){try{const s=n.ownerDocument.defaultView.getComputedStyle(n);return !!n&&n.isConnected&&n.getClientRects().length>0&&s.display!=='none'&&s.visibility!=='hidden';}catch{return false;}}
    const panels=document.querySelectorAll('.defaultSectionPanelGroup,.icePnlClpsbl,.mercerWorkAreaPanel,div');
    let section=null;
    for(let i=0;i<panels.length;i++){const n=panels[i];if(!visible(n))continue;const labels=n.querySelectorAll('span,label');for(let j=0;j<labels.length;j++)if(clean(labels[j].textContent)==='Neue Nachricht'){section=n;break;}if(section)break;}
    const scope=section||document;const labels=scope.querySelectorAll('label'),emails=[];
    for(let i=0;i<labels.length;i++){
      const l=labels[i];if(!visible(l)||clean(l.textContent)!=='An:')continue;
      const row=l.closest('tr')||l.parentElement;const text=clean(row?.textContent||'');
      const ms=text.match(/[A-Z0-9.!#$%&'*+/=?^_`{|}~-]{1,64}@[A-Z0-9.-]{1,253}\.[A-Z]{2,63}/gi)||[];
      for(let j=0;j<ms.length;j++)emails.push(ms[j].toLowerCase());
    }
    const uniq=[];for(let i=0;i<emails.length;i++)if(!uniq.includes(emails[i]))uniq.push(emails[i]);
    return {ok:uniq.length===1,count:uniq.length};
  });
}

async function saveButtonCenter(page){
  return await page.call(function(){
    function clean(v){return String(v??'').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();}
    function visible(n){try{const s=n.ownerDocument.defaultView.getComputedStyle(n);return !!n&&n.isConnected&&n.getClientRects().length>0&&s.display!=='none'&&s.visibility!=='hidden';}catch{return false;}}
    const nodes=document.querySelectorAll('a,button,input'),hits=[];
    for(let i=0;i<nodes.length;i++){const n=nodes[i];if(visible(n)&&clean(n.value||n.textContent)==='Ticket speichern')hits.push(n);}
    if(hits.length!==1)return {ok:false,count:hits.length};const n=hits[0];n.scrollIntoView({block:'center',inline:'nearest'});const r=n.getBoundingClientRect();return {ok:true,x:r.left+r.width/2,y:r.top+r.height/2};
  });
}

async function saveTicket(page){
  const c=await saveButtonCenter(page);need(c.ok,'SAVE_BUTTON','„Ticket speichern“ nicht eindeutig gefunden.');
  let saveWindow=true,jsErr=null;
  const off=page.cdp.on('Page.javascriptDialogOpening',(params,sid)=>{
    if(!saveWindow||sid!==page.sessionId)return;
    if(!['alert','confirm'].includes(params.type)){jsErr='UNEXPECTED_SAVE_DIALOG';return;}
    page.cdp.send('Page.handleJavaScriptDialog',{accept:true},sid).catch(()=>{jsErr='SAVE_DIALOG_ACCEPT_FAILED';});
  });
  try{
    log('Ticket speichern → ein einziger echter Browser-Mausklick.');
    diag.save.clicked=true;await page.mouseClick(c.x,c.y);const end=Date.now()+12000;let quietSince=0;
    while(Date.now()<end){
      if(jsErr)fail(jsErr,'Unerwarteter Dialog beim Speichern.');
      const d=await handleOneHtmlOk(page);
      if(d.state==='OK_CLICKED'){quietSince=0;log('Speicherdialog → OK wird bestätigt.');await sleep(450);continue;}
      if(d.state==='AMBIGUOUS_OK'||d.state==='UNKNOWN_DIALOG')fail('UNEXPECTED_SAVE_DIALOG','Unerwarteter/mehrdeutiger HTML-Dialog beim Speichern.');
      if(!quietSince)quietSince=Date.now();
      if(Date.now()-quietSince>1800)break;
      await sleep(250);
    }
    log('Ticket speichern: Server-/Dialogphase abgeschlossen.');
  } finally {saveWindow=false;off?.();}
}

async function verifySavedAndReturn(page,ticketId){
  log('Speicherprüfung: zurück zu Meine Vorgänge > In_Bearbeitung.');
  const my=await navigateToScope(page,'IN_BEARBEITUNG');
  let row=my.rows.find(r=>r.ticketId===ticketId);
  if(row){
    need(!row.descriptionBlank,'SAVE_UNVERIFIED','Ticket ist nach Speichern in „In_Bearbeitung“ weiterhin ohne zusätzliche Beschreibung. Abbruch, damit es nicht erneut versendet wird.');
    diag.save.verified=true;diag.save.verification='MY_TASKS_NONBLANK';return my;
  }
  const q=await navigateToScope(page,'WARTESCHLANGE_INTL01');
  row=q.rows.find(r=>r.ticketId===ticketId);
  if(row){
    need(!row.descriptionBlank,'SAVE_UNVERIFIED','Ticket ist nach Speichern in „Warteschlange INTL01“ weiterhin ohne zusätzliche Beschreibung. Abbruch, damit es nicht erneut versendet wird.');
    diag.save.verified=true;diag.save.verification='QUEUE_NONBLANK';
  }else{
    diag.save.verified=true;diag.save.verification='ABSENT_FROM_BOTH_WORKLISTS';
  }
  return await navigateToScope(page,'IN_BEARBEITUNG');
}

function resetTicketDiag(){
  diag.mail={downloaded:false,parsed:false,personAuto:false,personManual:false,downloadPolicy:null,downloadMethod:null,downloadCandidates:0,downloadAutoClicked:false,downloadFallbackManual:false,directFetch:false,historyRows:0,source:null,historyContentUsed:false};
  diag.member={searchStarted:false,autoClicked:false,manualGate:false,selected:false,commitSource:null,profileMatched:false};
  diag.edit={attempted:false,method:null,ready:false};
  diag.lookup={attempted:false,ready:false};
  diag.description={written:false,verified:false,route:null,candidates:null};
  diag.fixed={responsibility:false,category:false,subcategory:false,signature:false};
  diag.reply={generated:false,written:false,verified:false,salutationSource:null};
  diag.send={armed:false,clicked:false,jsDialogs:0,htmlDialogs:0,historyBefore:null,historyAfter:null,verified:false,acknowledged:false,ackMode:null,refreshAttempted:false};
  diag.save={clicked:false,verified:false,verification:null};
  diag.readyBeforeSend=false;
}

async function ensureEditModeLegacy(page){
  const state=await page.call(function(){
    const docs=(()=>{const out=[];function walk(doc,d){if(!doc||d>5||out.includes(doc))return;out.push(doc);for(const f of doc.querySelectorAll('iframe,frame'))try{walk(f.contentDocument,d+1)}catch{}}walk(document,0);return out})();
    const vis=n=>{try{return n?.isConnected&&n.getClientRects().length>0&&n.ownerDocument.defaultView.getComputedStyle(n).display!=='none'&&n.ownerDocument.defaultView.getComputedStyle(n).visibility!=='hidden'}catch{return false}};
    const member=docs.flatMap(d=>[...d.querySelectorAll('input[id="mainForm:member-value-id"]')]).find(vis);
    if(member&&!member.disabled&&!member.readOnly)return {mode:'EDIT'};
    const buttons=docs.flatMap(d=>[...d.querySelectorAll('input,button,a')]).filter(n=>vis(n)&&String(n.value||n.textContent||'').trim()==='Bearbeiten');
    if(buttons.length===1){const r=buttons[0].getBoundingClientRect();return {mode:'BUTTON',x:r.left+r.width/2,y:r.top+r.height/2};}
    return {mode:'WAIT'};
  });
  if(state.mode==='EDIT')return;
  if(state.mode==='BUTTON'){log('„Bearbeiten“ gefunden → wird geöffnet.');await page.mouseClick(state.x,state.y);}
  log('Warte auf bearbeitbares Member-Feld ...');
  await page.waitFor(function(){
    const docs=[];(function walk(doc,d){if(!doc||d>5||docs.includes(doc))return;docs.push(doc);for(const f of doc.querySelectorAll('iframe,frame'))try{walk(f.contentDocument,d+1)}catch{}})(document,0);
    return docs.some(d=>{const n=d.getElementById('mainForm:member-value-id');return n&&!n.disabled&&!n.readOnly&&n.getClientRects().length>0;});
  },{timeoutMs:90000,description:'Bearbeitungsmodus'});
}

async function currentHistoryMail(page){return await page.call(function(){
  const docs=[];(function walk(doc,d){if(!doc||d>6||docs.includes(doc))return;docs.push(doc);for(const f of doc.querySelectorAll('iframe,frame'))try{walk(f.contentDocument,d+1)}catch{}})(document,0);
  const vis=n=>{try{const w=n.ownerDocument.defaultView,s=w.getComputedStyle(n);return n.isConnected&&n.getClientRects().length>0&&s.display!=='none'&&s.visibility!=='hidden'}catch{return false}};
  const norm=v=>String(v??'').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim().toLocaleLowerCase('de-DE');
  const tables=[];
  for(const doc of docs)for(const table of doc.querySelectorAll('table')){
    if(!vis(table))continue;
    const headers=[...table.querySelectorAll('thead th,thead label,thead span')].map(n=>norm(n.textContent)).filter(Boolean);
    const required=['original','von','an','betreff','inhalt','datum'];
    if(required.every(x=>headers.includes(x)))tables.push(table);
  }
  if(tables.length!==1)return {ok:false,state:tables.length?'AMBIGUOUS_HISTORY':'NO_HISTORY',tableCount:tables.length,rowCount:0};
  const table=tables[0],body=table.tBodies?.[0];if(!body)return {ok:false,state:'NO_TBODY',tableCount:1,rowCount:0};
  const rows=[...body.rows].filter(r=>vis(r)&&r.querySelector('a[href*="GetFile?docId="]'));
  if(!rows.length)return {ok:false,state:'NO_MESSAGE_ROWS',tableCount:1,rowCount:0};
  const row=rows[rows.length-1],links=[...row.querySelectorAll('a[href*="GetFile?docId="]')].filter(vis);
  if(links.length!==1)return {ok:false,state:links.length?'AMBIGUOUS_DOWNLOAD':'NO_DOWNLOAD',tableCount:1,rowCount:rows.length,linkCount:links.length};
  const a=links[0],u=new URL(a.getAttribute('href'),a.ownerDocument.baseURI),m=u.searchParams.get('docId'),demoDoc=['about:','file:'].includes(a.ownerDocument.location.protocol);
  if(!demoDoc&&(u.origin!==a.ownerDocument.location.origin||!/(?:^|\/)GetFile\/?$/i.test(u.pathname)||!/^\d{1,15}$/.test(m??'')))return {ok:false,state:'UNSAFE_DOWNLOAD_LINK',tableCount:1,rowCount:rows.length};
  return {ok:true,state:'BOTTOM_DOM_ROW',href:u.href,rowCount:rows.length,docId:/^\d{1,15}$/.test(m??'')?m:null};
});}


async function historyMailSnapshots(page){return await page.call(function(){
  const docs=[];(function walk(doc,d){if(!doc||d>6||docs.includes(doc))return;docs.push(doc);for(const f of doc.querySelectorAll('iframe,frame'))try{walk(f.contentDocument,d+1)}catch{}})(document,0);
  const vis=n=>{try{const w=n.ownerDocument.defaultView,s=w.getComputedStyle(n);return n.isConnected&&n.getClientRects().length>0&&s.display!=='none'&&s.visibility!=='hidden'}catch{return false}};
  const norm=v=>String(v??'').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim().toLocaleLowerCase('de-DE');
  const tables=[];
  for(const doc of docs)for(const table of doc.querySelectorAll('table')){
    if(!vis(table))continue;
    const headers=[...table.querySelectorAll('thead th,thead label,thead span')].map(n=>norm(n.textContent)).filter(Boolean);
    const required=['original','von','an','betreff','inhalt','datum'];
    if(required.every(x=>headers.includes(x)))tables.push(table);
  }
  if(tables.length!==1)return {ok:false,state:tables.length?'AMBIGUOUS_HISTORY':'NO_HISTORY',rows:[]};
  const table=tables[0],body=table.tBodies?.[0];if(!body)return {ok:false,state:'NO_TBODY',rows:[]};
  const rows=[...body.rows].filter(r=>vis(r)&&r.querySelector('a[href*="GetFile?docId="]'));
  const data=rows.map((row,index)=>{
    const cells=[...row.cells],txt=i=>String(cells[i]?.textContent??cells[i]?.innerText??'').replace(/\u00a0/g,' ').replace(/\r\n?/g,'\n').trim();
    const a=row.querySelector('a[href*="GetFile?docId="]');let href=null,docId=null;
    try{const u=new URL(a?.getAttribute('href')??'',row.ownerDocument.baseURI);href=u.href;const v=u.searchParams.get('docId');if(/^\d{1,15}$/.test(v??''))docId=v;}catch{}
    return {index,sender:txt(1),recipient:txt(2),subject:txt(3),content:txt(4),date:txt(5),href,docId};
  }).reverse();
  return {ok:data.length>0,state:data.length?'READY':'NO_MESSAGE_ROWS',rows:data};
});}

async function choosePersonFromHistory(page,rl){
  const snapshot=await historyMailSnapshots(page);
  if(!snapshot.ok||!snapshot.rows.length)return null;
  diag.mail.historyRows=snapshot.rows.length;diag.mail.source='HISTORY_DOM';diag.mail.historyContentUsed=true;diag.mail.downloadPolicy='NO_DOWNLOAD_HISTORY_DOM';
  let fallback=null;
  for(const row of snapshot.rows){
    const mail={format:'COMARCH_HISTORY',subject:row.subject||'',senderName:'',senderEmail:row.sender||'',body:row.content||'',warnings:[],diagnostic:{plainText:true,attachmentsRead:false,source:'HISTORY_DOM'}};
    const cs=Person.candidates(mail);
    if(!cs.length)continue;
    if(!fallback)fallback=mail;
    if(cs.length===1){const picked=await choosePerson(mail,rl);return {mail,...picked};}
  }
  if(fallback){const picked=await choosePerson(fallback,rl);return {mail:fallback,...picked};}
  return null;
}

async function fetchMailInPage(page,url){return await page.call(async function(target){
  const response=await fetch(target,{credentials:'same-origin',cache:'no-store',redirect:'follow'});
  if(!response.ok)return {ok:false,status:response.status};
  const ab=await response.arrayBuffer();
  if(ab.byteLength<512||ab.byteLength>24*1024*1024)return {ok:false,status:response.status,size:ab.byteLength,reason:'SIZE'};
  const bytes=new Uint8Array(ab);let binary='';const chunk=0x8000;
  for(let i=0;i<bytes.length;i+=chunk)binary+=String.fromCharCode(...bytes.subarray(i,Math.min(i+chunk,bytes.length)));
  return {ok:true,status:response.status,size:bytes.length,base64:btoa(binary)};
},url);}


const MSG_MAGIC = Buffer.from([0xd0,0xcf,0x11,0xe0,0xa1,0xb1,0x1a,0xe1]);
function validMsgBytes(bytes){
  const b=Buffer.isBuffer(bytes)?bytes:Buffer.from(bytes);
  if(b.length<512||b.length>32*1024*1024||!b.subarray(0,8).equals(MSG_MAGIC))return false;
  try{Msg.parseMsg(b);return true;}catch{return false;}
}
async function provenDownloadLinks(page){return await page.call(function(){
  const visible=n=>{try{const s=n.ownerDocument.defaultView.getComputedStyle(n);return n.isConnected&&n.getClientRects().length>0&&s.display!=='none'&&s.visibility!=='hidden'}catch{return false}};
  const rows=[];
  for(const tr of document.querySelectorAll('tr.iceDatTblRow')){
    const a=tr.querySelector('a[href*="GetFile?docId="]');
    if(!a||!visible(tr)||!visible(a))continue;
    let u;try{u=new URL(a.getAttribute('href'),document.baseURI)}catch{continue}
    const id=u.searchParams.get('docId')||'';
    if(u.origin!==location.origin||!/\/DMSWWW\/GetFile$/i.test(u.pathname)||!/^\d{1,15}$/.test(id))continue;
    rows.push({href:u.href,docId:id});
  }
  return rows.reverse();
});}
async function provenPageFetch(page,url){return await page.call(async function(target){
  try{
    const r=await fetch(target,{
      credentials:'include',
      cache:'no-store',
      redirect:'follow',
      headers:{accept:'application/vnd.ms-outlook,application/octet-stream,*/*'}
    });
    const ab=await r.arrayBuffer();
    if(ab.byteLength>32*1024*1024)return {ok:false,status:r.status,size:ab.byteLength,reason:'TOO_LARGE',mime:r.headers.get('content-type')};
    const bytes=new Uint8Array(ab);let binary='';
    for(let i=0;i<bytes.length;i+=0x8000)binary+=String.fromCharCode(...bytes.subarray(i,Math.min(i+0x8000,bytes.length)));
    return {ok:r.ok,status:r.status,size:bytes.length,base64:btoa(binary),mime:r.headers.get('content-type'),finalSameOrigin:new URL(r.url).origin===location.origin};
  }catch(e){return {ok:false,reason:e.name||'FETCH_ERROR'};}
},url);}

async function listDownloadAnchors(page){return await page.call(function(){
  const docs=[];(function walk(doc,d){if(!doc||d>6||docs.includes(doc))return;docs.push(doc);for(const f of doc.querySelectorAll('iframe,frame'))try{walk(f.contentDocument,d+1)}catch{}})(document,0);
  const vis=n=>{try{const w=n.ownerDocument.defaultView,s=w.getComputedStyle(n);return n.isConnected&&n.getClientRects().length>0&&s.display!=='none'&&s.visibility!=='hidden'}catch{return false}};
  function absoluteCenter(n){let r=n.getBoundingClientRect(),x=r.left+r.width/2,y=r.top+r.height/2,doc=n.ownerDocument,guard=0;while(doc!==document&&guard++<8){const frame=doc.defaultView?.frameElement;if(!frame)break;const fr=frame.getBoundingClientRect();x+=fr.left;y+=fr.top;doc=frame.ownerDocument;}return {x,y,width:r.width,height:r.height};}
  const rows=[];let order=0;
  for(const doc of docs)for(const a of doc.querySelectorAll('a[href]')){if(!vis(a))continue;let u;try{u=new URL(a.href,doc.baseURI)}catch{continue}if(!/GetFile/i.test(u.pathname+u.search))continue;const r=absoluteCenter(a);rows.push({...r,order:order++});}
  return rows;
});}
async function waitNewMsg(dir,since,timeoutMs=30000){
  const deadline=Date.now()+timeoutMs;
  while(Date.now()<deadline){
    if(fs.existsSync(dir)){
      const files=fs.readdirSync(dir).filter(n=>/\.msg$/i.test(n)).map(n=>{const p=path.join(dir,n);const s=fs.statSync(p);return {p,mtime:s.mtimeMs,size:s.size};}).filter(x=>x.mtime>=since-2000&&x.size>=512).sort((a,b)=>b.mtime-a.mtime);
      if(files.length)return files[0].p;
    }
    await sleep(200);
  }
  return null;
}

async function downloadCurrentMail(page, cfg, rl){
  fs.mkdirSync(cfg.downloadDirectory,{recursive:true});
  for(const n of fs.readdirSync(cfg.downloadDirectory))try{fs.rmSync(path.join(cfg.downloadDirectory,n),{recursive:true,force:true})}catch{}

  const links=await provenDownloadLinks(page);
  if(links.length){
    diag.mail.downloadCandidates=links.length;
    diag.mail.downloadPolicy='PROVEN_PAGE_FETCH_NEWEST_FIRST';
    log(`Original-Mail: ${links.length} Nachrichtenzeile(n) gefunden → PAGE_FETCH (bewährter Weg), neueste Mail zuerst.`);
    for(let i=0;i<links.length;i++){
      try{
        const fetched=await provenPageFetch(page,links[i].href);
        if(fetched.ok&&fetched.base64){
          const bytes=Buffer.from(fetched.base64,'base64');
          if(validMsgBytes(bytes)){
            const file=path.join(cfg.downloadDirectory,`ticket_mail_${i+1}_${nowStamp()}.msg`);
            fs.writeFileSync(file,bytes);
            diag.mail.downloaded=true;
            diag.mail.directFetch=true;
            diag.mail.downloadMethod='PAGE_FETCH';
            diag.mail.downloadAutoClicked=false;
            diag.mail.source='MSG_DOWNLOAD';
            log(`PAGE_FETCH: Mail ${i+1} PASS - gültige MSG (${bytes.length} Bytes). Kein Download-Klick nötig.`);
            return file;
          }
          log(`PAGE_FETCH: Mail ${i+1} lieferte keine gültige Outlook-MSG → nächste Nachrichtenzeile.`);
        } else {
          log(`PAGE_FETCH: Mail ${i+1} nicht erfolgreich (${fetched.status??fetched.reason??'UNKNOWN'}) → nächste Nachrichtenzeile.`);
        }
      } catch(e) {
        log(`PAGE_FETCH: Mail ${i+1} Fehler (${e.code||e.name||'ERROR'}) → nächste Nachrichtenzeile.`);
      }
    }
    log('PAGE_FETCH konnte keine gültige MSG liefern. Nur jetzt folgt der alte Browserklick-Fallback.');
  }

  const anchors=await listDownloadAnchors(page);const since=Date.now();
  diag.mail.downloadCandidates=Math.max(diag.mail.downloadCandidates,anchors.length);
  const selected=MailDownload.chooseBottommost(anchors);
  if(selected){
    diag.mail.downloadPolicy='LEGACY_BROWSER_MOUSE_FALLBACK';diag.mail.downloadAutoClicked=true;diag.mail.downloadMethod='BROWSER_MOUSE';
    if(anchors.length===1)log('Fallback: genau ein Download-Pfeil gefunden → echter Browserklick.');
    else log(`Fallback: ${anchors.length} Download-Pfeile gefunden → unterste sichtbare Nachrichtenzeile.`);
    await page.mouseClick(selected.x,selected.y);
  } else {
    diag.mail.downloadPolicy='MANUAL_FALLBACK';diag.mail.downloadFallbackManual=true;diag.mail.downloadMethod='MANUAL';
    log('Kein Nachrichten-Downloadpfeil sicher erkannt. Bitte die unterste E-Mail im Nachrichtenverlauf manuell herunterladen.');
    if(!AUTO)await rl.question('ENTER drücken und dann den Download auslösen ... ');
  }
  let file=await waitNewMsg(cfg.downloadDirectory,since,25000);
  if(!file&&selected&&!AUTO){
    diag.mail.downloadFallbackManual=true;
    log('Automatischer Browserklick hat keinen Download geliefert. Bitte den Download-Pfeil der UNTERSTEN E-Mail einmal manuell anklicken.');
    await rl.question('ENTER drücken, nachdem du den Pfeil angeklickt hast ... ');file=await waitNewMsg(cfg.downloadDirectory,Date.now()-3000,30000);
  }
  need(file,'MAIL_DOWNLOAD','Keine neue .msg-Datei im Runner-Downloadordner gefunden.');
  const bytes=fs.readFileSync(file);
  need(validMsgBytes(bytes),'MAIL_DOWNLOAD_INVALID','Heruntergeladene Datei ist keine gültige Outlook-MSG.');
  diag.mail.downloaded=true;return file;
}
function choosePerson(mail, rl){
  const candidates=Person.candidates(mail);need(candidates.length,'NAME_NONE','Kein brauchbarer Namenshinweis in der MSG gefunden.');
  const analysis=Core.analyzeMail((mail.subject?'Betreff: '+mail.subject+'\n':'')+mail.body);
  const hints=Person.identifierHints(mail,analysis.idHints,candidates);
  const ids=[...new Set(hints.map(h=>h.clientId))];
  if(candidates.length===1){diag.mail.personAuto=true;return Promise.resolve({person:candidates[0],expectedId:ids.length===1?ids[0]:null});}
  // Strong local scoring: a unique name mentioned in the subject and/or address/signature wins only with clear margin.
  const subject=norm(mail.subject);const body=String(mail.body??'');
  const scored=candidates.map((c,i)=>{
    let score=0;const n1=norm(c.firstName+' '+c.lastName),n2=norm(c.lastName+' '+c.firstName);
    if(subject.includes(n1)||subject.includes(n2))score+=7;
    if(c.sources.includes('Adressblock'))score+=5;if(c.sources.includes('Beschrifteter Name'))score+=5;if(c.sources.includes('Signatur'))score+=3;if(c.sources.some(s=>/Absendername/.test(s)))score+=1;
    for(const id of ids){const re=new RegExp((c.firstName+'\\s+'+c.lastName+'|'+c.lastName+'\\s+'+c.firstName).replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'[\\s,;/]{0,8}'+id,'i');if(re.test(body)||re.test(mail.subject??''))score+=6;}
    return {i,c,score};
  }).sort((a,b)=>b.score-a.score);
  if(scored[0].score>=7&&(scored[1]?.score??-1)<=scored[0].score-3){diag.mail.personAuto=true;return Promise.resolve({person:scored[0].c,expectedId:ids.length===1?ids[0]:null});}
  if(AUTO){diag.mail.personAuto=true;return Promise.resolve({person:scored[0].c,expectedId:ids.length===1?ids[0]:null});}
  log('\nMehrere Namenshinweise in der Mail. Bitte die betroffene Person wählen:');
  scored.forEach((x,n)=>log(`  [${n+1}] ${x.c.name} (${x.c.sources.join(', ')})`));
  return rl.question('Nummer: ').then(v=>{
    const n=Number(v);need(Number.isInteger(n)&&n>=1&&n<=scored.length,'NAME_CHOICE','Ungültige Personenauswahl.');diag.mail.personManual=true;return {person:scored[n-1].c,expectedId:ids.length===1?ids[0]:null};
  });
}

async function memberFieldCenter(page){return await page.call(function(){
  const docs=[];(function walk(doc,d){if(!doc||d>5||docs.includes(doc))return;docs.push(doc);for(const f of doc.querySelectorAll('iframe,frame'))try{walk(f.contentDocument,d+1)}catch{}})(document,0);
  const vis=n=>{try{return n&&n.getClientRects().length>0&&!n.disabled&&!n.readOnly}catch{return false}};
  const hits=docs.map(d=>d.getElementById('mainForm:member-value-id')).filter(vis);if(hits.length!==1)return {ok:false,count:hits.length};
  const f=hits[0];f.scrollIntoView({block:'center',inline:'nearest'});const r=f.getBoundingClientRect();return {ok:true,x:r.left+r.width/2,y:r.top+r.height/2};
});}
async function primeMemberField(page){
  const c=await memberFieldCenter(page);need(c.ok,'MEMBER_FIELD','Member-Feld nicht eindeutig gefunden.');
  await page.mouseClick(c.x,c.y);await sleep(650);return c;
}
async function setMemberSearch(page, query){
  await primeMemberField(page);
  return await page.call(function(value){
    const docs=[];(function walk(doc,d){if(!doc||d>5||docs.includes(doc))return;docs.push(doc);for(const f of doc.querySelectorAll('iframe,frame'))try{walk(f.contentDocument,d+1)}catch{}})(document,0);
    const vis=n=>{try{return n&&n.getClientRects().length>0&&!n.disabled&&!n.readOnly}catch{return false}};
    const hits=docs.map(d=>d.getElementById('mainForm:member-value-id')).filter(vis);if(hits.length!==1)return {ok:false,count:hits.length};
    const f=hits[0],w=f.ownerDocument.defaultView,set=Object.getOwnPropertyDescriptor(w.HTMLInputElement.prototype,'value').set;
    set.call(f,'');f.dispatchEvent(new w.Event('input',{bubbles:true}));set.call(f,value);f.dispatchEvent(new w.Event('input',{bubbles:true}));
    const key=value.slice(-1)||'x',code=key.toUpperCase().charCodeAt(0)||88;f.dispatchEvent(new w.KeyboardEvent('keyup',{key,keyCode:code,which:code,bubbles:true}));return {ok:true};
  },query);
}

async function memberSuggestions(page, person){return await page.call(function(first,last){
  const docs=[];(function walk(doc,d){if(!doc||d>5||docs.includes(doc))return;docs.push(doc);for(const f of doc.querySelectorAll('iframe,frame'))try{walk(f.contentDocument,d+1)}catch{}})(document,0);
  const vis=n=>{try{return n?.isConnected&&n.getClientRects().length>0&&n.ownerDocument.defaultView.getComputedStyle(n).display!=='none'&&n.ownerDocument.defaultView.getComputedStyle(n).visibility!=='hidden'}catch{return false}};
  const fold=s=>String(s??'').replace(/Ä/g,'Ae').replace(/Ö/g,'Oe').replace(/Ü/g,'Ue').replace(/ä/g,'ae').replace(/ö/g,'oe').replace(/ü/g,'ue').replace(/ß/g,'ss');
  const norm=s=>fold(String(s??'').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim()).toLocaleLowerCase('de-DE').replace(/[.,]/g,'');
  const f=docs.map(d=>d.getElementById('mainForm:member-value-id')).find(vis);if(!f)return [];
  const fr=f.getBoundingClientRect(),want=[norm(last+' '+first),norm(first+' '+last)],targets=[];
  for(const leaf of f.ownerDocument.querySelectorAll('div,span,label,li,tr,td,button,a')){
    if(!vis(leaf))continue;const text=String(leaf.innerText??leaf.textContent??'').replace(/\s+/g,' ').trim();if(!text||text.length>350)continue;const nt=norm(text);if(!want.some(w=>nt.startsWith(w)||nt.includes(w)))continue;
    let target=null,n=leaf;for(let d=0;n&&d<5;d++,n=n.parentElement){if(typeof n.onmousedown==='function'){target=n;break;}if(['FORM','BODY','HTML'].includes(n.tagName))break;}
    if(!target||!vis(target))continue;const r=target.getBoundingClientRect();if(r.top<fr.top-30||r.top>fr.bottom+650||Math.abs(r.left-fr.left)>1000)continue;
    const t=String(target.innerText??target.textContent??text).replace(/\s+/g,' ').trim();const m=t.match(/\bINTL01-(\d{1,15})\b/i);targets.push({text:t,id:m?m[1]:null,x:r.left+r.width/2,y:r.top+r.height/2,width:r.width,height:r.height});
  }
  const seen=new Set();return targets.filter(x=>{const k=[x.id??'',x.text,Math.round(x.x),Math.round(x.y)].join('|');if(seen.has(k))return false;seen.add(k);return true;});
},person.firstName,person.lastName);}

async function selectedMember(page, person=null){return await page.call(function(first,last){
  const docs=[];(function walk(doc,d){if(!doc||d>5||docs.includes(doc))return;docs.push(doc);for(const f of doc.querySelectorAll('iframe,frame'))try{walk(f.contentDocument,d+1)}catch{}})(document,0);
  const vis=n=>{try{return !!n&&n.getClientRects().length>0&&n.ownerDocument.defaultView.getComputedStyle(n).display!=='none'&&n.ownerDocument.defaultView.getComputedStyle(n).visibility!=='hidden'}catch{return false}};
  const clean=v=>String(v??'').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();
  const fold=s=>clean(s).replace(/Ä/g,'Ae').replace(/Ö/g,'Oe').replace(/Ü/g,'Ue').replace(/ä/g,'ae').replace(/ö/g,'oe').replace(/ü/g,'ue').replace(/ß/g,'ss').toLocaleLowerCase('de-DE').replace(/[.,]/g,'');
  const idFrom=s=>{const m=clean(s).match(/(?:^|\b)INTL01-(\d{1,15})(?:\b|$)/i);return m?m[1]:null};
  const fields=docs.map(d=>d.getElementById('mainForm:member-value-id')).filter(vis);
  if(fields.length!==1)return null;
  const f=fields[0],display=clean(f.value);
  const direct=idFrom(display);
  if(direct)return {id:direct,display,source:'MEMBER_FIELD',firstName:null,lastName:null};

  // Some real COMARCH forms keep only the person's name in the Member input
  // and render MercerID/Vorname/Nachname in separate profile rows. Detect that
  // committed state semantically instead of requiring INTL01-* in the input.
  const scope=f.form||f.closest('form')||f.ownerDocument;
  function rowValue(labelRe, valueKind){
    const vals=[];
    const rows=scope.querySelectorAll('tr');
    for(let ri=0;ri<rows.length;ri++){
      const row=rows[ri];if(!vis(row))continue;
      const cells=row.cells||[];
      for(let ci=0;ci<cells.length;ci++){
        const label=clean(cells[ci].innerText||cells[ci].textContent);
        if(!labelRe.test(label))continue;
        for(let j=ci+1;j<cells.length;j++){
          const v=clean(cells[j].innerText||cells[j].textContent);if(!v||v.length>120)continue;
          if(valueKind==='id'){const id=idFrom(v);if(id)vals.push(id);}
          else if(!/:/.test(v)&&/^[\p{L}\p{M} .'’\-]{1,100}$/u.test(v))vals.push(v);
          break;
        }
      }
    }
    return [...new Set(vals)];
  }
  const ids=rowValue(/^Mercer\s*ID\s*:?$/i,'id');
  const firsts=rowValue(/^Vorname\s*:?$/i,'text');
  const lasts=rowValue(/^Nachname\s*:?$/i,'text');
  if(ids.length!==1||firsts.length!==1||lasts.length!==1)return null;
  if(first&&last&&(fold(firsts[0])!==fold(first)||fold(lasts[0])!==fold(last)))return null;
  return {id:ids[0],display:display||clean(lasts[0]+' '+firsts[0]),source:'PROFILE_ROWS',firstName:firsts[0],lastName:lasts[0]};
},person?.firstName??null,person?.lastName??null);}

async function selectMember(page, person, expectedId, rl){
  const reviewed=Person.query(person.firstName,person.lastName);
  // Recovery: a prior partial submit may already have committed the correct
  // Member even though the ticket itself was not saved yet. Reuse only when
  // the semantic COMARCH profile matches the person from the current mail.
  const preselected=await selectedMember(page,person);
  if(preselected){
    if(expectedId&&preselected.id!==expectedId)fail('MEMBER_ID_CONFLICT','Bereits ausgewählter COMARCH-Member widerspricht dem geprüften MercerID-Hinweis aus der Mail.');
    diag.member.selected=true;diag.member.commitSource=preselected.source;diag.member.profileMatched=preselected.source==='PROFILE_ROWS';
    log(`COMARCH-Member bereits übernommen. MercerID aus ${preselected.source==='PROFILE_ROWS'?'Profilfeldern':'Member-Feld'} gelesen.`);
    return preselected;
  }
  const searchQuery=QueueSend.memberSearchQuery(person.firstName,person.lastName);diag.member.searchStarted=true;
  const set=await setMemberSearch(page,searchQuery);need(set.ok,'MEMBER_FIELD','Member-Feld nicht eindeutig gefunden.');
  log(`Member-Suche gestartet: ${searchQuery}${searchQuery!==reviewed.query?' (COMARCH-Umlautnormalisierung aktiv)':''}`);
  let suggestions=[];
  for(let i=0;i<45;i++){await sleep(180);suggestions=await memberSuggestions(page,person);if(suggestions.length)break;}
  let pick=null;
  if(expectedId){const exact=suggestions.filter(s=>s.id===expectedId);if(exact.length===1)pick=exact[0];}
  if(!pick&&suggestions.length===1)pick=suggestions[0];
  if(pick){
    log('Eindeutiger Member-Vorschlag erkannt → echter Browser-Mausklick.');diag.member.autoClicked=true;await page.mouseClick(pick.x,pick.y);
  } else {
    diag.member.manualGate=true;
    log(suggestions.length?`Mehrere/uneindeutige Member-Vorschläge (${suggestions.length}) → bitte richtigen Treffer im Edge-Fenster anklicken.`:'Vorschlagsliste nicht sicher erkannt → bitte richtigen Member im Edge-Fenster anklicken.');
    if(!AUTO)await rl.question('ENTER drücken; Runner wartet danach auf die übernommene MercerID ... ');
  }
  let selected=null;
  for(let i=0;i<150;i++){selected=await selectedMember(page,person);if(selected)break;await sleep(200);}
  need(selected,'MEMBER_COMMIT','COMARCH hat keinen ausgewählten Member mit MercerID übernommen.');
  if(expectedId&&selected.id!==expectedId)fail('MEMBER_ID_CONFLICT','Ausgewählter COMARCH-Member widerspricht dem geprüften MercerID-Hinweis aus der Mail.');
  diag.member.selected=true;diag.member.commitSource=selected.source||'UNKNOWN';diag.member.profileMatched=selected.source==='PROFILE_ROWS';if(selected.source==='PROFILE_ROWS')log('COMARCH-Member übernommen. Member-Feld enthält nur den Namen; MercerID wurde aus den COMARCH-Profilfeldern gelesen.');return selected;
}

async function writeDescription(page,text){return await page.call(function(value){
  const docs=[];(function walk(doc,d){if(!doc||d>6||docs.includes(doc))return;docs.push(doc);for(const f of doc.querySelectorAll('iframe,frame'))try{walk(f.contentDocument,d+1)}catch{}})(document,0);
  const norm=v=>String(v??'').normalize('NFC').replace(/[\u00a0\u202f]/g,' ').replace(/[\u200b\ufeff]/g,'').replace(/\s+/g,' ').trim();
  const isLabel=v=>/^Zus(?:ä|ae)tzliche Beschreibung\s*:?$/i.test(norm(v));
  const visible=n=>{try{const s=n.ownerDocument.defaultView.getComputedStyle(n);return !!n.isConnected&&n.getClientRects().length>0&&s.visibility!=='hidden'&&s.visibility!=='collapse'&&s.display!=='none'&&!n.closest('[hidden],[inert]')}catch{return false}};
  const owner=n=>n?.form??n?.closest?.('form')??n?.ownerDocument;
  function caption(n){
    if(!n||!visible(n))return '';let count=0,out='';
    function walk(p){if(++count>160||out.length>220)return;if(p.nodeType===3){out+=' '+p.textContent;return;}if(p.nodeType!==1||p.matches('input,textarea,select,button,script,style,iframe,frame,[hidden],[inert],[contenteditable="true"]')||!visible(p))return;for(const c of p.childNodes)walk(c);}
    walk(n);return count>160||out.length>220?'':norm(out);
  }
  function linkedNames(n){const out=[];for(const l of n.labels??[]){const t=caption(l);if(t)out.push(t);}const a=norm(n.getAttribute('aria-label'));if(a)out.push(a);return [...new Set(out)];}
  let member=null;for(const doc of docs){const n=doc.getElementById('mainForm:member-value-id');if(n&&visible(n)){if(member)return {ok:false,state:'MULTIPLE_MEMBER_FIELDS',count:0};member=n;}}
  if(!member)return {ok:false,state:'NO_MEMBER_FIELD',count:0};
  const doc=member.ownerDocument,scope=owner(member);
  const same=n=>n?.ownerDocument===doc&&owner(n)===scope&&n.getRootNode()===doc;
  const shape=n=>n?.tagName==='TEXTAREA'&&same(n)&&visible(n)&&!n.isContentEditable&&!n.disabled&&!n.readOnly&&!n.closest('[contenteditable="true"],[role="listbox"],[role="option"]');
  const areas=[...doc.querySelectorAll('textarea')].filter(shape);if(areas.length>128)return {ok:false,state:'SCAN_LIMIT',count:areas.length};
  const hits=new Map();const take=(n,route)=>{if(shape(n)&&!linkedNames(n).some(t=>!isLabel(t))&&!hits.has(n))hits.set(n,route);};
  for(const n of areas)if(linkedNames(n).some(isLabel))take(n,'LABEL_ASSOCIATION');
  const nodes=[...scope.querySelectorAll('label,span,td,th,div,b,strong,dt,dd,p')];
  function takeContainer(n,route){if(!n||n===scope||!visible(n)||['FORM','BODY','HTML'].includes(n.tagName))return;if(n.tagName==='TEXTAREA'){take(n,route);return;}if(n.querySelector('input:not([type="hidden"]),select,button,iframe,frame,[contenteditable="true"]'))return;const t=caption(n);if(t&&!isLabel(t))return;const targets=[...n.querySelectorAll('textarea')].filter(shape);if(targets.length===1)take(targets[0],route);}
  for(const label of nodes){
    if(!visible(label)||!isLabel(caption(label))||label.querySelector('textarea,input,select,iframe,frame'))continue;
    if([...label.children].some(n=>isLabel(caption(n))))continue;
    if(label.htmlFor)take(doc.getElementById(label.htmlFor),'LABEL_FOR');
    let n=label;for(let depth=0;n&&depth<6;depth++){
      takeContainer(n.nextElementSibling,depth?'WRAPPED_LABEL_VALUE':'LABEL_NEXT');
      const parent=n.parentElement;if(!parent||parent===scope||['FORM','BODY','HTML'].includes(parent.tagName))break;
      takeContainer(parent,'LABEL_LOCAL_CONTAINER');
      if(!isLabel(caption(parent))||parent.querySelector('textarea,input,select,button,iframe,frame'))break;n=parent;
    }
  }
  // Geometric fallback for old table layouts: exact semantic label above/left of
  // one writable textarea. It is only accepted when the nearest candidate is
  // clearly closer than every other textarea in the same form.
  if(hits.size===0){
    const labels=nodes.filter(n=>visible(n)&&isLabel(caption(n))&&!n.querySelector('textarea,input,select,iframe,frame'));
    const scored=[];
    for(const l of labels){const lr=l.getBoundingClientRect();for(const a of areas){const ar=a.getBoundingClientRect();const below=ar.top>=lr.top-8;const dx=Math.max(0,Math.max(lr.left-ar.right,ar.left-lr.right));const dy=Math.max(0,ar.top-lr.bottom);if(!below||dx>500||dy>260)continue;scored.push({a,score:dy+dx*0.2});}}
    scored.sort((x,y)=>x.score-y.score);if(scored.length&&(!scored[1]||scored[1].score-scored[0].score>24))take(scored[0].a,'GEOMETRIC_LABEL_NEAREST');
  }
  if(hits.size!==1)return {ok:false,state:hits.size?'AMBIGUOUS':'NOT_FOUND',count:hits.size,textareaCount:areas.length};
  const [f,route]=[...hits][0];if(f.value.trim()&&f.value!==value)return {ok:false,state:'OCCUPIED',occupied:true,count:1,route};
  if(f.value!==value){const w=f.ownerDocument.defaultView,set=Object.getOwnPropertyDescriptor(w.HTMLTextAreaElement.prototype,'value')?.set;if(typeof set!=='function')return {ok:false,state:'NO_SETTER',count:1,route};set.call(f,value);f.dispatchEvent(new w.Event('input',{bubbles:true}));f.dispatchEvent(new w.Event('change',{bubbles:true}));}
  return {ok:f.value===value,state:f.value===value?'DOM_VERIFIED':'VERIFY_FAILED',count:1,route};
},text);}

async function verifyDescription(page,text){return await page.call(function(value){
  const norm=v=>String(v??'').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();
  const docs=[];(function walk(doc,d){if(!doc||d>6||docs.includes(doc))return;docs.push(doc);for(const f of doc.querySelectorAll('iframe,frame'))try{walk(f.contentDocument,d+1)}catch{}})(document,0);
  const visible=n=>{try{return n?.isConnected&&n.getClientRects().length>0&&n.ownerDocument.defaultView.getComputedStyle(n).display!=='none'&&n.ownerDocument.defaultView.getComputedStyle(n).visibility!=='hidden'}catch{return false}};
  const matches=[];for(const doc of docs)for(const t of doc.querySelectorAll('textarea'))if(visible(t)&&norm(t.value)===norm(value))matches.push(t);
  return {ok:matches.length===1,count:matches.length};
},text);}

async function setSelectExact(page,id,text){return await page.call(function(id,text){
  const s=document.getElementById(id);if(!s||s.tagName!=='SELECT'||s.disabled)return {ok:false};const norm=v=>String(v??'').replace(/\s+/g,' ').trim();const o=[...s.options].filter(x=>norm(x.textContent)===text);if(o.length!==1)return {ok:false,count:o.length};const set=Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype,'value').set;set.call(s,o[0].value);s.dispatchEvent(new Event('input',{bubbles:true}));s.dispatchEvent(new Event('change',{bubbles:true}));return {ok:norm(s.selectedOptions[0]?.textContent)===text};
},id,text);}

async function inputCenterById(page,id){return await page.call(function(id){
  const f=document.getElementById(id);if(!f||f.tagName!=='INPUT'||f.disabled||f.readOnly||!f.getClientRects().length)return {ok:false};f.scrollIntoView({block:'center',inline:'nearest'});const r=f.getBoundingClientRect();return {ok:true,x:r.left+r.width/2,y:r.top+r.height/2};
},id);}
async function waitEditable(page,id,timeoutMs=7000){
  const deadline=Date.now()+timeoutMs;while(Date.now()<deadline){const c=await inputCenterById(page,id);if(c.ok)return c;await sleep(180);}return {ok:false};
}
async function setSuggestExact(page,id,text){
  const center=await waitEditable(page,id);need(center.ok,'FIXED_FIELD','Feld nicht bearbeitbar: '+text);
await page.mouseClick(center.x,center.y);await sleep(300);
  const init=await page.call(function(id,value){
    const f=document.getElementById(id);if(!f||f.tagName!=='INPUT'||f.disabled||f.readOnly)return {ok:false};const set=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;set.call(f,'');f.dispatchEvent(new Event('input',{bubbles:true}));set.call(f,value);f.dispatchEvent(new Event('input',{bubbles:true}));const k=value.slice(-1)||'x',code=k.toUpperCase().charCodeAt(0)||88;f.dispatchEvent(new KeyboardEvent('keyup',{key:k,keyCode:code,which:code,bubbles:true}));return {ok:true};
  },id,text);need(init.ok,'FIXED_FIELD','Feld nicht bearbeitbar: '+text);
  let rows=[];
  for(let i=0;i<35;i++){await sleep(180);rows=await page.call(function(id,expected){
    const f=document.getElementById(id);if(!f)return[];const fr=f.getBoundingClientRect(),norm=v=>String(v??'').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();const out=[];
    for(const leaf of document.querySelectorAll('div,span,label,li,tr,td,button,a')){if(!leaf.getClientRects().length)continue;const t0=norm(leaf.innerText??leaf.textContent);if(t0!==expected)continue;let n=leaf,target=null;for(let d=0;n&&d<5;d++,n=n.parentElement){if(typeof n.onmousedown==='function'){target=n;break;}if(['FORM','BODY','HTML'].includes(n.tagName))break;}if(!target||!target.getClientRects().length)continue;const r=target.getBoundingClientRect();if(r.top<fr.top-20||r.top>fr.bottom+500||Math.abs(r.left-fr.left)>800)continue;out.push({x:r.left+r.width/2,y:r.top+r.height/2,text:t0});}return out;
  },id,text);if(rows.length)break;}
  if(rows.length===1){
    const fired=await page.call(function(id,expected){
      const f=document.getElementById(id);if(!f)return {ok:false,count:0};const fr=f.getBoundingClientRect(),norm=v=>String(v??'').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim(),targets=[];
      for(const leaf of document.querySelectorAll('div,span,label,li,tr,td,button,a')){if(!leaf.getClientRects().length||norm(leaf.innerText??leaf.textContent)!==expected)continue;let n=leaf,target=null;for(let d=0;n&&d<5;d++,n=n.parentElement){if(typeof n.onmousedown==='function'){target=n;break;}if(['FORM','BODY','HTML'].includes(n.tagName))break;}if(!target||!target.getClientRects().length)continue;const r=target.getBoundingClientRect();if(r.top<fr.top-20||r.top>fr.bottom+500||Math.abs(r.left-fr.left)>800)continue;if(!targets.includes(target))targets.push(target);}
      if(targets.length!==1)return {ok:false,count:targets.length};const target=targets[0],w=target.ownerDocument.defaultView;setTimeout(()=>target.dispatchEvent(new w.MouseEvent('mousedown',{bubbles:true,cancelable:true,view:w,button:0,buttons:1})),0);return {ok:true,count:1};
    },id,text);
    if(!fired.ok)rows=[];
    await sleep(1000);
  }else{await sleep(750);}
  const value=await page.call((id)=>document.getElementById(id)?.value??null,id);return {ok:clean(value)===text,selection:rows.length===1?'MOUSE':'TEXT_ONLY',rows:rows.length};
}


async function setSubcategoryExact(page,text){
  const center=await waitEditable(page,'mainForm:category-sub-value-id');need(center.ok,'FIXED_FIELD','Feld nicht bearbeitbar: '+text);
  const init=await page.call(function(value){
    const f=document.getElementById('mainForm:category-sub-value-id');if(!f||f.tagName!=='INPUT'||f.disabled||f.readOnly)return {ok:false};
    const set=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;set.call(f,'');f.dispatchEvent(new Event('input',{bubbles:true}));set.call(f,value);f.dispatchEvent(new Event('input',{bubbles:true}));const k=value.slice(-1)||'x',code=k.toUpperCase().charCodeAt(0)||88;f.dispatchEvent(new KeyboardEvent('keyup',{key:k,keyCode:code,which:code,bubbles:true}));return {ok:true};
  },text);need(init.ok,'FIXED_FIELD','Feld nicht bearbeitbar: '+text);
  await sleep(1200);
  const value=await page.call(()=>document.getElementById('mainForm:category-sub-value-id')?.value??null);
  return {ok:clean(value)===text,selection:'KEYUP_SUBMIT'};
}

async function prepareFixed(page,rl){
  if(DEMO){
    await page.call(function(){document.getElementById('mainForm:responsibility-value-id').value='Second Level';document.getElementById('mainForm:category-value-id').value='Allgemeine Schriftwechsel';document.getElementById('mainForm:category-sub-value-id').value='Personenschriftwechsel';document.getElementById('mainForm:signature-value-id').value='INTL01 - Intel Deutschland GmbH';});
    diag.fixed.responsibility=diag.fixed.category=diag.fixed.subcategory=diag.fixed.signature=true;
    log('Feste Felder (DEMO) gesetzt.');return;
  }
  log('Feste Felder: Zuständigkeit → Second Level');
  const r=await setSelectExact(page,'mainForm:responsibility-value-id',Prep.FIXED.responsibility);need(r.ok,'RESPONSIBILITY','Second Level konnte nicht gesetzt werden.');diag.fixed.responsibility=true;
  log('Feste Felder: Dokumentenkategorie → '+Prep.FIXED.category);
  let s=await setSuggestExact(page,'mainForm:category-value-id',Prep.FIXED.category);
  if(!s.ok&&!AUTO){log(`${Prep.FIXED.category}: automatische Vorschlagsauswahl nicht bestätigt. Bitte im Edge-Fenster exakt „${Prep.FIXED.category}“ auswählen.`);await rl.question('ENTER danach ... ');}let v=await page.call((id)=>document.getElementById(id)?.value??'','mainForm:category-value-id');need(clean(v)===Prep.FIXED.category,'FIXED_VERIFY',Prep.FIXED.category+' ist im COMARCH-Feld nicht sichtbar.');diag.fixed.category=true;
  // COMARCH ersetzt Teile des Formulars nach der Member-Übernahme und auch
  // nach Kategorie-Updates. Deshalb das echte Member-Feld HIER erneut real
  // anklicken, bevor die abhängige Unterkategorie geprüft/gesetzt wird.
  log('Abhängige Felder aktivieren → Member-Feld wird erneut real angeklickt.');
  await primeMemberField(page);await sleep(700);
  const subReady=await waitEditable(page,'mainForm:category-sub-value-id',10000);need(subReady.ok,'FIXED_FIELD','Unterkategorie blieb nach erneutem Member-Klick nicht bearbeitbar.');
  log('Feste Felder: Unterkategorie → '+Prep.FIXED.subcategory);
  s=await setSuggestExact(page,'mainForm:category-sub-value-id',Prep.FIXED.subcategory);
  if(!s.ok&&!AUTO){log(`${Prep.FIXED.subcategory}: automatische Vorschlagsauswahl nicht bestätigt. Bitte im Edge-Fenster exakt „${Prep.FIXED.subcategory}“ auswählen.`);await rl.question('ENTER danach ... ');}v=await page.call((id)=>document.getElementById(id)?.value??'','mainForm:category-sub-value-id');need(clean(v)===Prep.FIXED.subcategory,'FIXED_VERIFY',Prep.FIXED.subcategory+' ist im COMARCH-Feld nicht sichtbar.');diag.fixed.subcategory=true;
  log('Feste Felder: Signatur → '+Prep.FIXED.signature);
  s=await setSuggestExact(page,'mainForm:signature-value-id',Prep.FIXED.signature);
  if(!s.ok&&!AUTO){log(`${Prep.FIXED.signature}: automatische Vorschlagsauswahl nicht bestätigt. Bitte im Edge-Fenster exakt „${Prep.FIXED.signature}“ auswählen.`);await rl.question('ENTER danach ... ');}v=await page.call((id)=>document.getElementById(id)?.value??'','mainForm:signature-value-id');need(clean(v)===Prep.FIXED.signature,'FIXED_VERIFY',Prep.FIXED.signature+' ist im COMARCH-Feld nicht sichtbar.');diag.fixed.signature=true;
}

async function editorWrite(page,text){return await page.call(function(value){
  const docs=[];(function walk(doc,d){if(!doc||d>6||docs.includes(doc))return;docs.push(doc);for(const f of doc.querySelectorAll('iframe,frame'))try{walk(f.contentDocument,d+1)}catch{}})(document,0);
  const visible=n=>{try{return n&&n.getClientRects().length>0}catch{return false}};const hits=[];
  for(const doc of docs)for(const n of doc.querySelectorAll('[contenteditable="true"],body[contenteditable="true"],html[contenteditable="true"]'))if(visible(n))hits.push(n);
  const uniq=[...new Set(hits)].filter(n=>!hits.some(x=>x!==n&&n.contains(x)));
  if(uniq.length!==1)return {ok:false,count:uniq.length};const e=uniq[0];const norm=s=>String(s??'').replace(/\r\n?/g,'\n').replace(/\u00a0/g,' ').replace(/[ \t]+\n/g,'\n').replace(/\n[ \t]+/g,'\n').trim();
  const old=norm(e.innerText??e.textContent);if(old&&old!==norm(value))return {ok:false,occupied:true};e.innerHTML=value.split('\n').map(s=>s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')).join('<br>');e.dispatchEvent(new e.ownerDocument.defaultView.Event('input',{bubbles:true}));return {ok:norm(e.innerText??e.textContent)===norm(value)};
},text);}

async function injectDemo(page){
  const html=`<style>body{font:16px Segoe UI;margin:20px}nav a{margin-right:16px;cursor:pointer;color:#06c}table{border-collapse:collapse;margin-top:12px}td,th{border:1px solid #aaa;padding:7px}input,select,textarea{font:inherit;padding:6px}.suggest{position:absolute;background:#fff;border:1px solid #777;padding:4px;z-index:50}.suggest div{padding:6px;cursor:pointer}.icePnlPop,[role=dialog]{position:fixed;left:40%;top:30%;background:#fff;border:2px solid #555;padding:18px;z-index:100}iframe{width:700px;height:180px}</style>
  <nav><a title="Meine Vorgänge" id="myHeader">Meine Vorgänge</a><span id="storedSearchesContainer_MY_TASKS"><a id="myChild">In_Bearbeitung</a></span> | <a title="Warteschlange" id="queueHeader">Warteschlange</a><span id="storedSearchesContainer_MY_QUEUES"><a id="queueChild">INTL01</a></span></nav><div id="app"></div>`;
  await page.eval(`document.body.innerHTML=${JSON.stringify(html)};document.title='MCR Full Queue Demo';`);
  await page.eval(`(()=>{const app=document.getElementById('app');const state={current:null,source:null,descs:{'90000001':'','90000002':''}};
  const row=(id)=>'<tr tabindex="0" data-ticket="'+id+'"><td><button type="button" data-open="'+id+'">'+id+'</button></td><td>E-MAIL</td><td>'+state.descs[id]+'</td></tr>';
  function my(){state.current=null;state.source='MY';app.innerHTML='<h1>Meine Vorgänge</h1><table id="mainForm:tasksTableFor_MyTasksList"><thead><tr><th>Ticket-ID</th><th>Quelle</th><th>Zusätzliche Beschreibung</th></tr></thead><tbody>'+row('90000001')+'</tbody></table>';bindRows();}
  function queue(){state.current=null;state.source='QUEUE';app.innerHTML='<h1>Warteschlange INTL01</h1><table id="mainForm:tasksTableFor_MyQueuesTasksList"><thead><tr><th>Ticket-ID</th><th>Quelle</th><th>Zusätzliche Beschreibung</th></tr></thead><tbody>'+row('90000002')+'</tbody></table>';bindRows();}
  function bindRows(){app.querySelectorAll('[data-open]').forEach(b=>{b.onclick=()=>detail(b.dataset.open);b.closest('tr').onclick=()=>detail(b.dataset.open);});}
  function detail(id){state.current=id;app.innerHTML='<h1>Ticket-ID: <span>'+id+'</span></h1><button id="edit">Bearbeiten</button>';document.getElementById('edit').onclick=()=>edit(id);}
  function edit(id){state.current=id;app.innerHTML='<div><b>Ticket-ID:</b> <span>'+id+'</span></div><table id="history"><thead><tr><th>Original</th><th>Von</th><th>An</th><th>Betreff</th><th>Inhalt</th><th>Datum</th><th>Anlage</th></tr></thead><tbody><tr><td><a href="GetFile?docId=1">x</a></td><td>max@example.invalid</td><td>b</td><td>Test</td><td>Name: Max Mustermann</td><td>01.01.2026</td><td></td></tr></tbody></table><label>Zuständigkeit <select id="mainForm:responsibility-value-id"><option></option><option>Second Level</option></select></label><br><label>Dokumentenkategorie <input id="mainForm:category-value-id"></label><br><label>Unterkategorie <input id="mainForm:category-sub-value-id"></label><br><label>Member <input id="mainForm:member-value-id"></label><table><tr><td>MercerID:</td><td><span id="mercer"></span></td></tr><tr><td>Vorname:</td><td><span id="first"></span></td></tr><tr><td>Nachname:</td><td><span id="last"></span></td></tr></table><label>Zusätzliche Beschreibung:<textarea id="desc"></textarea></label><br><label>Signatur <input id="mainForm:signature-value-id"></label><br><table><tr><td><label>An:</label></td><td><span>max@example.invalid</span></td></tr></table><iframe id="editor"></iframe><input id="mainForm:send-new-message-button" type="button" value="Senden"><a id="saveTicket">Ticket speichern</a>';
    const specs={'mainForm:member-value-id':['Mustermann Max (INTL01-99900001) - 1970-01-01'],'mainForm:category-value-id':['Allgemeine Schriftwechsel'],'mainForm:category-sub-value-id':['Personenschriftwechsel'],'mainForm:signature-value-id':['INTL01 - Intel Deutschland GmbH']};
    for(const [fid,vals] of Object.entries(specs)){const f=document.getElementById(fid),render=()=>{document.querySelectorAll('.suggest').forEach(x=>x.remove());const box=document.createElement('div');box.className='suggest';const r=f.getBoundingClientRect();box.style.left=r.left+'px';box.style.top=(r.bottom+scrollY)+'px';vals.forEach(t=>{const d=document.createElement('div');d.textContent=t;d.onmousedown=e=>{f.value=(fid==='mainForm:member-value-id'?'Mustermann Max':t);if(fid==='mainForm:member-value-id'){document.getElementById('mercer').textContent='INTL01-99900001';document.getElementById('first').textContent='Max';document.getElementById('last').textContent='Mustermann';}box.remove();e.preventDefault();};box.append(d)});document.body.append(box)};f.addEventListener('focus',render);f.addEventListener('input',render);}
    const ed=document.getElementById('editor');ed.srcdoc='<html><body contenteditable="true"></body></html>';
    document.getElementById('mainForm:send-new-message-button').onclick=()=>showOk(1);
    document.getElementById('saveTicket').onclick=()=>{state.descs[id]=document.getElementById('desc').value;};
  }
  function showOk(n){const d=document.createElement('div');d.setAttribute('role','dialog');d.innerHTML='<p>Bestätigung '+n+'</p><button>OK</button>';d.querySelector('button').onclick=()=>{d.remove();if(n===1)showOk(2);else{const ed=document.getElementById('editor');try{ed.contentDocument.body.innerHTML='';}catch{}const tb=document.querySelector('#history tbody');const tr=document.createElement('tr');tr.innerHTML='<td>x</td><td>system</td><td>max</td><td>gesendet</td><td>ok</td><td>jetzt</td><td></td>';tb.append(tr);}};document.body.append(d);}
  document.getElementById('myHeader').onclick=my;document.getElementById('myChild').onclick=my;document.getElementById('queueHeader').onclick=queue;document.getElementById('queueChild').onclick=queue;my();})()`);
}

async function writeDiagnostic(cfg){
  fs.mkdirSync(cfg.diagnosticDirectory,{recursive:true});diag.createdAt=new Date().toISOString();const report=JSON.stringify(diag,null,2)+'\n';const manifest=JSON.stringify({schema:'MCR_DIAGNOSTIC_MANIFEST_V1',payload:[{path:'diagnostic.json',sha256:sha256(report)}],privacy:diag.privacy},null,2)+'\n';const zip=writeZip([{name:'diagnostic.json',data:report},{name:'manifest.json',data:manifest},{name:'SHA256SUMS.txt',data:sha256(report)+'  diagnostic.json\n'+sha256(manifest)+'  manifest.json\n'}]);const p=path.join(cfg.diagnosticDirectory,`MCR_LOCAL_RUNNER_${nowStamp()}_UPLOAD.zip`);fs.writeFileSync(p,zip);return {path:p,sha256:sha256(zip)};
}


async function processOpenedTicket(page,mapping,rl,row,sourceScope){
  resetTicketDiag();
  diag.queue.selected=true;diag.queue.scope=sourceScope;diag.queue.ticketBound=!!row.ticketId;
  await ensureEditModeMulti(page);

  let mail=null,person=null,expectedId=null;
  const historyChoice=await choosePersonFromHistory(page,rl);
  if(historyChoice){
    ({mail,person,expectedId}=historyChoice);diag.mail.parsed=true;
    log(`Ticket-Mail direkt aus dem Nachrichtenverlauf gelesen (${diag.mail.historyRows} Zeile(n)); kein Download nötig.`);
  }else{
    log('Im Nachrichtenverlauf kein ausreichend verwertbarer Namenshinweis gefunden → Fallback auf MSG-Download.');
    const cfg=resolveConfig();
    const msgPath=await downloadCurrentMail(page,cfg,rl);
    mail=Msg.parseMsg(fs.readFileSync(msgPath));diag.mail.parsed=true;diag.mail.source='MSG_DOWNLOAD';
    ({person,expectedId}=await choosePerson(mail,rl));log('Original-MSG lokal gelesen.');
  }

  log('Person für Member-Suche festgelegt: '+person.lastName+' '+person.firstName+(expectedId?' [MercerID-Hinweis vorhanden]':''));
  const selected=await selectMember(page,person,expectedId,rl);
  log('COMARCH-Member übernommen. MercerID wurde aus COMARCH gelesen.');

  diag.lookup.attempted=true;
  const entry=Core.lookup(mapping.map,selected.id);
  diag.lookup.ready=true;
  log('Bestandsabgleich: '+entry.description);

  const dw=await writeDescription(page,entry.description);
  diag.description.route=dw.route??null;diag.description.candidates=dw.count??null;
  need(dw.ok,'DESCRIPTION_WRITE','Zusätzliche Beschreibung konnte nicht eindeutig eingesetzt werden ('+(dw.state??'UNBEKANNT')+').');
  diag.description.written=true;
  await sleep(700);
  const dv=await verifyDescription(page,entry.description);
  need(dv.ok,'DESCRIPTION_VERIFY','Zusätzliche Beschreibung war nach der Seitenreaktion nicht mehr eindeutig nachweisbar.');
  diag.description.verified=true;
  log('Zusätzliche Beschreibung eingesetzt und nach Seitenreaktion erneut verifiziert.');

  await prepareFixed(page,rl);
  log('Feste Felder vorbereitet: Second Level / Kategorien / Signatur.');

  let sal=null;
  if(entry.gender==='M'){sal='Herr';diag.reply.salutationSource='MAPPING_O_M';log('Anrede automatisch aus Spalte O: Herr (M).');}
  else if(entry.gender==='F'){sal='Frau';diag.reply.salutationSource='MAPPING_O_F';log('Anrede automatisch aus Spalte O: Frau (F).');}
  else if(DEMO){sal='Herr';diag.reply.salutationSource='DEMO';}
  else if(!AUTO){
    const sv=clean(await rl.question('Spalte O ist leer. Anrede [H]err / [F]rau: ')).toLowerCase();
    sal=sv.startsWith('f')?'Frau':'Herr';diag.reply.salutationSource='MANUAL_FALLBACK';
  }else fail('SALUTATION_REQUIRED','Spalte O enthält für diesen Member kein M/F. Keine automatische Anrede ohne Datenquelle.');

  const reply=Prep.replyText(sal,person.lastName);
  diag.reply.generated=true;
  const ew=await editorWrite(page,reply);
  need(ew.ok,'REPLY_WRITE',ew.occupied?'Antworteditor enthält bereits abweichenden Text.':'Antworteditor konnte nicht eindeutig beschrieben werden.');
  diag.reply.written=true;
  await sleep(500);diag.reply.verified=true;

  const recipient=await recipientAddress(page);
  need(recipient.ok,'RECIPIENT','Empfänger im Feld „An“ ist nicht eindeutig. Kein automatischer Versand.');

  if(!FULL_RUN&&!AUTO){
    log('\nBitte im Edge-Fenster Empfänger, feste Felder, Beschreibung und Antworttext prüfen.');
    const ok=clean(await rl.question('Alles korrekt? Tippe JA, um den Versand vorzubereiten: '));
    need(/^ja$/i.test(ok),'FINAL_REVIEW','Pre-Send-Prüfung nicht bestätigt.');
  }
  diag.readyBeforeSend=true;

  log('Versandvorbereitung PASS → Nachricht wird im Vollautomatik-Lauf genau einmal gesendet.');
  await sendAndConfirm(page,rl,{preArmed:FULL_RUN||AUTO});
  log(`Versand bestätigt (${diag.send.ackMode}; Dialoge JS=${diag.send.jsDialogs}, HTML-OK=${diag.send.htmlDialogs}).`);

  await saveTicket(page);
  await verifySavedAndReturn(page,row.ticketId);
  log(`Ticket speichern PASS (${diag.save.verification}).`);

  diag.loop.processed++;
  if(sourceScope==='IN_BEARBEITUNG')diag.loop.myTasksProcessed++;
  if(sourceScope==='WARTESCHLANGE_INTL01')diag.loop.queueProcessed++;
  diag.loop.processedTickets.push({source:sourceScope,sendAck:diag.send.ackMode,save:diag.save.verification});
  return row.ticketId;
}

async function main(){
  heading('MCR Local Runner 0.7.2 - robuste Personenerkennung');
  log('Lokales Node.js + Edge/Chromium. Kein DevTools-Copy/Paste.');
  log('Reihenfolge pro Schleife: Meine Vorgänge > In_Bearbeitung → danach Warteschlange > INTL01.');
  log('Bearbeitet werden nur echte E-MAIL-Tickets mit vollständig leerer „Zusätzlicher Beschreibung“.');
  log('Nach erfolgreichem Versand: Ticket speichern → wieder Meine Vorgänge prüfen → erst wenn dort nichts mehr offen ist, INTL01 prüfen.');
  log('Bei unbekanntem Zustand wird fail-closed gestoppt; eine bereits gesendete Nachricht wird niemals erneut gesendet.\n');

  const cfg=resolveConfig();
  fs.mkdirSync(cfg.runtimeDirectory,{recursive:true});fs.mkdirSync(cfg.downloadDirectory,{recursive:true});
  const mapping=autoMapping(cfg);
  if(DEMO){for(const e of Object.values(mapping.map.payload.entries))e.gender='M';}
  diag.mapping.loaded=true;diag.mapping.sourceConfirmed=true;
  log('Mapping automatisch geladen: '+path.basename(mapping.path));

  const rl=readline.createInterface({input,output});
  let browser=null,cdp=null;
  const processedIds=new Set();

  try{
    let startUrl=cfg.comarchUrl,executable=findEdgeExecutable(cfg.edgePath);
    if(DEMO){startUrl='about:blank';executable=findEdgeExecutable(cfg.demoBrowserPath||cfg.edgePath);}
    need(executable,'BROWSER_NOT_FOUND','Microsoft Edge/Chromium wurde nicht gefunden. config prüfen.');

    browser=await launchBrowser({
      executable,
      userDataDir:cfg.profileDirectory,
      startUrl,
      headless:HEADLESS,
      extraArgs:DEMO?['--disable-popup-blocking',...(process.platform!=='win32'&&typeof process.getuid==='function'&&process.getuid()===0?['--no-sandbox']:[])]:[]
    });
    diag.browser.launched=true;

    const conn=await connectBrowser(browser.port);cdp=conn.cdp;diag.browser.connected=true;
    await cdp.send('Browser.setDownloadBehavior',{behavior:'allow',downloadPath:cfg.downloadDirectory,eventsEnabled:true}).catch(async()=>{});
    const page=await attachPage(cdp,t=>t.type==='page'&&(DEMO?t.url.startsWith(startUrl):(!/^(edge|chrome|devtools|about):/i.test(t.url))),30000);

    if(DEMO)await injectDemo(page);
    await waitComarch(page);

    if(!DEMO){
      log('\nVollautomatik-Hinweis: Der Lauf darf mehrere zulässige Tickets senden und speichern.');
      const arm=clean(await rl.question('Tippe START, um den Lauf für alle aktuell zulässigen Tickets freizugeben: '));
      need(/^start$/i.test(arm),'RUN_NOT_ARMED','Vollautomatik-Lauf nicht freigegeben.');
    }
    diag.loop.armed=true;

    // Always begin with My Tasks, regardless of where the browser currently is.
    await navigateToScope(page,'IN_BEARBEITUNG');

    while(diag.loop.processed<MAX_TICKETS){
      let row=null,sourceScope='IN_BEARBEITUNG';

      await navigateToScope(page,'IN_BEARBEITUNG');
      row=await openNextEligibleTicket(page,processedIds);

      if(!row){
        await navigateToScope(page,'WARTESCHLANGE_INTL01');
        sourceScope='WARTESCHLANGE_INTL01';
        row=await openNextEligibleTicket(page,processedIds);
      }

      if(!row){
        // Final re-check in My Tasks, then queue, to avoid ending on a stale transition.
        const my=await navigateToScope(page,'IN_BEARBEITUNG');
        const myEligible=my.rows.filter(r=>r.descriptionBlank&&(!r.source||r.source.toUpperCase()==='E-MAIL')&&!processedIds.has(r.ticketId));
        if(myEligible.length)continue;

        const q=await navigateToScope(page,'WARTESCHLANGE_INTL01');
        const qEligible=q.rows.filter(r=>r.descriptionBlank&&(!r.source||r.source.toUpperCase()==='E-MAIL')&&!processedIds.has(r.ticketId));
        if(qEligible.length)continue;

        diag.loop.completed=true;diag.loop.finishReason='NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS';
        heading('RUN COMPLETE');
        log(`Bearbeitet: ${diag.loop.processed}`);
        log(`Davon Meine Vorgänge > In_Bearbeitung: ${diag.loop.myTasksProcessed}`);
        log(`Davon Warteschlange > INTL01: ${diag.loop.queueProcessed}`);
        log('Keine weiteren E-MAIL-Tickets mit leerer „Zusätzlicher Beschreibung“ gefunden.');
        return;
      }

      const ticketId=row.ticketId;
      need(!processedIds.has(ticketId),'DUPLICATE_GUARD','Dieses Ticket wurde im aktuellen Lauf bereits bearbeitet. Abbruch zum Schutz vor Doppelversand.');
      log(`\n--- Ticket ${diag.loop.processed+1}: ${sourceScope==='IN_BEARBEITUNG'?'Meine Vorgänge':'Warteschlange INTL01'} ---`);

      await processOpenedTicket(page,mapping,rl,row,sourceScope);
      processedIds.add(ticketId);

      // processOpenedTicket returns with My Tasks visible after save verification.
      await sleep(500);
    }

    fail('MAX_TICKETS_REACHED',`Sicherheitslimit von ${MAX_TICKETS} Tickets erreicht. Lauf beendet, bevor weitere Tickets verarbeitet werden.`);
  }catch(e){
    diag.lastError=e.code||'ERROR';
    console.error('\nSTOP:',diag.lastError,'-',e.message);
    process.exitCode=1;
  }finally{
    try{
      const d=await writeDiagnostic(cfg);
      log('\nDiagnose: '+d.path);
      log('Diagnose-ZIP-SHA256: '+d.sha256);
    }catch(e){console.error('Diagnose konnte nicht geschrieben werden:',e.message);}
    try{rl.close();}catch{}
    try{cdp?.close();}catch{}
    if(DEMO||!KEEP_BROWSER)try{browser?.child?.kill();}catch{}
  }
}

await main();
