# MCR Datenbrücke – aktueller Stand 0.7.2

0.7.2 ist der Vollrunner MyTasks → INTL01 → Ende mit dem bestätigten Member-Profil-Fix aus 0.7.1 und einer gehärteten Personenerkennung. Technische Secure-Mail-/Outlook-Bezeichnungen werden nicht mehr als Kundennamen verwendet; englische Signaturformeln wie `Yours sincerely` werden ausgewertet. Details: `README_0_7_2.md`.
