import {completePendingSentTicket} from './phase1-completion-only.mjs';
import {commitDescription} from '../lib/trusted-description.mjs';
import {ensurePreSendDescription} from '../lib/pre-send-description.mjs';
import {watchPhase2Save} from '../lib/phase2-save-settle.mjs';
import {reviewUnverifiedSend} from '../lib/operator-send-review.mjs';
/** Consolidated runner: supplied COMARCH workflow + Identity Guard + guarded
 * trusted send/save, durable no-retry ledger and explicit bounded completion.
 * No old downloads or source patches are required at runtime. */
import os from 'node:os';import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import readline from 'node:readline/promises';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage,attachFreshPage,sleep} from '../lib/cdp.mjs';
import {sha256,requireThat as need} from '../lib/core.mjs';import {loadActiveMapping} from '../lib/active-mapping.mjs';import {makeMultirowMapping,lookupMultirow} from '../lib/multirow-tpp-mapping.mjs';
import {resolveConfig} from '../lib/config.mjs';import {VERSION,readJSON,writeJSON,stamp,verifySession,ledger,assertNoReview,plainPath} from '../lib/control.mjs';
import {blockedTicketIds} from '../lib/run-reset.mjs';
import {writeZip} from '../lib/zip.mjs';import {trustedAction} from '../lib/browser-actions.mjs';import * as UI from '../lib/browser-workflow.mjs';import {injectDemo} from '../lib/demo.mjs';
import {resolveMemberMapping,NOT_FOUND_DESCRIPTION} from '../lib/member-mapping.mjs';import {selectAssignee,forwardOnce,chooseForwardDestination} from '../lib/forwarding.mjs';
import {routeFixedAssessment} from '../lib/route-fixed-policy.mjs';
import {phase1SignatureState,mayChoosePhase1Signature,mayRetryPhase1Signature} from '../lib/phase1-signature-policy.mjs';
import {COMARCH_NOT_FOUND_DESCRIPTION,memberAbsenceGate,memberAbsenceObservation,chooseUnresolvedMemberAction} from '../lib/comarch-missing-member.mjs';
import {safePreactionSkip} from '../lib/preaction-skip.mjs';import {firstPassCandidate,nonEmailReplyProof} from '../lib/source-neutral-policy.mjs';
import Core from '../lib/data-core.cjs';import Person from '../lib/person-quoted.cjs';import Identity from '../lib/identity-evidence.cjs';import Prep from '../lib/ticket-prep.cjs';import Queue from '../lib/queue-send.cjs';import Msg from '../lib/msg.cjs';
import {discoverCurrentTicketNameLabels,NAME_LABEL_SOURCE} from '../lib/comarch-name-labels.mjs';
import {promptManualPerson} from '../lib/manual-person.mjs';import {confirmMemberCorrection,requireReviewedMember,reviewReceipt} from '../lib/member-review.mjs';import {createDeliveryConsole,completionDisplay} from '../lib/delivery-console.mjs';import {discoverNameHints,NAME_PROBE_BUDGET} from '../lib/name-probes.mjs';import {weakSenderOnly,preferVerifiedFullName} from '../lib/name-resolution.mjs';import {selectCurrentIncomingRow} from '../lib/history-binding.mjs';import {STANDARD_ANSWER_NOTE,verifiedNewOutgoingAcknowledgement} from '../lib/mail-history-audit.mjs';import {sentNotice,permitAcknowledgement,validSendAcknowledgements} from '../lib/send-dialog-policy.mjs';import {authorizeChainedContinuation,authorizeForwardPilotContinuation,authorizeMasterBatch} from '../lib/continuation-policy.mjs';import {descriptionWithStatus,statusColumns,statusCsv,sourceUSCLines} from '../lib/status-columns.mjs';
import {markAfterVerifiedSend} from '../lib/post-send-status-retry.mjs';
import {shutdownFictionalBrowser} from '../lib/demo-browser-shutdown.mjs';
import {preparePostSendDescription} from '../lib/post-send-editor-rebind.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),args=new Set(process.argv.slice(2)),DEMO=args.has('--demo'),PILOT=args.has('--pilot');
let overlay={enabled:false,update(){},close(){}};const show=(event)=>overlay.update(event);
const MAX=DEMO?(process.env.MCR_DEMO_TICKET_LIMIT==='1'?1:3):PILOT?1:Number(process.env.MCR_MAX_TICKETS||100),DEMO_SCENARIO=process.env.MCR_DEMO_SCENARIO||'normal',log=s=>console.log(s),clean=UI.clean;
const diag={schema:'MCR_LOCAL_RUNNER_DIAGNOSTIC_V2',version:VERSION,phase:'INITIAL',mode:DEMO?'DEMO':'REAL',createdAt:new Date().toISOString(),runId:process.env.MCR_RUN_ID||stamp(),lastError:null,personSource:null,manualNameConfirmations:0,mapping:{loaded:false},browser:{launched:false},send:{clicked:false,verified:false},save:{clicked:false,verified:false},loop:{processed:0,myTasksProcessed:0,queueProcessed:0,forwarded:0,skippedAlreadyAnswered:0,annotatedAlreadyAnswered:0,completed:false,finishReason:null,processedTickets:[]},privacy:'No names, IDs, email addresses, mail text, mapping values, paths, URLs or browser profile content.'};
const fail=(c,m)=>need(false,c,m);// Local two-column CSV, always AFTER independently verified COMARCH save.
// The original Intel workbook/mapping is never modified by this report.
const statusRows=[];
// Durable, local, per-ticket outcomes across pilot and continuation.
// No message text, names, or mapping values enter this report. A COMPLETED
// action is logged only after independently verified COMARCH save/forward.
function ticketAudit(cfg,ticketId,outcome,scope,proof=''){
 try{
  need(/^\d{6,12}$/.test(String(ticketId)),'AUDIT_TICKET_ID','Ungueltige Ticket-ID.');
  const folder=path.join(cfg.runtimeDirectory,'reports');fs.mkdirSync(folder,{recursive:true});plainPath(folder);
  const date=new Date().toLocaleDateString('sv-SE');
  const f=path.join(folder,'MCR_TICKETVERLAUF_'+date+'.csv');
  const cell=x=>'"'+String(x??'').replace(/[\r\n\t]/g,' ').replace(/"/g,'""')+'"';
  const first=!fs.existsSync(f);if(!first)plainPath(f);
  const line=[new Date().toISOString(),diag.runId,ticketId,outcome,scope,proof].map(cell).join(';')+'\r\n';
  fs.appendFileSync(f,(first?'\ufeffZeit;Run_ID;Ticket_ID;Ergebnis;Quelle;Nachweis\r\n':'')+line,{encoding:'utf8',mode:0o600});
  log('TICKET_RESULT: '+ticketId+' | '+outcome+' | '+proof+' | Tagesbericht: '+f);
 }catch(e){log('WARN TICKET_AUDIT: Lokaler Bericht fehlgeschlagen; keine Wiederholung externer Aktionen ('+(e.code||'IO_ERROR')+').');}
}
function recordStatusColumns(cfg,ticketId,description){
 const columns=statusColumns(description);const existing=statusRows.findIndex(x=>x.ticketId===ticketId);
 const next=[...statusRows];if(existing>=0)next[existing]={ticketId,description};else next.push({ticketId,description});
 const dir=path.join(cfg.runtimeDirectory,'reports');fs.mkdirSync(dir,{recursive:true});
 const name='MCR_Bearbeitungsstatus_'+diag.runId+'.csv',file=path.join(dir,name);
 const tmp=path.join(dir,name+'.tmp');
 try{fs.writeFileSync(tmp,statusCsv(next),{encoding:'utf8',mode:0o600});fs.renameSync(tmp,file);}
 finally{try{if(fs.existsSync(tmp))fs.unlinkSync(tmp);}catch{}}
 statusRows.splice(0,statusRows.length,...next);
 log('PASS STATUS_COLUMNS_SAVED: USC/Pläne und Standardantwort in zwei separaten CSV-Spalten; Bericht: '+file);
 return columns;
}

function reportColumnsAfterSave(cfg,id,description){
 try{return recordStatusColumns(cfg,id,description);}
 catch(e){diag.statusReportWarnings=(diag.statusReportWarnings||0)+1;log('WARN STATUS_REPORT_WRITE: COMARCH gespeichert, lokaler Zwei-Spalten-Bericht nicht geschrieben ('+(e.code||'IO_ERROR')+'). Kein erneuter Versand.');return null;}
}

async function ask(rl,text){return clean(await rl.question(text));}
async function choosePerson(mail,rl,{preCandidates=null,page=null,ticketId=null}={}){
 const current=Identity.currentBodyPart(mail.body),currentCandidates=preCandidates??discoverNameHints({...mail,body:current}).candidates;let cs=currentCandidates,quotedOnly=false;
 if(!cs.length){cs=Person.candidates(mail);quotedOnly=cs.length>0;}
 let person;
 if(!cs.length){
  // RC75: only when ALL existing probes and the original-MSG search failed.
  // The two operator-provided DOM labels are hints bound to this exact ticket,
  // never evidence of identity or authorization. Otherwise: original manual gate.
  if(page&&ticketId){
   const label=await discoverCurrentTicketNameLabels(page,ticketId,{log});
   if(label.status==='CANDIDATE'){
    person=label.person;
    diag.personSource=NAME_LABEL_SOURCE;
    if(diag.nameDiscovery)diag.nameDiscovery.successfulSource=NAME_LABEL_SOURCE;
   }
  }
  if(!person){
  // This is the final fallback AFTER bounded read-only discovery and MSG retries.
  // Only the fictional fixture may answer without operator input.
  let request=prompt=>ask(rl,prompt);
  if(DEMO){
   need(['manual-name','manual-name-denied'].includes(DEMO_SCENARIO),'DEMO_PERSON_MISSING','Unerwarteter leerer Demoname.');
   const scripted=DEMO_SCENARIO==='manual-name' ? ['Max','Mustermann','JA'] : Array.from({length:5},()=>['Max','Mustermann','NEIN']).flat();
   request=async()=>{need(scripted.length,'DEMO_MANUAL_PROMPTS','Zu viele fiktive Rueckfragen.');return scripted.shift();};
  }
  person=await promptManualPerson({ask:request,log});
  diag.personSource=DEMO?'MANUAL_OPERATOR_CONFIRMED_DEMO':'MANUAL_OPERATOR_CONFIRMED';
  diag.manualNameConfirmations++;
  log('PASS NAME_MANUAL_OPERATOR_CONFIRMED - Person muss weiterhin zum ausgewaehlten COMARCH-Member passen.');
  }
 }
 if(person){}else if(cs.length===1)person=cs[0];else if((person=preferVerifiedFullName(cs))){log('PASS NAME_FULLNAME_OVER_EMAIL_ALIAS: Signatur/beschrifteter Name eindeutig; COMARCH-Member-Pruefung folgt.');}else{
  const subject=Person.norm(mail.subject),scored=cs.map(c=>({c,score:(subject.includes(Person.norm(c.firstName+' '+c.lastName))||subject.includes(Person.norm(c.lastName+' '+c.firstName))?7:0)+(c.sources.includes('Adressblock')?5:0)+(c.sources.includes('Beschrifteter Name')?5:0)+(c.sources.includes('Signatur')?3:0)})).sort((a,b)=>b.score-a.score);
  if(!quotedOnly&&!scored[0].c.quotedOnly&&scored[0].score>=7&&scored[0].score-(scored[1]?.score||0)>=3)person=scored[0].c;
  else{need(!DEMO,'DEMO_PERSON_AMBIGUOUS','Fiktive Person nicht eindeutig.');log('Mehrere Namenshinweise:');cs.forEach((c,i)=>log(`${i+1}: ${c.name}`));const n=Number(await ask(rl,'Nummer der betroffenen Person: '));need(Number.isInteger(n)&&n>=1&&n<=cs.length,'NAME_CHOICE','Ungueltige Personenauswahl.');person=cs[n-1];}
 }
 if((quotedOnly||person.quotedOnly)&&!DEMO)need(/^ja$/i.test(await ask(rl,'Name nur in aelterer/zitierter Korrespondenz. Zugehoerigkeit geprueft? JA: ')),'QUOTED_NAME_REVIEW','Zitierte Person nicht bestaetigt.');
 const hints=Person.identifierHints(mail,Core.analyzeMail((mail.subject?'Betreff: '+mail.subject+'\n':'')+mail.body).idHints,[person,...cs].filter(Boolean)),evidence=Identity.buildEvidence(mail,hints);
 if(!diag.personSource){
  const sources=person.sources||[];
  diag.personSource=(quotedOnly||person.quotedOnly)?'QUOTED_OPERATOR_REVIEWED':
   sources.includes('Beschrifteter Name')?'CURRENT_EXPLICIT_NAME':
   sources.includes('Signatur')?'CURRENT_SIGNATURE':
   sources.includes('Absender-Anzeigename')?'SENDER_DISPLAY':
   sources.includes('Absender-E-Mail (Suchhinweis)')?'SENDER_EMAIL_LOCALPART':
   sources.includes('Adressblock')?'CURRENT_ADDRESS_BLOCK':'AUTO_CANDIDATE';
  log('NAME_CANDIDATE_DISCOVERY: '+diag.personSource+'; COMARCH-Member-Verifikation weiterhin erforderlich.');
 }
 Person.query(person.firstName,person.lastName);return {person,evidence};
}
async function downloadMail(page,cfg,rl,{automaticOnly=false,documentId=null}={}){
 const folder=path.join(cfg.downloadDirectory,stamp());fs.mkdirSync(folder,{recursive:true});await page.cdp.send('Browser.setDownloadBehavior',{behavior:'allow',downloadPath:folder},null);
 const links=await page.call(function(documentId){
  const list=[];
  // RC16: some COMARCH versions do not set iceDatTblRow on the email table.
  // Restrict this read-only lookup to a visible table row, an exact document ID
  // and a same-origin download endpoint. Never follow other ticket links.
  for(const row of document.querySelectorAll('table tr')){
   if(!row.getClientRects().length)continue;
   for(const n of row.querySelectorAll('a[href*="GetFile?docId="]')){
    try{const u=new URL(n.getAttribute('href'),document.baseURI),id=u.searchParams.get('docId');
     if(documentId&&id!==documentId)continue;
     if(u.origin===location.origin&&/\/DMSWWW\/GetFile$/i.test(u.pathname)&&/^\d{1,15}$/.test(id||'')&&!list.includes(u.href))list.push(u.href);
    }catch{}
   }
  }
  // Caller that lacks a document binding can only use a single unique URL.
  return documentId?list:list.length===1?list:[];
 },documentId);
 diag.msgReadMethods=diag.msgReadMethods||[];
 for(const url of links){
  for(const cache of ['no-store','reload']){
   const r=await page.call(async function(url,cache){try{
    const x=await fetch(url,{credentials:'include',cache,redirect:'error',signal:AbortSignal.timeout(12000)});
    if(!x.ok)return null;const bytes=new Uint8Array(await x.arrayBuffer());
    if(bytes.length<512||bytes.length>33554432)return null;
    let s='';for(let i=0;i<bytes.length;i+=32768)s+=String.fromCharCode(...bytes.subarray(i,i+32768));return btoa(s);
   }catch{return null;}},url,cache);
   if(r){try{const bytes=Buffer.from(r,'base64'),mail=Msg.parseMsg(bytes);
    fs.writeFileSync(path.join(folder,'ticket.msg'),bytes,{flag:'wx',mode:0o600});
    diag.msgReadMethods.push({method:'AUTHENTICATED_FETCH_'+cache,result:'PASS'});return mail;
   }catch{}}
   diag.msgReadMethods.push({method:'AUTHENTICATED_FETCH_'+cache,result:'UNAVAILABLE'});
  }
 }
 if(automaticOnly)return null;
 need(!DEMO,'DEMO_MAIL_MISSING','Fiktive Mail fehlt.');log('MSG-Download automatisch nicht bestaetigt. Im Bot-Browser die aktuelle Original-Mail herunterladen.');await ask(rl,'Nach dem Download ENTER: ');
 const files=fs.readdirSync(folder).filter(n=>/\.msg$/i.test(n));need(files.length===1,'MAIL_DOWNLOAD','Genau eine neue MSG im separaten Downloadordner erforderlich.');return Msg.parseMsg(fs.readFileSync(path.join(folder,files[0])));
}
async function mailAndPerson(page,cfg,rl,ticketId){
 let checked=0,rounds=0;const trail=[];let latest=null,latestSenderMeta=null;
 const inspect=(mail,method)=>{
  const budget=Math.max(1,NAME_PROBE_BUDGET-checked);
  const scan=discoverNameHints(mail,{maxProbes:budget});
  checked+=scan.checks;
  for(const h of scan.history)if(trail.length<NAME_PROBE_BUDGET)trail.push({phase:method,...h});
  if(scan.candidates.length)log('NAME_DISCOVERY: '+method+' | '+scan.candidates.length+' Suchkandidat(en), '+checked+' Lesepruefungen. COMARCH-Verifikation folgt.');
  return scan.candidates;
 };
 // Three bounded snapshots cover delayed ICEfaces rendering. Never guess from
 // outgoing acknowledgement, unrelated ticket, or a quoted prior e-mail.
 for(let attempt=0;attempt<3&&checked<NAME_PROBE_BUDGET;attempt++){
  rounds++;
  const s=await UI.historyMailSnapshots(page);latest=s;
  const meta=await UI.ticketSenderMetadata(page);
  if(meta.ok)latestSenderMeta=meta;
  trail.push({phase:'SYSTEMDATEN',method:'TICKET_EMAIL_VON',result:meta.ok?'READABLE':'UNAVAILABLE',count:meta.addressCount});
  trail.push({phase:'HISTORY',method:'VISIBLE_HISTORY_SNAPSHOT',result:s.ok?'READABLE':'UNAVAILABLE',count:s.rows?.length||0});
  if(s.ok){
   const snapshot=s.rows.map(row=>({subject:row.subject,senderName:row.sender,senderEmail:row.sender,sender:row.sender,body:row.content,documentId:row.documentId,direction:row.direction||'UNKNOWN'}));
   // The newest visible history row can be OUR PREVIOUS OUTGOING REPLY.
   // Anchor name discovery to the original incoming message instead.
   const original=selectCurrentIncomingRow(snapshot,meta.ok?meta.senderEmail:null);
   trail.push({phase:'HISTORY',method:'CURRENT_INCOMING_BINDING',result:original?'MATCH':'UNAVAILABLE',count:original?1:0});
   if(!original){await sleep(200);continue;}
   // Systemdaten / E-Mail von is the currently bound sender on the ticket.
   // Some COMARCH history tables omit sender names or display the service
   // mailbox, so enrich the current ORIGINAL row before giving up.
   const bound={...original,senderEmail:meta.ok?meta.senderEmail:original.senderEmail,senderName:meta.ok?meta.senderEmail:original.senderName};
   const found=inspect(bound,meta.ok?'SYSTEMDATEN_EMAIL_VON_PLUS_HISTORY':'HISTORY_DOM_CURRENT');
   if(found.length){
    let nameMail=bound,nameCandidates=found,nameSource=meta.ok?'SYSTEMDATEN_EMAIL_VON':'HISTORY_DOM_CURRENT';
    // Previously a single weak first.last sender candidate ended discovery.
    // The actual original .MSG may contain a signed FULL first name, e.g.
    // "Timm-Peter" whereas the alias uses only "timm". Read-only fetch;
    // accept a full name ONLY with independent signature/label evidence.
    if(!DEMO&&original.documentId&&weakSenderOnly(found)){
     let msg=null;
     try{msg=await downloadMail(page,cfg,rl,{automaticOnly:true,documentId:original.documentId});}
     catch{trail.push({phase:'ORIGINAL_MSG',method:'ALIAS_EXPANSION_READ',result:'UNAVAILABLE',count:0});}
     const sameSubject=!!msg&&(!original.subject||!msg.subject||Person.norm(original.subject)===Person.norm(msg.subject));
     const sameFrom=!!msg&&(!msg.senderEmail||!bound.senderEmail||clean(msg.senderEmail).toLowerCase()===clean(bound.senderEmail).toLowerCase());
     if(msg&&sameSubject&&sameFrom){
      const enriched={...msg,senderEmail:bound.senderEmail,senderName:msg.senderName||bound.senderEmail};
      const msgFound=inspect(enriched,'BOUND_ORIGINAL_MSG_ALIAS_EXPANSION');
      if(preferVerifiedFullName([...found,...msgFound])){
       nameMail=enriched;nameCandidates=[...found,...msgFound];nameSource='BOUND_ORIGINAL_MSG_SIGNED_NAME';
       log('NAME_ALIAS_RECOVERY: Signatur/beschrifteten Namen aus Original-MSG geladen; COMARCH-Verifikation folgt.');
      }else trail.push({phase:'ORIGINAL_MSG',method:'ALIAS_EXPANSION',result:'NO_CORROBORATED_FULL_NAME',count:msgFound.length});
     }else trail.push({phase:'ORIGINAL_MSG',method:'ALIAS_EXPANSION_BINDING',result:msg?'BOUND_HEADER_CONFLICT':'UNAVAILABLE',count:0});
    }
    diag.nameDiscovery={checked,rounds,successfulSource:nameSource,trail};diag.mailSource=nameSource;
    return {mail:nameMail,...await choosePerson(nameMail,rl,{preCandidates:nameCandidates,page,ticketId})};
   }
   // Read the original mail tied to THIS document ID, first via authenticated
   // GET and then a guarded browser download if needed. No sending is involved.
   if(original.documentId&&!DEMO){
    let msg=null;
    try{msg=await downloadMail(page,cfg,rl,{automaticOnly:true,documentId:original.documentId});}
    catch(e){trail.push({phase:'ORIGINAL_MSG',method:'READ_ORIGINAL',result:'UNAVAILABLE',count:0});}
    const sameSubject=!original.subject||!msg?.subject||Person.norm(original.subject)===Person.norm(msg.subject);
    if(msg&&sameSubject){const foundMsg=inspect(msg,'BOUND_ORIGINAL_MSG');
     if(foundMsg.length){diag.nameDiscovery={checked,rounds,successfulSource:'BOUND_ORIGINAL_MSG',trail};diag.mailSource='ORIGINAL_MSG_NAME_FALLBACK';log('NAME_CANDIDATE_FALLBACK: Original-MSG hat Namenshinweis geliefert.');return {mail:msg,...await choosePerson(msg,rl,{preCandidates:foundMsg,page,ticketId})};}
    }else trail.push({phase:'ORIGINAL_MSG',method:'SUBJECT_OR_DOWNLOAD',result:msg?'SUBJECT_MISMATCH':'UNAVAILABLE',count:0});
   }
   if(attempt===2){diag.nameDiscovery={checked,rounds,successfulSource:null,trail};diag.mailSource='HISTORY_DOM';return {mail:bound,...await choosePerson(bound,rl,{preCandidates:[],page,ticketId})};}
  }
  await sleep(350+(attempt*250));
 }
 diag.nameDiscovery={checked,rounds,successfulSource:null,trail};
 const mail=await downloadMail(page,cfg,rl);diag.mailSource='MSG_DOWNLOAD';
 const bound=latestSenderMeta?.ok?{...mail,senderEmail:latestSenderMeta.senderEmail,
  senderName:mail.senderName||latestSenderMeta.senderEmail}:mail;
 const found=inspect(bound,latestSenderMeta?.ok?'MSG_AND_SYSTEMDATEN_SENDER':'MSG_DOWNLOAD');
 diag.nameDiscovery={checked,rounds,successfulSource:found.length?(latestSenderMeta?.ok?'MSG_AND_SYSTEMDATEN_SENDER':'MSG_DOWNLOAD'):null,trail};
 return {mail:bound,...await choosePerson(bound,rl,{preCandidates:found,page,ticketId})};
}
async function completeMemberSelection(s,person,evidence,rl){
 const asker=DEMO&&['rc29-incorrect-sender','rc30-swapped-member'].includes(DEMO_SCENARIO)
  ?(()=>{const values=DEMO_SCENARIO==='rc30-swapped-member'?['99900001','Max','Mustermann','ZUORDNUNG GEPRUEFT']:['99900001','Daniel','Beispiel','ZUORDNUNG GEPRUEFT'];return async()=>values.shift()??'';})()
  :DEMO?async()=>fail('DEMO_UNEXPECTED_NAME_REVIEW','Unerwarteter Namenskonflikt in anderer fiktiver Probe.'):prompt=>ask(rl,prompt);
 if(!DEMO||['rc29-incorrect-sender','rc30-swapped-member'].includes(DEMO_SCENARIO)){
  if(!Identity.memberNameMatches(s,person)){diag.phase='MEMBER_CORRECTION_REVIEW';show({event:'update',name:'Namenskonflikt',id:s.id,phase:'Manuell zuordnen'});}
 }
 const match=await confirmMemberCorrection({member:s,mailPerson:person,evidence,ask:asker,log});
 if(match.reviewed){
  diag.memberReview={correction:'COMARCH_PROFILE_OPERATOR_REVIEWED',explicitIdAgreement:!evidence.expectedId||evidence.expectedId===s.id,correctedBeforeAnySend:true};
  diag.personSource='COMARCH_PROFILE_OPERATOR_REVIEWED';
  diag.memberVerification={...diag.memberVerification,originalSenderNameMatches:false,nameMatches:Identity.memberNameMatches(s,match.person),operatorReviewed:true};
  log('PASS MEMBER_REVIEW_NO_AUTOMATIC_OVERRIDE: Profil und MercerID bestaetigt; spaetere COMARCH-Pruefung bleibt aktiv.');
 }else diag.memberReview={correction:'NOT_REQUIRED'};
 show({event:'update',name:match.person.firstName+' '+match.person.lastName,id:s.id,phase:match.reviewed?'Profil manuell verifiziert':'Identitaet bestaetigt'});
 return {member:s,person:match.person,review:reviewReceipt(s,match.person,match.reviewed,{swappedProfile:match.swappedProfile})};
}
// A failed operator recheck cannot kill other untouched tickets. The operator
// may select another COMARCH record by surname or ID, but ONLY that record's
// committed profile can be used. No automatic selection based on mere aliases.
async function memberReviewWithReselect(page,s,person,evidence,rl,audit){
 for(let round=0;round<2;round++){
  try{return await completeMemberSelection(s,person,evidence,rl);}
  catch(e){
   if(e.code!=='MEMBER_REVIEW_RESELECT'||DEMO||round!==0)throw e;
   log('MANUAL_MEMBER_RESELECT: Bisher kein Versand. Im Bot-Edge mit NACHNAME oder MercerID neu suchen und den passenden Vorschlag auswaehlen.');
   log('Nicht einfach den Suchtext eintippen – die COMARCH-Auswahl muss tatsaechlich bestaetigt sein.');
   const mode=(await ask(rl,'Alternative Suche: NACHNAME / ID / ABBRUCH: ')).toUpperCase();
   need(['NACHNAME','ID'].includes(mode),'MEMBER_REVIEW_CANCELLED','Member-Wechsel nicht freigegeben. Kein Versand.');
   const query=await ask(rl,mode==='ID'?'MercerID zur Suche (nur Ziffern): ':'Nachname zur Suche: ');
   need(mode==='ID'?/^\d{1,15}$/.test(query):/^[\p{L}\p{M} .'-]{2,100}$/u.test(query),
    'MEMBER_REVIEW_SEARCH_QUERY','Alternative Suchanfrage ungueltig. Kein Versand.');
   // User-visible suggestion, not an authorization or a trust anchor.
   log('Bitte jetzt im Bot-Edge im Member-Feld nach '+(mode==='ID'?'der ID':'dem Nachnamen')+' suchen: '+query);
   await ask(rl,'Passenden COMARCH-Member ausgewaehlt? Dann ENTER: ');
   const next=await UI.selectedMember(page,person);
   need(next?.source==='MEMBER_PROFILE_VERIFIED'&&next.profileIdMatches===true,
    'MEMBER_REVIEW_RESELECT_FAILED','Neue Auswahl nicht eindeutig durch COMARCH-Profil verifiziert. Kein Versand.');
   need(next.id!==s.id||!Identity.memberNameMatches(next,{firstName:s.firstName,lastName:s.lastName}),
    'MEMBER_REVIEW_RESELECT_UNCHANGED','Kein anderer Member bestaetigt. Kein Versand.');
   s=next;audit(s);
   log('PASS MEMBER_RESELECT_COMARCH_PROFILE_BOUND: Neue Auswahl eigenstaendig verifiziert. Vollstaendige Kontrolle wird wiederholt.');
  }
 }
 fail('MEMBER_REVIEW_RESELECT_FAILED','Kein eindeutig bestaetigter Member. Kein Versand.');
}
async function selectMember(page,person,evidence,rl){
 const audit=s=>{diag.memberVerification={source:s?.source||'NO_COMMITTED_MEMBER',structuredProfile:s?.source==='MEMBER_PROFILE_VERIFIED'||s?.source==='PROFILE_ROWS',fieldProfileIdAgreement:s?.profileIdMatches??null,nameMatches:s?Identity.memberNameMatches(s,person):false,explicitIdMatches:evidence?.expectedId&&s?String(s.id)===evidence.expectedId:null};};
 let s=await UI.selectedMember(page,person);
 if(s){audit(s);const result=await memberReviewWithReselect(page,s,person,evidence,rl,audit);if(result.member.source==='MEMBER_PROFILE_VERIFIED')log('PASS MEMBER_STRUCTURED_PROFILE_VERIFIED: Member-ID und COMARCH-Vor-/Nachname stimmen ueberein.');return result;}
 const id='mainForm:member-value-id';
 const manualGate=DEMO?null:async(state)=>{
  log('MEMBER_INPUT_MANUAL_GATE ('+state+'): Feld trotz kontrolliertem Scrollen nicht anklickbar. Kein unsicherer Klick.');
  log('Im EIGENEN Bot-Edge nur das Member-Eingabefeld anklicken (nicht den Vorschlag oder Senden).');
  await ask(rl,'Member-Eingabefeld angeklickt? Dann ENTER: ');
 };
 need(await UI.setInputQuery(page,id,Queue.memberSearchQuery(person.firstName,person.lastName),{manualGate}),'MEMBER_FIELD','Member-Feld nicht bearbeitbar.');let suggestions=[];
 for(let i=0;i<45;i++){await sleep(180);suggestions=await UI.suggestionPoints(page,id,[person.lastName+' '+person.firstName,person.firstName+' '+person.lastName],{member:true});if(suggestions.length)break;}
 let pick=null;if(evidence.expectedId){const xs=suggestions.filter(s=>s.id===evidence.expectedId);if(xs.length===1)pick=xs[0];}if(!pick&&suggestions.length===1)pick=suggestions[0];
 diag.phase='MEMBER_SUGGESTION_SELECTION';
 if(pick){
  // The browser may rerender the autocomplete while we examine it. Rebind the
  // candidate to the currently displayed suggestion before one trusted click.
  const current=await UI.suggestionPoints(page,id,[person.lastName+' '+person.firstName,person.firstName+' '+person.lastName],{member:true});
  const same=current.filter(x=>x.x===pick.x&&x.y===pick.y&&x.id===pick.id);
  if(same.length===1){await page.mouseClick(same[0].x,same[0].y);log('PASS MEMBER_SUGGESTION_TRUSTED_CLICK');}
  else pick=null;
 }
 if(!pick){
  const fictionalMissing=DEMO&&['missing-comarch-member','missing-comarch-member-mark','missing-comarch-profile-hint'].includes(DEMO_SCENARIO);
  need(!DEMO||fictionalMissing,'DEMO_MEMBER_AMBIGUOUS','Demo-Member nicht eindeutig.');
  if(!fictionalMissing){
   log('MEMBER_SUGGESTION_MANUAL_GATE: COMARCH-Vorschlag im eigenen Bot-Edge manuell auswaehlen; kein automatischer unsicherer Klick.');
   await ask(rl,'Richtigen Member im Bot-Browser auswaehlen; dann ENTER: ');
  }
 }
 diag.phase='MEMBER_COMMIT_VERIFY';
 // An absent COMARCH record is a separate NO-EMAIL route, not a fatal
 // MEMBER_COMMIT exception. An ambiguous/contradictory profile is NOT absence.
 for(let i=0;i<(DEMO?12:35);i++){s=await UI.selectedMember(page,person);if(s)break;await sleep(200);}
 if(!s){
  for(let rechecks=0;rechecks<3&&!s;rechecks++){
   const action=await chooseUnresolvedMemberAction({ask:text=>ask(rl,text),log,
    observe:()=>memberAbsenceObservation(page),demo:DEMO&&['missing-comarch-member','missing-comarch-member-mark','missing-comarch-profile-hint'].includes(DEMO_SCENARIO)});
   if(action==='NOT_FOUND'){
    diag.memberVerification={source:'OPERATOR_CONFIRMED_NOT_IN_COMARCH',structuredProfile:false,fieldProfileIdAgreement:null,nameMatches:false,explicitIdMatches:null};
    return {member:null,person,review:null,comarchNotFound:true};
   }
   log('MEMBER_RECHECK: COMARCH-Member im Bot-Edge auswaehlen, nicht nur Namen eintippen.');
   await ask(rl,'Nach Auswahl und sichtbarem COMARCH-Profil ENTER: ');
   for(let i=0;i<20;i++){s=await UI.selectedMember(page,person);if(s)break;await sleep(180);}
  }
 }
 need(s,'COMARCH_MEMBER_REVIEW_CANCELLED','Keine verifizierte Person ausgewaehlt. Ticket bleibt ohne E-Mail/Weiterleitung zur manuellen Pruefung.');
 audit(s);const result=await memberReviewWithReselect(page,s,person,evidence,rl,audit);if(result.member.source==='MEMBER_PROFILE_VERIFIED')log('PASS MEMBER_STRUCTURED_PROFILE_VERIFIED: Member-ID und COMARCH-Vor-/Nachname stimmen ueberein.');return result;
}
/** IceFaces dropdowns commit their chosen value only after a genuine focus
 * change. In COMARCH the category must lose focus to the already selected
 * MEMBER field before its dependent subcategory is selected. NEVER type into
 * the MEMBER field here: it carries the verified identity. */
async function fixedFields(page,rl){
 // COMARCH can retain a correctly selected field across attempts. In that
 // situation do NOT retype, reselect or ask the operator to confirm it.
 const audit=(field,action,result)=>{
  const a=diag.fixedFieldResolution||(diag.fixedFieldResolution=[]);
  if(a.length<40)a.push({field,action,result});
 };
 const responsibilityReady=await page.call(function(text){
  const s=document.getElementById('mainForm:responsibility-value-id');
  return !!(s?.tagName==='SELECT'&&!s.disabled&&String(s.selectedOptions?.[0]?.textContent||'').trim()===text);
 },Prep.FIXED.responsibility);
 if(!responsibilityReady){
  const r=await page.call(function(text){
   const s=document.getElementById('mainForm:responsibility-value-id');
   if(!s||s.tagName!=='SELECT'||s.disabled)return false;
   const o=Array.from(s.options).filter(x=>String(x.textContent).trim()===text);
   if(o.length!==1)return false;
   Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype,'value').set.call(s,o[0].value);
   s.dispatchEvent(new Event('input',{bubbles:true}));s.dispatchEvent(new Event('change',{bubbles:true}));
   return s.selectedOptions[0]?.textContent.trim()===text;
  },Prep.FIXED.responsibility);
  need(r,'RESPONSIBILITY','Second Level konnte nicht gesetzt werden.');audit('responsibility','SET','PASS');
 }else audit('responsibility','ALREADY_EXACT','PASS');
 const manualGate=DEMO?null:async(state,field)=>{
  log('FIXED_INPUT_FOCUS_ASSIST ('+state+'): '+field+' ist nicht sicher anklickbar.');
  // Focusing is not authorization to change a value or to send.
  await ask(rl,'Im Bot-Edge NUR das richtige Textfeld anklicken, dann ENTER: ');
 };
 const valueOf=async id=>page.call(function(id){
  const hits=Array.from(document.querySelectorAll('input')).filter(x=>x.id===id&&x.isConnected);
  return hits.length===1?String(hits[0].value??'').replace(/\s+/g,' ').trim():null;
 },id);
 const waitExact=async(id,value,ms=5000)=>{
  let stable=0,end=Date.now()+(DEMO?Math.min(ms,1600):ms);
  while(Date.now()<end){const got=await valueOf(id);
   if(got===value){if(++stable>=3)return true;}else stable=0;
   await sleep(180);
  }return false;
 };
 const focus=async(id,reason,{optional=false}={})=>{
  const x=await UI.focusInput(page,id,{manualGate:optional?null:manualGate?state=>manualGate(state,reason):null});
  audit(reason,'FOCUS',x.ok?'PASS':x.state||'FAILED');
  if(!optional)need(x.ok,x.state||'FIXED_FOCUS','Fokuswechsel fuer '+reason+' nicht bestaetigt.');
  await sleep(350);return x.ok;
 };
 const categoryId='mainForm:category-value-id',subcategoryId='mainForm:category-sub-value-id',signatureId='mainForm:signature-value-id';
 const select=async(id,value,field)=>{
  // Already selected? Do NOT enter the dropdown a second time. The following
  // blur/stable checks will independently verify the field before send.
  if(await valueOf(id)===value){audit(field,'ALREADY_EXACT','PASS');log('PASS '+field.toUpperCase()+'_ALREADY_EXACT_NO_RESELECTION');return;}
  let ready=false;const end=Date.now()+10000;
  while(Date.now()<end){ready=await page.call(function(id){const f=document.getElementById(id);
   return !!(f&&f.tagName==='INPUT'&&!f.disabled&&!f.readOnly&&f.getClientRects().length>0);
  },id);if(ready)break;await sleep(200);}
  need(ready,'FIXED_FIELD','Abhaengiges Feld '+id+' nicht bearbeitbar.');
  // Do not repeatedly hammer the same autocomplete. These methods differ:
  // existing suggestion, trusted keyboard, renewed focus, legacy input event,
  // and shorter trusted search. No action ever changes a Member or sends mail.
  const strategies=[
   {name:'VISIBLE_EXACT_OPTION',run:async()=>{}},
   {name:'TRUSTED_KEYBOARD',run:async()=>{
     try{return await UI.typeTrustedFixedQuery(page,id,value,{manualGate:manualGate?x=>manualGate(x,id):null});}
     catch(e){if(['FIXED_QUERY_MISMATCH','FIXED_INPUT_FOCUS_LOST','INPUT_CHANGED'].includes(e.code))return e.code;throw e;}
   }},
   {name:'FOCUS_REOPEN',run:async()=>UI.focusInput(page,id,{manualGate:null})},
   {name:'LEGACY_INPUT_KEYUP',run:async()=>UI.setInputQuery(page,id,value,{manualGate:null})},
   {name:'TRUSTED_SHORT_QUERY',run:async()=>{
     const shorter=value.slice(0,Math.max(4,Math.ceil(value.length/2)));
     try{return await UI.typeTrustedFixedQuery(page,id,shorter,{manualGate:null});}
     catch(e){if(['FIXED_QUERY_MISMATCH','FIXED_INPUT_FOCUS_LOST','INPUT_CHANGED'].includes(e.code))return e.code;throw e;}
   }},
  ];
  let found=[],method=null;
  for(const strategy of strategies){
   try{const obs=await strategy.run();audit(field,strategy.name,'EXECUTED'+(typeof obs==='string'?':'+obs:''));}
   catch(e){audit(field,strategy.name,e.code||'FAILED');if(DEMO&&e.code==='DEMO_PERSON_MISSING')throw e;continue;}
   for(let k=0;k<12;k++){
    found=await UI.suggestionPoints(page,id,[value]);
    if(found.length)break;
    await sleep(180);
   }
   if(found.length){method=strategy.name;break;}
   audit(field,strategy.name,'NO_EXACT_CLICK_TARGET');
  }
  if(found.length===1){
   const now=await UI.suggestionPoints(page,id,[value]);
   if(now.length===1&&now[0].x===found[0].x&&now[0].y===found[0].y){
    await page.mouseClick(now[0].x,now[0].y);
    audit(field,'EXACT_OPTION_TRUSTED_CLICK_'+method+(now[0].method?'_'+now[0].method:''),'PASS');await sleep(420);return;
   }
   audit(field,'EXACT_OPTION_MOVED','NOT_CLICKED');
  }else if(found.length>1){audit(field,'SUGGESTION_AMBIGUOUS','NOT_CLICKED');}
  // Never equate a typed string with an option selection. A human fallback is
  // allowed ONLY in the supervised real run, followed by exact field checks.
  // This keeps the ticket moving when the ICEfaces suggestions are invisible
  // to Chromium but visible to the local operator.
  need(!DEMO,found.length>1?'FIXED_OPTION_AMBIGUOUS':'FIXED_OPTION_NOT_FOUND',
    'COMARCH-Auswahlliste nicht sicher bedienbar: '+field+'. Kein Versand.');
  log('FIXED_OPTION_OPERATOR_GATE: Autoauswahl von '+field+' nicht eindeutig. Kein Versand bis zur Bestaetigung.');
  log('Im Bot-Edge exakt "'+value+'" einmal aus der Vorschlagsliste waehlen (keinen aehnlichen Eintrag).');
  await ask(rl,'Nach erfolgter Auswahl ENTER: ');
  audit(field,'OPERATOR_SELECTED_EXACT','AWAIT_COMMIT_VERIFY');
 };
 await select(categoryId,Prep.FIXED.category,'category');
 await focus('mainForm:member-value-id','Kategorie per Member-Fokus bestaetigen');
 need(await waitExact(categoryId,Prep.FIXED.category),'FIXED_VERIFY','Dokumentenkategorie nicht eindeutig bestaetigt.');
 log('PASS CATEGORY_COMMITTED_AFTER_MEMBER_FOCUS');
 await select(subcategoryId,Prep.FIXED.subcategory,'subcategory');
 // One physical focus transfer without touching the Member ID or input text.
 await focus('mainForm:member-value-id','Unterkategorie per Member-Fokus bestaetigen');
 let committed=await waitExact(subcategoryId,Prep.FIXED.subcategory);
 if(!committed){audit('subcategory','WAIT_FOR_ICEfaces','PENDING');committed=await waitExact(subcategoryId,Prep.FIXED.subcategory,7500);}
 if(!committed){
  // Pure, reversible focus probes; never select a different subcategory.
  if(await focus(categoryId,'Unterkategorie Alternativfokus Kategorie',{optional:true}))committed=await waitExact(subcategoryId,Prep.FIXED.subcategory,2600);
  if(!committed&&await focus('mainForm:member-value-id','Unterkategorie Alternativfokus Member',{optional:true}))committed=await waitExact(subcategoryId,Prep.FIXED.subcategory,2600);
 }
 need(committed,'FIXED_VERIFY','Unterkategorie Personenschriftwechsel nicht bestaetigt. Keine andere Unterkategorie waehlen.');
 log('PASS SUBCATEGORY_COMMITTED_EXACT_PERSONENSCHRIFTWECHSEL');
 const initialSignature=await valueOf(signatureId);
 need(mayChoosePhase1Signature(phase1SignatureState(initialSignature,Prep.FIXED.signature)),'FIXED_SIGNATURE_CONFLICT',
  'Fremder Signaturwert vorhanden; keine automatische Ueberschreibung und kein Versand.');
 await select(signatureId,Prep.FIXED.signature,'signature');
 // A COMARCH ICEfaces re-render may invalidate the EXACT signature that was
 // just selected while category/subcategory and Member stay committed. Unlike
 // irreversible send/save, the signature chooser can safely be reopened.
 // Never accept a typed search string, and never overwrite an unrelated value.
 const signatureState=async()=>phase1SignatureState(await valueOf(signatureId),Prep.FIXED.signature);
 const commitSignature=async(stage,modes)=>{
  for(const mode of modes){
   const focused=mode==='EDITOR'?await UI.focusEditor(page):
    await focus(mode==='MEMBER'?'mainForm:member-value-id':categoryId,
     'Signatur '+stage+' Alternativfokus '+mode,{optional:true});
   audit('signature',stage+'_COMMIT_FOCUS_'+mode,focused?'PASS':'UNAVAILABLE');
   if(!focused)continue;
   await sleep(350);
   if(await waitExact(signatureId,Prep.FIXED.signature,mode==='EDITOR'?2400:2200))return true;
   const observation=await signatureState();
   audit('signature',stage+'_READBACK',observation);
   // A nonempty, unexpected signature is a conflict, not a retry candidate.
   need(observation!=='CONFLICT','FIXED_SIGNATURE_CONFLICT',
    'Signaturfeld enthaelt anderen Wert; kein Ueberschreiben und kein Versand.');
  }
  return false;
 };
 let signed=await commitSignature('INITIAL',['EDITOR','MEMBER','EDITOR']);
 if(!signed){
  const before=await signatureState();
  audit('signature','RECOVERY_BEFORE',before);
  need(before!=='CONFLICT'&&before!=='UNBOUND','FIXED_SIGNATURE_CONFLICT',
   'Signatur vor erneuter Auswahl nicht eindeutig/abweichend; kein Versand.');
  if(mayRetryPhase1Signature(before)){
   // One bounded second trusted selection is allowed only for an EMPTY
   // field after the original chooser was used. This is not a Send retry.
   log('P1_SIGNATURE_ICE_RETRY: COMARCH hat die Signaturauswahl zurueckgesetzt; erneute INTL01-Auswahl ohne Versand.');
   await select(signatureId,Prep.FIXED.signature,'signature');
  }
  signed=await commitSignature('RECOVERY',['MEMBER','EDITOR','CATEGORY','MEMBER']);
 }
 if(!signed&&!DEMO){
  log('P1_SIGNATURE_OPERATOR_GATE: INTL01-Signatur nicht automatisch stabil uebernommen. Kein Versand.');
  log('Im Bot-Edge nur im Feld Signatur den exakten Vorschlag "'+Prep.FIXED.signature+'" anklicken.');
  await ask(rl,'Signatur aus der COMARCH-Vorschlagsliste ausgewaehlt? Danach ENTER / ABBRUCH: ');
  signed=await commitSignature('OPERATOR',['MEMBER','EDITOR']);
 }
 need(signed,'FIXED_VERIFY','Signatur nicht stabil als COMARCH-Auswahl bestaetigt; kein Versand.');
 log('PASS P1_INTL01_SIGNATURE_COMMITTED_EXACT');
 const fixed=await UI.fixedFieldValues(page);
 need(fixed.responsibility===Prep.FIXED.responsibility&&fixed.category===Prep.FIXED.category&&
  fixed.subcategory===Prep.FIXED.subcategory&&fixed.signature===Prep.FIXED.signature,
  'FIXED_VERIFY','Pflichtfelder nicht gleichzeitig exakt bestaetigt.');
 log('PASS FIXED_FIELDS_ALL_VERIFIED');
}
/** The send button gets exactly ONE trusted mouse click. Browser/HTML dialogs
 * are acknowledged individually. A still-visible HTML dialog cannot receive
 * a second OK click, even when COMARCH's AJAX response is delayed. The third
 * distinct dialog is permitted ONLY if it says “Nachricht gesendet”.
 * Never re-send to resolve any ambiguous outcome.
 */
async function sendOnce(page,rl,id,journal,expectedRecipient,{savedDescription,approval,preSendSource}={}){
 // Snapshot BEFORE the one irreversible Send click: a pre-existing reply
 // must never become a false success after an unrelated history refresh.
 const preMail=await UI.historyMailSnapshots(page);
 const before=await UI.historyCount(page),ed=await UI.editor(page);
 need(Number.isInteger(before)&&before>=1&&ed.ok&&!ed.empty,'SEND_PRECONDITION','Nachrichtenverlauf/Antworteditor nicht eindeutig.');
 diag.send={clicked:false,verified:false,historyBefore:before,historyAfter:null,htmlDialogs:0,jsDialogs:0,successNotices:0,htmlPendingWaits:0,boundHistoryVerified:false,historyRefreshAttempts:0,historyBindingOutcome:null};
 let active=true,error=null,nativeOpen=false;
 const total=()=>diag.send.htmlDialogs+diag.send.jsDialogs;
 const offOpen=page.cdp.on('Page.javascriptDialogOpening',(p,s)=>{
  if(!active||s!==page.sessionId)return;
  if(!['alert','confirm'].includes(p.type)){error='UNEXPECTED_JS_DIALOG';return;}
  if(nativeOpen){error='SEND_DUPLICATE_JS_DIALOG_EVENT';return;}
  const success=sentNotice(p.message);
  if(!permitAcknowledgement({previous:total(),successNotices:diag.send.successNotices,success,type:p.type})){
   error='SEND_UNEXPECTED_EXTRA_DIALOG';return;
  }
  nativeOpen=true;diag.send.jsDialogs++;
  if(success)diag.send.successNotices++;
  page.cdp.send('Page.handleJavaScriptDialog',{accept:true},s).catch(()=>{error='DIALOG_FAILED';});
 });
 const offClosed=page.cdp.on('Page.javascriptDialogClosed',(_p,s)=>{if(active&&s===page.sessionId)nativeOpen=false;});
 try{
  await UI.assertTicket(page,id);
  await trustedAction(page,{id:'mainForm:send-new-message-button'},async()=>{
   // Re-read exact labelled field at the LAST reversible point, before the
   // irreversible send click or the SEND_INTENT journal. No auto repair here.
   const atClick=await UI.additionalDescriptionState(page);
   need(atClick.ok&&atClick.editable&&atClick.value===preSendSource,
    'PRESEND_DESCRIPTION_CHANGED_AT_CLICK','Beschreibung unmittelbar vor Versandklick abweichend. Kein Senden.');
   if(!DEMO){await overlay.commitAuthorization(approval);journal.begin(id,savedDescription);}
   diag.send.clicked=true;
  });
  if(!DEMO)log('SEND_PRUEFUNG_AKTIV: Versandklick erfolgt. Warte auf echte COMARCH-Bestaetigung; kein erneutes Senden. Automatische Pruefung bis 35 Sekunden, danach Sichtpruefung.');
  const end=Date.now()+(DEMO?15000:35000);let lastProgress=Date.now();let nextHistoryRefresh=Date.now()+(DEMO?2600:8000);
  let stable=0,reset=0,boundStable=0;
  while(Date.now()<end){
   need(!error,error||'DIALOG_FAILED','Unbekannte oder zusaetzliche Versandbestaetigung. Nicht erneut senden.');
   if(!DEMO&&Date.now()-lastProgress>=5000){lastProgress=Date.now();log('SEND_WARTET_AUF_NACHWEIS: '+Math.ceil((end-Date.now())/1000)+'s Rest | bestaetigte Dialoge='+total()+' | Verlauf-Aktualisierungen='+diag.send.historyRefreshAttempts+' | kein zweiter Sendeklick.');show({event:'update',phase:'Versandbeleg wird geprueft'});}
   const probe=await UI.htmlOkProbe(page);
   if(probe.state==='WAITING_CLOSED'){
    diag.send.htmlPendingWaits++;
    await sleep(160);continue;
   }
   if(probe.state==='READY'){
    need(permitAcknowledgement({previous:total(),successNotices:diag.send.successNotices,success:probe.success,type:'html'}),
     'SEND_UNEXPECTED_EXTRA_DIALOG','Zusatzdialog ist keine eindeutig bestaetigte Versand-Erfolgsmeldung. Kein erneutes Senden.');
    const claimed=await UI.htmlOkProbe(page,probe.signature);
    if(claimed.state==='CHANGED'||claimed.state==='NONE'||claimed.state==='WAITING_CLOSED')continue;
    need(claimed.state==='CLAIMED'&&claimed.success===probe.success,'SEND_DIALOG_CHANGED','OK-Dialog waehrend Auswahl veraendert. Kein unsicherer Klick.');
    await page.mouseClick(claimed.x,claimed.y); // one trusted click for exactly this dialog node
    diag.send.htmlDialogs++;
    if(claimed.success)diag.send.successNotices++;
    stable=0;reset=0;
    await sleep(220);
    continue;
   }
   need(probe.state==='NONE','UNEXPECTED_DIALOG','Unbekannter oder nicht anklickbarer COMARCH-Dialog. Kein erneutes Senden.');
   if(nativeOpen){await sleep(160);continue;}
   // ICEFaces often delays the history row until the history-panel refresh.
   // Refresh is a trusted click on the HISTORY REFRESH icon, NEVER on Senden.
   // Each attempt is bounded, ticket-bound, and read-only as to mail state.
   if((!DEMO||DEMO_SCENARIO==='rc26-refresh-history')&&Date.now()>=nextHistoryRefresh&&diag.send.historyRefreshAttempts<3){
    await UI.assertTicket(page,id);
    const refreshed=await UI.refreshCurrentTicketHistory(page,id);
    diag.send.historyRefreshAttempts++;
    nextHistoryRefresh=Date.now()+15000;
    if(refreshed.ok){await sleep(750);}else diag.send.historyRefreshState=refreshed.state;
   }
   const n=await UI.historyCount(page);
   need(n===null||n<=before+1,'SEND_MULTIPLE_HISTORY_ROWS','Mehr als ein neuer Verlaufseintrag. Manuell pruefen.');
   // RC25: A newly appended outgoing standard mail is stronger evidence
   // than a fixed number of confirmation dialogs. Require all of:
   // exact current ticket, original sender, exact recipient, standard text,
   // a single new outgoing row, and a stable, closed dialog state.
   if(n===before+1&&preMail.ok){
    const postMail=await UI.historyMailSnapshots(page);
    const proof=verifiedNewOutgoingAcknowledgement(preMail,postMail,id,expectedRecipient);
    if(proof.verified){
     diag.send.historyBindingOutcome=proof.subjectBinding||proof.reason;
     if(!boundStable)boundStable=Date.now();
     if(Date.now()-boundStable>=1500){
      diag.send.historyAfter=n;
      diag.send.boundHistoryVerified=true;
      diag.send.ackMode='BOUND_NEW_OUTGOING_HISTORY';
      need(validSendAcknowledgements(diag.send),'SEND_DIALOGS_NOT_VERIFIED','Dialogstatus unklar. Kein zweiter Versand.');
      diag.send.verified=true;
      journal?.set(id,'SENT_CONFIRMED');
      return;
     }
    }else {if(diag.send.historyBindingOutcome!==proof.reason&&!DEMO)log('SEND_NACHWEIS_NOCH_OFFEN: '+proof.reason+'; kein zweiter Versand.');diag.send.historyBindingOutcome=proof.reason;boundStable=0;}
   }else boundStable=0;
   const ack=validSendAcknowledgements(diag.send);
   if(DEMO&&n===before+1&&ack){
    if(!stable)stable=Date.now();
    if(Date.now()-stable>=1200){diag.send.historyAfter=n;diag.send.verified=true;diag.send.ackMode='HISTORY_INCREMENT';journal?.set(id,'SENT_CONFIRMED');return;}
   }else stable=0;
   const e=await UI.editor(page);
   if(DEMO&&e.ok&&e.empty&&ack){
    if(!reset)reset=Date.now();
    if(Date.now()-reset>=1800){diag.send.historyAfter=n;diag.send.verified=true;diag.send.ackMode='EDITOR_RESET_AFTER_CONFIRMED_DIALOGS';journal?.set(id,'SENT_CONFIRMED');return;}
   }else reset=0;
   await sleep(220);
  }
  if(!DEMO){
   log('SEND_AUTOMATISCHE_PRUEFUNG_OHNE_NACHWEIS: Bitte bestehenden Ausgang im COMARCH-Verlauf pruefen. Keine neue Nachricht senden; danach nur USC/Status und Ticket speichern.');
   const reviewed=await reviewUnverifiedSend({ticketId:id,recipient:expectedRecipient,
    assertTicket:x=>UI.assertTicket(page,x),hasPendingDialogs:async()=>nativeOpen||(await UI.htmlOkProbe(page)).state!=='NONE',
    ask:q=>ask(rl,q),log,record:(event,data)=>journal?.observe(id,event,data)});
   Object.assign(diag.send,reviewed,{verified:true});journal?.set(id,'SENT_CONFIRMED');return;
  }
  fail('SEND_UNVERIFIED','Versand nicht abschliessend bestaetigt. KEIN zweiter Sendeklick; Verlauf und Speicherung pruefen.');
 }finally{active=false;offOpen();offClosed();}
}
/** Ticket saving receives a single trusted click, and each HTML OK prompt
 * may be accepted only once; a slow/modal response cannot trigger duplicates.
 */
async function saveOnce(page,id,journal,{forwardOnly=false,forwardRepair=false}={}){
 diag.save={clicked:false,verified:false,dialogClicks:0};
 const saveWatch=await watchPhase2Save(page);
 let active=true,error=null;
 const off=page.cdp.on('Page.javascriptDialogOpening',(p,s)=>{
  if(!active||s!==page.sessionId)return;
  if(!['alert','confirm'].includes(p.type)){error='UNEXPECTED_SAVE_DIALOG';return;}
  page.cdp.send('Page.handleJavaScriptDialog',{accept:true},s).catch(()=>{error='SAVE_DIALOG_FAILED';});
 });
 try{
  await UI.assertTicket(page,id);
  await trustedAction(page,{text:'Ticket speichern',relocate:true},()=>{
   if(forwardRepair)journal?.forwardSet(id,'ROUTE_REPAIR_SAVE_INTENT');else if(forwardOnly)journal?.forwardSet(id,'ROUTE_SAVE_INTENT');else journal?.set(id,'SAVE_INTENT');
   diag.save.clicked=true;
  });
  log('Ticket speichern: ein gepruefter Browser-Mausklick ausgefuehrt.');
  const end=Date.now()+12000;let quiet=0;
  while(Date.now()<end){
   need(!error,error||'SAVE_DIALOG_FAILED','Speicherdialog unklar.');
   const probe=await UI.htmlOkProbe(page);
   if(probe.state==='WAITING_CLOSED'){quiet=0;await sleep(160);continue;}
   if(probe.state==='READY'){
    need(diag.save.dialogClicks<2,'UNEXPECTED_SAVE_DIALOG','Zu viele verschiedene Speicherdialoge.');
    const claim=await UI.htmlOkProbe(page,probe.signature);
    if(['CHANGED','NONE','WAITING_CLOSED'].includes(claim.state))continue;
    need(claim.state==='CLAIMED'&&claim.success===probe.success,'UNEXPECTED_SAVE_DIALOG','Speicherdialog veraendert.');
    await page.mouseClick(claim.x,claim.y);diag.save.dialogClicks++;quiet=0;await sleep(200);continue;
   }
   need(probe.state==='NONE','UNEXPECTED_SAVE_DIALOG','Speicherdialog nicht eindeutig.');
   if(!quiet)quiet=Date.now();
   if(Date.now()-quiet>1800){const observed=await saveWatch.settle();diag.save.network=observed;need(!['WRITE_REQUEST_ERROR','NETWORK_STILL_ACTIVE'].includes(observed.status),'SAVE_NETWORK_UNCLEAR','Speicheruebertragung unklar. Kein zweiter Klick.');return;}
   await sleep(200);
  }
  fail('SAVE_DIALOG_TIMEOUT','Speicherdialog nicht abgeschlossen; kein zweiter Speicherklick.');
 }finally{active=false;off();saveWatch.cancel();}
}
/** RC38: after a verified outbound email COMARCH may switch to a different
 * view. Rebind ONLY the same ticket and its edit form, never a new ticket.
 */
async function rebindSentTicket(page,ticketId){
 if(await UI.detailTicketId(page)!==ticketId){
  let selected=null;
  for(const scope of ['IN_BEARBEITUNG','WARTESCHLANGE_INTL01']){
   const snap=await UI.navigateToScope(page,scope);
   selected=snap.rows.find(r=>r.ticketId===ticketId);
   if(selected){await UI.openTicket(page,selected,{scope});break;}
  }
  need(selected,'POST_SEND_TICKET_NOT_FOUND','Versendetes Ticket nicht in einer bekannten Vorgangsansicht gefunden. Kein erneuter Versand.');
 }
 await UI.assertTicket(page,ticketId);
}
async function verifySaved(page,id,description){for(const scope of ['IN_BEARBEITUNG','WARTESCHLANGE_INTL01']){let snap=await UI.navigateToScope(page,scope),row=snap.rows.find(r=>r.ticketId===id);if(!row)continue;const end=Date.now()+(DEMO?1200:20000);while(Date.now()<end){if(!row.descriptionBlank&&typeof row.descriptionRaw==='string'&&row.descriptionRaw.replace(/\r\n?/g,'\n').trim()===description.replace(/\r\n?/g,'\n').trim()){diag.save.verified=true;diag.save.verification=scope==='IN_BEARBEITUNG'?'MY_TASKS_ALL_DESCRIPTION_CONTENT_MATCH':'QUEUE_ALL_DESCRIPTION_CONTENT_MATCH';await UI.navigateToScope(page,'IN_BEARBEITUNG');return;}await sleep(250);snap=await UI.queueTableSnapshot(page);row=snap.rows.find(r=>r.ticketId===id);if(!row)break;}}
 fail('SAVE_UNVERIFIED','Vollstaendige Beschreibung nach Speichern nicht nachgewiesen. Nicht erneut senden.');}

/** No reply text, no recipient, no send button for unmatched identities.
 * Save the exact note and fixed fields FIRST and verify persistence. Only then
 * select the top-level assignee and trigger the one-way forward action.
 */
async function forwardMissingPerson(page,rl,row,scope,journal,person,evidence,member,review,cfg,{description=NOT_FOUND_DESCRIPTION,reason='NOT_IN_MAPPING'}={}){
 need(reason==='NOT_IN_MAPPING'||reason==='NOT_IN_COMARCH','ROUTE_REASON','Unbekannter Weiterleitungsgrund.');
 if(reason==='NOT_IN_COMARCH'){
  need(member===null&&review===null,'NO_MEMBER_HAS_ID','Ohne COMARCH-Zuordnung darf keine Identitaet vorausgesetzt werden.');
  const check=memberAbsenceGate(await memberAbsenceObservation(page));
  need(check.ok,'COMARCH_MEMBER_IDENTITY_UNRESOLVED','COMARCH-Member nicht mehr eindeutig fehlend: '+check.reason);
  need(!(await UI.selectedMember(page,person)),'COMARCH_MEMBER_NOW_SELECTED','Inzwischen COMARCH-Member vorhanden. Keine No-Member-Weiterleitung.');
  log('COMARCH_PERSON_NOT_FOUND - Keine E-Mail, kein Versand; bewusstes Routing.');
 }else need(member&&review,'ROUTE_MEMBER_REQUIRED','Bestands-Nichttreffer verlangt gebundenen COMARCH-Member.');
 // Decide recipient before editing the ticket, so cancel leaves no draft/notes.
 const destination=await chooseForwardDestination(text=>ask(rl,text),log,{demo:DEMO,demoKey:['missing-member-mark','missing-comarch-member-mark'].includes(DEMO_SCENARIO)?'1':'2'});
 log('ROUTE_RECIPIENT_SELECTED: '+destination.display+' ('+destination.account+'). Keine E-Mail.');
 if(PILOT&&!DEMO){
  log('PILOT OHNE E-MAIL: '+row.ticketId+' | Weiterleitung an '+destination.display+'.');
  log('Zusatzbeschreibung: '+description+' | Zust.: Second Level | Kategorie: Allgemeine Schriftwechsel | Unterkategorie: Personenschriftwechsel.');
  need((await ask(rl,'Angaben geprueft und Weiterleitung statt E-Mail freigeben? WEITERLEITEN: ')).toUpperCase()==='WEITERLEITEN','ROUTE_NOT_ARMED','Weiterleitung nicht freigegeben. Kein Versand.');
 }
 let w=await UI.writeDescription(page,description);
 need(w.ok,'DESCRIPTION_WRITE','Manueller Klaerungstext nicht eindeutig einsetzbar: '+w.state);
 await sleep(650);need(await UI.verifyDescription(page,description),'DESCRIPTION_VERIFY','Manueller Klaerungstext nicht nachweisbar.');
 await fixedFields(page,rl);need(await UI.verifyDescription(page,description),'DESCRIPTION_CHANGED','Beschreibung nach Kategorieauswahl veraendert.');
 const recheck=await UI.selectedMember(page,person);
 if(reason==='NOT_IN_COMARCH'){
  need(!recheck,'COMARCH_MEMBER_NOW_SELECTED','Nach Pflichtfeldkontrolle ist ein COMARCH-Member vorhanden. Keine Weiterleitung als unbekannt.');
  need(memberAbsenceGate(await memberAbsenceObservation(page)).ok,'COMARCH_MEMBER_IDENTITY_UNRESOLVED','Nach Pflichtfeldkontrolle gibt es wieder Profilhinweise.');
 }else{requireReviewedMember(recheck,person,evidence,review);need(recheck.id===member.id,'MEMBER_CHANGED','Member vor Weiterleitung veraendert.');}
 if(!DEMO){need(loadActiveMapping(root).fileHash===diag.mapping.fileHash,'MAPPING_CHANGED','Aktives Mapping veraendert.');journal.beginForward(row.ticketId,description);}
 // A saved description is a proof of saving the NOTE, not necessarily of every
 // ICEfaces field. Reopen and inspect the three persistent routing fields.
 await saveOnce(page,row.ticketId,journal,{forwardOnly:true});await verifySaved(page,row.ticketId,description);
 journal?.forwardSet(row.ticketId,'ROUTE_SAVED_VERIFIED');
 const reopen=async()=>{
  let current=null,currentScope=null;
  for(const s of [scope,scope==='IN_BEARBEITUNG'?'WARTESCHLANGE_INTL01':'IN_BEARBEITUNG']){
   const snap=await UI.navigateToScope(page,s);current=snap.rows.find(r=>r.ticketId===row.ticketId);
   if(current){currentScope=s;break;}
  }
  need(current,'ROUTE_TICKET_NOT_VISIBLE','Beschreibung gespeichert, Ticket vor Weiterleitung nicht erneut auffindbar. Kein blinder Klick.');
  await UI.openTicket(page,current,{scope:currentScope});await UI.ensureEdit(page);await UI.assertTicket(page,row.ticketId);
  need(await UI.verifyDescription(page,description),'ROUTE_DESCRIPTION_NOT_PERSISTED','Gespeicherte Beschreibung vor Weiterleitung nicht nachgewiesen.');
 };
 await reopen();
 const postSaveFields=async()=>{
  let check=null;
  for(let i=0;i<12;i++){
   const fixed=await UI.fixedFieldValues(page);
   check=routeFixedAssessment(fixed,Prep.FIXED);
   if(check.ok)break;
   await sleep(250);
  }
  return check;
 };
 let check=await postSaveFields();
 if(!check.ok){
  // Exactly one repair of reversible fields is permitted, with its own
  // durable journal state BEFORE the second SAVE click. NEVER a second forward.
  log('ROUTE_PERSISTENCE_REPAIR: Nach Speichern nicht bestaetigt: '+check.missing.join(', ')+'. Einmaliges kontrolliertes Nachsetzen.');
  diag.phase='ROUTE_FIELD_REPAIR';
  await fixedFields(page,rl);await UI.assertTicket(page,row.ticketId);
  need(await UI.verifyDescription(page,description),'ROUTE_DESCRIPTION_CHANGED','Beschreibung vor Reparatur-Speichern geaendert.');
  await saveOnce(page,row.ticketId,journal,{forwardRepair:true});
  await verifySaved(page,row.ticketId,description);
  journal?.forwardSet(row.ticketId,'ROUTE_SAVED_VERIFIED');
  await reopen();check=await postSaveFields();
 }
 need(check.ok,'ROUTE_FIXED_FIELDS_NOT_PERSISTED',
  'Nach erneutem Oeffnen weiterhin nicht gespeichert: '+check.missing.join(', ')+'. Keine Weiterleitung; keine weitere Speicherung.');
 log('PASS ROUTE_PERSISTENT_FIELDS_VERIFIED: Second Level, Allgemeine Schriftwechsel, Personenschriftwechsel. Signatur wird nur VOR dem Speichern geprueft (kein E-Mail-Versand).');
 diag.phase='FORWARD_MISSING_PERSON';
 // User's actual COMARCH field, NOT a heuristically selected neighbour.
 const manualRouteGate=DEMO?null:async(state,dest)=>{
  if(state==='SUGGESTION_MANUAL_SELECTION'){
   log('ROUTE_MANUAL_SUGGESTION: Nur '+dest.display+' ('+dest.account+') im COMARCH-Dropdown anwaehlen. KEINE Weiterleitung ausloesen.');
   need((await ask(rl,'Nach TATSAECHLICHER Vorschlagsauswahl AUSGEWAEHLT eingeben, sonst ENTER: ')).toUpperCase()==='AUSGEWAEHLT',
    'ASSIGNEE_NOT_SELECTED','COMARCH-Person nicht bestaetigt. Keine Weiterleitung.');
  }else{
   log('ROUTE_MANUAL_FOCUS: Im Bot-Edge NUR das Feld mainForm:persona-assignment-id anklicken. Keine Weiterleitung. Ursache: '+state);
   await ask(rl,'Bearbeiterfeld wirklich fokussiert? ENTER: ');
  }
 };
 if(reason==='NOT_IN_COMARCH'){
  need(!(await UI.selectedMember(page,person))&&memberAbsenceGate(await memberAbsenceObservation(page)).ok,
   'COMARCH_MEMBER_NOW_SELECTED','Member/Profilhinweis nach erneutem Oeffnen gefunden. Keine unbekannte Person weiterleiten.');
 }
 const assignment=await selectAssignee(page,destination,{manualGate:manualRouteGate});
 log('PASS ROUTE_ASSIGNEE_COMMITTED: '+destination.display+' ('+assignment.method+').');
 const finalFields=routeFixedAssessment(await UI.fixedFieldValues(page),Prep.FIXED);
 need(finalFields.ok,'ROUTE_FIXED_FIELDS_CHANGED','Pflichtfelder nach Bearbeiterauswahl veraendert: '+finalFields.missing.join(', ')+'. Keine Weiterleitung.');
 const proof=await forwardOnce(page,destination,{
  selectionReceipt:assignment,
  beforeClick:()=>journal?.forwardSet(row.ticketId,'FORWARD_INTENT'),
  confirmManually:DEMO?null:async()=>{
   log('Weiterleitung wurde genau einmal angeklickt, aber COMARCH hat keinen auswertbaren Erfolgsnachweis gezeigt.');
   log('Bitte in COMARCH pruefen, dass Ticket '+row.ticketId+' wirklich bei '+destination.display+' liegt und Beschreibung gespeichert ist. KEINEN zweiten Klick ausloesen.');
   return (await ask(rl,'Nach eigener Pruefung WEITERGELEITET bestaetigen, sonst ENTER: ')).toUpperCase()==='WEITERGELEITET';
  }
 });
 journal?.forwardSet(row.ticketId,'ROUTED_CONFIRMED');
 diag.forward={verified:true,method:proof.source,noEmail:true,descriptionVerified:true,fixedFieldsVerified:true};
 diag.loop.processed++;diag.loop.forwarded++;
 if(scope==='IN_BEARBEITUNG')diag.loop.myTasksProcessed++;else diag.loop.queueProcessed++;
 diag.loop.processedTickets.push({source:scope,type:'FORWARDED_WITHOUT_EMAIL',route:proof.source,assignee:destination.key,save:diag.save.verification,lookup:reason,fixedFieldsVerified:true});
 show({event:'complete',answered:'Keine E-Mail',phase:'Weitergeleitet'});
 log('PASS PERSON_NOT_FOUND_FORWARDED ['+reason+'] - ohne E-Mail an '+destination.display+'.');
 ticketAudit(cfg,row.ticketId,reason==='NOT_IN_COMARCH'?'COMARCH_PERSON_NICHT_GEFUNDEN_WEITERGELEITET':'OHNE_EMAIL_WEITERGELEITET_VERIFIZIERT',scope,destination.display+' / '+proof.source);
 await UI.navigateToScope(page,'IN_BEARBEITUNG');
}
async function processTicket(page,mapping,rl,row,scope,cfg,journal){diag.preSendDescriptionRestored=false;diag.personSource=null;diag.nameDiscovery=null;diag.memberReview=null;diag.fixedFieldResolution=[];diag.phase='EDIT_OPEN';await UI.ensureEdit(page);await UI.assertTicket(page,row.ticketId);diag.phase='MAIL_AND_PERSON';let {person,evidence}=await mailAndPerson(page,cfg,rl,row.ticketId);
 const tAudit=diag.nameDiscoveryByTicket||(diag.nameDiscoveryByTicket=[]);
 if(tAudit.length<100)tAudit.push({ordinal:diag.loop.processed+1,source:diag.nameDiscovery?.successfulSource||diag.mailSource||'MANUAL',readProbes:diag.nameDiscovery?.checked??0,usedManualInput:diag.personSource==='MANUAL_OPERATOR_CONFIRMED'});
 diag.phase='MEMBER_SEARCH';const selection=await selectMember(page,person,evidence,rl);const {member,review}=selection;person=selection.person;
 if(selection.comarchNotFound){
  log('PERSON_IN_COMARCH_NICHT_GEFUNDEN: Keine MercerID; keine E-Mail und kein Bestands-Lookup.');
  diag.lookup={status:'NOT_IN_COMARCH',method:'OPERATOR_CONFIRMED_NO_MEMBER',sourceRowCount:0};
  diag.phase='FORWARD_COMARCH_MEMBER_NOT_FOUND';
  await forwardMissingPerson(page,rl,row,scope,journal,person,evidence,null,null,cfg,
    {description:COMARCH_NOT_FOUND_DESCRIPTION,reason:'NOT_IN_COMARCH'});
  return;
 }
 log('Identitaetsnachweis PASS ('+evidence.mode+').');
 diag.phase='MAPPING_LOOKUP';const resolved=resolveMemberMapping(mapping.map,member.id);
 diag.lookup={status:resolved.kind,method:resolved.method,sourceRowCount:resolved.entry?.rowCount??0,descriptionLineCount:resolved.entry?.descriptionLines.length??0,genderStatus:resolved.entry?.genderStatus??null};
 if(resolved.kind==='NOT_FOUND'){diag.phase='FORWARD_MISSING_PERSON';await forwardMissingPerson(page,rl,row,scope,journal,person,evidence,member,review,cfg);return;}
 if(resolved.method==='PREFIX_11_REMOVED')log('PASS PREFIX11_FALLBACK_MATCH - COMARCH-ID unveraendert; nur Bestands-Lookup mit gekuerzter Kennung.');
 const entry=resolved.entry;
 const displayLines=sourceUSCLines(entry.description);show({event:'update',usc:displayLines.join(' · '),phase:'Bestand geprueft'});
 // Preflight BEFORE any send: both facts must fit without truncating USC data.
 const savedDescription=descriptionWithStatus(entry.description);
 diag.phase='DESCRIPTION_AND_FIXED_FIELDS';show({event:'update',phase:'Pflichtfelder setzen'});
 // Check for the same outgoing acknowledgement before touching a user draft
 // or any fixed field. In particular, a previous bot run may have sent the
 // mail but crashed before SAVE. This is NOT an instruction to resend it.
 const earlySal=entry.gender==='M'?'Herr':entry.gender==='F'?'Frau':null;
 if(earlySal){const priorReply=Prep.replyText(earlySal,person.lastName);
  need(!(await UI.acknowledgementAlreadyInHistory(page,priorReply)),'REPLY_ALREADY_IN_HISTORY','Empfangsbestaetigung bereits im COMARCH-Verlauf vorhanden. Kein neuer Versand und kein Ueberschreiben eines bestehenden Entwurfs. Speicherung gesondert pruefen.');
 }
 if(entry.hasCachedFormulas&&!DEMO)need(/^ja$/i.test(await ask(rl,'Aktualitaet der gespeicherten Formelwerte aller Bestandszeilen geprueft? JA: ')),'FORMULA_REVIEW_REQUIRED','Formelcache nicht freigegeben.');
 const descriptionInitial=await UI.additionalDescriptionState(page);
 need(descriptionInitial.ok&&descriptionInitial.editable,'DESCRIPTION_UNBOUND','Zusaetzliche Beschreibung vor Bearbeitung nicht eindeutig.');
 log('Bestandsabgleich: '+entry.rowCount+' Quellzeile(n), eine Antwort pro Ticket.');const w=await UI.writeDescription(page,entry.description);need(w.ok,'DESCRIPTION_WRITE','Beschreibung nicht eindeutig einsetzbar: '+w.state);await sleep(700);need(await UI.verifyDescription(page,entry.description),'DESCRIPTION_VERIFY','Beschreibung nach Seitenreaktion abweichend.');await fixedFields(page,rl);show({event:'update',phase:'Antwort vorbereiten'});
 let sal=entry.gender==='M'?'Herr':entry.gender==='F'?'Frau':null;if(!sal){need(!DEMO,'DEMO_GENDER','Fiktive Anrede fehlt.');const a=(await ask(rl,'Anrede aus Bestand nicht eindeutig. Geprueft: H=Herr / F=Frau: ')).toUpperCase();need(['H','F'].includes(a),'SALUTATION_REQUIRED','Anrede nicht freigegeben.');sal=a==='H'?'Herr':'Frau';}
 const reply=Prep.replyText(sal,person.lastName);const replyResult=await UI.editor(page,reply);
 need(!replyResult.occupied,'REPLY_DRAFT_OCCUPIED','Im COMARCH-Antworteditor steht bereits ein abweichender Entwurf. Er wurde nicht ueberschrieben oder versendet. Bitte bestehenden Entwurf und Nachrichtenverlauf pruefen.');
 need(replyResult.ok,'REPLY_WRITE','Antworteditor nicht eindeutig erkannt/bestaetigt: '+(replyResult.state||'UNKNOWN')+'. Kein Versand.');await sleep(500);const dest=await UI.recipient(page);need(dest.ok,'RECIPIENT','Genau ein Empfaenger im Feld An erforderlich.');
 if(DEMO&&['rc62-presend-blank','rc62-presend-conflict'].includes(DEMO_SCENARIO))await page.eval('window.__mcrDemoResetBeforeSend()');
 const approval=DEMO?null:await overlay.authorize({ticketId:row.ticketId,ask:q=>ask(rl,q)});
 if(!DEMO){diag.deliveryMode=overlay.gate.mode;log('PASS VERSANDFREIGABE: '+approval.mode+' | '+row.ticketId);}
 await UI.assertTicket(page,row.ticketId);const finalMember=await UI.selectedMember(page,person);requireReviewedMember(finalMember,person,evidence,review);need(finalMember.id===member.id,'MEMBER_CHANGED','Member vor Versand geaendert.');need((await UI.recipient(page)).address===dest.address,'RECIPIENT_CHANGED','Empfaenger geaendert.');
 // RC62: an ICEfaces refresh after the answer editor or the MANUAL/AUTO gate
 // may clear only the additional-description field. Repair precisely that
 // blank once, natively, BEFORE committing any send intent. A foreign or
 // modified non-empty value is never overwritten. Verify all other fields
 // again after any repair.
 const preSend=await ensurePreSendDescription({ticketId:row.ticketId,expected:entry.description,
  initialValue:descriptionInitial.value,botWriteProven:true,
  read:()=>UI.additionalDescriptionState(page),assertTicket:x=>UI.assertTicket(page,x),
  restore:()=>commitDescription(page,{ticketId:row.ticketId,expected:entry.description,allowedBefore:[''],
   log,manualFocus:DEMO?null:async()=>{
    log('PRESEND_DESCRIPTION_FOKUS: Im Bot-Edge nur das Textfeld Zusaetzliche Beschreibung anklicken.');
    need((await ask(rl,'Feld gleich anklicken? BEREIT_BESCHREIBUNG / ABBRUCH: ')).toUpperCase()==='BEREIT_BESCHREIBUNG',
     'PRESEND_DESCRIPTION_FOCUS_CANCELLED','Manuelle Fokusfreigabe abgelehnt. Kein Versand.');
   }}),wait:()=>sleep(450),log});
 if(preSend.restored)diag.preSendDescriptionRestored=true;
 const finalFixed=await UI.fixedFieldValues(page);need(finalFixed.responsibility===Prep.FIXED.responsibility&&finalFixed.category===Prep.FIXED.category&&finalFixed.subcategory===Prep.FIXED.subcategory&&finalFixed.signature===Prep.FIXED.signature,'FIXED_FIELD_CHANGED_BEFORE_SEND','Unterkategorie oder anderes Pflichtfeld vor dem Versand veraendert. Kein Versand.');const ed=await UI.editor(page);need(ed.ok&&Prep.sameText(ed.text,reply),'REPLY_CHANGED','Antwort vor Versand geaendert.');need(!(await UI.acknowledgementAlreadyInHistory(page,reply)),'REPLY_ALREADY_IN_HISTORY','Diese Empfangsbestaetigung ist bereits im COMARCH-Verlauf vorhanden. Kein zweiter Versand.');
 if(!DEMO){need(loadActiveMapping(root).fileHash===mapping.fileHash,'MAPPING_CHANGED','Aktives Mapping im Lauf geaendert.');}
 show({event:'update',answered:'Nein',phase:'Versandpruefung'});
 diag.phase='SEND_AND_SAVE';log('VERSANDPRUEFUNG: Nur ein Versandklick; kontrolliere COMARCH-Dialoge und neue Ausgangsnachricht. Bitte keinen zweiten Versand ausloesen.');await sendOnce(page,rl,row.ticketId,journal,dest.address,{savedDescription,approval,preSendSource:entry.description});need(validSendAcknowledgements(diag.send),'SEND_DIALOGS_NOT_VERIFIED','Kein ausreichend sicherer Dialog- oder Verlaufnachweis. Kein zweiter Versand.');if(diag.send.ackMode==='BOUND_NEW_OUTGOING_HISTORY')log('PASS SEND_IN_HISTORY_BOUND: Eine neue ausgehende Standardantwort an den Originalabsender im aktuellen Ticket belegt; '+(diag.send.htmlDialogs+diag.send.jsDialogs)+' OK-Dialog(e), '+diag.send.successNotices+' Erfolgshinweis(e).');else if(diag.send.ackMode==='OPERATOR_VERIFIED_OUTGOING')log('PASS SEND_OPERATOR_VERIFIED: Versand manuell im COMARCH-Verlauf bestaetigt, kein automatischer Verlaufbeleg.');else log('PASS SEND_DIALOGS_CONFIRMED_ONCE ('+(diag.send.htmlDialogs+diag.send.jsDialogs)+' verschiedene Dialoge'+(diag.send.successNotices?', Erfolgsmeldung erkannt':'')+').');log('Versandnachweis PASS ('+diag.send.ackMode+').');show({event:'update',answered:'JA · belegt',phase:'Ticket speichern'});
 // Only NOW may the description say "Standardantwort versendet".
 // This is the SAME ticket and will be saved exactly once together with USC.
 diag.phase='POST_SEND_STATUS_AND_SAVE';
 if(DEMO&&DEMO_SCENARIO==='rc38-postsend-rerender')await page.eval('window.__mcrDemoResetAfterSend()');
 log('POST_SEND_STATUS_BEGIN: Versandnachweis bestaetigt. Kein zweiter Versand; pruefe Status und USC.');
 need(diag.send.verified&&journal?.pending?.some(p=>p.ticketId===row.ticketId&&p.state==='SENT_CONFIRMED')||DEMO&&diag.send.verified,
  'POST_SEND_SEND_NOT_PROVEN','Ohne bestaetigten Versand ist keine Statusmarkierung zulaessig.');
 await markAfterVerifiedSend({ticketId:row.ticketId,expected:savedDescription,marker:STANDARD_ANSWER_NOTE,
  prepare:async()=>preparePostSendDescription({ticketId:row.ticketId,source:entry.description,expected:savedDescription,
   bind:id=>rebindSentTicket(page,id),read:()=>UI.additionalDescriptionState(page),
   ensureEdit:()=>UI.ensureEdit(page),write:value=>UI.writeDescription(page,value),
   verify:value=>UI.verifyDescription(page,value),delay:sleep,log}),
  assertTicket:id=>UI.assertTicket(page,id),append:m=>UI.appendStandardAnswerMarker(page,m),
  verify:text=>UI.verifyDescription(page,text),delay:sleep,log});
 await commitDescription(page,{ticketId:row.ticketId,expected:savedDescription,log});
 diag.phase='SEND_AND_SAVE';
 await saveOnce(page,row.ticketId,journal);await verifySaved(page,row.ticketId,savedDescription);
 journal?.set(row.ticketId,'COMPLETE');log('Ticket speichern PASS ('+diag.save.verification+').');
 reportColumnsAfterSave(cfg,row.ticketId,savedDescription);show({event:'complete',answered:'JA · gespeichert',phase:'Fertig'});
 diag.loop.processed++;if(scope==='IN_BEARBEITUNG')diag.loop.myTasksProcessed++;else diag.loop.queueProcessed++;diag.loop.processedTickets.push({source:scope,sendAck:diag.send.ackMode,save:diag.save.verification,sourceRowCount:entry.rowCount,descriptionLineCount:entry.descriptionLines.length,lookupMethod:resolved.method,nameSource:diag.personSource,memberOperatorReview:!!review.reviewed,readProbes:diag.nameDiscovery?.checked??0,fixedFieldActionCount:diag.fixedFieldResolution?.length??0});
 ticketAudit(cfg,row.ticketId,'VERSAND_UND_SPEICHERUNG_VERIFIZIERT',scope,diag.send.ackMode+' / '+diag.save.verification);
 if(PILOT)log('PASS PILOT_STATUS_UND_SPEICHERUNG_VERIFIZIERT: Automatische Fortsetzung wird erst jetzt freigegeben.');
}
async function diagnostic(cfg){fs.mkdirSync(cfg.diagnosticDirectory,{recursive:true});plainPath(cfg.diagnosticDirectory);const raw=JSON.stringify(diag,null,2)+'\n',manifest=JSON.stringify({schema:'MCR_DIAGNOSTIC_MANIFEST_V1',payload:[{path:'diagnostic.json',sha256:sha256(raw)}]},null,2)+'\n';const file=path.join(cfg.diagnosticDirectory,'MCR_LOCAL_RUNNER_'+stamp()+'_UPLOAD.zip');const bytes=writeZip([{name:'diagnostic.json',data:raw},{name:'manifest.json',data:manifest}]);fs.writeFileSync(file,bytes,{flag:'wx'});writeJSON(path.join(cfg.diagnosticDirectory,'last-result.json'),diag);log('Diagnose: '+file);log('Diagnose-ZIP-SHA256: '+sha256(bytes));}
async function main(){let cfg=null,browser=null,cdp=null,rl=null;try{
 log('\n==============================================================\n MCR DATENBRUECKE '+VERSION+' | '+(DEMO?'FIKTIVE DEMO - KEIN ECHTVERSAND':args.has('--complete-pending')?'ABSCHLUSS OHNE NEUVERSAND':PILOT?'BEAUFSICHTIGTER EINZELTICKET-PILOT':'ECHTER TICKETLAUF')+'\n==============================================================');need(Number.isInteger(MAX)&&MAX>=1&&MAX<=100,'TICKET_LIMIT','Limit muss 1 bis 100 sein.');cfg=resolveConfig(root);if(DEMO){const sandbox=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-Fiktiv-Profil-'));cfg.runtimeDirectory=sandbox;cfg.profileDirectory=path.join(sandbox,'edge-profile');cfg.downloadDirectory=path.join(sandbox,'downloads');}let mapping,journal=null;
 if(DEMO){const f=readJSON(path.join(root,'examples/DEMO_mapping.json'),65536);need(f.schema==='MCR_FICTIONAL_SOURCE_V1'&&f.rows.length===2&&f.rows.every(r=>r.B==='99900001'),'DEMO_SOURCE','Fiktive Quelle fehlt.');const map=makeMultirowMapping({meta:f.source,allRows:()=>f.rows},{mode:'DEMO',headerConfirmed:true,generatedAt:'2026-01-01T00:00:00.000Z'});need(lookupMultirow(map,'99900001').description===f.expectedDescription,'DEMO_SEMANTICS','Fiktive Beschreibung abweichend.');mapping={map,fileHash:map.payloadSha256};diag.demoExpectedDescriptionSha256=sha256(descriptionWithStatus(f.expectedDescription));}
 else{verifySession(root,process.env.MCR_SESSION_TOKEN);mapping=loadActiveMapping(root);journal=ledger(root);blockedTicketIds(root);}
 diag.mapping={loaded:true,multirow:true,explicitActive:!DEMO,fileHash:mapping.fileHash};log('Aktives Mapping geprueft. Mehrzeilen/TPP-Regeln bleiben erhalten.');fs.mkdirSync(cfg.runtimeDirectory,{recursive:true});fs.mkdirSync(cfg.downloadDirectory,{recursive:true});overlay=DEMO?overlay:createDeliveryConsole({initialMode:args.has('--chained-after-pilot')&&process.env.MCR_DELIVERY_MODE==='AUTO'?'AUTO':'MANUAL',log});if(!DEMO)await overlay.ready();show({event:'start',ticket:'–',name:'–',id:'–',usc:'–',answered:'Nicht geprueft',phase:'Browser wird vorbereitet'});rl=readline.createInterface({input:process.stdin,output:process.stdout});const exe=findEdgeExecutable(cfg.edgePath);need(exe,'BROWSER_NOT_FOUND','Microsoft Edge/Chromium fehlt.');
 const chained=args.has('--chained-after-pilot')||args.has('--chained-after-forward')||args.has('--master-phase1-batch');
  browser=await launchBrowser({executable:exe,userDataDir:cfg.profileDirectory,startUrl:DEMO||chained?'about:blank':cfg.comarchUrl,headless:DEMO,extraArgs:DEMO?['--disable-background-networking','--disable-component-update','--disable-sync',...(process.platform!=='win32'&&process.getuid?.()===0?['--no-sandbox']:[])]:[]});
  diag.browser.launched=true;({cdp}=await connectBrowser(browser.port));if(!DEMO)overlay.protectInput(cdp);
  // A persisted Edge profile may restore an OLD COMARCH target; do not attach
  // the first arbitrary matching tab for a follow-on run. Bind a new target ID.
  const page=chained&&!DEMO?await attachFreshPage(cdp,cfg.comarchUrl):await attachPage(cdp,t=>DEMO?t.url==='about:blank':t.url.startsWith('https://comarchecm.mercer.com/'),DEMO?30000:180000);
  diag.browser.freshBoundTarget=chained&&!DEMO;
 if(DEMO){await injectDemo(page,{width:Number(process.env.MCR_DEMO_WIDTH||1000),scenario:DEMO_SCENARIO});}else{
  log('Im eigenen Bot-Edge anmelden. Kein Ticket manuell starten; der Bot beginnt in Meine Vorgaenge.');
  if(args.has('--chained-after-pilot')){
   const receipt=readJSON(path.join(root,'.runtime/beta-control/complete-pilot-pass.json'),65536);
   authorizeChainedContinuation({runId:process.env.MCR_CHAINED_PILOT_RUN_ID,receipt,
    manifestSha:sha256(fs.readFileSync(path.join(root,'MANIFEST.json'))),mappingSha:mapping.fileHash,ticketLimit:MAX});
   log('PASS CHAINED_AFTER_VERIFIED_PILOT: '+MAX+' weitere Tickets mit exakt versiongebundener Versandfreigabe.');
  }else if(args.has('--chained-after-forward')){
   need(PILOT&&MAX===1,'FORWARD_CHAIN_INVALID_MODE','Nur ein einzelner Fortsetzungspilot nach Weiterleitung.');
   const receipt=readJSON(path.join(root,'.runtime/beta-control/complete-forward-pilot-pass.json'),65536);
   authorizeForwardPilotContinuation({runId:process.env.MCR_CHAINED_FORWARD_RUN_ID,receipt,
    manifestSha:sha256(fs.readFileSync(path.join(root,'MANIFEST.json'))),mappingSha:mapping.fileHash,ticketLimit:MAX});
   log('PASS CHAINED_AFTER_VERIFIED_FORWARD: Vorige interne Weiterleitung nachgewiesen. Genau ein weiterer Einzelpilot; KEINE Sendebatchfreigabe.');
  }else if(args.has('--master-phase1-batch')){
   need(!PILOT&&MAX>=1&&MAX<=100,'MASTER_BATCH_INVALID_MODE','Masterteilprozess nur als begrenzter Batch.');
   const masterId=process.env.MCR_MASTER_RUN_ID,mf=path.join(root,'.runtime/master','MCR_MASTER_RUN_'+masterId+'.json');
   need(typeof masterId==='string'&&/^[0-9TZ._a-zA-Z-]{12,160}$/.test(masterId)&&fs.existsSync(mf),'MASTER_BATCH_NOT_AUTHORIZED','Masterfreigabe fehlt.');
   authorizeMasterBatch({masterId,masterReport:readJSON(mf,65536),
    receipt:readJSON(path.join(root,'.runtime/beta-control/complete-pilot-pass.json'),65536),
    manifestSha:sha256(fs.readFileSync(path.join(root,'MANIFEST.json'))),mappingSha:mapping.fileHash,ticketLimit:MAX});
   log('PASS MASTER_PHASE1_BATCH_AUTHORIZED: MASTER_START und echter verifizierter Versandpilot gebunden; maximal '+MAX+' unterschiedliche Tickets.');
  }else {
   const prompt=args.has('--complete-pending')?'Alten Versand pruefen und nur Status/Speicherung abschliessen. KEINE neue E-Mail. START: ':PILOT
    ? 'Echter Lauf: 1 Pilotticket. Bei verifiziertem Versand UND Speicherung folgen automatisch bis zu 5 weitere Tickets. START zum Vorbereiten (Versandmodus startet MANUELL): '
    : 'Echter Lauf, maximal '+MAX+' Ticket(s). START zum Freigeben: ';
   need(/^start$/i.test(await ask(rl,prompt)),'RUN_NOT_ARMED','Kein Lauf freigegeben.');
  }
 }
 if(!DEMO&&args.has('--complete-pending')){
  const id=process.env.MCR_REPAIR_TICKET;
  const repaired=await completePendingSentTicket({page,journal,id,mapping:mapping.map,ask:q=>ask(rl,q),log,
   save:(ticket,j)=>saveOnce(page,ticket,j),verify:(ticket,text)=>verifySaved(page,ticket,text),
   report:(ticket,text)=>reportColumnsAfterSave(cfg,ticket,text)});
  diag.completionOnly=repaired;diag.loop.processed=1;diag.loop.completed=true;diag.loop.finishReason='COMPLETION_ONLY';
  log('PASS PENDING_TICKET_COMPLETED_WITHOUT_SEND: '+id);return;
 }
 const processed=new Set([...(journal?.completedIds()||[]),...(!DEMO?blockedTicketIds(root):[])]);
  if(chained&&!DEMO){
   // No business action has occurred in the fresh follow-on tab. A controlled
   // same-origin restart of its own page is safe if initial ICEfaces boot fails.
   let navError=null;
   for(let attempt=0;attempt<2;attempt++){
    try{await UI.navigateToScope(page,'IN_BEARBEITUNG',{startup:true});navError=null;break;}
    catch(e){if(e.code!=='QUEUE_NAVIGATION')throw e;
     navError=e;diag.navigation=diag.navigation||{startupMode:'FRESH_TARGET',retries:[]};
     diag.navigation.retries.push({attempt:attempt+1,state:e.navigationState});
     log('NAV_STARTUP_RECOVERY: Neue COMARCH-Seite noch nicht in der Vorgangsansicht; Navigation wird kontrolliert neu geladen.');
     if(attempt===0){await page.cdp.send('Page.navigate',{url:cfg.comarchUrl},page.sessionId,15000);await sleep(900);}
    }
   }
   if(navError)throw navError;
   log('PASS FOLLOWON_QUEUE_READY: Eigene neue Browserseite und Vorgangsansicht eindeutig gebunden.');
  }else await UI.navigateToScope(page,'IN_BEARBEITUNG');
 while(diag.loop.processed<MAX){let row=null,scope=null;for(const s of ['IN_BEARBEITUNG','WARTESCHLANGE_INTL01']){const q=await UI.navigateToScope(page,s);row=q.rows.find(r=>firstPassCandidate(r)&&!processed.has(r.ticketId));if(row){scope=s;break;}}
 if(!row){diag.loop.completed=true;diag.loop.finishReason='NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS';break;}
 await UI.openTicket(page,row,{scope,log,manualOpen:DEMO?null:async ({ticketId,scope,state})=>{
  log('P1_MANUELLE_TICKETAUSWAHL: Nur Ticket '+ticketId+' in '+scope+' im Bot-Edge oeffnen; keinen anderen Vorgang und kein Bearbeiten anklicken.');
  const answer=(await ask(rl,'Genau dieses Ticket aus dieser Liste geoeffnet? TICKET_GEOEFFNET / ABBRUCH: ')).toUpperCase();
  need(answer==='TICKET_GEOEFFNET','P1_MANUAL_TICKET_ABORT','Ticketoeffnung nicht bestaetigt. Keine Bearbeitung.');
 }});show({event:'start',ticket:row.ticketId,name:'Wird ermittelt',id:'–',usc:'–',answered:'Wird geprueft',phase:'Ticket oeffnen'});log('\n--- Ticket '+(diag.loop.processed+1)+' aus '+scope+' ---');log('TICKET_ID: '+row.ticketId);
  // RC19: examine the authenticated, currently opened ticket BEFORE any edits.
  // A prior acknowledgement is a SKIP, not an error and NEVER a send retry.
  await UI.ensureEdit(page);await UI.assertTicket(page,row.ticketId);
  // Read-only counts come from the icons/columns of THIS ticket only.
  // A gateway/bounce is SYSTEM, never a customer and never a name source.
  const history=await UI.ticketHistoryAudit(page,row.ticketId);
  const audits=diag.historyByTicket||(diag.historyByTicket=[]);
  if(audits.length<100)audits.push({ordinal:audits.length+1,available:history.ok,total:history.total,
    fromCustomer:history.customer,fromUs:history.outgoing,system:history.system,unknown:history.unknown,
    standardAnswers:history.standardAnswerRows,standardAnswerBound:history.standardAnswerVerified});
  if(history.ok)show({event:'update',answered:history.standardAnswerVerified?'JA · bereits gesendet':'Nein',phase:history.standardAnswerVerified?'USC-Nachtrag':'Personenabgleich'});
  if(history.ok)log('MAIL_HISTORY: Gesamt '+history.total+' | Kunde '+history.customer+' | Von uns '+history.outgoing+' | System/Ruecklaeufer '+history.system+' | Unklar '+history.unknown+' | Standardantwort(en) '+history.standardAnswerRows);
  else log('MAIL_HISTORY_UNAVAILABLE: Kein sicherer Zaehlnachweis (kein Schaetzwert).');
  // Quelle is informational. A POST/PORTAL/etc. ticket is examined like
  // any other ticket, but may NOT produce an email unless a CURRENT incoming
  // customer email and the reply recipient match exactly. No external action
  // occurs when this evidence is missing; leave the ticket for manual routing.
  if(clean(row.source).toUpperCase()!=='E-MAIL'){
   const mailSnapshot=await UI.historyMailSnapshots(page);
   const boundSender=await UI.ticketSenderMetadata(page);
   const replyRecipient=await UI.recipient(page);
   const proof=nonEmailReplyProof({source:row.source,history:mailSnapshot,recipient:replyRecipient,senderMetadata:boundSender});
   if(!proof.ok){
    log('SKIP_NO_VERIFIED_EMAIL_FOR_SOURCE: Ticket '+row.ticketId+' | Quelle '+(clean(row.source)||'(leer)')+
      ' | '+proof.reason+'. KEIN Versand, KEINE Aenderung. Ticket zur manuellen Bearbeitung belassen.');
    diag.loop.skippedWithoutEmail=(diag.loop.skippedWithoutEmail||0)+1;
    const notes=diag.loop.skippedTickets||(diag.loop.skippedTickets=[]);
    if(notes.length<100)notes.push({source:scope,channel:clean(row.source),reason:proof.reason,sentAgain:false});
    ticketAudit(cfg,row.ticketId,'KEINE_VERIFIZIERBARE_EMAIL',scope,proof.reason);
    show({event:'skip',answered:'Keine E-Mail',phase:'Manuelle Pruefung'});
    processed.add(row.ticketId);await UI.navigateToScope(page,'IN_BEARBEITUNG');continue;
   }
   log('PASS SOURCE_NEUTRAL_EMAIL_PROOF: Quelle '+(clean(row.source)||'(leer)')+
     '; authentische Eingangs-E-Mail und Originalabsender/Empfaenger sind gebunden.');
  }
  if(history.ok&&history.standardAnswerVerified){
   if(journal)blockedTicketIds(root); // Unresolved OTHER tickets stay excluded; save-only is safe for this ticket.
   diag.phase='ALREADY_ANSWERED_ANNOTATION';
   await UI.assertTicket(page,row.ticketId);
   // An ACK may have been sent by a prior operator, before USC was written.
   // Build the USC part from the *validated* COMARCH Member and active mapping.
   // Do not leave an orphaned status-only description when lookup is unsafe.
   let uscExisting=sourceUSCLines(row.descriptionValue).length>0;
   if(!uscExisting){
    diag.phase='ALREADY_ANSWERED_USC_LOOKUP';
    let found=null;
    try{
     const {person,evidence}=await mailAndPerson(page,cfg,rl,row.ticketId);
     const {member}=await selectMember(page,person,evidence,rl);
     const resolution=resolveMemberMapping(mapping.map,member.id);
     if(resolution.kind==='FOUND'&&!resolution.entry.hasCachedFormulas)found=resolution.entry;
    }catch(e){
     // Only the read/identity stage is optional. Never hide a write failure.
     log('SKIP_ANSWERED_USC_REVIEW: USC/Member aus Bestand nicht sicher nachweisbar ('+(e.code||'REVIEW')+'). Bereits versendete E-Mail bleibt unberuehrt.');
     processed.add(row.ticketId);diag.loop.skippedAlreadyAnswered++;show({event:'skip',answered:'JA · vorher',phase:'Manuelle Pruefung'});continue;
    }
    if(!found){
     log('SKIP_ANSWERED_USC_REVIEW: USC/Plan nicht sicher und vollstaendig ableitbar; kein Status-only-Eintrag.');
     processed.add(row.ticketId);diag.loop.skippedAlreadyAnswered++;show({event:'skip',answered:'JA · vorher',phase:'Manuelle Pruefung'});continue;
    }
    // If a writable COMARCH description was touched, any failure is fatal.
    descriptionWithStatus(found.description);
    const legacyStatusOnly=clean(row.descriptionValue)===STANDARD_ANSWER_NOTE;
    const w=legacyStatusOnly
      ?await UI.upgradeStatusOnlyDescription(page,found.description,STANDARD_ANSWER_NOTE)
      :await UI.writeDescription(page,found.description);
    need(w.ok,'STANDARD_REPLY_USC_WRITE','USC/Plan-Daten konnten nicht sicher eingesetzt werden: '+(w.state||'UNKNOWN'));
    await sleep(600);
    const written=legacyStatusOnly?descriptionWithStatus(found.description):found.description;
    need(await UI.verifyDescription(page,written),'STANDARD_REPLY_USC_VERIFY','USC-Daten nicht bestaetigt. Kein Versand.');
   }
   diag.phase='ALREADY_ANSWERED_ANNOTATION';
   const note=await UI.appendStandardAnswerMarker(page,STANDARD_ANSWER_NOTE);
   need(note.ok,'STANDARD_REPLY_NOTE','USC/Status konnte nicht eindeutig und verlustfrei ergaenzt werden: '+(note.state||'UNKNOWN'));
   statusColumns(note.value); // Never save a status-only ticket.
   await sleep(650);
   need(await UI.verifyDescription(page,note.value),'STANDARD_REPLY_NOTE_VERIFY','USC- und Statusspalte nach COMARCH-Aktualisierung nicht bestaetigt. Kein Versand.');
   // Even an unchanged draft marker may still be unsaved. Queue rows selected
   // here had an EMPTY persisted description; save exactly once and verify it.
   await UI.assertTicket(page,row.ticketId);
   diag.phase='ALREADY_ANSWERED_SAVE';
   await saveOnce(page,row.ticketId,null);
   await verifySaved(page,row.ticketId,note.value);
   reportColumnsAfterSave(cfg,row.ticketId,note.value);ticketAudit(cfg,row.ticketId,'VORHANDENE_ANTWORT_USC_GESPEICHERT',scope,'KEIN_NEUVERSAND');show({event:'complete',usc:sourceUSCLines(note.value).join(' · '),answered:'JA · vorher',phase:'USC gespeichert'});
   processed.add(row.ticketId);diag.loop.skippedAlreadyAnswered++;diag.loop.annotatedAlreadyAnswered++;
   const records=diag.loop.skippedTickets||(diag.loop.skippedTickets=[]);
   if(records.length<100)records.push({source:scope,reason:'EXACT_TICKET_OUTBOUND_ACK_TO_ORIGINAL_SENDER',sentAgain:false,
    statusMarker:'Standardantwort versendet',annotationSaved:true,saveVerification:diag.save.verification});
   log('PASS STANDARDANTWORT_VERSENDET_MARKIERT: USC-/Planinformationen UND Status getrennt dokumentiert und gemeinsam gespeichert. Keine weitere E-Mail.');
   log('PASS SKIP_ALREADY_ANSWERED: Beantwortetes Ticket archiviert im Arbeitsablauf; suche naechstes unbeantwortetes Ticket.');
   await UI.navigateToScope(page,'IN_BEARBEITUNG');await sleep(250);continue;
  }
  if(!row.descriptionBlank){
   // A historical status-only entry without a currently verified outgoing
   // ACK is NOT a justification for either another send or a USC overwrite.
   processed.add(row.ticketId);
   show({event:'skip',answered:'Ungeklaert',phase:'Keine Aenderung'});log('SKIP_STATUS_ONLY_UNVERIFIED: Kein zum aktuellen Ticket gebundener Versandnachweis; keine Aenderung und keine E-Mail.');
   await UI.navigateToScope(page,'IN_BEARBEITUNG');continue;
  }
  try{await processTicket(page,mapping,rl,row,scope,cfg,journal);}
  catch(e){
   // No external action has happened if the operator cancels a Member review
   // OR declines routing before any field edit. A pending journal (even from
   // an earlier run) makes this a hard STOP, never a blind continuation.
   const ownPending=!!journal?.pending?.some(x=>x.ticketId===row.ticketId);
   const skip=safePreactionSkip(e.code,diag.phase,{pending:ownPending,demo:DEMO});
   if(!skip)throw e;
   if(skip==='ROUTE_DECLINED'){
    log('SKIP_ROUTE_WITHOUT_AUTHORIZATION: Ticket '+row.ticketId+' bleibt unveraendert; keine Weiterleitung, keine E-Mail. Naechstes Ticket wird gesucht.');
   }else{
    log('SKIP_UNRESOLVED_MEMBER: Ticket '+row.ticketId+' wegen '+e.code+' zur manuellen Bearbeitung belassen; KEINE E-Mail, KEIN Weiterleiten. Andere Tickets werden fortgesetzt.');
   }
   diag.loop.skippedIdentity=(diag.loop.skippedIdentity||0)+1;
   const ids=diag.loop.skippedTickets||(diag.loop.skippedTickets=[]);
   if(ids.length<100)ids.push({source:scope,reason:e.code,sentAgain:false,identityReviewRequired:skip==='IDENTITY_REVIEW',routeDeclined:skip==='ROUTE_DECLINED'});
   ticketAudit(cfg,row.ticketId,skip==='ROUTE_DECLINED'?'WEITERLEITUNG_NICHT_FREIGEGEBEN':'MANUELLE_IDENTITAETSPRUEFUNG',scope,e.code);
   show({event:'skip',answered:'NICHT versendet',phase:skip==='ROUTE_DECLINED'?'Keine Weiterleitung':'Manuelle Pruefung'});
   processed.add(row.ticketId);await UI.navigateToScope(page,'IN_BEARBEITUNG');continue;
  }
  processed.add(row.ticketId);await sleep(400);
 }
 if(diag.loop.processed===MAX){diag.loop.completed=true;diag.loop.finishReason=PILOT?(diag.loop.forwarded?'PILOT_LIMIT_AFTER_VERIFIED_FORWARD':'PILOT_LIMIT_AFTER_VERIFIED_SAVE'):'LIMIT_AFTER_VERIFIED_ACTION';}
 if(DEMO){const b=await page.eval('window.__mcrMultirowDemo');diag.demoBrowser={sendClicks:b.sendClicks,saveClicks:b.saveClicks,forwardClicks:b.forwardClicks||0,savedLineCounts:b.savedLineCounts,trustedSends:b.trustedSends,trustedSaves:b.trustedSaves,trustedForwards:b.trustedForwards||[],okClicks:b.okClicks,trustedOkClicks:b.trustedOkClicks,savedDescriptionsMatch:b.savedDescriptions.every(s=>sha256(s)===diag.demoExpectedDescriptionSha256),savedMissingDescriptionsMatch:b.savedDescriptions.every(s=>s===(['missing-comarch-member','missing-comarch-member-mark'].includes(DEMO_SCENARIO)?COMARCH_NOT_FOUND_DESCRIPTION:NOT_FOUND_DESCRIPTION)),fixedCommitSteps:b.fixedCommitSteps||[],fixedOptionClicks:b.fixedOptionClicks||{},selectedSubcategoryLabels:b.selectedSubcategoryLabels||[],savedStandardMarkers:b.savedDescriptions.filter(x=>x.split(/\r?\n/).includes(STANDARD_ANSWER_NOTE)).length};
   if(DEMO_SCENARIO==='rc64-signature-ajax-reset-once'&&MAX===1){
    need(diag.loop.processed===1&&b.sendClicks===1&&b.saveClicks===1&&b.trustedSends.every(Boolean)&&
      b.trustedSaves.every(Boolean)&&b.signatureAjaxResetCount===1&&
      (b.fixedOptionClicks?.['mainForm:signature-value-id']||0)===2&&
      diag.demoBrowser.savedStandardMarkers===1,'RC64_SIGNATURE_RESELECT_E2E',
      'Einmaliger COMARCH-Signaturreset nicht genau einmal sicher repariert; kein Doppelversand.');
   }
   else if(DEMO_SCENARIO==='rc64-signature-ajax-foreign'&&MAX===1){
    need(false,'RC64_SIGNATURE_FOREIGN_MUST_FAIL','Fremde Signatur darf nicht als normaler Erfolg durchgehen.');
   }
   else if(DEMO_SCENARIO==='rc38-postsend-rerender'&&MAX===1){
    need(diag.loop.processed===1&&b.sendClicks===1&&b.saveClicks===1&&b.savedDescriptions.length===1&&
      sha256(b.savedDescriptions[0])===diag.demoExpectedDescriptionSha256&&diag.send.verified&&diag.save.verified,
      'RC38_DEMO_RESET','Browser-Neubindung nach einem Sendeklick nicht nachgewiesen.');
   }
   else if(DEMO_SCENARIO==='rc62-presend-blank'&&MAX===1){
    need(diag.loop.processed===1&&b.sendClicks===1&&b.saveClicks===1&&diag.preSendDescriptionRestored===true&&
      diag.send.verified===true&&diag.save.verified===true&&b.savedDescriptions.length===1&&
      sha256(b.savedDescriptions[0])===diag.demoExpectedDescriptionSha256&&
      b.trustedSends.every(Boolean)&&b.trustedSaves.every(Boolean),
      'RC62_DEMO_PRESEND_REPAIR','Verlorene USC-Beschreibung nicht nachweislich vor Einzelversand repariert.');
   }
   else if(DEMO_SCENARIO==='rc75-label-fallback'){
    const n=MAX===1?1:2;
    need(diag.loop.processed===n&&b.sendClicks===n&&b.saveClicks===n&&
     diag.manualNameConfirmations===0&&
     diag.loop.processedTickets?.every(t=>t.nameSource===NAME_LABEL_SOURCE)&&
     diag.send.verified===true&&diag.save.verified===true&&
     b.trustedSends.every(Boolean)&&b.trustedSaves.every(Boolean),
     'RC75_DEMO_LABEL_FALLBACK','Labelsuchhinweis/Member-Nachweis oder einzelner Versand/Speicherung nicht belegt.');
   }
   else if(['rc29-incorrect-sender','rc30-swapped-member'].includes(DEMO_SCENARIO)&&MAX===1){
    need(diag.loop.processed===1&&b.sendClicks===1&&b.saveClicks===1&&
      diag.loop.processedTickets?.[0]?.memberOperatorReview===true&&
      diag.send.verified===true&&diag.save.verified===true&&b.trustedSends.every(Boolean)&&b.trustedSaves.every(Boolean),
      'RC29_DEMO_WRONG_SENDER','Fiktiver falscher Absendername nicht kontrolliert korrigiert/gesendet/gespeichert.');
   }
   else if(['send-one-dialog','send-no-dialog','rc26-remapped-subject','rc26-refresh-history','rc27-two-success-notices'].includes(DEMO_SCENARIO)){
    need(MAX===1&&diag.loop.processed===1&&b.sendClicks===1&&b.saveClicks===1&&
     diag.send.verified===true&&diag.send.ackMode==='BOUND_NEW_OUTGOING_HISTORY'&&
     diag.send.boundHistoryVerified===true&&
     b.okClicks===(DEMO_SCENARIO==='send-no-dialog'?0:DEMO_SCENARIO==='rc27-two-success-notices'?2:1)&&
     b.trustedSends.every(Boolean)&&b.trustedSaves.every(Boolean),
     'DEMO_SINGLE_ACK_NOT_VERIFIED','Ein- oder Null-Dialog-Sende-/Speicherprobe nicht vollstaendig.');
   }
   else if(['rc33-post-no-mail','rc33-post-wrong-recipient'].includes(DEMO_SCENARIO))need(
    diag.loop.processed===0&&diag.loop.skippedWithoutEmail===2&&b.sendClicks===0&&b.saveClicks===0&&b.forwardClicks===0,
    'RC33_SOURCE_WITHOUT_EMAIL_NOT_SAFE','Quelle nicht E-MAIL ohne Originalabsender darf keinen Versand oder Speichervorgang erzeugen.');
   else if(['rc18-existing-ack','rc28-status-only-existing'].includes(DEMO_SCENARIO))need(diag.loop.processed===0&&diag.loop.skippedAlreadyAnswered===2&&b.sendClicks===0&&b.saveClicks===2&&diag.loop.annotatedAlreadyAnswered===2&&diag.demoBrowser.savedStandardMarkers===2&&b.savedDescriptions.every(x=>sourceUSCLines(x).length===2),'DEMO_SKIP_NOT_VERIFIED','Beantwortete Tickets nicht sicher uebersprungen.');
   else if(['rc19-first-answered','rc19-last-answered'].includes(DEMO_SCENARIO))need(diag.loop.processed===1&&diag.loop.skippedAlreadyAnswered===1&&b.sendClicks===1&&b.saveClicks===2&&diag.loop.annotatedAlreadyAnswered===1&&diag.demoBrowser.savedStandardMarkers===2&&b.savedDescriptions.every(x=>sourceUSCLines(x).length===2)&&b.trustedSends.every(Boolean)&&b.trustedSaves.every(Boolean),'DEMO_SKIP_NEXT_NOT_VERIFIED','Nach dem uebersprungenen Ticket wurde das naechste nicht einmalig abgeschlossen.');
   else if(['missing-member','missing-member-mark','missing-fixed-once','missing-signature-ephemeral','missing-comarch-member','missing-comarch-member-mark'].includes(DEMO_SCENARIO))need(diag.loop.processed===2&&diag.loop.forwarded===2&&b.sendClicks===0&&b.saveClicks===(DEMO_SCENARIO==='missing-fixed-once'?4:2)&&b.forwardClicks===2&&b.trustedForwards.every(Boolean)&&b.forwardRecipients.every(v=>(['missing-member-mark','missing-comarch-member-mark'].includes(DEMO_SCENARIO)?v==='mark.baindl':v==='Victor.Gutierrez'))&&diag.demoBrowser.savedMissingDescriptionsMatch,'DEMO_FORWARD_NOT_VERIFIED','Fiktive Weiterleitung ohne E-Mail nicht nachgewiesen.');
   else need(diag.loop.processed===2&&b.sendClicks===2&&b.saveClicks===2&&b.savedLineCounts.length===2&&b.savedLineCounts.every(n=>n===3)&&b.trustedSends.every(Boolean)&&b.trustedSaves.every(Boolean)&&diag.demoBrowser.savedDescriptionsMatch,'DEMO_NOT_VERIFIED','Zwei fiktive Tickets mit echten Browserklicks nicht nachgewiesen.');}
 if(!DEMO){diag.deliveryMode=overlay.gate.mode;overlay.finish(completionDisplay({completed:diag.loop.completed,error:diag.lastError,pending:ledger(root).pending.length,skipped:(diag.loop.skippedWithoutEmail||0),finishReason:diag.loop.finishReason,processed:diag.loop.processed,pilot:PILOT}));}
 log('\nRUN COMPLETE | Bearbeitet: '+diag.loop.processed+' | '+diag.loop.finishReason);if(DEMO)log((MAX===1&&DEMO_SCENARIO==='rc64-signature-ajax-reset-once')?'PASS RC64_SIGNATURE_AJAX_RESET_ONE_SEND_ONE_SAVE':(MAX===1&&DEMO_SCENARIO==='rc38-postsend-rerender')?'PASS RC38_DEMO_REBIND_SINGLE_SEND_SINGLE_SAVE':(MAX===1&&DEMO_SCENARIO==='rc30-swapped-member')?'PASS RC30_DEMO_SWAPPED_MEMBER_OPERATOR_REVIEW_AND_SAVE':(DEMO_SCENARIO==='rc75-label-fallback')?'PASS RC75_NAME_LABEL_FALLBACK_SEND_SAVE_VERIFIED':(MAX===1&&DEMO_SCENARIO==='rc29-incorrect-sender')?'PASS RC29_DEMO_WRONG_SENDER_OPERATOR_REVIEW_AND_SAVE':(MAX===1&&['send-one-dialog','send-no-dialog','rc26-remapped-subject','rc26-refresh-history','rc27-two-success-notices'].includes(DEMO_SCENARIO))?'PASS OFFLINE_DEMO_SINGLE_SEND_SAVE_VERIFIED':(MAX===1&&DEMO_SCENARIO==='rc62-presend-blank')?'PASS RC62_PRESEND_DESCRIPTION_REPAIRED_ONE_SEND_ONE_SAVE':['missing-member','missing-member-mark','missing-fixed-once','missing-signature-ephemeral','missing-comarch-member','missing-comarch-member-mark'].includes(DEMO_SCENARIO)?'PASS OFFLINE_DEMO_2_FORWARDINGS_NO_EMAIL':['rc18-existing-ack','rc28-status-only-existing'].includes(DEMO_SCENARIO)?'PASS OFFLINE_DEMO_ALREADY_ANSWERED_NOTE_SAVED':['rc19-first-answered','rc19-last-answered'].includes(DEMO_SCENARIO)?'PASS OFFLINE_DEMO_SKIP_ONE_THEN_SEND_ONE':'PASS OFFLINE_DEMO_2_TICKETS_VERIFIED');
 }catch(e){if(e?.openTicketState)diag.ticketOpen=e.openTicketState;if(diag.send?.clicked&&!diag.save?.verified)log('ACHTUNG NACH VERSANDVERSUCH: Speichern/Status nicht bestaetigt. Ticket im COMARCH-Verlauf pruefen; KEIN neuer Versand. Aktueller Status ist UNGEKLAERT.');diag.lastError=/^[A-Z0-9_]{1,80}$/.test(e.code||'')?e.code:'RUNNER_ERROR';show({event:'error',phase:diag.lastError,answered:'STOP · pruefen'});console.error('\nSTOP '+diag.lastError+' [PHASE '+diag.phase+']: '+e.message);process.exitCode=1;}finally{
 if(cfg)try{await diagnostic(cfg);}catch(e){console.error('STOP DIAGNOSTIC_WRITE_FAILED');process.exitCode=1;}
 let leaveOpen=false;
 if(!DEMO&&diag.lastError&&args.has('--inspect-browser')&&browser?.child&&rl){
  try{
   log('BROWSER-KONTROLLE: Der Bot-Edge bleibt jetzt zur Nachpruefung offen. Alle Ticketlogs wurden lokal geschrieben.');
   if(PILOT){
    log('Nach dem Piloten muss dieses Browserprofil fuer die sichere neue Fortsetzung geschlossen werden.');
    await ask(rl,'Browser geprueft? ENTER schliesst ihn und erlaubt die Fortsetzung: ');
   }else{
    const answer=(await ask(rl,'ENTER = Bot-Edge schliessen / OFFEN = Browser offen lassen und Hauptmenue aufrufen: ')).toUpperCase();
    leaveOpen=answer==='OFFEN';
    if(leaveOpen)log('PASS BOT_EDGE_REMAINS_OPEN: Vor dem naechsten Lauf dieses Bot-Edge-Profil manuell schliessen.');
   }
  }catch{leaveOpen=false;}
 }
 try{rl?.close();}catch{}overlay.close();
 if(DEMO){
  // RC40: close the CDP-owned test browser BEFORE releasing the child handle.
  // Otherwise a finished demo can stay alive until spawnSync's test timeout.
  try{
   const ended=await shutdownFictionalBrowser({cdp,browser});
   if(ended.mode==='OWNED_DEMO_TREE_EXIT')log('PASS RC41_OWNED_TEST_BROWSER_TREE_CLOSED');
   if(!ended.closed){console.error('STOP DEMO_BROWSER_NOT_STOPPED: Test-Browser nicht sauber beendet.');process.exitCode=1;}
  }catch(e){console.error('STOP DEMO_BROWSER_CLEANUP: '+(e.code||'ERROR'));process.exitCode=1;}
 }else{
  try{cdp?.close();}catch{}
  if(leaveOpen){try{browser?.child?.unref();}catch{}}
  else if(args.has('--close-browser')||args.has('--inspect-browser'))try{browser?.child?.kill();}catch{}
  else try{browser?.child?.unref();}catch{}
 }
}
}
await main();
