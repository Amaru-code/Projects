# MCR DATENBRUECKE 0.8.1-rc.81

Kompaktes Vollpaket auf Basis des geprueften RC79, mit dem bestehenden Installer, Software-Rueckweg und unveraenderter Phase-1-Fachbearbeitung.

## Phase 2

Die gespeicherte zusaetzliche Beschreibung bestimmt den Arbeitsweg: Phase-1-Status erforderlich; Bearbeitet/Reviewed verhindert Doppelbearbeitung; DB/DB+ direkt an Mark; Kontoauszug fuer DC/PP+ zum Review; privater MBC-Login mit bestehendem Antwortentwurf zum Review; unbekannte `Moechte ...`-Anfragen direkt an Mark.

Bei DB/DB+ und unbekannten Anfragen wird der Bearbeitungsvermerk NICHT gesetzt. Nur bei fachlich vorbereiteten Kontoauszug- oder MBC-Faellen wird `Bearbeitet not reviewed` notiert. Bereits begonnene RC76-Direktfaelle koennen kontrolliert den irrtuemlichen alten Vermerk entfernen.

Alte SEND-Journale bleiben unveraendert erhalten, werden aber nicht mehr als alleinige Sperre fuer interne Phase-2-Arbeit benutzt. Keine neue E-Mail. Offene Weiterleitungen und unklare Phase-2-Schreibaktionen bleiben gegen Wiederholung geschuetzt.

Menue 12 integriert die Pruefung vorhandener Kontoauszug-PDFs. Fehlende PDFs muessen weiterhin mit den vorhandenen Generatorprogrammen erstellt werden; RC77 erfindet keine Eingabeschnittstelle. Der Bot zeigt Pfade und erwartete Dateien und setzt nach der Inhaltspruefung mit dem vorhandenen Anhaenge-/Review-Ablauf fort.

Details zu den in RC79 reduzierten Bestaetigungen und dem abgesicherten Speicherpfad: `docs/RC79_RELEASE.md`.

Neue Erkennung des dokumentierten Kontoauszug-Tippfehlers und kontrollierte Bearbeiten-Schaltflächenprüfung: `docs/RC78_RELEASE.md`. Marker-Regeln und Altfälle: `docs/RC77_RELEASE.md`. Historische Regeln: `docs/RC76_RELEASE.md`.

Installation: ZIP separat entpacken, neue START.cmd -> Menue 1; anschliessend nur START.cmd aus dem installierten Ordner. Danach Menue 14 (nur lesen) oder Menue 12 (echte Phase-2-Bearbeitung). private_data, Konfiguration, Browserprofil, Laufjournale und Archive bleiben lokal erhalten.

Die in RC75 ergaenzte Namenssuche und Identitaetsbestaetigung bleiben bestehen. Aeltere Release-Dokumente beschreiben die Historie, nicht die aktuelle Phase-2-Zulassungsregel.

RC80: Ticket 87917040 kann nach bestaetigten gespeicherten DC-/PP+-Anlagen und GEVO unter einer EINMALIGEN protokollierten Freigabe ausschliesslich die fehlende vierte Zeile nachtragen. Keine doppelte PDF- oder Entwurfserstellung, keine Mail. Original-Journal bleibt erhalten. Siehe docs/RC80_RELEASE.md.

## RC81 – Kontoauszug-Entwurf

Neuer personenbezogener Kontoauszug-Antwortentwurf mit einmaligem Entwurf-Speichern/OK-Dialog und gezielter ICEfaces-Statuswiederherstellung. Für den vor dem Ticket-Speicherklick gestoppten Fall 87393963 ein separater, journalkontrollierter Wiederaufnahmeweg. Details: docs/RC81_RELEASE.md. Kein E-Mail-Versand.

RC82: Bei einer COMARCH-Teilaktualisierung des Mark-Suchfeldes wird der naechste Bearbeiter erst nach eindeutigem Vorschlag oder expliziter manueller Auswahl und anschliessender COMARCH-Feldpruefung akzeptiert. Details: docs/RC82_RELEASE.md.


## RC83 Master Run
Menue 13 verbindet verifizierte Weiterleitungen ohne E-Mail mit weiteren Einzelpiloten. Erst ein nachgewiesener echter E-Mail-Versand UND Speicherung erlaubt den grossen Versandbatch. COMARCH-Dialoge, PDF-Freigaben, Journal- und Identitaetspruefungen bleiben aktiv. Einzelheiten: docs/RC83_RELEASE.md.

## RC84 – Sicherer Ticketklick in Phase 1

Einheitliche Sichtprüfung von sortierten Ticket-ID-Spalten bei Liste und Klick, drei reine Lesekontrollen vor dem Klick. Wenn der sichere Klickpunkt verdeckt oder uneindeutig ist, kann der Operator ausschließlich das bereits in In_Bearbeitung/INTL01 gebundene Ticket manuell öffnen. Danach ist die Ticket-ID-Prüfung weiterhin obligatorisch. Keine Änderungen an Mailversand, Memberprüfung, Mapping, PDF- oder Phase-2-Arbeitsregeln.
