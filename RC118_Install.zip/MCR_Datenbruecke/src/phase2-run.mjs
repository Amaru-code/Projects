/** RC52 supervised sequential Phase-2 run. One browser, one action per ticket.
 * Refreshes the actual task list before each item. Unrecognized/unprepared
 * work is skipped, not guessed. Any uncertain write stops the entire run. */
import fs from 'node:fs';import path from 'node:path';import readline from 'node:readline/promises';
import {requireThat as need,sha256} from '../lib/core.mjs';import {applyEnterApproval} from '../lib/operator-enter.mjs';
import {writeJSON,readJSON,plainPath,ledger,stamp,VERSION} from '../lib/control.mjs';
import {assertLiveWorkbookCurrent,refreshLiveWorkbook,inspectWorkbookQueueBoundary} from '../lib/live-workbook.mjs';
import {loadActiveMapping} from '../lib/active-mapping.mjs';import {resolveConfig} from '../lib/config.mjs';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachOwnedPage,createOwnedStartupTarget,detachOwnedPage,assertOwnedPageTarget} from '../lib/cdp.mjs';
import {mayRebindPhase2BeforeTicket} from '../lib/phase2-cdp-recovery.mjs';
import {browserLeaseEnvironment,validateBrowserLease} from '../lib/master-browser-lease.mjs';
import * as UI from '../lib/browser-workflow.mjs';
import {readPhase2Queue,phase2Inventory} from '../lib/phase2-readonly.mjs';
import {phase2WorkRule} from '../lib/phase2-work-rules.mjs';
import {phase2DisplayKind,documentDeferEvent} from '../lib/phase2-document-kind.mjs';
import {phase2Admission,phase2BlockingIds} from '../lib/phase2-admission.mjs';
import {phase2IntakeSummary} from '../lib/phase2-handoff.mjs';
import {openPhase2Ticket} from '../lib/phase2-navigation.mjs';
import {readPhase2MemberEvidence} from '../lib/phase2-member-evidence.mjs';
import {phase2ComarchPilot,preflightPhase2Write} from './phase2-comarch-pilot.mjs';
import {createPhase2TicketConsole} from '../lib/phase2-ticket-console.mjs';
import {capturePhase2RouteList} from '../lib/phase2-route-receipt.mjs';
import {preparePhase2PdfEvidence} from './phase2-pdf-prepare.mjs';
import {askAoContactLine} from '../lib/ao-contact-terminal.mjs';
import {isAoSharedWriteBlock,aoWriteBlockScope} from '../lib/phase2-ao-write-block.mjs';
import {rebindWorkbookAfterGeneratedAo} from '../lib/phase2-post-generator-workbook.mjs';
import {handlePhase2Work} from './phase2-work-handler.mjs';
import {inspectPhase2Tickets} from '../lib/phase2-intake-audit.mjs';
import {assessPhase2WorkResume} from '../lib/phase2-work-resume.mjs';import {mayDeferPhase2Readback,mayDeferPhase2PreWrite,mayDeferPhase2WorkRuleConflict,mayDeferPhase2DraftBeforeClick} from '../lib/phase2-safe-defer.mjs';import {phase2Completion,completionLines} from '../lib/master-completion.mjs';import {describeTicketIssue,dedupeTicketIssues,errorCsv,groupTicketIssues} from '../lib/ticket-error-catalog.mjs';import {approveUnclassifiedRequest} from '../lib/phase2-request-approval.mjs';

export function choosePhase2Candidate(rows,{visited=new Set(),blockedIds=[],pending=[],getPdfJournal=()=>null,getWorkJournal=()=>null,accountReady=()=>true,prepareMissingPdf=false,aoWriteBlock=null}={}){
 const blocked=new Set([...blockedIds.map(String),...phase2BlockingIds(rows,pending)]),skipped=[];
 for(const row of rows){
  const id=row.ticketId;if(visited.has(id))continue;
  if(row.intelGroupVerified===false){skipped.push({ticketId:id,reason:'OUTSIDE_INTEL_GROUP'});continue;}
  if(blocked.has(id)){skipped.push({ticketId:id,reason:'UNRESOLVED_PHASE1_JOURNAL'});continue;}
  const pdf=getPdfJournal(id),work=getWorkJournal(id);
  if(pdf&&work){skipped.push({ticketId:id,reason:'CONFLICTING_PHASE2_JOURNALS'});continue;}
  if(pdf?.state==='ROUTED_VERIFIED'||work?.state==='ROUTED_VERIFIED')continue;
  if(pdf){
   if(accountReady(id))return {row,kind:'ACCOUNT_STATEMENT',skipped};
   skipped.push({ticketId:id,reason:'PDF_JOURNAL_NOT_RESUMABLE'});continue;
  }
  if(work){
   const resume=assessPhase2WorkResume(row,work);
   if(resume.allowed)return {row,kind:resume.kind,skipped};
   skipped.push({ticketId:id,reason:resume.reason});continue;
  }
  const rule=phase2WorkRule(row);
  if(['DB_DIRECT','MARK_DIRECT','MBC_PRIVATE_EMAIL'].includes(rule.kind))return {row,kind:rule.kind,skipped};
  if(rule.kind==='ACCOUNT_STATEMENT'){
   if(prepareMissingPdf&&rule.targets?.includes('AO')){
    if(aoWriteBlock?.scope==='ALL_NEW_AO'){skipped.push({ticketId:id,reason:'AO_QUEUE_PAUSED_MASTER_WRITE',rule:phase2DisplayKind(rule),technicalDetails:{blockedBy:aoWriteBlock.reason,triggerTicketId:aoWriteBlock.ticketId}});continue;}
    return {row,kind:rule.kind,pdfPreparationRequired:true,contactWriteAllowed:!aoWriteBlock,skipped};
   }
   if(accountReady(id))return {row,kind:rule.kind,skipped};
   if(prepareMissingPdf)return {row,kind:rule.kind,pdfPreparationRequired:true,skipped};
   skipped.push({ticketId:id,reason:'PDF_PROOF_REQUIRED_OR_STALE'});
  }else skipped.push({ticketId:id,reason:rule.reason||rule.kind});
 }
 return {row:null,kind:null,skipped};
}

export async function phase2Run({root,askFn=null,log=console.log,maxTickets=100,session=null,memberLookup=readPhase2MemberEvidence,consoleFactory=createPhase2TicketConsole,masterApproved=false}={}){
 need(Number.isInteger(maxTickets)&&maxTickets>=1&&maxTickets<=100,'P2_RUN_LIMIT','Maximal 100 Tickets pro Lauf.');
 let active=loadActiveMapping(root);
 const ownsRl=!session?.rl,rl=session?.rl||readline.createInterface({input:process.stdin,output:process.stdout});
 const dir=path.join(root,'.runtime','phase2');fs.mkdirSync(dir,{recursive:true});plainPath(dir);
 const runId=stamp(),logFile=path.join(dir,'MCR_PHASE2_LAUF_'+runId+'.log');
 fs.writeFileSync(logFile,'MCR '+VERSION+' PHASE2\n',{flag:'wx',mode:0o600});
 let controls=null,currentTicket=null,restoreInput=null,contactInputMode=false,aoWriteBlock=null;
 const say=s=>{if(!contactInputMode){if(currentTicket&&controls)controls.update({phase:String(s).slice(0,220)});log(s);}fs.appendFileSync(logFile,String(s)+'\n',{mode:0o600});};
 const ask=async q=>{const raw=String(await (askFn?askFn(rl,q):rl.question(q))).trim();const a=applyEnterApproval(q,raw);fs.appendFileSync(logFile,q+(raw?raw:(a?'[ENTER -> '+a+']':'[ENTER]'))+'\n',{mode:0o600});return a;};
 const askContact=async(q,signal)=>{
  contactInputMode=true;
  try{
   controls?.update?.({phase:'Eingabe im aktuellen MCR-Terminal erforderlich; Generator wartet.'});
   const raw=await askAoContactLine(rl,q,{signal,askFn,gate:controls?.gate});
   fs.appendFileSync(logFile,'P2_AO_CONTACT_OPERATOR_INPUT: [Wert nicht protokolliert]\n',{mode:0o600});
   return raw;
  }finally{contactInputMode=false;}
 };
 let browser,cdp,sharedPage=null,ownedTargetId=null,preTicketRebound=false;const visited=new Set(),receipts=[],skipRecords=new Map(),handoffReceipts=[],mappingRebindings=[];
 try{
  say('PHASE 2: Kontoauszuege, Auszahlungsoptionen, DB/DB+ und unbekannte Anfragen an Mark, privater MBC-Login als Entwurf zur Pruefung. KEINE E-MAIL.');
  const first=masterApproved?'':await ask('Start-Ticket (z.B. 87278094), ENTER = alle passenden sichtbaren eigenen Vorgaenge: ');
  need(first===''||/^\d{6,12}$/.test(first),'P2_TICKET_ID','Ticketnummer oder ENTER erforderlich.');
  let page=session?.page;
  if(!page){
   const cfg=resolveConfig(root),exe=findEdgeExecutable(cfg.edgePath);need(exe,'P2_EDGE','Edge fehlt.');
   let targetId;
   if(session?.port){
    need(Number.isInteger(session.port)&&session.port>0&&session.port<=65535&&
     typeof session.masterId==='string'&&/^[0-9TZ._a-zA-Z-]{12,160}$/.test(session.masterId),
     'P2_MASTER_BROWSER_LEASE','Master-Browserfreigabe ungueltig.');
    need(masterApproved,'P2_MASTER_BROWSER_LEASE','Wiederverwendung benoetigt den eigenen Masterlauf.');
    const report=readJSON(path.join(root,'.runtime/master','MCR_MASTER_RUN_'+session.masterId+'.json'),65536);
    const lease=validateBrowserLease(browserLeaseEnvironment(session),{parentPid:process.pid,report,
     manifestSha:sha256(fs.readFileSync(path.join(root,'MANIFEST.json'))),mappingSha:active.fileHash,phase:'PHASE2'});
    targetId=lease.targetId;
    ({cdp}=await connectBrowser(session.port));
   }else{
    browser=await launchBrowser({executable:exe,userDataDir:cfg.profileDirectory,extraArgs:['--no-startup-window']});
    ({cdp}=await connectBrowser(browser.port));
    targetId=await createOwnedStartupTarget(cdp);
    say('PASS BROWSER_OWNED_TAB_CREATED: Eigenes Bot-Fenster erstellt, aktiviert und eindeutig gebunden.');
   }
   ownedTargetId=targetId;
   page=await attachOwnedPage(cdp,cfg.comarchUrl,{targetId});if(session?.port){sharedPage=page;
    say('PASS P2_MASTER_BROWSER_WIEDERVERWENDET: Gleicher Edge-Prozess und derselbe Bot-Tab; COMARCH-Ansicht frisch geladen.');}
  }
  say('Nach jedem verifizierten Abschluss folgt der naechste passende Fall. AO mit zentralem Generator und vermittelten Kontakteingaben neu erstellen; DC/PP+ nur mit eindeutig vorhandener PDF bis Generatorvertrag bestaetigt.');
  if(masterApproved)say('PASS MASTER_PHASE2_START_AUTORISIERT: MASTER_START erteilt; PDF-/Identitaetspruefungen und notwendige Fachfreigaben bleiben aktiv.');
  else need((await ask('In COMARCH angemeldet; diese Phase-2-Bearbeitung und Weiterleitung starten? ENTER = starten. START / ABBRUCH: ')).toUpperCase()==='START','P2_OPERATOR_ABORT','Kein Phase-2-Lauf.');
  controls=consoleFactory({log:say});await controls.ready();restoreInput=controls.protectInput(page.cdp);
  say('P2_BEDIENUNG: MANUELL = ein Knopf vor dem Abschluss; AUTO = nach einmaligem Umschalten selbststaendig. Unklare Nachweise werden nie als Erfolg angenommen.');
  say('LOKALER_LAUFBERICHT: '+logFile);
  const getJournal=(prefix,id)=>{const p=path.join(dir,'actions',prefix+id+'.json');return fs.existsSync(p)?readJSON(p,128*1024):null;};
  while(visited.size<maxTickets){
   let q;
   try{
    await UI.navigateToScope(page,'IN_BEARBEITUNG',{refresh:visited.size>0,startup:visited.size===0});
    q=await readPhase2Queue(page);
   }catch(e){
    if(!mayRebindPhase2BeforeTicket({error:e,sharedMaster:!!session?.port,currentTicket,
     visitedCount:visited.size,alreadyRebound:preTicketRebound}))throw e;
    // No ticket selected or business action started in Phase 2. The previous
    // CDP child session is stale; reconnect to the SAME master-owned target.
    // Never create a new tab and never retry a ticket write here.
    preTicketRebound=true;
    say('P2_CDP_SESSION_LOST_BEFORE_TICKET: Verbindung zur eigenen Seite wird einmal neu gebunden; kein Ticketklick/Upload/Weiterleiten wiederholt.');
    restoreInput?.();restoreInput=null;
    try{cdp?.close();}catch{}
    ({cdp}=await connectBrowser(session.port));
    await assertOwnedPageTarget(cdp,ownedTargetId);
    const cfg=resolveConfig(root);
    page=await attachOwnedPage(cdp,cfg.comarchUrl,{targetId:ownedTargetId});
    sharedPage=page;
    restoreInput=controls.protectInput(page.cdp);
    say('PASS P2_CDP_SESSION_REBOUND_SAME_TARGET: Eigener Master-Tab erneut gebunden, keine Ticketaktion wiederholt.');
    await UI.navigateToScope(page,'IN_BEARBEITUNG',{refresh:true,startup:true});
    q=await readPhase2Queue(page);
   }
   need(q.ok,'P2_RUN_QUEUE',q.reason||'Vorgangsliste nicht lesbar.');
   const workbookBoundary=inspectWorkbookQueueBoundary(root,active,{queueExhausted:q.rows.length===0});
   if(workbookBoundary.status==='REFRESH_REQUIRED'){
    need(currentTicket===null&&mappingRebindings.length<3,'WORKBOOK_REBIND_LIMIT',
     'Bestand aendert sich fortlaufend oder ein Ticket ist noch aktiv; keine neue Ticketaktion.');
    const before=active.fileHash;active=refreshLiveWorkbook(root,{log:say});
    mappingRebindings.push({at:new Date().toISOString(),before,after:active.fileHash,completed:receipts.length,nextTicketOpened:false});
    say('PASS P2_BESTAND_ZWISCHEN_TICKETS_AKTUALISIERT: Neuer Bestand vor dem naechsten Ticket gebunden.');
   }
   // Fresh inventory is now automatic, not another manual Menu 9 round-trip.
   const inventory=phase2Inventory(q.rows,{pendingIds:phase2BlockingIds(q.rows,ledger(root).pending)});
   writeJSON(path.join(dir,'MCR_PHASE2_LETZTE_INVENTUR.json'),inventory);
   writeJSON(path.join(dir,'MCR_PHASE2_WORK_LETZTE_INVENTUR.json'),{schema:'MCR_PHASE2_WORK_INVENTORY_V1',readOnly:true,generatedAt:new Date().toISOString(),items:q.rows.map(r=>phase2WorkRule(r))});
   const counts={};for(const r of q.rows){const k=phase2DisplayKind(phase2WorkRule(r));counts[k]=(counts[k]||0)+1;}
   say('P2_FALLERKENNUNG: MBC_PRIVATE_EMAIL='+String(counts.MBC_PRIVATE_EMAIL||0)+' | DB_DIRECT='+String(counts.DB_DIRECT||0)+' | ACCOUNT_STATEMENT='+String(counts.ACCOUNT_STATEMENT||0)+' | AUSZAHLUNGSOPTION='+String(counts.AUSZAHLUNGSOPTION||0)+' | KONTOAUSZUG_UND_AUSZAHLUNGSOPTION='+String(counts.KONTOAUSZUG_UND_AUSZAHLUNGSOPTION||0)+' | MARK_DIRECT='+String(counts.MARK_DIRECT||0)+' | PHASE1_REQUIRED='+String(counts.PHASE1_REQUIRED||0));
   const wanted=first&&visited.size===0?q.rows.filter(r=>r.ticketId===first):q.rows;
   if(first&&visited.size===0)need(wanted.length===1,'P2_START_NOT_IN_QUEUE','Startticket nicht genau einmal in aktueller eigener Liste.');
   const currentLedger=ledger(root);
   const audit=inspectPhase2Tickets(wanted,{pending:currentLedger.pending,visited,
    getPdfJournal:id=>getJournal('MCR_PHASE2_',id),getWorkJournal:id=>getJournal('MCR_PHASE2_WORK_',id)});
   const auditReport={...audit,runId,generatedAt:new Date().toISOString(),version:VERSION,
    pageCoverage:'VISIBLE_ROWS_ONLY_NO_PAGINATION_ASSUMPTION'};
   writeJSON(path.join(dir,'MCR_PHASE2_TICKETBESTAND_LETZTE.json'),auditReport);
   const c=audit.counts;
   say('P2_BESTAND: eigene_zeilen='+c.visible+' | bereit='+c.ready+' | wiederaufnahme='+c.resume+
    ' | altversand_lesepruefung='+c.phase1EvidenceToCheck+' | altjournal_gesperrt='+c.phase1Blocked+
    ' | weitere_pruefung='+c.reviewBlocked+' | nicht_unterstuetzt='+c.unsupported+' | phase1_noetig='+c.phase1Required+' | alte_versandjournale_unveraendert='+c.retainedPhase1Journals);
   for(const entry of audit.items)if(entry.stage==='PHASE1_BLOCKED'||entry.stage==='BLOCKED'||entry.stage==='UNSUPPORTED'||entry.stage==='PHASE1_REQUIRED')
    skipRecords.set(entry.ticketId,{ticketId:entry.ticketId,reason:entry.reason,rule:entry.rule,
     ...(entry.phase1Structure?{phase1Structure:entry.phase1Structure}:{})});
   const intake=phase2IntakeSummary(wanted,{pending:currentLedger.pending,getPdfJournal:id=>getJournal('MCR_PHASE2_',id),getWorkJournal:id=>getJournal('MCR_PHASE2_WORK_',id)});
   say('P2_ZULASSUNG: sichtbar='+intake.stats.visible+' | Regel_ohne_Journalblock='+intake.stats.readyWithoutBlock+' | Phase1_Journal_offen='+intake.stats.blockedPhase1+' | Altfall_mit_passender_Struktur='+intake.stats.oldJournalCandidates+' | ohne_unterstuetzte_Regel='+intake.stats.unclassified+' | unklarer_Status='+intake.stats.missingStatusOrPlan+' | fremde_Gruppe='+intake.stats.outsideIntelGroup+' | Phase1_noetig='+intake.stats.phase1Required);
   // RC76: stored server description determines routing. Historical SEND
   // journals remain immutable and pending; Phase 2 never re-sends or claims
   // to have proved the old delivery. A previous FORWARD intent still blocks.
   const pick=choosePhase2Candidate(wanted,{visited,pending:ledger(root).pending,
    getPdfJournal:id=>getJournal('MCR_PHASE2_',id),getWorkJournal:id=>getJournal('MCR_PHASE2_WORK_',id),prepareMissingPdf:true,aoWriteBlock,
    accountReady:id=>{try{preflightPhase2Write(root,id);return true;}catch(e){skipRecords.set(id,{ticketId:id,reason:e.code||'PDF_PREFLIGHT'});return false;}}});
   for(const skip of pick.skipped)if(!skipRecords.has(skip.ticketId))skipRecords.set(skip.ticketId,skip);
   if(!pick.row){
    for(const x of skipRecords.values())if(!visited.has(x.ticketId))say('P2_UEBERSPRUNGEN: '+x.ticketId+' | '+x.reason);
    say('P2_BESTANDSDIAGNOSE: '+path.join(dir,'MCR_PHASE2_TICKETBESTAND_LETZTE.json')+' | Nur sichtbare eigene Intel-Tickets, andere INTL01-Vorgaenge nicht automatisch weiterleiten.');
    if(first&&visited.size===0)need(false,'P2_START_NOT_READY','Startticket nicht fortsetzbar. Siehe P2_UEBERSPRUNGEN; kein Schreibversuch.');
    say('P2_LAUF_ENDE: Kein weiterer automatisch bearbeitbarer Fall in der aktuell sichtbaren eigenen Vorgangsliste.');break;
   }
   const admission=phase2Admission(pick.row,ledger(root).pending);
   const displayKind=pick.kind==='ACCOUNT_STATEMENT'?phase2DisplayKind(admission.rule):pick.kind;
   const id=pick.row.ticketId;visited.add(id);currentTicket=id;controls.start({ticketId:id,kind:displayKind,description:pick.row.descriptionValue});say('P2_NAECHSTES_TICKET: '+id+' | '+displayKind);
   for(const warning of [...(admission.rule.warnings||[]),...(admission.warning?[admission.warning]:[])])say('P2_ZUORDNUNG_HINWEIS: '+id+' | '+warning);
   // RC91: the third line is not a recognised 'Moechte' expression. The
   // operator may classify it as a customer request, but no automatic send or
   // unreviewed routing is allowed. A declined ticket is reported and skipped.
   if(admission.rule.requiresRequestConfirmation===true){
    say('P2_ANFRAGE_MANUELL_KLASSIFIZIEREN: '+id+' | Zeile 3 ohne bekannte Anfrageformel; keine Aktion bislang.');
    const answer=await approveUnclassifiedRequest({ticketId:id,ask,log:say});
    if(answer==='SKIP'){
     const skip={ticketId:id,reason:'REQUEST_REVIEW_NOT_CONFIRMED',rule:pick.kind};skipRecords.set(id,skip);
     say('P2_ANFRAGE_ZURUECKGESTELLT: '+id+' | REQUEST_REVIEW_NOT_CONFIRMED | keine Aenderung');
     controls.defer?.({ticketId:id});currentTicket=null;continue;
    }
    need(answer==='MARK','P2_OPERATOR_ABORT','Operator hat den Lauf ausdruecklich gestoppt. Keine Weiterleitung.');
    say('PASS P2_ANFRAGE_MARK_MANUELL_BESTAETIGT: '+id+' | nur interne Weiterleitung, keine E-Mail.');
   }
   const routeListBefore=await capturePhase2RouteList(page);
   let pdfReviewedThisRun=false,expectedProofFile=null;
   if(pick.pdfPreparationRequired){
    let prepared;
    try{prepared=await preparePhase2PdfEvidence({root,page,row:pick.row,mapping:active.map,ask,askContact,log:say,memberLookup,controls,contactWriteAllowed:pick.contactWriteAllowed!==false});}
    catch(e){
     // Only documented, local read-only errors in this preparation stage.
     // A browser error, operator abort, write journal or ambiguous side effect
     // remains a hard stop. No upload/save/route is retried.
     const allowed=new Set(['P2_EXACT_PDF_MISSING','P2_OUTPUT_FOLDER_MISSING','P2_PDF_SIZE','P2_PDF_HEADER','P2_PDF_EOF','P2_EXACT_PDF_NAME','P2_PDF_MUTATED','P2_PDF_CHANGED_DURING_CHECK','P2_PDF_MEMBER_CHANGED','P2_AO_AUDIT_CHANGED','P2_AO_AUDIT_MISSING','P2_AO_AUDIT_INVALID','P2_AO_GENERATOR_PERSON','P2_AO_GENERATOR_PROOF','P2_AO_STICHTAG','P2_AO_GENERATOR_RESULT_PATH','P2_AO_GENERATOR_PROOF_OLD','P2_AO_FRESHNESS_REQUIRED']);
     if(!allowed.has(e.code)||getJournal('MCR_PHASE2_',id)||getJournal('MCR_PHASE2_WORK_',id))throw e;
     prepared={status:'SKIPPED_UNCHANGED',ticketId:id,noWrite:true,reason:e.code};
    }
    if(prepared.status==='SKIPPED_UNCHANGED'){
     need(prepared.ticketId===id&&prepared.noWrite===true&&!getJournal('MCR_PHASE2_',id)&&!getJournal('MCR_PHASE2_WORK_',id),'P2_SKIP_UNSAFE','Dokument-Rueckstellung nicht eindeutig ohne COMARCH-Schreibbeginn.');
     skipRecords.set(id,{ticketId:id,reason:prepared.reason,rule:displayKind,missingFields:prepared.missingFields||[],technicalDetails:prepared.technicalDetails||{}});
     say(documentDeferEvent(admission.rule)+': '+id+' | '+prepared.reason+' | kein Upload/Speichern/Weiterleiten');
     if(admission.rule.targets?.includes('AO')&&isAoSharedWriteBlock(prepared.reason)){
      const scope=aoWriteBlockScope(prepared.reason,prepared.technicalDetails);
      if(!aoWriteBlock||scope==='ALL_NEW_AO'&&aoWriteBlock.scope!=='ALL_NEW_AO'){
       aoWriteBlock={ticketId:id,reason:prepared.reason,scope};
       say('AO_QUEUE_PAUSIERT: '+prepared.reason+' | '+(scope==='CONTACT_ONLY'?'Nur neue AO-Kontakteingaben/Schreibversuche pausiert. AO mit vollstaendigen Kontaktdaten bleiben moeglich.':'Speicher-, Lese- oder Bereinigungsergebnis nicht gesichert; alle neuen AO-Auftraege pausiert.')+' Nicht-AO-Faelle und sichere Journal-Wiederaufnahmen bleiben nach ihren eigenen Pruefungen moeglich.');
      }
     }
     controls.defer?.({ticketId:id});currentTicket=null;continue;
    }
    pdfReviewedThisRun=prepared.status==='PDF_PROOF_READY'&&prepared.ticketId===id;
    if(pdfReviewedThisRun)expectedProofFile=prepared.file;
    if(pdfReviewedThisRun&&prepared.proof?.targets?.includes('AO')){
     // The central calculation may run for minutes. No COMARCH write has
     // begun, so a fresh mapping can be bound without restarting the master.
     // Never let a changed beneficiary inherit the old financial PDF.
     const checked=rebindWorkbookAfterGeneratedAo(root,active,prepared.proof,{log:say});
     active=checked.active;
     if(checked.status==='BENEFICIARY_REVIEW_REQUIRED'){
      const reason='P2_AO_BENEFICIARY_STOCK_CHANGED';
      skipRecords.set(id,{ticketId:id,reason});
      say('P2_AO_TICKET_ZUR_PRUEFUNG: '+id+' | PDF bleibt erhalten; keine Anlage/Speicherung/Weiterleitung und keine neue Berechnung.');
      controls.defer?.({ticketId:id});currentTicket=null;continue;
     }
    }
   }
   assertLiveWorkbookCurrent(root,active);
   const oldWork=getJournal('MCR_PHASE2_WORK_',id),oldPdf=getJournal('MCR_PHASE2_',id);
   let result;
   try{
    result=pick.kind==='ACCOUNT_STATEMENT'?
     await phase2ComarchPilot({root,ticketId:id,session:{page,rl},reviewAuthorized:true,pdfReviewedThisRun,expectedProofFile,controls,routeListBefore,memberLookup,askFn:(_rl,q)=>ask(q),log:say}):
     await handlePhase2Work({root,page,row:pick.row,mapping:active.map,ask,log:say,memberLookup,controls,routeListBefore});
   }catch(error){
    // RC90: either the previously observed stale GEVO or a transiently
    // unreadable description in a resumed direct-routing case. Do not
    // proceed unless old work and PDF journals are byte-for-byte unchanged.
    // This ticket is NOT routed, NOT saved, and NOT treated as completed.
    const afterWork=getJournal('MCR_PHASE2_WORK_',id),afterPdf=getJournal('MCR_PHASE2_',id);
    const safeOld=mayDeferPhase2Readback({code:error?.code,kind:pick.kind,
     beforeWork:oldWork,afterWork,beforePdf:oldPdf,afterPdf});
    const safeNew=mayDeferPhase2PreWrite({code:error?.code,
     beforeWork:oldWork,afterWork,beforePdf:oldPdf,afterPdf});
    const safeRule=mayDeferPhase2WorkRuleConflict({code:error?.code,beforeWork:oldWork,afterWork,beforePdf:oldPdf,afterPdf});
    const safeDraft=mayDeferPhase2DraftBeforeClick({code:error?.code,ticketId:id,beforeWork:oldWork,afterWork,beforePdf:oldPdf,afterPdf});
    if(!safeOld&&!safeNew&&!safeRule&&!safeDraft)throw error;
    // Before continuing, independently establish that we can still safely
    // bind the own-task queue. An uncontrolled browser failure is a stop.
    await UI.navigateToScope(page,'IN_BEARBEITUNG',{refresh:true});
    const safeQueue=await readPhase2Queue(page);
    need(safeQueue.ok,'P2_DEFER_QUEUE_UNVERIFIED',
     'Nach Ticketfehler konnte die eigene Liste nicht sicher neu gebunden werden. Kein blinder Folgefall.');
    const reviewReason=error.code==='P2_WORK_READBACK_UNCLEAR'?
     'P2_WORK_READBACK_UNCLEAR_REVIEW_REQUIRED':error.code==='P2_WORK_SERVER_VALUES'?
     'P2_WORK_SERVER_VALUES_REVIEW_REQUIRED':String(error.code);
    skipRecords.set(id,{ticketId:id,reason:reviewReason,rule:pick.kind,writeAttempted:safeDraft});
    const issue=describeTicketIssue({ticketId:id,reason:reviewReason});
    say('P2_FEHLER: '+id+' | '+issue.errorCode+' | '+issue.cause);
    say('P2_SICHER_ZURUECKGESTELLT: '+id+' | '+error.code+' | '+(safeDraft?'Frueherer Upload/Editorzustand bleibt journalgebunden; kein Entwurf-Speicherklick':'Journal unveraendert/kein Schreibbeginn')+'; andere Tickets werden fortgesetzt.');
    controls.defer?.({ticketId:id});currentTicket=null;continue;
   }
   if(result?.status==='SKIPPED_UNCHANGED'){
    need(pick.kind==='MBC_PRIVATE_EMAIL'&&result.ticketId===id&&result.noWrite===true&&!getJournal('MCR_PHASE2_WORK_',id),'P2_SKIP_UNSAFE','Nur ein unveraenderter neuer MBC-Entwurf darf uebersprungen werden.');
    const skip={ticketId:id,reason:result.reason};skipRecords.set(id,skip);
    say('P2_ENTWURF_UNVERAENDERT: '+id+' | '+skip.reason+' | kein Speichern, kein Weiterleiten');
    controls.defer?.({ticketId:id});currentTicket=null;continue;
   }
   need(result?.status==='ROUTED_VERIFIED','P2_RUN_UNCONFIRMED','Voriger Abschluss nicht verifiziert. Kein naechstes Ticket.');
   receipts.push(result);skipRecords.delete(id);say('PASS P2_FALL_ABGESCHLOSSEN: '+id+' | mark.baindl | OHNE_EMAIL');controls.complete({ticketId:id});currentTicket=null;
  }
  const report={schema:'MCR_PHASE2_RUN_V1',runId,version:VERSION,status:'COMPLETED_VISIBLE_SCOPE',processed:receipts.length,scope:'VISIBLE_MY_TASKS_NO_PAGINATION',maxTickets,receipts,handoffReceipts,mappingRebindings,skipped:[...skipRecords.values()].filter(x=>!receipts.some(r=>r.ticketId===x.ticketId)),ticketAudit:path.join(dir,'MCR_PHASE2_TICKETBESTAND_LETZTE.json')};
  report.issues=dedupeTicketIssues(report.skipped);
  report.recoveryGroups=groupTicketIssues(report.issues);
  for(const [group,items] of Object.entries(report.recoveryGroups))say('P2_WIEDERAUFNAHMEGRUPPE: '+group+' | '+items.length+' offen | '+items.map(x=>x.ticketId||'UNBEKANNT').join(', '));
  report.errorSummary={processed:receipts.length,notProcessed:report.issues.length,
   errorCodes:[...new Set(report.issues.map(x=>x.errorCode))]};
  report.completion=phase2Completion({processed:receipts.length,skipped:report.skipped});
  const errorsJson=path.join(dir,'MCR_PHASE2_FEHLER_'+runId+'.json');
  const errorsCsv=path.join(dir,'MCR_PHASE2_FEHLER_'+runId+'.csv');
  writeJSON(errorsJson,{schema:'MCR_PHASE2_TICKET_ERRORS_V1',runId,version:VERSION,scope:report.scope,
   processed:receipts.length,failed:report.issues.length,items:report.issues,recoveryGroups:report.recoveryGroups});
  fs.writeFileSync(errorsCsv,errorCsv(report.issues),{flag:'wx',mode:0o600});
  report.errorFiles={json:errorsJson,csv:errorsCsv};
  for(const issue of report.issues){
   say('P2_TICKET_NICHT_BEARBEITET: '+(issue.ticketId||'UNBEKANNT')+' | '+issue.errorCode+' | '+issue.reason);
   say('  WARUM: '+issue.cause);
   say('  NAECHSTER_SCHRITT: '+issue.nextAction);
  }
  say('P2_FEHLERBERICHT: '+errorsCsv+' | abgeschlossen='+receipts.length+' | offen='+report.issues.length);
  writeJSON(path.join(dir,'MCR_PHASE2_LAUF_'+runId+'.json'),report);
  // The standalone Phase-2 menu also gets the two scoped, honest endings.
  if(!masterApproved)for(const line of completionLines(report.completion,{master:false}))say(line);
  return report;
 }catch(e){
  controls?.error(e);
  say('STOP '+(e.code||'ERROR')+': '+e.message);
  const failure=describeTicketIssue({ticketId:currentTicket,reason:e.code||'ERROR'});
  say('P2_UNTERBRECHUNG: '+(currentTicket||'KEIN_EINZELTICKET')+' | '+failure.errorCode+
   ' | '+failure.reason+' | Wiederholung ungeklaerter Aktionen verboten.');
  say('P2_FEHLER_URSACHE: '+failure.cause);
  say('P2_FEHLER_MASSNAHME: '+failure.nextAction);
  const errorsJson=path.join(dir,'MCR_PHASE2_FEHLER_'+runId+'.json'),errorsCsv=path.join(dir,'MCR_PHASE2_FEHLER_'+runId+'.csv');
  const failures=dedupeTicketIssues([...skipRecords.values(),failure]);
  writeJSON(errorsJson,{schema:'MCR_PHASE2_TICKET_ERRORS_V1',runId,version:VERSION,
   status:'STOP_REVIEW_REQUIRED',processed:receipts.length,failed:failures.length,items:failures,recoveryGroups:groupTicketIssues(failures)});
  fs.writeFileSync(errorsCsv,errorCsv(failures),{flag:'wx',mode:0o600});
  writeJSON(path.join(dir,'MCR_PHASE2_LAUF_'+runId+'.json'),{schema:'MCR_PHASE2_RUN_V1',runId,version:VERSION,status:'STOP_REVIEW_REQUIRED',errorCode:e.code||'ERROR',
   failure,processed:receipts.length,attempted:[...visited],receipts,mappingRebindings,skipped:[...skipRecords.values()],errorFiles:{json:errorsJson,csv:errorsCsv}});
  throw e;
 }finally{restoreInput?.();controls?.close();if(ownsRl)rl.close();if(sharedPage&&cdp&&!currentTicket){try{await detachOwnedPage(sharedPage);}catch{}}try{cdp?.close();}catch{}try{browser?.child?.kill();}catch{}}
}
