import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {temp,mapping} from './helpers.mjs';
import {withPhase2Browser,installPhase2Fixture} from './rc52-browser-fixture.mjs';
import {commitDescription} from '../lib/trusted-description.mjs';
import {handlePhase2Work} from '../src/phase2-work-handler.mjs';
import {phase2WorkJournal} from '../lib/phase2-work-journal.mjs';
import {markedPhase2Description,privateMbcDraft,PRIVATE_MBC_REQUEST} from '../lib/phase2-work-rules.mjs';
const id='87160524',original='USC 100/ DC\nStandardantwort versendet\n'+PRIVATE_MBC_REQUEST;
const after=markedPhase2Description(original),draft=privateMbcDraft({lastName:'Mustermann',gender:'M'});
const row={ticketId:id,descriptionValue:original};
const noAsk=async prompt=>{throw Error('Unerwartete Frage: '+prompt);};
const member=async()=>({profileVerified:true,profile:{first:'Max',last:'Mustermann',mercerId:'99900001'}});
function prior(root,{authorized=true,clickedAfterAuthorization=false}={}){
 const journal=phase2WorkJournal(root,id);
 journal.begin({rule:'MBC_PRIVATE_EMAIL',descriptionBefore:original,descriptionAfter:after,draft,memberId:'99900001'});
 for(const state of ['EDIT_INTENT','EDIT_VERIFIED','DRAFT_SAVE_INTENT','DRAFT_SAVE_VERIFIED','TICKET_SAVE_INTENT'])journal.advance(state);
 journal.observe('TICKET_SAVE_MANUAL_CLICK_INTENT');
 journal.observe('TICKET_SAVE_NETWORK_OBSERVED',{status:'NETWORK_QUIET',writeStarts:0});
 if(authorized)journal.observe('SAVE_REPAIR_AUTHORIZED');
 if(clickedAfterAuthorization)journal.observe('TICKET_SAVE_MANUAL_CLICK_INTENT');
 return journal;
}
async function addOverlay(page,{full=false}={}){return page.call(({full})=>{
 const section=document.getElementById('mainForm:document-data-section');const area=document.getElementById('additional');
 section.style.position='relative';const r=area.getBoundingClientRect();const s=section.getBoundingClientRect();
 const div=document.createElement('div');div.id='blocked-description';
 Object.assign(div.style,{position:'absolute',left:(r.left-s.left+(full?0:r.width*.33))+'px',
  top:(r.top-s.top+(full?0:r.height*.30))+'px',width:(full?r.width:r.width*.34)+'px',
  height:(full?r.height:r.height*.40)+'px',background:'rgba(180,0,0,.8)',zIndex:'99999'});
 section.appendChild(div);
},{full});}
test('RC57 Chromium: description center covered but side visible, trusted hit-test finds REAL textarea, no manual gate',{timeout:38000},()=>withPhase2Browser(async page=>{
 await installPhase2Fixture(page,[{ticketId:id,description:original}]);await page.call(id=>showDetail(id),id);
 await addOverlay(page);const log=[];
 const res=await commitDescription(page,{ticketId:id,expected:after,allowedBefore:[original],log:s=>log.push(s),manualFocus:()=>{throw Error('Should not need manual focus');}});
 assert(res.ok);assert(log.some(x=>x.includes('DESCRIPTION_TRUSTED_FOCUS')));
 assert.equal(await page.eval('document.getElementById("additional").value'),after);
 assert.equal(await page.eval('_counts.save+_counts.review+_counts.draft+_counts.send'),0);
}));
test('RC57 Chromium: fully covered description never clicks an adjacent field or edits without a real focused textarea',{timeout:37000},()=>withPhase2Browser(async page=>{
 await installPhase2Fixture(page,[{ticketId:id,description:original}]);await page.call(id=>showDetail(id),id);await addOverlay(page,{full:true});
 await assert.rejects(()=>commitDescription(page,{ticketId:id,expected:after,allowedBefore:[original]}),e=>e.code==='DESCRIPTION_FOCUS');
 assert.equal(await page.eval('document.getElementById("additional").value'),original);
 assert.equal(await page.eval('_counts.save+_counts.review+_counts.draft+_counts.send'),0);
}));
test('RC57 Chromium: operator removes overlay and physically clicks exact textarea, verified before any key is sent',{timeout:43000},()=>withPhase2Browser(async page=>{
 await installPhase2Fixture(page,[{ticketId:id,description:original}]);await page.call(id=>showDetail(id),id);await addOverlay(page,{full:true});let gates=0,log=[];
 const res=await commitDescription(page,{ticketId:id,expected:after,allowedBefore:[original],log:s=>log.push(s),manualFocus:async()=>{
  gates++;const p=await page.call(()=>{document.getElementById('blocked-description').remove();const f=document.getElementById('additional'),r=f.getBoundingClientRect();return {x:r.left+r.width*.5,y:r.top+r.height*.5};});
  await page.mouseClick(p.x,p.y);
 }});
 assert(res.ok);assert.equal(gates,1);assert(log.some(x=>x.includes('DESCRIPTION_OPERATOR_FOCUS_VERIFIED')));
 assert.equal(await page.eval('document.getElementById("additional").value'),after);
}));
test('RC57 Chromium: RC56 failed DESCRIPTION_FOCUS after SAVE_REPAIR_AUTHORIZED resumes with no second draft, one save and one Mark route',{timeout:60000},()=>withPhase2Browser(async page=>{
 const root=temp();try{const j=prior(root),events=j.read().events;
  await installPhase2Fixture(page,[{ticketId:id,description:original,draft}]);
  await page.call(()=>{const originalShow=window.showDetail;window.showDetail=id=>{originalShow(id);const f=document.getElementById('additional'),sec=f.parentElement,r=f.getBoundingClientRect(),s=sec.getBoundingClientRect();
   sec.style.position='relative';const o=document.createElement('div');o.style.cssText='position:absolute;z-index:5000;background:#777;';
   Object.assign(o.style,{left:(r.left-s.left+r.width*.32)+'px',top:(r.top-s.top+r.height*.3)+'px',width:r.width*.35+'px',height:r.height*.4+'px'});sec.appendChild(o);};});
  const asked=[],logs=[];
  const result=await handlePhase2Work({root,page,row,mapping:mapping(),memberLookup:()=>{throw Error('No member lookup on resume');},
   ask:async q=>{asked.push(q);assert(q.includes('NICHT_GESPEICHERT_'+id));return 'NICHT_GESPEICHERT_'+id;},log:s=>logs.push(s)});
  assert.equal(result.status,'ROUTED_VERIFIED');assert.equal(asked.length,1);
  assert.deepEqual(j.read().events.slice(0,events.length),events);
  assert(j.read().events.some(e=>e.state==='SAVE_REPAIR_FOCUS_RETRY_AUTHORIZED'));
  assert.equal(await page.eval('_counts.draft'),0);assert.equal(await page.eval('_counts.save'),1);
  assert.equal(await page.eval('_counts.review'),1);assert.equal(await page.eval('_counts.send'),0);
  assert.equal(await page.eval('_server[0].draft'),draft);assert.equal(await page.eval('_server[0].description'),after);
  assert(logs.some(x=>x.includes('P2_RC57_PRECLICK_FOCUS_RECOVERY')));
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));
test('RC57 Chromium: repair with a save-click intent AFTER prior authorization never retries or forwards',{timeout:31000},()=>withPhase2Browser(async page=>{
 const root=temp();try{const j=prior(root,{clickedAfterAuthorization:true});
  await installPhase2Fixture(page,[{ticketId:id,description:original,draft}]);
  await assert.rejects(()=>handlePhase2Work({root,page,row,mapping:mapping(),memberLookup:member,ask:noAsk,log:()=>{}}),e=>e.code==='P2_WORK_REPAIR_LIMIT');
  assert.equal(await page.eval('_counts.draft+_counts.save+_counts.review+_counts.send'),0);
  assert.equal(j.read().events.filter(e=>e.state==='SAVE_REPAIR_FOCUS_RETRY_AUTHORIZED').length,0);
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));
test('RC57 Chromium: refused repair leaves the original journal and server ticket unchanged',{timeout:31000},()=>withPhase2Browser(async page=>{
 const root=temp();try{const j=prior(root),events=j.read().events;
  await installPhase2Fixture(page,[{ticketId:id,description:original,draft}]);
  await assert.rejects(()=>handlePhase2Work({root,page,row,mapping:mapping(),memberLookup:member,ask:async()=>'',log:()=>{}}),e=>e.code==='P2_WORK_REPAIR_DECLINED');
  assert.deepEqual(j.read().events,events);assert.equal(await page.eval('_counts.save+_counts.draft+_counts.review'),0);
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));
