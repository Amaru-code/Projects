import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import vm from 'node:vm';
import {safePreactionSkip} from '../lib/preaction-skip.mjs';
import {ledger,writeJSON,assertNoReview,runState} from '../lib/control.mjs';
import {releaseProvenPreActionAbort} from '../lib/preaction-recovery.mjs';
import {prepareFreshRun,pendingSnapshot,blockedTicketIds} from '../lib/run-reset.mjs';
import {interruptedPilotCandidate} from '../lib/master-pilot-recovery.mjs';
import {phase1QueueExhaustedProof,runnerDiagnosticError} from '../tools/cli.mjs';
import {certifyPilot,certifyForwardWithoutEmail} from '../tools/proof.mjs';
import {masterCompletion,completionLines} from '../lib/master-completion.mjs';
import Queue from '../lib/queue-send.cjs';
import {resolveWwidPersonChoice,searchWwidMember} from '../lib/person-choice.mjs';

const ticketId='89827030';
const proof=(overrides={})=>({schema:'MCR_MEMBER_QUERY_RECOVERY_V1',ticketId,queryOnly:true,attempts:3,...overrides});
const options=(overrides={})=>({ticketId,memberQueryRecovery:proof(),...overrides});

test('RC100: only a bounded query-only proof for this exact early-stage ticket permits deferral',()=>{
 for(const phase of ['MEMBER_SEARCH','MEMBER_SUGGESTION_SELECTION']){
  for(const attempts of [1,2,3]){
   assert.equal(safePreactionSkip('MEMBER_QUERY_REVIEW_REQUIRED',phase,
    options({memberQueryRecovery:proof({attempts})})),'MEMBER_QUERY_REVIEW');
  }
 }
});

test('RC100: absent, foreign, malformed or unbounded query proof cannot authorize continuation',()=>{
 const invalid=[
  {},options({ticketId:null}),options({ticketId:89827030}),options({ticketId:'short'}),
  options({ticketId:'1234567890123'}),options({memberQueryRecovery:null}),
  options({memberQueryRecovery:proof({schema:'OTHER'})}),
  options({memberQueryRecovery:proof({ticketId:'89827031'})}),
  options({memberQueryRecovery:proof({ticketId:89827030})}),
  options({memberQueryRecovery:proof({queryOnly:false})}),
  options({memberQueryRecovery:proof({queryOnly:'true'})}),
  ...[undefined,null,0,-1,4,1.5,'3',NaN,Infinity].map(attempts=>
   options({memberQueryRecovery:proof({attempts})})),
 ];
 for(const input of invalid)
  assert.equal(safePreactionSkip('MEMBER_QUERY_REVIEW_REQUIRED','MEMBER_SEARCH',input),null);
 for(const phase of ['INITIAL','MAIL_AND_PERSON','MEMBER_COMMIT_VERIFY','MAPPING_LOOKUP',
  'DESCRIPTION_AND_FIXED_FIELDS','SEND_AND_SAVE','POST_SEND_STATUS_AND_SAVE','FORWARD_MISSING_PERSON'])
  assert.equal(safePreactionSkip('MEMBER_QUERY_REVIEW_REQUIRED',phase,options()),null);
});

test('RC100: pending actions, demo runs and raw input or system failures never gain query-skip authority',()=>{
 for(const patch of [{pending:true},{demo:true}])
  assert.equal(safePreactionSkip('MEMBER_QUERY_REVIEW_REQUIRED','MEMBER_SEARCH',options(patch)),null);
 for(const code of ['FIXED_QUERY_MISMATCH','FIXED_INPUT_FOCUS_LOST','INPUT_CHANGED','CDP_ERROR',
  'BROWSER_OWNED_TARGET_MISSING','WORKBOOK_DATA_CHANGED','TICKET_BINDING','NAME_CHOICE_CANCELLED'])
  assert.equal(safePreactionSkip(code,'MEMBER_SEARCH',options()),null);
 assert.equal(safePreactionSkip('NAME_CHOICE_SKIPPED','MAIL_AND_PERSON'),'IDENTITY_REVIEW');
 assert.equal(safePreactionSkip('NAME_CHOICE_CANCELLED','MEMBER_SUGGESTION_SELECTION'),null);
});

function exhaustedDiagnostic(){return {
 mode:'REAL',lastError:null,send:{clicked:false,verified:false},save:{clicked:false,verified:false},
 loop:{processed:0,forwarded:0,myTasksProcessed:0,queueProcessed:0,processedTickets:[],
  completed:true,finishReason:'NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS',skippedIdentity:1,skippedMemberQuery:1},
};}

test('RC100: a deferred search can finish an audited list scan but never certifies a send or forwarding pilot',()=>{
 const d=exhaustedDiagnostic();
 assert.equal(phase1QueueExhaustedProof(d),true);
 assert.throws(()=>certifyPilot(d),{code:'PILOT_NOT_VERIFIED'});
 assert.throws(()=>certifyForwardWithoutEmail(d),{code:'FORWARD_NOT_VERIFIED'});
 assert.throws(()=>certifyPilot({...d,loop:{...d.loop,finishReason:'PILOT_LIMIT_AFTER_VERIFIED_SAVE'}}),
  {code:'PILOT_NOT_VERIFIED'});
 for(const patch of [
  {lastError:'MEMBER_QUERY_REVIEW_REQUIRED'},
  {loop:{...d.loop,completed:false}},
  {loop:{...d.loop,finishReason:null}},
  {loop:{...d.loop,processed:1}},
  {loop:{...d.loop,forwarded:1}},
  {send:{clicked:true,verified:false}},
 ])assert.equal(phase1QueueExhaustedProof({...d,...patch}),false);
});

test('RC100: master completion remains partial when a member search was deferred',()=>{
 const c=masterCompletion({
  phase1:{status:'NO_NEW_ELIGIBLE_MANUAL_IDENTITY_REVIEW',manualIdentityReviewObserved:1,
   pilotAttempts:[{processed:0,skippedIdentity:1,skippedMemberQuery:1}],batches:[]},
  phase2:{status:'VERIFIED_VISIBLE_SCOPE',processed:2,skipped:[]},
 });
 assert.equal(c.fullyResolved,false);assert.equal(c.kind,'ALL_ELIGIBLE_TICKETS');
 assert.equal(c.phase1Processed,0);assert.equal(c.phase1IdentityReviews,1);
 const lines=completionLines(c).join('\n');
 assert.match(lines,/PHASE 1: 1 Identitaetspruefung/);
 assert.match(lines,/Phase-1-Prueffaelle bleiben offen/);
 assert.doesNotMatch(lines,/bearbeitet; 0 Tickets konnten nicht bearbeitet werden\./);
 assert.doesNotMatch(lines,/OFFENE FAELLE: 0 in den geprueften Listen/);
});

const historicalIds=['87086074','87687558','87782495','87810926','87813639',
 '87917040','88076481','88078437','88149870','88296387'];
const idle=()=>({schema:'MCR_PROCESS_GUARD_V1',checked:true,blockedCount:0,unknownCount:0});
function failedRc99Fixture({currentIntent=false}={}){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC100-RESTART-'));
 for(const id of historicalIds)ledger(root).begin(id,'SYNTHETIC_QA_ONLY');
 const ledgerPath=path.join(root,'.runtime/beta-control/ticket-ledger.json');
 const data=JSON.parse(fs.readFileSync(ledgerPath));
 for(const entry of Object.values(data.tickets))entry.startedAt='2026-11-01T10:00:00.000Z';
 writeJSON(ledgerPath,data);
 if(currentIntent){
  ledger(root).begin(ticketId,'SYNTHETIC_CURRENT_INTENT');
  const withCurrent=JSON.parse(fs.readFileSync(ledgerPath));
  Object.values(withCurrent.tickets).find(x=>x.ticketId===ticketId).startedAt='2026-11-19T15:12:00.000Z';
  writeJSON(ledgerPath,withCurrent);
 }
 const state={schema:'MCR_BETA_RUN_V1',version:'0.8.1-rc.99',operation:'REAL_RUN',pilot:true,
  state:'STOP_REVIEW_REQUIRED',pid:2147483647,startedAt:'2026-11-19T15:11:26.667Z',
  finishedAt:'2026-11-19T15:12:37.522Z',runId:'2026-11-19T15-11-26-667Z_8820e4d5',errorCode:'LIVE_NOT_VERIFIED'};
 const statePath=path.join(root,'.runtime/beta-control/last-run.json');writeJSON(statePath,state);
 fs.mkdirSync(path.join(root,'diagnostics'));
 writeJSON(path.join(root,'diagnostics/last-result.json'),{schema:'MCR_LOCAL_RUNNER_DIAGNOSTIC_V2',
  mode:'REAL',runId:state.runId,createdAt:'2026-11-19T15:11:27.000Z',phase:'MEMBER_SEARCH',
  lastError:'FIXED_QUERY_MISMATCH',send:{clicked:false,verified:false},save:{clicked:false,verified:false},
  loop:{processed:0,forwarded:0,processedTickets:[]}});
 return {root,ledgerPath,statePath,state,close:()=>fs.rmSync(root,{recursive:true,force:true})};
}

test('RC100: existing RC99 recovery archives the failed search while preserving all ten historical intents',()=>{
 const f=failedRc99Fixture();
 try{
  const before=fs.readFileSync(f.ledgerPath),pending=pendingSnapshot(f.root);
  assert.equal(interruptedPilotCandidate(f.state,ledger(f.root).pending),null);
  const preaction=releaseProvenPreActionAbort(f.root);
  assert.equal(preaction.released,false);assert.equal(preaction.reason,'NOT_PROVEN_NO_ACTION');
  const fresh=prepareFreshRun(f.root,{guard:idle});
  assert.equal(fresh.oldRunClosed,true);assertNoReview(f.root);
  assert.equal(runState(f.root).state,'AUTO_QUARANTINED_FOR_NEW_RUN');
  assert.equal(Buffer.compare(fs.readFileSync(f.ledgerPath),before),0);
  assert.deepEqual(pendingSnapshot(f.root),pending);
  assert.deepEqual(blockedTicketIds(f.root),[...historicalIds].sort());
  assert.equal(blockedTicketIds(f.root).includes(ticketId),false);
  const receipt=JSON.parse(fs.readFileSync(path.join(f.root,'.runtime/beta-control',fresh.receipt)));
  assert.equal(receipt.oldState.runId,f.state.runId);
  assert.deepEqual(receipt.pending,pending);
 }finally{f.close();}
});

test('RC100: an actual new intent remains quarantined and cannot be mistaken for the untouched search failure',()=>{
 const f=failedRc99Fixture({currentIntent:true});
 try{
  const before=fs.readFileSync(f.ledgerPath);
  assert.equal(interruptedPilotCandidate(f.state,ledger(f.root).pending).ticketId,ticketId);
  assert.equal(releaseProvenPreActionAbort(f.root).released,false);
  prepareFreshRun(f.root,{guard:idle});
  assert.equal(blockedTicketIds(f.root).includes(ticketId),true);
  assert.equal(ledger(f.root).pending.length,11);
  assert.equal(Buffer.compare(fs.readFileSync(f.ledgerPath),before),0);
 }finally{f.close();}
});

test('RC100: uncertain process state and malformed historical intents still block restart without changing records',()=>{
 const f=failedRc99Fixture();
 try{
  const stateBefore=fs.readFileSync(f.statePath),ledgerBefore=fs.readFileSync(f.ledgerPath);
  assert.throws(()=>prepareFreshRun(f.root,{guard:()=>({...idle(),blockedCount:1})}),
   {code:'PROCESS_CHECK_UNAVAILABLE'});
  assert.equal(Buffer.compare(fs.readFileSync(f.statePath),stateBefore),0);
  assert.equal(Buffer.compare(fs.readFileSync(f.ledgerPath),ledgerBefore),0);
  const data=JSON.parse(ledgerBefore);Object.values(data.tickets)[0].state='UNKNOWN_EFFECT';
  writeJSON(f.ledgerPath,data);const malformed=fs.readFileSync(f.ledgerPath);
  assert.throws(()=>prepareFreshRun(f.root,{guard:idle}),{code:'JOURNAL_STATE_UNCLEAR'});
  assert.equal(Buffer.compare(fs.readFileSync(f.statePath),stateBefore),0);
  assert.equal(Buffer.compare(fs.readFileSync(f.ledgerPath),malformed),0);
 }finally{f.close();}
});

/** Run the production processTicket catch and continuation statements. Only
 * processTicket and UI boundaries are replaced; skip policy/counters/audit
 * selection and continue behavior are the actual distributed source. */
function continuation({pending=[],errorCode='MEMBER_QUERY_REVIEW_REQUIRED',
 recovery=proof({reason:'FIXED_QUERY_MISMATCH'}),phase='MEMBER_SEARCH',bindingChanged=false,fixedReview=null}={}){
 const source=fs.readFileSync(new URL('../src/local-bot-full-run.mjs',import.meta.url),'utf8');
 const start=source.indexOf('  try{await processTicket(page,mapping,rl,row,scope,cfg,journal);}');
 const end=source.indexOf(' if(diag.loop.processed===MAX)',start);
 assert.ok(start>=0&&end>start,'actual processTicket continuation block is present');
 const rows=[{ticketId},{ticketId:'89827031'},{ticketId}],visited=[],actions=[],logs=[],audits=[],views=[];
 const diag={phase:null,loop:{processed:0,processedTickets:[]}},page={},journal={pending};
 const error=Object.assign(new Error('query could not be entered'),{code:errorCode,memberQueryRecovery:recovery,fixedReview});
 let current=null;
 const context={rows,diag,page,mapping:{},rl:{},cfg:{},scope:'WARTESCHLANGE_INTL01',journal,
  DEMO:false,safePreactionSkip,log:line=>logs.push(line),show:event=>views.push(event),sleep:async()=>{},
  ticketAudit:(_cfg,id,outcome,scope,reason)=>audits.push({id,outcome,scope,reason}),
  processTicket:async(_page,_mapping,_rl,row)=>{
   current=row.ticketId;visited.push(current);diag.phase=phase;
   if(current===ticketId)throw error;
   actions.push({ticketId:current,action:'send'},{ticketId:current,action:'save'});
   diag.loop.processed++;diag.loop.processedTickets.push({source:'WARTESCHLANGE_INTL01'});
  },
  UI:{
   assertTicket:async(p,id)=>{
    assert.equal(p,page);assert.equal(id,current);
    if(bindingChanged)throw Object.assign(new Error('different ticket'),{code:'TICKET_BINDING'});
   },
   navigateToScope:async(p,scope)=>{assert.equal(p,page);assert.equal(scope,'IN_BEARBEITUNG');return {};},
  },
 };
 // The extracted fragment contains the closing brace of the production
 // while loop; it closes this controlled traversal of queue candidates.
 const run=vm.runInNewContext('(async()=>{const processed=new Set();for(const row of rows){'+
  'if(processed.has(row.ticketId))continue;\n'+source.slice(start,end)+
  '\nreturn {processedIds:[...processed]};})',context);
 return {run,diag,visited,actions,logs,audits,views,error};
}

test('RC100: actual runner defers one exhausted search and processes the next ticket without claiming the first complete',async()=>{
 const h=continuation({pending:[{ticketId:'87086074',kind:'SEND',state:'SEND_INTENT'}]});
 const r=await h.run();
 assert.deepEqual(h.visited,[ticketId,'89827031']);
 assert.deepEqual(Array.from(r.processedIds),[ticketId,'89827031']);
 assert.deepEqual(h.actions,[{ticketId:'89827031',action:'send'},{ticketId:'89827031',action:'save'}]);
 assert.equal(h.diag.loop.processed,1);assert.equal(h.diag.loop.processedTickets.length,1);
 assert.equal(h.diag.loop.skippedIdentity,1);assert.equal(h.diag.loop.skippedMemberQuery,1);
 assert.equal(h.audits.length,1);assert.equal(h.audits[0].id,ticketId);
 assert.equal(h.audits[0].outcome,'MEMBER_SUCHE_OFFEN');
 assert.equal(h.diag.loop.skippedTickets[0].identityReviewRequired,true);
 assert.equal(h.diag.loop.skippedTickets[0].queryRecovery.reason,'FIXED_QUERY_MISMATCH');
 assert.equal(h.diag.loop.skippedTickets[0].queryRecovery.attempts,3);
 assert.equal(JSON.stringify(h.diag).includes(ticketId),false,'private ticket ID stays in local audit, not diagnostic');
 assert.ok(h.logs.some(x=>x.startsWith('SKIP_MEMBER_QUERY_REVIEW:')));
});

test('RC100: actual runner propagates current pending actions and unproved or late input failures',async()=>{
 for(const options of [
  {pending:[{ticketId,kind:'SEND',state:'SEND_INTENT'}]},
  {errorCode:'FIXED_QUERY_MISMATCH'},
  {recovery:null},
  {recovery:proof({ticketId:'89827031'})},
  {phase:'DESCRIPTION_AND_FIXED_FIELDS'},
 ]){
  const h=continuation(options);
  await assert.rejects(h.run(),error=>error===h.error);
  assert.deepEqual(h.visited,[ticketId]);assert.equal(h.actions.length,0);
  assert.equal(h.audits.length,0);assert.equal(h.diag.loop.skippedIdentity,undefined);
 }
});

test('RC100: actual runner rechecks ticket binding before recording a deferred search or moving to another ticket',async()=>{
 const h=continuation({bindingChanged:true});
 await assert.rejects(h.run(),{code:'TICKET_BINDING'});
 assert.deepEqual(h.visited,[ticketId]);assert.equal(h.actions.length,0);assert.equal(h.audits.length,0);
 assert.equal(h.diag.loop.skippedIdentity,undefined);
});

/** Stop at the actual selectMember input boundary. This checks the caller's
 * authority/options independently of the browser helper's input tests. */
function memberQueryCaller({answers=[],currentMember=null}={}){
 const source=fs.readFileSync(new URL('../src/local-bot-full-run.mjs',import.meta.url),'utf8');
 const start=source.indexOf('async function selectMember('),end=source.indexOf('/** IceFaces dropdowns commit',start);
 assert.ok(start>=0&&end>start,'actual selectMember is present');
 const boundary=new Error('QUERY_BOUNDARY_REACHED'),queries=[],checks=[],events=[];
 const page={},person={firstName:'Erika',lastName:'Beispiel'},diag={};
 let nextAnswer=0;
 const ui={
  assertTicket:async(p,id)=>{assert.equal(p,page);assert.equal(id,ticketId);checks.push(id);},
  selectedMember:async()=>{events.push('read-member');return currentMember;},
  setInputQuery:async(p,id,query,options)=>{
   assert.equal(p,page);queries.push({id,query,options});events.push('query');throw boundary;
  },
 };
 const context={Queue,UI:ui,diag,DEMO:false,log:()=>{},resolveWwidPersonChoice,
  searchWwidMember:async()=>{events.push('identifier-search');return {member:null,reason:'NAME_WWID_NO_MATCH'};},
  need:(ok,code,message)=>{if(!ok)throw Object.assign(new Error(message),{code});},
  ask:async()=>{assert.ok(nextAnswer<answers.length,'unexpected operator prompt');return answers[nextAnswer++];},
 };
 const select=vm.runInNewContext('('+source.slice(start,end)+')',context);
 const run=options=>select(page,person,{expectedId:null},{},{boundTicketId:ticketId,...options});
 return {run,person,boundary,queries,checks,events};
}

test('RC100: actual name-search caller permits committed replacement only for an explicit forced correction',async()=>{
 for(const forceSearch of [false,true]){
  const h=memberQueryCaller({currentMember:forceSearch?{id:'99900001'}:null});
  await assert.rejects(h.run({forceSearch}),error=>error===h.boundary);
  assert.equal(h.queries.length,1);assert.ok(h.checks.length>0);
  const q=h.queries[0];
  assert.equal(q.id,'mainForm:member-value-id');assert.equal(q.query,'Beispiel Erika');
  assert.equal(q.options.ticketId,ticketId);
  assert.equal(q.options.replaceCommittedForNewSearch,forceSearch);
  assert.equal(typeof q.options.manualGate,'function');
  assert.equal(h.events.includes('read-member'),!forceSearch,
   'a chosen correction must not reuse the prior committed profile');
 }
});

test('RC100: actual failed identifier choice followed by a name index enters the bound correction path',async()=>{
 const h=memberQueryCaller({answers:['2'],currentMember:{id:'99900001'}});
 const candidates=[{firstName:'Max',lastName:'Mustermann'},h.person];
 await assert.rejects(h.run({wwidChoice:{choice:{kind:'WWID',wwid:'99900003'},
  candidates,ticketId,quotedOnly:false}}),error=>error===h.boundary);
 assert.equal(h.queries.length,1);assert.equal(h.queries[0].query,'Beispiel Erika');
 assert.equal(h.queries[0].options.replaceCommittedForNewSearch,true);
 assert.equal(h.queries[0].options.ticketId,ticketId);
 assert.deepEqual(h.events,['identifier-search','query']);
 assert.ok(h.checks.length>=2,'ticket is rebound after choice and before the new search');
});

test('RC100: actual WWID and explicit MercerID search callers pass the bound replacement contract',async()=>{
 for(const hintKind of ['WWID','MERCERID']){
  const page={},queries=[],checks=[],boundary=new Error('IDENTIFIER_QUERY_BOUNDARY_REACHED');
  const wait=async()=>{},log=()=>{};
  const ui={
   assertTicket:async(p,id)=>{assert.equal(p,page);assert.equal(id,ticketId);checks.push(id);},
   setInputQuery:async(p,id,query,options)=>{
    assert.equal(p,page);queries.push({id,query,options});throw boundary;
   },
  };
  await assert.rejects(searchWwidMember({page,ticketId,wwid:'99900003',hintKind,
   candidates:[{firstName:'Erika',lastName:'Beispiel'}],map:null,ui,wait,log,
   ask:async()=>assert.fail('unexpected operator prompt')}),error=>error===boundary);
  assert.equal(queries.length,1);assert.deepEqual(checks,[ticketId]);
  const q=queries[0];
  assert.equal(q.id,'mainForm:member-value-id');assert.equal(q.query,'99900003');
  assert.equal(q.options.ticketId,ticketId);assert.equal(q.options.replaceCommittedForNewSearch,true);
  assert.equal(q.options.wait,wait);assert.equal(q.options.log,log);
  assert.equal(typeof q.options.manualGate,'function');
 }
});

test('RC100: a bound runner diagnostic retains the original input code and phase instead of LIVE_NOT_VERIFIED',()=>{
 const error=runnerDiagnosticError({lastError:'FIXED_QUERY_MISMATCH',phase:'MEMBER_SEARCH'});
 assert.equal(error.code,'FIXED_QUERY_MISMATCH');assert.equal(error.runnerPhase,'MEMBER_SEARCH');
 assert.notEqual(error.code,'LIVE_NOT_VERIFIED');
 assert.equal(runnerDiagnosticError({lastError:null}),null);
 assert.equal(runnerDiagnosticError({}),null);
 for(const value of ['',false,12,{},'bad code\nprivate@example.invalid']){
  const invalid=runnerDiagnosticError({lastError:value,phase:'PRIVATE\nTEXT'});
  assert.equal(invalid.code,'RUNNER_ERROR');assert.equal(invalid.runnerPhase,null);
  assert.doesNotMatch(invalid.message,/private@example\.invalid/);
 }
});

const signatureReview={schema:'MCR_FIXED_FIELD_REVIEW_V1',ticketId,noSendIntent:true,signatureReview:true,reason:'FIXED_SIGNATURE_CONFLICT'};
for(const phase of ['DESCRIPTION_AND_FIXED_FIELDS','FORWARD_COMARCH_MEMBER_NOT_FOUND','FORWARD_MISSING_PERSON'])test('RC118 actual queue catch defers a bound signature conflict in '+phase+' and processes next ticket',async()=>{
 const h=continuation({errorCode:'FIXED_FIELD_REVIEW_REQUIRED',fixedReview:signatureReview,phase});
 await h.run();assert.deepEqual(h.visited,[ticketId,'89827031']);
 assert.equal(h.audits[0].outcome,'PFLICHTFELDER_OFFEN');assert.equal(h.audits[0].reason,'FIXED_SIGNATURE_CONFLICT');
 assert.equal(h.actions.length,2);assert.equal(h.actions[0].ticketId,'89827031');
 assert.ok(h.logs.some(x=>x.startsWith('SKIP_FIXED_FIELD_REVIEW')));
});
test('RC118 signature skip must not bypass pending actions, unbound evidence or post-save phases',async()=>{
 for(const options of [{pending:[{ticketId,kind:'SEND',state:'SEND_INTENT'}]}, {pending:[{ticketId,kind:'FORWARD',state:'ROUTE_SAVED_VERIFIED'}]}, {phase:'ROUTE_FIELD_REPAIR'}, {phase:'SEND_AND_SAVE'}, {fixedReview:{...signatureReview,ticketId:'89827031'}}, {fixedReview:null}]){
  const h=continuation({errorCode:'FIXED_FIELD_REVIEW_REQUIRED',fixedReview:signatureReview,phase:'DESCRIPTION_AND_FIXED_FIELDS',...options});
  await assert.rejects(h.run(),e=>e===h.error);assert.equal(h.actions.length,0);assert.equal(h.audits.length,0);
 }
});
