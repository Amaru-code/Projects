import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import net from 'node:net';
import path from 'node:path';
import vm from 'node:vm';
import * as UI from '../lib/browser-workflow.mjs';
import Prep from '../lib/ticket-prep.cjs';
import * as policy from '../lib/phase1-signature-policy.mjs';
import {requireThat as need} from '../lib/core.mjs';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage,sleep} from '../lib/cdp.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';

const source=fs.readFileSync(new URL('../src/local-bot-full-run.mjs',import.meta.url),'utf8');
const body=source.slice(source.indexOf('async function fixedFields(page,rl){'),source.indexOf('/** The send button gets exactly ONE'));
const fixedFields=vm.runInNewContext('('+body+')',{
 UI,Prep,...policy,need,sleep,diag:{},DEMO:true,log:()=>{},ask:()=>assert.fail('Unexpected manual gate')
});

async function render(page,filter){
 await page.call((fixed,filter)=>{
  document.body.innerHTML=`<style>input{display:block;width:320px}.menu{position:absolute;background:white;z-index:10;border:1px solid} [role=option]{padding:5px}</style>
   <div>Ticket-ID: 88990001</div>
   <select id="mainForm:responsibility-value-id"><option>Second Level</option></select>
   <input id="mainForm:category-value-id"><input id="mainForm:category-sub-value-id">
   <input id="mainForm:member-value-id" value="INTL01-99999999">
   <input id="mainForm:signature-value-id"><div contenteditable="true">Entwurf</div>`;
  document.getElementById('mainForm:category-value-id').value=fixed.category;
  document.getElementById('mainForm:category-sub-value-id').value=fixed.subcategory;
  const input=document.getElementById('mainForm:signature-value-id');
  const trace=window.signatureTrace={typed:[],commands:[],chosen:[]};
  input.addEventListener('input',()=>trace.typed.push(input.value));
  input.addEventListener('keydown',e=>{
   if(e.ctrlKey||['Delete','Backspace'].includes(e.key))trace.commands.push(e.key);
  });
  input.addEventListener('keyup',e=>{
   if(!e.isTrusted||input.value!==filter)return;
   window.setTimeout(()=>{
    if(input.value!==filter||!input.isConnected)return;
    const menu=document.createElement('div');menu.className='menu';menu.setAttribute('role','listbox');
    const bounds=input.getBoundingClientRect();
    menu.style.left=bounds.left+'px';menu.style.top=bounds.bottom+'px';
    for(const text of [fixed.signature+' - anderer Mandant',fixed.signature]){
     const option=document.createElement('div');option.setAttribute('role','option');option.textContent=text;
     option.onmousedown=event=>{
      trace.chosen.push({text,trusted:event.isTrusted});
      input.value=text;menu.remove();event.preventDefault();
     };
     menu.append(option);
    }
    document.body.append(menu);
   },450);
  });
 },Prep.FIXED,filter);
}

test('RC119 real browser selects delayed exact option on code and legacy full-keyup filters without clearing', {timeout:90000},async t=>{
 const executable=findEdgeExecutable();
 if(!executable){t.skip('no local browser');return;}
 const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC20-NOTE-RC119-SIGNATURE-'));
 let browser,cdp;
 try{
  // Chromium's Linux process singleton requires an AF_UNIX socket. Some
  // container executors install Chromium but deny local Unix sockets.
  if(process.platform==='linux'){
   const server=net.createServer();
   try{
    await new Promise((resolve,reject)=>server.once('error',reject).listen(path.join(profile,'probe.sock'),resolve));
    await new Promise(resolve=>server.close(resolve));
   }catch(error){
    if(error.code!=='EPERM'&&error.code!=='EACCES')throw error;
    t.skip('local Unix sockets unavailable for Chromium');return;
   }
  }
  browser=await launchBrowser({executable,userDataDir:profile,startUrl:'about:blank',headless:true,
   extraArgs:process.platform==='linux'?['--no-sandbox','--disable-dev-shm-usage']:[]});
  ({cdp}=await connectBrowser(browser.port));
  const page=await attachPage(cdp,target=>target.type==='page'&&target.url==='about:blank');
  for(const filter of ['INTL01',Prep.FIXED.signature]){
   await render(page,filter);
   await fixedFields(page,{});
   const trace=await page.call(()=>window.signatureTrace);
   assert.equal(trace.typed.at(-1),filter);
   for(let i=1;i<trace.typed.length;i++){
    assert.ok(trace.typed[i].startsWith(trace.typed[i-1])&&trace.typed[i].length>trace.typed[i-1].length);
   }
   assert.deepEqual(trace.commands,[]);
   assert.deepEqual(trace.chosen,[{text:Prep.FIXED.signature,trusted:true}]);
   assert.equal((await UI.fixedFieldValues(page)).signature,Prep.FIXED.signature);
   await fixedFields(page,{});
   assert.deepEqual(await page.call(()=>window.signatureTrace),trace);
  }
 }finally{await cleanupTemporaryTestBrowser({profile,browser,cdp});}
});
