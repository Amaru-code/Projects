import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {focusInput} from '../lib/input-focus.mjs';
import {setInputQuery,typeTrustedFixedQuery} from '../lib/browser-workflow.mjs';
import {phase1SignatureState,mayChoosePhase1Signature,mayRetryPhase1Signature} from '../lib/phase1-signature-policy.mjs';

const memberId='mainForm:member-value-id';
function inputHarness({value='',focused=false,duplicate=false,covered=false,onClick=null,onRead=null,onPoint=null}={}){
 const calls={mouse:0,manual:0,scroll:[],events:[]};
 const fields=[];
 const doc={activeElement:null,querySelectorAll:()=>fields,getElementById:id=>fields.find(f=>f.id===id),
  elementFromPoint:()=>covered?{tagName:'DIV'}:fields[0]};
 const win={getComputedStyle:()=>({display:'block',visibility:'visible'}),innerWidth:1200,innerHeight:900};
 doc.defaultView=win;
 const create=()=>({id:memberId,tagName:'INPUT',value,selectionStart:value.length,selectionEnd:value.length,
  setSelectionRange(start,end){this.selectionStart=start;this.selectionEnd=end;},isConnected:true,disabled:false,readOnly:false,ownerDocument:doc,
  scrollIntoView:o=>calls.scroll.push(o.block),getClientRects:()=>[{left:20,top:30,right:320,bottom:60}]});
 fields.push(create());if(duplicate)fields.push(create());
 if(focused)doc.activeElement=fields[0];
 const context=vm.createContext({document:doc,setTimeout:fn=>{fn();return 1;}});
 const api={calls,doc,fields,create,replace(){const was=fields[0];was.isConnected=false;fields[0]=create();doc.activeElement=null;return fields[0];}};
 api.page={sessionId:'test',call:async(fn,...args)=>{
  if(fn.name==='inputState')onRead?.(api);
  if(fn.name==='inputPointStillBound')onPoint?.(api);
  context.args=args;
  return vm.runInContext('('+fn.toString()+')(...args)',context);
 },mouseClick:async()=>{calls.mouse++;doc.activeElement=fields[0];await onClick?.(api);},
 cdp:{send:async(method,p)=>{
  calls.events.push({method,...p});
  if(method==='Input.insertText'){
   const field=fields[0];field.value=field.value.slice(0,field.selectionStart)+p.text+field.value.slice(field.selectionEnd);
   field.selectionStart=field.selectionEnd=field.selectionStart+p.text.length;
  }
  if(p.type==='rawKeyDown'&&p.key==='a'&&p.modifiers===2)fields[0].setSelectionRange(0,fields[0].value.length);
  if(method==='Input.dispatchKeyEvent'&&p.type==='char')fields[0].value+=p.text;
 }}};
 return api;
}

test('RC97 delayed focus confirmation settles without a manual prompt or second click',async()=>{
 let reads=0;
 const h=inputHarness({onClick:({doc})=>{doc.activeElement=null;},onRead:h=>{
  if(h.calls.mouse&&++reads===3)h.doc.activeElement=h.fields[0];
 }});
 const r=await focusInput(h.page,memberId,{wait:async()=>{},manualGate:async()=>h.calls.manual++});
 assert.equal(r.ok,true);assert.equal(h.calls.mouse,1);assert.equal(h.calls.manual,0);
 assert.equal(h.calls.scroll[0],'nearest');
});

test('RC97 ICEfaces replacement gets at most one fresh same-input focus retry',async()=>{
 const h=inputHarness({value:'Example Person',onClick:h=>{if(h.calls.mouse===1)h.replace();}});
 const r=await focusInput(h.page,memberId,{wait:async()=>{},manualGate:async()=>h.calls.manual++});
 assert.equal(r.ok,true);assert.equal(r.method,'TRUSTED_INPUT_REBOUND');
 assert.equal(h.calls.mouse,2);assert.equal(h.calls.manual,0);assert.equal(h.fields[0].value,'Example Person');
});

test('RC97 changed Member content is never clicked again as a focus retry',async()=>{
 const h=inputHarness({value:'Example Person',onClick:h=>{h.replace();h.fields[0].value='Different Person';}});
 const r=await focusInput(h.page,memberId,{wait:async()=>{}});
 assert.equal(r.ok,false);assert.equal(r.state,'INPUT_VALUE_CHANGED_DURING_FOCUS');assert.equal(h.calls.mouse,1);
});

test('RC97 overlay and duplicate IDs cannot become trusted input clicks',async()=>{
 for(const opts of [{covered:true},{duplicate:true}]){
  const h=inputHarness(opts);const r=await focusInput(h.page,memberId,{wait:async()=>{}});
  assert.equal(r.ok,false);assert.equal(h.calls.mouse,0);assert.equal(h.calls.events.length,0);
 }
});

test('RC97 focus coordinate invalidated before click is re-probed without blind click',async()=>{
 const h=inputHarness({onPoint:h=>{h.doc.elementFromPoint=()=>({tagName:'BUTTON'});}});
 const r=await focusInput(h.page,memberId,{wait:async()=>{}});
 assert.equal(r.ok,false);assert.equal(h.calls.mouse,0);
});

test('RC97 focused input fast path leaves geometry and text untouched',async()=>{
 const h=inputHarness({value:'INTL01-11999001 | Example Person',focused:true});
 const r=await focusInput(h.page,memberId,{wait:async()=>{}});
 assert.equal(r.method,'ALREADY_FOCUSED');assert.equal(h.calls.mouse,0);assert.equal(h.calls.scroll.length,0);
});

test('RC97 Member searches use native typing with a real final digit key event',async()=>{
 const h=inputHarness({focused:true});
 assert.equal(await setInputQuery(h.page,memberId,'999001'),true);
 assert.equal(h.fields[0].value,'999001');
 assert.ok(h.calls.events.some(x=>x.method==='Input.insertText'&&x.text==='99900'));
 assert.ok(h.calls.events.some(x=>x.type==='keyUp'&&x.key==='1'&&x.code==='Digit1'));
 assert.equal(h.calls.mouse,0);
});

test('RC97 native search releases Control if selection is interrupted',async()=>{
 const h=inputHarness({focused:true});const raw=h.page.cdp.send;
 h.page.cdp.send=async(m,p)=>{await raw(m,p);if(p.type==='rawKeyDown'&&p.key==='a')throw Error('CDP interruption');};
 await assert.rejects(()=>typeTrustedFixedQuery(h.page,memberId,'Example Person'),/CDP interruption/);
 assert.ok(h.calls.events.some(x=>x.type==='keyUp'&&x.key==='Control'));
 assert.equal(h.fields[0].value,'');
});

function fixedHarness({already=false,subcategoryNeedsMember=false,foreignSignature=false,unstableSignature=false,duplicateSignature=false,codeOnlySignature=false,shortOnlySignature=false,fullOnlySignature=false,delayedSignature=0,resetFilter=false,neverSuggest=false,searchConflict=null,demo=true,auto=false,answer='',manualSelect=false,changeTicketOnManual=false}={}){
 const source=fs.readFileSync(new URL('../src/local-bot-full-run.mjs',import.meta.url),'utf8');
 const a=source.indexOf('async function fixedFields(page,rl){'),b=source.indexOf('/** The send button gets exactly ONE',a);
 assert.ok(a>0&&b>a);
 const ids={category:'mainForm:category-value-id',subcategory:'mainForm:category-sub-value-id',signature:'mainForm:signature-value-id'};
 const fixed={responsibility:'Second Level',category:'Allgemeine Schriftwechsel',subcategory:'Personenschriftwechsel',signature:'INTL01 - Intel Deutschland GmbH'};
 const fields=Object.fromEntries(Object.entries(ids).map(([k,id])=>[id,{id,value:already?fixed[k]:'',tagName:'INPUT',isConnected:true,disabled:false,readOnly:false,getClientRects:()=>[{}]}]));
 fields[memberId]={id:memberId,value:'INTL01-11999001 | Example Person',isConnected:true,tagName:'INPUT'};
 if(foreignSignature)fields[ids.signature].value='FOREIGN SIGNATURE';
 const responsibility={tagName:'SELECT',disabled:false,selectedOptions:[{textContent:fixed.responsibility}]};
 let conflictReads=0,conflictActive=false,conflictInjected=false;
 const doc={activeElement:null,getElementById:id=>id==='mainForm:responsibility-value-id'?responsibility:fields[id],querySelectorAll:()=>{
  if(conflictActive&&['transient','unbound'].includes(searchConflict)){
   if(++conflictReads>=4){fields[ids.signature].value=fixed.signature;conflictActive=false;}
   else if(searchConflict==='unbound')return Object.values(fields).filter(x=>x.id!==ids.signature);
  }
  return Object.values(fields);
 }};
 const calls={focus:[],type:[],query:[],mouse:0,manual:0,logs:[],reads:0};let pending=null;
 const ticket={id:'99900002'};let signatureProbes=0,lastQuery=null;
 const ui={detailTicketId:async()=>ticket.id,focusInput:async(p,id)=>{
  calls.focus.push(id);doc.activeElement=fields[id];
  if(subcategoryNeedsMember&&id===ids.signature&&fields[ids.subcategory].value===fixed.subcategory)fields[ids.subcategory].value='';
  if(subcategoryNeedsMember&&id===memberId&&calls.type.includes(ids.subcategory))fields[ids.subcategory].value=fixed.subcategory;
  return {ok:true};
 },typeTrustedFixedQuery:async(p,id,value,options)=>{calls.type.push(id);
  if(id===ids.signature){assert.equal(options.appendFrom,fields[id].value);await options.beforeAppend();calls.query.push({from:options.appendFrom,to:value});}
  doc.activeElement=fields[id];fields[id].value=value;pending=id;lastQuery=value;
  if(id===ids.signature&&searchConflict&&!conflictInjected){conflictInjected=true;conflictActive=true;fields[id].value='UNEXPECTED DURING RENDER';}
  return 'EXACT';},
  suggestionPoints:async(p,id)=>{
   if(pending!==id)return [];
   const x=Object.values(ids).indexOf(id)+1;
   if(id===ids.signature){
    signatureProbes++;
    if(resetFilter)fields[id].value='';
    if(conflictActive||neverSuggest||resetFilter||signatureProbes<=delayedSignature)return [];
    if(fullOnlySignature&&lastQuery!==fixed.signature)return [];
    if(shortOnlySignature&&lastQuery!==fixed.signature.slice(0,Math.ceil(fixed.signature.length/2)))return [];
    if(codeOnlySignature&&lastQuery!=='INTL01')return [];
    if(duplicateSignature&&signatureProbes<=2)return [{x,y:20},{x:x+25,y:20}];
    if(unstableSignature&&signatureProbes<=3)return [{x:x+signatureProbes*10,y:20}];

   }
   return [{x,y:20}];
  },
  focusEditor:async()=>{doc.activeElement={tagName:'DIV'};return true;},
  fixedFieldValues:async()=>({responsibility:fixed.responsibility,...Object.fromEntries(Object.entries(ids).map(([k,id])=>[k,fields[id].value]))})};
 let clock=0;
 const context=vm.createContext({document:doc,UI:ui,Prep:{FIXED:fixed},diag:{},DEMO:demo,overlay:{gate:{mode:auto?'AUTO':'MANUAL'}},
  need:(ok,code,message)=>{if(!ok)throw Object.assign(Error(message),{code});},
  log:x=>calls.logs.push(x),ask:async()=>{calls.manual++;if(manualSelect){fields[ids.signature].value=fixed.signature;conflictActive=false;}if(changeTicketOnManual)ticket.id='99999999';return answer;},
  sleep:async ms=>{clock+=ms;},Date:{now:()=>clock},
  phase1SignatureState,mayChoosePhase1Signature,mayRetryPhase1Signature});
 const fn=vm.runInContext('('+source.slice(a,b)+')',context);
 const page={call:async(fn,...args)=>{calls.reads++;context.args=args;return vm.runInContext('('+fn.toString()+')(...args)',context);},
  mouseClick:async()=>{calls.mouse++;if(pending===ids.signature)fields[pending].value=fixed.signature;pending=null;}};
 return {run:()=>fn(page,{}),calls,fields,ids,doc,fixed,ticket};
}

test('RC101 restores neutral Member blur for subcategory before signature',async()=>{
 const h=fixedHarness();await h.run();
 assert.deepEqual(h.calls.focus,[memberId,memberId]);
 assert.deepEqual(h.calls.type,[h.ids.category,h.ids.subcategory,h.ids.signature]);
 assert.equal(h.calls.mouse,3);assert.equal(h.calls.manual,0);
 assert.ok(h.calls.logs.includes('PASS FIXED_FIELDS_ALL_VERIFIED'));
 assert.equal(h.fields[memberId].value,'INTL01-11999001 | Example Person');
});

test('RC97 repeated fixed-field checks reuse a same-ticket commit receipt without further focus actions',async()=>{
 const h=fixedHarness({already:true});await h.run();
 assert.deepEqual(h.calls.focus,[memberId]);
 await h.run();
 assert.deepEqual(h.calls.focus,[memberId]);assert.deepEqual(h.calls.type,[]);assert.equal(h.calls.mouse,0);assert.equal(h.calls.manual,0);
 assert.ok(h.calls.logs.some(line=>line.startsWith('PASS FIXED_FIELDS_REUSED_COMMITTED')));
});

test('RC97 a different ticket cannot borrow the prior fixed-field commit receipt',async()=>{
 const h=fixedHarness({already:true});await h.run();h.ticket.id='99900003';await h.run();
 assert.deepEqual(h.calls.focus,[memberId,memberId]);
});

test('RC97 fixed fields still support the existing no-member/no-email clarification route',async()=>{
 const h=fixedHarness({already:true});h.fields[memberId].value='';await h.run();
 assert.equal(h.fields[memberId].value,'');assert.equal(h.calls.type.length,0);
 assert.ok(h.calls.logs.includes('PASS FIXED_FIELDS_ALL_VERIFIED'));
});

test('RC101 legacy subcategory commit uses proven Member focus, no signature race',async()=>{
 const h=fixedHarness({subcategoryNeedsMember:true});await h.run();
 assert.deepEqual(h.calls.focus,[memberId,memberId]);
 assert.equal(h.calls.type.filter(id=>id===h.ids.subcategory).length,1);
 assert.ok(h.calls.logs.includes('PASS FIXED_FIELDS_ALL_VERIFIED'));
});

test('RC97 foreign signature still blocks automatic replacement',async()=>{
 const h=fixedHarness({already:true,foreignSignature:true});
 await assert.rejects(h.run,{code:'FIXED_SIGNATURE_CONFLICT'});
 assert.equal(h.calls.type.length,0);assert.equal(h.calls.mouse,0);
});

for(const variant of ['unstableSignature','duplicateSignature','codeOnlySignature'])test('RC107 signature recovers '+variant+' without manual or extra option click',async()=>{
 const h=fixedHarness({[variant]:true});await h.run();assert.equal(h.calls.manual,0);assert.equal(h.calls.mouse,3);
 assert.ok(h.calls.logs.some(x=>x.startsWith('PASS P1_SIGNATURE_EXACT_OPTION_CLICK')));
 assert.ok(h.calls.logs.includes('PASS FIXED_FIELDS_ALL_VERIFIED'));
});

for(const variant of ['transient','unbound'])test('RC118 waits for '+variant+' signature after first search and still commits one exact option',async()=>{
 const h=fixedHarness({searchConflict:variant,demo:false});await h.run();
 assert.equal(h.calls.manual,0);assert.equal(h.calls.mouse,3);
 assert.ok(h.calls.logs.some(x=>x.startsWith('PASS P1_SIGNATURE_TRANSIENT_RECOVERED:')));
 assert.ok(h.calls.logs.includes('PASS FIXED_FIELDS_ALL_VERIFIED'));
});
test('RC118 genuine foreign signature: manual correction is verified, no bot overwrite',async()=>{
 const h=fixedHarness({foreignSignature:true,already:true,demo:false,manualSelect:true});await h.run();
 assert.equal(h.calls.manual,1);assert.equal(h.calls.type.length,0);assert.equal(h.calls.mouse,0);
 assert.ok(h.calls.logs.includes('PASS FIXED_FIELDS_ALL_VERIFIED'));
});
test('RC118 genuine foreign signature: manual skip is ticket-bound with no overwrite',async()=>{
 const h=fixedHarness({foreignSignature:true,already:true,demo:false,answer:'UEBERSPRINGEN'});
 await assert.rejects(h.run,e=>e.code==='FIXED_FIELD_REVIEW_REQUIRED'&&e.fixedReview.signatureReview===true&&e.fixedReview.ticketId===h.ticket.id);
 assert.equal(h.calls.manual,1);assert.equal(h.calls.type.length,0);assert.equal(h.calls.mouse,0);
 assert.equal(h.fields[h.ids.signature].value,'FOREIGN SIGNATURE');
});
test('RC118 persistent conflicting search in AUTO: no confirmation and no additional click',async()=>{
 const h=fixedHarness({searchConflict:'persistent',demo:false,auto:true});
 await assert.rejects(h.run,e=>e.code==='FIXED_FIELD_REVIEW_REQUIRED'&&e.fixedReview.reason==='FIXED_SIGNATURE_CONFLICT');
 assert.equal(h.calls.manual,0);assert.equal(h.calls.type.filter(x=>x===h.ids.signature).length,1);assert.equal(h.calls.mouse,2);
});
test('RC118 manual correction cannot carry approval to another ticket',async()=>{
 const h=fixedHarness({foreignSignature:true,already:true,demo:false,manualSelect:true,changeTicketOnManual:true});
 await assert.rejects(h.run,{code:'FIXED_TICKET_BINDING'});assert.equal(h.calls.mouse,0);
});
test('RC118 explicit ABBRUCH remains a real run stop',async()=>{
 const h=fixedHarness({foreignSignature:true,already:true,demo:false,answer:'ABBRUCH'});
 await assert.rejects(h.run,{code:'OPERATOR_ABORT'});assert.equal(h.calls.mouse,0);
});

test('RC119 delayed signature popup yields one query and one exact option click',async()=>{
 const h=fixedHarness({delayedSignature:20});await h.run();
 assert.deepEqual(h.calls.query,[{from:'',to:'INTL01'}]);assert.equal(h.calls.mouse,3);assert.equal(h.calls.manual,0);
});
test('RC119 filter refinement appends to the same code without replacing it',async()=>{
 const h=fixedHarness({shortOnlySignature:true});await h.run();
 assert.deepEqual(h.calls.query,[{from:'',to:'INTL01'},{from:'INTL01',to:h.fixed.signature.slice(0,Math.ceil(h.fixed.signature.length/2))}]);
 assert.equal(h.calls.mouse,3);assert.equal(h.calls.manual,0);
});
test('RC119 form clearing a filter cannot cause another typing cycle',async()=>{
 const h=fixedHarness({resetFilter:true,demo:false,auto:true});
 await assert.rejects(h.run,{code:'FIXED_FIELD_REVIEW_REQUIRED'});
 assert.deepEqual(h.calls.query,[{from:'',to:'INTL01'}]);assert.equal(h.calls.mouse,2);assert.equal(h.calls.manual,0);
});
test('RC119 an uncommitted search can never pass as the full signature',async()=>{
 const h=fixedHarness({neverSuggest:true,demo:false,auto:true});
 await assert.rejects(h.run,{code:'FIXED_FIELD_REVIEW_REQUIRED'});
 assert.equal(h.calls.query.at(-1).to,h.fixed.signature);
 assert.equal(h.calls.mouse,2);assert.equal(h.calls.manual,0);
});
test('RC119 native filter refinement preserves text and uses no select-all or delete',async()=>{
 const h=inputHarness({value:'INTL01',focused:true});h.fields[0].setSelectionRange(0,2);
 const result=await typeTrustedFixedQuery(h.page,memberId,'INTL01 - Intel',{appendFrom:'INTL01'});
 assert.equal(result,'EXACT');assert.equal(h.fields[0].value,'INTL01 - Intel');
 assert.ok(!h.calls.events.some(e=>['a','Control','Delete','Backspace'].includes(e.key)));
 assert.equal(h.calls.events.find(e=>e.method==='Input.insertText').text,' - Inte');
});
test('RC119 a changed value during native filter focus is left untouched',async()=>{
 const h=inputHarness({value:'Other',focused:true});
 await assert.rejects(typeTrustedFixedQuery(h.page,memberId,'INTL01 - Intel',{appendFrom:'INTL01'}),{code:'FIXED_QUERY_MISMATCH'});
 assert.equal(h.fields[0].value,'Other');assert.equal(h.calls.events.length,0);
});

test('RC119 pressing ENTER on a typed full label cannot attest a missing option',async()=>{
 const h=fixedHarness({neverSuggest:true,demo:false,answer:''});
 await assert.rejects(h.run,{code:'FIXED_FIELD_REVIEW_REQUIRED'});
 assert.equal(h.fields[h.ids.signature].value,h.fixed.signature);assert.equal(h.calls.manual,1);assert.equal(h.calls.mouse,2);
});

test('RC119 exact option can appear only after the last suffix; the actual row must be clicked',async()=>{
 const h=fixedHarness({fullOnlySignature:true});await h.run();
 const short=h.fixed.signature.slice(0,Math.ceil(h.fixed.signature.length/2));
 assert.deepEqual(h.calls.query,[{from:'',to:'INTL01'},{from:'INTL01',to:short},{from:short,to:h.fixed.signature}]);
 assert.equal(h.calls.mouse,3);assert.equal(h.calls.manual,0);
 assert.ok(h.calls.logs.some(line=>line.startsWith('PASS P1_SIGNATURE_EXACT_OPTION_CLICK: SIGNATURE_FULL_SUFFIX')));
});
