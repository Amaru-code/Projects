import {assertLiveWorkbookCurrent} from '../lib/live-workbook.mjs';
/** RC39 independent PHASE-2 supervised ONE-TICKET pilot. No Phase-1 send
 * orchestration, no automatic rerun, no arbitrary PDF generation.
 * Supports only an earlier operator-reviewed proof for DC and/or PP+.
 */
import fs from 'node:fs';import path from 'node:path';import readline from 'node:readline/promises';
import {fileURLToPath} from 'node:url';
import {applyEnterApproval} from '../lib/operator-enter.mjs';import {requireThat as need} from '../lib/core.mjs';
import {readJSON,writeJSON,plainPath,ledger,stamp} from '../lib/control.mjs';
import {resolveConfig} from '../lib/config.mjs';import {loadActiveMapping} from '../lib/active-mapping.mjs';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachFreshPage,sleep} from '../lib/cdp.mjs';
import {phase2BlockingIds,phase2Admission} from '../lib/phase2-admission.mjs';
import {phase2Inventory,readPhase2Queue,classifyPhase2Row} from '../lib/phase2-readonly.mjs';
import {verifyLegacyPlanAlias} from './phase2-pdf-prepare.mjs';
import {phase2WorkRule} from '../lib/phase2-work-rules.mjs';
import {inspectExistingStatements,documentWwidFromFilename,statementArtifactWwid} from '../lib/phase2-pdf-evidence.mjs';
import {hasAutomaticAoPreparation,hasAutomaticDocumentPreparation,inspectPreparedStatements} from '../lib/phase2-ao-proof.mjs';
import {assertCentralAoMemberBinding,createPhase2BoundTicketGuard} from '../lib/phase2-ao-member-binding.mjs';
import {createHash} from 'node:crypto';
import {phase2DraftPreview} from '../lib/phase2-draft-preview.mjs';
import {readPhase2MemberEvidence} from '../lib/phase2-member-evidence.mjs';
import {resolveMemberMapping} from '../lib/member-mapping.mjs';
import {prepareMbcDraft,applyMbcDraft,verifyMbcDraft,readMbcDraft,classifyMbcDraft} from '../lib/phase2-mbc-draft.mjs';
import {statementDraft,saveStatementDraftAndAcknowledge,statementDraftDigest} from '../lib/phase2-statement-draft.mjs';
import {phase2Journal,digestDescription} from '../lib/phase2-write-journal.mjs';
import {setPhase2Gevo,selectReviewMode,
 selectReviewAssignee,savePhase2Draft,savePhase2Ticket,executeReview,phase2FieldSnapshot,reviewAssignmentState,recoverUnsavedPhase2Gevo} from '../lib/phase2-comarch-actions.mjs';
import {forwardingNotices,forwardConfirmed} from '../lib/forwarding.mjs';
import {watchPhase2Save} from '../lib/phase2-save-settle.mjs';
import {phase2SaveReadbackStatus} from '../lib/phase2-save-readback.mjs';
import {canReuseCurrentPdfApproval} from '../lib/phase2-pdf-approval.mjs';
import {ensurePhase2UploadSurface,phase2AttachmentEvidence,attachPhase2Files,phase2ReviewableAttachmentEvidence} from '../lib/phase2-filepond.mjs';
import {planPhase2UploadContinuation} from '../lib/phase2-upload-continuation.mjs';
import * as UI from '../lib/browser-workflow.mjs';
import {ensurePhase2Edit} from '../lib/phase2-edit-mode.mjs';
import {openPhase2Ticket} from '../lib/phase2-navigation.mjs';
import {finishPhase2Route} from '../lib/phase2-review-flow.mjs';
import {readBoundDraftDescription,verifyBoundDraftDescription,reconcileDraftDescription} from '../lib/phase2-draft-description.mjs';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const normalize=s=>String(s??'').replace(/\r\n?/g,'\n').trim();
async function ask(rl,q){return applyEnterApproval(q,await rl.question(q));}
function phase2Dir(root){const p=path.join(root,'.runtime','phase2');plainPath(p);return p;}
function proofForTicket(root,id,{paths,expectedProofFile=null}={}){
 const dir=phase2Dir(root),files=fs.readdirSync(dir).filter(f=>f.startsWith('MCR_PHASE2_PDF_BELEG_'+id+'_')&&f.endsWith('.json')).sort().reverse();
 need(files.length,'P2_PDF_PROOF_REQUIRED','PDF-Vorbereitung im aktiven Lauf erforderlich.');
 const selectedFile=expectedProofFile||path.join(dir,files[0]);
 need(path.dirname(selectedFile)===dir&&files.includes(path.basename(selectedFile)),'P2_AO_FRESHNESS_REQUIRED','Aktueller Ticket-PDF-Beleg fehlt.');
 const proof=readJSON(selectedFile,256*1024);
 need(proof.schema==='MCR_PHASE2_PDF_PROOF_V1'&&proof.ticketId===id&&
  ((proof.operatorContentReviewed===true&&proof.operatorPersonTicketBindingReviewed===true)||hasAutomaticDocumentPreparation(proof)),
  'P2_PDF_PROOF_INVALID','PDFs nicht ausreichend geprueft.');
 need(Date.now()-Date.parse(proof.verifiedAt)<7*24*60*60*1000,'P2_PDF_PROOF_OLD','PDF-Inhaltspruefung veraltet, Menue 11 erneut ausfuehren.');
 const ids=(proof.artifacts||[]).map(x=>x.statementReceipt?statementArtifactWwid(x):documentWwidFromFilename(x.plan,x.name));
 need(ids.length===proof.artifacts.length&&ids.every(Boolean)&&new Set(ids).size===1,
  'P2_WWID_FILENAMES','Nur exakte WWID-Dateinamen mit identischer Personkennung.');
 const wwid=ids[0];
 need(proof.wwidSha256===createHash('sha256').update(wwid).digest('hex'),'P2_WWID_PROOF_CHANGED','PDF-WWID stimmt nicht mit freigegebenem Nachweis ueberein.');
 const verified=inspectPreparedStatements(root,proof,{wwid,...(paths?{paths}:{})});
 need(verified.artifacts.length===proof.artifacts.length&&verified.artifacts.every((a,i)=>{
  const expected=proof.artifacts.find(x=>x.plan===a.plan);return expected&&expected.sha256===a.sha256&&expected.bytes===a.bytes&&expected.name===a.name;
 }), 'P2_PDF_CHANGED','Pruefbelege oder PDFs wurden seit Menue 11 veraendert.');
 return {proof,verified,wwid};
}
/** Read-only RC49 canonicalization for a pending RC48 save. A saved marker
 * may have appeared during Entwurf speichern; only a bound old journal can
 * reconstruct the original, and only if its complete digest still matches. */
export function restorePendingSaveCandidate(item,previous){
 if(item?.kind!=='ALREADY_PREPARED'||!['DRAFT_SAVE_INTENT','TICKET_SAVE_INTENT','TICKET_SAVE_VERIFIED','REVIEW_INTENT','REVIEW_VERIFIED'].includes(previous?.state))return item;
 if(!['DRAFT_SAVE_INTENT','TICKET_SAVE_INTENT'].includes(previous.state)&&(previous.schema!=='MCR_PHASE2_ACTION_JOURNAL_V1'||!previous.events?.some(e=>e.state==='TICKET_SAVE_VERIFIED')||previous.events?.some(e=>e.state==='EXECUTE_INTENT')))return item;
 const lines=String(item.descriptionValue||'').replace(/\r\n?/g,'\n').replace(/\n+$/,'').split('\n');
 need(lines.at(-1)?.trim()==='Bearbeitet not reviewed'&&
  lines.filter(x=>x.trim()==='Bearbeitet not reviewed').length===1,
  'P2_SAVE_RECOVERY_MARKER','Keine einzelne exakt angehaengte Statuszeile im Server-Ticket.');
 const original=lines.slice(0,-1).join('\n');
 need(digestDescription(original)===previous.descriptionSha256,'P2_SAVE_RECOVERY_DESCRIPTION_HASH',
  'Die urspruengliche Ticketbeschreibung stimmt nicht mit dem unveraenderten Journal ueberein.');
 const classified=classifyPhase2Row({...item,descriptionValue:original});
 need(classified.kind==='NEEDS_VERIFIED_WWID','P2_SAVE_RECOVERY_SOURCE',
  'Das Server-Ticket ist nicht mehr derselbe Kontoauszug-Vorgang.');
 return {...item,kind:classified.kind,targets:classified.targets,descriptionValue:original,
  preexistingSavedMarker:true};
}

export function preflightPhase2Write(root,ticketId,options={}){
 const inventory=readJSON(path.join(phase2Dir(root),'MCR_PHASE2_LETZTE_INVENTUR.json'),2*1024*1024);
 need(inventory?.schema==='MCR_PHASE2_INVENTORY_V1'&&inventory.readOnly,'P2_INVENTORY_REQUIRED','Menue 9 erneut ausfuehren.');
 need(Date.now()-Date.parse(inventory.generatedAt)<60*60*1000,'P2_INVENTORY_STALE','Bitte frische Inventur ueber Menue 9.');
 let item=inventory.items.find(x=>x.ticketId===ticketId);
 // Entwurf speichern may already persist the fourth line. Never infer an
 // original ticket text except by exact match to the existing save journal.
 const previous=phase2Journal(root,ticketId).read();
 item=restorePendingSaveCandidate(item,previous);
 need(item?.kind==='NEEDS_VERIFIED_WWID','P2_TICKET_BLOCKED','Kein eindeutig vorbereiteter Kontoauszug-Kandidat.');
 need(phase2Admission({...item,descriptionValue:item.descriptionValue},ledger(root).pending).allowed,'P2_PHASE1_JOURNAL_PENDING','Beschreibung oder offene Weiterleitungsaktion erlaubt keine Phase 2.');
 const {proof,verified,wwid}=proofForTicket(root,ticketId,options);
 need(item.targets.length===proof.targets.length&&item.targets.every(x=>proof.targets.includes(x)),
  'P2_PLAN_CONFLICT','COMARCH-Planarten und PDF-Pruefung widersprechen sich.');
 const preview=phase2DraftPreview({ticketId,source:item.source,description:item.descriptionValue,pdfProof:proof});
 const initial={ticketId,descriptionSha256:digestDescription(item.descriptionValue),pdfHashes:proof.artifacts.map(x=>({plan:x.plan,sha256:x.sha256,...(x.statementReceipt?{outputName:x.name}:{})}))};
 const journal=phase2Journal(root,ticketId,{initial});
 const existing=journal.read();
 // RC45 also permits inspection of an upload-first interruption. This does
 // not authorize a file selection: current attachments and the operator's
 // independent review must be reconciled below before the journal advances.
 const recoveryMode=!existing?null:journal.mayRetryGevoFocus(initial)?'GEVO_FOCUS':
  journal.mayReconcileUpload(initial)?'UPLOAD_RECONCILIATION':
  journal.mayResumeUnclickedDraft(initial)?'DRAFT_BEFORE_CLICK':
  journal.mayRecoverTicketSave(initial)?'TICKET_SAVE_ONLY':
  journal.mayRecoverRc50UnconfirmedSave(initial)?'RC50_UNCONFIRMED_SAVE':
  journal.mayInspectPersistedSave(initial)?'SERVER_READBACK_ONLY':null;
 const recoveryNeeded=!!existing;
 need(!existing||recoveryMode,'P2_ALREADY_ATTEMPTED',
  'Phase-2-Aktion begonnen oder abgeschlossen. Nur ein genau gepruefter Fokus-, Upload- oder vor dem Speicherklick abgebrochener Phase-2-Schritt ist kontrolliert fortsetzbar.');
 return {item,proof,verified,wwid,preview,journal,initial,recoveryNeeded,recoveryMode};
}

/** Intentionally every stage is a distinct monotonic ledger state.
 * Browser/OS crashes leave the last INTENT state requiring manual review.
 */
export async function phase2ComarchPilot({root=ROOT,askFn=ask,log=console.log,memberLookup=readPhase2MemberEvidence,ticketId=null,session=null,reviewAuthorized=false,pdfReviewedThisRun=false,controls=null,routeListBefore=null,expectedProofFile=null}={}){
 const activeMapping=loadActiveMapping(root);
 const rl=session?.rl||readline.createInterface({input:process.stdin,output:process.stdout});
 let browser=null,cdp=null,armed=false;
 try{
  log('\nPHASE 2: Vorbereitete Dokumente am Ticket pruefen, speichern und intern weiterleiten.');
  const id=ticketId||await askFn(rl,'Vorbereitetes Kontoauszug-Ticket (z.B. 87278094): ');
  const openTicket=(row)=>openPhase2Ticket(page,row,{log,manualOpen:async(id)=>{
   log('Im Bot-Edge nur Ticket '+id+' oeffnen; NICHT speichern oder weiterleiten.');
   need((await askFn(rl,'Ticket geoeffnet? OFFEN / ABBRUCH: ')).toUpperCase()==='OFFEN','P2_OPEN_ABORT','Ticket nicht geoeffnet.');
  }});
  need(/^\d{6,12}$/.test(id),'P2_TICKET_ID','Ticketnummer erforderlich.');
  const {item,proof,verified,wwid,preview,journal,initial:journalInput,recoveryMode}=preflightPhase2Write(root,id,{expectedProofFile});
  if(item.targets.some(p=>p!=='AO')&&!journal.read())need(pdfReviewedThisRun&&expectedProofFile&&
   proof.artifacts.filter(a=>a.plan!=='AO').every(a=>statementArtifactWwid(a)===wwid),'P2_KONTOAUSZUG_AUDIT_REQUIRED','Neuer Kontoauszugsauftrag benoetigt den Erzeugungsbeleg dieses Laufs.');
  if(item.targets.includes('AO')&&!journal.read())need(pdfReviewedThisRun&&expectedProofFile&&proof.artifacts.find(a=>a.plan==='AO')?.generation?.freshness?.schema==='MCR_AO_FRESH_GENERATION_V1','P2_AO_FRESHNESS_REQUIRED','Neue AO nur aus aktueller Berechnung; kein alter Beleg als Ersatz.');
  log('TICKET '+id+' | '+item.targets.join('+')+' | '+wwid+' | '+verified.artifacts.map(x=>x.name).join(' + '));
  let page=session?.page;
  if(!page){
   const cfg=resolveConfig(root),exe=findEdgeExecutable(cfg.edgePath);need(exe,'P2_EDGE','Edge fehlt.');
   browser=await launchBrowser({executable:exe,userDataDir:cfg.profileDirectory,startUrl:'about:blank'});
   ({cdp}=await connectBrowser(browser.port));page=await attachFreshPage(cdp,cfg.comarchUrl);
   need((await askFn(rl,'In Bot-Edge anmelden. COMARCH bereit? START / ABBRUCH: ')).toUpperCase()==='START',
    'P2_OPERATOR_ABORT','Keine Bearbeitung gestartet.');
  }
  await UI.navigateToScope(page,'IN_BEARBEITUNG',{startup:true});
  const raw=await readPhase2Queue(page);need(raw.ok,'P2_QUEUE',raw.reason||'COMARCH-Vorgangsliste nicht lesbar.');
  const row=raw.rows.find(x=>x.ticketId===id);need(row,'P2_NOT_IN_TASKS','Ticket ist nicht mehr in Meine Vorgaenge.');
  const same=phase2Inventory([row],{pendingIds:phase2BlockingIds([row],ledger(root).pending)}).items[0];
  const sameOriginal=same.kind==='NEEDS_VERIFIED_WWID'&&normalize(row.descriptionValue)===normalize(item.descriptionValue);
  const saveRecoveryMode=['DRAFT_BEFORE_CLICK','TICKET_SAVE_ONLY','RC50_UNCONFIRMED_SAVE','SERVER_READBACK_ONLY'].includes(recoveryMode);
  const sameSaved=saveRecoveryMode&&item.preexistingSavedMarker===true&&
   same.kind==='ALREADY_PREPARED'&&normalize(row.descriptionValue)===normalize(preview.descriptionAfter);
  need(sameOriginal||sameSaved,'P2_TICKET_CHANGED','Ticketstatus/Anfrage veraendert. Bitte Menue 9 erneut.');
  await openTicket(row);await UI.assertTicket(page,id);await controls?.readDetail?.(page,id);
  const member=await memberLookup(page);
  need(member.profileVerified&&member.profile?.first&&member.profile?.last,'P2_MEMBER_NOT_BOUND','Kein eindeutiges COMARCH-Memberprofil.');
  assertCentralAoMemberBinding({proof,member,ticketId:id,wwid});
  verifyLegacyPlanAlias(phase2WorkRule({...row,descriptionValue:item.descriptionValue}),member,activeMapping.map);
  need(!member.wwid||member.wwid===wwid,'P2_WWID_MISMATCH','Explizite COMARCH-WWID unterscheidet sich aller PDFs.');
  need(member.wwid||!member.memberReferenceWwid||member.memberReferenceWwid===wwid,'P2_MEMBER_REFERENCE_MISMATCH',
   'INTL01-Referenz aus dem ausgewaehlten Member stimmt nicht mit der bereits geprueften PDF-WWID ueberein.');
  await ensurePhase2Edit(page,{ticketId:id,ask:q=>askFn(rl,q),log});
  const expectedFixed={responsibility:'Second Level',category:'Allgemeine Schriftwechsel',subcategory:'Personenschriftwechsel'};
  const fixedOkay=f=>Object.entries(expectedFixed).every(([k,v])=>String(f?.[k]||'').trim()===v);
  if(!fixedOkay(await UI.fixedFieldValues(page))){
   log('PFLICHTFELDER: In COMARCH Second Level / Allgemeine Schriftwechsel / Personenschriftwechsel exakt setzen. Keine E-Mail senden.');
   need((await askFn(rl,'Pflichtfelder geprueft? ENTER / ABBRUCH: ')).toUpperCase()!=='ABBRUCH',
    'P2_OPERATOR_ABORT','Pflichtfelder nicht freigegeben.');
  }
  need(fixedOkay(await UI.fixedFieldValues(page)),'P2_FIXED_FIELDS','COMARCH-Pflichtfelder nicht eindeutig eingestellt.');
  const initial=await UI.additionalDescriptionState(page);
  need(initial.ok&&initial.editable&&
   (normalize(initial.value)===normalize(item.descriptionValue)||
    (saveRecoveryMode&&normalize(initial.value)===normalize(preview.descriptionAfter))),
   'P2_DESCRIPTION_CHANGED','Ticketbeschreibung weicht vom genehmigten Original oder der genau einmal ergaenzten Statuszeile ab.');
  // A surname or first name is not a reliable gender indicator. Use only
  // the active verified worksheet's consistent gender, or ask once.
  let statementReply=null;
  const makeStatementReply=async()=>{
   if(statementReply)return statementReply;
   const resolved=resolveMemberMapping(activeMapping.map,member.profile.mercerId);
   let gender=resolved.entry?.genderStatus==='CONSISTENT'?resolved.entry.gender:null;
   if(!['M','F'].includes(gender)){
    log('P2_KA_ANREDE_NICHT_EINDEUTIG: Aus verifizierten Unterlagen bestaetigen, nicht aus dem Vornamen ableiten.');
    const answer=String(await askFn(rl,'Anrede aus den Unterlagen: HERR / FRAU / ABBRUCH: ')).toUpperCase();
    need(['HERR','FRAU'].includes(answer),'P2_KA_SALUTATION_REQUIRED','Keine verifizierte Anrede, kein Entwurf.');
    gender=answer==='HERR'?'M':'F';
   }
   statementReply=statementDraft({lastName:member.profile.last,gender,targets:item.targets});
   return statementReply;
  };
  // All writes to the reply editor go through the pre-existing exact-ticket
  // CAS writer. A foreign draft requires an independently backed-up consent.
  const prepareStatementReply=async()=>prepareMbcDraft({root,page,ticketId:id,
   draft:await makeStatementReply(),ask:q=>askFn(rl,q),controls,log,purpose:'Kontoauszug'});
  const verifyBoundDescription=(opts={})=>verifyBoundDraftDescription(page,id,preview.descriptionAfter,{bind:bound,...opts});
  const beforeDraftDescription=async()=>{
   const events=journal.read().events;
   let state=await reconcileDraftDescription(page,{ticketId:id,original:item.descriptionValue,expected:preview.descriptionAfter,bind:bound,log,
    allowRestore:!events.some(e=>e.state==='KA_PRE_DRAFT_DESCRIPTION_RESTORE_INTENT'),
    beforeRestore:()=>journal.recordStatementDraftEvent('KA_PRE_DRAFT_DESCRIPTION_RESTORE_INTENT'),
    afterRestore:()=>journal.recordStatementDraftEvent('KA_PRE_DRAFT_DESCRIPTION_RESTORED')});
   if(state.kind==='EXPECTED')return;
   log('P2_DESCRIPTION_REVIEW_REQUIRED: '+id+' | '+state.kind+' | erste abweichende Zeile: '+(state.firstDifferentLine??'?')+' | kein Speicherklick.');
   // Show the discrepancy only in the current local console, not in the
   // structured log/diagnostic export. Strip console control sequences.
   const printable=v=>JSON.stringify(String(v??'').slice(0,500));
   if(state.kind!=='UNREADABLE')process.stdout.write('Erwartete Beschreibung: '+printable(preview.descriptionAfter)+'\nAktuelle Beschreibung: '+printable(state.value)+'\n');
   log('Im richtigen Ticket pruefen. Nur unveraenderten Originalauftrag und exakt eine Statuszeile wiederherstellen. Keine andere Aktion ausloesen.');
   const answer=String(await askFn(rl,'Beschreibung im Ticket geprueft und exakt wiederhergestellt? BESCHREIBUNG_GEPRUEFT / UEBERSPRINGEN / ABBRUCH: ')).toUpperCase();
   need(answer!=='UEBERSPRINGEN','P2_DRAFT_DESCRIPTION_DEFERRED','Ticket bewusst zur Pruefung zurueckgestellt; kein Entwurf-Speicherklick.');
   need(answer==='BESCHREIBUNG_GEPRUEFT','P2_DRAFT_DESCRIPTION_REVIEW_REQUIRED','Beschreibung nicht freigegeben. Journal und Anlage bleiben zur Pruefung erhalten.');
   need(await verifyBoundDescription(),'P2_DRAFT_DESCRIPTION_REVIEW_REQUIRED','Beschreibung auch nach Sichtpruefung nicht exakt; kein Speicherklick.');
  };
  const saveStatementReply=async({legacy=false,recover=false}={})=>{
   const draft=await makeStatementReply();
   let plan;
   if(recover){
    const expectedHash=journal.read().events.find(e=>e.state==='KA_DRAFT_WRITE_INTENT')?.draftSha256;
    need(expectedHash===statementDraftDigest(draft),'P2_DRAFT_RECOVERY_TEXT_HASH','Frueherer Entwurf stimmt nicht exakt mit dem aktuellen Entwurf ueberein. Kein Speichern.');
    const snapshot=await readMbcDraft(page,id),kind=classifyMbcDraft(snapshot,draft);
    need(kind==='EMPTY'||kind==='MATCH','P2_DRAFT_RECOVERY_TEXT_CONFLICT','Vorhandener Entwurf weicht ab. Keine Ersetzung.');
    plan={kind,snapshot,draft,replaceAuthorized:false};
   }else plan=await prepareStatementReply();
   need(plan.kind!=='SKIP','P2_KA_DRAFT_SKIPPED','Entwurf nicht freigegeben. Keine weitere Bearbeitung.');
   const writeEvent=legacy?'KA_LEGACY_DRAFT_WRITE_INTENT':recover?'KA_DRAFT_RECOVERY_WRITE_INTENT':'KA_DRAFT_WRITE_INTENT';
   if(!recover||plan.kind==='EMPTY')await applyMbcDraft(page,{ticketId:id,plan,beforeWrite:async()=>{
    await bound();journal.recordStatementDraftEvent(writeEvent,{draftSha256:statementDraftDigest(draft),confirmed:legacy});
   }});
   need(await verifyMbcDraft(page,id,draft),'P2_KA_DRAFT_NOT_EXACT','Kontoauszug-Entwurf nicht exakt im Haupttextfeld.');
   if(!legacy&&!recover)journal.advance('DRAFT_SAVE_INTENT');
   if(!legacy)await beforeDraftDescription();
   const clickEvent=legacy?'KA_LEGACY_DRAFT_CLICK_INTENT':'KA_DRAFT_CLICK_INTENT';
   await saveStatementDraftAndAcknowledge(page,{ticketId:id,log,beforeClick:async()=>{
    await bound();assertUnchanged();
    need(await verifyMbcDraft(page,id,draft),'P2_KA_DRAFT_CHANGED_BEFORE_CLICK','Antworttext vor Entwurf-Speichern veraendert.');
    need(await verifyBoundDescription(),'P2_KA_DESCRIPTION_CHANGED_BEFORE_CLICK','Gebundene Beschreibung vor Entwurf-Speichern veraendert.');
    const g=await phase2FieldSnapshot(page);
    need(g.gevo.count===1&&g.gevo.visible&&g.gevo.value==='Anfrage Member','P2_KA_PRE_DRAFT_GEVO_CHANGED','Anfrage Member vor Entwurf-Speichern nicht exakt.');
    need(await stagingPresent(),'P2_KA_PRE_DRAFT_PDFS_CHANGED','Anlagen vor Entwurf-Speichern nicht eindeutig sichtbar.');
    journal.recordStatementDraftEvent(clickEvent);
   }});
   journal.recordStatementDraftEvent(legacy?'KA_LEGACY_DRAFT_OK_VERIFIED':'KA_DRAFT_OK_VERIFIED');
   // COMARCH may rebuild the entire ICEfaces form after draft save. The old
   // marker can disappear from the live editor even though original text is
   // unchanged on the server. Restore it only if exactly the 3 original lines
   // remain; never overwrite an unrelated edit, and never click Draft Save twice.
   await bound();
   const current=await UI.additionalDescriptionState(page);
   need(current.ok&&current.editable,'P2_KA_POST_DRAFT_DESCRIPTION_UNREADABLE','Beschreibung nach Entwurf nicht eindeutig lesbar.');
   if(normalize(current.value)===normalize(item.descriptionValue)){
    journal.recordStatementDraftEvent(legacy?'KA_LEGACY_DESCRIPTION_RESTORE_INTENT':'KA_POST_DRAFT_DESCRIPTION_RESTORE_INTENT');
    const restored=await UI.appendStandardAnswerMarker(page,'Bearbeitet not reviewed',{expectedOriginal:current.value});
    need(restored.ok&&normalize(restored.value)===normalize(preview.descriptionAfter),
     'P2_KA_POST_DRAFT_DESCRIPTION_RESTORE_FAILED','Nur die Statuszeile darf erneut in den Editor gesetzt werden.');
    journal.recordStatementDraftEvent(legacy?'KA_LEGACY_DESCRIPTION_RESTORED':'KA_POST_DRAFT_DESCRIPTION_RESTORED');
    log('PASS P2_KA_POST_DRAFT_MARKER_RESTORED: Nur Editorstatus nach ICEfaces-Aktualisierung erneuert; kein Speicherklick.');
   }else need(normalize(current.value)===normalize(preview.descriptionAfter),
    'P2_KA_POST_DRAFT_DESCRIPTION_CONFLICT','Fremde Beschreibung nach Entwurf; kein Ueberschreiben.');
   need(await verifyBoundDescription(),
    'P2_KA_POST_DRAFT_DESCRIPTION_UNVERIFIED','Statuszeile nach Entwurf-Speichern noch nicht exakt.');
   const g=await phase2FieldSnapshot(page);
   need(g.gevo.count===1&&g.gevo.visible&&g.gevo.value==='Anfrage Member',
    'P2_KA_POST_DRAFT_GEVO_CHANGED','COMARCH hat GEVO nach Entwurf-Speichern geaendert. Kein Ticket-Speicherklick.');
   need(await stagingPresent(),'P2_KA_POST_DRAFT_PDFS_CHANGED','PDFs nach Entwurf-Speichern nicht mehr sichtbar.');
   need(await verifyMbcDraft(page,id,draft),'P2_KA_POST_DRAFT_TEXT_CHANGED','Antwortentwurf nach Dialog nicht mehr exakt. Kein Ticket-Speicherklick.');
   log('PASS P2_KA_DRAFT_EDITOR_AND_OK_VERIFIED: Text und Dialog behandelt; kein E-Mail-Versand.');
   if(!legacy)journal.advance('DRAFT_SAVE_VERIFIED');
  };
  const names=verified.artifacts.map(a=>a.name);
  const bound=createPhase2BoundTicketGuard({proof,page,ticketId:id,wwid,memberLookup,assertTicket:UI.assertTicket});
  const assertUnchanged=()=>{assertLiveWorkbookCurrent(root,activeMapping);const now=inspectPreparedStatements(root,proof,{wwid});
   need(now.artifacts.length===verified.artifacts.length&&now.artifacts.every(a=>{
    const p=verified.artifacts.find(x=>x.plan===a.plan);return p?.sha256===a.sha256&&p?.bytes===a.bytes;
   }),'P2_PDF_CHANGED','PDF-Dateien seit Freigabe geaendert. Keine weitere COMARCH-Aktion.');};
  const currentUploadPlan=async()=>{
   const evidence=await phase2AttachmentEvidence(page,names);
   try{return planPhase2UploadContinuation({artifacts:verified.artifacts,evidence,
    resumeUpload:recoveryMode==='UPLOAD_RECONCILIATION'});}
   catch(e){log('P2_ATTACHMENT_EVIDENCE: '+JSON.stringify({rootCount:evidence.rootCount,items:evidence.items}));throw e;}
  };
  let operatorUiApproved=false,operatorServerReviewed=false;
  // Shared with save-only recovery: no second upload or unverified save.
  const stagingPresent=async()=>{
   const e=await phase2AttachmentEvidence(page,names);
   return e.allReady||(operatorUiApproved&&phase2ReviewableAttachmentEvidence(e,names));
  };
  const saveManual=async(rc80Repair=false)=>{
   assertLiveWorkbookCurrent(root,activeMapping);
   if(rc80Repair)journal.recordRc80MarkerRepairClickIntent('MANUAL');
   else journal.recordTicketSaveManualIntent();
   log('P2_SPEICHERN_MANUELL: Ticket speichern ist trotz passiver Scroll-/Hit-Test-Pruefung verdeckt.');
   log('Im EIGENEN Bot-Edge genau EINMAL Ticket speichern anklicken. Der Bot fuehrt dann KEINEN weiteren Speicherklick aus.');
   need((await askFn(rl,'Genau ein manueller Speicherklick ausgefuehrt? EINMAL_GEKLICKT / ABBRUCH: ')).toUpperCase()==='EINMAL_GEKLICKT',
    'P2_SAVE_CLICK_UNCLEAR','Manueller Speicherklick ungeklaert; Journal bleibt zur Sichtpruefung gesperrt.');
  };
  // The fresh task list is the server-backed evidence, not a successful POST.
  // Retain only bounded diagnostic states, never raw customer text in logs.
  const checkSaved=async()=>{
   let last={status:'QUEUE_NOT_READABLE'};
   for(let z=0;z<70;z++){
    try{
     await UI.navigateToScope(page,'IN_BEARBEITUNG',{refresh:true});
     const r=await readPhase2Queue(page);
     last=phase2SaveReadbackStatus({ticketId:id,rows:r.rows,queueOk:r.ok,
      expectedDescription:preview.descriptionAfter,originalDescription:item.descriptionValue});
     if(last.status==='PERSISTED_EXACT')return {ok:true,diagnostic:last};
     if(['DUPLICATE_TICKET_ROW','UNEXPECTED_DESCRIPTION'].includes(last.status))break;
    }catch{last={status:'QUEUE_READ_ERROR'};}
    await sleep(300);
   }
   return {ok:false,diagnostic:last};
  };
  /** RC51: the former runner navigated away as soon as mouseReleased returned.
   * ICEfaces saves asynchronously: observe this one action until requests are
   * quiet before querying the server-backed task list. Neither a click nor a
   * completed network request is proof of persistence. */
  const saveAndVerify=async({rc80Repair=false}={})=>{
   await bound();assertUnchanged();
   const watcher=await watchPhase2Save(page);
   try{
    const beforeSave=async()=>{assertLiveWorkbookCurrent(root,activeMapping);
     await bound();assertUnchanged();
     need(await verifyBoundDescription(),'P2_SAVE_DESCRIPTION_CHANGED',
      'Ticketbeschreibung vor Speichern nicht mehr exakt. Kein Speicherklick.');
     const g=await phase2FieldSnapshot(page);
     need(g.gevo.count===1&&g.gevo.visible&&g.gevo.value==='Anfrage Member','P2_SAVE_GEVO_CHANGED',
      'Anfrage Member vor Speichern nicht mehr exakt. Kein Speicherklick.');
     need(await stagingPresent(),'P2_SAVE_ATTACHMENT_STAGE_CHANGED',
      'PDF-Anlagen vor Speichern nicht mehr sichtbar. Kein Speicherklick.');
     if(statementReply)need(await verifyMbcDraft(page,id,statementReply),'P2_SAVE_KA_DRAFT_CHANGED','Kontoauszug-Anschreiben vor Ticket speichern veraendert.');
    };
    const click=await savePhase2Ticket(page,{ticketId:id,preActionCheck:beforeSave,log,
     manualClick:()=>saveManual(rc80Repair),beforeAutoClick:async()=>rc80Repair?
      journal.recordRc80MarkerRepairClickIntent('AUTO'):journal.recordTicketSaveAutoClickIntent()});
    log('P2_TICKET_SAVE_CLICK: '+(click.nativeActivations?'EINE_NATIVE_TASTATUR_AKTIVIERUNG':
     click.automaticClicks?'EIN_AUTOMATISCHER_KLICK':'EIN_MANUELLER_KLICK'));
   }catch(e){watcher.cancel();throw e;}
   const network=await watcher.settle();
   if(rc80Repair)journal.recordRc80RepairNetworkObservation(network);
   else journal.recordTicketSaveNetworkObservation(network);
   log('P2_SAVE_NETWORK_SETTLED: '+network.status+' | zugeordnete Schreibrequests='+network.writeStarts);
   need(!['WRITE_REQUEST_ERROR','NETWORK_STILL_ACTIVE'].includes(network.status),
    'P2_SAVE_NETWORK_UNCLEAR','COMARCH-Speichervorgang nicht abgeschlossen. Keinen weiteren Klick ausloesen.');
   const readback=await checkSaved();
   if(!readback.ok)log('P2_SAVE_READBACK_DIAGNOSE: '+readback.diagnostic.status+
    ' | Erneute Nur-Lese-Pruefung erlaubt, aber KEIN zweiter Speicherklick.');
   need(readback.ok,'P2_SAVE_UNVERIFIED',
    'Der Servernachweis fuer die vierte Zeile fehlt ('+readback.diagnostic.status+'). ' +
    'Keinen zweiten Speicherklick ausloesen. Ticket vor weiterer Aktion in COMARCH pruefen.');
   const persisted=await readPhase2Queue(page),record=persisted.rows?.find(x=>x.ticketId===id);
   need(persisted.ok&&record&&normalize(record.descriptionValue)===normalize(preview.descriptionAfter),
    'P2_SAVE_SERVER_DESCRIPTION','Serverbeschreibung nach Speicherklick nicht eindeutig.');
   await openTicket(record);await bound();
   let gevoSaved=false;
   for(let n=0;n<20;n++){
    const snap=await phase2FieldSnapshot(page);
    if(snap.gevo.count===1&&snap.gevo.visible&&snap.gevo.value==='Anfrage Member'){gevoSaved=true;break;}
    await sleep(250);
   }
   need(gevoSaved,'P2_SAVE_SERVER_GEVO','Beschreibung sichtbar, Anfrage Member nach erneutem Oeffnen nicht gespeichert. Keine Weiterleitung.');
   log('PASS P2_TICKET_SERVER_PERSISTENCE: Beschreibung und Anfrage Member nach erneutem Oeffnen vorhanden.');
  };
  if(recoveryMode==='DRAFT_BEFORE_CLICK'){
   log('P2_DRAFT_BEFORE_CLICK_RECOVERY: '+id+' | vorhandenes Uploadjournal, kein Entwurf-Klick-Intent. Keine neue PDF und keine erneute Dateiauswahl.');
   let e=await phase2AttachmentEvidence(page,names);
   need(phase2ReviewableAttachmentEvidence(e,names),'P2_DRAFT_RECOVERY_ATTACHMENTS_MISSING','Vorhandene Anlage nicht eindeutig sichtbar. Manuelle Klaerung; kein erneuter Upload.');
   const g=await phase2FieldSnapshot(page);
   need(g.gevo.count===1&&g.gevo.visible&&g.gevo.value==='Anfrage Member','P2_DRAFT_RECOVERY_GEVO_MISSING','Anfrage Member nicht exakt sichtbar. Keine Aktion.');
   log('Im richtigen Ticket '+id+' alle '+names.length+' PDF-Anlage(n) und Inhalt pruefen: '+names.join(' + '));
   need(String(await askFn(rl,'Anlagen geprueft und sicher KEIN Entwurf-/Ticket-Speicherklick oder Weiterleitung seit Abbruch? FORTSETZEN / ABBRUCH: ')).toUpperCase()==='FORTSETZEN',
    'P2_DRAFT_RECOVERY_DECLINED','Wiederaufnahme nicht bestaetigt. Kein neuer Klick.');
   await bound();assertUnchanged();
   e=await phase2AttachmentEvidence(page,names);
   need(phase2ReviewableAttachmentEvidence(e,names),'P2_DRAFT_RECOVERY_ATTACHMENTS_CHANGED','Anlagen seit Freigabe veraendert.');
   const desc=await readBoundDraftDescription(page,id,item.descriptionValue,preview.descriptionAfter,{bind:bound});
   need(['EXPECTED','ORIGINAL_ONLY'].includes(desc.kind),'P2_DRAFT_RECOVERY_DESCRIPTION','Beschreibung weicht vom Journal ab.');
   operatorUiApproved=!e.allReady;
   journal.approveUnclickedDraftRecovery({...journalInput,operatorConfirmed:true,attachmentsReviewed:true,noPriorClick:true});armed=true;
   await saveStatementReply({recover:true});
   need(await stagingPresent(),'P2_DRAFT_ATTACHMENTS_UNVERIFIED','Anlagen nach Entwurf-Speichern nicht sicher sichtbar.');
   journal.advance('TICKET_SAVE_INTENT');await saveAndVerify();journal.advance('TICKET_SAVE_VERIFIED');
   log('PASS P2_DRAFT_RECOVERY_SAVED: '+id+' | kein zweiter Upload.');
  }else if(recoveryMode==='SERVER_READBACK_ONLY'){
   log('P2_RC51_READBACK_ONLY: Voriger Speicherklick bleibt erhalten. Erst Serverwerte pruefen; kein blinder Wiederholklick.');
   if(!sameSaved){
    need(sameOriginal&&journal.mayRepairMissingMarker(journalInput),
     'P2_RC80_REPAIR_NOT_ELIGIBLE','Nur Ticket 87917040 mit genau einem frueheren Schreibversuch und unveraendertem Originaltext ist reparierbar. Keine Wiederholung.');
    const g0=await phase2FieldSnapshot(page);
    need(g0.gevo.count===1&&g0.gevo.visible&&g0.gevo.value==='Anfrage Member',
     'P2_RC80_REPAIR_GEVO_MISSING','Anfrage Member ist nicht dauerhaft gespeichert. Keine Statuskorrektur.');
    const e0=await phase2AttachmentEvidence(page,names);
    need(e0.allReady||phase2ReviewableAttachmentEvidence(e0,names),
     'P2_RC80_REPAIR_PDFS_UNVERIFIED','Beide gespeicherten PDFs sind nicht eindeutig sichtbar. Kein erneuter Upload.');
    operatorUiApproved=!e0.allReady;
    if(operatorUiApproved){
     log('Gespeicherte DC-/PP+-Anhaenge erneut geoeffnet pruefen: '+names.join(' + '));
     need((await askFn(rl,'Beide PDFs GESPEICHERT im Ticket 87917040 geprueft? GESPEICHERTE_PDFS_GEPRUEFT / ABBRUCH: ')).toUpperCase()==='GESPEICHERTE_PDFS_GEPRUEFT',
      'P2_RC80_REPAIR_PDFS_DECLINED','Keine Korrektur ohne bestaetigte, dauerhaft gespeicherte Anlagen.');
     await bound();
     need(phase2ReviewableAttachmentEvidence(await phase2AttachmentEvidence(page,names),names),
      'P2_RC80_REPAIR_PDFS_CHANGED','PDF-Anlagenanzeige nach der Pruefung veraendert.');
    }
    operatorServerReviewed=operatorUiApproved;
    const description=await UI.additionalDescriptionState(page);
    need(description.ok&&description.editable&&normalize(description.value)===normalize(item.descriptionValue),
     'P2_RC80_REPAIR_TEXT_CHANGED','Nur die exakt unveraenderten Originalzeilen duerfen ergaenzt werden.');
    log('P2_RC80_MARKER_ONLY: PDF-Upload und GEVO bleiben unangetastet. Einzige Aenderung: neue vierte Zeile Bearbeitet not reviewed.');
    need((await askFn(rl,'Einmalige Statuskorrektur fuer Ticket 87917040, ohne PDF-Upload und ohne E-Mail freigeben? REPARATUR_87917040 / ABBRUCH: ')).toUpperCase()==='REPARATUR_87917040',
     'P2_RC80_REPAIR_DECLINED','Statuskorrektur nicht freigegeben.');
    await bound();assertUnchanged();
    journal.approveRc80MarkerRepair({...journalInput,operatorConfirmed:true,serverOriginalExact:true,
     serverGevoExact:true,attachmentsReviewed:true,notForwarded:true});armed=true;
    const marker=await UI.appendStandardAnswerMarker(page,'Bearbeitet not reviewed');
    need(marker.ok&&normalize(marker.value)===normalize(preview.descriptionAfter)&&
     await verifyBoundDescription(),
     'P2_RC80_REPAIR_MARKER_FAILED','Exakt eine vierte Zeile konnte nicht verifiziert werden. Kein Speicherklick.');
    const gAfter=await phase2FieldSnapshot(page);
    need(gAfter.gevo.count===1&&gAfter.gevo.value==='Anfrage Member'&&await stagingPresent(),
     'P2_RC80_REPAIR_FIELDS_CHANGED','GEVO oder PDF-Anlagen nach Statuskorrektur nicht unveraendert.');
    await saveAndVerify({rc80Repair:true});
    journal.reconcileRc80MarkerRepair({...journalInput,serverDescriptionVerified:true,
     serverGevoVerified:true,attachmentsReviewed:true});
    log('PASS P2_RC80_MARKER_REPAIR_SERVER_VERIFIED: Nur vierte Zeile nachgewiesen; Original-Speicherjournal erhalten.');
   }else{
   const g=await phase2FieldSnapshot(page);
   need(g.gevo.count===1&&g.gevo.visible&&g.gevo.value==='Anfrage Member','P2_RC52_SERVER_GEVO_MISSING','Anfrage Member im neu geoeffneten Ticket nicht gespeichert. Kein zweiter Speicherklick.');
   const e=await phase2AttachmentEvidence(page,names);
   need(e.allReady||phase2ReviewableAttachmentEvidence(e,names),'P2_RC52_SERVER_PDFS_MISSING','Gespeicherte PDFs nicht eindeutig sichtbar; kein erneuter Upload.');
   operatorUiApproved=!e.allReady;
   if(operatorUiApproved){
    log('Gespeicherte PDF-Anlagen im erneut geoeffneten Ticket inhaltlich pruefen: '+names.join(' + '));
    need((await askFn(rl,'Gespeicherte PDFs geprueft? GESPEICHERTE_PDFS_GEPRUEFT / ABBRUCH: ')).toUpperCase()==='GESPEICHERTE_PDFS_GEPRUEFT','P2_RC52_PDF_REVIEW_DECLINED','Keine Weiterleitung ohne Anlagenpruefung.');
   }
   operatorServerReviewed=operatorUiApproved;
   await bound();assertUnchanged();
   need((await phase2FieldSnapshot(page)).gevo.value==='Anfrage Member'&&await verifyBoundDescription({requireEditable:false}),'P2_RC52_READBACK_CHANGED','Serverwerte waehrend der Pruefung veraendert.');
   if(journal.rc80RepairClickPending(journalInput)){
    journal.reconcileRc80MarkerRepair({...journalInput,serverDescriptionVerified:true,
     serverGevoVerified:true,attachmentsReviewed:true});
    log('PASS P2_RC80_REPAIR_READBACK: Voriger protokollierter Reparaturklick nachgewiesen; kein weiterer Klick.');
   }else{
    journal.reconcilePersistedSave({...journalInput,serverDescriptionVerified:true,serverGevoVerified:true,attachmentsReviewed:true});
    log('PASS P2_TICKET_SERVER_PERSISTENCE: RC51-Speicherung nachgewiesen, kein erneuter Klick.');
   }
   armed=true;
   } // End original server readback after an older click; missing marker branch uses one explicitly journaled repair.
  }else if(saveRecoveryMode){
   // The prior observed ACTION_OCCLUDED_OR_OFFSCREEN never issued mouseClick.
   // However, this was not journaled at the time: require fresh independent
   // operator review, an unchanged ticket, and a new one-time approval.
   log('P2_SAVE_WIEDERAUFNAHME: Alter Entwurf und PDFs bleiben unangetastet. Vor dem Speichern wird der Serverzustand kontrolliert.');
   await bound();assertUnchanged();
   const existing=await phase2AttachmentEvidence(page,names);
   need(existing.allReady||phase2ReviewableAttachmentEvidence(existing,names),
    'P2_SAVE_RECOVERY_ATTACHMENTS','Beide PDFs im wiedergeoeffneten Ticket nicht eindeutig sichtbar; kein erneuter Upload.');
   operatorUiApproved=!existing.allReady;
   const g=await phase2FieldSnapshot(page);
   need(g.gevo.count===1&&g.gevo.visible&&g.gevo.enabled,'P2_SAVE_RECOVERY_GEVO_FIELD',
    'GEVO nach erneutem Oeffnen nicht eindeutig editierbar.');
   // An unsaved edit is not a committed database value. The old successful
   // GEVO_VERIFIED is evidence of the RC48 editor only, not of persistence.
   const repairGevo=g.gevo.value!=='Anfrage Member';
   if(repairGevo){
    need(g.gevo.value===''||g.gevo.value==='Anfrage Membe','P2_SAVE_RECOVERY_GEVO_CONFLICT',
     'GEVO ist anders belegt. Nicht automatisch ueberschreiben.');
    log('P2_GEVO_NACH_OEFFNEN_LEER: RC48-Auswahl war nur im nicht gespeicherten Editor. ' +
     'Anfrage Member wird nach Freigabe kontrolliert erneut ausgewaehlt.');
   }
   const desc=await UI.additionalDescriptionState(page);
   need(desc.ok&&desc.editable&&[normalize(item.descriptionValue),normalize(preview.descriptionAfter)].includes(normalize(desc.value)),
    'P2_SAVE_RECOVERY_DESCRIPTION','Status oder Originalbeschreibung nicht eindeutig wiederhergestellt.');
   log('Pruefe exakt Ticket '+id+', die geprueften PDF-Inhalte, Anfrage Member und den alten Speicherversuch.');
   if(recoveryMode==='RC50_UNCONFIRMED_SAVE'&&sameSaved&&!repairGevo){
    log('P2_RC51_SERVER_ALREADY_SAVED: Original-Serverliste zeigt die vierte Zeile und der neu geoeffnete Datensatz Anfrage Member. KEIN neuer Speicherklick.');
    need((await askFn(rl,'Bereits gespeicherte Beschreibung, Anfrage Member und alle PDFs im Server-Ticket geprueft, keine Weiterleitung? RC50_GESPEICHERT_GEPRUEFT / ABBRUCH: ')).toUpperCase()==='RC50_GESPEICHERT_GEPRUEFT',
     'P2_RC51_SAVED_RECONCILIATION_DECLINED','Kein Weiterleiten ohne bestaetigten Serverzustand.');
    await bound();assertUnchanged();
    journal.approveRc50PersistedSave({...journalInput,operatorConfirmed:true,serverDescriptionVerified:true,
     serverGevoVerified:true,attachmentsReviewed:true,notForwarded:true});armed=true;
    journal.advance('TICKET_SAVE_VERIFIED');log('P2_JOURNAL TICKET_SAVE_VERIFIED');
   }else{
   if(recoveryMode==='RC50_UNCONFIRMED_SAVE'){
    log('RC50-SPEICHERSTATUS: Ein frueherer Klick ist nicht beweisbar. Erst im frischen COMARCH-Ticket prüfen, ob GEVO/Beschreibung NICHT gespeichert sind.');
    need((await askFn(rl,'RC50-Ticket nicht gespeichert, keine Weiterleitung, alle PDFs und gleiches Ticket geprueft? RC50_NICHT_GESPEICHERT_GEPRUEFT / ABBRUCH: ')).toUpperCase()==='RC50_NICHT_GESPEICHERT_GEPRUEFT',
     'P2_RC51_RECOVERY_DECLINED','Kein zweiter Speicherversuch ohne unabhängigen Nicht-Persistenz-Nachweis.');
   }else{
    need((await askFn(rl,'Sicher KEIN Ticket-Speicherklick/keine Weiterleitung im vorigen Lauf und alle PDFs geprueft? SAVE_OHNE_KLICK_GEPRUEFT / ABBRUCH: ')).toUpperCase()==='SAVE_OHNE_KLICK_GEPRUEFT',
     'P2_SAVE_RECOVERY_DECLINED','Keine Wiederholung ohne unabhaengige Freigabe.');
   }
   await bound();assertUnchanged();
   need((await phase2AttachmentEvidence(page,names)).allReady||
    phase2ReviewableAttachmentEvidence(await phase2AttachmentEvidence(page,names),names),
    'P2_SAVE_RECOVERY_CHANGED','Anlagenzustand seit Sichtpruefung veraendert.');
   if(recoveryMode==='RC50_UNCONFIRMED_SAVE')
    journal.approveRc50UnconfirmedSave({...journalInput,operatorConfirmed:true,noPersistedSave:true,
     ticketUnchanged:true,attachmentsReviewed:true,notForwarded:true});
   else journal.approveTicketSaveRecovery({...journalInput,operatorConfirmed:true,noPriorClick:true,ticketUnchanged:true,
    attachmentsReviewed:true,notForwarded:true});
   armed=true;
   const repaired=await recoverUnsavedPhase2Gevo(page,{
    beforeRepair:async(observedValue)=>recoveryMode==='RC50_UNCONFIRMED_SAVE'?
     journal.recordRc51GevoRepairIntent({observedValue}):journal.recordTicketSaveGevoRepairIntent({observedValue}),
    manualFocus:async(reason)=>{
     log('P2_GEVO_WIEDERAUFNAHME_FOKUS: '+reason+'; nur das GEVO-Feld im Bot-Edge fokussieren.');
     need((await askFn(rl,'GEVO-Feld fokussiert? FOKUS / ABBRUCH: ')).toUpperCase()==='FOKUS',
      'P2_OPERATOR_ABORT','GEVO-Fokus nicht bestaetigt.');
    },
    manualSelect:async()=>{
     log('Im COMARCH-Vorschlag EXAKT Anfrage Member auswaehlen.');
     need((await askFn(rl,'Anfrage Member ausgewaehlt? AUSGEWAEHLT / ABBRUCH: ')).toUpperCase()==='AUSGEWAEHLT',
      'P2_OPERATOR_ABORT','Keine bestaetigte GEVO-Auswahl.');
    }
   });
   if(repaired.modified){
    if(recoveryMode==='RC50_UNCONFIRMED_SAVE')journal.recordRc51GevoRepairVerified();
    else journal.recordTicketSaveGevoRepairVerified();
    log('PASS P2_GEVO_RECOVERY_EDITOR_EXACT: Anfrage Member erneut im Editor gewaehlt. Noch nicht gespeichert.');}
   else log('PASS P2_GEVO_RECOVERY_ALREADY_EXACT: Bestehender Wert unveraendert.');
   await bound();assertUnchanged();
   const afterGevo=await phase2AttachmentEvidence(page,names);
   need(afterGevo.allReady||phase2ReviewableAttachmentEvidence(afterGevo,names),
    'P2_SAVE_RECOVERY_ATTACHMENTS_AFTER_GEVO','Anlagen nach GEVO-Wiederherstellung nicht mehr sichtbar.');
   const updated=await UI.additionalDescriptionState(page);
   need(updated.ok&&updated.editable&&[normalize(item.descriptionValue),normalize(preview.descriptionAfter)].includes(normalize(updated.value)),
    'P2_SAVE_RECOVERY_DESCRIPTION_AFTER_GEVO','GEVO-Aenderung hat die Beschreibung unkontrolliert veraendert.');
   if(normalize(updated.value)===normalize(item.descriptionValue)){
    const marker=await UI.appendStandardAnswerMarker(page,'Bearbeitet not reviewed');
    need(marker.ok&&normalize(marker.value)===normalize(preview.descriptionAfter),'P2_SAVE_RECOVERY_MARKER','Statuszeile nicht hergestellt.');
   }
   need(await verifyBoundDescription(),'P2_SAVE_RECOVERY_MARKER','Statuszeile nicht exakt.');
   if(sameSaved&&!repaired.modified){
    log('P2_SAVE_SERVER_ROW_ALREADY_UPDATED: Beschreibung und GEVO unveraendert, kein weiterer Ticket-Speicherklick.');
    journal.advance('TICKET_SAVE_VERIFIED');log('P2_JOURNAL TICKET_SAVE_VERIFIED');
   }else{
    // If draft save already persisted the description but not GEVO, a save
    // is still mandatory; a preexisting fourth line alone proves no GEVO.
    log('P2_SAVE_RECOVERY_READY: PDFs und Beschreibung erneut geprueft; GEVO exakt. Kein erneuter Upload oder Entwurf-Speicherklick.');
    const preSave=await phase2FieldSnapshot(page);
    need(preSave.gevo.count===1&&preSave.gevo.value==='Anfrage Member','P2_SAVE_GEVO_LOST_BEFORE_CLICK',
     'GEVO vor Ticket speichern nicht mehr exakt.');
    // RC81: the RC80 incident stopped BEFORE any Ticket-save click, after
    // the old draft click. Upgrade this exact incident with a NEW account-
    // statement text and one explicitly authorized draft-save, without
    // reuploading the already staged PDFs or replaying the old save.
    if(id==='87393963'&&recoveryMode==='TICKET_SAVE_ONLY'&&!journal.read().events.some(e=>e.state==='KA_LEGACY_DRAFT_WRITE_INTENT')){
     const ans=String(await askFn(rl,'Ticket 87393963: neues Kontoauszug-Antwortschreiben EINMAL als Entwurf speichern (alte PDFs behalten)? RC81_ENTWURF_87393963 / ABBRUCH: ')).toUpperCase();
     need(ans==='RC81_ENTWURF_87393963','P2_KA_LEGACY_DRAFT_NOT_AUTHORIZED','Kein neuer Entwurf ohne ausdrueckliche Freigabe.');
     await saveStatementReply({legacy:true});
    }
    await saveAndVerify();
    journal.advance('TICKET_SAVE_VERIFIED');log('P2_JOURNAL TICKET_SAVE_VERIFIED');
   }
   } // RC51: either server-only reconciliation or one new controlled save.
  }else{
  // A collapsed, but already populated, attachment area is not an absence
  // proof. Open only its UI before classifying existing versus missing PDFs.
  const firstEvidence=await phase2AttachmentEvidence(page,names);
  let surface=null;
  if(!firstEvidence.allReady&&firstEvidence.items.every(e=>['READY','ABSENT','HIDDEN_UNVERIFIED'].includes(e.status))){
   surface=await ensurePhase2UploadSurface(page,{log});
   if(!surface.available){
    log('P2_ANHANGSBEREICH: Dokument anhaengen im Bot-Edge oeffnen, ohne Dateien auszuwaehlen.');
    need((await askFn(rl,'Anhangsbereich offen? ENTER / ABBRUCH: ')).toUpperCase()!=='ABBRUCH',
     'P2_OPERATOR_ABORT','Anhangsbereich nicht geoeffnet.');
    surface=await ensurePhase2UploadSurface(page,{log});
   }
   need(surface.available,'P2_UPLOAD_NOT_READY','Kein eindeutiger Anhangsbereich. Noch keine Dateiauswahl.');
  }
  let uploadPlan=await currentUploadPlan();
  log('COMARCH-MEMBER: '+member.profile.first+' '+member.profile.last+' | verifizierte PDF-WWID '+wwid+
   (member.memberReferenceWwid?' | INTL01-'+member.memberReferenceWwid+' im ausgewählten Member bestaetigt':' | Member hat keine eindeutig beschriftete WWID'));
  log('PDF-ANLAGE ZUERST: '+names.join(' + ')+' | '+(surface?.mode||'VORHANDENE_ANLAGEN')+'. Danach Anfrage Member und Speicherung.');
  log('Vorbereitung nur fuer dieses Ticket. Noch keine Datei uebergeben.');
  // One approval for new runs; for legacy GEVO_INTENT the operator must
  // independently rule out ANY earlier upload/save/forward side effects.
  if(recoveryMode==='UPLOAD_RECONCILIATION'){
   log('P2_TEILUPLOAD_PRUEFUNG: Vorhanden: '+(uploadPlan.existing.map(a=>a.name).join(' + ')||'keine')+
    ' | Fehlend: '+(uploadPlan.missing.map(a=>a.name).join(' + ')||'keine')+'.');
   log('Vorhandene PDFs im selben COMARCH-Ticket inhaltlich pruefen. Noch kein Entwurf-/Ticket-Speichern und keine Weiterleitung aus dem unterbrochenen Lauf.');
   need((await askFn(rl,'Anlagenbestand/Inhalt geprueft UND noch nicht gespeichert/weitergeleitet? ANHAENGE_GEPRUEFT_UND_FORTSETZEN / ABBRUCH: ')).toUpperCase()==='ANHAENGE_GEPRUEFT_UND_FORTSETZEN',
    'P2_UPLOAD_RECOVERY_DECLINED','Teilupload bleibt zur Pruefung erhalten. Keine Dateiauswahl wiederholt.');
   await bound();assertUnchanged();
   const unchanged=await UI.additionalDescriptionState(page);
   need(unchanged.ok&&unchanged.editable&&normalize(unchanged.value)===normalize(item.descriptionValue),
    'P2_DESCRIPTION_CHANGED','Ticket wurde waehrend der Anlagenpruefung veraendert.');
   const rechecked=await currentUploadPlan();
   need(JSON.stringify(rechecked.existing.map(a=>a.name))===JSON.stringify(uploadPlan.existing.map(a=>a.name)),
    'P2_UPLOAD_EVIDENCE_CHANGED','Anlagenbestand seit der Anzeige veraendert. Erneut unabhaengig pruefen.');
   uploadPlan=rechecked;
   journal.approveUploadReconciliation({...journalInput,operatorConfirmed:true,ticketUnchanged:true,noSaveOrForward:true,
    existingPlans:uploadPlan.existing.map(a=>a.plan),missingPlans:uploadPlan.missing.map(a=>a.plan)});
   log('PASS P2_UPLOAD_RECONCILED: '+uploadPlan.existing.length+' vorhandene PDF(s) beibehalten; '+uploadPlan.missing.length+' fehlende PDF(s) anhaengen.');
  }else if(recoveryMode==='GEVO_FOCUS'){
   log('P2_ALTES_GEVO_JOURNAL: Der RC41/RC42-Lauf hatte nur den GEVO-Fokus begonnen, bevor es irgendeine Upload-Absicht gab.');
   // Der alte Freigabecode GEVO_OHNE_AKTIONEN_GEPRUEFT wird durch eine einzige gemeinsame, strengere Freigabe ersetzt.
   log('Vor der Freigabe COMARCH ausserhalb des Bots pruefen: keine Anlage, kein gespeicherter Entwurf, kein Ticket-Speichern, keine Weiterleitung.');
   need((await askFn(rl,'Gleiches Ticket, PDFs, Rechte geprueft UND keinerlei fruehere Aktion erfolgt? PHASE2_FREIGABE_UND_WIEDERAUFNAHME / ABBRUCH: ')).toUpperCase()==='PHASE2_FREIGABE_UND_WIEDERAUFNAHME',
    'P2_GEVO_RECOVERY_DECLINED','Altes Journal bleibt gesperrt; keine wiederholte Dateianlage.');
   journal.approveGevoFocusRetry({...journalInput,operatorConfirmed:true,ticketUnchanged:true,noAttachments:true});
   log('PASS P2_LEGACY_FOCUS_RECOVERY_AUTHORIZED: Alter Journalstand wird ohne Reset fuer den FilePond-Upload fortgesetzt.');
  }else{
   const approvalReused=canReuseCurrentPdfApproval({pdfReviewedThisRun,sessionPresent:!!session?.page,
    ticketId:id,proof,member,wwid});
   if(approvalReused)log(hasAutomaticAoPreparation(proof)?
    'PASS P2_AO_ANLAGE_FUER_PRUEFUNG: Zentraler Generatornachweis und identischer COMARCH-Member im selben Lauf bestaetigt; fachliche Pruefung durch Mark.':
    hasAutomaticDocumentPreparation(proof)?'PASS P2_KONTOAUSZUG_ANLAGE_FUER_PRUEFUNG: Frische Dateien und COMARCH-Member in diesem Lauf bestaetigt.':
    'PASS P2_PDF_FREIGABE_GLEICHER_LAUF: PDF-Inhalt und Berechtigung einmal in diesem Lauf geprueft; keine doppelte Nachfrage.');
   else need((await askFn(rl,'Originalvorgang, Member, WWID, PDF-Inhalt und Rechte geprueft? PHASE2_FREIGABE / ABBRUCH: ')).toUpperCase()==='PHASE2_FREIGABE',
    'P2_OPERATOR_ABORT','Keine Bearbeitung gestartet.');
   journal.begin();
  }
  armed=true;
  const advance=next=>{const val=journal.advance(next);log('P2_JOURNAL '+next);return val;};
  if(recoveryMode!=='UPLOAD_RECONCILIATION')advance('UPLOAD_INTENT');await bound();
  const files=uploadPlan.missing.map(a=>a.file);
  assertUnchanged();
  let uploadResult=null;
  if(files.length)uploadResult=await attachPhase2Files(page,files,{log,
   beforeSelect:async({file,name})=>{
    await bound();assertUnchanged();
    const artifact=uploadPlan.missing.find(a=>a.file===file&&a.name===name);
    need(artifact,'P2_UPLOAD_FILE_BIND','Datei gehoert nicht zu den geprueften fehlenden Anlagen.');
    const snapshot=await phase2AttachmentEvidence(page,names);
    const target=snapshot.items.find(e=>e.name===name);
    need(target?.present===false&&target.count===0&&target.status==='ABSENT',
     'P2_UPLOAD_DUPLICATE','Diese PDF ist bereits vorhanden oder ihr Status ist unklar. Keine erneute Auswahl.');
    if(artifact.plan==='AO'&&!recoveryMode)log('P2_AO_UPLOAD_NEW_PDF: '+id+' | '+name+' | jetzt wird die neue PDF angehaengt.');
    journal.recordUploadFileIntent(artifact);log('P2_DATEI_INTENT: '+name);
   },
   afterStaged:async({file,name,evidence})=>{
    const artifact=uploadPlan.missing.find(a=>a.file===file&&a.name===name);
    const item=evidence?.items?.find(e=>e.name===name);
    need(artifact&&item?.ready&&item.count===1,'P2_UPLOAD_FILE_EVIDENCE','Einzelanlage nicht eindeutig bestaetigt.');
    journal.recordUploadFileStaged({...artifact,source:item.source});log('PASS P2_DATEI_SICHTBAR: '+name);
    if(artifact.plan==='AO'&&!recoveryMode)log('PASS P2_AO_NEW_PDF_ATTACHED: '+id+' | '+name);
   },
   afterProvisional:async({file,name,evidence})=>{
    const artifact=uploadPlan.missing.find(a=>a.file===file&&a.name===name);
    need(artifact&&evidence?.items?.[0]?.status==='UNBOUND_NAME',
     'P2_UPLOAD_PROVISIONAL','Dateiauswahl stimmt nicht mit dem Uploadplan ueberein.');
    journal.recordUploadFileProvisional(artifact);
    log('P2_DATEI_NICHT_AUTOMATISCH_VERIFIZIERT: '+name+' | Explorer-Auswahl erfolgt, Dateiname sichtbar, COMARCH-Anhangszuordnung offen.');
   }
  });
  let confirmed=false;
  for(let z=0;z<35;z++){
   const e=await phase2AttachmentEvidence(page,names);
   if(e.allReady){confirmed=true;break;}
   await sleep(200);
  }
  operatorUiApproved=false;
  if(!confirmed){
   const uncertain=await phase2AttachmentEvidence(page,names);
   need(phase2ReviewableAttachmentEvidence(uncertain,names)&&uploadResult?.provisionalNames?.length,
    'P2_UPLOAD_UNVERIFIED','Nicht alle PDFs sind im COMARCH-Ticket sichtbar; keine weiteren Aktionen.');
   log('P2_DATEIAUSWAHL_ABGESCHLOSSEN: '+names.length+' benoetigte PDF-Anlage(n), je eigener Dateidialog.');
   log('P2_MANUELLE_ANLAGENKONTROLLE: COMARCH zeigt Dateinamen ausserhalb erkannter Anhangszeilen.');
   log('Im Bot-Edge im Abschnitt Dokument anhaengen '+names.length+' PDF-Anlage(n) und Inhalt pruefen: '+names.join(' + '));
   need(['PDF_ANLAGEN_SICHTBAR','BEIDE_PDFS_SICHTBAR'].includes((await askFn(rl,names.length+' neue PDF-Anlage(n) im RICHTIGEN Ticket sichtbar und inhaltlich geprueft? PDF_ANLAGEN_SICHTBAR / ABBRUCH: ')).toUpperCase()),
    'P2_UPLOAD_REVIEW_DECLINED','Dateiauswahl bleibt im Journal; kein GEVO, keine Speicherung.');
   await bound();assertUnchanged();
   const checked=await phase2AttachmentEvidence(page,names);
   need(phase2ReviewableAttachmentEvidence(checked,names),
    'P2_UPLOAD_UI_CHANGED','Dateinamen nach der Sichtkontrolle veraendert. Keine Speicherung.');
   journal.recordUploadVisualReview({names});operatorUiApproved=true;
   log('PASS P2_UPLOAD_OPERATOR_UI_REVIEW: '+names.length+' PDF-Anlage(n) im Uploadbereich manuell bestaetigt; serverseitige Speicherung noch nicht bewiesen.');
  }
  assertUnchanged();advance('UPLOAD_VERIFIED');
  log('PASS P2_FILEPOND_FILES_STAGED: '+names.length+' PDF(s) vor GEVO sichtbar; '+
   (operatorUiApproved?'UI-Sichtpruefung durch Operator, serverseitige Speicherung offen':'automatische COMARCH-Anlagenzuordnung, serverseitige Speicherung offen')+'.');
  // Now enter the type of request – only after the PDFs were accepted by the
  // FilePond UI, as in the operator's actual workflow.
  advance('GEVO_INTENT');await bound();
  const f=await phase2FieldSnapshot(page);
  need(f.gevo.count===1&&f.gevo.visible&&f.gevo.enabled,'P2_GEVO_MISSING','Anfrage-Art-Feld fehlt nach PDF-Anlage.');
  await setPhase2Gevo(page,{
   manualFocus:async(reason)=>{
    log('P2_GEVO_MANUAL_FOCUS: '+reason+'. Nur GEVO im EIGENEN Bot-Edge fokussieren; keine andere Aktion.');
    need((await askFn(rl,'GEVO-Eingabefeld angeklickt? FOKUS / ABBRUCH: ')).toUpperCase()==='FOKUS',
     'P2_OPERATOR_ABORT','GEVO-Fokus nicht bestaetigt. Keine weiteren Aktionen.');
   },
   manualSelect:async()=>{
    log('Im COMARCH-Vorschlag genau Anfrage Member waehlen.');
    need((await askFn(rl,'Anfrage Member ausgewaehlt? AUSGEWAEHLT / ABBRUCH: ')).toUpperCase()==='AUSGEWAEHLT',
     'P2_OPERATOR_ABORT','Auswahl abgebrochen.');
   }
  });advance('GEVO_VERIFIED');
  need(await stagingPresent(),'P2_FILEPOND_LOST_AFTER_GEVO',
   'COMARCH hat nach Anfrage Member die ausgewaehlten PDF-Anlagen nicht mehr angezeigt. Keine Speicherung oder Wiederholung.');
  advance('DESCRIPTION_INTENT');await bound();
  const before=await UI.additionalDescriptionState(page);
  need(before.ok&&before.editable&&normalize(before.value)===normalize(item.descriptionValue),
   'P2_DESCRIPTION_CHANGED','Originaltext vor Statusaenderung nicht mehr identisch.');
  const update=await UI.appendStandardAnswerMarker(page,'Bearbeitet not reviewed',{expectedOriginal:before.value});
  need(update.ok&&normalize(update.value)===normalize(preview.descriptionAfter),'P2_MARKER_WRITE','Vierte Zeile nicht sicher angehaengt.');
  need(await verifyBoundDescription(),'P2_MARKER_VERIFY','Mehrzeiliger Tickettext nicht eindeutig im Editor.');
  advance('DESCRIPTION_VERIFIED');
  await bound();await saveStatementReply();
  // A draft click is NOT a server receipt. Revalidate the staged PDFs,
  // exact reply, GEVO and description before the separate ticket save.
  need(await stagingPresent(),'P2_DRAFT_ATTACHMENTS_UNVERIFIED',
   'Anlagen nach Entwurf-Speichern nicht sicher sichtbar.');
  advance('TICKET_SAVE_INTENT');await saveAndVerify();
  advance('TICKET_SAVE_VERIFIED');
  } // End regular PP+/DC upload/GEVO/draft path; save-only recovery rejoins here.

  log('PASS P2_DRAFT_AND_TICKET_SAVED: Tickettext gespeichert; dauerhafte PDF-Bestaetigung folgt nach erneutem Oeffnen.');
  // Review is explicitly gated and performed separately from saving.
  log('Pruefung: '+names.length+' PDF-Anlage(n) und Entwurf in COMARCH jetzt visuell pruefen. Nicht selbst weiterleiten.');
  const choice=reviewAuthorized?'WEITERLEITEN':await askFn(rl,'An Mark Baindl zur Ueberpruefung weiterleiten? WEITERLEITEN / OFFEN_LASSEN: ');
  if(choice!=='WEITERLEITEN'){
   log('P2_OFFEN: Ticket gespeichert, Review noch nicht ausgefuehrt. Journal bleibt auf TICKET_SAVE_VERIFIED; kein automatischer Neustart.');
   return {ticketId:id,status:'SAVED_PENDING_REVIEW',journal:journal.file};
  }
  if(await UI.detailTicketId(page)!==id){
   await UI.navigateToScope(page,'IN_BEARBEITUNG',{refresh:true});
   const current=await readPhase2Queue(page);const sameRow=current.rows?.find(r=>r.ticketId===id);
   need(sameRow,'P2_REVIEW_BIND','Nach Speichern ist das Ticket nicht mehr in Meine Vorgaenge.');
   await openTicket(sameRow);
  }
  await UI.assertTicket(page,id);
  need(fixedOkay(await UI.fixedFieldValues(page)),'P2_FIXED_NOT_SAVED','Pflichtfelder nach Speichern nicht mehr exakt. Keine Weiterleitung.');
  // RC49: the GEVO search input was verified before draft save; verify that
  // COMARCH still shows the *committed exact* value after reopening, too.
  let savedGevo=false;
  for(let z=0;z<15;z++){const g=await phase2FieldSnapshot(page);
   if(g.gevo.count===1&&g.gevo.visible&&g.gevo.value==='Anfrage Member'){savedGevo=true;break;}
   await sleep(200);
  }
  need(savedGevo,'P2_SAVED_GEVO_NOT_COMMITTED','Anfrage Member nach Ticket-Speichern nicht mehr exakt sichtbar. Keine Weiterleitung.');
  log('PASS P2_SAVED_GEVO_EXACT: Anfrage Member im wiedergeoeffneten Ticket.');
  // Reopen from server-backed task view to verify attachments survive save.
  const attachmentAfterReopen=await phase2AttachmentEvidence(page,names);
  if(!attachmentAfterReopen.allReady){
   need(operatorUiApproved&&phase2ReviewableAttachmentEvidence(attachmentAfterReopen,names),
    'P2_SAVED_ATTACHMENTS_NOT_VISIBLE',
    'Nach erneutem Oeffnen sind nicht alle PDF-Anlagen nachweisbar. Keine Weiterleitung.');
   log('P2_SERVER_ATTACHMENT_MANUAL_REVIEW: COMARCH zeigt im NEU geoefneten Ticket weiterhin nur ungebundene Dateinamen.');
   log('Pruefe im GESPEICHERTEN COMARCH-Ticket '+names.length+' PDF-Anlage(n) und Inhalt/WWID: '+names.join(' + '));
   need(operatorServerReviewed||(await askFn(rl,names.length+' PDF-Anlage(n) nach erneutem Oeffnen GESPEICHERT vorhanden und Inhalt kontrolliert? GESPEICHERTE_PDFS_GEPRUEFT / ABBRUCH: ')).toUpperCase()==='GESPEICHERTE_PDFS_GEPRUEFT',
    'P2_POST_SAVE_REVIEW_DECLINED','Keine Weiterleitung ohne gepruefte gespeicherte PDFs.');
   await bound();
   need(phase2ReviewableAttachmentEvidence(await phase2AttachmentEvidence(page,names),names),
    'P2_SAVED_ATTACHMENTS_CHANGED','Anlagenanzeige nach der manuellen Kontrolle veraendert. Keine Weiterleitung.');
   if(!journal.read().events.some(e=>e.state==='POST_SAVE_ATTACHMENT_OPERATOR_REVIEW'))journal.recordPostSaveAttachmentReview({names});
   log('PASS P2_POST_SAVE_OPERATOR_ATTACHMENT_REVIEW: Nach erneutem Oeffnen manuell bestaetigt, nicht durch automatischen Downloadbeleg.');
  }
  const savedDescription=await UI.additionalDescriptionState(page);
  need(!savedDescription.ok||normalize(savedDescription.value)===normalize(preview.descriptionAfter),
   'P2_SAVED_DESCRIPTION_CHANGED','Tickettext nach erneutem Oeffnen veraendert.');
  assertUnchanged();
  const routeResult=await finishPhase2Route(page,{ticketId:id,journal,ask:q=>askFn(rl,q),log,route:'REVIEW',controls,routeListBefore,
   beforeExecute:async()=>{await bound();assertUnchanged();
    need(await verifyBoundDescription({requireEditable:false}),'P2_FINAL_DESCRIPTION_CHANGED','Beschreibung vor dem Pruefschritt geaendert.');
    const e=await phase2AttachmentEvidence(page,names);
    need(e.allReady||(operatorUiApproved&&phase2ReviewableAttachmentEvidence(e,names)),'P2_FINAL_ATTACHMENTS_CHANGED','Anlagen vor dem Pruefschritt geaendert.');
   }});
  const receipt={schema:'MCR_PHASE2_REVIEW_RECEIPT_V1',ticketId:id,status:'ROUTED_VERIFIED',reviewer:'mark.baindl',evidence:routeResult.evidence,pdfHashes:proof.artifacts.map(x=>({plan:x.plan,sha256:x.sha256})),createdAt:new Date().toISOString()};
  const rec=path.join(phase2Dir(root),'MCR_PHASE2_ABSCHLUSS_'+id+'_'+stamp()+'.json');writeJSON(rec,receipt);
  log('PASS P2_REVIEW_ROUTE_VERIFIED | '+id+' | mark.baindl | '+rec);
  return receipt;
 }finally{if(!session)rl.close();try{cdp?.close();}catch{}try{browser?.child?.kill();}catch{}if(armed)log('P2_AUDIT: Schreibjournal bleibt dauerhaft erhalten. Bei Unterbrechung keine automatische Wiederholung.');}
}
