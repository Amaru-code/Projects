# MCR Ticket Assistant · 0.8.0 Beta 4

**Ein täglicher Einstieg: `START.cmd`. Ticketkern: unverändert 0.7.4.**

## Nach dem Fehler OLD_STARTER_PRESENT

Das war ein Fehler im bisherigen Installer: `MSG_DOWNLOAD_TEST.cmd`,
`START_LOCAL_BOT_GENDER.cmd` und `README_DOWNLOAD_TEST.md` waren nicht im
Archivplan. Der Abschlusscheck verbot jedoch die beiden liegen gebliebenen Starter.
Beta 4 ordnet alle drei Dateien dem lokalen Softwarearchiv zu. Der Plan wird vor
jeder Verschiebung mit derselben Hauptordner-Regel wie der Abschluss geprüft.
Unbekannte eigene Programme werden nicht einfach mitarchiviert: Der Installer
stoppt vorher und nennt sie. Die Dateien bleiben erhalten.

## Einrichten

Das gesamte Beta-4-ZIP in einen **neuen separaten Ordner außerhalb von
MCR_Datenbruecke** entpacken. Nicht über das Arbeitsprojekt kopieren und keine
Datei direkt im geöffneten ZIP starten. MCR-Bot und dessen eigenes Edge-Fenster
vorher schließen; andere Programme werden nicht beendet.

`BETA_EINRICHTEN.cmd` aus dem entpackten Paket starten, den vorhandenen Projektpfad
mit Enter übernehmen. `AUSGANGSSTAND PASS` bestätigt den vollständigen 0.7.4-Stand.
Die Vorschau muss die drei obigen Altdateien unter „Archiviert werden“ aufführen,
soweit sie vorhanden sind. Mit `UMSTELLEN` die Umstellung bestätigen.

Meldet der Installer einen offenen Rückweg, `BETA_ZURUECK.cmd` **aus Beta 4**
starten und `ZURUECK` bestätigen. Danach erneut `BETA_EINRICHTEN.cmd` verwenden.
Dieser Rückweg kann Journale der mitgeliefert referenzierten Beta-1-, Beta-2- und
Beta-3-Pakete prüfen. Bei unbekannten oder veränderten Nachweisen wird gestoppt.
Ist 0.7.4 bereits vollständig wiederhergestellt, nimmt der Rückweg keine Änderung vor.

`BETA_PRUEFEN.cmd` im Installationspaket prüft nur den Ausgangsstand und den Plan.
Es erstellt weder ein Archiv noch eine Sperre und startet keinen Browser.

## Nach erfolgreicher Installation

Im bestehenden `MCR_Datenbruecke` liegt dann `START.cmd`.
Zuerst Menü **2 – Paket und aktives Mapping prüfen**, dann **4 – Selbsttest**,
anschließend **3 – Funktionsdemo** verwenden. Die Demo verwendet fiktive Daten
und ein eigenes temporäres Browserprofil. Erst **1 – Ticketlauf starten** führt
nach der bisherigen START-Freigabe den echten Workflow einschließlich Versand aus.

## Was erhalten bleibt

`private_data`, das aktive Mapping und sein Aktivierungszeiger, das vorhandene
`.runtime/edge-profile`, bisherige Laufdaten, `diagnostics`, `.git`, `node_modules`
und die XLSX im übergeordneten Ordner werden nicht umgeräumt. Unter
`.runtime/beta-control` entstehen Kontrollmetadaten für Installation und Start.
Alte Software bleibt in `_MCR_Archiv/beta4_<Zeitpunkt>/software` erhalten.
Alte Beta-Archive, Maildownloads und Mappingstände werden nicht pauschal gelöscht.

## Grenzen

Die 17 Laufzeitdateien sind bytegleich zu 0.7.4. Es gibt keine neue Ticketlogik,
keine geänderten Leistungsmerkmale und keine Erweiterung des Versandumfangs.
Der bestehende Versandnachweis bleibt ein Nachweis der Anwendung, keine unabhängige
Zustellbestätigung. Ein unklar beendeter Versand darf nicht blind wiederholt werden.
Der Software-Rückweg macht keine Mails, Tickets oder Mappingänderungen rückgängig.

Die Windows-Fallbacks aus Beta 3 bleiben erhalten. Zurücklesen prüft Bytes, ersetzt
aber keinen garantierten Stromausfallschutz bei nicht verfügbarem fsync.
Beta 4 wurde lokal unter Linux/Node mit Fehler-Injektion getestet; die Ausführung
auf dem konkreten Firmen-Windows ist erst mit dessen nächstem erfolgreichen Test bestätigt.

Details: `docs/PRUEFBERICHT_BETA4.md`, `docs/QUALIFIKATION.json`, `docs/HANDBUCH.html`.
