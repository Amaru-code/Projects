# MCR Ticket Assistant · Beta 4 – Prüfbericht

**Paket:** 0.8.0-beta.4  
**Unveränderte Softwarebasis:** 0.7.4  
**Datum:** 7. Oktober 2026  
**Status:** lokal qualifiziert; Umstellung auf dem konkreten Firmen-Windows noch nicht bestätigt.

## Ursache des gemeldeten Fehlers

Der gemeldete Abbruch `OLD_STARTER_PRESENT – MSG_DOWNLOAD_TEST.cmd` ist ein Fehler
im Beta-3-Installer. Seine Archivliste enthielt die beiden historischen Starter
`MSG_DOWNLOAD_TEST.cmd` und `START_LOCAL_BOT_GENDER.cmd` nicht. Die dazugehörige
`README_DOWNLOAD_TEST.md` war ebenfalls nicht zugeordnet. Deshalb wurden sie in
der Vorschau als unverschoben angezeigt. Der abschließende Paketcheck erlaubte
jedoch nur `START.cmd` als Programmeinstieg im Hauptordner.

Dieser Widerspruch wurde mit dem unveränderten bereitgestellten Beta-3-Paket,
dem Original-Softwarepaket 0.7.4 und künstlichen Ergänzungsdateien reproduziert.
Der Testaufbau enthält keine privaten Benutzerdateien und ist kein vollständiges
Abbild seines Dateisystems. Ergebnis: gleicher Fehlercode beim Abschlusscheck;
danach automatische Wiederherstellung des alten Softwarestands im Test.
Beleg: `quality/beta3-reproduction.json`.

**Wichtige Abgrenzung:** Der Fehler entsteht nach begonnenem Umbau, nicht vor
jeder Dateibewegung. Aus dem Benutzerprotokoll allein ist der abschließende Zustand
seines Rechners nicht sicher feststellbar. Beta 4 prüft daher vor dem nächsten
Versuch den real vorhandenen Softwarestand vollständig gegen die 0.7.4-Referenz.

## Änderung in Beta 4

Die drei genannten Altdateien werden, sofern vorhanden, in das lokale Softwarearchiv
aufgenommen und im Plan angezeigt. Vorschau, erneute Prüfung vor dem Umbau und
Abschluss nutzen die gemeinsame Regel in `tools/root-policy.mjs`.
Die strikte Prüfung wurde nicht abgeschaltet. Unbekannte eigene Skripte erzeugen
`UNPLANNED_ROOT_PROGRAM`, bevor neue Archive oder Dateibewegungen entstehen.
Solche Dateien bleiben unverändert, statt pauschal nach Dateiendung verschoben zu werden.

Der Installer zeigt den Ausgangszustand und den Erfolg eines automatischen Rückwegs
explizit an. `BETA_PRUEFEN.cmd` prüft ausschließlich lokal und ohne Änderungen.
`BETA_ZURUECK.cmd` aus Beta 4 unterstützt auch die bekannten Beta-1-/Beta-2-/Beta-3-
Journale. Dazu werden deren Paketmanifest-SHA256 und erwartete Paketbaum-Nachweise
mit den mitgelieferten Referenzen verglichen. Fremde oder widersprüchliche Journale
werden abgewiesen. Partielle Copy/Delete-Reste werden im Rückweg erhalten.

## Tatsächlich ausgeführte Prüfungen

| Prüfung | Ergebnis |
|---|---:|
| Beta-Hülle, Datenregeln und lokale Laufzeitprüfungen | 50/50 bestanden |
| Umstellung, Rückwege, Vorprüfungen und Fehlersimulationen | 50/50 bestanden |
| Gesamte neue Beta-4-Tests | **100/100 bestanden, 0 Fehler, 0 übersprungen** |
| Erneuter Testlauf der unveränderten 0.7.4-Basis | **507/507 bestanden** |
| Laufzeitdateien gegen 0.7.4 und Beta 3 verglichen | **17/17 bytegleich** |
| Frische synthetische Browserdemo über die Beta-Hülle | **2 fiktive Tickets, RUN COMPLETE** |

Belege: `quality/beta-and-migration.tap`, `quality/baseline-074.tap`,
`quality/demo-summary.json`, `tools/reference/engine-lock.json`.

Die Tests decken insbesondere die drei zuvor übersehenen Altdateien, unbekannte
Starter vor und nach der Vorschau, Schreibweisen mit anderer Groß-/Kleinschreibung,
veränderte Quellen/Mappingzeiger, symbolische Verknüpfungen, laufende Sperren,
Installation mit anschließendem Rückweg und Wiederholung der Einrichtung ab.
Der echte Beta-3-Fehler wurde nachgestellt und anschließend im selben Testordner
mit Beta 4 erfolgreich migriert. Außerdem wurden tatsächliche unterbrochene Journale
aus allen drei vorherigen Beta-Paketen durch Beta 4 wiederhergestellt und der
zurückgestellte 0.7.4-Stand anschließend erfolgreich neu migriert.

Zusätzliche Fehlersimulationen: `EPERM` für `fsync` und `rename`, Abbruch zwischen
Dateibewegung und Journalupdate, partielle Löschung nach vollständiger Archivkopie,
partielle neue Kopie bei noch vorhandener Staging-Kopie, erneuter Rückweg mit
partiellem Archivrest und Journal nur noch als gültige Backupkopie.
Veränderte Archivdaten oder fremde Paketnachweise werden nicht still akzeptiert.

## Was sich nicht ändert

Die 17 Dateien unter `src/` und `lib/` bleiben bytegleich zu 0.7.4. Es gibt keine
Änderung an Namenssuche, PAGE_FETCH, MercerID-Abgleich, Mehrzeilen-/TPP-Regel,
Anrede, Ticketfilterung, Antworttext, Versand oder Speicherung.
Das aktive Mapping und sein Zeiger werden gelesen und auf unveränderte Hashes
geprüft, nicht neu erzeugt oder aktiviert.

`private_data`, das vorhandene Browserprofil, bisherige Laufdaten, Diagnosen und
die XLSX im übergeordneten Ordner werden nicht umgeräumt. Bei Tests dienen hierfür
synthetische Sentineldateien; die realen Benutzerinhalte wurden nicht geöffnet.
Eigene Kontrollmetadaten entstehen unter `.runtime/beta-control`.
Das Softwarearchiv und vorherige Beta-Archive bleiben lokal erhalten.

## Grenzen der Aussage

Ausführungsumgebung: Linux, Node.js v22.16.0, Chromium 144.0.7559.96.
Die Windows-Fehler wurden gezielt in die Dateisystemaufrufe injiziert.
Windows-CMD-Starter und die PowerShell-5.1-Prozessabfrage wurden hier nicht nativ
auf dem Firmenrechner ausgeführt. Der erfolgreiche Test dort steht noch aus.
Es wurde keine echte COMARCH-Seite aufgerufen und keine echte E-Mail versendet.

Bytegenaues Zurücklesen ersetzt bei nicht verfügbarem fsync keinen garantierten
Stromausfallschutz. Ein Software-Rollback macht keinen Ticketversand rückgängig.
Der bisherige anwendungsseitige Versandnachweis bleibt unverändert; er ist keine
unabhängige Zustellbestätigung und keine neue prozessübergreifende Exactly-once-Garantie.

## Nächster Schritt auf dem Zielrechner

Beta 4 vollständig in einen neuen separaten Ordner entpacken. MCR-Bot und eigenes
MCR-Edge schließen. `BETA_EINRICHTEN.cmd` starten. Bei `AUSGANGSSTAND PASS` und
passender Vorschau `UMSTELLEN` bestätigen. Bei `MIGRATION_INCOMPLETE` zuerst den
angezeigten Rückweg über `BETA_ZURUECK.cmd` aus Beta 4 verwenden.
Keine Altdatei oder Archivfragmente von Hand löschen.

Erst nach `BETA-UMSTELLUNG ABGESCHLOSSEN` im vorhandenen Arbeitsprojekt `START.cmd`
öffnen: Menü 2 → Menü 4 → Menü 3. Die Einrichtung startet keinen echten Ticketlauf.
