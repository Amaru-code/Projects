# Beta-4-Status

Klassifikation: **lokal qualifiziertes Beta-Paket, Zielhost-Umstellung noch zu bestätigen**.
Betriebliche Softwarebasis: 0.7.4. Paketversion: 0.8.0-beta.4.

Der vom Benutzer berichtete erfolgreiche 0.7.4-Lauf mit drei Tickets bleibt die
betriebliche Referenz; er wurde hier nicht erneut an COMARCH ausgeführt.
Der aktuelle Fehler OLD_STARTER_PRESENT wurde mit dem originalen Beta-3-Paket,
der originalen 0.7.4-Software und künstlichen Zusatzdateien reproduziert.
Beta 3 hatte dabei die Dateien bereits umgeräumt, bevor der Abschlusscheck scheiterte.
Im Nachbau wurde der Softwarestand automatisch zurückgestellt. Daraus folgt keine
ungeprüfte Aussage über den tatsächlichen Zustand auf dem Zielrechner.

Beta 4 prüft deshalb den tatsächlichen Ausgangsstand vor der Umstellung und zeigt
in Fehlerfällen ein erfolgreiches oder noch offenes Software-Rollback explizit an.
Keine Änderung am produktiven Ticketkern und keine neuen automatischen Tickettests
an echten Personen. Prüfbelege und Grenzen stehen in PRUEFBERICHT_BETA4.md.
