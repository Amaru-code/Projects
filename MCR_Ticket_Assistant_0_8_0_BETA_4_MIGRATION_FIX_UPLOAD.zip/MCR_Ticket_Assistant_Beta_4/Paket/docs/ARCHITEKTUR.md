# Architektur der Beta-Hülle

## Gefrorener Kern

`src/` und `lib/` enthalten 17 bytegleiche Laufzeitdateien aus 0.7.4.
`tools/reference/engine-lock.json` bindet diese Dateien mit SHA256 und Bytezahl.
Das Paketmanifest deckt zusätzlich Setup, Menü, Tests, Konfiguration und Dokumentation ab.
`START.cmd` führt das Menü in `tools/beta-cli.mjs` aus. Der Echtlauf verwendet den
bestehenden Runner und dessen START-Freigabe, Abbruchregeln und Bestandsmapping.

## Ein gemeinsamer Plan- und Abschlusscheck

`tools/root-policy.mjs` definiert die bekannten historischen Zusatzdateien und die
Hauptordner-Regel: Ausführbare Einstiegdateien sind dort nach dem Umbau auf START.cmd
begrenzt. Die Migration prüft das projizierte Ergebnis zuerst in makePlan und nochmals
in checkPlan vor den Dateibewegungen. verifyRelease nutzt dieselbe Regel.
Es gibt keinen bloßen OLD_STARTER_PRESENT-Bypass.
Unbekannte eigene Skripte führen vor dem Umbau zu UNPLANNED_ROOT_PROGRAM.
Unbekannte kollidierende Verzeichnisse bleiben ebenfalls erhalten und blockieren.

## Umstellung

1. Paket, 0.7.4-Referenzmanifest, Quelldateien und aktives TPP-Mapping prüfen.
2. Archivplan und geschützte Pfade anzeigen; UMSTELLEN ist erforderlich.
3. Windows-Prozesse prüfen, parallele MCR-Operationen sperren.
4. Neue Software im Archiv vorab bereitstellen und vollständig prüfen.
5. Alte Software anhand des Plans archivieren; neue Software installieren.
6. Paket und unverändertes aktives Mapping erneut prüfen; Installation quittieren.

Normales Rename wird bevorzugt. Bei den bereits behandelten Windows-Fehlercodes
wird auf Copy → Hashprüfung → Quellfreigabe zurückgegriffen.
Kleine Kontroll-JSONs verwenden nach Möglichkeit Rename, andernfalls einen
zurückgelesenen Direktwrite. Das Journal erhält eine letzte gültige Backupkopie.
Ein erfolgreicher Readback ist keine Zusicherung physischer Persistenz nach Stromausfall.

## Wiederherstellung

Der Rückweg arbeitet nur mit erlaubten obersten Softwarepfaden. Für frühere Beta-
Journale sind Manifest-SHA256 und erwartete Paketbaum-Nachweise in
`tools/reference/migration-compat.json` hinterlegt. Ein beliebiges fremdes Journal
wird dadurch nicht zugelassen. Archiv und Ziel werden auf erlaubte Pfade geprüft.
Vor Wiederherstellung jeder alten Quelle muss ein vollständiges passendes Original
im Archiv oder am ursprünglichen Ort verfügbar sein.
Partielle oder nachträglich hinzugefügte Dateien werden im Rückwegarchiv erhalten,
nicht ungeprüft überschrieben. Die Tests umfassen auch unterbrochene Copy/Delete-
Vorgänge und Backup-only-Journale.

Die Wiederherstellung betrifft Software. Private Mappings, Tickets, versendete
Nachrichten und das Browserprofil werden nicht auf einen früheren Stand zurückgesetzt.

## Daten und Betrieb

Geschützt: private_data, .runtime, diagnostics, .git, node_modules; die XLSX liegt
außerhalb des Softwareziels. Nur eigene Kontrollmetadaten werden unter
.runtime/beta-control geführt. Keine Browserprofilinhalte werden vom Installer
kopiert oder im Auslieferungsarchiv mitgeliefert. Alte Archive bleiben lokal erhalten.
Die Benutzeroberfläche zeigt Routineaktionen im Menü und grenzt Echtlauf, lokale
Prüfung und synthetische Demo ausdrücklich voneinander ab.
