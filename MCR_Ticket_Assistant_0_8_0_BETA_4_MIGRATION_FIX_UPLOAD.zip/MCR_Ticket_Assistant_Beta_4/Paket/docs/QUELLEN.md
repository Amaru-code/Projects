# Quellen und eigene Belege

Die Fehleranalyse basiert auf dem Benutzerprotokoll OLD_STARTER_PRESENT und dem
bereitgestellten Originalpaket MCR_Ticket_Assistant_0_8_0_BETA_3_WINDOWS_COMPAT_UPLOAD.zip.
Original-ZIP-SHA256: d1b13e02fc360e49dcbeb2cdebe41911122d96ca96b337aa808771a563e156b8.
Die Ursache liegt im Zusammenspiel von tools/migration.mjs (EXTRA_LEGACY/oldNames)
und tools/beta-common.mjs (verifyRelease). Öffentliche Quellen ersetzen diese
Projektanalyse nicht.

Öffentliche Primärdokumentation, abgerufen am 7. Oktober 2026:
- Node.js 22 File system: https://nodejs.org/docs/latest-v22.x/api/fs.html
- Node.js 22 Errors: https://nodejs.org/docs/latest-v22.x/api/errors.html

Relevante Funktionen: readdirSync, lstatSync, copyFileSync, renameSync, fsyncSync.
Die Ursache einer konkreten Windows-EPERM-Meldung lässt sich aus dem Fehlercode
allein nicht einer Endpoint-Sicherheitssoftware zuordnen. Beta 4 macht hierzu
keine neue Ursachenbehauptung. OLD_STARTER_PRESENT ist ein eigener Prüfcode.

Eigene Testergebnisse: quality/beta3-reproduction.json, quality/beta-and-migration.tap,
quality/baseline-074.tap, quality/demo-summary.json. Keine Tests greifen auf das
private COMARCH, echte Mails, die Benutzer-XLSX oder das reale Browserprofil zu.
