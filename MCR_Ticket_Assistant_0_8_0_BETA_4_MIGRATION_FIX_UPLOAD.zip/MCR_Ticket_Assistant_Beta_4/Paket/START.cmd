@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
if exist "%~dp0BETA_UMSTELLUNG_LAEUFT.txt" goto migration
if not exist "%~dp0tools\beta-cli.mjs" goto incomplete
call "%~dp0tools\find-node.cmd"
if not "%errorlevel%"=="0" goto nodeError
"%MCR_NODE%" "%~dp0tools\beta-cli.mjs" --menu
set "RC=%errorlevel%"
if not "%RC%"=="0" pause
exit /b %RC%
:migration
echo STOP: Umstellung noch offen. BETA_ZURUECK.cmd im separat entpackten Betapaket verwenden.
pause
exit /b 2
:incomplete
echo STOP: Unvollstaendiges Paket. BETA_EINRICHTEN.cmd statt manuellem Ueberkopieren verwenden.
pause
exit /b 2
:nodeError
pause
exit /b 3
