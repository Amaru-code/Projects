# Compatible with Windows PowerShell 5.1. No process kill, no command lines in output.
$ErrorActionPreference = 'Stop'
try {
    $root = [IO.Path]::GetFullPath($env:MCR_GUARD_ROOT).ToLowerInvariant()
    $exclude = [int]$env:MCR_GUARD_EXCLUDE_PID
    $blocked = 0
    $unknown = 0
    $items = @(Get-CimInstance -ClassName Win32_Process -Filter "Name='msedge.exe' OR Name='node.exe' OR Name='chrome.exe'" -ErrorAction Stop)
    foreach ($item in $items) {
        if ([int]$item.ProcessId -eq $exclude) { continue }
        $cmd = [string]$item.CommandLine
        if ([string]::IsNullOrWhiteSpace($cmd)) { $unknown++; continue }
        $value = $cmd.ToLowerInvariant().Replace('/', '\')
        $underRoot = $value.Contains($root)
        $isRunner = $item.Name -eq 'node.exe' -and ($value -match 'local-bot[^\\\s]*\.mjs|queue-detect\.mjs|msg-download-test\.mjs|export-mapping\.mjs|export-multirow\.mjs|activate-tpp\.mjs|check-member\.mjs|patch-ef-tpp\.mjs|apply-gender\.mjs|beta-cli\.mjs|setup\.mjs')
        $isProfile = ($item.Name -eq 'msedge.exe' -or $item.Name -eq 'chrome.exe') -and $underRoot -and ($value -match '\-\-user-data-dir')
        if ($isRunner -or $isProfile -or ($item.Name -eq 'node.exe' -and $underRoot)) { $blocked++ }
    }
    @{schema='MCR_PROCESS_GUARD_V1';checked=$true;blockedCount=$blocked;unknownCount=$unknown} | ConvertTo-Json -Compress
} catch {
    @{schema='MCR_PROCESS_GUARD_V1';checked=$false;blockedCount=0;unknownCount=1} | ConvertTo-Json -Compress
    exit 1
}
