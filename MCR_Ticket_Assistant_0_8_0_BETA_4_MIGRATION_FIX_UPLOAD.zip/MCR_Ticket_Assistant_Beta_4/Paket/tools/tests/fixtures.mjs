/** Fictitious data only. Never load an operator workbook, mail or browser profile. */
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';
import {makeMultirowMapping} from '../../lib/multirow-tpp-mapping.mjs';
import {publishActiveMapping} from '../../lib/active-mapping.mjs';
export const key='99900001';
export const row=(x={})=>({row:10,B:key,C:0,D:0,E:1,F:1,L:'20',O:'F',errors:{},formulas:[],...x});
export function makeMap(rows=[row(),row({row:11,F:0})]){return makeMultirowMapping({meta:{filename:'FIKTIV.xlsx',sheet:'output',sha256:'a'.repeat(64),headerRow:2,headers:{B:'ClientEEID',C:'IsEligible_DC',D:'IsEligible_IPP',E:'IsEligible_PensIntel',F:'IsEligible_TPP',L:'USC',O:'Gender'}},allRows:()=>structuredClone(rows)},{headerConfirmed:true,mode:'LOCAL_WORKBOOK'});}
export function fakeData(root){
 publishActiveMapping(root,makeMap());
 for(const [rel,text] of [['.runtime/edge-profile/DO_NOT_TOUCH','FAKE_PROFILE_SENTINEL'],['.runtime/downloads/DO_NOT_TOUCH','FAKE_MAIL_SENTINEL'],['diagnostics/DO_NOT_TOUCH','FAKE_DIAGNOSTIC_SENTINEL'],['.git/DO_NOT_TOUCH','FAKE_GIT_SENTINEL']]){fs.mkdirSync(path.dirname(path.join(root,rel)),{recursive:true});fs.writeFileSync(path.join(root,rel),text);}
}
export function temp(){return fs.mkdtempSync(path.join(os.tmpdir(),'MCR_beta_test_'));}
export const dispose=p=>fs.rmSync(p,{recursive:true,force:true});
