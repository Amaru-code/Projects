/** Extended qualification: requires an unpacked original 0.7.4 release via MCR_BASELINE_DIR. */
import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';
import {PACKAGE_ROOT,verifyRelease,verifyBaseline,treeRecord,jsonRead,sha} from '../beta-common.mjs';
import {makePlan,applyPlan,rollbackJournal,findJournals,activeSnapshot,inspectInstallation} from '../migration.mjs';
import {fakeData,temp,dispose} from './fixtures.mjs';
const base=process.env.MCR_BASELINE_DIR;
const err=code=>e=>e.code===code;
const idle=()=>({checked:true,blockedCount:0,unknownCount:0});
function fixture(){
 const parent=temp(),root=path.join(parent,'MCR_Datenbruecke');fs.cpSync(base,root,{recursive:true});fakeData(root);
 fs.writeFileSync(path.join(parent,'FIKTIVE_QUELLE.xlsx'),'SYNTHETIC_WORKBOOK_SENTINEL');
 fs.mkdirSync(path.join(root,'MCR_QUEUE_DETECTION_TEST_0_1'));fs.writeFileSync(path.join(root,'MCR_QUEUE_DETECTION_TEST_0_1','local-test.mjs'),'// locally added historical test');
 for(const name of ['MSG_DOWNLOAD_TEST.cmd','START_LOCAL_BOT_GENDER.cmd'])fs.writeFileSync(path.join(root,name),'@echo off\r\necho SYNTHETIC LEGACY STARTER\r\n');
 fs.writeFileSync(path.join(root,'README_DOWNLOAD_TEST.md'),'SYNTHETIC DOWNLOAD DOC');
 fs.writeFileSync(path.join(root,'private-notes.txt'),'UNKNOWN_FILE_STAYS');
 fs.writeFileSync(path.join(root,'src','__tmp_editorreset.mjs'),'// locally added old experiment');
 fs.writeFileSync(path.join(root,'config','local-runner-gender.json'),'{}');
 return {parent,root};
}
function protectedState(root){return Object.fromEntries(['private_data','.runtime/edge-profile','.runtime/downloads','diagnostics','.git','private-notes.txt'].map(x=>[x,treeRecord(path.join(root,x))]));}
function withFixture(fn){const f=fixture();try{return fn(f);}finally{dispose(f.parent);}}
const options={skip:!base};
test('preview does not mutate any files and excludes browser/private data',options,()=>withFixture(({root})=>{const before=treeRecord(root),p=makePlan(root);assert.deepEqual(treeRecord(root),before);assert.ok(p.source.some(x=>x.name==='src'));assert.ok(p.source.some(x=>x.name==='MCR_QUEUE_DETECTION_TEST_0_1'));for(const n of ['.runtime','private_data','diagnostics','.git'])assert.ok(!p.source.some(x=>x.name===n));}));
test('install and rollback retain all original software plus private sentinels',options,()=>withFixture(({root,parent})=>{
 const before=protectedState(root),p=makePlan(root),r=applyPlan(p,{idleCheck:idle});assert.equal(r.state,'COMPLETE');verifyRelease(root);assert.deepEqual(protectedState(root),before);assert.equal(fs.readFileSync(path.join(parent,'FIKTIVE_QUELLE.xlsx'),'utf8'),'SYNTHETIC_WORKBOOK_SENTINEL');
 assert.ok(fs.existsSync(path.join(r.archive,'software','src','__tmp_editorreset.mjs')));assert.ok(fs.existsSync(path.join(r.archive,'software','MCR_QUEUE_DETECTION_TEST_0_1')));
 assert.ok(!fs.existsSync(path.join(root,'START_FULL_QUEUE_RUN.cmd')));const back=rollbackJournal(path.join(r.archive,'migration.json'),{idleCheck:idle});assert.equal(back.state,'SOFTWARE_RESTORED');verifyBaseline(root);assert.deepEqual(protectedState(root),before);for(const x of p.source)assert.equal(treeRecord(path.join(root,x.name)).digest,x.digest);
}));
test('already installed beta is idempotent; no second archive',options,()=>withFixture(({root})=>{applyPlan(makePlan(root),{idleCheck:idle});const j=findJournals(root);assert.equal(makePlan(root).alreadyInstalled,true);assert.deepEqual(findJournals(root),j);}));
test('closed source invariant detects change after preview',options,()=>withFixture(({root})=>{const p=makePlan(root);fs.appendFileSync(path.join(root,'src/local-bot-full-run.mjs'),'//edit');assert.throws(()=>applyPlan(p,{idleCheck:idle}),err('SOURCE_CHANGED'));assert.equal(findJournals(root).length,0);}));
test('active pointer change after preview blocks before mutation',options,()=>withFixture(({root})=>{const p=makePlan(root);fs.appendFileSync(path.join(root,'private_data/active-mapping.json'),' ');assert.throws(()=>applyPlan(p,{idleCheck:idle}),err('ACTIVE_CHANGED'));assert.equal(findJournals(root).length,0);}));
test('running process guard blocks before mutation',options,()=>withFixture(({root})=>{const p=makePlan(root),before=treeRecord(root);assert.throws(()=>applyPlan(p,{idleCheck:()=>{throw Object.assign(new Error('busy'),{code:'BUSY'});}}),err('BUSY'));assert.deepEqual(treeRecord(root),before);}));
test('idle check cannot be omitted',options,()=>withFixture(({root})=>assert.throws(()=>applyPlan(makePlan(root)),err('IDLE_CHECK_REQUIRED'))));
test('unknown folder collision is not overwritten',options,()=>withFixture(({root})=>{fs.mkdirSync(path.join(root,'tools'));fs.writeFileSync(path.join(root,'tools/own.txt'),'KEEP');assert.throws(()=>makePlan(root),err('UNKNOWN_COLLISION'));assert.equal(fs.readFileSync(path.join(root,'tools/own.txt'),'utf8'),'KEEP');}));
test('software symlink blocks before staging',options,()=>withFixture(({root,parent})=>{fs.symlinkSync(parent,path.join(root,'src/linked'),process.platform==='win32'?'junction':'dir');assert.throws(()=>makePlan(root),err('LINK_BLOCKED'));}));
test('wrong target name rejected',options,()=>withFixture(({root,parent})=>{const other=path.join(parent,'NotThisProject');fs.renameSync(root,other);assert.throws(()=>makePlan(other),err('TARGET_NAME'));}));
for(const [phase,index] of [['after-old-rename',1],['after-old-rename',12],['after-old-rename',30],['after-new-rename',1],['after-new-rename',5],['after-new-rename',10]]){
 test('automatic rollback on injected failure '+phase+' '+index,options,()=>withFixture(({root})=>{const before=protectedState(root),p=makePlan(root);assert.throws(()=>applyPlan(p,{idleCheck:idle,fault:(at,n)=>{if(at===phase&&n===index)throw Object.assign(new Error('injected'),{code:'INJECTED'});}}),err('INJECTED'));verifyBaseline(root);assert.deepEqual(protectedState(root),before);assert.equal(jsonRead(findJournals(root)[0]).state,'ROLLED_BACK');}));
}
for(const [phase,index] of [['after-old-rename',3],['after-new-rename',4]]){
 test('recovery after crash between rename and journal '+phase,options,()=>withFixture(({root})=>{const before=protectedState(root),p=makePlan(root);assert.throws(()=>applyPlan(p,{idleCheck:idle,fault:(at,n)=>{if(at===phase&&n===index)throw Object.assign(new Error('crash'),{code:'CRASH',simulatedPowerLoss:true});}}),err('CRASH'));const f=findJournals(root)[0];rollbackJournal(f,{idleCheck:idle});verifyBaseline(root);assert.deepEqual(protectedState(root),before);}));
}
test('rollback refusal on changed backup does not overwrite beta',options,()=>withFixture(({root})=>{const r=applyPlan(makePlan(root),{idleCheck:idle});fs.appendFileSync(path.join(r.archive,'software/src/local-bot-full-run.mjs'),'//bad');assert.throws(()=>rollbackJournal(path.join(r.archive,'migration.json'),{idleCheck:idle}),err('BACKUP_CHANGED'));verifyRelease(root);}));
test('rollback preserves locally added beta files in retired archive',options,()=>withFixture(({root})=>{const r=applyPlan(makePlan(root),{idleCheck:idle});fs.writeFileSync(path.join(root,'tools','my-note.txt'),'KEEP ME');rollbackJournal(path.join(r.archive,'migration.json'),{idleCheck:idle});assert.equal(fs.readFileSync(path.join(r.archive,'beta_retired','tools','my-note.txt'),'utf8'),'KEEP ME');verifyBaseline(root);}));
test('repeated rollback is no-op',options,()=>withFixture(({root})=>{const r=applyPlan(makePlan(root),{idleCheck:idle}),f=path.join(r.archive,'migration.json');rollbackJournal(f,{idleCheck:idle});assert.equal(rollbackJournal(f,{idleCheck:idle}).state,'ALREADY_ROLLED_BACK');}));
test('journal cannot address protected mapping folder',options,()=>withFixture(({root})=>{const r=applyPlan(makePlan(root),{idleCheck:idle}),f=path.join(r.archive,'migration.json'),j=jsonRead(f);j.incoming.push({name:'private_data'});fs.writeFileSync(f,JSON.stringify(j));const before=protectedState(root);assert.throws(()=>rollbackJournal(f,{idleCheck:idle}),err('JOURNAL_PATH'));assert.deepEqual(protectedState(root),before);}));

test('managed Windows EPERM on fsync and rename uses verified fallbacks',options,()=>withFixture(({root})=>{
 const before=protectedState(root),p=makePlan(root),realRename=fs.renameSync,realFsync=fs.fsyncSync;
 fs.renameSync=()=>{throw Object.assign(new Error('simulated rename denial'),{code:'EPERM'});};
 fs.fsyncSync=()=>{throw Object.assign(new Error('simulated fsync denial'),{code:'EPERM'});};
 try{const r=applyPlan(p,{idleCheck:idle});assert.equal(r.state,'COMPLETE');verifyRelease(root);assert.deepEqual(protectedState(root),before);const back=rollbackJournal(path.join(r.archive,'migration.json'),{idleCheck:idle});assert.equal(back.state,'SOFTWARE_RESTORED');verifyBaseline(root);assert.deepEqual(protectedState(root),before);}finally{fs.renameSync=realRename;fs.fsyncSync=realFsync;}
}));
test('installed CLI resolves own root after relocation with spaces and Unicode',options,async()=>{
 const {execFileSync}=await import('node:child_process');const f=fixture();const moved=path.join(f.parent,'Test Leerzeichen Aeu ß');fs.mkdirSync(moved);const root=path.join(moved,'MCR_Datenbruecke');fs.renameSync(f.root,root);
 try{applyPlan(makePlan(root),{idleCheck:idle});const out=execFileSync(process.execPath,[path.join(root,'tools/beta-cli.mjs'),'--status'],{encoding:'utf8',cwd:f.parent});assert.match(out,/17 Kern-Dateien bytegleich/);assert.match(out,/Verwendbare Personen: 1/);assert.match(out,/0\.8\.0-beta\.4/);}finally{dispose(f.parent);}
});

test('reported Beta3 residual files are ALL in the preview archive plan',options,()=>withFixture(({root})=>{
 const p=makePlan(root);for(const name of ['MSG_DOWNLOAD_TEST.cmd','START_LOCAL_BOT_GENDER.cmd','README_DOWNLOAD_TEST.md']){
  assert.ok(p.source.some(x=>x.name===name));assert.ok(!p.untouched.includes(name));
 }
 assert.equal(p.rootPolicy.state,'ROOT_POLICY_PASS');
}));
test('known historical starters and readme are archived and exactly restored',options,()=>withFixture(({root})=>{
 const names=['MSG_DOWNLOAD_TEST.cmd','START_LOCAL_BOT_GENDER.cmd','README_DOWNLOAD_TEST.md'];
 const before=Object.fromEntries(names.map(n=>[n,treeRecord(path.join(root,n))]));
 const r=applyPlan(makePlan(root),{idleCheck:idle});
 for(const n of names){assert.equal(fs.existsSync(path.join(root,n)),false);assert.deepEqual(treeRecord(path.join(r.archive,'software',n)),before[n]);}
 rollbackJournal(path.join(r.archive,'migration.json'),{idleCheck:idle});
 for(const n of names)assert.deepEqual(treeRecord(path.join(root,n)),before[n]);
}));
for(const ext of ['cmd','bat','ps1','mjs','cjs','js','html'])test('unknown root '+ext+' blocks BEFORE any archive or move',options,()=>withFixture(({root})=>{
 fs.writeFileSync(path.join(root,'OWN_TOOL.'+ext),'KEEP OWN CONTENT');const before=treeRecord(root);
 assert.throws(()=>makePlan(root),err('UNPLANNED_ROOT_PROGRAM'));
 assert.deepEqual(treeRecord(root),before);assert.equal(findJournals(root).length,0);
}));
test('unknown program added after preview also blocks before archive creation',options,()=>withFixture(({root})=>{
 const p=makePlan(root);fs.writeFileSync(path.join(root,'NEW_OWN.cmd'),'KEEP');const before=treeRecord(root);
 assert.throws(()=>applyPlan(p,{idleCheck:idle}),err('UNPLANNED_ROOT_PROGRAM'));assert.deepEqual(treeRecord(root),before);assert.equal(findJournals(root).length,0);
}));
test('case variation of a known extra uses actual basename and is archived',options,()=>withFixture(({root})=>{
 fs.renameSync(path.join(root,'MSG_DOWNLOAD_TEST.cmd'),path.join(root,'msg_download_test.CMD'));
 const p=makePlan(root);assert.ok(p.source.some(x=>x.name==='msg_download_test.CMD'));
 const r=applyPlan(p,{idleCheck:idle});verifyRelease(root);rollbackJournal(path.join(r.archive,'migration.json'),{idleCheck:idle});
 assert.ok(fs.existsSync(path.join(root,'msg_download_test.CMD')));
}));
test('migration barrier blocks same-release idempotence',options,()=>withFixture(({root})=>{
 applyPlan(makePlan(root),{idleCheck:idle});fs.writeFileSync(path.join(root,'BETA_UMSTELLUNG_LAEUFT.txt'),'OPEN');
 assert.throws(()=>makePlan(root),err('MIGRATION_INCOMPLETE'));assert.equal(inspectInstallation(root).state,'ROLLBACK_REQUIRED');
}));
test('read-only starting-state inspection verifies baseline without creating control files',options,()=>withFixture(({root})=>{
 const before=treeRecord(root);assert.equal(inspectInstallation(root).state,'BASELINE_READY');assert.deepEqual(treeRecord(root),before);
}));
test('automatic rollback exposes explicit recovery state on the original exception',options,()=>withFixture(({root})=>{
 let error;try{applyPlan(makePlan(root),{idleCheck:idle,fault:(phase,n)=>{if(phase==='after-new-rename'&&n===2)throw Object.assign(new Error('failure'),{code:'INJECTED'});}});}catch(e){error=e;}
 assert.equal(error.code,'INJECTED');assert.equal(error.rollbackState,'SOFTWARE_RESTORED');assert.ok(error.rollbackArchive);verifyBaseline(root);
}));
test('rollback can read a backup-only interrupted journal',options,()=>withFixture(({root})=>{
 const p=makePlan(root);assert.throws(()=>applyPlan(p,{idleCheck:idle,fault:(phase,n)=>{if(phase==='after-old-rename'&&n===3)throw Object.assign(new Error('crash'),{code:'CRASH',simulatedPowerLoss:true});}}),err('CRASH'));
 const f=findJournals(root)[0];fs.unlinkSync(f);assert.ok(fs.existsSync(f+'.bak'));
 assert.equal(inspectInstallation(root).state,'ROLLBACK_REQUIRED');rollbackJournal(f,{idleCheck:idle});verifyBaseline(root);
}));

// Actual predecessor packages are supplied only during release qualification.
// User selftests do not require these old archives and never fetch them.
for(const beta of [1,2,3]){
 const dir=process.env['MCR_BETA'+beta+'_DIR'];
 test('Beta4 restores an actual interrupted Beta'+beta+' journal with pinned package identity',{skip:!base||!dir},async()=>{
  const {pathToFileURL}=await import('node:url');const old=await import(pathToFileURL(path.join(dir,'tools/migration.mjs')).href);
  const f=fixture();try{
   const before=protectedState(f.root),p=old.makePlan(f.root,dir);
   assert.throws(()=>old.applyPlan(p,{packageRoot:dir,idleCheck:idle,fault:(phase,n)=>{if(phase==='after-new-rename'&&n===4)throw Object.assign(new Error('crash'),{code:'CRASH',simulatedPowerLoss:true});}}),err('CRASH'));
   const inspection=inspectInstallation(f.root);assert.equal(inspection.state,'ROLLBACK_REQUIRED');assert.equal(inspection.journal.release,'0.8.0-beta.'+beta);
   const r=rollbackJournal(inspection.journal.file,{idleCheck:idle});assert.equal(r.state,'SOFTWARE_RESTORED');verifyBaseline(f.root);assert.deepEqual(protectedState(f.root),before);
   const current=applyPlan(makePlan(f.root),{idleCheck:idle});assert.equal(current.state,'COMPLETE');verifyRelease(f.root);assert.deepEqual(protectedState(f.root),before);
  }finally{dispose(f.parent);}
 });
}
test('actual Beta3 reported failure rolls back then Beta4 installs the same directory',{skip:!base||!process.env.MCR_BETA3_DIR},async()=>{
 const {pathToFileURL}=await import('node:url'),dir=process.env.MCR_BETA3_DIR,old=await import(pathToFileURL(path.join(dir,'tools/migration.mjs')).href);
 const f=fixture();try{
  const before=protectedState(f.root);assert.throws(()=>old.applyPlan(old.makePlan(f.root,dir),{packageRoot:dir,idleCheck:idle}),err('OLD_STARTER_PRESENT'));
  assert.equal(inspectInstallation(f.root).state,'BASELINE_READY');verifyBaseline(f.root);
  const r=applyPlan(makePlan(f.root),{idleCheck:idle});assert.equal(r.state,'COMPLETE');verifyRelease(f.root);assert.deepEqual(protectedState(f.root),before);
 }finally{dispose(f.parent);}
});
test('forged previous package pin is rejected without touching the target',{skip:!base||!process.env.MCR_BETA3_DIR},async()=>{
 const {pathToFileURL}=await import('node:url'),dir=process.env.MCR_BETA3_DIR,old=await import(pathToFileURL(path.join(dir,'tools/migration.mjs')).href);
 const f=fixture();try{
  assert.throws(()=>old.applyPlan(old.makePlan(f.root,dir),{packageRoot:dir,idleCheck:idle,fault:(phase,n)=>{if(phase==='after-new-rename'&&n===4)throw Object.assign(new Error('crash'),{code:'CRASH',simulatedPowerLoss:true});}}),err('CRASH'));
  const jfile=findJournals(f.root)[0],j=jsonRead(jfile);j.packageHash='0'.repeat(64);fs.writeFileSync(jfile,JSON.stringify(j));const before=treeRecord(f.root);
  assert.throws(()=>rollbackJournal(jfile,{idleCheck:idle}),err('JOURNAL_PACKAGE'));assert.deepEqual(treeRecord(f.root),before);
 }finally{dispose(f.parent);}
});
test('unknown historical journal release is not used',options,()=>withFixture(({root})=>{
 const r=applyPlan(makePlan(root),{idleCheck:idle}),file=path.join(r.archive,'migration.json'),j=jsonRead(file);j.release='0.8.0-beta.999';fs.writeFileSync(file,JSON.stringify(j));const before=treeRecord(root);
 assert.throws(()=>rollbackJournal(file,{idleCheck:idle}),err('JOURNAL_SCHEMA'));assert.deepEqual(treeRecord(root),before);
}));

test('copy-delete OLD failure retains partial source and restores full baseline',options,()=>withFixture(({root})=>{
 const p=makePlan(root),before=protectedState(root),rename=fs.renameSync,rm=fs.rmSync;let injected=false,error;
 fs.renameSync=()=>{throw Object.assign(new Error('denied rename'),{code:'EPERM'});};
 fs.rmSync=(name,options)=>{
  if(!injected&&String(name)===path.join(root,'src')){injected=true;fs.unlinkSync(path.join(root,'src','__tmp_editorreset.mjs'));throw Object.assign(new Error('partial delete denied'),{code:'EPERM'});}
  return rm(name,options);
 };
 try{try{applyPlan(p,{idleCheck:idle});}catch(e){error=e;}assert.equal(injected,true);assert.equal(error.rollbackState,'SOFTWARE_RESTORED');verifyBaseline(root);assert.deepEqual(protectedState(root),before);}
 finally{fs.renameSync=rename;fs.rmSync=rm;}
}));
test('partial NEW copy with both stage and live is preserved then rolled back',options,()=>withFixture(({root})=>{
 const p=makePlan(root),before=protectedState(root),rename=fs.renameSync,copy=fs.copyFileSync;let injected=false,error;
 fs.renameSync=()=>{throw Object.assign(new Error('denied rename'),{code:'EPERM'});};
 fs.copyFileSync=(source,dest,flags)=>{
  if(!injected&&String(dest)===path.join(root,'src','local-bot-full-run.mjs')){injected=true;throw Object.assign(new Error('copy denied'),{code:'EPERM'});}
  return copy(source,dest,flags);
 };
 try{try{applyPlan(p,{idleCheck:idle});}catch(e){error=e;}assert.equal(injected,true);assert.equal(error.rollbackState,'SOFTWARE_RESTORED');verifyBaseline(root);assert.deepEqual(protectedState(root),before);assert.ok(fs.existsSync(path.join(error.rollbackArchive,'beta_retired','src')));}
 finally{fs.renameSync=rename;fs.copyFileSync=copy;}
}));
test('rollback can be resumed after restoring an original with partial archive remainder',options,()=>withFixture(({root})=>{
 const r=applyPlan(makePlan(root),{idleCheck:idle});const file=path.join(r.archive,'migration.json');
 assert.throws(()=>rollbackJournal(file,{idleCheck:idle,fault:(phase,name)=>{if(phase==='after-restore'&&name==='src')throw Object.assign(new Error('crash'),{code:'CRASH'});}}),err('CRASH'));
 const old=path.join(r.archive,'software','src');fs.mkdirSync(old);fs.writeFileSync(path.join(old,'partial-original.txt'),'PRESERVED RESIDUAL');
 const again=rollbackJournal(file,{idleCheck:idle});assert.equal(again.state,'SOFTWARE_RESTORED');verifyBaseline(root);assert.ok(fs.existsSync(path.join(old,'partial-original.txt')));
}));

test('setup --inspect reports ready baseline and does not change its tree',options,async()=>{
 const {execFileSync}=await import('node:child_process');const f=fixture();try{
  const before=treeRecord(f.root),out=execFileSync(process.execPath,[path.join(PACKAGE_ROOT,'tools/setup.mjs'),'--target',f.root,'--inspect'],{encoding:'utf8',cwd:f.parent});
  assert.match(out,/AUSGANGSSTAND PASS/);assert.match(out,/ARCHIVPLAN PASS/);assert.match(out,/NUR PRUEFUNG/);assert.deepEqual(treeRecord(f.root),before);
 }finally{dispose(f.parent);}
});
test('setup --rollback on restored baseline is a verified read-only no-op',options,async()=>{
 const {execFileSync}=await import('node:child_process');const f=fixture();try{
  const before=treeRecord(f.root),out=execFileSync(process.execPath,[path.join(PACKAGE_ROOT,'tools/setup.mjs'),'--target',f.root,'--rollback'],{encoding:'utf8',cwd:f.parent});
  assert.match(out,/KEIN RUECKWEG NOETIG/);assert.deepEqual(treeRecord(f.root),before);
 }finally{dispose(f.parent);}
});
