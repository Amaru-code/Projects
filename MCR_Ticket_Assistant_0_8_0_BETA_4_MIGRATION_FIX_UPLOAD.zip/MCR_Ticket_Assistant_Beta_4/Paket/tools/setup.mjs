/** Installer UI. Inspection is read-only; mutation requires UMSTELLEN or ZURUECK. */
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';
import readline from 'node:readline/promises';
import {PACKAGE_ROOT,RELEASE,need,verifyRelease,assertWindowsIdle,jsonRead,journalRead,processAlive,stamp,assertPlainPath} from './beta-common.mjs';
import {makePlan,applyPlan,rollbackJournal,findJournals,inspectInstallation} from './migration.mjs';
async function ask(s){const rl=readline.createInterface({input:process.stdin,output:process.stdout});try{return String(await rl.question(s)).trim();}finally{rl.close();}}
const args=process.argv.slice(2),opt=n=>{const i=args.indexOf(n);return i>=0?args[i+1]:null;};
function strip(s){return s.trim().replace(/^"(.*)"$/,'$1');}
function oldDefault(){return path.join(os.homedir(),'projects','Aktive_Projekte','Ticket_bot','MCR_Datenbruecke');}
function clearDeadOperationLock(root){
 const file=path.join(root,'.runtime','beta-control','operation.lock.json');if(!fs.existsSync(file))return;
 assertPlainPath(file);const lock=jsonRead(file,65536);need(lock.schema==='MCR_OPERATION_LOCK_V1'&&['MIGRATION','ROLLBACK'].includes(lock.operation),'RUN_REVIEW_REQUIRED','Es liegt keine tote Umstellungssperre vor. Einen unterbrochenen Ticketlauf zuerst ueber START.cmd / Wiederanlauf pruefen.');
 need(!processAlive(lock.pid),'OPERATION_ALIVE','Eine Umstellung ist noch aktiv. Keine Wiederherstellung.');
 const dir=path.join(root,'.runtime','beta-control','lock_archive');fs.mkdirSync(dir,{recursive:true});assertPlainPath(dir);
 const dest=path.join(dir,'migration_lock_'+stamp()+'.json');fs.copyFileSync(file,dest,fs.constants.COPYFILE_EXCL);need(fs.readFileSync(dest,'utf8')===fs.readFileSync(file,'utf8'),'LOCK_ARCHIVE_VERIFY','Tote Sperre konnte nicht verifiziert archiviert werden.');fs.unlinkSync(file);
}
function showState(s){
 if(s.state==='BASELINE_READY')console.log('\nAUSGANGSSTAND PASS: Softwarebasis 0.7.4 vollstaendig geprueft ('+s.baselineFiles+' Manifestdateien).\nEin eventueller vorheriger Rueckweg ist damit fuer diese Softwarebasis verifiziert.');
 else if(s.state==='CURRENT_BETA_READY')console.log('\nBETA BEREITS INSTALLIERT: '+RELEASE+'; Paket geprueft.');
 else if(s.state==='ROLLBACK_REQUIRED')console.log('\nAUSGANGSSTAND: Vorherige Beta-Umstellung muss zuerst zurueckgestellt werden.\nJournal: '+s.journal.file+'\nJournalzustand: '+s.journal.state+' | '+s.journal.release+'\nDafuer BETA_ZURUECK.cmd AUS DIESEM Beta-4-Paket verwenden; anschliessend BETA_EINRICHTEN.cmd erneut starten.');
 else console.log('\nAUSGANGSSTAND UNKLAR: Kein unveraenderter 0.7.4-Stand und kein sicher verwendbares Rueckwegjournal erkannt.\nNicht starten, nichts loeschen/ueberkopieren. Diese Ausgabe zur Pruefung weitergeben.');
}
try{
 verifyRelease(PACKAGE_ROOT);
 const target=path.resolve(strip(opt('--target')||(await ask('Vorhandener Projektordner [ENTER = '+oldDefault()+']: '))||oldDefault()));
 const state=inspectInstallation(target);showState(state);
 if(args.includes('--inspect')){
  if(state.state==='BASELINE_READY'){
   const p=makePlan(target);console.log('ARCHIVPLAN PASS: '+p.source.length+' oberste Eintraege. Kein alter Starter bleibt nach diesem Plan im Hauptordner.\nAktives Mapping: '+p.active.file+'\nNUR PRUEFUNG: Keine Datei verschoben, keine Sperre angelegt, kein Browser gestartet.');
  }else if(state.state==='CURRENT_BETA_READY'){
   const p=makePlan(target);console.log('Aktives Mapping geprueft: '+p.active.file+'\nNUR PRUEFUNG beendet.');
  }else process.exitCode=2;
 }else if(args.includes('--rollback')){
  if(state.state==='BASELINE_READY')console.log('\nKEIN RUECKWEG NOETIG: 0.7.4 liegt bereits vollstaendig vor.\nZum Einrichten BETA_EINRICHTEN.cmd aus Beta 4 verwenden.');
  else{
   assertWindowsIdle(target);
   const all=findJournals(target),usable=all.filter(f=>{try{const j=journalRead(f);return j.state!=='ROLLED_BACK'&&path.resolve(j.target)===target;}catch{return false;}});
   need(usable.length>0,'NO_ROLLBACK','Kein offenes/lokales Beta-Umstellungsarchiv gefunden.');
   const file=state.journal?.file??usable[0],j=journalRead(file);
   console.log('\nSOFTWARE-RUECKWEG\nZiel: '+target+'\nArchiv: '+j.archive+'\nZustand: '+j.state);
   console.log('Nur Software wird zurueckgestellt. Keine versendete Mail, kein Ticket und kein Mapping werden rueckgaengig gemacht.');
   if((await ask('Diesen Softwarestand wiederherstellen? ZURUECK: ')).toUpperCase()!=='ZURUECK')console.log('Abgebrochen. Keine Aenderung.');
   else{
    assertWindowsIdle(target);clearDeadOperationLock(target);const r=rollbackJournal(file,{idleCheck:assertWindowsIdle});
    console.log('\nRUECKWEG PASS: '+r.state+'\nSoftwarebasis 0.7.4 wiederhergestellt.\nArchiv: '+r.archive+'\nJetzt BETA_EINRICHTEN.cmd aus Beta 4 erneut starten.');
   }
  }
 }else{
  need(['BASELINE_READY','CURRENT_BETA_READY'].includes(state.state),state.state==='ROLLBACK_REQUIRED'?'MIGRATION_INCOMPLETE':'BASELINE_REVIEW_REQUIRED','Siehe Ausgangsstand oben. Kein neuer Umbau ausgefuehrt.');
  const p=makePlan(target);
  if(p.alreadyInstalled)console.log('\nPaket und aktives Mapping geprueft. Kein weiteres Archiv erzeugt.\nAb jetzt: '+path.join(target,'START.cmd'));
  else{
   console.log('\n==============================================================\n VORSCHAU - NOCH KEINE DATEI VERSCHOBEN\n==============================================================');
   console.log('Ziel bleibt: '+p.target+'\nSoftwarebasis: '+p.baselineVersion+'\nNeues Paket: '+RELEASE);
   console.log('Softwarebestand: '+p.source.reduce((s,x)=>s+x.files,0)+' Dateien / '+p.source.length+' oberste Eintraege ins lokale Archiv.');
   console.log('ARCHIVPLAN PASS: derselbe Hauptordner-Check wie bei der Abschlusspruefung.');
   console.log('Neuer Programmeinstieg: START.cmd\nArchiv: '+p.archiveParent+'\\beta4_<Zeitpunkt>\\software');
   console.log('Geschuetzt: private_data, .runtime/edge-profile, bisherige Laufdaten, diagnostics, .git, die XLSX im uebergeordneten Ordner.');
   console.log('Das Mapping '+p.active.file+' bleibt aktiv; keine erneute Aktivierung noetig.');
   console.log('Archiviert werden:\n  '+p.source.map(x=>x.name).join('\n  '));
   console.log('Bestehende oberste Eintraege ohne Verschiebung:\n  '+p.untouched.join('\n  '));
   console.log('\nAlten MCR-Bot UND das eigene MCR-Edge-Fenster vorher schliessen.\nAndere Edge-Fenster/Programme werden nicht beendet. Kein Browserstart, kein Versand.');
   if(args.includes('--plan-only'))console.log('\nNUR VORSCHAU beendet.');
   else if((await ask('\nUmstellung jetzt mit Archiv und Rueckweg ausfuehren? UMSTELLEN: ')).toUpperCase()!=='UMSTELLEN')console.log('Abgebrochen. Keine Aenderung.');
   else{
    assertWindowsIdle(target);clearDeadOperationLock(target);
    const r=applyPlan(p,{idleCheck:assertWindowsIdle});
    console.log('\n==============================================================\n BETA-UMSTELLUNG ABGESCHLOSSEN\n==============================================================');
    console.log('Ticketkern: 17 Dateien bytegleich zu 0.7.4\nAktives Mapping: SHA256 unveraendert\nEdge-Profil: am bisherigen Ort, nicht gelesen/kopiert/verschoben\nSoftwarearchiv: '+r.archive+'\nStart: '+path.join(target,'START.cmd'));
    console.log('\nJetzt START.cmd oeffnen: zuerst Menue 2 (Status), danach 4 (Selbsttest), dann 3 (fiktive Demo).\nDieser Installer startet KEINEN Ticketlauf.');
   }
  }
 }
}catch(e){
 console.error('\nSTOP: '+(e.code||'SETUP_ERROR')+' - '+e.message);
 if(e.rollbackState)console.error('AUTOMATISCHER RUECKWEG PASS: '+e.rollbackState+'\nSoftwarebasis 0.7.4 wurde nach dem Fehler wieder geprueft.\nArchiv bleibt erhalten: '+e.rollbackArchive);
 if(e.rollbackCode)console.error('RUECKWEG OFFEN: '+e.rollbackCode+'. Bot nicht starten; BETA_ZURUECK.cmd aus Beta 4 verwenden.');
 process.exitCode=1;
}
