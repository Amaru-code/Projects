/** One root policy shared by the migration preview and the release verifier.
 * Only these known historical additions may be archived outside the 0.7.4 manifest.
 * Unknown operator scripts are never moved just because they have a script suffix.
 */
export const EXTRA_LEGACY = Object.freeze([
 'DOWNLOAD_TEST_MANIFEST.json',
 'MAPPING_EF_TPP_AKTUALISIEREN.cmd',
 'patch-ef-tpp.mjs',
 'README_EF_TPP_PATCH_0_1.md',
 'MCR_QUEUE_DETECTION_TEST_0_1',
 'MSG_DOWNLOAD_TEST.cmd',
 'START_LOCAL_BOT_GENDER.cmd',
 'README_DOWNLOAD_TEST.md'
]);
export function isRootProgram(name){return /\.(?:cmd|bat|ps1|mjs|cjs|js|html)$/i.test(name);}
export function rootProgramBlockers(names){return Array.from(names).filter(name=>isRootProgram(name)&&name!=='START.cmd').sort();}
export function projectedRootNames(current,archived,incoming){
 const retired=new Set(archived.map(name=>name.toLowerCase()));
 return [...current.filter(name=>!retired.has(name.toLowerCase())),...incoming];
}
export function assertRootPolicy(names,{code='OLD_STARTER_PRESENT',planned=false}={}){
 const blockers=rootProgramBlockers(names);
 if(blockers.length){
  const message=planned
   ? 'Archivplan unvollstaendig: Diese Programme wuerden im Hauptordner liegen bleiben: '+blockers.join(', ')+'. STOP vor der ersten Verschiebung. Dateien bleiben erhalten; nichts manuell loeschen.'
   : 'Alter Starter im Hauptordner: '+blockers.join(', ')+'. Nicht manuell mischen; Umstellung verwenden.';
  throw Object.assign(new Error(message),{code,blockers});
 }
 return {state:'ROOT_POLICY_PASS',rootPrograms:['START.cmd']};
}
