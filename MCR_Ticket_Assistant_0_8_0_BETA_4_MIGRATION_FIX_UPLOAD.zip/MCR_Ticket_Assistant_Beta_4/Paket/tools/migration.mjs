/** Reversible in-place software reorganisation. Protected user data never moves. */
import fs from 'node:fs';
import path from 'node:path';
import {loadActiveMapping} from '../lib/active-mapping.mjs';
import {SCHEMA as TPP_SCHEMA} from '../lib/multirow-tpp-mapping.mjs';
import {PACKAGE_ROOT,RELEASE,PROTECTED,need,sha,stamp,jsonRead,atomicJSON,journalJSON,journalRead,safeRelative,assertPlainPath,treeRecord,verifyRelease,verifyBaseline,acquireLock} from './beta-common.mjs';
import {EXTRA_LEGACY,assertRootPolicy,projectedRootNames} from './root-policy.mjs';
const BARRIER='BETA_UMSTELLUNG_LAEUFT.txt';
const ARCHIVE='_MCR_Archiv';const ARCHIVE_PREFIX='beta4_';
function oneName(x){return safeRelative(x)&&!x.includes('/')&&!PROTECTED.has(x)&&x!==BARRIER;}
function sameRecord(a,b){return a.kind===b.kind&&a.bytes===b.bytes&&a.files===b.files&&a.digest===b.digest;}
export function activeSnapshot(root){
 assertPlainPath(path.join(root,'private_data'));
 const active=loadActiveMapping(root);need(active.map.schema===TPP_SCHEMA,'TPP_MAPPING_REQUIRED','Zuerst das aktive TPP-Mehrzeilen-Mapping 0.7.4 fertigstellen. Keine Neuerzeugung waehrend der Bereinigung.');
 assertPlainPath(active.path);assertPlainPath(active.pointerPath);
 return {file:path.basename(active.path),fileHash:active.fileHash,pointerHash:sha(fs.readFileSync(active.pointerPath)),schema:active.map.schema};
}
function sameActive(root,expected){const a=activeSnapshot(root);need(JSON.stringify(a)===JSON.stringify(expected),'ACTIVE_CHANGED','Aktives Mapping/Zeiger wurde waehrend der Umstellung geaendert.');return a;}
function guardedTarget(root,packageRoot){
 root=assertPlainPath(path.resolve(root));need(path.basename(root).toLowerCase()==='mcr_datenbruecke','TARGET_NAME','Ziel muss der vorhandene Ordner MCR_Datenbruecke sein.');
 need(fs.lstatSync(root).isDirectory(),'TARGET_DIRECTORY','Ziel ist kein Ordner.');
 const pkg=path.resolve(packageRoot);need(root!==pkg&&!pkg.startsWith(root+path.sep)&&!root.startsWith(pkg+path.sep),'SETUP_LOCATION','ZIP ausserhalb des vorhandenen Projektordners entpacken; nicht ueberkopieren.');
 return root;
}
function oldNames(packageRoot){const ref=jsonRead(path.join(packageRoot,'tools/reference/baseline-0.7.4-manifest.json'));return [...new Set([...ref.payload.map(x=>x.path.split('/')[0]),'MANIFEST.json','SHA256SUMS.txt',...EXTRA_LEGACY])].filter(x=>oneName(x));}
function newNames(packageRoot){return fs.readdirSync(packageRoot).filter(x=>oneName(x)).sort();}
function orderNames(names){return [...names].sort((a,b)=>Number(/\.(cmd|bat)$/i.test(b))-Number(/\.(cmd|bat)$/i.test(a))||a.localeCompare(b));}
export function makePlan(root,packageRoot=PACKAGE_ROOT){
 root=guardedTarget(root,packageRoot);verifyRelease(packageRoot);
 need(!fs.existsSync(path.join(root,BARRIER)),'MIGRATION_INCOMPLETE','Vorherige Umstellung unvollstaendig. BETA_ZURUECK.cmd aus Beta 4 verwenden; keine Datei manuell entfernen.');
 const installed=path.join(root,'package.json');
 if(fs.existsSync(installed)){
  const p=jsonRead(installed,65536);if(p.version===RELEASE){const r=verifyRelease(root);return {schema:'MCR_BETA_MIGRATION_PLAN_V1',alreadyInstalled:true,target:root,release:RELEASE,check:r,active:activeSnapshot(root)};}
 }
 const baseline=verifyBaseline(root,packageRoot),active=activeSnapshot(root);
 for(const n of PROTECTED)if(fs.existsSync(path.join(root,n)))assertPlainPath(path.join(root,n));
 const allowedOld=new Set(oldNames(packageRoot).map(n=>n.toLowerCase()));
 const names=orderNames(fs.readdirSync(root).filter(n=>allowedOld.has(n.toLowerCase())));
 const install=newNames(packageRoot);
 for(const n of install){need(oneName(n),'PROTECTED_TARGET','Unzulaessiger Paketordner.');need(!fs.existsSync(path.join(root,n))||names.includes(n),'UNKNOWN_COLLISION','Nicht zugeordneter bestehender Ordner/Datei kollidiert: '+n+'. Bleibt unveraendert.');}
 // Preview and final verifier must agree BEFORE any lock, archive or move is created.
 const rootPolicy=assertRootPolicy(projectedRootNames(fs.readdirSync(root),names,install),{code:'UNPLANNED_ROOT_PROGRAM',planned:true});
 const source=names.map(name=>({name,...treeRecord(path.join(root,name))}));
 const incoming=install.map(name=>({name,...treeRecord(path.join(packageRoot,name))}));
 const untouched=fs.readdirSync(root).filter(n=>!names.includes(n));
 return {schema:'MCR_BETA_MIGRATION_PLAN_V1',alreadyInstalled:false,release:RELEASE,target:root,packageHash:sha(fs.readFileSync(path.join(packageRoot,'MANIFEST.json'))),baselineVersion:baseline.version,source,incoming,active,untouched,rootPolicy,archiveParent:path.join(path.dirname(root),ARCHIVE),newTopLevel:install,protected:[...PROTECTED],createdAt:new Date().toISOString()};
}
function checkPlan(plan,packageRoot){
 need(plan?.schema==='MCR_BETA_MIGRATION_PLAN_V1'&&plan.release===RELEASE&&!plan.alreadyInstalled,'PLAN_INVALID','Kein anwendbarer Umstellungsplan.');
 guardedTarget(plan.target,packageRoot);verifyRelease(packageRoot);
 need(plan.packageHash===sha(fs.readFileSync(path.join(packageRoot,'MANIFEST.json'))),'PACKAGE_CHANGED','Installationspaket seit Vorschau geaendert.');
 for(const x of plan.source){need(oneName(x.name),'PLAN_PATH','Unsicherer Quellpfad.');need(sameRecord(x,treeRecord(path.join(plan.target,x.name))),'SOURCE_CHANGED','Software seit Vorschau geaendert: '+x.name);}
 for(const x of plan.incoming){need(oneName(x.name),'PLAN_PATH','Unsicherer Paketpfad.');need(sameRecord(x,treeRecord(path.join(packageRoot,x.name))),'PACKAGE_CHANGED','Paket seit Vorschau geaendert: '+x.name);}
 // Recheck the projection: a new local script may have appeared after the preview.
 assertRootPolicy(projectedRootNames(fs.readdirSync(plan.target),plan.source.map(x=>x.name),plan.incoming.map(x=>x.name)),{code:'UNPLANNED_ROOT_PROGRAM',planned:true});
 sameActive(plan.target,plan.active);
}
function copyItem(source,dest){
 assertPlainPath(source);need(!fs.existsSync(dest),'DEST_EXISTS','Ziel existiert bereits: '+path.basename(dest));
 const st=fs.lstatSync(source);
 if(st.isDirectory()){fs.mkdirSync(dest);for(const n of fs.readdirSync(source))copyItem(path.join(source,n),path.join(dest,n));}
 else{need(st.isFile(),'SPECIAL_FILE','Keine normale Quelldatei.');fs.copyFileSync(source,dest,fs.constants.COPYFILE_EXCL);}
}
const MOVE_RETRY_CODES=new Set(['EPERM','EACCES','EBUSY','EXDEV']);
function removeItem(target){
 if(!fs.existsSync(target))return;
 const st=fs.lstatSync(target);need(!st.isSymbolicLink(),'LINK_BLOCKED','Verknuepfung wird nicht entfernt: '+target);
 if(st.isDirectory())fs.rmSync(target,{recursive:true,force:false,maxRetries:8,retryDelay:75});else fs.unlinkSync(target);
}
/** Move with a normal rename first. Managed Windows security products can briefly
 * deny rename; after retries we fall back to copy -> hash verify -> delete source.
 */
function moveItem(source,dest,expected){
 assertPlainPath(source);need(!fs.existsSync(dest),'DEST_EXISTS','Ziel existiert bereits: '+path.basename(dest));
 let last;
 try{fs.renameSync(source,dest);need(sameRecord(expected,treeRecord(dest)),'MOVE_VERIFY','Verschobene Software weicht ab: '+path.basename(dest));return 'RENAME';}
 catch(e){last=e;}
 if(!last||!MOVE_RETRY_CODES.has(last.code))throw last;
 copyItem(source,dest);need(sameRecord(expected,treeRecord(dest)),'MOVE_COPY_VERIFY','Kopiertes Softwarearchiv weicht ab: '+path.basename(dest));
 try{removeItem(source);}catch(e){
  // Keep the verified destination for recovery. The rollback logic below accepts
  // a verified backup even when a partially removed source still exists.
  e.code=e.code||'MOVE_DELETE';throw e;
 }
 need(!fs.existsSync(source),'MOVE_SOURCE_REMAINS','Quelle blieb nach verifiziertem Kopieren bestehen: '+path.basename(source));
 return 'COPY_VERIFY_DELETE';
}
function journalWrite(j){return journalJSON(path.join(j.archive,'migration.json'),j);}
export function applyPlan(plan,{packageRoot=PACKAGE_ROOT,idleCheck,fault=null}={}){
 need(typeof idleCheck==='function','IDLE_CHECK_REQUIRED','Eine Prozesspruefung ist Pflicht.');idleCheck(plan.target);checkPlan(plan,packageRoot);
 const root=plan.target;const lock=acquireLock(root,'MIGRATION');let j=null;
 try{
  idleCheck(root);checkPlan(plan,packageRoot);
  if(!fs.existsSync(plan.archiveParent))fs.mkdirSync(plan.archiveParent);assertPlainPath(plan.archiveParent);
  const archive=path.join(plan.archiveParent,ARCHIVE_PREFIX+stamp());fs.mkdirSync(archive);
  j={...plan,archive,schema:'MCR_BETA_MIGRATION_JOURNAL_V1',state:'STAGING',movedOld:[],installedNew:[],createdAt:new Date().toISOString()};
  fs.mkdirSync(path.join(archive,'software'));fs.mkdirSync(path.join(archive,'stage'));journalWrite(j);
  fs.writeFileSync(path.join(archive,'NUR_LOKAL.txt'),'Lokales Softwarearchiv und Umstellungsjournal. Keine Tickets, Mappings oder Browserprofile zuruecksetzen. Konfigurationen koennen private Pfade enthalten: nicht pauschal weitergeben.\n',{flag:'wx'});
  // Stage the complete release and verify it before moving any original file.
  for(const x of j.incoming)copyItem(path.join(packageRoot,x.name),path.join(archive,'stage',x.name));
  verifyRelease(path.join(archive,'stage'));checkPlan(plan,packageRoot);idleCheck(root);
  fs.writeFileSync(path.join(root,BARRIER),'Umstellung aktiv. Nicht starten. Wiederherstellung mit BETA_ZURUECK.cmd aus dem entpackten Betapaket.\n',{flag:'wx'});
  j.state='MOVING_OLD';journalWrite(j);let count=0;
  for(const x of j.source){
   j.intent={phase:'OLD',name:x.name};journalWrite(j);
   moveItem(path.join(root,x.name),path.join(archive,'software',x.name),x);
   fault?.('after-old-rename',++count,j);
   j.movedOld.push(x.name);delete j.intent;journalWrite(j);
  }
  j.state='INSTALLING';journalWrite(j);count=0;
  for(const x of j.incoming){
   j.intent={phase:'NEW',name:x.name};journalWrite(j);
   moveItem(path.join(archive,'stage',x.name),path.join(root,x.name),x);
   fault?.('after-new-rename',++count,j);
   j.installedNew.push(x.name);delete j.intent;journalWrite(j);
  }
  // The barrier is a TXT file, so release verification remains valid during commit.
  verifyRelease(root);sameActive(root,j.active);
  const receipt={schema:'MCR_BETA_INSTALL_V1',release:RELEASE,engineVersion:'0.7.4',installedAt:new Date().toISOString(),archive,journal:path.join(archive,'migration.json'),engineUnchanged:true,activeMappingUnchanged:true};
  atomicJSON(path.join(root,'.runtime','beta-control','install.json'),receipt);
  j.state='COMPLETE';j.completedAt=new Date().toISOString();journalWrite(j);
  fs.unlinkSync(path.join(root,BARRIER));return {state:'COMPLETE',archive,oldTopItems:j.source.length,newTopItems:j.incoming.length,activeUnchanged:true};
 }catch(e){
  if(j){
   if(e.simulatedPowerLoss===true)throw e;
   j.errorCode=e.code||'IO_ERROR';
   try{journalWrite(j);}catch(journalError){e.journalCode=journalError.code||'IO_ERROR';}
   try{const restored=rollbackJournal(path.join(j.archive,'migration.json'),{packageRoot,idleCheck,insideMigration:true});e.rollbackState=restored.state;e.rollbackArchive=restored.archive;}
   catch(rollbackError){e.rollbackCode=rollbackError.code||'IO_ERROR';e.message+=' Rueckweg noch offen: BETA_ZURUECK.cmd aus Beta 4 verwenden. Archiv: '+j.archive;}
  }
  throw e;
 }finally{try{lock.release();}catch{}}
}
function validateJournal(file,packageRoot){
 const abs=path.resolve(file);assertPlainPath(path.dirname(abs));
 if(fs.existsSync(abs))assertPlainPath(abs);
 if(fs.existsSync(abs+'.bak'))assertPlainPath(abs+'.bak');
 const j=journalRead(abs,16*1024*1024);
 const compat=jsonRead(path.join(packageRoot,'tools/reference/migration-compat.json'));
 need(compat.schema==='MCR_BETA_MIGRATION_COMPAT_V1','COMPAT_SCHEMA','Rueckweg-Referenzen fehlen.');
 const prior=compat.releases?.[j.release];
 need(j.schema==='MCR_BETA_MIGRATION_JOURNAL_V1'&&(j.release===RELEASE||prior),'JOURNAL_SCHEMA','Unbekanntes Umstellungsjournal.');
 guardedTarget(j.target,packageRoot);
 const releaseNo=j.release.match(/^0\.8\.0-beta\.([1-4])$/)?.[1];
 const expectedParent=path.join(path.dirname(j.target),ARCHIVE);
 need(releaseNo&&path.dirname(j.archive)===expectedParent&&new RegExp('^beta'+releaseNo+'_[0-9TZ_-]+[a-f0-9]{8}$').test(path.basename(j.archive))&&abs===path.join(j.archive,'migration.json'),'JOURNAL_PATH','Journal gehoert nicht zum lokalen Betaarchiv.');
 assertPlainPath(j.archive);
 const allowedOld=new Set(oldNames(packageRoot).map(n=>n.toLowerCase()));
 const allowedNew=new Set(newNames(packageRoot));
 need(Array.isArray(j.source)&&j.source.length>0&&Array.isArray(j.incoming)&&j.incoming.length>0,'JOURNAL_CONTENT','Journal ist unvollstaendig.');
 need(j.baselineVersion==='0.7.4','JOURNAL_SCHEMA','Falsche Softwarebasis im Journal.');
 const record=x=>x&&['file','directory'].includes(x.kind)&&Number.isSafeInteger(x.files)&&x.files>=0&&Number.isSafeInteger(x.bytes)&&x.bytes>=0&&/^[a-f0-9]{64}$/.test(x.digest??'');
 for(const x of j.source)need(oneName(x.name)&&allowedOld.has(x.name.toLowerCase())&&record(x),'JOURNAL_PATH','Nicht erlaubter alter Softwarepfad/Dateinachweis.');
 for(const x of j.incoming)need(oneName(x.name)&&allowedNew.has(x.name)&&record(x),'JOURNAL_PATH','Nicht erlaubter neuer Softwarepfad/Dateinachweis.');
 need(new Set(j.source.map(x=>x.name.toLowerCase())).size===j.source.length&&new Set(j.incoming.map(x=>x.name.toLowerCase())).size===j.incoming.length,'JOURNAL_CONTENT','Doppelte Journaleintraege.');
 if(prior){
  need(j.packageHash===prior.packageManifestSha256,'JOURNAL_PACKAGE','Altes Journal gehoert nicht zum ausgelieferten Beta-Paket.');
  need(j.incoming.length===prior.incoming.length&&j.incoming.every(x=>prior.incoming.some(r=>r.name===x.name&&sameRecord(r,x))),'JOURNAL_PACKAGE','Alte Paketnachweise stimmen nicht mit der bekannten Beta-Version ueberein.');
 }
 return j;
}
export function rollbackJournal(file,{packageRoot=PACKAGE_ROOT,idleCheck,insideMigration=false,fault=null}={}){
 need(typeof idleCheck==='function','IDLE_CHECK_REQUIRED','Prozesspruefung fehlt.');verifyRelease(packageRoot);let j=validateJournal(file,packageRoot);
 idleCheck(j.target);if(j.state==='ROLLED_BACK')return {state:'ALREADY_ROLLED_BACK',archive:j.archive};
 const root=j.target,backup=path.join(j.archive,'software'),stage=path.join(j.archive,'stage');
 const retired=path.join(j.archive,'beta_retired');if(!fs.existsSync(retired))fs.mkdirSync(retired);assertPlainPath(retired);
 // Validate *all* old material before restoring any of it. For interrupted renames,
 // the location + hash decides what happened; the latest journal intent is not trusted alone.
 for(const x of j.source){
  const old=path.join(backup,x.name),live=path.join(root,x.name);
  const liveIsOriginal=fs.existsSync(live)&&sameRecord(x,treeRecord(live));
  if(!liveIsOriginal){
   need(fs.existsSync(old),'BACKUP_MISSING','Original weder unveraendert im Archiv noch am Ursprungsort: '+x.name);
   need(sameRecord(x,treeRecord(old)),'BACKUP_CHANGED','Archivierte Software geaendert: '+x.name);
  }
 }
 let lock=null;if(!insideMigration)lock=acquireLock(root,'ROLLBACK');
 try{
  j.state='ROLLING_BACK';journalWrite(j);
  // Keep every installed beta item, including newly added local files, in beta_retired.
  for(const x of j.incoming){
   const live=path.join(root,x.name),staged=path.join(stage,x.name),old=path.join(backup,x.name);
   const orig=j.source.find(y=>y.name===x.name);
   const isOriginal=orig&&fs.existsSync(live)&&sameRecord(orig,treeRecord(live));
   if(fs.existsSync(live)&&!isOriginal){
    // A denied rename may leave both a complete staged copy and a partial live
    // copy. Preserve the live material even in that state; no blind removal.
    const liveRecord=treeRecord(live);
    const preferred=path.join(retired,x.name);
    const dest=fs.existsSync(preferred)?path.join(retired,x.name+'_residual_'+stamp()):preferred;
    moveItem(live,dest,liveRecord);fault?.('after-retire',x.name,j);
   }
  }
  for(const x of j.source){
   const old=path.join(backup,x.name),live=path.join(root,x.name);
   if(fs.existsSync(old)){
    if(fs.existsSync(live)){
     // Preserve partial or newly added local material instead of deleting it.
     const liveRecord=treeRecord(live);
     if(!sameRecord(x,liveRecord))moveItem(live,path.join(retired,x.name+'_residual_'+stamp()),liveRecord);
    }
    if(!fs.existsSync(live))moveItem(old,live,x);
    fault?.('after-restore',x.name,j);
   }
   need(sameRecord(x,treeRecord(live)),'ROLLBACK_VERIFY','Wiederherstellung abweichend: '+x.name);
  }
  verifyBaseline(root,packageRoot);activeSnapshot(root); // current data remains current, not restored to an old mapping
  j.state='ROLLED_BACK';j.rolledBackAt=new Date().toISOString();delete j.intent;journalWrite(j);
  const marker=path.join(root,BARRIER);if(fs.existsSync(marker))fs.unlinkSync(marker);
  const ctrl=path.join(root,'.runtime','beta-control');atomicJSON(path.join(ctrl,'rollback.json'),{schema:'MCR_BETA_ROLLBACK_V1',state:'SOFTWARE_RESTORED',createdAt:new Date().toISOString(),dataRestored:false,ticketActionsUndone:false});
  return {state:'SOFTWARE_RESTORED',archive:j.archive};
 }finally{try{lock?.release();}catch{}}
}
export function findJournals(root){
 const parent=path.join(path.dirname(path.resolve(root)),ARCHIVE);if(!fs.existsSync(parent))return [];assertPlainPath(parent);
 return fs.readdirSync(parent).filter(n=>/^beta[1-4]_[0-9TZ_-]+[a-f0-9]{8}$/.test(n)).sort((a,b)=>b.slice(6).localeCompare(a.slice(6)))
  .map(n=>{const dir=path.join(parent,n);assertPlainPath(dir);return path.join(dir,'migration.json');})
  .filter(f=>fs.existsSync(f)||fs.existsSync(f+'.bak'));
}
/** Read-only starting-state classification. Never infer rollback success from the last console line. */
export function inspectInstallation(root,packageRoot=PACKAGE_ROOT){
 root=guardedTarget(root,packageRoot);verifyRelease(packageRoot);
 const barrierPresent=fs.existsSync(path.join(root,BARRIER));
 let baselineError=null,betaError=null;
 if(!barrierPresent){
  try{const b=verifyBaseline(root,packageRoot);return {state:'BASELINE_READY',root,baselineFiles:b.payload.length,barrierPresent:false};}
  catch(e){baselineError=e.code||'IO_ERROR';}
  try{const b=verifyRelease(root);return {state:'CURRENT_BETA_READY',root,release:b.version,barrierPresent:false};}
  catch(e){betaError=e.code||'IO_ERROR';}
 }
 const journals=[];let invalidJournalCount=0;
 for(const file of findJournals(root)){
  try{const j=validateJournal(file,packageRoot);if(path.resolve(j.target)!==root){invalidJournalCount++;continue;}if(j.state!=='ROLLED_BACK')journals.push({file,archive:j.archive,state:j.state,release:j.release});}
  catch{invalidJournalCount++;}
 }
 return {state:journals.length?'ROLLBACK_REQUIRED':'UNKNOWN_NEEDS_REVIEW',root,barrierPresent,baselineError,betaError,invalidJournalCount,journal:journals[0]??null};
}
