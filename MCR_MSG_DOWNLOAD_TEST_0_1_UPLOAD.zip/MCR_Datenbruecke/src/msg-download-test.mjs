import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
import {deflateRawSync} from 'node:zlib';
import readline from 'node:readline/promises';
import {stdin as input, stdout as output} from 'node:process';
import {findEdgeExecutable, launchBrowser, connectBrowser, attachPage, CdpConnection, sleep} from '../lib/cdp.mjs';

const require = createRequire(import.meta.url);
const Msg = require('../lib/msg.cjs');
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const rl = readline.createInterface({input, output});
const NONINTERACTIVE = process.argv.includes('--noninteractive');
const MAX_BYTES = 32 * 1024 * 1024;
const MSG_MAGIC = Buffer.from([0xd0,0xcf,0x11,0xe0,0xa1,0xb1,0x1a,0xe1]);
const sha256 = data => createHash('sha256').update(data).digest('hex');
const stamp = () => new Date().toISOString().replace(/[:.]/g,'-');

function log(s=''){console.log(s)}
function heading(s){log('\n==============================================================\n '+s+'\n==============================================================')}
function safeJson(p){try{return JSON.parse(fs.readFileSync(p,'utf8'))}catch{return {}}}
function isMsgBytes(bytes){const b=Buffer.isBuffer(bytes)?bytes:Buffer.from(bytes);return b.length>=512&&b.subarray(0,8).equals(MSG_MAGIC)}
function validateMsg(bytes){
  const b=Buffer.isBuffer(bytes)?bytes:Buffer.from(bytes);
  if(!isMsgBytes(b))return {ok:false,reason:'NOT_MSG_MAGIC',size:b.length};
  if(b.length>MAX_BYTES)return {ok:false,reason:'TOO_LARGE',size:b.length};
  try{const parsed=Msg.parseMsg(b);return {ok:true,size:b.length,plainText:!!parsed?.body};}
  catch(e){return {ok:false,reason:e.code||'MSG_PARSE',size:b.length};}
}
function bucketMime(v){const s=String(v||'').toLowerCase();if(!s)return null;if(s.includes('outlook')||s.includes('ms-tnef'))return 'MSG_LIKE';if(s.includes('html'))return 'HTML';if(s.includes('octet-stream'))return 'BINARY';return s.split(';')[0].slice(0,80)}
function ensureDirs(cfg){fs.mkdirSync(cfg.probeDirectory,{recursive:true});fs.mkdirSync(cfg.diagnosticDirectory,{recursive:true});}
function cleanProbe(dir){fs.mkdirSync(dir,{recursive:true});for(const n of fs.readdirSync(dir))try{fs.rmSync(path.join(dir,n),{recursive:true,force:true})}catch{}}
function cfg(){
  const base=safeJson(path.join(root,'config','local-runner.json'));
  const localRel=v=>String(v).split(/[\\/]+/).join(path.sep);
  return {
    comarchUrl:base.comarchUrl||'https://comarchecm.mercer.com/DMSWWW/main.jspx',
    edgePath:base.edgePath||'auto',
    profileDirectory:path.resolve(root,localRel(base.profileDirectory||'.runtime\\edge-profile')),
    probeDirectory:path.resolve(root,'.runtime','download_probe'),
    diagnosticDirectory:path.resolve(root,localRel(base.diagnosticDirectory||'diagnostics'))
  };
}
async function tryExistingProfile(profileDirectory){
  const active=path.join(profileDirectory,'DevToolsActivePort');if(!fs.existsSync(active))return null;
  try{const lines=fs.readFileSync(active,'utf8').trim().split(/\r?\n/),port=Number(lines[0]);if(!Number.isInteger(port)||port<=0)return null;const x=await connectBrowser(port);return {...x,port,child:null,existing:true};}catch{return null;}
}
async function browser(cfg){
  const existing=await tryExistingProfile(cfg.profileDirectory);
  if(existing){log('Bereits laufender MCR-Edge erkannt → Downloadtest hängt sich dort an.');return existing;}
  const exe=findEdgeExecutable(cfg.edgePath);if(!exe)throw Object.assign(new Error('Microsoft Edge wurde nicht gefunden.'),{code:'EDGE_NOT_FOUND'});
  const launched=await launchBrowser({executable:exe,userDataDir:cfg.profileDirectory,startUrl:cfg.comarchUrl,headless:false});
  const connected=await connectBrowser(launched.port);log('Eigenes MCR-Edge-Fenster gestartet. Die vorhandene MCR-Anmeldesitzung wird wiederverwendet.');return {...connected,port:launched.port,child:launched.child,existing:false};
}
async function currentPage(cdp){
  return await attachPage(cdp,t=>t.type==='page'&&/https:\/\/comarchecm\.mercer\.com\/DMSWWW\//i.test(t.url||''),30000);
}
async function links(page){return await page.call(function(){
  const visible=n=>{try{const s=n.ownerDocument.defaultView.getComputedStyle(n);return n.isConnected&&n.getClientRects().length>0&&s.display!=='none'&&s.visibility!=='hidden'}catch{return false}};
  const rows=[];for(const tr of document.querySelectorAll('tr.iceDatTblRow')){const a=tr.querySelector('a[href*="GetFile?docId="]');if(!a||!visible(tr)||!visible(a))continue;let u;try{u=new URL(a.getAttribute('href'),document.baseURI)}catch{continue}if(u.origin!==location.origin||!/\/DMSWWW\/GetFile$/i.test(u.pathname)||!/^\d{1,15}$/.test(u.searchParams.get('docId')||''))continue;rows.push({href:u.href,rowIndex:rows.length});}
  return rows.reverse();
});}
async function pageFetch(page,url){return await page.call(async function(target){
  try{const r=await fetch(target,{credentials:'include',cache:'no-store',redirect:'follow',headers:{accept:'application/vnd.ms-outlook,application/octet-stream,*/*'}});const ab=await r.arrayBuffer();if(ab.byteLength>32*1024*1024)return {ok:false,status:r.status,size:ab.byteLength,reason:'TOO_LARGE',mime:r.headers.get('content-type')};const bytes=new Uint8Array(ab);let binary='';for(let i=0;i<bytes.length;i+=0x8000)binary+=String.fromCharCode(...bytes.subarray(i,Math.min(i+0x8000,bytes.length)));return {ok:r.ok,status:r.status,size:bytes.length,base64:btoa(binary),mime:r.headers.get('content-type'),finalSameOrigin:new URL(r.url).origin===location.origin};}catch(e){return {ok:false,reason:e.name||'FETCH_ERROR'};}
},url);}
async function pageXhr(page,url){return await page.call(function(target){return new Promise(resolve=>{try{const x=new XMLHttpRequest();x.open('GET',target,true);x.responseType='arraybuffer';x.withCredentials=true;x.timeout=30000;x.setRequestHeader('Accept','application/vnd.ms-outlook,application/octet-stream,*/*');x.onload=()=>{const ab=x.response||new ArrayBuffer(0);if(ab.byteLength>32*1024*1024)return resolve({ok:false,status:x.status,size:ab.byteLength,reason:'TOO_LARGE',mime:x.getResponseHeader('content-type')});const bytes=new Uint8Array(ab);let binary='';for(let i=0;i<bytes.length;i+=0x8000)binary+=String.fromCharCode(...bytes.subarray(i,Math.min(i+0x8000,bytes.length)));resolve({ok:x.status>=200&&x.status<400,status:x.status,size:bytes.length,base64:btoa(binary),mime:x.getResponseHeader('content-type')});};x.onerror=()=>resolve({ok:false,reason:'XHR_ERROR'});x.ontimeout=()=>resolve({ok:false,reason:'XHR_TIMEOUT'});x.send();}catch(e){resolve({ok:false,reason:e.name||'XHR_EXCEPTION'});}})},url);}
async function loadNetworkResource(page,url){
  try{
    await page.cdp.send('Network.enable',{},page.sessionId).catch(()=>{});
    const tree=await page.cdp.send('Page.getFrameTree',{},page.sessionId);const frameId=tree.frameTree?.frame?.id;if(!frameId)return {ok:false,reason:'NO_FRAME'};
    const r=await page.cdp.send('Network.loadNetworkResource',{frameId,url,options:{disableCache:true,includeCredentials:true}},page.sessionId,45000);
    const res=r.resource||{};if(!res.success||!res.stream)return {ok:false,status:res.httpStatusCode??null,reason:res.netErrorName||'NO_STREAM',mime:bucketMime(res.headers?.['content-type']||res.headers?.['Content-Type'])};
    const chunks=[];let total=0;for(;;){const x=await page.cdp.send('IO.read',{handle:res.stream,size:262144},page.sessionId,15000);const b=Buffer.from(x.data||'',x.base64Encoded?'base64':'utf8');total+=b.length;if(total>MAX_BYTES){await page.cdp.send('IO.close',{handle:res.stream},page.sessionId).catch(()=>{});return {ok:false,status:res.httpStatusCode??null,reason:'TOO_LARGE',size:total};}chunks.push(b);if(x.eof)break;}await page.cdp.send('IO.close',{handle:res.stream},page.sessionId).catch(()=>{});return {ok:true,status:res.httpStatusCode??200,bytes:Buffer.concat(chunks),mime:bucketMime(res.headers?.['content-type']||res.headers?.['Content-Type'])};
  }catch(e){return {ok:false,reason:e.code||e.name||'CDP_LOAD_RESOURCE'};}
}
function cookieMatches(c,u){const host=u.hostname.toLowerCase(),domain=String(c.domain||'').replace(/^\./,'').toLowerCase();if(domain&&host!==domain&&!host.endsWith('.'+domain))return false;const p=c.path||'/';return u.pathname.startsWith(p);}
async function nodeFetchWithCookies(cdp,page,url){
  try{
    const u=new URL(url);await page.cdp.send('Network.enable',{},page.sessionId).catch(()=>{});
    const a=await page.cdp.send('Network.getCookies',{urls:[url]},page.sessionId).catch(()=>({cookies:[]}));
    const b=await cdp.send('Storage.getCookies',{}).catch(()=>({cookies:[]}));
    const all=[...(a.cookies||[]),...(b.cookies||[])].filter(c=>cookieMatches(c,u));const seen=new Set(),cookies=[];for(const c of all){const key=c.name+'|'+c.domain+'|'+c.path;if(seen.has(key))continue;seen.add(key);cookies.push(c);}
    const meta=await page.call(function(){return {href:location.href,ua:navigator.userAgent,lang:navigator.language||'de-DE'};});
    const headers={accept:'application/vnd.ms-outlook,application/octet-stream,*/*','accept-language':meta.lang+',de;q=0.9,en;q=0.7','user-agent':meta.ua,referer:meta.href,'sec-fetch-dest':'document','sec-fetch-mode':'navigate','sec-fetch-site':'same-origin','sec-fetch-user':'?1'};if(cookies.length)headers.cookie=cookies.map(c=>c.name+'='+c.value).join('; ');
    const r=await fetch(url,{headers,redirect:'follow',cache:'no-store'});const bytes=Buffer.from(await r.arrayBuffer());return {ok:r.ok,status:r.status,bytes,mime:bucketMime(r.headers.get('content-type')),cookieCount:cookies.length,finalSameOrigin:new URL(r.url).origin===u.origin};
  }catch(e){return {ok:false,reason:e.code||e.name||'NODE_FETCH',cookieCount:null};}
}
async function setDownloadBehavior(cdp,page,dir){
  fs.mkdirSync(dir,{recursive:true});let browserMode=null,pageMode=null;
  try{await cdp.send('Browser.setDownloadBehavior',{behavior:'allowAndName',downloadPath:dir,eventsEnabled:true},null,10000);browserMode='allowAndName';}catch{try{await cdp.send('Browser.setDownloadBehavior',{behavior:'allow',downloadPath:dir,eventsEnabled:true},null,10000);browserMode='allow';}catch{}}
  try{await page.cdp.send('Page.setDownloadBehavior',{behavior:'allow',downloadPath:dir},page.sessionId,10000);pageMode='allow';}catch{}
  return {browserMode,pageMode};
}
function probeFiles(dir,since){if(!fs.existsSync(dir))return[];return fs.readdirSync(dir).map(n=>{const p=path.join(dir,n);try{const s=fs.statSync(p);return {p,mtime:s.mtimeMs,size:s.size,name:n};}catch{return null}}).filter(Boolean).filter(x=>x.mtime>=since-2500&&x.size>=512&&!/\.crdownload$/i.test(x.name)).sort((a,b)=>b.mtime-a.mtime);}
async function waitFile(dir,since,timeout=25000){const end=Date.now()+timeout;while(Date.now()<end){for(const f of probeFiles(dir,since)){const b=fs.readFileSync(f.p);if(validateMsg(b).ok)return {ok:true,file:f.p,bytes:b};}await sleep(200);}return {ok:false,reason:'NO_VALID_MSG_FILE'};}
async function withDownloadCapture(cdp,page,dir,action){
  cleanProbe(dir);const behavior=await setDownloadBehavior(cdp,page,dir);const since=Date.now();const events={willBegin:0,complete:0,canceled:0};
  const off1=cdp.on('Browser.downloadWillBegin',()=>events.willBegin++);const off2=cdp.on('Browser.downloadProgress',p=>{if(p.state==='completed')events.complete++;if(p.state==='canceled')events.canceled++;});
  try{await action();const got=await waitFile(dir,since,25000);return {...got,behavior,events};}finally{off1();off2();}
}
async function scrollAnchor(page,url){return await page.call(function(target){for(const a of document.querySelectorAll('a[href*="GetFile?docId="]')){let u;try{u=new URL(a.getAttribute('href'),document.baseURI)}catch{continue}if(u.href!==target)continue;a.scrollIntoView({block:'center',inline:'center',behavior:'instant'});const r=a.getBoundingClientRect();return {ok:r.width>0&&r.height>0,x:r.left+r.width/2,y:r.top+r.height/2};}return {ok:false};},url);}
async function trustedMouse(cdp,page,dir,url){return await withDownloadCapture(cdp,page,dir,async()=>{const p=await scrollAnchor(page,url);if(!p.ok)throw Object.assign(new Error('Anchor nicht sichtbar.'),{code:'ANCHOR_NOT_VISIBLE'});await sleep(150);await page.mouseClick(p.x,p.y);});}
async function domClick(cdp,page,dir,url){return await withDownloadCapture(cdp,page,dir,async()=>{const r=await page.call(function(target){for(const a of document.querySelectorAll('a[href*="GetFile?docId="]')){let u;try{u=new URL(a.getAttribute('href'),document.baseURI)}catch{continue}if(u.href===target){a.click();return true;}}return false;},url);if(!r)throw Object.assign(new Error('Anchor nicht gefunden.'),{code:'ANCHOR_NOT_FOUND'});});}
async function windowOpen(cdp,page,dir,url){return await withDownloadCapture(cdp,page,dir,async()=>{await page.eval(`window.open(${JSON.stringify(url)},'_blank')`);});}
async function navigateTarget(cdp,page,dir,url){return await withDownloadCapture(cdp,page,dir,async()=>{const {targetId}=await cdp.send('Target.createTarget',{url:'about:blank',background:true});let sessionId=null;try{({sessionId}=await cdp.send('Target.attachToTarget',{targetId,flatten:true}));await cdp.send('Page.enable',{},sessionId);await cdp.send('Page.setDownloadBehavior',{behavior:'allow',downloadPath:dir},sessionId).catch(()=>{});await cdp.send('Page.navigate',{url},sessionId,20000).catch(()=>{});await sleep(500);}finally{setTimeout(()=>cdp.send('Target.closeTarget',{targetId}).catch(()=>{}),3000);}});}
function sanitizeAttempt(method,index,r){return {method,candidateOrdinal:index+1,ok:!!r.ok,status:Number.isInteger(r.status)?r.status:null,size:Number.isFinite(r.size)?r.size:(r.bytes?.length??null),reason:r.ok?null:String(r.reason||'NOT_VALID_MSG').slice(0,80),mime:bucketMime(r.mime),cookieCount:Number.isInteger(r.cookieCount)?r.cookieCount:null,downloadEvents:r.events?{willBegin:r.events.willBegin,complete:r.events.complete,canceled:r.events.canceled}:null,downloadBehavior:r.behavior||null};}
function crc32(data){let c=0xffffffff;for(const v of data){c^=v;for(let k=0;k<8;k++)c=(c&1)?0xedb88320^(c>>>1):c>>>1;}return(c^0xffffffff)>>>0;}
function zip(files){let offset=0;const chunks=[],central=[];for(const [name,raw] of files){const data=Buffer.isBuffer(raw)?raw:Buffer.from(raw,'utf8'),packed=deflateRawSync(data),n=Buffer.from(name),crc=crc32(data);const h=Buffer.alloc(30);h.writeUInt32LE(0x04034b50);h.writeUInt16LE(20,4);h.writeUInt16LE(0x800,6);h.writeUInt16LE(8,8);h.writeUInt16LE(33,12);h.writeUInt32LE(crc,14);h.writeUInt32LE(packed.length,18);h.writeUInt32LE(data.length,22);h.writeUInt16LE(n.length,26);const z=Buffer.alloc(46);z.writeUInt32LE(0x02014b50);z.writeUInt16LE(20,4);z.writeUInt16LE(20,6);z.writeUInt16LE(0x800,8);z.writeUInt16LE(8,10);z.writeUInt16LE(33,14);z.writeUInt32LE(crc,16);z.writeUInt32LE(packed.length,20);z.writeUInt32LE(data.length,24);z.writeUInt16LE(n.length,28);z.writeUInt32LE(offset,42);chunks.push(h,n,packed);central.push(z,n);offset+=h.length+n.length+packed.length;}const cd=Buffer.concat(central),end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50);end.writeUInt16LE(files.length,8);end.writeUInt16LE(files.length,10);end.writeUInt32LE(cd.length,12);end.writeUInt32LE(offset,16);return Buffer.concat([...chunks,cd,end]);}
function diagnostic(cfg,report){const txt=JSON.stringify(report,null,2)+'\n',h=sha256(txt),manifest=JSON.stringify({schema:'MCR_MSG_DOWNLOAD_PROBE_MANIFEST_V1',payload:[{path:'diagnostic.json',sha256:h}],privacy:'No names, IDs, URLs, cookies, message text or downloaded MSG bytes included.'},null,2)+'\n';const sums=h+'  diagnostic.json\n'+sha256(manifest)+'  manifest.json\n';const out=zip([['diagnostic.json',txt],['manifest.json',manifest],['SHA256SUMS.txt',sums]]),p=path.join(cfg.diagnosticDirectory,`MCR_MSG_DOWNLOAD_PROBE_${stamp()}_UPLOAD.zip`);fs.writeFileSync(p,out);return {path:p,sha256:sha256(out)};}

async function main(){
  const C=cfg();ensureDirs(C);cleanProbe(C.probeDirectory);heading('MCR MSG Download-Test 0.1 - nur Download, keine Ticketänderung');
  log('Dieser Test sendet/speichert nichts und verändert keine Ticketfelder.');
  log('Er probiert mehrere technische Downloadwege und stoppt beim ersten gültigen Outlook-MSG.\n');
  const B=await browser(C);
  if(!NONINTERACTIVE){log('Öffne im MCR-Edge EIN Ticket mit mindestens einer Mail im Nachrichtenverlauf.');await rl.question('ENTER drücken, sobald das Ticket geöffnet ist ... ');}
  const page=await currentPage(B.cdp);const L=await links(page);if(!L.length)throw Object.assign(new Error('Keine GetFile-Mail-Links im sichtbaren Nachrichtenverlauf gefunden.'),{code:'NO_GETFILE_LINKS'});
  log(`${L.length} Mail-Downloadlink(s) erkannt. Neueste Zeile wird zuerst getestet.`);
  const report={schema:'MCR_MSG_DOWNLOAD_PROBE_V1',version:'0.1',createdAt:new Date().toISOString(),candidateCount:L.length,methods:[],success:null,manualControl:null,privacy:'No names, IDs, URLs, cookies, message text or downloaded MSG bytes.'};
  const methods=[
    ['PAGE_FETCH',async u=>{const r=await pageFetch(page,u);if(r.base64)r.bytes=Buffer.from(r.base64,'base64');return r;}],
    ['PAGE_XHR',async u=>{const r=await pageXhr(page,u);if(r.base64)r.bytes=Buffer.from(r.base64,'base64');return r;}],
    ['CDP_NETWORK_LOAD_RESOURCE',u=>loadNetworkResource(page,u)],
    ['NODE_FETCH_WITH_EDGE_COOKIES',u=>nodeFetchWithCookies(B.cdp,page,u)],
    ['CDP_NAVIGATE_DOWNLOAD',u=>navigateTarget(B.cdp,page,C.probeDirectory,u)],
    ['PAGE_WINDOW_OPEN_DOWNLOAD',u=>windowOpen(B.cdp,page,C.probeDirectory,u)],
    ['TRUSTED_MOUSE_DOWNLOAD',u=>trustedMouse(B.cdp,page,C.probeDirectory,u)],
    ['DOM_CLICK_DOWNLOAD',u=>domClick(B.cdp,page,C.probeDirectory,u)]
  ];
  let winner=null,winnerBytes=null;
  outer:for(const [method,fn] of methods){
    log(`\n[${method}]`);
    for(let i=0;i<L.length;i++){
      let r;try{r=await fn(L[i].href);}catch(e){r={ok:false,reason:e.code||e.name||'EXCEPTION'};}
      if(r.bytes){const v=validateMsg(r.bytes);r={...r,ok:v.ok,reason:v.ok?null:v.reason,size:r.bytes.length};}
      else if(r.file){const b=fs.readFileSync(r.file),v=validateMsg(b);r={...r,ok:v.ok,reason:v.ok?null:v.reason,size:b.length,bytes:v.ok?b:null};}
      const s=sanitizeAttempt(method,i,r);report.methods.push(s);log(`  Mail ${i+1}: ${s.ok?'PASS - gültige MSG':`kein Erfolg (${s.reason||'unbekannt'}${s.status?`, HTTP ${s.status}`:''})`}`);
      if(s.ok){winner={method,candidateOrdinal:i+1};winnerBytes=r.bytes||fs.readFileSync(r.file);break outer;}
    }
  }
  if(!winner&&!NONINTERACTIVE){
    log('\n[AUTOMATIK NOCH OHNE TREFFER]');log('Kontrolltest: Downloadverhalten ist bereits auf den Runner-Ordner gesetzt.');log('Bitte jetzt EINMAL manuell auf irgendeinen Mail-Downloadpfeil klicken.');const since=Date.now();await setDownloadBehavior(B.cdp,page,C.probeDirectory);await rl.question('Danach ENTER drücken ... ');const m=await waitFile(C.probeDirectory,since,10000);report.manualControl={ok:m.ok};if(m.ok){winner={method:'MANUAL_CONTROL',candidateOrdinal:null};winnerBytes=m.bytes;}}
  if(winner&&winnerBytes){const success=path.join(C.probeDirectory,'MCR_DOWNLOAD_TEST_SUCCESS.msg');fs.writeFileSync(success,winnerBytes);report.success={method:winner.method,candidateOrdinal:winner.candidateOrdinal,size:winnerBytes.length,msgValidated:true};heading('DOWNLOAD ERFOLG');log(`Methode: ${winner.method}`);log(`Gültige MSG gespeichert: ${success}`);log('Die Datei wurde zusätzlich mit dem internen MSG-Parser validiert.');}
  else{report.success=null;heading('NOCH KEIN AUTOMATISCHER DOWNLOAD');log('Alle automatischen Wege wurden getestet. Der Diagnosebericht zeigt, an welcher Schicht sie scheitern.');}
  const d=diagnostic(C,report);log(`\nDiagnose-ZIP: ${d.path}`);log(`ZIP-SHA256: ${d.sha256}`);return winner?0:5;
}

let rc=0;try{rc=await main();}catch(e){heading('TEST ABGEBROCHEN');log(`${e.code||'ERROR'}: ${e.message}`);rc=4;}finally{rl.close();}
process.exitCode=rc;
