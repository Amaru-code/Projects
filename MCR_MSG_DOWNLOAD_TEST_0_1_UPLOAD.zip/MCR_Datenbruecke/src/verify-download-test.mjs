import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import {createHash} from 'node:crypto';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),mf=JSON.parse(fs.readFileSync(path.join(root,'DOWNLOAD_TEST_MANIFEST.json'),'utf8'));
const sha=p=>createHash('sha256').update(fs.readFileSync(p)).digest('hex');let bad=[];
for(const x of mf.files){const p=path.join(root,...x.path.split('/'));if(!fs.existsSync(p)||sha(p)!==x.sha256)bad.push(x.path);}
if(bad.length){console.error('Download-Test Integritaet FAIL:',bad.join(', '));process.exit(3)}console.log(`Download-Test Integritaet PASS | Dateien: ${mf.files.length} | Node: ${process.versions.node}`);
