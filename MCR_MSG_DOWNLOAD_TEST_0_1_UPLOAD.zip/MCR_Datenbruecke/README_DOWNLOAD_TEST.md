# MCR MSG Download-Test 0.1

Dieses Add-on testet **nur** den Download einer Original-Mail aus dem bereits geöffneten COMARCH-Ticket. Es verändert keine Ticketfelder, sendet keine Nachricht und speichert kein Ticket.

## Benutzung

1. ZIP vollständig entpacken und den Ordner `MCR_Datenbruecke` mit dem bestehenden Projektordner zusammenführen.
2. `MSG_DOWNLOAD_TEST.cmd` starten.
3. Falls noch kein MCR-Edge läuft, öffnet der Test dasselbe persistente MCR-Profil. Anmelden, falls nötig.
4. Genau ein Ticket mit mindestens einer Mail im Nachrichtenverlauf öffnen.
5. Im CMD-Fenster ENTER drücken.
6. Der Test probiert nacheinander:
   - `PAGE_FETCH`
   - `PAGE_XHR`
   - `CDP_NETWORK_LOAD_RESOURCE`
   - `NODE_FETCH_WITH_EDGE_COOKIES`
   - `CDP_NAVIGATE_DOWNLOAD`
   - `PAGE_WINDOW_OPEN_DOWNLOAD`
   - `TRUSTED_MOUSE_DOWNLOAD`
   - `DOM_CLICK_DOWNLOAD`
7. Beim ersten technisch gültigen Outlook-MSG stoppt die Automatik und speichert lokal:
   `.runtime\download_probe\MCR_DOWNLOAD_TEST_SUCCESS.msg`
8. Nur wenn alle automatischen Wege scheitern, gibt es einen einmaligen manuellen Kontrolltest.

## Diagnose

Unabhängig vom Ergebnis entsteht unter `diagnostics` ein `MCR_MSG_DOWNLOAD_PROBE_*_UPLOAD.zip`. Es enthält nur technische Statuscodes, HTTP-Statuswerte, Größen, Cookie-Anzahl (keine Cookie-Werte) und Download-Ereignisse. Es enthält **keine** Namen, IDs, URLs, Mailtexte oder MSG-Datei.

Für die weitere Analyse bitte nur dieses Diagnose-ZIP weitergeben.
