@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
echo ==============================================================
echo  MCR MSG Download-Test 0.1 - mehrere Methoden
echo ==============================================================
echo.
if not exist "%~dp0src\msg-download-test.mjs" goto notExtracted
set "NODE_EXE="
for %%N in (
  "C:\Users\Amaru-Zegarra\projects\Compiler\javascript\tools\node\node.exe"
  "%~dp0tools\node\node.exe"
) do if not defined NODE_EXE if exist "%%~N" set "NODE_EXE=%%~N"
if not defined NODE_EXE for /f "delims=" %%N in ('where node.exe 2^>nul') do if not defined NODE_EXE set "NODE_EXE=%%N"
if not defined NODE_EXE goto noNode
"%NODE_EXE%" "%~dp0src\verify-download-test.mjs"
if errorlevel 1 (
  echo.
  echo Integritaetspruefung fehlgeschlagen. Download-Test wird nicht gestartet.
  pause
  exit /b 4
)
"%NODE_EXE%" "%~dp0src\msg-download-test.mjs"
set "RC=%errorlevel%"
echo.
if "%RC%"=="0" (
  echo Download-Test erfolgreich abgeschlossen.
) else (
  echo Download-Test beendet. Bitte Diagnose-ZIP verwenden.
)
pause
exit /b %RC%
:notExtracted
echo FEHLER: Paket nicht vollstaendig entpackt.
echo ZIP zuerst in den bestehenden MCR_Datenbruecke-Ordner entpacken.
pause
exit /b 2
:noNode
echo FEHLER: node.exe wurde nicht gefunden.
echo Erwartet wird bevorzugt:
echo C:\Users\Amaru-Zegarra\projects\Compiler\javascript\tools\node\node.exe
pause
exit /b 3
