# RC29 Slim – Prüfbericht (lokale technische Qualifikation)

**Grundlage:** unverändertes bereitgestelltes `MCR_Datenbruecke_KOMPLETTPAKET_0_8_1_RC28_SLIM(1).zip`, SHA256 der RC28-Manifestdatei `a6f39118e604372376b69df47dd10fd7d2d5fb2a8d050ca35d33ee80ceb6dad6`.

## Positive Nachweise

- `PASS SELFTEST_SLIM_RUNTIME` – **277/277** aktuelle Node-Selbsttests, 0 Fehler. Ausführung mit Node.js v22.16.0 auf Linux. Vollständige TAP-Ausgabe in `docs/SELFTEST.tap`.
- **Realer Chromium, nur fiktiver Inhalt:** Die neue Browserprobe `rc29-incorrect-sender` verarbeitet eine explizite falsche E-Mail-Namensangabe. Ein bereits ausgewähltes COMARCH-Fixture-Profil zeigt einen anderen Vor-/Nachnamen, dieselbe feste MercerID. Die Korrektur wird vom simulierten Operator durch Eingabe von ID, beiden Namen und eindeutiger Bestätigungsphrase freigegeben. Ergebnis: **1 trusted Send, 1 trusted Save, 1 verifizierte Status-/USC-Beschreibung**, `PASS RC29_DEMO_WRONG_SENDER_OPERATOR_REVIEW_AND_SAVE`, Exitcode 0.
- Zusätzlich sind negative Unit-Fälle Bestandteil der 277 Tests: falsche ID, falscher Vor- oder Nachname, fehlende Berechtigungsfreigabe, unstrukturiertes Profil, expliziter MercerID-Konflikt, Member/Profil-ID-Konflikt, nachträglich geänderte Member-ID/Name.
- Windows-Anzeige: Pipe-Protokoll, Nicht-Blockieren, Beschränkung auf Windows, keine Übergabe von MCR-Sitzungstoken und der verlangte `WS_EX_TRANSPARENT|WS_EX_NOACTIVATE`-Stil geprüft. **Die grafische tatsächliche Windows-Anzeige selbst wurde nicht auf Windows ausgeführt.**
- **RC28-Originalpaket → RC29:** Installationsplan, Installation, Paketprüfung, Prüfung auf unverändertes lokales Mapping, Browserprofil, Laufstatus und absichtlich offenen `SEND_INTENT`: `PASS RC28_TO_RC29_REAL_PACKAGE_UPGRADE_UNCERTAIN_SEND_PRESERVED`.
- **RC29 → RC28:** Geprüfter Software-Rückweg ohne Mutation der genannten Bestandsdaten oder Journale: `PASS RC29_TO_RC28_VERIFIED_ROLLBACK_AND_DATA_PRESERVATION`.

## Grenzen / noch kein PASS

- Auf dieser Linux-Umgebung blieb die reguläre **Vier-Szenarien-Demo** bei der zweiten fiktiven Antwort in der Probe `normal` hängen; die Probe konnte nicht als vollständig PASS bestätigt werden. Ein unabhängiger Lauf **mit der unveränderten Original-RC28-Software** blieb an derselben Stelle hängen. Der Hänger ist deshalb hier **nicht als RC29-Regression belegt**, aber es gibt auch keine vollständige RC29-Demo-Abnahme für alle vier Szenarien in dieser Umgebung.
- Kein Zugang zum echten COMARCH ECM oder zur Windows-PowerShell-Anzeige. Keine produktive Mail versendet. Keine sichere Aussage, dass jede reale COMARCH-Darstellungsvariante die strukturierten Profilfelder zur Verfügung stellt.
- Die Installation erfolgt weiterhin nur nach ihren eigenen lokalen Tests und mit dem bestehenden gesicherten RC28-Rückweg. **Ein erneuter echter RC29-Pilot ist erforderlich.**

## Datenschutz / Versandkontrolle

Die lokale CSV behält die Spalten `Ticket_ID`, `USC_Plaene`, `Standardantwort`. Personenname und MercerID erscheinen nur temporär in der eigenen Laufkonsole sowie im flüchtigen anonymen Datenkanal zum optionalen Windows-Statusfenster; sie werden nicht in neue Diagnosefelder oder die CSV aufgenommen. Bereits abgeschlossene RC28-Sendungen dürfen nicht neu versendet werden.
