# RC27 – Belegter Versand hat Vorrang vor der Zahl der OK-Meldungen

**Produktiver RC26-Befund:** Nach dem Sendeklick wurde bei einem Ticket ein neuer, eindeutig gebundener Ausgangseintrag erkannt. `SEND_DIALOGS_NOT_VERIFIED` konnte dennoch auftreten, wenn ICEFaces mehr als einen separaten Dialog als „Nachricht gesendet“ bezeichnete. Die vorausgehende Nachrichtenverlaufsprüfung wurde so von einer weiteren Dialog-Zählregel fälschlich überstimmt.

- Jetzt gilt der **bereits streng geprüfte** neue Ausgangseintrag im aktuellen Ticket als maßgeblicher Versandnachweis, auch bei zwei separaten Erfolgsmeldungen. Die echten OK-Klicks bleiben auf die sichere `permitAcknowledgement`-Regel beschränkt.
- Nur wenn anschließend der **eigene Speicherklick** und die **persistierte vollständige zusätzliche Beschreibung** nachgewiesen sind, wird der Pilot bestätigt und die automatische Folgeausführung freigegeben.
- Ohne passenden neuen Ausgangseintrag wird nie ein erneuter Sendeklick veranlasst; das Ticket bleibt zur Prüfung gesperrt.
- Ein vor dem Lauf bereits gesendetes Ticket wird weiter wie bisher markiert, gespeichert und übersprungen (ohne zweite E-Mail). Ein ursprünglich unbeantwortetes Ticket benötigt einen separaten Nachweis des **neuen** Versands.
- Keine Änderung an Namenssuche, COMARCH-Member-Identität, Kategorie, Unterkategorie, Mapping, Empfänger, Antworttext, Versandklick oder Run-Lock-Logik.

Regression: Zwei fiktive „Nachricht gesendet“-Dialoge, exakt ein gebundener neuer Ausgangseintrag, exakt ein Sendeklick und ein Speicherklick. Negative Tests für falschen Empfänger, falsche Ticket-ID, alte Nachricht und unzulässige zusätzliche Dialoge.
