# RC35 – Windows-EPERM im RC34-Phase-2-Chromium-Selbsttest

**Auslöser:** Unter Windows wurden im RC34-Menü-1-Selbsttest 331/332 Assertions erfolgreich abgeschlossen, der Test `RC34 Chromium: actual task table and textarea.value ...` scheiterte ausschließlich im `finally` mit `EPERM` beim Löschen eines temporären Edge-Profils (`MCR-P2-DOM-*`). Damit stoppte der Installer korrekt.

**Reparatur:** Der RC34-Phase-2-Browsertest ruft jetzt den seit RC21 bewährten Testprofil-Reinigungshelfer statt des synchronen `fs.rmSync` unmittelbar nach `child.kill` auf. Zunächst wird `Browser.close` per CDP angefordert und auf den Browserprozess gewartet. Dann wird der ausschließlich unter `os.tmpdir()` generierte Testordner wiederholt entfernt. Nur die bekannten temporären Sperren `EPERM`, `EACCES`, `EBUSY`, `ENOTEMPTY` können nach erfolgten UI-Assertions zu `WARN TEST_TEMP_PROFILE_CLEANUP_DEFERRED` führen; andere Dateisystemfehler werfen weiterhin und stoppen. Das echte Bot-Edge-Profil wird nicht verändert.

**Scope:** Ausschließlich die Chromium-Testbereinigung und die Zulässigkeitsprüfung von temporären Testpfaden geändert; Versions-/Manifest-/Installerprüfung aktualisiert. **Phase 1, Phase 2 und COMARCH-Produktionslogik unverändert.** Keine E-Mails, BAT-Aufrufe, Uploads oder Weiterleitungen durch diese Reparatur.

**Update:** Original RC34-Manifest ist bytegenau als vertrauenswürdige Vorversion gepinnt. RC33 bleibt ebenfalls als bekannte Vorversion für direktes Update erlaubt. Software-Rückweg und Bestandsschutz gelten unverändert.

**Prüfung:** Reale Chromium-Phase-2-DOM-Probe plus Simulation transitorischer Windows-Sperren, persistenter temporärer Sperre, unerwarteter Fehler, unsicherer Pfade und unveränderter Versand-/Weiterleitungsabläufe. Endgültige Aussage zu Windows-/COMARCH-Wirksamkeit erst nach Menü-1-Test auf dem Zielrechner.
