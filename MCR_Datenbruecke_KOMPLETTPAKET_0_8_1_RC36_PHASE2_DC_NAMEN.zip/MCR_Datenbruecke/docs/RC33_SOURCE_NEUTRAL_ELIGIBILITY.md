# RC33 – Ticketquelle ist kein Zulassungskriterium

- `Quelle` bleibt lesbare Metainformation in der COMARCH-Tabelle, bestimmt aber **nicht** mehr die Ticketauswahl. Jedes Ticket mit leerer zusaetzlicher Beschreibung oder exakt dem alten Status-only-Marker kann in die Phase-1-Pruefung gelangen, sofern es nicht in einem abgeschlossenen oder ungeklärten Journal steht.
- Vollstaendige `USC ...`-Beschreibungen bleiben Phase 2 vorbehalten. Ihre Sperre in der Erstsichtung ist **nicht** durch `Quelle` begruendet.
- `E-MAIL` nutzt weiterhin die bisherigen, strengen Identitaets-/Empfaenger-/Versandnachweise.
- Bei jeder anderen Quelle (`POST`, `BRIEF`, `PORTAL`, leer usw.) werden eine eindeutig eingehende, aktuelle Kunden-E-Mail aus dem authentifizierten Nachrichtenverlauf und die Uebereinstimmung von urspruenglichem Absender, gebundener Systemdaten-Adresse (falls vorhanden) und tatsaechlichem Antwortempfaenger zusaetzlich geprueft. Nur dann kann der normale Ablauf einen Versand vorbereiten.
- Ohne verifizierbare E-Mail wird das Ticket **ohne Aenderung und ohne Versand** im Tagesbericht zur manuellen Bearbeitung markiert; der Bot setzt mit weiteren moeglichen Tickets fort. Es erfolgt keine erfundene Adresse und keine automatische Weiterleitung unter falschem Grund.
- Nur die Quelle wurde als Kriterium entfernt; vorhandene Versand-, Forward-, Member-, Beschreibung- und Duplikatsicherungen bleiben bestehen.
- Phase-2-Kontoauszug: Die ausschliesslich lesende Vorplanung nimmt alle Quellen an, verlangt aber weiterhin bestehende unabhaengige WWID-/Status-/USC-Pruefungen; reale Phase-2-Aktionen bleiben deaktiviert.
- Produktionsabnahme: Windows/COMARCH-Echtpilot steht aus. Die Tests bilden fiktive Browser-Vorgaenge und einen gesicherten Upgrade-/Rollbackpfad ab.
