# RC28 – Fortsetzung nach Pilot und getrennte USC-/Statusspalten

## Zweck

RC27 hat den echten Piloten mit `PASS LIVE_PILOT_SEND_AND_SAVE_VERIFIED` qualifiziert. Erst beim anschließenden Neustart für die fünf Folgetickets trat `QUEUE_NAVIGATION` auf. Ein späterer Versuch, ein bereits beantwortetes Ticket zu speichern, hatte `ACTION_OCCLUDED_OR_OFFSCREEN` ausgelöst.

RC28 bindet für den zertifizierten Folgelauf eine **eigene neu angelegte Browser-Target-ID** statt irgendeiner wiederhergestellten Edge-Seite. Die Navigation zu `IN_BEARBEITUNG` wartet begrenzt auf die ICEfaces-Vorgangsansicht und darf die ausschließlich neu angelegte Seite kontrolliert neu laden. Beim Speichern werden vor **einem einzigen vertrauenswürdigen Mausklick** mehrere sichtbare Positionen und Scroll-Ausrichtungen geprüft. Ein dauerhaft verdeckter Button bleibt blockiert.

## USC und Versandstatus

Die COMARCH-Ansicht bietet nur **ein** `<textarea>` für `Zusätzliche Beschreibung`, nicht zwei eigene persistente Felder. Deshalb sind die getrennten Angaben dort **unterschiedliche Zeilen**; zusätzlich erzeugt der Bot im installierten Ordner einen echten lokalen Zwei-Spalten-CSV-Bericht unter `.runtime/reports/MCR_Bearbeitungsstatus_<lauf>.csv` mit:

- `USC_Plaene`: alle Original-USC-/DC-/PP+-/DB+-/TPP-Zeilen des verifizierten aktiven Bestands, in Quellreihenfolge.
- `Standardantwort`: exakt `Standardantwort versendet`, nur nach belegtem Versand und unabhängig belegter Speicherung.

Die CSV enthält zusätzlich `Ticket_ID` als Identifikationsspalte, keine Namen oder E-Mail-Adressen. Die produktive Intel-Excelquelle, das aktive JSON-Mapping sowie das Browserprofil und die Versandjournale bleiben unverändert. Der Bericht wird nach jedem bestätigten Speichern atomar aktualisiert. Ein optionales CSV-Dateisystemproblem wird **als Warnung** gemeldet und führt nicht zu einem zweiten Versand oder einer falschen Niederlage eines bereits korrekt gespeicherten Tickets.

Beim **neuen Versand** wird zunächst wie bisher die reine USC-/Planbeschreibung im COMARCH-Ticket gesetzt. Vor dem Sendeklick wird geprüft, dass der spätere Status plus alle USC-Zeilen in die Grenze von 450 Zeichen passen. **Erst nachdem** eine neu versendete Standardantwort eindeutig nachgewiesen ist, wird die Statuszeile hinzugefügt. Anschließend erfolgt **ein** Speicherklick und die vollständige USC-/Status-Beschreibung wird nach dem Speichern unabhängig geprüft. Der `SEND_INTENT` bleibt bei ungeklärtem Versand gesperrt.

Bei einer **bereits vorliegenden Antwort** und noch leerer **oder historisch nur mit `Standardantwort versendet` gefüllter** Zusatzbeschreibung versucht der Bot, über Original-Mail, verifizierten COMARCH-Member und aktives Mapping zunächst die USC-/Planinformationen zu ergänzen. Nur wenn das sicher gelingt, wird der Status hinzugefügt und einmal gespeichert. Schlägt Identitäts- oder Mappingprüfung fehl, wird der Fall unverändert zur manuellen Prüfung vorgemerkt; er wird nicht als bloßer `Standardantwort versendet`-Eintrag gespeichert. Es wird niemals eine zweite E-Mail versendet.

## Einschränkung

Zwei echte **COMARCH-Datenbankspalten** können ohne entsprechende Konfiguration/Erweiterung der COMARCH-Software nicht eingerichtet werden. Die lokale CSV besitzt echte getrennte Spalten, die COMARCH-Zusatzbeschreibung besitzt getrennte Zeilen. Tests gegen lokale Chromium-Fixtures sind keine produktive COMARCH-Abnahme.
