# RC34 – Phase 2 gestartet: Kontoauszuege (beaufsichtigter Einrichtungs-/Belegpilot)

## Unveraenderter Phase-1-Vertrag

Die Erstsichtung (Menue 3/4) bleibt unangetastet. Insbesondere bleiben Identitaetsnachweis, USC/TPP, Standardantwort, Send-/Save-Journal, keine Doppelantwort, Windows-Upgrade und Software-Rueckweg erhalten. **Die Quelle ist KEIN Kriterium fuer die Ticketauswahl.**

## Neu: drei getrennte Menuepunkte

**9 – COMARCH-Kontoauszug-Inventur, nur lesen.** Nach Edge-Anmeldung liest der Bot die Tabelle `mainForm:tasksTableFor_MyTasksList` und bestimmt anhand der semantischen Spalten `Ticket-ID`, `Quelle`, `Zusaetzliche Beschreibung` den Status. Mehrzeilige `textarea.value` wird vollstaendig gelesen. Dynamische `j_id`-Selektoren sind ausgeschlossen. Erkannt werden `Moechte Kontoauszug`, `Moechte KA` und die zuvor vereinbarte Variante `Moechet KA`. Der Parser unterscheidet DC, PP+, DC+PP+, unbekannte Plaene, andere Anliegen, bereits markierte Vorbereitung und unsichere Versandstatuszeilen. Optional wird **ein** Ticket geoeffnet und die Existenz der benoetigten COMARCH-Felder ausschliesslich lesend nachgeprueft. Kein `Bearbeiten`, kein Klick auf Senden, kein Draft/Save/Forward, keine Anhaenge.

**10 – Generator-Vorpruefung, nur lesen.** Die zwei bereits vorhandenen Windows-BATs und Ausgabeordner werden unter dem Elternordner `Ticket_bot` gesucht. BAT-Quelltext wird lediglich begrenzt nach Hinweisen auf `set /p`, `Read-Host` oder Parameter untersucht: ein Hinweis ist KEIN belegter Uebergabevertrag. Es wird weder ein Generator gestartet noch in den Scripts editiert.

**11 – PDF-Pilot mit manuell gestarteten Generatoren.** Voraussetzung: frische Inventur aus Menue 9 (max. eine Stunde alt), eindeutig erkannte Kontoauszug-Anweisung und kein ungeklärtes Phase-1-Journal. Verifizierte WWID und Person werden **getrennt** manuell eingegeben. Der Bot friert vor dem Start den Bestand der beiden Ausgabeordner ein; der Operator startet die vorhandenen BATs und gibt die WWID ein. Nach dem externen Lauf erkennt der Bot pro Zielplan genau **eine neue** PDF-Datei, verweigert ueberschriebene/stale/mehrdeutige Dateien, verifiziert das Dateinamensmuster und die PDF-Header-/EOF-Merkmale und erzeugt SHA256-Nachweise. Der Operator kontrolliert den Inhalt. Das aktuelle PDF-Pilotprotokoll enthaelt keine Dokumentinhalte. PDF-Dateien bleiben in den Original-Ausgabeordnern. Der vierzeilige COMARCH-Text wird aus dem zuvor unveraendert gelesenen Text als **reine Entwurfsvorschau** erzeugt; die ersten drei Zeilen werden nicht manuell neu eingetippt.

DC: `Intel_{WWID}_KA_DE_{aktuellesJahr}.pdf`.
PP+: `{Datum}_Kontoauszug_{Nachname}_{Vorname}.pdf`.

## Warum RC34 noch NICHT in COMARCH speichert oder weiterleitet

Die Original-BATs sind nicht Bestandteil des Softwarepakets; ihr tatsächlicher Ein-/Ausgabevertrag und ihre Live-PDFs sind ohne Zugriff auf den Anwender-PC nicht pruefbar. Ausserdem sind die ICEfaces-Interaktionen fuer Upload, `Anfrage Member`, `Entwurf speichern`, `Ticket speichern`, `FORWARD_TO_REVIEW`, `mark.baindl` und den finalen `Schritt ausfuehren` in Phase 2 noch nicht gegen einen fiktiven End-to-End-Browserablauf abgenommen. **Diese Operationen sind NICHT freigeschaltet und werden durch die neuen Menuepunkte niemals ausgefuehrt.** Insbesondere darf `Bearbeitet not reviewed` noch nicht geschrieben werden.

## Nachweise fuer naechste RC

(1) Menue 9: Inventurbericht `MCR_PHASE2_LETZTE_INVENTUR.json` und die Existenzpruefung der COMARCH-Felder.
(2) Menue 10: Generator-Vorpruefbericht. Bitte BAT-Inhalte separat bereitstellen, falls eine vollautomatische WWID-Uebergabe gewuenscht ist, ohne unkontrolliert eine Windows-Konsole zu steuern.
(3) Menue 11: Lokaler PDF-Beleg mit exakt einer neuen PDF je Plan, Dateiname, Groesse, SHA-256 und bestaetigter Inhaltssichtpruefung.
(4) Danach separater fiktiver COMARCH-Upload-/Entwurf-/Review-Test und erst danach ein echter Einzelticketpilot.

**Datenschutz:** Die lokalen Inventurberichte koennen Ticketnummern, Dateinamen und den originalen Ticket-Beschreibungstext enthalten. Auf dem gesicherten Windows-PC unter `.runtime/phase2` belassen; nicht ungefiltert auf oeffentliche Systeme hochladen.
