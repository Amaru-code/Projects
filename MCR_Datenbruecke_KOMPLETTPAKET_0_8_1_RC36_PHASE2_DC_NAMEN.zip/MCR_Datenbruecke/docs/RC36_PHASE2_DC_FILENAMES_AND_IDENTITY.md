# RC36 – Tatsächliche DC-Kontoauszugnamen und sichere WWID-Zuordnung

Ausgang: RC35, Menü 11, `STOP P2_PDF_NAME (DC)` trotz erzeugtem DC-Dokument. Benutzer meldet neues gewünschtes Format `{WWID}_Kontoauszug_DC.pdf`. Das beigefügte Windows-Foto zeigt **abweichend** eine am 29.10.2026 aktualisierte Datei `2024_DC_Kontoauszug_HürtgenF.pdf`, daneben eine ältere `Intel_11384834_KA_DE_2026_01.pdf`. Die Namen dürfen nicht gleichgesetzt werden; das Foto beweist nicht, welche WWID in der neuen PDF steht.

## Akzeptierte DC-Namenshinweise

1. **Stark (WWID im Namen):** `{WWID}_Kontoauszug_DC.pdf`. Keine geratenen Präfixe oder fehlenden Ziffern, exakte WWID wie vom Operator unabhängig nachgewiesen.
2. **Stark (alte Form):** `Intel_{WWID}_KA_DE_{aktuelles_Jahr}.pdf` und `Intel_{WWID}_KA_DE_{aktuelles_Jahr}_{Monat-01..12}.pdf`.
3. **Schwach (Foto/Bestandsvariante):** `{Dokumentjahr}_DC_Kontoauszug_{Nachname}{VornameInitial}.pdf`. Nur wenn Nachname/Initiale exakt zum unabhängig bestätigten Namen passen und Jahr nicht in der Zukunft liegt. **Keine WWID im Dateinamen!** Menü 11 fordert vor dem allgemeinen PDF-Review zusätzlich die explizite Kontrolle, dass im **geöffneten PDF** WWID und vollständige Person zum Originalvorgang passen (`DC_PDF_PERSON_WWID_GEPRUEFT`). Wenn nicht möglich, muss der Operator abbrechen. Der Beleg ist dauerhaft mit `wwidInFilename=false`, `manualIdentityReviewRequired=true`, `automaticAttachmentAuthorized=false` gekennzeichnet. Keine automatische COMARCH-Anlage wird dadurch erlaubt.

Für PP+ bleibt das vollständige `{Datum}_Kontoauszug_{Nachname}_{Vorname}.pdf` unverändert. Alle Dateimuster gelten ausschließlich für **exakt eine neue PDF je benötigter Planart**, nach eingefrorenem Ausgangsbestand, bei unveränderten Bestands-PDFs, gültigem PDF-Magic/EOF und SHA-256. Der Inhaltsnachweis bleibt unabhängig nötig. Dateien werden niemals umbenannt, verschoben, gelöscht, ausgeführt oder in COMARCH hochgeladen.

## Noch offener praktischer Punkt

Da RC35 beim früheren Fehlversuch den PDF-Ausgangsbestand nicht dauerhaft gespeichert hat, gehört das bereits erzeugte Dokument beim nächsten Versuch zum **Altbestand**. In Menü 11 darf es nicht stillschweigend als neu gelten. Wenn Generatoren denselben Namen überschreiben, blockiert dies ebenfalls. Deshalb bereits vorhandene DC-Dateien **zuerst außerhalb von `Ausgabe_PDF` sicher archivieren** und danach einen neuen beaufsichtigten Lauf starten – nichts löschen oder bloß umbenennen, um eine Fremdzuordnung zu verdecken. Nach RC36 weiterhin ausdrücklich: keine Generator-Automatisierung und kein COMARCH-Upload.

Versions- und Installerverträge aktualisiert, RC35-Manifest exakt als Updatequelle gepinnt, archivierte Version zurückspielbar. Keine Änderungen an Phase-1-Versand, Weiterleitung, Mapping oder COMARCH-Steuerung.
