# RC32: Keine Person in COMARCH gefunden – no-email Weiterleitung

## Ausgangspunkt

Der RC31-Echtlauf am 28.10.2026 zu Ticket `87034524` wurde zweimal bei
`MEMBER_COMMIT_VERIFY / STOP MEMBER_COMMIT` gestoppt. COMARCH lieferte nach
der manuellen Suche keinen durch Member + MercerID belegten Datensatz. Vor
jedem Versand und jeder Speicherung wurde korrekt gestoppt, aber die
Erstsichtung konnte nicht zur gewollten manuellen Zuordnung übergehen.

## Getrennter Workflow

1. Ein eindeutig bestätigter Member führt weiterhin über das bestehende
   Prüfverfahren: Name, COMARCH-Profil, MercerID, dann Bestands-Lookup,
   Standardantwort oder bestehende Weiterleitung bei Excel-Nichttreffer.
2. Wenn trotz manueller Auswahl **kein** verifizierter Member vorhanden ist,
   wird nicht automatisch behauptet, die Person existiere nicht. Die
   Terminaloptionen sind **1 Erneut auswählen**, **2 Nach aktiver Suche nicht
   in COMARCH gefunden**, **0 Ohne Änderung manuell bearbeiten**.
3. Option 2 verlangt zusätzlich die vollständige Eingabe
   `PERSON NICHT GEFUNDEN`. Wird in einem vorher oder nachher abgefragten
   DOM-Zustand eine COMARCH-MercerID oder ein Profilname sichtbar, wird die
   No-Member-Weiterleitung gesperrt. Fehlende, mehrdeutige oder unlesbare
   Member-Felder bleiben gesperrt. Ein manueller Suchtext ist nie ein Member.
4. Erst danach wird die Route zu Mark Baindl oder Victor Gutierrez ausgewählt.
   In einem Pilot ist **WEITERLEITEN** weiterhin ausdrücklich erforderlich.
   Eine verweigerte/abgebrochene Freigabe ändert das Ticket nicht und beendet nicht den gesamten Lauf: sofern zuvor kein Schreib- oder Weiterleitungsjournal angelegt wurde, wird dieser Vorgang als manuell offen protokolliert und der Bot sucht das nächste geeignete Ticket. Nach einer bereits begonnenen Speicherung/Weiterleitung stoppt er weiterhin sicher.
5. Für den COMARCH-Nichttreffer wird allein der Text
   `Person nicht in COMARCH gefunden` geschrieben – keine USC-/Planwerte,
   keine erfundene MercerID und keine E-Mail. Ein verifizierter COMARCH-Member
   ohne Excel-Eintrag behält die separate Beschreibung
   `Person nicht im Gesamtbestand gefunden`.
6. Pflichtfelder setzen; exakt eine Beschreibung speichern und per Liste
   nachprüfen; erneut öffnen, Zuständigkeit/Kategorien kontrollieren,
   gegebenenfalls maximal eine sichere Reparaturspeicherung.
7. Den Empfänger nur im echten `mainForm:persona-assignment-id` per
   bestätigtem Vorschlag auswählen. **Ein** Weiterleitungsklick mit
   Write-Ahead-Journal, dann neuen Erfolgsnachweis oder gezielte
   operatorverifizierte COMARCH-Prüfung abwarten. Bei Nichtnachweis kein
   automatischer Zweitklick.
8. Erst bei eindeutiger Weiterleitung das Ergebnis
   `COMARCH_PERSON_NICHT_GEFUNDEN_WEITERGELEITET` in den Tagesbericht
   übernehmen und das nächste zulässige Ticket bearbeiten.

## Grenzen und Wiederanlauf

Der Pilot darf nach nur einer ohne E-Mail weitergeleiteten Person keine
zusätzlichen fünf automatischen Tickets freischalten; dafür gelten die
bestehenden Versand- und Speicher-Gates. Menü 3 kann erneut gestartet
werden. Das RC31-Protokoll von Ticket `87034524` bestätigt **keinen**
Versand und **keine** Weiterleitung; der neue Code ersetzt weder
COMARCH-Prüfung noch Bedienerfreigabe. Offene Versand- und Forward-Journale
bleiben mit unverändertem Wiederanlauf- und Ausschlussverhalten erhalten.

Die bereits in RC31 angelegte Phase-2-Kontoauszugplanung bleibt strikt
lesend. Kein Ausführen der BAT-Dateien, kein PDF-Anhang, kein Ticketabschluss.

## Abnahme

Tests: Eingabe-Gates (auch falsche Bestätigungen, ungültige Felder,
nachträglich sichtbare Profile); echte fiktive Chromium-Zwei-Ticket-Routen
zu beiden erlaubten Accounts; Regression von Standardantwort, Mapping,
Rückweg und Installer. Windows-/COMARCH-Echtlauf bleibt ausstehend.
