# MCR Datenbrücke RC29: verifizierte Member-Korrektur und Live-Laufübersicht

## Ursache des gemeldeten RC28-Stopps

Am 28.10.2026 bestand der erste RC28-Echtpilot den gebundenen Versandnachweis sowie die unabhängige COMARCH-Speicherprüfung. Im ersten Folgeticket wurde ein falscher Name aus der E-Mail ermittelt. Der Operator wählte den richtigen Member im Bot-Edge; danach warf RC28 in `MEMBER_COMMIT_VERIFY` einen `MEMBER_NAME_MISMATCH`. Das ist ein **beabsichtigter Sicherheitsstopp vor Versand**, kein Nachweis, dass eine zweite Mail versendet wurde.

## Neue Ausnahmeroute

1. Normalfall: Namens-/ID-Prüfung unverändert vollautomatisch, keinerlei zusätzlicher Prompt.
2. Konfliktfall: Ein verifizierter **COMARCH-Profil-Datensatz** mit getrenntem Vor- und Nachnamen, numerischer MercerID und übereinstimmender bereits festgelegter Member-Feld-ID ist erforderlich. Eine bloß eingetippte Member-ID, ein ungeprüfter Feldname oder eine alte Profilzeile reichen nicht.
3. Die aktuelle E-Mail darf **keine ausdrücklich abweichende MercerID** enthalten. Widerspruch der COMARCH-Profil- und Member-Feld-IDs führt immer zum Stopp.
4. Der Operator sieht den falschen Mail-Namenshinweis und den tatsächlich durch COMARCH verifizierten Profilnamen mit MercerID. Nach selbstständiger Kontrolle von Originalticket, betroffener Person und Berechtigung muss er **exakt MercerID, Vorname, Nachname und den Wortlaut `ZUORDNUNG GEPRUEFT`** bestätigen.
5. Nur für **dieses eine Ticket** wird danach der verifizierte Profilname verwendet, auch für die korrekte Anrede. Unmittelbar vor dem einen Versand oder einer Weiterleitung wird der ausgewählte COMARCH-Member erneut geprüft. Ein Wechsel des Namens oder der ID invalidiert die Freigabe.
6. Journal-, Entwurfs-, Absender-/Empfänger-, Versand- und Speicherprüfungen bleiben unverändert. Kein automatischer Retry bei ungeklärter Sendung. Sicherheitsabbruch ist weiterhin möglich und gewollt.

### Grenzen

Der Bot kann die Berechtigung einer Person **nicht** aus dem bloßen Umstand ableiten, dass der Operator den richtigen Namen gefunden hat. Bei jeder Unklarheit über die tatsächliche Zuordnung **nicht freigeben**. Eine abweichende aktuelle explizite MercerID ist auch mit manueller Bestätigung niemals übersteuerbar. Ohne übereinstimmendes strukturiertes COMARCH-Profil bleibt der Lauf gesperrt; reale DOM-Abnahme ist erforderlich.

## Kleines Windows-Statusfenster

Bei einem echten Lauf startet der Bot auf Windows ein separates, nur lesendes PowerShell-/Windows-Forms-Fenster (kein zusätzlicher Browser). Angezeigt werden die aktuelle Ticket-ID, der erkannte bzw. verifizierte Personenname, die COMARCH-MercerID, USC/Planzeilen und der belegte Versandstatus. Bei Statusänderungen wird asynchron aktualisiert; der Bot wartet **nicht** darauf. Ein Ticketabschluss blendet das Fenster bei Inaktivität dezent ab, ein neues Ticket hebt es wieder hervor, und nach dem Lauf schließt sich die Anzeige durch Ausblenden.

Die Anzeige ist **nicht fokussierbar, mausdurchlässig, ohne Netzwerkzugriff**, nicht zum Klicken gedacht und steuert nie den Bot. Namen/IDs werden nur im anonymen Prozess-STDIN übertragen, nicht in neue Status- oder Diagnose-Dateien geschrieben. Das vorhandene Datenformat der CSV bleibt unverändert. Ist Windows PowerShell oder die Formularbibliothek gesperrt, läuft der Bot ohne Overlay weiter. Bei Bedarf vor dem Start in der `START.cmd`-Konsole `set MCR_PROGRESS_OVERLAY=0` setzen, um die Anzeige für diesen Start zu deaktivieren.

## Prüfung und erneuter Pilot

Einen erneuten echten Pilot mit **einem bislang unbeantworteten Ticket** ausführen (`Menü 3`), nachdem das Update installiert wurde. Eine alte RC28-Pilotfreigabe ist an die RC28-Manifest-SHA gebunden und qualifiziert RC29 absichtlich nicht automatisch. Vorherigen RC28-Abbruch ohne Sendeklick nicht als bereits versendet deklarieren; Menü 5 bzw. die automatische Vor-Aktions-Aufarbeitung schützt die bereits versendeten Tickets. RC28-Tickets mit bestätigter E-Mail werden nie blind wiederholt.

Die beigefügten Browserdemos verwenden ausschließlich fiktive Daten; ein echter COMARCH-Windows-Test und eine Beobachtung des nativen Statusfensters sind nach wie vor erforderlich.
