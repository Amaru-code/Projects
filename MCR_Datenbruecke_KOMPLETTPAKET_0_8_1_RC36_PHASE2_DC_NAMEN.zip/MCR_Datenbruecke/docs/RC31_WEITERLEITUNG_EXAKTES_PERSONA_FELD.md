# MCR Datenbruecke 0.8.1-rc.31 – Weiterleitung ohne E-Mail

## Anlass / reproduzierter COMARCH-Stopp

Am 28.10.2026 bei Ticket 87086074: COMARCH-Member und Name wurden kontrolliert
geprüft; beide Bestands-Lookups (exakt und 11-prefix) ergaben keinen Treffer.
Der Operator gab `WEITERLEITEN` frei; COMARCH erhielt **einen** verifizierten
Speicherklick. Der Tages-Log endete mit:

`STOP ROUTE_FIXED_FIELDS_NOT_SAVED [PHASE FORWARD_MISSING_PERSON]`

Das bedeutet **kein nachgewiesener Weiterleitungsklick**, nicht dass das
E-Mail-System abgestürzt wäre. Es gab keinen Standardantwortversand für dieses
Ticket. Die genaue Kombination nicht gespeicherter Felder ist aus RC30s
Sammelfehler nicht rekonstruierbar.

## RC31 Workflow

1. Original-Mail, strukturierten COMARCH-Member, MercerID und fehlenden
   Bestand weiterhin sicher prüfen; kein E-Mail-Versand bei Nichttreffer.
2. `Person nicht im Gesamtbestand gefunden` setzen. Second Level,
   Allgemeine Schriftwechsel, Personenschriftwechsel und Signatur **vor dem
   Speichern** exakt prüfen.
3. Terminal fragt bei **jedem echten** fehlenden Bestandsdatensatz:
   `1 Baindl Mark (mark.baindl)`, `2 Gutierrez Victor (Victor.Gutierrez)`,
   `0 keine Weiterleitung`. Andere Eingaben werden bis zu dreimal erneut
   erfragt, danach kein Weiterleitungsklick.
4. Im Pilot zusätzlich `WEITERLEITEN` zur Freigabe; kein zweites Nachsenden.
5. Beschreibung einmal speichern und in der echten Ticketliste prüfen;
   selben Vorgang erneut öffnen.
6. Nach dem Öffnen müssen **Zuständigkeit, Kategorie, Unterkategorie**
   unverändert sein. Die Signatur gehört zur Antwortmaske, wurde bereits
   **vor** dem Speichern geprüft und wird bei einem Vorgang ohne E-Mail
   nicht fälschlich als dauerhaftes Routingfeld vorausgesetzt.
7. Fehlende Pflichtfelder werden höchstens **einmal** nachgesetzt und mit
   separatem, dauerhaftem Journaleintrag erneut gespeichert und geprüft.
   Bleiben sie anschließend falsch oder nicht lesbar, STOP vor Weiterleitung.
8. Bearbeiter nur im eindeutigen sichtbaren Feld
   `mainForm:persona-assignment-id` suchen. Die alte geometrische
   Nachbarfeld-Heuristik wurde entfernt. Nur eindeutiger Vorschlag mit
   korrektem Account und Name darf mit echtem Mausereignis gewählt werden.
   Bei UI-Problemen bedingter manueller Fokus bzw. ausdrückliche Auswahl
   des exakt angezeigten Vorschlags, anschließend erneute Wertkontrolle.
9. Die bestehende Schaltfläche `Weiterleitung` erhält **höchstens einen**
   Browserklick, erst nach dauerhaftem `FORWARD_INTENT`. Erfolg muss durch
   eine *neu aufgetretene* Erfolgsmeldung nachgewiesen werden. Bleibt ein
   DOM-Beweis aus, darf der Operator das Ergebnis direkt in COMARCH prüfen
   und manuell `WEITERGELEITET` bestätigen. Kein automatischer Zweitklick.
10. Erst nach dem eindeutigen Nachweis wird `ROUTED_CONFIRMED` gespeichert
    und die Suche nach dem nächsten Ticket fortgesetzt.

## Nicht Teil des Fixes

- Kein automatischer Standardantwortversand an unbekannte Personen.
- Keine Phase-2-Kontoauszug-BAT-Aufrufe, Anhänge oder Weiterleitung zur
  fachlichen Überprüfung nach `FORWARD_TO_REVIEW`.
- Kein automatischer erneuter Forward nach einem `FORWARD_INTENT` oder
  `ROUTE_REPAIR_SAVE_INTENT` mit unklarem Abschluss.

## Wiederanlauf nach RC30-Abbruch

Das zuvor gespeicherte Ticket 87086074 ist auf die bestehende
Ticketbeschreibung und einen offenen Forward-Status zu prüfen. Der
Menü-5-Dialog darf `SICHER_NICHT_WEITERGELEITET` nur nach eigenständiger
COMARCH-Prüfung erhalten. Da die Beschreibung bereits befüllt ist, wird
es vom Erstkontakt-Filter nicht unbemerkt erneut aufgegriffen. Eine noch
nötige Weiterleitung dieses Altfalls muss gegebenenfalls manuell durchgeführt
werden. Erst neue geeignete Tickets durchlaufen den RC31-Ablauf automatisch.

## Abnahmegrenzen

Gezielte Tests umfassen ein echtes Chromium-Dropdown mit beiden erlaubten
Zielkonten, das nicht zu verwendende Nachbarfeld, eine nach dem Speichern
leere Signatur, eine einmal reparierbare bzw. dauerhaft verlorene
Pflichtfeldgruppe, mehrere identische Vorschläge und einen fehlenden
Weiterleitungsnachweis. Die Tests verwenden ausschließlich fiktive Daten.
Eine reale Windows-/COMARCH-Abnahme bleibt erforderlich.
