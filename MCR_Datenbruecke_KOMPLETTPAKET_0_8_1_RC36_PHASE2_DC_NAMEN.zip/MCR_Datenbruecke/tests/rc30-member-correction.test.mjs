import test from 'node:test';import assert from 'node:assert/strict';
import {correctionPlan,confirmMemberCorrection,requireReviewedMember,reviewReceipt} from '../lib/member-review.mjs';
const profile={id:'11568211',firstName:'Lytkin',lastName:'Maksim',source:'MEMBER_PROFILE_VERIFIED',profileIdMatches:true};
const mail={firstName:'Maksim',lastName:'Lytkin'};
const answers=xs=>{const list=[...xs];return async()=>list.shift()??''};
test('RC30 explicit swapped profile recognized but requires all operator checks',async()=>{
 const plan=correctionPlan(profile,mail,{});assert.equal(plan.swappedProfile,true);
 assert.deepEqual([plan.person.firstName,plan.person.lastName],['Maksim','Lytkin']);
 const r=await confirmMemberCorrection({member:profile,mailPerson:mail,ask:answers(['11568211','Maksim','Lytkin','ZUORDNUNG GEPRUEFT'])});
 const receipt=reviewReceipt(profile,r.person,r.reviewed,{swappedProfile:r.swappedProfile});
 assert.equal(r.swappedProfile,true);assert.equal(requireReviewedMember(profile,r.person,{},receipt),true);
 assert.throws(()=>requireReviewedMember({...profile,id:'11568212'},r.person,{},receipt),{code:'MEMBER_REVIEW_CHANGED'});
 assert.throws(()=>requireReviewedMember({...profile,firstName:'Fremd'},r.person,{},receipt),{code:'MEMBER_REVIEW_CHANGED'});
 assert.throws(()=>requireReviewedMember({...profile,source:'MEMBER_FIELD'},r.person,{},receipt),{code:'MEMBER_REVIEW_CHANGED'});
 assert.throws(()=>requireReviewedMember(profile,r.person,{expectedId:'999999'},receipt),{code:'MEMBER_ID_CONFLICT'});
});
test('RC30 correction permits uppercase and typo retry, without reducing evidence',async()=>{
 const logs=[];
 const r=await confirmMemberCorrection({member:profile,mailPerson:mail,
  ask:answers(['11568211','lytkin','MAKSIM','LYTKIN','ZUORDNUNG GEPRUEFT']),log:x=>logs.push(x)});
 assert.equal(r.reviewed,true);assert.ok(logs.some(x=>x.includes('ANDEREN Namensfeld')));
});
test('RC30 three wrong attempts then alternative surname cannot bypass full name checks',async()=>{
 const m={...profile,firstName:'Daniel',lastName:'Beispiel'},wrong={firstName:'Max',lastName:'Mustermann'};
 const r=await confirmMemberCorrection({member:m,mailPerson:wrong,
  ask:answers(['11568211','Falsch','Falsch','Falsch','NACHNAME','BEISPIEL','Daniel','Beispiel','ZUORDNUNG GEPRUEFT'])});
 assert.equal(r.reviewed,true);
 await assert.rejects(confirmMemberCorrection({member:m,mailPerson:wrong,
  ask:answers(['11568211','Falsch','Falsch','Falsch','NACHNAME','Fremd'])}),{code:'MEMBER_REVIEW_RESELECT'});
});
test('RC30 no auto approval for near-match, wrong ID, incomplete profile, or abort',async()=>{
 const altered={...profile,lastName:'Maxim'};
 assert.equal(correctionPlan(altered,mail,{}).swappedProfile,false);
 await assert.rejects(confirmMemberCorrection({member:profile,mailPerson:mail,
  ask:answers(['999999','999999','999999','ABBRUCH'])}),{code:'MEMBER_REVIEW_ID_NOT_CONFIRMED'});
 await assert.rejects(confirmMemberCorrection({member:profile,mailPerson:mail,
  ask:answers(['ABBRUCH'])}),{code:'MEMBER_REVIEW_CANCELLED'});
 await assert.rejects(confirmMemberCorrection({member:profile,mailPerson:mail,evidence:{expectedId:'000000'},
  ask:answers(['11568211','Maksim','Lytkin','ZUORDNUNG GEPRUEFT'])}),{code:'MEMBER_ID_CONFLICT'});
});
