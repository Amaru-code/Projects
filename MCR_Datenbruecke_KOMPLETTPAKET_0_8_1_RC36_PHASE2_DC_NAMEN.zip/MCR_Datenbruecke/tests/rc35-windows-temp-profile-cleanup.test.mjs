import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {ROOT} from './helpers.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
const make=()=>fs.mkdtempSync(path.join(os.tmpdir(),'MCR-P2-DOM-'));
const locked=code=>Object.assign(new Error('simulated Windows profile lock'),{code});

test('RC35 Phase2 test-only transient Windows EPERM retries and removes profile',async()=>{
 const profile=make();let attempts=0,closes=0;
 const cdp={async send(m){assert.equal(m,'Browser.close');closes++;},close(){closes++;}};
 const result=await cleanupTemporaryTestBrowser({profile,cdp,browser:{child:{exitCode:0,signalCode:null}},pause:async()=>{},remove:async(p,o)=>{
  attempts++;if(attempts<5)throw locked('EPERM');await fs.promises.rm(p,o);
 }});
 assert.equal(result.removed,true);assert.equal(attempts,5);assert.equal(closes,2);assert.equal(fs.existsSync(profile),false);
});

test('RC35 Phase2 permanent Windows lock warns after completed DOM assertions',async()=>{
 const profile=make(),warnings=[];
 try{
  const result=await cleanupTemporaryTestBrowser({profile,attempts:2,pause:async()=>{},remove:async()=>{throw locked('EBUSY')},warning:s=>warnings.push(s)});
  assert.equal(result.removed,false);assert.equal(result.errorCode,'EBUSY');assert.equal(warnings.length,1);
  assert.match(warnings[0],/CLEANUP_DEFERRED/);
 }finally{fs.rmSync(profile,{recursive:true,force:true});}
});

test('RC35 Phase2 unexpected IO errors still fail and unsafe profile paths blocked',async()=>{
 const profile=make();
 try{await assert.rejects(cleanupTemporaryTestBrowser({profile,remove:async()=>{throw locked('EIO')}}),{code:'EIO'});}
 finally{fs.rmSync(profile,{recursive:true,force:true});}
 await assert.rejects(cleanupTemporaryTestBrowser({profile:path.join(os.tmpdir(),'MCR-REAL-EDGE'),remove:async()=>{throw new Error('MUST_NOT_RUN')}}),/UNSAFE_TEST_PROFILE_PATH/);
 await assert.rejects(cleanupTemporaryTestBrowser({profile:path.join(os.tmpdir(),'other','MCR-P2-DOM-evil'),remove:async()=>{throw new Error('MUST_NOT_RUN')}}),/UNSAFE_TEST_PROFILE_PATH/);
});

test('RC35 original RC34 manifest is independently pinned for direct upgrade',async()=>{
 const {verifyPrevious}=await import('../tools/integrity.mjs');
 const {sha256}=await import('../lib/core.mjs');
 const manifest=fs.readFileSync(path.join(ROOT,'tools/reference/complete-0.8.1-rc.34-manifest.json'));
 assert.equal(sha256(manifest),'772d34d7fe0580f4f76e9743130f43985e38794d3306bd4a765cd93810e98101');
 assert.match(verifyPrevious.toString(),/0\.8\.1-rc\.34/);
});
