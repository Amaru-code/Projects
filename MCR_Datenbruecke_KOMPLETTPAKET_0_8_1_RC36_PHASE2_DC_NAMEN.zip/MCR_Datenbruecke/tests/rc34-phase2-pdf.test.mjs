import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';
import {localGeneratorInventory,snapshotStatementOutputs,verifyNewStatements,approvedWwid} from '../lib/phase2-pdf-evidence.mjs';
const make=()=>{const base=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-P2-GEN-')),root=path.join(base,'MCR_Datenbruecke');fs.mkdirSync(root);
 const pp=path.join(base,'Kontoauszug_pp+'),dc=path.join(base,'Kontoauszug DC');for(const folder of [pp,dc])fs.mkdirSync(path.join(folder,'Ausgabe_PDF'),{recursive:true});
 fs.writeFileSync(path.join(pp,'START_KONTOAUSZUG.bat'),'@echo off\nset /p WWID=WWID: \n');
 fs.writeFileSync(path.join(dc,'START_KONTOAUSZUG_DC.bat'),'@echo off\nset /p WWID=WWID: \n');
 const fake=(name,folder)=>{const pdf=Buffer.concat([Buffer.from('%PDF-1.4\n'),Buffer.alloc(200,0x20),Buffer.from('\n%%EOF\n')]);fs.writeFileSync(path.join(folder,'Ausgabe_PDF',name),pdf);};
 return {base,root,pp,dc,fake,clean:()=>fs.rmSync(base,{recursive:true,force:true})};};
test('RC34 preflight inspects BAT without ever executing it',{timeout:10000},()=>{const a=make();try{
 const r=localGeneratorInventory(a.root);assert.equal(r.executed,false);assert.equal(r.plans.length,2);assert.ok(r.plans.every(x=>x.scriptPresent&&x.outputPresent&&x.operatorInputHint==='INTERACTIVE_PROMPT_POSSIBLE'));
 }finally{a.clean();}});
test('RC34 two PDFs must be genuinely new, match DC WWID and PP+ full name and have valid signature',()=>{
 const a=make();try{a.fake('old.pdf',a.pp);const before=snapshotStatementOutputs(a.root,['DC','PP+']);
 a.fake('Intel_12345678_KA_DE_2026.pdf',a.dc);a.fake('20261029_Kontoauszug_Mustermann_Max.pdf',a.pp);
 const report=verifyNewStatements(a.root,before,{wwid:'12345678',first:'Max',last:'Mustermann',year:2026});
 assert.equal(report.artifacts.length,2);assert.deepEqual(report.targets,['DC','PP+']);assert.equal(report.ticketEffects,0);assert.equal(report.comarchEffects,0);
 }finally{a.clean();}});
test('RC34 wrong name/WWID, zero/multiple PDFs and stale overwrite fail closed',()=>{
 const a=make();try{
  assert.throws(()=>approvedWwid('not a WWID'),x=>x.code==='P2_WWID_INVALID');
  let baseline=snapshotStatementOutputs(a.root,['DC']);
  assert.throws(()=>verifyNewStatements(a.root,baseline,{wwid:'12345678',first:'Max',last:'Mustermann'}),x=>x.code==='P2_PDF_COUNT');
  a.fake('Intel_98765432_KA_DE_2026.pdf',a.dc);
  assert.throws(()=>verifyNewStatements(a.root,baseline,{wwid:'12345678',first:'Max',last:'Mustermann',year:2026}),x=>x.code==='P2_PDF_NAME');
  baseline=snapshotStatementOutputs(a.root,['DC']);
  fs.appendFileSync(path.join(a.dc,'Ausgabe_PDF','Intel_98765432_KA_DE_2026.pdf'),'increment');
  assert.throws(()=>verifyNewStatements(a.root,baseline,{wwid:'12345678',first:'Max',last:'Mustermann'}),x=>x.code==='P2_EXISTING_PDF_OVERWRITTEN');
 }finally{a.clean();}});
test('RC34 refuses non-PDF payload masquerading as freshly produced .pdf',()=>{
 const a=make();try{const before=snapshotStatementOutputs(a.root,['DC']);
 fs.writeFileSync(path.join(a.dc,'Ausgabe_PDF','Intel_12345678_KA_DE_2026.pdf'),'junk junk junk'.repeat(12));
 assert.throws(()=>verifyNewStatements(a.root,before,{wwid:'12345678',first:'Max',last:'Mustermann',year:2026}),x=>x.code==='P2_PDF_HEADER');
 }finally{a.clean();}});
