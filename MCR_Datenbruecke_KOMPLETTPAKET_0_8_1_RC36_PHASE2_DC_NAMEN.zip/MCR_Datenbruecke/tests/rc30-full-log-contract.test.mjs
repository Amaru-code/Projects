import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';
import {runChild} from '../tools/cli.mjs';
test('RC30 complete runner transcript appends pilot and follow-on across process exits',async()=>{
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC30-LOG-'));
 try{
  const mock=path.join(root,'fake-process.mjs'),log=path.join(root,'report.log');
  fs.writeFileSync(mock,"process.stdout.write('TICKET_RESULT 90000001\\n');process.stderr.write('WARN CHECK\\n');");
  for(let i=0;i<2;i++){
   const r=await runChild(mock,[],{logFile:log});assert.equal(r.code,0);
  }
  const text=fs.readFileSync(log,'utf8');
  assert.equal(text.split('TICKET_RESULT 90000001').length-1,2);
  assert.equal(text.split('=== MCR').length-1,2);
  assert.equal(text.split('WARN CHECK').length-1,2);
  console.log('PASS RC30_TWO_PROCESSES_ONE_TRANSCRIPT');
 }finally{fs.rmSync(root,{recursive:true,force:true});}
});
