import test from 'node:test';import assert from 'node:assert/strict';
import {safePreactionSkip} from '../lib/preaction-skip.mjs';

test('RC32 route recipient cancelled: no journal, no actions, skip only before edit',()=>{
 for(const code of ['ROUTE_OPERATOR_CANCEL','ROUTE_NOT_ARMED']){
  for(const phase of ['FORWARD_COMARCH_MEMBER_NOT_FOUND','FORWARD_MISSING_PERSON']){
   assert.equal(safePreactionSkip(code,phase), 'ROUTE_DECLINED');
   assert.equal(safePreactionSkip(code,phase,{pending:true}),null);
   assert.equal(safePreactionSkip(code,phase,{demo:true}),null);
  }
  for(const phase of ['ROUTE_FIELD_REPAIR','FORWARD_MISSING_PERSON_AFTER_SAVE','SEND_AND_SAVE','POST_SEND_STATUS_AND_SAVE','MEMBER_COMMIT_VERIFY']){
   assert.equal(safePreactionSkip(code,phase),null);
  }
 }
});

test('RC32 unresolved COMARCH Member can leave ticket for manual review, never mask side effects',()=>{
 assert.equal(safePreactionSkip('COMARCH_MEMBER_REVIEW_CANCELLED','MEMBER_COMMIT_VERIFY'),'IDENTITY_REVIEW');
 assert.equal(safePreactionSkip('COMARCH_MEMBER_IDENTITY_UNRESOLVED','MEMBER_COMMIT_VERIFY'),'IDENTITY_REVIEW');
 assert.equal(safePreactionSkip('COMARCH_MEMBER_IDENTITY_UNRESOLVED','FORWARD_COMARCH_MEMBER_NOT_FOUND'),null);
 assert.equal(safePreactionSkip('COMARCH_MEMBER_REVIEW_CANCELLED','MEMBER_COMMIT_VERIFY',{pending:true}),null);
 for(const code of ['COMARCH_MEMBER_NOW_SELECTED','ROUTE_FIXED_FIELDS_NOT_PERSISTED','SAVE_UNVERIFIED','SEND_UNVERIFIED','ASSIGNEE_NOT_SELECTED','FORWARD_UNVERIFIED']){
  assert.equal(safePreactionSkip(code,'MEMBER_COMMIT_VERIFY'),null);
  assert.equal(safePreactionSkip(code,'FORWARD_COMARCH_MEMBER_NOT_FOUND'),null);
 }
});
