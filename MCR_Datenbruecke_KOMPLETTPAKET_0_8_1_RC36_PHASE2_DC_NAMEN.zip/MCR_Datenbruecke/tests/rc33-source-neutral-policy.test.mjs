import test from 'node:test';import assert from 'node:assert/strict';
import {firstPassCandidate,nonEmailReplyProof} from '../lib/source-neutral-policy.mjs';
const incoming={sender:'max@example.invalid',recipient:'support@example.invalid',subject:'[MERCER#90000001] Anfrage',content:'Guten Tag',direction:'INCOMING',documentId:'12'};
const valid={source:'POST',history:{ok:true,rows:[incoming]},recipient:{ok:true,address:'max@example.invalid'},senderMetadata:{ok:false}};
test('RC33 Quelle is never a candidate filter; only description and ticket status matter',()=>{
 for(const source of ['POST','BRIEF','PORTAL','FAX','',null,'E-MAIL'])assert.equal(firstPassCandidate({ticketId:'90000001',source,descriptionBlank:true,descriptionValue:''}),true);
 assert.equal(firstPassCandidate({ticketId:'90000001',source:'POST',descriptionBlank:false,descriptionValue:'Standardantwort versendet'}),true);
 for(const description of ['USC 20/ DC;PP+\nStandardantwort versendet','Möchte Kontoauszug','Stansardantwort versendet'])assert.equal(firstPassCandidate({ticketId:'90000001',source:'E-MAIL',descriptionBlank:false,descriptionValue:description}),false);
 assert.equal(firstPassCandidate({ticketId:'abc',descriptionBlank:true,descriptionValue:''}),false);
});
test('RC33 non-email source with bounded inbound actual customer email can be processed',()=>{
 assert.deepEqual(nonEmailReplyProof(valid),{ok:true,mode:'NON_EMAIL_SOURCE_WITH_BOUND_INCOMING_EMAIL'});
 assert.deepEqual(nonEmailReplyProof({...valid,source:'PORTAL',senderMetadata:{ok:true,senderEmail:'max@example.invalid'}}),{ok:true,mode:'NON_EMAIL_SOURCE_WITH_BOUND_INCOMING_EMAIL'});
 assert.equal(nonEmailReplyProof({...valid,source:'E-MAIL'}).ok,true);
});
test('RC33 no email, ambiguous sender, wrong recipient, old outgoing cannot trigger send',()=>{
 const failing=[
  {...valid,history:{ok:false,rows:[]}},
  {...valid,history:{ok:true,rows:[{...incoming,direction:'UNKNOWN'}]}},
  {...valid,history:{ok:true,rows:[{...incoming,direction:'OUTGOING'}]}},
  {...valid,history:{ok:true,rows:[{...incoming,sender:'postmaster@example.invalid'}]}},
  {...valid,history:{ok:true,rows:[incoming,{...incoming,sender:'someone@example.invalid',documentId:'16'}]}},
  {...valid,recipient:{ok:true,address:'different@example.invalid'}},
  {...valid,senderMetadata:{ok:true,senderEmail:'different@example.invalid'}},
 ];
 for(const x of failing)assert.equal(nonEmailReplyProof(x).ok,false,JSON.stringify(x));
});
