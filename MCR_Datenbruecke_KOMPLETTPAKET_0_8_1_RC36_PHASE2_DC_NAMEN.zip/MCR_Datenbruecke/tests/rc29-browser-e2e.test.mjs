/** RC29 REAL CHROMIUM / FICTIONAL DATA. No COMARCH connection or real delivery.
 * Recovers from a sender who names a different person, with explicit scripted
 * operator review; verifies a single trusted send and a single save. */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {ROOT} from './helpers.mjs';

test('RC29 browser: incorrect sender corrected by strict operator profile review, exactly one trusted send and save', {timeout:180000}, ()=>{
 const d=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC29-CORRECTION-'));
 try{
  for(const n of ['src','lib','examples','config'])fs.cpSync(path.join(ROOT,n),path.join(d,n),{recursive:true});
  const cfgPath=path.join(d,'config/local-runner-queue-send.json');
  const cfg=JSON.parse(fs.readFileSync(cfgPath,'utf8'));
  fs.writeFileSync(cfgPath,JSON.stringify({...cfg,profileDirectory:'.runtime/edge-profile',downloadDirectory:'.runtime/downloads',runtimeDirectory:'.runtime',diagnosticDirectory:'diagnostics'}));
  const out=spawnSync(process.execPath,[path.join(d,'src/local-bot-full-run.mjs'),'--demo','--close-browser'],
   {cwd:d,encoding:'utf8',env:{...process.env,MCR_DEMO_SCENARIO:'rc29-incorrect-sender',MCR_DEMO_TICKET_LIMIT:'1',MCR_RUN_ID:'rc29browserqa'},timeout:150000,maxBuffer:8*1024*1024});
  assert.equal(out.status,0,'RC29 fictional run failed: '+String(out.stderr||'')+'\n'+String(out.stdout||'').slice(-2500));
  assert.match(out.stdout,/PASS RC29_DEMO_WRONG_SENDER_OPERATOR_REVIEW_AND_SAVE/);
  const diag=JSON.parse(fs.readFileSync(path.join(d,'diagnostics/last-result.json'),'utf8'));
  assert.equal(diag.lastError,null);assert.equal(diag.loop.processed,1);
  assert.equal(diag.loop.processedTickets[0].memberOperatorReview,true);
  assert.equal(diag.send.clicked,true);assert.equal(diag.send.verified,true);
  assert.equal(diag.save.clicked,true);assert.equal(diag.save.verified,true);
  assert.deepEqual(diag.demoBrowser.trustedSends,[true]);assert.deepEqual(diag.demoBrowser.trustedSaves,[true]);
  assert.equal(diag.demoBrowser.sendClicks,1);assert.equal(diag.demoBrowser.saveClicks,1);
  assert.equal(diag.memberReview.correctedBeforeAnySend,true);
  assert.ok(!JSON.stringify(diag).includes('Daniel Beispiel'),'Diagnosis must not contain PII');
  console.log('PASS RC29_REAL_CHROMIUM_WRONG_SENDER_OPERATOR_REVIEW');
 }finally{fs.rmSync(d,{recursive:true,force:true,maxRetries:5,retryDelay:200});}
});
