/** RC28 Chromium regression: a restarted browser profile may contain a stale
 * COMARCH tab. The certified follow-on must bind its OWN tab and navigate
 * only via trusted, visible process-menu controls. No real COMARCH access. */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage,attachFreshPage} from '../lib/cdp.mjs';
import {navigateToScope,navigationSnapshot} from '../lib/browser-workflow.mjs';
import {actionPoint} from '../lib/browser-actions.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';

test('RC28 fresh continuation page ignores restored/stale COMARCH tab; delayed menu recovery works',async()=>{
 const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC20-NOTE-RC28-FRESH-'));
 let browser,cdp;
 try{
  browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,
   extraArgs:process.platform==='linux'?['--no-sandbox','--disable-dev-shm-usage']:[]});
  ({cdp}=await connectBrowser(browser.port));
  const old=await attachPage(cdp,t=>t.type==='page'&&t.url==='about:blank');
  await old.eval(`document.body.innerHTML='<h1>Stale detail from previous task</h1><div id="mainForm:member-value-id"></div>'`);
  const fresh=await attachFreshPage(cdp,'about:blank');
  assert.notEqual(fresh.targetId,old.targetId,'Continuation must own a distinct browser target');
  await fresh.call(()=>{
   document.body.innerHTML='<form><input type="password" /></form>';
   setTimeout(()=>{
    document.body.innerHTML='<a class="tab_section_processes" id="process">Vorgänge</a><a title="Meine Vorgänge" id="header">Meine Vorgänge</a><span id="storedSearchesContainer_MY_TASKS" style="display:none"><a id="child">In_Bearbeitung</a></span><div id="main"></div>';
    const h=document.getElementById('header'),c=document.getElementById('child');
    const open=()=>document.getElementById('storedSearchesContainer_MY_TASKS').style.display='inline';
    h.onclick=open;document.getElementById('process').onclick=open;
    c.onclick=()=>document.getElementById('main').innerHTML='<table id="mainForm:tasksTableFor_MyTasksList"><thead><tr><th>Ticket-ID</th><th>Quelle</th><th>Zusätzliche Beschreibung</th></tr></thead><tbody><tr><td>90000001</td><td>E-MAIL</td><td></td></tr></tbody></table>';
   },950);
  });
  const q=await navigateToScope(fresh,'IN_BEARBEITUNG',{startup:true});
  assert.equal(q.ok,true);assert.equal(q.scope,'IN_BEARBEITUNG');assert.equal(q.rows[0].ticketId,'90000001');
  assert.equal((await navigationSnapshot(fresh)).hasTaskMenu,true);
  assert.ok(await old.call(()=>document.body.textContent.includes('Stale detail')),'Stale tab should remain untouched');
  console.log('PASS RC28_FRESH_TARGET_DELAYED_MENU_NAVIGATION');
 }finally{await cleanupTemporaryTestBrowser({profile,browser,cdp});}
});

test('RC28 passive save geometry recovery never issues a second or occluded click',async()=>{
 const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC20-NOTE-RC28-GEOM-'));
 let browser,cdp;
 try{
  browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,
   extraArgs:process.platform==='linux'?['--no-sandbox','--disable-dev-shm-usage']:[]});
  ({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.type==='page'&&t.url==='about:blank');
  await page.call(()=>{
   document.body.innerHTML='<style>body{height:2000px}#save{display:block;position:absolute;top:400px;left:60px;background:#cfc;padding:14px}#cover{position:fixed;inset:0;z-index:999;background:#ccc}</style><a id="save">Ticket speichern</a><div id="cover"></div>';
   window.__saved=0;document.getElementById('save').onclick=e=>{if(e.isTrusted)window.__saved++;};
   setTimeout(()=>document.getElementById('cover')?.remove(),340);
  });
  const point=await actionPoint(page,{text:'Ticket speichern',relocate:true});
  assert.equal(point.ok,true,JSON.stringify(point));
  await page.mouseClick(point.x,point.y);
  assert.equal(await page.eval('window.__saved'),1,'Save clicked exactly once');
  await page.call(()=>{const x=document.createElement('div');x.id='cover';x.style.cssText='position:fixed;inset:0;z-index:999;background:#ccc';document.body.append(x);});
  const blocked=await actionPoint(page,{text:'Ticket speichern',relocate:true});
  assert.equal(blocked.ok,false);assert.equal(blocked.state,'ACTION_OCCLUDED_OR_OFFSCREEN');
  assert.equal(await page.eval('window.__saved'),1,'No click through a permanent obstruction');
  console.log('PASS RC28_ONE_TRUSTED_SAVE_ZERO_OCCLUDED_CLICKS');
 }finally{await cleanupTemporaryTestBrowser({profile,browser,cdp});}
});
