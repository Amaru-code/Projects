import test from 'node:test';
import assert from 'node:assert/strict';
import {
 COMARCH_NOT_FOUND_DESCRIPTION,memberAbsenceGate,chooseUnresolvedMemberAction
} from '../lib/comarch-missing-member.mjs';
const blank={fieldCount:1,editable:true,embeddedId:false,profileId:false,profileName:false,enteredSearch:true};
const yes=()=>({...blank});
test('RC32 missing COMARCH Member is separately noted, never made into fake MercerID',()=>{
 assert.equal(COMARCH_NOT_FOUND_DESCRIPTION,'Person nicht in COMARCH gefunden');
 assert.equal(memberAbsenceGate(blank).ok,true);
 for(const o of [{...blank,embeddedId:true},{...blank,profileId:true},{...blank,profileName:true},{...blank,fieldCount:2},{...blank,editable:false}]){
  assert.equal(memberAbsenceGate(o).ok,false);
 }
});
test('RC32 operator confirms missing Member explicitly; no silent no-member route',async()=>{
 const script=['2','PERSON NICHT GEFUNDEN'];let calls=0;
 const result=await chooseUnresolvedMemberAction({ask:async()=>{calls++;return script.shift();},observe:yes});
 assert.equal(result,'NOT_FOUND');assert.equal(calls,2);
 await assert.rejects(()=>chooseUnresolvedMemberAction({ask:async()=> '0',observe:yes}),{code:'COMARCH_MEMBER_REVIEW_CANCELLED'});
 await assert.rejects(()=>chooseUnresolvedMemberAction({ask:async()=> '2',observe:()=>({...blank,embeddedId:true})}),{code:'COMARCH_MEMBER_IDENTITY_UNRESOLVED'});
 await assert.rejects(()=>chooseUnresolvedMemberAction({ask:async()=> '2',observe:()=>({...blank,profileName:true})}),{code:'COMARCH_MEMBER_IDENTITY_UNRESOLVED'});
});
test('RC32 retry selection remains available, three false confirmations cannot forward',async()=>{
 const mode=await chooseUnresolvedMemberAction({ask:async()=> '1',observe:yes});assert.equal(mode,'RECHECK');
 const script=['2','nein','2','KAPUTT','2',''];
 await assert.rejects(()=>chooseUnresolvedMemberAction({ask:async()=> script.shift(),observe:yes}),{code:'COMARCH_MEMBER_REVIEW_CANCELLED'});
 const demo=await chooseUnresolvedMemberAction({ask:async()=>{throw Error('demo must not prompt');},observe:yes,demo:true});
 assert.equal(demo,'NOT_FOUND');
});
test('RC32 profile appearing between operator confirmation and recheck blocks route',async()=>{
 let count=0;
 await assert.rejects(()=>chooseUnresolvedMemberAction({
  ask:async()=>count++===0?'2':'PERSON NICHT GEFUNDEN',
  observe:async()=>count>=2?{...blank,profileId:true}:blank
 }),{code:'COMARCH_MEMBER_IDENTITY_UNRESOLVED'});
});
