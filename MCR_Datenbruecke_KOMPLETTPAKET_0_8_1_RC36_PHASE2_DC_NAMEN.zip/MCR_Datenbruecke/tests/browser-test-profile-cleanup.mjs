/** Test-only Chromium cleanup. Never use this for the permanent bot Edge profile.
 * Windows/Edge may keep profile handles open after child.kill(); closing via
 * CDP and awaiting process exit before async retry avoids the EPERM race.
 * If another process (e.g. AV scanner) still holds a TEMP profile, report
 * a warning rather than turn a completed functional test into a false failure.
 */
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {sleep} from '../lib/cdp.mjs';

const LOCK_CODES=new Set(['EPERM','EACCES','EBUSY','ENOTEMPTY']);
function exited(child){return !child||child.exitCode!==null||child.signalCode!==null;}
async function waitForExit(child,ms){
 if(exited(child))return true;
 return new Promise(resolve=>{
  let done=false;
  const finish=()=>{if(done)return;done=true;clearTimeout(timer);child.removeListener('exit',finish);child.removeListener('error',finish);resolve(exited(child));};
  const timer=setTimeout(finish,ms);
  child.once('exit',finish);child.once('error',finish);
 });
}

export async function cleanupTemporaryTestBrowser({profile,browser,cdp,remove=fs.rm,pause=sleep,warning=console.warn,attempts=18,shutdownWaitMs=5000}={}){
 // Constrain deletion to a generated temp profile: never touch user Edge data.
 if(typeof profile!=='string'||path.dirname(path.resolve(profile))!==path.resolve(os.tmpdir())||!['MCR-RC20-NOTE-','MCR-P2-DOM-'].some(prefix=>path.basename(profile).startsWith(prefix)))throw new Error('UNSAFE_TEST_PROFILE_PATH');
 try{await cdp?.send('Browser.close',{},null,1800);}catch{} // Browser closes connection without always replying.
 try{cdp?.close();}catch{}
 const child=browser?.child;
 if(child&&!exited(child)){
  if(!await waitForExit(child,1800)){
   try{child.kill();}catch{}
   await waitForExit(child,shutdownWaitMs);
  }
 }
 let last;
 for(let i=0;i<attempts;i++){
  try{
   await remove(profile,{recursive:true,force:true,maxRetries:1,retryDelay:200});
   return {removed:true,attempts:i+1};
  }catch(e){
   if(e?.code==='ENOENT')return {removed:true,attempts:i+1};
   if(!LOCK_CODES.has(e?.code))throw e;
   last=e;
   if(i<attempts-1)await pause(Math.min(250+i*175,1250));
  }
 }
 warning('WARN TEST_TEMP_PROFILE_CLEANUP_DEFERRED: '+last.code+' after browser shutdown; only the generated temporary Edge test directory may remain. Ticket and mail tests already passed.');
 return {removed:false,attempts,errorCode:last.code};
}
