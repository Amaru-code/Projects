import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import {spawnSync} from 'node:child_process';
import {ROOT} from './helpers.mjs';
test('RC30 real Chromium: exactly swapped profile needs explicit review and exactly one send+save', {timeout:180000},()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC30-SWAP-'));
 try{
  for(const n of ['src','lib','examples','config'])fs.cpSync(path.join(ROOT,n),path.join(dir,n),{recursive:true});
  const p=path.join(dir,'config/local-runner-queue-send.json'),cfg=JSON.parse(fs.readFileSync(p,'utf8'));
  fs.writeFileSync(p,JSON.stringify({...cfg,profileDirectory:'.runtime/edge-profile',downloadDirectory:'.runtime/downloads',runtimeDirectory:'.runtime',diagnosticDirectory:'diagnostics'}));
  const r=spawnSync(process.execPath,[path.join(dir,'src/local-bot-full-run.mjs'),'--demo','--close-browser'],{
   cwd:dir,encoding:'utf8',env:{...process.env,MCR_DEMO_SCENARIO:'rc30-swapped-member',MCR_DEMO_TICKET_LIMIT:'1',MCR_RUN_ID:'rc30swapproof'},timeout:150000,maxBuffer:9*1024*1024});
  assert.equal(r.status,0,JSON.stringify({stdout:r.stdout?.slice(-2200),stderr:r.stderr?.slice(-1500),signal:r.signal}));
  assert.match(r.stdout,/HINWEIS PROFILFELDER VERTAUSCHT/);
  assert.match(r.stdout,/PASS RC30_DEMO_SWAPPED_MEMBER_OPERATOR_REVIEW_AND_SAVE/);
  const diag=JSON.parse(fs.readFileSync(path.join(dir,'diagnostics/last-result.json'),'utf8'));
  assert.equal(diag.loop.processed,1);assert.equal(diag.lastError,null);
  assert.equal(diag.send.clicked,true);assert.equal(diag.send.verified,true);
  assert.equal(diag.save.clicked,true);assert.equal(diag.save.verified,true);
  assert.equal(diag.demoBrowser.sendClicks,1);assert.equal(diag.demoBrowser.saveClicks,1);
  console.log('PASS RC30_REAL_CHROMIUM_SWAPPED_IDENTITY_ONE_SEND_ONE_SAVE');
 }finally{fs.rmSync(dir,{recursive:true,force:true,maxRetries:6,retryDelay:200});}
});
