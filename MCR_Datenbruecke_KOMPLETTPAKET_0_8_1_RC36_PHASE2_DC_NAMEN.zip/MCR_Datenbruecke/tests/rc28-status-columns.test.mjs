import test from 'node:test';
import assert from 'node:assert/strict';
import {descriptionWithStatus,statusColumns,statusCsv,REPORT_COLUMNS} from '../lib/status-columns.mjs';
import {descriptionUnits} from '../lib/multirow-tpp-mapping.mjs';
import {STANDARD_ANSWER_NOTE} from '../lib/mail-history-audit.mjs';

test('RC28 USC and confirmed standard reply coexist without truncation',()=>{
 const usc='USC 18/ DC;PP+\nUSC 28/ DB+;TPP';
 const combined=descriptionWithStatus(usc);
 assert.equal(combined,usc+'\n'+STANDARD_ANSWER_NOTE);
 assert.equal(statusColumns(combined).uscLines,2);
 assert.equal(statusColumns(combined).uscPlaene,'USC 18/ DC;PP+ | USC 28/ DB+;TPP');
 assert.equal(statusColumns(combined).standardantwort,STANDARD_ANSWER_NOTE);
 assert.ok(descriptionUnits(combined)<=450);
});
test('RC28 status is absent before sent proof and cannot be silently asserted',()=>{
 assert.throws(()=>statusColumns('USC 18/ DC;PP+'),/Versandstatus fehlt/);
 assert.throws(()=>statusColumns(STANDARD_ANSWER_NOTE),/USC\/Planinformationen fehlen/);
 assert.throws(()=>statusColumns('USC 18/ DC\n'+STANDARD_ANSWER_NOTE+'\n'+STANDARD_ANSWER_NOTE),/mehrfach/);
});
test('RC28 status 450-character capacity is checked before send',()=>{
 const source='USC 18/ '+('D'.repeat(425));
 assert.ok(descriptionUnits(source)<=450);
 assert.throws(()=>descriptionWithStatus(source),e=>e.code==='STATUS_DESCRIPTION_TOO_LONG');
});
test('RC28 separate CSV columns preserve USC multiline and Excel delimiters',()=>{
 const desc=descriptionWithStatus('USC 18/ DC;PP+\nUSC 28/ DB+;TPP');
 const csv=statusCsv([{ticketId:'90000001',description:desc}]);
 assert.deepEqual(REPORT_COLUMNS,['Ticket_ID','USC_Plaene','Standardantwort']);
 assert.match(csv,/^\ufeffTicket_ID;USC_Plaene;Standardantwort\r\n/);
 assert.ok(csv.includes('"90000001";"USC 18/ DC;PP+ | USC 28/ DB+;TPP";"Standardantwort versendet"'));
 assert.throws(()=>statusCsv([{ticketId:'90000001',description:desc},{ticketId:'90000001',description:desc}]),/doppelt/);
});
test('RC28 no fabricated COMARCH database columns or mapping mutation',()=>{
 const desc='USC 18/ DC;PP+';
 const result=descriptionWithStatus(desc);
 assert.equal(desc,'USC 18/ DC;PP+');
 assert.ok(result.endsWith('\nStandardantwort versendet'));
});
