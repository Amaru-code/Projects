import test from 'node:test';import assert from 'node:assert/strict';
import {classifyPhase2Row,phase2Inventory} from '../lib/phase2-readonly.mjs';
const row=(descriptionValue,source='POST',ticketId='87393963')=>({ticketId,descriptionValue,source});
test('RC34 Phase2 recognizes source-neutral DC+PP+ request on original three lines',()=>{
 const item=classifyPhase2Row(row('USC 20/ DC;PP+\nStandardantwort versendet\nMöchte Kontoauszug'));
 assert.equal(item.kind,'NEEDS_VERIFIED_WWID');assert.deepEqual(item.targets,['DC','PP+']);assert.equal(item.source,'POST');
});
test('RC34 Phase2 KA alias, PP+ only, unrelated cases',()=>{
 assert.deepEqual(classifyPhase2Row(row('USC 10/PP+\nStandardantwort versendet\nMöchet KA')).targets,['PP+']);
 assert.equal(classifyPhase2Row(row('USC 10/PP+\nStandardantwort versendet\nMöchte Versorgungsausgleich')).kind,'OTHER_PHASE2_REQUEST');
 assert.equal(classifyPhase2Row(row('USC 10/PP+\nStandardantwort versendet')).kind,'NOT_KONTOAUSZUG');
});
test('RC34 Phase2 never promotes typo, missing status, unsupported plan or completed work',()=>{
 assert.equal(classifyPhase2Row(row('USC 20/ DC;PP+\nStansardantwort versendet\nMöchte Kontoauszug')).reason,'STANDARD_MARKER_UNCERTAIN');
 assert.equal(classifyPhase2Row(row('USC 20/ DC;PP+\nMöchte Kontoauszug')).kind,'REVIEW');
 assert.equal(classifyPhase2Row(row('USC 20/ DB+\nStandardantwort versendet\nMöchte KA')).reason,'NO_DC_PP_PLAN');
 assert.equal(classifyPhase2Row(row('USC 20/ DC;XY\nStandardantwort versendet\nMöchte KA')).reason,'PLANS_UNKNOWN');
 assert.equal(classifyPhase2Row(row('USC 20/ DC\nStandardantwort versendet\nMöchte KA\nBearbeitet not reviewed')).kind,'ALREADY_PREPARED');
 assert.equal(classifyPhase2Row(row('USC 20/ DC\nStandardantwort versendet\nMöchte KA\nMöchte Kontoauszug')).reason,'DUPLICATED_REQUEST');
});
test('RC34 Phase2 non-email source does not exclude but unresolved send journal does',()=>{
 const a=row('USC 20/ DC\nStandardantwort versendet\nMöchte KA','PORTAL');
 const report=phase2Inventory([a,row('USC 20/ DC\nStandardantwort versendet\nMöchte KA','POST','87086074')],{pendingIds:['87086074']});
 assert.equal(report.items[0].kind,'NEEDS_VERIFIED_WWID');assert.match(report.items[0].descriptionValue,/Möchte KA/);assert.equal(report.items[1].reason,'UNRESOLVED_PHASE1_JOURNAL');assert.equal(report.readyForActions,0);
});
