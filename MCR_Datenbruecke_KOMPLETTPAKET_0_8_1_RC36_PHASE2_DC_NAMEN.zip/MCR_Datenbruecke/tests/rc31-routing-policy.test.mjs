import test from 'node:test';import assert from 'node:assert/strict';
import {routeFixedAssessment} from '../lib/route-fixed-policy.mjs';
import {chooseForwardDestination,forwardingDestination,FORWARD_DESTINATIONS,ROUTE_FIELD_ID} from '../lib/forwarding.mjs';
const expected={responsibility:'Second Level',category:'Allgemeine Schriftwechsel',subcategory:'Personenschriftwechsel',signature:'INTL01 - Intel Deutschland GmbH'};
test('RC31 route post-save check does not demand a persisted email signature',()=>{
 assert.deepEqual(routeFixedAssessment({...expected,signature:''},expected),{ok:true,missing:[]});
 assert.deepEqual(routeFixedAssessment({...expected,signature:'XXX'},expected),{ok:true,missing:[]});
});
test('RC31 any missing persisted responsibility/category/subcategory blocks forward',()=>{
 for(const key of ['responsibility','category','subcategory']){
  const changed={...expected,[key]:''};
  assert.deepEqual(routeFixedAssessment(changed,expected),{ok:false,missing:[key]});
 }
});
test('RC31 exactly two whitelisted accounts and exact COMARCH field',()=>{
 assert.equal(ROUTE_FIELD_ID,'mainForm:persona-assignment-id');
 assert.deepEqual(FORWARD_DESTINATIONS.map(x=>[x.key,x.account]),[['1','mark.baindl'],['2','Victor.Gutierrez']]);
 assert.equal(forwardingDestination('3'),null);
});
test('RC31 terminal selection retries typos and allows explicit cancel',async()=>{
 const scripted=['A','3','1'];let count=0;
 const choice=await chooseForwardDestination(async()=>{count++;return scripted.shift();},()=>{});
 assert.equal(count,3);assert.equal(choice.account,'mark.baindl');
 await assert.rejects(()=>chooseForwardDestination(async()=> '0',()=>{}),{code:'ROUTE_OPERATOR_CANCEL'});
 await assert.rejects(()=>chooseForwardDestination(async()=> 'maybe',()=>{}),{code:'ROUTE_OPERATOR_CANCEL'});
 assert.equal((await chooseForwardDestination(async()=>{throw new Error('not called');},()=>{}, {demo:true})).account,'Victor.Gutierrez');
});

test('RC31 repair save is separately journaled and bounded to one attempt',async()=>{
 const {ledger}=await import('../lib/control.mjs');
 const fs=await import('node:fs'),os=await import('node:os'),path=await import('node:path');
 const temp=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC31-LEDGER-'));
 try{
  const j=ledger(temp);
  j.beginForward('90000001','Person nicht im Gesamtbestand gefunden');
  j.forwardSet('90000001','ROUTE_SAVE_INTENT');
  j.forwardSet('90000001','ROUTE_SAVED_VERIFIED');
  j.forwardSet('90000001','ROUTE_REPAIR_SAVE_INTENT');
  j.forwardSet('90000001','ROUTE_SAVED_VERIFIED');
  assert.throws(()=>j.forwardSet('90000001','ROUTE_REPAIR_SAVE_INTENT'),{code:'ROUTE_REPAIR_LIMIT'});
  j.forwardSet('90000001','FORWARD_INTENT');
  j.forwardSet('90000001','ROUTED_CONFIRMED');
  assert.deepEqual(j.completedIds(),['90000001']);
 }finally{fs.rmSync(temp,{force:true,recursive:true});}
});

test('RC31 interrupted repair is recognized as pending and cannot auto-retry',async()=>{
 const {ledger}=await import('../lib/control.mjs');const {pendingSnapshot,blockedTicketIds}=await import('../lib/run-reset.mjs');
 const fs=await import('node:fs'),os=await import('node:os'),path=await import('node:path');
 const temp=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC31-PENDING-'));
 try{
  const j=ledger(temp);j.beginForward('90000012','Person nicht im Gesamtbestand gefunden');
  j.forwardSet('90000012','ROUTE_SAVE_INTENT');j.forwardSet('90000012','ROUTE_SAVED_VERIFIED');j.forwardSet('90000012','ROUTE_REPAIR_SAVE_INTENT');
  assert.equal(pendingSnapshot(temp)[0].state,'ROUTE_REPAIR_SAVE_INTENT');
  assert.deepEqual(blockedTicketIds(temp),['90000012']);
 }finally{fs.rmSync(temp,{force:true,recursive:true});}
});

test('RC31 stale success notice is not forwarding proof, new identical notice is',async()=>{
 const {forwardConfirmed,forwardingDestination}=await import('../lib/forwarding.mjs');
 const destination=forwardingDestination('2');
 const note='weiterleitung erfolgreich an gutierrez victor';
 const fakePage=notes=>({call:async()=>notes});
 assert.equal((await forwardConfirmed(fakePage([note]),destination,[note])).ok,false);
 assert.equal((await forwardConfirmed(fakePage([note,note]),destination,[note])).ok,true);
 assert.equal((await forwardConfirmed(fakePage(['andere meldung']),destination,[])).ok,false);
 for(const error of ['weiterleitung an gutierrez victor nicht möglich','weiterleitung fehlgeschlagen: gutierrez victor','weiterleitung nicht erfolgreich','weiterleitung wurde abgebrochen']){
  assert.equal((await forwardConfirmed(fakePage([error]),destination,[])).ok,false,error);
 }
 assert.equal((await forwardConfirmed(fakePage(['vorgang erfolgreich weitergeleitet']),destination,[])).ok,true);
});
