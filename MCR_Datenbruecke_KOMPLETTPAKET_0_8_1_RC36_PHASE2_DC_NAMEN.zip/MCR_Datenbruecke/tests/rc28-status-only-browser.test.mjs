import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {upgradeStatusOnlyDescription} from '../lib/browser-workflow.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
import {descriptionWithStatus} from '../lib/status-columns.mjs';

test('RC28 legacy status-only is upgraded only when field exactly matches, preserving reply draft',async()=>{
 const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC20-NOTE-RC28-STATUS-'));let browser,cdp;
 try{
  browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,
   extraArgs:process.platform==='linux'?['--no-sandbox','--disable-dev-shm-usage']:[]});
  ({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.url==='about:blank');
  await page.call(()=>{
   document.body.innerHTML='<div id="mainForm:document-data-section"><label>Zusätzliche Beschreibung:<textarea>Standardantwort versendet</textarea></label></div><iframe id="draft"></iframe>';
   document.getElementById('draft').contentDocument.body.innerText='Fremder, gespeicherter Entwurf – nicht ändern';
  });
  const a=await upgradeStatusOnlyDescription(page,'USC 10/ DC;PP+\nUSC 12/ DB+','Standardantwort versendet');
  assert.equal(a.ok,true,JSON.stringify(a));assert.equal(a.value,descriptionWithStatus('USC 10/ DC;PP+\nUSC 12/ DB+'));
  const same=await upgradeStatusOnlyDescription(page,'USC 10/ DC;PP+','Standardantwort versendet');
  assert.equal(same.ok,false);assert.equal(same.state,'STATUS_ONLY_FIELD_CHANGED');
  const actual=await page.call(()=>({description:document.querySelector('textarea').value,draft:document.getElementById('draft').contentDocument.body.innerText}));
  assert.equal(actual.description,a.value);assert.equal(actual.draft,'Fremder, gespeicherter Entwurf – nicht ändern');
 }finally{await cleanupTemporaryTestBrowser({profile,browser,cdp});}
});
