import test from 'node:test';
import assert from 'node:assert/strict';
import {EventEmitter} from 'node:events';
import {overlayMessage,createProgressOverlay} from '../lib/progress-overlay.mjs';

test('RC29 status message JSONL cannot inject protocol fields/terminal controls',()=>{
 const e=JSON.parse(overlayMessage({event:'update',ticket:'90000001',name:'A\nB',id:'99900001',usc:'USC 11/ PP+',answered:'Nein',phase:'Lauf',unsupported:'never'}));
 assert.equal(e.schema,'MCR_PROGRESS_V1');assert.equal(e.ticket,'90000001');assert.equal(e.name,'A B');
 assert.equal(e.unsupported,undefined);
 assert.equal(JSON.parse(overlayMessage({event:'arbitrary'})).event,'update');
});
test('RC29 overlay disabled on non-Windows and never touches network/files',()=>{
 const x=createProgressOverlay({platform:'linux',env:{}});
 assert.equal(x.enabled,false);assert.doesNotThrow(()=>{x.update({ticket:'999'});x.close();});
});
test('RC29 window progress is non-blocking, one-way, and closes pipe',()=>{
 const received=[];let args;
 const launcher=(exe,argv,options)=>{
  args={exe,argv,options};const p=new EventEmitter();
  p.stdin=new EventEmitter();p.stdin.writable=true;p.stdin.write=x=>{received.push(x);return true;};p.stdin.end=()=>{p.stdin.writable=false;};return p;
 };
 const x=createProgressOverlay({platform:'win32',env:{},launcher});
 assert.equal(x.enabled,true);assert.equal(args.exe,'powershell.exe');
 assert.deepEqual(args.options.stdio,['pipe','ignore','ignore']);
 assert.equal(args.options.env.MCR_SESSION_TOKEN,undefined);
 x.update({event:'start',ticket:'90000001'});x.update({name:'Anna Example',answered:'JA'});
 x.close({phase:'Beendet'});x.update({event:'update',ticket:'bad'});
 assert.equal(received.length,3);assert.equal(JSON.parse(received[0]).ticket,'90000001');
 assert.equal(JSON.parse(received[1]).name,'Anna Example');assert.equal(JSON.parse(received[2]).event,'close');
});
test('RC29 no Windows overlay if explicitly disabled',()=>{
 let called=false;const x=createProgressOverlay({platform:'win32',env:{MCR_PROGRESS_OVERLAY:'0'},launcher:()=>{called=true;}});
 assert.equal(x.enabled,false);assert.equal(called,false);
});
