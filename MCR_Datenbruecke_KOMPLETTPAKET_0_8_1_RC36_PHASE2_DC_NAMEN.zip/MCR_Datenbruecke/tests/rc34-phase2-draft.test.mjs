import test from 'node:test';import assert from 'node:assert/strict';
import {phase2DraftPreview} from '../lib/phase2-draft-preview.mjs';
const ticketId='87393963',description='USC 20/ DC;PP+\nStandardantwort versendet\nMöchte Kontoauszug';
const pdfProof={schema:'MCR_PHASE2_PDF_PROOF_V1',ticketId,operatorContentReviewed:true,
 artifacts:[{plan:'DC',sha256:'a'.repeat(64),bytes:1000},{plan:'PP+',sha256:'b'.repeat(64),bytes:2000}]};
test('RC34 prepares 4th line append-only after both PDFs and operator review, never writes COMARCH',()=>{
 const r=phase2DraftPreview({ticketId,description,source:'POST',pdfProof});
 assert.equal(r.descriptionAfter,description+'\nBearbeitet not reviewed');assert.equal(r.reviewAssignee,'mark.baindl');
 assert.equal(r.gevotransaction,'Anfrage Member');assert.equal(r.reviewChoice,'FORWARD_TO_REVIEW');
 assert.equal(r.writeAuthorized,false);assert.equal(r.status,'PREVIEW_ONLY_NO_COMARCH_MUTATION');
});
test('RC34 never prepares draft with missing plan, mismatched identity or duplicate marker',()=>{
 assert.throws(()=>phase2DraftPreview({ticketId,description,source:'POST',pdfProof:{...pdfProof,artifacts:pdfProof.artifacts.slice(0,1)}}),x=>x.code==='P2_DRAFT_PDF_COUNT');
 assert.throws(()=>phase2DraftPreview({ticketId,description,source:'POST',pdfProof:{...pdfProof,ticketId:'00000001'}}),x=>x.code==='P2_DRAFT_PDF_PROOF');
 assert.throws(()=>phase2DraftPreview({ticketId,description:description+'\nBearbeitet not reviewed',source:'POST',pdfProof}),x=>x.code==='P2_DRAFT_REQUEST');
 assert.throws(()=>phase2DraftPreview({ticketId,description:description+'\n'+'x'.repeat(370),source:'POST',pdfProof}),x=>x.code==='P2_DRAFT_TOO_LONG');
});
