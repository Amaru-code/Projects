import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import {spawnSync} from 'node:child_process';
import {ROOT} from './helpers.mjs';
for(const [scenario,shouldSend] of [['rc33-post-incoming',true],['rc33-post-no-mail',false],['rc33-post-wrong-recipient',false]]){
 test('RC33 Chromium non-EMAIL source '+scenario,{timeout:150000},()=>{
  const temp=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC33-SOURCE-'));
  try{
   for(const n of ['src','lib','examples','config'])fs.cpSync(path.join(ROOT,n),path.join(temp,n),{recursive:true});
   const f=path.join(temp,'config/local-runner-queue-send.json'),cfg=JSON.parse(fs.readFileSync(f));
   fs.writeFileSync(f,JSON.stringify({...cfg,profileDirectory:'.runtime/edge-profile',downloadDirectory:'.runtime/downloads',runtimeDirectory:'.runtime',diagnosticDirectory:'diagnostics'}));
   const result=spawnSync(process.execPath,[path.join(temp,'src/local-bot-full-run.mjs'),'--demo','--close-browser'],{
    cwd:temp,encoding:'utf8',env:{...process.env,MCR_DEMO_SCENARIO:scenario,MCR_RUN_ID:'rc33-'+scenario},timeout:140000,maxBuffer:10*1024*1024});
   assert.equal(result.status,0,JSON.stringify({stdout:result.stdout?.slice(-3600),stderr:result.stderr?.slice(-1500),signal:result.signal}));
   const d=JSON.parse(fs.readFileSync(path.join(temp,'diagnostics/last-result.json'),'utf8'));
   if(shouldSend){assert.match(result.stdout,/PASS SOURCE_NEUTRAL_EMAIL_PROOF/);assert.equal(d.loop.processed,2);assert.equal(d.demoBrowser.sendClicks,2);assert.equal(d.demoBrowser.saveClicks,2);assert.equal(d.send.verified,true);}
   else{assert.match(result.stdout,/SKIP_NO_VERIFIED_EMAIL_FOR_SOURCE/);assert.equal(d.loop.processed,0);assert.equal(d.loop.skippedWithoutEmail,2);assert.equal(d.demoBrowser.sendClicks,0);assert.equal(d.demoBrowser.saveClicks,0);}
   console.log('PASS RC33_SOURCE_NEUTRAL_BROWSER '+scenario);
  }finally{fs.rmSync(temp,{recursive:true,force:true,maxRetries:5,retryDelay:200});}
 });
}
