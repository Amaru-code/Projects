import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';import os from 'node:os';
import {spawn} from 'node:child_process';import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
async function run(scenario){const temp=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC19-SKIPNEXT-'));
 try{
  for(const d of ['src','lib','config','examples'])fs.cpSync(path.join(root,d),path.join(temp,d),{recursive:true});
  const file=path.join(temp,'config/local-runner-queue-send.json'),cfg=JSON.parse(fs.readFileSync(file));Object.assign(cfg,{runtimeDirectory:'.runtime',profileDirectory:'.runtime/edge-profile',downloadDirectory:'.runtime/downloads',diagnosticDirectory:'diagnostics'});fs.writeFileSync(file,JSON.stringify(cfg));
  const {code,out}=await new Promise((resolve,reject)=>{const p=spawn(process.execPath,[path.join(temp,'src/local-bot-full-run.mjs'),'--demo','--close-browser'],{cwd:temp,env:{...process.env,MCR_DEMO_SCENARIO:scenario},stdio:['ignore','pipe','pipe']});let out='';p.stdout.on('data',b=>out+=b.toString());p.stderr.on('data',b=>out+=b.toString());const timer=setTimeout(()=>p.kill(),90000);p.on('error',reject);p.once('exit',code=>{clearTimeout(timer);resolve({code,out});});});
  return {code,out,d:JSON.parse(fs.readFileSync(path.join(temp,'diagnostics/last-result.json')))};
 }finally{fs.rmSync(temp,{recursive:true,force:true,maxRetries:10,retryDelay:150});}}

test('RC19 skip only preanswered first ticket, process next once',async()=>{
 const r=await run('rc19-first-answered');assert.equal(r.code,0,r.out);assert.equal(r.d.loop.skippedAlreadyAnswered,1);assert.equal(r.d.loop.processed,1);assert.equal(r.d.demoBrowser.sendClicks,1);assert.equal(r.d.demoBrowser.saveClicks,2);assert.equal(r.d.loop.annotatedAlreadyAnswered,1);assert.equal(r.d.demoBrowser.savedStandardMarkers,2);assert.ok(r.d.demoBrowser.trustedSends.every(Boolean));assert.ok(r.out.includes('PASS SKIP_ALREADY_ANSWERED'));assert.ok(r.out.includes('PASS OFFLINE_DEMO_SKIP_ONE_THEN_SEND_ONE'));
});
