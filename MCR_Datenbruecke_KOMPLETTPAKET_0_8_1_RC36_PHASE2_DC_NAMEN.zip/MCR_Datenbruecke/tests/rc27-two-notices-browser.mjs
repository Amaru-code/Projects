/** Distinct COMARCH success notices must not block bound outgoing -> save. */
import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';import os from 'node:os';import {spawn} from 'node:child_process';import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC27-Notices-'));
try{
 for(const dir of ['src','lib','examples','config'])fs.cpSync(path.join(root,dir),path.join(tmp,dir),{recursive:true});
 const f=path.join(tmp,'config/local-runner-queue-send.json');const cfg=JSON.parse(fs.readFileSync(f,'utf8'));
 Object.assign(cfg,{runtimeDirectory:'.runtime',profileDirectory:'.runtime/edge-profile',downloadDirectory:'.runtime/downloads',diagnosticDirectory:'diagnostics'});fs.writeFileSync(f,JSON.stringify(cfg,null,2)+'\n');
 const run=await new Promise((resolve,reject)=>{const env={...process.env,MCR_DEMO_SCENARIO:'rc27-two-success-notices',MCR_DEMO_TICKET_LIMIT:'1'};delete env.NODE_OPTIONS;delete env.NODE_PATH;
  const child=spawn(process.execPath,[path.join(tmp,'src/local-bot-full-run.mjs'),'--demo','--close-browser'],{cwd:tmp,env,stdio:['ignore','pipe','pipe']});let out='';
  const timer=setTimeout(()=>child.kill('SIGKILL'),80000);for(const stream of [child.stdout,child.stderr])stream.on('data',buf=>{out+=buf.toString();if(out.length>120000)out=out.slice(-120000);});
  child.once('error',reject);child.once('exit',(code,signal)=>{clearTimeout(timer);resolve({code,signal,out});});});
 const d=JSON.parse(fs.readFileSync(path.join(tmp,'diagnostics/last-result.json'),'utf8'));
 assert.equal(run.code,0,run.out.slice(-3000));assert.equal(d.lastError,null);
 assert.equal(d.send.htmlDialogs,2);assert.equal(d.send.successNotices,2);
 assert.equal(d.send.verified,true);assert.equal(d.send.boundHistoryVerified,true);assert.equal(d.send.ackMode,'BOUND_NEW_OUTGOING_HISTORY');
 assert.equal(d.save.verified,true);assert.equal(d.loop.processed,1);
 assert.equal(d.demoBrowser.sendClicks,1);assert.equal(d.demoBrowser.saveClicks,1);assert.equal(d.demoBrowser.okClicks,2);
 assert.deepEqual(d.demoBrowser.trustedSends,[true]);assert.deepEqual(d.demoBrowser.trustedSaves,[true]);assert.deepEqual(d.demoBrowser.trustedOkClicks,[true,true]);
 assert.match(run.out,/PASS SEND_IN_HISTORY_BOUND/);
 console.log('PASS RC27 TWO_SUCCESS_NOTICES -> ONE_SEND -> ONE_SAVED_TICKET');
}finally{try{fs.rmSync(tmp,{recursive:true,force:true,maxRetries:7,retryDelay:250});}catch(e){if(!['EPERM','EBUSY','EACCES','ENOTEMPTY'].includes(e?.code))throw e;console.log('WARN RC27 TEST_TEMP_LOCK');}}
