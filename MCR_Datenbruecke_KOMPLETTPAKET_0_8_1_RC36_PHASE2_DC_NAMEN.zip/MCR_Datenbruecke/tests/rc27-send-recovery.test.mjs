/** Regression for real RC26 SEND_DIALOGS_NOT_VERIFIED despite a bound new outgoing mail. */
import test from 'node:test';import assert from 'node:assert/strict';
import {validSendAcknowledgements,permitAcknowledgement} from '../lib/send-dialog-policy.mjs';
import {verifiedNewOutgoingAcknowledgement} from '../lib/mail-history-audit.mjs';
import {certifyPilot} from '../tools/proof.mjs';
const ticket='87422280',recipient='person@example.invalid';
const standard='Sehr geehrte Damen und Herren. Mit dieser E-Mail möchten wir Ihnen bestätigen, dass wir Ihr Ticket erhalten haben und unser Team derzeit daran arbeitet.';
const inbound={direction:'INCOMING',sender:recipient,recipient:'servicelineintel@mercer.com',documentId:'12800001',subject:'Auskunft zur betrieblichen Altersversorgung und Pensionsplan',content:'Bitte um Auskunft',date:'2026-10-28 10:00'};
const outgoing={direction:'OUTGOING',sender:'servicelineintel@mercer.com',recipient,documentId:'12800002',subject:'[MERCER#'+ticket+'] Auskunft zur betrieblichen Altersversorgung und Pensionsplan',content:standard,date:'2026-10-28 10:05'};
const snap=rows=>({ok:true,rows});
function proofState(patch={}){return {htmlDialogs:2,jsDialogs:0,successNotices:2,ackMode:'BOUND_NEW_OUTGOING_HISTORY',boundHistoryVerified:true,...patch};}
test('RC27: two sent-information dialogs and one truly new bound outgoing mail certify ONE send',()=>{
 const proof=verifiedNewOutgoingAcknowledgement(snap([inbound]),snap([inbound,outgoing]),ticket,recipient);
 assert.equal(proof.verified,true,proof.reason);
 assert.equal(permitAcknowledgement({previous:0,successNotices:0,success:true,type:'html'}),true);
 assert.equal(permitAcknowledgement({previous:1,successNotices:1,success:true,type:'html'}),true);
 assert.equal(validSendAcknowledgements(proofState()),true);
 const pilot={mode:'REAL',lastError:null,send:{...proofState(),verified:true,clicked:true},save:{verified:true},loop:{completed:true,finishReason:'PILOT_LIMIT_AFTER_VERIFIED_SAVE',processed:1,myTasksProcessed:1,queueProcessed:0,processedTickets:[{sendAck:'BOUND_NEW_OUTGOING_HISTORY',save:'MY_TASKS_ALL_DESCRIPTION_CONTENT_MATCH'}]}};
 assert.equal(certifyPilot(pilot),true);
});
test('RC27: dialogs alone, stale history, foreign recipient and wrong ticket cannot certify a send',()=>{
 assert.equal(validSendAcknowledgements(proofState({ackMode:null})),false);
 assert.equal(validSendAcknowledgements(proofState({boundHistoryVerified:false})),false);
 assert.equal(verifiedNewOutgoingAcknowledgement(snap([inbound]),snap([inbound]),ticket,recipient).verified,false);
 assert.equal(verifiedNewOutgoingAcknowledgement(snap([inbound]),snap([inbound,{...outgoing,recipient:'other@example.invalid'}]),ticket,recipient).verified,false);
 assert.equal(verifiedNewOutgoingAcknowledgement(snap([inbound]),snap([inbound,{...outgoing,subject:'[MERCER#22222222] Test'}]),ticket,recipient).verified,false);
});
test('RC27: malformed or additional untrusted dialog sequences never pass',()=>{
 assert.equal(permitAcknowledgement({previous:2,successNotices:1,success:true,type:'html'}),false);
 assert.equal(permitAcknowledgement({previous:2,successNotices:0,success:false,type:'html'}),false);
 for(const data of [{htmlDialogs:4,jsDialogs:0,successNotices:2},{htmlDialogs:3,jsDialogs:0,successNotices:0},{htmlDialogs:1,jsDialogs:0,successNotices:2},{htmlDialogs:-1,jsDialogs:0,successNotices:0}])assert.equal(validSendAcknowledgements(proofState(data)),false);
 assert.equal(validSendAcknowledgements({htmlDialogs:2,jsDialogs:0,successNotices:0}),true,'normal old two dialog behavior preserved');
});
