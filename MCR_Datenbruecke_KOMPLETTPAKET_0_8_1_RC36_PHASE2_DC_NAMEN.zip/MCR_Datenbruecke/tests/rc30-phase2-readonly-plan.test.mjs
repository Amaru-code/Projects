import test from 'node:test';import assert from 'node:assert/strict';
import {accountStatementPlan} from '../lib/phase2-account-statement-plan.mjs';
const ticket={ticketId:'87393963',source:'E-MAIL',memberName:'Max Mustermann',wwid:'987654',description:'USC 20/ DC;PP+\nStandardantwort versendet\nMöchte Kontoauszug'};
test('RC30 phase2 dry plan: both DC and PP+ exactly once, NO execution',()=>{
 const p=accountStatementPlan(ticket);assert.equal(p.kind,'READY_FOR_SEPARATE_SUPERVISED_PILOT');
 assert.deepEqual(p.targets,['DC','PP+']);assert.equal(p.actionsEnabled,false);assert.equal(p.expectedOutputCount,2);
 assert.deepEqual(p.scripts.map(x=>x.start),['START_KONTOAUSZUG_DC.bat','START_KONTOAUSZUG.bat']);
});
test('RC30 phase2: KA alias and PP+ only',()=>{
 const p=accountStatementPlan({...ticket,description:'USC 10/ PP+\nStandardantwort versendet\nMöchet KA'});
 assert.deepEqual(p.targets,['PP+']);
});
test('RC30 phase2: no WWID means NO external subprocess',()=>{
 const p=accountStatementPlan({...ticket,wwid:null});assert.equal(p.kind,'NEEDS_VERIFIED_WWID');assert.equal(p.actionsEnabled,false);
});
test('RC30 phase2: typo in standard answer must be reviewed, never assumed sent',()=>{
 assert.throws(()=>accountStatementPlan({...ticket,description:'USC 20/ DC;PP+\nStansardantwort versendet\nMöchte Kontoauszug'}),{code:'P2_STANDARD_STATUS_UNCERTAIN'});
});
test('RC30 phase2: unknown plans, duplicated request, previously prepared never rerun',()=>{
 for(const [extra,code] of [
  ['USC 20/ DC;FAKE\nStandardantwort versendet\nMöchte KA','P2_PLANS_UNKNOWN'],
  ['USC 20/ DC;PP+\nStandardantwort versendet\nMöchte KA\nMöchte Kontoauszug','P2_REQUEST_AMBIGUOUS'],
  ['USC 20/ DC\nStandardantwort versendet\nMöchte KA\nBearbeitet not reviewed','P2_ALREADY_PREPARED']
 ])assert.throws(()=>accountStatementPlan({...ticket,description:extra}),{code});
});
test('RC30 phase2: unrelated requests, supply exact email title',()=>{
 assert.equal(accountStatementPlan({...ticket,description:'USC 20/ PP+\nStandardantwort versendet\nMöchte neue E-Mail Verknüpfung'}).kind,'NOT_KONTOAUSZUG');
 assert.equal(accountStatementPlan({...ticket,source:'BRIEF'}).kind,'READY_FOR_SEPARATE_SUPERVISED_PILOT');
});
