# RC29 - read-only Windows dashboard; anonymous STDIN pipe, NO files/network.
# Non-activating AND click-through: it must never intercept any COMARCH clicks.
# Windows PowerShell 5.1 / Windows Forms; failures are isolated to this process.
$ErrorActionPreference = 'Stop'
try {
 Add-Type -AssemblyName System.Windows.Forms
 Add-Type -AssemblyName System.Drawing
 Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class McrOverlayWindowStyles {
 [DllImport("user32.dll", EntryPoint="GetWindowLongPtrW", SetLastError=true)]
 public static extern IntPtr GetWindowLongPtr(IntPtr hWnd, int nIndex);
 [DllImport("user32.dll", EntryPoint="SetWindowLongPtrW", SetLastError=true)]
 public static extern IntPtr SetWindowLongPtr(IntPtr hWnd, int nIndex, IntPtr value);
}
'@
 $form = New-Object System.Windows.Forms.Form
 $form.Text = 'MCR Laufuebersicht'
 $form.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::None
 $form.StartPosition = [System.Windows.Forms.FormStartPosition]::Manual
 $form.ClientSize = New-Object System.Drawing.Size(338,217)
 $form.BackColor = [System.Drawing.Color]::FromArgb(22,32,46)
 $form.ForeColor = [System.Drawing.Color]::White
 $form.ShowInTaskbar = $false
 $form.TopMost = $true
 $form.Opacity = 0.95
 $form.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::None
 $work = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
 $form.Location = New-Object System.Drawing.Point(($work.Right - 356),($work.Bottom - 234))
 $font = New-Object System.Drawing.Font('Segoe UI',9,[System.Drawing.FontStyle]::Regular)
 $bold = New-Object System.Drawing.Font('Segoe UI Semibold',9,[System.Drawing.FontStyle]::Bold)
 $big = New-Object System.Drawing.Font('Segoe UI',10,[System.Drawing.FontStyle]::Bold)
 function Add-Row([string]$name,[int]$top,[bool]$highlight) {
  $l = New-Object System.Windows.Forms.Label
  $l.Location = New-Object System.Drawing.Point(13,$top)
  $l.Size = New-Object System.Drawing.Size(90,24)
  $l.Font = $font
  $l.ForeColor = [System.Drawing.Color]::FromArgb(170,193,214)
  $l.Text = $name
  $form.Controls.Add($l)
  $v = New-Object System.Windows.Forms.Label
  $v.Location = New-Object System.Drawing.Point(106,$top)
  $v.Size = New-Object System.Drawing.Size(224,25)
  $v.Font = $(if($highlight){$bold}else{$font})
  $v.AutoEllipsis = $true
  $v.ForeColor = [System.Drawing.Color]::White
  $v.Text = '–'
  $form.Controls.Add($v)
  return $v
 }
 $heading = New-Object System.Windows.Forms.Label
 $heading.Text = 'MCR  |  LIVE-TICKET'
 $heading.Font = $big
 $heading.ForeColor = [System.Drawing.Color]::FromArgb(111,204,232)
 $heading.Location = New-Object System.Drawing.Point(13,9)
 $heading.Size = New-Object System.Drawing.Size(310,23)
 $form.Controls.Add($heading)
 $val = @{}
 $val.ticket = Add-Row 'Ticket' 39 $true
 $val.name = Add-Row 'Person' 65 $true
 $val.id = Add-Row 'MercerID' 91 $false
 $val.usc = Add-Row 'USC / Pläne' 117 $false
 $val.answered = Add-Row 'Antwort' 143 $true
 $val.phase = Add-Row 'Vorgang' 169 $false
 $note = New-Object System.Windows.Forms.Label
 $note.Text = 'Nur Anzeige  •  keine Browser-Klicks'
 $note.Font = New-Object System.Drawing.Font('Segoe UI',7)
 $note.ForeColor = [System.Drawing.Color]::FromArgb(130,151,173)
 $note.Location = New-Object System.Drawing.Point(13,199)
 $note.Size = New-Object System.Drawing.Size(310,16)
 $form.Controls.Add($note)
 # Extended styles: WS_EX_TRANSPARENT, WS_EX_NOACTIVATE, WS_EX_TOOLWINDOW.
 # Prevents the native overlay from masking or stealing trusted click targets.
 $handle = $form.Handle
 $old = [McrOverlayWindowStyles]::GetWindowLongPtr($handle,-20).ToInt64()
 $new = $old -bor 0x00000020 -bor 0x08000000 -bor 0x00000080
 [void][McrOverlayWindowStyles]::SetWindowLongPtr($handle,-20,[IntPtr]$new)
 # Never display a window unless the OS has accepted click-through and
 # non-activation. Otherwise it might intercept a trusted COMARCH click.
 $verified = [McrOverlayWindowStyles]::GetWindowLongPtr($handle,-20).ToInt64()
 if(($verified -band 0x08000020) -ne 0x08000020){ exit 0 }
 $reader = [Console]::In
 $script:reading = $reader.ReadLineAsync()
 $script:closing = $false
 $script:closedAt = [DateTime]::MinValue
 $script:doneAt = [DateTime]::MinValue
 $script:lastEvent = ''
 $timer = New-Object System.Windows.Forms.Timer
 $timer.Interval = 140
 $timer.Add_Tick({
  if($script:reading -ne $null -and $script:reading.IsCompleted){
   $line = $null
   try {$line = $script:reading.GetAwaiter().GetResult()}catch{}
   if($null -eq $line){$script:closing=$true;$script:closedAt=[DateTime]::UtcNow;$script:reading=$null}
   else {
    $script:reading=$reader.ReadLineAsync()
    try {
     $m = $line | ConvertFrom-Json -ErrorAction Stop
     if($m.schema -eq 'MCR_PROGRESS_V1'){
      if($m.event -eq 'start' -or $m.event -eq 'update'){$script:doneAt=[DateTime]::MinValue;$form.Opacity=0.95}
      if($m.event -eq 'complete' -or $m.event -eq 'skip' -or $m.event -eq 'error'){$script:doneAt=[DateTime]::UtcNow}
      if($m.event -eq 'close'){$script:closing=$true;$script:closedAt=[DateTime]::UtcNow}
      foreach($key in @('ticket','name','id','usc','answered','phase')){
       if($null -ne $m.$key){$val[$key].Text=[string]$m.$key}
      }
      if($m.event -eq 'error'){$heading.Text='MCR  |  PRUEFUNG ERFORDERLICH';$heading.ForeColor=[System.Drawing.Color]::Orange}
      elseif($m.event -eq 'complete'){$heading.Text='MCR  |  TICKET FERTIG';$heading.ForeColor=[System.Drawing.Color]::LightGreen}
      elseif($m.event -eq 'start'){$heading.Text='MCR  |  LIVE-TICKET';$heading.ForeColor=[System.Drawing.Color]::FromArgb(111,204,232)}
     }
    }catch{}
   }
  }
  $now = [DateTime]::UtcNow
  if($script:closing){
   $elapsed = ($now-$script:closedAt).TotalMilliseconds
   $form.Opacity=[Math]::Max(0.05,0.95*(1.0-$elapsed/3300.0))
   if($elapsed -ge 3300){$timer.Stop();$form.Close()}
  }elseif($script:doneAt -ne [DateTime]::MinValue){
   $elapsed=($now-$script:doneAt).TotalMilliseconds
   if($elapsed -ge 3000){$form.Opacity=[Math]::Max(0.38,0.95-0.57*($elapsed-3000)/1600)}
  }
 })
 $timer.Start()
 [System.Windows.Forms.Application]::Run($form)
 $timer.Dispose();$font.Dispose();$bold.Dispose();$big.Dispose();$form.Dispose()
}catch { exit 0 }
