import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {generatorPaths,inspectExistingStatements} from '../lib/phase2-pdf-evidence.mjs';
import {verifyAoGeneratorProof,hasAutomaticAoPreparation,inspectPreparedStatements} from '../lib/phase2-ao-proof.mjs';
import {reviewedPdfProof,preparePhase2PdfEvidence} from '../src/phase2-pdf-prepare.mjs';
import {preflightPhase2Write} from '../src/phase2-comarch-pilot.mjs';
import {phase2Inventory} from '../lib/phase2-readonly.mjs';
import {canReuseCurrentPdfApproval} from '../lib/phase2-pdf-approval.mjs';
import {phase2DraftPreview} from '../lib/phase2-draft-preview.mjs';
import {ledger,writeJSON} from '../lib/control.mjs';
import {choosePhase2Candidate} from '../src/phase2-run.mjs';

const hash=x=>createHash('sha256').update(x).digest('hex');
const wwid='11369951',id='89664431';
const member={profileVerified:true,profile:{mercerId:'99900001',first:'Boris',last:'Schmulewitsch'},memberReferenceWwid:wwid,wwid:null};
const row={ticketId:id,source:'E-MAIL',group:'Intel Deutschland GmbH',descriptionValue:'USC 20/PP+\nStandardantwort versendet\nMöchte Auszahlungsoption'};
const pdf='%PDF-1.4\n'+('Synthetic AO fixture, no real benefit calculation.\n'.repeat(20))+'%%EOF';
function fixture(){
 const parent=fs.mkdtempSync(path.join(os.tmpdir(),'mcr-rc105-ao-flow-')),root=path.join(parent,'MCR_Datenbruecke');fs.mkdirSync(root);
 fs.mkdirSync(path.join(root,'.runtime','phase2'),{recursive:true});
 const paths=(r,plan)=>plan==='AO'?{...generatorPaths(r,plan),output:path.join(parent,'AO','Ausgabe PDF'),audit:path.join(parent,'AO','Audit_Logs')}:generatorPaths(r,plan);
 fs.mkdirSync(paths(root,'AO').output,{recursive:true});fs.mkdirSync(paths(root,'AO').audit,{recursive:true});
 const year=new Date().getFullYear(),name=`${year}-12-31_Auszahlungsoption_Schmulewitsch Boris_${wwid}.pdf`;
 const file=path.join(paths(root,'AO').output,name),auditFile=path.join(paths(root,'AO').audit,'20261120_115850_'+wwid+'.json');
 const audit={timestamp:'2026-11-20T11:58:50',wwid,status:'success',record:187,name:'Schmulewitsch Boris',stichtag:`31.12.${year}`,contact_supplied:false,pdf:file};
 function generate(){
  fs.writeFileSync(file,pdf);fs.writeFileSync(auditFile,JSON.stringify(audit));
  return {schema:'MCR_AO_GENERATOR_PROOF_V1',requestId:'0'.repeat(32),wwid,name:audit.name,stichtag:audit.stichtag,
   stichtagIso:`${year}-12-31`,file,auditFile,sha256:hash(fs.readFileSync(file)),bytes:fs.statSync(file).size,
   auditSha256:hash(fs.readFileSync(auditFile)),sourceSha256:'f'.repeat(64),generatedAt:new Date().toISOString(),auditTimestamp:audit.timestamp};
 }
 return {parent,root,paths,name,file,auditFile,audit,generate,cleanup:()=>fs.rmSync(parent,{recursive:true,force:true})};
}
function prepareProof(f,g){
 const a=verifyAoGeneratorProof(f.root,g,{wwid,...member.profile,paths:f.paths,fresh:true});
 const before=inspectExistingStatements(f.root,['AO'],wwid,{...member.profile,paths:f.paths,selectedArtifacts:[a]});
 return reviewedPdfProof({root:f.root,ticketId:id,rule:{targets:['AO']},wwid,member,before,
  wwidOrigin:'BOUND_INTL01_MEMBER_REFERENCE',planEvidence:{verified:true},automaticAo:true,paths:f.paths});
}
test('RC105 generated AO binds exact dated file despite old files for the same WWID',()=>{
 const f=fixture();try{
  const g=f.generate();fs.writeFileSync(path.join(f.paths(f.root,'AO').output,`2025-12-31_Auszahlungsoption_Schmulewitsch Boris_${wwid}.pdf`),pdf+'old');
  const proof=prepareProof(f,g);
  assert.equal(proof.artifacts[0].name,f.name);assert.equal(proof.operatorContentReviewed,false);
  assert.equal(proof.requiresReviewerContentReview,true);assert(hasAutomaticAoPreparation(proof));
  assert.equal(inspectPreparedStatements(f.root,proof,{wwid,paths:f.paths}).artifacts[0].sha256,g.sha256);
  const preview=phase2DraftPreview({ticketId:id,description:row.descriptionValue,pdfProof:proof});
  assert.equal(preview.reviewAssignee,'mark.baindl');assert.equal(preview.descriptionAfter.endsWith('Bearbeitet not reviewed'),true);
  assert.equal(canReuseCurrentPdfApproval({pdfReviewedThisRun:true,sessionPresent:true,ticketId:id,proof,member,wwid}),true);
  assert.equal(canReuseCurrentPdfApproval({pdfReviewedThisRun:false,sessionPresent:true,ticketId:id,proof,member,wwid}),false);
 }finally{f.cleanup();}
});
test('RC105 AO proof rejects wrong person, WWID, date, changed audit and changed PDF',()=>{
 const f=fixture();try{
  const g=f.generate(),args={wwid,...member.profile,paths:f.paths,fresh:true};
  for(const bad of [{...g,wwid:'11369952'},{...g,name:'Andere Person'},{...g,stichtag:'30.12.2026'},
   {...g,auditSha256:'a'.repeat(64)},{...g,generatedAt:new Date(Date.now()+3600000).toISOString()}])
   assert.throws(()=>verifyAoGeneratorProof(f.root,bad,args));
  const proof=prepareProof(f,g);fs.appendFileSync(f.file,'tampered');
  assert.throws(()=>inspectPreparedStatements(f.root,proof,{wwid,paths:f.paths}),e=>e.code==='P2_PDF_MUTATED');
 }finally{f.cleanup();}
});
test('RC105 generator proof does not claim automatic approval for manual WWID, mixed files or fake review',()=>{
 const f=fixture();try{
  const proof=prepareProof(f,f.generate());
  for(const changed of [{wwidOrigin:'OPERATOR_ENTRY'},{memberProfileVerified:false},{memberName:{first:'Other',last:'Person'}},
   {targets:['DC','AO']},{systemPreparedForReview:false},{requiresReviewerContentReview:false}])assert(!hasAutomaticAoPreparation({...proof,...changed}));
  assert(!hasAutomaticAoPreparation({...proof,artifacts:[{...proof.artifacts[0],generation:null}]}));
 }finally{f.cleanup();}
});
test('RC105 approved central AO passes actual phase2 preflight with immutable old SEND journal',()=>{
 const f=fixture();try{
  const proof=prepareProof(f,f.generate()),dir=path.join(f.root,'.runtime','phase2');fs.mkdirSync(dir,{recursive:true});
  writeJSON(path.join(dir,'MCR_PHASE2_LETZTE_INVENTUR.json'),phase2Inventory([row]));
  writeJSON(path.join(dir,`MCR_PHASE2_PDF_BELEG_${id}_current.json`),proof);
  ledger(f.root).begin(id,'USC 99/DB+\nStandardantwort versendet');const old=JSON.stringify(ledger(f.root).pending);
  const checked=preflightPhase2Write(f.root,id,{paths:f.paths});
  assert.equal(checked.wwid,wwid);assert.equal(checked.verified.artifacts[0].name,f.name);
  assert.equal(checked.preview.reviewAssignee,'mark.baindl');assert.equal(JSON.stringify(ledger(f.root).pending),old);
  fs.appendFileSync(f.auditFile,' ');assert.throws(()=>preflightPhase2Write(f.root,id,{paths:f.paths}),e=>e.code==='P2_AO_AUDIT_CHANGED');
 }finally{f.cleanup();}
});
// Deterministic browser-boundary doubles. Actual preparation, file/audit
// validation, proof persistence and phase2 preflight remain real production code.
const fixtureUi={assertTicket:async(page,ticket)=>assert.equal(page.ticketId,ticket)};
const fixtureOpen=async(page,row)=>{page.ticketId=row.ticketId;page.effects.open++;};
async function withPage(fn){
 const page={ticketId:null,effects:{open:0,save:0,send:0,forward:0},async eval(){return this.effects;}};
 await fn(page);
}
test('RC105 integration AO creates once, accepts default flow without PDFS_BEREIT or content prompts, then real preflight',{timeout:45000},()=>withPage(async page=>{
 const f=fixture();try{
  let runs=0,questions=0;const logs=[];
  const result=await preparePhase2PdfEvidence({root:f.root,page,row,mapping:{},paths:f.paths,ui:fixtureUi,openTicket:fixtureOpen,memberLookup:async()=>member,
   ask:async()=>{questions++;throw Error('AO normal path must not ask PDF readiness');},log:x=>logs.push(x),
   generator:async(root,plan,input)=>{runs++;assert.equal(plan,'AO');assert.equal(input,wwid);return {status:'GENERATOR_EXECUTED',proof:f.generate()};}});
  assert.equal(result.status,'PDF_PROOF_READY');assert.equal(runs,1);assert.equal(questions,0);
  assert.equal(result.proof.operatorContentReviewed,false);assert.equal(result.proof.artifacts[0].name,f.name);
  writeJSON(path.join(f.root,'.runtime','phase2','MCR_PHASE2_LETZTE_INVENTUR.json'),phase2Inventory([row]));
  assert.equal(preflightPhase2Write(f.root,id,{paths:f.paths}).preview.reviewAssignee,'mark.baindl');
  assert.deepEqual(await page.eval('window.effects'),{open:1,save:0,send:0,forward:0});
  assert(logs.some(x=>x.includes('PASS P2_AO_ERZEUGT_UND_GEBUNDEN')));
 }finally{f.cleanup();}
}));
test('RC105 integration AO failure defers this ticket without readiness prompt or stale PDF fallback',{timeout:45000},()=>withPage(async page=>{
 const f=fixture();try{
  let runs=0;
  const result=await preparePhase2PdfEvidence({root:f.root,page,row,mapping:{},paths:f.paths,ui:fixtureUi,openTicket:fixtureOpen,memberLookup:async()=>member,
   ask:async()=>{throw Error('no readiness question on failed AO');},log:()=>{},
   generator:async()=>{runs++;return {status:'AO_GENERATOR_REVIEW_REQUIRED',error:'AO_CONTACT_INPUT_REQUIRED',reason:'Adresse fehlt.'};}});
  assert.equal(result.status,'SKIPPED_UNCHANGED');assert.equal(result.reason,'AO_CONTACT_INPUT_REQUIRED');assert.equal(runs,1);
  assert(!fs.existsSync(path.join(f.root,'.runtime','phase2','actions','MCR_PHASE2_'+id+'.json')));
  assert.deepEqual(await page.eval('window.effects'),{open:1,save:0,send:0,forward:0});
 }finally{f.cleanup();}
}));
test('RC105 integration changed COMARCH member after calculation cannot get an attachment proof',{timeout:45000},()=>withPage(async page=>{
 const f=fixture();try{
  let reads=0;
  await assert.rejects(preparePhase2PdfEvidence({root:f.root,page,row,mapping:{},paths:f.paths,ui:fixtureUi,openTicket:fixtureOpen,
   memberLookup:async()=>++reads===1?member:{...member,profile:{...member.profile,mercerId:'99900002'}},
   ask:async()=>{throw Error('no readiness question');},log:()=>{},
   generator:async()=>({status:'GENERATOR_EXECUTED',proof:f.generate()})}),e=>e.code==='P2_PDF_MEMBER_CHANGED');
  assert.deepEqual(await page.eval('window.effects'),{open:1,save:0,send:0,forward:0});
 }finally{f.cleanup();}
}));

 test('RC105 AO without an action journal always gets a current generator binding; pending upload does not regenerate',()=>{
  const next=choosePhase2Candidate([row],{accountReady:()=>true,prepareMissingPdf:true});
  assert.equal(next.pdfPreparationRequired,true);
  const pending=choosePhase2Candidate([row],{accountReady:()=>true,prepareMissingPdf:true,getPdfJournal:()=>({state:'UPLOAD_INTENT'})});
  assert.equal(pending.pdfPreparationRequired,undefined);
 });
