# MCR Level 05A.2 – R Mode 1 Parity v0.1.1

First R parity candidate for the frozen LNW DC benchmark.

- existing R runtime
- base R only
- offline build/run
- no external packages
- no new native candidate EXE
- complete business implementation in R
- common Level-05 validator after the timed candidate run

Run `START_5A2_R.ps1`.


## v0.1.1

If R is missing on the benchmark laptop, the package automatically provisions a
portable R 4.6.1 runtime as a ZIP below `projects/Compiler/r/tools`.
No Windows installer is launched.
