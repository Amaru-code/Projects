import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';
import {ROOT} from './helpers.mjs';import {sha256} from '../lib/core.mjs';
import {VERSION} from '../lib/control.mjs';

test('RC29 previous RC28 manifest is pinned bit-for-bit, no old full package embedded',()=>{
 const ref=path.join(ROOT,'tools/reference/complete-0.8.1-rc.28-manifest.json');
 const m=JSON.parse(fs.readFileSync(ref,'utf8'));
 assert.equal(m.version,'0.8.1-rc.28');assert.equal(VERSION,'0.8.1-rc.29');
 assert.equal(sha256(fs.readFileSync(ref)),'a6f39118e604372376b69df47dd10fd7d2d5fb2a8d050ca35d33ee80ceb6dad6');
});
test('RC29 Windows status overlay cannot steal focus, intercept mouse clicks, or write data',()=>{
 const s=fs.readFileSync(path.join(ROOT,'tools/progress-window.ps1'),'utf8');
 assert.match(s,/0x00000020/);assert.match(s,/0x08000000/);assert.match(s,/SetWindowLongPtr/);
 assert.match(s,/ReadLineAsync/);assert.match(s,/\$verified -band 0x08000020/);
 assert.doesNotMatch(s,/WriteAllText|WriteFile|Start-Transcript|Invoke-WebRequest|Invoke-RestMethod|http[s]?:\/\//i);
});
