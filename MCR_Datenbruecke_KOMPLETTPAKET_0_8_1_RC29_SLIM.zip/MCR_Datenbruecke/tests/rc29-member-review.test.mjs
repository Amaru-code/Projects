/** Original e-mail has a wrong name. Do not bypass COMARCH identity; require
 * verified profile, explicit operator reconciliation and a recheck at send. */
import test from 'node:test';
import assert from 'node:assert/strict';
import I from '../lib/identity-evidence.cjs';
import {correctionPlan,confirmMemberCorrection,requireReviewedMember,reviewReceipt} from '../lib/member-review.mjs';
const mail={firstName:'Max',lastName:'Mustermann'};
const trueMember={source:'MEMBER_PROFILE_VERIFIED',id:'99900001',firstName:'Daniel',lastName:'Beispiel',display:'Beispiel Daniel (INTL01-99900001)',profileIdMatches:true};
const okAnswers=['99900001','Daniel','Beispiel','ZUORDNUNG GEPRUEFT'];
const answers=all=>{const a=[...all];return async()=>a.shift()??'';};
const approval=(m=trueMember,ask=answers(okAnswers),e={})=>confirmMemberCorrection({member:m,mailPerson:mail,evidence:e,ask});

test('RC29 wrong sender does NOT automatically match a different COMARCH person',()=>{
 assert.throws(()=>I.requireMatched(trueMember,mail,{}),{code:'MEMBER_NAME_MISMATCH'});
 const plan=correctionPlan(trueMember,mail,{});
 assert.equal(plan.required,true);assert.deepEqual([plan.person.firstName,plan.person.lastName],['Daniel','Beispiel']);
});
test('RC29 controlled operator correction requires exact ID, name, explicit authorization; original guard works afterwards',async()=>{
 const r=await approval();
 assert.equal(r.reviewed,true);
 assert.equal(r.person.lastName,'Beispiel');
 const receipt=reviewReceipt(trueMember,r.person,r.reviewed);
 assert.equal(requireReviewedMember(trueMember,r.person,{},receipt),true);
 assert.throws(()=>requireReviewedMember({...trueMember,firstName:'Daniela'},r.person,{},receipt),{code:'MEMBER_NAME_MISMATCH'});
 assert.throws(()=>requireReviewedMember({...trueMember,id:'99900002'},r.person,{},receipt),{code:'MEMBER_REVIEW_CHANGED'});
});
test('RC29 correct name passes automatically, with zero manual prompts',async()=>{
 let asked=false;const p={...mail};const member={...trueMember,firstName:'Max',lastName:'Mustermann'};
 const r=await confirmMemberCorrection({member,mailPerson:p,evidence:{},ask:async()=>{asked=true;}});
 assert.equal(r.reviewed,false);assert.equal(asked,false);
});
test('RC29 explicit current MercerID conflict blocks even with operator willing to approve',async()=>{
 await assert.rejects(approval(trueMember,answers(okAnswers),{expectedId:'00000001'}),{code:'MEMBER_ID_CONFLICT'});
 await assert.rejects(approval({...trueMember,profileIdMatches:false}),{code:'MEMBER_PROFILE_CONFLICT'});
});
test('RC29 standalone Member field, old profile and no selected ID never permit override',async()=>{
 await assert.rejects(approval({...trueMember,source:'MEMBER_FIELD',firstName:null,lastName:null}),{code:'MEMBER_REVIEW_NO_PROFILE'});
 await assert.rejects(approval({...trueMember,source:'PROFILE_ROWS'}),{code:'MEMBER_REVIEW_NO_PROFILE'});
 await assert.rejects(approval({...trueMember,id:'abc'}),{code:'MEMBER_REVIEW_NO_PROFILE'});
});
test('RC29 wrong ID/name/gate/abort all fail before any send',async()=>{
 const cases=[
  [['000001','Daniel','Beispiel','ZUORDNUNG GEPRUEFT'],'MEMBER_REVIEW_ID_NOT_CONFIRMED'],
  [['99900001','Marcel','Beispiel','ZUORDNUNG GEPRUEFT'],'MEMBER_REVIEW_NAME_NOT_CONFIRMED'],
  [['99900001','Daniel','Fremd','ZUORDNUNG GEPRUEFT'],'MEMBER_REVIEW_NAME_NOT_CONFIRMED'],
  [['99900001','Daniel','Beispiel','JA'],'MEMBER_REVIEW_NOT_AUTHORIZED'],
  [['ABBRUCH'],'MEMBER_REVIEW_ID_NOT_CONFIRMED'],
  [[], 'MEMBER_REVIEW_ID_NOT_CONFIRMED']
 ];
 for(const [a,code] of cases)await assert.rejects(approval(trueMember,answers(a)),{code});
});
test('RC29 no use of operator correction for ID conflict in subsequent revalidation',async()=>{
 const r=await approval();const receipt=reviewReceipt(trueMember,r.person,r.reviewed);
 assert.throws(()=>requireReviewedMember(trueMember,r.person,{expectedId:'88888888'},receipt),{code:'MEMBER_ID_CONFLICT'});
 assert.throws(()=>requireReviewedMember({...trueMember,source:'MEMBER_FIELD'},r.person,{},receipt),{code:'MEMBER_REVIEW_CHANGED'});
});
