import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';
import {ROOT} from './helpers.mjs';import {sha256} from '../lib/core.mjs';
import {VERSION} from '../lib/control.mjs';import {verifyPackage} from '../tools/integrity.mjs';
test('RC49 exact RC48 manifest pin, no private runtime content, and save/fast-install files sealed',()=>{
 assert.equal(VERSION,'0.8.1-rc.55');
 const old=fs.readFileSync(path.join(ROOT,'tools/reference/complete-0.8.1-rc.48-manifest.json'));
 assert.equal(sha256(old),'27bfea9b60b5522860c539b6692485d1e8c7d3c113ca54ad30dad72b60f1d93c');
 const m=JSON.parse(fs.readFileSync(path.join(ROOT,'MANIFEST.json')));
 assert.equal(m.version,VERSION);
 for(const p of ['tests/rc49-save-action-browser.test.mjs','tests/rc49-save-recovery.test.mjs',
  'tests/rc49-fast-install.test.mjs','tests/rc49-upgrade.test.mjs','docs/RC49_SPEICHERN_WIEDERAUFNAHME_SCHNELLINSTALLATION.md',
  'lib/phase2-write-journal.mjs','src/phase2-comarch-pilot.mjs','tools/cli.mjs',
  'tools/reference/complete-0.8.1-rc.48-manifest.json'])
  assert(m.payload.some(x=>x.path===p),p);
 assert(m.payload.every(x=>! /^(private_data|\.runtime|diagnostics|Ergebnis|reports)\//i.test(x.path)));
 assert.equal(verifyPackage(ROOT).version,VERSION);
});
