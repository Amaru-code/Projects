import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';
import {ROOT} from './helpers.mjs';import {sha256} from '../lib/core.mjs';import {VERSION} from '../lib/control.mjs';import {verifyPackage} from '../tools/integrity.mjs';

test('RC43 pinned published RC42 manifest and original source cannot be silently changed',()=>{
 assert.equal(VERSION,'0.8.1-rc.55');const p=path.join(ROOT,'tools/reference/complete-0.8.1-rc.42-manifest.json');
 const r=fs.readFileSync(p),expected=JSON.parse(r);
 assert.equal(expected.version,'0.8.1-rc.42');
 const source=fs.readFileSync(path.join(ROOT,'tools/integrity.mjs'),'utf8');
 assert.match(source,/m\.version==='0\.8\.1-rc\.42'/);assert.match(source,new RegExp(sha256(r)));
 assert.equal(verifyPackage(ROOT).version,VERSION);
});
test('RC43 Phase 2 has upload before GEVO; FilePond is mandatory when displayed; cannot call email SEND',()=>{
 const pilot=fs.readFileSync(path.join(ROOT,'src/phase2-comarch-pilot.mjs'),'utf8');
 const bridge=fs.readFileSync(path.join(ROOT,'lib/phase2-filepond.mjs'),'utf8');
 assert(pilot.indexOf("advance('UPLOAD_INTENT')")<pilot.indexOf("advance('GEVO_INTENT')"));
 assert.match(pilot,/attachPhase2Files\(page,files,\{log,/);
 assert.match(bridge,/Page\.setInterceptFileChooserDialog/);
 assert.match(bridge,/DOM\.setFileInputFiles/);
 assert.match(bridge,/filepond--browser-/);
 assert.match(bridge,/phase2UploadSurface/);
 assert.doesNotMatch(pilot,/\b(?:sendEmail|sendMessage|clickSend|sendStandardAnswer)\s*\(/);
 assert.doesNotMatch(bridge,/\b(?:sendEmail|sendMessage|clickSend|sendStandardAnswer)\s*\(/);
});
