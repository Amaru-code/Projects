import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import fs from 'node:fs';
const require=createRequire(import.meta.url);
const MailDownload=require('../lib/mail-download.cjs');

test('one visible download is selected',()=>{
 const r=MailDownload.chooseBottommost([{x:20,y:100,width:12,height:12,order:0}]);
 assert.equal(r.y,100);assert.equal(r.policy,'BOTTOMMOST_VISIBLE_MESSAGE_ROW');
});

test('bottom-most message row wins',()=>{
 const r=MailDownload.chooseBottommost([
  {x:20,y:100,width:12,height:12,order:0},
  {x:20,y:160,width:12,height:12,order:1}
 ]);
 assert.equal(r.y,160);assert.equal(r.candidateCount,2);
});

test('left-most control wins inside bottom row',()=>{
 const r=MailDownload.chooseBottommost([
  {x:20,y:100,width:12,height:12,order:0},
  {x:540,y:160,width:12,height:12,order:2},
  {x:22,y:163,width:12,height:12,order:1}
 ]);
 assert.equal(r.x,22);assert.equal(r.bottomRowCount,2);
});

test('invalid geometry is ignored',()=>{
 const r=MailDownload.chooseBottommost([{x:1,y:Number.NaN,width:1,height:1},{x:5,y:20,width:1,height:1}]);
 assert.equal(r.x,5);
});

test('local runner source declares 0.5.1 bottom-mail and semantic description verification',()=>{
 const s=fs.readFileSync(new URL('../src/local-bot.mjs',import.meta.url),'utf8');
 assert.match(s,/version:'0\.5\.1'/);
 assert.ok(s.includes('UNTERSTE sichtbare Nachrichtenzeile'));
 assert.ok(s.includes('GEOMETRIC_LABEL_NEAREST'));
 assert.ok(s.includes('verifyDescription'));
 assert.ok(s.includes("MailDownload.chooseBottommost"));
});
