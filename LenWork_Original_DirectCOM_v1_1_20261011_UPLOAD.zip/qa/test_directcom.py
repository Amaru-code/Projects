import hashlib
import pathlib
import unittest
import json

ROOT = pathlib.Path(__file__).resolve().parents[1]
REF = ROOT/'qa'/'ORIGINAL_SKILL_REFERENCE.md'
SOURCE = pathlib.Path('/mnt/data/LenWork_Original_Skill_50Plus_v1')

class OriginalPolicyFreeze(unittest.TestCase):
    def test_original_priority_and_output_exact(self):
        self.assertEqual(
            (ROOT/'SKILL.md').read_text(encoding='utf8').split('## Step 2 – ',1)[1],
            REF.read_text(encoding='utf8').split('## Step 2 – ',1)[1]
        )

    def test_frontmatter_hard_rules_scope_unchanged(self):
        self.assertEqual(
            (ROOT/'SKILL.md').read_text(encoding='utf8').split('## Step 1b – ',1)[0],
            REF.read_text(encoding='utf8').split('## Step 1b – ',1)[0]
        )

    def test_expected_absender_digest(self):
        self.assertEqual(hashlib.sha256((ROOT/'absender.md').read_bytes()).hexdigest(),
                         '18073dfc0e6fc2935a50b1a8a651e9c48e034d163dfbd333b22d1d578266675e')

    def test_frozen_exporter_digest(self):
        self.assertEqual(hashlib.sha256((ROOT/'Export-InboxReadOnly.ps1').read_bytes()).hexdigest(),
                         '29b4d7b55382fec0591919000e018fe56d012c648af607eb99054b3ea3f76411')

    def test_runner_flat_layout_and_read_only(self):
        run = (ROOT/'Invoke-LenWorkInbox.ps1').read_text(encoding='utf8')
        for s in ('Join-Path $PSScriptRoot', 'Export-InboxReadOnly.ps1', 'verify_export.py',
                  'GetActiveObject', 'AllUnread', 'IncludeRead', 'RESULT=EXPORT_VERIFIED'):
            self.assertIn(s, run)
        for disallowed in ('Set-ExecutionPolicy', 'Unblock-File', 'MailItem.Save', 'MailItem.Send'):
            self.assertNotIn(disallowed, run)

    def test_no_legacy_sandbox_misinformation(self):
        sk = (ROOT/'SKILL.md').read_text(encoding='utf8')
        self.assertNotIn('LenWork kann das Skript nicht', sk)
        self.assertIn('Dateien liegen in LenWork **direkt neben', sk)

if __name__ == '__main__': unittest.main()
