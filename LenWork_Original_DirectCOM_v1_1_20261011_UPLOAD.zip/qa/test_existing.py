"""Offline tests: original policy freeze + synthetic 120-mail export validation."""
from __future__ import annotations

import hashlib
import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from verify_export import verify  # noqa: E402


def build_export(path: Path, *, n: int = 120, day: str = '2026-10-11') -> None:
    batches = path / 'batches'
    batches.mkdir(parents=True)
    filemeta = []
    for start in range(0, n, 25):
        i = 1 + start // 25
        name = f'mail_batch_{i:04d}'
        chunk = []
        md = [f'# Outlook Inbox Batch {i}', '']
        for j in range(start, min(n, start + 25)):
            row = {
                'message_id': f'outlook-entry:TEST-{j:05d}',
                'received_at_local': f'{day}T10:00:00',
                'sender': 'test@example.invalid',
                'to': 'test@example.invalid',
                'cc': '',
                'recipient_placement': 'to',
                'subject': 'synthetic local test',
                'importance': 1,
                'has_attachments': False,
                'conversation_id': 'thread',
                'is_unread': True,
                'folder': 'inbox',
                'source': 'classic_outlook_local_com',
                'body_preview': 'Only a test',
            }
            chunk.append(json.dumps(row, ensure_ascii=False, separators=(',', ':')))
            md.extend(['```json', chunk[-1], '```', ''])
        json_path = batches / f'{name}.jsonl'
        md_path = batches / f'{name}.md'
        json_path.write_text('\n'.join(chunk) + '\n', encoding='utf-8')
        md_path.write_text('\n'.join(md) + '\n', encoding='utf-8')
        for p, kind in [(json_path, 'jsonl'), (md_path, 'md')]:
            filemeta.append({'path': f'batches/{p.name}', 'format': kind,
                             'records': len(chunk), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()})
    manifest = {
        'schema': 'LENWORK_ORIGINAL_INBOX_EXPORT_V1',
        'mode': 'INBOX_METADATA',
        'status': 'COMPLETE_LOCAL_STORE',
        'source': 'classic_outlook_local_com',
        'folder': 'inbox',
        'scope_start': day,
        'scope_end_inclusive': day,
        'unread_only': True,
        'scanned_objects': n,
        'inbox_count_at_scan_start': n,
        'unique_records': n,
        'batch_size': 25,
        'batch_count': (n + 24) // 25,
        'issue_codes': [],
        'files': filemeta,
    }
    (path / 'manifest.json').write_text(json.dumps(manifest), encoding='utf-8')


class TestPolicyFreeze(unittest.TestCase):
    def test_priority_steps_and_output_unchanged(self):
        orig = (ROOT / 'qa' / 'ORIGINAL_SKILL_REFERENCE.md').read_text(encoding='utf-8')
        modified = (ROOT / 'SKILL.md').read_text(encoding='utf-8')
        self.assertEqual(orig.split('## Step 2 – ', 1)[1], modified.split('## Step 2 – ', 1)[1])

    def test_scope_and_hard_rules_unchanged(self):
        orig = (ROOT / 'qa' / 'ORIGINAL_SKILL_REFERENCE.md').read_text(encoding='utf-8')
        modified = (ROOT / 'SKILL.md').read_text(encoding='utf-8')
        self.assertEqual(orig.split('## Step 1b – ', 1)[0], modified.split('## Step 1b – ', 1)[0])

    def test_absender_rules_present_and_exact_reference(self):
        content = (ROOT / 'absender.md').read_text(encoding='utf-8')
        for item in ('HRservices@mmc.com', 'europe.update@marsh.com',
                     'Einladung zu einem Termin, bei dem ich Pflichtteilnehmer*in bin'):
            self.assertIn(item, content)

    def test_script_has_no_priority_assignment(self):
        text = (ROOT / 'Export-InboxReadOnly.ps1').read_text(encoding='utf-8')
        self.assertNotIn('function categorize', text.lower())
        self.assertNotIn('Get-MgUserMessage', text)
        self.assertIn('GetActiveObject', text)
        self.assertIn('GetDefaultFolder(6)', text)


class TestValidator(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name)
        build_export(self.path)

    def tearDown(self):
        self.tmp.cleanup()

    def _manifest(self):
        return json.loads((self.path / 'manifest.json').read_text(encoding='utf-8'))

    def _save_manifest(self, m):
        (self.path / 'manifest.json').write_text(json.dumps(m), encoding='utf-8')

    def test_120_same_day_success(self):
        result = verify(self.path)
        self.assertEqual(result['VERIFY_RESULT'], 'PASS')
        self.assertEqual(result['UNIQUE_RECORDS'], 120)
        self.assertEqual(result['BATCHES'], 5)

    def test_empty_manifest_zero_works(self):
        for p in (self.path / 'batches').iterdir():
            p.unlink()
        m = self._manifest()
        m.update(unique_records=0, batch_count=0, files=[], scanned_objects=0,
                 inbox_count_at_scan_start=0)
        self._save_manifest(m)
        self.assertEqual(verify(self.path)['UNIQUE_RECORDS'], 0)

    def test_tampering_detected(self):
        p = self.path / 'batches' / 'mail_batch_0001.jsonl'
        with p.open('a', encoding='utf-8') as out:
            out.write('garbage\n')
        with self.assertRaisesRegex(ValueError, 'SHA256'):
            verify(self.path)

    def test_missing_batch_detected(self):
        (self.path / 'batches' / 'mail_batch_0002.md').unlink()
        with self.assertRaisesRegex(ValueError, 'Missing batch'):
            verify(self.path)

    def test_incomplete_manifest_detected(self):
        m = self._manifest()
        m['status'] = 'INCOMPLETE_LOCAL_ERRORS'
        self._save_manifest(m)
        with self.assertRaisesRegex(ValueError, 'incomplete'):
            verify(self.path)

    def test_duplicate_id_detected_with_valid_checksum(self):
        p = self.path / 'batches' / 'mail_batch_0002.jsonl'
        lines = p.read_text(encoding='utf-8').splitlines()
        duplicate = json.loads(lines[0])
        duplicate['message_id'] = 'outlook-entry:TEST-00000'
        lines[0] = json.dumps(duplicate, separators=(',', ':'))
        p.write_text('\n'.join(lines) + '\n', encoding='utf-8')
        m = self._manifest()
        for file in m['files']:
            if file['path'].endswith('mail_batch_0002.jsonl'):
                file['sha256'] = hashlib.sha256(p.read_bytes()).hexdigest()
        self._save_manifest(m)
        with self.assertRaisesRegex(ValueError, 'Duplicate message ID'):
            verify(self.path)

    def test_out_of_scope_date_detected_with_valid_checksum(self):
        p = self.path / 'batches' / 'mail_batch_0001.jsonl'
        lines = p.read_text(encoding='utf-8').splitlines()
        obj = json.loads(lines[0])
        obj['received_at_local'] = '2026-10-12T00:00:00'
        lines[0] = json.dumps(obj, separators=(',', ':'))
        p.write_text('\n'.join(lines) + '\n', encoding='utf-8')
        m = self._manifest()
        for file in m['files']:
            if file['path'].endswith('mail_batch_0001.jsonl'):
                file['sha256'] = hashlib.sha256(p.read_bytes()).hexdigest()
        self._save_manifest(m)
        with self.assertRaisesRegex(ValueError, 'Out-of-scope'):
            verify(self.path)

    def test_inconsistent_scan_detected(self):
        m = self._manifest()
        m['scanned_objects'] -= 1
        self._save_manifest(m)
        with self.assertRaisesRegex(ValueError, 'scan count'):
            verify(self.path)

    def test_manifest_path_traversal_detected(self):
        m = self._manifest()
        m['files'][0]['path'] = '../mail_batch_0001.jsonl'
        self._save_manifest(m)
        with self.assertRaises(ValueError):
            verify(self.path)


if __name__ == '__main__':
    unittest.main()
