# Inbox catch-up after absence (Urlaubs-Rückblick)

## Goal
When the user comes back from vacation or another absence, read the emails received during that time and give a prioritized overview in German: what needs an answer now, what can wait, what is just for information, and what can be ignored.

## Hard rules
- READ-ONLY. Never send, reply, forward, delete, move, flag, categorize or mark any email as read. Drafts only if the user asks for them afterwards, and only shown in the chat.
- Output language is ALWAYS German, even if the user writes in English or the emails are in English.
- Use only what is in the emails. Do not invent deadlines, intentions or facts. If something is unclear, write "unklar".
- Before classifying anything, read the file absender.md from this skill (sender and subject rules). Its rules override your own judgment.

## Step 1 – Scope
- If the user gives a period (e.g. "Urlaub 22.09.–06.10."), use exactly that period.
- Otherwise: all UNREAD emails in the Inbox from the last 14 days. State this assumption in the first line of the answer.
- Inbox only, plus subfolders the user names explicitly. Skip Junk, Deleted Items and Archive.

## Step 1b – Mehrfachabruf über das vorhandene `msgraph_email`-Tool (READ-ONLY)

Dieses Kapitel regelt **nur die Beschaffung der E-Mails**. Es ändert keine Priorität, Absenderregel oder Ausgabevorgabe aus Step 2–4. Das Tool ist pro `list`-Aufruf auf `count: 50` begrenzt. Die 50 sind KEINE Gesamtgrenze des Skills.

1. Für den durch Step 1 festgelegten Scope `msgraph_email` mit `action: list`, `folder: inbox`, `count: 50`, korrekt gesetztem `unread_only` und dem gewünschten `date_range` abfragen. Der ursprüngliche Standard bleibt `unread_only: true`; nur bei ausdrücklichem Wunsch nach gelesenen und ungelesenen E-Mails `unread_only: false` verwenden. Keine Parameter erfinden.
2. **Weniger als 50 Treffer** für ein nachweislich wirksam gefiltertes Intervall: vorläufig vollständiges Blatt. **Genau 50 Treffer:** nicht als vollständig behaupten; in zwei aufeinanderfolgende, disjunkte Kalendertagsintervalle aufteilen und beide abfragen. Die Aufteilung wiederholen, bis alle Blätter <50 haben.
3. Ein Einzeltag mit genau 50 Treffern bleibt `UNRESOLVED`, denn `date_range` hat nach der LenWork-Diagnose nur Tagesgranularität. Ohne belegbar vollständige andere Partition darf keine vollständige Auswertung behauptet werden.
4. Ausschließlich Blattdaten zusammenführen, anhand stabiler Message-IDs deduplizieren und tatsächliche Anzahl der Tool-Abrufe sowie nicht vollständig auflösbare Tage dokumentieren. Eine fehlende/instabile ID oder Tool-Fehler bedeutet `FETCH_STATUS=INCOMPLETE`.
5. Gilt `FETCH_STATUS=COMPLETE_UNDER_TOOL_CONTRACT`, fahre mit dem **unveränderten Step 2** fort. Dies ist keine atomare Snapshot-Garantie für das Postfach. Bei `INCOMPLETE` transparent nur als Teilauswertung berichten und ggf. Step 1c anbieten.

## Step 1c – Direkter Outlook-COM-Export innerhalb von LenWork (optional, READ-ONLY)

Dieser Abschnitt ändert **ausschließlich den Datenabruf aus Step 1**. Step 2, Step 3, Step 4 und `absender.md` bleiben **exakt unverändert**. Wähle diesen Abrufweg, wenn die vom Nutzer freigegebene lokale Windows-Ausführungsumgebung verfügbar ist; besonders bei >50 E-Mails an EINEM Tag oder dem expliziten Wunsch „alle ungelesenen E-Mails“. Andernfalls nutze Step 1b und melde eventuelle Tagesüberläufe.

**Verifizierte Voraussetzung am Zielrechner:** LenWork kann Windows PowerShell **5.1** ausführen und mittels `[Runtime.InteropServices.Marshal]::GetActiveObject('Outlook.Application')` die bereits laufende klassische Outlook-Instanz mit MAPI und Inbox lesen. Ein *neuer* COM-Prozess (`New-Object -ComObject`) ist keine gleichwertige Verbindung. Der laufende Outlook-Prozess ist eine Vorbedingung, kein pauschales Hindernis für automatischen Betrieb.

1. Die Dateien liegen in LenWork **direkt neben `SKILL.md`** (keine funktionierende Unterordnerstruktur nötig): `absender.md`, `Export-InboxReadOnly.ps1`, `verify_export.py`, `Invoke-LenWorkInbox.ps1` und optional `Test-ClassicOutlookCom.ps1`. Ermittle den tatsächlich zugänglichen Pfad zur ausführbaren `.ps1`-Datei über die vorhandenen Datei-/Shell-Tools. **Niemals einen Pfad oder eine erfolgreich ausgeführte Datei erfinden.** Falls die Script-Datei zwar im Skill sichtbar, aber im Windows-Dateisystem nicht ausführbar ist: `AUTOMATION_STATUS=BLOCKED_SKILL_FILE_PATH` melden.
2. Keine neuen Zugangsdaten und keine Security-Bypässe. Nur wenn lokaler Outlook-Export und Verarbeitung der Korrespondenz innerhalb der autorisierten Unternehmensumgebung erlaubt sind. **Nie** per Netzwerk an unfreigegebene Dienste senden. Keine E-Mail mutieren. Keine Prozessstarts von Outlook, keine Umstellung von ExecutionPolicy, keine automatische `Unblock-File`-Aktion. Falls eine Unternehmensrichtlinie Skriptausführung verbietet, stoppen und IT-Freigabe einholen.
3. `Invoke-LenWorkInbox.ps1` mit **Windows PowerShell 5.1** über den **wirklichen absoluten Skill-Dateipfad** starten (`powershell.exe -NoProfile -NonInteractive -File <Pfad> ...`). Der Runner verwendet nur `GetActiveObject`, ruft den vorhandenen `Export-InboxReadOnly.ps1` auf, prüft mit `verify_export.py` und nennt den Ausgabeordner. `-AllUnread` verwenden, wenn der Nutzer ausdrücklich **alle ungelesenen Inbox-E-Mails ohne Zeitbegrenzung** verlangt; für einen expliziten Zeitraum `-StartDate YYYY-MM-DD -EndDate YYYY-MM-DD`; ohne ausdrücklichen Zeitraum oder „alle“ gelten die ursprünglichen **letzten 14 Kalendertage** und `unread_only=true`. Gelesene E-Mails nur bei ausdrücklichem Auftrag mit `-IncludeRead` berücksichtigen. `-BatchSize 25` und Vorschauen `-PreviewChars 350` standardmäßig beibehalten.
4. Falls Outlook nicht läuft, `WAITING_FOR_CLASSIC_OUTLOOK` anzeigen und den Nutzer bitten, klassisches Outlook zu öffnen; danach erneut versuchen. Ein Skriptaufruf ohne `RESULT=EXPORT_VERIFIED`, `VERIFY_RESULT=PASS` und `STATUS=COMPLETE_LOCAL_STORE` ist **keine** ausreichende Basis für Vollständigkeitsbehauptungen. Nach fehlerhaftem Export nicht auf veraltete Batches eines anderen Runs ausweichen.
5. **Datenübernahme aus genau einem erfolgreichen Exportlauf:** `RUN_DIR` aus der Skriptantwort verwenden. `manifest.json` und ALLE in dessen `files`-Liste aufgeführten `batches/mail_batch_*.md` (alternativ die `*.jsonl`, aber nie beide Formate doppelt zählen) tatsächlich mit den genehmigten lokalen Lesetools öffnen. Prüfe `unique_records`, Dateianzahl, `unread_only` und jede ID gegen die eigene Analyse-Liste. Kann LenWork die Ausgabedateien nicht lesen, melde `IMPORT_STATUS=BLOCKED_LOCAL_FILES` – **keine** erfundene Priorisierung. Verarbeite alle E-Mails in Batches von 20–30 nach dem unveränderten Step 2–4 und dem unveränderten `absender.md`. `ANALYZED_COUNT` muss `unique_records` entsprechen; sonst `ANALYSIS_STATUS=INCOMPLETE`.
6. Bei nicht eindeutig klassifizierbaren Nachrichten den fehlenden Volltext gezielt per ursprünglichem `msgraph_email`-READ-ONLY-Detailabruf beschaffen, sofern möglich. Als Alternative kann der bestehende Exporter mit `-BodyIdsFile` eine begrenzte Volltext-Nachlieferung zu den IDs erzeugen (nur mit Freigabe); niemals die gesamte Inbox unnötig als Volltext exportieren. Unklare Fälle bleiben „unklar“.
7. `COMPLETE_LOCAL_STORE` bedeutet eine fehlerfreie Momentaufnahme des in klassischem Outlook erreichbaren lokalen Inbox-Stores, **keine Garantie**, dass die cloudseitige Microsoft-365-Inbox alle identischen Nachrichten zeigt oder die Synchronisierung aktuell ist. Besonders bei Abweichungen zwischen lokalem Outlook und `msgraph_email` auf Synchronisierung/Konto/Ordner prüfen. Bis zur bestätigten lokalen Datenübernahme ist der komplett automatische Chatablauf lediglich **technisch möglich, noch nicht end-to-end abgenommen**.

**Wichtig:** Python und PowerShell priorisieren keine E-Mails. Ausschließlich der Original-Skill entscheidet über 🔴/🟡/🔵/⚪. Die Skriptdateien sind Werkzeuge für Abruf, Integrität und Batching – keine neue fachliche Semantik.

## Step 2 – Metadata first, full text only when needed
1. List for every email: sender, whether the user is in To or only in CC, subject, received date, importance flag, attachments yes/no, conversation/thread, short preview.
2. Apply absender.md: everything matching "Ignorieren" goes straight to ⚪ without opening it.
3. Group by conversation/thread. Judge each thread by its LATEST message. If the question in a thread was already answered or solved by someone else, put it under "Bereits erledigt" and name who solved it.
4. If possible, check Sent Items for the same period: if the user already replied to a thread, mark it as "bereits beantwortet".
5. Open the full text only for emails that cannot be clearly classified as 🔵 or ⚪ from the metadata.
6. Work in batches of about 20–30 emails. Do not stop early; process all emails in scope.

## Step 3 – Priorities
🔴 Sofort beantworten (today):
- a direct question or request to the user (user in To)
- a deadline that has passed or is within the next 2 working days (mark passed ones as "ÜBERFÄLLIG")
- anything from a VIP in absender.md that contains a question or a deadline
- reminders and escalations ("Erinnerung", "dringend", "nochmals", 2nd follow-up)
- meeting requests for the next days that still need a response

🟡 Diese Woche:
- a request to the user without a tight deadline
- a deadline within the next ~2 weeks
- coordination where the user's input is expected

🔵 Zur Kenntnis:
- user only in CC, status updates, decisions already made, finished threads, past meeting invitations

⚪ Ignorierbar:
- newsletters, HR/IT mass mailings, marketing, automatic notifications, out-of-office replies, expired invitations

When in doubt between two levels, choose the higher one.

## Step 4 – Output (German, short)
Start with one line: Zeitraum, Anzahl gelesener E-Mails, Verteilung (🔴 x / 🟡 x / 🔵 x / ⚪ x).

### 🔴 Sofort beantworten
Table: Nr. | Von | Betreff | Worum geht es (1 Satz) | Was wird von dir erwartet | Frist

### 🟡 Diese Woche
Same table.

### 🔵 Zur Kenntnis
One line per thread: Von – Betreff – Kernaussage in 1 Satz.

### ⚪ Ignorierbar
Counts by group only, no details (e.g. "HR-Rundmails: 4, Newsletter: 7, Systembenachrichtigungen: 12").

### 📅 Fristen und Termine
Chronological list of all deadlines and dates found: Datum – was – von wem.

### ✅ Bereits erledigt / beantwortet
One line each: Betreff – erledigt durch wen.

End with exactly one question: "Soll ich für die 🔴-Mails Antwortentwürfe vorbereiten?"
Keep every summary to one sentence. No long quotes from emails.
