<#
.SYNOPSIS
  Read-only LenWork command bridge: open classic Outlook -> Inbox export -> verify.
.DESCRIPTION
  Run ONLY in Windows PowerShell 5.1 under the same Windows user/session as classic Outlook.
  Does not open Outlook; does not change any emails. Files remain on approved local disk.
  Does not assign email priorities. LenWork must read/validate the resulting batches
  and apply the ORIGINAL SKILL.md and absender.md.
#>
[CmdletBinding()]
param(
    [string]$StartDate = '',
    [string]$EndDate = '',
    [switch]$AllUnread,
    [switch]$IncludeRead,
    [ValidateRange(1,100)][int]$BatchSize = 25,
    [ValidateRange(0,2000)][int]$PreviewChars = 350,
    [string]$OutputDir = (Join-Path $env:LOCALAPPDATA 'LenWorkInboxExports'),
    [string]$MailboxName = '',
    [string]$OwnAddress = ''
)
$ErrorActionPreference = 'Stop'
try {
    if ($PSVersionTable.PSVersion.Major -ne 5) {
        throw 'Windows PowerShell 5.1 required (not PowerShell 7).'
    }
    $exporter = Join-Path $PSScriptRoot 'Export-InboxReadOnly.ps1'
    $validator = Join-Path $PSScriptRoot 'verify_export.py'
    if (-not (Test-Path -LiteralPath $exporter -PathType Leaf)) { throw 'Export-InboxReadOnly.ps1 missing next to runner.' }
    if (-not (Test-Path -LiteralPath $validator -PathType Leaf)) { throw 'verify_export.py missing next to runner.' }
    if ($AllUnread -and ($StartDate -or $EndDate -or $IncludeRead)) {
        throw 'AllUnread cannot be combined with dates or IncludeRead.'
    }
    if ([bool]$StartDate -xor [bool]$EndDate) {
        throw 'StartDate and EndDate must be provided together.'
    }
    $today = Get-Date
    if ($AllUnread) {
        $StartDate = '1900-01-01'
        $EndDate = $today.ToString('yyyy-MM-dd')
        $scope = 'ALL_UNREAD_INBOX'
    } elseif (-not $StartDate) {
        $StartDate = $today.Date.AddDays(-13).ToString('yyyy-MM-dd')
        $EndDate = $today.ToString('yyyy-MM-dd')
        $scope = 'LAST_14_CALENDAR_DAYS'
    } else {
        $scope = 'EXPLICIT_INTERVAL'
    }
    $unreadOnly = -not $IncludeRead.IsPresent

    # Identical preflight access mode already demonstrated inside LenWork.
    try {
        $outlook = [Runtime.InteropServices.Marshal]::GetActiveObject('Outlook.Application')
        $mapi = $outlook.GetNamespace('MAPI')
        $null = $mapi.GetDefaultFolder(6)
    } catch {
        Write-Host 'RESULT=WAITING_FOR_CLASSIC_OUTLOOK'
        Write-Host 'REASON=ACTIVE_OUTLOOK_OR_MAPI_NOT_ACCESSIBLE'
        exit 3
    }
    Write-Host 'OUTLOOK_COM_PRECHECK=PASS'
    if (-not (Test-Path -LiteralPath $OutputDir -PathType Container)) {
        [System.IO.Directory]::CreateDirectory($OutputDir) | Out-Null
    }
    $oldFolders = @{}
    Get-ChildItem -LiteralPath $OutputDir -Directory -Filter 'InboxExport_*' | ForEach-Object {
        $oldFolders[$_.FullName] = $true
    }
    Write-Host ('REQUEST_SCOPE=' + $scope)
    Write-Host ('UNREAD_ONLY=' + $unreadOnly)
    $exportParams = @{
        StartDate=$StartDate; EndDate=$EndDate; BatchSize=$BatchSize;
        PreviewChars=$PreviewChars; OutputDir=$OutputDir;
        UnreadOnly=$unreadOnly; MailboxName=$MailboxName; OwnAddress=$OwnAddress
    }
    & $exporter @exportParams
    $newFolders = @(Get-ChildItem -LiteralPath $OutputDir -Directory -Filter 'InboxExport_*' |
        Where-Object { -not $oldFolders.ContainsKey($_.FullName) })
    if ($newFolders.Count -ne 1) {
        throw 'Expected exactly one new export folder; no stale-run fallback.'
    }
    $runDir = $newFolders[0].FullName
    $manifestPath = Join-Path $runDir 'manifest.json'
    if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) {
        throw 'Export manifest missing.'
    }
    $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($manifest.status -ne 'COMPLETE_LOCAL_STORE' -or $manifest.mode -ne 'INBOX_METADATA') {
        throw 'Export manifest reports incomplete status or wrong mode.'
    }
    if ([bool]$manifest.unread_only -ne $unreadOnly) { throw 'UnreadOnly filter mismatch.' }
    if ($manifest.scope_start -ne $StartDate -or $manifest.scope_end_inclusive -ne $EndDate) {
        throw 'Scope mismatch in export manifest.'
    }
    if ($manifest.issue_codes.Count -ne 0) { throw 'Export reported issues.' }
    # Do not skip integrity verification just because Python is unavailable.
    $pyLauncher = Get-Command py -ErrorAction SilentlyContinue
    if ($pyLauncher) {
        & $pyLauncher.Source -3 $validator $runDir
    } else {
        $python = Get-Command python -ErrorAction SilentlyContinue
        if (-not $python) { throw 'Python 3 validator unavailable; no COMPLETE claim.' }
        & $python.Source $validator $runDir
    }
    if ($LASTEXITCODE -ne 0) { throw 'Python validator failed; do not ingest export.' }
    Write-Host 'IMPORT_SOURCE=LOCAL_COM_VERIFIED'
    Write-Host ('UNIQUE_RECORDS=' + $manifest.unique_records)
    Write-Host ('BATCH_COUNT=' + $manifest.batch_count)
    Write-Host ('RUN_DIR=' + $runDir)
    Write-Host 'RESULT=EXPORT_VERIFIED'
    Write-Host 'NEXT=LENWORK_MUST_READ_AND_RECONCILE_ALL_BATCHES'
} catch {
    Write-Host 'RESULT=EXPORT_BLOCKED'
    Write-Host ('REASON=' + $_.Exception.Message)
    exit 4
}
