# LENWORK – ERSTER DIREKTER COM-SMOKE-TEST (READ-ONLY)

Verwende meinen Skill `inbox-urlaub-rueckblicke-v2` mit **unveränderten** ursprünglichen `absender.md`-Regeln und Step 2–4.

**Ziel dieser Sitzung:** Die vollständige lokale Skriptkette DIREKT IN LenWork testen, bevor wir 100+ neue Test-Mails zustellen. Es geht hier zuerst nur um einen technisch geprüften lokalen Abruf, keine inhaltliche Priorisierung. Das vorhandene Outlook ist bereits gestartet.

1. Suche die tatsächlich zugänglichen Skill-Dateien `Invoke-LenWorkInbox.ps1`, `Export-InboxReadOnly.ps1`, `verify_export.py` im selben Skill-Verzeichnis. Die LenWork-Skill-Ablage ist FLACH: `scripts/` als Unterordner existiert NICHT. Verwende keine erfundenen Windows-Pfade oder Dateiinhalte.
2. Rufe den Runner mit **Windows PowerShell 5.1**, `-NoProfile -NonInteractive -File <absoluter REALER Pfad zu Invoke-LenWorkInbox.ps1> -StartDate 2026-01-01 -EndDate 2026-10-11 -IncludeRead -BatchSize 25 -PreviewChars 0` auf. Nur die Inbox, keinerlei Mail-Schreibzugriffe. `-IncludeRead` ist ausdrücklich NUR für diesen technischen Test erlaubt, um auch die 78 bereits bekannten E-Mails zu erfassen. Keine PowerShell-ExecutionPolicy verändern.
3. Das Skript muss `OUTLOOK_COM_PRECHECK=PASS`, `VERIFY_RESULT=PASS` und `RESULT=EXPORT_VERIFIED` liefern. Bei Fehler die exakte Ursache und keinen erfundenen Erfolg melden.
4. Nimm `RUN_DIR` aus dem echten Runner-Ergebnis. Öffne `manifest.json`, prüfe `UNIQUE_RECORDS`, und öffne anschließend JEDES zugehörige `batches/mail_batch_XXXX.md` mit den erlaubten Dateizugriffen. Zähle die dort vorhandenen eindeutigen `message_id`-Werte; Markdown- und JSONL-Varianten dürfen NICHT doppelt gezählt werden. Keine Nachrichtentexte in der Antwort ausgeben.
5. Wenn auf Dateien nicht zugegriffen werden kann, STOP mit `IMPORT_STATUS=BLOCKED_LOCAL_FILES`; niemals synthetische oder im Skill dauerhaft gespeicherte Fixture-Daten als echte Outlook-Ergebnisse verwenden.
6. Keine E-Mails priorisieren und keine E-Mail-Daten ausgeben. Berichte ausschließlich:
   - PS_VERSION
   - OUTLOOK_COM_PRECHECK
   - RESULT
   - RUN_DIR (darf lokal im vertraulichen LenWork-Bericht stehen)
   - VERIFY_RESULT
   - UNIQUE_RECORDS
   - BATCH_COUNT
   - BATCH_FILES_READ
   - UNIQUE_IDS_INGESTED
   - MISSING_IDS
   - IMPORT_STATUS (`PASS` oder Blocker)
   - AUTOMATION_READINESS (`READY_FOR_100PLUS_LIVE_TEST` ausschließlich wenn alles erfüllt)

Erst bei `AUTOMATION_READINESS=READY_FOR_100PLUS_LIVE_TEST` werde ich meinen Priority-E-Mail-Generator mit 100+ ungelesenen Testmails ausführen. Die originale Priorisierung und `absender.md` bleiben unangetastet.
