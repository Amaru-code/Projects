# LenWork Original Skill – Direct COM v1.1

## Ziel

**Ohne Änderung der Priorisierung** mehr als 50 ungelesene Outlook-E-Mails aus dem LenWork-Chat verarbeiten. Keine Ordner innerhalb der LenWork-Skill-Dateien erforderlich.

## Upload in LenWork (flach, keine Unterordner)

- `SKILL.md` – aktualisierter **Abrufabschnitt Step 1c**, originaler Step 2, Step 3 und Step 4 unverändert
- `absender.md` – byteidentische originale Absenderregeln
- `Export-InboxReadOnly.ps1` – unveränderter bereits lokal erfolgreich getesteter Outlook-COM-Exporter
- `verify_export.py` – unveränderter Integritätsvalidator
- `Invoke-LenWorkInbox.ps1` – **NEU**, startet Export und Validation in der richtigen Reihenfolge
- `Test-ClassicOutlookCom.ps1` – optionaler Test

Die `README_DE.md`, `LENWORK_DIREKTTEST_PROMPT.md` und `qa/` müssen NICHT als Skill-Dateien hochgeladen werden. Testdateien (`mail_batch_...`, Test-`manifest.json`) aus früheren Offline-Tests gehören NICHT in den produktiven Skill.

## Neues Diagnoseergebnis am Zielgerät

LenWork hat über `Windows PowerShell 5.1` + `Marshal.GetActiveObject` (laufendes klassisches Outlook) den MAPI-Namespace und Inbox-Lesezugriff bestätigt. Das allein ist noch keine Abnahme für das automatische **Starten des Exporters und Einlesen des erzeugten Manifests/der Batches in LenWork**.

## Richtige Benutzung

1. Stelle sicher, dass **klassisches Outlook läuft** und die benötigte Inbox synchronisiert ist.
2. Leg alle obigen Skill-Dateien in LenWork auf derselben Ebene ab. `scripts/` als Pfad in LenWork NICHT verwenden.
3. Verwende für einen ersten Smoke-Test `LENWORK_DIREKTTEST_PROMPT.md`. Der Test soll das neue Runner-Skript aus LenWork starten, den Manifest-Status verifizieren, die Batches tatsächlich lesen und zählt zunächst rein technisch.
4. Nach erfolgreicher Smoke-Abnahme deinen Mail-Generator starten. Wenn die 100+ Testmails lokal in der Inbox angekommen und ungelesen sind, in LenWork: **„Priorisiere alle meine ungelesenen E-Mails“**. Diese ausdrückliche Formulierung aktiviert `-AllUnread`, also die gesamte lokale Inbox ohne 14-Tage-Default.
5. Ein Ergebnis ist erst abnahmefähig, wenn `RESULT=EXPORT_VERIFIED`, die lokale Batch-Übernahme vollständig, `ANALYZED_COUNT=UNIQUE_RECORDS` und die Original-Regeln angewandt wurden.

## Sicherheitsgrenzen

- READ-ONLY in Outlook; Exportdateien sind lokale Kopien und unterliegen den Unternehmensrichtlinien.
- Weder PowerShell noch Python stufen E-Mails ein; `SKILL.md` und `absender.md` tun das.
- Keine `ExecutionPolicy Bypass`, kein automatisches Entsperren, keine neuen OAuth-Token und kein Upload in externe, nicht genehmigte Dienste.
- Falls LenWork auf die Run-Dateien nicht zugreifen kann, `IMPORT_STATUS=BLOCKED_LOCAL_FILES` – **nicht** behaupten, dass 100+ Mails verarbeitet wurden.
- `COMPLETE_LOCAL_STORE` beweist nur den lokalen Outlook-Store, nicht die synchrone Vollständigkeit der Microsoft-365-Cloud.
- Exportdaten nach der firmeninternen Aufbewahrungsregel löschen; nicht im Skill-Ordner als statische Fixtures behalten.

## Stand der Abnahme

- ✅ Outlook/MAPI aus LenWork erreicht (Nutzerdiagnose)
- ✅ 78 Mails außerhalb von LenWork via Exporter geprüft
- ✅ 125 Offline-Fixtures in LenWork verarbeitet
- ⏳ *Noch offen*: direkter Runner aus LenWork → Dateizugriff → 100+ echte ungelesene Mails aus Outlook

`qa/` enthält Offline-Verifikation, die keinerlei Outlook-Postfach benötigt.
