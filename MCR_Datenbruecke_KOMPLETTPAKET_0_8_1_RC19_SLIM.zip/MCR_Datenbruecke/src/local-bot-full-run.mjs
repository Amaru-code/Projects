/** Consolidated runner: supplied COMARCH workflow + Identity Guard + guarded
 * trusted send/save, durable no-retry ledger and explicit bounded completion.
 * No old downloads or source patches are required at runtime. */
import os from 'node:os';import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import readline from 'node:readline/promises';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage,sleep} from '../lib/cdp.mjs';
import {sha256,requireThat as need} from '../lib/core.mjs';import {loadActiveMapping} from '../lib/active-mapping.mjs';import {makeMultirowMapping,lookupMultirow} from '../lib/multirow-tpp-mapping.mjs';
import {resolveConfig} from '../lib/config.mjs';import {VERSION,readJSON,writeJSON,stamp,verifySession,ledger,assertNoReview,plainPath} from '../lib/control.mjs';
import {writeZip} from '../lib/zip.mjs';import {trustedAction} from '../lib/browser-actions.mjs';import * as UI from '../lib/browser-workflow.mjs';import {injectDemo} from '../lib/demo.mjs';
import {resolveMemberMapping,NOT_FOUND_DESCRIPTION} from '../lib/member-mapping.mjs';import {selectAssignee,forwardOnce,ASSIGNEE_DISPLAY} from '../lib/forwarding.mjs';
import Core from '../lib/data-core.cjs';import Person from '../lib/person-quoted.cjs';import Identity from '../lib/identity-evidence.cjs';import Prep from '../lib/ticket-prep.cjs';import Queue from '../lib/queue-send.cjs';import Msg from '../lib/msg.cjs';
import {promptManualPerson} from '../lib/manual-person.mjs';import {discoverNameHints,NAME_PROBE_BUDGET} from '../lib/name-probes.mjs';import {selectCurrentIncomingRow} from '../lib/history-binding.mjs';import {sentNotice,permitAcknowledgement,validSendAcknowledgements} from '../lib/send-dialog-policy.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),args=new Set(process.argv.slice(2)),DEMO=args.has('--demo'),PILOT=args.has('--pilot');
const MAX=DEMO?3:PILOT?1:Number(process.env.MCR_MAX_TICKETS||100),DEMO_SCENARIO=process.env.MCR_DEMO_SCENARIO||'normal',log=s=>console.log(s),clean=UI.clean;
const diag={schema:'MCR_LOCAL_RUNNER_DIAGNOSTIC_V2',version:VERSION,phase:'INITIAL',mode:DEMO?'DEMO':'REAL',createdAt:new Date().toISOString(),runId:process.env.MCR_RUN_ID||stamp(),lastError:null,personSource:null,manualNameConfirmations:0,mapping:{loaded:false},browser:{launched:false},send:{clicked:false,verified:false},save:{clicked:false,verified:false},loop:{processed:0,myTasksProcessed:0,queueProcessed:0,forwarded:0,skippedAlreadyAnswered:0,completed:false,finishReason:null,processedTickets:[]},privacy:'No names, IDs, email addresses, mail text, mapping values, paths, URLs or browser profile content.'};
const fail=(c,m)=>need(false,c,m);
async function ask(rl,text){return clean(await rl.question(text));}
async function choosePerson(mail,rl,{preCandidates=null}={}){
 const current=Identity.currentBodyPart(mail.body),currentCandidates=preCandidates??discoverNameHints({...mail,body:current}).candidates;let cs=currentCandidates,quotedOnly=false;
 if(!cs.length){cs=Person.candidates(mail);quotedOnly=cs.length>0;}
 let person;
 if(!cs.length){
  // This is the final fallback AFTER bounded read-only discovery and MSG retries.
  // Only the fictional fixture may answer without operator input.
  let request=prompt=>ask(rl,prompt);
  if(DEMO){
   need(['manual-name','manual-name-denied'].includes(DEMO_SCENARIO),'DEMO_PERSON_MISSING','Unerwarteter leerer Demoname.');
   const scripted=DEMO_SCENARIO==='manual-name' ? ['Max','Mustermann','JA'] : Array.from({length:5},()=>['Max','Mustermann','NEIN']).flat();
   request=async()=>{need(scripted.length,'DEMO_MANUAL_PROMPTS','Zu viele fiktive Rueckfragen.');return scripted.shift();};
  }
  person=await promptManualPerson({ask:request,log});
  diag.personSource=DEMO?'MANUAL_OPERATOR_CONFIRMED_DEMO':'MANUAL_OPERATOR_CONFIRMED';
  diag.manualNameConfirmations++;
  log('PASS NAME_MANUAL_OPERATOR_CONFIRMED - Person muss weiterhin zum ausgewaehlten COMARCH-Member passen.');
 }
 if(person){}else if(cs.length===1)person=cs[0];else{
  const subject=Person.norm(mail.subject),scored=cs.map(c=>({c,score:(subject.includes(Person.norm(c.firstName+' '+c.lastName))||subject.includes(Person.norm(c.lastName+' '+c.firstName))?7:0)+(c.sources.includes('Adressblock')?5:0)+(c.sources.includes('Beschrifteter Name')?5:0)+(c.sources.includes('Signatur')?3:0)})).sort((a,b)=>b.score-a.score);
  if(!quotedOnly&&!scored[0].c.quotedOnly&&scored[0].score>=7&&scored[0].score-(scored[1]?.score||0)>=3)person=scored[0].c;
  else{need(!DEMO,'DEMO_PERSON_AMBIGUOUS','Fiktive Person nicht eindeutig.');log('Mehrere Namenshinweise:');cs.forEach((c,i)=>log(`${i+1}: ${c.name}`));const n=Number(await ask(rl,'Nummer der betroffenen Person: '));need(Number.isInteger(n)&&n>=1&&n<=cs.length,'NAME_CHOICE','Ungueltige Personenauswahl.');person=cs[n-1];}
 }
 if((quotedOnly||person.quotedOnly)&&!DEMO)need(/^ja$/i.test(await ask(rl,'Name nur in aelterer/zitierter Korrespondenz. Zugehoerigkeit geprueft? JA: ')),'QUOTED_NAME_REVIEW','Zitierte Person nicht bestaetigt.');
 const hints=Person.identifierHints(mail,Core.analyzeMail((mail.subject?'Betreff: '+mail.subject+'\n':'')+mail.body).idHints,[person,...cs].filter(Boolean)),evidence=Identity.buildEvidence(mail,hints);
 if(!diag.personSource){
  const sources=person.sources||[];
  diag.personSource=(quotedOnly||person.quotedOnly)?'QUOTED_OPERATOR_REVIEWED':
   sources.includes('Beschrifteter Name')?'CURRENT_EXPLICIT_NAME':
   sources.includes('Signatur')?'CURRENT_SIGNATURE':
   sources.includes('Absender-Anzeigename')?'SENDER_DISPLAY':
   sources.includes('Absender-E-Mail (Suchhinweis)')?'SENDER_EMAIL_LOCALPART':
   sources.includes('Adressblock')?'CURRENT_ADDRESS_BLOCK':'AUTO_CANDIDATE';
  log('NAME_CANDIDATE_DISCOVERY: '+diag.personSource+'; COMARCH-Member-Verifikation weiterhin erforderlich.');
 }
 Person.query(person.firstName,person.lastName);return {person,evidence};
}
async function downloadMail(page,cfg,rl,{automaticOnly=false,documentId=null}={}){
 const folder=path.join(cfg.downloadDirectory,stamp());fs.mkdirSync(folder,{recursive:true});await page.cdp.send('Browser.setDownloadBehavior',{behavior:'allow',downloadPath:folder},null);
 const links=await page.call(function(documentId){
  const list=[];
  // RC16: some COMARCH versions do not set iceDatTblRow on the email table.
  // Restrict this read-only lookup to a visible table row, an exact document ID
  // and a same-origin download endpoint. Never follow other ticket links.
  for(const row of document.querySelectorAll('table tr')){
   if(!row.getClientRects().length)continue;
   for(const n of row.querySelectorAll('a[href*="GetFile?docId="]')){
    try{const u=new URL(n.getAttribute('href'),document.baseURI),id=u.searchParams.get('docId');
     if(documentId&&id!==documentId)continue;
     if(u.origin===location.origin&&/\/DMSWWW\/GetFile$/i.test(u.pathname)&&/^\d{1,15}$/.test(id||'')&&!list.includes(u.href))list.push(u.href);
    }catch{}
   }
  }
  // Caller that lacks a document binding can only use a single unique URL.
  return documentId?list:list.length===1?list:[];
 },documentId);
 diag.msgReadMethods=diag.msgReadMethods||[];
 for(const url of links){
  for(const cache of ['no-store','reload']){
   const r=await page.call(async function(url,cache){try{
    const x=await fetch(url,{credentials:'include',cache,redirect:'error',signal:AbortSignal.timeout(12000)});
    if(!x.ok)return null;const bytes=new Uint8Array(await x.arrayBuffer());
    if(bytes.length<512||bytes.length>33554432)return null;
    let s='';for(let i=0;i<bytes.length;i+=32768)s+=String.fromCharCode(...bytes.subarray(i,i+32768));return btoa(s);
   }catch{return null;}},url,cache);
   if(r){try{const bytes=Buffer.from(r,'base64'),mail=Msg.parseMsg(bytes);
    fs.writeFileSync(path.join(folder,'ticket.msg'),bytes,{flag:'wx',mode:0o600});
    diag.msgReadMethods.push({method:'AUTHENTICATED_FETCH_'+cache,result:'PASS'});return mail;
   }catch{}}
   diag.msgReadMethods.push({method:'AUTHENTICATED_FETCH_'+cache,result:'UNAVAILABLE'});
  }
 }
 if(automaticOnly)return null;
 need(!DEMO,'DEMO_MAIL_MISSING','Fiktive Mail fehlt.');log('MSG-Download automatisch nicht bestaetigt. Im Bot-Browser die aktuelle Original-Mail herunterladen.');await ask(rl,'Nach dem Download ENTER: ');
 const files=fs.readdirSync(folder).filter(n=>/\.msg$/i.test(n));need(files.length===1,'MAIL_DOWNLOAD','Genau eine neue MSG im separaten Downloadordner erforderlich.');return Msg.parseMsg(fs.readFileSync(path.join(folder,files[0])));
}
async function mailAndPerson(page,cfg,rl){
 let checked=0,rounds=0;const trail=[];let latest=null,latestSenderMeta=null;
 const inspect=(mail,method)=>{
  const budget=Math.max(1,NAME_PROBE_BUDGET-checked);
  const scan=discoverNameHints(mail,{maxProbes:budget});
  checked+=scan.checks;
  for(const h of scan.history)if(trail.length<NAME_PROBE_BUDGET)trail.push({phase:method,...h});
  if(scan.candidates.length)log('NAME_DISCOVERY: '+method+' | '+scan.candidates.length+' Suchkandidat(en), '+checked+' Lesepruefungen. COMARCH-Verifikation folgt.');
  return scan.candidates;
 };
 // Three bounded snapshots cover delayed ICEfaces rendering. Never guess from
 // outgoing acknowledgement, unrelated ticket, or a quoted prior e-mail.
 for(let attempt=0;attempt<3&&checked<NAME_PROBE_BUDGET;attempt++){
  rounds++;
  const s=await UI.historyMailSnapshots(page);latest=s;
  const meta=await UI.ticketSenderMetadata(page);
  if(meta.ok)latestSenderMeta=meta;
  trail.push({phase:'SYSTEMDATEN',method:'TICKET_EMAIL_VON',result:meta.ok?'READABLE':'UNAVAILABLE',count:meta.addressCount});
  trail.push({phase:'HISTORY',method:'VISIBLE_HISTORY_SNAPSHOT',result:s.ok?'READABLE':'UNAVAILABLE',count:s.rows?.length||0});
  if(s.ok){
   const snapshot=s.rows.map(row=>({subject:row.subject,senderName:row.sender,senderEmail:row.sender,sender:row.sender,body:row.content,documentId:row.documentId,direction:row.direction||'UNKNOWN'}));
   // The newest visible history row can be OUR PREVIOUS OUTGOING REPLY.
   // Anchor name discovery to the original incoming message instead.
   const original=selectCurrentIncomingRow(snapshot,meta.ok?meta.senderEmail:null);
   trail.push({phase:'HISTORY',method:'CURRENT_INCOMING_BINDING',result:original?'MATCH':'UNAVAILABLE',count:original?1:0});
   if(!original){await sleep(200);continue;}
   // Systemdaten / E-Mail von is the currently bound sender on the ticket.
   // Some COMARCH history tables omit sender names or display the service
   // mailbox, so enrich the current ORIGINAL row before giving up.
   const bound={...original,senderEmail:meta.ok?meta.senderEmail:original.senderEmail,senderName:meta.ok?meta.senderEmail:original.senderName};
   const found=inspect(bound,meta.ok?'SYSTEMDATEN_EMAIL_VON_PLUS_HISTORY':'HISTORY_DOM_CURRENT');
   if(found.length){const source=meta.ok?'SYSTEMDATEN_EMAIL_VON':'HISTORY_DOM_CURRENT';diag.nameDiscovery={checked,rounds,successfulSource:source,trail};diag.mailSource='HISTORY_DOM';return {mail:bound,...await choosePerson(bound,rl,{preCandidates:found})};}
   // Read the original mail tied to THIS document ID, first via authenticated
   // GET and then a guarded browser download if needed. No sending is involved.
   if(original.documentId&&!DEMO){
    let msg=null;
    try{msg=await downloadMail(page,cfg,rl,{automaticOnly:true,documentId:original.documentId});}
    catch(e){trail.push({phase:'ORIGINAL_MSG',method:'READ_ORIGINAL',result:'UNAVAILABLE',count:0});}
    const sameSubject=!original.subject||!msg?.subject||Person.norm(original.subject)===Person.norm(msg.subject);
    if(msg&&sameSubject){const foundMsg=inspect(msg,'BOUND_ORIGINAL_MSG');
     if(foundMsg.length){diag.nameDiscovery={checked,rounds,successfulSource:'BOUND_ORIGINAL_MSG',trail};diag.mailSource='ORIGINAL_MSG_NAME_FALLBACK';log('NAME_CANDIDATE_FALLBACK: Original-MSG hat Namenshinweis geliefert.');return {mail:msg,...await choosePerson(msg,rl,{preCandidates:foundMsg})};}
    }else trail.push({phase:'ORIGINAL_MSG',method:'SUBJECT_OR_DOWNLOAD',result:msg?'SUBJECT_MISMATCH':'UNAVAILABLE',count:0});
   }
   if(attempt===2){diag.nameDiscovery={checked,rounds,successfulSource:null,trail};diag.mailSource='HISTORY_DOM';return {mail:bound,...await choosePerson(bound,rl,{preCandidates:[]})};}
  }
  await sleep(350+(attempt*250));
 }
 diag.nameDiscovery={checked,rounds,successfulSource:null,trail};
 const mail=await downloadMail(page,cfg,rl);diag.mailSource='MSG_DOWNLOAD';
 const bound=latestSenderMeta?.ok?{...mail,senderEmail:latestSenderMeta.senderEmail,
  senderName:mail.senderName||latestSenderMeta.senderEmail}:mail;
 const found=inspect(bound,latestSenderMeta?.ok?'MSG_AND_SYSTEMDATEN_SENDER':'MSG_DOWNLOAD');
 diag.nameDiscovery={checked,rounds,successfulSource:found.length?(latestSenderMeta?.ok?'MSG_AND_SYSTEMDATEN_SENDER':'MSG_DOWNLOAD'):null,trail};
 return {mail:bound,...await choosePerson(bound,rl,{preCandidates:found})};
}
async function selectMember(page,person,evidence,rl){let s=await UI.selectedMember(page,person);if(s){Identity.requireMatched(s,person,evidence);return s;}
 const id='mainForm:member-value-id';
 const manualGate=DEMO?null:async(state)=>{
  log('MEMBER_INPUT_MANUAL_GATE ('+state+'): Feld trotz kontrolliertem Scrollen nicht anklickbar. Kein unsicherer Klick.');
  log('Im EIGENEN Bot-Edge nur das Member-Eingabefeld anklicken (nicht den Vorschlag oder Senden).');
  await ask(rl,'Member-Eingabefeld angeklickt? Dann ENTER: ');
 };
 need(await UI.setInputQuery(page,id,Queue.memberSearchQuery(person.firstName,person.lastName),{manualGate}),'MEMBER_FIELD','Member-Feld nicht bearbeitbar.');let suggestions=[];
 for(let i=0;i<45;i++){await sleep(180);suggestions=await UI.suggestionPoints(page,id,[person.lastName+' '+person.firstName,person.firstName+' '+person.lastName],{member:true});if(suggestions.length)break;}
 let pick=null;if(evidence.expectedId){const xs=suggestions.filter(s=>s.id===evidence.expectedId);if(xs.length===1)pick=xs[0];}if(!pick&&suggestions.length===1)pick=suggestions[0];
 diag.phase='MEMBER_SUGGESTION_SELECTION';
 if(pick){
  // The browser may rerender the autocomplete while we examine it. Rebind the
  // candidate to the currently displayed suggestion before one trusted click.
  const current=await UI.suggestionPoints(page,id,[person.lastName+' '+person.firstName,person.firstName+' '+person.lastName],{member:true});
  const same=current.filter(x=>x.x===pick.x&&x.y===pick.y&&x.id===pick.id);
  if(same.length===1){await page.mouseClick(same[0].x,same[0].y);log('PASS MEMBER_SUGGESTION_TRUSTED_CLICK');}
  else pick=null;
 }
 if(!pick){
  need(!DEMO,'DEMO_MEMBER_AMBIGUOUS','Demo-Member nicht eindeutig.');
  log('MEMBER_SUGGESTION_MANUAL_GATE: COMARCH-Vorschlag im eigenen Bot-Edge manuell auswaehlen; kein automatischer unsicherer Klick.');
  await ask(rl,'Richtigen Member im Bot-Browser auswaehlen; dann ENTER: ');
 }
 diag.phase='MEMBER_COMMIT_VERIFY';
 for(let i=0;i<150;i++){s=await UI.selectedMember(page,person);if(s)break;await sleep(200);}need(s,'MEMBER_COMMIT','COMARCH hat keine eindeutige Member/MercerID-Zuordnung bestaetigt.');Identity.requireMatched(s,person,evidence);return s;
}
/** IceFaces dropdowns commit their chosen value only after a genuine focus
 * change. In COMARCH the category must lose focus to the already selected
 * MEMBER field before its dependent subcategory is selected. NEVER type into
 * the MEMBER field here: it carries the verified identity. */
async function fixedFields(page,rl){
 // COMARCH can retain a correctly selected field across attempts. In that
 // situation do NOT retype, reselect or ask the operator to confirm it.
 const audit=(field,action,result)=>{
  const a=diag.fixedFieldResolution||(diag.fixedFieldResolution=[]);
  if(a.length<40)a.push({field,action,result});
 };
 const responsibilityReady=await page.call(function(text){
  const s=document.getElementById('mainForm:responsibility-value-id');
  return !!(s?.tagName==='SELECT'&&!s.disabled&&String(s.selectedOptions?.[0]?.textContent||'').trim()===text);
 },Prep.FIXED.responsibility);
 if(!responsibilityReady){
  const r=await page.call(function(text){
   const s=document.getElementById('mainForm:responsibility-value-id');
   if(!s||s.tagName!=='SELECT'||s.disabled)return false;
   const o=Array.from(s.options).filter(x=>String(x.textContent).trim()===text);
   if(o.length!==1)return false;
   Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype,'value').set.call(s,o[0].value);
   s.dispatchEvent(new Event('input',{bubbles:true}));s.dispatchEvent(new Event('change',{bubbles:true}));
   return s.selectedOptions[0]?.textContent.trim()===text;
  },Prep.FIXED.responsibility);
  need(r,'RESPONSIBILITY','Second Level konnte nicht gesetzt werden.');audit('responsibility','SET','PASS');
 }else audit('responsibility','ALREADY_EXACT','PASS');
 const manualGate=DEMO?null:async(state,field)=>{
  log('FIXED_INPUT_FOCUS_ASSIST ('+state+'): '+field+' ist nicht sicher anklickbar.');
  // Focusing is not authorization to change a value or to send.
  await ask(rl,'Im Bot-Edge NUR das richtige Textfeld anklicken, dann ENTER: ');
 };
 const valueOf=async id=>page.call(function(id){
  const hits=Array.from(document.querySelectorAll('input')).filter(x=>x.id===id&&x.isConnected);
  return hits.length===1?String(hits[0].value??'').replace(/\s+/g,' ').trim():null;
 },id);
 const waitExact=async(id,value,ms=5000)=>{
  let stable=0,end=Date.now()+(DEMO?Math.min(ms,1600):ms);
  while(Date.now()<end){const got=await valueOf(id);
   if(got===value){if(++stable>=3)return true;}else stable=0;
   await sleep(180);
  }return false;
 };
 const focus=async(id,reason,{optional=false}={})=>{
  const x=await UI.focusInput(page,id,{manualGate:optional?null:manualGate?state=>manualGate(state,reason):null});
  audit(reason,'FOCUS',x.ok?'PASS':x.state||'FAILED');
  if(!optional)need(x.ok,x.state||'FIXED_FOCUS','Fokuswechsel fuer '+reason+' nicht bestaetigt.');
  await sleep(350);return x.ok;
 };
 const categoryId='mainForm:category-value-id',subcategoryId='mainForm:category-sub-value-id',signatureId='mainForm:signature-value-id';
 const select=async(id,value,field)=>{
  // Already selected? Do NOT enter the dropdown a second time. The following
  // blur/stable checks will independently verify the field before send.
  if(await valueOf(id)===value){audit(field,'ALREADY_EXACT','PASS');log('PASS '+field.toUpperCase()+'_ALREADY_EXACT_NO_RESELECTION');return;}
  let ready=false;const end=Date.now()+10000;
  while(Date.now()<end){ready=await page.call(function(id){const f=document.getElementById(id);
   return !!(f&&f.tagName==='INPUT'&&!f.disabled&&!f.readOnly&&f.getClientRects().length>0);
  },id);if(ready)break;await sleep(200);}
  need(ready,'FIXED_FIELD','Abhaengiges Feld '+id+' nicht bearbeitbar.');
  // Do not repeatedly hammer the same autocomplete. These methods differ:
  // existing suggestion, trusted keyboard, renewed focus, legacy input event,
  // and shorter trusted search. No action ever changes a Member or sends mail.
  const strategies=[
   {name:'VISIBLE_EXACT_OPTION',run:async()=>{}},
   {name:'TRUSTED_KEYBOARD',run:async()=>{
     try{return await UI.typeTrustedFixedQuery(page,id,value,{manualGate:manualGate?x=>manualGate(x,id):null});}
     catch(e){if(['FIXED_QUERY_MISMATCH','FIXED_INPUT_FOCUS_LOST','INPUT_CHANGED'].includes(e.code))return e.code;throw e;}
   }},
   {name:'FOCUS_REOPEN',run:async()=>UI.focusInput(page,id,{manualGate:null})},
   {name:'LEGACY_INPUT_KEYUP',run:async()=>UI.setInputQuery(page,id,value,{manualGate:null})},
   {name:'TRUSTED_SHORT_QUERY',run:async()=>{
     const shorter=value.slice(0,Math.max(4,Math.ceil(value.length/2)));
     try{return await UI.typeTrustedFixedQuery(page,id,shorter,{manualGate:null});}
     catch(e){if(['FIXED_QUERY_MISMATCH','FIXED_INPUT_FOCUS_LOST','INPUT_CHANGED'].includes(e.code))return e.code;throw e;}
   }},
  ];
  let found=[],method=null;
  for(const strategy of strategies){
   try{const obs=await strategy.run();audit(field,strategy.name,'EXECUTED'+(typeof obs==='string'?':'+obs:''));}
   catch(e){audit(field,strategy.name,e.code||'FAILED');if(DEMO&&e.code==='DEMO_PERSON_MISSING')throw e;continue;}
   for(let k=0;k<12;k++){
    found=await UI.suggestionPoints(page,id,[value]);
    if(found.length)break;
    await sleep(180);
   }
   if(found.length){method=strategy.name;break;}
   audit(field,strategy.name,'NO_EXACT_CLICK_TARGET');
  }
  if(found.length===1){
   const now=await UI.suggestionPoints(page,id,[value]);
   if(now.length===1&&now[0].x===found[0].x&&now[0].y===found[0].y){
    await page.mouseClick(now[0].x,now[0].y);
    audit(field,'EXACT_OPTION_TRUSTED_CLICK_'+method+(now[0].method?'_'+now[0].method:''),'PASS');await sleep(420);return;
   }
   audit(field,'EXACT_OPTION_MOVED','NOT_CLICKED');
  }else if(found.length>1){audit(field,'SUGGESTION_AMBIGUOUS','NOT_CLICKED');}
  // Never equate a typed string with an option selection. A human fallback is
  // allowed ONLY in the supervised real run, followed by exact field checks.
  // This keeps the ticket moving when the ICEfaces suggestions are invisible
  // to Chromium but visible to the local operator.
  need(!DEMO,found.length>1?'FIXED_OPTION_AMBIGUOUS':'FIXED_OPTION_NOT_FOUND',
    'COMARCH-Auswahlliste nicht sicher bedienbar: '+field+'. Kein Versand.');
  log('FIXED_OPTION_OPERATOR_GATE: Autoauswahl von '+field+' nicht eindeutig. Kein Versand bis zur Bestaetigung.');
  log('Im Bot-Edge exakt "'+value+'" einmal aus der Vorschlagsliste waehlen (keinen aehnlichen Eintrag).');
  await ask(rl,'Nach erfolgter Auswahl ENTER: ');
  audit(field,'OPERATOR_SELECTED_EXACT','AWAIT_COMMIT_VERIFY');
 };
 await select(categoryId,Prep.FIXED.category,'category');
 await focus('mainForm:member-value-id','Kategorie per Member-Fokus bestaetigen');
 need(await waitExact(categoryId,Prep.FIXED.category),'FIXED_VERIFY','Dokumentenkategorie nicht eindeutig bestaetigt.');
 log('PASS CATEGORY_COMMITTED_AFTER_MEMBER_FOCUS');
 await select(subcategoryId,Prep.FIXED.subcategory,'subcategory');
 // One physical focus transfer without touching the Member ID or input text.
 await focus('mainForm:member-value-id','Unterkategorie per Member-Fokus bestaetigen');
 let committed=await waitExact(subcategoryId,Prep.FIXED.subcategory);
 if(!committed){audit('subcategory','WAIT_FOR_ICEfaces','PENDING');committed=await waitExact(subcategoryId,Prep.FIXED.subcategory,7500);}
 if(!committed){
  // Pure, reversible focus probes; never select a different subcategory.
  if(await focus(categoryId,'Unterkategorie Alternativfokus Kategorie',{optional:true}))committed=await waitExact(subcategoryId,Prep.FIXED.subcategory,2600);
  if(!committed&&await focus('mainForm:member-value-id','Unterkategorie Alternativfokus Member',{optional:true}))committed=await waitExact(subcategoryId,Prep.FIXED.subcategory,2600);
 }
 need(committed,'FIXED_VERIFY','Unterkategorie Personenschriftwechsel nicht bestaetigt. Keine andere Unterkategorie waehlen.');
 log('PASS SUBCATEGORY_COMMITTED_EXACT_PERSONENSCHRIFTWECHSEL');
 await select(signatureId,Prep.FIXED.signature,'signature');
 // The editor does not always deliver the blur COMARCH expects. Probe other
 // harmless fields in a fixed order. No retyping, manual confirmation or send.
 let signed=false;
 for(const mode of ['EDITOR','MEMBER','EDITOR','MEMBER','EDITOR']){
  const focused=mode==='EDITOR'?await UI.focusEditor(page):await focus('mainForm:member-value-id','Signatur Alternativfokus Member',{optional:true});
  audit('signature','COMMIT_FOCUS_'+mode,focused?'PASS':'UNAVAILABLE');
  if(focused){await sleep(450);signed=await waitExact(signatureId,Prep.FIXED.signature,mode==='EDITOR'?2600:2200);}
  if(signed)break;
 }
 need(signed,'FIXED_VERIFY','Signatur nach automatischen Fokuswechseln nicht bestaetigt. Kein manueller Bestaetigungsdialog und kein Versand.');
 const fixed=await UI.fixedFieldValues(page);
 need(fixed.responsibility===Prep.FIXED.responsibility&&fixed.category===Prep.FIXED.category&&
  fixed.subcategory===Prep.FIXED.subcategory&&fixed.signature===Prep.FIXED.signature,
  'FIXED_VERIFY','Pflichtfelder nicht gleichzeitig exakt bestaetigt.');
 log('PASS FIXED_FIELDS_ALL_VERIFIED');
}
/** The send button gets exactly ONE trusted mouse click. Browser/HTML dialogs
 * are acknowledged individually. A still-visible HTML dialog cannot receive
 * a second OK click, even when COMARCH's AJAX response is delayed. The third
 * distinct dialog is permitted ONLY if it says “Nachricht gesendet”.
 * Never re-send to resolve any ambiguous outcome.
 */
async function sendOnce(page,rl,id,journal){
 const before=await UI.historyCount(page),ed=await UI.editor(page);
 need(Number.isInteger(before)&&before>=1&&ed.ok&&!ed.empty,'SEND_PRECONDITION','Nachrichtenverlauf/Antworteditor nicht eindeutig.');
 diag.send={clicked:false,verified:false,historyBefore:before,historyAfter:null,htmlDialogs:0,jsDialogs:0,successNotices:0,htmlPendingWaits:0};
 let active=true,error=null,nativeOpen=false;
 const total=()=>diag.send.htmlDialogs+diag.send.jsDialogs;
 const offOpen=page.cdp.on('Page.javascriptDialogOpening',(p,s)=>{
  if(!active||s!==page.sessionId)return;
  if(!['alert','confirm'].includes(p.type)){error='UNEXPECTED_JS_DIALOG';return;}
  if(nativeOpen){error='SEND_DUPLICATE_JS_DIALOG_EVENT';return;}
  const success=sentNotice(p.message);
  if(!permitAcknowledgement({previous:total(),successNotices:diag.send.successNotices,success,type:p.type})){
   error='SEND_UNEXPECTED_EXTRA_DIALOG';return;
  }
  nativeOpen=true;diag.send.jsDialogs++;
  if(success)diag.send.successNotices++;
  page.cdp.send('Page.handleJavaScriptDialog',{accept:true},s).catch(()=>{error='DIALOG_FAILED';});
 });
 const offClosed=page.cdp.on('Page.javascriptDialogClosed',(_p,s)=>{if(active&&s===page.sessionId)nativeOpen=false;});
 try{
  await UI.assertTicket(page,id);
  await trustedAction(page,{id:'mainForm:send-new-message-button'},()=>{diag.send.clicked=true;});
  const end=Date.now()+(DEMO?15000:45000);
  let stable=0,reset=0;
  while(Date.now()<end){
   need(!error,error||'DIALOG_FAILED','Unbekannte oder zusaetzliche Versandbestaetigung. Nicht erneut senden.');
   const probe=await UI.htmlOkProbe(page);
   if(probe.state==='WAITING_CLOSED'){
    diag.send.htmlPendingWaits++;
    await sleep(160);continue;
   }
   if(probe.state==='READY'){
    need(permitAcknowledgement({previous:total(),successNotices:diag.send.successNotices,success:probe.success,type:'html'}),
     'SEND_UNEXPECTED_EXTRA_DIALOG','Zusatzdialog ist keine eindeutig bestaetigte Versand-Erfolgsmeldung. Kein erneutes Senden.');
    const claimed=await UI.htmlOkProbe(page,probe.signature);
    if(claimed.state==='CHANGED'||claimed.state==='NONE'||claimed.state==='WAITING_CLOSED')continue;
    need(claimed.state==='CLAIMED'&&claimed.success===probe.success,'SEND_DIALOG_CHANGED','OK-Dialog waehrend Auswahl veraendert. Kein unsicherer Klick.');
    await page.mouseClick(claimed.x,claimed.y); // one trusted click for exactly this dialog node
    diag.send.htmlDialogs++;
    if(claimed.success)diag.send.successNotices++;
    stable=0;reset=0;
    await sleep(220);
    continue;
   }
   need(probe.state==='NONE','UNEXPECTED_DIALOG','Unbekannter oder nicht anklickbarer COMARCH-Dialog. Kein erneutes Senden.');
   if(nativeOpen){await sleep(160);continue;}
   const n=await UI.historyCount(page);
   need(n===null||n<=before+1,'SEND_MULTIPLE_HISTORY_ROWS','Mehr als ein neuer Verlaufseintrag. Manuell pruefen.');
   const ack=validSendAcknowledgements(diag.send);
   if(n===before+1&&ack){
    if(!stable)stable=Date.now();
    if(Date.now()-stable>=1200){diag.send.historyAfter=n;diag.send.verified=true;diag.send.ackMode='HISTORY_INCREMENT';journal?.set(id,'SENT_CONFIRMED');return;}
   }else stable=0;
   const e=await UI.editor(page);
   if(!DEMO&&e.ok&&e.empty&&ack){
    if(!reset)reset=Date.now();
    if(Date.now()-reset>=1800){diag.send.historyAfter=n;diag.send.verified=true;diag.send.ackMode='EDITOR_RESET_AFTER_CONFIRMED_DIALOGS';journal?.set(id,'SENT_CONFIRMED');return;}
   }else reset=0;
   await sleep(220);
  }
  fail('SEND_UNVERIFIED','Versand nicht abschliessend bestaetigt. KEIN zweiter Sendeklick; Verlauf und Speicherung pruefen.');
 }finally{active=false;offOpen();offClosed();}
}
/** Ticket saving receives a single trusted click, and each HTML OK prompt
 * may be accepted only once; a slow/modal response cannot trigger duplicates.
 */
async function saveOnce(page,id,journal,{forwardOnly=false}={}){
 diag.save={clicked:false,verified:false,dialogClicks:0};
 let active=true,error=null;
 const off=page.cdp.on('Page.javascriptDialogOpening',(p,s)=>{
  if(!active||s!==page.sessionId)return;
  if(!['alert','confirm'].includes(p.type)){error='UNEXPECTED_SAVE_DIALOG';return;}
  page.cdp.send('Page.handleJavaScriptDialog',{accept:true},s).catch(()=>{error='SAVE_DIALOG_FAILED';});
 });
 try{
  await UI.assertTicket(page,id);
  await trustedAction(page,{text:'Ticket speichern'},()=>{
   if(forwardOnly)journal?.forwardSet(id,'ROUTE_SAVE_INTENT');else journal?.set(id,'SAVE_INTENT');
   diag.save.clicked=true;
  });
  log('Ticket speichern: ein gepruefter Browser-Mausklick ausgefuehrt.');
  const end=Date.now()+12000;let quiet=0;
  while(Date.now()<end){
   need(!error,error||'SAVE_DIALOG_FAILED','Speicherdialog unklar.');
   const probe=await UI.htmlOkProbe(page);
   if(probe.state==='WAITING_CLOSED'){quiet=0;await sleep(160);continue;}
   if(probe.state==='READY'){
    need(diag.save.dialogClicks<2,'UNEXPECTED_SAVE_DIALOG','Zu viele verschiedene Speicherdialoge.');
    const claim=await UI.htmlOkProbe(page,probe.signature);
    if(['CHANGED','NONE','WAITING_CLOSED'].includes(claim.state))continue;
    need(claim.state==='CLAIMED'&&claim.success===probe.success,'UNEXPECTED_SAVE_DIALOG','Speicherdialog veraendert.');
    await page.mouseClick(claim.x,claim.y);diag.save.dialogClicks++;quiet=0;await sleep(200);continue;
   }
   need(probe.state==='NONE','UNEXPECTED_SAVE_DIALOG','Speicherdialog nicht eindeutig.');
   if(!quiet)quiet=Date.now();
   if(Date.now()-quiet>1800)return;
   await sleep(200);
  }
  fail('SAVE_DIALOG_TIMEOUT','Speicherdialog nicht abgeschlossen; kein zweiter Speicherklick.');
 }finally{active=false;off();}
}
async function verifySaved(page,id,description){for(const scope of ['IN_BEARBEITUNG','WARTESCHLANGE_INTL01']){let snap=await UI.navigateToScope(page,scope),row=snap.rows.find(r=>r.ticketId===id);if(!row)continue;const end=Date.now()+(DEMO?1200:10000);while(Date.now()<end){if(!row.descriptionBlank&&clean(row.descriptionValue)===clean(description)){diag.save.verified=true;diag.save.verification=scope==='IN_BEARBEITUNG'?'MY_TASKS_ALL_DESCRIPTION_CONTENT_MATCH':'QUEUE_ALL_DESCRIPTION_CONTENT_MATCH';await UI.navigateToScope(page,'IN_BEARBEITUNG');return;}await sleep(250);snap=await UI.queueTableSnapshot(page);row=snap.rows.find(r=>r.ticketId===id);if(!row)break;}}
 fail('SAVE_UNVERIFIED','Vollstaendige Beschreibung nach Speichern nicht nachgewiesen. Nicht erneut senden.');}

/** No reply text, no recipient, no send button for unmatched identities.
 * Save the exact note and fixed fields FIRST and verify persistence. Only then
 * select the top-level assignee and trigger the one-way forward action.
 */
async function forwardMissingPerson(page,rl,row,scope,journal,person,evidence,member){
 log('BESTAND_NOT_FOUND_EXACT_AND_PREFIX11 - Keine E-Mail, kein Versand.');
 let w=await UI.writeDescription(page,NOT_FOUND_DESCRIPTION);
 need(w.ok,'DESCRIPTION_WRITE','Manueller Klaerungstext nicht eindeutig einsetzbar: '+w.state);
 await sleep(650);need(await UI.verifyDescription(page,NOT_FOUND_DESCRIPTION),'DESCRIPTION_VERIFY','Manueller Klaerungstext nicht nachweisbar.');
 await fixedFields(page,rl);need(await UI.verifyDescription(page,NOT_FOUND_DESCRIPTION),'DESCRIPTION_CHANGED','Beschreibung nach Kategorieauswahl veraendert.');
 const recheck=await UI.selectedMember(page,person);Identity.requireMatched(recheck,person,evidence);need(recheck.id===member.id,'MEMBER_CHANGED','Member vor Weiterleitung veraendert.');
 if(PILOT&&!DEMO){
  log('PILOT OHNE E-MAIL: '+row.ticketId+' | Weiterleitung an '+ASSIGNEE_DISPLAY+'.');
  log('Zusatzbeschreibung: '+NOT_FOUND_DESCRIPTION+' | Zust.: Second Level | Kategorie: Allgemeine Schriftwechsel | Unterkategorie: Personenschriftwechsel.');
  need((await ask(rl,'Angaben geprueft und Weiterleitung statt E-Mail freigeben? WEITERLEITEN: ')).toUpperCase()==='WEITERLEITEN','ROUTE_NOT_ARMED','Weiterleitung nicht freigegeben. Kein Versand.');
 }
 if(!DEMO){need(loadActiveMapping(root).fileHash===diag.mapping.fileHash,'MAPPING_CHANGED','Aktives Mapping veraendert.');journal.beginForward(row.ticketId,NOT_FOUND_DESCRIPTION);}
 await saveOnce(page,row.ticketId,journal,{forwardOnly:true});await verifySaved(page,row.ticketId,NOT_FOUND_DESCRIPTION);
 journal?.forwardSet(row.ticketId,'ROUTE_SAVED_VERIFIED');
 // Re-open the same verified ticket without selecting an unrelated row.
 let current=null;
 for(const s of [scope,scope==='IN_BEARBEITUNG'?'WARTESCHLANGE_INTL01':'IN_BEARBEITUNG']){
  const snap=await UI.navigateToScope(page,s);current=snap.rows.find(r=>r.ticketId===row.ticketId);
  if(current)break;
 }
 need(current,'ROUTE_TICKET_NOT_VISIBLE','Beschreibung gespeichert, Ticket vor Weiterleitung nicht erneut auffindbar. Kein blinder Klick.');
 await UI.openTicket(page,current);await UI.ensureEdit(page);await UI.assertTicket(page,row.ticketId);
 need(await UI.verifyDescription(page,NOT_FOUND_DESCRIPTION),'ROUTE_DESCRIPTION_NOT_PERSISTED','Gespeicherte Beschreibung vor Weiterleitung nicht nachgewiesen.');
 const fixed=await UI.fixedFieldValues(page);
 need(fixed.responsibility===Prep.FIXED.responsibility&&fixed.category===Prep.FIXED.category&&fixed.subcategory===Prep.FIXED.subcategory&&fixed.signature===Prep.FIXED.signature,'ROUTE_FIXED_FIELDS_NOT_SAVED','Zustaendigkeit/Kategorien/Signatur nach Speichern nicht vollstaendig. Keine Weiterleitung.');
 await selectAssignee(page);
 const finalFixed=await UI.fixedFieldValues(page);
 need(finalFixed.responsibility===Prep.FIXED.responsibility&&finalFixed.category===Prep.FIXED.category&&finalFixed.subcategory===Prep.FIXED.subcategory&&finalFixed.signature===Prep.FIXED.signature,'ROUTE_FIXED_FIELDS_CHANGED','Pflichtfelder nach Bearbeiterauswahl veraendert; keine Weiterleitung.');
 const proof=await forwardOnce(page,{
  beforeClick:()=>journal?.forwardSet(row.ticketId,'FORWARD_INTENT'),
  confirmManually:DEMO?null:async()=>{
   log('Weiterleitung wurde genau einmal angeklickt, aber COMARCH hat keinen auswertbaren Erfolgsnachweis gezeigt.');
   log('Bitte in COMARCH sicherstellen: Ticket ist Gutierrez Victor zugewiesen und Beschreibung gespeichert. KEINEN zweiten Weiterleitungsklick ausloesen.');
   return (await ask(rl,'Nach eigener Pruefung WEITERGELEITET bestaetigen, sonst ENTER: ')).toUpperCase()==='WEITERGELEITET';
  }
 });
 journal?.forwardSet(row.ticketId,'ROUTED_CONFIRMED');
 diag.forward={verified:true,method:proof.source,noEmail:true,descriptionVerified:true,fixedFieldsVerified:true};
 diag.loop.processed++;diag.loop.forwarded++;
 if(scope==='IN_BEARBEITUNG')diag.loop.myTasksProcessed++;else diag.loop.queueProcessed++;
 diag.loop.processedTickets.push({source:scope,type:'FORWARDED_WITHOUT_EMAIL',route:proof.source,save:diag.save.verification,lookup:'NOT_FOUND_EXACT_AND_PREFIX11',fixedFieldsVerified:true});
 log('PASS PERSON_NOT_FOUND_FORWARDED - ohne E-Mail an '+ASSIGNEE_DISPLAY+'.');
 await UI.navigateToScope(page,'IN_BEARBEITUNG');
}
async function processTicket(page,mapping,rl,row,scope,cfg,journal){diag.personSource=null;diag.nameDiscovery=null;diag.fixedFieldResolution=[];diag.phase='EDIT_OPEN';await UI.ensureEdit(page);await UI.assertTicket(page,row.ticketId);diag.phase='MAIL_AND_PERSON';const {person,evidence}=await mailAndPerson(page,cfg,rl);
 const tAudit=diag.nameDiscoveryByTicket||(diag.nameDiscoveryByTicket=[]);
 if(tAudit.length<100)tAudit.push({ordinal:diag.loop.processed+1,source:diag.nameDiscovery?.successfulSource||diag.mailSource||'MANUAL',readProbes:diag.nameDiscovery?.checked??0,usedManualInput:diag.personSource==='MANUAL_OPERATOR_CONFIRMED'});
 diag.phase='MEMBER_SEARCH';const member=await selectMember(page,person,evidence,rl);log('Identitaetsnachweis PASS ('+evidence.mode+').');
 diag.phase='MAPPING_LOOKUP';const resolved=resolveMemberMapping(mapping.map,member.id);
 diag.lookup={status:resolved.kind,method:resolved.method,sourceRowCount:resolved.entry?.rowCount??0,descriptionLineCount:resolved.entry?.descriptionLines.length??0,genderStatus:resolved.entry?.genderStatus??null};
 if(resolved.kind==='NOT_FOUND'){diag.phase='FORWARD_MISSING_PERSON';await forwardMissingPerson(page,rl,row,scope,journal,person,evidence,member);return;}
 if(resolved.method==='PREFIX_11_REMOVED')log('PASS PREFIX11_FALLBACK_MATCH - COMARCH-ID unveraendert; nur Bestands-Lookup mit gekuerzter Kennung.');
 const entry=resolved.entry;diag.phase='DESCRIPTION_AND_FIXED_FIELDS';
 // Check for the same outgoing acknowledgement before touching a user draft
 // or any fixed field. In particular, a previous bot run may have sent the
 // mail but crashed before SAVE. This is NOT an instruction to resend it.
 const earlySal=entry.gender==='M'?'Herr':entry.gender==='F'?'Frau':null;
 if(earlySal){const priorReply=Prep.replyText(earlySal,person.lastName);
  need(!(await UI.acknowledgementAlreadyInHistory(page,priorReply)),'REPLY_ALREADY_IN_HISTORY','Empfangsbestaetigung bereits im COMARCH-Verlauf vorhanden. Kein neuer Versand und kein Ueberschreiben eines bestehenden Entwurfs. Speicherung gesondert pruefen.');
 }
 if(entry.hasCachedFormulas&&!DEMO)need(/^ja$/i.test(await ask(rl,'Aktualitaet der gespeicherten Formelwerte aller Bestandszeilen geprueft? JA: ')),'FORMULA_REVIEW_REQUIRED','Formelcache nicht freigegeben.');
 log('Bestandsabgleich: '+entry.rowCount+' Quellzeile(n), eine Antwort pro Ticket.');const w=await UI.writeDescription(page,entry.description);need(w.ok,'DESCRIPTION_WRITE','Beschreibung nicht eindeutig einsetzbar: '+w.state);await sleep(700);need(await UI.verifyDescription(page,entry.description),'DESCRIPTION_VERIFY','Beschreibung nach Seitenreaktion abweichend.');await fixedFields(page,rl);
 let sal=entry.gender==='M'?'Herr':entry.gender==='F'?'Frau':null;if(!sal){need(!DEMO,'DEMO_GENDER','Fiktive Anrede fehlt.');const a=(await ask(rl,'Anrede aus Bestand nicht eindeutig. Geprueft: H=Herr / F=Frau: ')).toUpperCase();need(['H','F'].includes(a),'SALUTATION_REQUIRED','Anrede nicht freigegeben.');sal=a==='H'?'Herr':'Frau';}
 const reply=Prep.replyText(sal,person.lastName);const replyResult=await UI.editor(page,reply);
 need(!replyResult.occupied,'REPLY_DRAFT_OCCUPIED','Im COMARCH-Antworteditor steht bereits ein abweichender Entwurf. Er wurde nicht ueberschrieben oder versendet. Bitte bestehenden Entwurf und Nachrichtenverlauf pruefen.');
 need(replyResult.ok,'REPLY_WRITE','Antworteditor nicht eindeutig erkannt/bestaetigt: '+(replyResult.state||'UNKNOWN')+'. Kein Versand.');await sleep(500);const dest=await UI.recipient(page);need(dest.ok,'RECIPIENT','Genau ein Empfaenger im Feld An erforderlich.');
 if(PILOT&&!DEMO){log('PILOT: Einmalige Versandfreigabe erfolgte bereits ueber START. Kein zweites SENDEN erforderlich.');diag.pilotAutomaticSend=true;}
 await UI.assertTicket(page,row.ticketId);const finalMember=await UI.selectedMember(page,person);Identity.requireMatched(finalMember,person,evidence);need(finalMember.id===member.id,'MEMBER_CHANGED','Member vor Versand geaendert.');need((await UI.recipient(page)).address===dest.address,'RECIPIENT_CHANGED','Empfaenger geaendert.');need(await UI.verifyDescription(page,entry.description),'DESCRIPTION_CHANGED','Beschreibung vor Versand geaendert.');const finalFixed=await UI.fixedFieldValues(page);need(finalFixed.responsibility===Prep.FIXED.responsibility&&finalFixed.category===Prep.FIXED.category&&finalFixed.subcategory===Prep.FIXED.subcategory&&finalFixed.signature===Prep.FIXED.signature,'FIXED_FIELD_CHANGED_BEFORE_SEND','Unterkategorie oder anderes Pflichtfeld vor dem Versand veraendert. Kein Versand.');const ed=await UI.editor(page);need(ed.ok&&Prep.sameText(ed.text,reply),'REPLY_CHANGED','Antwort vor Versand geaendert.');need(!(await UI.acknowledgementAlreadyInHistory(page,reply)),'REPLY_ALREADY_IN_HISTORY','Diese Empfangsbestaetigung ist bereits im COMARCH-Verlauf vorhanden. Kein zweiter Versand.');
 if(!DEMO){need(loadActiveMapping(root).fileHash===mapping.fileHash,'MAPPING_CHANGED','Aktives Mapping im Lauf geaendert.');journal.begin(row.ticketId,entry.description);}
 diag.phase='SEND_AND_SAVE';await sendOnce(page,rl,row.ticketId,journal);need(validSendAcknowledgements(diag.send),'SEND_DIALOGS_NOT_VERIFIED','COMARCH-OK-Bestaetigungen nicht vollstaendig nachgewiesen.');log('PASS SEND_DIALOGS_CONFIRMED_ONCE ('+(diag.send.htmlDialogs+diag.send.jsDialogs)+' verschiedene Dialoge'+(diag.send.successNotices?', Erfolgsmeldung erkannt':'')+').');log('Versandnachweis PASS ('+diag.send.ackMode+').');await saveOnce(page,row.ticketId,journal);await verifySaved(page,row.ticketId,entry.description);journal?.set(row.ticketId,'COMPLETE');log('Ticket speichern PASS ('+diag.save.verification+').');
 diag.loop.processed++;if(scope==='IN_BEARBEITUNG')diag.loop.myTasksProcessed++;else diag.loop.queueProcessed++;diag.loop.processedTickets.push({source:scope,sendAck:diag.send.ackMode,save:diag.save.verification,sourceRowCount:entry.rowCount,descriptionLineCount:entry.descriptionLines.length,lookupMethod:resolved.method,nameSource:diag.personSource,readProbes:diag.nameDiscovery?.checked??0,fixedFieldActionCount:diag.fixedFieldResolution?.length??0});
}
async function diagnostic(cfg){fs.mkdirSync(cfg.diagnosticDirectory,{recursive:true});plainPath(cfg.diagnosticDirectory);const raw=JSON.stringify(diag,null,2)+'\n',manifest=JSON.stringify({schema:'MCR_DIAGNOSTIC_MANIFEST_V1',payload:[{path:'diagnostic.json',sha256:sha256(raw)}]},null,2)+'\n';const file=path.join(cfg.diagnosticDirectory,'MCR_LOCAL_RUNNER_'+stamp()+'_UPLOAD.zip');const bytes=writeZip([{name:'diagnostic.json',data:raw},{name:'manifest.json',data:manifest}]);fs.writeFileSync(file,bytes,{flag:'wx'});writeJSON(path.join(cfg.diagnosticDirectory,'last-result.json'),diag);log('Diagnose: '+file);log('Diagnose-ZIP-SHA256: '+sha256(bytes));}
async function main(){let cfg=null,browser=null,cdp=null,rl=null;try{
 log('\n==============================================================\n MCR DATENBRUECKE '+VERSION+' | '+(DEMO?'FIKTIVE DEMO - KEIN ECHTVERSAND':PILOT?'BEAUFSICHTIGTER EINZELTICKET-PILOT':'ECHTER TICKETLAUF')+'\n==============================================================');need(Number.isInteger(MAX)&&MAX>=1&&MAX<=100,'TICKET_LIMIT','Limit muss 1 bis 100 sein.');cfg=resolveConfig(root);if(DEMO){const sandbox=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-Fiktiv-Profil-'));cfg.runtimeDirectory=sandbox;cfg.profileDirectory=path.join(sandbox,'edge-profile');cfg.downloadDirectory=path.join(sandbox,'downloads');}let mapping,journal=null;
 if(DEMO){const f=readJSON(path.join(root,'examples/DEMO_mapping.json'),65536);need(f.schema==='MCR_FICTIONAL_SOURCE_V1'&&f.rows.length===2&&f.rows.every(r=>r.B==='99900001'),'DEMO_SOURCE','Fiktive Quelle fehlt.');const map=makeMultirowMapping({meta:f.source,allRows:()=>f.rows},{mode:'DEMO',headerConfirmed:true,generatedAt:'2026-01-01T00:00:00.000Z'});need(lookupMultirow(map,'99900001').description===f.expectedDescription,'DEMO_SEMANTICS','Fiktive Beschreibung abweichend.');mapping={map,fileHash:map.payloadSha256};diag.demoExpectedDescriptionSha256=sha256(f.expectedDescription);}
 else{verifySession(root,process.env.MCR_SESSION_TOKEN);mapping=loadActiveMapping(root);journal=ledger(root);journal.assertClear();}
 diag.mapping={loaded:true,multirow:true,explicitActive:!DEMO,fileHash:mapping.fileHash};log('Aktives Mapping geprueft. Mehrzeilen/TPP-Regeln bleiben erhalten.');fs.mkdirSync(cfg.runtimeDirectory,{recursive:true});fs.mkdirSync(cfg.downloadDirectory,{recursive:true});rl=readline.createInterface({input:process.stdin,output:process.stdout});const exe=findEdgeExecutable(cfg.edgePath);need(exe,'BROWSER_NOT_FOUND','Microsoft Edge/Chromium fehlt.');
 browser=await launchBrowser({executable:exe,userDataDir:cfg.profileDirectory,startUrl:DEMO?'about:blank':cfg.comarchUrl,headless:DEMO,extraArgs:DEMO?['--disable-background-networking','--disable-component-update','--disable-sync',...(process.platform!=='win32'&&process.getuid?.()===0?['--no-sandbox']:[])]:[]});diag.browser.launched=true;({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>DEMO?t.url==='about:blank':t.url.startsWith('https://comarchecm.mercer.com/'),DEMO?30000:180000);
 if(DEMO){await injectDemo(page,{width:Number(process.env.MCR_DEMO_WIDTH||1000),scenario:DEMO_SCENARIO});}else{log('Im eigenen Bot-Edge anmelden. Kein Ticket manuell starten; der Bot beginnt in Meine Vorgaenge.');need(/^start$/i.test(await ask(rl,'Echter Lauf, maximal '+MAX+' Ticket(s). START zum Freigeben: ')),'RUN_NOT_ARMED','Kein Lauf freigegeben.');}
 const processed=new Set(journal?.completedIds()||[]);await UI.navigateToScope(page,'IN_BEARBEITUNG');
 while(diag.loop.processed<MAX){let row=null,scope=null;for(const s of ['IN_BEARBEITUNG','WARTESCHLANGE_INTL01']){const q=await UI.navigateToScope(page,s);row=q.rows.find(r=>r.descriptionBlank&&r.source.toUpperCase()==='E-MAIL'&&!processed.has(r.ticketId));if(row){scope=s;break;}}
 if(!row){diag.loop.completed=true;diag.loop.finishReason='NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS';break;}
 await UI.openTicket(page,row);log('\n--- Ticket '+(diag.loop.processed+1)+' aus '+scope+' ---');
  // RC19: examine the authenticated, currently opened ticket BEFORE any edits.
  // A prior acknowledgement is a SKIP, not an error and NEVER a send retry.
  await UI.ensureEdit(page);await UI.assertTicket(page,row.ticketId);
  const prior=await UI.priorAcknowledgementProof(page,row.ticketId);
  if(prior.verified){
   journal?.assertClear(); // Previous tickets may have been sent; only an OPEN journal blocks the next action.
   processed.add(row.ticketId);diag.loop.skippedAlreadyAnswered++;
   const records=diag.loop.skippedTickets||(diag.loop.skippedTickets=[]);
   if(records.length<100)records.push({source:scope,reason:'SAME_TICKET_INBOUND_SENDER_AND_OUTGOING_ACK',sentAgain:false,savedByBot:false});
   log('PASS SKIP_ALREADY_ANSWERED: Im Nachrichtenverlauf ist die an den Originalabsender gerichtete Empfangsbestaetigung fuer dieses Ticket bereits vorhanden. Kein zweiter Versand. Keine Aenderung an vorhandenen Entwuerfen oder Feldern.');
   log('HINWEIS: Der Speicherstatus dieses Tickets wurde NICHT nachgewiesen. Bitte bei Bedarf separat in COMARCH pruefen. Suche naechstes unbeantwortetes Ticket.');
   await UI.navigateToScope(page,'IN_BEARBEITUNG');await sleep(250);continue;
  }
  await processTicket(page,mapping,rl,row,scope,cfg,journal);processed.add(row.ticketId);await sleep(400);
 }
 if(diag.loop.processed===MAX){diag.loop.completed=true;diag.loop.finishReason=PILOT?(diag.loop.forwarded?'PILOT_LIMIT_AFTER_VERIFIED_FORWARD':'PILOT_LIMIT_AFTER_VERIFIED_SAVE'):'LIMIT_AFTER_VERIFIED_ACTION';}
 if(DEMO){const b=await page.eval('window.__mcrMultirowDemo');diag.demoBrowser={sendClicks:b.sendClicks,saveClicks:b.saveClicks,forwardClicks:b.forwardClicks||0,savedLineCounts:b.savedLineCounts,trustedSends:b.trustedSends,trustedSaves:b.trustedSaves,trustedForwards:b.trustedForwards||[],okClicks:b.okClicks,trustedOkClicks:b.trustedOkClicks,savedDescriptionsMatch:b.savedDescriptions.every(s=>sha256(s)===diag.demoExpectedDescriptionSha256),savedMissingDescriptionsMatch:b.savedDescriptions.every(s=>s===NOT_FOUND_DESCRIPTION),fixedCommitSteps:b.fixedCommitSteps||[],fixedOptionClicks:b.fixedOptionClicks||{},selectedSubcategoryLabels:b.selectedSubcategoryLabels||[]};
   if(DEMO_SCENARIO==='rc18-existing-ack')need(diag.loop.processed===0&&diag.loop.skippedAlreadyAnswered===2&&b.sendClicks===0&&b.saveClicks===0,'DEMO_SKIP_NOT_VERIFIED','Beantwortete Tickets nicht sicher uebersprungen.');
   else if(['rc19-first-answered','rc19-last-answered'].includes(DEMO_SCENARIO))need(diag.loop.processed===1&&diag.loop.skippedAlreadyAnswered===1&&b.sendClicks===1&&b.saveClicks===1&&b.trustedSends.every(Boolean)&&b.trustedSaves.every(Boolean),'DEMO_SKIP_NEXT_NOT_VERIFIED','Nach dem uebersprungenen Ticket wurde das naechste nicht einmalig abgeschlossen.');
   else if(DEMO_SCENARIO==='missing-member')need(diag.loop.processed===2&&diag.loop.forwarded===2&&b.sendClicks===0&&b.saveClicks===2&&b.forwardClicks===2&&b.trustedForwards.every(Boolean)&&diag.demoBrowser.savedMissingDescriptionsMatch,'DEMO_FORWARD_NOT_VERIFIED','Fiktive Weiterleitung ohne E-Mail nicht nachgewiesen.');
   else need(diag.loop.processed===2&&b.sendClicks===2&&b.saveClicks===2&&b.savedLineCounts.length===2&&b.savedLineCounts.every(n=>n===2)&&b.trustedSends.every(Boolean)&&b.trustedSaves.every(Boolean)&&diag.demoBrowser.savedDescriptionsMatch,'DEMO_NOT_VERIFIED','Zwei fiktive Tickets mit echten Browserklicks nicht nachgewiesen.');}
 log('\nRUN COMPLETE | Bearbeitet: '+diag.loop.processed+' | '+diag.loop.finishReason);if(DEMO)log(DEMO_SCENARIO==='missing-member'?'PASS OFFLINE_DEMO_2_FORWARDINGS_NO_EMAIL':DEMO_SCENARIO==='rc18-existing-ack'?'PASS OFFLINE_DEMO_ALREADY_ANSWERED_SKIP':['rc19-first-answered','rc19-last-answered'].includes(DEMO_SCENARIO)?'PASS OFFLINE_DEMO_SKIP_ONE_THEN_SEND_ONE':'PASS OFFLINE_DEMO_2_TICKETS_VERIFIED');
 }catch(e){diag.lastError=/^[A-Z0-9_]{1,80}$/.test(e.code||'')?e.code:'RUNNER_ERROR';console.error('\nSTOP '+diag.lastError+' [PHASE '+diag.phase+']: '+e.message);process.exitCode=1;}finally{if(cfg)try{await diagnostic(cfg);}catch(e){console.error('STOP DIAGNOSTIC_WRITE_FAILED');process.exitCode=1;}try{rl?.close();}catch{}try{cdp?.close();}catch{}if(DEMO||args.has('--close-browser'))try{browser?.child?.kill();}catch{}}
}
await main();
