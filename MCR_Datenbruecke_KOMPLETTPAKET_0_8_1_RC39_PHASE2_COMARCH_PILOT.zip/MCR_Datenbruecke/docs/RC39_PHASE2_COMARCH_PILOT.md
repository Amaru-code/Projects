# RC39 – Phase 2: Beaufsichtigter Kontoauszug-Bearbeitungspilot

## Zweck und Grenzen

Menü 12 ist ein **separater** Einzelticket-Pilot für bereits in Menü 11 überprüfte DC-/PP+-PDFs. Es gibt **keine** E-Mail-Versandfunktion und es wird **kein** vorhandener Kontoauszug-Generator automatisch gestartet. Die Funktionen von Phase 1 (Menüs 3/4) und die Versandjournale bleiben unverändert.

Es wird nur gearbeitet, wenn ein aktueller Menü-9-Inventurbeleg, ein zugehöriger Menü-11-PDF-Beleg, die unveränderten PDF-Prüfsummen und der unveränderte aktuelle COMARCH-Tickettext zusammenpassen. Ticket und COMARCH-Member müssen eindeutig gebunden sein. MercerID und WWID werden **nicht** gleichgesetzt.

## Schritte im beaufsichtigten Einzelpilot

1. Ticket in **Meine Vorgänge** öffnen und Identität, drei Originalzeilen sowie die beiden WWID-Dateien prüfen.
2. Exakte Anfrageart `Anfrage Member` setzen. Falls der Anhangsbereich im ICEfaces-Formular noch nicht angezeigt wird, kann der Operator ihn manuell öffnen; ein zweites Sendefenster darf nicht verwendet werden.
3. Nur Dateien aus den beiden festgelegten `Ausgabe_PDF`-Ordnern via Chromium-Dateiinput `emailAttachmentFileUpload` wählen. Ein Upload wird **nicht** anhand des Datei-Eingabefelds selbst als bestätigt gewertet. Beide Namen müssen im COMARCH-Anhangsbereich erscheinen.
4. Die Originalbeschreibung **anhängend** um `Bearbeitet not reviewed` erweitern, vor dem Speichern erneut prüfen, danach je **einmal** `Entwurf speichern` und `Ticket speichern`. Der Tickettext wird aus der erneut geöffneten Vorgangsliste geprüft.
5. Erst wenn die PDFs nach **erneutem Öffnen** noch im Ticket sichtbar sind, den Prüfungsworkflow `FORWARD_TO_REVIEW` und `Baindl Mark (mark.baindl)` auswählen. Der finale Klick `Schritt ausführen` erfordert das ausdrückliche Terminalwort `WEITERLEITEN`. Eine neue Erfolgsmeldung **und** das Verschwinden des Tickets aus „Meine Vorgänge“ sind Pflichtnachweise.

## Wiederanlauf und Sicherheit

Der lokale Phase-2-Schreibjournalstand wird **vor** jedem mutierenden Schritt unter `.runtime/phase2/actions/MCR_PHASE2_<Ticket-ID>.json` festgehalten. Ein unklarer Speicherklick, Upload oder Weiterleitungsklick wird **nicht** automatisch wiederholt. Menü 5 ist für Phase-1-Versandjournale bestimmt und erklärt Phase-2-Nebenwirkungen **nicht** automatisch für erledigt. Nach Fehlern den Phase-2-Journalstatus und COMARCH manuell prüfen und nicht blind erneut Menü 12 starten.

Ohne sichtbaren Anhangsbereich oder ohne eindeutig verifizierbare Speicherung endet der Pilot vor der Weiterleitung. Die COMARCH-HTML-Struktur bei echten Ticketanhängen und bei `Schritt ausführen` kann von der fiktiven Browserumgebung abweichen. Ein tatsächlicher Windows-/COMARCH-Test ist noch notwendig; die Tests gegen Chromium-Fakes allein beweisen keine produktive Wirkung.
