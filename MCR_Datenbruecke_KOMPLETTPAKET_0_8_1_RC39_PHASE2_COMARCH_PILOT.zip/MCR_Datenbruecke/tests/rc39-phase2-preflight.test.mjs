import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {inspectExistingStatements} from '../lib/phase2-pdf-evidence.mjs';
import {preflightPhase2Write} from '../src/phase2-comarch-pilot.mjs';
import {phase2Inventory} from '../lib/phase2-readonly.mjs';
import {writeJSON} from '../lib/control.mjs';
const validId='87278094',wwid='11368989',desc='USC 20/ DC;PP+\nStandardantwort versendet\nMöchte Kontoauszug';
test('RC39 Phase2 requires current inventory, signed content review, unchanged WWID files, no duplicate action',()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC39-PREFLIGHT-'));const root=path.join(dir,'MCR_Datenbruecke');
 try{
  const base=path.join(root,'.runtime','phase2');fs.mkdirSync(base,{recursive:true});
  for(const [plan,folder] of [['DC','Kontoauszug DC'],['PP+','Kontoauszug_pp+']]){
   const dest=path.join(dir,folder,'Ausgabe_PDF');fs.mkdirSync(dest,{recursive:true});
   fs.writeFileSync(path.join(dest,wwid+'_Kontoauszug_'+plan+'.pdf'),'%PDF-1.4\n'+(' '.repeat(200))+'\n%%EOF\n');
  }
  const inv=phase2Inventory([{ticketId:validId,source:'POST',descriptionValue:desc}]);
  writeJSON(path.join(base,'MCR_PHASE2_LETZTE_INVENTUR.json'),inv);
  const raw=inspectExistingStatements(root,['DC','PP+'],wwid);
  const proof={...raw,ticketId:validId,operatorContentReviewed:true,operatorPersonTicketBindingReviewed:true};
  writeJSON(path.join(base,'MCR_PHASE2_PDF_BELEG_'+validId+'_2026-10-29T15-04-26-131Z.json'),proof);
  const ready=preflightPhase2Write(root,validId);
  assert.equal(ready.item.source,'POST');assert.deepEqual(ready.preview.expectedDocuments,['DC','PP+']);
  assert.equal(ready.preview.descriptionAfter,desc+'\nBearbeitet not reviewed');
  assert.equal(ready.journal.begin().state,'PREPARED');
  assert.throws(()=>preflightPhase2Write(root,validId),e=>e.code==='P2_ALREADY_ATTEMPTED');
  fs.rmSync(ready.journal.file);
  fs.writeFileSync(raw.artifacts[0].file,'%PDF-1.4\nTAMPERED\n%%EOF');
  assert.throws(()=>preflightPhase2Write(root,validId),e=>e.code==='P2_PDF_CHANGED'||e.code==='P2_PDF_SIZE');
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
