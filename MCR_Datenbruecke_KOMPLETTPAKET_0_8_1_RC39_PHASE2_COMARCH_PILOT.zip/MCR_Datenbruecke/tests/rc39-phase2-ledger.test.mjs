import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {phase2Journal,digestDescription} from '../lib/phase2-write-journal.mjs';
test('RC39 Phase2 upload/save/forward journal is write-ahead and irreversible without review',()=>{
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC39-JOURNAL-'));
 try{
  fs.mkdirSync(path.join(root,'.runtime/phase2'),{recursive:true});
  const initial={ticketId:'87278094',descriptionSha256:digestDescription('USC 20/ DC;PP+\nStandardantwort versendet\nMöchte Kontoauszug'),pdfHashes:[{plan:'DC',sha256:'1'.repeat(64)}]};
  const j=phase2Journal(root,'87278094',{initial});assert.equal(j.read(),null);
  assert.equal(j.begin().state,'PREPARED');
  assert.throws(()=>j.begin(),e=>e.code==='P2_PENDING_OR_COMPLETE');
  assert.equal(j.advance('GEVO_INTENT').state,'GEVO_INTENT');
  assert.throws(()=>j.advance('GEVO_INTENT'),e=>e.code==='P2_JOURNAL_TRANSITION');
  assert.equal(phase2Journal(root,'87278094').read().state,'GEVO_INTENT');
  const stages=['GEVO_VERIFIED','UPLOAD_INTENT','UPLOAD_VERIFIED','DESCRIPTION_INTENT','DESCRIPTION_VERIFIED',
   'DRAFT_SAVE_INTENT','DRAFT_SAVE_VERIFIED','TICKET_SAVE_INTENT','TICKET_SAVE_VERIFIED',
   'REVIEW_INTENT','REVIEW_VERIFIED','EXECUTE_INTENT','ROUTED_VERIFIED'];
  for(const stage of stages)j.advance(stage);
  assert.equal(j.read().state,'ROUTED_VERIFIED');
  assert.throws(()=>j.advance('EXECUTE_INTENT'),e=>e.code==='P2_JOURNAL_TRANSITION');
  assert.equal(j.read().events.length,stages.length+2);
 }finally{fs.rmSync(root,{recursive:true,force:true});}
});
