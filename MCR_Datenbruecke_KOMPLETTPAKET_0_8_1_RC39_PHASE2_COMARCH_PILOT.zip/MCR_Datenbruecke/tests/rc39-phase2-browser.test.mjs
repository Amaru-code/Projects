import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
import {phase2FieldSnapshot,uploadControl,attachLocalFiles,observedAttachments,setPhase2Gevo,selectReviewMode,
 selectReviewAssignee,reviewAssignmentState,savePhase2Draft,savePhase2Ticket,executeReview} from '../lib/phase2-comarch-actions.mjs';
import {forwardingNotices,forwardConfirmed} from '../lib/forwarding.mjs';
test('RC39 real Chromium native PDF file chooser, distinct draft/ticket and review click, no email SEND',{timeout:70000},async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC39-'));
 const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-P2-DOM-'));let browser,cdp;
 try{
  const a=path.join(dir,'11368989_Kontoauszug_DC.pdf'),b=path.join(dir,'11368989_Kontoauszug_PP+.pdf');
  const fake='%PDF-1.4\n'+('0'.repeat(220))+'\n%%EOF\n';fs.writeFileSync(a,fake);fs.writeFileSync(b,fake);
  browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,
   extraArgs:['--disable-background-networking','--disable-sync',...(process.platform!=='win32'&&process.getuid?.()===0?['--no-sandbox']:[])]});
  ({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.url==='about:blank');
  await page.call(function(){document.body.innerHTML=`<div id="ticket">Ticket-ID: 87278094</div>
    <input id="mainForm:gevo-value-id" value="Anfrage Member"/><input id="emailAttachmentFileUpload" name="files[]" type="file" multiple/>
    <ul id="uploaded"></ul><a id="draft" href="#">Entwurf speichern</a><a id="ticketSave" href="#">Ticket speichern</a>
    <select id="review"><option value="">Bitte wählen</option><option value="FORWARD_TO_REVIEW">Weiterleiten zur Überprüfung</option></select>
    <input id="mainForm:next-persona-assignment-id" value="Baindl Mark (mark.baindl)"/>
    <input type="submit" id="run" value="Schritt ausführen"/><div id="msgs" role="status"></div>`;
   window.clicks={draft:0,save:0,execute:0,send:0};
   document.getElementById('emailAttachmentFileUpload').addEventListener('change',e=>{
    const u=document.getElementById('uploaded');u.innerHTML='';for(const file of e.target.files){const li=document.createElement('li');li.textContent=file.name;u.appendChild(li);}
   });
   document.getElementById('draft').addEventListener('click',e=>{e.preventDefault();window.clicks.draft++});
   document.getElementById('ticketSave').addEventListener('click',e=>{e.preventDefault();window.clicks.save++});
   document.getElementById('run').addEventListener('click',e=>{e.preventDefault();window.clicks.execute++;document.getElementById('msgs').textContent='Erfolgreich weitergeleitet zur Überprüfung';});
  });
  assert.equal((await phase2FieldSnapshot(page)).upload.count,1);
  assert.equal((await setPhase2Gevo(page)).ok,true);
  assert.equal((await uploadControl(page)).multiple,true);
  const pre=await forwardingNotices(page);
  await attachLocalFiles(page,[a,b]);
  let r;for(let i=0;i<15;i++){r=await observedAttachments(page,[path.basename(a),path.basename(b)]);if(r.present.every(Boolean))break;await new Promise(x=>setTimeout(x,100));}
  assert.deepEqual(r.present,[true,true]);
  await savePhase2Draft(page);await savePhase2Ticket(page);
  await selectReviewMode(page);assert.equal((await selectReviewAssignee(page)).ok,true);
  assert.equal((await reviewAssignmentState(page)).ok,true);
  await executeReview(page);
  const proof=await forwardConfirmed(page,{display:'Baindl Mark',account:'mark.baindl'},pre);
  assert.equal(proof.ok,true);
  assert.deepEqual(await page.eval('window.clicks'),{draft:1,save:1,execute:1,send:0});
  console.log('PASS RC39_NATIVE_FILES_TWO_SAVES_ONE_REVIEW_ZERO_EMAIL');
 }finally{try{await cleanupTemporaryTestBrowser({profile,browser,cdp});}finally{fs.rmSync(dir,{recursive:true,force:true,maxRetries:7,retryDelay:150});}}
});
