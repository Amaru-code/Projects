import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import fs from 'node:fs';
const require=createRequire(import.meta.url);
const MailDownload=require('../lib/mail-download.cjs');

test('one visible download is selected',()=>{
 const r=MailDownload.chooseBottommost([{x:20,y:100,width:12,height:12,order:0}]);
 assert.equal(r.y,100);assert.equal(r.policy,'BOTTOMMOST_VISIBLE_MESSAGE_ROW');
});

test('bottom-most message row wins',()=>{
 const r=MailDownload.chooseBottommost([
  {x:20,y:100,width:12,height:12,order:0},
  {x:20,y:160,width:12,height:12,order:1}
 ]);
 assert.equal(r.y,160);assert.equal(r.candidateCount,2);
});

test('left-most control wins inside bottom row',()=>{
 const r=MailDownload.chooseBottommost([
  {x:20,y:100,width:12,height:12,order:0},
  {x:540,y:160,width:12,height:12,order:2},
  {x:22,y:163,width:12,height:12,order:1}
 ]);
 assert.equal(r.x,22);assert.equal(r.bottomRowCount,2);
});

test('invalid geometry is ignored',()=>{
 const r=MailDownload.chooseBottommost([{x:1,y:Number.NaN,width:1,height:1},{x:5,y:20,width:1,height:1}]);
 assert.equal(r.x,5);
});

test('local runner source declares 0.5.3 history-DOM mail, real member focus and dependency reactivation',()=>{
 const s=fs.readFileSync(new URL('../src/local-bot.mjs',import.meta.url),'utf8');
 assert.match(s,/version:'0\.5\.3'/);
 assert.ok(s.includes('NO_DOWNLOAD_HISTORY_DOM'));
 assert.ok(s.includes('historyMailSnapshots'));
 assert.ok(s.includes('choosePersonFromHistory'));
 assert.ok(s.includes('fetchMailInPage')); // fallback remains
 assert.ok(s.includes('primeMemberField'));
 assert.ok(s.includes('category-sub-value-id'));
 assert.ok(s.includes('GEOMETRIC_LABEL_NEAREST'));
 assert.ok(s.includes('verifyDescription'));
 assert.ok(s.includes("MailDownload.chooseBottommost"));
});

test('0.5.3 fallback mail fetch remains same-origin browser-side and bounded',()=>{
 const s=fs.readFileSync(new URL('../src/local-bot.mjs',import.meta.url),'utf8');
 assert.ok(s.includes("fetch(target,{credentials:'same-origin'"));
 assert.ok(s.includes("u.origin!==a.ownerDocument.location.origin"));
 assert.ok(s.includes('24*1024*1024'));
 assert.ok(!s.includes('Network.getAllCookies'));
});

test('0.5.3 member search primes the real field before setting the query',()=>{
 const s=fs.readFileSync(new URL('../src/local-bot.mjs',import.meta.url),'utf8');
 const a=s.indexOf('async function setMemberSearch');
 const b=s.indexOf('async function memberSuggestions',a);
 const block=s.slice(a,b);
 assert.ok(block.includes('await primeMemberField(page)'));
 assert.ok(block.includes("KeyboardEvent('keyup'"));
});


test('0.5.3 re-clicks real member field immediately before dependent subcategory',()=>{
 const s=fs.readFileSync(new URL('../src/local-bot.mjs',import.meta.url),'utf8');
 const a=s.indexOf('async function prepareFixed');
 const b=s.indexOf('async function editorWrite',a);
 const block=s.slice(a,b);
 const category=block.indexOf('Dokumentenkategorie');
 const reprime=block.indexOf('await primeMemberField(page)',category);
 const sub=block.indexOf('Unterkategorie',reprime);
 assert.ok(category>=0&&reprime>category&&sub>reprime);
 assert.ok(block.includes("setSuggestExact(page,'mainForm:category-sub-value-id'"));
});

test('0.5.3 normal path can use visible history without a msg download',()=>{
 const s=fs.readFileSync(new URL('../src/local-bot.mjs',import.meta.url),'utf8');
 const history=s.indexOf('const historyChoice=await choosePersonFromHistory');
 const fallback=s.indexOf('downloadCurrentMail(page,cfg,rl)',history);
 assert.ok(history>=0&&fallback>history);
 assert.ok(s.includes("diag.mail.source='HISTORY_DOM'"));
});
