import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import http from 'node:http';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
import readline from 'node:readline/promises';
import {stdin as input, stdout as output} from 'node:process';
import {findEdgeExecutable, launchBrowser, connectBrowser, attachPage, sleep} from '../lib/cdp.mjs';
import {sha256} from '../lib/core.mjs';
import {writeZip} from '../lib/zip.mjs';

const require = createRequire(import.meta.url);
const Core = require('../lib/data-core.cjs');
const Msg = require('../lib/msg.cjs');
const Person = require('../lib/person.cjs');
const Prep = require('../lib/ticket-prep.cjs');
const MailDownload = require('../lib/mail-download.cjs');
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

const argv = new Set(process.argv.slice(2));
const DEMO = argv.has('--demo');
const AUTO = argv.has('--auto');
const HEADLESS = argv.has('--headless');
const KEEP_BROWSER = !argv.has('--close-browser');

const diag = {
  schema:'MCR_LOCAL_RUNNER_DIAGNOSTIC_V1', version:'0.5.3', createdAt:new Date().toISOString(),
  mode: DEMO?'DEMO':'REAL', mapping:{loaded:false,sourceConfirmed:false}, browser:{launched:false,connected:false,comarchReady:false},
  mail:{downloaded:false,parsed:false,personAuto:false,personManual:false,downloadPolicy:null,downloadCandidates:0,downloadAutoClicked:false,downloadFallbackManual:false,directFetch:false,historyRows:0,source:null,historyContentUsed:false}, member:{searchStarted:false,autoClicked:false,manualGate:false,selected:false},
  lookup:{attempted:false,ready:false}, description:{written:false,verified:false,route:null,candidates:null}, fixed:{responsibility:false,category:false,subcategory:false,signature:false},
  reply:{generated:false,written:false,verified:false}, readyBeforeSend:false, automaticSend:false, automaticSave:false, lastError:null,
  privacy:'No names, IDs, email addresses, mail text, mapping values, paths, URLs, selectors, cookies or page content.'
};

function log(s=''){console.log(s);}
function heading(s){console.log('\n==============================================================\n '+s+'\n==============================================================');}
function fail(code,message){const e=new Error(message);e.code=code;throw e;}
function need(ok,code,message){if(!ok)fail(code,message);}
function clean(v){return String(v??'').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();}
function norm(v){return clean(v).toLocaleLowerCase('de-DE').replace(/[.,]/g,'').replace(/\s+/g,' ');}
function escHtml(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
function nowStamp(){return new Date().toISOString().replace(/[:.]/g,'-');}

function readJson(p){return JSON.parse(fs.readFileSync(p,'utf8'));}
function resolveConfig(){
  const p = path.join(root,'config','local-runner.json');
  const cfg = fs.existsSync(p)?readJson(p):{};
  const localRel = v => String(v).split(/[\\/]+/).join(path.sep);
  const runtime = path.resolve(root, localRel(cfg.runtimeDirectory || '.runtime'));
  return {
    ...cfg,
    runtimeDirectory:runtime,
    profileDirectory:path.resolve(root,localRel(cfg.profileDirectory || path.join('.runtime','edge-profile'))),
    downloadDirectory:path.resolve(root,localRel(cfg.downloadDirectory || path.join('.runtime','downloads'))),
    diagnosticDirectory:path.resolve(root,localRel(cfg.diagnosticDirectory || 'diagnostics')),
    comarchUrl:cfg.comarchUrl || 'https://comarchecm.mercer.com/DMSWWW/main.jspx'
  };
}

function validateMappingObject(obj){
  Core.validateMap(obj);
  need(sha256(JSON.stringify(obj.payload))===obj.payloadSha256,'MAP_HASH_MISMATCH','Mapping-Payload-Prüfsumme stimmt nicht.');
  return obj;
}
function autoMapping(cfg){
  if (DEMO) return {path:path.join(root,'examples','DEMO_mapping.json'),map:validateMappingObject(readJson(path.join(root,'examples','DEMO_mapping.json')))};
  const candidates=[];
  if(cfg.mappingPath) candidates.push(cfg.mappingPath);
  const dirs=[cfg.mappingDirectory, path.join(root,'private_data')].filter(Boolean);
  for(const d of dirs){
    if(!fs.existsSync(d))continue;
    for(const name of fs.readdirSync(d))if(/^INTL01_mapping_.*\.json$/i.test(name)){
      const p=path.join(d,name);try{candidates.push(p);}catch{}
    }
  }
  const unique=[...new Set(candidates.map(p=>path.resolve(p)))].filter(fs.existsSync).sort((a,b)=>{
    if(cfg.mappingPath && path.resolve(cfg.mappingPath)===a)return -1;if(cfg.mappingPath&&path.resolve(cfg.mappingPath)===b)return 1;
    return fs.statSync(b).mtimeMs-fs.statSync(a).mtimeMs;
  });
  for(const p of unique){try{return {path:p,map:validateMappingObject(readJson(p))};}catch(e){log('Mapping übersprungen: '+path.basename(p)+' ('+(e.code||e.message)+')');}}
  fail('MAP_NOT_FOUND','Kein gültiges INTL01-Mapping gefunden. config/local-runner.json oder private_data prüfen.');
}

function docsHelper(){
  const out=[];function walk(doc,depth){if(!doc||depth>6||out.length>=40||out.includes(doc))return;out.push(doc);for(const f of doc.querySelectorAll('iframe,frame'))try{walk(f.contentDocument,depth+1)}catch{}}walk(document,0);return out;
}
function visibleHelper(n){try{return !!n?.isConnected&&n.getClientRects().length>0&&getComputedStyle(n).visibility!=='hidden'&&getComputedStyle(n).display!=='none'}catch{return false}}

async function pageHost(page){return await page.eval('location.hostname');}
async function waitComarch(page){
  if(DEMO)return;
  log('\nEdge wurde als eigener MCR-Browser gestartet.');
  log('Falls nötig: dort anmelden. Öffne anschließend EIN Ticket. Der Runner wartet automatisch.');
  const deadline=Date.now()+180000;
  while(Date.now()<deadline){
    const host=await pageHost(page).catch(()=>null);
    if(host==='comarchecm.mercer.com'){diag.browser.comarchReady=true;return;}
    await sleep(500);
  }
  fail('COMARCH_LOGIN_TIMEOUT','COMARCH wurde im Runner-Browser nicht innerhalb von 3 Minuten erreicht.');
}

async function ensureEditMode(page){
  const state=await page.call(function(){
    const docs=(()=>{const out=[];function walk(doc,d){if(!doc||d>5||out.includes(doc))return;out.push(doc);for(const f of doc.querySelectorAll('iframe,frame'))try{walk(f.contentDocument,d+1)}catch{}}walk(document,0);return out})();
    const vis=n=>{try{return n?.isConnected&&n.getClientRects().length>0&&n.ownerDocument.defaultView.getComputedStyle(n).display!=='none'&&n.ownerDocument.defaultView.getComputedStyle(n).visibility!=='hidden'}catch{return false}};
    const member=docs.flatMap(d=>[...d.querySelectorAll('input[id="mainForm:member-value-id"]')]).find(vis);
    if(member&&!member.disabled&&!member.readOnly)return {mode:'EDIT'};
    const buttons=docs.flatMap(d=>[...d.querySelectorAll('input,button,a')]).filter(n=>vis(n)&&String(n.value??n.textContent??'').trim()==='Bearbeiten');
    if(buttons.length===1){const r=buttons[0].getBoundingClientRect();return {mode:'BUTTON',x:r.left+r.width/2,y:r.top+r.height/2};}
    return {mode:'WAIT'};
  });
  if(state.mode==='EDIT')return;
  if(state.mode==='BUTTON'){log('„Bearbeiten“ gefunden → wird geöffnet.');await page.mouseClick(state.x,state.y);}
  log('Warte auf bearbeitbares Member-Feld ...');
  await page.waitFor(function(){
    const docs=[];(function walk(doc,d){if(!doc||d>5||docs.includes(doc))return;docs.push(doc);for(const f of doc.querySelectorAll('iframe,frame'))try{walk(f.contentDocument,d+1)}catch{}})(document,0);
    return docs.some(d=>{const n=d.getElementById('mainForm:member-value-id');return n&&!n.disabled&&!n.readOnly&&n.getClientRects().length>0;});
  },{timeoutMs:90000,description:'Bearbeitungsmodus'});
}

async function currentHistoryMail(page){return await page.call(function(){
  const docs=[];(function walk(doc,d){if(!doc||d>6||docs.includes(doc))return;docs.push(doc);for(const f of doc.querySelectorAll('iframe,frame'))try{walk(f.contentDocument,d+1)}catch{}})(document,0);
  const vis=n=>{try{const w=n.ownerDocument.defaultView,s=w.getComputedStyle(n);return n.isConnected&&n.getClientRects().length>0&&s.display!=='none'&&s.visibility!=='hidden'}catch{return false}};
  const norm=v=>String(v??'').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim().toLocaleLowerCase('de-DE');
  const tables=[];
  for(const doc of docs)for(const table of doc.querySelectorAll('table')){
    if(!vis(table))continue;
    const headers=[...table.querySelectorAll('thead th,thead label,thead span')].map(n=>norm(n.textContent)).filter(Boolean);
    const required=['original','von','an','betreff','inhalt','datum'];
    if(required.every(x=>headers.includes(x)))tables.push(table);
  }
  if(tables.length!==1)return {ok:false,state:tables.length?'AMBIGUOUS_HISTORY':'NO_HISTORY',tableCount:tables.length,rowCount:0};
  const table=tables[0],body=table.tBodies?.[0];if(!body)return {ok:false,state:'NO_TBODY',tableCount:1,rowCount:0};
  const rows=[...body.rows].filter(r=>vis(r)&&r.querySelector('a[href*="GetFile?docId="]'));
  if(!rows.length)return {ok:false,state:'NO_MESSAGE_ROWS',tableCount:1,rowCount:0};
  const row=rows[rows.length-1],links=[...row.querySelectorAll('a[href*="GetFile?docId="]')].filter(vis);
  if(links.length!==1)return {ok:false,state:links.length?'AMBIGUOUS_DOWNLOAD':'NO_DOWNLOAD',tableCount:1,rowCount:rows.length,linkCount:links.length};
  const a=links[0],u=new URL(a.getAttribute('href'),a.ownerDocument.baseURI),m=u.searchParams.get('docId'),demoDoc=['about:','file:'].includes(a.ownerDocument.location.protocol);
  if(!demoDoc&&(u.origin!==a.ownerDocument.location.origin||!/(?:^|\/)GetFile\/?$/i.test(u.pathname)||!/^\d{1,15}$/.test(m??'')))return {ok:false,state:'UNSAFE_DOWNLOAD_LINK',tableCount:1,rowCount:rows.length};
  return {ok:true,state:'BOTTOM_DOM_ROW',href:u.href,rowCount:rows.length,docId:/^\d{1,15}$/.test(m??'')?m:null};
});}


async function historyMailSnapshots(page){return await page.call(function(){
  const docs=[];(function walk(doc,d){if(!doc||d>6||docs.includes(doc))return;docs.push(doc);for(const f of doc.querySelectorAll('iframe,frame'))try{walk(f.contentDocument,d+1)}catch{}})(document,0);
  const vis=n=>{try{const w=n.ownerDocument.defaultView,s=w.getComputedStyle(n);return n.isConnected&&n.getClientRects().length>0&&s.display!=='none'&&s.visibility!=='hidden'}catch{return false}};
  const norm=v=>String(v??'').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim().toLocaleLowerCase('de-DE');
  const tables=[];
  for(const doc of docs)for(const table of doc.querySelectorAll('table')){
    if(!vis(table))continue;
    const headers=[...table.querySelectorAll('thead th,thead label,thead span')].map(n=>norm(n.textContent)).filter(Boolean);
    const required=['original','von','an','betreff','inhalt','datum'];
    if(required.every(x=>headers.includes(x)))tables.push(table);
  }
  if(tables.length!==1)return {ok:false,state:tables.length?'AMBIGUOUS_HISTORY':'NO_HISTORY',rows:[]};
  const table=tables[0],body=table.tBodies?.[0];if(!body)return {ok:false,state:'NO_TBODY',rows:[]};
  const rows=[...body.rows].filter(r=>vis(r)&&r.querySelector('a[href*="GetFile?docId="]'));
  const data=rows.map((row,index)=>{
    const cells=[...row.cells],txt=i=>String(cells[i]?.textContent??cells[i]?.innerText??'').replace(/\u00a0/g,' ').replace(/\r\n?/g,'\n').trim();
    const a=row.querySelector('a[href*="GetFile?docId="]');let href=null,docId=null;
    try{const u=new URL(a?.getAttribute('href')??'',row.ownerDocument.baseURI);href=u.href;const v=u.searchParams.get('docId');if(/^\d{1,15}$/.test(v??''))docId=v;}catch{}
    return {index,sender:txt(1),recipient:txt(2),subject:txt(3),content:txt(4),date:txt(5),href,docId};
  }).reverse();
  return {ok:data.length>0,state:data.length?'READY':'NO_MESSAGE_ROWS',rows:data};
});}

async function choosePersonFromHistory(page,rl){
  const snapshot=await historyMailSnapshots(page);
  if(!snapshot.ok||!snapshot.rows.length)return null;
  diag.mail.historyRows=snapshot.rows.length;diag.mail.source='HISTORY_DOM';diag.mail.historyContentUsed=true;diag.mail.downloadPolicy='NO_DOWNLOAD_HISTORY_DOM';
  let fallback=null;
  for(const row of snapshot.rows){
    const mail={format:'COMARCH_HISTORY',subject:row.subject||'',senderName:'',senderEmail:row.sender||'',body:row.content||'',warnings:[],diagnostic:{plainText:true,attachmentsRead:false,source:'HISTORY_DOM'}};
    const cs=Person.candidates(mail);
    if(!cs.length)continue;
    if(!fallback)fallback=mail;
    if(cs.length===1){const picked=await choosePerson(mail,rl);return {mail,...picked};}
  }
  if(fallback){const picked=await choosePerson(fallback,rl);return {mail:fallback,...picked};}
  return null;
}

async function fetchMailInPage(page,url){return await page.call(async function(target){
  const response=await fetch(target,{credentials:'same-origin',cache:'no-store',redirect:'follow'});
  if(!response.ok)return {ok:false,status:response.status};
  const ab=await response.arrayBuffer();
  if(ab.byteLength<512||ab.byteLength>24*1024*1024)return {ok:false,status:response.status,size:ab.byteLength,reason:'SIZE'};
  const bytes=new Uint8Array(ab);let binary='';const chunk=0x8000;
  for(let i=0;i<bytes.length;i+=chunk)binary+=String.fromCharCode(...bytes.subarray(i,Math.min(i+chunk,bytes.length)));
  return {ok:true,status:response.status,size:bytes.length,base64:btoa(binary)};
},url);}

async function listDownloadAnchors(page){return await page.call(function(){
  const docs=[];(function walk(doc,d){if(!doc||d>6||docs.includes(doc))return;docs.push(doc);for(const f of doc.querySelectorAll('iframe,frame'))try{walk(f.contentDocument,d+1)}catch{}})(document,0);
  const vis=n=>{try{const w=n.ownerDocument.defaultView,s=w.getComputedStyle(n);return n.isConnected&&n.getClientRects().length>0&&s.display!=='none'&&s.visibility!=='hidden'}catch{return false}};
  function absoluteCenter(n){let r=n.getBoundingClientRect(),x=r.left+r.width/2,y=r.top+r.height/2,doc=n.ownerDocument,guard=0;while(doc!==document&&guard++<8){const frame=doc.defaultView?.frameElement;if(!frame)break;const fr=frame.getBoundingClientRect();x+=fr.left;y+=fr.top;doc=frame.ownerDocument;}return {x,y,width:r.width,height:r.height};}
  const rows=[];let order=0;
  for(const doc of docs)for(const a of doc.querySelectorAll('a[href]')){if(!vis(a))continue;let u;try{u=new URL(a.href,doc.baseURI)}catch{continue}if(!/GetFile/i.test(u.pathname+u.search))continue;const r=absoluteCenter(a);rows.push({...r,order:order++});}
  return rows;
});}
async function waitNewMsg(dir,since,timeoutMs=30000){
  const deadline=Date.now()+timeoutMs;
  while(Date.now()<deadline){
    if(fs.existsSync(dir)){
      const files=fs.readdirSync(dir).filter(n=>/\.msg$/i.test(n)).map(n=>{const p=path.join(dir,n);const s=fs.statSync(p);return {p,mtime:s.mtimeMs,size:s.size};}).filter(x=>x.mtime>=since-2000&&x.size>=512).sort((a,b)=>b.mtime-a.mtime);
      if(files.length)return files[0].p;
    }
    await sleep(200);
  }
  return null;
}

async function downloadCurrentMail(page, cfg, rl){
  fs.mkdirSync(cfg.downloadDirectory,{recursive:true});
  for(const n of fs.readdirSync(cfg.downloadDirectory))try{fs.rmSync(path.join(cfg.downloadDirectory,n),{recursive:true,force:true})}catch{}
  const semantic=await currentHistoryMail(page);
  if(semantic.ok){
    diag.mail.downloadCandidates=semantic.rowCount;diag.mail.historyRows=semantic.rowCount;diag.mail.downloadPolicy='BOTTOM_DOM_MESSAGE_ROW_DIRECT_FETCH';
    log(`Original-Mail: ${semantic.rowCount} Nachrichtenzeile(n) gefunden → die UNTERSTE Tabellenzeile wird direkt geladen.`);
    try{
      const fetched=await fetchMailInPage(page,semantic.href);
      if(fetched.ok){
        const name=`ticket_${semantic.docId||'mail'}_${nowStamp()}.msg`,file=path.join(cfg.downloadDirectory,name);
        fs.writeFileSync(file,Buffer.from(fetched.base64,'base64'));diag.mail.downloaded=true;diag.mail.directFetch=true;diag.mail.downloadAutoClicked=false;return file;
      }
      log('Direktes Laden der unteren Mail wurde von COMARCH/Browser nicht bestätigt. Fallback auf Browserklick.');
    }catch{log('Direktes Laden der unteren Mail nicht verfügbar. Fallback auf Browserklick.');}
  }
  const anchors=await listDownloadAnchors(page);const since=Date.now();
  diag.mail.downloadCandidates=Math.max(diag.mail.downloadCandidates,anchors.length);
  const selected=MailDownload.chooseBottommost(anchors);
  if(selected){
    diag.mail.downloadPolicy='BOTTOMMOST_VISIBLE_MESSAGE_ROW_MOUSE';diag.mail.downloadAutoClicked=true;
    if(anchors.length===1)log('Original-Mail: genau ein Download-Pfeil gefunden → echter Browserklick.');
    else log(`Original-Mail: ${anchors.length} Download-Pfeile gefunden → die UNTERSTE sichtbare Nachrichtenzeile wird angeklickt.`);
    await page.mouseClick(selected.x,selected.y);
  } else {
    diag.mail.downloadPolicy='MANUAL_FALLBACK';diag.mail.downloadFallbackManual=true;
    log('Kein Nachrichten-Downloadpfeil sicher erkannt. Bitte die unterste E-Mail im Nachrichtenverlauf manuell herunterladen.');
    if(!AUTO)await rl.question('ENTER drücken und dann den Download auslösen ... ');
  }
  let file=await waitNewMsg(cfg.downloadDirectory,since,25000);
  if(!file&&selected&&!AUTO){
    diag.mail.downloadFallbackManual=true;
    log('Automatischer Browserklick hat keinen Download geliefert. Bitte den Download-Pfeil der UNTERSTEN E-Mail einmal manuell anklicken.');
    await rl.question('ENTER drücken, nachdem du den Pfeil angeklickt hast ... ');file=await waitNewMsg(cfg.downloadDirectory,Date.now()-3000,30000);
  }
  need(file,'MAIL_DOWNLOAD','Keine neue .msg-Datei im Runner-Downloadordner gefunden.');
  diag.mail.downloaded=true;return file;
}
function choosePerson(mail, rl){
  const candidates=Person.candidates(mail);need(candidates.length,'NAME_NONE','Kein brauchbarer Namenshinweis in der MSG gefunden.');
  const analysis=Core.analyzeMail((mail.subject?'Betreff: '+mail.subject+'\n':'')+mail.body);
  const hints=Person.identifierHints(mail,analysis.idHints,candidates);
  const ids=[...new Set(hints.map(h=>h.clientId))];
  if(candidates.length===1){diag.mail.personAuto=true;return Promise.resolve({person:candidates[0],expectedId:ids.length===1?ids[0]:null});}
  // Strong local scoring: a unique name mentioned in the subject and/or address/signature wins only with clear margin.
  const subject=norm(mail.subject);const body=String(mail.body??'');
  const scored=candidates.map((c,i)=>{
    let score=0;const n1=norm(c.firstName+' '+c.lastName),n2=norm(c.lastName+' '+c.firstName);
    if(subject.includes(n1)||subject.includes(n2))score+=7;
    if(c.sources.includes('Adressblock'))score+=5;if(c.sources.includes('Beschrifteter Name'))score+=5;if(c.sources.includes('Signatur'))score+=3;if(c.sources.some(s=>/Absendername/.test(s)))score+=1;
    for(const id of ids){const re=new RegExp((c.firstName+'\\s+'+c.lastName+'|'+c.lastName+'\\s+'+c.firstName).replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'[\\s,;/]{0,8}'+id,'i');if(re.test(body)||re.test(mail.subject??''))score+=6;}
    return {i,c,score};
  }).sort((a,b)=>b.score-a.score);
  if(scored[0].score>=7&&(scored[1]?.score??-1)<=scored[0].score-3){diag.mail.personAuto=true;return Promise.resolve({person:scored[0].c,expectedId:ids.length===1?ids[0]:null});}
  if(AUTO){diag.mail.personAuto=true;return Promise.resolve({person:scored[0].c,expectedId:ids.length===1?ids[0]:null});}
  log('\nMehrere Namenshinweise in der Mail. Bitte die betroffene Person wählen:');
  scored.forEach((x,n)=>log(`  [${n+1}] ${x.c.name} (${x.c.sources.join(', ')})`));
  return rl.question('Nummer: ').then(v=>{
    const n=Number(v);need(Number.isInteger(n)&&n>=1&&n<=scored.length,'NAME_CHOICE','Ungültige Personenauswahl.');diag.mail.personManual=true;return {person:scored[n-1].c,expectedId:ids.length===1?ids[0]:null};
  });
}

async function memberFieldCenter(page){return await page.call(function(){
  const docs=[];(function walk(doc,d){if(!doc||d>5||docs.includes(doc))return;docs.push(doc);for(const f of doc.querySelectorAll('iframe,frame'))try{walk(f.contentDocument,d+1)}catch{}})(document,0);
  const vis=n=>{try{return n&&n.getClientRects().length>0&&!n.disabled&&!n.readOnly}catch{return false}};
  const hits=docs.map(d=>d.getElementById('mainForm:member-value-id')).filter(vis);if(hits.length!==1)return {ok:false,count:hits.length};
  const f=hits[0];f.scrollIntoView({block:'center',inline:'nearest'});const r=f.getBoundingClientRect();return {ok:true,x:r.left+r.width/2,y:r.top+r.height/2};
});}
async function primeMemberField(page){
  const c=await memberFieldCenter(page);need(c.ok,'MEMBER_FIELD','Member-Feld nicht eindeutig gefunden.');
  await page.mouseClick(c.x,c.y);await sleep(650);return c;
}
async function setMemberSearch(page, query){
  await primeMemberField(page);
  return await page.call(function(value){
    const docs=[];(function walk(doc,d){if(!doc||d>5||docs.includes(doc))return;docs.push(doc);for(const f of doc.querySelectorAll('iframe,frame'))try{walk(f.contentDocument,d+1)}catch{}})(document,0);
    const vis=n=>{try{return n&&n.getClientRects().length>0&&!n.disabled&&!n.readOnly}catch{return false}};
    const hits=docs.map(d=>d.getElementById('mainForm:member-value-id')).filter(vis);if(hits.length!==1)return {ok:false,count:hits.length};
    const f=hits[0],w=f.ownerDocument.defaultView,set=Object.getOwnPropertyDescriptor(w.HTMLInputElement.prototype,'value').set;
    set.call(f,'');f.dispatchEvent(new w.Event('input',{bubbles:true}));set.call(f,value);f.dispatchEvent(new w.Event('input',{bubbles:true}));
    const key=value.slice(-1)||'x',code=key.toUpperCase().charCodeAt(0)||88;f.dispatchEvent(new w.KeyboardEvent('keyup',{key,keyCode:code,which:code,bubbles:true}));return {ok:true};
  },query);
}

async function memberSuggestions(page, person){return await page.call(function(first,last){
  const docs=[];(function walk(doc,d){if(!doc||d>5||docs.includes(doc))return;docs.push(doc);for(const f of doc.querySelectorAll('iframe,frame'))try{walk(f.contentDocument,d+1)}catch{}})(document,0);
  const vis=n=>{try{return n?.isConnected&&n.getClientRects().length>0&&n.ownerDocument.defaultView.getComputedStyle(n).display!=='none'&&n.ownerDocument.defaultView.getComputedStyle(n).visibility!=='hidden'}catch{return false}};
  const norm=s=>String(s??'').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim().toLocaleLowerCase('de-DE').replace(/[.,]/g,'');
  const f=docs.map(d=>d.getElementById('mainForm:member-value-id')).find(vis);if(!f)return [];
  const fr=f.getBoundingClientRect(),want=[norm(last+' '+first),norm(first+' '+last)],targets=[];
  for(const leaf of f.ownerDocument.querySelectorAll('div,span,label,li,tr,td,button,a')){
    if(!vis(leaf))continue;const text=String(leaf.innerText??leaf.textContent??'').replace(/\s+/g,' ').trim();if(!text||text.length>350)continue;const nt=norm(text);if(!want.some(w=>nt.startsWith(w)||nt.includes(w)))continue;
    let target=null,n=leaf;for(let d=0;n&&d<5;d++,n=n.parentElement){if(typeof n.onmousedown==='function'){target=n;break;}if(['FORM','BODY','HTML'].includes(n.tagName))break;}
    if(!target||!vis(target))continue;const r=target.getBoundingClientRect();if(r.top<fr.top-30||r.top>fr.bottom+650||Math.abs(r.left-fr.left)>1000)continue;
    const t=String(target.innerText??target.textContent??text).replace(/\s+/g,' ').trim();const m=t.match(/\bINTL01-(\d{1,15})\b/i);targets.push({text:t,id:m?m[1]:null,x:r.left+r.width/2,y:r.top+r.height/2,width:r.width,height:r.height});
  }
  const seen=new Set();return targets.filter(x=>{const k=[x.id??'',x.text,Math.round(x.x),Math.round(x.y)].join('|');if(seen.has(k))return false;seen.add(k);return true;});
},person.firstName,person.lastName);}

async function selectedMember(page){return await page.call(function(){
  const docs=[];(function walk(doc,d){if(!doc||d>5||docs.includes(doc))return;docs.push(doc);for(const f of doc.querySelectorAll('iframe,frame'))try{walk(f.contentDocument,d+1)}catch{}})(document,0);
  const f=docs.map(d=>d.getElementById('mainForm:member-value-id')).find(n=>n&&n.getClientRects().length>0);if(!f)return null;const m=String(f.value??'').match(/\bINTL01-(\d{1,15})\b/i);return m?{id:m[1],display:f.value}:null;
});}

async function selectMember(page, person, expectedId, rl){
  const q=Person.query(person.firstName,person.lastName);diag.member.searchStarted=true;
  const set=await setMemberSearch(page,q.query);need(set.ok,'MEMBER_FIELD','Member-Feld nicht eindeutig gefunden.');
  log(`Member-Suche gestartet: ${q.query}`);
  let suggestions=[];
  for(let i=0;i<45;i++){await sleep(180);suggestions=await memberSuggestions(page,person);if(suggestions.length)break;}
  let pick=null;
  if(expectedId){const exact=suggestions.filter(s=>s.id===expectedId);if(exact.length===1)pick=exact[0];}
  if(!pick&&suggestions.length===1)pick=suggestions[0];
  if(pick){
    log('Eindeutiger Member-Vorschlag erkannt → echter Browser-Mausklick.');diag.member.autoClicked=true;await page.mouseClick(pick.x,pick.y);
  } else {
    diag.member.manualGate=true;
    log(suggestions.length?`Mehrere/uneindeutige Member-Vorschläge (${suggestions.length}) → bitte richtigen Treffer im Edge-Fenster anklicken.`:'Vorschlagsliste nicht sicher erkannt → bitte richtigen Member im Edge-Fenster anklicken.');
    if(!AUTO)await rl.question('ENTER drücken; Runner wartet danach auf die übernommene MercerID ... ');
  }
  let selected=null;
  for(let i=0;i<120;i++){selected=await selectedMember(page);if(selected)break;await sleep(200);}
  need(selected,'MEMBER_COMMIT','COMARCH hat keinen ausgewählten Member mit MercerID übernommen.');
  if(expectedId&&selected.id!==expectedId)fail('MEMBER_ID_CONFLICT','Ausgewählter COMARCH-Member widerspricht dem geprüften MercerID-Hinweis aus der Mail.');
  diag.member.selected=true;return selected;
}

async function writeDescription(page,text){return await page.call(function(value){
  const docs=[];(function walk(doc,d){if(!doc||d>6||docs.includes(doc))return;docs.push(doc);for(const f of doc.querySelectorAll('iframe,frame'))try{walk(f.contentDocument,d+1)}catch{}})(document,0);
  const norm=v=>String(v??'').normalize('NFC').replace(/[\u00a0\u202f]/g,' ').replace(/[\u200b\ufeff]/g,'').replace(/\s+/g,' ').trim();
  const isLabel=v=>/^Zus(?:ä|ae)tzliche Beschreibung\s*:?$/i.test(norm(v));
  const visible=n=>{try{const s=n.ownerDocument.defaultView.getComputedStyle(n);return !!n.isConnected&&n.getClientRects().length>0&&s.visibility!=='hidden'&&s.visibility!=='collapse'&&s.display!=='none'&&!n.closest('[hidden],[inert]')}catch{return false}};
  const owner=n=>n?.form??n?.closest?.('form')??n?.ownerDocument;
  function caption(n){
    if(!n||!visible(n))return '';let count=0,out='';
    function walk(p){if(++count>160||out.length>220)return;if(p.nodeType===3){out+=' '+p.textContent;return;}if(p.nodeType!==1||p.matches('input,textarea,select,button,script,style,iframe,frame,[hidden],[inert],[contenteditable="true"]')||!visible(p))return;for(const c of p.childNodes)walk(c);}
    walk(n);return count>160||out.length>220?'':norm(out);
  }
  function linkedNames(n){const out=[];for(const l of n.labels??[]){const t=caption(l);if(t)out.push(t);}const a=norm(n.getAttribute('aria-label'));if(a)out.push(a);return [...new Set(out)];}
  let member=null;for(const doc of docs){const n=doc.getElementById('mainForm:member-value-id');if(n&&visible(n)){if(member)return {ok:false,state:'MULTIPLE_MEMBER_FIELDS',count:0};member=n;}}
  if(!member)return {ok:false,state:'NO_MEMBER_FIELD',count:0};
  const doc=member.ownerDocument,scope=owner(member);
  const same=n=>n?.ownerDocument===doc&&owner(n)===scope&&n.getRootNode()===doc;
  const shape=n=>n?.tagName==='TEXTAREA'&&same(n)&&visible(n)&&!n.isContentEditable&&!n.disabled&&!n.readOnly&&!n.closest('[contenteditable="true"],[role="listbox"],[role="option"]');
  const areas=[...doc.querySelectorAll('textarea')].filter(shape);if(areas.length>128)return {ok:false,state:'SCAN_LIMIT',count:areas.length};
  const hits=new Map();const take=(n,route)=>{if(shape(n)&&!linkedNames(n).some(t=>!isLabel(t))&&!hits.has(n))hits.set(n,route);};
  for(const n of areas)if(linkedNames(n).some(isLabel))take(n,'LABEL_ASSOCIATION');
  const nodes=[...scope.querySelectorAll('label,span,td,th,div,b,strong,dt,dd,p')];
  function takeContainer(n,route){if(!n||n===scope||!visible(n)||['FORM','BODY','HTML'].includes(n.tagName))return;if(n.tagName==='TEXTAREA'){take(n,route);return;}if(n.querySelector('input:not([type="hidden"]),select,button,iframe,frame,[contenteditable="true"]'))return;const t=caption(n);if(t&&!isLabel(t))return;const targets=[...n.querySelectorAll('textarea')].filter(shape);if(targets.length===1)take(targets[0],route);}
  for(const label of nodes){
    if(!visible(label)||!isLabel(caption(label))||label.querySelector('textarea,input,select,iframe,frame'))continue;
    if([...label.children].some(n=>isLabel(caption(n))))continue;
    if(label.htmlFor)take(doc.getElementById(label.htmlFor),'LABEL_FOR');
    let n=label;for(let depth=0;n&&depth<6;depth++){
      takeContainer(n.nextElementSibling,depth?'WRAPPED_LABEL_VALUE':'LABEL_NEXT');
      const parent=n.parentElement;if(!parent||parent===scope||['FORM','BODY','HTML'].includes(parent.tagName))break;
      takeContainer(parent,'LABEL_LOCAL_CONTAINER');
      if(!isLabel(caption(parent))||parent.querySelector('textarea,input,select,button,iframe,frame'))break;n=parent;
    }
  }
  // Geometric fallback for old table layouts: exact semantic label above/left of
  // one writable textarea. It is only accepted when the nearest candidate is
  // clearly closer than every other textarea in the same form.
  if(hits.size===0){
    const labels=nodes.filter(n=>visible(n)&&isLabel(caption(n))&&!n.querySelector('textarea,input,select,iframe,frame'));
    const scored=[];
    for(const l of labels){const lr=l.getBoundingClientRect();for(const a of areas){const ar=a.getBoundingClientRect();const below=ar.top>=lr.top-8;const dx=Math.max(0,Math.max(lr.left-ar.right,ar.left-lr.right));const dy=Math.max(0,ar.top-lr.bottom);if(!below||dx>500||dy>260)continue;scored.push({a,score:dy+dx*0.2});}}
    scored.sort((x,y)=>x.score-y.score);if(scored.length&&(!scored[1]||scored[1].score-scored[0].score>24))take(scored[0].a,'GEOMETRIC_LABEL_NEAREST');
  }
  if(hits.size!==1)return {ok:false,state:hits.size?'AMBIGUOUS':'NOT_FOUND',count:hits.size,textareaCount:areas.length};
  const [f,route]=[...hits][0];if(f.value.trim()&&f.value!==value)return {ok:false,state:'OCCUPIED',occupied:true,count:1,route};
  if(f.value!==value){const w=f.ownerDocument.defaultView,set=Object.getOwnPropertyDescriptor(w.HTMLTextAreaElement.prototype,'value')?.set;if(typeof set!=='function')return {ok:false,state:'NO_SETTER',count:1,route};set.call(f,value);f.dispatchEvent(new w.Event('input',{bubbles:true}));f.dispatchEvent(new w.Event('change',{bubbles:true}));}
  return {ok:f.value===value,state:f.value===value?'DOM_VERIFIED':'VERIFY_FAILED',count:1,route};
},text);}

async function verifyDescription(page,text){return await page.call(function(value){
  const norm=v=>String(v??'').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();
  const docs=[];(function walk(doc,d){if(!doc||d>6||docs.includes(doc))return;docs.push(doc);for(const f of doc.querySelectorAll('iframe,frame'))try{walk(f.contentDocument,d+1)}catch{}})(document,0);
  const visible=n=>{try{return n?.isConnected&&n.getClientRects().length>0&&n.ownerDocument.defaultView.getComputedStyle(n).display!=='none'&&n.ownerDocument.defaultView.getComputedStyle(n).visibility!=='hidden'}catch{return false}};
  const matches=[];for(const doc of docs)for(const t of doc.querySelectorAll('textarea'))if(visible(t)&&norm(t.value)===norm(value))matches.push(t);
  return {ok:matches.length===1,count:matches.length};
},text);}

async function setSelectExact(page,id,text){return await page.call(function(id,text){
  const s=document.getElementById(id);if(!s||s.tagName!=='SELECT'||s.disabled)return {ok:false};const norm=v=>String(v??'').replace(/\s+/g,' ').trim();const o=[...s.options].filter(x=>norm(x.textContent)===text);if(o.length!==1)return {ok:false,count:o.length};const set=Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype,'value').set;set.call(s,o[0].value);s.dispatchEvent(new Event('input',{bubbles:true}));s.dispatchEvent(new Event('change',{bubbles:true}));return {ok:norm(s.selectedOptions[0]?.textContent)===text};
},id,text);}

async function inputCenterById(page,id){return await page.call(function(id){
  const f=document.getElementById(id);if(!f||f.tagName!=='INPUT'||f.disabled||f.readOnly||!f.getClientRects().length)return {ok:false};f.scrollIntoView({block:'center',inline:'nearest'});const r=f.getBoundingClientRect();return {ok:true,x:r.left+r.width/2,y:r.top+r.height/2};
},id);}
async function waitEditable(page,id,timeoutMs=7000){
  const deadline=Date.now()+timeoutMs;while(Date.now()<deadline){const c=await inputCenterById(page,id);if(c.ok)return c;await sleep(180);}return {ok:false};
}
async function setSuggestExact(page,id,text){
  const center=await waitEditable(page,id);need(center.ok,'FIXED_FIELD','Feld nicht bearbeitbar: '+text);
await page.mouseClick(center.x,center.y);await sleep(300);
  const init=await page.call(function(id,value){
    const f=document.getElementById(id);if(!f||f.tagName!=='INPUT'||f.disabled||f.readOnly)return {ok:false};const set=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;set.call(f,'');f.dispatchEvent(new Event('input',{bubbles:true}));set.call(f,value);f.dispatchEvent(new Event('input',{bubbles:true}));const k=value.slice(-1)||'x',code=k.toUpperCase().charCodeAt(0)||88;f.dispatchEvent(new KeyboardEvent('keyup',{key:k,keyCode:code,which:code,bubbles:true}));return {ok:true};
  },id,text);need(init.ok,'FIXED_FIELD','Feld nicht bearbeitbar: '+text);
  let rows=[];
  for(let i=0;i<35;i++){await sleep(180);rows=await page.call(function(id,expected){
    const f=document.getElementById(id);if(!f)return[];const fr=f.getBoundingClientRect(),norm=v=>String(v??'').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();const out=[];
    for(const leaf of document.querySelectorAll('div,span,label,li,tr,td,button,a')){if(!leaf.getClientRects().length)continue;const t0=norm(leaf.innerText??leaf.textContent);if(t0!==expected)continue;let n=leaf,target=null;for(let d=0;n&&d<5;d++,n=n.parentElement){if(typeof n.onmousedown==='function'){target=n;break;}if(['FORM','BODY','HTML'].includes(n.tagName))break;}if(!target||!target.getClientRects().length)continue;const r=target.getBoundingClientRect();if(r.top<fr.top-20||r.top>fr.bottom+500||Math.abs(r.left-fr.left)>800)continue;out.push({x:r.left+r.width/2,y:r.top+r.height/2,text:t0});}return out;
  },id,text);if(rows.length)break;}
  if(rows.length===1){
    const fired=await page.call(function(id,expected){
      const f=document.getElementById(id);if(!f)return {ok:false,count:0};const fr=f.getBoundingClientRect(),norm=v=>String(v??'').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim(),targets=[];
      for(const leaf of document.querySelectorAll('div,span,label,li,tr,td,button,a')){if(!leaf.getClientRects().length||norm(leaf.innerText??leaf.textContent)!==expected)continue;let n=leaf,target=null;for(let d=0;n&&d<5;d++,n=n.parentElement){if(typeof n.onmousedown==='function'){target=n;break;}if(['FORM','BODY','HTML'].includes(n.tagName))break;}if(!target||!target.getClientRects().length)continue;const r=target.getBoundingClientRect();if(r.top<fr.top-20||r.top>fr.bottom+500||Math.abs(r.left-fr.left)>800)continue;if(!targets.includes(target))targets.push(target);}
      if(targets.length!==1)return {ok:false,count:targets.length};const target=targets[0],w=target.ownerDocument.defaultView;setTimeout(()=>target.dispatchEvent(new w.MouseEvent('mousedown',{bubbles:true,cancelable:true,view:w,button:0,buttons:1})),0);return {ok:true,count:1};
    },id,text);
    if(!fired.ok)rows=[];
    await sleep(1000);
  }else{await sleep(750);}
  const value=await page.call((id)=>document.getElementById(id)?.value??null,id);return {ok:clean(value)===text,selection:rows.length===1?'MOUSE':'TEXT_ONLY',rows:rows.length};
}


async function setSubcategoryExact(page,text){
  const center=await waitEditable(page,'mainForm:category-sub-value-id');need(center.ok,'FIXED_FIELD','Feld nicht bearbeitbar: '+text);
  const init=await page.call(function(value){
    const f=document.getElementById('mainForm:category-sub-value-id');if(!f||f.tagName!=='INPUT'||f.disabled||f.readOnly)return {ok:false};
    const set=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;set.call(f,'');f.dispatchEvent(new Event('input',{bubbles:true}));set.call(f,value);f.dispatchEvent(new Event('input',{bubbles:true}));const k=value.slice(-1)||'x',code=k.toUpperCase().charCodeAt(0)||88;f.dispatchEvent(new KeyboardEvent('keyup',{key:k,keyCode:code,which:code,bubbles:true}));return {ok:true};
  },text);need(init.ok,'FIXED_FIELD','Feld nicht bearbeitbar: '+text);
  await sleep(1200);
  const value=await page.call(()=>document.getElementById('mainForm:category-sub-value-id')?.value??null);
  return {ok:clean(value)===text,selection:'KEYUP_SUBMIT'};
}

async function prepareFixed(page,rl){
  log('Feste Felder: Zuständigkeit → Second Level');
  const r=await setSelectExact(page,'mainForm:responsibility-value-id',Prep.FIXED.responsibility);need(r.ok,'RESPONSIBILITY','Second Level konnte nicht gesetzt werden.');diag.fixed.responsibility=true;
  log('Feste Felder: Dokumentenkategorie → '+Prep.FIXED.category);
  let s=await setSuggestExact(page,'mainForm:category-value-id',Prep.FIXED.category);
  if(!s.ok&&!AUTO){log(`${Prep.FIXED.category}: automatische Vorschlagsauswahl nicht bestätigt. Bitte im Edge-Fenster exakt „${Prep.FIXED.category}“ auswählen.`);await rl.question('ENTER danach ... ');}let v=await page.call((id)=>document.getElementById(id)?.value??'','mainForm:category-value-id');need(clean(v)===Prep.FIXED.category,'FIXED_VERIFY',Prep.FIXED.category+' ist im COMARCH-Feld nicht sichtbar.');diag.fixed.category=true;
  // COMARCH ersetzt Teile des Formulars nach der Member-Übernahme und auch
  // nach Kategorie-Updates. Deshalb das echte Member-Feld HIER erneut real
  // anklicken, bevor die abhängige Unterkategorie geprüft/gesetzt wird.
  log('Abhängige Felder aktivieren → Member-Feld wird erneut real angeklickt.');
  await primeMemberField(page);await sleep(700);
  const subReady=await waitEditable(page,'mainForm:category-sub-value-id',10000);need(subReady.ok,'FIXED_FIELD','Unterkategorie blieb nach erneutem Member-Klick nicht bearbeitbar.');
  log('Feste Felder: Unterkategorie → '+Prep.FIXED.subcategory);
  s=await setSuggestExact(page,'mainForm:category-sub-value-id',Prep.FIXED.subcategory);
  if(!s.ok&&!AUTO){log(`${Prep.FIXED.subcategory}: automatische Vorschlagsauswahl nicht bestätigt. Bitte im Edge-Fenster exakt „${Prep.FIXED.subcategory}“ auswählen.`);await rl.question('ENTER danach ... ');}v=await page.call((id)=>document.getElementById(id)?.value??'','mainForm:category-sub-value-id');need(clean(v)===Prep.FIXED.subcategory,'FIXED_VERIFY',Prep.FIXED.subcategory+' ist im COMARCH-Feld nicht sichtbar.');diag.fixed.subcategory=true;
  log('Feste Felder: Signatur → '+Prep.FIXED.signature);
  s=await setSuggestExact(page,'mainForm:signature-value-id',Prep.FIXED.signature);
  if(!s.ok&&!AUTO){log(`${Prep.FIXED.signature}: automatische Vorschlagsauswahl nicht bestätigt. Bitte im Edge-Fenster exakt „${Prep.FIXED.signature}“ auswählen.`);await rl.question('ENTER danach ... ');}v=await page.call((id)=>document.getElementById(id)?.value??'','mainForm:signature-value-id');need(clean(v)===Prep.FIXED.signature,'FIXED_VERIFY',Prep.FIXED.signature+' ist im COMARCH-Feld nicht sichtbar.');diag.fixed.signature=true;
}

async function editorWrite(page,text){return await page.call(function(value){
  const docs=[];(function walk(doc,d){if(!doc||d>6||docs.includes(doc))return;docs.push(doc);for(const f of doc.querySelectorAll('iframe,frame'))try{walk(f.contentDocument,d+1)}catch{}})(document,0);
  const visible=n=>{try{return n&&n.getClientRects().length>0}catch{return false}};const hits=[];
  for(const doc of docs)for(const n of doc.querySelectorAll('[contenteditable="true"],body[contenteditable="true"],html[contenteditable="true"]'))if(visible(n))hits.push(n);
  const uniq=[...new Set(hits)].filter(n=>!hits.some(x=>x!==n&&n.contains(x)));
  if(uniq.length!==1)return {ok:false,count:uniq.length};const e=uniq[0];const norm=s=>String(s??'').replace(/\r\n?/g,'\n').replace(/\u00a0/g,' ').replace(/[ \t]+\n/g,'\n').replace(/\n[ \t]+/g,'\n').trim();
  const old=norm(e.innerText??e.textContent);if(old&&old!==norm(value))return {ok:false,occupied:true};e.innerHTML=value.split('\n').map(s=>s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')).join('<br>');e.dispatchEvent(new e.ownerDocument.defaultView.Event('input',{bubbles:true}));return {ok:norm(e.innerText??e.textContent)===norm(value)};
},text);}

async function injectDemo(page){
  const msg64=fs.readFileSync(path.join(root,'examples','DEMO_Mail.msg')).toString('base64');
  const html=`<style>body{font:16px Segoe UI;margin:30px}label{display:block;margin-top:15px}input,select,textarea{font:inherit;padding:6px;width:500px}.suggest{position:absolute;background:#fff;border:1px solid #777;padding:4px}.suggest div{padding:6px;cursor:pointer}iframe{width:720px;height:220px;border:1px solid #aaa}</style>
<h1>MCR Local Runner Demo</h1><table id="history"><thead><tr><th>Original</th><th>Von</th><th>An</th><th>Betreff</th><th>Inhalt</th><th>Datum</th><th>Anlage</th></tr></thead><tbody><tr><td><a id="mail-old" href="GetFile?docId=0">Herunterladen</a></td><td>max@example.invalid</td><td>B</td><td>Alt</td><td>Mit freundlichen Grüßen\nMax Mustermann</td><td>01.01.2026</td><td></td></tr><tr><td><a id="mail" href="GetFile?docId=1">Herunterladen</a></td><td>max@example.invalid</td><td>B</td><td>Neu</td><td>Bitte um Prüfung.\nMit freundlichen Grüßen\nMax Mustermann</td><td>02.01.2026</td><td></td></tr></tbody></table>
<label>Zuständigkeit<select id="mainForm:responsibility-value-id"><option></option><option>Second Level</option></select></label>
<label>Dokumentenkategorie<input id="mainForm:category-value-id"></label><label>Unterkategorie<input id="mainForm:category-sub-value-id" disabled></label>
<label>Member<input id="mainForm:member-value-id"></label><div>MercerID: <span id="mercer"> </span></div><div>Vorname: <span id="first"></span> Nachname: <span id="last"></span></div>
<label>Zusätzliche Beschreibung<textarea id="mainForm:j_id7019"></textarea></label><label>Signatur<input id="mainForm:signature-value-id"></label>
<label>An<input id="recipient" value="max@example.invalid"></label><iframe id="editor"></iframe>`;
  const expr=`(()=>{document.title='MCR Local Runner Demo';document.body.innerHTML=${JSON.stringify(html)};const msg64=${JSON.stringify(msg64)};document.getElementById('mail-old').href='data:application/vnd.ms-outlook;base64,'+msg64+'#GetFile?docId=0';document.getElementById('mail').href='data:application/vnd.ms-outlook;base64,'+msg64+'#GetFile?docId=1';const specs={'mainForm:member-value-id':['Mustermann Max (INTL01-99900001) - 1970-01-01'],'mainForm:category-value-id':['Allgemeine Schriftwechsel'],'mainForm:category-sub-value-id':['Personenschriftwechsel'],'mainForm:signature-value-id':['INTL01 - Intel Deutschland GmbH']};const memberField=document.getElementById('mainForm:member-value-id');const subField=document.getElementById('mainForm:category-sub-value-id');memberField.addEventListener('mousedown',()=>{subField.disabled=false;});for(const [id,vals] of Object.entries(specs)){const f=document.getElementById(id);const render=()=>{document.querySelectorAll('.suggest').forEach(x=>x.remove());const box=document.createElement('div');box.className='suggest';const r=f.getBoundingClientRect();box.style.left=r.left+'px';box.style.top=(r.bottom+scrollY)+'px';vals.forEach(t=>{const d=document.createElement('div');d.textContent=t;d.onmousedown=e=>{f.value=t;if(id==='mainForm:member-value-id'){document.getElementById('mercer').textContent='INTL01-99900001';document.getElementById('first').textContent='Max';document.getElementById('last').textContent='Mustermann';subField.disabled=true;}box.remove();e.preventDefault();};box.append(d)});document.body.append(box);};f.addEventListener('focus',render);f.addEventListener('input',render);}const ed=document.getElementById('editor');ed.srcdoc='<html contenteditable="true"><body contenteditable="true"></body></html>';})()`;
  await page.eval(expr);
}
async function writeDiagnostic(cfg){
  fs.mkdirSync(cfg.diagnosticDirectory,{recursive:true});diag.createdAt=new Date().toISOString();const report=JSON.stringify(diag,null,2)+'\n';const manifest=JSON.stringify({schema:'MCR_DIAGNOSTIC_MANIFEST_V1',payload:[{path:'diagnostic.json',sha256:sha256(report)}],privacy:diag.privacy},null,2)+'\n';const zip=writeZip([{name:'diagnostic.json',data:report},{name:'manifest.json',data:manifest},{name:'SHA256SUMS.txt',data:sha256(report)+'  diagnostic.json\n'+sha256(manifest)+'  manifest.json\n'}]);const p=path.join(cfg.diagnosticDirectory,`MCR_LOCAL_RUNNER_${nowStamp()}_UPLOAD.zip`);fs.writeFileSync(p,zip);return {path:p,sha256:sha256(zip)};
}

async function main(){
  heading('MCR Local Runner 0.5.3 - beaufsichtigter Einzelticket-Lauf');
  log('Lokales Node.js + Edge/Chromium. Kein DevTools-Copy/Paste.');
  log('Mapping und Ticket-Mail werden automatisch aus dem Nachrichtenverlauf gelesen; MSG-Download ist nur noch Fallback. Senden/Speichern bleiben deaktiviert.\n');
  const cfg=resolveConfig();fs.mkdirSync(cfg.runtimeDirectory,{recursive:true});fs.mkdirSync(cfg.downloadDirectory,{recursive:true});
  const mapping=autoMapping(cfg);diag.mapping.loaded=true;diag.mapping.sourceConfirmed=true;log('Mapping automatisch geladen: '+path.basename(mapping.path));
  const rl=readline.createInterface({input,output});let browser=null,cdp=null;
  try{
    let startUrl=cfg.comarchUrl, executable=findEdgeExecutable(cfg.edgePath);
    if(DEMO){startUrl='about:blank';executable=findEdgeExecutable(cfg.demoBrowserPath || cfg.edgePath);}
    need(executable,'BROWSER_NOT_FOUND','Microsoft Edge/Chromium wurde nicht gefunden. config/local-runner.json prüfen.');
    browser=await launchBrowser({executable,userDataDir:cfg.profileDirectory,startUrl,headless:HEADLESS,extraArgs:DEMO?['--disable-popup-blocking',...(process.platform!=='win32'&&typeof process.getuid==='function'&&process.getuid()===0?['--no-sandbox']:[])]:[]});diag.browser.launched=true;
    const conn=await connectBrowser(browser.port);cdp=conn.cdp;diag.browser.connected=true;
    await cdp.send('Browser.setDownloadBehavior',{behavior:'allow',downloadPath:cfg.downloadDirectory,eventsEnabled:true}).catch(async()=>{});
    const page=await attachPage(cdp,t=>t.type==='page'&&(DEMO?t.url.startsWith(startUrl):(!/^(edge|chrome|devtools|about):/i.test(t.url))),30000);
    if(DEMO)await injectDemo(page);
    await waitComarch(page);
    if(!DEMO){log('\nÖffne jetzt EIN gewünschtes INTL01-Ticket. Der Runner erkennt „Bearbeiten“ automatisch.');if(!AUTO)await rl.question('ENTER sobald das Ticket geöffnet ist (oder sofort, wenn es schon offen ist) ... ');}
    await ensureEditMode(page);
    let mail=null,person=null,expectedId=null;
    const historyChoice=await choosePersonFromHistory(page,rl);
    if(historyChoice){
      ({mail,person,expectedId}=historyChoice);diag.mail.parsed=true;
      log(`Ticket-Mail direkt aus dem Nachrichtenverlauf gelesen (${diag.mail.historyRows} Zeile(n)); kein Download nötig.`);
    } else {
      log('Im Nachrichtenverlauf kein ausreichend verwertbarer Namenshinweis gefunden → Fallback auf MSG-Download.');
      const msgPath=await downloadCurrentMail(page,cfg,rl);mail=Msg.parseMsg(fs.readFileSync(msgPath));diag.mail.parsed=true;diag.mail.source='MSG_DOWNLOAD';
      ({person,expectedId}=await choosePerson(mail,rl));log('Original-MSG lokal gelesen.');
    }
    log('Person für Member-Suche festgelegt: '+person.lastName+' '+person.firstName+(expectedId?' [MercerID-Hinweis vorhanden]':''));
    const selected=await selectMember(page,person,expectedId,rl);log('COMARCH-Member übernommen. MercerID wurde aus COMARCH gelesen.');
    diag.lookup.attempted=true;const entry=Core.lookup(mapping.map,selected.id);diag.lookup.ready=true;log('Bestandsabgleich: '+entry.description);
    const dw=await writeDescription(page,entry.description);diag.description.route=dw.route??null;diag.description.candidates=dw.count??null;need(dw.ok,'DESCRIPTION_WRITE','Zusätzliche Beschreibung konnte nicht eindeutig eingesetzt werden ('+(dw.state??'UNBEKANNT')+').');diag.description.written=true;await sleep(700);const dv=await verifyDescription(page,entry.description);need(dv.ok,'DESCRIPTION_VERIFY','Zusätzliche Beschreibung war nach der Seitenreaktion nicht mehr eindeutig nachweisbar.');diag.description.verified=true;log('Zusätzliche Beschreibung eingesetzt und nach Seitenreaktion erneut verifiziert.');
    await prepareFixed(page,rl);log('Feste Felder vorbereitet: Second Level / Kategorien / Signatur.');
    let sal='Herr';if(!AUTO){const s=clean(await rl.question('Anrede [H]err / [F]rau: ')).toLowerCase();sal=s.startsWith('f')?'Frau':'Herr';}
    const reply=Prep.replyText(sal,person.lastName);diag.reply.generated=true;const ew=await editorWrite(page,reply);need(ew.ok,'REPLY_WRITE',ew.occupied?'Antworteditor enthält bereits abweichenden Text.':'Antworteditor konnte nicht eindeutig beschrieben werden.');diag.reply.written=true;await sleep(500);diag.reply.verified=true;
    if(!AUTO){log('\nBitte im Edge-Fenster Empfänger, feste Felder, Beschreibung und Antworttext prüfen.');const ok=clean(await rl.question('Alles korrekt? Tippe JA, um den Pre-Send-Gate zu bestätigen: '));need(/^ja$/i.test(ok),'FINAL_REVIEW','Pre-Send-Prüfung nicht bestätigt.');}
    diag.readyBeforeSend=true;
    heading('BEREIT VOR VERSAND');
    log('✓ Mapping automatisch geladen');log('✓ Ticket-Mail automatisch aus dem Nachrichtenverlauf gelesen / Fallback MSG');log('✓ Member gewählt und MercerID aus COMARCH gelesen');log('✓ USC / Pläne berechnet');log('✓ Beschreibung eingesetzt');log('✓ feste Felder vorbereitet');log('✓ Antworttext eingesetzt');
    log('\nSTOPP: Version 0.5.3 klickt NICHT auf „Senden“ und NICHT auf „Ticket speichern“.');
  } catch(e){diag.lastError=e.code||'ERROR';console.error('\nSTOP:',diag.lastError,'-',e.message);process.exitCode=1;}
  finally{
    try{const d=await writeDiagnostic(cfg);log('\nDiagnose: '+d.path);log('Diagnose-ZIP-SHA256: '+d.sha256);}catch(e){console.error('Diagnose konnte nicht geschrieben werden:',e.message);}
    try{rl.close();}catch{}
    try{cdp?.close();}catch{}
    if(DEMO||!KEEP_BROWSER)try{browser?.child?.kill();}catch{}
  }
}

await main();
