# MCR Datenbrücke / Local Runner 0.5.3

Aktueller Runner: `START_LOCAL_BOT.cmd`. Details: `README_0_5_3.md`.

# MCR Local Runner 0.5.2

## Ziel dieses Stands

0.5.2 qualifiziert den lokalen Node+Edge-Runner weiter, ohne Versand oder Ticket-Speicherung zu aktivieren.

Neu gegenüber 0.5.1:

- Die Original-Mail wird im Nachrichtenverlauf semantisch über die Tabelle `Original / Von / An / Betreff / Inhalt / Datum` gefunden.
- Bei mehreren Nachrichten wird die **unterste Tabellenzeile** verwendet.
- Der Runner liest den `GetFile?docId=...`-Link dieser Zeile und lädt die MSG zuerst direkt im bereits authentifizierten COMARCH-Seitenkontext. Dadurch ist kein Download-Popup nötig.
- Nur wenn dieser direkte Abruf nicht funktioniert, fällt der Runner auf einen echten Browser-Mausklick bzw. zuletzt auf das bisherige manuelle Gate zurück.
- Vor der Member-Suche wird das echte Feld `mainForm:member-value-id` einmal mit der Browsermaus angeklickt. Erst danach wird `Nachname Vorname` gesetzt und `keyup` ausgelöst.
- Die Suche nach Member-Vorschlägen berücksichtigt auch Kind-Elemente, deren übergeordnete Zeile den `onmousedown`-Handler besitzt.
- Bei genau einem passenden Treffer wird ein echter Browser-Mausklick ausgeführt; bei mehreren Treffern bleibt die menschliche Auswahl Pflicht.
- Nach übernommener MercerID wird das Member-Feld erneut real fokussiert. Das aktiviert in der beobachteten COMARCH-Version abhängige Felder.
- Kategorie wird vor Unterkategorie gesetzt; danach wird das Member-Feld erneut fokussiert und erst anschließend `Personenschriftwechsel` verarbeitet.

## Start

ZIP vollständig entpacken und anschließend:

`START_LOCAL_BOT.cmd`

verwenden.

## Sicherheitsgrenze

0.5.2 klickt weiterhin **nicht** auf `Senden` und **nicht** auf `Ticket speichern`.

Der Lauf bleibt ein beaufsichtigter Einzelvorgang. Bei Mehrdeutigkeiten oder nicht bestätigter Serverübernahme wird fail-closed angehalten.
