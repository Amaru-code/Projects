/** RC105: central AO generation plus existing DC/PP+ preparation.
 * The calculator owns all financial formulas. No COMARCH mutation here. */
import fs from 'node:fs';
import path from 'node:path';
import {requireThat as need} from '../lib/core.mjs';
import {validAoContact} from '../lib/documents/ao-contact-value.mjs';
import {writeJSON,stamp,ledger} from '../lib/control.mjs';
import {phase2Admission} from '../lib/phase2/phase2-admission.mjs';
import {approvedWwid,inspectExistingStatements,generatorPaths} from '../lib/documents/phase2-pdf-evidence.mjs';
import {runAccountStatement,inspectCentralStatement} from '../lib/documents/phase2-statement-generator.mjs';
import {runLocalStatementGenerator} from '../lib/documents/phase2-local-generator.mjs';
import {verifyAoGeneratorProof,hasAutomaticDocumentPreparation} from '../lib/documents/phase2-ao-proof.mjs';
import {aoContactQueue} from '../lib/documents/phase2-ao-contact-queue.mjs';
import {beneficiaryBusinessFingerprint} from '../lib/documents/phase2-post-generator-workbook.mjs';
import {readPhase2MemberEvidence} from '../lib/comarch/comarch-member.mjs';
import {lookupMultirow} from '../lib/workbook/multirow-tpp-mapping.mjs';
import {resolveMemberMapping} from '../lib/phase1/member-mapping.mjs';
import {openPhase2Ticket} from '../lib/phase2/phase2-navigation.mjs';
import * as UI from '../lib/comarch/browser-workflow.mjs';

export function verifyLegacyPlanAlias(rule,member,mapping){
 if(!rule.requiresPlanConfirmation)return {verified:true,method:'CANONICAL_DESCRIPTION_PLANS'};
 need(member.profileVerified&&member.profile?.mercerId,'P2_LEGACY_IPP_MEMBER','IPP-Alteintrag ohne gebundenes Memberprofil.');
 const resolved=resolveMemberMapping(mapping,member.profile.mercerId);
 need(resolved.kind==='FOUND'&&Array.isArray(resolved.entry?.records),'P2_LEGACY_IPP_MAPPING','IPP-Alteintrag nicht eindeutig im Bestand.');
 const plans=new Set(resolved.entry.records.flatMap(r=>[...(r.dc===1?['DC']:[]),...(r.ppPlus===1?['PP+']:[])]));
 need(rule.targets.filter(t=>t!=='AO').every(t=>plans.has(t)),'P2_LEGACY_IPP_PLAN_CONFLICT','IPP-Alteintrag passt nicht zu DC/PP+ im gebundenen Bestand. Keine Anlage geraten.');
 return {verified:true,method:'LEGACY_IPP_CONFIRMED_BY_MEMBER_MAPPING'};
}

export function reviewedPdfProof({root,ticketId,rule,wwid,member,before,wwidOrigin,planEvidence,automaticAo=false,automaticStatements=false,paths=generatorPaths}){
 const selectedArtifacts=before.artifacts.filter(a=>['CENTRAL_AO_GENERATOR_AUDIT','STATEMENT_GENERATOR_CLI','CENTRAL_STATEMENT_PDF','CENTRAL_DC_OPERATOR_REVIEW','CENTRAL_PP_OPERATOR_REVIEW'].includes(a.provenance));
 for(const a of selectedArtifacts)if(a.plan==='AO')verifyAoGeneratorProof(root,a.generation,{wwid,first:member.profile.first,last:member.profile.last,paths});
 const fresh=inspectExistingStatements(root,rule.targets,wwid,{first:member.profile.first,last:member.profile.last,selectedArtifacts,paths});
 need(fresh.artifacts.length===before.artifacts.length&&fresh.artifacts.every(a=>{
  const p=before.artifacts.find(x=>x.plan===a.plan);return p&&p.name===a.name&&p.sha256===a.sha256&&p.bytes===a.bytes;
 }),'P2_PDF_MUTATED','PDFs seit Inhaltspruefung veraendert. Keine Anlage.');
 const proof={...fresh,ticketId,wwidOrigin,memberProfileVerified:true,
  memberId:member.profile.mercerId,memberName:{first:member.profile.first,last:member.profile.last},
  operatorContentReviewed:!(automaticAo||automaticStatements),operatorPersonTicketBindingReviewed:!(automaticAo||automaticStatements),
  ...((automaticAo||automaticStatements)?{systemPreparedForReview:true,requiresReviewerContentReview:true,preparationMethod:automaticAo?'CENTRAL_AO_GENERATOR_AUDIT':'GENERATED_DOCUMENTS_FOR_REVIEW'}:{}),
  operatorNameOnlyRecheckCompleted:false,planEvidence,
  automaticAttachmentAuthorized:false,comarchStatus:'NOT_ATTACHED_NOT_SAVED_NOT_FORWARDED'};
 if(automaticAo||automaticStatements)need(hasAutomaticDocumentPreparation(proof),'P2_AO_AUTOMATIC_BINDING','Automatische AO-Vorbereitung nicht vollstaendig an den COMARCH-Member gebunden.');
 return proof;
}

export async function preparePhase2PdfEvidence({root,page,row,mapping,ask,askContact=ask,log=console.log,memberLookup=readPhase2MemberEvidence,controls=null,
 generator=runLocalStatementGenerator,statementGenerator=runAccountStatement,paths=generatorPaths,ui=UI,openTicket=openPhase2Ticket,contactWriteAllowed=true}){
 const id=String(row.ticketId),admission=phase2Admission(row,ledger(root).pending),rule=admission.rule;
 need(admission.allowed&&rule.kind==='ACCOUNT_STATEMENT','P2_PDF_PREP_RULE','Kein unterstuetzter Dokumentenauftrag (DC/PP+/AO).');
 const actions=path.join(root,'.runtime','phase2','actions');
 need(!fs.existsSync(path.join(actions,'MCR_PHASE2_'+id+'.json'))&&!fs.existsSync(path.join(actions,'MCR_PHASE2_WORK_'+id+'.json')),
  'P2_PDF_PREP_PREVIOUS_ACTION','Schon begonnene Phase-2-Aktion: keine neue PDF-Vorbereitung.');
 await openTicket(page,row,{log,manualOpen:async ticket=>{
  need(String(await ask('Nur Ticket '+ticket+' im Bot-Edge oeffnen. OFFEN / ABBRUCH: ')).toUpperCase()==='OFFEN','P2_OPEN_ABORT','Abgebrochen.');
 }});
 await ui.assertTicket(page,id);await controls?.readDetail?.(page,id);
 const member=await memberLookup(page);
 need(member.profileVerified&&member.profile?.first&&member.profile?.last&&member.profile?.mercerId,
  'P2_MEMBER_NOT_BOUND','Kein eindeutiges COMARCH-Memberprofil fuer Dokumente.');
 const planEvidence=verifyLegacyPlanAlias(rule,member,mapping);
 need(!member.wwid||!member.memberReferenceWwid||member.wwid===member.memberReferenceWwid,
  'P2_WWID_CONFLICT','WWID-Feld widerspricht gebundener INTL01-Memberreferenz.');
 // Never use a generic MercerID or scan unrelated PDFs for a person ID.
 let wwid=member.wwid||member.memberReferenceWwid;
 const wwidOrigin=member.wwid?'EXPLICIT_COMARCH_FIELD':member.memberReferenceWwid?'BOUND_INTL01_MEMBER_REFERENCE':'OPERATOR_ENTRY';
 if(!wwid)wwid=approvedWwid(await ask('Verifizierte WWID dieser Person (nicht pauschal MercerID): '));
 wwid=approvedWwid(wwid);
 log('P2_PDF_PERSON: '+id+' | '+member.profile.first+' '+member.profile.last+' | WWID '+wwid+' | '+wwidOrigin);
 await controls?.waitUntilResumed?.();
 const selectedArtifacts=[];
 const pdfBlockCodes=new Set(['P2_EXACT_PDF_MISSING','P2_OUTPUT_FOLDER_MISSING','P2_PDF_SIZE','P2_PDF_HEADER','P2_PDF_EOF','P2_UNSAFE_PDF','P2_KONTOAUSZUG_PDF_MISSING','P2_KONTOAUSZUG_AUDIT_REQUIRED','P2_PDF_MUTATED']);
 const statements=rule.targets.filter(plan=>plan!=='AO');
 for(const plan of statements){
  let stockProblem='';
  try{
   const entry=lookupMultirow(mapping,wwid),flag=plan==='DC'?'dc':'ppPlus';
   if(!entry.records.some(record=>record[flag]===1))stockProblem='Plan '+plan+' ist im aktuellen Excel-Bestand fuer WWID '+wwid+' nicht belegt.';
  }catch(error){
   if(!['ID_NOT_FOUND','ID_BLOCKED'].includes(error.code))throw error;
   stockProblem='WWID '+wwid+' ist im aktuellen Excel-Bestand nicht verfuegbar: '+error.message;
  }
  if(stockProblem){
   const reason='P2_KONTOAUSZUG_GENERATOR_PREFLIGHT_FAILED';
   log(reason+': '+id+' | '+stockProblem);
   return {status:'SKIPPED_UNCHANGED',ticketId:id,noWrite:true,reason,technicalDetails:{plan,generatorReason:stockProblem}};
  }
 }
 for(const plan of statements){
  await controls?.waitUntilResumed?.();
  await ui.assertTicket(page,id);
  const current=await memberLookup(page);
  need(current.profileVerified&&current.profile?.mercerId===member.profile.mercerId&&
   current.profile.first===member.profile.first&&current.profile.last===member.profile.last&&
   (current.wwid===wwid||current.memberReferenceWwid===wwid)&&(!current.wwid||current.wwid===wwid)&&
   (!current.memberReferenceWwid||current.memberReferenceWwid===wwid),
   'P2_PDF_MEMBER_CHANGED','Vor Kontoauszug-Start fehlt die eindeutige Member-/WWID-Bindung.');
  const existing=await inspectCentralStatement(root,plan,wwid,{paths,person:member.profile,log});
  if(existing.status==='EXISTING_STATEMENT'){
   selectedArtifacts.push(existing.artifact);
   continue;
  }
  if(existing.status==='NOT_FOUND')log('P2_KONTOAUSZUG_BESTAND_FEHLT: '+plan+' | '+wwid+' | Zentrale Erzeugung fuer dieses Ticket beginnt.');
  const generated=existing?.error?existing:await statementGenerator(root,plan,wwid,{paths,person:member.profile,log});
  if(generated.status!=='GENERATOR_EXECUTED'||!generated.artifact){
   const reason=generated.error||'P2_KONTOAUSZUG_GENERATOR_FAILED';
   log(reason+': '+id+' | '+plan+' | '+(generated.reason||'Kein zuordenbares Ergebnis.'));
   return {status:'SKIPPED_UNCHANGED',ticketId:id,noWrite:true,reason,technicalDetails:{plan,generatorReason:generated.reason}};
  }
  selectedArtifacts.push(generated.artifact);
 }
 if(rule.targets.includes('AO')){
  // RC111: a new document job always generates; old preparation receipts
  // are historical only. The earlier action-journal guard remains mandatory.
  await ui.assertTicket(page,id);
  const stichtag='31.12.'+new Date().getFullYear();
  const queue=aoContactQueue(root,{ticketId:id,wwid,member,stichtag,masterPath:paths(root,'AO').master,generatorPath:paths(root,'AO').script,interactive:true});
  queue.recheck();
  log('P2_AO_REGENERATION_REQUIRED: '+id+' | WWID '+wwid+' | '+stichtag+' | alte PDF kein Ersatz.');
  log('P2_AO_ERSTELLEN: Ticket '+id+' | WWID '+wwid+' | Standardstichtag '+stichtag);
  let started;
  const attemptStartedAt=Date.now();
  try{started=await generator(root,'AO',wwid,{log,paths,aoOptions:{contactWriteAllowed,expectedPerson:{first:member.profile.first,last:member.profile.last},contactInput:async(field,signal)=>{
   if(!contactWriteAllowed)return null;
   await ui.assertTicket(page,id);
   let value;
   // Repeat the local question, never the generator's request. Keep the same
   // child process and active-time pause while correcting invalid input.
   while(true){
    if(signal?.aborted||controls?.gate?.closed)return null;
    value=await askContact(`\n------------------------------------------------\nEINGABE IM AKTUELLEN MCR-FENSTER ERFORDERLICH\nTicket: ${id} | WWID: ${wwid}\nPerson: ${member.profile.first} ${member.profile.last}\n${field} fehlt im Stammdatenbestand. Nur fachlich gepruefte Angaben eingeben.\nDer zentrale Generator speichert die fachlich bestaetigten Angaben selbst. Ein Schreibfehler wird gesondert gemeldet.\n${field==='PLZ'?'PLZ und Ort: z.B. 78073 Bad Duerrheim (vollstaendig eingeben).\n':''}ENTER ohne Wert / UEBERSPRINGEN = Ticket offenlassen.\n------------------------------------------------\n${field}: > `,signal);
    if(signal?.aborted||controls?.gate?.closed||value===null||!String(value).trim()||/^(UEBERSPRINGEN|ABBRUCH)$/i.test(String(value).trim()))return null;
    value=String(value).trim();
    if(validAoContact(field,value))break;
    log(field==='PLZ'?'P2_AO_PLZ_EINGABE_UNGUELTIG: Bitte fuenf Ziffern und Ortsnamen eingeben; derselbe Generator wartet.':'P2_AO_ADRESSE_EINGABE_UNGUELTIG: Bitte gepruefte Adresse eingeben; derselbe Generator wartet.');
   }
   await ui.assertTicket(page,id);
   const current=await memberLookup(page);
   need(current.profileVerified&&current.profile?.mercerId===member.profile.mercerId&&current.profile.first===member.profile.first&&current.profile.last===member.profile.last&&(!current.wwid||current.wwid===wwid)&&(!current.memberReferenceWwid||current.memberReferenceWwid===wwid),
    'P2_PDF_MEMBER_CHANGED','Member waehrend der Kontakteingabe geaendert.');
   return value;
  }}});}
  catch(error){
   log('P2_AO_ERSTELLUNG_OFFEN: '+id+' | '+(error.code||'AO_GENERATOR_ERROR')+' | '+error.message);
   return {status:'SKIPPED_UNCHANGED',ticketId:id,noWrite:true,reason:error.code||'P2_AO_GENERATOR_FAILED'};
  }
  if(started.status!=='GENERATOR_EXECUTED'||!started.proof){
   const reason=started.error||'P2_AO_GENERATOR_FAILED';
   log('P2_AO_ERSTELLUNG_OFFEN: '+id+' | '+reason+' | '+(started.reason||started.status)+' | Dokumentauftrag bleibt offen.');
   if(['AO_CONTACT_DATA_REQUIRED','AO_CONTACT_INPUT_DEFERRED','AO_CONTACT_INPUT_INVALID'].includes(reason)){
    if(reason==='AO_CONTACT_INPUT_DEFERRED')log('P2_AO_CONTACT_INPUT_ABGEBROCHEN: Generator hat den Abbruch vor der Kontaktspeicherung bestaetigt; keine neue PDF, kein Upload.');
    const pending=queue.waiting(started.missingFields,started.details?.master_sha256);
    log('P2_AO_WAITING_FOR_CONTACT_DATA: '+id+' | '+pending.missingFields.join(', ')+' | Kontakteingabe offen; kein COMARCH-Schreibzugriff.');
    return {status:'SKIPPED_UNCHANGED',ticketId:id,noWrite:true,reason:'AO_WAITING_FOR_CONTACT_DATA',missingFields:pending.missingFields,technicalDetails:started.details||{}};
   }
   return {status:'SKIPPED_UNCHANGED',ticketId:id,noWrite:true,reason,reviewMember:{mercerId:member.profile.mercerId,wwid},missingFields:started.missingFields||[],technicalDetails:started.details||{}};
  }
  selectedArtifacts.push(verifyAoGeneratorProof(root,started.proof,{wwid,first:member.profile.first,last:member.profile.last,paths,fresh:true,attemptStartedAt}));
  queue.generated(started.proof);
  const aoArtifact=selectedArtifacts.at(-1);
  log('PASS P2_AO_NEW_AUDIT_VERIFIED: '+id+' | neuer gebundener Audit.');
  log('PASS P2_AO_NEW_PDF_VERIFIED: '+id+' | '+aoArtifact.name);
  log('PASS P2_AO_ERZEUGT_UND_GEBUNDEN: '+id+' | '+aoArtifact.name+' | WWID, Name, Stichtag, Audit und PDF-Hash bestaetigt.');
 }
 await controls?.waitUntilResumed?.();
 let before;
 try{before=inspectExistingStatements(root,rule.targets,wwid,{first:member.profile.first,last:member.profile.last,selectedArtifacts,paths});}
 catch(e){if(!pdfBlockCodes.has(e.code))throw e;
  log('P2_DOKUMENTE_NICHT_EINDEUTIG: '+id+' | '+e.code+' | keine COMARCH-Schreibaktion.');
  return {status:'SKIPPED_UNCHANGED',ticketId:id,noWrite:true,reason:e.code};
 }
 const automaticAo=rule.targets.length===1&&rule.targets[0]==='AO'&&selectedArtifacts.length===1&&wwidOrigin!=='OPERATOR_ENTRY';
 const automaticStatements=rule.targets.some(p=>p!=='AO')&&wwidOrigin!=='OPERATOR_ENTRY'&&
  before.artifacts.every(a=>a.plan==='AO'?a.provenance==='CENTRAL_AO_GENERATOR_AUDIT':a.statementReceipt?.personCheck==='PDF_TEXT');
 if(automaticStatements){
  log('PASS P2_KONTOAUSZUG_PERSON_IM_PDF: Member und PDF an die aktuelle Vorbereitung gebunden.');
 }else if(automaticAo){
  log('PASS P2_AO_AUTOMATISCH_VORBEREITET: Ergebnis des zentralen Generators wird angehaengt; fachliche Pruefung bei Mark.');
 }else{
  for(const a of before.artifacts)log('P2_PDF_INHALT_PRUEFEN: '+a.plan+' | '+a.file);
  if(before.artifacts.some(a=>['CENTRAL_DC_OPERATOR_REVIEW','CENTRAL_PP_OPERATOR_REVIEW'].includes(a.provenance)))log('P2_KONTOAUSZUG_BESTAND_PRUEFEN: Die vorhandene zentrale Datei oeffnen. Finalen Kontoauszug, vollstaendigen Namen, WWID und angeforderten Abrechnungszeitraum anhand des Dokuments und Tickets vergleichen.');
  const response=String(await ask('Ticket '+id+': '+member.profile.first+' '+member.profile.last+', WWID '+wwid+', Zeitraum, Berechtigung und Inhalt in ALLEN '+before.artifacts.length+' PDFs geprueft? JA / UEBERSPRINGEN / ABBRUCH: ')).trim().toUpperCase();
  if(response==='UEBERSPRINGEN')return {status:'SKIPPED_UNCHANGED',ticketId:id,noWrite:true,reason:'PDF_CONTENT_REVIEW_DEFERRED'};
  need(response==='JA','P2_CONTENT_REVIEW_REQUIRED','Keine Anlage ohne Inhaltspruefung.');
 }
 for(const a of before.artifacts.filter(a=>a.provenance==='STATEMENT_GENERATOR_CLI'))log('PASS P2_KONTOAUSZUG_NEW_PDF_VERIFIED: '+id+' | '+a.plan+' | '+a.name+' | '+a.bytes+' Bytes | SHA256 '+a.sha256+' | WWID/Name im Dokument geprueft.');
 await ui.assertTicket(page,id);
 const afterMember=await memberLookup(page);
 need(afterMember.profileVerified&&afterMember.profile.mercerId===member.profile.mercerId&&
  afterMember.profile.first===member.profile.first&&afterMember.profile.last===member.profile.last&&
  (!afterMember.wwid||afterMember.wwid===wwid)&&(!afterMember.memberReferenceWwid||afterMember.memberReferenceWwid===wwid)&&
  (wwidOrigin==='OPERATOR_ENTRY'||afterMember.wwid===wwid||afterMember.memberReferenceWwid===wwid),
  'P2_PDF_MEMBER_CHANGED','Member/WWID waehrend der PDF-Pruefung geaendert.');
 const proof=reviewedPdfProof({root,ticketId:id,rule,wwid,member,before,wwidOrigin,planEvidence,automaticAo,automaticStatements,paths});
 if(rule.targets.includes('AO')){
  const fingerprint=beneficiaryBusinessFingerprint(mapping,wwid);
  if(fingerprint)proof.memberBusinessEvidence={schema:'MCR_AO_MEMBER_WORKBOOK_V1',wwid,fingerprint};
 }
 const file=path.join(root,'.runtime','phase2','MCR_PHASE2_PDF_BELEG_'+id+'_'+stamp()+'.json');
 writeJSON(file,proof);log('PASS P2_PDF_BELEGE_IM_LAUF: '+id+' | '+rule.targets.join('+')+' | keine COMARCH-Aenderung bisher.');
 return {status:'PDF_PROOF_READY',ticketId:id,proof,file};
}
