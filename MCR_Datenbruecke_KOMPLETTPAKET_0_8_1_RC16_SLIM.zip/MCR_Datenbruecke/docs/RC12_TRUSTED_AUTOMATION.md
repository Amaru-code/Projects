# RC12 – Automatisierte COMARCH-Auswahl und Pilotabschluss

**Ziel:** die in RC11 noch notwendigen manuellen Eingriffe bei Kategorie/Unterkategorie/Signatur und beim zweiten Versand-Armierungsdialog zu beseitigen, ohne ein Risiko fuer Doppelantworten zu erhoehen.

**DOM-Suche:** ICEfaces-Autocomplete reagiert in der Realmaske moeglicherweise nicht auf synthetische Events mit `isTrusted=false`. Fuer die drei fixed fields nutzt RC12 daher `Input.dispatchKeyEvent` und `Input.insertText` ueber Chrome DevTools. Der exakte Kandidat muss sichtbar, eindeutig, dem gesuchten Feld zugeordnet und an seiner Klickposition getroffen werden koennen. Weder eine grosse Elternbox noch ein fremdes Feld wird als Kandidat akzeptiert.

**Fokus:** Kategorie -> Member-Klick ohne Mutation -> Unterkategorie Personenschriftwechsel -> Member-Klick ohne Mutation -> Signatur INTL01 - Intel Deutschland GmbH -> Antworteditor. Die fruehere alternative Signatur-Fokussierung der Unterkategorie ist entfernt. Eine zweite automatische Unterkategorie-Auswahl ist nicht vorgesehen.

**Versand:** Einmaliges START im Menue 3 ist die ausdrueckliche Freigabe zum kontrollierten Pilot. Der sonst nochmals eingegebene SENDEN-Code faellt weg. Ticket-ID, COMARCH-Member/Name/MercerID, bestehendes Mapping, Empfaengeradresse, Beschreibung und Antworttext werden unmittelbar vor SEND_INTENT erneut geprueft. Ein identischer sichtbarer Standardantworttext in der aktuellen Ticket-Historie sperrt den Versand vorsorglich. Bestehende getrennte SEND-/FORWARD-Journale, Dialog-Einmalklicks und Speichernachweise bleiben unveraendert.

**Pilot / Menue 4:** Ein erfolgreicher sichtbarer Versand alleine genuegt nicht. Der reale Pilot muss den kompletten Send-/Save-Nachweis erzeugen. Erst dann wird Menue 4 fuer exakt dieses Manifest und Mapping freigeschaltet. RC11-Lauflogs bis `SENDEN` sind kein Freigabenachweis.

**Testgrenze:** Offline fiktives Chromium nach echtem Tastatur-Keyup, Zaehlung aller drei Feldauswahlen einmal je Ticket, separate historische Installer-/Rollback-Tests. Echtes COMARCH Windows wurde nicht erreicht. Bei erkennbar bereits gesendeter Antwort niemals SICHER_KEIN_VERSAND waehlen.
