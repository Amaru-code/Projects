# RC13 – COMARCH-Kategorie: letztes Zeichen im Suchfeld verloren

**Realer Befund 27.10.2026:** Nach dem RC12-Update stand im Kategorie-Suchfeld
`Allgemeine Schriftwechse` (24 Zeichen), waehrend die originale COMARCH-Option
`Allgemeine Schriftwechsel` (25 Zeichen) als Dropdown sichtbar war. RC12 warf
`FIXED_QUERY_MISMATCH`, bevor die sichere Auswahl stattfinden konnte.

**Korrektur:** Die getippte Suchanfrage darf nach dem trusted keyup exakt den
festgelegten Suchtext oder exakt dessen um **ein letztes Zeichen gekuerzten
Praefix** enthalten. Ein Praefix gilt *nur* als Suchanfrage, niemals als
akzeptierter Pflichtfeldwert. Der vorhandene Autocomplete-Code muss weiterhin
genau **einen** sichtbaren, unverdeckten, exakt beschrifteten Vorschlag finden;
bei Erfolg erfolgt ein einzelner echter Browser-Mausklick. Anschliessend
wird das Member-Feld nur fokussiert und der volle Kategoriename stabil
verifiziert. Entsprechende strengere Verifikationen gelten fuer die
Unterkategorie und Signatur weiter. Keine automatische Zweitauswahl.

Bei allen anderen Textabweichungen: in der fiktiven Demo sofortiger
Sicherheitsstopp; real nur manuelle exakte Korrektur moeglich. Versand-/
Save-/Forward-Journale und der Sendeknopf bleiben unveraendert.

**Grenze:** Reale Windows-/ICEfaces-Interaktion wurde nur aus Nutzerbild und
Lauf-Log abgeleitet. Regression durch offline Chromium mit simuliertem
Abschneiden des letzten Zeichens und Negativfall getestet.
