# RC14 — Adaptive Namenskandidaten und COMARCH-Identitaet

## Zweck
Die bisherige Logik verwarf den COMARCH-Absender im HISTORY_DOM, bevor sie
die Personenhinweise suchte. Fehlte eine explizite Namenszeile im Text,
folgte sofort eine manuelle Abfrage.

## Suchstrategie (in dieser Reihenfolge / ohne Versand)
1. Name: und aktuelle Signatur im Nachrichteninhalt.
2. Anzeigename des aktuellen Absenders / Outlook-MSG-Header.
3. Nur für reine persönliche Mail-Handles mit exakt zwei alphabetischen
   Komponenten: `vorname.nachname@`, `vorname_nachname@`, `vorname-nachname@`.
4. Bei Unsicherheit oder widersprüchlichen Kandidaten: manueller Name.

Ein abgeleiteter Name ist nur **Suchhinweis**, keine Identitätsfreigabe.
COMARCH-Member muss ausgewaehlt und in Vorname, Nachname und MercerID
verifiziert werden. Eine in der aktuellen Mail explizit genannte MercerID
ist bindend. In der zitierten alten Korrespondenz gefundene Namen bleiben
reviewpflichtig. Rollenpostfaecher, Zahlen in Mail-Handles und mehrteilige
Adressen werden nicht in Namen umgedeutet.

Im datensparsamen Diagnoseprotokoll wird nur die Suchmethode gespeichert
(z. B. `SENDER_EMAIL_LOCALPART`), keine Adresse oder Person.

Die reproduzierbaren Tests fuer normale, widerspruechliche, zitierte und
Rollenpostfaecher sind in `tests/rc14-person-discovery.test.mjs`.

Die Sendeschaltflaeche, zwei OK-Dialoge, journalsichere Duplikatsperre,
Pflichtfelder und automatischer Pilot bleiben wie in RC13.

Ein erfolgreicher Offline-Test ist kein Nachweis fuer den echten COMARCH-Lauf.
