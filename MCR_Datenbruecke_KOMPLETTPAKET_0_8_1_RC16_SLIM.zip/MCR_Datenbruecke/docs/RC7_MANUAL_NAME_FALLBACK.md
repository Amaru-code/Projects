# RC7: Manueller Namens-Fallback bei NAME_NONE

**Motivation:** RC6 brach im Echtlauf unter `MAIL_AND_PERSON` ab, obwohl die E-Mail in COMARCH lesbar war; die bestehende Regex-Namenserkennung erkannte keinen Namenshinweis.

**Neue Regel:** Bei keiner automatisch erkannten Person wird KEIN neuer unscharfer Namensparser verwendet. Der Bot verlangt lokal im Konsolenfenster Vorname und Nachname als getrennte Eingaben. Leerwerte, HTML, numerische Kennungen und E-Mail-Adressen werden abgewiesen. Fehlerhafte Eingaben lassen die Abfrage erneut beginnen (maximal fünf Versuche). Der Anwender bestätigt mit `JA`, dass der Name anhand der Original-E-Mail bzw. des Tickets geprüft wurde. `ABBRUCH` stoppt kontrolliert und ohne Versand.

Der anschließende originale Identity-Guard bleibt verpflichtend: nur ein tatsächlich ausgewählter COMARCH-Member mit passendem Namen und (falls in der aktuellen Nachricht explizit vorhanden) passender MercerID ermöglicht die Bearbeitung. Keine Änderung am 11-Präfix-Regelwerk, an den Kategorien, dem Versandjournal, der Weiterleitung oder der produktiven Mappingdatei. Die Diagnose enthält ausschließlich den Status des Namensweges und eine Bestätigungsanzahl, nicht den Namen selbst.

**Datensicherheit:** Wird die aktuelle E-Mail im Nachrichtenverlauf als Text gelesen, aber kein Name erkannt, wird unmittelbar die manuelle Eingabe genutzt, nicht zuerst eine MSG heruntergeladen. Ist der Nachrichteninhalt nicht lesbar, bleibt der sichere MSG-Fallback erhalten. Im fiktiven vierten Testfall werden ausschließlich die Werte Max Mustermann testweise eingespeist; dieser Testzweig ist in jedem echten Lauf abgeschaltet.

**Betrieb:** Start nur aus der installierten MCR_Datenbruecke. RC6 kann als geprüfte Softwarebasis aktualisiert werden, und der Rückweg ist verfügbar. Bestehende `private_data`, Edge-Profil und Sende-/Weiterleitungsjournal bleiben unverändert. Echtgeld-/E-Mail-Versand weiterhin ausschließlich im beaufsichtigten Pilot nach tatsächlicher COMARCH-Prüfung.
