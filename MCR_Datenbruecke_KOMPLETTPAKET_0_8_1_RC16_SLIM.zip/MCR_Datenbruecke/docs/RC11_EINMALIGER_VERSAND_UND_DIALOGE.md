# MCR Datenbruecke 0.8.1-rc.11 – Einmalige Versand-/OK-Klicks

## Originalbefund 23.10.2026

Der kontrollierte RC10-Echtlauf erreichte alle Pflichtfelder, Unterkategorie und Signatur. Der Browser zeigte nach dem Sendeklick die COMARCH-Information „Nachricht gesendet“. Trotzdem stoppte der Bot mit `SEND_UNEXPECTED_EXTRA_DIALOG`, bevor der nachgelagerte Speicher-Nachweis erfolgte. Der Status ist deshalb **SENDUNG_MOEGLICH_ODER_WAHRSCHEINLICH, SPEICHERUNG_NICHT_VERIFIZIERT**, nicht „kein Versand“.

## Korrektur ohne Änderung des Ticket-Inhalts

- Sendetaste: ein einziger vertrauenswürdiger CDP-Klick nach durablem Send-Intent, niemals ein Wiederholungs-Klick.
- Statt HTML-Dialoge per untrusted `element.click()` in kurzen Intervallen anzuklicken, werden eindeutige sichtbare Dialoge zunächst nur gelesen, anschließend einmal pro konkreter Dialoginstanz als angeklickt markiert und danach mit genau einem trusted CDP-Mausklick quittiert.
- Bleibt der gleiche Dialog bei einer verzögerten COMARCH-Antwort sichtbar, wartet der Bot auf dessen Verschwinden – **kein zweiter OK-Klick**.
- Zwei verschiedene reguläre OK-Dialoge werden akzeptiert. Ein dritter **verschiedener** Dialog darf nur dann einmal quittiert werden, wenn sein Text ausdrücklich eine bereits versendete Nachricht bestätigt, z. B. „Nachricht gesendet“. Ein dritter unbekannter Dialog bleibt offen und stoppt sicher.
- Native Browserdialoge verwenden dieselbe Obergrenze und erkennen die zusätzliche ausdrückliche Erfolgsmeldung; ein drittes unbekanntes `confirm` wird niemals automatisch akzeptiert.
- Nach Abschluss der Dialoge sind Verlaufseintragszuwachs bzw. leer gewordener Antworteditor nach vorherigem bestätigtem Versand und das erfolgreiche Speichern weiterhin getrennt nachzuweisen.
- Der Ticket-speichern-Button wird weiterhin exakt einmal vertrauenswürdig geklickt; auch zusätzliche HTML-Speicherdialoge sind nur einmal pro sichtbarer Instanz klickbar.
- Nur ein bestätigter Versand **und** ein bestätigtes Speichern schließen ein Ticket ab; anschließend darf der Runner die nächste Mail auswählen.
- Bei einem bereits begonnenen oder unklaren Versand bleibt der Wiederanlauf blockiert. Der vorhandene Menü-5-Nachweis darf nicht durch die automatische Pre-Action-Freigabe umgangen werden.

## Release-Qualifikation

- Neue Unit-Regression prüft die Dialogbegrenzung, Erfolgsmeldungs-Whitelists, No-Click-on-Unknown und zwei/drei unterschiedliche COMARCH-Meldungen.
- Neue realistische Offline-CDP-Demos pruefen die verzögerte OK-Entfernung, dritte Erfolgsmeldung sowie den unbekannten dritten Dialog, ohne COMARCH-Konto und ohne externe E-Mail.
- Originales RC10-Paket ist hashgebunden als Updatequelle zugelassen. Die alte lokale Installation, Browserprofil, mapping und Laufjournale bleiben unverändert erhalten; der Installer archiviert nur die alte Software.
- Keine historischen Komplettpaket-ZIPs im Auslieferungspaket, um die fruehere Rekursion zu vermeiden.

## Nächster echter Test (noch offen)

RC11 wurde nicht gegen den echten COMARCH-Server ausgeführt. Zuvor den RC10-Piloten **manuell in COMARCH** abgleichen: sichtbar gesendete Antwort, Beschreibung gespeichert, gegebenenfalls das verbliebene OK-Fenster einmal schließen und „Ticket speichern“ einmal auslösen. Nur nach eigener positiver Prüfung Menü 5 mit `VERSAND_UND_SPEICHERUNG_GEPRUEFT` abschließen. **Nicht** `SICHER_KEIN_VERSAND` für einen sichtbar gesendeten Vorgang verwenden. Erst dann mit neuem Ticket fortfahren.
