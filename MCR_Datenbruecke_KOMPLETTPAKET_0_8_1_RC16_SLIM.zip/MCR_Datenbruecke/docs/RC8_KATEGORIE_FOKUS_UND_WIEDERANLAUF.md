# RC8 – COMARCH: Kategorie-Fokus, Unterkategorie, Signatur und sicherer Wiederanlauf

**Version**: `0.8.1-rc.8` • **Quelle**: unverändertes, SHA256-geprüftes RC7-Komplettpaket (`6eaa7eca104ee163ebc7674f8b301cee8668c59d754be48988d0c4802f77b38f`)

## Reproduzierter Fehler und Fix

Im realen RC7-Piloten wurde der Member korrekt gefunden und der Bestandsabgleich bestand. Nach der manuellen Dokumentenkategorie-Auswahl wurde jedoch unmittelbar `FIXED_VERIFY [PHASE DESCRIPTION_AND_FIXED_FIELDS]` gemeldet. Der alte Code las den Kategorienwert, **bevor** der für COMARCH notwendige Fokuswechsel auf das bereits ausgewählte Member-Feld stattfand. Das konnte eine noch nicht übernommene ICEfaces-Autocomplete-Auswahl als Fehler melden.

**RC8-Reihenfolge**, jeweils mit Wert-/DOM-Verifikation und strikt ohne überschreibende Änderung am Member:

1. Zuständigkeit **Second Level**; nur gültige eindeutige Select-Option.
2. Dokumentenkategorie **Allgemeine Schriftwechsel** auswählen. Vorschlag wird durch viewport-geprüften echten CDP-Mausklick ausgewählt, falls eindeutig; alternativ explizit manuell.
3. **Member-Eingabefeld nur anklicken/fokussieren, NICHT schreiben/löschen.** Danach Kategorienwert stabil verifizieren.
4. Freigeschaltete Unterkategorie **Personenschriftwechsel** auswählen; Fokus ins Signaturfeld; Unterkategorie stabil verifizieren.
5. Signatur **INTL01 - Intel Deutschland GmbH** auswählen; eindeutigen Antworteditor fokussieren; Signatur stabil verifizieren.
6. Alle vier festen Felder gleichzeitig gegen die bestehenden Pflichtwerte vergleichen. Erst danach Antworttext setzen; unverändert strikte Identitäts-/Empfänger-/Beschreibungskontrolle.
7. Ein echter Sendeklick nach durablem Send-Intent. **Exakt zwei akzeptierte OK-Dialoge erforderlich** (HTML und/oder Browserdialoge); anschließend bisherigen Verlaufszuwachs/Editorreset sicher nachweisen. Ein unklares Ergebnis wird niemals durch erneutes Senden kompensiert.
8. Ticket speichern, Beschreibung unabhängig verifizieren, im regulären Lauf zum nächsten geeigneten Ticket gehen.

## Weniger Rückfragen – aber kein Risiko für Doppelmail

RC8 hebt `STOP_REVIEW_REQUIRED` bzw. `INTERRUPTED_REVIEW_REQUIRED` automatisch auf, **ausschließlich** wenn gleichzeitig folgende Beweismittel vorliegen: RUN-ID identischer frischer Diagnose-/Steuerdateien; expliziter Fehler in einer Vor-Aktionsphase; exakt 0 bearbeitete Tickets; kein vom Bot protokollierter Sendeklick/Speicherklick/Weiterleitungsklick; Versand- und Weiterleitungsjournal haben **0 offene Absichten**; kein vorheriger Prozess/Lock mehr aktiv. Das bisherige Review wird als `auto_preaction_review_*.json` archiviert und Status `AUTO_REVIEWED_PRE_ACTION_NO_EFFECT` gesetzt. Wenn nur eine Bedingung nicht bestätigt ist, bleibt die gewohnte Menü-5-Sperre erhalten. Alte bestätigte Sendungen bleiben im Ticketjournal ausgeschlossen.

Ein fremder manueller COMARCH-Versand außerhalb des Bots ist durch lokale Bot-Diagnosen nicht beweisbar; der automatisierte Freigabefall belegt nur **keine vom Bot begonnenen irreversiblen Aktionen**.

## Unverändert

Mapping/Excel-Zeilen/TPP, `11`-Fallback nur bei ID_NOT_FOUND, Identität und MercerID, keine E-Mail bei Bestand-Nichttreffer, Weiterleitung an Gutierrez Victor, getrennte Send-/Forward-Journale, Private-Daten, Edge-Profil, alte Laufdaten und geprüfter Software-Rückweg. Release-Kandidat bis zum erfolgreichen beaufsichtigten Echtpilot in COMARCH. Das Update selbst sendet keine Nachricht.
