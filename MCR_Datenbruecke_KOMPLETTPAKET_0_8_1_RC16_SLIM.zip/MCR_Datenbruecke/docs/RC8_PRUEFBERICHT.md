# MCR Datenbruecke 0.8.1 RC8 — Pruefbericht (23.10.2026)

## Auftrag / Fehlerbeobachtung

Der beaufsichtigte RC7-Echtlauf bestaetigte die richtige Zustaendigkeit,
Dokumentenkategorie, Member-Auswahl und Bestandszuordnung, brach jedoch in
`DESCRIPTION_AND_FIXED_FIELDS` mit `FIXED_VERIFY` ab. Die COMARCH-Oberflaeche
uebernimmt das Kategoriefeld erst, wenn das bereits ausgewählte Member-Eingabefeld
**nur fokussiert/angeklickt** wird. Erst danach ist die Unterkategorie bedienbar.

## Umsetzung RC8

1. Nach `Allgemeine Schriftwechsel` mit einem geprueften echten Mausklick ins
   vorhandene Member-Eingabefeld wechseln; dessen Wert unveraendert lassen.
2. Kategorie stabil verifizieren, Unterkategorie `Personenschriftwechsel`
   waehlen und durch Fokuswechsel ins Signaturfeld bestaetigen.
3. Signatur `INTL01 - Intel Deutschland GmbH` waehlen und durch Fokus auf den
   eindeutigen Antworteditor bestaetigen. Alle vier Pflichtfelder erneut pruefen.
4. Bestehende Identitaets-/Empfaenger-/Mapping- und Versandabsichtspruefungen
   beibehalten. Nach genau einem Sendeklick **zwei** OK-Bestaetigungen und
   Versandnachweis verlangen; dann speichern und unabhaengig verifizieren.
5. In Menue 3 bleibt die Obergrenze **ein echtes Ticket**. Erst ein echter
   erfolgreicher Sende-/Speicherpilot schaltet den regulaeren Mehrticketlauf
   (Menue 4) frei.
6. Eine alte `SICHER_KEIN_VERSAND`-Abfrage nur automatisch protokolliert
   entfallen lassen, wenn letzte Run-ID/Diagnose zusammenpassen, die
   Bearbeitung vor dem irreversiblen Versand/Weiterleitungsschritt endete,
   null Tickets bearbeitet wurden, kein Bot-Send-/Save-/Forward-Klick vorliegt,
   keine offenen Journal-Intents existieren und kein alter Prozess aktiv ist.
   Bei Unklarheit verbleibt die Sperre.

## Lokale Abnahme (isolierte fiktive Daten; Node.js 22, Linux/Chromium)

- **Vollstaendige automatisierte Tests: 206 / 206 PASS; 0 FAIL; 0 SKIP.**
- **Offizielle vier fiktive Browser-Szenarien: 4 / 4 PASS** (je zwei Tickets):
  normal, MercerID-Praefix-`11`, Bestands-Nichttreffer mit kontrollierter
  Weiterleitung ohne E-Mail, manuell bestaetigter Personenname.
- **Abhaengige COMARCH-Feldsimulation: PASS.** Die Testoberflaeche uebernimmt
  Kategorie, Unterkategorie und Signatur erst nach dem entsprechenden
  Fokuswechsel. Beide Tickets wurden einschliesslich zwei OK-Bestaetigungen
  und gespeicherter Beschreibung abgeschlossen.
- **RC7→RC8 inkl. intakter Bestandsdaten/Browserprofil/Laufprotokoll und
  Rueckweg: PASS.** Ausgangsrelease ist das originale RC7-ZIP mit SHA256
  `6eaa7eca104ee163ebc7674f8b301cee8668c59d754be48988d0c4802f77b38f`.
- **Automatische Vor-Aktionsfreigabe: PASS**, einschliesslich Negativfaellen
  fuer offene Intents, dokumentierte Klicks, abweichende Run-ID, ungueltige
  Diagnosen, vorhandene alte Prozesse und fremde Sperren.

## Betrieb und Grenzen

**Kein realer COMARCH-Versand in der Entwicklungsumgebung.** Die Windows-
Oberflaeche, echte COMARCH-Berechtigungen, die dortigen Dropdowns und die
realen zwei OK-Dialoge muessen im beaufsichtigten Einzelticket-Piloten
bestaetigt werden. Das Paket ist weiterhin Release Candidate bis zu diesem
Nachweis. Keine automatische Mehrticketfreigabe ohne bestandenen echten
Sende-/Speicherpilot. Der Updatevorgang selbst sendet keine E-Mails.

`private_data`, aktives Mapping, Edge-Profil, vorherige Send-/Forward-Journale
und installierter Software-Rueckweg werden beim Installerupdate nicht geaendert.
Die automatische Vor-Aktionspruefung beweist nur, dass **der Bot** keine
irreversible Aktion angefangen hat; etwaige manuelle COMARCH-Aktionen ausserhalb
des Bots koennen lokale Protokolle nicht ausschliessen.
