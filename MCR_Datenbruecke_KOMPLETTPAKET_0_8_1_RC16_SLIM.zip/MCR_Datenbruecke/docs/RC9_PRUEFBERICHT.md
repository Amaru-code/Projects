# MCR Datenbruecke 0.8.1 RC9 | Feldfokus-Hotfix (23.10.2026)

## Beobachtung im echten RC8-Pilot
Die Dokumentenkategorie wurde nach dem Member-Klick uebernommen, aber die Unterkategorie blieb nach Wechsel zur Signatur unbestaetigt. Dieser Live-Befund hat hoehere Prioritaet als erfolgreiche Demo-Feldsimulationen.

## Aenderung
- Nach Auswahl von `Personenschriftwechsel` wird das **bereits belegte Member-Eingabefeld ausschliesslich per echtem Browserklick fokussiert**. Der Personeneintrag wird weder geloescht noch ueberschrieben.
- Abhaengige Unterkategorie wird stabil geprueft. Ist sie trotz Fokuswechsel nicht uebernommen, erfolgt ein begrenzter alternativer Wechsel ins Signaturfeld. Falls noch immer nicht bestaetigt, erscheint eine konkrete manuelle Korrekturanweisung (Unterkategorie waehlen, nur Member anklicken), gefolgt von erneuter Verifikation. Ohne positive Verifikation kein Versand.
- Danach unveraendert: Signatur `INTL01 - Intel Deutschland GmbH`, Antwort, genau zwei bestaetigte OK-Dialoge, Versandnachweis und Ticket-Speicherung.
- Bestehende Identitaets-, Member-, Mapping-, Weiterleitungs-, Duplikatschutz-, Auto-Review- und Rollback-Regeln unveraendert.

## Abnahme
- Separate COMARCH-UI-Simulation mit `subcategory-member-blur`: Test im echten CDP-Browser ausfuehren.
- Bestehende `field-blur-required`-Simulation weiterhin testen (Signatur-Wechsel als Altverhalten).
- Gesamttests plus vier fiktive Standardszenarien ausfuehren; RC8 -> RC9 Upgrade und Rollback pruefen.

## Grenze
Kein Zugriff auf echte COMARCH-Oberflaeche oder das auf dem Windows-Rechner gespeicherte Diagnose-ZIP. RC9 ist erst nach beaufsichtigtem Echtpilot produktiv qualifiziert. Vor produktivem Start ggf. offene Versandaktivitaeten nach COMARCH pruefen.
