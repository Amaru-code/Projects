# RC15 — Namenssuche + exakt erlaubte Unterkategorie

1. Die bestehenden Namenskandidaten aus aktueller E-Mail-Signatur, Absendername und privater Absenderadresse bleiben bestehen.
2. Ohne erkennbaren DOM-Kandidaten versucht RC15 **automatisch die Original-MSG der konkret angezeigten Nachrichtenzeile** (gleiche `docId`). Erst wenn auch dort kein verlässlicher Name zu erkennen ist, erscheint die manuelle Eingabe.
3. Ableitung aus Mailadressen ist ausschließlich **Suchhinweis**. Die COMARCH-Member-/MercerID-Identitätsprüfung bleibt unverändert. Mehrdeutige oder ungültige Absender werden nicht geraten.
4. Der klickbare Optionsdatensatz der Unterkategorie muss den **vollständigen exakten Text** `Personenschriftwechsel` tragen. `Personenschriftwechsel - potenzieller Haftungsfall` darf **nicht** gewählt werden. Ein übergeordnetes Element mit mehreren Optionslabels wird abgelehnt.
5. Direkt vor dem tatsächlichen Sendeklick werden alle festen Feldwerte ein zweites Mal exakt verglichen. Bereits vorhandene Empfangsbestätigungen bleiben durch `REPLY_ALREADY_IN_HISTORY` geschützt.
6. Bei fehlender eindeutiger Auswahl erfolgt kein blinder Versand. Manuelle Option nur exakter Eintrag und erneute Bestätigung.
7. Testfixture zeigt beide Optionen nebeneinander (falscher Eintrag zuerst); eine alleinige falsche Option blockiert den Versand.

Diese Version wurde offline gegen fiktive Chromium-Tests qualifiziert. Echte COMARCH-Resultate, einschließlich gespeicherter Backend-Unterkategorie, müssen im Windows-Piloten unabhängig geprüft werden.
