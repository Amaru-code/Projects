# MCR Datenbruecke – RC7 | Abschlussprüfung (2026-10-23)

## Änderung und Umfang

`NAME_NONE [PHASE MAIL_AND_PERSON]` ist bei einer in COMARCH lesbaren Originalmail **kein unmittelbarer Programmabbruch mehr**. Erkennt der unveränderte bestehende Parser keinen Personennamen, fragt RC7 manuell nach Vorname, Nachname und ausdrücklicher Bestätigung `JA`. Ungültige, leere oder unbestätigte Eingaben lassen den Bot erneut fragen (maximal fünf Versuche). Der Benutzer kann mit `ABBRUCH` kontrolliert stoppen; vor bestätigtem Namen erfolgt weder Versand noch Weiterleitung.

Die manuelle Eingabe ersetzt niemals den COMARCH-Identitätsnachweis: Der tatsächlich ausgewählte Member muss zum manuell eingegebenen Namen passen; eine ausdrücklich in der aktuellen Nachricht vorhandene MercerID bleibt verbindlich. Das `11`-Fallback-Mapping, aktive Bestandsdaten und die getrennten Send-/Forward-Journale bleiben unverändert. Das Diagnose-ZIP zeichnet nur die Methode `MANUAL_OPERATOR_CONFIRMED` und Bestätigungszähler auf, **keine Namen oder Mailtexte**.

Im vorhandenen DOM-Nachrichtenverlauf wird bei lesbarem Nachrichteninhalt ohne erkannten Namen sofort die manuelle Abfrage ausgelöst. Ist die Nachricht dort nicht lesbar, bleibt der bestehende MSG-Fallback erhalten.

## Lokale Qualifikation (Node 22 / Linux / Chromium)

- **185/185 automatisierte Unit-, Security- und Upgrader-/Rollback-Tests PASS, 0 FAIL, 0 SKIP.** Darunter neue Tests für gültige und ungültige Namenseingaben, Wiederholung, Benutzerabbruch, verweigerte Bestätigung, COMARCH-Namens- und explizite MercerID-Widersprüche.
- **4/4 offizielle fiktive Zwei-Ticket-Szenarien PASS:** normal (2/2 Send+Save), MercerID ohne `11` (2/2 Send+Save), Bestands-Nichttreffer (2/2 Weiterleitung, 0 E-Mail), neuer manueller Name (2/2 Send+Save nach Testbestätigung).
- **Fiktiver Negativfall (Name fünfmal nicht bestätigt): PASS als erwarteter Sicherheitsstopp.** Exit 1, `NAME_MANUAL_NOT_CONFIRMED`, genau **0** Versandklicks und **0** bearbeitete Tickets.
- **RC6 → RC7 Upgrade und Rückweg PASS:** Das veröffentlichte RC6-ZIP `dd69d6a81037345fa5ab8734607d09fde014c60c27b405b852d7dcb8f8f17130` ist Hash-gebunden; Aktivmapping, Browserprofil, Diagnose und vorheriger ungeprüfter Echtlauf bleiben bytegleich, auch nach Rückweg.
- RC7-Browserdemo nutzt fiktive Testdaten. Die Testeingabe `Max Mustermann` erfolgt nur bei `--demo` mit `MCR_DEMO_SCENARIO=manual-name`, **niemals im echten Lauf**.

## Grenzen und Betrieb

Echte COMARCH-Berechtigungen, Scrollpositionen und der erste reale RC7-Pilot konnten in der Entwicklungsumgebung nicht getestet werden. RC7 ist deshalb bis zum **beaufsichtigten Einzelticket-Lauf** ein Release-Kandidat. Unklaren alten Versand-/Weiterleitungsstatus ausschließlich nach COMARCH-Kontrolle über Menü 5 dokumentieren; keinen Blind-Neustart durchführen.

Installation nur mit der vollständigen RC7-ZIP in separatem Download-Ordner, dann `START.cmd` → Menü 1 → `EINRICHTEN`. `private_data`, das ursprüngliche Mapping, Edge-Profil und Versand-/Weiterleitungsjournal bleiben lokal erhalten. Das Update selbst sendet keine echten E-Mails.
