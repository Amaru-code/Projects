# RC16 Slim – Suchstrategie und COMARCH-Pflichtfelder

## Ziel
Soweit eindeutige Informationen vorhanden sind, den Vor- und Nachnamen ohne Eingabe durch den Betreiber als **Suchkandidat** ermitteln. Manuelle Eingabe bleibt bei widersprüchlicher oder nicht auffindbarer Identität möglich. Weder automatische Namenssuche noch irgendein Leseversuch hebt die Identitätsprüfung im tatsächlich ausgewählten COMARCH-Member oder eine explizite MercerID auf.

## Read-only-Suchläufe (Budget bis 100 Prüfungen je Ticket)
- Lesende Abfragen zum aktuellen Nachrichtenverlauf, durch verifizierte Spaltennamen statt feste Zellpositionen.
- Zwei unabhängige Absenderfelder, jeweils kombiniert und einzeln, sowie die aktuelle Signatur, beschriftete Namenszeilen, Einleitung („Mein Name ist …“, „Ich bin …“), einzeilige Grußformeln und Text mit HTML-Zeilenumbrüchen.
- Bei Bedarf drei zeitlich versetzte Beobachtungen derselben Originalnachricht.
- Bei lesbarem originalen Dokument-Identifier alternative MSG-Verarbeitung mit gebundenem Betreff und zwei authentifizierten, nur lesenden Download-Versuchen; keine Downloads von fremden Tickets.
- Pro Prüfmethode wird im lokalen Diagnosebericht nur Methoden-ID, Ergebniscode und Kandidatenzahl gespeichert. **Keine Namen, E-Mail-Adressen, Nachrichteninhalte oder MercerIDs** in der Diagnose.
- Höchstens 100 reine Daten-/Suchprüfungen. Die Anzahl tatsächlich sinnvoller Strategien ist geringer; wir wiederholen nicht blind 100-mal eine fehlgeschlagene Methode. Keine zusätzlichen Send-/Speicher- oder Weiterleitungsklicks.

## Pflichtfelder
- Die Sollwerte bleiben unverändert: Second Level; Allgemeine Schriftwechsel; **ausschließlich Personenschriftwechsel**; INTL01 - Intel Deutschland GmbH.
- Vor jeder Auswahl zunächst exakte Gleichheit mit dem bereits ausgefüllten Feld prüfen. Bestehende korrekte Auswahl **nicht neu auswählen oder überschreiben**.
- Nur einen eindeutig passenden echten COMARCH-Vorschlag per Browserklick auswählen. Ein bloß eingetippter String ist keine sichere Optionsauswahl. Haftungsfall-Varianten werden abgewiesen.
- Unterkategorie über das bereits belegte Member-Feld nur fokussieren; Signatur bei Bedarf über eine endliche Reihe alternativer Fokuswechsel zum Antworttext und Member verifizieren. Keine Bestätigungsdialoge für bereits korrekt verifizierte Pflichtfelder.
- Vor Versand alle Pflichtfelder und die gebundene Person unabhängig erneut vergleichen. Beim Fehlschlag stoppt der Bot ohne Versand.

## Grenzen
Alle Tests laufen gegen eine fiktive Chromium/COMARCH-Oberfläche; ein erfolgreicher Realbetrieb ist damit nicht garantiert. Die tatsächliche Original-MSG kann abhängig von COMARCH-Rechten, Browserkonfiguration und serverseitigem AJAX fehlen. Kein automatischer Neustart nach unklarem Versandstatus; ein bereits im Verlauf vorhandener Antworttext darf niemals doppelt verschickt werden.
