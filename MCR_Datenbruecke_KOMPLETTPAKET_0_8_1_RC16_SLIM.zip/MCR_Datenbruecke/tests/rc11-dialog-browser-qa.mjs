/** Offline CDP evidence: the same AJAX modal may stay visible, a success
 * information dialog can be the third distinct dialog, but unknown extra
 * dialogs MUST remain unclicked. Every send/save action stays exactly once.
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {fileURLToPath} from 'node:url';import {spawn} from 'node:child_process';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
async function scenario(name,expectedOK){
 const d=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC11-DialogQA-'));
 try{
  for(const f of ['lib','src','examples','config'])fs.cpSync(path.join(root,f),path.join(d,f),{recursive:true});
  const c=JSON.parse(fs.readFileSync(path.join(d,'config/local-runner-queue-send.json'),'utf8'));
  Object.assign(c,{runtimeDirectory:'.runtime',profileDirectory:'.runtime/edge-profile',downloadDirectory:'.runtime/downloads',diagnosticDirectory:'diagnostics'});
  fs.writeFileSync(path.join(d,'config/local-runner-queue-send.json'),JSON.stringify(c,null,2)+'\n');
  const run=await new Promise((resolve,reject)=>{
   const env={...process.env,MCR_DEMO_SCENARIO:name};delete env.NODE_OPTIONS;delete env.NODE_PATH;
   const child=spawn(process.execPath,[path.join(d,'src/local-bot-full-run.mjs'),'--demo','--close-browser'],{cwd:d,env,stdio:['ignore','pipe','pipe']});let out='';
   for(const stream of [child.stdout,child.stderr])stream.on('data',bytes=>{out+=bytes.toString('utf8');if(out.length>100000)out=out.slice(-100000);});
   const timer=setTimeout(()=>child.kill('SIGKILL'),90000);
   child.once('error',reject);child.once('exit',(code,signal)=>{clearTimeout(timer);resolve({code,signal,out});});
  });
  const diag=JSON.parse(fs.readFileSync(path.join(d,'diagnostics/last-result.json'),'utf8'));
  if(expectedOK){
   assert.equal(run.code,0,`${name} failed: ${run.out.slice(-1800)}`);
   assert.equal(diag.lastError,null);
   assert.equal(diag.loop.processed,2);
   assert.equal(diag.demoBrowser.sendClicks,2);
   assert.equal(diag.demoBrowser.saveClicks,2);
   assert.deepEqual(diag.demoBrowser.trustedSends,[true,true]);
   assert.deepEqual(diag.demoBrowser.trustedSaves,[true,true]);
   assert.equal(diag.demoBrowser.okClicks,name==='send-third-success'?6:4);
   assert.equal(diag.demoBrowser.trustedOkClicks.every(Boolean),true);
   assert.equal(diag.send.htmlDialogs,name==='send-third-success'?3:2);
   assert.equal(diag.send.jsDialogs,0);
   if(name==='send-sticky-ok')assert.ok(diag.send.htmlPendingWaits>0,'Same dialog was not held while the server was slow');
   if(name==='send-third-success')assert.equal(diag.send.successNotices,1);
   console.log('PASS RC11 '+name+' SEND_ONCE ACK_ONCE SAVE_ONCE');
  }else{
   assert.equal(run.code,1,run.out.slice(-1000));
   assert.equal(diag.lastError,'SEND_UNEXPECTED_EXTRA_DIALOG');
   assert.equal(diag.send.clicked,true);
   assert.equal(diag.send.htmlDialogs,2,'Third unknown OK was not clicked');
   assert.equal(diag.send.verified,false);
   assert.equal(diag.save.clicked,false,'No save after unknown dialog');
   assert.equal(diag.loop.processed,0);
   console.log('PASS RC11 '+name+' EXTRA_UNKNOWN_UNCLICKED NO_RESEND');
  }
 }finally{fs.rmSync(d,{recursive:true,force:true,maxRetries:5,retryDelay:150});}
}
const cases=[['normal',true],['send-sticky-ok',true],['send-third-success',true],['send-third-unknown',false]];
const select=process.env.MCR_RC11_SCENARIOS?.split(',').filter(Boolean);
for(const [name,ok] of cases)if(!select||select.includes(name))await scenario(name,ok);
