import fs from 'node:fs';import path from 'node:path';import os from 'node:os';
import {fileURLToPath} from 'node:url';import {spawn} from 'node:child_process';import assert from 'node:assert/strict';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
for(const scenario of ['subcategory-liability-first','subcategory-liability-only'].filter(s=>!process.env.MCR_RC15_ONLY_SCENARIO||s===process.env.MCR_RC15_ONLY_SCENARIO)){
 const d=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC15-ExactSubcategory-'));
 try{
  for(const folder of ['src','lib','config','examples'])fs.cpSync(path.join(root,folder),path.join(d,folder),{recursive:true});
  const config=path.join(d,'config/local-runner-queue-send.json');const cfg=JSON.parse(fs.readFileSync(config,'utf8'));
  Object.assign(cfg,{runtimeDirectory:'.runtime',profileDirectory:'.runtime/edge-profile',downloadDirectory:'.runtime/downloads',diagnosticDirectory:'diagnostics'});
  fs.writeFileSync(config,JSON.stringify(cfg,null,2)+'\n');
  const result=await new Promise((resolve,reject)=>{
   const env={...process.env,MCR_DEMO_SCENARIO:scenario};delete env.NODE_OPTIONS;delete env.NODE_PATH;
   const ch=spawn(process.execPath,[path.join(d,'src/local-bot-full-run.mjs'),'--demo','--close-browser'],{cwd:d,env,stdio:'inherit'});
   const timer=setTimeout(()=>ch.kill(),105000);ch.on('error',reject);ch.on('exit',(code,signal)=>{clearTimeout(timer);resolve({code,signal});});
  });
  const diag=JSON.parse(fs.readFileSync(path.join(d,'diagnostics/last-result.json'),'utf8'));
  if(scenario==='subcategory-liability-first'){
   assert.equal(result.code,0);assert.equal(diag.loop.processed,2);
   assert.deepEqual(diag.demoBrowser.selectedSubcategoryLabels,['Personenschriftwechsel','Personenschriftwechsel']);
   assert.equal(diag.demoBrowser.sendClicks,2);assert.equal(diag.demoBrowser.saveClicks,2);
   console.log('PASS RC15_EXACT_ONLY_WITH_LIABILITY_SIBLING_2_SEND_2_SAVE');
  }else{
   assert.notEqual(result.code,0);assert.ok(['DEMO_FIXED_FIELD','FIXED_OPTION_NOT_FOUND'].includes(diag.lastError));
   assert.equal(diag.send.clicked,false);assert.equal(diag.loop.processed,0);
   console.log('PASS RC15_LIABILITY_ONLY_BLOCKED_BEFORE_SEND');
  }
 }finally{fs.rmSync(d,{recursive:true,force:true,maxRetries:3});}
}
