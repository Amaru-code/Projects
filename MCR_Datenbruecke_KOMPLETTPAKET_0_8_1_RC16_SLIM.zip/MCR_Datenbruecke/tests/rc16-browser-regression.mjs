/** Explicit RC16 QA. Not a runtime selftest (it launches 3 separate Chromium
 * profiles); runs only in development qualification. */
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';
import {fileURLToPath} from 'node:url';import {spawn} from 'node:child_process';import assert from 'node:assert/strict';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
for(const scenario of ['rc16-preselected-fields','rc16-signature-member-commit','rc16-self-introduction']){
 const temp=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC16-Browser-'));
 try{
  for(const dir of ['src','lib','config','examples'])fs.cpSync(path.join(root,dir),path.join(temp,dir),{recursive:true});
  const file=path.join(temp,'config/local-runner-queue-send.json');const cfg=JSON.parse(fs.readFileSync(file,'utf8'));
  Object.assign(cfg,{runtimeDirectory:'.runtime',profileDirectory:'.runtime/edge-profile',downloadDirectory:'.runtime/downloads',diagnosticDirectory:'diagnostics'});
  fs.writeFileSync(file,JSON.stringify(cfg,null,2)+'\n');
  const code=await new Promise((resolve,reject)=>{
   const ch=spawn(process.execPath,[path.join(temp,'src/local-bot-full-run.mjs'),'--demo','--close-browser'],{cwd:temp,env:{...process.env,MCR_DEMO_SCENARIO:scenario},stdio:['ignore','pipe','pipe']});
   let out='';const record=d=>{out+=d.toString();if(out.length>100000)out=out.slice(-50000);};
   ch.stdout.on('data',record);ch.stderr.on('data',record);
   const deadline=setTimeout(()=>{ch.kill();},120000);
   ch.once('error',reject);ch.once('exit',(code,signal)=>{clearTimeout(deadline);console.log('QA '+scenario+' exit='+code+' signal='+signal);console.log(out.slice(-2400));resolve(code??1);});
  });
  const diag=JSON.parse(fs.readFileSync(path.join(temp,'diagnostics/last-result.json'),'utf8'));
  assert.equal(code,0);assert.equal(diag.loop.processed,2);assert.equal(diag.demoBrowser.sendClicks,2);assert.equal(diag.demoBrowser.saveClicks,2);
  assert.equal(diag.lastError,null);assert.equal(diag.manualNameConfirmations,0);
  if(scenario==='rc16-preselected-fields'){
   for(const id of ['mainForm:category-value-id','mainForm:category-sub-value-id','mainForm:signature-value-id'])assert.equal(diag.demoBrowser.fixedOptionClicks[id]??0,0,id);
   assert.ok(diag.fixedFieldResolution.some(x=>x.field==='signature'&&x.action==='ALREADY_EXACT'));
  }
  if(scenario==='rc16-signature-member-commit')assert.ok(diag.demoBrowser.fixedCommitSteps.includes('SIGNATURE_MEMBER_BLUR'));
  if(scenario==='rc16-self-introduction')assert.equal(diag.personSource,'CURRENT_EXPLICIT_NAME');
  assert.equal(diag.nameDiscovery.successfulSource,'HISTORY_DOM_CURRENT');
  console.log('PASS RC16_'+scenario.toUpperCase().replaceAll('-','_')+'_TWO_TICKETS');
 }finally{fs.rmSync(temp,{recursive:true,force:true,maxRetries:3});}
}
