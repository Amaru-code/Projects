/** Two real CDP-trusted send/save interactions in a browser fixture
 * where the mail body has NO name and only sender email first.last exists. */
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';
import {fileURLToPath} from 'node:url';import {spawn} from 'node:child_process';
import assert from 'node:assert/strict';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
for(const scenario of ['auto-name-email','auto-name-header']){
 const d=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC14-AutoName-'));
 try{
  for(const folder of ['src','lib','config','examples'])fs.cpSync(path.join(root,folder),path.join(d,folder),{recursive:true});
  const file=path.join(d,'config/local-runner-queue-send.json');
  const cfg=JSON.parse(fs.readFileSync(file,'utf8'));
  Object.assign(cfg,{runtimeDirectory:'.runtime',profileDirectory:'.runtime/edge-profile',downloadDirectory:'.runtime/downloads',diagnosticDirectory:'diagnostics'});
  fs.writeFileSync(file,JSON.stringify(cfg,null,2)+'\n');
  const r=await new Promise((resolve,reject)=>{
   const env={...process.env,MCR_DEMO_SCENARIO:scenario};delete env.NODE_OPTIONS;delete env.NODE_PATH;
   const child=spawn(process.execPath,[path.join(d,'src/local-bot-full-run.mjs'),'--demo','--close-browser'],{cwd:d,env,stdio:'inherit'});
   const tm=setTimeout(()=>child.kill(),105000);
   child.once('error',reject);child.once('exit',(code,signal)=>{clearTimeout(tm);resolve({code,signal});});
  });
  const diag=JSON.parse(fs.readFileSync(path.join(d,'diagnostics/last-result.json'),'utf8'));
  assert.equal(r.code,0);assert.equal(diag.lastError,null);
  assert.equal(diag.loop.processed,2);assert.equal(diag.manualNameConfirmations,0);
  assert.equal(diag.personSource,scenario==='auto-name-email'?'SENDER_EMAIL_LOCALPART':'SENDER_DISPLAY');
  assert.deepEqual(diag.demoBrowser.trustedSends,[true,true]);
  assert.deepEqual(diag.demoBrowser.trustedSaves,[true,true]);
  assert.equal(diag.demoBrowser.sendClicks,2);assert.equal(diag.demoBrowser.saveClicks,2);
  console.log('PASS RC14_'+scenario+'_2_TICKETS_NO_MANUAL_NAME');
 }finally{fs.rmSync(d,{recursive:true,force:true,maxRetries:5,retryDelay:150});}
}
