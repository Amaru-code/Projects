import test from 'node:test';
import assert from 'node:assert/strict';
import {suggestionPoints} from '../lib/browser-workflow.mjs';

// Minimal deterministic DOM for the serialized page.call function. No actual
// COMARCH data or browser credentials are touched by these unit tests.
async function synthetic({rects=[{left:-900,right:180,top:115,bottom:142}],
    visibleHit=true,duplicate=false,containsField=false,category=false,clickOnly=false}={}){
 const previous={document:globalThis.document,innerWidth:globalThis.innerWidth,innerHeight:globalThis.innerHeight};
 const fieldRect={left:20,right:240,top:80,bottom:110};
 const document={defaultView:{getComputedStyle:()=>({display:'block',visibility:'visible',pointerEvents:'auto'})}};
 const field={id:'mainForm:member-value-id',isConnected:true,getClientRects:()=>[fieldRect],getBoundingClientRect:()=>fieldRect};
 function makeTarget(second=false){return {
  tagName:'DIV',isConnected:true,onmousedown:clickOnly?null:()=>{},onclick:clickOnly?()=>{}:null,
  innerText:category?'Allgemeine Schriftwechsel':'Mustermann Max (INTL01-99900001)',
  getClientRects:()=>second?[{left:-900,right:180,top:155,bottom:182}]:rects,getBoundingClientRect:()=>second?{left:-900,right:180,top:155,bottom:182}:rects[0],
  ownerDocument:document,getAttribute:()=>null,parentElement:null,
  contains(n){return containsField&&n===field;}
 };}
 const target=makeTarget(),other=duplicate?makeTarget(true):null;
 document.getElementById=id=>id===field.id?field:null;
 document.querySelectorAll=()=>other?[target,other]:[target];
 document.elementFromPoint=(x,y)=>{if(!visibleHit)return null;const r=rects[0];if(duplicate&&x>=0&&x<=180&&y>=155&&y<=182)return other;return rects.some(r=>x>=Math.max(0,r.left)&&x<=Math.min(500,r.right)&&y>=Math.max(0,r.top)&&y<=Math.min(350,r.bottom))?target:null;};
 globalThis.document=document;globalThis.innerWidth=500;globalThis.innerHeight=350;
 try{return await suggestionPoints({call:(fn,...args)=>Promise.resolve(fn(...args))},field.id,
  category?['Allgemeine Schriftwechsel']:['Mustermann Max','Max Mustermann'],{member:!category});}
 finally{for(const [key,value] of Object.entries(previous)){if(value===undefined)delete globalThis[key];else globalThis[key]=value;}}
}

test('partly off-viewport suggestion: valid clipped visible point, not negative center',async()=>{
 const points=await synthetic();assert.equal(points.length,1);
 assert.ok(points[0].x>=0&&points[0].y>=0&&points[0].x<500&&points[0].y<350);
 assert.equal(points[0].id,'99900001');
});
test('fully off-viewport suggestion produces no automatic click point',async()=>{
 assert.deepEqual(await synthetic({rects:[{left:-190,right:-2,top:115,bottom:142}]}),[]);
});
test('occluded suggestion produces no automatic click point',async()=>{
 assert.deepEqual(await synthetic({visibleHit:false}),[]);
});
test('autocomplete form/field container cannot be clicked as suggestion',async()=>{
 assert.deepEqual(await synthetic({containsField:true}),[]);
});
test('nonfinite rectangle is ignored instead of passing a NaN click coordinate',async()=>{
 assert.deepEqual(await synthetic({rects:[{left:NaN,right:120,top:115,bottom:142}]}),[]);
});
test('category autocomplete reuses the same clipped hit-test policy',async()=>{
 const points=await synthetic({category:true});assert.equal(points.length,1);assert.ok(points[0].x>=0);
});
test('suggestion points are never outside viewport even for huge parent rect',async()=>{
 const pts=await synthetic({rects:[{left:-9000,right:3000,top:-50,bottom:160}]});
 assert.equal(pts.length,1);assert.ok(pts[0].x>=0&&pts[0].x<=500&&pts[0].y>=0&&pts[0].y<=350);
});

test('two distinct, visible autocomplete candidates remain ambiguous for automatic selection',async()=>{
 const p=await synthetic({duplicate:true});assert.equal(p.length,2);assert.equal(p[0].id,'99900001');assert.equal(p[1].id,'99900001');
});

test('category suggestions with click-only handlers are safely selectable',async()=>{const points=await synthetic({category:true,clickOnly:true});assert.equal(points.length,1);assert.ok(points[0].x>=0);});
