/** Published RC12 ZIP -> RC13 software-only upgrade with intact identity, mapping and state. */
import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';
import {ROOT,temp,putActive,historyFixture} from './helpers.mjs';
import {sha256} from '../lib/core.mjs';import {readZip} from '../lib/zip.mjs';
import {verifyPackage,verifyPrevious,treeDigest} from '../tools/integrity.mjs';
import {planInstall,installSoftware,journals,restoreSoftware} from '../tools/deploy.mjs';
import {VERSION} from '../lib/control.mjs';
const ZIP=historyFixture('complete-0.8.1-rc.12.zip');
const RC12_SHA='1645f41df158c963cd35c9498fc26b90ea90db96d57e1eba5a50335326f3028b';
test('original RC12 slim ZIP is pinned, RC12 -> RC13 preserves mapping/profile, interrupted run and rollback',()=>{
 assert.equal(sha256(ZIP),RC12_SHA);
 const parent=temp(),target=path.join(parent,'MCR_Datenbruecke');fs.mkdirSync(target);
 try{
  const zip=readZip(ZIP);
  for(const name of zip.names){assert.ok(name.startsWith('MCR_Datenbruecke/'));const rel=name.slice('MCR_Datenbruecke/'.length),f=path.join(target,rel);fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,zip.get(name));}
  putActive(target);const profile=path.join(target,'.runtime/edge-profile');fs.mkdirSync(profile,{recursive:true});fs.writeFileSync(path.join(profile,'profile.sentinel'),'DO_NOT_MODIFY');
  const ctrl=path.join(target,'.runtime/beta-control');fs.mkdirSync(ctrl,{recursive:true});fs.writeFileSync(path.join(ctrl,'last-run.json'),JSON.stringify({schema:'MCR_BETA_RUN_V1',state:'INTERRUPTED_REVIEW_REQUIRED',operation:'REAL_RUN'})+'\n');
  const diagnostic=path.join(target,'diagnostics');fs.mkdirSync(diagnostic);fs.writeFileSync(path.join(diagnostic,'receipt.sentinel'),'DO_NOT_MODIFY');
  const before={mapping:treeDigest(path.join(target,'private_data')),profile:treeDigest(profile),run:sha256(fs.readFileSync(path.join(ctrl,'last-run.json'))),diagnostic:treeDigest(diagnostic)};
  const preserved=()=>{
   assert.equal(treeDigest(path.join(target,'private_data')),before.mapping);
   assert.equal(treeDigest(profile),before.profile);
   assert.equal(sha256(fs.readFileSync(path.join(ctrl,'last-run.json'))),before.run);
   assert.equal(treeDigest(diagnostic),before.diagnostic);
  };
  assert.equal(verifyPrevious(target).version,'0.8.1-rc.12');
  const plan=planInstall(ROOT,target);const r=installSoftware(plan,{guard:()=>{}});
  assert.equal(r.state,'COMPLETE');assert.equal(verifyPackage(target).version,VERSION);preserved();
  const rollback=restoreSoftware(journals(target)[0]);assert.equal(rollback.state,'ROLLED_BACK');assert.equal(verifyPrevious(target).version,'0.8.1-rc.12');preserved();
 }finally{fs.rmSync(parent,{recursive:true,force:true,maxRetries:2});}
});
