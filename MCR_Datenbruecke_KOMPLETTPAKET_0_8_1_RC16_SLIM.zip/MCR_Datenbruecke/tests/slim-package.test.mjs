import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';
import {ROOT} from './helpers.mjs';
import {verifyPackage} from '../tools/integrity.mjs';
import {sha256} from '../lib/core.mjs';
import {VERSION} from '../lib/control.mjs';
test('release has no recursively embedded historical complete package ZIPs',()=>{
 const root=path.join(ROOT,'tests','fixtures');
 const remaining=fs.readdirSync(root).filter(n=>/^complete-0\.8\.1-rc\.\d+\.zip$/.test(n));
 assert.deepEqual(remaining,[]);
 assert.equal(verifyPackage(ROOT).version,VERSION);
});
test('old published RC9 manifest is pinned for upgrade validation',()=>{
 const r=JSON.parse(fs.readFileSync(path.join(ROOT,'tools/reference/complete-0.8.1-rc.9-manifest.json'),'utf8'));
 assert.equal(r.version,'0.8.1-rc.9');
 const bytes=fs.readFileSync(path.join(ROOT,'tools/reference/complete-0.8.1-rc.9-manifest.json'));
 assert.equal(sha256(bytes),'949b766eae902f8752b81e49cf3f7bd61d536d46bfd5e0bf0e04d03ea66134d4');
});
