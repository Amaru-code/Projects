/** Dedicated realistic offline fixture: COMARCH dropdown values only commit
 * on blur (category -> member, subcategory -> signature, signature -> editor).
 * Execute: node tests/rc9-browser-qa.mjs
 * No COMARCH account, recipient or live data is read or used.
 */
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const d=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC9-MemberBlurQA-'));
try{
 for(const dir of ['src','lib','config','examples'])fs.cpSync(path.join(root,dir),path.join(d,dir),{recursive:true});
 const cfg=JSON.parse(fs.readFileSync(path.join(d,'config/local-runner-queue-send.json'),'utf8'));
 cfg.runtimeDirectory='.runtime';cfg.profileDirectory='.runtime/edge-profile';cfg.downloadDirectory='.runtime/downloads';cfg.diagnosticDirectory='diagnostics';
 fs.writeFileSync(path.join(d,'config/local-runner-queue-send.json'),JSON.stringify(cfg,null,2)+'\n');
 const r=await new Promise((resolve,reject)=>{
  const env={...process.env,MCR_DEMO_SCENARIO:'subcategory-member-blur'};delete env.NODE_OPTIONS;delete env.NODE_PATH;
  const child=spawn(process.execPath,[path.join(d,'src/local-bot-full-run.mjs'),'--demo','--close-browser'],{cwd:d,env,stdio:'inherit'});
  const timeout=setTimeout(()=>child.kill(),120000);
  child.once('error',reject);child.once('exit',(code,signal)=>{clearTimeout(timeout);resolve({code,signal});});
 });
 assert.equal(r.code,0,'Fiktives Blur-Szenario wurde nicht abgeschlossen');
 const diag=JSON.parse(fs.readFileSync(path.join(d,'diagnostics/last-result.json'),'utf8'));
 assert.equal(diag.lastError,null);assert.equal(diag.loop.processed,2);
 assert.equal(diag.demoBrowser.sendClicks,2);assert.equal(diag.demoBrowser.saveClicks,2);
 assert.deepEqual(diag.demoBrowser.fixedCommitSteps,Array.from({length:2},()=>[
  'CATEGORY_MEMBER_BLUR','SUBCATEGORY_MEMBER_BLUR','SIGNATURE_EDITOR_BLUR']).flat());
 assert.equal(diag.send.htmlDialogs+diag.send.jsDialogs,2);
 console.log('PASS RC9_REAL_UI_CATEGORY_MEMBER_BLUR_SUBCATEGORY_MEMBER_BLUR_SIGNATURE_EDITOR_2xOK_SAVE');
}finally{fs.rmSync(d,{recursive:true,force:true,maxRetries:6,retryDelay:150});}
