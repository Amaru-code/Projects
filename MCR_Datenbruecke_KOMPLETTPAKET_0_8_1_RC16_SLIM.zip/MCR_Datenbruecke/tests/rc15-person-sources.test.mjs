import test from 'node:test';
import assert from 'node:assert/strict';
import P from '../lib/person-quoted.cjs';

test('RC15 COMARCH From: Martin Freibothe (address) generates one candidate',()=>{
 const found=P.candidates({subject:'',body:'Guten Tag, bitte helfen Sie.',senderName:'Von: Martin Freibothe (martin.freibothe@intel.com)',senderEmail:''});
 assert.equal(found.length,1);assert.equal(found[0].firstName,'Martin');assert.equal(found[0].lastName,'Freibothe');
});
test('RC15 display name surname, first and strict email converge',()=>{
 const found=P.candidates({subject:'',body:'Bitte bearbeiten.',senderName:'Freibothe, Martin <martin.freibothe@intel.com>'});
 assert.equal(found.length,1);assert.equal(found[0].firstName,'Martin');assert.equal(found[0].lastName,'Freibothe');
});
test('RC15 role mailbox with display text is not silently a human name',()=>{
 const found=P.candidates({subject:'',body:'Bitte bearbeiten.',senderName:'Von: Support Team (support.team@intel.com)'});
 assert.equal(found.length,0);
});
