import test from 'node:test';
import assert from 'node:assert/strict';
import P from '../lib/person-quoted.cjs';
import I from '../lib/identity-evidence.cjs';
const base={subject:'Re: Anfrage',body:'Hallo, bitte helfen Sie mir. Vielen Dank.'};
test('RC14 current sender address first.last yields COMARCH search hint without manual gate',()=>{
 const found=P.candidates({...base,senderEmail:'sovan.biswas@intel.com'});
 assert.equal(found.length,1);assert.equal(found[0].firstName,'Sovan');assert.equal(found[0].lastName,'Biswas');
 assert.deepEqual(found[0].sources,['Absender-E-Mail (Suchhinweis)']);
});
test('RC14 COMARCH history From display plus address merges provenance once',()=>{
 const a=P.candidates({...base,senderName:'Sovan Biswas <sovan.biswas@intel.com>',senderEmail:'Sovan Biswas <sovan.biswas@intel.com>'});
 assert.equal(a.length,1);assert.ok(a[0].sources.includes('Absender-Anzeigename'));assert.ok(a[0].sources.includes('Absender-E-Mail (Suchhinweis)'));
});
test('RC14 MSG senderName wins even without parseable email',()=>{
 const a=P.candidates({...base,senderName:'Sovan Biswas',senderEmail:'s.b@example.invalid'});
 assert.equal(a.length,1);assert.equal(a[0].firstName,'Sovan');assert.equal(a[0].lastName,'Biswas');
});
test('RC14 current signature is preferred as explicit signed name hint',()=>{
 const a=P.candidates({...base,body:'Guten Tag\n\nViele Grüße\nSovan Biswas',senderEmail:'sovan.biswas@intel.com'});
 assert.equal(a.length,1);assert.ok(a[0].sources.includes('Signatur'));assert.ok(a[0].sources.includes('Absender-E-Mail (Suchhinweis)'));
});
test('RC14 role addresses, numeric handles, multi-part aliases and quoted headers do not invent a person',()=>{
 for(const senderEmail of ['support.team@intel.com','no.reply@intel.com','info@intel.com','sovan123.biswas@intel.com','sovan.biswas77@intel.com','sovan.middle.biswas@intel.com','max@intel.com','max.mustermann+help@intel.com','noreply@intel.com'])
  assert.deepEqual(P.candidates({...base,senderEmail}),[],senderEmail);
});
test('RC14 distinct conflicting names remain separate and cannot silently merge',()=>{
 const a=P.candidates({...base,body:'Name: Erika Musterfrau',senderEmail:'sovan.biswas@intel.com'});
 assert.equal(a.length,2);assert.notEqual(a[0].lastName,a[1].lastName);
});
test('RC14 email-derived name cannot bypass COMARCH identity or current explicit MercerID',()=>{
 const p=P.candidates({...base,senderEmail:'sovan.biswas@intel.com'})[0];
 assert.throws(()=>I.requireMatched({id:'99900001',source:'PROFILE_ROWS',firstName:'Andere',lastName:'Person'},p,{}),{code:'MEMBER_NAME_MISMATCH'});
 assert.throws(()=>I.requireMatched({id:'99900001',source:'PROFILE_ROWS',firstName:'Sovan',lastName:'Biswas'},p,{expectedId:'11122233'}),{code:'MEMBER_ID_CONFLICT'});
 assert.equal(I.requireMatched({id:'99900001',source:'PROFILE_ROWS',firstName:'Sovan',lastName:'Biswas'},p,{}),true);
});
test('RC14 quoted-only candidates still request operator review',()=>{
 const a=P.candidates({...base,body:'> Mit freundlichen Grüßen\n> Sovan Biswas'});
 assert.equal(a.length,1);assert.equal(a[0].quotedOnly,true);
});
