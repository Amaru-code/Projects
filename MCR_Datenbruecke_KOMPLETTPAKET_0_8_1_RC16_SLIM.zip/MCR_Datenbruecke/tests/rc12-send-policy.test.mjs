import test from 'node:test';import assert from 'node:assert/strict';
import {acknowledgementAlreadyInHistory} from '../lib/browser-workflow.mjs';
import Prep from '../lib/ticket-prep.cjs';
const reply=Prep.replyText('Herr','Mustermann');
const table={tHead:{textContent:'Original Von An Betreff Inhalt Datum'},tBodies:[{rows:[{textContent:'An name@example.invalid '+reply}]}]};
const fakeDoc={querySelectorAll:(q)=>q==='table'?[table]:[]};
const page={call:async(fn,...args)=>fn(...args)};
async function withDocument(doc,callback){const original=globalThis.document;globalThis.document=doc;try{return await callback();}finally{if(original===undefined)delete globalThis.document;else globalThis.document=original;}}
test('RC12: an already-visible acknowledgement in ticket history blocks a repeat send',async()=>withDocument(fakeDoc,async()=>{
 assert.equal(await acknowledgementAlreadyInHistory(page,reply),true);
}));
test('RC12: unrelated history content does not count as the same acknowledgement',async()=>withDocument({querySelectorAll:q=>q==='table'?[{tHead:{textContent:'Original Von An Betreff Inhalt Datum'},tBodies:[{rows:[{textContent:'Eine andere Nachricht'}]}]}]:[]},async()=>{
 assert.equal(await acknowledgementAlreadyInHistory(page,reply),false);
}));
test('RC12: exact subcategory is Personenschriftwechsel only',()=>{
 assert.equal(Prep.FIXED.subcategory,'Personenschriftwechsel');
 assert.equal(Prep.FIXED.category,'Allgemeine Schriftwechsel');
 assert.equal(Prep.FIXED.signature,'INTL01 - Intel Deutschland GmbH');
});
