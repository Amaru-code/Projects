/** RC12 browser proof: fixed-field suggestions only exist after isTrusted
 * keyup, as on a legacy JSF/ICEfaces form. Manual gates are unavailable in
 * demo mode. All three exact values must be selected exactly once per ticket.
 */
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';
import {fileURLToPath} from 'node:url';import {spawn} from 'node:child_process';
import assert from 'node:assert/strict';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const d=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC12-TrustedKeyup-'));
try{
 for(const folder of ['src','lib','config','examples'])fs.cpSync(path.join(root,folder),path.join(d,folder),{recursive:true});
 const cfg=JSON.parse(fs.readFileSync(path.join(d,'config/local-runner-queue-send.json'),'utf8'));
 Object.assign(cfg,{runtimeDirectory:'.runtime',profileDirectory:'.runtime/edge-profile',downloadDirectory:'.runtime/downloads',diagnosticDirectory:'diagnostics'});
 fs.writeFileSync(path.join(d,'config/local-runner-queue-send.json'),JSON.stringify(cfg,null,2)+'\n');
 const r=await new Promise((resolve,reject)=>{
  const env={...process.env,MCR_DEMO_SCENARIO:'trusted-keyup-only'};delete env.NODE_OPTIONS;delete env.NODE_PATH;
  const child=spawn(process.execPath,[path.join(d,'src/local-bot-full-run.mjs'),'--demo','--close-browser'],{cwd:d,env,stdio:'inherit'});
  const timeout=setTimeout(()=>child.kill(),120000);
  child.once('error',reject);child.once('exit',(code,signal)=>{clearTimeout(timeout);resolve({code,signal});});
 });
 assert.equal(r.code,0,'Trusted keyup fixture must complete two tickets without manual gates');
 const diag=JSON.parse(fs.readFileSync(path.join(d,'diagnostics/last-result.json'),'utf8'));
 assert.equal(diag.lastError,null);assert.equal(diag.loop.processed,2);
 assert.equal(diag.demoBrowser.sendClicks,2);assert.equal(diag.demoBrowser.saveClicks,2);
 assert.deepEqual(diag.demoBrowser.fixedCommitSteps,Array.from({length:2},()=>['CATEGORY_MEMBER_BLUR','SUBCATEGORY_MEMBER_BLUR','SIGNATURE_EDITOR_BLUR']).flat());
 for(const id of ['mainForm:category-value-id','mainForm:category-sub-value-id','mainForm:signature-value-id']){
  assert.equal(diag.demoBrowser.fixedOptionClicks[id],2,'One exact selection per field and per ticket: '+id);
 }
 assert.deepEqual(diag.demoBrowser.trustedSends,[true,true]);assert.deepEqual(diag.demoBrowser.trustedSaves,[true,true]);
 console.log('PASS RC12_TRUSTED_KEYUP_EACH_FIXED_OPTION_ONCE_2x_SEND_SAVE');
}finally{fs.rmSync(d,{recursive:true,force:true,maxRetries:5,retryDelay:150});}
