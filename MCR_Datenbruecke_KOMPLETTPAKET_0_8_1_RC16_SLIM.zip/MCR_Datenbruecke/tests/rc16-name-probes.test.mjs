import test from 'node:test';
import assert from 'node:assert/strict';
import {discoverNameHints,NAME_PROBE_BUDGET} from '../lib/name-probes.mjs';
import I from '../lib/identity-evidence.cjs';
const mail=(body,senderName='',senderEmail='')=>({body,subject:'Test',senderName,senderEmail});
test('RC16 name discovery: German self-introduction without email and without manual input',()=>{
 const d=discoverNameHints(mail('Guten Tag, mein Name ist Martin Freibothe. Bitte beantworten Sie meine Frage.'));
 assert.deepEqual(d.candidates.map(x=>[x.firstName,x.lastName]),[['Martin','Freibothe']]);
 assert.ok(d.checks>3&&d.checks<=NAME_PROBE_BUDGET);
 assert.ok(d.history.some(x=>x.method==='INTRO_MEIN_NAME'&&x.result==='MATCH'));
});
test('RC16 name discovery: no-line-break salutation signature',()=>{
 const d=discoverNameHints(mail('Vielen Dank. Mit freundlichen Grüßen Martin Freibothe'));
 assert.deepEqual(d.candidates.map(x=>x.name),['Martin Freibothe']);
});
test('RC16 name discovery: strict sender address plus COMARCH member name match',()=>{
 const d=discoverNameHints(mail('Bitte helfen.','', 'martin.freibothe@intel.com'));
 assert.equal(d.candidates.length,1);
 assert.equal(I.requireMatched({id:'99900001',source:'PROFILE_ROWS',firstName:'Martin',lastName:'Freibothe'},d.candidates[0],{}),true);
 assert.throws(()=>I.requireMatched({id:'99900001',source:'PROFILE_ROWS',firstName:'Andere',lastName:'Person'},d.candidates[0],{}),{code:'MEMBER_NAME_MISMATCH'});
});
test('RC16 name discovery: roll-off, role mailbox, and quoted prior message are not automatically accepted',()=>{
 const d=discoverNameHints(mail('Bitte helfen.\n\n-----Original Message-----\nName: Alte Person','Support Team','support.team@intel.com'));
 assert.deepEqual(d.candidates,[]);
});
test('RC16 probe record is privacy safe and bounded to 100 strategies',()=>{
 const d=discoverNameHints(mail('Bitte helfen, kein Name im Text.','', 'no.reply@intel.com'),{maxProbes:100});
 assert.equal(d.candidates.length,0);assert.ok(d.checks<=100);assert.ok(d.history.every(x=>!JSON.stringify(x).includes('no.reply')));
});
test('RC16 malformed candidate cannot override explicit ID or unique Member',()=>{
 const d=discoverNameHints(mail('Ich bin Martin Freibothe.'));
 assert.throws(()=>I.requireMatched({id:'99900001',source:'PROFILE_ROWS',firstName:'Martin',lastName:'Freibothe'},d.candidates[0],{expectedId:'12345678'}),{code:'MEMBER_ID_CONFLICT'});
});
