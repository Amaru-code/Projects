import test from 'node:test';import assert from 'node:assert/strict';
import {fixedQueryObservation} from '../lib/browser-workflow.mjs';
const wanted='Allgemeine Schriftwechsel';
test('RC13 accepted exact query must still be picked from dropdown',()=>{
 assert.equal(fixedQueryObservation(wanted,wanted),'EXACT');
});
test('RC13 one missing final character allows only search, not committed category',()=>{
 assert.equal(fixedQueryObservation(wanted,'Allgemeine Schriftwechse'),'ONE_CHAR_PREFIX');
});
test('RC13 no other truncated or corrupted field value accepted',()=>{
 for(const s of ['Allgemeine Schriftwechs','Falsche Kategorie','',null,undefined,'ALLGEMEINE SCHRIFTWECHSE',25]){
  assert.equal(fixedQueryObservation(wanted,s),'MISMATCH');
 }
});
test('RC13 subcategory and signature remain exact or single-char query only',()=>{
 const values=['Personenschriftwechsel','INTL01 - Intel Deutschland GmbH'];
 for(const value of values){
  assert.equal(fixedQueryObservation(value,value),'EXACT');
  assert.equal(fixedQueryObservation(value,value.slice(0,-1)),'ONE_CHAR_PREFIX');
  assert.equal(fixedQueryObservation(value,value.slice(0,-2)),'MISMATCH');
 }
});
