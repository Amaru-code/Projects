/** Regression: real COMARCH exhibited 24/25 chars for Allgemeine
 * Schriftwechsel and exposed the unique correct ICEfaces dropdown item.
 * Accept only a one-character query prefix; click the exact result once.
 * A semantically wrong query must never cause any outbound action.
 */
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';
import {fileURLToPath} from 'node:url';import {spawn} from 'node:child_process';
import assert from 'node:assert/strict';
import {fixedQueryObservation} from '../lib/browser-workflow.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
assert.equal(fixedQueryObservation('Allgemeine Schriftwechsel','Allgemeine Schriftwechse'),'ONE_CHAR_PREFIX');
assert.equal(fixedQueryObservation('Allgemeine Schriftwechsel','Allgemeine Schriftwechsel'),'EXACT');
for(const wrong of ['Allgemeine Schriftwechs','Falsche Kategorie','',null,'ALLGEMEINE SCHRIFTWECHSE']){
 assert.equal(fixedQueryObservation('Allgemeine Schriftwechsel',wrong),'MISMATCH');
}
for(const scenario of ['trusted-keyup-category-short','trusted-keyup-category-corrupt']){
 const d=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC13-FixedQuery-'));
 try{
  for(const folder of ['src','lib','config','examples'])fs.cpSync(path.join(root,folder),path.join(d,folder),{recursive:true});
  const cfg=JSON.parse(fs.readFileSync(path.join(d,'config/local-runner-queue-send.json'),'utf8'));
  Object.assign(cfg,{runtimeDirectory:'.runtime',profileDirectory:'.runtime/edge-profile',downloadDirectory:'.runtime/downloads',diagnosticDirectory:'diagnostics'});
  fs.writeFileSync(path.join(d,'config/local-runner-queue-send.json'),JSON.stringify(cfg,null,2)+'\n');
  const r=await new Promise((resolve,reject)=>{
   const env={...process.env,MCR_DEMO_SCENARIO:scenario};delete env.NODE_OPTIONS;delete env.NODE_PATH;
   const child=spawn(process.execPath,[path.join(d,'src/local-bot-full-run.mjs'),'--demo','--close-browser'],{cwd:d,env,stdio:'inherit'});
   const timer=setTimeout(()=>child.kill(),90000);
   child.once('error',reject);child.once('exit',(code,signal)=>{clearTimeout(timer);resolve({code,signal});});
  });
  const diag=JSON.parse(fs.readFileSync(path.join(d,'diagnostics/last-result.json'),'utf8'));
  const clicks=diag.demoBrowser||{};
  if(scenario==='trusted-keyup-category-short'){
   assert.equal(r.code,0);assert.equal(diag.lastError,null);assert.equal(diag.loop.processed,2);
   assert.equal(clicks.sendClicks,2);assert.equal(clicks.saveClicks,2);
   assert.deepEqual(clicks.trustedSends,[true,true]);assert.deepEqual(clicks.trustedSaves,[true,true]);
   for(const id of ['mainForm:category-value-id','mainForm:category-sub-value-id','mainForm:signature-value-id']){
    assert.equal(clicks.fixedOptionClicks[id],2,'Exactly one exact option per ticket: '+id);
   }
   console.log('PASS RC13_CATEGORY_SHORT_PREFIX_EXACT_OPTION_EACH_ONCE_TWO_TICKETS');
  }else{
   assert.notEqual(r.code,0);assert.equal(diag.lastError,'FIXED_QUERY_MISMATCH');
   assert.equal(diag.loop.processed,0);assert.equal(diag.send.clicked,false);
   assert.equal(diag.phase,'DESCRIPTION_AND_FIXED_FIELDS');
   console.log('PASS RC13_CORRUPT_QUERY_BLOCKS_ALL_AUTOMATIC_CLICKS_AND_SEND');
  }
 }finally{fs.rmSync(d,{recursive:true,force:true,maxRetries:5,retryDelay:150});}
}
