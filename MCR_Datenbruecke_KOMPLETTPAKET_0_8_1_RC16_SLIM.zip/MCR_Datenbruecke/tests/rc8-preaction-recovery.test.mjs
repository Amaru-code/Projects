import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {temp} from './helpers.mjs';
import {writeJSON,readJSON,controlDir,runState,assertNoReview,ledger} from '../lib/control.mjs';
import {preActionProof,releaseProvenPreActionAbort} from '../lib/preaction-recovery.mjs';
const timestamp='2026-10-23T12:00:00.000Z';
function sample(){
 const run={schema:'MCR_BETA_RUN_V1',state:'STOP_REVIEW_REQUIRED',operation:'REAL_RUN',runId:'RC7-incident-001',pid:999999991,startedAt:timestamp,errorCode:'LIVE_NOT_VERIFIED'};
 const diag={schema:'MCR_LOCAL_RUNNER_DIAGNOSTIC_V2',mode:'REAL',runId:run.runId,createdAt:'2026-10-23T12:00:01.000Z',phase:'DESCRIPTION_AND_FIXED_FIELDS',lastError:'FIXED_VERIFY',send:{clicked:false},save:{clicked:false},loop:{processed:0,forwarded:0,processedTickets:[]}};
 return {run,diag};
}
function onDisk(d,run,diag){writeJSON(path.join(controlDir(d),'last-run.json'),run);fs.mkdirSync(path.join(d,'diagnostics'),{recursive:true});writeJSON(path.join(d,'diagnostics/last-result.json'),diag);}
test('RC8 zero-action RC7 category failure is automatically cleared with audit and without send',()=>{
 const d=temp();try{
  const {run,diag}=sample();onDisk(d,run,diag);const profile=path.join(d,'.runtime/edge-profile');fs.mkdirSync(profile,{recursive:true});fs.writeFileSync(path.join(profile,'original.sentinel'),'unchanged');
  assert.throws(()=>assertNoReview(d),{code:'LIVE_REVIEW_REQUIRED'});
  assert.deepEqual(releaseProvenPreActionAbort(d),{released:true,reason:'PROVEN_PRE_ACTION_NO_EFFECT',phase:'DESCRIPTION_AND_FIXED_FIELDS',diagnosticError:'FIXED_VERIFY'});
  assert.equal(runState(d).reviewRequired,false);assert.equal(readJSON(path.join(controlDir(d),'last-run.json')).state,'AUTO_REVIEWED_PRE_ACTION_NO_EFFECT');
  assert.equal(ledger(d).pending.length,0);assert.equal(fs.readFileSync(path.join(profile,'original.sentinel'),'utf8'),'unchanged');
  assert.ok(fs.readdirSync(controlDir(d)).some(x=>x.startsWith('auto_preaction_review_')));
  assert.equal(releaseProvenPreActionAbort(d).released,false);
 }finally{fs.rmSync(d,{recursive:true,force:true});}
});
for(const [caseName,modify] of [
 ['send intent remains pending',(d,r,v)=>{ledger(d).begin('90000001','description');}],
 ['send click recorded',(d,r,v)=>{v.send.clicked=true;}],
 ['save click recorded',(d,r,v)=>{v.save.clicked=true;}],
 ['forward click recorded',(d,r,v)=>{v.forward={clicked:true};}],
 ['already in SEND_AND_SAVE phase',(d,r,v)=>{v.phase='SEND_AND_SAVE';}],
 ['one processed ticket',(d,r,v)=>{v.loop.processed=1;}],
 ['last run ID differs',(d,r,v)=>{v.runId='unrelated';}],
 ['diagnostic predates the run',(d,r,v)=>{v.createdAt='2026-10-23T11:59:59.000Z';}],
 ['not a real diagnostic',(d,r,v)=>{v.mode='DEMO';}],
 ['no confirmed error',(d,r,v)=>{v.lastError=null;}],
 ['unknown error',(d,r,v)=>{v.lastError='RUNNER_ERROR';}],
 ['malformed state',(d,r,v)=>{r.schema='INVALID';}],
 ['unknown control state',(d,r,v)=>{r.state='UNKNOWN';}],
 ['old process still alive',(d,r,v)=>{r.pid=process.pid;}],
 ['stale lock belongs to another process',(d,r,v)=>{writeJSON(path.join(controlDir(d),'operation.lock.json'),{schema:'MCR_OPERATION_LOCK_V1',operation:'REAL_RUN',pid:123456789,token:'a'.repeat(48)});}]
])test('RC8 recovery blocks '+caseName,()=>{
 const d=temp();try{const {run,diag}=sample();onDisk(d,run,diag);modify(d,run,diag);onDisk(d,run,diag);
  const outcome=releaseProvenPreActionAbort(d);assert.equal(outcome.released,false,JSON.stringify(outcome));
  assert.notEqual(readJSON(path.join(controlDir(d),'last-run.json')).state,'AUTO_REVIEWED_PRE_ACTION_NO_EFFECT');
 }finally{fs.rmSync(d,{recursive:true,force:true});}
});
test('RC8 stale lock is archived only with a bound zero-action diagnostic',()=>{
 const d=temp();try{const {run,diag}=sample();onDisk(d,run,diag);
 writeJSON(path.join(controlDir(d),'operation.lock.json'),{schema:'MCR_OPERATION_LOCK_V1',operation:'REAL_RUN',pid:run.pid,token:'a'.repeat(48)});
 assert.equal(releaseProvenPreActionAbort(d).released,true);
 assert.equal(fs.existsSync(path.join(controlDir(d),'operation.lock.json')),false);
 assert.equal(fs.readdirSync(path.join(controlDir(d),'lock_archive')).length,1);
 }finally{fs.rmSync(d,{recursive:true,force:true});}
});
test('RC8 proof requires zero outbound effects even at a permitted preparatory phase',()=>{
 const {run,diag}=sample();assert.equal(preActionProof(run,diag),true);
 assert.equal(preActionProof(run,diag,{pending:1}),false);
 assert.equal(preActionProof(run,diag,{livePid:true}),false);
 diag.phase='PRE_SEND_OPERATOR_REVIEW';assert.equal(preActionProof(run,diag),false);
 diag.phase='DESCRIPTION_AND_FIXED_FIELDS';
 diag.send.clicked=true;assert.equal(preActionProof(run,diag),false);
});
