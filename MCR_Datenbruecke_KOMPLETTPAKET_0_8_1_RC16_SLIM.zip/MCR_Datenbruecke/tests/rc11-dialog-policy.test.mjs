import test from 'node:test';import assert from 'node:assert/strict';
import {sentNotice,permitAcknowledgement,validSendAcknowledgements} from '../lib/send-dialog-policy.mjs';
test('German COMARCH information popup is a sent notice',()=>{
 for(const s of ['Information: Nachricht gesendet','Nachricht wurde gesendet.','E-Mail erfolgreich versendet','Message sent'])assert.equal(sentNotice(s),true);
 for(const s of ['Bitte den Vorgang bestätigen','Antwort nicht gesendet','Unbekannter Fehler','Nachricht löschen',''])assert.equal(sentNotice(s),false);
});
test('only first two ordinary distinct confirmations are permitted',()=>{
 for(const n of [0,1])assert.equal(permitAcknowledgement({previous:n,successNotices:0,success:false,type:'html'}),true);
 assert.equal(permitAcknowledgement({previous:2,successNotices:0,success:false,type:'html'}),false);
 assert.equal(permitAcknowledgement({previous:2,successNotices:0,success:false,type:'alert'}),false);
});
test('third must be explicit sent-success information, at most once',()=>{
 assert.equal(permitAcknowledgement({previous:2,successNotices:0,success:true,type:'html'}),true);
 assert.equal(permitAcknowledgement({previous:2,successNotices:0,success:true,type:'alert'}),true);
 assert.equal(permitAcknowledgement({previous:2,successNotices:0,success:true,type:'confirm'}),false);
 assert.equal(permitAcknowledgement({previous:3,successNotices:1,success:true,type:'html'}),false);
 assert.equal(permitAcknowledgement({previous:2,successNotices:1,success:true,type:'html'}),false);
});
test('confirmation proof accepts exact two, or third recognized success',()=>{
 for(const x of [{htmlDialogs:2,jsDialogs:0},{htmlDialogs:1,jsDialogs:1,successNotices:0},{htmlDialogs:2,jsDialogs:1,successNotices:1}])assert.equal(validSendAcknowledgements(x),true);
 for(const x of [{htmlDialogs:2,jsDialogs:1,successNotices:0},{htmlDialogs:3,jsDialogs:1,successNotices:1},{htmlDialogs:1,jsDialogs:0},{htmlDialogs:3,jsDialogs:0,successNotices:2},{htmlDialogs:-1,jsDialogs:3}])assert.equal(validSendAcknowledgements(x),false);
});
