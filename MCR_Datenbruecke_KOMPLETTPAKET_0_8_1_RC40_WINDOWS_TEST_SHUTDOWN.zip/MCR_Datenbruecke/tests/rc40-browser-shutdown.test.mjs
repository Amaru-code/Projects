import test from 'node:test';
import assert from 'node:assert/strict';
import {EventEmitter} from 'node:events';
import fs from 'node:fs';
import path from 'node:path';
import {shutdownFictionalBrowser} from '../lib/demo-browser-shutdown.mjs';
import {ROOT} from './helpers.mjs';
import {VERSION} from '../lib/control.mjs';
import {sha256} from '../lib/core.mjs';

function childMock({initialExit=false,respondToKill=true}={}){
 const c=new EventEmitter();c.exitCode=initialExit?0:null;c.signalCode=null;c.killCount=0;c.unrefCount=0;
 c.kill=()=>{c.killCount++;if(respondToKill){c.signalCode='SIGTERM';c.emit('exit',null,'SIGTERM');}return true;};
 c.unref=()=>c.unrefCount++;return c;
}
test('RC40 graceful CDP Browser.close takes precedence over process kill',async()=>{
 const child=childMock();let closes=0,cdpClosed=0;
 const cdp={opened:true,async send(method){assert.equal(method,'Browser.close');closes++;child.exitCode=0;child.emit('exit',0,null);},close(){cdpClosed++;}};
 const d=await shutdownFictionalBrowser({cdp,browser:{child},graceMs:50,killWaitMs:50});
 assert.equal(d.closed,true);assert.equal(child.killCount,0);assert.equal(child.unrefCount,1);assert.equal(closes,1);assert.equal(cdpClosed,1);
});
test('RC40 bounded fallback kills only the launched fictional child',async()=>{
 const child=childMock();const cdp={opened:true,async send(){throw new Error('socket closed by browser');},close(){}};
 const d=await shutdownFictionalBrowser({cdp,browser:{child},graceMs:15,killWaitMs:15});
 assert.equal(d.closed,true);assert.equal(child.killCount,1);
});
test('RC40 refuses to call a never-exiting browser a verified test',async()=>{
 const child=childMock({respondToKill:false});const cdp={opened:false,close(){}};
 const d=await shutdownFictionalBrowser({cdp,browser:{child},graceMs:15,killWaitMs:15});
 assert.equal(d.closed,false);assert.equal(d.mode,'CHILD_STILL_ALIVE');assert.equal(child.killCount,1);
});
test('RC40 pins published RC39 manifest for verified software-only upgrades',()=>{
 assert.equal(VERSION,'0.8.1-rc.40');
 const p=path.join(ROOT,'tools/reference/complete-0.8.1-rc.39-manifest.json');
 assert.equal(sha256(fs.readFileSync(p)),'af72e0bc941bb176d0151f9d6c53fd62d693545d8300d4243de869efa5ad214d');
 const code=fs.readFileSync(path.join(ROOT,'tools/cli.mjs'),'utf8');
 assert.match(code,/--test-concurrency=4/);
 assert.match(code,/r\.code===0&&!r\.signal/);
});
