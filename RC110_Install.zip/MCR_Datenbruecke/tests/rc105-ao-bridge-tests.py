"""Offline adapter tests: the financial workbook/Excel are never accessed."""
import importlib.util
import json
import os
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('ao_bridge', ROOT / 'tools' / 'ao-generator-bridge.py')
bridge = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bridge)

FIXTURE = '''from pathlib import Path
from datetime import datetime
import json, os, types
BASE=Path(__file__).resolve().parent
WORKBOOK=BASE/'IPP_Leistungsberechnungen_Arbeitsdatei.xlsm'
OUTPUT=BASE/'Ausgabe PDF'
AUDIT=BASE/'Audit_Logs'
MASTER=BASE/'master.xlsx'
CONTROL_TEMPLATE=BASE/'control.xlsm'
win32=types.SimpleNamespace(DispatchEx=lambda name: types.SimpleNamespace(Quit=lambda: None))
def lookup_person(excel, wwid):
    return {'WWID':int(wwid),'Name':'Nachname Vorname','Adresse':'Teststr. 1','PLZ':'12345'}
def is_missing_contact_value(value):
    return value in (None,'','#NV','#N/A')
def request_missing_address(person):
    raise RuntimeError('interactive contact routine must never be called')
def default_stichtag(today=None):
    today=today or datetime.now()
    return datetime(today.year,12,31)
def ask_stichtag():
    value=input('Stichtag (TT.MM.JJJJ) [31.12.2026]: ').strip()
    return datetime.strptime(value,'%d.%m.%Y') if value else default_stichtag()
def create_pdf(wwid):
    date=ask_stichtag()
    person=lookup_person(None,wwid)
    request_missing_address(person)
    MODE
    name='Nachname Vorname'
    person={'WWID':int(wwid),'Name':name}
    WORKBOOK.write_bytes(b'working fixture saved')
    OUTPUT.mkdir(exist_ok=True);AUDIT.mkdir(exist_ok=True)
    pdf=OUTPUT/f'{date:%Y-%m-%d}_Auszahlungsoption_{name}_{wwid}.pdf'
    pdf.write_bytes(b'%PDF-1.7\\n'+b'x'*500+b'\\n%%EOF')
    audit=AUDIT/f'current_{wwid}.json'
    payload={'timestamp':datetime.now().isoformat(timespec='seconds'),'status':'success','wwid':wwid,
      'name':name,'stichtag':date.strftime('%d.%m.%Y'),'record':7,'pdf':str(pdf)}
    MUTATION
    audit.write_text(json.dumps(payload),encoding='utf-8')
    AFTER
    return pdf,audit,7,person
'''


class DummyExcel:
    def install(self):
        pass
    def cleanup(self, grace_ms=5000):
        pass
    def restore(self):
        pass


class AoBridgeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.folder = Path(self.temp.name)
        self.script = self.folder / 'auszahlungsoption_generator.py'
        self.request_id = 'a' * 32
        (self.folder/'master.xlsx').write_bytes(b'fictional master')
        (self.folder/'control.xlsm').write_bytes(b'fictional control')
        (self.folder/'IPP_Leistungsberechnungen_Arbeitsdatei.xlsm').write_bytes(b'fictional workbook')

    def tearDown(self):
        self.temp.cleanup()

    def source(self, mode='pass', mutation='pass', after='pass'):
        self.script.write_text(FIXTURE.replace('MODE', mode).replace('MUTATION', mutation).replace('AFTER', after), encoding='utf-8')
        return bridge.sha(self.script.read_bytes())

    def run_fixture(self, source_sha=None):
        with patch.object(bridge, 'OwnedExcel', DummyExcel):
            return bridge.generate(self.script, '11412817', self.request_id,
                                   source_sha or bridge.sha(self.script.read_bytes()), 5, lambda value: None)

    def test_default_date_and_verified_wwid_yield_bound_fresh_proof(self):
        source_sha = self.source()
        result = self.run_fixture(source_sha)
        proof = result['proof']
        self.assertEqual(result['status'], 'SUCCESS')
        self.assertEqual(proof['wwid'], '11412817')
        self.assertEqual(proof['requestId'], self.request_id)
        self.assertEqual(proof['name'], 'Nachname Vorname')
        self.assertEqual(proof['stichtag'], bridge.datetime.now().strftime('31.12.%Y'))
        self.assertEqual(proof['sourceSha256'], source_sha)
        self.assertEqual(proof['sha256'], bridge.sha(Path(proof['file']).read_bytes()))
        self.assertEqual(proof['auditSha256'], bridge.sha(Path(proof['auditFile']).read_bytes()))
        self.assertNotIn('Saldovortrag', json.dumps(proof))

    def test_missing_address_is_not_answered_with_stichtag_or_wwid(self):
        self.source(mode="input('Adresse: ')")
        with self.assertRaisesRegex(bridge.BridgeError, 'Adresse oder PLZ') as error:
            self.run_fixture()
        self.assertEqual(error.exception.code, 'AO_CONTACT_DATA_REQUIRED')
        self.assertIn('Angefordertes Feld: Adresse', str(error.exception))
        self.assertFalse((self.folder / 'Ausgabe PDF').exists())

    def test_missing_postcode_is_reported_separately(self):
        self.source(mode="input('PLZ: ')")
        with self.assertRaises(bridge.BridgeError) as error:
            self.run_fixture()
        self.assertEqual(error.exception.code, 'AO_CONTACT_DATA_REQUIRED')
        self.assertIn('Angefordertes Feld: PLZ', str(error.exception))
        self.assertFalse((self.folder / 'Ausgabe PDF').exists())

    def test_contact_preflight_blocks_both_fields_before_calculation(self):
        self.source(mode="raise RuntimeError('calculator must not run')")
        self.script.write_text(self.script.read_text().replace("'Adresse':'Teststr. 1','PLZ':'12345'", "'Adresse':'#NV','PLZ':''"))
        with self.assertRaises(bridge.BridgeError) as error:
            self.run_fixture()
        self.assertEqual(error.exception.code, 'AO_CONTACT_DATA_REQUIRED')
        self.assertEqual(error.exception.missing_fields, ['Adresse','PLZ'])
        self.assertFalse((self.folder/'Ausgabe PDF').exists())

    def test_owner_file_does_not_block_readonly_contact_lookup(self):
        self.source()
        (self.folder/'~$master.xlsx').write_text('owner')
        result = self.run_fixture()
        self.assertEqual(result['status'], 'SUCCESS')
        self.assertEqual((self.folder/'~$master.xlsx').read_text(), 'owner')
        self.assertEqual((self.folder/'master.xlsx').read_bytes(), b'fictional master')

    def test_owner_file_with_missing_address_reports_contact_block(self):
        self.source(mode="raise RuntimeError('calculator must not run')")
        self.script.write_text(self.script.read_text().replace("'Adresse':'Teststr. 1'", "'Adresse':'#NV'"))
        (self.folder/'~$master.xlsx').write_text('owner')
        with self.assertRaises(bridge.BridgeError) as error:
            self.run_fixture()
        self.assertEqual(error.exception.code, 'AO_CONTACT_DATA_REQUIRED')
        self.assertEqual(error.exception.missing_fields, ['Adresse'])
        self.assertFalse((self.folder/'Ausgabe PDF').exists())

    def test_missing_master_and_missing_folder_have_separate_codes(self):
        self.source()
        (self.folder/'master.xlsx').unlink()
        with self.assertRaises(bridge.BridgeError) as error:
            self.run_fixture()
        self.assertEqual(error.exception.code, 'MASTER_FILE_NOT_FOUND')
        with self.assertRaises(bridge.BridgeError) as error:
            bridge.check_readable_master_path(self.folder/'missing-folder'/'master.xlsx')
        self.assertEqual(error.exception.code, 'MASTER_PATH_UNAVAILABLE')

    def test_actual_sharing_error_not_guessed_from_owner_file(self):
        self.source()
        exc = OSError('private data must not be logged')
        exc.winerror = 32
        self.assertEqual(bridge.source_error(exc, 'read_contact_data').code, 'MASTER_WORKBOOK_LOCKED')
        self.assertEqual(bridge.source_error(exc, 'read_contact_data').details['winerror'], 32)
        self.assertNotIn('private data', str(bridge.source_error(exc, 'read_contact_data')))
        self.assertEqual(bridge.source_error(PermissionError('denied'), 'read_contact_data').code, 'MASTER_READ_ACCESS_DENIED')
        self.assertEqual(bridge.source_error(RuntimeError('unknown COM failure'), 'read_contact_data').code, 'MASTER_OPEN_FAILED')
        exc.winerror = 53
        self.assertEqual(bridge.source_error(exc, 'read_contact_data').code, 'MASTER_PATH_UNAVAILABLE')

    def test_readonly_lookup_and_actual_com_failure_preserved_on_quit(self):
        events = []
        exc = RuntimeError('synthetic COM error')
        exc.hresult = -2147024891
        def lookup(app, wwid):
            events.append('read')
            raise exc
        def quit_failed():
            events.append('quit')
            raise RuntimeError('secondary cleanup')
        ns = {'MASTER': self.folder/'master.xlsx', 'lookup_person': lookup,
              'win32': types.SimpleNamespace(DispatchEx=lambda _: types.SimpleNamespace(Quit=quit_failed))}
        with self.assertRaises(bridge.BridgeError) as error:
            bridge.contact_preflight(ns, '11412817')
        self.assertEqual(error.exception.code, 'MASTER_READ_ACCESS_DENIED')
        self.assertEqual(error.exception.details['hresult'], -2147024891)
        self.assertEqual(events, ['read', 'quit'])

    def test_changed_person_between_preflight_and_create_is_blocked(self):
        self.source()
        self.script.write_text(self.script.read_text().replace(
            "def lookup_person(excel, wwid):\n    return",
            "def lookup_person(excel, wwid):\n    global calls\n    calls=globals().get('calls',0)+1\n    if calls>1: return {'WWID':int(wwid),'Name':'Andere Person','Adresse':'Teststr. 1','PLZ':'12345'}\n    return"))
        with self.assertRaises(bridge.BridgeError) as error:
            self.run_fixture()
        self.assertEqual(error.exception.code, 'AO_MASTER_PERSON_CHANGED')
        self.assertFalse((self.folder/'Ausgabe PDF').exists())

    def test_unrecognized_prompt_is_not_guessed(self):
        self.source(mode="input('Menueauswahl: ')")
        with self.assertRaises(bridge.BridgeError) as error:
            self.run_fixture()
        self.assertEqual(error.exception.code, 'AO_UNEXPECTED_INPUT')

    def test_changed_source_after_probe_is_not_executed(self):
        old_sha = self.source()
        self.script.write_text(self.script.read_text() + '\n# changed\n')
        with self.assertRaises(bridge.BridgeError) as error:
            self.run_fixture(old_sha)
        self.assertEqual(error.exception.code, 'AO_SCRIPT_CHANGED')
        self.assertFalse((self.folder / 'Ausgabe PDF').exists())

    def test_wrong_audit_wwid_rejected(self):
        self.source(mutation="payload['wwid']='99999999'")
        with self.assertRaises(bridge.BridgeError) as error:
            self.run_fixture()
        self.assertEqual(error.exception.code, 'AO_AUDIT_MISMATCH')

    def test_stale_output_rejected(self):
        self.source(after='os.utime(pdf,(100,100))')
        with self.assertRaises(bridge.BridgeError) as error:
            self.run_fixture()
        self.assertEqual(error.exception.code, 'AO_RESULT_STALE')

    def test_global_lock_serializes_all_wwids_and_releases(self):
        with bridge.generator_lock(self.folder, wait_seconds=0):
            with self.assertRaises(bridge.BridgeError) as error:
                with bridge.generator_lock(self.folder, wait_seconds=0):
                    self.fail('second workbook owner acquired lock')
            self.assertEqual(error.exception.code, 'AO_GENERATOR_BUSY')
        with bridge.generator_lock(self.folder, wait_seconds=0):
            pass

    def test_manual_workbook_lock_prevents_export(self):
        self.source()
        (self.folder / '~$IPP_Leistungsberechnungen_Arbeitsdatei.xlsm').write_text('owner')
        with self.assertRaises(bridge.BridgeError) as error:
            self.run_fixture()
        self.assertEqual(error.exception.code, 'AO_WORKBOOK_BUSY')
        self.assertFalse((self.folder / 'Ausgabe PDF').exists())

    def test_existing_excel_process_is_not_quit_or_killed(self):
        events = []
        app = types.SimpleNamespace(Hwnd=1, Quit=lambda: events.append('quit'))
        client = types.ModuleType('win32com.client')
        client.DispatchEx = lambda *a, **k: app
        win32com = types.ModuleType('win32com')
        win32com.client = client
        process = types.ModuleType('win32process')
        process.EnumProcesses = lambda: [42]
        process.GetWindowThreadProcessId = lambda hwnd: (1, 42)
        api = types.ModuleType('win32api')
        api.OpenProcess = lambda *a: events.append('open')
        with patch.dict('sys.modules', {'win32com': win32com, 'win32com.client': client,
                                       'win32process': process, 'win32api': api}):
            owned = bridge.OwnedExcel()
            owned.install()
            with self.assertRaises(bridge.BridgeError):
                client.DispatchEx('Excel.Application')
            owned.restore()
        self.assertEqual(events, [])


if __name__ == '__main__':
    unittest.main()
