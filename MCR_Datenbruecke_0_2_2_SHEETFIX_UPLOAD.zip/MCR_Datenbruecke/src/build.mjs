import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const code='/* MCR Datenbruecke 0.2.2 - generated from lib/data-core.cjs + browser/ui.js. */\n(()=>{\nconst module={exports:{}};\n'+fs.readFileSync(path.join(root,'lib/data-core.cjs'),'utf8')+'\nconst Core=module.exports;\n'+fs.readFileSync(path.join(root,'browser/ui.js'),'utf8')+'\n})();\n';
fs.writeFileSync(path.join(root,'COMARCH_DATENBRUECKE.js'),code);
