@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "ERRORLEVEL="
cd /d "%~dp0"
if not "%errorlevel%"=="0" goto failed
call BUILD_UND_TEST.cmd
set "IPP_DEMO_RC=%errorlevel%"
if not "%IPP_DEMO_RC%"=="0" goto failed
if not defined IPP_DOTNET goto failed
if not exist "src\Mcr.Ipp.Cli\bin\Release\net10.0\Mcr.Ipp.Cli.dll" goto failed
"%IPP_DOTNET%" exec "src\Mcr.Ipp.Cli\bin\Release\net10.0\Mcr.Ipp.Cli.dll" contribute --baseline "examples\Bestand_Synthetisch.xlsx" --txt "examples\Monatsdaten\Aenderungen_012026.txt" --txt "examples\Monatsdaten\Aenderungen_022026.txt" --txt "examples\Monatsdaten\Aenderungen_032026.txt" --txt "examples\Monatsdaten\Aenderungen_042026.txt" --txt "examples\Monatsdaten\Aenderungen_052026.txt" --txt "examples\Monatsdaten\Aenderungen_062026.txt" --out "Output"
set "IPP_DEMO_RC=%errorlevel%"
if not "%IPP_DEMO_RC%"=="0" goto failed
echo Demo erstellt. Nur synthetische Beitraege; keine Leistungsbescheinigung.
pause
exit /b 0
:failed
echo Demo nicht bestaetigt. Details: evidence\local\DIAGNOSE.txt
pause
exit /b 1
