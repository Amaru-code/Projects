using Mcr.Ipp.Core;
using System.Text.Json;

if (args.Length == 0 || args[0] is "help" or "--help")
{
    Console.WriteLine("""
    MCR IPP 0.2.1 - C# Contribution + sichere IPP-Vorbereitung (nicht DC)

    contribute --baseline Bestand.xlsx --txt Aenderung_012026.txt --txt Aenderung_022026.txt --out Output
               [--ipp Original_IPP.xlsm] [--options options.json] [--decisions Personenfreigaben.json]
    inspect --ipp Original_IPP.xlsm --out IPP_Pruefung.json

    Keine automatische Beitragsbereitstellung/Fallentscheidung. Keine produktiven PDFs in V0.1.
    """);
    return 0;
}
try
{
    var arguments = new Dictionary<string, List<string>>(StringComparer.Ordinal);
    for (int i = 1; i < args.Length; i++)
    {
        if (!args[i].StartsWith("--", StringComparison.Ordinal) || i + 1 >= args.Length) throw new IppException("ARGUMENT", "Argument erwartet --name wert.");
        string key = args[i++]; if (!arguments.TryGetValue(key, out var values)) arguments[key] = values = new(); values.Add(args[i]);
    }
    string Required(string key) => arguments.TryGetValue(key, out var v) && v.Count == 1 ? v[0] : throw new IppException("ARGUMENT", "Genau ein Wert erforderlich: " + key);
    string? Optional(string key) => arguments.ContainsKey(key) ? Required(key) : null;
    if (args[0] == "contribute")
    {
        foreach (var k in arguments.Keys) if (!new[] { "--baseline", "--txt", "--out", "--ipp", "--options", "--decisions" }.Contains(k)) throw new IppException("ARGUMENT", "Unbekannte Option: " + k);
        var request = new RunRequest { BaselinePath = Required("--baseline"), TxtPaths = arguments.GetValueOrDefault("--txt") ?? new(), OutputDirectory = Required("--out"), IppTemplatePath = Optional("--ipp"), PersonDecisionsPath = Optional("--decisions"), Options = Optional("--options") is { } file ? JsonFiles.Read<ContributionOptions>(file) : new() { ReviewTariffIssues = true } };
        var result = new Pipeline().Execute(request, Console.WriteLine);
        Console.WriteLine(JsonSerializer.Serialize(result, JsonFiles.Options));
        return result.IppStatus.StartsWith("BLOCKED", StringComparison.Ordinal) ? 3 : result.OpenPersonCases > 0 || result.OpenTariffMonths > 0 ? 4 : 0;
    }
    if (args[0] == "inspect")
    {
        var target = Required("--out");
        if (File.Exists(target)) throw new IppException("OUTPUT_EXISTS", "Diagnoseziel existiert bereits; wird nicht ueberschrieben.");
        JsonFiles.Write(target, TemplatePreparation.Inspect(SourceBlob.Read(Required("--ipp"))));
        Console.WriteLine("Statischer IPP-Pruefbericht erstellt. Kein Excel-Start."); return 0;
    }
    throw new IppException("COMMAND", "Unbekanntes Kommando.");
}
catch (Exception ex)
{
    Console.Error.WriteLine((ex is IppException ie ? ie.Code : ex.GetType().Name) + ": " + ex.Message);
    return 2;
}
