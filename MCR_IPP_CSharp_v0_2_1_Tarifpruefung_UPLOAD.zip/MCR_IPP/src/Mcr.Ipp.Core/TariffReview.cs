using System.Security.Cryptography;
using System.Text;

namespace Mcr.Ipp.Core;

public sealed record TariffOccurrence(string File, string Sha256, string Month, int DataRecord,
    string OriginalId, string? TariffColumn, string? RawTariff, double? ParsedTariff, string? Error);

public sealed class TariffCase
{
    public string CaseId { get; set; } = "";
    public string ClientId { get; set; } = "";
    public string OriginalClientId { get; set; } = "";
    public string DisplayName { get; set; } = "NAME_NICHT_GELIEFERT";
    public string Month { get; set; } = "";
    public string SourceFile { get; set; } = "";
    public string SourceSha256 { get; set; } = "";
    public string Classification { get; set; } = "";
    public string Resolution { get; set; } = "OFFEN";
    public double? PreviousTariff { get; set; }
    public string Note { get; set; } = "";
    public List<TariffOccurrence> Occurrences { get; set; } = new();
    public bool Open => Resolution == "OFFEN";
}
public sealed class TariffCoverage
{
    public string Month { get; set; } = "";
    public string File { get; set; } = "";
    public string? TariffColumn { get; set; }
    public int SourceRecords { get; set; }
    public int KnownRecords { get; set; }
    public int PersonsInScope { get; set; }
    public int PersonsWithTxtRecord { get; set; }
    public int PersonsWithoutTxtRecord { get; set; }
    public int OpenTariffCases { get; set; }
}
public sealed class TariffReviewReport
{
    public string Schema { get; set; } = "MCR_IPP_TARIFF_REVIEW_V1";
    public string ContextSha256 { get; set; } = "";
    public string Policy { get; set; } = "BLOCK_PERSON_MONTH_CONTINUE_OTHERS";
    public List<TariffCase> Cases { get; set; } = new();
    public List<TariffCoverage> Coverage { get; set; } = new();
    public int OpenMonthCases => Cases.Count(c => c.Open);
    public int AffectedPersons => Cases.Where(c => c.Open).Select(c => c.ClientId).Distinct(StringComparer.Ordinal).Count();
}
public sealed record TariffMonthState(double? RawTariff, double? EffectiveTariff, bool ReviewRequired, string Status, string Reason);
public sealed record TariffPlan(TariffReviewReport Report, Dictionary<(string ClientId, int Month), TariffMonthState> States);

public static class TariffReview
{
    public static TariffPlan Analyze(IReadOnlyList<PersonResult> persons, IReadOnlyList<MonthFile> files, CancellationToken cancel = default)
    {
        var report = new TariffReviewReport();
        var states = new Dictionary<(string ClientId, int Month), TariffMonthState>();
        var previous = new Dictionary<string, double?>();
        var interrupted = new HashSet<string>(StringComparer.Ordinal);
        var ids = persons.Select(p => p.ClientId).ToHashSet(StringComparer.Ordinal);
        foreach (var file in files.OrderBy(f => f.Month))
        {
            cancel.ThrowIfCancellationRequested();
            string month = file.Month.ToString("yyyy-MM", Parse.Inv);
            var rows = new Dictionary<string, List<(Dictionary<string, string?> Row, int Record)>>(StringComparer.Ordinal);
            for (int i = 0; i < file.Rows.Count; i++)
            {
                var row = file.Rows[i]; string id = Parse.Id(row.GetValueOrDefault("KDMA_IDENT"));
                if (!ids.Contains(id)) continue; // Persons outside the baseline are owned by PersonReview.
                if (!rows.TryGetValue(id, out var list)) rows[id] = list = new();
                int number = file.OriginalRecordNumbers is not null && file.OriginalRecordNumbers.TryGetValue(row, out var n) ? n : i + 1;
                list.Add((row, number));
            }
            report.Coverage.Add(new()
            {
                Month = month, File = file.Name, TariffColumn = file.TariffColumn,
                SourceRecords = file.OriginalRecordCount ?? file.Rows.Count,
                KnownRecords = rows.Values.Sum(r => r.Count), PersonsInScope = persons.Count,
                PersonsWithTxtRecord = rows.Count, PersonsWithoutTxtRecord = persons.Count - rows.Count
            });
            foreach (var person in persons)
            {
                cancel.ThrowIfCancellationRequested();
                rows.TryGetValue(person.ClientId, out var current); current ??= new();
                previous.TryGetValue(person.ClientId, out var prev);
                var occurrences = new List<TariffOccurrence>();
                var valid = new HashSet<double>();
                bool invalid = false;
                foreach (var item in current)
                {
                    string? raw = file.TariffColumn is null ? null : item.Row.GetValueOrDefault(file.TariffColumn);
                    double? value = null; string? error = null;
                    try { value = Parse.Tariff(raw); }
                    catch (IppException ex) when (ex.Code is "TARIFF_INVALID" or "INVALID_NUMBER") { invalid = true; error = ex.Code; }
                    if (value is { } t) valid.Add(t);
                    occurrences.Add(new(file.Name, file.Source.Sha256, month, item.Record,
                        Parse.Text(item.Row.GetValueOrDefault("KDMA_IDENT")) ?? "[LEER]", file.TariffColumn, raw, value, error));
                }
                bool conflict = valid.Count > 1;
                double? rawTariff = !invalid && !conflict && valid.Count == 1 ? valid.Single() : null;
                // Only past evidence can be carried. A contradictory/unreadable update interrupts continuity.
                double? effective = invalid || conflict ? null : rawTariff ?? prev;
                string reason = invalid ? "TARIFF_VALUE_INVALID" : conflict ? "TARIFF_VALUES_CONFLICT"
                    : file.TariffColumn is null ? "TARIFF_COLUMN_MISSING"
                    : interrupted.Contains(person.ClientId) && effective is null ? "TARIFF_UNRESOLVED_AFTER_CONFLICT"
                    : current.Count == 0 ? "NO_TXT_RECORD_NO_PRIOR_TARIFF" : "TARIFF_EMPTY_NO_PRIOR_TARIFF";
                bool beforeEntry = person.Master.GetValueOrDefault("DAT_AD2") is DateOnly entry
                    && file.Month < new DateOnly(entry.Year, entry.Month, 1);
                bool needsReview = effective is null && !beforeEntry;
                string status = needsReview ? "BLOCKED_TARIFF_REVIEW" : beforeEntry ? "NOT_REQUIRED_BEFORE_ENTRY"
                    : rawTariff is not null ? "KNOWN_FROM_CURRENT_TXT" : "KNOWN_FROM_PRIOR_MONTH";
                states[(person.ClientId, file.Month.Month)] = new(rawTariff, effective, needsReview, status, reason);
                if (invalid || conflict) interrupted.Add(person.ClientId);
                else if (rawTariff is not null) interrupted.Remove(person.ClientId);
                previous[person.ClientId] = effective;
                if (!needsReview) continue;
                string name = string.Join(" ", new[] { Parse.Text(person.Master.GetValueOrDefault("FirstName")), Parse.Text(person.Master.GetValueOrDefault("Surname")) }.Where(x => !string.IsNullOrWhiteSpace(x)));
                string note = reason switch
                {
                    "NO_TXT_RECORD_NO_PRIOR_TARIFF" => "Keine TXT-Zeile fuer diese Bestands-ID in diesem Monat und kein zuvor bekannter Tarif. Das ist kein Nachweis eines Austritts.",
                    "TARIFF_COLUMN_MISSING" => "Keine Tarifklassenspalte und kein zuvor gesicherter Tarif. Quelldatei/Schema pruefen.",
                    "TARIFF_VALUE_INVALID" => "Mindestens ein Tarifwert ist nicht gueltig lesbar. Kein Rueckgriff auf einen aelteren Tarif nach widerspruechlicher Aenderung.",
                    "TARIFF_VALUES_CONFLICT" => "Mehrere unterschiedliche gueltige Tarife im selben Monat. Keine willkuerliche Auswahl der letzten Zeile.",
                    "TARIFF_UNRESOLVED_AFTER_CONFLICT" => "Ein vorheriger ungueltiger/widerspruechlicher Tarif ist noch nicht durch einen eindeutigen neuen Wert geklaert.",
                    _ => "TXT-Zeile vorhanden, Tarifwerte leer und kein zuvor bekannter Tarif. Keine pauschale Zulassung."
                };
                report.Cases.Add(new()
                {
                    CaseId = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes("MCR_IPP_TARIFF_REVIEW_V1\n" + person.ClientId + "\n" + month + "\n" + file.Source.Sha256))),
                    ClientId = person.ClientId, OriginalClientId = person.OriginalClientId,
                    DisplayName = name.Length == 0 ? "NAME_NICHT_GELIEFERT" : name,
                    Month = month, SourceFile = file.Name, SourceSha256 = file.Source.Sha256,
                    Classification = reason, PreviousTariff = prev, Occurrences = occurrences,
                    Note = note + " ATTC und Betrag bleiben leer (nicht 0 Euro); TZG bleibt unabhaengig sichtbar. Kein Rueckfuellen aus spaeteren Monaten."
                });
            }
        }
        report.Cases = report.Cases.OrderBy(c => c.ClientId, StringComparer.Ordinal).ThenBy(c => c.Month, StringComparer.Ordinal).ToList();
        FinalizeCoverage(report);
        return new(report, states);
    }
    public static void FinalizeCoverage(TariffReviewReport report)
    {
        foreach (var c in report.Coverage) c.OpenTariffCases = report.Cases.Count(p => p.Month == c.Month && p.Open);
    }
    public static void Write(string folder, TariffReviewReport report)
    {
        // Both calls (pre-calculation and final) replace only this run's own audit files atomically.
        string json = Path.Combine(folder, "Tarif_Pruefung.json");
        string book = Path.Combine(folder, "Tarifpruefung.xlsx");
        string temp = Path.Combine(folder, ".tariff_" + Guid.NewGuid().ToString("N") + ".tmp");
        JsonFiles.Write(temp, report); File.Move(temp, json, true);
        var people = report.Cases.GroupBy(c => c.ClientId, StringComparer.Ordinal).Select(g => new List<object?>
        {
            g.Key, g.First().DisplayName, g.Count(c => c.Open), string.Join(", ", g.Where(c => c.Open).Select(c => c.Month)),
            g.Any(c => c.Open) ? "TEILWEISE_GESPERRT" : "KEIN_OFFENER_TARIFFALL",
            "Nur offene Monate gesperrt. Keine automatische Beitragsbereitstellung und keine PDF-Freigabe."
        }).ToList();
        var months = report.Cases.Select(c => new List<object?> { c.ClientId, c.DisplayName, c.Month, c.Classification, c.Resolution,
            c.PreviousTariff, c.SourceFile, c.Note }).ToList();
        var sources = report.Cases.SelectMany(c => c.Occurrences.Select(o => new List<object?>
            { c.ClientId, c.Month, o.File, o.DataRecord, o.OriginalId, o.TariffColumn, o.RawTariff, o.ParsedTariff, o.Error, o.Sha256 })).ToList();
        var coverage = report.Coverage.Select(c => new List<object?> { c.Month, c.File, c.TariffColumn, c.SourceRecords, c.KnownRecords,
            c.PersonsInScope, c.PersonsWithTxtRecord, c.PersonsWithoutTxtRecord, c.OpenTariffCases }).ToList();
        foreach (var row in people.Concat(months).Concat(sources).Concat(coverage))
            for (int i = 0; i < row.Count; i++) if (row[i] is string text && text.Length > 30000) row[i] = text[..30000] + " [GEKUERZT; siehe JSON]";
        temp = Path.Combine(folder, ".tariff_" + Guid.NewGuid().ToString("N") + ".xlsx");
        try
        {
            SpreadsheetWriter.Write(temp,
                new OutputSheet("Personen", new() { "ClientID", "Name aus Bestand", "Offene Monate", "Monate gesperrt", "Status", "Hinweis" }, people) { ReviewLayout = true, ColumnWidths = new() { 16, 27, 14, 30, 30, 40 } },
                new OutputSheet("Monate", new() { "ClientID", "Name aus Bestand", "Monat", "Ursache", "Pruefstatus", "Vorheriger Tarif (kein Ersatz)", "Quelldatei", "Hinweis" }, months) { ReviewLayout = true, ColumnWidths = new() { 16, 27, 12, 35, 24, 20, 32, 40 } },
                new OutputSheet("Fundstellen", new() { "ClientID", "Monat", "TXT-Datei", "Datenrecord (nicht Textzeile)", "Original-ID", "Tarifspalte", "Tarif roh", "Tarif gelesen", "Lesefehler", "SHA256" }, sources) { ReviewLayout = true, ColumnWidths = new() { 16, 12, 32, 20, 18, 20, 26, 16, 22, 40 } },
                new OutputSheet("Abdeckung", new() { "Monat", "TXT-Datei", "Tarifspalte", "TXT-Datenrecords gesamt", "Bekannte Datenrecords", "Bestand im Lauf", "Mit TXT-Zeile", "Ohne TXT-Zeile", "Offene Tarifmonate" }, coverage) { ReviewLayout = true, ColumnWidths = new() { 12, 32, 20, 18, 18, 16, 18, 18, 18 } });
            File.Move(temp, book, true);
        }
        finally { if (File.Exists(temp)) File.Delete(temp); }
    }
}
