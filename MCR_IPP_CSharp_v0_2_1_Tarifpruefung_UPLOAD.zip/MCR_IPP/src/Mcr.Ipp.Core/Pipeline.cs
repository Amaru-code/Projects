using System.Security.Cryptography;
using System.Text;

namespace Mcr.Ipp.Core;

public sealed class RunRequest
{
    public string BaselinePath { get; set; } = "";
    public List<string> TxtPaths { get; set; } = new();
    public string OutputDirectory { get; set; } = "";
    public string? IppTemplatePath { get; set; }
    public ContributionOptions Options { get; set; } = new() { ReviewTariffIssues = true };
    public string? PersonDecisionsPath { get; set; }
}
public sealed record RunOutcome(string Directory, int Persons, int Months, int Warnings, string ContributionStatus, string IppStatus, string PdfStatus, int OpenPersonCases = 0, int NewPersonsAdded = 0, int OpenTariffMonths = 0, int PersonsWithOpenTariffs = 0);
public sealed class Pipeline
{
    public RunOutcome Execute(RunRequest request, Action<string>? progress = null, CancellationToken token = default)
    {
        if (string.IsNullOrWhiteSpace(request.OutputDirectory)) throw new IppException("OUTPUT_MISSING", "Ausgabeordner fehlt.");
        string output = Path.GetFullPath(request.OutputDirectory); Directory.CreateDirectory(output);
        string runId = "IPP_Run_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + "_" + Guid.NewGuid().ToString("N")[..8];
        string stage = Path.Combine(output, ".inprogress_" + runId), final = Path.Combine(output, runId);
        Directory.CreateDirectory(stage);
        try
        {
            progress?.Invoke("Lese Bestandsvorlage...");
            var baselineBlob = SourceBlob.Read(request.BaselinePath);
            using var reader = new SpreadsheetReader(baselineBlob.Bytes);
            var table = reader.Baseline(request.Options.BaselineSheet);
            var sources = request.TxtPaths.Select(SourceBlob.Read).ToList();
            var monthInputs = sources.Select(b => MonthReader.Read(b, request.Options)).ToList();
            progress?.Invoke("Gleiche alle TXT-Kennungen mit dem Bestand ab...");
            var decisions = new List<NewPersonDecision>();
            SourceBlob? decisionBlob = null;
            if (!string.IsNullOrWhiteSpace(request.PersonDecisionsPath) && File.Exists(request.PersonDecisionsPath))
            {
                decisionBlob = SourceBlob.Read(request.PersonDecisionsPath);
                decisions = System.Text.Json.JsonSerializer.Deserialize<List<NewPersonDecision>>(decisionBlob.Bytes, JsonFiles.Options)
                    ?? throw new IppException("DECISIONS_EMPTY", "Freigabedatei ohne gueltige Liste.");
            }
            var prepared = PersonReview.Prepare(table, baselineBlob.Info, monthInputs, decisions, token);
            // Persist all findings BEFORE calculation. They survive a later independent calculation error.
            PersonReview.Write(stage, prepared.Report);
            JsonFiles.Write(Path.Combine(stage, "Neuaufnahmen_Verwendet.json"), decisions.Where(d => d is not null && d.ContextSha256 == prepared.Report.ContextSha256 && prepared.Report.Cases.Any(c => c.CaseId == d.CaseId && c.Added)).ToList());
            progress?.Invoke($"Personenpruefung: {prepared.Report.OpenCases} offene Faelle; {prepared.Report.AddedPersons} bestaetigte Neuaufnahmen. Uebriger Bestand laeuft weiter.");
            TariffReviewReport? latestTariffReport = null;
            var result = new ContributionEngine().Run(prepared.Baseline, prepared.Months, request.Options, progress, token,
                tariffReviewReady: report =>
                {
                    report.ContextSha256 = prepared.Report.ContextSha256;
                    TariffReview.Write(stage, report);
                    if (latestTariffReport is null)
                        progress?.Invoke($"Tarifpruefung: {report.OpenMonthCases} offene Personenmonate bei {report.AffectedPersons} Personen. ATTC/Betrag dieser Monate bleiben leer; uebrige Faelle laufen weiter.");
                    latestTariffReport = report;
                });
            result.PersonReview = prepared.Report;
            foreach (var c in prepared.Report.Cases)
                result.Warnings.Add(new Warning(c.Added ? "NEW_PERSON_CONFIRMED_ADDED" : "TXT_PERSON_REVIEW_OPEN", c.Added ? "Bestaetigter Neueintritt aufgenommen; siehe Prueffaelle.xlsx." : "Person separat in Prueffaelle.xlsx; NICHT im Beitragsergebnis enthalten.", c.ClientId));
            if (request.Options.AllowUnknownTxtPersons) result.Warnings.Add(new Warning("LEGACY_IGNORE_REPLACED", "Pipeline verwendet immer Prueffaelle statt stilles Ignorieren."));
            if (decisionBlob is not null) result.Inputs.Add(decisionBlob.Info);
            if (prepared.Report.AddedPersons > 0)
                SpreadsheetWriter.Write(Path.Combine(stage, "Bestand_Fortgeschrieben.xlsx"), PersonReview.BaselineCopy(prepared.Baseline));
            result.Inputs.Insert(0, baselineBlob.Info);
            progress?.Invoke("Schreibe Ergebnis.xlsx und Rechenprotokoll...");
            SpreadsheetWriter.Write(Path.Combine(stage, "Ergebnis.xlsx"), SpreadsheetWriter.Contributions(result));
            JsonFiles.Write(Path.Combine(stage, "Contribution_Result.json"), result);
            JsonFiles.Write(Path.Combine(stage, "Options_used.json"), request.Options);
            WriteTrace(Path.Combine(stage, "Monatsprotokoll.csv"), result);
            string ippStatus = "NOT_REQUESTED";
            if (!string.IsNullOrWhiteSpace(request.IppTemplatePath))
            {
                token.ThrowIfCancellationRequested(); progress?.Invoke("Pruefe ausschliesslich die IPP-Vorlage...");
                try
                {
                    var ipp = SourceBlob.Read(request.IppTemplatePath);
                    var audit = TemplatePreparation.Inspect(ipp);
                    JsonFiles.Write(Path.Combine(stage, "IPP_Pruefung.json"), audit);
                    if (audit.MatchesKnownIppTemplate)
                    {
                        var proof = TemplatePreparation.CreateStagingCopy(ipp, result, Path.Combine(stage, "IPP_VORBEREITUNG_NICHT_FREIGEGEBEN.xlsm"));
                        JsonFiles.Write(Path.Combine(stage, "IPP_Staging_Proof.json"), proof);
                        ippStatus = "STAGING_ONLY_MAPPING_NOT_BOUND";
                    }
                    else ippStatus = "BLOCKED_TEMPLATE_IDENTITY";
                }
                catch (IppException ex)
                {
                    ippStatus = "BLOCKED_" + ex.Code;
                    JsonFiles.Write(Path.Combine(stage, "IPP_Fehler.json"), new { code = ex.Code, message = ex.Message });
                }
            }
            token.ThrowIfCancellationRequested();
            int tariffMonths = result.TariffReview?.OpenMonthCases ?? 0;
            int tariffPeople = result.TariffReview?.AffectedPersons ?? 0;
            string contributionStatus = prepared.Report.OpenCases > 0 && tariffMonths > 0 ? "PARTIAL_PERSON_AND_TARIFF_REVIEW_REQUIRED"
                : prepared.Report.OpenCases > 0 ? "PARTIAL_PERSON_REVIEW_REQUIRED"
                : tariffMonths > 0 ? "PARTIAL_TARIFF_REVIEW_REQUIRED" : "EXPORTED_NOT_BUSINESS_CERTIFIED";
            var outcome = new RunOutcome(final, result.Persons.Count, result.Months.Count, result.Warnings.Count, contributionStatus,
                ippStatus, "NOT_AUTHORIZED", prepared.Report.OpenCases, prepared.Report.AddedPersons, tariffMonths, tariffPeople);
            JsonFiles.Write(Path.Combine(stage, "Run_Report.json"), new { app = "MCR_IPP", version = "0.2.1", scope = "IPP_NOT_DC", utc = DateTimeOffset.UtcNow, outcome, inputs = result.Inputs, rules = ContributionFormula.Periods, pythonReceivedPatch = "T01 decimal-comma tuple; T02 open-ended sentinel", fullPythonParityCertified = false, economicRulesApproved = false, pdfsCreated = 0 });
            File.WriteAllText(Path.Combine(stage, "00_LAUF_LESEN.txt"), $"MCR IPP V0.2.1\n\nLAUFSTATUS: {outcome.ContributionStatus}\nOFFENE PERSONENFAELLE: {prepared.Report.OpenCases} (NICHT im Beitragsergebnis)\nBESTAETIGTE NEUAUFNAHMEN: {prepared.Report.AddedPersons}\nPRUEFLISTE PERSONEN: Prueffaelle.xlsx / Personen_Pruefung.json\nOFFENE TARIFMONATE: {tariffMonths} bei {tariffPeople} Personen\nPRUEFLISTE TARIFE: Tarifpruefung.xlsx / Tarif_Pruefung.json (bei aktivierter Tarifpruefung)\n\nBEITRAGSTABELLE: {result.Persons.Count} Personen / {result.Months.Count} Monate exportiert. Leere Monatswerte anhand der Pruef- und Monatsprotokolle einordnen.\nOHNE OFFENE TARIFPRUEFUNG: {result.Persons.Count - tariffPeople} Personen (keine fachliche Vollstaendigkeitsfreigabe).\nGESPERRTE TARIFMONATE: ATTC und Betrag leer, NICHT 0 Euro; TZG bleibt unabhaengig sichtbar.\nMonate ohne Tarif nicht aufsummieren oder fuer Dokumente freigeben. Keine Rueckfuellung aus spaeteren Monaten.\nWARNUNGEN: {result.Warnings.Count}; Monatsprotokoll und JSON pruefen.\nIPP: {ippStatus}\nPDF: NICHT FREIGEGEBEN. Keine freigegebene LNW erstellt.\n\nErgebnis.xlsx ist der C#-Beitragsoutput. Eine IPP_VORBEREITUNG-Kopie enthaelt nur zusaetzliche Staging-Blaetter; alte Importdaten sind unveraendert.\nKeine automatische Beitragsbereitstellung, Saldenuebernahme oder Fallentscheidung.\nAlle Originaldateien wurden nur gelesen.\n", new UTF8Encoding(false));
            var manifest = Directory.GetFiles(stage).OrderBy(Path.GetFileName, StringComparer.Ordinal).Select(p => new { file = Path.GetFileName(p), bytes = new FileInfo(p).Length, sha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(p))) }).ToList();
            JsonFiles.Write(Path.Combine(stage, "Manifest.json"), manifest);
            Directory.Move(stage, final); progress?.Invoke(prepared.Report.OpenCases > 0 || tariffMonths > 0 ? "TEILERGEBNIS erstellt: Prueffaelle.xlsx und Tarifpruefung.xlsx pruefen. Kein vollstaendiger Gesamtlauf." : "Beitragsexport erstellt. IPP/PDF bleibt gesondert gekennzeichnet.");
            return outcome;
        }
        catch (Exception ex)
        {
            // Preserve failed run evidence locally; never label partial output as successful.
            ex.Data["RunDirectory"] = stage;
            try { File.WriteAllText(Path.Combine(stage, "00_LAUF_LESEN.txt"), "STATUS=FAILED_NOT_PUBLISHED\nVorhandene Personen-/Tarifpruefung bleibt lokal erhalten. Keine fertigen Beitraege freigegeben.\n" + ex.Message); JsonFiles.Write(Path.Combine(stage, "FAILED.json"), new { status = "FAILED_NOT_PUBLISHED", code = ex is IppException ie ? ie.Code : ex.GetType().Name, message = ex.Message }); }
            catch { /* Original exception must be retained. */ }
            throw;
        }
    }
    private static void WriteTrace(string path, ContributionResult result)
    {
        string Q(string? s) => "\"" + (s ?? "").Replace("\"", "\"\"") + "\"";
        using var writer = new StreamWriter(path, false, new UTF8Encoding(true));
        writer.WriteLine("ClientID;Monat;ATTC_Quelle;TZG_Quelle;Tarifklasse;Gruende;Tarif_Pruefstatus;Tarif_Pruefung_Offen");
        foreach (var p in result.Persons) foreach (var r in p.Months.Values)
            writer.WriteLine(string.Join(";", Q(p.ClientId), Q(r.SalaryDate.ToString("yyyy-MM")), Q(r.AttcSource), Q(r.TzgSource), Q(r.EffectiveTariff?.ToString(Parse.Inv)), Q(string.Join("|", r.Reasons)), Q(r.TariffStatus), Q(r.TariffReviewRequired ? "JA" : "NEIN")));
    }
}
