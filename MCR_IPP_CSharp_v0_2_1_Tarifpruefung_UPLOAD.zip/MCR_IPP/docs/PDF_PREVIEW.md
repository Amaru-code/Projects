# Excel-PDF-Adapter: Entwicklungsvorschau, nicht Produktion

`ExcelPreviewRenderer.cs` enthält einen mechanischen Vorschaupfad für bereits manuell
geprüfte, selbständige IPP-UVA-Arbeitskopien. Der Beitragsexport ruft ihn nicht auf.
Die bekannte Original-IPP-Vorlage wird derzeit wegen ihrer externen Quellen/UDFs und
beschädigten Formeln abgelehnt. Keine bestehenden Links oder Schutzfunktionen werden
automatisch entfernt, keine VBA-Projekt-Zugriffsrechte freigegeben.

## Zulässige Eingabe

Ein `PreviewJob` benennt eine konkrete Arbeitsmappe, deren erwarteten SHA256, ein
belegtes IPP-UVA-Blatt, einzelne Datensatzindizes (maximal 100) und einen Ausgabeordner.
`mode` muss PREVIEW_ONLY sein. Ein Beispiel steht in config, ist absichtlich nicht
als ausführbare Freigabe ausgefüllt. Alle Felder sind technische Voraussetzungen,
keine automatische fachliche oder rechtliche Anerkennung der Datensätze.

Der Adapter lehnt externe Arbeitsmappenverweise, aktive eingebettete Objekte,
Abfrage-/Verbindungsbestandteile, XLM-Makroblätter, Paket-Signaturen und erkannte #REF-
Formeln ab. Vorhandene EXCEL-Prozesse führen zum Abbruch; nie werden fremde Prozesse
beendet. Es wird eine neue Arbeitskopie angelegt. Excel wird über einen eigenen
COM-Aufruf mit deaktivierten Ereignissen und AutomationSecurity=3 angesprochen.
Dies ist keine Sandbox: lokale Office-Add-ins und die Firmenumgebung liegen außerhalb
der technischen Qualifikation dieser ZIP.

## Ablauf der mechanischen Vorschau

I1 wird gesetzt; vollständige Berechnung mit CalculateFullRebuild; Warten auf Abschluss;
Kontrolle des WWID-Selektors gegen Importzeile index+1; Prüfung relevanter Pflichtfelder;
Ablehnung von Fehler-/###-Anzeigen im Ausgabe-Blatt; expliziter Druckbereich erforderlich.
Der vorhandene Filter G82:G85 wird exakt wie im übermittelten VBA gesetzt (Zeile82
fungiert dabei als Filterkopf). Der Seitenkopf bekommt das Wasserzeichen
ENTWURF – NICHT FREIGEGEBEN. Export über ExportAsFixedFormat. Individuelle Dateinamen
enthalten nur den Datensatzindex, keine geratenen Namen; PDFs werden auf Signatur
und Hash geprüft, bevor der Vorschauordner veröffentlicht wird.

Excel schließt ohne Speichern; keine Datenzuordnung und keine neue LNW-Arbeitsmappe
werden daraus abgeleitet. Ein COM-Aufruf kann in bestimmten Office-Situationen selbst
blockieren; der Polling-Timeout ist keine Garantie gegen jeden COM-Hänger. Es gibt
in V0.1 keinen produktionsqualifizierten Watchdog. Bei Hängern Arbeiten sichern und
nur die identifizierte Vorschauinstanz kontrolliert schließen. Kein `taskkill /IM EXCEL`.

## Ausführung

`PDF_VORSCHAU_ENTWICKLUNG.cmd "C:\Pfad\preview-job.json"`.
Voraussetzung: Windows, vorhandenes Desktop-Excel und erfolgreicher lokaler Build.
Auf diesem Erstellungsrechner wurde der COM-Pfad nicht ausgeführt. Auch ein erfolgreicher
Vorschau-Export ist kein Ende-zu-Ende-Paritätsnachweis und nicht zum Versand vorgesehen.
