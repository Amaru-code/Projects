# Nächster IPP-Workstream nach Personen- und Tarifprüfung

0. Realdatenlauf V0.2.1: neue Tarif-Prüfliste lokal prüfen. Ursache je Personenmonat
   ermitteln, keine rückwirkende Tariffüllung aus späteren Monaten. Vier übermittelte
   Personen-Kandidaten bleiben ohne Benutzerbestätigung offen.
1. Realdaten-Qualifikation der Monatsbeiträge: gleicher Bestand, gleiche TXT-Auswahl,
   explizite Personenpopulation, C# gegen korrigierte Python-Referenz. Bekannte
   Abweichungen (Aufnahmen, fehlende Werte, Prüfstopps) getrennt vom Geldkern behandeln.
2. Beitragsübergabe definieren: fachlich festgelegter Zeitraum/Rundung/Korrekturen für
   Beitragsbereitstellung, Quelle für beitragsfähige Bezüge, keine feste AF-Position
   oder ungeprüfte Summe. Personenzuordnung ClientID/WWID und Saldenquelle qualifizieren.
3. Ausschließlich bekannte IPP-Vorlage befüllen, UDF-/Fall-/Layoutpfad qualifizieren,
   kleine anonymisierte Referenzfälle und PDF-Parität vor jeglicher Produktionsfreigabe.

Personenprüfung und Status-/Mapping-Code können unabhängig gebaut/getestet werden.
Offene wirtschaftliche Regeln werden nicht durch technische Tests freigegeben.
