﻿[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$ModeRoot = $PSScriptRoot
$SrcRoot = Join-Path $ModeRoot 'src'
$BuildRoot = Join-Path $ModeRoot 'build'
$Publish = Join-Path $BuildRoot 'publish'
$Pointer = Join-Path $BuildRoot 'rscript_path.txt'
$MainSource = Join-Path $SrcRoot 'main.R'
$MainPublish = Join-Path $Publish 'main.R'

function Test-Rscript([string]$Path) {
    if ([string]::IsNullOrWhiteSpace($Path) -or -not (Test-Path $Path -PathType Leaf)) { return $false }

    $old=$ErrorActionPreference
    $ErrorActionPreference='Continue'
    try {
        $v = & $Path --version 2>&1
        $c = $LASTEXITCODE
    }
    catch {
        return $false
    }
    finally {
        $ErrorActionPreference=$old
    }

    # Different Windows R builds print slightly different --version banners,
    # e.g. "Rscript (R) version ..." instead of "R version ...".
    # A successful native exit code plus a non-empty R/Rscript version banner
    # is the robust runtime check.
    $banner = ($v -join ' ').Trim()
    return (
        $c -eq 0 -and
        -not [string]::IsNullOrWhiteSpace($banner) -and
        $banner -match '(?i)\bRscript\b|\bR\b.*\bversion\b|\bversion\b.*\bR\b'
    )
}

$Candidates = New-Object System.Collections.Generic.List[string]
$cmd = Get-Command Rscript.exe -ErrorAction SilentlyContinue
if ($cmd) { $Candidates.Add($cmd.Source) }
if ($env:USERPROFILE) {
    foreach ($root in @(
        (Join-Path $env:USERPROFILE 'projects\Compiler\r'),
        (Join-Path $env:USERPROFILE 'projects\Compiler\R')
    )) {
        if (Test-Path $root) {
            Get-ChildItem $root -Recurse -Filter Rscript.exe -File -ErrorAction SilentlyContinue | ForEach-Object {
                if (-not $Candidates.Contains($_.FullName)) { $Candidates.Add($_.FullName) }
            }
        }
    }
}
foreach ($root in @('C:\Program Files\R','C:\Program Files (x86)\R')) {
    if (Test-Path $root) {
        Get-ChildItem $root -Recurse -Filter Rscript.exe -File -ErrorAction SilentlyContinue | ForEach-Object {
            if (-not $Candidates.Contains($_.FullName)) { $Candidates.Add($_.FullName) }
        }
    }
}

$Rscript=$null
foreach($c in $Candidates){if(Test-Rscript $c){$Rscript=$c;break}}

# If R is not present, bootstrap a portable, relocatable Windows build.
# This does NOT run an installer and does NOT create a new native executable.
# It downloads a prebuilt R runtime ZIP and extracts it below projects\Compiler\r.
if(-not $Rscript){
    $RVersion = '4.6.1'
    $CompilerRoot = Join-Path $env:USERPROFILE 'projects\Compiler\r'
    $ToolsRoot = Join-Path $CompilerRoot 'tools'
    $DownloadRoot = Join-Path $CompilerRoot '_downloads'
    $Archive = Join-Path $DownloadRoot "R-$RVersion-windows.zip"
    $PortableUrl = "https://cdn.posit.co/r/windows/R-$RVersion-windows.zip"

    New-Item -ItemType Directory -Force -Path $ToolsRoot,$DownloadRoot | Out-Null

    Write-Host ''
    Write-Host 'Rscript.exe wurde nicht gefunden.' -ForegroundColor Yellow
    Write-Host "Lade portable R $RVersion Runtime (ZIP, kein Installer)..." -ForegroundColor Yellow
    Write-Host "Quelle: $PortableUrl"

    if(-not(Test-Path $Archive -PathType Leaf)){
        $ProgressPreference='SilentlyContinue'
        Invoke-WebRequest -Uri $PortableUrl -OutFile $Archive -UseBasicParsing
    }

    if(-not(Test-Path $Archive -PathType Leaf)){
        throw "Portable R Download fehlgeschlagen: $Archive"
    }

    $ArchiveHash=(Get-FileHash $Archive -Algorithm SHA256).Hash.ToLower()
    Write-Host "Portable R ZIP SHA256: $ArchiveHash"

    $ExtractRoot = Join-Path $ToolsRoot "R-$RVersion"
    if(Test-Path $ExtractRoot){
        Remove-Item $ExtractRoot -Recurse -Force
    }

    $TempExtract = Join-Path $env:TEMP "MCR_Portable_R_$RVersion"
    Remove-Item $TempExtract -Recurse -Force -ErrorAction SilentlyContinue
    New-Item -ItemType Directory -Force -Path $TempExtract | Out-Null

    Expand-Archive $Archive $TempExtract -Force

    $FoundRscript = Get-ChildItem $TempExtract -Recurse -Filter Rscript.exe -File -ErrorAction SilentlyContinue |
        Select-Object -First 1

    if(-not $FoundRscript){
        throw 'Portable R ZIP wurde entpackt, aber Rscript.exe wurde nicht gefunden.'
    }

    $PortableRoot = Split-Path (Split-Path $FoundRscript.FullName -Parent) -Parent
    New-Item -ItemType Directory -Force -Path $ExtractRoot | Out-Null
    Copy-Item (Join-Path $PortableRoot '*') $ExtractRoot -Recurse -Force

    Remove-Item $TempExtract -Recurse -Force -ErrorAction SilentlyContinue

    $PortableRscript = Join-Path $ExtractRoot 'bin\Rscript.exe'
    if(-not(Test-Path $PortableRscript -PathType Leaf)){
        throw "Portable R Runtime wurde entpackt, aber Rscript.exe fehlt am erwarteten Pfad: $PortableRscript"
    }

    if(-not(Test-Rscript $PortableRscript)){
        Write-Host ''
        Write-Host 'Rscript Runtime-Check fehlgeschlagen. Direkte Diagnose:' -ForegroundColor Yellow
        $old=$ErrorActionPreference
        $ErrorActionPreference='Continue'
        try {
            $diag = & $PortableRscript --version 2>&1
            $diagCode = $LASTEXITCODE
        }
        catch {
            $diag = $_.Exception.Message
            $diagCode = $null
        }
        finally {
            $ErrorActionPreference=$old
        }
        Write-Host "      Pfad:     $PortableRscript"
        Write-Host "      ExitCode: $diagCode"
        Write-Host "      Output:   $($diag -join ' ')"
        throw "Portable R Runtime wurde entpackt, aber der Runtime-Check ist fehlgeschlagen: $PortableRscript"
    }

    $Rscript=$PortableRscript

    Write-Host "Portable R Runtime: PASS" -ForegroundColor Green
    Write-Host "Rscript: $Rscript"
    Write-Host "Version: $((& $Rscript --version 2>&1) -join ' ')"
}

Write-Host '============================================================'
Write-Host ' Level 05A.2 - R Parity Build'
Write-Host '============================================================'
Write-Host "Rscript:   $Rscript"
& $Rscript --version
Write-Host "Source:    $MainSource"
Write-Host "Publish:   $Publish"
Write-Host ''
Write-Host 'Dependencies: existing or auto-bootstrapped portable R runtime + base/recommended R only'
Write-Host 'External R packages: NONE'
Write-Host 'Native candidate EXE generation: NONE'
Write-Host ''

if(Test-Path $Publish){Remove-Item $Publish -Recurse -Force}
New-Item -ItemType Directory -Force -Path $Publish | Out-Null
Copy-Item $MainSource $MainPublish -Force
Copy-Item (Join-Path $SrcRoot 'excel_bridge.ps1') (Join-Path $Publish 'excel_bridge.ps1') -Force
New-Item -ItemType Directory -Force -Path (Join-Path $Publish 'resources') | Out-Null
Copy-Item (Join-Path $SrcRoot 'resources\settings.json') (Join-Path $Publish 'resources\settings.json') -Force
Copy-Item (Join-Path $SrcRoot 'resources\wwid_mapping.csv') (Join-Path $Publish 'resources\wwid_mapping.csv') -Force
New-Item -ItemType Directory -Force -Path $BuildRoot | Out-Null
Set-Content $Pointer $Rscript -Encoding ASCII

# Parse-only preflight via a tiny .R file to avoid Windows native -e quoting.
$Check = Join-Path $BuildRoot '_source_check.R'
@'
args <- commandArgs(trailingOnly=TRUE)
invisible(parse(file=args[[1]]))
cat("R_SOURCE_OK\n")
'@ | Set-Content $Check -Encoding ASCII
$CheckLog = Join-Path $BuildRoot '_source_check.log'
Remove-Item $CheckLog -Force -ErrorAction SilentlyContinue

$old=$ErrorActionPreference
$ErrorActionPreference='Continue'
try {
    & $Rscript --vanilla $Check $MainPublish *> $CheckLog
    $Code=$LASTEXITCODE
} finally {
    $ErrorActionPreference=$old
}

Remove-Item $Check -Force -ErrorAction SilentlyContinue

if($Code -ne 0){
    if(Test-Path $CheckLog){
        Write-Host ''
        Get-Content $CheckLog -Tail 80
    }
    throw "R Source Check fehlgeschlagen. ExitCode=$Code"
}

Write-Host 'R_SOURCE_OK' -ForegroundColor Green
Remove-Item $CheckLog -Force -ErrorAction SilentlyContinue

Write-Host ''
Write-Host 'R PARITY BUILD: PASS' -ForegroundColor Green
Write-Host "MAIN: $MainPublish"
Write-Host 'Runtime: existing Rscript.exe (no new native EXE)' -ForegroundColor Green
exit 0
