﻿[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [ValidateSet('Snapshot','Apply','WriteTable','WriteTablesBatch')]
    [string]$Mode,

    [Parameter(Mandatory=$true)]
    [string]$Workbook,

    [string]$SnapshotPath,
    [string]$PlanPath,
    [string]$CsvPath,
    [string]$TablePath,
    [string]$SheetName = 'Gesamtdaten',
    [string]$BatchManifest
)

$ErrorActionPreference = 'Stop'
$Invariant = [System.Globalization.CultureInfo]::InvariantCulture

function Release-Com([object]$Object) {
    if ($null -eq $Object) { return }
    try {
        if ([System.Runtime.InteropServices.Marshal]::IsComObject($Object)) {
            [void][System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($Object)
        }
    } catch {}
}

function Normalize-Header([object]$Value) {
    if ($null -eq $Value) { return '' }
    $s = [Convert]::ToString($Value, $Invariant).Replace([char]0x00A0,' ').Trim().ToLowerInvariant()
    $s = $s.Replace('ä','ae').Replace('ö','oe').Replace('ü','ue').Replace('ß','ss')
    return [regex]::Replace($s, '[^a-z0-9]+', '')
}

function Normalize-Wwid([object]$Value) {
    if ($null -eq $Value) { return '' }
    if ($Value -is [double]) {
        $d = [double]$Value
        if ([math]::Abs($d % 1.0) -lt [double]::Epsilon) { return ([long]$d).ToString($Invariant) }
    }
    $s = [Convert]::ToString($Value, $Invariant).Trim()
    if ($s.EndsWith('.0') -and $s.Substring(0,$s.Length-2) -match '^\d+$') { return $s.Substring(0,$s.Length-2) }
    return $s
}

function Number-Text([object]$Value) {
    if ($null -eq $Value) { return '0' }
    try { return ([Convert]::ToDouble($Value, $Invariant)).ToString('R',$Invariant) }
    catch { return '0' }
}

function Csv-Escape([string]$Value) {
    if ($null -eq $Value) { $Value = '' }
    if ($Value.Contains(';') -or $Value.Contains('"') -or $Value.Contains("`r") -or $Value.Contains("`n")) {
        return '"' + $Value.Replace('"','""') + '"'
    }
    return $Value
}

function Float-Text([double]$Value) {
    if ([double]::IsNaN($Value)) { return 'nan' }
    if ([double]::IsPositiveInfinity($Value)) { return 'inf' }
    if ([double]::IsNegativeInfinity($Value)) { return '-inf' }
    if ($Value -eq 0.0) { return '0.0' }

    # Python's csv.writer receives these Excel COM values as Python floats.
    # Python repr keeps ".0" for integral floats (e.g. 1.0, 9999999.0),
    # whereas .NET Double.ToString("R") emits "1" / "9999999".
    # The certified Golden CSV therefore requires the explicit .0 suffix.
    if ($Value -eq [math]::Truncate($Value)) {
        return $Value.ToString('0.0',$Invariant)
    }

    return $Value.ToString('R',$Invariant).Replace('E','e')
}

function Csv-Value([object]$Value) {
    if ($null -eq $Value) { return '' }
    if ($Value -is [string]) { return [string]$Value }
    if ($Value -is [bool]) { if ($Value) { return 'True' } else { return 'False' } }
    if ($Value -is [System.Runtime.InteropServices.ErrorWrapper]) { return $Value.ErrorCode.ToString($Invariant) }
    if ($Value -is [double] -or $Value -is [float]) { return Float-Text ([double]$Value) }
    return [Convert]::ToString($Value,$Invariant)
}

function Column-Name([int]$Column) {
    $chars = New-Object System.Collections.Generic.Stack[char]
    while ($Column -gt 0) {
        $Column--
        $chars.Push([char]([int][char]'A' + ($Column % 26)))
        $Column = [math]::Floor($Column / 26)
    }
    return -join $chars.ToArray()
}

function Xlsx-XmlEscape([string]$Value) {
    if ($null -eq $Value) { return '' }
    return [System.Security.SecurityElement]::Escape($Value)
}

function Add-ZipText($Archive,[string]$Name,[string]$Text) {
    $entry = $Archive.CreateEntry($Name,[System.IO.Compression.CompressionLevel]::Fastest)
    $stream = $entry.Open()
    $writer = [System.IO.StreamWriter]::new($stream,[System.Text.UTF8Encoding]::new($false))
    try { $writer.Write($Text) } finally { $writer.Dispose(); $stream.Dispose() }
}

function Write-MinimalXlsx([string]$Path,[string]$Sheet,[string]$TsvPath) {
    Add-Type -AssemblyName System.IO.Compression -ErrorAction SilentlyContinue
    Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue

    $rows = @(Import-Csv -Path $TsvPath -Delimiter "`t" -Encoding UTF8)
    if ($rows.Count -gt 0) {
        $headers = @($rows[0].PSObject.Properties.Name)
    }
    else {
        $first = Get-Content $TsvPath -First 1 -Encoding UTF8
        if ([string]::IsNullOrWhiteSpace($first)) { throw 'TSV has no header.' }

        # Parse a quoted TSV header directly. R write.table writes headers as
        # standard CSV-style quoted fields, with doubled quotes inside fields.
        $headersList = New-Object System.Collections.Generic.List[string]
        $field = New-Object System.Text.StringBuilder
        $quoted = $false
        for ($i=0; $i -lt $first.Length; $i++) {
            $ch = $first[$i]
            if ($ch -eq '"') {
                if ($quoted -and $i + 1 -lt $first.Length -and $first[$i+1] -eq '"') {
                    [void]$field.Append('"')
                    $i++
                } else {
                    $quoted = -not $quoted
                }
            } elseif ($ch -eq "`t" -and -not $quoted) {
                $headersList.Add($field.ToString())
                [void]$field.Clear()
            } else {
                [void]$field.Append($ch)
            }
        }
        $headersList.Add($field.ToString())
        $headers = @($headersList.ToArray())

        if ($headers.Count -lt 1) { throw 'Could not parse TSV header.' }
    }
    $cols = $headers.Count
    if ($cols -lt 1) { throw 'TSV has no columns.' }

    $sheetXml = [System.Text.StringBuilder]::new()
    [void]$sheetXml.Append('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>')

    function Append-Row([int]$RowNo,[string[]]$Values) {
        [void]$sheetXml.Append('<row r="').Append($RowNo).Append('">')
        for ($c=0; $c -lt $Values.Count; $c++) {
            $value = if ($null -eq $Values[$c]) { '' } else { [string]$Values[$c] }
            if ($value.Length -eq 0) { continue }
            $cell = (Column-Name ($c+1)) + $RowNo
            $escaped = Xlsx-XmlEscape $value
            $preserve = ($value.Length -gt 0 -and ([char]::IsWhiteSpace($value[0]) -or [char]::IsWhiteSpace($value[$value.Length-1])))
            [void]$sheetXml.Append('<c r="').Append($cell).Append('" t="inlineStr"><is><t')
            if ($preserve) { [void]$sheetXml.Append(' xml:space="preserve"') }
            [void]$sheetXml.Append('>').Append($escaped).Append('</t></is></c>')
        }
        [void]$sheetXml.Append('</row>')
    }

    Append-Row 1 ([string[]]$headers)
    for ($r=0; $r -lt $rows.Count; $r++) {
        $vals = New-Object string[] $cols
        for ($c=0; $c -lt $cols; $c++) {
            $prop = $rows[$r].PSObject.Properties[$headers[$c]]
            $vals[$c] = if ($null -eq $prop -or $null -eq $prop.Value) { '' } else { [string]$prop.Value }
        }
        Append-Row ($r+2) $vals
    }
    [void]$sheetXml.Append('</sheetData></worksheet>')

    $sheetEsc = Xlsx-XmlEscape $Sheet
    $contentTypes = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>'
    $rootRels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'
    $workbook = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="' + $sheetEsc + '" sheetId="1" r:id="rId1"/></sheets></workbook>'
    $workbookRels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>'

    $dir = Split-Path -Parent $Path
    if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    if (Test-Path $Path) { Remove-Item $Path -Force }
    $fs = [System.IO.File]::Open($Path,[System.IO.FileMode]::CreateNew,[System.IO.FileAccess]::ReadWrite,[System.IO.FileShare]::None)
    $zip = [System.IO.Compression.ZipArchive]::new($fs,[System.IO.Compression.ZipArchiveMode]::Create,$false)
    try {
        Add-ZipText $zip '[Content_Types].xml' $contentTypes
        Add-ZipText $zip '_rels/.rels' $rootRels
        Add-ZipText $zip 'xl/workbook.xml' $workbook
        Add-ZipText $zip 'xl/_rels/workbook.xml.rels' $workbookRels
        Add-ZipText $zip 'xl/worksheets/sheet1.xml' $sheetXml.ToString()
    } finally { $zip.Dispose(); $fs.Dispose() }
}

if ($Mode -eq 'WriteTable') {
    if ([string]::IsNullOrWhiteSpace($TablePath)) { throw 'TablePath missing.' }
    if (-not (Test-Path $TablePath -PathType Leaf)) { throw "TablePath not found: $TablePath" }
    Write-MinimalXlsx $Workbook $SheetName $TablePath
    Write-Host "[XLSX] WriteTable abgeschlossen. Sheet=$SheetName"
    return
}

if ($Mode -eq 'WriteTablesBatch') {
    if ([string]::IsNullOrWhiteSpace($BatchManifest)) { throw 'BatchManifest missing.' }
    if (-not (Test-Path $BatchManifest -PathType Leaf)) { throw "BatchManifest not found: $BatchManifest" }
    $count = 0
    foreach ($line in Get-Content $BatchManifest -Encoding UTF8) {
        if ([string]::IsNullOrWhiteSpace($line)) { continue }
        $p = $line.Split("`t")
        if ($p.Count -lt 3) { throw "Invalid batch manifest line: $line" }
        Write-MinimalXlsx $p[0] $p[1] $p[2]
        $count++
    }
    Write-Host "[XLSX] WriteTablesBatch abgeschlossen. Files=$count"
    return
}

$excel = $null
$book = $null
$sheet = $null
try {
    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $excel.DisplayAlerts = $false
    $excel.EnableEvents = $false
    $excel.ScreenUpdating = $false
    $excel.AskToUpdateLinks = $false
    $book = $excel.Workbooks.Open($Workbook,0,$false)
    $sheet = $book.Worksheets.Item('Import DC LNW')

    $usedCols = [math]::Max([int]$sheet.UsedRange.Columns.Count, 99)
    $headerRow = 0
    $wwidCol = 0
    for ($r=1; $r -le 30 -and $headerRow -eq 0; $r++) {
        for ($c=1; $c -le $usedCols; $c++) {
            if ((Normalize-Header $sheet.Cells.Item($r,$c).Value2) -eq 'wwid') {
                $headerRow = $r; $wwidCol = $c; break
            }
        }
    }
    if ($headerRow -eq 0) { throw 'WWID header not found.' }
    $lastRow = [int]$sheet.Cells.Item($sheet.Rows.Count,$wwidCol).End(-4162).Row
    if ($lastRow -le $headerRow) { throw 'No WWID rows found.' }

    if ($Mode -eq 'Snapshot') {
        if ([string]::IsNullOrWhiteSpace($SnapshotPath)) { throw 'SnapshotPath missing.' }
        $enc = [System.Text.UTF8Encoding]::new($false)
        $sw = [System.IO.StreamWriter]::new($SnapshotPath,$false,$enc)
        try {
            $sw.WriteLine("META`t$headerRow`t$wwidCol`t$lastRow")
            $prevCols = 90..99 # CL:CU
            for ($r=$headerRow+1; $r -le $lastRow; $r++) {
                $wwid = Normalize-Wwid $sheet.Cells.Item($r,$wwidCol).Value2
                $parts = New-Object System.Collections.Generic.List[string]
                $parts.Add('ROW'); $parts.Add([string]$r); $parts.Add($wwid)
                foreach ($c in $prevCols) { $parts.Add((Number-Text $sheet.Cells.Item($r,$c).Value2)) }
                $sw.WriteLine([string]::Join("`t",$parts))
            }
        } finally { $sw.Dispose() }
        Write-Host "[Excel] Snapshot: header=$headerRow wwidCol=$wwidCol lastRow=$lastRow"
        $book.Close($false)
    }
    else {
        if ([string]::IsNullOrWhiteSpace($PlanPath)) { throw 'PlanPath missing.' }
        if ([string]::IsNullOrWhiteSpace($CsvPath)) { throw 'CsvPath missing.' }
        $firstData = $headerRow + 1
        $planLast = $lastRow
        $lines = Get-Content $PlanPath
        if ($lines.Count -gt 0 -and $lines[0].StartsWith("META`t")) {
            $m = $lines[0].Split("`t")
            if ($m.Count -ge 3) { $firstData = [int]$m[1]; $planLast = [int]$m[2] }
        }
        try {
            $constants = $sheet.Range("AJ${firstData}:CU${planLast}").SpecialCells(2)
            $constants.ClearContents()
            Release-Com $constants
        } catch {}

        foreach ($line in $lines) {
            if (-not $line.StartsWith("SET`t")) { continue }
            $p = $line.Split("`t")
            if ($p.Count -lt 3) { continue }
            $cell = $null
            try {
                $cell = $sheet.Range($p[1])
                $hasFormula = $false
                try { $hasFormula = [Convert]::ToBoolean($cell.HasFormula,$Invariant) } catch {}
                if (-not $hasFormula) { $cell.Value2 = [double]::Parse($p[2],$Invariant) }
            } finally { Release-Com $cell }
        }

        $excel.CalculateFullRebuild()
        $book.Save()

        $after = $null; $found = $null
        try {
            $after = $sheet.Cells.Item(1,1)
            $found = $sheet.Cells.Find('*',$after,-4123,2,1,2,$false,[Type]::Missing,$false)
            if ($null -ne $found) { $csvLastRow = [int]$found.Row } else { $csvLastRow = $lastRow }
        } catch { $csvLastRow = $lastRow }
        finally { Release-Com $found; Release-Com $after }

        $enc = [System.Text.UTF8Encoding]::new($true)
        $sw = [System.IO.StreamWriter]::new($CsvPath,$false,$enc)
        $sw.NewLine = "`r`n"
        try {
            for ($r=1; $r -le $csvLastRow; $r++) {
                $a = Csv-Escape (Csv-Value $sheet.Cells.Item($r,1).Value2)
                $b = Csv-Escape (Csv-Value $sheet.Cells.Item($r,2).Value2)
                $sw.WriteLine($a + ';' + $b)
            }
        } finally { $sw.Dispose() }

        Write-Host "[Excel] Apply + Recalc + CSV abgeschlossen. Rows=$csvLastRow"
        $book.Close($false)
    }
}
finally {
    try { if ($null -ne $book) { $book.Close($false) } } catch {}
    try { if ($null -ne $excel) { $excel.Quit() } } catch {}
    Release-Com $sheet; Release-Com $book; Release-Com $excel
    [gc]::Collect(); [gc]::WaitForPendingFinalizers(); [gc]::Collect(); [gc]::WaitForPendingFinalizers()
}
