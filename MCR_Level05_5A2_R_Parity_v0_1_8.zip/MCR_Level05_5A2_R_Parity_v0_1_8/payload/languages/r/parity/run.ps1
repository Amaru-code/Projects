[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][Alias('Case')][ValidateNotNullOrEmpty()][string]$CaseId,
    [Parameter(Mandatory=$true)][Alias('Input')][ValidateNotNullOrEmpty()][string]$InputPath,
    [Parameter(Mandatory=$true)][Alias('Template')][ValidateNotNullOrEmpty()][string]$TemplatePath,
    [Parameter(Mandatory=$true)][Alias('Output')][ValidateNotNullOrEmpty()][string]$OutputPath,
    [int]$Workers = 4
)
$ErrorActionPreference='Stop'
$ModeRoot=$PSScriptRoot
$BuildRoot=Join-Path $ModeRoot 'build'
$Publish=Join-Path $BuildRoot 'publish'
$Main=Join-Path $Publish 'main.R'
$Pointer=Join-Path $BuildRoot 'rscript_path.txt'
if(-not(Test-Path $Main -PathType Leaf)){throw "R Candidate wurde noch nicht gebaut: $Main"}
if(-not(Test-Path $Pointer -PathType Leaf)){throw 'rscript_path.txt fehlt. build.ps1 zuerst ausfuehren.'}
$Rscript=(Get-Content $Pointer -Raw).Trim()
if(-not(Test-Path $Rscript -PathType Leaf)){throw "R Runtime fehlt: $Rscript"}
Write-Host 'R Candidate Wrapper'
Write-Host "Case:     [$CaseId]"
Write-Host "Input:    [$InputPath]"
Write-Host "Template: [$TemplatePath]"
Write-Host "Output:   [$OutputPath]"
Write-Host "Workers:  [$Workers]"
Write-Host "Runtime:  [$Rscript]"
if(Test-Path $OutputPath){Get-ChildItem $OutputPath -Force -ErrorAction SilentlyContinue|Remove-Item -Recurse -Force}else{New-Item -ItemType Directory -Force -Path $OutputPath|Out-Null}
& $Rscript --vanilla $Main --case $CaseId --input $InputPath --template $TemplatePath --output $OutputPath --workers $Workers
$Code=$LASTEXITCODE
if($null -eq $Code){throw 'R Candidate returned no exit code.'}
exit [int]$Code
