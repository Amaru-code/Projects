# RC72 – Gespeicherter MBC-Signaturbeleg vor Ausfuehrungsfreigabe

## Live-Befund aus RC71

Ticket 87647759: `P2_WORK_SERVER_PERSISTENCE`, `FORWARD_TO_REVIEW`, `Baindl Mark (mark.baindl)` und `REVIEW_VERIFIED` waren PASS. Vor dem Ausfuehrungsklick meldete RC71 `STOP P2_MBC_FINAL_SIGNATURE`. Das Signaturfeld war nach einer ICEfaces-Teilaktualisierung nicht mehr exakt lesbar, obwohl die Signatur bereits beim MBC-Entwurfsspeichern kontrolliert worden war. Der genaue Live-Feldwert ist aus dem Terminalprotokoll nicht bekannt.

## Aenderung

* Eine reine Beweisregel unterscheidet `LIVE_INTL01_EXACT` von `SAVED_INTL01_PROOF_AFTER_ICE_CLEARED_FIELD`, `...REMOVED_FIELD` und `...HIDDEN_FIELD`.
* Fuer volatile leere/entfernte Felder ist ein geordneter, positiv abgeschlossener Signatur-/Entwurfsspeicherbeleg im unveraenderten Ticketjournal zwingend. Die gespeicherten Ticketfelder und der MBC-Entwurf werden erneut kontrolliert. Vorangegangene Freigaben allein reichen nicht.
* Ein fremder Wert, doppelte Felder, widerspruechliche oder ausstehende Signaturversuche fuehren weiterhin vor jedem Ausfuehrungsklick zum Stopp.
* Die finale Signaturkontrolle erfolgt VOR der MANUELL-/AUTO-Freigabe und nochmals unmittelbar danach. Der einzig erlaubte Weiterleitungsklick bleibt unveraendert.
* Die Korrektur verwendet weder `Entwurf speichern`, `Ticket speichern` noch `Senden`. Standardantworten, PDF-Anhaenge und DB-Faelle wurden nicht veraendert.

## Grenzen

Der alte Entwurf-Speicherbeleg ist eine COMARCH-UI-/Journal-Beobachtung, kein kryptographischer Servernachweis einer eingebetteten Signatur. Der eigentliche Entwurfstext sowie GEVO und Beschreibung werden unabhaengig wieder eingelesen. Die Weiterleitung geht an Mark zur Ueberpruefung, nicht an einen E-Mail-Empfaenger. Ein produktiver COMARCH-Test steht aus; fehlende unabhaengige Belege werden nicht als Erfolg ausgegeben.
