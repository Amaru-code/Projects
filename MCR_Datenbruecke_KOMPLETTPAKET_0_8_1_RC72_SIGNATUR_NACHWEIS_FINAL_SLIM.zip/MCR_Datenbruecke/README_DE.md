# MCR DATENBRUECKE 0.8.1-rc.72

Kompaktes, vollstaendiges Softwarepaket. Fuer Bestandsinstallation `START.cmd` im separat entpackten Paket, Menue 1; danach nur die installierte `START.cmd` verwenden.

## RC72 – MBC-Signaturbeleg nach ICEfaces-Pruefschritt

Der MBC-Entwurf wird mit der COMARCH-Signatur `INTL01 - Intel Deutschland GmbH` gespeichert, nie als E-Mail versendet. Nach dem Wechsel auf `Weiterleiten zur Ueberpruefung` kann ICEfaces das fluechtige Signatur-Eingabefeld leeren oder aus dem DOM entfernen. RC71 stoppte deshalb NACH der manuellen Ausfuehrungsfreigabe.

RC72 prueft ZUVOR und unmittelbar danach: exakt dasselbe Ticket, unveraenderten MBC-Entwurf, gespeicherte GEVO- und Beschreibungswerte und das append-only-Journal. Ein fehlender/geleerter Formularwert ist nur erlaubt, wenn die exakte COMARCH-Signaturauswahl vor der zugeordneten Entwurfsspeicherung protokolliert, die Speicherung bestaetigt und kein neuer ungeklaerter Signaturversuch hinzugekommen ist. Ein fremder Signaturwert, doppelte Felder, fehlender Beleg oder geaenderter Entwurf stoppen weiterhin OHNE `Schritt ausfuehren`.

Die bestehende autorisierte Mark-Baindl-Auswahl und der einzelne `Schritt ausfuehren`-Klick bleiben erhalten. Keine doppelte Entwurfsspeicherung, keine zweite Ticket-Speicherung, kein E-Mail-Versand.

Wiederaufnahme: `START.cmd` -> Menue 1 der Downloadkopie, danach installierte `START.cmd` -> Menue 12 -> Ticket `87647759`. Die bereits serverseitig gespeicherten Ticketwerte werden nur gelesen. Nur MANUELL-Freigabe im Ticketfenster bzw. bewusstes Umschalten auf AUTO erlaubt den Abschluss.

Alle lokalen Daten (`private_data`, `.runtime`, Mapping, Browserprofil, Ticketjournale) bleiben am Bestandsort. Ein echter Windows-COMARCH-Durchlauf mit RC72 wurde noch nicht durchgefuehrt. Siehe `docs/RC72_RELEASE.md`.
