# MCR Datenbrücke 0.8.1-rc.128

Die Datenbrücke bearbeitet Intel-Vorgänge in COMARCH. Phase 1 kann nach Freigabe eine Standardantwort versenden. Phase 2 erzeugt und prüft angeforderte Dokumente, speichert Anlagen im selben Ticket und leitet den Vorgang intern zur fachlichen Prüfung weiter.

## Installation und Bedienung

Das Installationspaket in ein eigenes Verzeichnis entpacken. Dort `START.cmd` öffnen, Menüpunkt **1** wählen und die vorhandene Installation als Ziel bestätigen. Anschließend über die `START.cmd` der **installierten** Version starten. Die Voraussetzungen sind Windows, Edge, Node.js ab 22.15, Zugriff auf COMARCH und den Intel-Datenbestand. Die zentralen Dokumentgeneratoren benötigen ihre vorhandene Windows-/Python-/Excel-Umgebung.

| Auswahl | Funktion |
| --- | --- |
| 1 | Software aktualisieren und alte Bot-Ausgaben bereinigen. Der Installationsvorgang erzeugt einen Rückweg im benachbarten Ordner `_MCR_Archiv`. |
| 2 | Excel-Bestand erneut einlesen und vorgemerkte Kontaktänderungen bearbeiten. |
| 3 | Geeignete Phase-1-Tickets in `In_Bearbeitung` und `INTL01` bearbeiten. |
| 4 | Phase 2 allein starten. ENTER verarbeitet passende sichtbare eigene Vorgänge. `DC 90035267` wählt genau dieses Ticket mit DC-Auftrag. Enthält der Auftrag zusätzlich PP+, prüft der Bot beide Auszüge. `AO` wählt einen einzelnen reinen AO-Fall. `AO <Ticketnummer>` wählt einen bestimmten AO- oder kombinierten Auftrag. |
| 5 | Phase 1 und anschließend Phase 2 im selben Bot-Browser starten. |
| M | Die Live-Karte zur Anzeige öffnen. |

Die Nummer nach `DC` oder `AO` ist die COMARCH-Ticketnummer. Die WWID ermittelt der Bot aus dem geöffneten Ticket. `node tools/cli.mjs --selftest` prüft das Paket und die Auswahl fiktiver Dokumentaufträge vor Ort. Der Selbsttest öffnet keine echten Tickets.

## Was mit den Dokumenten passiert

**DC und PP+.** Einzelaufruf und Master prüfen zuerst den zentralen Ausgabeordner für den jeweiligen Plan. Für die automatische Übernahme eines vorhandenen Auszugs müssen der Inhalt des Dokuments, die gebundene Person, die WWID, die Dokumentart und der erwartete Abrechnungszeitraum zusammenpassen. Eine frühere Periode kann eine Neuerzeugung auslösen. Wenn der Text einer vorhandenen Datei die Zuordnung offenlässt, gibt es eine inhaltliche Sichtprüfung. Widersprüche oder eine laufende Erzeugung können den Fall zurückstellen. Eine angenommene Datei ist an ihren SHA-256, die Person und den Vorgang gebunden.

Bei einer Neuerzeugung startet der Bot den zentralen Python-Generator für den jeweiligen Plan. Bei DC und PP+ kann er die fertige PDF prüfen, sobald Excel den Export erfolgreich beendet hat. Die Personenordner-Kopie und das Speichern und Schließen der Arbeitsmappe können im Generator weiterlaufen. Der PP+-Exportbeleg bindet die Datei an den Generatorlauf, die WWID, den Stichtag und den SHA-256. Beendet sich der PP+-Generator erfolgreich, kann der Bot eine in diesem Lauf neu erzeugte oder geänderte PDF auch am erwarteten Ausgabepfad prüfen, wenn keine Pfadangabe ausgegeben wurde. Bei einer erneuten Ticketauswahl prüft der Bot die vorhandenen Dokumente beider benötigten Pläne. Ein laufender Nachlauf schützt die belegte Arbeitsmappe vor einer zweiten Erzeugung.

**PP+-Angaben im Terminal.** Bei der Neuanlage übernimmt der zentrale Generator verfügbare Stammdaten. Für jeden dann noch fehlenden Wert zeigt das Bot-Terminal die Originalfrage sowie Ticketnummer, WWID, Person und Stichtag. Mögliche Fragen betreffen Name, Anrede, Geburtsdatum, Eintritt, Austritt, LE, Adresse und PLZ/Ort. Datumswerte im Format `TT.MM.JJJJ` eingeben. Die WWID und der Stichtag kommen aus dem Auftrag, die Kontostände aus der Kontrollmappe.

Jede Antwort mit ENTER bestätigen. Bei einem ungültigen Datum oder einer ungültigen LE-Zahl fragt der Generator dasselbe Feld erneut ab. Beim optionalen Feld **LE** übernimmt ENTER ein leeres Feld und die Bearbeitung geht weiter. Bei einem Pflichtfeld stellt eine leere Antwort das Ticket zurück. Mit `UEBERSPRINGEN` kann man die Bearbeitung auch bei einer optionalen Frage zurückstellen. Während der Antwort wartet derselbe Generatorprozess. Die Phase-2-Berichte protokollieren die Feldwerte nicht. Das Update wird über den Bot installiert. Beim Aufruf über die manuelle BAT-Datei gilt die Bedienung des zentralen Skripts.

Bei einem kombinierten DC-/PP+-Ticket bleibt die bereits gefundene DC-Datei für die anschließende gemeinsame Anlagenprüfung vorgemerkt. Falls für die vorhandene DC-PDF eine Sichtprüfung nötig ist, erscheint sie nach erfolgreicher PP+-Erzeugung. Liefert eine Generatorversion ausschließlich `PP_INPUT_REQUIRED` ohne zuordenbare Eingabefrage, bleibt der Fall mit einem Hinweis auf den zentralen Generator offen.

**Auszahlungsoption (AO).** Bei einem neuen AO-Auftrag startet der Bot den zentralen Generator mit verifizierter WWID und Jahresendstichtag. Er prüft den neuen Auditbeleg und die neue PDF. Kontaktfragen des Generators erscheinen während des Laufs. Meldet die Berechnung beispielsweise eine fehlende Jahreszeile, kann der Bot für den zurückgestellten Fall den Prüfvermerk `Manuel review required` speichern und durch erneutes Öffnen prüfen. Bei einer Wiederaufnahme entscheidet der bereits protokollierte Aktionsstand über den nächsten Schritt.

**Anlage und Weiterleitung.** Die Dokumentvorbereitung übergibt die geprüften Dateien an die gemeinsame COMARCH-Anlagenverarbeitung. Bei kombinierten Aufträgen werden alle angeforderten Dokumente geprüft. Nach dem Speichern kontrolliert der Bot die Anlagen im erneut geöffneten Ticket. Er fragt bei mehrdeutiger COMARCH-Anzeige nach der vorgesehenen Sichtprüfung. Die interne Weiterleitung an Mark hat einen eigenen Nachweis. Ein bereits aufgezeichneter, ungeklärter Upload- oder Speicherversuch löst eine Wiederaufnahmeprüfung aus.

## Wo die Funktionen liegen

| Pfad | Aufgabe |
| --- | --- |
| `tools/cli.mjs` | Hauptmenü, Start von Pilot, Folgelauf und Phase 2 im Master. |
| `src/local-bot-full-run.mjs` | Ablauf im einzelnen Phase-1-Ticket und Auswahl des nächsten geeigneten Tickets. |
| `src/phase2-run.mjs` | Offene Phase-2-Fälle lesen, Fachregel bestimmen und passenden Bearbeiter im Code aufrufen. |
| `src/phase2-pdf-prepare.mjs`, `src/phase2-comarch-pilot.mjs` | Dokumente vorbereiten und geprüfte Anlagen im gebundenen Ticket verarbeiten. |
| `lib/comarch/` | Gemeinsame Interaktion mit COMARCH. `comarch-member.mjs` bündelt Vorschlagssuche, Klick und Profilprüfung. `comarch-fixed-fields.mjs` bündelt Kategorie, Unterkategorie und Signatur. |
| `lib/phase1/`, `lib/phase2/` | Regeln, Freigaben und Journalprüfungen für die jeweilige Bearbeitungsphase. |
| `lib/documents/` | Dokumentauftrag, Generatoraufrufe und PDF-Nachweise. |
| `lib/workbook/`, `lib/runtime/` | Excel-Bestandszugriff und Mapping sowie Laufsteuerung, Bedienfenster und Wiederaufnahme. |
| `tools/` | Installer, Paketprüfung, Python-/Windows-Adapter und Live-Karte. |

## Bestand, Journale und Speicherplatz

Die konfigurierte XLSX ist die führende Datenquelle. `private_data/active-mapping.json` verweist auf den aktuell aktivierten, per Hash gebundenen Datenstand. Mehrere Excel-Zeilen zu einer WWID können zu diesem Datenstand gehören. Bei der Aktualisierung bereinigt der Bot von ihm erzeugte, nachweislich abgelöste Mapping-Versionen. Unbekannte oder anderweitig referenzierte private Dateien behandelt er gesondert.

Das reguläre Phase-1-Ergebnis liegt in `Ergebnis/LETZTER_ECHTLAUF.json`. Ein neuer Echtlauf ersetzt dieses Ergebnis. Ticketbezogene Versand-, Speicher- und Weiterleitungsnachweise sowie offene Excel-Kontaktänderungen liegen unter `.runtime`. Sie werden für die Wiederaufnahme und zum Schutz vor Doppelversand benötigt. Der Installer übernimmt einen gültigen letzten Laufbeleg und entfernt danach den lokalen Standardordner `diagnostics` einschließlich seiner Unterordner. Bei einem Konflikt mit einer konfigurierten Datenquelle oder einem ungeklärten letzten Laufbeleg meldet er die offene Bereinigung. Im Normalbetrieb entstehen keine Diagnose-ZIPs pro Ticketlauf mehr. Beim Update erkennt der Installer auch frühere, unveränderte Installations-ZIPs direkt im Installationsordner an ihren archivierten Paketprüfsummen.

Die Testfälle und die Versionshistorie gehören zur Entwicklung. Das Installationspaket enthält die im Betrieb benötigten Abläufe, Adapter, Konfiguration, diese Anleitung und die Paketprüfsummen.
