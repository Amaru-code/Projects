import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';
import {PACKAGE_ROOT,RELEASE,ENGINE,safeRelative,assertPlainPath,treeRecord,verifyRelease,acquireLock,atomicJSON,journalJSON,journalRead,jsonRead,sha} from '../beta-common.mjs';
import {status,prepareDemo,hasReviewState} from '../beta-cli.mjs';
import {activeSnapshot} from '../migration.mjs';
import {lookupMultirow} from '../../lib/multirow-tpp-mapping.mjs';
import Person from '../../lib/person-quoted.cjs';
import {publishActiveMapping} from '../../lib/active-mapping.mjs';
import {key,row,makeMap,fakeData,temp,dispose} from './fixtures.mjs';
const err=code=>e=>e.code===code;
function sandbox(fn){const p=temp();try{return fn(p);}finally{dispose(p);}}
function releaseCopy(parent){const dest=path.join(parent,'release');fs.cpSync(PACKAGE_ROOT,dest,{recursive:true,filter:source=>!['.runtime','private_data','diagnostics','.git'].includes(path.relative(PACKAGE_ROOT,source).split(path.sep)[0])});return dest;}
test('sealed release and 17 unchanged engine files',()=>{const r=verifyRelease();assert.equal(r.version,RELEASE);assert.equal(r.engineVersion,ENGINE);assert.equal(r.frozenFiles,17);});
test('only START.cmd is an executable at root',()=>assert.deepEqual(fs.readdirSync(PACKAGE_ROOT).filter(n=>/\.(cmd|bat|js|cjs|mjs|html|ps1)$/i.test(n)),['START.cmd']));
for(const bad of ['../x','a/../x','/x','a//b','a\\b','C:/x','a\u0000x','./x'])test('unsafe relative path rejected '+JSON.stringify(bad),()=>assert.equal(safeRelative(bad),false));
test('normal relative paths accepted',()=>assert.equal(safeRelative('tools/tests/beta.test.mjs'),true));
test('fingerprint is deterministic and changes with content',()=>sandbox(p=>{fs.mkdirSync(path.join(p,'x'));fs.writeFileSync(path.join(p,'x/a'),'a');const a=treeRecord(p);assert.deepEqual(treeRecord(p),a);fs.writeFileSync(path.join(p,'x/a'),'b');assert.notEqual(treeRecord(p).digest,a.digest);}));
test('symlink not traversed',()=>sandbox(p=>{const outside=path.join(p,'real');fs.mkdirSync(outside);fs.symlinkSync(outside,path.join(p,'link'),process.platform==='win32'?'junction':'dir');assert.throws(()=>assertPlainPath(path.join(p,'link')),err('LINK_BLOCKED'));}));
test('atomic JSON accepts BOM read but writes UTF8 without BOM',()=>sandbox(p=>{const f=path.join(p,'a.json');fs.writeFileSync(f,'\uFEFF{"a":1}');assert.equal(jsonRead(f).a,1);atomicJSON(f,{a:2});assert.equal(jsonRead(f).a,2);assert.notEqual(fs.readFileSync(f)[0],0xef);}));

test('migration journal survives Windows-style EPERM on temp rename',()=>sandbox(p=>{const f=path.join(p,'migration.json');const deny=()=>{const e=Object.assign(new Error('simulated managed-Windows rename denial'),{code:'EPERM'});throw e;};assert.equal(journalJSON(f,{step:1},{renameImpl:deny}),'WINDOWS_DIRECT_VERIFIED');assert.equal(journalRead(f).step,1);assert.equal(journalJSON(f,{step:2},{renameImpl:deny}),'WINDOWS_DIRECT_VERIFIED');assert.equal(journalRead(f).step,2);assert.equal(jsonRead(f+'.bak').step,1);}));
test('control writes tolerate managed-Windows EPERM on fsync',()=>sandbox(p=>{const original=fs.fsyncSync;fs.fsyncSync=()=>{throw Object.assign(new Error('simulated fsync denial'),{code:'EPERM'});};try{const f=path.join(p,'state.json');atomicJSON(f,{ok:true});assert.equal(jsonRead(f).ok,true);const l=acquireLock(p,'TEST');l.release();}finally{fs.fsyncSync=original;}}));

test('lock blocks second operation and releases its own token',()=>sandbox(p=>{const l=acquireLock(p,'TEST');assert.throws(()=>acquireLock(p,'OTHER'),err('OPERATION_LOCKED'));l.release();const b=acquireLock(p,'OTHER');b.release();}));
test('changed lock cannot be silently released',()=>sandbox(p=>{const l=acquireLock(p,'TEST');atomicJSON(l.file,{token:'other'});assert.throws(()=>l.release(),err('LOCK_CHANGED'));assert.ok(fs.existsSync(l.file));}));
test('interrupted run is review-required, not marked delivered',()=>{for(const state of ['RUNNING','STOP_REVIEW_REQUIRED','INTERRUPTED_REVIEW_REQUIRED'])assert.equal(hasReviewState({state}),true);assert.equal(hasReviewState({state:'RUNNER_EXIT_0'}),false);assert.equal(hasReviewState({state:'OPERATOR_REVIEWED_NOT_RETRIED'}),false);});
test('TPP stays on its source row',()=>{const e=lookupMultirow(makeMap(),key);assert.equal(e.description,'USC 20/ DB+;TPP\nUSC 20/ DB+');assert.equal(e.rowCount,2);});
for(let bits=0;bits<16;bits++)test('C D E F truth table unchanged '+bits,()=>{const C=bits&1?1:0,D=bits&2?1:0,E=bits&4?1:0,F=bits&8?1:0,m=makeMap([row({C,D,E,F})]);if(bits===0)assert.ok(m.payload.blocked[key]);else assert.equal(lookupMultirow(m,key).description,'USC 20/ '+[C?'DC':null,D?'PP+':null,E?'DB+':null,F?'TPP':null].filter(Boolean).join(';'));});
test('identical descriptions remain two lines',()=>assert.equal(lookupMultirow(makeMap([row(),row({row:11})]),key).descriptionLines.length,2));
test('conflicting gender is not inferred',()=>assert.equal(lookupMultirow(makeMap([row(),row({row:11,O:'M'})]),key).gender,null));
test('one invalid row blocks whole person',()=>assert.ok(makeMap([row(),row({row:11,F:9})]).payload.blocked[key]));
test('quote-only name stays operator-reviewed and no software sender',()=>{const c=Person.candidates({senderName:'VExample',body:'>> Mit freundlichen Grüßen\n>> Anna Beispiel'});assert.equal(c[0].quotedOnly,true);assert.deepEqual(Person.candidates({senderName:'Microsoft Outlook',body:'Kind regards\nMicrosoft Outlook'}),[]);});
test('active pointer snapshot read is unchanged',()=>sandbox(p=>{fakeData(p);const before=treeRecord(path.join(p,'private_data'));activeSnapshot(p);assert.deepEqual(treeRecord(path.join(p,'private_data')),before);}));
test('status missing mapping never opens browser',()=>sandbox(p=>{const root=releaseCopy(p);const s=status(root);assert.equal(s.mappingReady,false);assert.ok(!fs.existsSync(path.join(root,'.runtime')));}));
test('status accepts real-mode synthetic TPP snapshot',()=>sandbox(p=>{const root=releaseCopy(p);fakeData(root);const s=status(root);assert.equal(s.mappingReady,true);assert.equal(s.mapping.summary.multirowKeys,1);}));
test('source corruption rejected',()=>sandbox(p=>{const root=releaseCopy(p);fs.appendFileSync(path.join(root,'src/local-bot-full-run.mjs'),'\n//bad');assert.throws(()=>verifyRelease(root),err('PACKAGE_HASH'));}));
test('four-file manifest rejected',()=>sandbox(p=>{const root=releaseCopy(p);atomicJSON(path.join(root,'MANIFEST.json'),{schema:'OLD',payload:[1,2,3,4]});assert.throws(()=>verifyRelease(root),err('PACKAGE_IDENTITY'));}));
test('old starter at root rejected',()=>sandbox(p=>{const root=releaseCopy(p);fs.writeFileSync(path.join(root,'START_FULL_QUEUE_RUN.cmd'),'echo old');assert.throws(()=>verifyRelease(root),err('OLD_STARTER_PRESENT'));}));
test('config has no stale personal mapping path',()=>{const c=jsonRead(path.join(PACKAGE_ROOT,'config/local-runner-queue-send.json'));assert.equal(c.profileDirectory,'.runtime/edge-profile');assert.equal(c.mappingPath,undefined);assert.equal(c.mappingDirectory,undefined);});
test('demo workspace isolated from private state and live browser profile',()=>{const d=prepareDemo();try{assert.ok(fs.existsSync(path.join(d,'examples/DEMO_Mail.msg')));assert.ok(!fs.existsSync(path.join(d,'private_data')));assert.ok(!fs.existsSync(path.join(d,'.runtime')));assert.equal(sha(fs.readFileSync(path.join(d,'src/local-bot-full-run.mjs'))),sha(fs.readFileSync(path.join(PACKAGE_ROOT,'src/local-bot-full-run.mjs'))));}finally{dispose(d);}});
