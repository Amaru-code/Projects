import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {assessBoundDescription,canonicalVisibleDescription,readVerifiedBoundWorkDescription} from '../lib/phase2-bound-description.mjs';
import * as UI from '../lib/browser-workflow.mjs';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
const id='88078437';
const original='USC 30/ DB+\nStandardantwort versendet\nMöchte eine Auskunft zur Rente';
const state=x=>({ok:true,editable:true,value:x,state:'EXACT_ADDITIONAL_DESCRIPTION'});

test('RC93: strict match and harmless ICEfaces line-ending/terminal whitespace are separated',()=>{
 assert.equal(assessBoundDescription(state(original),original).method,'EXACT_TEXT');
 assert.equal(assessBoundDescription(state(original.replace(/\n/g,'\r\n')),original).method,'EXACT_TEXT');
 const form=original.replace('DB+','DB+\u00a0').replace('versendet','versendet  ')+ '\n';
 assert.equal(assessBoundDescription(state(form),original).method,'UI_WHITESPACE_ONLY');
 assert.equal(canonicalVisibleDescription(form),canonicalVisibleDescription(original));
});
test('RC93: customer content, status, plan and unexpected marker are never normalized away',()=>{
 for(const changed of [original.replace('DB+','PP+'),original.replace('Möchte','Möchten'),
  original+'\nBearbeitet not reviewed',original.replace('Standardantwort versendet','Standardantwort nicht versendet')]){
  const d=assessBoundDescription(state(changed),original);
  assert.equal(d.ok,false);assert.equal(d.reason,'CONTENT_CONFLICT');
  assert.ok(Number.isInteger(d.firstDifferentLine));
 }
 assert.equal(assessBoundDescription({ok:false,state:'AMBIGUOUS'},original).reason,'NOT_BOUND');
 assert.equal(assessBoundDescription({...state(original),editable:false},original).reason,'NOT_EDITABLE');
});
test('RC93: bounded pure reads diagnose content conflicts without leaking message text',async()=>{
 const logs=[];let count=0;
 const result=await readVerifiedBoundWorkDescription({},id,original,{
  read:async()=>{count++;return state(original.replace('DB+','PP+'));},
  assertTicket:async(_p,t)=>assert.equal(t,id),delay:async()=>{},log:s=>logs.push(s),
 });
 assert.equal(result.ok,false);assert.equal(result.reason,'CONTENT_CONFLICT');assert.equal(count,4);
 assert.match(logs.at(-1),/erste_abweichende_zeile=1/);
 assert(!logs.join('\n').includes('Möchte'));assert(!logs.join('\n').includes('USC 30'));
});
test('RC93: wrong or unbound ticket rejects before any additional-description access',async()=>{
 let reads=0;
 await assert.rejects(readVerifiedBoundWorkDescription({},id,original,{
  assertTicket:async()=>{throw Object.assign(new Error('different ticket'),{code:'TICKET_BINDING'});},
  read:async()=>{reads++;return state(original);},delay:async()=>{},
 }),{code:'TICKET_BINDING'});
 assert.equal(reads,0);
});
test('RC93: intermittent ICEfaces re-render re-reads same field; never clicks or writes',async()=>{
 const states=[{ok:false,state:'NOT_FOUND'},state(original.replace('DB+','DB+\u00a0')),state(original)];
 let reads=0,checks=0;const logs=[];
 const result=await readVerifiedBoundWorkDescription({},id,original,{
  read:async()=>{reads++;return states.shift();},assertTicket:async()=>{checks++;},delay:async()=>{},log:s=>logs.push(s),
 });
 assert.equal(result.ok,true);assert.equal(result.method,'UI_WHITESPACE_ONLY');
 assert.equal(reads,2);assert.equal(checks,2);
 assert(logs.some(x=>/PASS P2_RC93_BOUND_DESCRIPTION/.test(x)));
});
async function withPage(run){const exe=findEdgeExecutable('auto');if(!exe)return;
 const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC20-NOTE-RC93-BOUND-'));let browser,cdp;
 try{
  browser=await launchBrowser({executable:exe,userDataDir:profile,startUrl:'about:blank',headless:true,
   extraArgs:process.platform==='linux'?['--no-sandbox','--disable-dev-shm-usage','--disable-background-networking','--disable-component-update']:[]});
  ({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.type==='page'&&t.url==='about:blank');
  return await run(page);
 }finally{await cleanupTemporaryTestBrowser({profile,browser,cdp});}
}
test('RC93 Chromium: bound textarea verifies even if generic textarea match is ambiguous',{timeout:45000},()=>withPage(async page=>{
 await page.call((ticket,raw)=>{
  document.body.innerHTML='<span>Ticket-ID: '+ticket+'</span><div id="mainForm:document-data-section"><label>Zusätzliche Beschreibung</label><textarea id="bound" style="width:450px;height:120px"></textarea></div><section><textarea id="email" style="width:400px;height:120px"></textarea></section><input id="mainForm:gevo-value-id" value="Anfrage Member" />';
  document.querySelector('#bound').value=raw;
  document.querySelector('#email').value=raw;
  window.__clicks=0;document.addEventListener('click',()=>window.__clicks++);
 },id,original);
 assert.equal(await UI.verifyDescription(page,original),false,'RC92 generic textarea counter rejects duplicates');
 const proof=await readVerifiedBoundWorkDescription(page,id,original,{attempts:1});
 assert.equal(proof.ok,true);assert.equal(proof.method,'EXACT_TEXT');
 assert.equal(await page.eval('window.__clicks'),0);
 await page.call(()=>{document.querySelector('#bound').value+='\nBearbeitet not reviewed';});
 const denied=await readVerifiedBoundWorkDescription(page,id,original,{attempts:1});
 assert.equal(denied.ok,false);assert.equal(denied.reason,'CONTENT_CONFLICT');
 assert.equal(await page.eval('window.__clicks'),0);
}));
test('RC93 wiring: all direct-route pre-execute verification uses the bound field',()=>{
 const file=new URL('../src/phase2-work-handler.mjs',import.meta.url);
 const source=fs.readFileSync(file,'utf8');
 assert.match(source,/readVerifiedBoundWorkDescription\(page,id,descriptionAfter,\{log\}\)/);
 assert.match(source,/beforeAuthorize:\(\)=>checkFinalMbc\('VOR_FREIGABE'\)/);
 assert.match(source,/beforeExecute:\(\)=>checkFinalMbc\('VOR_AUSFUEHRUNG'\)/);
 assert.match(source,/need\(verified,'P2_WORK_SERVER_VALUES'/);
});
