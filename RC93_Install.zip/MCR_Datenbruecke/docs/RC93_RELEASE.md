# MCR DATENBRUECKE 0.8.1-rc.93

## Ticket 88078437: die urspruengliche Beschreibung eindeutig pruefen

### Bisherige Ursache

RC92 hat nach dem Oeffnen des Bearbeitungsmodus `verifyDescription()` benutzt.
Die alte Pruefung zaehlte **alle sichtbaren Textareas mit dem erwarteten Inhalt**,
statt die nachweislich an `Zusaetzliche Beschreibung` gebundene Textarea
zu lesen. Mehrere sichtbare Textfelder konnten dadurch einen falschen
`Beschreibung=NOT_EXACT`-Befund ausloesen. Die Vorkontrolle nutzte dagegen
das eindeutig gebundene Feld (`additionalDescriptionState`).

### RC93

- Fuer DB/DB+ und reine Weiterleitungen wird der Beschreibungstext **vor und nach dem Editormodus** ueber dasselbe eindeutig gebundene Feld gelesen.
- Vor jeder wiederholten Lesepruefung wird die Ticket-ID neu verifiziert.
- COMARCH-Teilaktualisierungen werden bis zu viermal **rein lesend** geprueft.
- Reine UI-Formatunterschiede (CRLF, NBSP, ueberfluessige Leerzeichen am Zeilenende) sind akzeptiert. Eigentliche Textaenderungen, fehlende Statuszeilen, geaenderte Plaene und unbekannte Beschreibungen werden NICHT toleriert.
- Vor Freigabe und direkt vor `Schritt ausfuehren`/Direktweiterleitung wird der eindeutige Feldnachweis erneut eingeholt.
- Im Fehlerfall werden strukturierte, datensparsame Diagnosen mit Anzahl der Zeilen und der Position der ersten Abweichung ausgegeben, **kein Kundentext**. Der bestehende MCR-P2-201-Fehlercode und die sichere Rueckstellung bleiben erhalten.

**Sicherheit:** Keine Aenderung an der gespeicherten Beschreibung, kein erneuter Speicherklick und kein neuer E-Mail-Versand allein aufgrund des Wiederaufnahmepfads. Ungeklaerte fruehere Aktionen bleiben gesperrt.

Ein COMARCH-Echtlauf von RC93 steht noch aus. Wenn das eindeutig gebundene Feld tatsaechlich einen anderen Inhalt besitzt, darf der Bot das Ticket nicht blind weiterleiten; dann zeigt die Diagnose an, ob die Abweichung an einer Zeile oder der Formbindung liegt.
