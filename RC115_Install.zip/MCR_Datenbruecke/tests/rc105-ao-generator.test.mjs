import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {EventEmitter} from 'node:events';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {aoPythonCandidates,runCentralAoGenerator} from '../lib/phase2-ao-generator.mjs';
import {runLocalStatementGenerator} from '../lib/phase2-local-generator.mjs';

const root=fileURLToPath(new URL('..',import.meta.url));
const marker='MCR_AO_BRIDGE_RESULT ';
const sourceSha='a'.repeat(64);
const tick=()=>new Promise(resolve=>setTimeout(resolve,1));
function fixture(){
 const folder=fs.mkdtempSync(path.join(os.tmpdir(),'mcr-ao-bridge-'));
 const paths={folder,start:path.join(folder,'START_Auszahlungsoption.bat'),script:path.join(folder,'auszahlungsoption_generator.py')};
 fs.writeFileSync(paths.script,'# fixture only\n');
 fs.writeFileSync(paths.start,'@echo off\npython auszahlungsoption_generator.py\npause\n');
 return {paths,dispose:()=>fs.rmSync(folder,{recursive:true,force:true})};
}
function spawnMock(handler){
 return (executable,args,options)=>{
  const child=new EventEmitter();child.stdout=new EventEmitter();child.stderr=new EventEmitter();child.kill=()=>child.emit('close',1);
  setImmediate(()=>{
   const r=handler({executable,args,options});
   if(r.throw){child.emit('error',Object.assign(new Error(r.throw),{code:r.throw}));return;}
   child.stdout.emit('data',Buffer.from(r.raw??marker+JSON.stringify(r.body)+'\n'));
   child.emit('close',r.exitCode??0);
  });
  return child;
 };
}
function success(args){
 const value=flag=>args[args.indexOf(flag)+1];
 const year=new Date().getFullYear();
 return {status:'SUCCESS',proof:{schema:'MCR_AO_GENERATOR_PROOF_V1',requestId:value('--request-id'),wwid:value('--wwid'),
  name:'Nachname Vorname',stichtag:`31.12.${year}`,stichtagIso:`${year}-12-31`,file:'K:\\AO\\Ausgabe PDF\\result.pdf',
  auditFile:'K:\\AO\\Audit_Logs\\result.json',sha256:'b'.repeat(64),auditSha256:'c'.repeat(64),sourceSha256:sourceSha,
  bytes:1000,generatedAt:new Date().toISOString(),auditTimestamp:new Date().toISOString(),freshness:{schema:'MCR_AO_FRESH_GENERATION_V1',newPdf:true,newAudit:true,startedAtMs:Date.now(),pdfMtimeMs:Date.now(),auditMtimeMs:Date.now()}}};
}

test('RC105 AO invokes central Python exactly once after a read-only probe, hidden and shell-free',async()=>{
 const f=fixture(),calls=[];
 try{
  const spawnImpl=spawnMock(call=>{calls.push(call);return {body:call.args.includes('--probe')?{status:'PROBE_OK',sourceSha256:sourceSha}:success(call.args)};});
  const result=await runLocalStatementGenerator(root,'AO','11412817',{isWindows:true,paths:()=>f.paths,spawnImpl,wait:tick,
   aoOptions:{candidates:()=>[{executable:'python.exe',args:[]}]}});
  assert.equal(result.status,'GENERATOR_EXECUTED');assert.equal(result.proof.wwid,'11412817');
  assert.equal(calls.length,2);assert(calls[0].args.includes('--probe'));assert(calls[1].args.includes('--wwid'));assert(calls[1].args.includes('--non-interactive'));assert.equal(calls[1].args[calls[1].args.indexOf('--stichtag')+1],`31.12.${new Date().getFullYear()}`);
  assert(calls.every(c=>c.options.shell===false&&c.options.windowsHide===true&&c.options.stdio[0]==='ignore'));
  assert(calls.every(c=>c.executable!=='cmd.exe'&&!c.args.some(x=>x.endsWith('.bat'))));
 }finally{f.dispose();}
});

test('RC105 AO interpreter fallback happens only before generation; failed generation is never repeated',async()=>{
 const f=fixture(),calls=[];
 try{
  const result=await runCentralAoGenerator(root,'11412817',f.paths,{wait:tick,candidates:()=>[
   {executable:'missing.exe',args:[]},{executable:'python.exe',args:[]}],
   spawnImpl:spawnMock(call=>{
    calls.push(call);
    if(call.executable==='missing.exe')return {throw:'ENOENT'};
    if(call.args.includes('--probe'))return {body:{status:'PROBE_OK',sourceSha256:sourceSha}};
    return {exitCode:1,body:{status:'FAILED',requestId:call.args[call.args.indexOf('--request-id')+1],error:'AO_CONTACT_DATA_REQUIRED',reason:'Adresse fehlt.'}};
   })});
  assert.equal(result.status,'AO_GENERATOR_REVIEW_REQUIRED');assert.equal(result.error,'AO_CONTACT_DATA_REQUIRED');
  assert.equal(calls.filter(c=>!c.args.includes('--probe')).length,1);
 }finally{f.dispose();}
});

test('RC105 AO rejects a foreign WWID result even with a successful exit',async()=>{
 const f=fixture();
 try{
  await assert.rejects(runCentralAoGenerator(root,'11412817',f.paths,{wait:tick,candidates:()=>[{executable:'python.exe',args:[]}],
   spawnImpl:spawnMock(call=>{
    if(call.args.includes('--probe'))return {body:{status:'PROBE_OK',sourceSha256:sourceSha}};
    const body=success(call.args);body.proof.wwid='99999999';return {body};
   })}),e=>e.code==='P2_AO_RECEIPT_BINDING');
 }finally{f.dispose();}
});

test('RC105 absent AO central script cannot silently execute its BAT',async()=>{
 const f=fixture();fs.unlinkSync(f.paths.script);
 try{
  await assert.rejects(runLocalStatementGenerator(root,'AO','11412817',{isWindows:true,paths:()=>f.paths,
   spawnImpl:()=>{throw new Error('must not spawn');}}),e=>e.code==='P2_AO_SCRIPT_NOT_FOUND');
 }finally{f.dispose();}
});

test('RC105 Python candidates read only literal central launcher and local venv',()=>{
 const f=fixture();
 try{
  const exe=path.join(f.paths.folder,'.venv','Scripts','python.exe');fs.mkdirSync(path.dirname(exe),{recursive:true});fs.writeFileSync(exe,'fixture');
  fs.writeFileSync(f.paths.start,'@echo off\n"%~dp0.venv/Scripts/python.exe" "%~dp0auszahlungsoption_generator.py"\nstart "" evil.exe\npause\n');
  const candidates=aoPythonCandidates(f.paths);
  assert.equal(candidates[0].executable,exe);assert(candidates.some(x=>x.executable==='py.exe'&&x.args[0]==='-3'));
  assert(!candidates.some(x=>x.executable.includes('evil')||x.executable==='cmd.exe'));
 }finally{f.dispose();}
});

test('RC105 Python adapter verifies input/audit/locking/owned Excel with offline fixtures',()=>{
 const isWindows=process.platform==='win32';
 const result=spawnSync(isWindows?'py':'python3',[...(isWindows?['-3']:[]),path.join(root,'tests','rc105-ao-bridge-tests.py')],{
  encoding:'utf8',timeout:30000,env:{...process.env,PYTHONDONTWRITEBYTECODE:'1'}
 });
 assert.equal(result.status,0,result.stderr||result.stdout||result.error?.message);
 assert.match(result.stderr,/Ran 47 tests/);
});


test('RC110 AO machine receipt preserves actual read error and stage, no second generation',async()=>{
 const f=fixture(),calls=[],logs=[];
 try{
  const r=await runCentralAoGenerator(root,'11412817',f.paths,{wait:tick,log:x=>logs.push(x),candidates:()=>[{executable:'python.exe',args:[]}],spawnImpl:spawnMock(call=>{
   calls.push(call);
   if(call.args.includes('--probe'))return {body:{status:'PROBE_OK',sourceSha256:sourceSha}};
   const body={status:'BLOCKED',requestId:call.args[call.args.indexOf('--request-id')+1],wwid:'11412817',error:'MASTER_OPEN_FAILED',reason:'Lesender Zugriff fehlgeschlagen.',details:{operation:'read_contact_data',source:'master',exception_type:'com_error',hresult:-2146827284,raw:'private'}};
   return {exitCode:2,raw:'MCR_AO_BRIDGE_STAGE PREFLIGHT\n'+marker+JSON.stringify(body)+'\n'};
  })});
  assert.equal(r.status,'GENERATOR_BLOCKED');assert.equal(r.error,'MASTER_OPEN_FAILED');assert.equal(r.details.hresult,-2146827284);assert.equal(r.details.raw,undefined);
  assert.equal(calls.length,2);assert(logs.some(x=>x.startsWith('P2_AO_TECHNISCHE_DIAGNOSE: ')));assert(!logs.join(' ').includes('private'));
 }finally{f.dispose();}
});


test('RC112 contact questions use the same child stdin; no raw values in log',async()=>{
 const f=fixture(),calls=[],logs=[],answers=[],fields=[];
 try{
  const spawnImpl=(executable,args,options)=>{
   calls.push({executable,args,options});
   if(args.includes('--probe'))return spawnMock(()=>({body:{status:'PROBE_OK',sourceSha256:sourceSha}}))(executable,args,options);
   const child=new EventEmitter();child.stdout=new EventEmitter();child.stderr=new EventEmitter();child.stdin=new EventEmitter();child.kill=()=>child.emit('close',1);child.stdin.end=()=>{};
   const requestId=args[args.indexOf('--request-id')+1];
   const prompt=field=>child.stdout.emit('data',Buffer.from('MCR_AO_BRIDGE_CONTACT '+JSON.stringify({requestId,wwid:'11412817',field})+'\n'));
   child.stdin.write=raw=>{const answer=JSON.parse(raw);answers.push(answer);setImmediate(()=>{if(answer.field==='Adresse')prompt('PLZ');else{const body=success(args);body.proof.contactInput={schema:'MCR_AO_OPERATOR_CONTACT_V1',fields:['Adresse','PLZ'],masterReadbackVerified:true};child.stdout.emit('data',Buffer.from(marker+JSON.stringify(body)+'\n'));child.emit('close',0);}});};
   setImmediate(()=>prompt('Adresse'));return child;
  };
  const result=await runCentralAoGenerator(root,'11412817',f.paths,{spawnImpl,wait:tick,log:x=>logs.push(x),candidates:()=>[{executable:'python.exe',args:[]}],contactInput:async field=>{fields.push(field);return field==='Adresse'?'Fiktive Teststrasse 7':'01234';}});
  assert.equal(result.status,'GENERATOR_EXECUTED');assert.deepEqual(fields,['Adresse','PLZ']);assert.equal(calls.length,2);assert(calls[1].args.includes('--interactive-contacts'));assert.equal(calls[1].options.stdio[0],'pipe');
  assert.deepEqual(answers.map(x=>[x.field,x.approved,x.value]),[['Adresse',true,'Fiktive Teststrasse 7'],['PLZ',true,'01234']]);assert(!logs.join(' ').includes('Fiktive Teststrasse'));assert(!logs.join(' ').includes('01234'));
 }finally{f.dispose();}
});

test('RC113 no heartbeat or technical timeout during either contact question; technical clock resumes', {timeout:5000},async()=>{
 const f=fixture(),logs=[],answers=[],fields=[];let now=0,answerPending=null,waitingTicks=0,childKilled=false;
 try{
  const spawnImpl=(executable,args,options)=>{
   if(args.includes('--probe'))return spawnMock(()=>({body:{status:'PROBE_OK',sourceSha256:sourceSha}}))(executable,args,options);
   const child=new EventEmitter();child.stdout=new EventEmitter();child.stderr=new EventEmitter();child.stdin=new EventEmitter();child.stdin.end=()=>{};child.kill=()=>{childKilled=true;child.emit('close',1);};
   const requestId=args[args.indexOf('--request-id')+1];
   const prompt=field=>child.stdout.emit('data',Buffer.from('MCR_AO_BRIDGE_CONTACT '+JSON.stringify({requestId,wwid:'11412817',field})+'\n'));
   child.stdin.write=raw=>{const a=JSON.parse(raw);answers.push(a);setImmediate(()=>{
    if(a.field==='Adresse')prompt('PLZ');else{const body=success(args);body.proof.contactInput={schema:'MCR_AO_OPERATOR_CONTACT_V1',fields:['Adresse','PLZ'],masterReadbackVerified:true};child.stdout.emit('data',Buffer.from(marker+JSON.stringify(body)+'\n'));child.emit('close',0);}
   });};setImmediate(()=>prompt('Adresse'));return child;
  };
  const result=await runCentralAoGenerator(root,'11412817',f.paths,{spawnImpl,timeoutMs:5000,monotonicNow:()=>now,
   wait:async()=>{await tick();if(answerPending){now+=60000;waitingTicks++;if(waitingTicks%4===0){const pending=answerPending;answerPending=null;pending();}}else now+=1;},
   log:x=>logs.push(x),candidates:()=>[{executable:'python.exe',args:[]}],contactInput:field=>new Promise(resolve=>{
    fields.push(field);answerPending=()=>resolve(field==='Adresse'?'Fiktive Teststrasse 7':'01234');
   })});
  assert.equal(result.status,'GENERATOR_EXECUTED');assert.equal(childKilled,false);assert.deepEqual(fields,['Adresse','PLZ']);assert.equal(waitingTicks,8);assert(now>=480000);
  assert.equal(answers.length,2);assert(logs.some(x=>x.includes('P2_AO_CONTACT_ADDRESS_RECEIVED')));assert(logs.some(x=>x.includes('P2_AO_CONTACT_POSTCODE_RECEIVED')));
  assert(!logs.some(x=>x.includes('WARTET_AUF_KONTAKTEINGABE')||x.includes('GENERATOR_ARBEITET')));
  assert(!logs.join(' ').includes('Fiktive Teststrasse')&&!logs.join(' ').includes('01234'));
 }finally{f.dispose();}
});

test('RC113 contact declined after address yields structured blocked result, not a second invocation', {timeout:5000},async()=>{
 const f=fixture(),answers=[],calls=[];let killed=false;
 try{
  const spawnImpl=(executable,args,options)=>{
   calls.push(args);if(args.includes('--probe'))return spawnMock(()=>({body:{status:'PROBE_OK',sourceSha256:sourceSha}}))(executable,args,options);
   const child=new EventEmitter();child.stdout=new EventEmitter();child.stderr=new EventEmitter();child.stdin=new EventEmitter();child.stdin.end=()=>{};child.kill=()=>{killed=true;child.emit('close',1);};
   const requestId=args[args.indexOf('--request-id')+1];
   const prompt=field=>child.stdout.emit('data',Buffer.from('MCR_AO_BRIDGE_CONTACT '+JSON.stringify({requestId,wwid:'11412817',field})+'\n'));
   child.stdin.write=raw=>{const a=JSON.parse(raw);answers.push(a);setImmediate(()=>{if(a.field==='Adresse')prompt('PLZ');else{child.stdout.emit('data',Buffer.from(marker+JSON.stringify({status:'BLOCKED',error:'AO_CONTACT_INPUT_DEFERRED',requestId,wwid:'11412817',missing_fields:['Adresse','PLZ']})+'\n'));child.emit('close',2);}});};
   setImmediate(()=>prompt('Adresse'));return child;
  };
  const result=await runCentralAoGenerator(root,'11412817',f.paths,{spawnImpl,wait:tick,candidates:()=>[{executable:'python.exe',args:[]}],contactInput:async field=>field==='Adresse'?'Fiktive Teststrasse 7':null});
  assert.equal(result.status,'GENERATOR_BLOCKED');assert.equal(result.error,'AO_CONTACT_INPUT_DEFERRED');assert.deepEqual(result.missingFields,['Adresse','PLZ']);assert.equal(calls.length,2);assert.equal(killed,false);assert.equal(answers[1].approved,false);assert(!('value' in answers[1]));
 }finally{f.dispose();}
});

test('RC113 technical timeout still applies after the contact prompt is answered', {timeout:5000},async()=>{
 const f=fixture(),logs=[];let now=0,answerPending=null,killed=false,answered=false;
 try{
  const spawnImpl=(executable,args,options)=>{
   if(args.includes('--probe'))return spawnMock(()=>({body:{status:'PROBE_OK',sourceSha256:sourceSha}}))(executable,args,options);
   const child=new EventEmitter();child.stdout=new EventEmitter();child.stderr=new EventEmitter();child.stdin=new EventEmitter();child.stdin.end=()=>{};child.kill=()=>{killed=true;child.emit('close',1);};
   const requestId=args[args.indexOf('--request-id')+1];
   child.stdin.write=()=>{answered=true;}; // Synthetic hung generator after a valid response.
   setImmediate(()=>child.stdout.emit('data',Buffer.from('MCR_AO_BRIDGE_CONTACT '+JSON.stringify({requestId,wwid:'11412817',field:'Adresse'})+'\n')));return child;
  };
  const r=await runCentralAoGenerator(root,'11412817',f.paths,{spawnImpl,timeoutMs:5000,monotonicNow:()=>now,wait:async()=>{await tick();if(answerPending){now+=180000;const pending=answerPending;answerPending=null;pending('Fiktive Teststrasse 7');}else now+=answered?5000:1;},log:x=>logs.push(x),candidates:()=>[{executable:'python.exe',args:[]}],contactInput:()=>new Promise(resolve=>{answerPending=resolve;})});
  assert.equal(r.error,'AO_GENERATOR_TIMEOUT');assert(answered&&killed);assert(logs.some(x=>x.includes('GENERATOR_ARBEITET')));
 }finally{f.dispose();}
});


test('RC115 paused contact writing passes flag; logs isolated attempts and preserves sanitized diagnostics',async()=>{
 const f=fixture(),logs=[];f.paths.master=path.join(f.paths.folder,'master.xlsx');
 try{
  const result=await runCentralAoGenerator(root,'11412817',f.paths,{contactWriteAllowed:false,contactInput:async()=>assert.fail('no contact prompt'),log:x=>logs.push(x),wait:tick,candidates:()=>[{executable:'python.exe',args:[]}],spawnImpl:spawnMock(call=>{
   if(call.args.includes('--probe'))return {body:{status:'PROBE_OK',sourceSha256:sourceSha}};
   assert(call.args.includes('--contact-write-paused'));assert(call.args.includes('--interactive-contacts'));
   const body={status:'BLOCKED',requestId:call.args[call.args.indexOf('--request-id')+1],wwid:'11412817',error:'AO_QUEUE_PAUSED_MASTER_WRITE',missing_fields:['Adresse'],details:{operation:'open_contact_write_preflight',source:'master',owner_marker_present:true,separate_excel_lifecycles:true,directory_write_probe:'CREATED',directory_probe_removed:true,master_write_open_probe:'FAILED',master_probe_winerror:32,write_attempts:3,private_value:'never log'}};
   return {exitCode:2,raw:'MCR_AO_BRIDGE_STAGE MASTER_READER_CLOSED\nMCR_AO_BRIDGE_STAGE CONTACT_WRITE_ATTEMPT_1\nMCR_AO_BRIDGE_STAGE CONTACT_WRITE_RETRY_2\n'+marker+JSON.stringify(body)+'\n'};
  })});
  assert.equal(result.status,'GENERATOR_BLOCKED');assert.equal(result.error,'AO_QUEUE_PAUSED_MASTER_WRITE');assert.deepEqual(result.missingFields,['Adresse']);assert.equal(result.details.master_probe_winerror,32);assert.equal(result.details.owner_marker_present,true);assert.equal(result.details.write_attempts,3);assert(!logs.join(' ').includes('never log'));assert(logs.some(x=>x.includes('AO_MASTER_READER_CLOSED')));assert(logs.some(x=>x.includes('P2_AO_MASTER_WRITE_RETRY')));
 }finally{f.dispose();}
});
