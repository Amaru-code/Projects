/** RC105: central AO generation plus existing DC/PP+ preparation.
 * The calculator owns all financial formulas. No COMARCH mutation here. */
import fs from 'node:fs';
import path from 'node:path';
import {requireThat as need} from '../lib/core.mjs';
import {writeJSON,stamp,ledger} from '../lib/control.mjs';
import {phase2Admission} from '../lib/phase2-admission.mjs';
import {approvedWwid,inspectExistingStatements,generatorPaths} from '../lib/phase2-pdf-evidence.mjs';
import {runLocalStatementGenerator} from '../lib/phase2-local-generator.mjs';
import {verifyAoGeneratorProof,hasAutomaticAoPreparation} from '../lib/phase2-ao-proof.mjs';
import {aoContactQueue} from '../lib/phase2-ao-contact-queue.mjs';
import {beneficiaryBusinessFingerprint} from '../lib/phase2-post-generator-workbook.mjs';
import {readPhase2MemberEvidence} from '../lib/phase2-member-evidence.mjs';
import {resolveMemberMapping} from '../lib/member-mapping.mjs';
import {openPhase2Ticket} from '../lib/phase2-navigation.mjs';
import * as UI from '../lib/browser-workflow.mjs';

export function verifyLegacyPlanAlias(rule,member,mapping){
 if(!rule.requiresPlanConfirmation)return {verified:true,method:'CANONICAL_DESCRIPTION_PLANS'};
 need(member.profileVerified&&member.profile?.mercerId,'P2_LEGACY_IPP_MEMBER','IPP-Alteintrag ohne gebundenes Memberprofil.');
 const resolved=resolveMemberMapping(mapping,member.profile.mercerId);
 need(resolved.kind==='FOUND'&&Array.isArray(resolved.entry?.records),'P2_LEGACY_IPP_MAPPING','IPP-Alteintrag nicht eindeutig im Bestand.');
 const plans=new Set(resolved.entry.records.flatMap(r=>[...(r.dc===1?['DC']:[]),...(r.ppPlus===1?['PP+']:[])]));
 need(rule.targets.filter(t=>t!=='AO').every(t=>plans.has(t)),'P2_LEGACY_IPP_PLAN_CONFLICT','IPP-Alteintrag passt nicht zu DC/PP+ im gebundenen Bestand. Keine Anlage geraten.');
 return {verified:true,method:'LEGACY_IPP_CONFIRMED_BY_MEMBER_MAPPING'};
}

export function reviewedPdfProof({root,ticketId,rule,wwid,member,before,wwidOrigin,planEvidence,automaticAo=false,paths=generatorPaths}){
 const selectedArtifacts=before.artifacts.filter(a=>a.provenance==='CENTRAL_AO_GENERATOR_AUDIT');
 for(const a of selectedArtifacts)verifyAoGeneratorProof(root,a.generation,{wwid,first:member.profile.first,last:member.profile.last,paths});
 const fresh=inspectExistingStatements(root,rule.targets,wwid,{first:member.profile.first,last:member.profile.last,selectedArtifacts,paths});
 need(fresh.artifacts.length===before.artifacts.length&&fresh.artifacts.every(a=>{
  const p=before.artifacts.find(x=>x.plan===a.plan);return p&&p.name===a.name&&p.sha256===a.sha256&&p.bytes===a.bytes;
 }),'P2_PDF_MUTATED','PDFs seit Inhaltspruefung veraendert. Keine Anlage.');
 const proof={...fresh,ticketId,wwidOrigin,memberProfileVerified:true,
  memberId:member.profile.mercerId,memberName:{first:member.profile.first,last:member.profile.last},
  operatorContentReviewed:!automaticAo,operatorPersonTicketBindingReviewed:!automaticAo,
  ...(automaticAo?{systemPreparedForReview:true,requiresReviewerContentReview:true,preparationMethod:'CENTRAL_AO_GENERATOR_AUDIT'}:{}),
  operatorNameOnlyRecheckCompleted:false,planEvidence,
  automaticAttachmentAuthorized:false,comarchStatus:'NOT_ATTACHED_NOT_SAVED_NOT_FORWARDED'};
 if(automaticAo)need(hasAutomaticAoPreparation(proof),'P2_AO_AUTOMATIC_BINDING','Automatische AO-Vorbereitung nicht vollstaendig an den COMARCH-Member gebunden.');
 return proof;
}

export async function preparePhase2PdfEvidence({root,page,row,mapping,ask,askContact=ask,log=console.log,memberLookup=readPhase2MemberEvidence,controls=null,
 generator=runLocalStatementGenerator,paths=generatorPaths,ui=UI,openTicket=openPhase2Ticket,contactWriteAllowed=true}){
 const id=String(row.ticketId),admission=phase2Admission(row,ledger(root).pending),rule=admission.rule;
 need(admission.allowed&&rule.kind==='ACCOUNT_STATEMENT','P2_PDF_PREP_RULE','Kein unterstuetzter Dokumentenauftrag (DC/PP+/AO).');
 const actions=path.join(root,'.runtime','phase2','actions');
 need(!fs.existsSync(path.join(actions,'MCR_PHASE2_'+id+'.json'))&&!fs.existsSync(path.join(actions,'MCR_PHASE2_WORK_'+id+'.json')),
  'P2_PDF_PREP_PREVIOUS_ACTION','Schon begonnene Phase-2-Aktion: keine neue PDF-Vorbereitung.');
 await openTicket(page,row,{log,manualOpen:async ticket=>{
  need(String(await ask('Nur Ticket '+ticket+' im Bot-Edge oeffnen. OFFEN / ABBRUCH: ')).toUpperCase()==='OFFEN','P2_OPEN_ABORT','Abgebrochen.');
 }});
 await ui.assertTicket(page,id);await controls?.readDetail?.(page,id);
 const member=await memberLookup(page);
 need(member.profileVerified&&member.profile?.first&&member.profile?.last&&member.profile?.mercerId,
  'P2_MEMBER_NOT_BOUND','Kein eindeutiges COMARCH-Memberprofil fuer Dokumente.');
 const planEvidence=verifyLegacyPlanAlias(rule,member,mapping);
 need(!member.wwid||!member.memberReferenceWwid||member.wwid===member.memberReferenceWwid,
  'P2_WWID_CONFLICT','WWID-Feld widerspricht gebundener INTL01-Memberreferenz.');
 // Never use a generic MercerID or scan unrelated PDFs for a person ID.
 let wwid=member.wwid||member.memberReferenceWwid;
 const wwidOrigin=member.wwid?'EXPLICIT_COMARCH_FIELD':member.memberReferenceWwid?'BOUND_INTL01_MEMBER_REFERENCE':'OPERATOR_ENTRY';
 if(!wwid)wwid=approvedWwid(await ask('Verifizierte WWID dieser Person (nicht pauschal MercerID): '));
 wwid=approvedWwid(wwid);
 log('P2_PDF_PERSON: '+id+' | '+member.profile.first+' '+member.profile.last+' | WWID '+wwid+' | '+wwidOrigin);
 await controls?.waitUntilResumed?.();
 const selectedArtifacts=[];
 // Validate all required account statements BEFORE starting a potentially
 // persistent AO calculation. Missing/ambiguous files are ticket-local blocks.
 // DC/PP+ have no confirmed non-interactive generator contract yet.
 const pdfBlockCodes=new Set(['P2_EXACT_PDF_MISSING','P2_OUTPUT_FOLDER_MISSING','P2_PDF_SIZE','P2_PDF_HEADER','P2_PDF_EOF','P2_UNSAFE_PDF']);
 for(const plan of rule.targets.filter(plan=>plan!=='AO')){
  try{inspectExistingStatements(root,[plan],wwid,{first:member.profile.first,last:member.profile.last,paths});}
  catch(e){
   if(!pdfBlockCodes.has(e.code))throw e;
   log('P2_KONTOAUSZUG_GENERATORVERTRAG_OFFEN: '+id+' | '+plan+' | '+e.code+' | kein BAT-Start; keine Anlage; naechster Fall.');
   return {status:'SKIPPED_UNCHANGED',ticketId:id,noWrite:true,reason:e.code==='P2_EXACT_PDF_MISSING'||e.code==='P2_OUTPUT_FOLDER_MISSING'?'P2_DOCUMENT_GENERATOR_CONTRACT_REQUIRED':e.code};
  }
 }
 if(rule.targets.includes('AO')){
  // RC111: a new document job always generates; old preparation receipts
  // are historical only. The earlier action-journal guard remains mandatory.
  await ui.assertTicket(page,id);
  const stichtag='31.12.'+new Date().getFullYear();
  const queue=aoContactQueue(root,{ticketId:id,wwid,member,stichtag,masterPath:paths(root,'AO').master,generatorPath:paths(root,'AO').script,interactive:true});
  queue.recheck();
  log('P2_AO_REGENERATION_REQUIRED: '+id+' | WWID '+wwid+' | '+stichtag+' | alte PDF kein Ersatz.');
  log('P2_AO_ERSTELLEN: Ticket '+id+' | WWID '+wwid+' | Standardstichtag '+stichtag);
  let started;
  const attemptStartedAt=Date.now();
  try{started=await generator(root,'AO',wwid,{log,paths,aoOptions:{contactWriteAllowed,expectedPerson:{first:member.profile.first,last:member.profile.last},contactInput:async(field,signal)=>{
   if(!contactWriteAllowed)return null;
   await ui.assertTicket(page,id);
   let value;
   // Repeat the local question, never the generator's request. Keep the same
   // child process and active-time pause while correcting invalid input.
   while(true){
    if(signal?.aborted||controls?.gate?.closed)return null;
    value=await askContact(`\n------------------------------------------------\nEINGABE IM AKTUELLEN MCR-FENSTER ERFORDERLICH\nTicket: ${id} | WWID: ${wwid}\nPerson: ${member.profile.first} ${member.profile.last}\n${field} fehlt im Stammdatenbestand. Nur fachlich gepruefte Angaben eingeben.\nSchreibzugriff vorgeprueft; vor Save erneute Pruefung.\nDie Eingabe ersetzt nur den fehlenden/fehlerhaften Wert (ggf. eine Formel mit fehlendem Ergebnis).\nDie Angaben werden nach vollstaendiger Eingabe im Stammdatenbestand gespeichert.\n${field==='PLZ'?'PLZ: genau fuenf Ziffern, ohne Ort.\n':''}ENTER ohne Wert / UEBERSPRINGEN = Ticket offenlassen.\n------------------------------------------------\n${field}: > `,signal);
    if(signal?.aborted||controls?.gate?.closed||value===null||!String(value).trim()||/^(UEBERSPRINGEN|ABBRUCH)$/i.test(String(value).trim()))return null;
    value=String(value).trim();
    if(field!=='PLZ'||/^[0-9]{5}$/.test(value))break;
    log('P2_AO_PLZ_EINGABE_UNGUELTIG: Bitte genau fuenf Ziffern ohne Ortsnamen eingeben; derselbe Generator wartet.');
   }
   await ui.assertTicket(page,id);
   const current=await memberLookup(page);
   need(current.profileVerified&&current.profile?.mercerId===member.profile.mercerId&&current.profile.first===member.profile.first&&current.profile.last===member.profile.last&&(!current.wwid||current.wwid===wwid)&&(!current.memberReferenceWwid||current.memberReferenceWwid===wwid),
    'P2_PDF_MEMBER_CHANGED','Member waehrend der Kontakteingabe geaendert.');
   return value;
  }}});}
  catch(error){
   log('P2_AO_ERSTELLUNG_OFFEN: '+id+' | '+(error.code||'AO_GENERATOR_ERROR')+' | '+error.message);
   return {status:'SKIPPED_UNCHANGED',ticketId:id,noWrite:true,reason:error.code||'P2_AO_GENERATOR_FAILED'};
  }
  if(started.status!=='GENERATOR_EXECUTED'||!started.proof){
   const reason=started.error||'P2_AO_GENERATOR_FAILED';
   log('P2_AO_ERSTELLUNG_OFFEN: '+id+' | '+reason+' | '+(started.reason||started.status)+' | kein Upload; naechstes Ticket.');
   if(['AO_CONTACT_DATA_REQUIRED','AO_CONTACT_INPUT_DEFERRED','AO_CONTACT_INPUT_INVALID'].includes(reason)){
    if(reason==='AO_CONTACT_INPUT_DEFERRED')log('P2_AO_CONTACT_INPUT_ABGEBROCHEN: Generator hat den Abbruch vor der Kontaktspeicherung bestaetigt; keine neue PDF, kein Upload.');
    const pending=queue.waiting(started.missingFields,started.details?.master_sha256);
    log('P2_AO_WAITING_FOR_CONTACT_DATA: '+id+' | '+pending.missingFields.join(', ')+' | Kontakteingabe offen; kein COMARCH-Schreibzugriff.');
    return {status:'SKIPPED_UNCHANGED',ticketId:id,noWrite:true,reason:'AO_WAITING_FOR_CONTACT_DATA',missingFields:pending.missingFields,technicalDetails:started.details||{}};
   }
   return {status:'SKIPPED_UNCHANGED',ticketId:id,noWrite:true,reason,missingFields:started.missingFields||[],technicalDetails:started.details||{}};
  }
  selectedArtifacts.push(verifyAoGeneratorProof(root,started.proof,{wwid,first:member.profile.first,last:member.profile.last,paths,fresh:true,attemptStartedAt}));
  queue.generated(started.proof);
  log('PASS P2_AO_NEW_AUDIT_VERIFIED: '+id+' | neuer gebundener Audit.');
  log('PASS P2_AO_NEW_PDF_VERIFIED: '+id+' | '+selectedArtifacts[0].name);
  log('PASS P2_AO_ERZEUGT_UND_GEBUNDEN: '+id+' | '+selectedArtifacts[0].name+' | WWID, Name, Stichtag, Audit und PDF-Hash bestaetigt.');
 }
 await controls?.waitUntilResumed?.();
 let before;
 try{before=inspectExistingStatements(root,rule.targets,wwid,{first:member.profile.first,last:member.profile.last,selectedArtifacts,paths});}
 catch(e){if(!pdfBlockCodes.has(e.code))throw e;
  log('P2_DOKUMENTE_NICHT_EINDEUTIG: '+id+' | '+e.code+' | keine COMARCH-Schreibaktion.');
  return {status:'SKIPPED_UNCHANGED',ticketId:id,noWrite:true,reason:e.code};
 }
 const automaticAo=rule.targets.length===1&&rule.targets[0]==='AO'&&selectedArtifacts.length===1&&wwidOrigin!=='OPERATOR_ENTRY';
 if(automaticAo){
  log('PASS P2_AO_AUTOMATISCH_VORBEREITET: Ergebnis des zentralen Generators wird angehaengt; fachliche Pruefung bei Mark.');
 }else{
  for(const a of before.artifacts)log('P2_PDF_INHALT_PRUEFEN: '+a.plan+' | '+a.file);
  const response=String(await ask('Ticket '+id+': Person, WWID, Zeitraum, Berechtigung und Inhalte ALLER '+before.artifacts.length+' PDFs geprueft? JA / UEBERSPRINGEN / ABBRUCH: ')).trim().toUpperCase();
  if(response==='UEBERSPRINGEN')return {status:'SKIPPED_UNCHANGED',ticketId:id,noWrite:true,reason:'PDF_CONTENT_REVIEW_DEFERRED'};
  need(response==='JA','P2_CONTENT_REVIEW_REQUIRED','Keine Anlage ohne Inhaltspruefung.');
 }
 await ui.assertTicket(page,id);
 const afterMember=await memberLookup(page);
 need(afterMember.profileVerified&&afterMember.profile.mercerId===member.profile.mercerId&&
  afterMember.profile.first===member.profile.first&&afterMember.profile.last===member.profile.last&&
  (!afterMember.wwid||afterMember.wwid===wwid)&&(!afterMember.memberReferenceWwid||afterMember.memberReferenceWwid===wwid)&&
  (wwidOrigin==='OPERATOR_ENTRY'||afterMember.wwid===wwid||afterMember.memberReferenceWwid===wwid),
  'P2_PDF_MEMBER_CHANGED','Member/WWID waehrend der PDF-Pruefung geaendert.');
 const proof=reviewedPdfProof({root,ticketId:id,rule,wwid,member,before,wwidOrigin,planEvidence,automaticAo,paths});
 if(rule.targets.includes('AO')){
  const fingerprint=beneficiaryBusinessFingerprint(mapping,wwid);
  if(fingerprint)proof.memberBusinessEvidence={schema:'MCR_AO_MEMBER_WORKBOOK_V1',wwid,fingerprint};
 }
 const file=path.join(root,'.runtime','phase2','MCR_PHASE2_PDF_BELEG_'+id+'_'+stamp()+'.json');
 writeJSON(file,proof);log('PASS P2_PDF_BELEGE_IM_LAUF: '+id+' | '+rule.targets.join('+')+' | keine COMARCH-Aenderung bisher.');
 return {status:'PDF_PROOF_READY',ticketId:id,proof,file};
}
