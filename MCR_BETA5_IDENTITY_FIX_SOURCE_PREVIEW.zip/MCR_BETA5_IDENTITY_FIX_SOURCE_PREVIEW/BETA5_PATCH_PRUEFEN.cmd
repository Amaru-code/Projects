@echo off
setlocal
chcp 65001 >nul
set "KIT=%~dp0"
set "PROJ=%USERPROFILE%\projects\Aktive_Projekte\Ticket_bot\MCR_Datenbruecke"
if not "%~1"=="" set "PROJ=%~1"
set "DEST=%KIT%candidate_preview_%RANDOM%_%RANDOM%"

echo ==============================================================
echo  MCR Beta 5 - Identity-Guard PATCH VORSCHAU - KEIN ECHTLAUF
echo ==============================================================
echo.
echo Quelle: %PROJ%
echo Ausgabe: %DEST%
echo.
where node >nul 2>&1
if errorlevel 1 (
  echo STOP: Node.js im PATH nicht gefunden.
  goto :fail
)
node --test "%KIT%tests\identity-evidence.test.cjs" "%KIT%tests\patcher.test.mjs"
if errorlevel 1 goto :fail
node "%KIT%tools\prepare.mjs" --root "%PROJ%" --out "%DEST%"
if errorlevel 1 goto :fail
echo.
echo PATCH-VORSCHAU ERFOLGREICH. Beta 4 bleibt UNVERAENDERT.
echo Einbauen und als Beta 5 freigeben erst nach Paket-Integrationspruefung.
pause
exit /b 0
:fail
echo.
echo STOP: Keine produktive Datei veraendert. Nichts senden.
pause
exit /b 1
