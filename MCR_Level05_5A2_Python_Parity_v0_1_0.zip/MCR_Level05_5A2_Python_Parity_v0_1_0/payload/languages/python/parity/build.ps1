[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'

$ModeRoot = $PSScriptRoot
$SrcRoot = Join-Path $ModeRoot 'src'
$BuildRoot = Join-Path $ModeRoot 'build'
$Publish = Join-Path $BuildRoot 'publish'
$Pointer = Join-Path $BuildRoot 'python_path.txt'
$MainSource = Join-Path $SrcRoot 'main.py'
$MainPublish = Join-Path $Publish 'main.py'

function Test-Python([string]$Path) {
    if ([string]::IsNullOrWhiteSpace($Path) -or -not (Test-Path $Path -PathType Leaf)) { return $false }
    $old=$ErrorActionPreference; $ErrorActionPreference='Continue'
    try {
        & $Path -c "import sys, openpyxl, win32com.client; print(sys.version.split()[0])" *> $null
        $c=$LASTEXITCODE
    } finally { $ErrorActionPreference=$old }
    return ($c -eq 0)
}

$Candidates = New-Object System.Collections.Generic.List[string]

if ($env:LOCALAPPDATA) {
    $ProductPython = Join-Path $env:LOCALAPPDATA 'LNW_DCPipeline\venv\Scripts\python.exe'
    if (Test-Path $ProductPython -PathType Leaf) { $Candidates.Add($ProductPython) }
}

$cmd = Get-Command python.exe -ErrorAction SilentlyContinue
if ($cmd -and -not $Candidates.Contains($cmd.Source)) { $Candidates.Add($cmd.Source) }

if ($env:USERPROFILE) {
    $compiler = Join-Path $env:USERPROFILE 'projects\Compiler'
    if (Test-Path $compiler) {
        Get-ChildItem $compiler -Recurse -Filter python.exe -File -ErrorAction SilentlyContinue | ForEach-Object {
            if (-not $Candidates.Contains($_.FullName)) { $Candidates.Add($_.FullName) }
        }
    }
}

$Python=$null
foreach($c in $Candidates){ if(Test-Python $c){ $Python=$c; break } }
if(-not $Python){ throw 'Keine vorhandene Python-Runtime mit openpyxl + pywin32 gefunden. Es wird nichts heruntergeladen.' }

Write-Host '============================================================'
Write-Host ' Level 05A.2 - Python Parity Reference Build'
Write-Host '============================================================'
Write-Host "python:    $Python"
Write-Host "Python:    $(& $Python --version)"
Write-Host "Source:    $MainSource"
Write-Host "Publish:   $Publish"
Write-Host ''
Write-Host 'Role: frozen Python 1.0.3 reference implementation'
Write-Host 'Dependencies: existing certified product runtime only / OFFLINE'
Write-Host 'Native candidate EXE generation: NONE'
Write-Host ''

if(Test-Path $Publish){ Remove-Item $Publish -Recurse -Force }
New-Item -ItemType Directory -Force -Path $Publish | Out-Null
Copy-Item $MainSource $MainPublish -Force
New-Item -ItemType Directory -Force -Path $BuildRoot | Out-Null
Set-Content $Pointer $Python -Encoding UTF8

# Compile-only syntax check; no candidate execution.
& $Python -m py_compile $MainPublish
if($LASTEXITCODE -ne 0){ throw "Python Source Check fehlgeschlagen. ExitCode=$LASTEXITCODE" }

Write-Host ''
Write-Host 'PYTHON PARITY REFERENCE BUILD: PASS' -ForegroundColor Green
Write-Host "MAIN: $MainPublish"
Write-Host 'Runtime: existing python.exe (no new native EXE)' -ForegroundColor Green
exit 0
