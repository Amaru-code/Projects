from __future__ import annotations

import argparse
import json
import os
import sys
import traceback
from pathlib import Path

EXPECTED_CASE = "MCR_LNW_001"
EXPECTED_ORACLE_ROOT_SHA256 = "0183692661275035cd886ec56cf539b36d92f46b4deead23e2e609b80f5aadf9"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="MCR Level 05A.2 Python parity reference candidate")
    parser.add_argument("--case", required=True)
    parser.add_argument("--input", required=True)
    parser.add_argument("--template", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--workers", type=int, default=4)
    return parser.parse_args()


def level05_root() -> Path:
    # .../Level_05/languages/python/parity/build/publish/main.py
    return Path(__file__).resolve().parents[5]


def load_frozen_product_source(level05: Path):
    oracle_base = level05 / "oracle" / "python_1_0_3"
    manifest_path = oracle_base / "ORACLE_SOURCE_MANIFEST.json"
    product_root = oracle_base / "source" / "LNW_DC_Pipeline_1_0_3"

    if not manifest_path.is_file():
        raise RuntimeError(f"Frozen Python oracle manifest missing: {manifest_path}")
    if not product_root.is_dir():
        raise RuntimeError(f"Frozen Python product source missing: {product_root}")

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    actual_root = str(manifest.get("root_sha256", "")).lower()
    if actual_root != EXPECTED_ORACLE_ROOT_SHA256:
        raise RuntimeError(
            "Frozen Python product source SHA mismatch: "
            f"expected {EXPECTED_ORACLE_ROOT_SHA256}, got {actual_root}"
        )

    pipeline_dir = product_root / "pipeline"
    if str(pipeline_dir) not in sys.path:
        sys.path.insert(0, str(pipeline_dir))

    from orchestrator import LNWPipeline  # type: ignore

    return LNWPipeline, product_root, manifest


def relpath(path: Path, output_root: Path) -> str:
    return path.resolve().relative_to(output_root.resolve()).as_posix()


def main() -> int:
    args = parse_args()

    if args.case != EXPECTED_CASE:
        raise RuntimeError(f"This candidate is frozen to case {EXPECTED_CASE}.")

    source = Path(args.input).resolve()
    template = Path(args.template).resolve()
    output = Path(args.output).resolve()

    if not source.is_dir():
        raise RuntimeError(f"Frozen input directory missing: {source}")
    if not template.is_file():
        raise RuntimeError(f"Frozen template missing: {template}")

    output.mkdir(parents=True, exist_ok=True)

    level05 = level05_root()
    LNWPipeline, product_root, manifest = load_frozen_product_source(level05)

    print("=" * 72)
    print("MCR LEVEL 05A.2 - PYTHON MODE 1 PARITY REFERENCE CANDIDATE")
    print("=" * 72)
    print(f"Case:     {args.case}")
    print(f"Input:    {source}")
    print(f"Template: {template}")
    print(f"Output:   {output}")
    print(f"Workers:  {args.workers}")
    print("Reference source: frozen LNW_DC_Pipeline 1.0.3")
    print(f"Source SHA: {manifest['root_sha256']}")
    print()

    previous_workers = os.environ.get("LNW_PIPELINE_WORKERS")
    os.environ["LNW_PIPELINE_WORKERS"] = str(max(1, args.workers))

    try:
        pipeline = LNWPipeline(progress_callback=print)
        result = pipeline.run(source, template, output, recursive=True)
    finally:
        if previous_workers is None:
            os.environ.pop("LNW_PIPELINE_WORKERS", None)
        else:
            os.environ["LNW_PIPELINE_WORKERS"] = previous_workers

    candidate = {
        "schema": "mcr.level05.candidate-result.v1",
        "status": "success",
        "case": args.case,
        "language": "python",
        "mode": "parity",
        "artifacts": {
            "du_master": relpath(result.du.master_file, output),
            "dp_master": relpath(result.dp.master_file, output),
            "lnw_excel": relpath(result.lnw_excel, output),
            "lnw_csv": relpath(result.lnw_csv, output),
        },
        "diagnostics": {
            "du_master_rows": result.du.master_rows,
            "dp_master_rows": result.dp.master_rows,
            "workers": max(1, args.workers),
            "python": sys.version,
            "reference_source": str(product_root),
            "reference_source_sha256": manifest["root_sha256"],
            "reference_role": "frozen_python_baseline",
        },
    }

    result_path = output / "candidate_result.json"
    result_path.write_text(json.dumps(candidate, ensure_ascii=False, indent=2), encoding="utf-8")

    print()
    print("Python reference candidate completed successfully.")
    print(f"DU Master Rows: {result.du.master_rows}")
    print(f"DP Master Rows: {result.dp.master_rows}")
    print("candidate_result.json written.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except SystemExit:
        raise
    except Exception:
        print(file=sys.stderr)
        print("PYTHON CANDIDATE FAILED", file=sys.stderr)
        traceback.print_exc()
        raise SystemExit(1)
