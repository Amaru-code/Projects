[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][Alias('Case')][ValidateNotNullOrEmpty()][string]$CaseId,
    [Parameter(Mandatory=$true)][Alias('Input')][ValidateNotNullOrEmpty()][string]$InputPath,
    [Parameter(Mandatory=$true)][Alias('Template')][ValidateNotNullOrEmpty()][string]$TemplatePath,
    [Parameter(Mandatory=$true)][Alias('Output')][ValidateNotNullOrEmpty()][string]$OutputPath,
    [int]$Workers = 4
)

$ErrorActionPreference='Stop'
$ModeRoot=$PSScriptRoot
$BuildRoot=Join-Path $ModeRoot 'build'
$Publish=Join-Path $BuildRoot 'publish'
$Main=Join-Path $Publish 'main.py'
$Pointer=Join-Path $BuildRoot 'python_path.txt'

if(-not(Test-Path $Main -PathType Leaf)){throw "Python Candidate wurde noch nicht gebaut: $Main"}
if(-not(Test-Path $Pointer -PathType Leaf)){throw 'python_path.txt fehlt. build.ps1 zuerst ausfuehren.'}
$Python=(Get-Content $Pointer -Raw).Trim()
if(-not(Test-Path $Python -PathType Leaf)){throw "Python Runtime fehlt: $Python"}

Write-Host 'Python Reference Candidate Wrapper'
Write-Host "Case:     [$CaseId]"
Write-Host "Input:    [$InputPath]"
Write-Host "Template: [$TemplatePath]"
Write-Host "Output:   [$OutputPath]"
Write-Host "Workers:  [$Workers]"
Write-Host "Runtime:  [$Python]"

if(Test-Path $OutputPath){
    Get-ChildItem $OutputPath -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force
}else{
    New-Item -ItemType Directory -Force -Path $OutputPath | Out-Null
}

& $Python -B $Main --case $CaseId --input $InputPath --template $TemplatePath --output $OutputPath --workers $Workers
$Code=$LASTEXITCODE
if($null -eq $Code){throw 'Python Candidate returned no exit code.'}
exit [int]$Code
