# Level 05A.2 – Python Mode 1 Parity Reference v0.1.0

Python is the original implementation language of the frozen LNW DC product.
For that reason the Python Mode-1 candidate deliberately uses the exact frozen
`LNW_DC_Pipeline 1.0.3` product source already certified in Level 05A.0.

This is **not** the benchmark oracle runner and it does not call the validator.
It invokes the frozen product pipeline directly, then writes the standard
`candidate_result.json` contract so the common Level-05 validator can evaluate
the outputs exactly like every other language.

Frozen source root SHA-256:
`0183692661275035cd886ec56cf539b36d92f46b4deead23e2e609b80f5aadf9`
