# MCR Level 05A.2 – Python Mode 1 Parity Reference v0.1.0

Python is the frozen reference implementation for Level 05.

This package installs a standard Level-05 candidate wrapper that invokes the
already-certified `LNW_DC_Pipeline 1.0.3` product source directly and exposes
its outputs through the same `candidate_result.json` contract used by every
other language.

Important distinction:
- frozen product source: used intentionally as the Python baseline
- `runner/oracle_runner.py`: NOT used
- common validator: runs only after the timed candidate execution
- no new native candidate EXE is generated

Run `START_5A2_PYTHON.ps1`.
