@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
echo ==============================================================
echo  MCR Gender-Mapping 0.1.1 aktualisieren - Spalte O M/F
ECHO ==============================================================
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0GENDER_MAPPING_AKTUALISIEREN.ps1"
set "RC=%errorlevel%"
echo.
if not "%RC%"=="0" echo FEHLER: Gender-Erweiterung wurde nicht abgeschlossen.
pause
exit /b %RC%
