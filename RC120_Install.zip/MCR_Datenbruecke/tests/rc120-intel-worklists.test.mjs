import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {inspectIntelNavigation,readPhase1Worklist,reloadPhase1List} from '../lib/intel-worklist-navigation.mjs';
import {queueTableSnapshot,navigateToScope} from '../lib/browser-workflow.mjs';
import {phase1ListDecision} from '../lib/source-neutral-policy.mjs';
import {describeTicketIssue} from '../lib/ticket-error-catalog.mjs';

const queue='WARTESCHLANGE_INTL01',queueMenu='storedSearchesContainer_MY_QUEUES';
const queueTable='mainForm:tasksTableFor_MyQueuesTasksList',ownTable='mainForm:tasksTableFor_MyTasksList';
const unavailable=()=>Object.assign(new Error('list unavailable'),{code:'INTL_SCOPE_NOT_AVAILABLE',navigationState:{targetState:'CHILD_NOT_VISIBLE'}});

function fixture(){
 const doc={readyState:'complete'},entries=new Map(),clicks=[];
 const style=()=>({display:'block',visibility:'visible',fontWeight:'400',pointerEvents:'auto'});
 doc.defaultView={getComputedStyle:style};
 let nextY=0;
 const rect=y=>({left:5,right:105,top:y,bottom:y+8});
 function element(attrs={},props={}){
  const y=nextY+=10, n={ownerDocument:doc,tagName:'SPAN',isConnected:true,shown:true,
   getAttribute:k=>attrs[k]??null,hasAttribute:k=>Object.hasOwn(attrs,k),getClientRects(){return this.shown?[rect(y)]:[];},
   scrollIntoView(){},classList:{contains:()=>false},closest:()=>null,querySelectorAll:()=>[],contains(other){return this===other;},...props};
  entries.set(y,n);return n;
 }
 function item(text,options={}){
  const n=element(options.attrs,{textContent:text,tagName:'A',...options});
  n.closest=()=>n;return n;
 }
 const child=item('INTL01 (3)'),folder=element({id:queueMenu},{contains:n=>children.includes(n),querySelectorAll:()=>children});
 const header=element({'aria-controls':queueMenu,'aria-expanded':'false'},{tagName:'BUTTON',type:'button'});
 const otherHeader=item('Offene Vorgänge',{attrs:{href:'#open-list','aria-controls':queueMenu,'aria-expanded':'false'}});
 let children=[],disclosures=[otherHeader,header],table;
 const makeRow=id=>{
  const cells=[id,'E-MAIL',''].map(v=>element({},{tagName:'TD',textContent:v,querySelector:()=>null}));
  return element({},{tagName:'TR',children:cells,textContent:cells.map(c=>c.textContent).join(' ')});
 };
 function setTable(tableId,groups){
  table=element({},{id:tableId,tHead:{rows:[{cells:['Ticket-ID','Quelle','Zusätzliche Beschreibung'].map(textContent=>({textContent}))}]},
   tBodies:groups.map(ids=>({rows:ids.map(makeRow)}))});
 }
 doc.querySelectorAll=sel=>{
  if(sel==='[id="'+queueMenu+'"]')return [folder];
  if(sel.includes('aria-controls'))return disclosures;
  if(sel==='[id="'+table?.id+'"]')return [table];
  return [];
 };
 doc.elementFromPoint=(x,y)=>[...entries].find(([top,n])=>n.shown&&y>=top&&y<top+8)?.[1];
 const ctx=vm.createContext({document:doc,window:{},getComputedStyle:style,innerWidth:300,innerHeight:1500});
 const page={call:(fn,...args)=>vm.runInContext('('+fn.toString()+')(...'+JSON.stringify(args)+')',ctx),
  async mouseClick(x,y){const n=doc.elementFromPoint(x,y);clicks.push(n);await n?.onClick?.();}};
 header.onClick=()=>{children=[child];disclosures=[otherHeader];};
 child.onClick=()=>setTable(queueTable,[[],['99911001']]);
 return {page,clicks,child,header,otherHeader,setTable,setChildren:c=>{children=c;},getTable:()=>table,makeRow,item,inspect:()=>page.call(inspectIntelNavigation,queue,true,true)};
}

test('RC120 chained scan expands only an attributed disclosure and clicks the exact queue including its item count',async()=>{
 const f=fixture();f.setTable(ownTable,[[]]);
 assert.equal(f.inspect().state,'DISCLOSURE');
 const next=await navigateToScope(f.page,queue);
 assert.deepEqual(f.clicks,[f.header,f.child]);assert(!f.clicks.includes(f.otherHeader));
 assert.equal(next.rows[0].ticketId,'99911001');assert.equal(next.scope,queue);
});

test('RC120 ambiguous, annotated foreign and similarly named queue options cannot be picked',()=>{
 const f=fixture();f.setChildren([f.child,f.item('INTL01')]);assert.equal(f.inspect().state,'DUPLICATE_CHILD');
 f.setChildren([f.item('INTL01 West',{title:'INTL01'}),f.item('INTL0101')]);
 assert.equal(f.inspect().state,'DISCLOSURE');
 f.setChildren([f.item('INTL01 [9]',{attrs:{'aria-selected':'true'}})]);
 assert.equal(f.inspect().active,true);
});

test('RC120 wait past menu highlight for stale rows in a table shared with a different stored search',async()=>{
 const f=fixture();f.setTable(queueTable,[['99911002']]);f.setChildren([f.child]);
 f.child.onClick=()=>setTimeout(()=>f.setTable(queueTable,[['99911003']]),330);
 const next=await navigateToScope(f.page,queue);
 assert.deepEqual(f.clicks,[f.child]);assert.equal(next.rows[0].ticketId,'99911003');
});

test('RC120 an explicit empty result is distinct from a loading placeholder',async()=>{
 const f=fixture();f.setTable(queueTable,[[]]);assert.equal((await queueTableSnapshot(f.page)).state,'READY_EMPTY');
 const temp=f.makeRow('Lädt …');f.getTable().tBodies[0].rows.push(temp);
 assert.equal((await queueTableSnapshot(f.page)).state,'QUEUE_ROWS_UNREADABLE');
 temp.textContent='Keine Treffer';assert.equal((await queueTableSnapshot(f.page)).state,'READY_EMPTY');
});

test('RC120 exact unavailable scope now recovers in the same Phase 1 scan; errors cannot be counted as an empty queue',async()=>{
 let reads=0,resets=0,questions=0;
 const target={scope:queue,rows:[{ticketId:'99911001'}]};
 const result=await readPhase1Worklist(queue,{readList:async s=>{assert.equal(s,queue);if(++reads===1)throw unavailable();return target;},
  resetView:async()=>{resets++;return true;},ask:async()=>{questions++;}});
 assert.equal(result,target);assert.equal(reads,2);assert.equal(resets,1);assert.equal(questions,0);
 reads=0;
 await assert.rejects(()=>readPhase1Worklist(queue,{readList:async()=>{reads++;throw unavailable();},resetView:async()=>true,ask:async()=>''}),{code:'INTL_SCOPE_NOT_AVAILABLE'});
 assert.equal(reads,3);
 assert.equal(describeTicketIssue({reason:'INTL_SCOPE_NOT_AVAILABLE',phase:'P1'}).errorCode,'MCR-P1-112');
});

test('RC120 persisted queue collapse allows one operator-assisted same-run continuation',async()=>{
 let reads=0,prompt;const result=await readPhase1Worklist(queue,{readList:async()=>{if(++reads<3)throw unavailable();return {scope:queue,rows:[]};},resetView:async()=>true,
  ask:async s=>{prompt=s;return '';}});
 assert.match(prompt,/INTL01/);assert.equal(result.scope,queue);
 await assert.rejects(()=>readPhase1Worklist(queue,{readList:async()=>{throw Object.assign(new Error(),{code:'TICKET_BINDING'});},
  resetView:()=>assert.fail(),ask:()=>assert.fail()}),{code:'TICKET_BINDING'});
});

test('RC120 list-view reload is confined to one owned session and waits for the new document',async()=>{
 let sends=[],polls=0;const url='https://comarchecm.mercer.com/app';
 const page={sessionId:'ownSession',call:async(_fn,expected)=>expected===url,cdp:{send:async(method,p,session)=>{
  assert.equal(session,'ownSession');sends.push(method);
  if(method==='Page.navigate'){assert.equal(p.url,url);return {frameId:'frame'};}
  return {frameTree:{frame:{id:'frame',loaderId:++polls<=2?'prior':'new'}}};
 }}};
 assert(await reloadPhase1List(page,url,{detailId:async()=>null,delay:async()=>{}}));
 assert.deepEqual(sends,['Page.getFrameTree','Page.navigate','Page.getFrameTree','Page.getFrameTree']);
 sends=[];
 assert.equal(await reloadPhase1List(page,url,{detailId:async()=>'99911002',delay:async()=>{}}),false);
 assert.deepEqual(sends,[]);
});

test('RC120 selection and counts use the live textarea value and do not double-count journal exclusions',async()=>{
 const f=fixture();f.setTable(ownTable,[['99911001','99911002','99911003','99911004']]);
 const rows=f.getTable().tBodies[0].rows;
 const desc=(idx,old,live)=>{
  const cell=rows[idx].children[2];cell.innerText=old;
  cell.querySelectorAll=s=>s==='textarea'?[{value:live}]:[];
 };
 desc(0,'','Already processed\r\nInternal note');desc(1,'Old USC 22 / DB','');
 desc(2,'Input at page load','Standardantwort versendet');
 desc(3,'','Completed\nStandardantwort versendet');
 const result=await queueTableSnapshot(f.page),decision=phase1ListDecision(result.rows,new Set(['99911003']));
 assert(result.ok);assert.equal(result.rows[0].descriptionBlank,false);
 assert.equal(result.rows[0].descriptionRaw,'Already processed\nInternal note');
 assert.equal(result.rows[1].descriptionBlank,true);assert.equal(decision.next.ticketId,'99911002');
 assert.deepEqual(decision.counts,{visible:4,processedOrExcluded:1,notEligible:2,candidates:1});
 rows[0].children[2].querySelectorAll=()=>[{value:''},{value:'USC 20/DB'}];
 assert.equal((await queueTableSnapshot(f.page)).state,'QUEUE_DESCRIPTION_AMBIGUOUS');
});

test('RC120 malformed or duplicate mixed rows invalidate the scan, standard pager rows do not',async()=>{
 const f=fixture();f.setTable(ownTable,[['99911001'],['99911002']]);
 const second=f.getTable().tBodies[1].rows;
 second.push(f.makeRow('data pending'));
 assert.equal((await queueTableSnapshot(f.page)).state,'QUEUE_ROWS_UNREADABLE');
 second.pop();second.push(f.makeRow('99911001'));
 assert.equal((await queueTableSnapshot(f.page)).state,'DUPLICATE_TICKET_ID');
 second.pop();
 const pager=f.makeRow('Page 1');pager.children=pager.children.slice(0,1);
 pager.children[0].colSpan=3;pager.matches=()=>false;pager.children[0].matches=()=>false;
 pager.children[0].querySelector=q=>q.includes('.iceDatPgr')?{}:null;
 second.push(pager);
 const result=await queueTableSnapshot(f.page);
 assert(result.ok);assert.equal(result.rows.length,2);
});
