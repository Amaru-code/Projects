/** Full software deployment, preserving all user data in place.
 * No recursive copy of .runtime/private_data, no browser launch, no ticket action.
 */
import fs from 'node:fs';import path from 'node:path';import {requireThat as need,sha256} from '../lib/core.mjs';import {plainPath,readJSON,writeJSON,stamp,lock,controlDir,phase1ResultPath} from '../lib/control.mjs';import {loadActiveMapping} from '../lib/workbook/active-mapping.mjs';import {verifyPackage,verifyPrevious,treeDigest} from './integrity.mjs';import {windowsIdle} from './process-guard.mjs';
import {cleanupInstallationOutputs} from './install-cleanup.mjs';
import {resolveConfig} from '../lib/config.mjs';
import {releaseOrphanedRealLock} from '../lib/runtime/run-reset.mjs';
import {assertMigrationPermit} from '../lib/runtime/migration-priority.mjs';
const NAMES=['MAP_START.cmd','MAP_OEFFNEN.cmd','START.cmd','package.json','MANIFEST.json','SHA256SUMS.txt','README_DE.md','README.md','.gitignore','src','lib','tools','tests','docs','examples'];
const BARRIER='BETA_UMSTELLUNG_LAEUFT.txt';
function copyTree(src,dst){plainPath(src);need(!fs.existsSync(dst),'DEST_EXISTS','Ziel existiert bereits.');const s=fs.statSync(src);if(s.isDirectory()){fs.mkdirSync(dst);for(const n of fs.readdirSync(src))copyTree(path.join(src,n),path.join(dst,n));}else{need(s.isFile(),'SOURCE_FILE','Keine normale Softwaredatei.');fs.copyFileSync(src,dst,fs.constants.COPYFILE_EXCL);}}
function targetCheck(source,target){source=plainPath(path.resolve(source));target=plainPath(path.resolve(target));need(path.basename(target).toLowerCase()==='mcr_datenbruecke','TARGET_NAME','Ziel muss MCR_Datenbruecke heissen.');need(source!==target&&!source.startsWith(target+path.sep)&&!target.startsWith(source+path.sep),'SETUP_LOCATION','Neues Paket getrennt ausserhalb der alten Installation entpacken.');return {source,target};}
function dataBinding(root){const a=loadActiveMapping(root);return {mappingFileSha256:a.fileHash,pointerSha256:sha256(fs.readFileSync(a.pointerPath)),configSha256:sha256(fs.readFileSync(path.join(root,'config/local-runner-queue-send.json')))};}
export function planInstall(source,target,{verifyOld=verifyPrevious,migration=null}={}){({source,target}=targetCheck(source,target));const release=verifyPackage(source);if(fs.existsSync(path.join(target,BARRIER))){need(migration,'MIGRATION_INCOMPLETE','Offene Umstellung: Rueckweg im neuen START-Menue verwenden.');assertMigrationPermit(target,source,migration);}const old=verifyOld(target);
 const programs=fs.readdirSync(target).filter(n=>/\.(cmd|bat|ps1|mjs|cjs|js|html)$/i.test(n)&&!['START.cmd','MAP_START.cmd','MAP_OEFFNEN.cmd'].includes(n));need(!programs.length,'UNKNOWN_ROOT_PROGRAM','Unbekannte Programme im Hauptordner. Nichts wird still geloescht.');const before=dataBinding(target);
 const sealedRoots=new Set(['MANIFEST.json','SHA256SUMS.txt',...readJSON(path.join(source,'MANIFEST.json'),2*1024*1024).payload.map(item=>item.path.split('/')[0])]);
 const oldItems=NAMES.filter(n=>fs.existsSync(path.join(target,n))).map(name=>({name,hash:treeDigest(path.join(target,name))}));
 const incoming=NAMES.filter(n=>sealedRoots.has(n)).map(name=>({name,hash:treeDigest(path.join(source,name))}));
 return {schema:'MCR_COMPLETE_INSTALL_PLAN_V1',source,target,release,old,before,oldItems,incoming};}
// Windows may temporarily prohibit renaming a directory (especially `tests`)
// while enterprise AV/indexers scan it. A staged copy is safer than requiring a
// directory rename: the deployment barrier remains set throughout, and every
// installed tree is checked against the sealed source digest before proceeding.
const RETRYABLE_MOVE=new Set(['EPERM','EACCES','EBUSY','EXDEV','EINVAL']);
function pause(ms){Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0,ms);}
function tryRename(src,dest){
 let last;
 for(let i=0;i<4;i++){
  try{fs.renameSync(src,dest);return true;}
  catch(e){if(!RETRYABLE_MOVE.has(e.code))throw e;last=e;if(i<3)pause(80*(i+1));}
 }
 return false;
}
function removeSoftware(p){
 plainPath(p);
 fs.rmSync(p,{recursive:true,force:false,maxRetries:6,retryDelay:120});
 need(!fs.existsSync(p),'MOVE_SOURCE_REMAINS','Verifizierte Softwarequelle blieb nach der Archivierung erhalten.');
}
function moveSoftwareVerified(src,dst,expected){
 plainPath(src);need(!fs.existsSync(dst),'DEST_EXISTS','Archiv-/Zielpfad ist bereits belegt.');
 need(treeDigest(src)===expected,'SOURCE_CHANGED','Software vor dem Verschieben veraendert.');
 if(tryRename(src,dst)){
  need(treeDigest(dst)===expected,'MOVE_VERIFY','Verschobene Software weicht ab.');return 'RENAME';
 }
 // Do not delete the source before verifying the independent backup.
 copyTree(src,dst);
 need(treeDigest(dst)===expected,'MOVE_COPY_VERIFY','Kopierte Software weicht vom Original ab.');
 removeSoftware(src);
 return 'COPY_VERIFY_REMOVE';
}
function installStagedSoftware(stage,target,expected){
 plainPath(stage);need(!fs.existsSync(target),'DEST_EXISTS','Unerwartete Datei am Installationsziel.');
 need(treeDigest(stage)===expected,'STAGE_CHANGED','Gestagte Software hat sich vor dem Installieren veraendert.');
 // Never rename staged directories into the live path. Windows can deny the
 // rename despite an otherwise fully writable destination. Copy file by file.
 copyTree(stage,target);
 need(treeDigest(target)===expected,'INSTALL_COPY_VERIFY','Installierte Software konnte nicht vollstaendig verifiziert werden.');
 return 'COPY_AND_VERIFY';
}
function saveJournal(j){writeJSON(path.join(j.archive,'migration.json'),j);}
function checkJournal(j,target){need(j?.schema==='MCR_COMPLETE_INSTALL_JOURNAL_V1'&&path.resolve(j.target)===path.resolve(target),'JOURNAL_INVALID','Falsches Installationsjournal.');const parent=path.join(path.dirname(path.resolve(target)),'_MCR_Archiv');need(path.dirname(j.archive)===parent&&/^complete_[0-9TZ_-]+[a-f0-9]{8}$/.test(path.basename(j.archive)),'JOURNAL_PATH','Fremder Archivpfad.');for(const xs of [j.oldItems,j.incoming]){need(Array.isArray(xs)&&xs.length>0,'JOURNAL_INVALID','Journal unvollstaendig.');const seen=new Set();for(const x of xs){need(NAMES.includes(x.name)&&!seen.has(x.name)&&/^[a-f0-9]{64}$/.test(x.hash),'JOURNAL_INVALID','Journalpfad falsch.');seen.add(x.name);}}plainPath(j.archive);}
function restoreLegacyRunEvidence(j){
 const previous=/^0\.8\.1-rc\.(\d+)$/.exec(j.old?.version||'');
 if(!previous||Number(previous[1])>=125)return;
 const root=j.target,from=phase1ResultPath(root),directory=resolveConfig(root).diagnosticDirectory;
 const target=path.join(directory,'last-result.json'),stateFile=path.join(root,'.runtime','beta-control','last-run.json');
 if(fs.existsSync(target)||!fs.existsSync(from)||!fs.existsSync(stateFile))return;
 const state=readJSON(stateFile,65536),result=readJSON(from);
 if(result.schema!=='MCR_LOCAL_RUNNER_DIAGNOSTIC_V2'||result.mode!=='REAL'||!result.runId||result.runId!==state.runId)return;
 let current=root;
 for(const name of path.relative(root,directory).split(path.sep)){
  current=path.join(current,name);
  if(!fs.lstatSync(current,{throwIfNoEntry:false}))fs.mkdirSync(current);
  plainPath(current);
 }
 fs.copyFileSync(from,target,fs.constants.COPYFILE_EXCL);
}
export function restoreSoftware(j,{verifyOld=verifyPrevious,migration=null}={}){checkJournal(j,j.target);const target=j.target,backup=path.join(j.archive,'software'),retired=path.join(j.archive,'retired');if(!fs.existsSync(retired))fs.mkdirSync(retired);plainPath(retired);
 for(const x of j.oldItems){
  const b=path.join(backup,x.name),p=path.join(target,x.name);
  const originalAtTarget=fs.existsSync(p)&&treeDigest(p)===x.hash;
  const verifiedBackup=fs.existsSync(b)&&treeDigest(b)===x.hash;
  need(originalAtTarget||verifiedBackup,'BACKUP_CHANGED','Originalsoftware weder unveraendert am Ziel noch im Archiv nachgewiesen.');
 }
 for(const x of j.incoming){
  const p=path.join(target,x.name),old=j.oldItems.find(o=>o.name===x.name);
  if(fs.existsSync(p)&&(!old||treeDigest(p)!==old.hash)){
   let d=path.join(retired,x.name);if(fs.existsSync(d))d+='_'+stamp();
   moveSoftwareVerified(p,d,treeDigest(p));
  }
 }
 for(const x of j.oldItems){
  const b=path.join(backup,x.name),p=path.join(target,x.name);
  if(!fs.existsSync(p)){
   need(fs.existsSync(b),'BACKUP_MISSING','Originalsoftware fehlt im lokalen Archiv.');
   moveSoftwareVerified(b,p,x.hash);
  }
  need(treeDigest(p)===x.hash,'ROLLBACK_VERIFY','Wiederherstellung abweichend.');
 }
 verifyOld(target);need(JSON.stringify(dataBinding(target))===JSON.stringify(j.before),'DATA_CHANGED','Mapping/Config geaendert. Keine Daten werden zurueckgesetzt.');restoreLegacyRunEvidence(j);j.state='ROLLED_BACK';j.finishedAt=new Date().toISOString();saveJournal(j);if(migration)migration.markFinished(j);else{const marker=path.join(target,BARRIER);if(fs.existsSync(marker))fs.unlinkSync(marker);}return j;
}
export function installSoftware(plan,{guard=windowsIdle,verifyOld=verifyPrevious,fault=null,migration=null}={}){if(migration)migration.check();else guard(plan.target);const fresh=planInstall(plan.source,plan.target,{verifyOld,migration});need(JSON.stringify(fresh)===JSON.stringify(plan),'PLAN_CHANGED','Installationsstand seit Vorschau geaendert.');const recovered=migration?{released:migration.recoveredStaleLock}:releaseOrphanedRealLock(plan.target,{guard:()=>{guard(plan.target);return {schema:'MCR_PROCESS_GUARD_V1',checked:true,blockedCount:0,unknownCount:0};}});const l=migration?null:lock(plan.target,'MIGRATION');let j=null;
 try{if(migration)migration.check();else guard(plan.target);const parent=path.join(path.dirname(plan.target),'_MCR_Archiv');if(!fs.existsSync(parent))fs.mkdirSync(parent);plainPath(parent);const archive=path.join(parent,'complete_'+stamp());fs.mkdirSync(archive);fs.mkdirSync(path.join(archive,'software'));fs.mkdirSync(path.join(archive,'stage'));
 j={...plan,schema:'MCR_COMPLETE_INSTALL_JOURNAL_V1',archive,state:'STAGING',oldMoved:[],newMoved:[],createdAt:new Date().toISOString(),...(migration?{migrationToken:migration.token}:{})};saveJournal(j);
 for(const x of plan.incoming){copyTree(path.join(plan.source,x.name),path.join(archive,'stage',x.name));need(treeDigest(path.join(archive,'stage',x.name))===x.hash,'STAGE_VERIFY','Staging abweichend.');}
 // Data/config remain at their existing path; this marker also stops Beta-4 START.cmd.
 if(migration){assertMigrationPermit(plan.target,plan.source,migration);migration.markMoving(archive);}
 else fs.writeFileSync(path.join(plan.target,BARRIER),'Softwareumstellung offen. START.cmd aus dem NEUEN entpackten Paket -> Rueckweg.\n',{flag:'wx'});
 j.state='MOVING';saveJournal(j);let count=0;
 for(const x of plan.oldItems){
  need(treeDigest(path.join(plan.target,x.name))===x.hash,'SOURCE_CHANGED','Alte Software geaendert.');
  moveSoftwareVerified(path.join(plan.target,x.name),path.join(archive,'software',x.name),x.hash);
  j.oldMoved.push(x.name);saveJournal(j);fault?.('OLD',++count);
 }
 for(const x of plan.incoming){
  installStagedSoftware(path.join(archive,'stage',x.name),path.join(plan.target,x.name),x.hash);
  j.newMoved.push(x.name);saveJournal(j);fault?.('NEW',++count);
 }
 verifyPackage(plan.target);need(JSON.stringify(dataBinding(plan.target))===JSON.stringify(plan.before),'DATA_CHANGED','Bestandsmapping/Config hat sich veraendert.');writeJSON(path.join(controlDir(plan.target),'complete-install.json'),{schema:'MCR_COMPLETE_INSTALL_RECEIPT_V1',version:plan.release.version,manifestSha256:plan.release.manifestSha256,archive,installedAt:new Date().toISOString(),mappingUnchanged:true,profileTouched:false});j.state='COMPLETE';saveJournal(j);if(migration)migration.markFinished(j);else fs.unlinkSync(path.join(plan.target,BARRIER));
 // The install is committed. Keep the original rollback backup. The staged
 // copy of the now verified incoming software has served its purpose.
 let cleanup={diagnosticZips:0,installerZips:0,mappings:0,legacyPointers:0,bytes:0,warnings:[]};
 try{cleanup=cleanupInstallationOutputs(plan.target);}
 catch(error){cleanup.warnings.push('Bereinigung konnte nicht abgeschlossen werden: '+(error.code||'IO_ERROR'));}
 try{removeSoftware(path.join(archive,'stage'));}
 catch(error){cleanup.warnings.push('Zwischenkopie im Migrationsarchiv verblieben: '+(error.code||'IO_ERROR'));}
 return {archive,target:plan.target,state:'COMPLETE',recoveredStaleLock:recovered.released,cleanup};
 }catch(e){if(j){if(e.simulatePowerLoss){throw e;}try{restoreSoftware(j,{verifyOld,migration});e.rollback='SOFTWARE_RESTORED';}catch(r){e.rollback='OPEN';e.rollbackCode=r.code||'IO_ERROR';}}throw e;}
 finally{try{l?.release();}catch{}}
}
export function journals(target){const parent=path.join(path.dirname(path.resolve(target)),'_MCR_Archiv');if(!fs.existsSync(parent))return [];plainPath(parent);const out=[];for(const n of fs.readdirSync(parent).filter(n=>/^complete_[0-9TZ_-]+[a-f0-9]{8}$/.test(n)).sort().reverse()){const file=path.join(parent,n,'migration.json');if(fs.existsSync(file)){const j=readJSON(file);checkJournal(j,target);if(j.state!=='ROLLED_BACK')out.push(j);}}return out;}
