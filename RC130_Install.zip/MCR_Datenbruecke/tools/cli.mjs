import fs from 'node:fs';import path from 'node:path';import os from 'node:os';import {fileURLToPath} from 'node:url';import {spawn} from 'node:child_process';import readline from 'node:readline/promises';
import {sha256,requireThat as need} from '../lib/core.mjs';import {applyEnterApproval} from '../lib/runtime/operator-enter.mjs';import {VERSION,stamp,phase1ResultPath,plainPath,readJSON,writeJSON,controlDir,lock,ledger,runState,assertNoReview,processAlive,assertNoMigrationPriority} from '../lib/control.mjs';import {loadActiveMapping} from '../lib/workbook/active-mapping.mjs';import {resolveConfig} from '../lib/config.mjs';import {verifyPackage,verifyPrevious} from './integrity.mjs';import {planInstall,installSoftware,journals,restoreSoftware} from './deploy.mjs';import {windowsIdle} from './process-guard.mjs';import {certifyPilot,certifyForwardWithoutEmail} from './proof.mjs';
import {beginMigrationPriority,recoverOrphanedMigrationPriority} from '../lib/runtime/migration-priority.mjs';
import {releaseProvenPreActionAbort} from '../lib/runtime/preaction-recovery.mjs';
import {phase2Run} from '../src/phase2-run.mjs';
import {masterCompletion,completionLines} from '../lib/runtime/master-completion.mjs';
import {describeTicketIssue} from '../lib/runtime/ticket-error-catalog.mjs';import {browserLeaseEnvironment} from '../lib/runtime/master-browser-lease.mjs';import {findEdgeExecutable,launchBrowser,connectBrowser,createOwnedStartupTarget,assertOwnedPageTarget} from '../lib/comarch/cdp.mjs';
import {prepareFreshRun,pendingSnapshot,assertPendingUnchanged,assertPendingWithDeferredForwards} from '../lib/runtime/run-reset.mjs';import {interruptedPilotCandidate} from '../lib/runtime/master-pilot-recovery.mjs';import {authorizeChainedContinuation,authorizeForwardPilotContinuation,authorizeMasterBatch} from '../lib/runtime/continuation-policy.mjs';
import {createFlowRecorder,captureFlowConsole} from '../lib/runtime/flow-events.mjs';
import {ensureFlowBridge,openFlowMap} from '../lib/runtime/flow-launcher.mjs';
import {refreshLiveWorkbook,assertLiveWorkbookCurrent,phase1WorkbookBoundaryProof} from '../lib/workbook/live-workbook.mjs';
import {flushWorkbookContacts} from '../lib/workbook/workbook-contacts.mjs';
let flowRecorder=null;
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),defaultTarget=()=>path.join(os.homedir(),'projects/Aktive_Projekte/Ticket_bot/MCR_Datenbruecke');
const log=s=>console.log(s);async function ask(text){const rl=readline.createInterface({input:process.stdin,output:process.stdout});try{return applyEnterApproval(text,await rl.question(text));}finally{rl.close();}}
function outDir(){const d=path.join(root,'Ergebnis');fs.mkdirSync(d,{recursive:true});plainPath(d);return d;}
function cleanEnv(extra={}){const e={...process.env};for(const k of Object.keys(e))if(k.startsWith('MCR_'))delete e[k];delete e.NODE_OPTIONS;delete e.NODE_PATH;return {...e,...extra};}
export async function runChild(file,args=[],options={}){
 // RC30: mirror the complete real runner stream, including the pilot AND its
 // continuation, to a local append-only daily transcript. Console stays fast.
 const {logFile,...spawnOptions}=options;
 return new Promise((resolve,reject)=>{
  if(logFile){plainPath(path.dirname(logFile));if(fs.existsSync(logFile))plainPath(logFile);
   fs.appendFileSync(logFile,'\n=== MCR '+VERSION+' '+new Date().toISOString()+' ===\n',{mode:0o600});}
  const child=spawn(process.execPath,[file,...args],{cwd:root,stdio:logFile?['inherit','pipe','pipe']:'inherit',env:cleanEnv(),windowsHide:false,...spawnOptions});
  if(logFile)for(const [stream,destination] of [[child.stdout,process.stdout],[child.stderr,process.stderr]]){
   stream?.on('data',bytes=>{destination.write(bytes);flowRecorder?.chunk(bytes,stream);try{fs.appendFileSync(logFile,bytes,{mode:0o600});}
    catch{destination.write('\nWARN MCR_LOG_WRITE: Lokale Laufprotokoll-Datei nicht beschreibbar.\n');}});
   stream?.on('end',()=>flowRecorder?.endStream(stream));
  }
  child.once('error',reject);child.once('close',(code,signal)=>resolve({code,signal}));
 });
}
export async function selftest(){
 const pkg=verifyPackage(root);
 const {choosePhase2Candidate}=await import('../src/phase2-run.mjs');
 const {phase2WorkRule}=await import('../lib/phase2/phase2-work-rules.mjs');
 const expected=[['Möchte Kontoauszug','DC'],['Möchte Auszahlungsoption','AO']];
 for(const [request,plan] of expected){
  const row={ticketId:'99900001',descriptionValue:'USC 1/ DC\nStandardantwort versendet\n'+request};
  const selected=choosePhase2Candidate([row],{prepareMissingPdf:true});
  const rule=phase2WorkRule(row);
  need(selected.row===row&&selected.pdfPreparationRequired&&rule.targets.length===1&&rule.targets[0]===plan,
   'SELFTEST_FAILED','Dokumentauswahl fuer '+plan+' fehlgeschlagen.');
 }
 log('PASS SELBSTTEST: '+pkg.files+' Paketdateien und Auswahl fiktiver Dokumentauftraege geprueft.');
 const dir=path.join(root,'tests');
 if(fs.existsSync(dir)){
  const tests=fs.readdirSync(dir).filter(n=>n.endsWith('.test.mjs')).sort().map(n=>path.join(dir,n));
  if(tests.length){
   const result=await runChild('--test',['--test-concurrency=3',...tests]);
   need(result.code===0&&!result.signal,'SELFTEST_FAILED','Entwicklungstests fehlgeschlagen.');
  }
 }
 return true;
}
export async function demo(){
 const file=path.join(root,'tests','development-checks.mjs');
 need(fs.existsSync(file),'DEVELOPMENT_DEMO',
  'Die Browserdemo ist Teil des Entwicklungsbestands. Der lokale Paket- und Funktionstest ist mit --selftest verfuegbar.');
 const {runDevelopmentDemo}=await import('../tests/development-checks.mjs');
 return runDevelopmentDemo({root,runChild,log,outDir,cleanEnv});
}
async function status(target=root){const pkg=verifyPackage(target),state=runState(target);let map=null,error=null;try{const a=loadActiveMapping(target);map={valid:true,fileHash:a.fileHash,schema:a.map.schema,validKeys:a.map.payload.summary.validKeys};}catch(e){error=e.code||'MAPPING_ERROR';}const pending=fs.existsSync(path.join(target,'.runtime/beta-control/ticket-ledger.json'))?ledger(target).pending.length:0;const report={schema:'MCR_COMPLETE_STATUS_V1',package:pkg,mapping:map,mappingError:error,previousRun:state,unreviewedTickets:pending,liveReady:false,note:'Status alone does not authorize a send.'};writeJSON(path.join(outDir(),'STATUS.json'),report);log(JSON.stringify(report,null,2));return report;}
async function setup(){let target=defaultTarget();if(path.resolve(root)===path.resolve(target)){log('Bereits installierte Version. Paket- und Funktionstest: --selftest.');await status();return;}
 const input=await ask('Vorhandene Installation [ENTER = '+target+']: ');if(input)target=path.resolve(input.replace(/^"|"$/g,''));
 recoverOrphanedMigrationPriority(target,{verifyOld:verifyPrevious,log});
 let p=planInstall(root,target);
 if(p.old.legacyResiduals?.length){log('\nPASS BEKANNTE_BETA4_ALTDATEIEN_VERIFIZIERT: '+p.old.legacyResiduals.length);log('Diese Altdateien werden mit der bisherigen Software gesichert, nicht in den neuen Lauf uebernommen:');for(const f of p.old.legacyResiduals)log('  '+f.path);}
 log('\nZiel: '+target+'\nAlt: '+p.old.version+' -> '+VERSION+'\nDie bisherige Software wird fuer den Rueckweg gesichert. Die Bereinigung erfasst alte Diagnosepakete, verifizierte Installations-ZIPs und abgeloeste generierte Mappings. Aktives Mapping, Browserprofil und Ticketjournale bleiben erhalten.\nEinrichtung versendet keine Nachrichten.');
 const migration=beginMigrationPriority(p,{log});
 try{
  // Freeze the data binding only AFTER the owned old execution has stopped.
  p=planInstall(root,target,{migration});
  log('SCHNELLINSTALLATION: Paket-Hash/Altversion verifiziert; Prozesssperre, Staging, Rueckweg und Datenbindung bleiben aktiv.');
  log('SELBSTTEST: Paket und Dokumentauswahl bei Bedarf mit --selftest pruefen.');
  migration.check();const r=installSoftware(p,{migration});
  log('PASS INSTALLATION_COMPLETE\nSicherung: '+r.archive);
  const c=r.cleanup;
  log('INSTALLATION_AUFGERAEUMT: '+c.diagnosticZips+' Diagnose-ZIPs, '+c.installerZips+' alte Installationspakete, '+c.mappings+' Mappingdateien, '+c.legacyPointers+' alte Mappingzeiger; '+c.bytes+' Bytes freigegeben.');
  for(const warning of c.warnings)log('INSTALLATION_AUFRAEUMHINWEIS: '+warning);
 }finally{migration.release();}
 log('\nAb jetzt nur '+path.join(target,'START.cmd'));log('Das neue Hauptmenue der installierten Version wird geoeffnet.');
 await runChild(path.join(target,'tools/cli.mjs'),['--menu'],{cwd:target});return 'EXIT';
}
/** RC100: preserve a concrete error from the already run-bound diagnostic.
 * This only creates an error; it grants no retry, skip or pilot permission. */
export function runnerDiagnosticError(d){
 if(d?.lastError===null||d?.lastError===undefined)return null;
 const code=typeof d.lastError==='string'&&/^[A-Z][A-Z0-9_]{0,79}$/.test(d.lastError)?d.lastError:'RUNNER_ERROR';
 const issue=describeTicketIssue({reason:code,phase:'P1'});
 const phase=typeof d.phase==='string'&&/^[A-Z][A-Z0-9_]{0,79}$/.test(d.phase)?d.phase:null;
 const error=Object.assign(new Error(issue.cause+' '+issue.nextAction),{code,runnerPhase:phase});
 if(code==='INTL_SCOPE_NOT_AVAILABLE'&&Array.isArray(d.navigation?.missingScopes)){
  const missing=['IN_BEARBEITUNG','WARTESCHLANGE_INTL01'].filter(s=>d.navigation.missingScopes.includes(s));
  if(missing.length){
   error.missingScopes=missing;
   error.message='Listenpruefung offen fuer '+missing.join(', ')+'. '+issue.nextAction;
  }
 }
 return error;
}
async function real(pilot,{automaticContinuation=false,limitAfterPilot=5,pilotRunId=null,initialDeliveryMode='MANUAL',masterLimit=null,forwardChainRunId=null,masterId=null,sharedBrowser=null,masterBoundaryApproved=false}={}){need(process.platform==='win32','WINDOWS_REQUIRED','COMARCH-Echtlauf nur auf Windows.');const pkg=verifyPackage(root);need(fs.existsSync(path.join(root,'private_data')),'LIVE_FROM_DOWNLOAD_BLOCKED','Dieses Downloadpaket enthaelt keine produktiven Bestandsdaten. Echter Ticketlauf ausschliesslich aus der installierten MCR_Datenbruecke starten.');need(!fs.existsSync(path.join(root,'BETA_UMSTELLUNG_LAEUFT.txt')),'MIGRATION_INCOMPLETE','Softwareumstellung nicht abgeschlossen.');const active=loadActiveMapping(root);let startupAt=Date.now();log('P1_STARTVORBEREITUNG: Prozess- und Journalpruefung.');const fresh=prepareFreshRun(root,{guard:windowsIdle,afterInitialIdle:()=>{
 const recovery=releaseProvenPreActionAbort(root);
 if(recovery.released)log('PASS AUTO_REVIEW_PRE_ACTION: Kein vom Bot begonnener Versand/keine Weiterleitung. Vorheriger Abbruch automatisch dokumentiert ('+recovery.phase+').');
 }});if(fresh.oldRunClosed||fresh.lockReleased)log('PASS AUTO_CLOSE_OLD_RUN: Vergangener Bot-Lauf archiviert; keine alten Prozesse aktiv.');if(fresh.pending.length)log('PASS UNRESOLVED_TICKETS_EXCLUDED: '+fresh.pending.map(x=>x.ticketId).join(', ')+'. Diese Tickets erhalten KEINE automatische neue E-Mail.');assertNoReview(root);const journal=ledger(root);const previousPending=pendingSnapshot(root);log('ECHTLAUF_DIREKT: Keine fiktiven Demos. Browserproben gehoeren zum Entwicklungsbestand.');
 // A verified forwarding is sufficient for ONE additional single-ticket pilot,
 // but never for a regular/bulk email run. Master batches require a real SEND proof.
 let forwardReceipt=null,masterReport=null;
 if(forwardChainRunId!==null){
  need(pilot,'FORWARD_CHAIN_NOT_PILOT','Interne Weiterleitungsfortsetzung nur als Einzelpilot.');
  const f=path.join(root,'.runtime/beta-control/complete-forward-pilot-pass.json');
  need(fs.existsSync(f),'FORWARD_CHAIN_MISSING','Vorige Weiterleitung nicht zertifiziert.');forwardReceipt=readJSON(f,65536);
  authorizeForwardPilotContinuation({runId:forwardChainRunId,receipt:forwardReceipt,
   manifestSha:pkg.manifestSha256,mappingSha:active.fileHash,ticketLimit:1});
 }
 if(!pilot){const f=path.join(root,'.runtime/beta-control/complete-pilot-pass.json');need(fs.existsSync(f),'PILOT_REQUIRED','Phase-1-Batch bleibt gesperrt: Erst nach einem echt abgeschlossenen Piloten mit nachgewiesenem Versand UND Speicherung wird der reguläre Lauf freigegeben (Menue 3).');const p=readJSON(f);need(p.schema==='MCR_COMPLETE_PILOT_PASS_V1'&&p.manifestSha256===pkg.manifestSha256&&p.mappingSha256===active.fileHash,'PILOT_REQUIRED','Die vorhandene Pilotfreigabe gehoert zu einer anderen Programm- oder Mapping-Version. Menue 3 erneut mit nachgewiesenem Versand UND Speicherung abschliessen.');}
 let limit=1;if(!pilot){if(automaticContinuation){
  limit=limitAfterPilot;
  const receipt=readJSON(path.join(root,'.runtime/beta-control/complete-pilot-pass.json'),65536);
  authorizeChainedContinuation({runId:pilotRunId,receipt,manifestSha:pkg.manifestSha256,mappingSha:active.fileHash,ticketLimit:limit});
  log('AUTO_FORTSETZUNG: Zertifizierter E-Mail-Pilot beendet; maximal '+limit+' weitere Tickets unter derselben Menue-3-Freigabe.');
 }else if(masterLimit!==null){
  limit=masterLimit;need(Number.isInteger(limit)&&limit>=1&&limit<=100,'TICKET_LIMIT','Masterlimit ungueltig.');
  if(masterId){const mf=path.join(root,'.runtime/master','MCR_MASTER_RUN_'+masterId+'.json');
   need(fs.existsSync(mf),'MASTER_BATCH_NOT_AUTHORIZED','Masterreport fehlt.');masterReport=readJSON(mf,65536);
   authorizeMasterBatch({masterId,masterReport,receipt:readJSON(path.join(root,'.runtime/beta-control/complete-pilot-pass.json'),65536),
    manifestSha:pkg.manifestSha256,mappingSha:active.fileHash,ticketLimit:limit});}
 }else{const s=await ask('Maximal wie viele Tickets (1 bis 100; ENTER=100): ');limit=s?Number(s):100;need(Number.isInteger(limit)&&limit>=1&&limit<=100,'TICKET_LIMIT','Ungueltiges Limit.');}}
 log('P1_STARTVORBEREITUNG_ZWEITE_PROZESSPRUEFUNG: '+(Date.now()-startupAt)+' ms bisher.');windowsIdle(root);log('PASS P1_STARTVORBEREITUNG: '+(Date.now()-startupAt)+' ms.');const l=lock(root,'REAL_RUN'),dir=controlDir(root),runId=stamp(),sf=path.join(dir,'last-run.json'),state={schema:'MCR_BETA_RUN_V1',version:VERSION,operation:'REAL_RUN',state:'RUNNING',pid:process.pid,startedAt:new Date().toISOString(),runId,ticketDeliveryVerified:false,pilot};writeJSON(sf,state);
 const interrupt=()=>{state.state='INTERRUPTED_REVIEW_REQUIRED';try{writeJSON(sf,state);}catch{}};process.on('SIGINT',interrupt);process.on('SIGTERM',interrupt);
 try{
 const cfgForLog=resolveConfig(root);
 const reports=path.join(cfgForLog.runtimeDirectory,'reports');fs.mkdirSync(reports,{recursive:true});plainPath(reports);
 const day=new Date().toLocaleDateString('sv-SE');
 const transcript=path.join(reports,'MCR_ECHTLAUF_'+day+'.log');
 log('VOLLSTAENDIGES_LAUFPROTOKOLL: '+transcript+' (beide Pilot-/Folgelauf-Prozesse werden angehaengt)');
 const r=await runChild(path.join(root,'src/local-bot-full-run.mjs'),[pilot?'--pilot':'--full-run','--inspect-browser',...(automaticContinuation?['--chained-after-pilot']:[]),...(forwardChainRunId?['--chained-after-forward']:[]),...(masterId?['--master-phase1-batch']:[]),...(masterBoundaryApproved?['--master-workbook-rebind']:[])],{logFile:transcript,env:cleanEnv({MCR_SESSION_TOKEN:l.token,MCR_RUN_ID:runId,MCR_MAX_TICKETS:String(limit),...(sharedBrowser?browserLeaseEnvironment(sharedBrowser):{}),...(automaticContinuation?{MCR_CHAINED_PILOT_RUN_ID:pilotRunId,MCR_DELIVERY_MODE:initialDeliveryMode}:{}),...(forwardChainRunId?{MCR_CHAINED_FORWARD_RUN_ID:forwardChainRunId}:{}),...(masterId?{MCR_MASTER_RUN_ID:masterId}:{})})});const f=phase1ResultPath(root);need(fs.existsSync(f),'LIVE_DIAGNOSTIC_MISSING','Frischer Laufbericht fehlt.');const d=readJSON(f);need(d.runId===runId&&d.mode==='REAL','LIVE_DIAGNOSTIC_STALE','Bericht gehoert nicht zum aktuellen Lauf.');const runnerError=runnerDiagnosticError(d);if(runnerError)throw runnerError;need(r.code===0&&!r.signal&&!d.lastError&&d.loop?.completed&&state.state==='RUNNING','LIVE_NOT_VERIFIED','Echtlauf nicht sauber bestaetigt. Verlauf pruefen; kein blinder Neustart.');assertPendingWithDeferredForwards(root,previousPending,runId,d.loop.deferredForwards||0);if(d.loop.deferredForwards)log('PASS P1_FORWARD_DEFERRED_JOURNALS: '+d.loop.deferredForwards+' gesperrte Weiterleitung(en), keine Wiederholung.');state.state='RUNNER_EXIT_0';state.finishedAt=new Date().toISOString();state.processed=d.loop.processed;writeJSON(sf,state);
 if(d.loop.finishReason==='WORKBOOK_REBIND_AT_QUEUE_BOUNDARY'){
  need(phase1WorkbookBoundaryProof(d)&&d.workbookBoundary.mappingSha256===active.fileHash,
   'WORKBOOK_BOUNDARY_UNVERIFIED','Bestandswechsel ist nicht als abgeschlossene Grenze vor einem neuen Ticket nachgewiesen.');
  log('PASS P1_WORKBOOK_BOUNDARY_VERIFIED: Kein naechstes Ticket begonnen; Versandjournal unveraendert.');
  return {verified:true,workbookRefreshRequired:true,workbookBoundary:d.workbookBoundary,
   runId,processed:d.loop.processed,limit,finishReason:d.loop.finishReason,deferredForwards:d.loop?.deferredForwards||0,skippedIdentity:d.loop?.skippedIdentity||0};
 }
 if(pilot&&d.loop.processed===1&&d.loop.forwarded===1){
  certifyForwardWithoutEmail(d);
  writeJSON(path.join(dir,'complete-forward-pilot-pass.json'),{schema:'MCR_COMPLETE_FORWARD_PILOT_PASS_V1',
   manifestSha256:pkg.manifestSha256,mappingSha256:active.fileHash,runId,ticketLimit:1,
   noEmail:true,forwardVerified:true,passedAt:new Date().toISOString()});
  log('PASS PILOT_ROUTED_WITHOUT_EMAIL - Einzelticket-Weiterleitung verifiziert. Nur naechster Einzelpilot erlaubt, KEINE Batch-E-Mail-Freigabe.');
  return {pilotVerified:false,forwardVerified:true,runId,processed:1,deferredForwards:d.loop?.deferredForwards||0,skippedIdentity:d.loop?.skippedIdentity||0,deliveryMode:d.deliveryMode==='AUTO'?'AUTO':'MANUAL'};
 }else if(pilot&&d.loop.processed===1){certifyPilot(d);writeJSON(path.join(dir,'complete-pilot-pass.json'),{schema:'MCR_COMPLETE_PILOT_PASS_V1',manifestSha256:pkg.manifestSha256,mappingSha256:active.fileHash,runId,passedAt:new Date().toISOString()});log('PASS LIVE_PILOT_SEND_AND_SAVE_VERIFIED | PHASE1_BATCH_FREIGEGEBEN');return {pilotVerified:true,runId,processed:d.loop.processed,deferredForwards:d.loop?.deferredForwards||0,skippedIdentity:d.loop?.skippedIdentity||0,deliveryMode:d.deliveryMode==='AUTO'?'AUTO':'MANUAL'};}else if(pilot){
  // RC68: A fully read, exhausted Phase-1 queue is NOT a failed send pilot.
  // Keep the pilot certificate absent (no send permission), but explicitly
  // authorize the independent Phase-2 read/process path in the master.
  const emptyProof=phase1QueueExhaustedProof(d);
  log(emptyProof?'PASS PHASE1_QUEUE_EXHAUSTED_NO_SEND: Beide erlaubten Intel-Listen geprueft; kein neuer Versandpilot erforderlich fuer Phase 2.':'Kein passendes Ticket vorhanden. Noch keine Pilotfreigabe.');
  return {pilotVerified:false,noEligible:emptyProof,reason:emptyProof?'NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS':'UNVERIFIED_NO_PILOT',runId,processed:0,deferredForwards:d.loop?.deferredForwards||0,skippedIdentity:d.loop?.skippedIdentity||0,skippedWithoutEmail:d.loop?.skippedWithoutEmail||0};
 }else{log('PASS LIVE_RUN_VERIFIED');return {verified:true,runId,processed:d.loop.processed,limit,finishReason:d.loop.finishReason,deferredForwards:d.loop?.deferredForwards||0,skippedIdentity:d.loop?.skippedIdentity||0};}
 }catch(e){if(state.state!=='INTERRUPTED_REVIEW_REQUIRED')state.state='STOP_REVIEW_REQUIRED';state.errorCode=/^[A-Z0-9_]+$/.test(e.code||'')?e.code:'RUN_ERROR';state.finishedAt=new Date().toISOString();writeJSON(sf,state);throw e;}
 finally{process.removeListener('SIGINT',interrupt);process.removeListener('SIGTERM',interrupt);try{l.release();}catch{}}
}
/** RC68: only a real, completed and write-free Intel-list scan can prove
 * that a fresh Phase-1 pilot is unnecessary BEFORE entering independent Phase 2.
 * A failed pilot, any click, an incomplete scan or a missing diagnostic is NOT
 * equivalent to an empty queue and must never grant Phase-2 permission. */
export function phase1QueueExhaustedProof(d){
 return d?.mode==='REAL'&&d?.lastError===null&&d.loop?.completed===true&&
  d.loop?.finishReason==='NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS'&&
  d.loop?.processed===0&&d.loop?.forwarded===0&&
  Array.isArray(d.loop?.processedTickets)&&d.loop.processedTickets.length===0&&
  d.send?.clicked===false&&d.send?.verified!==true;
}
/** RC60: sequential master coordinator, reuses unchanged guarded runners. */
export async function masterRun({runPhase1=real,runPhase2=phase2Run,recoverPilot=completionOnly,confirm=ask,write=writeJSON,output=log,rootDir=root,phase1Only=false,refreshAtBoundary=refreshLiveWorkbook}={}){
 need(process.platform==='win32'||runPhase1!==real,'WINDOWS_REQUIRED','Master Run nur auf Windows.');
 verifyPackage(rootDir);
 need(fs.existsSync(path.join(rootDir,'private_data'))||runPhase1!==real,'LIVE_FROM_DOWNLOAD_BLOCKED','Master Run ausschliesslich aus installierter Software starten.');
 const approval=await confirm(phase1Only?'PHASE 1: Alle geeigneten Tickets bis zur nachgewiesenen Leerpruefung (max. 1000 Aktionen je Lauf). ECHTE E-MAILS und interne Weiterleitungen. ENTER = bestaetigen. PHASE1_START / ABBRUCH: ':'MASTER RUN: ECHTE Standardantworten in Phase 1, danach Phase 2 OHNE E-MAIL. Sicher starten? ENTER = bestaetigen. MASTER_START / ABBRUCH: ');
 need(approval===(phase1Only?'PHASE1_START':'MASTER_START'),'MASTER_ABORT','Lauf nicht gestartet.');
 if(runPhase1===real)await mappingMaintenance({output});
 const folder=path.join(rootDir,'.runtime','master');fs.mkdirSync(folder,{recursive:true});plainPath(folder);
 const id=stamp(),file=path.join(folder,'MCR_MASTER_RUN_'+id+'.json');
 const pkgAtStart=verifyPackage(rootDir),mapAtStart=runPhase1===real?loadActiveMapping(rootDir).fileHash:'TEST_ONLY';
 const result={schema:'MCR_MASTER_RUN_V1',version:VERSION,id,startedAt:new Date().toISOString(),explicitMasterStart:!phase1Only,explicitPhase1Start:phase1Only,manifestSha256:pkgAtStart.manifestSha256,mappingSha256:mapAtStart,state:'STARTED',phase1:{status:'PENDING',batches:[],pilotAttempts:[],forwardedBeforeSendPilot:0,manualIdentityReviewObserved:0,manualForwardReviewObserved:0},phase2:{status:phase1Only?'NOT_REQUESTED':'PENDING'},scope:phase1Only?'PHASE1_MAX_100_PER_BATCH':'PHASE1_MAX_100_PER_BATCH_PHASE2_VISIBLE_MY_TASKS',noBlindRetry:true};
 const checkpoint=()=>write(file,result);
 checkpoint();output('MASTER_REPORT: '+file);
 let ownedBrowser=null;
 async function launchOwnedBrowser(){
  const cfg=resolveConfig(rootDir),exe=findEdgeExecutable(cfg.edgePath);
  need(exe,'MASTER_BROWSER_NOT_FOUND','Edge fehlt; Master nicht gestartet.');
  output('MASTER_BROWSER_START: Eigenen Edge-Prozess starten und Bot-Fenster eindeutig erstellen.');
  const started=await launchBrowser({executable:exe,userDataDir:cfg.profileDirectory,extraArgs:['--no-startup-window']});
  let probe;
  try{
   probe=await connectBrowser(started.port);
   const targetId=await createOwnedStartupTarget(probe.cdp);
   const lease={port:started.port,masterId:id,ownerPid:process.pid,targetId};
   browserLeaseEnvironment(lease);
   ownedBrowser={...started,lease};
   result.browser={port:started.port,targetId,ownership:'EXPLICIT_CDP_CREATE_TARGET',reuse:'ONE_OWNED_TAB_FRESH_NAVIGATION'};checkpoint();
   output('PASS BROWSER_OWNED_TAB_CREATED: Eigenes Bot-Fenster erstellt, aktiviert und eindeutig gebunden.');
  }catch(e){try{started.child.kill();}catch{}throw e;}
  finally{try{probe?.cdp.close();}catch{}}
 }
 async function browserReady(){
  if(!ownedBrowser)return;
  try{const probe=await connectBrowser(ownedBrowser.port,{onRetry:r=>output('BROWSER_CONNECT_RETRY: '+r.attempt+'/'+r.attempts+' | nur Verbindung')});try{await assertOwnedPageTarget(probe.cdp,ownedBrowser.lease.targetId);}finally{probe.cdp.close();}return;}
  catch(e){
   if(e.code==='BROWSER_OWNED_TARGET_MISSING')throw e;
   // Coordinator calls only BEFORE a new runner / phase. No replay of a ticket.
   const child=ownedBrowser.child;
   need(child.exitCode!==null||child.signalCode!==null,'BROWSER_LOOPBACK_UNAVAILABLE','Eigener Edge-Prozess noch aktiv, Debugverbindung aber unklar. Keine neue Instanz und kein Ticket-Neuversand.');
   windowsIdle(rootDir);
   output('MASTER_BROWSER_RECOVERY_BEGIN: Eigener Browser ist beendet; neue Verbindung vor naechstem Teilprozess. Bereits bearbeitete Tickets bleiben abgeschlossen.');
   await launchOwnedBrowser();
   output('PASS MASTER_BROWSER_RECOVERED: Nur Browser vor neuem Teilprozess wiederhergestellt; keine Aktion wiederholt.');
  }
 }
 try{
  result.state='PHASE1';result.phase1.status='RUNNING';checkpoint();
  // RC61: Stop at a previous interrupted pilot and offer a SINGLE, named
  // completion-only path. This never resends mail, never clears unrelated
  // SEND_INTENT entries, and never creates a new pilot receipt from an old run.
  const previousFile=path.join(rootDir,'.runtime/beta-control/last-run.json');
  const interrupted=interruptedPilotCandidate(fs.existsSync(previousFile)?readJSON(previousFile,65536):null,ledger(rootDir).pending);
  if(interrupted){
   output('MASTER_VORHERIGER_PILOT_OFFEN: Ticket '+interrupted.ticketId+' | '+interrupted.state+'. Keine neue E-Mail an dieses Ticket.');
   const decision=await confirm('Dieses Ticket zuerst OHNE NEUVERSAND pruefen und nur Status/Ticket speichern? PRUEFEN '+interrupted.ticketId+' / UEBERSPRINGEN / ABBRUCH: ');
   need([`PRUEFEN ${interrupted.ticketId}`,'UEBERSPRINGEN'].includes(decision),'MASTER_RECOVERY_NOT_APPROVED','Unklarer Pilot bleibt gesperrt. Kein Master-Versand gestartet.');
   result.phase1.interruptedPilot={ticketId:interrupted.ticketId,originalState:interrupted.state,status:decision==='UEBERSPRINGEN'?'UNRESOLVED_EXCLUDED':'REVIEW_IN_PROGRESS'};checkpoint();
   if(decision!== 'UEBERSPRINGEN'){
    output('MASTER_ABSCHLUSS_OHNE_NEUVERSAND: Nur Ticket '+interrupted.ticketId+'. Original-Ausgang im COMARCH-Verlauf muss verifiziert sein.');
    const otherPending=pendingSnapshot(rootDir).filter(t=>t.ticketId!==interrupted.ticketId);
    await recoverPilot(rootDir,interrupted.ticketId);
    assertPendingUnchanged(rootDir,otherPending);
    need(ledger(rootDir).completedIds().includes(interrupted.ticketId),'MASTER_RECOVERY_NOT_COMPLETED','Altes Ticket nicht als versendet UND gespeichert nachgewiesen. Kein neuer Versand.');
    result.phase1.interruptedPilot.status='SENT_AND_SAVED_VERIFIED_NO_NEW_EMAIL';checkpoint();
    output('PASS MASTER_ABSCHLUSS_OHNE_NEUVERSAND: '+interrupted.ticketId+' | Status und Speicherung nachgewiesen.');
   }else output('MASTER_PILOT_GESPERRT: '+interrupted.ticketId+' bleibt ungeklärt und wird bei allen neuen Läufen übersprungen.');
  }
  // If an older send requires recovery, complete it before starting the shared
  // browser. Two Edge owners must never use the same bot profile at once.
  // RC99: the coordinator OWNS one Edge process and explicitly creates its tab.
  // Every pilot/batch and Phase 2 uses a fresh CDP session/navigation in that tab.
  // Injected QA runners remain browser-free and deterministic.
  if(runPhase1===real && (phase1Only||runPhase2===phase2Run)){
   const browserStartProof=windowsIdle(rootDir);
   if(browserStartProof.snapshotProvider==='WMI')output('PASS PROCESS_CHECK_WMI_FALLBACK: Windows-Prozesse ueber zweite Abfrage sicher verifiziert; Edge-Start freigegeben.');
   await launchOwnedBrowser();
   output('PASS MASTER_BROWSER_EINMAL_GESTARTET: Ein Edge-Prozess und ein Bot-Tab fuer Phase 1 und Phase 2; neue Ansicht im selben Tab je Teillauf.');
  }
  let workbookRebinds=0,pilotCount=0,batchCount=0;
  async function rebindAtBoundary(boundaryRun){
   const b=boundaryRun.workbookBoundary;
   need(boundaryRun.verified===true&&boundaryRun.finishReason==='WORKBOOK_REBIND_AT_QUEUE_BOUNDARY'&&
    b?.schema==='MCR_WORKBOOK_QUEUE_BOUNDARY_V1'&&b.status==='REFRESH_REQUIRED'&&
    b.reason==='WORKBOOK_DATA_CHANGED'&&b.nextTicketOpened===false&&b.mappingSha256===result.mappingSha256,
    'WORKBOOK_BOUNDARY_UNVERIFIED','Bestandswechsel ist nicht an die aktuelle Ticketgrenze gebunden.');
   need(workbookRebinds<3,'WORKBOOK_CHANGING_REPEATEDLY','Bestand wurde an drei Ticketgrenzen neu eingelesen und aendert sich weiter. Aktuelle Excel-Bearbeitung abschliessen; keine Ticketaktion wiederholen.');
   const before=pendingSnapshot(rootDir),old=result.mappingSha256;
   output('MASTER_BESTAND_NEU_BINDEN: '+(workbookRebinds+1)+'/3 | zwischen Tickets; bereits bestaetigte Abschluesse bleiben gesperrt.');
   const current=await refreshAtBoundary(rootDir,{log:output});
   need(current&&/^[a-f0-9]{64}$/.test(current.fileHash??''),'WORKBOOK_BOUNDARY_MAPPING','Neuer Bestandsnachweis fehlt.');
   assertPendingUnchanged(rootDir,before);
   workbookRebinds++;
   result.mappingSha256=current.fileHash;
   (result.phase1.workbookRebindings??=[]).push({at:new Date().toISOString(),afterRun:boundaryRun.runId,
    previousMappingSha256:old,mappingSha256:current.fileHash,reason:b.reason});
   checkpoint();
   output('PASS MASTER_BESTAND_NEU_GEBUNDEN: Aktuelle Daten uebernommen. Naechster Einzelpilot oder direkte Phase 2 bei leerer Phase-1-Liste.');
  }
  // An exact, still-valid RC61 pilot receipt may be reused. Otherwise the
  // existing guarded pilot is mandatory: no fabricated shipping approval.
  phase1Cycles: for(;;){
  if(batchCount>=10){result.phase1.limitReached=true;result.phase1.status='LIMIT_REACHED';break;}
  const pkg=verifyPackage(rootDir),mapping=runPhase1===real?loadActiveMapping(rootDir):{fileHash:"TEST_ONLY"};
  const cert=path.join(rootDir,'.runtime/beta-control/complete-pilot-pass.json');
  const proof=fs.existsSync(cert)?readJSON(cert,65536):null;
  let ready=proof?.schema==='MCR_COMPLETE_PILOT_PASS_V1'&&proof.manifestSha256===pkg.manifestSha256&&proof.mappingSha256===mapping.fileHash;
  if(!ready){
   output('MASTER_PHASE1_PILOT_KETTE: Weiterleitung ohne E-Mail fuehrt zum naechsten Einzelpilot, nicht zu einer Batch-Versandfreigabe.');
   let predecessor=null,finishedNoEligible=false;
   for(let attempt=0;attempt<1000&&pilotCount<1000;attempt++,pilotCount++){
    await browserReady();
    const p=await runPhase1(true,{...(workbookRebinds?{masterBoundaryApproved:true}:{}),...(predecessor?{forwardChainRunId:predecessor.runId}:{}),...(ownedBrowser?{sharedBrowser:ownedBrowser.lease}:{})});
    if(p?.workbookRefreshRequired===true){
     result.phase1.pilotAttempts.push({runId:p.runId,processed:p.processed||0,outcome:'WORKBOOK_BOUNDARY',skippedIdentity:p.skippedIdentity||0});
     result.phase1.manualIdentityReviewObserved+=(p.skippedIdentity||0);result.phase1.manualForwardReviewObserved+=(p.deferredForwards||0);
     await rebindAtBoundary(p);continue phase1Cycles;
    }
    result.phase1.pilot=p;
    result.phase1.pilotAttempts.push({runId:p?.runId||null,processed:p?.processed||0,
     outcome:p?.pilotVerified?'SEND_SAVED':p?.forwardVerified?'FORWARD_NO_EMAIL':p?.noEligible?'NO_NEW_ELIGIBLE':'UNVERIFIED',
     skippedIdentity:p?.skippedIdentity||0});
    result.phase1.manualIdentityReviewObserved+=(p?.skippedIdentity||0);result.phase1.manualForwardReviewObserved+=(p?.deferredForwards||0);checkpoint();
    if(p?.pilotVerified===true&&p?.processed===1){ready=true;break;}
    if(p?.forwardVerified===true&&p?.pilotVerified!==true&&p?.processed===1&&
      typeof p.runId==='string'&&p.runId.length>=12&&p.runId.length<=160){
     predecessor=p;result.phase1.forwardedBeforeSendPilot++;checkpoint();
     output('MASTER_PHASE1_FORWARD_OK: '+result.phase1.forwardedBeforeSendPilot+
      ' interne Weiterleitung(en) verifiziert. Naechsten Einzelpilot automatisch suchen, KEINE E-Mail-Batch-Freigabe.');
     continue;
    }
    if(p?.noEligible===true&&p?.processed===0&&p?.reason==='NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS'){
     result.phase1.status=(p.skippedIdentity||0)>0?'NO_NEW_ELIGIBLE_MANUAL_IDENTITY_REVIEW':'NO_ELIGIBLE_TICKETS';
     result.phase1.noSendPilot=true;result.phase1.skippedIdentity=p.skippedIdentity||0;
     finishedNoEligible=true;checkpoint();
     output('MASTER_PHASE1_QUEUE_ABGESUCHT: Kein weiterer geeigneter Fall in den beiden geprueften Listen;'+
      (p.skippedIdentity?' Identitaetsfaelle bleiben MANUELL OFFEN.':'')+(phase1Only?' Phase-1-Lauf endet nach Listenpruefung.':' Phase 2 startet getrennt OHNE E-Mail.'));
     break;
    }
    result.phase1.status='NO_SEND_PILOT';result.state='PARTIAL_PHASE1_NO_PILOT';result.finishedAt=new Date().toISOString();checkpoint();
    output('MASTER_PHASE1_STOP: Weder verifizierter Versand noch verifizierte Weiterleitung noch vollstaendige Leerpruefung. Keine Phase-2-Fortsetzung.');return result;
   }
   if(!ready&&!finishedNoEligible){result.phase1.status='ROUTE_LIMIT_REACHED';result.state='PARTIAL_PHASE1_ROUTE_LIMIT';result.finishedAt=new Date().toISOString();checkpoint();
    output('MASTER_PHASE1_ROUTE_LIMIT: 1000 Einzelpiloten erreicht. Kein blinder weiterer Versand/Weiterleitung.');return result;}
  }
  if(ready){
   // Stop if a batch consumes fewer than its cap. The cap keeps pagination
   // bounded and enforces new session/journal checks for every batch.
   for(let n=batchCount;n<10;n++){
    batchCount++;
    const cap=100;output('MASTER_PHASE1_BATCH '+(n+1)+' (maximal '+cap+' Tickets).');
    await browserReady();
    const r=await runPhase1(false,{masterLimit:cap,masterId:id,...(ownedBrowser?{sharedBrowser:ownedBrowser.lease}:{})});
    if(r?.workbookRefreshRequired===true){
     result.phase1.batches.push({runId:r.runId,processed:r.processed||0,limit:cap,skippedIdentity:r.skippedIdentity||0,outcome:'WORKBOOK_BOUNDARY'});
     result.phase1.manualIdentityReviewObserved+=(r.skippedIdentity||0);result.phase1.manualForwardReviewObserved+=(r.deferredForwards||0);
     await rebindAtBoundary(r);continue phase1Cycles;
    }
    need(r?.verified===true&&Number.isInteger(r.processed)&&r.processed>=0&&r.processed<=cap,'MASTER_PHASE1_UNVERIFIED','Phase 1 nicht unabhaengig bestaetigt.');
    result.phase1.batches.push({runId:r.runId,processed:r.processed,limit:cap,skippedIdentity:r.skippedIdentity||0});
    result.phase1.manualIdentityReviewObserved+=(r.skippedIdentity||0);result.phase1.manualForwardReviewObserved+=(r.deferredForwards||0);checkpoint();
    if(r.processed<cap){need(r.finishReason==='NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS'||runPhase1!==real&&r.finishReason===undefined,'MASTER_PHASE1_NOT_EXHAUSTED','Batch ohne Leerpruefung vorzeitig beendet; kein naechster Schritt.');break;}
    if(n===9)result.phase1.limitReached=true;
   }
   result.phase1.status=result.phase1.limitReached?'LIMIT_REACHED':'VERIFIED';
  }
  break;
  }
  // A hard cap is NOT evidence of an exhausted ticket list.
  if(result.phase1.limitReached){result.state='PARTIAL_PHASE1_LIMIT';checkpoint();output('MASTER_PARTIAL: Phase-1-Limit erreicht; Phase 2 noch nicht begonnen.');return result;}
  if(phase1Only){
   result.phase2.status='NOT_REQUESTED';
   result.state=result.phase1.manualIdentityReviewObserved>0?'PARTIAL_PHASE1_MANUAL_IDENTITY_REVIEW':'PHASE1_COMPLETE_VISIBLE_SCOPE';
   result.finishedAt=new Date().toISOString();checkpoint();
   output('PHASE1_LAUF_ENDE: '+result.phase1.status+' | bearbeitete Tickets gemaess Pilot-/Batchberichten. Keine Phase 2 gestartet.');
   return result;
  }
  output('MASTER_PHASE1_FERTIG: Listenpruefung abgeschlossen; Phase 2 wird jetzt automatisch vorbereitet.');
  if(runPhase1===real){
   const current=await refreshAtBoundary(rootDir,{log:output});
   result.mappingSha256=current.fileHash;checkpoint();
  }
  await browserReady();
  result.state='PHASE2';result.phase2.status='RUNNING';checkpoint();
  output('MASTER_PHASE2: Alle sichtbaren geeigneten Vorgaenge. MASTER_START deckt die allgemeine Startfreigabe ab; erforderliche Fachpruefungen bleiben bestehen. KEIN E-Mail-Versand.');
  const l=lock(rootDir,'PHASE2_COMARCH_PILOT');
  try{const p=await runPhase2({root:rootDir,masterApproved:true,...(ownedBrowser?{session:{...ownedBrowser.lease}}:{})});need(p?.status==='COMPLETED_VISIBLE_SCOPE','MASTER_PHASE2_UNVERIFIED','Phase-2-Lauf nicht erfolgreich abgeschlossen.');result.phase2={status:'VERIFIED_VISIBLE_SCOPE',processed:p.processed,scope:p.scope,skipped:p.skipped,runId:p.runId,errorSummary:p.errorSummary,errorFiles:p.errorFiles};checkpoint();}
  finally{l.release();}
  // Two NORMAL operator-facing endings. Preserve older machine states for
  // existing checkpoints and audits. Never use either label after an error.
  result.completion=masterCompletion(result);
  if(result.phase2.skipped?.length)
   result.state=result.phase2.processed===0?'PARTIAL_PHASE2_NO_ELIGIBLE':'PARTIAL_PHASE2_OPEN_CASES';
  else if(result.phase1.manualIdentityReviewObserved>0)
   result.state='PARTIAL_PHASE1_MANUAL_IDENTITY_REVIEW';
  else result.state='COMPLETE_VISIBLE_SCOPE';
  result.finishedAt=new Date().toISOString();checkpoint();
  for(const line of completionLines(result.completion))output(line);
  if(result.phase2.errorFiles?.csv)output('MASTER_TICKETFEHLER_CSV: '+result.phase2.errorFiles.csv);
  if(result.phase2.errorFiles?.json)output('MASTER_TICKETFEHLER_JSON: '+result.phase2.errorFiles.json);
  return result;
 }catch(e){
  const stage=result.state==='PHASE1'?'P1':'P2';
  result.state='STOP_REVIEW_REQUIRED';result.errorCode=e.code||'ERROR';
  if(e.runnerPhase)result.runnerPhase=e.runnerPhase;
  if(e.missingScopes)result.missingScopes=e.missingScopes;
  result.message=String(e.message||'').slice(0,350);
  result.failure=describeTicketIssue({reason:result.errorCode,phase:stage});
  result.finishedAt=new Date().toISOString();checkpoint();
  output('MASTER_UNTERBROCHEN: '+result.errorCode+' | '+result.failure.errorCode+
   '; KEIN Abschluss, unabhaengige Pruefung notwendig; kein blinder Wiederanlauf.');
  if(result.runnerPhase)output('MASTER_FEHLER_PHASE: '+result.runnerPhase);
  if(result.missingScopes)output('MASTER_LISTENPRUEFUNG_OFFEN: '+result.missingScopes.join(', '));
  output('MASTER_FEHLER_URSACHE: '+result.failure.cause);
  output('MASTER_FEHLER_MASSNAHME: '+result.failure.nextAction);
  throw e;}
 finally{
  if(ownedBrowser){
   let keepOpen=false;
   if(result.state==='STOP_REVIEW_REQUIRED'){
    output('MASTER_BROWSER_PRUEFUNG: Browser nach Unterbrechung fuer die Sichtpruefung geoeffnet.');
    try{keepOpen=(await confirm('Bot-Edge fuer manuelle Pruefung offen lassen? OFFEN / ENTER = schliessen: ')).trim().toUpperCase()==='OFFEN';}catch{}
   }
   if(keepOpen){ownedBrowser.child.unref();output('MASTER_BROWSER_OFFEN: Vor neuem Lauf Bot-Edge schliessen.');}
   else{try{ownedBrowser.child.kill();}catch{}output('MASTER_BROWSER_GESCHLOSSEN: Ein Edge-Prozess am Ende des Master-Runs geschlossen.');}
  }
 }
}
async function completionOnly(target,id){
 verifyPackage(target);loadActiveMapping(target);windowsIdle(target);
 prepareFreshRun(target,{guard:windowsIdle});assertNoReview(target);
 const before=pendingSnapshot(target);need(before.some(t=>t.ticketId===id&&t.kind==='SEND'),'REPAIR_PENDING_MISSING','Ticket ist kein offener Versand.');
 const l=lock(target,'REAL_RUN'),runId=stamp(),sf=path.join(controlDir(target),'last-run.json');
 let state={schema:'MCR_BETA_RUN_V1',version:VERSION,operation:'REAL_RUN',state:'RUNNING',pid:process.pid,startedAt:new Date().toISOString(),runId};writeJSON(sf,state);
 try{
  const cfg=resolveConfig(target),reports=path.join(cfg.runtimeDirectory,'reports');fs.mkdirSync(reports,{recursive:true});
  const r=await runChild(path.join(target,'src/local-bot-full-run.mjs'),['--complete-pending','--inspect-browser'],{cwd:target,logFile:path.join(reports,'MCR_ABSCHLUSS_OHNE_NEUVERSAND_'+runId+'.log'),env:cleanEnv({MCR_SESSION_TOKEN:l.token,MCR_RUN_ID:runId,MCR_MAX_TICKETS:'1',MCR_REPAIR_TICKET:id})});
  const d=readJSON(phase1ResultPath(target));
  need(r.code===0&&!r.signal&&d.runId===runId&&!d.lastError&&d.completionOnly?.id===id&&d.completionOnly?.status==='COMPLETE'&&d.send?.clicked===false,'REPAIR_NOT_VERIFIED','Nachbearbeitung nicht bestaetigt. Kein Neuversand.');
  assertPendingUnchanged(target,before.filter(t=>t.ticketId!==id));state.state='RUNNER_EXIT_0';
  log('PASS ABSCHLUSS_OHNE_NEUVERSAND: '+id+'; andere offene Tickets unveraendert.');
 }catch(e){state.state='STOP_REVIEW_REQUIRED';state.errorCode=e.code||'ERROR';throw e;}
 finally{state.finishedAt=new Date().toISOString();writeJSON(sf,state);l.release();}
}
async function review(target=root){plainPath(target);const dir=controlDir(target),lf=path.join(dir,'operation.lock.json'),sf=path.join(dir,'last-run.json');windowsIdle(target);const recovery=releaseProvenPreActionAbort(target);if(recovery.released){log('PASS AUTO_REVIEW_PRE_ACTION: Kein Bot-Versand oder -Weiterleitungsversuch begonnen. Keine manuelle SICHER_KEIN_VERSAND-Bestaetigung notwendig.');return;}if(fs.existsSync(lf))need(!processAlive(readJSON(lf).pid),'OPERATION_ALIVE','Sperrbesitzer laeuft noch.');const j=ledger(target);log('Vorheriger Lauf: '+JSON.stringify(runState(target)));log('Offene Sende-/Weiterleitungsabsichten: '+j.pending.length);log('Nur lokale Anzeige offener Tickets:');for(const t of j.pending)log('Ticket '+t.ticketId+' | '+t.state);
 if(j.pending.some(t=>t.kind==='SEND')){
  log('NEU: Einzelnes bereits versendetes Ticket abschliessen, OHNE neue E-Mail. Empfohlen fuer SEND_UNVERIFIED.');
  const chosen=await ask('Ticket-ID fuer Status-/Speichernachtrag (z.B. 88149870), ENTER = bisherige manuelle Pruefung: ');
  if(chosen){need(/^\d{6,12}$/.test(chosen),'REPAIR_TICKET_ID','Genau eine Ticketnummer.');return completionOnly(target,chosen);}
 }
 const pendingKinds=[...new Set(j.pending.map(p=>p.kind==='FORWARD'?'FORWARD':'SEND'))];need(pendingKinds.length<=1,'REVIEW_MIXED_ACTIONS','Gemischte offene Sendungen und Weiterleitungen muessen einzeln extern geklaert werden.');const forwarding=pendingKinds[0]==='FORWARD';
 log('\nCOMARCH manuell pruefen. Weitergeleitet ist NICHT gleich gesendet. Bei Unsicherheit abbrechen.');
 const prompt=forwarding?'WEITERGELEITET_GEPRUEFT oder SICHER_NICHT_WEITERGELEITET; sonst ENTER: ':'SICHER_KEIN_VERSAND oder VERSAND_UND_SPEICHERUNG_GEPRUEFT; sonst ENTER: ';
 const answer=await ask(prompt);const allowed=forwarding?['WEITERGELEITET_GEPRUEFT','SICHER_NICHT_WEITERGELEITET']:['SICHER_KEIN_VERSAND','VERSAND_UND_SPEICHERUNG_GEPRUEFT'];if(!allowed.includes(answer)){log('Sperre bleibt bestehen.');return;}
 windowsIdle(target);if(fs.existsSync(lf)){const old=readJSON(lf);need(!processAlive(old.pid),'OPERATION_ALIVE','Sperrbesitzer aktiv.');const a=path.join(dir,'lock_archive');fs.mkdirSync(a,{recursive:true});plainPath(a);fs.copyFileSync(lf,path.join(a,'review_'+stamp()+'.json'),fs.constants.COPYFILE_EXCL);fs.unlinkSync(lf);}
 j.review(forwarding?(answer==='WEITERGELEITET_GEPRUEFT'?'OPERATOR_CONFIRMED_ROUTED':'OPERATOR_CONFIRMED_NOT_ROUTED_RETRY_ALLOWED'):(answer==='SICHER_KEIN_VERSAND'?'OPERATOR_CONFIRMED_NO_SEND_RETRY_ALLOWED':'OPERATOR_CONFIRMED_SENT_SAVED'));if(fs.existsSync(sf)){const old=readJSON(sf);writeJSON(path.join(dir,'review_'+stamp()+'.json'),old);writeJSON(sf,{...old,state:'OPERATOR_REVIEWED_NOT_RETRIED',reviewedAt:new Date().toISOString(),ticketDeliveryVerified:false});}log('Pruefentscheidung dokumentiert. Keine Nachricht versendet.');
}
async function rollback(){const input=await ask('Ziel der Wiederherstellung [ENTER = '+defaultTarget()+']: '),target=input?path.resolve(input.replace(/^"|"$/g,'')):defaultTarget();recoverOrphanedMigrationPriority(target,{forRollback:true,verifyOld:verifyPrevious,log});windowsIdle(target);const all=journals(target);need(all.length,'NO_ROLLBACK','Kein passendes Gesamtpaket-Archiv gefunden.');const j=all[0];log('Software-Rueckweg: '+j.archive+'\nKeine Tickets, Nachrichten oder Daten werden rueckgaengig gemacht.');need((await ask('ZURUECK: ')).toUpperCase()==='ZURUECK','ROLLBACK_ABORT','Keine Freigabe.');const l=lock(target,'ROLLBACK');try{restoreSoftware(j);log('PASS SOFTWARE_RESTORED');}finally{l.release();}}
function verifyMaintenanceStart(){
 verifyPackage(root);assertNoMigrationPriority(root);windowsIdle(root);
}
function mappingMaintenance({output=log}={}){
 verifyMaintenanceStart();
 maintainWorkbook(output);
}
function maintainWorkbook(output){
 const started=Date.now();
 refreshLiveWorkbook(root,{log:output});
 // Contact recovery has no access to COMARCH and never changes its send ledger.
 try{const result=flushWorkbookContacts(root,{log:output});
  output('BESTAND_KONTAKTSTATUS: '+result.applied+' Ergaenzung(en) gespeichert; '+result.pending+' offen.');
 }catch(e){output('BESTAND_ERGAENZUNG_OFFEN: '+(e.code||'WORKBOOK_IO')+' | Kontaktdatei pruefen; kein Ticket-Neuversand.');}
 output('BESTAND_VORBEREITUNGSDAUER: '+(Date.now()-started)+' ms fuer Bestandslesen und offene Kontakte.');
}
/** RC83: single menu-3 authorization covers at most six proven actions.
 * Only a real send-and-save pilot may unlock a multi-ticket e-mail runner. */
export async function menu3Flow({runPhase1=real,runFull=real,output=log}={}){
 let completed=0,previous=null;
 while(completed<6){
  const p=await runPhase1(true,previous?{forwardChainRunId:previous.runId}:{});
  if(p?.forwardVerified===true&&p?.pilotVerified!==true&&p?.processed===1){
   need(typeof p.runId==='string'&&p.runId.length>=12,'MENU3_FORWARD_PROOF','Weiterleitungsbeleg fehlt.');
   completed++;previous=p;
   output('MENU3_FORTSETZUNG: '+completed+'/6 abgeschlossen ohne E-Mail. Suche automatisch naechsten Einzelpilot.');
   continue;
  }
  if(p?.pilotVerified===true&&p?.processed===1){
   completed++;
   if(completed<6){output('PASS PILOT -> FORTSETZUNG: '+(6-completed)+' weitere Tickets unter derselben Menue-3-Freigabe.');
    await runFull(false,{automaticContinuation:true,limitAfterPilot:6-completed,pilotRunId:p.runId,initialDeliveryMode:p.deliveryMode});}
   return {status:'SUCCESS',processedByPilots:completed,pilotVerified:true};
  }
  if(p?.noEligible===true&&p?.processed===0&&p?.reason==='NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS'){
   output('MENU3_LISTEN_GEPRUEFT: '+completed+' Weiterleitung(en), kein zusaetzlicher E-Mail-Pilot. Menue 4 bleibt gesperrt.');
   return {status:'NO_MORE_ELIGIBLE',processedByPilots:completed,pilotVerified:false};
  }
  output('MENU3_STOP: Pilotnachweis unklar. Kein automatischer Folgelauf.');
  return {status:'STOP_REVIEW',processedByPilots:completed,pilotVerified:false};
 }
 output('MENU3_LIMIT: Sechs bestaetigte Weiterleitungen; kein E-Mail-Pilot. Fuer weitere Tickets Menu 3 erneut oder Master Run.');
 return {status:'LIMIT',processedByPilots:completed,pilotVerified:false};
}
// RC86: Compact operator menu. Technical recovery, rollback, QA and demos
// are retained behind explicit CLI flags but no longer clutter routine work.
export const OPERATOR_MENU=Object.freeze([
 '1  Schnellinstallation / aktualisieren (kein Echtversand)',
 '2  Excel-Bestand neu einlesen / offene Kontaktdaten ergaenzen',
 '3  PHASE 1: Alle geeigneten Tickets bearbeiten',
 '4  PHASE 2: Bearbeiten und weiterleiten',
 '5  MASTER RUN: Phase 1 -> Phase 2',
 '0  Beenden'
]);
async function showMap(){const service=await ensureFlowBridge(root);openFlowMap(service.url);log('FLOW_MAP_OPEN_REQUESTED: Live-Karte im normalen Browser angefordert; Verbindungsstatus steht in der Karte. Nur Anzeige, keine Botfreigabe.');}
/** RC98: refresh the leading XLSX immediately when the installed bot opens.
 * Refresh is local snapshot maintenance ONLY: do not flush FM/FN contact
 * records or touch COMARCH here.  A failed startup refresh never authorizes
 * a ticket run: menus 3/4/5 independently recheck the source and fail closed.
 */
export function startupWorkbookRefresh({rootDir=root,output=log,
 installed=fs.existsSync(path.join(rootDir,'private_data')),
 guard=assertNoMigrationPriority,idle=windowsIdle,refresh=refreshLiveWorkbook}={}){
 if(!installed)return {status:'NOT_INSTALLED'};
 try{
  guard(rootDir);
  idle(rootDir);
  refresh(rootDir,{log:output});
  output('PASS STARTUP_BESTAND_GEPRUEFT: Aktuelle XLSX beim Botstart uebernommen; Menue 3/4/5 pruefen erneut vor der Ticketbearbeitung.');
  return {status:'REFRESHED'};
 }catch(e){
  const code=typeof e?.code==='string'?e.code:'STARTUP_REFRESH_ERROR';
  output('WARN STARTUP_BESTAND_NICHT_AKTUELL: '+code+
   ' | Kein automatischer Ticketlauf und kein Excel-FM/FN-Schreiben beim Start. Menue 3/4/5 bleibt bis zur erfolgreichen erneuten Quellenpruefung gesperrt.');
  return {status:'BLOCKED',code};
 }
}
async function menu(){
 try{flowRecorder=createFlowRecorder(root,{onWarning:s=>process.stderr.write(s+'\n')});captureFlowConsole(flowRecorder);}catch{log('HINWEIS: Live-Protokoll nicht beschreibbar; Bot kann ohne Karte arbeiten.');}
 if(fs.existsSync(path.join(root,'private_data'))){
  startupWorkbookRefresh();
  const choice=(await ask('Live-Karte parallel oeffnen? ENTER = Ja / N = ohne Karte: ')).trim().toUpperCase();
  if(choice!=='N')try{await showMap();}catch(e){log('FLOW_MAP_UNAVAILABLE: '+e.message);}
 }
 for(;;){
 log('\n==============================================================\n MCR DATENBRUECKE '+VERSION+'\n==============================================================\n'+OPERATOR_MENU.join('\n')+'\nM  Live-Karte oeffnen (nur Anzeige)');
 try{
  const a=await ask('Auswahl: ');if(a==='0')return;
  assertNoMigrationPriority(root);
  if(a==='1'){if(await setup()==='EXIT')return;}
  else if(a==='2')await mappingMaintenance();
  else if(a==='3'){flowRecorder?.begin('P1');await masterRun({phase1Only:true});flowRecorder?.finish('RETURNED');}
  else if(a==='4'){flowRecorder?.begin('P2');verifyMaintenanceStart();const l=lock(root,'PHASE2_COMARCH_PILOT');try{maintainWorkbook(log);await phase2Run({root});flowRecorder?.finish('RETURNED');}finally{l.release();}}
  else if(a==='5'){flowRecorder?.begin('MASTER');await masterRun();flowRecorder?.finish('RETURNED');}
  else if(a.toUpperCase()==='M')await showMap();
  else log('Bitte 0 bis 5 oder M waehlen.');
 }catch(e){console.error('STOP '+(e.code||'ERROR')+': '+e.message);flowRecorder?.finish('INTERRUPTED');if(e.rollback)log('Rueckweg: '+e.rollback);}
 await ask('\nENTER zum Hauptmenue: ');
}}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){try{const [major,minor]=process.versions.node.split('.').map(Number);need(major>22||major===22&&minor>=15,'NODE_VERSION','Vorhandenes Node.js ab 22.15 erforderlich.');assertNoMigrationPriority(root);verifyPackage(root);const action=process.argv[2]||'--menu';if(action==='--selftest')await selftest();else if(action==='--demo')await demo();else if(action==='--status')await status();else if(action==='--rollback')await rollback();else if(action==='--review')await review(root);else if(action==='--map')await showMap();else if(action==='--menu')await menu();else need(false,'ARGUMENT','Zulaessig: --menu, --status, --selftest, --demo, --rollback, --review, --map.');}catch(e){console.error('STOP '+(e.code||'ERROR')+': '+e.message);process.exitCode=1;}}
