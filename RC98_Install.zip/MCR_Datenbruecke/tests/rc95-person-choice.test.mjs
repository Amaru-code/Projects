/** Regression of actual NAME_CHOICE failure, with only fictional profiles.
 * 11370121 is the operator-supplied regression input, not a fixture identity.
 * No COMARCH/network/send/save is invoked by these tests.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import Identity from '../lib/identity-evidence.cjs';
import Person from '../lib/person-quoted.cjs';
import Core from '../lib/data-core.cjs';
import Queue from '../lib/queue-send.cjs';
import {confirmMemberCorrection,reviewReceipt} from '../lib/member-review.mjs';
import {preferVerifiedFullName} from '../lib/name-resolution.mjs';
import {SCHEMA,POLICY,recordFromRow,summarizeRecords} from '../lib/multirow-tpp-mapping.mjs';
import {parsePersonChoice,promptPersonChoice,inspectWwidSelection,inspectMercerIdSelection,wwidSearchQueries,resolveWwidPersonChoice,searchWwidMember,wwidIssueMessage} from '../lib/person-choice.mjs';
import {safePreactionSkip} from '../lib/preaction-skip.mjs';
import {sanitizeFlowLine} from '../lib/flow-events.mjs';
import {describeTicketIssue} from '../lib/ticket-error-catalog.mjs';

const candidates=[
 {firstName:'Max',lastName:'Mustermann',name:'Max Mustermann',sources:['Signatur'],quotedOnly:false},
 {firstName:'Erika',lastName:'Beispiel',name:'Erika Beispiel',sources:['Signatur'],quotedOnly:false}
];
const wwid='11370121';
function mapping(keys=[]){
 const entries=Object.fromEntries(keys.map((key,i)=>{
  const record=recordFromRow({row:2+i,B:key,L:'10',C:'1',D:'0',E:'0',F:'0',O:'M'},key);
  return [key,{clientId:key,duplicatePolicy:POLICY,records:[record],...summarizeRecords([record])}];
 }));
 return {schema:SCHEMA,payload:{entries,blocked:{}}};
}
function member(id='99900001',person=candidates[1]){return {id,source:'MEMBER_PROFILE_VERIFIED',profileIdMatches:true,firstName:person.firstName,lastName:person.lastName};}
function profile(m,extra={}){return {profileVerified:true,profile:{mercerId:m.id,first:m.firstName,last:m.lastName},wwidEvidence:'EXACT_LABELED_WWID',wwid,...extra};}
function inspect(options={}){const m=member();return inspectWwidSelection({wwid,member:m,profileEvidence:profile(m),candidates,evidence:{expectedId:null},map:mapping(),...options});}
const scripted=values=>{let i=0;return async()=>{assert(i<values.length,'Unexpected extra prompt');return values[i++];};};

test('RC95: candidate indices and WWID input are distinct without numeric coercion',()=>{
 assert.deepEqual(parsePersonChoice('1',2),{kind:'INDEX',index:0});
 assert.deepEqual(parsePersonChoice('2',2),{kind:'INDEX',index:1});
 for(const value of [wwid,'WWID:'+wwid,'wwid '+wwid,' WWID = '+wwid+' '])assert.deepEqual(parsePersonChoice(value,2),{kind:'WWID',wwid});
 for(const value of ['ID:'+wwid,'MERCERID: '+wwid,'Mercer ID = '+wwid])assert.deepEqual(parsePersonChoice(value,2),{kind:'MERCERID',mercerId:wwid});
 for(const value of ['0001','00000002'])assert.deepEqual(parsePersonChoice(value,2),{kind:'WWID',wwid:value});
 assert.equal(parsePersonChoice('02',2).kind,'INVALID');
 for(const value of ['', '0','3','-1','1.0','1e2','Infinity','Mark','WWID:0000','0000','1234567890123456','WWID:'])assert.equal(parsePersonChoice(value,2).kind,'INVALID',value);
 assert.equal(parsePersonChoice('ABBRUCH',2).kind,'ABORT');
 assert.equal(parsePersonChoice('ÜBERSPRINGEN',2).kind,'SKIP');
});

test('RC95: typos and ENTER re-prompt rather than aborting or selecting a default',async()=>{
 const lines=[];const choice=await promptPersonChoice({candidates,ask:scripted(['wrong','','99','2']),log:x=>lines.push(x)});
 assert.deepEqual(choice,{kind:'INDEX',index:1});assert.equal(lines.length,3);assert(lines.every(x=>x.startsWith('NAME_CHOICE_RETRY:')));
});

test('RC95: explicit abort and explicit skip remain different actions',async()=>{
 await assert.rejects(()=>promptPersonChoice({candidates,ask:scripted(['ABBRUCH'])}),{code:'NAME_CHOICE_CANCELLED'});
 await assert.rejects(()=>promptPersonChoice({candidates,ask:scripted(['UEBERSPRINGEN'])}),{code:'NAME_CHOICE_SKIPPED'});
 for(const phase of ['MAIL_AND_PERSON','MEMBER_SUGGESTION_SELECTION']){
  assert.equal(safePreactionSkip('NAME_CHOICE_SKIPPED',phase),'IDENTITY_REVIEW');
  assert.equal(safePreactionSkip('NAME_CHOICE_SKIPPED',phase,{pending:true}),null);
  assert.equal(safePreactionSkip('NAME_CHOICE_CANCELLED',phase),null);
 }
 assert.equal(safePreactionSkip('NAME_CHOICE_SKIPPED','SENDING'),null);
});

test('RC95: labeled WWID resolves the matching candidate without making it MercerID',()=>{
 const evidence=Object.freeze({expectedId:null,mode:'NAME_AND_COMARCH_ONLY'});
 const result=inspect({evidence});
 assert.equal(result.ok,true);assert.equal(result.person,candidates[1]);assert.equal(result.relation,'EXACT_LABELED_WWID');
 assert.notEqual(result.member.id,wwid);assert.equal(evidence.expectedId,null);
});

test('RC95: a numeric MercerID match alone cannot establish a WWID relation',()=>{
 const m=member(wwid),proof=profile(m,{wwid:null,wwidEvidence:'NO_EXPLICIT_WWID_FIELD',memberReferenceWwid:wwid});
 assert.equal(inspect({member:m,profileEvidence:proof,map:mapping()}).reason,'NAME_WWID_UNPROVEN');
 assert.equal(inspect({member:m,profileEvidence:proof,map:null}).reason,'NAME_WWID_UNPROVEN');
 const exact=inspect({member:m,profileEvidence:proof,map:mapping([wwid])});
 assert.equal(exact.ok,true);assert.equal(exact.relation,'VALIDATED_CLIENTEEID_EXACT');
});

test('RC95: existing one-prefix COMARCH mapping relation is verified, not guessed',()=>{
 const m=member('11'+wwid),proof=profile(m,{wwid:null,wwidEvidence:'NO_EXPLICIT_WWID_FIELD'});
 const result=inspect({member:m,profileEvidence:proof,map:mapping([wwid])});
 assert.equal(result.ok,true);assert.equal(result.relation,'VALIDATED_CLIENTEEID_PREFIX11');
 assert.deepEqual(wwidSearchQueries(mapping([wwid]),wwid),[wwid,'11'+wwid]);
 assert.deepEqual(wwidSearchQueries(mapping(),wwid),[wwid]);
 // An exact, different key has priority in the existing lookup. Do not skip it.
 assert.equal(inspect({member:m,profileEvidence:proof,map:mapping([m.id,wwid])}).reason,'NAME_WWID_UNPROVEN');
});

test('RC95: reported number can be explicitly corrected from WWID to MercerID when mapping removes its 11-prefix',async()=>{
 const m=member(wwid),map=mapping(['370121']);
 const proof=profile(m,{wwid:null,wwidEvidence:'NO_EXPLICIT_WWID_FIELD',memberReferenceWwid:wwid});
 assert.equal(inspect({member:m,profileEvidence:proof,map}).reason,'NAME_WWID_UNPROVEN');
 const lines=[],hints=[],evidence=Object.freeze({expectedId:null,mode:'NAME_AND_COMARCH_ONLY'});
 const result=await resolveWwidPersonChoice({choice:{kind:'WWID',wwid},candidates,evidence,map,
  search:async(q,opts)=>{hints.push([q,opts.hintKind]);return {member:m,profileEvidence:proof};},ask:scripted(['ID:'+wwid]),log:x=>lines.push(x)});
 assert.equal(result.kind,'MERCERID');assert.equal(result.relation,'EXPLICIT_MERCERID_PROFILE_MATCH');
 assert.deepEqual(hints,[[wwid,'WWID'],[wwid,'MERCERID']]);assert.equal(evidence.expectedId,null);
 assert.equal(lines.some(x=>x.startsWith('PASS NAME_WWID_RELATION_VERIFIED:')),false);
 assert(lines.some(x=>x.includes('ID:<Kennung>')));assert(lines.some(x=>x.startsWith('PASS NAME_MERCERID_PROFILE_VERIFIED:')));
});

test('RC95: explicit MercerID still requires exact profile, full original name and any original MercerID',()=>{
 const m=member(wwid),args={mercerId:wwid,member:m,profileEvidence:profile(m),candidates,evidence:{expectedId:null}};
 assert.equal(inspectMercerIdSelection(args).ok,true);
 assert.equal(inspectMercerIdSelection({...args,mercerId:'99900004'}).reason,'NAME_MERCERID_NO_MATCH');
 assert.equal(inspectMercerIdSelection({...args,candidates:[candidates[0]]}).reason,'NAME_WWID_NAME_CONFLICT');
 assert.equal(inspectMercerIdSelection({...args,evidence:{expectedId:'99900005'}}).reason,'NAME_WWID_ID_CONFLICT');
 assert.equal(inspectMercerIdSelection({...args,member:{...m,source:'MEMBER_FIELD'}}).reason,'NAME_WWID_PROFILE_UNVERIFIED');
});

test('RC95: WWID conflict, ambiguous field, name conflict and original MercerID conflict block selection',()=>{
 const m=member();
 assert.equal(inspect({profileEvidence:profile(m,{wwid:'99900002'})}).reason,'NAME_WWID_CONFLICT');
 assert.equal(inspect({profileEvidence:profile(m,{wwid:null,wwidEvidence:'MULTIPLE_WWID_FIELDS'}),map:mapping([wwid])}).reason,'NAME_WWID_CONFLICT');
 assert.equal(inspect({candidates:[candidates[0]]}).reason,'NAME_WWID_NAME_CONFLICT');
 assert.equal(inspect({evidence:{expectedId:'99900002'}}).reason,'NAME_WWID_ID_CONFLICT');
 assert.equal(inspect({member:{...m,source:'MEMBER_FIELD'}}).reason,'NAME_WWID_PROFILE_UNVERIFIED');
 assert.equal(inspect({profileEvidence:{...profile(m),profile:{...profile(m).profile,mercerId:'99900003'}}}).reason,'NAME_WWID_PROFILE_CHANGED');
});

test('RC95: blocked mappings are not bypassed by prefix-removal or operator numeric input',()=>{
 const m=member('11'+wwid),map=mapping([wwid]);map.payload.blocked[m.id]={codes:['CELL_ERROR']};
 assert.equal(inspect({member:m,profileEvidence:profile(m,{wwid:null,wwidEvidence:'NO_EXPLICIT_WWID_FIELD'}),map}).reason,'NAME_WWID_MAPPING_BLOCKED');
});

test('RC95: nonexistent WWID permits correction to a name number and does not end the run',async()=>{
 let searches=0;const lines=[];
 const result=await resolveWwidPersonChoice({choice:{kind:'WWID',wwid},candidates,evidence:{expectedId:null},map:mapping(),
  search:async()=>{searches++;return {member:null,reason:'NAME_WWID_NO_MATCH'};},ask:scripted(['nonsense','2']),log:x=>lines.push(x)});
 assert.equal(searches,1);assert.equal(result.kind,'INDEX');assert.equal(result.person,candidates[1]);
 assert(lines.some(x=>x.startsWith('NAME_WWID_RETRY:')));assert(lines.some(x=>x.startsWith('NAME_CHOICE_RETRY:')));
});

test('RC95: conflicting hint can be corrected; transport failures never become hidden retries',async()=>{
 const m=member(),queries=[];
 const result=await resolveWwidPersonChoice({choice:{kind:'WWID',wwid:'99900009'},candidates,evidence:{expectedId:null},map:mapping(),
  search:async q=>{queries.push(q);return {member:m,profileEvidence:profile(m)};},ask:scripted([wwid])});
 assert.equal(result.kind,'WWID');assert.deepEqual(queries,['99900009',wwid]);
 let calls=0;const network=Object.assign(new Error('disconnected'),{code:'CDP_CLOSED'});
 await assert.rejects(()=>resolveWwidPersonChoice({choice:{kind:'WWID',wwid},candidates,evidence:{},map:mapping(),
  search:async()=>{calls++;throw network;},ask:async()=>assert.fail('must not ask/retry transport')}),{code:'CDP_CLOSED'});
 assert.equal(calls,1);
});

test('RC95: browser adapter uses only the bound Member input and one freshly verified suggestion click',async()=>{
 const calls=[],m=member('11'+wwid),map=mapping([wwid]);let query='';
 const point={id:m.id,x:120,y:200};
 const page={mouseClick:async(x,y)=>calls.push(['click',x,y])};
 const ui={
  assertTicket:async(p,id)=>{assert.equal(id,'99900011');calls.push(['ticket']);},
  setInputQuery:async(p,id,value)=>{assert.equal(id,'mainForm:member-value-id');query=value;calls.push(['query',value]);return true;},
  suggestionPoints:async(p,id,terms,opts)=>{assert.equal(id,'mainForm:member-value-id');assert.equal(opts.member,true);assert(terms.includes('Erika Beispiel'));return query===wwid?[]:[point];},
  reactivateMemberAutocomplete:async()=>false,
  selectedMember:async()=>m
 };
 const result=await searchWwidMember({page,ticketId:'99900011',wwid,candidates,map,ask:async()=>assert.fail('unexpected prompt'),
  ui,wait:async()=>{},readEvidence:async()=>profile(m,{wwid:null,wwidEvidence:'NO_EXPLICIT_WWID_FIELD'})});
 assert.equal(inspect({member:result.member,profileEvidence:result.profileEvidence,map}).ok,true);
 assert.deepEqual(calls.filter(c=>c[0]==='query'),[['query',wwid],['query','11'+wwid]]);
 assert.equal(calls.filter(c=>c[0]==='click').length,1);
 assert(calls.every(c=>['ticket','query','click'].includes(c[0])));
});

test('RC95: changed suggestion or ticket binding produces no selection click',async()=>{
 let probes=0,clicks=0;
 const page={mouseClick:async()=>clicks++},m=member();
 const ui={assertTicket:async()=>{},setInputQuery:async()=>true,reactivateMemberAutocomplete:async()=>false,
  suggestionPoints:async()=>[{id:m.id,x:++probes===1?100:101,y:150}],selectedMember:async()=>m};
 const result=await searchWwidMember({page,ticketId:'99900011',wwid,candidates,map:mapping(),ui,wait:async()=>{},ask:async()=>'',readEvidence:async()=>profile(m)});
 assert.equal(result.reason,'NAME_WWID_SUGGESTION_CHANGED');assert.equal(clicks,0);
 ui.assertTicket=async()=>{throw Object.assign(new Error('wrong ticket'),{code:'TICKET_BINDING'});};
 await assert.rejects(()=>searchWwidMember({page,ticketId:'99900011',wwid,candidates,map:mapping(),ui,wait:async()=>{},ask:async()=>''}),{code:'TICKET_BINDING'});
 assert.equal(clicks,0);
});

test('RC95: explicit MercerID search never adds 11 or chooses a different ID',async()=>{
 const queries=[];let clicks=0;
 const page={mouseClick:async()=>clicks++};
 const ui={assertTicket:async()=>{},setInputQuery:async(p,id,q)=>{queries.push(q);return true;},reactivateMemberAutocomplete:async()=>false,
  suggestionPoints:async()=>[{id:'11'+wwid,x:100,y:150}],selectedMember:async()=>member(wwid)};
 const result=await searchWwidMember({page,ticketId:'99900011',wwid,hintKind:'MERCERID',candidates,map:mapping([wwid]),ui,wait:async()=>{},ask:async()=>''});
 assert.equal(result.reason,'NAME_MERCERID_NO_MATCH');assert.deepEqual(queries,[wwid]);assert.equal(clicks,0);
});

test('RC95: changing tickets during manual field focus blocks typing the search hint',async()=>{
 let changed=false,typed=false,clicked=false;
 const page={mouseClick:async()=>{clicked=true;}};
 const ui={
  assertTicket:async()=>{if(changed)throw Object.assign(new Error('Ticket changed during prompt'),{code:'TICKET_BINDING'});},
  setInputQuery:async(p,id,q,{manualGate})=>{await manualGate('INPUT_OCCLUDED');typed=true;return true;}
 };
 await assert.rejects(()=>searchWwidMember({page,ticketId:'99900011',wwid,candidates,map:mapping(),ui,wait:async()=>{},ask:async()=>{changed=true;return '';}}),{code:'TICKET_BINDING'});
 assert.equal(typed,false);assert.equal(clicked,false);
});

function actualChoosePerson(values){
 const source=fs.readFileSync(new URL('../src/local-bot-full-run.mjs',import.meta.url),'utf8');
 const body=source.slice(source.indexOf('async function choosePerson('),source.indexOf('async function downloadMail('));
 assert(body.startsWith('async function choosePerson('));
 const lines=[],diag={},context={Identity,Person,Core,preferVerifiedFullName,promptPersonChoice,DEMO:false,diag,
  ask:async(rl,text)=>rl.question(text),log:x=>lines.push(x),need:(ok,code,msg)=>{if(!ok)throw Object.assign(new Error(msg),{code});}};
 return {fn:vm.runInNewContext('('+body+')',context),rl:{question:scripted(values)},diag,lines};
}
test('RC95: actual runner choosePerson accepts the reported 11370121 input and preserves original identity evidence',async()=>{
 const run=actualChoosePerson([wwid]);
 const result=await run.fn({subject:'Anfrage',body:'Eine offene Anfrage.'},run.rl,{preCandidates:candidates,ticketId:'99900011'});
 assert.equal(result.person,null);assert.equal(result.wwidChoice.choice.wwid,wwid);assert.equal(result.wwidChoice.candidates.length,2);
 assert.equal(result.evidence.expectedId,null);assert.equal(run.diag.personSource,'OPERATOR_WWID_SEARCH_HINT');
});
test('RC95: actual runner choosePerson keeps retrying invalid input and still accepts candidate 2',async()=>{
 const run=actualChoosePerson(['abc','','3','2']);
 const result=await run.fn({subject:'Anfrage',body:'Eine offene Anfrage.'},run.rl,{preCandidates:candidates,ticketId:'99900011'});
 assert.equal(result.person.firstName,'Erika');assert.equal(result.wwidChoice,null);assert.equal(run.lines.filter(l=>l.startsWith('NAME_CHOICE_RETRY:')).length,3);
});

function actualSelectMember({answers=[],searchResult=null,currentMember=member(),currentProof=null}={}){
 const source=fs.readFileSync(new URL('../src/local-bot-full-run.mjs',import.meta.url),'utf8');
 const body=source.slice(source.indexOf('async function selectMember('),source.indexOf('/** IceFaces dropdowns commit'));
 const calls=[],diag={},lines=[];
 let fieldQueried=false;
 const ui={
  assertTicket:async(p,id)=>{assert.equal(id,'99900011');calls.push('ticket');},
  selectedMember:async()=>{calls.push('read-profile');return currentMember;},
  setInputQuery:async(p,id,value)=>{calls.push('name-query:'+value);fieldQueried=true;return true;},
  suggestionPoints:async()=>{assert(fieldQueried);return [{id:currentMember.id,x:50,y:60}];},
  reactivateMemberAutocomplete:async()=>false
 };
 const context={Identity,Person,Queue,UI:ui,DEMO:false,diag,log:x=>lines.push(x),sleep:async()=>{},
  ask:async(rl,text)=>rl.question(text),need:(ok,code,msg)=>{if(!ok)throw Object.assign(new Error(msg),{code});},
  promptPersonChoice,resolveWwidPersonChoice,inspectWwidSelection,inspectMercerIdSelection,wwidIssueMessage,
  searchWwidMember:async()=>{calls.push('wwid-search');return searchResult??{member:member(),profileEvidence:profile(member())};},
  readPhase2MemberEvidence:async()=>currentProof??profile(currentMember),
  memberReviewWithReselect:async(page,m,p,evidence,rl)=>{
   calls.push('existing-name-and-id-guard');const result=await confirmMemberCorrection({member:m,mailPerson:p,evidence,ask:async()=>assert.fail('Unexpected identity override')});
   return {member:m,person:result.person,review:reviewReceipt(m,result.person,result.reviewed)};
  }
 };
 const fn=vm.runInNewContext('('+body+')',context);
 return {fn,calls,diag,lines,ui,rl:{question:scripted(answers)},page:{mouseClick:async()=>calls.push('member-click')}};
}
test('RC95: actual selectMember continues through the existing COMARCH name/ID guard after WWID lookup',async()=>{
 const run=actualSelectMember(),evidence=Object.freeze({expectedId:null,mode:'NAME_AND_COMARCH_ONLY'});
 const result=await run.fn(run.page,null,evidence,run.rl,{wwidChoice:{choice:{kind:'WWID',wwid},candidates,quotedOnly:false,ticketId:'99900011'},map:mapping()});
 assert.equal(result.person.firstName,'Erika');assert.equal(result.member.id,'99900001');assert.equal(result.review.reviewed,false);
 assert.equal(run.calls.filter(c=>c==='existing-name-and-id-guard').length,1);assert.equal(evidence.expectedId,null);
 assert.equal(run.diag.personIdentifierSelection.relation,'EXACT_LABELED_WWID');
});
test('RC95: actual selectMember accepts explicit MercerID correction without claiming a WWID proof',async()=>{
 const m=member(wwid),proof=profile(m,{wwid:null,wwidEvidence:'NO_EXPLICIT_WWID_FIELD'});
 const run=actualSelectMember({answers:['ID:'+wwid],searchResult:{member:m,profileEvidence:proof},currentMember:m,currentProof:proof});
 const result=await run.fn(run.page,null,{expectedId:null},run.rl,{wwidChoice:{choice:{kind:'WWID',wwid},candidates,quotedOnly:false,ticketId:'99900011'},map:mapping(['370121'])});
 assert.equal(result.member.id,wwid);assert.equal(result.person.firstName,'Erika');
 assert.equal(run.diag.personSource,'OPERATOR_MERCERID_COMARCH_VERIFIED');assert.equal(run.diag.personIdentifierSelection.kind,'MERCERID');
 assert.equal(run.calls.filter(c=>c==='existing-name-and-id-guard').length,1);
});
test('RC95: actual selectMember restarts a name search after failed WWID, without trusting the prior selected Member',async()=>{
 const run=actualSelectMember({answers:['2'],searchResult:{member:null,reason:'NAME_WWID_NO_MATCH'}});
 const result=await run.fn(run.page,null,{expectedId:null},run.rl,{wwidChoice:{choice:{kind:'WWID',wwid},candidates,quotedOnly:false,ticketId:'99900011'},map:mapping()});
 assert.equal(result.person.firstName,'Erika');
 assert(run.calls.indexOf('name-query:Beispiel Erika')<run.calls.indexOf('read-profile'));
 assert.equal(run.calls.filter(c=>c==='member-click').length,1);assert.equal(run.calls.filter(c=>c==='existing-name-and-id-guard').length,1);
});
test('RC95: actual name-number fallback rechecks the ticket after the operator prompt',async()=>{
 const run=actualSelectMember({answers:['2'],searchResult:{member:null,reason:'NAME_WWID_NO_MATCH'}});
 run.ui.assertTicket=async()=>{throw Object.assign(new Error('Ticket changed during choice'),{code:'TICKET_BINDING'});};
 await assert.rejects(()=>run.fn(run.page,null,{expectedId:null},run.rl,{wwidChoice:{choice:{kind:'WWID',wwid},candidates,quotedOnly:false,ticketId:'99900011'},map:mapping()}),{code:'TICKET_BINDING'});
 assert.equal(run.calls.some(x=>x.startsWith('name-query:')),false);assert.equal(run.calls.includes('member-click'),false);
});
test('RC95: actual selectMember rejects a changed profile after WWID resolution and honors skip',async()=>{
 const changed=member('99900003',candidates[0]);
 const run=actualSelectMember({answers:['UEBERSPRINGEN'],currentMember:changed,currentProof:profile(changed)});
 await assert.rejects(()=>run.fn(run.page,null,{expectedId:null},run.rl,{wwidChoice:{choice:{kind:'WWID',wwid},candidates,quotedOnly:false,ticketId:'99900011'},map:mapping()}),{code:'NAME_CHOICE_SKIPPED'});
 assert.equal(run.calls.includes('existing-name-and-id-guard'),false);assert(run.lines.some(x=>x.startsWith('NAME_WWID_RETRY:')));
});

test('RC95: telemetry strips names and WWID values, and actionable incident codes are stable',()=>{
 for(const code of ['NAME_CHOICE_REQUIRED','NAME_CHOICE_RETRY','NAME_WWID_SEARCH_HINT','NAME_WWID_RETRY','NAME_MERCERID_SEARCH_HINT','NAME_MERCERID_RETRY']){
  assert.equal(sanitizeFlowLine(code+': Erika Beispiel '+wwid),code+':');
 }
 assert.equal(sanitizeFlowLine('PASS NAME_WWID_RELATION_VERIFIED: '+wwid),'PASS NAME_WWID_RELATION_VERIFIED:');
 assert.equal(describeTicketIssue({reason:'NAME_CHOICE',phase:'P1'}).errorCode,'MCR-P1-104');
 assert.equal(describeTicketIssue({reason:'NAME_CHOICE_CANCELLED',phase:'P1'}).errorCode,'MCR-P1-105');
});
