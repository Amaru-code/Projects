import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {contactObservation,planContactUpdate,flushWorkbookContacts,recordWorkbookContact,emailsInCell} from '../lib/workbook-contacts.mjs';
import {readLiveWorkbook,refreshLiveWorkbook} from '../lib/live-workbook.mjs';
import {reviewReceipt} from '../lib/member-review.mjs';
import {sha256} from '../lib/core.mjs';
import {fixture,row,header,cells} from './rc97-workbook-fixture.mjs';

const email='ada.beispiel@example.invalid';
const member={id:'1199900001',firstName:'Ada',lastName:'Beispiel',source:'MEMBER_PROFILE_VERIFIED',profileIdMatches:true};
const person={firstName:'Ada',lastName:'Beispiel',sources:['SENDER_DISPLAY'],quotedOnly:false};
const mail={senderName:'Ada Beispiel',senderEmail:email,body:'Guten Tag, bitte um Bearbeitung. Vielen Dank. Freundliche Grüße\nAda Beispiel'};
function environment(bytes=fixture()){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'mcr97-contact-'));
 const file=path.join(root,'current.xlsx');fs.writeFileSync(file,bytes);fs.mkdirSync(path.join(root,'config'));
 fs.writeFileSync(path.join(root,'config/local-runner-queue-send.json'),JSON.stringify({stockWorkbookPath:file}));
 const active=refreshLiveWorkbook(root);
 const options=extra=>({root,active,ticketId:'99900002',member,person,mail,recipient:email,review:{reviewed:false},
  languageEvidence:{language:'DE',reason:'CURRENT_ORIGINAL_MESSAGE'},observedAt:'2026-11-18T09:00:00Z',...extra});
 return {root,file,active,options,item:extra=>contactObservation(options(extra)),close:()=>fs.rmSync(root,{recursive:true,force:true})};
}
const pendingDirectory=root=>path.join(root,'.runtime/workbook/contacts');
function enqueue(root,item){
 const dir=pendingDirectory(root);fs.mkdirSync(dir,{recursive:true});
 const file=path.join(dir,item.id+'.json');fs.writeFileSync(file,JSON.stringify(item));return file;
}
const readItem=file=>JSON.parse(fs.readFileSync(file));
// A deliberately injected local adapter, never the production Windows writer.
// It independently checks the source generation and verifies its disk output.
function testCommit(counter){return (root,file,live,plan)=>{
 counter.calls++;
 assert.equal(sha256(fs.readFileSync(file)),live.hash);
 fs.writeFileSync(file,plan.bytes);
 assert.equal(sha256(fs.readFileSync(file)),sha256(plan.bytes));return {verified:true};
};}

test('RC97 contacts: original sender, structured Member and original language produce stable WWID-bound receipt',()=>{
 const env=environment();try{
  const item=env.item();assert.equal(item.wwid,'99900001');assert.equal(item.comarchId,member.id);
  assert.equal(item.email,email);assert.equal(item.language,'DE');assert.equal(item.ownerConfirmed,true);
  assert.equal(item.id,env.item({observedAt:'2026-11-18T09:10:00Z'}).id);
  assert.notEqual(item.id,env.item({ticketId:'99900003'}).id);
 }finally{env.close();}
});

test('RC97 contacts: another sender/representative, mismatched recipient, unclear language and conflicting WWID cannot be learned',()=>{
 const env=environment();try{
  const cases=[
   [{mail:{...mail,senderName:'Anna Vertreter',senderEmail:'anna.vertreter@example.invalid'},recipient:'anna.vertreter@example.invalid'},'WORKBOOK_CONTACT_OWNER'],
   [{recipient:'other@example.invalid'},'WORKBOOK_CONTACT_SENDER'],
   [{languageEvidence:{language:'DE',reason:'MAPPING_DEFAULT'}},'WORKBOOK_CONTACT_LANGUAGE'],
   [{member:{...member,wwid:'99999999',wwidEvidence:'EXACT_LABELED_WWID'}},'WORKBOOK_CONTACT_WWID'],
   [{member:{...member,source:'DISPLAY_ONLY'}},'WORKBOOK_CONTACT_PROFILE'],
   [{person:{...person,manualConfirmed:true}},'WORKBOOK_CONTACT_OWNER'],
   [{review:reviewReceipt(member,person,true,{contactOwnerConfirmed:false})},'WORKBOOK_CONTACT_REPRESENTATIVE'],
   [{review:{...reviewReceipt(member,person,true,{contactOwnerConfirmed:true}),memberId:'1199999999'}},'MEMBER_REVIEW_CHANGED']
  ];
  for(const [override,code] of cases)assert.throws(()=>env.item(override),{code});
  assert.equal(fs.existsSync(pendingDirectory(env.root)),false);
 }finally{env.close();}
});

test('RC97 contacts: explicit same-profile owner confirmation permits a corrected alias without retyping names',()=>{
 const env=environment();try{
  const review=reviewReceipt(member,person,true,{contactOwnerConfirmed:true});
  const item=env.item({review,person:{...person,manualConfirmed:true},mail:{...mail,senderName:'AB Account',senderEmail:'alias@example.invalid'},recipient:'alias@example.invalid'});
  assert.equal(item.email,'alias@example.invalid');assert.equal(item.wwid,'99900001');
 }finally{env.close();}
});

test('RC97 contacts: append/deduplicate FM and write FN on every matching row, leaving unrelated WWID unchanged',()=>{
 const initial=fixture({values:{...row,FM:'old@example.invalid',FN:'EN'},
  rows:`<row r="3">${cells({...row,L:'20',FM:'second@example.invalid',FN:'DE'},3)}</row><row r="4">${cells({...row,B:'99900009',FM:'different@example.invalid',FN:'EN'},4)}</row>`});
 const env=environment(initial);try{
  const live=readLiveWorkbook(env.file),plan=planContactUpdate(live,env.item());
  assert.deepEqual(plan.rows,[2,3]);assert.equal(plan.updates.some(u=>/^[A-Z]+4$/.test(u.ref)),false);
  assert.equal(plan.updates.some(u=>!/^F[MN]\d+$/.test(u.ref)),false);
  fs.writeFileSync(env.file,plan.bytes);
  const updated=readLiveWorkbook(env.file);
  assert.equal(updated.rows[0].FM,'old@example.invalid; '+email);assert.equal(updated.rows[1].FM,'second@example.invalid; '+email);
  assert.equal(updated.rows[0].FN,'DE');assert.equal(updated.rows[1].FN,'DE');
  assert.equal(updated.rows[2].FM,'different@example.invalid');assert.equal(updated.rows[2].FN,'EN');
  assert.equal(updated.businessSha256,live.businessSha256);
  const again=planContactUpdate(updated,env.item());assert.equal(again.changed,false);assert.deepEqual(again.updates,[]);
 }finally{env.close();}
});

test('RC97 contacts: existing address aliases are case-insensitively deduplicated and malformed lists are not overwritten',()=>{
 assert.deepEqual(emailsInCell(' ADA.BEISPIEL@example.invalid; ada.beispiel@example.invalid\nother@example.invalid '),[email,'other@example.invalid']);
 assert.throws(()=>emailsInCell('old@example.invalid something'),{code:'WORKBOOK_EMAIL_CELL'});
 const env=environment(fixture({headers:{...header,FM:'E-Mail',FN:'Sprache'},values:{...row,FM:email.toUpperCase(),FN:'DE'},rows:''}));
 try{assert.equal(planContactUpdate(readLiveWorkbook(env.file),env.item()).changed,false);}finally{env.close();}
});

test('RC97 contacts: shared-address conflicts, foreign headers, unknown languages and formulas defer all cell writes',()=>{
 const cases=[
  [fixture({rows:`<row r="3">${cells({...row,B:'99900009',FM:email},3)}</row>`}),'WORKBOOK_EMAIL_CONFLICT'],
  [fixture({headers:{...header,FM:'Private Note'}}),'WORKBOOK_CONTACT_HEADER'],
  [fixture({values:{...row,FN:'Unbekannter Wert'}}),'WORKBOOK_LANGUAGE_CELL'],
  [fixture({values:{...row,FM:'not-an-address'}}),'WORKBOOK_EMAIL_CELL'],
  [fixture({extraCells:'<c r="FN2"><f>LANGUAGE()</f><v>0</v></c>'}),'WORKBOOK_CONTACT_FORMULA']
 ];
 for(const [bytes,code] of cases){const env=environment(bytes);try{
  const before=fs.readFileSync(env.file);assert.throws(()=>planContactUpdate(readLiveWorkbook(env.file),env.item()),{code});
  assert.ok(fs.readFileSync(env.file).equals(before));
 }finally{env.close();}}
});

test('RC97 contacts queue: locked workbook keeps durable pending records and retry applies exactly once',()=>{
 const env=environment();try{
  const first=enqueue(env.root,env.item()),second=enqueue(env.root,env.item({ticketId:'99900003',observedAt:'2026-11-18T09:10:00Z'}));
  const before=fs.readFileSync(env.file);let blockedCalls=0;
  const blocked=flushWorkbookContacts(env.root,{commit:()=>{blockedCalls++;throw Object.assign(Error('Synthetic lock'),{code:'WORKBOOK_LOCKED_OR_IO'});}});
  assert.deepEqual(blocked,{applied:0,pending:2});assert.equal(blockedCalls,1);
  assert.equal(readItem(first).status,'PENDING');assert.equal(readItem(first).lastError,'WORKBOOK_LOCKED_OR_IO');
  assert.equal(readItem(second).status,'PENDING');assert.ok(fs.readFileSync(env.file).equals(before));
  const counter={calls:0},done=flushWorkbookContacts(env.root,{commit:testCommit(counter)});
  assert.deepEqual(done,{applied:2,pending:0});assert.equal(counter.calls,1);
  assert.equal(readItem(first).status,'APPLIED');assert.equal(readItem(second).status,'APPLIED');
  const repeat=flushWorkbookContacts(env.root,{commit:()=>{throw Error('Must not commit twice');}});
  assert.deepEqual(repeat,{applied:0,pending:0});
  assert.equal(readLiveWorkbook(env.file).rows[0].FM,email);
 }finally{env.close();}
});

test('RC97 contacts queue: older delayed observation can add email without replacing a newer FN language',()=>{
 const env=environment();try{
  enqueue(env.root,env.item({languageEvidence:{language:'EN',reason:'CURRENT_ORIGINAL_MESSAGE'},observedAt:'2026-11-18T10:00:00Z'}));
  const counter={calls:0};flushWorkbookContacts(env.root,{commit:testCommit(counter)});
  const old=env.item({ticketId:'99900004',observedAt:'2026-11-18T08:00:00Z',mail:{...mail,senderEmail:'ada.beispiel+old@example.invalid'},recipient:'ada.beispiel+old@example.invalid'});
  enqueue(env.root,old);flushWorkbookContacts(env.root,{commit:testCommit(counter)});
  const data=readLiveWorkbook(env.file).rows;
  assert.ok(data[0].FM.includes(old.email));assert.equal(data[0].FN,'EN');assert.equal(data[1].FN,'EN');
  const times=JSON.parse(fs.readFileSync(path.join(env.root,'.runtime/workbook/last-contact-times.json')));
  assert.equal(times['99900001'],'2026-11-18T10:00:00Z');
 }finally{env.close();}
});

test('RC97 contacts queue: changed source path or missing WWID never reaches the commit adapter',()=>{
 const env=environment();try{
  const wrongSource=env.item();wrongSource.workbookPath=path.join(env.root,'another.xlsx');const f=enqueue(env.root,wrongSource);
  assert.deepEqual(flushWorkbookContacts(env.root,{commit:()=>{throw Error('Wrong source must not commit');}}),{applied:0,pending:1});
  assert.equal(readItem(f).lastError,'WORKBOOK_CONTACT_SOURCE');
  fs.unlinkSync(f);enqueue(env.root,env.item());
  fs.writeFileSync(env.file,fixture({values:{...row,B:'99900009'},rows:''}));
  assert.deepEqual(flushWorkbookContacts(env.root,{commit:()=>{throw Error('Missing row must not commit');}}),{applied:0,pending:1});
  assert.equal(readItem(f).lastError,'WORKBOOK_CONTACT_ROW');
 }finally{env.close();}
});

test('RC97 contacts queue: a false write receipt stays pending and preserves source bytes',()=>{
 const env=environment();try{
  const f=enqueue(env.root,env.item()),before=fs.readFileSync(env.file);
  assert.deepEqual(flushWorkbookContacts(env.root,{commit:()=>({verified:false})}),{applied:0,pending:1});
  assert.equal(readItem(f).status,'PENDING');assert.equal(readItem(f).lastError,'WORKBOOK_COMMIT_UNCERTAIN');
  assert.ok(fs.readFileSync(env.file).equals(before));
 }finally{env.close();}
});

test('RC97 contacts queue: ambiguous interrupted workbook commit preserves newer data and forbids blind retry',()=>{
 const env=environment();try{
  const item=env.item(),f=enqueue(env.root,item),before=fs.readFileSync(env.file);
  const proposed=planContactUpdate(readLiveWorkbook(env.file),item).bytes;
  const dir=path.join(env.root,'.runtime/workbook/transactions');fs.mkdirSync(dir,{recursive:true});
  fs.writeFileSync(path.join(dir,'pending.json'),JSON.stringify({state:'WRITE_INTENT',path:env.file,beforeSha256:sha256(before),afterSha256:sha256(proposed)}));
  const newer=fixture({values:{...row,FM:'newer@example.invalid'}});fs.writeFileSync(env.file,newer);
  let calls=0;
  assert.deepEqual(flushWorkbookContacts(env.root,{commit:()=>{calls++;return {verified:true};}}),{applied:0,pending:1});
  assert.equal(calls,0);assert.equal(readItem(f).lastError,'WORKBOOK_COMMIT_UNCERTAIN');assert.ok(fs.readFileSync(env.file).equals(newer));
 }finally{env.close();}
});

test('RC97 contacts queue: exact after-hash resolves interrupted commit without applying contacts twice',()=>{
 const env=environment();try{
  const item=env.item(),f=enqueue(env.root,item),before=fs.readFileSync(env.file),plan=planContactUpdate(readLiveWorkbook(env.file),item);
  const dir=path.join(env.root,'.runtime/workbook/transactions');fs.mkdirSync(dir,{recursive:true});
  const tx=path.join(dir,'pending.json');fs.writeFileSync(tx,JSON.stringify({state:'WRITE_INTENT',path:env.file,beforeSha256:sha256(before),afterSha256:sha256(plan.bytes)}));
  fs.writeFileSync(env.file,plan.bytes);
  assert.deepEqual(flushWorkbookContacts(env.root,{commit:()=>{throw Error('Already written must not be repeated');}}),{applied:1,pending:0});
  assert.equal(readItem(tx).state,'COMMITTED_VERIFIED');assert.equal(readItem(f).status,'APPLIED');
 }finally{env.close();}
});

test('RC97 contact recording: same ticket/email/language reuses one pending record when workbook is unavailable',()=>{
 const env=environment();try{
  fs.unlinkSync(env.file);const first=recordWorkbookContact(env.options()),again=recordWorkbookContact(env.options());
  assert.equal(first.status,'PENDING');assert.equal(again.status,'PENDING');
  const files=fs.readdirSync(pendingDirectory(env.root));assert.equal(files.length,1);
  assert.equal(readItem(path.join(pendingDirectory(env.root),files[0])).lastError,'WORKBOOK_UNAVAILABLE');
 }finally{env.close();}
});
