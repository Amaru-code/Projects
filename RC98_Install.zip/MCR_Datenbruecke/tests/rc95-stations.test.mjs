import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const html=fs.readFileSync(new URL('../tools/flow-lab/MCR_Flow_Lab_RC94.html',import.meta.url),'utf8');
const moduleSource=[...html.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/g)].map(m=>m[1]).find(s=>s.includes('RC95 Fahrplan:'));
assert.ok(moduleSource,'embedded stations module exists');
const context={window:{},document:{getElementById:()=>null}};vm.createContext(context);
new vm.Script(moduleSource).runInContext(context);
const A=context.window.MCRStations95;
const ev=(g,id,over,extra={})=>({run:1,seq:1,g,id,overview:over,type:'step',ticket:'90000001',...extra});

test('25 stations, existing edge endpoints and original source-node references',()=>{
 assert.equal(A.nodes.length,25);const ids=new Set(A.nodes.map(n=>n.id));assert.equal(ids.size,25);
 for(const e of A.edges){assert.ok(ids.has(e.from));assert.ok(ids.has(e.to));assert.ok(e.points.length>=2);}
 const graphs=JSON.parse(html.match(/<script[^>]*id="graphData"[^>]*>([\s\S]*?)<\/script>/)[1]);
 for(const n of A.nodes)for(const r of n.refs)assert.ok(graphs[r.g]?.nodes.some(x=>x.id===r.id),`${n.id}: invalid source ${r.g}:${r.id}`);
});
test('WWID input stays manual until independent member proof',()=>{
 const input=ev(3,'MANUAL','ID',{phase:'P1',code:'NAME_CHOICE_REQUIRED',type:'wait'}),hint=ev(3,'PICK','ID',{phase:'P1',seq:2,code:'NAME_WWID_SEARCH_HINT'}),proof=ev(3,'VERIFIED','ID',{phase:'P1',seq:3,code:'NAME_WWID_RELATION_VERIFIED',type:'good'});
 let m=A.buildLiveModel([input]);assert.equal(m.current,'manual');assert.equal(m.states.manual,'wait');
 m=A.buildLiveModel([input,hint]);assert.equal(m.current,'manual');assert.notEqual(m.states.manual,'good');
 m=A.buildLiveModel([input,hint,proof]);assert.equal(m.current,'member');assert.equal(m.states.member,'good');
});
test('assignee selected and route intent do not turn the combined handoff station green',()=>{
 const select=ev(7,'CHECK','ROUTE',{phase:'P2',type:'good',code:'P2_PRUEFER_KONTO_EXAKT'}),intent=ev(7,'EXEC','ROUTE',{phase:'P2',seq:2,type:'wait',code:'P2_JOURNAL'}),proof=ev(7,'DONE','VERIFIED',{phase:'P2',seq:3,type:'good',code:'P2_JOURNAL'});
 assert.equal(A.buildLiveModel([select]).states.handoff,'observed');
 assert.equal(A.buildLiveModel([select,intent]).states.handoff,'wait');
 assert.equal(A.buildLiveModel([select,intent,proof]).states.handoff,'good');
});
test('phase1 direct result without email maps to ticket closure rather than sent email',()=>{
 const m=A.buildLiveModel([ev(3,'NOTFOUND','P1DONE',{phase:'P1',type:'good',code:'TICKET_RESULT'})]);assert.equal(m.current,'p1save');assert.equal(m.states.p1save,'good');assert.equal(m.states.send,undefined);
});
test('next ticket, next phase and same ticket revisited do not borrow previous green path',()=>{
 const old=ev(4,'DONE','P1DONE',{phase:'P1',type:'good'}),newTicket=ev(3,'NAME','ID',{phase:'P1',ticket:'90000002',seq:2}),returned=ev(3,'NAME','ID',{phase:'P1',seq:3});
 let m=A.buildLiveModel([old,newTicket]);assert.equal(m.states.p1save,undefined);assert.equal(m.current,'original');
 m=A.buildLiveModel([old,newTicket,returned]);assert.equal(m.states.p1save,undefined);assert.equal(m.count,1);
 m=A.buildLiveModel([old,ev(5,'CURRENT','RULE',{phase:'P2',seq:2})]);assert.equal(m.phase,'P2');assert.equal(m.states.p1save,undefined);
});
test('a new scan without a ticket clears the previous ticket route',()=>{
 const m=A.buildLiveModel([ev(7,'DONE','VERIFIED',{phase:'P2',type:'good'}),ev(0,'P2SCAN','P2SCAN',{phase:'P2',ticket:null,seq:2})]);assert.equal(m.ticket,null);assert.equal(m.current,'p2scan');assert.equal(m.states.handoff,undefined);
});
test('local run filtering excludes old run even when ticket IDs match',()=>{
 const m=A.buildLiveModel([ev(4,'DONE','P1DONE',{phase:'P1',type:'good'}),ev(3,'NAME','ID',{phase:'P1',run:2})],{run:2});assert.equal(m.states.p1save,undefined);assert.equal(m.count,1);
});
test('missing intermediate events never fabricate green stations or shortcut edges',()=>{
 const m=A.buildLiveModel([ev(3,'NAME','ID',{phase:'P1'}),ev(4,'DONE','P1DONE',{phase:'P1',seq:2,type:'good'})]);assert.equal(m.states.member,undefined);assert.equal(m.states.mapping,undefined);assert.equal(m.states.send,undefined);assert.equal(m.links.size,0);assert.equal(m.gap,1);
});
test('semantic phase is from actual reference/context, not helper code prefix',()=>{
 assert.equal(A.inferPhase(ev(4,'STATUS','SAVE',{code:'P2_DESCRIPTION_INPUT_VERIFIED'})),'P1');
 assert.equal(A.inferPhase(ev(2,'BROWSER','EDGE',{code:'MASTER_BROWSER_WIEDERVERWENDET'})),'P1');
 assert.equal(A.inferPhase(ev(2,'P2MASTER','P2SCAN',{code:'P2_MASTER_BROWSER_WIEDERVERWENDET'})),'P2');
 assert.equal(A.inferPhase(ev(0,'MENU','MENU',{phase:'MENU'}),'P2'),'SYSTEM');
});
test('run-end interruption is red; returned alone cannot manufacture success',()=>{
 const xs=[ev(7,'EXEC','ROUTE',{phase:'P2',type:'wait'})];
 const bad=A.buildLiveModel(xs,{runStatus:'INTERRUPTED'});assert.equal(bad.current,'stop');assert.equal(bad.states.stop,'bad');assert.equal(bad.states.handoff,'wait');
 const returned=A.buildLiveModel(xs,{runStatus:'RETURNED'});assert.equal(returned.current,'finish');assert.equal(returned.states.finish,'observed');
});
test('verified run result survives browser-close and RETURNED in the same scope',()=>{
 const success=ev(0,'SUCCESS','SUCCESS',{phase:'P2',ticket:null,type:'good',code:'ERGEBNIS',label:'Geprüfter Bereich erledigt'});
 const close=ev(2,'CLOSE','CLOSE',{phase:'P2',ticket:null,seq:2,type:'report',code:'MASTER_BROWSER_GESCHLOSSEN',label:'Browser geschlossen'});
 const m=A.buildLiveModel([success,close],{runStatus:'RETURNED'});
 assert.equal(m.current,'finish');assert.equal(m.states.finish,'good');assert.equal(m.proofs.finish.label,success.label);
 assert.equal(m.latest.label,close.label,'latest activity remains visible separately');
 assert.equal(A.buildLiveModel([close],{runStatus:'RETURNED'}).states.finish,'observed','closing alone is never success');
 assert.equal(A.buildLiveModel([success,{...close,run:2}],{run:2,runStatus:'RETURNED'}).states.finish,'observed','next run cannot inherit old success');
});
test('open or failed run result is not hidden by a neutral browser-close message',()=>{
 const success=ev(0,'SUCCESS','SUCCESS',{phase:'P2',ticket:null,type:'good',code:'ERGEBNIS'});
 const close=ev(2,'CLOSE','CLOSE',{phase:'P2',ticket:null,seq:3,type:'report',code:'MASTER_BROWSER_GESCHLOSSEN'});
 for(const type of ['wait','bad']){
  const issue=ev(0,'PARTIAL','PARTIAL',{phase:'P2',ticket:null,seq:2,type,code:'NOCH_NICHT_ERLEDIGT',label:'Offene Fälle'});
  const m=A.buildLiveModel([success,issue,close],{runStatus:'RETURNED'});
  assert.equal(m.states.finish,type);assert.equal(m.proofs.finish.label,issue.label);
 }
});
test('free simulation only paints selected diagram path and is marked synthetic',()=>{
 const m=A.buildSimulationModel({mode:'free',diagram:3,step:1,activePath:['NAME','MANUAL','VERIFIED'],model:{paths:{0:['SEND','SAVE']}},settings:{ticketId:'90000001'}});assert.equal(m.live,false);assert.equal(m.current,'manual');assert.equal(m.states.member,undefined);assert.equal(m.states.send,undefined);
});
test('unmapped events do not fabricate a station',()=>{
 assert.equal(A.stationForEvent(ev(42,'UNKNOWN','UNKNOWN')),null);
 const m=A.buildLiveModel([]);assert.equal(m.current,null);assert.equal(m.count,0);assert.equal(Object.keys(m.states).length,0);
});

/** A deliberately narrow mounted-DOM stub. It only implements selectors and
 * mutations used by render(); it does not claim CSS layout or browser behavior. */
function mountedHarness(){
 const ids=new Map();let detail=null,detailButtons=[],detailHTML='',insertions=0;
 const doc={getElementById:id=>ids.get(id)||null,activeElement:null};
 class El {
  constructor(){this.className='';this.attrs={};this.dataset={};this.parts=new Map();this.textContent='';this.innerHTML='';this.listeners={};this.classList={add:(...xs)=>{const cs=new Set(this.className.split(/\s+/).filter(Boolean));xs.forEach(x=>cs.add(x));this.className=[...cs].join(' ');},toggle:(x,on)=>{const cs=new Set(this.className.split(/\s+/).filter(Boolean));if(on??!cs.has(x))cs.add(x);else cs.delete(x);this.className=[...cs].join(' ');},contains:x=>this.className.split(/\s+/).includes(x)};}
  querySelector(q){return this.parts.get(q)||null;}
  setAttribute(k,v){this.attrs[k]=String(v);}
  addEventListener(k,fn){this.listeners[k]=fn;}
  closest(selector){return selector==='[data-fp95-source]'&&this.dataset.fp95Source?this:null;}
  focus(options){doc.activeElement=this;this.lastFocusOptions=options;}
 }
 const c={window:{},document:doc,matchMedia:()=>({matches:true})};vm.createContext(c);new vm.Script(moduleSource).runInContext(c);
 const api=c.window.MCRStations95,rail=new El(),scroller=new El(),bar=new El(),cp=new El(),source=new El(),phase=new El(),ticket=new El(),now=new El(),label=new El(),next=new El(),legend=new El();
 Object.defineProperty(rail,'innerHTML',{get(){return'[mounted map]';},set(){throw Error('Mounted railMap.innerHTML must never be replaced');},configurable:true});
 rail.parts.set('.fp95-map',new El());rail.parts.set('.fp95-map-scroll',scroller);rail.parts.set('.fp95-context',bar);rail.parts.set('.fp95-legend>span:last-child',legend);
 bar.parts.set('.fp95-source',source);bar.parts.set('strong',phase);bar.parts.set('.fp95-ticket',ticket);bar.parts.set(':scope>p',cp);bar.parts.set('details p',next);cp.parts.set('b',now);cp.parts.set('span',label);
 const stationObjects=new Map();for(const n of api.nodes){const b=new El();b.dataset.fp95Station=n.id;b.parts.set('.fp95-station-top i',new El());b.parts.set('.fp95-station-state',new El());stationObjects.set(n.id,b);rail.parts.set('[data-fp95-station="'+n.id+'"]',b);}
 const edgeObjects=new Map();for(const edge of api.edges){const el=new El();edgeObjects.set(edge.id,el);rail.parts.set('[data-fp95-edge="'+edge.id+'"]',el);}
 const ordinaryQuery=rail.querySelector.bind(rail);rail.querySelector=q=>q==='.fp95-detail'?detail:ordinaryQuery(q);
 rail.querySelectorAll=q=>q==='[data-fp95-source]'?detailButtons:[];
 rail.insertAdjacentHTML=(where,html)=>{assert.equal(where,'beforeend');assert.match(html,/^<section class="fp95-detail">/);insertions++;detailHTML=html;detail=new El();detail.remove=()=>{detail=null;detailButtons=[];};detailButtons=[...html.matchAll(/data-fp95-source="([^"]+)" data-fp95-graph="([^"]+)"/g)].map(m=>{const b=new El();b.dataset={fp95Source:m[1],fp95Graph:m[2]};return b;});};
 scroller.scrollLeft=147;scroller.scrollTop=36;rail.scrollTop=283;
 ids.set('railMap',rail);ids.set('compactSource',new El());
 const events=[];c.window.MCRLive={state:{overlay:true,run:1,events,source:'bridge',connected:true,hideIds:true},scopeEvents:()=>events};
 const original=fs.readFileSync(new URL('../tools/flow-lab/MCR_Flow_Lab_RC94.html',import.meta.url),'utf8');
 c.window.MCRLab={GRAPHS:JSON.parse(original.match(/<script[^>]*id="graphData"[^>]*>([\s\S]*?)<\/script>/)[1])};
 return{api,rail,scroller,doc,events,stationObjects,edgeObjects,source,phase,ticket,now,label,next,legend,get detailButtons(){return detailButtons;},get detailHTML(){return detailHTML;},get insertions(){return insertions;}};
}
test('mounted live updates preserve every station node, scroll offsets and keyboard focus',()=>{
 const h=mountedHarness(),originalNodes=new Map(h.stationObjects);const focused=h.stationObjects.get('original');h.doc.activeElement=focused;
 h.events.push(ev(3,'NAME','ID',{phase:'P1',at:Date.now(),label:'Originalmail wird gelesen'}));assert.equal(h.api.init(),true);
 assert.match(h.stationObjects.get('original').className,/observed current/);assert.equal(h.source.textContent,'Live verbunden');assert.match(h.phase.textContent,/Phase 1/);
 h.events.push(ev(3,'VERIFIED','MAPCHECK',{phase:'P1',type:'good',seq:2,at:Date.now(),label:'COMARCH-Profil bestätigt'}));assert.equal(h.api.render(),true);
 assert.match(h.stationObjects.get('member').className,/good current/);assert.doesNotMatch(h.stationObjects.get('original').className,/current/);assert.ok(h.edgeObjects.get('original-member').classList.contains('passed'));assert.equal(h.edgeObjects.get('original-member').attrs['marker-end'],'url(#fp95-arrow-green)');
 assert.match(h.now.textContent,/COMARCH-Member/);assert.equal(h.label.textContent,'COMARCH-Profil bestätigt');
 for(const [id,el]of originalNodes)assert.equal(h.stationObjects.get(id),el,'station object replaced: '+id);
 assert.equal(h.scroller.scrollLeft,147);assert.equal(h.scroller.scrollTop,36);assert.equal(h.rail.scrollTop,283);assert.equal(h.doc.activeElement,focused);
 const before=h.insertions;h.api.render();assert.equal(h.insertions,before);assert.equal(h.doc.activeElement,focused);
});
test('a changed selected-station proof preserves detail focus without scrolling the map',()=>{
 const h=mountedHarness();h.events.push(ev(3,'VERIFIED','MAPCHECK',{phase:'P1',type:'good',seq:1,at:Date.now(),label:'Erster Profilnachweis'}));h.api.init();h.api.state.selected='member';h.api.render();
 assert.ok(h.detailButtons.length>0);const previous=h.detailButtons.find(b=>b.dataset.fp95Source==='VERIFIED');assert.ok(previous);h.doc.activeElement=previous;
 h.events.push(ev(3,'VERIFIED','MAPCHECK',{phase:'P1',type:'good',seq:2,at:Date.now(),label:'Erneuter gebundener Profilnachweis'}));h.api.render();
 const current=h.detailButtons.find(b=>b.dataset.fp95Source==='VERIFIED');assert.notEqual(current,previous);assert.equal(h.doc.activeElement,current);assert.equal(current.lastFocusOptions.preventScroll,true);assert.match(h.detailHTML,/Erneuter gebundener Profilnachweis/);
 assert.equal(h.scroller.scrollLeft,147);assert.equal(h.scroller.scrollTop,36);assert.equal(h.rail.scrollTop,283);
 const count=h.insertions;h.api.render();assert.equal(h.insertions,count);assert.equal(h.doc.activeElement,current);
});
