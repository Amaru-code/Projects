"""Offline adapter tests: the financial workbook/Excel are never accessed."""
import importlib.util
import json
import os
from pathlib import Path
import tempfile
import threading
import time
import types
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('ao_bridge', ROOT / 'tools' / 'ao-generator-bridge.py')
bridge = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bridge)

FIXTURE = '''from pathlib import Path
from datetime import datetime
import json, os, types
BASE=Path(__file__).resolve().parent
WORKBOOK=BASE/'IPP_Leistungsberechnungen_Arbeitsdatei.xlsm'
OUTPUT=BASE/'Ausgabe PDF'
AUDIT=BASE/'Audit_Logs'
MASTER=BASE/'master.xlsx'
CONTROL_TEMPLATE=BASE/'control.xlsm'
win32=types.SimpleNamespace(DispatchEx=lambda name: types.SimpleNamespace(Quit=lambda: None))
def lookup_person(excel, wwid):
    return {'WWID':int(wwid),'Name':'Nachname Vorname','Adresse':'Teststr. 1','PLZ':'12345'}
def is_missing_contact_value(value):
    return value in (None,'','#NV','#N/A')
def request_missing_address(person):
    raise RuntimeError('interactive contact routine must never be called')
def default_stichtag(today=None):
    today=today or datetime.now()
    return datetime(today.year,12,31)
def ask_stichtag():
    value=input('Stichtag (TT.MM.JJJJ) [31.12.2026]: ').strip()
    return datetime.strptime(value,'%d.%m.%Y') if value else default_stichtag()
def create_pdf(wwid):
    date=ask_stichtag()
    person=lookup_person(None,wwid)
    request_missing_address(person)
    MODE
    name='Nachname Vorname'
    person={'WWID':int(wwid),'Name':name}
    WORKBOOK.write_bytes(b'working fixture saved')
    OUTPUT.mkdir(exist_ok=True);AUDIT.mkdir(exist_ok=True)
    pdf=OUTPUT/f'{date:%Y-%m-%d}_Auszahlungsoption_{name}_{wwid}.pdf'
    pdf.write_bytes(b'%PDF-1.7\\n'+b'x'*500+b'\\n%%EOF')
    audit=AUDIT/(datetime.now().strftime('%Y%m%d_%H%M%S_')+wwid+'.json')
    payload={'timestamp':datetime.now().isoformat(timespec='seconds'),'status':'success','wwid':wwid,
      'name':name,'stichtag':date.strftime('%d.%m.%Y'),'record':7,'pdf':str(pdf),'contact_supplied':False}
    MUTATION
    audit.write_text(json.dumps(payload),encoding='utf-8')
    AFTER
    return pdf,audit,7,person
'''


class DummyExcel:
    def install(self):
        pass
    def cleanup(self, grace_ms=5000):
        pass
    def restore(self):
        pass


class AoBridgeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.folder = Path(self.temp.name)
        self.script = self.folder / 'auszahlungsoption_generator.py'
        self.request_id = 'a' * 32
        (self.folder/'master.xlsx').write_bytes(b'fictional master')
        (self.folder/'control.xlsm').write_bytes(b'fictional control')
        (self.folder/'IPP_Leistungsberechnungen_Arbeitsdatei.xlsm').write_bytes(b'fictional workbook')

    def tearDown(self):
        self.temp.cleanup()

    def source(self, mode='pass', mutation='pass', after='pass'):
        self.script.write_text(FIXTURE.replace('MODE', mode).replace('MUTATION', mutation).replace('AFTER', after), encoding='utf-8')
        return bridge.sha(self.script.read_bytes())

    def run_fixture(self, source_sha=None):
        with patch.object(bridge, 'OwnedExcel', DummyExcel):
            return bridge.generate(self.script, '11412817', self.request_id,
                                   source_sha or bridge.sha(self.script.read_bytes()), 5, lambda value: None)

    def test_default_date_and_verified_wwid_yield_bound_fresh_proof(self):
        source_sha = self.source()
        result = self.run_fixture(source_sha)
        proof = result['proof']
        self.assertEqual(result['status'], 'SUCCESS')
        self.assertEqual(proof['wwid'], '11412817')
        self.assertEqual(proof['requestId'], self.request_id)
        self.assertEqual(proof['name'], 'Nachname Vorname')
        self.assertEqual(proof['stichtag'], bridge.datetime.now().strftime('31.12.%Y'))
        self.assertEqual(proof['sourceSha256'], source_sha)
        self.assertEqual(proof['sha256'], bridge.sha(Path(proof['file']).read_bytes()))
        self.assertEqual(proof['auditSha256'], bridge.sha(Path(proof['auditFile']).read_bytes()))
        self.assertNotIn('Saldovortrag', json.dumps(proof))

    def test_missing_address_is_not_answered_with_stichtag_or_wwid(self):
        self.source(mode="input('Adresse: ')")
        with self.assertRaisesRegex(bridge.BridgeError, 'Adresse oder PLZ') as error:
            self.run_fixture()
        self.assertEqual(error.exception.code, 'AO_CONTACT_DATA_REQUIRED')
        self.assertIn('Angefordertes Feld: Adresse', str(error.exception))
        self.assertFalse((self.folder / 'Ausgabe PDF').exists())

    def test_missing_postcode_is_reported_separately(self):
        self.source(mode="input('PLZ: ')")
        with self.assertRaises(bridge.BridgeError) as error:
            self.run_fixture()
        self.assertEqual(error.exception.code, 'AO_CONTACT_DATA_REQUIRED')
        self.assertIn('Angefordertes Feld: PLZ', str(error.exception))
        self.assertFalse((self.folder / 'Ausgabe PDF').exists())

    def test_contact_preflight_blocks_both_fields_before_calculation(self):
        self.source(mode="raise RuntimeError('calculator must not run')")
        self.script.write_text(self.script.read_text().replace("'Adresse':'Teststr. 1','PLZ':'12345'", "'Adresse':'#NV','PLZ':''"))
        with self.assertRaises(bridge.BridgeError) as error:
            self.run_fixture()
        self.assertEqual(error.exception.code, 'AO_CONTACT_DATA_REQUIRED')
        self.assertEqual(error.exception.missing_fields, ['Adresse','PLZ'])
        self.assertFalse((self.folder/'Ausgabe PDF').exists())

    def test_owner_file_does_not_block_readonly_contact_lookup(self):
        self.source()
        (self.folder/'~$master.xlsx').write_text('owner')
        result = self.run_fixture()
        self.assertEqual(result['status'], 'SUCCESS')
        self.assertEqual((self.folder/'~$master.xlsx').read_text(), 'owner')
        self.assertEqual((self.folder/'master.xlsx').read_bytes(), b'fictional master')

    def test_owner_file_with_missing_address_reports_contact_block(self):
        self.source(mode="raise RuntimeError('calculator must not run')")
        self.script.write_text(self.script.read_text().replace("'Adresse':'Teststr. 1'", "'Adresse':'#NV'"))
        (self.folder/'~$master.xlsx').write_text('owner')
        with self.assertRaises(bridge.BridgeError) as error:
            self.run_fixture()
        self.assertEqual(error.exception.code, 'AO_CONTACT_DATA_REQUIRED')
        self.assertEqual(error.exception.missing_fields, ['Adresse'])
        self.assertFalse((self.folder/'Ausgabe PDF').exists())

    def test_missing_master_and_missing_folder_have_separate_codes(self):
        self.source()
        (self.folder/'master.xlsx').unlink()
        with self.assertRaises(bridge.BridgeError) as error:
            self.run_fixture()
        self.assertEqual(error.exception.code, 'MASTER_FILE_NOT_FOUND')
        with self.assertRaises(bridge.BridgeError) as error:
            bridge.check_readable_master_path(self.folder/'missing-folder'/'master.xlsx')
        self.assertEqual(error.exception.code, 'MASTER_PATH_UNAVAILABLE')

    def test_actual_sharing_error_not_guessed_from_owner_file(self):
        self.source()
        exc = OSError('private data must not be logged')
        exc.winerror = 32
        self.assertEqual(bridge.source_error(exc, 'read_contact_data').code, 'MASTER_WORKBOOK_LOCKED')
        self.assertEqual(bridge.source_error(exc, 'read_contact_data').details['winerror'], 32)
        self.assertNotIn('private data', str(bridge.source_error(exc, 'read_contact_data')))
        self.assertEqual(bridge.source_error(PermissionError('denied'), 'read_contact_data').code, 'MASTER_READ_ACCESS_DENIED')
        self.assertEqual(bridge.source_error(RuntimeError('unknown COM failure'), 'read_contact_data').code, 'MASTER_OPEN_FAILED')
        exc.winerror = 53
        self.assertEqual(bridge.source_error(exc, 'read_contact_data').code, 'MASTER_PATH_UNAVAILABLE')

    def test_readonly_lookup_and_actual_com_failure_preserved_on_quit(self):
        events = []
        exc = RuntimeError('synthetic COM error')
        exc.hresult = -2147024891
        def lookup(app, wwid):
            events.append('read')
            raise exc
        def quit_failed():
            events.append('quit')
            raise RuntimeError('secondary cleanup')
        ns = {'MASTER': self.folder/'master.xlsx', 'lookup_person': lookup,
              'win32': types.SimpleNamespace(DispatchEx=lambda _: types.SimpleNamespace(Quit=quit_failed))}
        with self.assertRaises(bridge.BridgeError) as error:
            bridge.contact_preflight(ns, '11412817')
        self.assertEqual(error.exception.code, 'MASTER_READ_ACCESS_DENIED')
        self.assertEqual(error.exception.details['hresult'], -2147024891)
        self.assertEqual(events, ['read', 'quit'])

    def test_changed_person_between_preflight_and_create_is_blocked(self):
        self.source()
        self.script.write_text(self.script.read_text().replace(
            "def lookup_person(excel, wwid):\n    return",
            "def lookup_person(excel, wwid):\n    global calls\n    calls=globals().get('calls',0)+1\n    if calls>1: return {'WWID':int(wwid),'Name':'Andere Person','Adresse':'Teststr. 1','PLZ':'12345'}\n    return"))
        with self.assertRaises(bridge.BridgeError) as error:
            self.run_fixture()
        self.assertEqual(error.exception.code, 'AO_MASTER_PERSON_CHANGED')
        self.assertFalse((self.folder/'Ausgabe PDF').exists())

    def test_unrecognized_prompt_is_not_guessed(self):
        self.source(mode="input('Menueauswahl: ')")
        with self.assertRaises(bridge.BridgeError) as error:
            self.run_fixture()
        self.assertEqual(error.exception.code, 'AO_UNEXPECTED_INPUT')

    def test_changed_source_after_probe_is_not_executed(self):
        old_sha = self.source()
        self.script.write_text(self.script.read_text() + '\n# changed\n')
        with self.assertRaises(bridge.BridgeError) as error:
            self.run_fixture(old_sha)
        self.assertEqual(error.exception.code, 'AO_SCRIPT_CHANGED')
        self.assertFalse((self.folder / 'Ausgabe PDF').exists())

    def test_wrong_audit_wwid_rejected(self):
        self.source(mutation="payload['wwid']='99999999'")
        with self.assertRaises(bridge.BridgeError) as error:
            self.run_fixture()
        self.assertEqual(error.exception.code, 'AO_AUDIT_MISMATCH')

    def test_stale_output_rejected(self):
        self.source(after='os.utime(pdf,(100,100))')
        with self.assertRaises(bridge.BridgeError) as error:
            self.run_fixture()
        self.assertEqual(error.exception.code, 'AO_RESULT_STALE')

    def test_global_lock_serializes_all_wwids_and_releases(self):
        with bridge.generator_lock(self.folder, wait_seconds=0):
            with self.assertRaises(bridge.BridgeError) as error:
                with bridge.generator_lock(self.folder, wait_seconds=0):
                    self.fail('second workbook owner acquired lock')
            self.assertEqual(error.exception.code, 'AO_GENERATOR_BUSY')
        with bridge.generator_lock(self.folder, wait_seconds=0):
            pass

    def test_manual_workbook_lock_prevents_export(self):
        self.source()
        (self.folder / '~$IPP_Leistungsberechnungen_Arbeitsdatei.xlsm').write_text('owner')
        with self.assertRaises(bridge.BridgeError) as error:
            self.run_fixture()
        self.assertEqual(error.exception.code, 'AO_WORKBOOK_BUSY')
        self.assertFalse((self.folder / 'Ausgabe PDF').exists())

    def test_existing_excel_process_is_not_quit_or_killed(self):
        events = []
        app = types.SimpleNamespace(Hwnd=1, Quit=lambda: events.append('quit'))
        client = types.ModuleType('win32com.client')
        client.DispatchEx = lambda *a, **k: app
        win32com = types.ModuleType('win32com')
        win32com.client = client
        process = types.ModuleType('win32process')
        process.EnumProcesses = lambda: [42]
        process.GetWindowThreadProcessId = lambda hwnd: (1, 42)
        api = types.ModuleType('win32api')
        api.OpenProcess = lambda *a: events.append('open')
        with patch.dict('sys.modules', {'win32com': win32com, 'win32com.client': client,
                                       'win32process': process, 'win32api': api}):
            owned = bridge.OwnedExcel()
            owned.install()
            with self.assertRaises(bridge.BridgeError):
                client.DispatchEx('Excel.Application')
            owned.restore()
        self.assertEqual(events, [])


    def test_rc111_recreate_existing_pdf_and_keep_historical_copy(self):
        self.source()
        first = self.run_fixture()['proof']
        old_pdf, old_audit = Path(first['file']), Path(first['auditFile'])
        old_bytes, audit_bytes = old_pdf.read_bytes(), old_audit.read_bytes()
        self.request_id = 'b' * 32
        result = self.run_fixture()['proof']
        self.assertEqual(result['file'], first['file'])
        self.assertNotEqual(result['auditFile'], first['auditFile'])
        self.assertEqual(result['freshness']['newPdf'], True)
        self.assertEqual(result['freshness']['newAudit'], True)
        self.assertGreaterEqual(result['freshness']['pdfMtimeMs'], result['freshness']['startedAtMs'])
        archived = old_pdf.parent / '.mcr_historie' / self.request_id
        self.assertEqual((archived / old_pdf.name).read_bytes(), old_bytes)
        self.assertEqual((archived / old_audit.name).read_bytes(), audit_bytes)
        self.assertEqual(old_audit.read_bytes(), audit_bytes)

    def test_rc111_reject_unchanged_pdf_even_when_old_file_has_recent_mtime(self):
        self.source()
        old = self.run_fixture()['proof']
        self.request_id = 'c' * 32
        self.source(mode='pass')
        self.script.write_text(self.script.read_text().replace("    pdf.write_bytes(b'%PDF-1.7\\n'+b'x'*500+b'\\n%%EOF')", "    pass"))
        with self.assertRaises(bridge.BridgeError) as error:
            self.run_fixture()
        self.assertEqual(error.exception.code, 'AO_RESULT_STALE')
        self.assertEqual(Path(old['file']).read_bytes(), b'%PDF-1.7\n'+b'x'*500+b'\n%%EOF')

    def test_rc111_name_mismatch_before_generation(self):
        self.source(mode="raise RuntimeError('calculator must not run')")
        with patch.object(bridge, 'OwnedExcel', DummyExcel):
            with self.assertRaises(bridge.BridgeError) as error:
                bridge.generate(self.script, '11412817', self.request_id, bridge.sha(self.script.read_bytes()), 5,
                                lambda value: None, expected_first='Wrong', expected_last='Name')
        self.assertEqual(error.exception.code, 'P2_AO_GENERATOR_PERSON')
        self.assertFalse((self.folder/'Ausgabe PDF').exists())

    def test_rc111_contact_block_has_stable_source_digest(self):
        self.source(mode="raise RuntimeError('calculator must not run')")
        self.script.write_text(self.script.read_text().replace("'Adresse':'Teststr. 1','PLZ':'12345'", "'Adresse':'#NV','PLZ':''"))
        with self.assertRaises(bridge.BridgeError) as error:
            self.run_fixture()
        self.assertEqual(error.exception.details['master_sha256'], bridge.sha((self.folder/'master.xlsx').read_bytes()))


    def interactive_source(self, address='', postcode='', save='normal'):
        self.source()
        source = self.script.read_text()
        # Fictional master, actual prompt/return structure from the supplied AO generator.
        source = source.replace("def lookup_person(excel, wwid):\n    return {'WWID':int(wwid),'Name':'Nachname Vorname','Adresse':'Teststr. 1','PLZ':'12345'}", """CONTACT = {'Adresse': %r, 'PLZ': %r}
def lookup_person(excel, wwid):
    return {'WWID':int(wwid),'Name':'Nachname Vorname','source_sheet':'output','source_row':3, **CONTACT}
def save_contact_to_master(excel, person, wwid):
    %s
    MASTER.write_text(json.dumps(CONTACT), encoding='utf8')
""" % (address, postcode, "CONTACT.update({k:person[k] for k in ('Adresse','PLZ')})" if save == 'normal' else "raise PermissionError('write denied')"))
        source = source.replace("    raise RuntimeError('interactive contact routine must never be called')", """    supplied = False
    for field in ('Adresse','PLZ'):
        if is_missing_contact_value(person.get(field)):
            person[field] = input(field + ': ').strip()
            if not person[field]: raise ValueError('empty field')
            supplied = True
    return supplied""")
        source = source.replace('    request_missing_address(person)', '    contact_supplied = request_missing_address(person)\n    if contact_supplied: save_contact_to_master(None, person, wwid)')
        source = source.replace("'contact_supplied':False", "'contact_supplied':contact_supplied")
        self.script.write_text(source, encoding='utf8')
        return bridge.sha(self.script.read_bytes())

    def run_interactive(self, callback, first='Vorname', last='Nachname'):
        with patch.object(bridge, 'OwnedExcel', DummyExcel):
            return bridge.generate(self.script, '11412817', self.request_id, bridge.sha(self.script.read_bytes()), 10,
                                   lambda value: None, expected_first=first, expected_last=last, contact_io=callback)

    def test_rc112_real_contact_routine_two_fields_and_saved_readback(self):
        self.interactive_source(); seen=[]
        values={'Adresse':'Fiktive Teststrasse 1','PLZ':'01234'}
        result=self.run_interactive(lambda field: (seen.append(field), values[field])[1])
        self.assertEqual(seen, ['Adresse','PLZ'])
        self.assertEqual(json.loads((self.folder/'master.xlsx').read_text()), values)
        proof=result['proof']; self.assertEqual(proof['contactInput']['fields'],seen)
        self.assertTrue(proof['contactInput']['masterReadbackVerified'])
        self.assertTrue(json.loads(Path(proof['auditFile']).read_text())['contact_supplied'])
        self.assertNotIn(values['Adresse'], json.dumps(proof))
        self.assertNotIn(values['PLZ'], json.dumps(proof))

    def test_rc112_only_missing_postcode_is_requested(self):
        self.interactive_source(address='Vorhandene Teststrasse 1');seen=[]
        result=self.run_interactive(lambda field: (seen.append(field),'01234')[1])
        self.assertEqual(seen,['PLZ'])
        self.assertEqual(json.loads((self.folder/'master.xlsx').read_text())['Adresse'],'Vorhandene Teststrasse 1')
        self.assertEqual(result['proof']['contactInput']['fields'], ['PLZ'])

    def test_rc112_complete_contacts_never_prompt_or_write(self):
        self.interactive_source('Teststrasse 1','01234')
        result=self.run_interactive(lambda _: self.fail('unexpected question'))
        self.assertNotIn('contactInput',result['proof'])
        self.assertEqual((self.folder/'master.xlsx').read_bytes(),b'fictional master')

    def test_rc112_decline_second_field_leaves_master_and_pdf_untouched(self):
        self.interactive_source()
        def answer(field):
            if field=='Adresse':return 'Teststrasse 1'
            raise bridge.BridgeError('AO_CONTACT_INPUT_DEFERRED','declined')
        with self.assertRaises(bridge.BridgeError) as err:self.run_interactive(answer)
        self.assertEqual(err.exception.code,'AO_CONTACT_INPUT_DEFERRED')
        self.assertEqual((self.folder/'master.xlsx').read_bytes(),b'fictional master')
        self.assertFalse((self.folder/'Ausgabe PDF').exists())

    def test_rc112_wrong_person_does_not_request_contacts(self):
        self.interactive_source()
        with self.assertRaises(bridge.BridgeError) as err:self.run_interactive(lambda _: self.fail('unexpected question'), first='Other')
        self.assertEqual(err.exception.code,'P2_AO_GENERATOR_PERSON')

    def test_rc112_failed_master_write_does_not_export(self):
        self.interactive_source(save='denied')
        with self.assertRaises(bridge.BridgeError) as err:self.run_interactive(lambda field: '01234' if field=='PLZ' else 'Teststrasse 1')
        self.assertEqual(err.exception.code,'AO_CONTACT_SAVE_UNVERIFIED')
        self.assertFalse((self.folder/'Ausgabe PDF').exists())

    def test_rc112_formula_like_contact_is_refused(self):
        self.interactive_source()
        with self.assertRaises(bridge.BridgeError) as err:self.run_interactive(lambda _: '=1+1')
        self.assertEqual(err.exception.code,'AO_CONTACT_INPUT_INVALID')
        self.assertEqual((self.folder/'master.xlsx').read_bytes(),b'fictional master')

    def test_rc113_interactive_wait_exceeds_active_timeout_without_abort(self):
        self.interactive_source()
        seen = []
        def answer(field):
            seen.append(field)
            # Each human delay alone is longer than the entire technical budget.
            time.sleep(0.40)
            return '01234' if field == 'PLZ' else 'Fiktive Teststrasse 1'
        with patch.object(bridge, 'OwnedExcel', DummyExcel):
            result = bridge.generate(self.script, '11412817', self.request_id,
                bridge.sha(self.script.read_bytes()), 0.30, lambda value: None,
                expected_first='Vorname', expected_last='Nachname', contact_io=answer)
        self.assertEqual(seen, ['Adresse', 'PLZ'])
        self.assertEqual(result['status'], 'SUCCESS')
        self.assertTrue(result['proof']['contactInput']['masterReadbackVerified'])

    def test_rc113_watchdog_technical_budget_resumes_after_input(self):
        watchdog = bridge.ActiveTimeWatchdog(0.10)
        watchdog.start()
        result = []
        with watchdog.human_input():
            timer = threading.Thread(target=lambda: result.append(watchdog.wait_expired()), daemon=True)
            timer.start()
            time.sleep(0.20)
            self.assertEqual(result, [])
        timer.join(1)
        self.assertEqual(result, [True])

    def test_rc113_watchdog_finish_releases_paused_waiter(self):
        watchdog = bridge.ActiveTimeWatchdog(0.10)
        watchdog.start()
        result = []
        with watchdog.human_input():
            timer = threading.Thread(target=lambda: result.append(watchdog.wait_expired()), daemon=True)
            timer.start()
            watchdog.finish()
            timer.join(1)
            self.assertEqual(result, [False])

if __name__ == '__main__':
    unittest.main()
