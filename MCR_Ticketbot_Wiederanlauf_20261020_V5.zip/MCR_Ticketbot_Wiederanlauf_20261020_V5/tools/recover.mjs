import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import {scanDiagnostics,runControlled} from './runner-control.mjs';
import {discoverCandidate as findCandidate} from './source-locator.mjs';
import {secureDemoMapping,DEMO_MAPPING_REL,HISTORIC_DEMO_MULTIROW_SHA256} from './demo-assets.mjs';
import {loadRecoverySettings} from './user-settings.mjs';
import {PINS,NAMES,demand,sha,readBytes,hashFile,readJson,inside,atomicJson,walk,readZip,
  dependencyFiles,checkSyntax,verifyPins,makeOverlay,retargetIdentity,verifyFiles,installAdditions,rollback,
  isVerifiedRun,uncertainSend,publicDiagnostic} from './recovery-core.mjs';

const kit=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const action=process.argv[2]||'check';
const settings=loadRecoverySettings(kit);
const home=os.homedir();
const root=path.resolve(settings.installRoot || path.join(home,'projects','Aktive_Projekte','Ticket_bot','MCR_Datenbruecke'));
const out=path.join(kit,'Ergebnis'); fs.mkdirSync(out,{recursive:true});
const report={schema:'MCR_RECOVERY_RESULT_V1',version:'2026-10-20.5',action,createdAt:new Date().toISOString(),
  status:'STARTED',steps:[],originalRunnerWritesByRepair:0,originalStartWritesByRepair:0,mappingWritesByRepair:0,
  offlineDemo:null,livePilot:null,liveQueue:null,
  privacy:'No names, IDs, message content, paths, URLs, tokens or browser data in this report.'};
const say=s=>console.log(s);
function mark(step,status='PASS'){report.steps.push({step,status});say(status+'  '+step);saveReport();}
function saveReport(){atomicJson(path.join(out,'REPARATUR_ERGEBNIS.json'),report);}
function verifyKit() {
  const manifest=readJson(path.join(kit,'MANIFEST_SHA256.json'));
  demand(manifest.schema==='MCR_RECOVERY_KIT_MANIFEST_V1','KIT_MANIFEST');
  for(const [rel,expected] of Object.entries(manifest.files)) demand(hashFile(inside(kit,rel))===expected,'KIT_CHANGED','Eine ausgelieferte Programmdatei wurde veraendert.');
}
function checkNoOtherBot() {
  demand(process.platform==='win32','WINDOWS_REQUIRED','Dieser Starter ist fuer den vorhandenen Windows-/Edge-Bot bestimmt.');
  const ps=path.join(process.env.SystemRoot||'C:\\Windows','System32','WindowsPowerShell','v1.0','powershell.exe');
  const script="$ErrorActionPreference='Stop'; $all=@(Get-CimInstance Win32_Process -Filter \"Name='node.exe'\"); $all | Select-Object ProcessId,CommandLine | ConvertTo-Json -Compress";
  const r=spawnSync(ps,['-NoProfile','-NonInteractive','-Command',script],{encoding:'utf8',timeout:20000,windowsHide:true});
  demand(!r.error&&r.status===0,'PROCESS_CHECK_FAILED','Laufende Bots konnten nicht sicher geprueft werden.');
  let list=r.stdout.trim()?JSON.parse(r.stdout.replace(/^\uFEFF/,'')):[];if(!Array.isArray(list))list=[list];
  for(const p of list) if(p.ProcessId!==process.pid) {
    demand(typeof p.CommandLine==='string','PROCESS_VISIBILITY','Ein anderer Node-Prozess ist nicht eindeutig pruefbar.');
    demand(!/local-bot-(?:full-run|recovery)|beta5.*(?:real|live)|recover\.mjs/i.test(p.CommandLine),'BOT_ALREADY_RUNNING','Ein anderer Ticketbot/Wiederanlauf ist aktiv. Nichts wurde beendet.');
  }
}
function moduleSnapshot(files) {
  return Object.fromEntries([...files].filter(([rel])=>rel!==NAMES.helper&&rel!==NAMES.original).map(([rel])=>[rel,sha(readBytes(inside(root,rel)))]).concat([[NAMES.original,hashFile(inside(root,NAMES.original))]]));
}
function pointerHash() {
  const p=inside(root,NAMES.pointer), x=readJson(p);
  demand(x&&typeof x==='object'&&!Array.isArray(x)&&Object.keys(x).length>0,'ACTIVE_MAPPING_MISSING','Der aktive Bestands-Pointer fehlt oder ist leer. Es wird kein anderes Mapping ausgewaehlt.');
  return hashFile(p);
}
function discoverCandidate() {
  const candidate=findCandidate({settings,kit,home,installRoot:root,onProgress:name=>say('Suche Quelle: '+name)});
  report.sourceScan={candidatesChecked:candidate.stats.checked,rootsChecked:candidate.stats.rootsChecked,scannedFiles:candidate.stats.scannedFiles};
  return candidate;
}
let heldLock=null;
function acquire() {
  const meta=inside(root,NAMES.metadata);fs.mkdirSync(meta,{recursive:true});
  const lock=path.join(meta,'operation.lock');
  const fd=fs.openSync(lock,'wx');
  const token=crypto.randomBytes(16).toString('hex');
  fs.writeFileSync(fd,JSON.stringify({pid:process.pid,token,createdAt:new Date().toISOString()}));fs.fsyncSync(fd);fs.closeSync(fd);
  heldLock={file:lock,token};
}
function release() {
  if(heldLock&&fs.existsSync(heldLock.file)&&readJson(heldLock.file).token===heldLock.token)fs.unlinkSync(heldLock.file);
  heldLock=null;
}
function ensureNoUncertainPreviousRun() {
  const statePath=inside(root,NAMES.metadata+'/live-state.json');
  if(fs.existsSync(statePath)) {
    const s=readJson(statePath);
    demand(!['RUNNING','REVIEW_REQUIRED'].includes(s.status),'PREVIOUS_RUN_UNCERTAIN','Frueherer Lauf ist nicht eindeutig abgeschlossen. Nicht blind erneut senden; Versand und Speicherung im COMARCH-Verlauf pruefen.');
  }
  const d=scanDiagnostics(root).find(d=>d.mode==='REAL');
  demand(!uncertainSend(d),'PREVIOUS_SEND_UNCERTAIN','Der letzte Bot-Nachweis meldet Senden ohne bestaetigte Speicherung. Zuerst COMARCH pruefen, nicht erneut senden.');
}
async function offlineDemo(candidate,files,helper,gate) {
  const temp=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-Recovery-Demo-'));
  const materialized=new Map(files);
  materialized.set(NAMES.original,candidate.bytes);
  materialized.set(NAMES.overlay,makeOverlay(candidate.bytes));
  materialized.set(NAMES.helper,helper); materialized.set(NAMES.gate,gate);
  // Only sealed synthetic resources; never clone real config/private_data/browser profiles.
  if(candidate.entries)for(const [name,b]of candidate.entries)if(name.startsWith(candidate.prefix)){
    const rel=name.slice(candidate.prefix.length);
    if(/^(?:demo|fixtures|public|assets|examples|templates)\//.test(rel)&&!materialized.has(rel))materialized.set(rel,b);
  }
  // V5: The historical demo digest is for the GENERATED multirow payload,
  // NOT for the legacy examples/DEMO_mapping.json raw bytes. Validate the
  // legacy file's internal payload hash and fictional persons before copying.
  const demoFixture=secureDemoMapping({installRoot:root,candidate,preloaded:materialized});
  materialized.set(DEMO_MAPPING_REL,demoFixture.bytes);
  report.demoFixture={status:'INTERNAL_PAYLOAD_AND_SYNTHETIC_ROWS_VERIFIED',source:demoFixture.source,
    rawFileSha256:demoFixture.integrity.fileSha256,
    legacyPayloadSha256:demoFixture.integrity.legacyPayloadSha256,
    fictionalEntryCount:demoFixture.integrity.entryCount};
  mark('FICTIONAL_LEGACY_MAPPING_VERIFIED');
  for(const [rel,b] of materialized){const p=inside(temp,rel);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,b,{flag:'wx'});}
  const hashes=Object.fromEntries([...materialized].filter(([r])=>/^(src|lib)\//.test(r)).map(([r,b])=>[r,sha(b)]));
  say('\nIsolierte Offline-Demo: keine echten Bestandsdaten, keine COMARCH-Anmeldung.');
  const result=await runControlled(temp,'DEMO',hashes);
  report.offlineDemo=publicDiagnostic(result.diagnostic);
  // Exactly the logged historic transformed payload fingerprint (not the input file SHA).
  demand(result.demoMultirowSha256===HISTORIC_DEMO_MULTIROW_SHA256,
    'DEMO_MULTIROW_RESULT_MISMATCH','Die neu erzeugte Demo-Mehrzeilenabbildung weicht vom nachgewiesenen alten Demo-Ergebnis ab. Kein Live-Start.');
  mark('HISTORIC_DEMO_MULTIROW_SHA256_MATCH');
  demand(!result.interrupted&&result.exit===0&&isVerifiedRun(result.diagnostic,'DEMO',2),'OFFLINE_DEMO_NOT_VERIFIED','Die lokale Demo ist nicht mit zwei gesendeten und gespeicherten fiktiven Tickets nachgewiesen. Keine Live-Dateien installiert.');
  mark('OFFLINE_DEMO_2_TICKETS_VERIFIED');
  // Keep the temporary fictitious evidence for diagnosis, no deletion of user files.
  return result;
}
async function liveRun(mode,receipt) {
  const statePath=inside(root,NAMES.metadata+'/live-state.json');
  verifyFiles(root,receipt.hashes);
  demand(pointerHash()===receipt.pointerSha256,'MAPPING_POINTER_CHANGED','Aktiver Mapping-Pointer wurde seit der Pruefung veraendert. Erneut REPARIEREN_UND_STARTEN verwenden.');
  atomicJson(statePath,{schema:'MCR_RECOVERY_LIVE_STATE_V1',status:'RUNNING',mode,createdAt:new Date().toISOString()});
  say(mode==='PILOT'?'\nECHTBETRIEB: maximal EIN Ticket. Der Bot kann die bestehende Standardantwort senden.':'\nECHTBETRIEB: bisheriger Ablauf, maximal 100 Tickets.');
  say('Bei unklarem Versandstatus wird kein automatischer Wiederholungsversuch gestartet.');
  let r;
  try {r=await runControlled(root,mode,receipt.hashes);}catch(e){atomicJson(statePath,{schema:'MCR_RECOVERY_LIVE_STATE_V1',status:'REVIEW_REQUIRED',mode});throw e;}
  const d=r.diagnostic;
  const verified=!r.interrupted&&r.exit===0&&d?.mode==='REAL'&&!d.lastError&&d?.send?.verified===true&&d?.save?.verified===true&&Number.isInteger(d?.loop?.processed)&&d.loop.processed>0&&(mode!=='PILOT'||d.loop.processed===1);
  const empty=!r.interrupted&&r.exit===0&&d?.mode==='REAL'&&!d.lastError&&d?.loop?.processed===0&&d?.send?.clicked===false;
  const safeAbort=!r.interrupted&&d?.mode==='REAL'&&d.send?.clicked===false&&d.loop?.processed===0;
  const status=verified?'VERIFIED':empty?'NO_ELIGIBLE_TICKET':safeAbort?'ABORTED_BEFORE_SEND':'REVIEW_REQUIRED';
  const safe=publicDiagnostic(d);atomicJson(statePath,{schema:'MCR_RECOVERY_LIVE_STATE_V1',status,mode,createdAt:new Date().toISOString(),diagnostic:safe});
  report[mode==='PILOT'?'livePilot':'liveQueue']=safe;
  if(verified&&mode==='PILOT'){receipt.pilotQualified=true;receipt.pilotAt=new Date().toISOString();atomicJson(inside(root,NAMES.metadata+'/receipt.json'),receipt);}
  if(empty){mark('NO_ELIGIBLE_TICKET','INFO');say('Aktuell kein passendes Ticket. Noch kein Einzelticket-Nachweis; denselben Starter spaeter erneut verwenden.');return;}
  demand(verified,status,status==='ABORTED_BEFORE_SEND'?'Der Originalbot hat vor dem Senden gestoppt. Fehlercode steht im Ergebnisbericht.':'Versand/Speicherung nicht eindeutig bestaetigt. Nicht blind erneut starten.');
  mark(mode==='PILOT'?'LIVE_PILOT_SEND_AND_SAVE_VERIFIED':'LIVE_QUEUE_SEND_AND_SAVE_VERIFIED');
}
async function main() {
  demand(['check','repair-pilot','queue','rollback','source-check','demo-only'].includes(action),'ACTION_INVALID');
  verifyKit();mark('REPAIR_KIT_INTEGRITY');
  if(action==='source-check') { const x=discoverCandidate(); report.status='PINNED_SOURCE_AVAILABLE'; report.sourceType=x.source;report.sourceArchiveSha256=x.archiveSha256;saveReport();mark('PINNED_IDENTITY_RUNNER_FOUND');say('Quelle gefunden und mit Original-SHA256 verifiziert. Kein Versand und keine Installation.');return; }
  demand(fs.existsSync(root),'INSTALLATION_NOT_FOUND','Die dokumentierte Installation fehlt. installRoot in recovery-settings.local.json auf den bestehenden MCR_Datenbruecke-Ordner setzen.');
  checkNoOtherBot();mark('NO_OTHER_BOT_PROCESS');
  if(action==='rollback') {
    acquire();ensureNoUncertainPreviousRun();rollback(root);report.status='ROLLBACK_COMPLETE';saveReport();say('Nur die unveraenderten Zusatzdateien wurden entfernt. Original-START und Original-Runner bleiben unveraendert.');return;
  }
  if(action==='queue') {
    acquire();ensureNoUncertainPreviousRun();
    const receipt=readJson(inside(root,NAMES.metadata+'/receipt.json'));
    demand(receipt.schema==='MCR_RECOVERY_RECEIPT_V1'&&receipt.pilotQualified===true,'PILOT_REQUIRED','Zuerst JETZT_REPARIEREN_UND_STARTEN.cmd: ein echtes Ticket mit Versand- und Speichernachweis.');
    await liveRun('QUEUE',receipt);report.status='QUEUE_FINISHED';saveReport();return;
  }
  const candidate=discoverCandidate();candidate.demoMappingPath=settings.demoMappingPath||'';report.sourceType=candidate.source;report.sourceArchiveSha256=candidate.archiveSha256;mark('PINNED_IDENTITY_RUNNER_FOUND');
  const helper=readBytes(path.join(kit,'payload','identity-evidence.cjs')),gate=readBytes(path.join(kit,'payload','mcr-recovery-gate-20261020.mjs'));
  verifyPins(root,candidate.bytes,readBytes(path.join(kit,'payload','identity-evidence.original.cjs')));demand(sha(helper)===PINS.repairedIdentity,'REPAIRED_HELPER_HASH');mark('BASELINE_AND_IDENTITY_HASHES');
  const mappingHash=pointerHash();mark('EXISTING_ACTIVE_MAPPING_PRESENT');
  const files=dependencyFiles(root,retargetIdentity(candidate.bytes),helper),snapshot=moduleSnapshot(files);
  if(candidate.entries) {
    for(const [rel,b]of files)if(rel!==NAMES.original&&rel!==NAMES.helper){
      const reference=candidate.entries.get(candidate.prefix+rel);
      demand(reference&&sha(reference)===sha(b),'CORE_DIFFERS_FROM_RC1','Eine Laufzeitdatei weicht vom bekannten RC1-Paket ab. Kein Live-Start.');
    }
    mark('RUNTIME_DEPENDENCIES_MATCH_PINNED_ARCHIVE');
  } else mark('DEPENDENCIES_LOCAL_ONLY_NOT_INDEPENDENTLY_PINNED','INFO');
  for(const [rel]of files)if(rel!==NAMES.original&&rel!==NAMES.helper&&/\.(mjs|cjs|js)$/.test(rel))checkSyntax(inside(root,rel));
  checkSyntax(path.join(kit,'payload','identity-evidence.cjs'));mark('LOCAL_DEPENDENCY_SYNTAX');
  ensureNoUncertainPreviousRun();
  if(action==='check'){report.status='PRECHECK_PASS_NO_CHANGES_NO_SEND';saveReport();say('Nur geprueft. Keine Installation und kein Versand.');return;}
  if(action==='demo-only'){
    acquire();await offlineDemo(candidate,files,helper,gate);
    report.status='OFFLINE_DEMO_VERIFIED_NO_INSTALL_NO_SEND';saveReport();
    say('Offline-Demo erfolgreich: exakt zwei fiktive Tickets nachgewiesen. Keine Installation und kein echter Versand.');return;
  }
  acquire();await offlineDemo(candidate,files,helper,gate);
  checkNoOtherBot();verifyFiles(root,snapshot);demand(pointerHash()===mappingHash,'MAPPING_POINTER_CHANGED');
  const additions=new Map([[NAMES.helper,helper],[NAMES.gate,gate],[NAMES.overlay,makeOverlay(candidate.bytes)]]);
  installAdditions(root,additions,snapshot);mark('ADDITIVE_RECOVERY_INSTALLED_OR_VERIFIED');
  const receipt={schema:'MCR_RECOVERY_RECEIPT_V1',createdAt:new Date().toISOString(),pilotQualified:false,
    candidateSha256:PINS.candidate,pointerSha256:mappingHash,
    hashes:{...snapshot,...Object.fromEntries([...additions].map(([r,b])=>[r,sha(b)]))}};
  atomicJson(inside(root,NAMES.metadata+'/receipt.json'),receipt);
  await liveRun('PILOT',receipt);report.status=receipt.pilotQualified?'PILOT_VERIFIED_READY_FOR_QUEUE':'INSTALLED_WAITING_FOR_ELIGIBLE_TICKET';saveReport();
  if(receipt.pilotQualified)say('\nErstes echtes Ticket gesendet UND gespeichert. Fuer den normalen Lauf TICKETBOT_STARTEN.cmd verwenden.');
}
try { await main(); }
catch(e) {
  if(e.stats) report.sourceScan={candidatesChecked:e.stats.checked,rootsChecked:e.stats.rootsChecked,scannedFiles:e.stats.scannedFiles,hashMismatchCount:e.stats.hashMismatchCount,skippedRoots:e.stats.skippedRoots};
  report.status='STOPPED';report.errorCode=e.code&&/^[A-Z0-9_]+$/.test(e.code)?e.code:'UNEXPECTED_ERROR';
  report.errorMessage=report.errorCode==='UNEXPECTED_ERROR'?'Technischer Abbruch; kein Erfolg behauptet.':String(e.message).replace(/(?:[A-Z]:\\|\/Users\/|\/home\/)[^\r\n]*/gi,'[lokaler Pfad]');
  saveReport();console.error('\nSTOPP '+report.errorCode+': '+report.errorMessage);
  console.error('Ergebnis\\REPARATUR_ERGEBNIS.json enthaelt den datensparsamen Status.');process.exitCode=1;
} finally {release();}
