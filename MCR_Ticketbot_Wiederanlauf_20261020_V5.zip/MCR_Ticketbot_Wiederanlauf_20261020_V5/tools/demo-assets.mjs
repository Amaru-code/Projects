/* MCR recovery V5: inspect only bounded, fictional LEGACY demo mapping bytes.
 * The historical c147... digest is NOT a hash of DEMO_mapping.json.
 * It is the runtime digest of makeMultirowMapping(...)'s NEW payload.
 * The input file contains its own payloadSha256, calculated over the ORIGINAL
 * legacy payload using JSON.stringify(obj.payload) (Node semantics).
 * No active mapping/Excel/browser/profile is ever copied into demo.
 */
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {sha,demand,inside,readBytes,walk} from './recovery-core.mjs';

export const DEMO_MAPPING_REL='examples/DEMO_mapping.json';
export const HISTORIC_DEMO_MULTIROW_SHA256='c147a9eb9c93d5c6d4a47f208c9f98c2afd0b0144cbf63b2c50b1c06676fdc40';
const MAX_FIXTURE_BYTES=1024*1024;
// The historical legacy entries represent SOURCE ROWS, NOT persons. Their
// original fields are clientId/sourceRow/usc/dc/ppPlus/dbPlus/formulas/description.
// A fictitious person is created separately by the runner's demo page, so
// checking each source row for the name "Mustermann" was categorically wrong.
// The fixed test ID and USC value are documented by the 2/2 RC1.1 DEMO run.
export const HISTORIC_DEMO_CLIENT_ID='99900001';
export const HISTORIC_DEMO_USC='10';
const ENTRY_FIELDS=new Set(['clientId','sourceRow','usc','dc','ppPlus','dbPlus','formulas','description']);
const DEMO_DESCRIPTION=/^USC\s*10\s*\/\s*(?:(?:DC|PP\+|DB\+|TPP)(?:\s*;\s*(?:DC|PP\+|DB\+|TPP))*)?\s*$/i;
const MAIL_ADDRESS=/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/;
const PRIVATE_SOURCE=/(?:mercer\.com|\\\\mercer\.|[A-Za-z]:\\[^"\r\n]*\b(?:INTL01_Gesamtdatenbestand|Bestand\s*Intel)|\bprivate_data[/\\]|\bactive-mapping\.json\b)/i;

function reject(code,message) {throw Object.assign(new Error(message),{code});}

/* The actual format used by the legacy runner's validateMappingObject:
 * Core.validateMap(obj) plus sha256(JSON.stringify(obj.payload)) === obj.payloadSha256.
 * We preflight that contract and verify fictional identity data; the original
 * runner performs its own validation once the file is in the isolated DEMO.
 */
export function verifyLegacyFictionalDemo(bytes) {
  demand(Buffer.isBuffer(bytes) && bytes.length>0 && bytes.length<=MAX_FIXTURE_BYTES,
    'DEMO_MAPPING_SIZE','Die Demo-Datei muss eine kleine, regulaere JSON-Datei sein.');
  let obj;
  try {obj=JSON.parse(bytes.toString('utf8').replace(/^\uFEFF/,''));}
  catch {reject('DEMO_MAPPING_JSON_INVALID','Die Demo-Datei enthaelt kein gueltiges JSON.');}
  if(!obj || typeof obj!=='object' || Array.isArray(obj) || typeof obj.schema!=='string' || !obj.schema.trim() ||
     !obj.payload || typeof obj.payload!=='object' || Array.isArray(obj.payload) ||
     !/^[a-f0-9]{64}$/i.test(String(obj.payloadSha256||''))) {
    reject('DEMO_MAPPING_LEGACY_SCHEMA','Die Demo-Datei hat nicht den erforderlichen alten Mapping-Vertrag schema/payload/payloadSha256.');
  }
  const actualPayloadSha256=sha(Buffer.from(JSON.stringify(obj.payload),'utf8'));
  if(actualPayloadSha256!==obj.payloadSha256.toLowerCase()) {
    reject('DEMO_MAPPING_PAYLOAD_INTEGRITY','Die interne Payload-SHA256 der Demo-Datei stimmt nicht. Nichts wurde uebernommen.');
  }
  // We require *synthetic source rows* throughout the fixture. A valid embedded
  // checksum by itself proves only consistency, not that the data is fake.
  const entries=obj.payload.entries;
  if(!entries || typeof entries!=='object' || Array.isArray(entries) ||
     Object.keys(entries).length<1 || Object.keys(entries).length>48) {
    reject('DEMO_MAPPING_ENTRIES','Die Demo-Eintraege entsprechen nicht dem kleinen fiktiven Legacy-Demoformat.');
  }
  const text=JSON.stringify(obj.payload);
  if(PRIVATE_SOURCE.test(text) || MAIL_ADDRESS.test(text)) {
    reject('DEMO_MAPPING_PRIVATE_REFERENCE','Die Demo enthaelt einen Verweis auf private oder produktive Bestandsquellen.');
  }
  for(const entry of Object.values(entries)) {
    // Genuine legacy demo rows have NO firstName/lastName. Require the exact
    // synthetic ID + USC and strict non-PII column contract instead of names.
    // Even a misleading 'Mustermann' embedded in real data is never sufficient.
    if(!entry || typeof entry!=='object' || Array.isArray(entry) ||
       String(entry.clientId??'')!==HISTORIC_DEMO_CLIENT_ID ||
       String(entry.usc??'')!==HISTORIC_DEMO_USC) {
      reject('DEMO_MAPPING_NOT_FICTIONAL',
        'Legacy-Demo-Zeile enthaelt nicht die festgelegten synthetischen ID-/USC-Werte. Keine Uebernahme.');
    }
    if(Object.keys(entry).some(k=>!ENTRY_FIELDS.has(k)) ||
       !Number.isSafeInteger(Number(entry.sourceRow)) ||
       Number(entry.sourceRow)<1 || Number(entry.sourceRow)>100000 ||
       !['0','1'].includes(String(entry.dc)) ||
       !['0','1'].includes(String(entry.ppPlus)) ||
       !['0','1'].includes(String(entry.dbPlus)) ||
       (entry.formulas!==undefined && (!Array.isArray(entry.formulas) || entry.formulas.length!==0)) ||
       (entry.description!==undefined &&
         (typeof entry.description!=='string' || !DEMO_DESCRIPTION.test(entry.description)))) {
      reject('DEMO_MAPPING_LEGACY_ROW_FORMAT',
        'Legacy-Demo-Zeile entspricht nicht dem dokumentierten synthetischen Spaltenvertrag. Keine Uebernahme.');
    }
  }
  return {fileSha256:sha(bytes),legacyPayloadSha256:actualPayloadSha256,entryCount:Object.keys(entries).length};
}

/**
 * V5 verifies a legacy demo's OWN payload integrity; never compares its raw
 * file SHA to HISTORIC_DEMO_MULTIROW_SHA256. The latter is tested against the
 * demo runner's freshly computed *transformed* mapping fingerprint.
 */
export function secureDemoMapping({installRoot,candidate,preloaded}) {
  if(preloaded.has(DEMO_MAPPING_REL)) {
    demand(candidate?.entries instanceof Map && candidate.entries.has(candidate.prefix+DEMO_MAPPING_REL),
      'DEMO_ASSET_UNTRUSTED','Vorab geladene Demo-Datei ist nicht an ein freigegebenes Originalarchiv gebunden.');
    const trusted=candidate.entries.get(candidate.prefix+DEMO_MAPPING_REL);
    demand(preloaded.get(DEMO_MAPPING_REL).equals(trusted),'DEMO_ASSET_UNTRUSTED',
      'Demo-Datei weicht vom Originalarchiv ab.');
    return {bytes:Buffer.from(trusted),source:'PINNED_RELEASE_ARCHIVE',integrity:verifyLegacyFictionalDemo(trusted)};
  }
  const pinnedSource=String(candidate?.filePath||'').trim();
  const previewRoot=pinnedSource && path.basename(pinnedSource).toLowerCase()==='local-bot-full-run.mjs'
    ? path.dirname(path.dirname(pinnedSource)) : null;
  const chosen=String(candidate?.demoMappingPath||'').trim();
  const hints=[inside(installRoot,DEMO_MAPPING_REL),
    ...(previewRoot?[path.join(previewRoot,DEMO_MAPPING_REL)]:[])];
  const home=os.homedir();
  const roots=[path.join(home,'Downloads'),path.join(home,'Documents'),path.join(home,'Desktop'),
    path.join(home,'projects','Aktive_Projekte','Ticket_bot')];
  const visited=new Set(); let bad=null; let observed=0;
  function accept(file) {
    const resolved=path.resolve(file),k=process.platform==='win32'?resolved.toLowerCase():resolved;
    if(visited.has(k))return null;visited.add(k);
    let stat;
    try {
      const parent=fs.lstatSync(path.dirname(file));stat=fs.lstatSync(file);
      if(!parent.isDirectory()||parent.isSymbolicLink()||!stat.isFile()||stat.isSymbolicLink()||
         stat.size<1||stat.size>MAX_FIXTURE_BYTES)return null;
    }catch{return null;}
    let bytes;try{bytes=readBytes(file,MAX_FIXTURE_BYTES);}catch{return null;}
    observed++;
    try {return {bytes,source:'VALIDATED_LOCAL_FICTIONAL_LEGACY_DEMO',integrity:verifyLegacyFictionalDemo(bytes)};}
    catch(e){bad=bad||e;return null;}
  }
  // An explicit operator-selected synthetic fixture wins over auto-discovery.
  // It is still fully checked; invalid choices are not silently ignored.
  if(chosen) {
    const selected=accept(path.resolve(chosen));
    if(selected)return selected;
    if(bad)throw bad;
    reject('DEMO_SELECTED_FILE_UNAVAILABLE','Die explizit ausgewaehlte Demo-Datei fehlt oder ist keine regulaere lokale Datei.');
  }
  for(const file of hints){const found=accept(file);if(found)return found;}
  for(const root of roots) {
    if(!fs.existsSync(root))continue;
    let list=[];
    try {list=walk(root,{maxDepth:9,maxFiles:20000});}
    catch(e){if(['SCAN_LIMIT','EACCES','EPERM'].includes(e.code))continue;throw e;}
    for(const file of list)if(path.basename(file).toLowerCase()==='demo_mapping.json') {
      const found=accept(file);if(found)return found;
    }
  }
  if(observed>0)throw bad;
  reject('DEMO_MAPPING_MISSING','Keine synthetische examples\\DEMO_mapping.json gefunden. Keinesfalls produktive Bestandsdaten verwenden.');
}
