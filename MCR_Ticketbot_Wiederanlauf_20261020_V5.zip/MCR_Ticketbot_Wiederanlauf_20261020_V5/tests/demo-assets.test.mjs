import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {secureDemoMapping,verifyLegacyFictionalDemo,DEMO_MAPPING_REL,HISTORIC_DEMO_MULTIROW_SHA256,HISTORIC_DEMO_CLIENT_ID,HISTORIC_DEMO_USC} from '../tools/demo-assets.mjs';
import {runControlled} from '../tools/runner-control.mjs';

const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const legacyPayload={source:{type:'DEMO',name:'DEMO_mapping.json'},entries:{'99900001':{clientId:'99900001',sourceRow:3,usc:'10',dc:0,ppPlus:1,dbPlus:0,formulas:[],description:'USC 10/ PP+'}}};
function mapping(payload=legacyPayload,spacing=2){return Buffer.from(JSON.stringify({schema:'MCR_LEGACY_MAPPING_TEST_V1',payload,payloadSha256:sha(Buffer.from(JSON.stringify(payload)))},null,spacing)+'\n');}
const fixture=mapping();
function tmp(t){const root=fs.mkdtempSync(path.join(os.tmpdir(),'mcr-v5-demo-'));t.after(()=>fs.rmSync(root,{recursive:true,force:true}));return root;}
function writeFixture(root,content=fixture){const p=path.join(root,...DEMO_MAPPING_REL.split('/'));fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,content);return p;}
function source(installRoot,candidate={entries:null}){return secureDemoMapping({installRoot,candidate,preloaded:new Map()});}

// Pin is the output from makeMultirowMapping, not the original legacy file hash.
test('historical runtime digest is not falsely treated as original file sha256',()=>{
 assert.equal(HISTORIC_DEMO_MULTIROW_SHA256,'c147a9eb9c93d5c6d4a47f208c9f98c2afd0b0144cbf63b2c50b1c06676fdc40');
 assert.notEqual(sha(fixture),HISTORIC_DEMO_MULTIROW_SHA256);
 assert.equal(verifyLegacyFictionalDemo(fixture).legacyPayloadSha256,sha(Buffer.from(JSON.stringify(legacyPayload))));
});
test('accepts self-consistent, fictional legacy demo even if complete file raw SHA differs',t=>{
 const base=tmp(t);writeFixture(base);const r=source(base);
 assert.equal(r.source,'VALIDATED_LOCAL_FICTIONAL_LEGACY_DEMO');
 assert.deepEqual(r.bytes,fixture);
 assert.notEqual(r.integrity.fileSha256,HISTORIC_DEMO_MULTIROW_SHA256);
});
test('formatting, CRLF and BOM do not change validated payload semantics',t=>{
 const a=mapping(legacyPayload,0), b=Buffer.from('\uFEFF'+mapping(legacyPayload,4).toString('utf8').replaceAll('\n','\r\n'));
 assert.notEqual(sha(a),sha(b));assert.equal(verifyLegacyFictionalDemo(a).legacyPayloadSha256,verifyLegacyFictionalDemo(b).legacyPayloadSha256);
 const base=tmp(t);writeFixture(base,b);assert.equal(source(base).integrity.legacyPayloadSha256,sha(Buffer.from(JSON.stringify(legacyPayload))));
});
test('old legacy payloadSha256 cannot be faked with altered entry content',()=>{
 const o=JSON.parse(fixture);o.payload.entries['99900001'].clientId='123456';
 assert.throws(()=>verifyLegacyFictionalDemo(Buffer.from(JSON.stringify(o))),{code:'DEMO_MAPPING_PAYLOAD_INTEGRITY'});
});
test('even correct embedded payload checksum cannot authorize a real identity',()=>{
 const p={...legacyPayload,entries:{'10':{clientId:'123',sourceRow:3,usc:'10',dc:0,ppPlus:1,dbPlus:0,formulas:[],description:'USC 10/ PP+'}}};
 assert.throws(()=>verifyLegacyFictionalDemo(mapping(p)),{code:'DEMO_MAPPING_NOT_FICTIONAL'});
});
test('rejects production UNC or personal mapping reference before demo run',()=>{
 const p={...legacyPayload,source:'\\\\mercer.com\\eu_data\\INTL01_Gesamtdatenbestand.xlsx'};
 assert.throws(()=>verifyLegacyFictionalDemo(mapping(p)),{code:'DEMO_MAPPING_PRIVATE_REFERENCE'});
});
test('valid mapping does not read/copy existing active mapping',t=>{
 const base=tmp(t);writeFixture(base);
 const secret=Buffer.from('private content not for demo');const p=path.join(base,'private_data','active-mapping.json');
 fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,secret);
 const r=source(base);assert.deepEqual(r.bytes,fixture);assert.deepEqual(fs.readFileSync(p),secret);
});
test('rejects missing demo without resorting to active mapping',t=>{assert.throws(()=>source(tmp(t)),{code:'DEMO_MAPPING_MISSING'});});
test('rejects invalid json',()=>{assert.throws(()=>verifyLegacyFictionalDemo(Buffer.from('{invalid')),{code:'DEMO_MAPPING_JSON_INVALID'});});
test('rejects unrelated synthetic rows without original legacy contract',()=>{assert.throws(()=>verifyLegacyFictionalDemo(Buffer.from('{"testOnly":true,"rows":[]}')),{code:'DEMO_MAPPING_LEGACY_SCHEMA'});});
test('rejects empty or overlarge legacy entry collections',()=>{
 assert.throws(()=>verifyLegacyFictionalDemo(mapping({...legacyPayload,entries:{}})),{code:'DEMO_MAPPING_ENTRIES'});
 const many=Object.fromEntries(Array.from({length:49},(_,i)=>[String(i),{name:'Max Mustermann'}]));
 assert.throws(()=>verifyLegacyFictionalDemo(mapping({...legacyPayload,entries:many})),{code:'DEMO_MAPPING_ENTRIES'});
});
test('rejects bogus claims to valid file identity without valid internal checksum',t=>{
 const base=tmp(t), p=JSON.parse(fixture);p.payloadSha256='0'.repeat(64);writeFixture(base,Buffer.from(JSON.stringify(p)));
 assert.throws(()=>source(base),{code:'DEMO_MAPPING_PAYLOAD_INTEGRITY'});
});
test('pinned release archive carries exact matching bytes, but still has to pass legacy integrity',t=>{
 const base=tmp(t);writeFixture(base,Buffer.from('modified'));const prefix='release/';
 const candidate={prefix,entries:new Map([[prefix+DEMO_MAPPING_REL,fixture]])};
 const got=secureDemoMapping({installRoot:base,candidate,preloaded:new Map([[DEMO_MAPPING_REL,fixture]])});
 assert.equal(got.source,'PINNED_RELEASE_ARCHIVE');assert.deepEqual(got.bytes,fixture);
});
test('preloaded mapping without matching pinned release archive is denied',t=>{
 const base=tmp(t);assert.throws(()=>secureDemoMapping({installRoot:base,candidate:{entries:null},preloaded:new Map([[DEMO_MAPPING_REL,fixture]])}),{code:'DEMO_ASSET_UNTRUSTED'});
});
test('archive preloaded data differing from pinned archive contents is denied',t=>{
 const base=tmp(t), candidate={prefix:'r/',entries:new Map([['r/'+DEMO_MAPPING_REL,fixture]])};
 assert.throws(()=>secureDemoMapping({installRoot:base,candidate,preloaded:new Map([[DEMO_MAPPING_REL,Buffer.from('changed')]])}),{code:'DEMO_ASSET_UNTRUSTED'});
});
test('rejects symlink demo file and parent directory',t=>{
 const base=tmp(t), x=tmp(t);writeFixture(x);const target=path.join(x,...DEMO_MAPPING_REL.split('/'));
 fs.mkdirSync(path.join(base,'examples'));
 try{fs.symlinkSync(target,path.join(base,'examples','DEMO_mapping.json'));}catch(e){if(e.code==='EPERM')return t.skip('symlink privilege missing');throw e;}
 assert.throws(()=>source(base),{code:'PATH_LINK'});
});
test('isolated child opens DEMO_mapping.json and no private mapping was materialized',t=>{
 const base=tmp(t), scratch=tmp(t);writeFixture(base);const result=source(base);writeFixture(scratch,result.bytes);
 const code="const fs=require('fs');const x=JSON.parse(fs.readFileSync('examples/DEMO_mapping.json','utf8'));if(x.payload.entries['99900001'].clientId!=='99900001')process.exit(2);";
 const p=spawnSync(process.execPath,['-e',code],{cwd:scratch,encoding:'utf8'});
 assert.equal(p.status,0,p.stderr);assert.equal(fs.existsSync(path.join(scratch,'private_data')),false);
});

test('runtime digest capture reads transformed mapping SHA and is independent of legacy file digest',async t=>{
 const base=tmp(t), files={
  'src/local-bot-recovery-20261020.mjs':`import fs from 'node:fs';\nconsole.log('Mapping-Datei-SHA256: ${HISTORIC_DEMO_MULTIROW_SHA256}');\nfs.writeFileSync('demo-diagnostic.json',JSON.stringify({schema:'MCR_LOCAL_RUNNER_DIAGNOSTIC_V1',mode:'DEMO',createdAt:new Date().toISOString(),loop:{processed:2},send:{verified:true},save:{verified:true},lastError:null}));`,
  'src/reference.mjs':'export const demo=true;',
  'lib/a.cjs':'module.exports=1;',
  'lib/b.cjs':'module.exports=2;'
 };
 const hashes={};for(const [rel,txt] of Object.entries(files)){const p=path.join(base,rel);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,txt);hashes[rel]=sha(Buffer.from(txt));}
 const r=await runControlled(base,'DEMO',hashes);
 assert.equal(r.exit,0);assert.equal(r.demoMultirowSha256,HISTORIC_DEMO_MULTIROW_SHA256);assert.equal(r.diagnostic?.loop?.processed,2);
});

test('explicitly selected fictional demo takes precedence over another local valid demo',t=>{
 const base=tmp(t), other=tmp(t);
 const alt=mapping({...legacyPayload,source:{type:'DEMO',name:'another synthetic asset'}});
 writeFixture(base,alt);const selected=writeFixture(other,fixture);
 const r=secureDemoMapping({installRoot:base,candidate:{entries:null,demoMappingPath:selected},preloaded:new Map()});
 assert.deepEqual(r.bytes,fixture);
});
test('explicitly selected missing demo is not silently replaced by another valid one',t=>{
 const base=tmp(t);writeFixture(base,fixture);
 assert.throws(()=>secureDemoMapping({installRoot:base,candidate:{entries:null,demoMappingPath:path.join(base,'nowhere','DEMO_mapping.json')},preloaded:new Map()}),{code:'DEMO_SELECTED_FILE_UNAVAILABLE'});
});

// V5 regression: the documented RC1.1 legacy fixture contains numeric spreadsheet
// rows, not person records. "Mustermann Max" belongs to the *separate demo page*.
test('V5 accepts historic fake MercerID and USC in a nameless legacy row',()=>{
 const row=legacyPayload.entries['99900001'];
 assert.deepEqual(Object.keys(row).sort(),['clientId','sourceRow','usc','dc','ppPlus','dbPlus','formulas','description'].sort());
 assert.equal(HISTORIC_DEMO_CLIENT_ID,'99900001');
 assert.equal(HISTORIC_DEMO_USC,'10');
 assert.ok(verifyLegacyFictionalDemo(fixture).entryCount===1);
});
test('V5 accepts numeric canonical source-row columns, independent of person markers',()=>{
 const p={...legacyPayload,entries:{'synthetic-key':{clientId:99900001,sourceRow:'3',usc:10,dc:0,ppPlus:1,dbPlus:0,formulas:[],description:'USC 10/ PP+'}}};
 assert.equal(verifyLegacyFictionalDemo(mapping(p)).entryCount,1);
});
test('V5 blocks realistic MercerID even if description contains a fake name',()=>{
 const p={...legacyPayload,entries:{'99900001':{...legacyPayload.entries['99900001'],clientId:'123456',description:'USC 10/ PP+; Mustermann'}}};
 assert.throws(()=>verifyLegacyFictionalDemo(mapping(p)),{code:'DEMO_MAPPING_NOT_FICTIONAL'});
});
test('V5 blocks fake person fields when identity sentinel does not match',()=>{
 const p={...legacyPayload,entries:{'99900001':{...legacyPayload.entries['99900001'],clientId:'5',firstName:'Max',lastName:'Mustermann'}}};
 assert.throws(()=>verifyLegacyFictionalDemo(mapping(p)),{code:'DEMO_MAPPING_NOT_FICTIONAL'});
});
test('V5 blocks mixed fake and realistic ID rows',()=>{
 const p={...legacyPayload,entries:{...legacyPayload.entries,private:{...legacyPayload.entries['99900001'],clientId:'43678'}}};
 assert.throws(()=>verifyLegacyFictionalDemo(mapping(p)),{code:'DEMO_MAPPING_NOT_FICTIONAL'});
});
test('V5 blocks historic fake ID with unrelated USC',()=>{
 const p={...legacyPayload,entries:{'99900001':{...legacyPayload.entries['99900001'],usc:'11'}}};
 assert.throws(()=>verifyLegacyFictionalDemo(mapping(p)),{code:'DEMO_MAPPING_NOT_FICTIONAL'});
});
test('V5 blocks arbitrary name fields even when ID is synthetic',()=>{
 const p={...legacyPayload,entries:{'99900001':{...legacyPayload.entries['99900001'],lastName:'Real Private Person'}}};
 assert.throws(()=>verifyLegacyFictionalDemo(mapping(p)),{code:'DEMO_MAPPING_LEGACY_ROW_FORMAT'});
});
test('V5 blocks unexpected private email embedded in source metadata',()=>{
 const p={...legacyPayload,source:{type:'DEMO',owner:'private.employee@company.example'}};
 assert.throws(()=>verifyLegacyFictionalDemo(mapping(p)),{code:'DEMO_MAPPING_PRIVATE_REFERENCE'});
});
test('V5 blocks malformed source row and nonbinary flag',()=>{
 for(const edit of [{sourceRow:0},{sourceRow:-2},{sourceRow:1.5},{dc:2},{ppPlus:'maybe'},{dbPlus:null}]){
  const p={...legacyPayload,entries:{'99900001':{...legacyPayload.entries['99900001'],...edit}}};
  assert.throws(()=>verifyLegacyFictionalDemo(mapping(p)),{code:'DEMO_MAPPING_LEGACY_ROW_FORMAT'});
 }
});
test('V5 blocks unverified formulas and unstructured description texts',()=>{
 for(const edit of [{formulas:['=HYPERLINK("http://example.invalid")']},{description:'USC 10/ PP+\nEmployee: Name'},{description:'Private employee record'}]) {
  const p={...legacyPayload,entries:{'99900001':{...legacyPayload.entries['99900001'],...edit}}};
  assert.throws(()=>verifyLegacyFictionalDemo(mapping(p)),{code:'DEMO_MAPPING_LEGACY_ROW_FORMAT'});
 }
});
test('V5 still validates whole legacy payload SHA, not historical transformation SHA',()=>{
 const obj=JSON.parse(fixture);
 assert.notEqual(obj.payloadSha256,HISTORIC_DEMO_MULTIROW_SHA256);
 assert.equal(verifyLegacyFictionalDemo(fixture).legacyPayloadSha256,obj.payloadSha256);
 obj.payload.entries['99900001'].usc='11';
 assert.throws(()=>verifyLegacyFictionalDemo(Buffer.from(JSON.stringify(obj))),{code:'DEMO_MAPPING_PAYLOAD_INTEGRITY'});
});
test('V5 explicit selected nameless numeric-demo fixture is still isolated',t=>{
 const base=tmp(t), other=tmp(t), selected=writeFixture(other,fixture);
 writeFixture(base,mapping({...legacyPayload,source:{type:'DEMO',name:'other simulated file'}}));
 const picked=secureDemoMapping({installRoot:base,candidate:{entries:null,demoMappingPath:selected},preloaded:new Map()});
 assert.equal(picked.integrity.entryCount,1);
 assert.deepEqual(picked.bytes,fixture);
});

test('V5 synthetic integration: nameless legacy mapping is loaded in isolated two-ticket child',async t=>{
 const base=tmp(t);const scratch=tmp(t);writeFixture(base,fixture);
 const preflight=source(base);writeFixture(scratch,preflight.bytes);
 const script=`import fs from 'node:fs';
 const x=JSON.parse(fs.readFileSync('examples/DEMO_mapping.json','utf8'));
 if(!Object.values(x.payload.entries).every(e=>String(e.clientId)==='${HISTORIC_DEMO_CLIENT_ID}' && String(e.usc)==='${HISTORIC_DEMO_USC}'))process.exit(3);
 console.log('Mapping-Datei-SHA256: ${HISTORIC_DEMO_MULTIROW_SHA256}');
 fs.writeFileSync('demo-diagnostic.json',JSON.stringify({schema:'MCR_LOCAL_RUNNER_DIAGNOSTIC_V1',mode:'DEMO',createdAt:new Date().toISOString(),loop:{processed:2},send:{verified:true},save:{verified:true},lastError:null}));`;
 const runner=path.join(scratch,'src','local-bot-recovery-20261020.mjs');fs.mkdirSync(path.dirname(runner),{recursive:true});fs.writeFileSync(runner,script);
 const hashes={'src/local-bot-recovery-20261020.mjs':sha(Buffer.from(script))};
 const result=await runControlled(scratch,'DEMO',hashes);
 assert.equal(result.exit,0);assert.equal(result.demoMultirowSha256,HISTORIC_DEMO_MULTIROW_SHA256);
 assert.equal(result.diagnostic?.loop?.processed,2);
 assert.equal(fs.existsSync(path.join(scratch,'private_data')),false);
});
