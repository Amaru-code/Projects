# MCR Level 05A.2 – Julia Mode 1 Parity v0.1.1

Independent Julia/std-lib-only candidate for the frozen LNW benchmark.
Uses the already installed Julia runtime and creates no new native candidate EXE.
Run `START_5A2_JULIA.ps1`.
