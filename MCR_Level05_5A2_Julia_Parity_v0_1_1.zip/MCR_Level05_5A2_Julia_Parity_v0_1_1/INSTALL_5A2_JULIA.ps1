[CmdletBinding()]
param(
    [string]$Level05Root = "C:\Users\Amaru-Zegarra\projects\Aktive_Projekte\New_Language_Benchmark\Level_05",
    [switch]$RunAfterInstall,
    [int]$Workers = 4
)

$ErrorActionPreference = "Stop"

$ExpectedInputSha = "5534444df25e1050e18012b78661ac6f9069f0c26d8f866c9d2344643d938c36"
$ExpectedGoldenSha = "078fdf618634632de329ebf250bede8b3a84ba7d7b604d8ec49f277ee2095e32"

$PackageRoot = $PSScriptRoot
$PayloadRoot = Join-Path $PackageRoot "payload"
$SourceCandidate = Join-Path $PayloadRoot "languages\julia\parity"
$TargetCandidate = Join-Path $Level05Root "languages\julia\parity"
$GoldenPath = Join-Path $Level05Root "data\reference\MCR_LNW_001\GOLDEN_REFERENCE.json"
$SpecPath = Join-Path $Level05Root "tools\benchmark_spec.json"
$StatePath = Join-Path $Level05Root "BENCHMARK_STATE.json"

Write-Host ""
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host " LEVEL 05A.2 - JULIA MODE 1 PARITY INSTALLER v0.1.1" -ForegroundColor Cyan
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host ""

foreach ($Required in @($Level05Root, $SourceCandidate, $GoldenPath, $SpecPath, $StatePath)) {
    if (-not (Test-Path $Required)) {
        throw "FEHLER: Erforderlicher Pfad fehlt: $Required"
    }
}

$Spec = Get-Content $SpecPath -Raw | ConvertFrom-Json
$Golden = Get-Content $GoldenPath -Raw | ConvertFrom-Json
$State = Get-Content $StatePath -Raw | ConvertFrom-Json

if ($Spec.case.id -ne "MCR_LNW_001") { throw "FEHLER: Falscher Level-05 Case." }
if ($Spec.case.input_sha256 -ne $ExpectedInputSha) { throw "FEHLER: Frozen Input SHA stimmt nicht." }
if ($Golden.certification_status -ne "PASS") { throw "FEHLER: Golden Reference ist nicht PASS." }
if ($Golden.overall_semantic_sha256 -ne $ExpectedGoldenSha) { throw "FEHLER: Golden Semantic SHA stimmt nicht." }

Write-Host "[1/6] Frozen Benchmark pruefen..." -ForegroundColor Yellow
Write-Host "      5A.1 State:   $($State.status)"
Write-Host "      Input SHA:    $ExpectedInputSha"
Write-Host "      Golden SHA:   $ExpectedGoldenSha"
Write-Host "      PASS" -ForegroundColor Green
Write-Host ""

Write-Host "[2/6] Mode-1 Policy pruefen..." -ForegroundColor Yellow
$ForbiddenPatterns = @(
    'oracle_runner',
    'runner\.oracle',
    'python\.exe',
    'LNW_DC_Pipeline_1_0_3',
    'ProcessStartInfo.*python',
    'Start-Process.*python',
    'dotnet\.exe',
    'Mcr\.Level05\.CSharp',
    'mcr_level05_rust',
    'rustc\.exe',
    'node\.exe',
    'tsc\.cmd',
    'tsc\.js',
    'java\.exe',
    'javac\.exe',
    'ruby\.exe'
)

$PolicyFiles = @(
    Get-ChildItem (Join-Path $SourceCandidate 'src') -Recurse -File | Where-Object { $_.Extension -eq '.jl' }
    Get-Item (Join-Path $SourceCandidate 'run.ps1')
)

foreach ($File in $PolicyFiles) {
    $Text = Get-Content $File.FullName -Raw
    foreach ($Pattern in $ForbiddenPatterns) {
        if ($Text -match $Pattern) {
            throw "MODE-1 POLICY FAIL: $($File.FullName) matched $Pattern"
        }
    }
}
Write-Host "      Kein Python-Oracle/C#/Rust/Node/Ruby/Java-Worker-Aufruf im Candidate-Code gefunden." -ForegroundColor Green
Write-Host ""

Write-Host "[3/6] Bestehenden Julia Parity-Ordner sichern..." -ForegroundColor Yellow
if (Test-Path $TargetCandidate) {
    $Existing = @(Get-ChildItem $TargetCandidate -Force -ErrorAction SilentlyContinue)
    if ($Existing.Count -gt 0) {
        $Stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
        $ArchiveRoot = Join-Path $Level05Root "languages\julia\_archive"
        $Backup = Join-Path $ArchiveRoot "parity_before_5A2_$Stamp"
        New-Item -ItemType Directory -Force -Path $ArchiveRoot | Out-Null
        Move-Item $TargetCandidate $Backup
        Write-Host "      Backup: $Backup"
    }
}
New-Item -ItemType Directory -Force -Path (Split-Path -Parent $TargetCandidate) | Out-Null
Copy-Item $SourceCandidate $TargetCandidate -Recurse -Force
Write-Host "      Candidate installiert: $TargetCandidate" -ForegroundColor Green
Write-Host ""

Write-Host "[4/6] Julia Candidate Source inventarisieren..." -ForegroundColor Yellow
$ManifestPath = Join-Path $TargetCandidate 'SOURCE_MANIFEST.json'
$ManifestFiles = @(
    Get-ChildItem $TargetCandidate -Recurse -File |
    Where-Object { $_.FullName -notmatch '\\build\\' -and $_.Name -ne 'SOURCE_MANIFEST.json' } |
    Sort-Object FullName |
    ForEach-Object {
        [PSCustomObject]@{
            path = $_.FullName.Substring($TargetCandidate.Length + 1).Replace('\','/')
            bytes = $_.Length
            sha256 = (Get-FileHash $_.FullName -Algorithm SHA256).Hash.ToLower()
        }
    }
)
$Manifest = [ordered]@{
    schema = 'mcr.level05.julia-parity-source.v1'
    candidate = 'julia/parity'
    version = '0.1.1'
    frozen_case = 'MCR_LNW_001'
    input_sha256 = $ExpectedInputSha
    golden_semantic_sha256 = $ExpectedGoldenSha
    files = $ManifestFiles
}
$Manifest | ConvertTo-Json -Depth 20 | Set-Content $ManifestPath -Encoding UTF8
Write-Host "      Manifest: $ManifestPath" -ForegroundColor Green
Write-Host ""

Write-Host "[5/6] Offline Build starten..." -ForegroundColor Yellow
$BuildScript = Join-Path $TargetCandidate 'build.ps1'
& $BuildScript
$BuildExit = $LASTEXITCODE
if ($BuildExit -ne 0) { throw "Julia Build fehlgeschlagen. ExitCode=$BuildExit" }

$MainJl = Join-Path $TargetCandidate 'build\publish\main.jl'
if (-not (Test-Path $MainJl)) { throw "Build erzeugte kein Julia main.jl." }

# Excel COM Preflight, ausserhalb jeder Benchmark-Messung.
$Excel = New-Object -ComObject Excel.Application
try {
    Write-Host "      Microsoft Excel COM: PASS (Version $($Excel.Version))" -ForegroundColor Green
}
finally {
    $Excel.Quit()
    [System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($Excel) | Out-Null
}
Write-Host ""

Write-Host "[6/6] Installation abgeschlossen." -ForegroundColor Yellow
Write-Host "      Julia Mode-1 Candidate: READY FOR PARITY RUN" -ForegroundColor Green
Write-Host ""

if (-not $RunAfterInstall) {
    Write-Host "Naechster Befehl:" -ForegroundColor Cyan
    Write-Host "  .\Run-Level05.ps1 -Language julia -Mode parity -Runs 1 -WarmupRuns 0 -Workers $Workers"
    Write-Host ""
    exit 0
}

Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host " STARTE ERSTEN JULIA PARITY RUN" -ForegroundColor Cyan
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host ""

Push-Location $Level05Root
try {
    $OldPreference = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        & (Join-Path $Level05Root 'Run-Level05.ps1') `
            -Language julia `
            -Mode parity `
            -Runs 1 `
            -WarmupRuns 0 `
            -Workers $Workers
        $RunExit = $LASTEXITCODE
    }
    finally {
        $ErrorActionPreference = $OldPreference
    }
}
finally {
    Pop-Location
}

$Latest = Get-ChildItem (Join-Path $Level05Root 'results\parity\julia') -Directory -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -like 'run_*' } |
    Sort-Object LastWriteTime -Descending |
    Select-Object -First 1

Write-Host ""
Write-Host "======================================================================"
Write-Host " JULIA PARITY FIRST RUN RESULT"
Write-Host "======================================================================"

if ($Latest) {
    Write-Host "Result: $($Latest.FullName)"
    $MetricsPath = Join-Path $Latest.FullName 'run_metrics.json'
    $ValidationPath = Join-Path $Latest.FullName 'validation.json'

    if (Test-Path $MetricsPath) {
        $Metrics = Get-Content $MetricsPath -Raw | ConvertFrom-Json
        Write-Host "Status:       $($Metrics.status)"
        Write-Host "Wall Clock:   $($Metrics.wall_clock_seconds) s"
        Write-Host "Peak RSS:     $($Metrics.peak_candidate_process_tree_rss_mib) MiB"
        Write-Host "Semantic SHA: $($Metrics.overall_semantic_sha256)"
    }

    if (Test-Path $ValidationPath) {
        $Validation = Get-Content $ValidationPath -Raw | ConvertFrom-Json
        foreach ($Name in @('du_master','dp_master','lnw_excel','lnw_csv')) {
            $A = $Validation.artifacts.$Name
            if ($null -ne $A) {
                Write-Host ("{0,-10} {1}" -f $Name, ($(if ($A.pass) {'PASS'} else {'FAIL'})))
            }
        }
    }

    Write-Host ""
    Write-Host "stdout: $(Join-Path $Latest.FullName 'stdout.log')"
    Write-Host "stderr: $(Join-Path $Latest.FullName 'stderr.log')"
    Write-Host "validation: $ValidationPath"
}

Write-Host "======================================================================"
Write-Host ""

exit $RunExit
