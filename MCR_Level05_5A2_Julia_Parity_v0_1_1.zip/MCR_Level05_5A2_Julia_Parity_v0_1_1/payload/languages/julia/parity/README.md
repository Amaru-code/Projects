# Level 05A.2 – Julia Mode 1 Parity v0.1.0

Independent Julia implementation of the frozen LNW DC pipeline.

- existing `julia.exe` runtime only
- Julia stdlib only; no external packages
- no generated native candidate EXE
- no Python/C#/Rust/Node/Ruby/Java worker
- Excel is used only through the existing PowerShell COM bridge for workbook I/O/recalculation

Correctness target:
`078fdf618634632de329ebf250bede8b3a84ba7d7b604d8ec49f277ee2095e32`


## v0.1.1

Windows PowerShell 5.1 compatibility fix for the Julia source/load preflight.

The v0.1.0 build used `julia -e '...println("JULIA_SOURCE_OK")...'`.
Windows native argument marshalling stripped the embedded quotes before Julia
received the expression, producing `println(JULIA_SOURCE_OK)` and therefore
`UndefVarError`.

v0.1.1 writes the preflight expression to a temporary `.jl` file and executes
that file with the existing `julia.exe`. No Julia business logic, benchmark
input, Golden Reference, validator, or runtime contract changed.
