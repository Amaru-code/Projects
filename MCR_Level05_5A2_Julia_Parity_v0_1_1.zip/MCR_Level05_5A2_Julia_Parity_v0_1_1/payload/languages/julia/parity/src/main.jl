module McrLevel05Julia

using Printf

const MARKER_PREFIXES = [">>>>", "<<<<", ">>>", "<<<", "===="]
const METADATA_LABELS = Set([
    "dateiname", "datei name", "info", "informationen", "groesse", "größe",
    "dateigroesse", "dateigröße", "typ", "dateityp", "erstellungsdatum",
    "erstellt am", "geaendert am", "geändert am", "aenderungsdatum", "änderungsdatum"
])
const KNOWN_HEADER_TERMS = Set([
    "erstellungsdatum", "vermittlerzentrale", "vermittlernummer", "kundenidentifikator",
    "kunden_identifikator", "depotnummer", "unterdepot", "wkn", "isin", "kag",
    "fondsname", "depotvariante", "anteilspreis", "waehrungpreis", "währungpreis",
    "produktart", "bestandstuecke", "bestand_stuecke", "bestandbetrag", "bestand_betrag",
    "firmenid", "dat", "wwid", "umsatzstuecke", "umsatz_stuecke", "abgerechneterpreis",
    "anlbetrag", "zahlbetrag", "umsatzart", "devisenkurs", "kursdatum", "zvf_id_alt",
    "zvu_id_alt", "eroeffnungsdatum", "währung_bestand", "waehrung_bestand",
    "schlusstag", "bonus", "status", "id-mercer"
])
const DU_PROFILE_MARKERS = Set(["umsatzstuecke", "abgerechneterpreis", "anlbetrag", "zahlbetrag", "umsatzart", "devisenkurs", "zvfidalt", "zvuidalt"])
const DP_PROFILE_MARKERS = Set(["anteilspreis", "eroeffnungsdatum", "bestandstuecke", "bestandbetrag", "waehrungbestand", "schlusstag", "idmercer"])

const ALLOWED_COMPANY_IDS = Set([
    "MERCER_0003", "MERCER_0351", "MERCER_0342", "MERCER_0352", "MERCER_0343",
    "INTELJP_0003", "INTELSK_0001", "INTELSK_0002", "INTELSK_0003", "MERCER_XXX"
])
const COMPANY_ID_COLUMN_INDEX = 25  # original zero-based index 24
const DU_TARGET_HEADERS = [
    "Erstellungsdatum", "Vermittlerzentrale", "Vermittlernummer", "Kunden_Identifikator",
    "WWID", "Depotnummer", "Unterdepot", "WKN", "ISIN", "KAG", "Fondsname", "Depotvariante",
    "UmsatzStuecke", "Abgerechneter Preis", "WaehrungPreis", "Anlbetrag", "Waehrung Anlagebetrag",
    "ZahlBetrag", "Waehrung Zahlungsbetrag", "Umsatzart", "Storno", "Produktart", "leer2", "leer3",
    "leer4", "leer5", "Antweilwert", "Waehrung_ Antweilwert", "Devisenkurs", "Kursdatum", "ZVF_ID_ALT",
    "ZVU_ID_ALT", "FirmenID", "DAT"
]
const DP_TARGET_HEADERS = [
    "Erstellungsdatum", "Vermittlerzentrale", "Vermittlernummer", "Kunden_Identifikator", "Leer1", "WWID",
    "Depotnummer", "Unterdepot", "WKN", "ISIN", "KAG", "Fondsname", "Depotvariante", "Anteilspreis",
    "Waehrung_Preis", "Eroeffnungsdatum", "Produktart", "Bestand_Stuecke", "Bestand_Betrag", "Waehrung_Bestand",
    "Schlusstag", "Bonus", "Status", "ID-Mercer", "FirmenID", "DAT"
]

clean_cell(value) = strip(replace(string(value === nothing ? "" : value), '\u00A0' => ' '))

function normalize_header(value)
    s = lowercase(clean_cell(value))
    s = replace(s, "ä"=>"ae", "ö"=>"oe", "ü"=>"ue", "ß"=>"ss")
    return replace(s, r"[^a-z0-9]+" => "")
end

function normalize_text(value)
    s = lowercase(strip(replace(string(value === nothing ? "" : value), '\u00A0'=>' ')))
    return replace(s, r"\s+" => " ")
end

const FUND_ALIASES = Dict(
    normalize_text("DWS INV.FOC.EUROPE FC") => normalize_text("DWSI-EUR.EQ.HI.CO.FC"),
    normalize_text("DWSI-EUR.EQ.HI.CO.FC Anteile") => normalize_text("DWSI-EUR.EQ.HI.CO.FC")
)
normalize_fund(value) = get(FUND_ALIASES, normalize_text(value), normalize_text(value))

function normalize_wwid(value)
    value === nothing && return ""
    if value isa Number && isfinite(Float64(value)) && trunc(Float64(value)) == Float64(value)
        return string(Int64(trunc(Float64(value))))
    end
    s = strip(string(value))
    if occursin(r"^\d+\.0$", s)
        s = s[1:end-2]
    end
    return s
end

function as_number(value)
    (value === nothing || value == "") && return 0.0
    if value isa Number
        v = Float64(value)
        return isfinite(v) ? v : 0.0
    end
    text = replace(strip(string(value)), " "=>"")
    isempty(text) && return 0.0
    comma = findlast(==(','), text)
    dot = findlast(==('.'), text)
    if comma !== nothing && dot !== nothing
        if comma > dot
            text = replace(text, "."=>"")
            text = replace(text, ","=>"."; count=1)
        else
            text = replace(text, ","=>"")
        end
    elseif comma !== nothing
        text = replace(text, "."=>"")
        text = replace(text, ","=>"."; count=1)
    end
    v = tryparse(Float64, text)
    return v === nothing || !isfinite(v) ? 0.0 : v
end

function is_distribution(value)
    t = normalize_text(value)
    return startswith(t, "ertragsaussch") && endswith(t, "ttung")
end

function profile_from_filename(name)
    stem = lowercase(strip(splitext(basename(string(name)))[1]))
    occursin(r"^du(?:$|[_\-\s])", stem) && return "du"
    occursin(r"^dp(?:$|[_\-\s])", stem) && return "dp"
    return nothing
end

function header_map(header::Vector{String})
    result = Dict{String,Int}()
    for (i,h) in enumerate(header)
        n = normalize_header(h)
        !isempty(n) && !haskey(result,n) && (result[n]=i)
    end
    return result
end

function find_index(map::Dict{String,Int}, aliases::Vector{String})
    for a in aliases
        n = normalize_header(a)
        haskey(map,n) && return map[n]
    end
    error("Required master header missing: " * join(aliases, " / "))
end

function xml_escape(value)
    s = string(value)
    s = replace(s, "&"=>"&amp;", "<"=>"&lt;", ">"=>"&gt;", "\""=>"&quot;", "'"=>"&apos;")
    return s
end

function parse_delimited_line(line::String, delimiter::Char)
    result = String[]
    field = IOBuffer()
    quoted = false
    chars = collect(line)
    i = 1
    while i <= length(chars)
        c = chars[i]
        if c == '"'
            if quoted && i < length(chars) && chars[i+1] == '"'
                print(field, '"')
                i += 1
            else
                quoted = !quoted
            end
        elseif c == delimiter && !quoted
            push!(result, String(take!(field)))
        else
            print(field, c)
        end
        i += 1
    end
    push!(result, String(take!(field)))
    return result
end

mutable struct WwidMapping
    exact::Dict{String,String}
    depot_fallback::Dict{String,String}
    conflicts::Dict{String,Set{String}}
end
WwidMapping() = WwidMapping(Dict{String,String}(), Dict{String,String}(), Dict{String,Set{String}}())

function mapping_clean(value)
    text = clean_cell(value)
    text = replace(text, r"^'+|'+$"=>"")
    occursin(r"^\d+\.0$", text) && (text = text[1:end-2])
    return text
end
normalize_depot(value) = replace(mapping_clean(value), r"\s+"=>"")

function normalize_underdepot(value)
    text = mapping_clean(value)
    isempty(text) && return ""
    digits = join([c for c in text if isdigit(c)])
    isempty(digits) && return text
    stripped = replace(digits, r"^0+"=>"")
    return isempty(stripped) ? "0" : stripped
end
normalize_mapping_wwid(value) = mapping_clean(value)

function read_bytes_text(path::String)
    bytes = read(path)
    if length(bytes) >= 3 && bytes[1:3] == UInt8[0xEF,0xBB,0xBF]
        bytes = bytes[4:end]
    end
    if valid_utf8(bytes)
        return String(bytes)
    end
    return decode_cp1252(bytes)
end

function valid_utf8(bytes::Vector{UInt8})
    i=1; n=length(bytes)
    while i<=n
        b=bytes[i]
        if b <= 0x7f
            i+=1
        elseif 0xc2 <= b <= 0xdf
            i+1<=n || return false
            (0x80 <= bytes[i+1] <= 0xbf) || return false
            i+=2
        elseif b == 0xe0
            i+2<=n || return false
            (0xa0 <= bytes[i+1] <= 0xbf && 0x80 <= bytes[i+2] <= 0xbf) || return false
            i+=3
        elseif 0xe1 <= b <= 0xec || 0xee <= b <= 0xef
            i+2<=n || return false
            (0x80 <= bytes[i+1] <= 0xbf && 0x80 <= bytes[i+2] <= 0xbf) || return false
            i+=3
        elseif b == 0xed
            i+2<=n || return false
            (0x80 <= bytes[i+1] <= 0x9f && 0x80 <= bytes[i+2] <= 0xbf) || return false
            i+=3
        elseif b == 0xf0
            i+3<=n || return false
            (0x90 <= bytes[i+1] <= 0xbf && all(x->0x80<=x<=0xbf, bytes[i+2:i+3])) || return false
            i+=4
        elseif 0xf1 <= b <= 0xf3
            i+3<=n || return false
            all(x->0x80<=x<=0xbf, bytes[i+1:i+3]) || return false
            i+=4
        elseif b == 0xf4
            i+3<=n || return false
            (0x80 <= bytes[i+1] <= 0x8f && all(x->0x80<=x<=0xbf, bytes[i+2:i+3])) || return false
            i+=4
        else
            return false
        end
    end
    return true
end

function decode_cp1252(bytes::Vector{UInt8})
    special = [
        '€','\u0081','‚','ƒ','„','…','†','‡','ˆ','‰','Š','‹','Œ','\u008D','Ž','\u008F',
        '\u0090','‘','’','“','”','•','–','—','˜','™','š','›','œ','\u009D','ž','Ÿ'
    ]
    io=IOBuffer()
    for b in bytes
        if b <= 0x7f
            print(io, Char(b))
        elseif b <= 0x9f
            print(io, special[Int(b)-0x80+1])
        else
            print(io, Char(b))
        end
    end
    return String(take!(io))
end

function load_mapping(path::String)
    text = read_bytes_text(path)
    lines = split(replace(text, "\r\n"=>"\n", "\r"=>"\n"), '\n')
    result = WwidMapping()
    (isempty(lines) || isempty(strip(lines[1]))) && return result
    header = parse_delimited_line(replace(lines[1], '\ufeff'=>""), ';')
    fields = Dict{String,Int}()
    for (i,h) in enumerate(header)
        fields[lowercase(strip(h))]=i
    end
    function fidx(names...)
        for n in names
            k=lowercase(n)
            haskey(fields,k) && return fields[k]
        end
        return 0
    end
    wwid_idx=fidx("WWID"); dep1_idx=fidx("Depot_01","Depo_01"); dep2_idx=fidx("Depot_02","Depo_02"); dep3_idx=fidx("Depot_03","Depo_03")
    any(==(0), [wwid_idx,dep1_idx,dep2_idx,dep3_idx]) && error("WWID mapping header is incomplete.")
    candidates=Dict{String,Set{String}}(); depot_candidates=Dict{String,Set{String}}()
    for line in lines[2:end]
        isempty(strip(line)) && continue
        row=parse_delimited_line(String(line), ';')
        at(i)= (1<=i<=length(row)) ? row[i] : ""
        wwid=normalize_mapping_wwid(at(wwid_idx)); isempty(wwid) && continue
        for (under,idx) in [("1",dep1_idx),("2",dep2_idx),("3",dep3_idx)]
            depot=normalize_depot(at(idx)); isempty(depot) && continue
            k=depot*"\0"*under
            push!(get!(candidates,k,Set{String}()), wwid)
            push!(get!(depot_candidates,depot,Set{String}()), wwid)
        end
    end
    for (k,s) in candidates
        if length(s)==1
            result.exact[k]=first(s)
        else
            result.conflicts[k]=s
        end
    end
    for (d,s) in depot_candidates
        length(s)==1 && (result.depot_fallback[d]=first(s))
    end
    return result
end

function resolve_mapping(m::WwidMapping, depot, underdepot, existing_wwid)
    depot_key=normalize_depot(depot); under_key=normalize_underdepot(underdepot); existing=normalize_mapping_wwid(existing_wwid)
    isempty(depot_key) && return existing
    k=depot_key*"\0"*under_key
    !isempty(under_key) && haskey(m.exact,k) && return m.exact[k]
    !isempty(under_key) && haskey(m.conflicts,k) && return existing
    haskey(m.depot_fallback,depot_key) && return m.depot_fallback[depot_key]
    return existing
end

struct TableData
    header::Vector{String}
    rows::Vector{Vector{String}}
    source_name::String
end

mutable struct TextParser
    mapping::WwidMapping
    allowed_company_ids::Set{String}
end
TextParser(mapping::WwidMapping)=TextParser(mapping, ALLOWED_COMPANY_IDS)

function detect_target_profile(parser::TextParser, source_header::Vector{String}, fallback_width::Int, source_name::String)
    fp=profile_from_filename(source_name); fp !== nothing && return fp
    normalized=Set(normalize_header(x) for x in source_header if !isempty(strip(x)))
    du_score=count(x->x in normalized, DU_PROFILE_MARKERS)
    dp_score=count(x->x in normalized, DP_PROFILE_MARKERS)
    du_score>=2 && du_score>dp_score && return "du"
    dp_score>=2 && dp_score>du_score && return "dp"
    return fallback_width>=30 ? "du" : "dp"
end

normalize_company_id(value)=uppercase(clean_cell(value))

function find_company_id_column(header::Vector{String}, width::Int, fixed::Bool)
    norm=normalize_header.(header)
    for c in ["firmenid","companyid","firmen_id","company_id"]
        idx=findfirst(==(normalize_header(c)), norm)
        idx !== nothing && return idx
    end
    fixed && COMPANY_ID_COLUMN_INDEX<=width && return COMPANY_ID_COLUMN_INDEX
    return nothing
end

function find_allowed_company_id(parser::TextParser, row::Vector{String}, preferred)
    checked=Set{Int}()
    for idx in preferred
        idx === nothing && continue
        i=Int(idx)
        (!(1<=i<=length(row)) || i in checked) && continue
        push!(checked,i)
        c=normalize_company_id(row[i]); c in parser.allowed_company_ids && return c
    end
    for i in eachindex(row)
        i in checked && continue
        c=normalize_company_id(row[i]); c in parser.allowed_company_ids && return c
    end
    return nothing
end

function header_match_score(parser::TextParser,row::Vector{String}, reference)
    row_norm=Set(normalize_header(x) for x in row if !isempty(strip(x)))
    if reference !== nothing
        ref_norm=Set(normalize_header(x) for x in reference if !isempty(strip(x)))
        return count(x->x in row_norm, ref_norm)
    end
    du_norm=Set(normalize_header.(DU_TARGET_HEADERS)); dp_norm=Set(normalize_header.(DP_TARGET_HEADERS))
    return max(count(x->x in du_norm,row_norm),count(x->x in dp_norm,row_norm))
end

function is_numeric_like(value::String)
    s=strip(value)
    return occursin(r"^[-+]?\d+(?:[.,]\d+)?$",s) || occursin(r"^\d{6,14}$",s) || occursin(r"^[A-Z]{2}\d{9,12}$",s)
end

function looks_like_header(parser::TextParser,row::Vector{String})
    cells=[clean_cell(x) for x in row if !isempty(clean_cell(x))]
    length(cells)<4 && return false
    normalized=Set(normalize_header.(cells)); known=Set(normalize_header.(collect(KNOWN_HEADER_TERMS)))
    count(x->x in known,normalized)>=3 && return true
    header_match_score(parser,cells,nothing)>=5 && return true
    alpha_cells=count(x->occursin(r"[A-Za-zÄÖÜäöüß]",x),cells)
    numeric_cells=count(is_numeric_like,cells)
    date_like_first=occursin(r"^\d{8}$",cells[1])
    (date_like_first || numeric_cells>=max(3,floor(Int,length(cells)/3))) && return false
    return alpha_cells>=max(4,floor(Int,length(cells)*0.65))
end

function build_target_mapping(source_header::Vector{String}, target_header::Vector{String})
    isempty(source_header) && return nothing
    source_index=Dict{String,Int}()
    for (i,h) in enumerate(source_header)
        n=normalize_header(h); !isempty(n) && !haskey(source_index,n) && (source_index[n]=i)
    end
    target_norm=normalize_header.(target_header)
    overlap=count(n->!isempty(n)&&haskey(source_index,n),target_norm)
    overlap<max(5,floor(Int,length(target_norm)*0.35)) && return nothing
    mapping=Vector{Union{Nothing,Int}}(undef,length(target_norm))
    for i in eachindex(target_norm)
        n=target_norm[i]
        mapping[i]=haskey(source_index,n) ? source_index[n] : (i<=length(source_header) ? i : nothing)
    end
    return mapping
end

normalize_row_width(row::Vector{String}, width::Int)=[i<=length(row) ? clean_cell(row[i]) : "" for i in 1:width]
function map_row_to_target(row::Vector{String}, target_width::Int, mapping)
    mapping===nothing && return normalize_row_width(row,target_width)
    return [begin
        s=i<=length(mapping) ? mapping[i] : nothing
        s!==nothing && 1<=s<=length(row) ? clean_cell(row[s]) : ""
    end for i in 1:target_width]
end

function pair_overlap(a::Vector{String},b::Vector{String})
    n=0
    for i in 1:min(length(a),length(b))
        !isempty(a[i]) && a[i]==b[i] && (n+=1)
    end
    n
end

function make_unique_headers(headers::Vector{String})
    counts=Dict{String,Int}(); out=String[]
    for (i,h) in enumerate(headers)
        name=clean_cell(h); isempty(name) && (name=@sprintf("Feld_%02d",i))
        c=get(counts,name,0)+1; counts[name]=c
        push!(out,c>1 ? "$(name)_$(c)" : name)
    end
    out
end

function trim_trailing_empty(row::Vector{String})
    v=clean_cell.(row)
    while !isempty(v) && isempty(v[end]); pop!(v); end
    v
end
first_nonempty(row::Vector{String})=begin
    for x in row
        c=clean_cell(x); !isempty(c) && return c
    end
    ""
end
is_empty_row(row::Vector{String})=!any(x->!isempty(clean_cell(x)),row)
is_marker_row(row::Vector{String})=begin f=lstrip(first_nonempty(row)); !isempty(f)&&any(p->startswith(f,p),MARKER_PREFIXES) end
function is_metadata_row(row::Vector{String})
    c=[clean_cell(x) for x in row if !isempty(clean_cell(x))]
    (isempty(c)||length(c)>3) && return false
    return lowercase(replace(strip(c[1]),r":$"=>"")) in METADATA_LABELS
end
remove_noise_rows(rows)= [trim_trailing_empty(r) for r in rows if begin t=trim_trailing_empty(r); !isempty(t)&&!is_marker_row(t)&&!is_metadata_row(t) end]

function split_packed_rows(rows)
    out=Vector{Vector{String}}()
    for r in rows
        c=trim_trailing_empty(r); nonempty=[x for x in c if !isempty(x)]
        if length(nonempty)==1 && count(==(';'),nonempty[1])>=3
            push!(out,clean_cell.(parse_delimited_line(nonempty[1],';')))
        else
            push!(out,c)
        end
    end
    out
end

function count_outside_quotes(line::String,delimiter::Char)
    chars=collect(line); quoted=false; countv=0; i=1
    while i<=length(chars)
        if chars[i]=='"'
            if quoted && i<length(chars) && chars[i+1]=='"'; i+=1; else; quoted=!quoted; end
        elseif chars[i]==delimiter && !quoted
            countv+=1
        end
        i+=1
    end
    countv
end

function detect_separator(content::String)
    lines=[x for x in split(replace(content,"\r\n"=>"\n","\r"=>"\n"),'\n') if !isempty(strip(x))]
    lines=lines[1:min(end,20)]
    isempty(lines)&&return nothing
    best=nothing; best_score=0
    for c in [';','\t','|',',']
        score=sum(count_outside_quotes(String(l),c) for l in lines)
        if score>best_score; best=c; best_score=score; end
    end
    return best_score>0 ? best : nothing
end

function parse_text_rows(content::String)
    sep=detect_separator(content)
    lines=split(replace(content,"\r\n"=>"\n","\r"=>"\n"),'\n')
    rows=Vector{Vector{String}}()
    for raw0 in lines
        raw=String(raw0); isempty(strip(raw))&&continue
        row=sep===nothing ? [strip(raw)] : parse_delimited_line(raw,sep)
        cleaned=clean_cell.(row); any(x->!isempty(x),cleaned)&&push!(rows,cleaned)
    end
    rows
end

function extract_table(parser::TextParser, raw_rows, fixed_target_header::Bool, apply_company_filter::Bool, source_name::String)
    rows=remove_noise_rows(split_packed_rows(raw_rows))
    if isempty(rows)
        !fixed_target_header && return TableData(String[],Vector{Vector{String}}(),source_name)
        profile=detect_target_profile(parser,String[],0,source_name)
        header=copy(profile=="du" ? DU_TARGET_HEADERS : DP_TARGET_HEADERS)
        return TableData(header,Vector{Vector{String}}(),source_name)
    end
    header_index=nothing
    for i in 1:min(30,length(rows))
        if header_match_score(parser,rows[i],nothing)>=5 || looks_like_header(parser,rows[i])
            header_index=i; break
        end
    end
    detected_source_header=header_index===nothing ? String[] : copy(rows[header_index])
    header=String[]; data_rows=Vector{Vector{String}}(); source_header=String[]; source_company_index=nothing; target_company_index=nothing; target_mapping=nothing; width=0
    if fixed_target_header
        source_width=isempty(detected_source_header) ? maximum(length.(rows)) : length(detected_source_header)
        profile=detect_target_profile(parser,detected_source_header,source_width,source_name)
        header=copy(profile=="du" ? DU_TARGET_HEADERS : DP_TARGET_HEADERS)
        data_rows=rows[(header_index===nothing ? 1 : header_index+1):end]
        width=length(header); source_header=detected_source_header
        source_company_index=find_company_id_column(source_header,length(source_header),false)
        target_company_index=find_company_id_column(header,width,true)
        target_mapping=build_target_mapping(source_header,header)
    else
        if header_index!==nothing
            header=make_unique_headers(rows[header_index]); data_rows=rows[header_index+1:end]; width=length(header)
        else
            width=maximum(length.(rows)); header=[@sprintf("Feld_%02d",i) for i in 1:width]; data_rows=rows
        end
        source_header=copy(header); source_company_index=find_company_id_column(source_header,width,false); target_company_index=source_company_index; target_mapping=nothing
    end
    normalized_header=normalize_header.(header); normalized_source_header=normalize_header.(source_header); clean_data=Vector{Vector{String}}()
    for row in data_rows
        (is_empty_row(row)||is_marker_row(row)||is_metadata_row(row))&&continue
        fitted_for_header=normalize_row_width(row,max(width,length(source_header))); row_norm=normalize_header.(fitted_for_header)
        target_overlap=pair_overlap(row_norm,normalized_header); source_overlap=pair_overlap(row_norm,normalized_source_header)
        if target_overlap>=max(4,min(8,floor(Int,width/3))) || source_overlap>=max(4,min(8,floor(Int,max(1,length(source_header))/3))) || header_match_score(parser,row,header)>=5 || (!isempty(source_header)&&header_match_score(parser,row,source_header)>=5)
            continue
        end
        company_id=nothing
        if apply_company_filter
            company_id=find_allowed_company_id(parser,row,[source_company_index,COMPANY_ID_COLUMN_INDEX]); company_id===nothing&&continue
        end
        fitted=map_row_to_target(row,width,target_mapping)
        if fixed_target_header
            idx_map=Dict{String,Int}()
            for (i,h) in enumerate(header)
                n=normalize_header(h); !isempty(n)&&(idx_map[n]=i)
            end
            wwid_idx=get(idx_map,"wwid",0); depot_idx=get(idx_map,"depotnummer",0); under_idx=get(idx_map,"unterdepot",0)
            if wwid_idx>0 && depot_idx>0
                existing=fitted[wwid_idx]; depot=fitted[depot_idx]; under=under_idx>0 ? fitted[under_idx] : ""
                fitted[wwid_idx]=resolve_mapping(parser.mapping,depot,under,existing)
            end
        end
        company_id!==nothing && target_company_index!==nothing && target_company_index<=length(fitted) && (fitted[target_company_index]=company_id)
        any(x->x!="",fitted)&&push!(clean_data,fitted)
    end
    return TableData(header,clean_data,source_name)
end

function parse_file(parser::TextParser,file_path::String)
    content=read_bytes_text(file_path); rows=parse_text_rows(content)
    return extract_table(parser,rows,true,true,basename(file_path))
end

# Minimal store-only ZIP writer used for XLSX master files.
function crc32_bytes(buf::Vector{UInt8})
    crc=UInt32(0xffffffff)
    for b in buf
        crc ⊻= UInt32(b)
        for _ in 1:8
            crc=(crc & UInt32(1))!=0 ? ((crc>>1) ⊻ UInt32(0xedb88320)) : (crc>>1)
        end
    end
    return ~crc
end
u8(s::String)=Vector{UInt8}(codeunits(s))
function put_u16(io,v); write(io,htol(UInt16(v))); end
function put_u32(io,v); write(io,htol(UInt32(v))); end

function write_store_zip(file_path::String, files)
    mkpath(dirname(file_path)); out=IOBuffer(); entries=Vector{NamedTuple}(); offset=0
    for (name,data) in files
        nameb=u8(name); crc=crc32_bytes(data); size=length(data); localio=IOBuffer()
        put_u32(localio,0x04034b50); put_u16(localio,20); put_u16(localio,0); put_u16(localio,0); put_u16(localio,0); put_u16(localio,0x0021)
        put_u32(localio,crc); put_u32(localio,size); put_u32(localio,size); put_u16(localio,length(nameb)); put_u16(localio,0); write(localio,nameb); write(localio,data)
        localbytes=take!(localio); write(out,localbytes); push!(entries,(name=name,crc=crc,size=size,offset=offset)); offset+=length(localbytes)
    end
    central_start=offset
    for e in entries
        nameb=u8(e.name); c=IOBuffer()
        put_u32(c,0x02014b50); put_u16(c,20); put_u16(c,20); put_u16(c,0); put_u16(c,0); put_u16(c,0); put_u16(c,0x0021)
        put_u32(c,e.crc); put_u32(c,e.size); put_u32(c,e.size); put_u16(c,length(nameb)); put_u16(c,0); put_u16(c,0); put_u16(c,0); put_u16(c,0); put_u32(c,0); put_u32(c,e.offset); write(c,nameb)
        cb=take!(c); write(out,cb); offset+=length(cb)
    end
    central_size=offset-central_start; eocd=IOBuffer(); put_u32(eocd,0x06054b50); put_u16(eocd,0); put_u16(eocd,0); put_u16(eocd,length(entries)); put_u16(eocd,length(entries)); put_u32(eocd,central_size); put_u32(eocd,central_start); put_u16(eocd,0); write(out,take!(eocd))
    open(file_path,"w") do f; write(f,take!(out)); end
end

function column_name(col::Int)
    s=""; c=col
    while c>0
        c-=1; s=string(Char(65+(c%26)),s); c=div(c,26)
    end
    s
end

function worksheet_xml(header::Vector{String},rows::Vector{Vector{String}})
    io=IOBuffer(); write(io,"<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>")
    function write_row(rnum,values)
        write(io,"<row r=\"$(rnum)\">")
        for (i,v0) in enumerate(values)
            v=v0===nothing ? "" : string(v0); isempty(v)&&continue; cref="$(column_name(i))$(rnum)"
            write(io,"<c r=\"$(cref)\" t=\"inlineStr\"><is><t")
            (occursin(r"^\s",v) || occursin(r"\s$",v)) && write(io," xml:space=\"preserve\"")
            write(io,">",xml_escape(v),"</t></is></c>")
        end
        write(io,"</row>")
    end
    write_row(1,header); for (i,r) in enumerate(rows); write_row(i+1,r); end
    write(io,"</sheetData></worksheet>"); String(take!(io))
end

function write_xlsx(file_path::String,sheet_name::String,header::Vector{String},rows::Vector{Vector{String}})
    content_types="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>"
    root_rels="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>"
    workbook="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"$(xml_escape(sheet_name))\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>"
    workbook_rels="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/></Relationships>"
    sheet=worksheet_xml(header,rows)
    write_store_zip(file_path,[("[Content_Types].xml",u8(content_types)),("_rels/.rels",u8(root_rels)),("xl/workbook.xml",u8(workbook)),("xl/_rels/workbook.xml.rels",u8(workbook_rels)),("xl/worksheets/sheet1.xml",u8(sheet))])
end

at(row,idx)=1<=idx<=length(row) ? row[idx] : ""
du_key(wwid,fund,movement)=wwid*"\0"*fund*"\0"*movement
dp_key(wwid,fund)=wwid*"\0"*fund

function aggregate_du(table::TableData,investment_value::Bool)
    map=header_map(table.header); wwid_idx=find_index(map,["WWID"]); fund_idx=find_index(map,["Fondsname","Fonds Name"]); movement_idx=find_index(map,["Umsatzart","Umsatz Art"]); shares_idx=find_index(map,["UmsatzStuecke","Umsatzstücke","Umsatz Stücke"])
    value_idx=investment_value ? find_index(map,["Anlbetrag","AnlBetrag","Anl Betrag","Anlagebetrag"]) : find_index(map,["ZahlBetrag","Zahlbetrag","Zahl Betrag"])
    out=Dict{String,Tuple{Float64,Float64}}(); order=String[]
    for row in table.rows
        wwid=normalize_wwid(at(row,wwid_idx)); fund=normalize_fund(at(row,fund_idx)); movement=normalize_text(at(row,movement_idx)); (isempty(wwid)||isempty(fund)||isempty(movement))&&continue
        k=du_key(wwid,fund,movement)
        if !haskey(out,k); out[k]=(0.0,0.0); push!(order,k); end
        cur=out[k]; out[k]=(cur[1]+as_number(at(row,shares_idx)),cur[2]+as_number(at(row,value_idx)))
    end
    (values=out,order=order)
end

function aggregate_dp(table::TableData)
    map=header_map(table.header); wwid_idx=find_index(map,["WWID"]); fund_idx=find_index(map,["Fondsname","Fonds Name"]); shares_idx=find_index(map,["Bestand_Stuecke","BestandStuecke","Bestand Stücke","Bestand_Stücke","Bestandstücke"]); value_idx=find_index(map,["Bestand_Betrag","BestandBetrag","Bestand Betrag"])
    out=Dict{String,Tuple{Float64,Float64}}()
    for row in table.rows
        wwid=normalize_wwid(at(row,wwid_idx)); fund=normalize_fund(at(row,fund_idx)); (isempty(wwid)||isempty(fund))&&continue
        k=dp_key(wwid,fund); cur=get(out,k,(0.0,0.0)); out[k]=(cur[1]+as_number(at(row,shares_idx)),cur[2]+as_number(at(row,value_idx)))
    end
    out
end

bridge_path()=joinpath(@__DIR__,"excel_bridge.ps1")
function run_bridge(args::Vector{String})
    p=bridge_path(); isfile(p)||error("Excel bridge missing: $p")
    cmd=Cmd(vcat(["powershell.exe","-NoProfile","-ExecutionPolicy","Bypass","-File",p],args))
    run(cmd)
end

function parse_snapshot(file_path::String)
    header_row=0; last_row=0; rows=Vector{NamedTuple}()
    for line0 in split(read(file_path,String),r"\r?\n")
        line=String(line0); isempty(line)&&continue; p=split(line,'\t';keepempty=true)
        if p[1]=="META" && length(p)>=4
            header_row=parse(Int,p[2]); last_row=parse(Int,p[4])
        elseif p[1]=="ROW" && length(p)>=13
            push!(rows,(row=parse(Int,p[2]),wwid=normalize_wwid(p[3]),prev=[as_number(x) for x in p[4:13]]))
        end
    end
    (header_row==0||last_row<=header_row)&&error("Snapshot metadata invalid")
    return (header_row=header_row,last_row=last_row,rows=rows)
end
number_text(v::Float64)=isfinite(v) ? string(v) : "0"

function run_lnw(template_path::String,du::TableData,dp::TableData,output_excel::String,output_csv::String,work_dir::String)
    mkpath(work_dir); cp(template_path,output_excel;force=true); snapshot_path=joinpath(work_dir,"excel_snapshot.tsv"); plan_path=joinpath(work_dir,"excel_plan.tsv")
    println("[LNW] Output-Template wird ueber Microsoft Excel geoeffnet ..."); run_bridge(["-Mode","Snapshot","-Workbook",output_excel,"-SnapshotPath",snapshot_path]); snap=parse_snapshot(snapshot_path)
    println("[LNW] Zielblatt erkannt: WWID-Header Zeile $(snap.header_row), letzte WWID-Zeile $(snap.last_row).")
    println("[LNW] DU wird nach WWID, Fonds und Umsatzart aggregiert ..."); du_agg=aggregate_du(du,false); purchase_agg=aggregate_du(du,true)
    println("[LNW] DP wird nach WWID und Fonds aggregiert ..."); dp_agg=aggregate_dp(dp)
    lines=String["META\t$(snap.header_row+1)\t$(snap.last_row)"]; setv(addr,val)=push!(lines,"SET\t$(addr)\t$(number_text(Float64(val)))")
    prev_to_current=[("AJ",1),("AK",2),("AL",3),("AM",4),("AN",5),("AO",6),("AP",7),("AQ",8),("AR",9),("AS",10)]
    purchase_maps=[("DWS EURORENTA","AV","AW"),("DWS INS.-ESG EO MO.M.IC","AY","AZ"),("DWSI-EUR.EQ.HI.CO.FC","BB","BC")]
    funds=[("DWSI-EUR.EQ.HI.CO.FC","CL","CM","BI","BJ"),("DWS EURORENTA","CN","CO","BK","BL"),("DWS INS.-ESG EO MO.M.IC","CP","CQ","BM","BN"),("SIEMENS EUROINVEST AKTIEN","CR","CS",nothing,nothing),("SIEMENS EUROINVEST RENTEN","CT","CU",nothing,nothing)]
    purchase_movement=normalize_text("Kauf"); realloc_movement=normalize_text("Fondsportfolioanpassung"); dist_fund=normalize_fund("DWS EURORENTA")
    println("[LNW] Schreibplan fuer AJ:CU wird erzeugt ...")
    for s in snap.rows
        isempty(s.wwid)&&continue
        for (col,i) in prev_to_current; setv("$(col)$(s.row)",s.prev[i]); end
        for (fund,sc,vc) in purchase_maps
            v=get(purchase_agg.values,du_key(s.wwid,normalize_fund(fund),purchase_movement),(0.0,0.0)); setv("$(sc)$(s.row)",v[1]); setv("$(vc)$(s.row)",v[2])
        end
        ds=0.0; dv=0.0
        for k in du_agg.order
            v=du_agg.values[k]; parts=split(k,'\0';limit=3); if length(parts)==3 && parts[1]==s.wwid && parts[2]==dist_fund && is_distribution(parts[3]); ds+=v[1]; dv+=v[2]; end
        end
        setv("BF$(s.row)",ds); setv("BG$(s.row)",dv)
        for (fund,end_s,end_v,rs,rv) in funds
            f=normalize_fund(fund)
            if rs!==nothing && rv!==nothing
                v=get(du_agg.values,du_key(s.wwid,f,realloc_movement),(0.0,0.0)); setv("$(rs)$(s.row)",v[1]); setv("$(rv)$(s.row)",v[2])
            end
            d=get(dp_agg,dp_key(s.wwid,f),(0.0,0.0)); setv("$(end_s)$(s.row)",d[1]); setv("$(end_v)$(s.row)",d[2])
        end
    end
    open(plan_path,"w") do f; write(f,join(lines,"\r\n")*"\r\n"); end
    println("[LNW] Konstanten werden geloescht, Werte geschrieben und Excel neu berechnet ..."); run_bridge(["-Mode","Apply","-Workbook",output_excel,"-PlanPath",plan_path,"-CsvPath",output_csv]); println("[LNW] Verarbeitung erfolgreich abgeschlossen.")
end

function enumerate_files(dir::String,out::Vector{String})
    for (root,dirs,files) in walkdir(dir)
        for f in files; push!(out,joinpath(root,f)); end
    end
end
function filename_date(file_path::String)
    stem=splitext(basename(file_path))[1]; vals=Int[]
    for m in eachmatch(r"(?<!\d)(20\d{6})(?!\d)",stem); push!(vals,parse(Int,m.captures[1])); end
    isempty(vals) ? 99_999_999 : vals[end]
end
function select_dp(files::Vector{String})
    length(files)<=1 && return copy(files)
    sorted=sort(copy(files);by=p->(filename_date(p),lowercase(basename(p)))); println("[DP] $(length(files)) DP-Dateien erkannt. Verwendet wird $(basename(sorted[1]))."); [sorted[1]]
end
function reserve_output_paths(source_files::Vector{String},output_dir::String)
    used=Set{String}(); map=Dict{String,String}()
    for source in source_files
        stem=splitext(basename(source))[1]; isempty(stem)&&(stem=basename(source)); candidate=joinpath(output_dir,stem*".xlsx"); counter=1
        while lowercase(candidate) in used; candidate=joinpath(output_dir,"$(stem)_$(counter).xlsx"); counter+=1; end
        push!(used,lowercase(candidate)); map[source]=candidate
    end
    map
end
function align_rows(source::TableData,master_header::Vector{String})
    source_norm=normalize_header.(source.header); master_norm=normalize_header.(master_header)
    length(source_norm)==length(master_norm) && all(source_norm .== master_norm) && return [copy(r) for r in source.rows]
    source_index=Dict{String,Int}(); for (i,n) in enumerate(source_norm); !isempty(n)&&(source_index[n]=i); end
    common=count(n->haskey(source_index,n),master_norm); common<max(4,floor(Int,length(master_norm)*0.60))&&error("Header weicht zu stark von den übrigen Dateien ab.")
    return [[begin i=get(source_index,n,0); i>0&&i<=length(row) ? row[i] : "" end for n in master_norm] for row in source.rows]
end

mutable struct Pipeline
    parser::TextParser
end
function convert_and_merge(pipe::Pipeline,profile::String,source_files::Vector{String},converted_dir::String,master_path::String,workers::Int)
    label=uppercase(profile); println("[$label] $(length(source_files)) Rohdatei(en) werden konvertiert und zusammengefuehrt ..."); mkpath(converted_dir); reservations=reserve_output_paths(source_files,converted_dir); results=Dict{String,TableData}(); errors=String[]; completed=0
    for source in source_files
        try
            table=parse_file(pipe.parser,source); write_xlsx(reservations[source],"Ziel 1",table.header,table.rows); results[source]=table; completed+=1; println("[$label] $completed/$(length(source_files)) | $(basename(source)) | Datei abgeschlossen")
        catch e
            completed+=1; msg=sprint(showerror,e); push!(errors,"$(basename(source)): $msg"); println("[$label] $completed/$(length(source_files)) | $(basename(source)) | FEHLER: $msg")
        end
    end
    successful=[s for s in source_files if haskey(results,s)]; isempty(successful)&&error("No $label source could be converted.\n"*join(errors[1:min(end,20)],"\n"))
    println("[$label] Konvertierung fertig. $(length(successful)) Datei(en) werden zum Master zusammengefuehrt ..."); header=copy(results[successful[1]].header); merged=Vector{Vector{String}}(); pos=0
    for source in successful
        pos+=1; table=results[source]
        try
            append!(merged,align_rows(table,header)); println("[$label] Merge $pos/$(length(successful)+1) | $(basename(reservations[source])) | Datei abgeschlossen | $(length(merged)) Zeilen")
        catch e
            msg=sprint(showerror,e); push!(errors,"$(basename(reservations[source])): $msg"); println("[$label] Merge $pos/$(length(successful)+1) | $(basename(reservations[source])) | FEHLER: $msg | $(length(merged)) Zeilen")
        end
    end
    write_xlsx(master_path,"Gesamtdaten",header,merged); println("[$label] Merge $(length(successful)+1)/$(length(successful)+1) | $(basename(master_path)) | Masterdatei gespeichert | $(length(merged)) Zeilen"); println("[$label] Master fertig: $(basename(master_path)) | $(length(merged)) Datenzeilen")
    return (table=TableData(header,merged,master_path),errors=errors)
end

function run_pipeline(pipe::Pipeline,options)
    isdir(options.input_dir)||error("Input directory missing: $(options.input_dir)"); isfile(options.template_path)||error("Template missing: $(options.template_path)"); mkpath(options.output_dir)
    work=joinpath(options.output_dir,"work"); convert_root=joinpath(work,"01_convert_merge"); du_converted=joinpath(convert_root,"DU"); dp_converted=joinpath(convert_root,"DP"); lnw_dir=joinpath(work,"02_LNW"); foreach(mkpath,[du_converted,dp_converted,lnw_dir])
    files=String[]; enumerate_files(options.input_dir,files); filtered=[p for p in files if !startswith(basename(p),"~\$")]; du_files=sort([p for p in filtered if profile_from_filename(basename(p))=="du"];by=p->lowercase(basename(p))); dp_all=sort([p for p in filtered if profile_from_filename(basename(p))=="dp"];by=p->lowercase(basename(p)))
    println("Quelldateien erkannt: $(length(du_files)) DU | $(length(dp_all)) DP | $(length(filtered)-length(du_files)-length(dp_all)) ignoriert"); isempty(du_files)&&error("No DU raw files found."); isempty(dp_all)&&error("No DP raw files found.")
    dp_files=select_dp(dp_all); du_master=joinpath(options.output_dir,"DU_MASTER.xlsx"); dp_master=joinpath(options.output_dir,"DP_MASTER.xlsx"); du=convert_and_merge(pipe,"du",du_files,du_converted,du_master,options.workers); dp=convert_and_merge(pipe,"dp",dp_files,dp_converted,dp_master,options.workers)
    ext=splitext(options.template_path)[2]; isempty(ext)&&(ext=".xlsm"); lnw_excel=joinpath(options.output_dir,"LNW_Output"*ext); lnw_csv=joinpath(options.output_dir,"LNW_Output.csv")
    println("[LNW] DU- und DP-Master werden an die Julia LNW-Engine uebergeben ..."); run_lnw(options.template_path,du.table,dp.table,lnw_excel,lnw_csv,lnw_dir)
    return (du_master=du_master,dp_master=dp_master,lnw_excel=lnw_excel,lnw_csv=lnw_csv,du_rows=length(du.table.rows),dp_rows=length(dp.table.rows))
end

function parse_args(argv)
    map=Dict{String,String}(); i=1
    while i<=length(argv)
        k=argv[i]; startswith(k,"--")||error("Unexpected argument: $k"); i<length(argv)||error("Missing value for $k"); map[lowercase(k)]=argv[i+1]; i+=2
    end
    need(k)=begin v=get(map,k,""); isempty(strip(v))&&error("Required argument missing: $k"); v end
    workers=max(1,something(tryparse(Int,get(map,"--workers","4")),4))
    return (case_id=get(map,"--case","MCR_LNW_001"),input_dir=abspath(need("--input")),template_path=abspath(need("--template")),output_dir=abspath(need("--output")),workers=workers)
end

function json_escape(s::String)
    s=replace(s,"\\"=>"\\\\","\""=>"\\\"","\r"=>"\\r","\n"=>"\\n","\t"=>"\\t"); s
end
jstr(s)="\"" * json_escape(string(s)) * "\""

function write_candidate_result(path::String,options,result)
    txt="""{
  \"schema\": \"mcr.level05.candidate-result.v1\",
  \"status\": \"success\",
  \"case\": $(jstr(options.case_id)),
  \"language\": \"julia\",
  \"mode\": \"parity\",
  \"artifacts\": {
    \"du_master\": $(jstr(basename(result.du_master))),
    \"dp_master\": $(jstr(basename(result.dp_master))),
    \"lnw_excel\": $(jstr(basename(result.lnw_excel))),
    \"lnw_csv\": $(jstr(basename(result.lnw_csv)))
  },
  \"diagnostics\": {
    \"du_master_rows\": $(result.du_rows),
    \"dp_master_rows\": $(result.dp_rows),
    \"workers\": $(options.workers),
    \"runtime\": $(jstr("julia "*string(VERSION)))
  }
}
"""
    open(path,"w") do f; write(f,txt); end
end

function main(argv=ARGS)
    try
        options=parse_args(argv); options.case_id=="MCR_LNW_001"||error("This candidate is frozen to case MCR_LNW_001.")
        mapping_path=joinpath(@__DIR__,"resources","wwid_mapping.csv"); isfile(mapping_path)||error("Candidate resources are missing from build output.")
        println(repeat("=",72)); println("MCR LEVEL 05A.2 - JULIA MODE 1 PARITY CANDIDATE"); println(repeat("=",72)); println("Case:    $(options.case_id)"); println("Input:   $(options.input_dir)"); println("Template:$(options.template_path)"); println("Output:  $(options.output_dir)"); println("Workers: $(options.workers)"); println()
        mkpath(options.output_dir); mapping=load_mapping(mapping_path); parser=TextParser(mapping); result=run_pipeline(Pipeline(parser),options); write_candidate_result(joinpath(options.output_dir,"candidate_result.json"),options,result)
        println(); println("Julia candidate completed successfully."); println("DU Master Rows: $(result.du_rows)"); println("DP Master Rows: $(result.dp_rows)"); println("candidate_result.json written."); return 0
    catch e
        println(stderr); println(stderr,"JULIA CANDIDATE FAILED"); showerror(stderr,e,catch_backtrace()); println(stderr); return 1
    end
end

end # module

if abspath(PROGRAM_FILE) == @__FILE__
    exit(McrLevel05Julia.main())
end
