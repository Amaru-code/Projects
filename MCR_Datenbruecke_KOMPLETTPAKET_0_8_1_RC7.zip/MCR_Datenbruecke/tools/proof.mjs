import {requireThat as need} from '../lib/core.mjs';
export function certifyDemo(d){const ps=d?.loop?.processedTickets,b=d?.demoBrowser;need(d?.mode==='DEMO'&&!d.lastError&&d.loop?.completed&&d.loop.finishReason==='NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS'&&d.loop.processed===2&&d.loop.myTasksProcessed===1&&d.loop.queueProcessed===1,'DEMO_FLOW','Vollstaendiger Demoabschluss fehlt.');need(Array.isArray(ps)&&ps.length===2&&ps[0].source==='IN_BEARBEITUNG'&&ps[1].source==='WARTESCHLANGE_INTL01'&&ps.every(p=>p.sendAck==='HISTORY_INCREMENT'&&p.sourceRowCount===2&&p.descriptionLineCount===2)&&ps[0].save==='MY_TASKS_ALL_DESCRIPTION_CONTENT_MATCH'&&ps[1].save==='QUEUE_ALL_DESCRIPTION_CONTENT_MATCH','DEMO_TICKETS','Einzelticketnachweise fehlen.');need(b?.sendClicks===2&&b?.saveClicks===2&&b.savedDescriptionsMatch===true&&['trustedSends','trustedSaves'].every(k=>Array.isArray(b[k])&&b[k].length===2&&b[k].every(v=>v===true))&&Array.isArray(b.savedLineCounts)&&b.savedLineCounts.length===2&&b.savedLineCounts.every(n=>n===2),'DEMO_BROWSER_PROOF','Echte Browserklicks/gespeicherte Beschreibungen nicht nachgewiesen.');return true;}
export function certifyPilot(d){need(d?.mode==='REAL'&&!d.lastError&&d.loop?.completed&&d.loop.finishReason==='PILOT_LIMIT_AFTER_VERIFIED_SAVE'&&d.loop.processed===1&&d.loop.myTasksProcessed+d.loop.queueProcessed===1&&d.send?.verified===true&&d.save?.verified===true&&d.loop.processedTickets?.length===1&&['HISTORY_INCREMENT','EDITOR_RESET_AFTER_CONFIRMED_DIALOGS'].includes(d.loop.processedTickets[0].sendAck)&&['MY_TASKS_ALL_DESCRIPTION_CONTENT_MATCH','QUEUE_ALL_DESCRIPTION_CONTENT_MATCH'].includes(d.loop.processedTickets[0].save),'PILOT_NOT_VERIFIED','Genau ein gesendetes und gespeichertes echtes Ticket nicht bestaetigt.');return true;}

export function certifyForwardWithoutEmail(d){
 need(d?.mode==='REAL'&&!d.lastError&&d.loop?.completed&&d.loop?.processed===1&&d.loop?.forwarded===1&&d.loop?.processedTickets?.length===1&&d.loop.processedTickets[0].type==='FORWARDED_WITHOUT_EMAIL'&&d.forward?.verified===true&&d.forward?.noEmail===true&&d.forward?.fixedFieldsVerified===true&&d.send?.clicked!==true&&d.save?.verified===true,'FORWARD_NOT_VERIFIED','Weiterleitung ohne Antwortmail nicht eindeutig nachgewiesen.');
 return true;
}

/** Both fiktive 11-prefix cases use the true browser send/save path. */
export function certifyPrefixDemo(d){
 certifyDemo(d);
 need(d?.loop?.processedTickets?.every(x=>x.lookupMethod==='PREFIX_11_REMOVED')&&d.lookup?.method==='PREFIX_11_REMOVED',
  'DEMO_PREFIX_LOOKUP','Der echte 11-Praefix-Fallback wurde nicht in beiden Tickets ausgefuehrt.');
 return true;
}
/** No reply or send action is allowed on the manual-routing scenario. */
export function certifyForwardDemo(d){
 const t=d?.loop?.processedTickets,b=d?.demoBrowser;
 need(d?.mode==='DEMO'&&!d.lastError&&d.loop?.completed&&d.loop.finishReason==='NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS'&&d.loop.processed===2&&d.loop.forwarded===2&&d.loop.myTasksProcessed===1&&d.loop.queueProcessed===1,
  'DEMO_FORWARD_FLOW','Fiktive Weiterleitung nicht vollstaendig.');
 need(Array.isArray(t)&&t.length===2&&t[0].source==='IN_BEARBEITUNG'&&t[1].source==='WARTESCHLANGE_INTL01'&&t.every(x=>x.type==='FORWARDED_WITHOUT_EMAIL'&&x.fixedFieldsVerified===true&&['MY_TASKS_ALL_DESCRIPTION_CONTENT_MATCH','QUEUE_ALL_DESCRIPTION_CONTENT_MATCH'].includes(x.save)),
  'DEMO_FORWARD_DETAILS','Weiterleitungs-, Speicher- oder Pflichtfeldnachweis fehlt.');
 need(b?.sendClicks===0&&b?.saveClicks===2&&b?.forwardClicks===2&&b?.savedMissingDescriptionsMatch===true&&Array.isArray(b.trustedForwards)&&b.trustedForwards.length===2&&b.trustedForwards.every(Boolean)&&Array.isArray(b.trustedSaves)&&b.trustedSaves.length===2&&b.trustedSaves.every(Boolean),
  'DEMO_FORWARD_BROWSER','Exakt zwei echte Weiterleitungs-/Speicherklicks OHNE E-Mail nicht nachgewiesen.');
 return true;
}

/** Fictional no-recognizable-name mail MUST take the confirmed operator path. */
export function certifyManualNameDemo(d){
 certifyDemo(d);
 need(d?.personSource==='MANUAL_OPERATOR_CONFIRMED_DEMO'&&d?.manualNameConfirmations===2&&d?.mailSource==='HISTORY_DOM'&&d?.send?.verified===true&&d?.save?.verified===true,
  'DEMO_MANUAL_NAME_NOT_VERIFIED','Fiktiver manueller Namens-Fallback und anschliessende Member/Send/Save-Pruefung fehlen.');
 return true;
}
