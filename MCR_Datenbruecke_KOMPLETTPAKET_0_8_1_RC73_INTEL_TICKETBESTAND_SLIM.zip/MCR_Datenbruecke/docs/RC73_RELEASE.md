# RC73 – Transparenter Intel-Ticketbestand und kontrollierte Phase-2-Zulassung

## Ziel und Grenzen

Nach RC72 konnte ein MBC-Ticket sicher zu Mark Baindl weitergeleitet werden. Weitere sichtbare Intel-Tickets blieben aufgrund offener Phase-1-Versandjournale, unklarem Standardantwort-Marker oder fehlenden USC-/Planwerten stehen. Eine rohe Anzahl an MBC- oder DB-Tickets ist kein Nachweis, dass diese Fälle bereits zulässig bearbeitet werden dürfen.

RC73 trennt **Vorgang gefunden** von **bearbeitbar** und erzeugt pro Ticket eine nachvollziehbare Zulassungsentscheidung. Der neue Menüpunkt 14 liest die **eigene** Intel-Liste `In_Bearbeitung` und die **separate** Warteschlange `INTL01` ohne Ticketaktionen; die Warteschlange wird nur als separate Anzeige erfasst, nicht als bereits zugewiesene Phase-2-Arbeit behandelt. Beide Ansichten werden nur über ihre exakt erlaubten Unterpunkte aufgerufen. Fremde Unternehmensgruppen können keine Phase-2-Aktionen auslösen.

## Bedienung

* `START.cmd` aus diesem separaten ZIP -> Menü 1 -> RC72 in bestehender Installation auf RC73 aktualisieren. `private_data`, `.runtime`, Mapping, Browserprofil und Archiv bleiben erhalten.
* In **installierter** START.cmd -> **Menü 14** -> `START`: ausschließlich lesende Intel-Bestandsdiagnose. Das JSON liegt unter `.runtime\phase2\MCR_PHASE2_TICKETBESTAND_LETZTE.json`. Es enthält Ticket-ID, Regel, Prüfstufe und Sperrgrund, keine vollständigen Personen-/Nachrichtentexte.
* Menü 12 verarbeitet weiterhin nur sicher freigegebene eigene Phase-2-Tickets. Nach jedem Abschluss prüft der Bot seine Liste neu, dokumentiert den Bestand und nennt vor dem Ende konkrete Gründe für die übrigen sichtbaren Fälle.
* Menü 13 ruft die vorhandenen gesicherten Phase-1- und Phase-2-Bearbeiter weiter auf. Keine pauschale Entsperrung alter SEND_INTENT-Fälle.

## Automatisch freigegeben versus gesperrt

Ein alter SEND_INTENT wird nur dann als abgeschlossen verbucht, wenn bereits die bestehenden, strengen Bedingungen erfüllt sind: unveränderter ursprünglicher SHA, exakter Servertext, eindeutig passende ausgehende Standardantwort, richtige Absender/Empfänger, Gesprächs-/Ticketbindung und genau ein eindeutiger Ausgang. Fehlender Status darf nur nach einer belegten Sendung und einem ausdrücklich dokumentierten einzigen Speicher-Vorsatz nachgetragen werden. Ohne diese Belege bleibt die Sperre erhalten und RC73 nennt den Strukturgrund.

Ein `DB_DIRECT`-Eintrag ohne Sperre nutzt den vorhandenen Mark-Baindl-Ablauf; `MBC_PRIVATE_EMAIL` und Kontoauszug nutzen ihre alten Review-/PDF-Regeln. Neue, unbekannte fachliche Anfragen werden nicht automatisch beantwortet. Die Anzeige erfasst **sichtbare Seiten**; Pagination kann derzeit nicht als vollständig inventarisiert gelten. Die separate INTL01-Warteschlange kann zusätzliche Fälle enthalten, die nicht ohne Zuweisung/Phase-1-Beweis als eigene Phase-2-Tickets gelten. Ein echter COMARCH-RC73-Durchlauf steht aus.
