# MCR DATENBRUECKE 0.8.1-rc.73

Kompaktes vollstaendiges Softwarepaket (KEINE produktiven Bestandsdaten enthalten). Fuer die Bestandsinstallation dieses ZIP separat entpacken -> `START.cmd` -> Menue 1. Anschliessend nur die **installierte** `START.cmd` starten.

**RC73:** Ticketgenaue Intel-Inventur vor Phase 2. Neues Menue 14 prueft `In_Bearbeitung` und `INTL01` nur lesend; Menue 12 protokolliert bei jedem Durchlauf fuer alle sichtbaren eigenen Tickets die Bearbeitbarkeit und den genauen Sperrgrund. Andere Gruppen werden nicht als Intel-Fall bearbeitet. Kein Aufweichen alter Versandjournale, kein automatischer Doppelversand, keine unbekannten fachlichen Antworten.

Vollstaendige Hinweise und Grenzen: `docs/RC73_RELEASE.md`. Alte lokale `.runtime`-/`private_data`-Daten, Bestandsmapping, Browserprofil und Rueckweg-Archiv werden beim Softwareupdate nicht veraendert.
