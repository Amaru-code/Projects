/** RC73 operator-only read-only intake inventory for the two explicitly
 * permitted Intel scopes. INTL01 queue entries are NOT auto-forwarded from
 * Phase 2 and are never treated as assigned personal tasks. */
import fs from 'node:fs';
import path from 'node:path';
import readline from 'node:readline/promises';
import {requireThat as need} from '../lib/core.mjs';
import {readJSON,writeJSON,ledger,stamp,plainPath,VERSION} from '../lib/control.mjs';
import {resolveConfig} from '../lib/config.mjs';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachFreshPage} from '../lib/cdp.mjs';
import * as UI from '../lib/browser-workflow.mjs';
import {readPhase2Queue} from '../lib/phase2-readonly.mjs';
import {inspectPhase2Tickets} from '../lib/phase2-intake-audit.mjs';

export async function phase2ReadOnlyInventory({root,page:provided=null,askFn=null,log=console.log}={}){
 const dir=path.join(root,'.runtime','phase2');fs.mkdirSync(dir,{recursive:true});plainPath(dir);
 const rl=readline.createInterface({input:process.stdin,output:process.stdout});
 const ask=askFn||((q)=>rl.question(q));let browser,cdp;
 try{
  need(String(await ask('INTEL-BESTAND NUR LESEN: Beide erlaubten Ansichten einsehen, KEIN Versand/Speichern/Weiterleiten. START / ABBRUCH: ')).trim().toUpperCase()==='START',
   'P2_AUDIT_ABORT','Keine Inventur ausgefuehrt.');
  let page=provided;
  if(!page){const cfg=resolveConfig(root),exe=findEdgeExecutable(cfg.edgePath);need(exe,'P2_EDGE','Edge fehlt.');
   browser=await launchBrowser({executable:exe,userDataDir:cfg.profileDirectory,startUrl:'about:blank'});
   ({cdp}=await connectBrowser(browser.port));page=await attachFreshPage(cdp,cfg.comarchUrl);
  }
  await UI.navigateToScope(page,'IN_BEARBEITUNG',{startup:true});
  const own=await readPhase2Queue(page);need(own.ok,'P2_AUDIT_OWN_SCOPE',own.reason||'Intel-Eigenliste nicht lesbar.');
  const getJournal=(prefix,id)=>{const f=path.join(dir,'actions',prefix+id+'.json');return fs.existsSync(f)?readJSON(f,128*1024):null;};
  const audit=inspectPhase2Tickets(own.rows,{pending:ledger(root).pending,
   getPdfJournal:id=>getJournal('MCR_PHASE2_',id),getWorkJournal:id=>getJournal('MCR_PHASE2_WORK_',id)});
  const q={scope:'WARTESCHLANGE_INTL01_VISIBLE_PAGE_ONLY',status:'NOT_CHECKED',visibleRows:null,
   note:'INTL01 ist eine andere Warteschlangenliste, nicht automatisch eigene Phase-2-Tickets.'};
  try{
   await UI.navigateToScope(page,'WARTESCHLANGE_INTL01',{refresh:true});
   const view=await UI.queueTableSnapshot(page);
   if(view.ok&&view.scope==='WARTESCHLANGE_INTL01'&&await UI.activeIntelScope(page,'WARTESCHLANGE_INTL01')){
    q.status='BOUND_VISIBLE_PAGE';q.visibleRows=view.rows.length;
   }else q.status='NOT_UNAMBIGUOUSLY_BOUND';
  }catch(e){q.status='INTL01_SCOPE_UNAVAILABLE';q.reason=e.code||'NAVIGATION_FAILED';}
  const report={...audit,generatedAt:new Date().toISOString(),version:VERSION,
   pageCoverage:'VISIBLE_ROWS_ONLY_NO_PAGINATION_ASSUMPTION',intelQueue:q};
  const named=path.join(dir,'MCR_PHASE2_TICKETBESTAND_'+stamp()+'.json');
  writeJSON(named,report);writeJSON(path.join(dir,'MCR_PHASE2_TICKETBESTAND_LETZTE.json'),report);
  log('P2_BESTAND_NUR_LESEN: Eigene Intel-Tickets dieser sichtbaren Seite='+audit.counts.visible+
   ' | Bereit='+audit.counts.ready+' | Wiederaufnahme='+audit.counts.resume+
   ' | Alter Versand pruefbar='+audit.counts.phase1EvidenceToCheck+
   ' | Alte Journale blockiert='+audit.counts.phase1Blocked+
   ' | Weitere Pruefungen='+audit.counts.reviewBlocked+
   ' | Unbekannte Regeln='+audit.counts.unsupported);
  for(const item of audit.items)log('P2_TICKETSTATUS: '+item.ticketId+' | '+item.rule+' | '+item.stage+' | '+item.reason);
  log('P2_INTL01_WARTESCHLANGE: '+q.status+(q.visibleRows===null?'':' | Zeilen dieser Seite='+q.visibleRows)+
   ' | NICHT als eigene Phase-2-Tickets gewertet.');
  log('P2_BESTANDSBERICHT: '+named);
  return report;
 }finally{rl.close();try{cdp?.close();}catch{}try{browser?.child?.kill();}catch{}}
}
