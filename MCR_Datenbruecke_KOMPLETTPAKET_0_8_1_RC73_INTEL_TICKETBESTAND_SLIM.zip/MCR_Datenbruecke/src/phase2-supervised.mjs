/** RC34 separate Phase-2 operator workflow. All COMARCH access is read-only.
 * PDF generation remains with the user's existing interactive programs.
 */
import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import readline from 'node:readline/promises';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachFreshPage} from '../lib/cdp.mjs';
import {resolveConfig} from '../lib/config.mjs';import {loadActiveMapping} from '../lib/active-mapping.mjs';import {plainPath,writeJSON,readJSON,stamp,ledger} from '../lib/control.mjs';
import {requireThat as need} from '../lib/core.mjs';import * as UI from '../lib/browser-workflow.mjs';
import {phase2Inventory,readPhase2Queue,readPhase2DetailContract} from '../lib/phase2-readonly.mjs';
import {phase2DraftPreview} from '../lib/phase2-draft-preview.mjs';
import {localGeneratorInventory,generatorPaths,inspectExistingStatements,discoverPdfWwid,approvedPerson,approvedWwid} from '../lib/phase2-pdf-evidence.mjs';
import {readPhase2MemberEvidence} from '../lib/phase2-member-evidence.mjs';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const printed=s=>console.log(s);
async function question(rl,text){return String(await rl.question(text)).trim();}
function reportDir(root){const d=path.join(root,'.runtime','phase2');fs.mkdirSync(d,{recursive:true});plainPath(d);return d;}
function save(root,name,value){const f=path.join(reportDir(root),name);writeJSON(f,value);printed('LOKALER_BERICHT: '+f);return f;}
export async function inventoryLive({root=ROOT,ask=question,log=printed}={}){
 // Require the installed/activated datastore before opening the production profile.
 loadActiveMapping(root);
 const cfg=resolveConfig(root);let browser=null,cdp=null;
 const rl=readline.createInterface({input:process.stdin,output:process.stdout});let leaveOpen=false;
 try{
  const exe=findEdgeExecutable(cfg.edgePath);need(exe,'P2_EDGE_NOT_FOUND','Edge/Chromium fehlt.');
  log('\nPHASE2 COMARCH INVENTUR – KEINE BEARBEITUNG, KEIN VERSAND, KEINE WEITERLEITUNG.');
  browser=await launchBrowser({executable:exe,userDataDir:cfg.profileDirectory,startUrl:'about:blank'});
  ({cdp}=await connectBrowser(browser.port));const page=await attachFreshPage(cdp,cfg.comarchUrl);
  log('Im Bot-Edge anmelden, falls erforderlich. Danach im Terminal START eingeben.');
  need((await ask(rl,'Nur-Lese-Inventur START / ABBRUCH: ')).toUpperCase()==='START','P2_INVENTORY_ABORT','Inventur abgebrochen.');
  await UI.navigateToScope(page,'IN_BEARBEITUNG',{startup:true});
  const raw=await readPhase2Queue(page);need(raw.ok,'P2_QUEUE_READ',raw.reason||'Tabelle nicht lesbar.');
  const pendingIds=ledger(root).pending.map(x=>x.ticketId);
  const result=phase2Inventory(raw.rows,{pendingIds});
  const report={...result,uiSource:'EXACT_MY_TASKS_TABLE',checks:{originalMailNotYetVerified:true,identityNotYetVerified:true,wwidNotYetVerified:true},detail:null};
  log('PHASE2_INVENTUR: '+raw.rows.length+' Tickets in Meine Vorgaenge; '+report.candidates+' Kontoauszug-Kandidaten/Prueffaelle.');
  for(const item of report.items.filter(x=>x.kind!=='NOT_KONTOAUSZUG')){
   log(`TICKET ${item.ticketId} | ${item.kind} | Quelle=${item.source||'(leer)'} | ${item.targets.join('+')||'-'} | ${item.reason}`);
  }
  // Inspect one requested ticket without pressing Bearbeiten / Entwurf speichern.
  const choice=await ask(rl,'Ticket-ID fuer UI-Detailpruefung (ENTER=ueberspringen): ');
  if(choice){const selected=raw.rows.find(x=>x.ticketId===choice);need(selected,'P2_TICKET_NOT_IN_QUEUE','Ticket nicht in dieser Live-Liste.');
   await UI.openTicket(page,selected,{scope:'IN_BEARBEITUNG'});await UI.assertTicket(page,choice);report.detail={ticketId:choice,ui:await readPhase2DetailContract(page)};
   log('PHASE2_UI_READ_ONLY '+choice+': '+JSON.stringify(report.detail.ui));
  }
  const stored=save(root,'MCR_PHASE2_LETZTE_INVENTUR.json',report);
  save(root,'MCR_PHASE2_INVENTUR_'+stamp()+'.json',report);
  log('PASS PHASE2_INVENTORY_READ_ONLY; KEINE Ticketaktion, KEIN BAT-Start.');
  const a=(await ask(rl,'Bot-Edge schliessen ENTER / OFFEN zur Kontrolle: ')).toUpperCase();leaveOpen=a==='OFFEN';
  if(leaveOpen)log('Bot-Edge bleibt offen. Vor einem weiteren Lauf manuell schliessen.');
  return {count:report.candidates,file:stored};
 }finally{rl.close();try{cdp?.close();}catch{}if(leaveOpen){try{browser?.child?.unref();}catch{}}else try{browser?.child?.kill();}catch{}}
}
export function generatorPreflight({root=ROOT,log=printed}={}){
 const report=localGeneratorInventory(root),file=save(root,'MCR_PHASE2_GENERATOR_PREFLIGHT_'+stamp()+'.json',report);
 for(const p of report.plans){log(`GENERATOR ${p.plan} | BAT ${p.scriptPresent?'VORHANDEN':'FEHLT'} | PDF-Ordner ${p.outputPresent?'VORHANDEN':'FEHLT'} | vorhandene PDFs=${p.existingPdfCount} | Eingabe=${p.operatorInputHint}`);
  log('  '+p.start);
 }
 log('PASS PHASE2_GENERATORS_READ_ONLY: Keine BAT gestartet. Eingabe-Vertrag noch nicht freigegeben.');return file;
}
/** RC37: one ticket number, read-only Member lookup, one final content review.
 * Existing correctly named PDFs are accepted for preview without re-running
 * their creators. No COMARCH writes / attachment / forwarding permitted.
 */
export async function manualPdfPilot({root=ROOT,ask=question,log=printed,memberLookup=readPhase2MemberEvidence}={}){
 const inventory=path.join(reportDir(root),'MCR_PHASE2_LETZTE_INVENTUR.json');
 need(fs.existsSync(inventory),'P2_INVENTORY_REQUIRED','Zuerst Menue 9 ausfuehren.');
 const source=readJSON(inventory,2*1024*1024);
 need(source.schema==='MCR_PHASE2_INVENTORY_V1'&&source.readOnly&&Array.isArray(source.items),'P2_INVENTORY_INVALID','Inventur unlesbar.');
 need(Date.now()-Date.parse(source.generatedAt)<60*60*1000,'P2_INVENTORY_EXPIRED','Inventur aelter als eine Stunde; Menue 9 erneut starten.');
 const rl=readline.createInterface({input:process.stdin,output:process.stdout});
 let browser=null,cdp=null;
 try{
  const id=await ask(rl,'Kontoauszug-Ticket-ID: '),item=source.items.find(x=>x.ticketId===id);
  need(item?.kind==='NEEDS_VERIFIED_WWID','P2_TICKET_NOT_READY','Ticket ist nicht als eindeutiger Kontoauszug-Kandidat registriert.');
  log('TICKET '+id+' | Plaene '+item.targets.join('+')+' | Quelle '+item.source+' – keine Bearbeitung von COMARCH.');
  // Read from the REAL current ticket, not from a cached inventory row.
  loadActiveMapping(root);
  const cfg=resolveConfig(root),exe=findEdgeExecutable(cfg.edgePath);
  need(exe,'P2_EDGE_NOT_FOUND','Edge/Chromium fehlt.');
  browser=await launchBrowser({executable:exe,userDataDir:cfg.profileDirectory,startUrl:'about:blank'});
  ({cdp}=await connectBrowser(browser.port));const page=await attachFreshPage(cdp,cfg.comarchUrl);
  log('Bot-Edge: gegebenenfalls anmelden. Danach START eingeben.');
  need((await ask(rl,'COMARCH bereit? START / ABBRUCH: ')).toUpperCase()==='START','P2_OPERATOR_ABORT','Ohne COMARCH-Ansicht keine Identitaet.');
  await UI.navigateToScope(page,'IN_BEARBEITUNG',{startup:true});
  const raw=await readPhase2Queue(page);need(raw.ok,'P2_QUEUE_READ',raw.reason||'COMARCH-Liste nicht lesbar.');
  const live=raw.rows.find(x=>x.ticketId===id);
  need(live,'P2_TICKET_NOT_IN_QUEUE','Ticket ist nicht mehr in Meine Vorgaenge.');
  const fresh=phase2Inventory([live],{pendingIds:ledger(root).pending.map(x=>x.ticketId)}).items[0];
  need(fresh.kind==='NEEDS_VERIFIED_WWID'&&fresh.descriptionValue===item.descriptionValue,
   'P2_TICKET_CHANGED','Tickettext/Status seit Inventur veraendert. Bitte Menue 9 erneut pruefen.');
  await UI.openTicket(page,live,{scope:'IN_BEARBEITUNG'});await UI.assertTicket(page,id);
  const member=await memberLookup(page);
  log('COMARCH-MEMBER: '+(member.profileVerified?'Profilname gelesen':'Profil nicht eindeutig')+'; WWID: '+(member.wwid?'als beschriftetes Feld gelesen':'nicht eindeutig im Profil gefunden'));
  // The file name supplies only a WWID CANDIDATE, never an independent
  // person-to-WWID link. An operator must review the PDF contents.
  const fileWwid=discoverPdfWwid(root,item.targets);
  need(!member.wwid||!fileWwid||member.wwid===fileWwid,'P2_WWID_CONFLICT','COMARCH-WWID und PDF-Dateinamen widersprechen sich.');
  let wwId=member.wwid||fileWwid;
  if(!wwId)wwId=approvedWwid(await ask(rl,'WWID nicht eindeutig. Einmalig verifizierte WWID eingeben (ABBRUCH moeglich): '));
  const origin=member.wwid?'EXPLICIT_COMARCH_FIELD':fileWwid?'MATCHING_PDF_FILENAMES':'OPERATOR_ENTRY';
  // No typing first/last from memory. They are shown only when verified by COMARCH.
  log('WWID: '+wwId+' ['+origin+']'+(member.profileVerified?' | Name: '+member.profile.first+' '+member.profile.last:''));
  const result=inspectExistingStatements(root,item.targets,wwId,member.profileVerified?{first:member.profile.first,last:member.profile.last}:{});
  for(const a of result.artifacts)log('PDF '+a.plan+': '+a.name+' | '+a.bytes+' Bytes | SHA256 '+a.sha256);
  log('WICHTIG: Dateiname und PDF-Struktur beweisen NICHT den Inhalt oder die Berechtigung.');
  log('Beide PDFs im Originalordner oeffnen und mit dem aktuellen COMARCH-Ticket vergleichen.');
  need((await ask(rl,'Originalticket, Standardantwort-Verlauf, Person, WWID, Zeitraum und beide PDFs kontrolliert? JA / ABBRUCH: ')).toUpperCase()==='JA',
   'P2_CONTENT_REVIEW_REQUIRED','Keine Freigabe ohne eigene Sichtpruefung.');
  // After the review, verify file has not changed since its hash was captured.
  const freshFiles=inspectExistingStatements(root,item.targets,wwId,member.profileVerified?{first:member.profile.first,last:member.profile.last}:{});
  need(result.artifacts.every((a,i)=>a.sha256===freshFiles.artifacts[i].sha256),'P2_PDF_MUTATED','PDF seit Inhaltspruefung veraendert.');
  const proof={...freshFiles,ticketId:id,wwidOrigin:origin,memberProfileVerified:member.profileVerified,
   operatorContentReviewed:true,operatorPersonTicketBindingReviewed:true,operatorNameOnlyRecheckCompleted:false,
   automaticAttachmentAuthorized:false,comarchStatus:'NOT_ATTACHED_NOT_SAVED_NOT_FORWARDED'};
  save(root,'MCR_PHASE2_PDF_BELEG_'+id+'_'+stamp()+'.json',proof);
  const draft=phase2DraftPreview({ticketId:id,source:item.source,description:item.descriptionValue,pdfProof:proof});
  save(root,'MCR_PHASE2_ENTWURF_VORSCHAU_'+id+'_'+stamp()+'.json',draft);
  log('PASS P2_EXISTING_PDFS_VERIFIED | '+id+' | '+item.targets.join('+')+' | 4. Zeile nur Vorschau, KEIN COMARCH-Upload.');
  return proof;
 }finally{rl.close();try{cdp?.close();}catch{}try{browser?.child?.kill();}catch{}}
}
