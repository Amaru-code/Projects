/** RC52 supervised sequential Phase-2 run. One browser, one action per ticket.
 * Refreshes the actual task list before each item. Unrecognized/unprepared
 * work is skipped, not guessed. Any uncertain write stops the entire run. */
import fs from 'node:fs';import path from 'node:path';import readline from 'node:readline/promises';
import {requireThat as need} from '../lib/core.mjs';
import {writeJSON,readJSON,plainPath,ledger,stamp,VERSION} from '../lib/control.mjs';
import {loadActiveMapping} from '../lib/active-mapping.mjs';import {resolveConfig} from '../lib/config.mjs';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachFreshPage} from '../lib/cdp.mjs';
import * as UI from '../lib/browser-workflow.mjs';
import {readPhase2Queue,phase2Inventory} from '../lib/phase2-readonly.mjs';
import {phase2WorkRule} from '../lib/phase2-work-rules.mjs';
import {phase2HandoffAudit,phase2HandoffDescription,phase2IntakeSummary} from '../lib/phase2-handoff.mjs';
import {openPhase2Ticket} from '../lib/phase2-navigation.mjs';
import {completeVerifiedPhase1Handoff,beginVerifiedPhase1StatusRepair,finishVerifiedPhase1StatusRepair} from '../lib/phase2-handoff-ledger.mjs';
import {commitDescription} from '../lib/trusted-description.mjs';
import {savePhase2Ticket} from '../lib/phase2-comarch-actions.mjs';
import {watchPhase2Save} from '../lib/phase2-save-settle.mjs';
import {readPhase2MemberEvidence} from '../lib/phase2-member-evidence.mjs';
import {phase2ComarchPilot,preflightPhase2Write} from './phase2-comarch-pilot.mjs';
import {createPhase2TicketConsole} from '../lib/phase2-ticket-console.mjs';
import {capturePhase2RouteList} from '../lib/phase2-route-receipt.mjs';
import {handlePhase2Work} from './phase2-work-handler.mjs';
import {inspectPhase2Tickets} from '../lib/phase2-intake-audit.mjs';

export function choosePhase2Candidate(rows,{visited=new Set(),blockedIds=[],getPdfJournal=()=>null,getWorkJournal=()=>null,accountReady=()=>true}={}){
 const blocked=new Set(blockedIds.map(String)),skipped=[];
 for(const row of rows){
  const id=row.ticketId;if(visited.has(id))continue;
  if(row.intelGroupVerified===false){skipped.push({ticketId:id,reason:'OUTSIDE_INTEL_GROUP'});continue;}
  if(blocked.has(id)){skipped.push({ticketId:id,reason:'UNRESOLVED_PHASE1_JOURNAL'});continue;}
  const pdf=getPdfJournal(id),work=getWorkJournal(id);
  if(pdf&&work){skipped.push({ticketId:id,reason:'CONFLICTING_PHASE2_JOURNALS'});continue;}
  if(pdf?.state==='ROUTED_VERIFIED'||work?.state==='ROUTED_VERIFIED')continue;
  if(pdf){
   if(accountReady(id))return {row,kind:'ACCOUNT_STATEMENT',skipped};
   skipped.push({ticketId:id,reason:'PDF_JOURNAL_NOT_RESUMABLE'});continue;
  }
  if(work){
   const postDraft=!!(work.draft&&['DRAFT_SAVE_VERIFIED','EDIT_VERIFIED'].includes(work.state)&&work.events?.some(e=>e.state==='DRAFT_SAVE_VERIFIED')&&!work.events?.some(e=>e.state==='TICKET_SAVE_INTENT'));
   if((['TICKET_SAVE_INTENT','TICKET_SAVE_VERIFIED','REVIEW_INTENT','REVIEW_VERIFIED'].includes(work.state)||postDraft)&&
    (String(row.descriptionValue).trim()===String(work.descriptionAfter).trim()||((work.state==='TICKET_SAVE_INTENT'||postDraft)&&String(row.descriptionValue).trim()===String(work.descriptionBefore).trim())))return {row,kind:work.rule,skipped};
   skipped.push({ticketId:id,reason:'WORK_JOURNAL_REVIEW_REQUIRED'});continue;
  }
  const rule=phase2WorkRule(row);
  if(['DB_DIRECT','MBC_PRIVATE_EMAIL'].includes(rule.kind))return {row,kind:rule.kind,skipped};
  if(rule.kind==='ACCOUNT_STATEMENT'){
   if(accountReady(id))return {row,kind:rule.kind,skipped};
   skipped.push({ticketId:id,reason:'PDF_PROOF_REQUIRED_OR_STALE'});
  }else skipped.push({ticketId:id,reason:rule.reason||rule.kind});
 }
 return {row:null,kind:null,skipped};
}

export async function phase2Run({root,askFn=null,log=console.log,maxTickets=100,session=null,memberLookup=readPhase2MemberEvidence,consoleFactory=createPhase2TicketConsole}={}){
 need(Number.isInteger(maxTickets)&&maxTickets>=1&&maxTickets<=100,'P2_RUN_LIMIT','Maximal 100 Tickets pro Lauf.');
 const active=loadActiveMapping(root),rl=session?.rl||readline.createInterface({input:process.stdin,output:process.stdout});
 const dir=path.join(root,'.runtime','phase2');fs.mkdirSync(dir,{recursive:true});plainPath(dir);
 const runId=stamp(),logFile=path.join(dir,'MCR_PHASE2_LAUF_'+runId+'.log');
 fs.writeFileSync(logFile,'MCR '+VERSION+' PHASE2\n',{flag:'wx',mode:0o600});
 let controls=null,currentTicket=null,restoreInput=null;
 const say=s=>{if(currentTicket&&controls)controls.update({phase:String(s).slice(0,220)});log(s);fs.appendFileSync(logFile,String(s)+'\n',{mode:0o600});};
 const ask=async q=>{const a=String(await (askFn?askFn(rl,q):rl.question(q))).trim();fs.appendFileSync(logFile,q+a+'\n',{mode:0o600});return a;};
 let browser,cdp;const visited=new Set(),receipts=[],skipRecords=new Map(),handoffChecked=new Set(),handoffReceipts=[];
 try{
  say('PHASE 2: Kontoauszug, DB/DB+ direkt an Mark, privater MBC-Login als Entwurf zur Pruefung. KEINE E-MAIL.');
  const first=await ask('Start-Ticket (z.B. 87278094), ENTER = alle passenden sichtbaren eigenen Vorgaenge: ');
  need(first===''||/^\d{6,12}$/.test(first),'P2_TICKET_ID','Ticketnummer oder ENTER erforderlich.');
  let page=session?.page;
  if(!page){
   const cfg=resolveConfig(root),exe=findEdgeExecutable(cfg.edgePath);need(exe,'P2_EDGE','Edge fehlt.');
   browser=await launchBrowser({executable:exe,userDataDir:cfg.profileDirectory,startUrl:'about:blank'});
   ({cdp}=await connectBrowser(browser.port));page=await attachFreshPage(cdp,cfg.comarchUrl);
  }
  say('Nach jedem verifizierten Abschluss folgt automatisch der naechste passende Fall. Neue PDFs werden nicht erzeugt; Inhaltspruefungen bleiben bestehen.');
  need((await ask('In COMARCH angemeldet; diese Phase-2-Bearbeitung und Weiterleitung starten? START / ABBRUCH: ')).toUpperCase()==='START','P2_OPERATOR_ABORT','Kein Phase-2-Lauf.');
  controls=consoleFactory({log:say});await controls.ready();restoreInput=controls.protectInput(page.cdp);
  say('P2_BEDIENUNG: MANUELL = ein Knopf vor dem Abschluss; AUTO = nach einmaligem Umschalten selbststaendig. Unklare Nachweise werden nie als Erfolg angenommen.');
  say('LOKALER_LAUFBERICHT: '+logFile);
  const getJournal=(prefix,id)=>{const p=path.join(dir,'actions',prefix+id+'.json');return fs.existsSync(p)?readJSON(p,128*1024):null;};
  while(visited.size<maxTickets){
   await UI.navigateToScope(page,'IN_BEARBEITUNG',{refresh:visited.size>0,startup:visited.size===0});
   const q=await readPhase2Queue(page);need(q.ok,'P2_RUN_QUEUE',q.reason||'Vorgangsliste nicht lesbar.');
   // Fresh inventory is now automatic, not another manual Menu 9 round-trip.
   const inventory=phase2Inventory(q.rows,{pendingIds:ledger(root).pending.map(x=>x.ticketId)});
   writeJSON(path.join(dir,'MCR_PHASE2_LETZTE_INVENTUR.json'),inventory);
   writeJSON(path.join(dir,'MCR_PHASE2_WORK_LETZTE_INVENTUR.json'),{schema:'MCR_PHASE2_WORK_INVENTORY_V1',readOnly:true,generatedAt:new Date().toISOString(),items:q.rows.map(r=>phase2WorkRule(r))});
   const counts={};for(const r of q.rows){const k=phase2WorkRule(r).kind;counts[k]=(counts[k]||0)+1;}
   say('P2_FALLERKENNUNG: MBC_PRIVATE_EMAIL='+String(counts.MBC_PRIVATE_EMAIL||0)+' | DB_DIRECT='+String(counts.DB_DIRECT||0)+' | ACCOUNT_STATEMENT='+String(counts.ACCOUNT_STATEMENT||0));
   const wanted=first&&visited.size===0?q.rows.filter(r=>r.ticketId===first):q.rows;
   if(first&&visited.size===0)need(wanted.length===1,'P2_START_NOT_IN_QUEUE','Startticket nicht genau einmal in aktueller eigener Liste.');
   const currentLedger=ledger(root),priorById=new Map(currentLedger.pending.map(x=>[x.ticketId,x]));
   const audit=inspectPhase2Tickets(wanted,{pending:currentLedger.pending,visited,
    getPdfJournal:id=>getJournal('MCR_PHASE2_',id),getWorkJournal:id=>getJournal('MCR_PHASE2_WORK_',id)});
   const auditReport={...audit,runId,generatedAt:new Date().toISOString(),version:VERSION,
    pageCoverage:'VISIBLE_ROWS_ONLY_NO_PAGINATION_ASSUMPTION'};
   writeJSON(path.join(dir,'MCR_PHASE2_TICKETBESTAND_LETZTE.json'),auditReport);
   const c=audit.counts;
   say('P2_BESTAND: eigene_zeilen='+c.visible+' | bereit='+c.ready+' | wiederaufnahme='+c.resume+
    ' | altversand_lesepruefung='+c.phase1EvidenceToCheck+' | altjournal_gesperrt='+c.phase1Blocked+
    ' | weitere_pruefung='+c.reviewBlocked+' | nicht_unterstuetzt='+c.unsupported);
   for(const entry of audit.items)if(entry.stage==='PHASE1_BLOCKED'||entry.stage==='BLOCKED'||entry.stage==='UNSUPPORTED')
    skipRecords.set(entry.ticketId,{ticketId:entry.ticketId,reason:entry.reason,rule:entry.rule,
     ...(entry.phase1Structure?{phase1Structure:entry.phase1Structure}:{})});
   const intake=phase2IntakeSummary(wanted,{pending:currentLedger.pending,getPdfJournal:id=>getJournal('MCR_PHASE2_',id),getWorkJournal:id=>getJournal('MCR_PHASE2_WORK_',id)});
   say('P2_ZULASSUNG: sichtbar='+intake.stats.visible+' | Regel_ohne_Journalblock='+intake.stats.readyWithoutBlock+' | Phase1_Journal_offen='+intake.stats.blockedPhase1+' | Altfall_mit_passender_Struktur='+intake.stats.oldJournalCandidates+' | ohne_unterstuetzte_Regel='+intake.stats.unclassified+' | unklarer_Status='+intake.stats.missingStatusOrPlan+' | fremde_Gruppe='+intake.stats.outsideIntelGroup);
   // Reconcile only previously SENT and SAVED status, backed by the OLD
   // immutable SHA and exactly one bound outgoing document in this ticket.
   // This step has no send/save/forwarding capability. Other journals stay put.
   const candidate=wanted.find(r=>r.intelGroupVerified!==false&&!visited.has(r.ticketId)&&!handoffChecked.has(r.ticketId)&&
    priorById.get(r.ticketId)?.kind==='SEND'&&
    phase2HandoffDescription({row:r,prior:priorById.get(r.ticketId)}).verified&&
    !getJournal('MCR_PHASE2_',r.ticketId)&&!getJournal('MCR_PHASE2_WORK_',r.ticketId));
   if(candidate){
    const id=candidate.ticketId,prior=priorById.get(id);handoffChecked.add(id);let statusRepairStarted=false;
    say('P2_PHASE1_ALTFALL_PRUEFUNG: '+id+' | '+prior.state+' | zuerst NUR LESEN; Statusnachtrag ausschliesslich nach gebundenem Ausgangsbeleg; KEIN E-Mail-Versand.');
    try{
     // Before opening COMARCH there must already be a plausible, exact and
     // hash-bound saved status. Otherwise do not even navigate into the item.
     const preflight=phase2HandoffAudit({row:candidate,prior,detailDescription:candidate.descriptionValue,history:{ok:false},allowRepair:true});
     if(!['NO_BOUND_MAIL_HISTORY'].includes(preflight.reason)){
      say('P2_PHASE1_ALTFALL_GESPERRT: '+id+' | '+preflight.reason);
     }else{
      await openPhase2Ticket(page,candidate,{log:say});await UI.assertTicket(page,id);
      await UI.ensureEdit(page);await UI.assertTicket(page,id);
      const descriptionState=await UI.additionalDescriptionState(page);
      const history=await UI.historyMailSnapshots(page);
      const proof=phase2HandoffAudit({row:candidate,prior,history,detailDescription:descriptionState.ok?descriptionState.value:null,allowRepair:true});
      if(proof.verified){
       await UI.assertTicket(page,id);
       if(!proof.requiresSave){
        const receipt=completeVerifiedPhase1Handoff(root,prior,proof);
        handoffReceipts.push(receipt);skipRecords.delete(id);
        say('PASS P2_PHASE1_ALTFALL_ABGESCHLOSSEN: '+id+' | Ausgang und Status bereits gespeichert; null neue E-Mails, null Speicherklicks.');
       }else{
        // Exact OLD SEND_INTENT SHA + single bound original/outgoing message,
        // no previous SAVE_INTENT and unchanged COMARCH server description.
        // All other descriptions remain read-only and blocked. No mail-sender
        // exists anywhere in this recovery path.
        const repair=beginVerifiedPhase1StatusRepair(root,prior,proof);statusRepairStarted=true;
        say('P2_PHASE1_NACHTRAG: '+id+' | Ausgang bestaetigt; nur fehlende Statuszeile und ein Ticket-Speicherklick. KEINE E-MAIL.');
        await UI.assertTicket(page,id);
        await commitDescription(page,{ticketId:id,expected:repair.expectedDescription,
         allowedBefore:[proof.currentDescription],log:say,
         manualFocus:async()=>{const ok=await ask('Beschreibungsfeld verdeckt. BEREIT_BESCHREIBUNG eingeben, DANACH im Bot-Edge exakt dieses Feld anklicken: ');
          need(ok.toUpperCase()==='BEREIT_BESCHREIBUNG','P2_STATUS_FOCUS_DECLINED','Fokus nicht freigegeben.');}});
        await UI.assertTicket(page,id);
        need(await UI.verifyDescription(page,repair.expectedDescription),'P2_STATUS_BEFORE_SAVE','Statustext vor Speichern nicht exakt.');
        const watcher=await watchPhase2Save(page);
        try{await savePhase2Ticket(page,{manualClick:async()=>{
         need((await ask('Ticket '+id+' einmal manuell gespeichert? EINMAL_GEKLICKT / ABBRUCH: ')).toUpperCase()==='EINMAL_GEKLICKT',
         'P2_STATUS_SAVE_UNCLEAR','Nur ein bestaetigter Speicherklick erlaubt.');}});}catch(e){watcher.cancel();throw e;}
        const settled=await watcher.settle();
        need(!['WRITE_REQUEST_ERROR','NETWORK_STILL_ACTIVE'].includes(settled.status),'P2_STATUS_SAVE_UNCLEAR','Speicherung unklar; kein zweiter Klick.');
        await UI.navigateToScope(page,'IN_BEARBEITUNG',{refresh:true});
        const after=await readPhase2Queue(page),matches=after.rows?.filter(r=>r.ticketId===id)||[];
        need(after.ok&&matches.length===1&&matches[0].descriptionValue.replace(/\r\n?/g,'\n').trim()===repair.expectedDescription,
         'P2_STATUS_SERVER_NOT_SAVED','Status nicht in der frisch geladenen Vorgangsliste nachgewiesen. Kein zweiter Klick.');
        await openPhase2Ticket(page,matches[0],{log:say});await UI.assertTicket(page,id);
        const detail=await UI.additionalDescriptionState(page);
        need(detail.ok&&detail.value.replace(/\r\n?/g,'\n').trim()===repair.expectedDescription,
         'P2_STATUS_DETAIL_NOT_SAVED','Status nicht im erneut geoeffneten Server-Ticket nachgewiesen. Kein zweiter Klick.');
        const receipt=finishVerifiedPhase1StatusRepair(root,id,repair.expectedDescription);
        handoffReceipts.push(receipt);skipRecords.delete(id);
        say('PASS P2_PHASE1_STATUS_NACHGETRAGEN: '+id+' | alter Ausgang, exakte USC/Status/Anfrage gespeichert; keine neue E-Mail.');
       }
       continue; // Refresh the exact list; the now-unblocked item is eligible.
      }
      say('P2_PHASE1_ALTFALL_GESPERRT: '+id+' | '+proof.reason);
     }
    }catch(e){
     // Read-only audit must never create a new send or suppress a genuine
     // uncertainty. An inaccessible ticket stays excluded and recorded.
     if(statusRepairStarted||e.code==='P2_PHASE1_LEDGER_CHANGED')throw e;
     say('P2_PHASE1_ALTFALL_PRUEFUNG_NICHT_MOEGLICH: '+id+' | '+(e.code||'READ_FAILED'));
    }
    await UI.navigateToScope(page,'IN_BEARBEITUNG',{refresh:true});
   }
   const pick=choosePhase2Candidate(wanted,{visited,blockedIds:ledger(root).pending.map(x=>x.ticketId),
    getPdfJournal:id=>getJournal('MCR_PHASE2_',id),getWorkJournal:id=>getJournal('MCR_PHASE2_WORK_',id),
    accountReady:id=>{try{preflightPhase2Write(root,id);return true;}catch(e){skipRecords.set(id,{ticketId:id,reason:e.code||'PDF_PREFLIGHT'});return false;}}});
   for(const skip of pick.skipped)if(!skipRecords.has(skip.ticketId))skipRecords.set(skip.ticketId,skip);
   if(!pick.row){
    for(const x of skipRecords.values())if(!visited.has(x.ticketId))say('P2_UEBERSPRUNGEN: '+x.ticketId+' | '+x.reason);
    say('P2_BESTANDSDIAGNOSE: '+path.join(dir,'MCR_PHASE2_TICKETBESTAND_LETZTE.json')+' | Nur sichtbare eigene Intel-Tickets, andere INTL01-Vorgaenge nicht automatisch weiterleiten.');
    if(first&&visited.size===0)need(false,'P2_START_NOT_READY','Startticket nicht fortsetzbar. Siehe P2_UEBERSPRUNGEN; kein Schreibversuch.');
    say('P2_LAUF_ENDE: Kein weiterer automatisch bearbeitbarer Fall in der aktuell sichtbaren eigenen Vorgangsliste.');break;
   }
   const id=pick.row.ticketId;visited.add(id);currentTicket=id;controls.start({ticketId:id,kind:pick.kind,description:pick.row.descriptionValue});say('P2_NAECHSTES_TICKET: '+id+' | '+pick.kind);
   const routeListBefore=await capturePhase2RouteList(page);
   const result=pick.kind==='ACCOUNT_STATEMENT'?
    await phase2ComarchPilot({root,ticketId:id,session:{page,rl},reviewAuthorized:true,controls,routeListBefore,memberLookup,askFn:(_rl,q)=>ask(q),log:say}):
    await handlePhase2Work({root,page,row:pick.row,mapping:active.map,ask,log:say,memberLookup,controls,routeListBefore});
   if(result?.status==='SKIPPED_UNCHANGED'){
    need(pick.kind==='MBC_PRIVATE_EMAIL'&&result.ticketId===id&&result.noWrite===true&&!getJournal('MCR_PHASE2_WORK_',id),'P2_SKIP_UNSAFE','Nur ein unveraenderter neuer MBC-Entwurf darf uebersprungen werden.');
    const skip={ticketId:id,reason:result.reason};skipRecords.set(id,skip);
    say('P2_ENTWURF_UNVERAENDERT: '+id+' | '+skip.reason+' | kein Speichern, kein Weiterleiten');
    controls.defer?.({ticketId:id});currentTicket=null;continue;
   }
   need(result?.status==='ROUTED_VERIFIED','P2_RUN_UNCONFIRMED','Voriger Abschluss nicht verifiziert. Kein naechstes Ticket.');
   receipts.push(result);skipRecords.delete(id);say('PASS P2_FALL_ABGESCHLOSSEN: '+id+' | mark.baindl | OHNE_EMAIL');controls.complete({ticketId:id});currentTicket=null;
  }
  const report={schema:'MCR_PHASE2_RUN_V1',runId,version:VERSION,status:'COMPLETED_VISIBLE_SCOPE',processed:receipts.length,scope:'VISIBLE_MY_TASKS_NO_PAGINATION',maxTickets,receipts,handoffReceipts,skipped:[...skipRecords.values()].filter(x=>!visited.has(x.ticketId)),ticketAudit:path.join(dir,'MCR_PHASE2_TICKETBESTAND_LETZTE.json')};
  writeJSON(path.join(dir,'MCR_PHASE2_LAUF_'+runId+'.json'),report);return report;
 }catch(e){
  controls?.error(e);
  say('STOP '+(e.code||'ERROR')+': '+e.message);
  writeJSON(path.join(dir,'MCR_PHASE2_LAUF_'+runId+'.json'),{schema:'MCR_PHASE2_RUN_V1',runId,version:VERSION,status:'STOP_REVIEW_REQUIRED',errorCode:e.code||'ERROR',processed:receipts.length,attempted:[...visited],receipts});
  throw e;
 }finally{restoreInput?.();controls?.close();if(!session)rl.close();try{cdp?.close();}catch{}try{browser?.child?.kill();}catch{}}
}
