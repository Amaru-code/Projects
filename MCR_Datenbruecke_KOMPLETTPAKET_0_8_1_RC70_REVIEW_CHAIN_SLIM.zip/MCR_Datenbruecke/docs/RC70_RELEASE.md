# RC70 – Verlaesslicher Phase-2-Pruefschritt und kontrollierter Wiederanlauf

## Fehlerbild im produktiven RC69

Ticket 88449724: MBC-Entwurf, gespeicherte Beschreibung, GEVO und erneutes Oeffnen wurden bestaetigt. Anschliessend brach die Pruefschrittauswahl mit `P2_REVIEW_SELECT_FOCUS` ab. Es erfolgte kein `EXECUTE_INTENT`, keine Weiterleitung und kein weiterer E-Mail-Versand.

## RC70: Die gesamte Uebergabekante abgesichert

- Nach dem Browserklick auf das einzige gebundene `select` mit `FORWARD_TO_REVIEW` wird die aktuelle DOM-Struktur neu gelesen. Ein verlorener Fokus oder ICEfaces-Ersatzknoten darf nicht mehr sofort zu `P2_REVIEW_SELECT_FOCUS` fuehren.
- Ausschliesslich dieses eindeutig gebundene, aktive und zum richtigen Ticket gehoerende COMARCH-SELECT wird bei Bedarf per nativer Browser-API `DOM.focus` erneut fokussiert. Kein zweiter Mausklick auf das Dropdown, kein JS `.value=`, keine ungepruefte Formularabgabe.
- Wenn `FORWARD_TO_REVIEW` bereits nachweislich ausgewaehlt ist, wird nicht nochmals gewaehlt. Andernfalls wird ausschliesslich bei nachgewiesenem Fokus mittels nativer Tastaturevents ausgewaehlt und der Wert erneut gelesen.
- Ein fremdes/mehrdeutiges Feld, eine Modal-Dialogblockade oder ein weiterhin ungepruefter Wert beendet die Aktion vor Prueferauswahl und Weiterleitung. Der vorhandene explizite manuelle Fokuspfad bleibt verfuegbar.
- Die bestehende Prueferauswahl `Baindl Mark (mark.baindl)` und `Schritt ausfuehren` laufen erst nach erneuter `FORWARD_TO_REVIEW`- und GEVO-Pruefung. Ein bereits gespeicherter MBC-Entwurf und das Ticket werden im Wiederanlauf nicht ein weiteres Mal gespeichert.

## Grenzen und Installationsanleitung

Die Tests nutzen Chromium mit nachgebauten ICEfaces-Feldersetzungen, ohne einen produktiven COMARCH-Aufruf. Ein wirklicher Windows-Run muss den Abschluss nachweisen. E-Mail-Versand bleibt in Phase 2 unmoeglich. Weiterleitung nur nach MANUELL-/AUTO-Freigabe und anschliessend eindeutiger Erfolgspruefung. Kein blinder zweiter Klick.

ZIP separat entpacken, `START.cmd` -> Menue 1 (RC69 auf RC70), dann die **installierte** `START.cmd` -> Menue 12 -> Ticket `88449724`. Nach erfolgreichem Abschluss fuer einen Folgelauf Menue 12 mit leerem Startticket ausfuehren, um auch andere zulassbare Intel-Tickets zu bearbeiten. Bereits gespeicherte Journal-Daten, Mapping und Browserprofil bleiben am Standort.
