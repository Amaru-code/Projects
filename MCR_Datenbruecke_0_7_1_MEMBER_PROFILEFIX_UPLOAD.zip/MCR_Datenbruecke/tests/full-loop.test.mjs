import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const src=fs.readFileSync(path.join(root,'src','local-bot-full-run.mjs'),'utf8');

test('Vollrunner priorisiert Meine Vorgänge vor INTL01',()=>{
  const a=src.indexOf("navigateToScope(page,'IN_BEARBEITUNG')");
  const b=src.indexOf("navigateToScope(page,'WARTESCHLANGE_INTL01')",a+1);
  assert.ok(a>=0&&b>a);
});

test('Vollrunner speichert und prüft Persistenz vor nächstem Ticket',()=>{
  assert.match(src,/await saveTicket\(page\)/);
  assert.match(src,/await verifySavedAndReturn\(page,row\.ticketId\)/);
  assert.match(src,/SAVE_UNVERIFIED/);
});

test('Versandnachweis akzeptiert serverseitig geleerten Editor nach bestätigten Dialogen',()=>{
  assert.match(src,/EDITOR_RESET_AFTER_CONFIRMED_DIALOGS/);
  assert.match(src,/dialogCount>=1/);
  assert.match(src,/ed\.ok&&ed\.empty/);
});

test('Doppelversand- und Endlosschleifen-Gates sind vorhanden',()=>{
  assert.match(src,/DUPLICATE_GUARD/);
  assert.match(src,/MAX_TICKETS_REACHED/);
  assert.match(src,/NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS/);
});


test('Member-Commit kann MercerID aus separaten COMARCH-Profilzeilen lesen',()=>{
  assert.match(src,/source:'PROFILE_ROWS'/);
  assert.match(src,/\^Mercer\\s\*ID/);
  assert.match(src,/\^Vorname/);
  assert.match(src,/\^Nachname/);
  assert.match(src,/selectedMember\(page,person\)/);
});

test('Bereits korrekt übernommener Member wird vor erneuter Suche wiederverwendet',()=>{
  assert.match(src,/const preselected=await selectedMember\(page,person\)/);
  assert.match(src,/COMARCH-Member bereits übernommen/);
});
