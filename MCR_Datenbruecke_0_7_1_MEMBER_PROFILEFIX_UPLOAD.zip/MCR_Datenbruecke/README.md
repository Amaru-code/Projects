# MCR Datenbrücke – aktueller Stand 0.7.1

0.7.1 ist der Vollrunner mit MyTasks → INTL01 → Ende und einem zusätzlichen realen Member-Commit-Fix: COMARCH darf nach der Auswahl die MercerID separat unter `MercerID:` anzeigen, während im Member-Feld nur der Name steht. Details: `README_0_7_1.md`.

Start: `START_FULL_QUEUE_RUN.cmd`
