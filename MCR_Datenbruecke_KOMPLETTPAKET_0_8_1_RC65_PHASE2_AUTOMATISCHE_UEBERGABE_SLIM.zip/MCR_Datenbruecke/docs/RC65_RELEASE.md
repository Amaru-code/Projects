# RC65 – Phase-2-Übergabe und klare Abschlussmeldung

## Diagnose aus RC64

Die Phase-2-Entdeckung zählte Rohkandidaten vor der Prüfung offener Phase-1-Journale. Deshalb konnten zwei MBC- und vier DB-Regeln erkannt werden, obwohl kein einziges Ticket freigegeben war. Der Master meldete nach 0 Weiterleitungen trotzdem COMPLETE_VISIBLE_SCOPE. RC65 stellt dies richtig.

## RC65 – neu

- `P2_ZULASSUNG`: sichtbare, ohne Journalsperre bereite, blockierte, nicht unterstützte und unklare Tickets getrennt zählen.
- Nur bei alten `SEND_INTENT`/`SENT_CONFIRMED`/`SAVE_INTENT` mit bereits gespeichertem **exaktem** USC-Status (SHA-256 muss zu ursprünglicher Sendeabsicht passen) und einer einzigen, durch Dokument-ID, Originalabsender, Absender, Standardantwort und Ticketbetreff gebundenen ausgehenden Nachricht: bestehendes Journal auf COMPLETE setzen und im nächsten Durchgang die vorhandene Phase-2-Regel nutzen. Keine neue Mail, kein Speichern oder Weiterleiten im Abgleich. Unklarheiten bleiben gesperrt.
- Keine automatische Phase-2-Antwort für unbekannte Anfragearten; keine Interpretation von `SEND_INTENT` als bereits erfolgt.
- Wenn alle Fälle blockiert bleiben, Ausgabe `MASTER_PHASE2_OFFENE_FAELLE` und Masterstatus `PARTIAL_PHASE2_NO_ELIGIBLE`, nicht fälschlich vollständiger Erfolg.
- Intel-Ansichten, Versand-/Signaturregeln, MBC, DB und Kontoauszugsbearbeitung aus RC64 bleiben unverändert. Paket bleibt kompakt.

## Installation

RC65 ZIP separat entpacken → START.cmd → Menü 1 → bestehende RC64-Installation aktualisieren. Dann installierte START.cmd → Menü 13. Daten/Journale und Edge-Profil bleiben erhalten. Keine produktiven COMARCH-Daten im ZIP.
