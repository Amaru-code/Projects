import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const code='/* MCR Datenbruecke 0.2.2 - generated from lib/data-core.cjs + browser/ui.js. */\n(()=>{\nconst module={exports:{}};\n'+fs.readFileSync(path.join(root,'lib/data-core.cjs'),'utf8')+'\nconst Core=module.exports;\n'+fs.readFileSync(path.join(root,'browser/ui.js'),'utf8')+'\n})();\n';
fs.writeFileSync(path.join(root,'COMARCH_DATENBRUECKE.js'),code);

const modules=[['Core','lib/data-core.cjs'],['Msg','lib/msg.cjs'],['Person','lib/person.cjs'],['Widget','lib/member-widget.cjs'],['ListDOM','lib/member-list.cjs'],['Profile','lib/member-profile.cjs'],['Suggest','lib/member-suggest.cjs'],['Description','lib/description-field.cjs']];
const v3='/* MCR Mail-Assistent 0.3.5. Offline MSG parser and supervised member workflow. */\n(()=>{\n'+modules.map(([name,file])=>'const '+name+'=(()=>{const module={exports:{}};\n'+fs.readFileSync(path.join(root,file),'utf8')+'\nreturn module.exports;})();\n').join('')+fs.readFileSync(path.join(root,'browser/mail-ui.js'),'utf8')+'\n})();\n';
fs.writeFileSync(path.join(root,'COMARCH_MAIL_ASSISTENT.js'),v3);

const prep='/* MCR Ticket-Vorbereiter 0.4.0. No send/save. */\n(()=>{\nconst Prep=(()=>{const module={exports:{}};\n'+fs.readFileSync(path.join(root,'lib/ticket-prep.cjs'),'utf8')+'\nreturn module.exports;})();\n'+fs.readFileSync(path.join(root,'browser/ticket-prep-ui.js'),'utf8')+'\n})();\n';
fs.writeFileSync(path.join(root,'COMARCH_TICKET_VORBEREITER.js'),prep);
