# MCR Ticket-Automatisierung 0.4.0 — Ticket vorbereiten

## Ziel dieses Stands

Der bestätigte 0.3.5-Datenpfad bleibt bestehen: Original-MSG → geprüfter Name →
manuell ausgewählter COMARCH-Member → MercerID → lokales JSON-Mapping →
USC/DC/PP+/DB+ → „Zusätzliche Beschreibung“.

**0.4.0 ergänzt anschließend die Ticketvorbereitung bis unmittelbar vor den Versand.**
Der neue Ticket-Vorbereiter kann:

- Zuständigkeit auf `Second Level` setzen,
- Dokumentenkategorie `Allgemeine Schriftwechsel` vorbereiten,
- Unterkategorie `Personenschriftwechsel` vorbereiten,
- Signatur `INTL01 - Intel Deutschland GmbH` vorbereiten,
- nach manueller Auswahl von `Herr` oder `Frau` den freigegebenen Antworttext erzeugen,
- den Antworttext in einen eindeutig erkannten oder einmal manuell verbundenen
  COMARCH-Nachrichteneditor einsetzen,
- eine finale Vor-Versand-Prüfung durchführen.

**Nicht automatisiert:** Senden, Bestätigungsdialoge und `Ticket speichern`.
Dieser Stand besitzt dafür bewusst keine Aktion.

## Aktualisieren

ZIP vollständig entpacken und den enthaltenen Ordner `MCR_Datenbruecke` mit dem
vorhandenen gleichnamigen Ordner zusammenführen. Gelieferte Paketdateien ersetzen,
den bisherigen Ordner aber nicht löschen. `private_data`, vorhandenes Mapping,
Excel-Dateien und Node-Runtime behalten.

Das mit 0.3.2 oder neuer erzeugte JSON bleibt verwendbar. **Kein erneuter
Excel-Export ist für 0.4.0 erforderlich.**

## Empfohlener Ablauf pro Ticket

1. Wie bisher `MAIL_ASSISTENT_OEFFNEN.cmd` verwenden.
2. Original-MSG und vorhandenes Mapping laden.
3. Namen prüfen, Member-Suche starten und den richtigen Member selbst auswählen.
4. Schritt 4 berechnen lassen und `Beschreibung in COMARCH einsetzen` verwenden.
5. Danach `TICKET_VORBEREITER_OEFFNEN.cmd` öffnen, den gesamten JavaScript-Code
   aus Notepad kopieren und in derselben COMARCH-DevTools-Konsole (`top`) ausführen.
   Der Ticket-Vorbereiter übernimmt keine Mail- oder Mappingdaten.

Wenn der Mail-Assistent noch aktiv ist und `descriptionWritten=true` gemeldet hat,
wird diese lokale Vorbedingung übernommen. Trotzdem bleibt im Ticket-Vorbereiter
ein sichtbares Kontrollkästchen für die zusätzliche Beschreibung.

## Feste Felder vorbereiten

Im Panel **Feste Felder vorbereiten** anklicken. Der Helfer verwendet die stabil
beobachteten COMARCH-Felder:

- `mainForm:responsibility-value-id`
- `mainForm:category-value-id`
- `mainForm:category-sub-value-id`
- `mainForm:signature-value-id`

Bei Zuständigkeit wird ausschließlich die exakt beschriftete Option `Second Level`
verwendet. Für Kategorie, Unterkategorie und Signatur wird die COMARCH-Vorschlagsliste
abgewartet und nur ein exakt beschrifteter Vorschlag über dessen vorhandenes
`mousedown`-Ereignis ausgewählt. Der Helfer ruft SuggestServlet/iceSubmit nicht direkt auf.

Wird keine eindeutige exakte Vorschlagszeile erkannt, erscheint `MANUAL_REQUIRED`.
Dann den angezeigten Sollwert im echten COMARCH-Feld selbst auswählen und anschließend
**Feste Felder prüfen** anklicken. Vor dem finalen Gate müssen die vier Werte zusätzlich
im echten Formular manuell bestätigt werden.

## Antworttext

Anrede wird **nicht** aus dem Vornamen oder aus sonstigen Daten abgeleitet. Im Panel
muss `Herr` oder `Frau` ausdrücklich gewählt werden. Der Nachname wird nur bei einer
einfachen zweigliedrigen COMARCH-Anzeige vorsichtig vorbefüllt; er bleibt immer prüfbar.

Die Vorlage lautet:

```text
Sehr geehrter Herr/Frau <Nachname>,

vielen Dank, dass Sie sich mit uns in Verbindung gesetzt haben.

Mit dieser E-Mail möchten wir Ihnen bestätigen, dass wir Ihr Ticket erhalten haben und unser Team derzeit daran arbeitet. Wir wissen Ihre Geduld und Ihr Verständnis zu schätzen, da wir uns bemühen, Ihnen den bestmöglichen Support zu bieten.
Seien Sie versichert, dass Ihr Anliegen für uns wichtig ist und wir uns bemühen, es so schnell wie möglich zu lösen. Unser engagiertes Team arbeitet aktiv an Ihrem Ticket und wird Sie über den aktuellen Stand der Dinge informieren.
Wenn Sie weitere Informationen oder Fragen zu Ihrem Ticket haben, können Sie gerne auf diese E-Mail antworten.
```

**Antworttext erzeugen** zeigt die konkrete Vorschau. **Antwort in COMARCH einsetzen**
verwendet nur einen eindeutig gefundenen `contenteditable`-Editor. Bei mehreren oder
unbekannten Editoren zuerst **Antworteditor verbinden** klicken und dann mit gedrückter
`ALT`-Taste direkt in den echten leeren Nachrichteneditor klicken. Das Verbinden schreibt
noch nichts.

Ein bereits abweichend befüllter Editor wird nicht überschrieben. Nach dem Einsetzen
wird der sichtbare Editorinhalt lokal nachgelesen. Dies ist kein Nachweis einer späteren
Serverspeicherung.

## Harter Stopp vor Versand

Vor `Vor Versand prüfen` sind drei menschliche Kontrollen erforderlich:

- feste Felder im echten COMARCH-Formular geprüft,
- zusätzliche Beschreibung im echten Ticket geprüft,
- Empfänger im COMARCH-Feld `An` geprüft.

Zusätzlich muss der Antworttext im Editor lokal verifiziert sein. Erst dann zeigt das
Panel `BEREIT VOR VERSAND`.

**Der Helfer klickt niemals `Senden`, bestätigt keine Versanddialoge und klickt niemals
`Ticket speichern`.** Diese Schritte bleiben in 0.4.0 vollständig manuell.

## Datenschutz und Diagnose

Mail und Mapping werden weiterhin nur durch den Mail-Assistenten lokal im
COMARCH-Seitenkontext verarbeitet. Der neue Ticket-Vorbereiter benötigt weder Mail noch
Mapping und überträgt nichts an externe Dienste. Der Seitenkontext ist dennoch keine
isolierte Datenschutz-Sandbox.

Bei einem Fehler im neuen Teil `Diagnose-ZIP` verwenden. Die Diagnose enthält nur
Statuscodes/Booleans und keine Namen, MercerIDs, Mailadressen, Antworttexte,
Feldwerte, URLs, Selektoren oder Cookies.

Historische Details zum bestätigten Datenpfad stehen in `docs/ANLEITUNG_BIS_0_3_4.md`
und `docs/DESCRIPTION_TESTBERICHT.md`.
