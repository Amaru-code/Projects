@echo off
start "" notepad.exe "%~dp0COMARCH_TICKET_VORBEREITER.js"
