@echo off
setlocal DisableDelayedExpansion
set "NODE_EXE="
if defined MCR_NODE_EXE if exist "%MCR_NODE_EXE%" set "NODE_EXE=%MCR_NODE_EXE%"
if defined NODE_EXE goto nodefound
if exist "%USERPROFILE%\projects\Compiler\javascript\tools\node\node.exe" set "NODE_EXE=%USERPROFILE%\projects\Compiler\javascript\tools\node\node.exe"
if defined NODE_EXE goto nodefound
for /f "delims=" %%N in ('where.exe node.exe 2^>nul') do if not defined NODE_EXE set "NODE_EXE=%%N"
if defined NODE_EXE goto nodefound
echo STOPP NODE_NOT_FOUND
echo Der bisherige portable Node-Compiler wurde nicht gefunden.
echo Es wird nichts installiert oder heruntergeladen.
echo Erwartet: %%USERPROFILE%%\projects\Compiler\javascript\tools\node\node.exe
exit /b 2
:nodefound
"%NODE_EXE%" -e "if(Number(process.versions.node.split('.')[0])<18)process.exit(3)"
if not "%ERRORLEVEL%"=="0" (
 echo STOPP NODE_VERSION: Vorhandener Node kann den Starter nicht ausfuehren.
 exit /b 3
)
pushd "%~dp0.."
if not "%ERRORLEVEL%"=="0" exit /b 4
if /i "%~1"=="selftest" goto selftest
"%NODE_EXE%" "%~dp0recover.mjs" "%~1"
set "MCR_EXIT=%ERRORLEVEL%"
popd
exit /b %MCR_EXIT%
:selftest
"%NODE_EXE%" --test "%~dp0..\tests\recovery.test.mjs"
set "MCR_EXIT=%ERRORLEVEL%"
popd
exit /b %MCR_EXIT%
