# LenWork – UTF-8-Brückentest für eingebettete PowerShell (KEIN Outlook-Export)

**Ziel:** Den Fehler `BLOCKED_SHELL_ENCODING` reproduzierbar eingrenzen, ohne Mails zu lesen, ohne Ausführungsrichtlinien zu ändern, ohne externe Netzwerkverbindung und ohne Skripte in einen lokalen Installationspfad zu schreiben.

## Diesen gesamten Auftrag an LenWork senden

> Arbeite ausschließlich mit der bereits freigegebenen Bash-/Shell-Ausführungsfunktion. Nutze in **allen** Tests dasselbe reale Tool und dieselbe Sitzung, deren Datenzugriff später für den Skill autorisiert wäre. Keine Nutzung von simulierten Ausgaben. Keine Änderungen an Outlook, Skripten oder Sicherheitsrichtlinien. Gib nur ASCII-Marker und technische Statuswerte zurück.
>
> **A. Baseline**: Führe eine reine Bash-Ausgabe `printf 'BASH_ASCII_OK\n'` aus. Melde `BASH_ASCII` mit dem tatsächlichen Ergebnis.
>
> **B. PowerShell explizit UTF-8**: Führe, soweit das Tool POSIX-Bash unterstützt, diesen exakt harmlosen Befehl aus:
>
> ```bash
> powershell.exe -NoLogo -NoProfile -NonInteractive -Command '[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false); $OutputEncoding = [Console]::OutputEncoding; [Console]::WriteLine("LW_PS_UTF8_OK")'
> ```
>
> Melde `POWERSHELL_UTF8_STDOUT`. Wenn `stream did not contain valid UTF-8` erscheint, scheitert B und es gibt **noch keinen** COM-Readiness-PASS.
>
> **C. Fehlerquelle abgrenzen (ohne PowerShell-stdout)**: Falls B scheitert, führe über dasselbe POSIX-Bash-Tool aus:
>
> ```bash
> powershell.exe -NoLogo -NoProfile -NonInteractive -Command 'exit 0' >/dev/null 2>&1
> rc=$?
> printf 'PS_QUIET_EXIT=%s\n' "$rc"
> ```
>
> Der PowerShell-Prozess muss seine Ausgabe vollständig unterdrücken. Nur Bash schreibt den ASCII-Marker. Falls der Toolzugang kein echtes POSIX-Bash ist, nutze die **dokumentierte gleichwertige Shell-Syntax**, nicht die wörtliche Vorlage. Melde `POWERSHELL_QUIET_EXIT` und den beobachteten Exitcode.
>
> **D. Ergebnis**: `BASH_ASCII`, `POWERSHELL_UTF8_STDOUT`, `POWERSHELL_QUIET_EXIT`, `SHELL_TRANSPORT_RESULT`, `NEXT_SAFE_TEST`. Keine Mail-/COM-Abrufe, keine Änderung von Gruppenrichtlinien, keine nachträgliche Behauptung einer erfolgreichen Datenübertragung. Bei B=FAIL und C=PASS liegt eine Hypothese über Ausgabeencoding vor, **noch kein** funktionierender E-Mail-Datenkanal. Führe Step 1c nicht aus, bevor ein belastbarer Importkanal existiert.

## Hinweise

- Das vorliegende Outlook-COM-Programm ist **bereits lokal** mit 78 E-Mails getestet, aber **nicht** erfolgreich direkt aus dem virtuellen LenWork-Skill gestartet worden.
- `SCALE_101_PASS` im Microsoft-365-Fallback bedeutet mehr als 100 E-Mails **über mehrere Tage**, nicht garantiert mehr als 50 an einem einzelnen Tag.
- Code-Hash: 12.764 UTF-8-Bytes mit genau einem LF am Ende → `29b4d7b55382fec0591919000e018fe56d012c648af607eb99054b3ea3f76411`.
- Ein Fix für die stdout-Codierung ist nicht automatisch ein Beweis, dass LenWork eine große JSONL-Datei zwischen Windows und seiner virtuellen Umgebung zuverlässig importieren kann.
