# LenWork Original-Skill EmbeddedCOM v1.5 – Transportkorrektur

**Ziel:** Vollständig teilbarer LenWork-Skill ohne dauerhaft zu installierende PowerShell-Datei. Keine Änderung an den fachlichen Originalregeln oder `absender.md`.

## Befunde aus LenWork (11.10.2026)

- Fallback `msgraph_email`: 18 Nachrichten erfolgreich importiert; mehr als 100 über Datumsblätter zuvor bestätigt.
- COM-Skript: unter Windows PowerShell 5.1 lokal mit 78 E-Mails erfolgreich, **aber aus LenWork nicht vollständig gestartet/übergeben**.
- Blocker 1: `BLOCKED_SHELL_ENCODING` bei PowerShell-stdout im Bash-Tool, schon beim harmlosen Test.
- Blocker 2: Hash der eingebetteten Skriptquelle ohne abschließendes LF wurde mit Hash der Originaldatei mit LF verglichen. Kein festgestellter funktioneller Skriptunterschied.

## Änderungen gegenüber v1.4

1. Einzige technische Korrektur in der Bash→Windows-PowerShell-Hülle: lokale stdout-Konfiguration explizit UTF-8.
2. CRLF/LF und **genau ein** abschließendes LF vor dem SHA256-Abgleich kanonisiert.
3. Priorität Step 2, 3, 4 und Absenderliste **byteidentisch** zum Original (QA-geprüft).
4. PowerShell-Exporter ist **byteidentisch** zum bereits lokal geprüften 12.764-Byte-Original.
5. Keine Behauptung `READY_FOR_100PLUS_GENERATOR=YES`, bevor echter Transport und Batch-Import nachgewiesen sind.

## Installation in LenWork

Nur zwei Dateien: `SKILL.md` und `absender.md`. Alte separate Skriptdateien und künstliche 125-Testmails aus der produktiven Skill-Version entfernen. In einer **privaten Testkopie** beginnen, nicht produktiven Skill überschreiben. Unterlagen `LENWORK_ENCODING_PROBE.md` als Textprompt im LenWork-Chat nutzen, **nicht** als zusätzliche Skill-Datei erforderlich.

## Nächster Test

Sende `LENWORK_ENCODING_PROBE.md` an LenWork. Dieser Test verwendet **keine Mails**. Bei erfolgreichem Kanal wird erst danach der reale COM-Export aus Step 1c samt Manifest/Import-Abnahme geprüft. Wenn der Kanal nicht funktioniert, verbleibt Step 1b als eingeschränkte, bereits verifizierte Lösung. Unternehmensrichtlinien und COM-Zugriff müssen pro geteilter Umgebung erfüllt sein.
