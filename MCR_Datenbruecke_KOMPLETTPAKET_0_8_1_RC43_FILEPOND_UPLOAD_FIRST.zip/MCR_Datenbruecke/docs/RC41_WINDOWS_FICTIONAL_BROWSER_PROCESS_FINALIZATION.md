# RC41 – Nur fiktive Edge-Prozesse unter Windows zuverlässig beenden

## Hintergrund

Die RC40-Installation schlug bei 361/362 Tests fehl. In der RC29-Browserprobe waren einmaliger Versand, drei Beschreibungszeilen und einmaliges Speichern nachweislich PASS. Erst nach `RUN COMPLETE` folgte `STOP DEMO_BROWSER_NOT_STOPPED`.

## Gezielte Reparatur

1. Wie bisher zuerst Browser.close (CDP), WebSocket-Schluss, kindgerechtes Warten, `child.kill()` und erneutes Warten.
2. Nur unter Windows, nur bei nachweislich weiterhin laufendem **selbst gestarteten** Chromium und nur für ein exklusives `MCR-Fiktiv-Profil-*\edge-profile` unter dem Windows-Temp-Verzeichnis wird `taskkill.exe /PID <eigener_PID> /T /F` ohne Shell ausgeführt.
3. Der Prozess muss die erwartete Browser-EXE und exakt dieselbe `--user-data-dir`-Angabe besitzen; bei nicht eindeutiger Zuordnung erfolgt kein Taskkill.
4. Selbst ein Exitcode 0 von `taskkill` ist **kein Erfolgsbeweis**. Erst wenn das zugehörige Child beendet ist, wird `PASS` vergeben.
5. Andere Edge-Fenster, Benutzerprofile, COMARCH-Echtläufe und Phase-2-Piloten werden nicht verändert oder zwangsbeendet.

## Status der Abnahme

Die absichernden Tests prüfen isolierte Kinder, verweigerte unberechtigte PIDs, gescheitertes Beenden sowie den weiterhin fehlgeschlagenen Proof bei fehlendem Prozess-Exit. Das Original-RC40-Manifest wird bytegenau als Upgradereferenz mitgeliefert. Die produktiven E-Mail-/COMARCH- und Phase-2-Logiken sind unverändert.
