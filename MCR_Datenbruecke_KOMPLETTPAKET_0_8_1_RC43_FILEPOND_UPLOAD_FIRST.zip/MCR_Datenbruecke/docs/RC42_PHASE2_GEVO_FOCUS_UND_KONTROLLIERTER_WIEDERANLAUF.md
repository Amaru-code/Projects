# RC42 – Phase-2-GEVO-Fokus und kontrollierter Wiederanlauf

## Befund aus RC41

Echter Pilot Ticket 87278094: PDF-Belege fuer DC und PP+ vorhanden, COMARCH-Ticket eindeutig gebunden, Operatorfreigabe erteilt. `P2_JOURNAL GEVO_INTENT` wurde geschrieben. Danach `STOP INPUT_FOCUS_NOT_CONFIRMED` auf `mainForm:gevo-value-id`. **Es wurde kein Upload, kein Speichern, keine Weiterleitung durch RC41 protokolliert.** Ein solcher STOP beweist nicht allein, dass keine manuelle Aktion erfolgt ist; COMARCH muss geprüft werden.

Der vorherige RC39-E2E-Browsertest hatte das GEVO-Feld bereits mit `Anfrage Member` vorausgefüllt und konnte darum diese Fokusstörung nicht simulieren.

## Änderungen

- Die RC6-Fokusprüfung (`focusInput`) wird jetzt auch beim Phase-2-GEVO-Feld mit `manualGate` verwendet. Prüfung: exakte einmalige Feld-ID, Sichtbarkeit/Schreibbarkeit, kontrolliertes Scrollen, `elementFromPoint`, höchstens ein automatischer echter Browserklick. Ohne bestätigten Fokus keine Tastatureingabe und kein Upload.
- Ist das Feld verdeckt: Terminal fordert dazu auf, **nur** das GEVO-Eingabefeld im **eigenen Bot-Edge** anzuklicken. Der Benutzer bestätigt `FOKUS`. Nach der Rückkehr verifiziert das Programm `document.activeElement === genau dieses Eingabefeld` und tippt erst danach `Anfrage Member` über die echte Chromium-Tastatureingabe. Fehlende/gefälschte Bestätigung stoppt.
- Die Auswahl aus dem COMARCH-Vorschlag bleibt gesondert und muss genau `Anfrage Member` ergeben. Kein automatisches Klicken auf andere Felder.
- Das mit RC41 hinterlassene Journal `MCR_PHASE2_87278094.json` bleibt erhalten. **Nur** der unveränderte Zustand `GEVO_INTENT` mit genau zwei ursprünglichen Ereignissen (`PREPARED`, `GEVO_INTENT`) und übereinstimmenden Beschreibung/PDF-Hashes ist für **einen** Fokus-Wiederanlauf qualifizierbar.
- Vor einer Wiederaufnahme prüft RC42 dieselbe Ticket-ID, originale Beschreibung, identisches Memberprofil, erlaubte Planarten und dass die zu erwartenden Anhänge nicht im COMARCH-Ticket sichtbar sind. Der Operator muss außerdem unabhängig geprüft haben, dass kein Entwurf gespeichert, kein Ticket gespeichert und keine Weiterleitung erfolgt ist; expliziter Schlüssel `GEVO_OHNE_AKTIONEN_GEPRUEFT`.
- Die Berechtigung wird **im selben Journal** als `GEVO_FOCUS_RETRY_OPERATOR_AUTHORIZED` protokolliert. Die nächste Aktion darf nur den schon vorgesehenen GEVO-Wert prüfen. Keine Journaldatei wird gelöscht oder neu erstellt. Eine weitere automatische Wiederholung ist blockiert.
- Alle Zustände ab `UPLOAD_INTENT`, `DESCRIPTION_INTENT`, `DRAFT_SAVE_INTENT`, `TICKET_SAVE_INTENT` und `EXECUTE_INTENT` bleiben nicht wiederholbar. Menü 5 für Phase 1 ist keine Freigabe hierfür.

## Fiktive Browser-End-to-End-Tests

1. Leeres, vollständig verdecktes GEVO-Feld: eine operatorgesteuerte physische Fokussierung, echte Tastatureingabe, korrekter Vorschlag, kein Versand.
2. Behauptete manuelle Fokussierung ohne tatsächlichen Fokus: kein Schreiben, kein Sendeklick.
3. Zwei lokale Kontoauszugs-PDFs im echten Chromium-Dateifeld: ein Entwurfsklick, ein Ticket-Speicherklick, ein Review-Klick, kein E-Mail-Sendeklick. Der fiktive Browser simuliert die Anzeige nach Speichern; der echte COMARCH-Persistenznachweis bleibt bis zum Windows-Piloten offen.
4. Alter RC41-Journalstand `GEVO_INTENT` mit Hashabgleich: ein einziges genehmigtes Fokus-Retry; negative Fälle mit verändertem Hash, falscher Freigabe, `UPLOAD_INTENT` oder zweitem Retry werden abgelehnt.

## Sichere Bedienung

1. RC42 separat entpacken und über Menü 1 aktualisieren; RC41-`.runtime`-Daten bleiben unverändert.
2. Menü 9 für eine frische Nur-Lese-Inventur. Menü 11/PDF-Proof nur erneuern, wenn älter als sieben Tage oder PDFs verändert.
3. Menü 12 mit demselben vorbereiteten Ticket 87278094: bei erkannten alten `GEVO_INTENT`-Journal wird der oben beschriebene unabhängige Beleg erwartet. Bei Unklarheit ABBRUCH, keine erneute Anlage.
4. Bei `P2_GEVO_MANUAL_FOCUS` **nur** das eine GEVO-Eingabefeld anklicken, zurück zum Terminal, `FOKUS` eingeben. Danach gegebenenfalls den echten COMARCH-Vorschlag auswählen und `AUSGEWAEHLT` eingeben.
5. Der Rest bleibt streng bewacht: zwei PDFs, `Bearbeitet not reviewed`, Entwurf speichern, Ticket speichern, nach Wiederöffnen verifizieren, *erst dann* optionale Freigabe `WEITERLEITEN` an `mark.baindl`. Kein E-Mail-Versand und keine automatischen PDF-Generatorstarts.

Nicht produktiv verifiziert: tatsächliche COMARCH-Dateianlage, Persistenz nach neuer Anmeldung und finale Weiterleitung. Ein bestandener fiktiver Chromium-Test ersetzt diesen Nachweis nicht.
