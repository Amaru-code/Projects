# RC43: Echte FilePond-Anlage vor GEVO

## Reproduzierter Fehler
RC42 wurde auf einem echten Ticket durch ein altes `GEVO_INTENT` unterbrochen; nach nicht erteilter Wiederaufnahme wurde die Ausführung korrekt gestoppt, **ohne dass ein Datei-Upload begonnen wurde**. Auch der vorherige positive RC39/RC42-Fiktionstest verwendete nur das alte Eingabefeld `emailAttachmentFileUpload` und erfasste den dynamischen FilePond-Dialog nicht.

## Neuer Ablauf
1. Aktuelle Nur-Lese-Inventur und geprüften Menü-11-PDF-Beleg erneut laden; dieselbe Ticket-ID, dieselbe zusätzliche Beschreibung, unveränderte Planarten und unveränderte PDF-SHA256 prüfen.
2. Eindeutig ausgewähltes COMARCH-Member lesen; wenn `mainForm:member-value-id` den konkreten Suffix `INTL01-11368989` trägt, gegen Profilname und gebundene Member-ID prüfen. Ein solcher numerischer Suffix ist **kein genereller Ersatz** für eine explizite WWID: er dient nur als zusätzlicher Cross-Check zur zuvor gesondert verifizierten PDF-WWID. Bei abweichendem expliziten WWID-Feld stoppen.
3. Im geöffneten Bearbeitungsticket das FilePond-Label mit dem exakt angezeigten Text suchen. Die Label-ID darf wechseln; ausschließlich das über das `for`-Attribut gebundene File-Input ist zulässig. Bei fehlender eindeutiger Oberfläche **vor Journaleintrag** den Operator bitten, den Anhangsbereich sichtbar zu öffnen; keinen blind geratenen Klick.
4. Erst vor dem tatsächlichen Browserdialog `UPLOAD_INTENT` unveränderbar schreiben. Das sichtbare Label mit einem echten Browser-Mausklick betätigen, den nativen Chromium-Dateidialog abfangen, dessen `backendNodeId` unabhängig als dasselbe File-Input bestätigen und die lokal geprüften absoluten PDF-Pfade über `DOM.setFileInputFiles` übergeben. Dies ist echte File-Input-Auswahl, kein gefälschtes DOM-Event. Bei Einzelauswahl zweite Datei nach erneuter FilePond-Bindung wählen.
5. Beide Dateinamen in FilePond beobachten, Lade-/Fehlerzustände blockieren und `UPLOAD_VERIFIED` ausschließlich als *vorläufig in der Browseroberfläche erfasst* protokollieren. Ein vorzeitiger Abbruch führt **nicht** zu einem automatischen zweiten Upload.
6. Erst jetzt `mainForm:gevo-value-id` sicher auf `Anfrage Member` setzen; bei verdecktem Feld die bestehende verifizierte manuelle Fokus-Hilfe verwenden. Keine alten USC-/Standardantwort-/Möchte-Zeilen überschreiben. Vierte Zeile nur `Bearbeitet not reviewed`.
7. Entwurf/Ticket genau einmal speichern; Ticket serverseitig neu öffnen und beide PDF-Dateinamen sowie Beschreibungszeilen erneut lesen. **Vor diesem Nachweis keine Weiterleitung**; PDF-Name im Dateiauswahldialog allein beweist weder erfolgreiches Hochladen noch Persistenz.
8. Nach ausdrücklichem `WEITERLEITEN` wird `FORWARD_TO_REVIEW`, Bearbeiter `mark.baindl` und genau einmal `Schritt ausführen` genutzt. Das COMARCH-Ergebnis und die Entfernung aus der eigenen Aufgabenliste werden separat geprüft. Keine E-Mail senden.

## Journal/Wiederanlauf
Neuer Journalpfad: PREPARED -> UPLOAD_INTENT -> UPLOAD_VERIFIED -> GEVO_INTENT -> GEVO_VERIFIED -> DESCRIPTION_INTENT ... -> ROUTED_VERIFIED. Der unveränderte RC41/42-Altpfad bleibt für bestehende Statusleser lesbar. Bei vorherigem `GEVO_INTENT` mit ausschließlich PREPARED und GEVO_INTENT, gleichen PDF- und Beschreibungs-Hashes, ohne im Ticket vorhandene Anlagen und nach einer **kombinierten** unabhängigen Betreiberfreigabe wird `GEVO_FOCUS_RETRY_OPERATOR_AUTHORIZED` als einmaliges Zusatzereignis angehängt und die neue Reihenfolge fortgesetzt. Keine Journallöschung, keine erneute automatische Dateianlage nach einem unklaren `UPLOAD_INTENT`.

## Getestete Fälle
- Chromium: dynamische FilePond-Label-/Input-ID, 2 PDFs über einen abgefangenen nativen Dateidialog, erst danach echtes GEVO, genau je ein Draft/Ticket/Review-Klick, keine SEND-Aktion.
- Chromium: einzelner File-Input und dynamischer ID-Wechsel nach der ersten Datei; die zweite Datei wird separat gewählt, ohne die erste zu verlieren.
- Überdecktes Label: kein Klick, keine Dateiauswahl und kein Sendeversuch.
- Nur-Lese Member: `Huertgen Frank (INTL01-11368989)` wird mit dem strukturierten Profil verglichen; andere Namen werden nicht stillschweigend übernommen, explizit beschriftete WWID bleibt unabhängig.
- Journal: neuer Upload-Zuerst-Pfad und einmaliger, auditierter RC42-GEVO-Altstand; doppelte Freigaben oder offene Upload-/Speicherintents sind nicht wiederholbar.

## Grenzen
Nur der echte Windows-/COMARCH-Einzelticket-Pilot kann belegen, dass die jeweilige produktive FilePond-Version den Upload und die anschließende Serverpersistenz erlaubt. Der Bot startet keine externen Generatoren und schickt keine E-Mail. Ein festhängender `UPLOAD_INTENT` erfordert Untersuchung des tatsächlichen Vorgangs und wird nicht automatisch freigegeben.
