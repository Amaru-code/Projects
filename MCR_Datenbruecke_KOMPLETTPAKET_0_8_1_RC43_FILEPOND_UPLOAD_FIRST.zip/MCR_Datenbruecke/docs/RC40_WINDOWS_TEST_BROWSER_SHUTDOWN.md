# RC40 – Testbrowser beendet, bevor die Installationsprüfung entscheidet

## Reproduzierter Windows-Fall (03.11.2026)

RC39 meldete **357/358 PASS**; die einzige fehlerhafte Suite war
`rc32-comarch-browser-e2e.test.mjs`, Szenario `missing-comarch-member-mark`.
Beide Testtickets wurden ohne E-Mail an `mark.baindl` weitergeleitet und der
Browser meldete `RUN COMPLETE`, aber der Child-Prozess lieferte innerhalb des
140-Sekunden-Testlimits keinen Exitcode (`signal: SIGTERM`, `status: null`).
Deshalb durfte `SELFTEST_SLIM_RUNTIME` zu Recht nicht ausgestellt werden.

## Korrektur

- Ausschließlich **fiktive Browserläufe** schließen den selbst gestarteten
  Chromium/Edge zuerst über `Browser.close` (CDP), schließen danach das
  WebSocket, prüfen den Child-Exit und verwenden notfalls einen einmaligen
  Kill mit separater begrenzter Wartezeit. Unbestätigter Browser-Exit
  bleibt Testfehler und wird nicht als PASS gewertet.
- Der Node-Testläufer begrenzt parallele Testdateien auf vier, um Windows
  Edge/Chromium-Profile nicht durch zu viele gleichzeitige Browser zu
  überlasten. Keine Wartezeit wurde dem produktiven Ticketlauf hinzugefügt.
- Der betreffende Zwei-Ticket-Browsertest bekommt eine begrenzte
  Windows-taugliche Zeitreserve (185 s Child/195 s Suite). Maßgeblich
  bleibt **Exitcode 0 ohne Signal** plus bestätigtes Weiterleitungsjournal,
  nicht die bloße Konsolenausgabe.
- Erfolgreich getestete Kontoauszug-Verarbeitung (Menüs 9–12), Phase 1,
  Mapping, Daten und Journal bleiben funktional unverändert.

## Installation

RC39 wurde bei `STOP SELFTEST_FAILED` nicht installiert. RC40 wird aus
separatem Ordner installiert und akzeptiert die originale RC38- wie auch
RC39-Ausgangsversion nur bei bekanntem, vollständig verifiziertem Manifest.
