import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {phase2Journal,digestDescription} from '../lib/phase2-write-journal.mjs';
import {phase2Inventory} from '../lib/phase2-readonly.mjs';
import {inspectExistingStatements} from '../lib/phase2-pdf-evidence.mjs';
import {preflightPhase2Write} from '../src/phase2-comarch-pilot.mjs';
import {writeJSON} from '../lib/control.mjs';

const ID='87278094',WWID='11368989',DESCRIPTION='USC 20/ DC;PP+\nStandardantwort versendet\nMöchte Kontoauszug';
function fixture(run){
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC42-GEVO-'));
 const root=path.join(dir,'MCR_Datenbruecke');const base=path.join(root,'.runtime','phase2');fs.mkdirSync(base,{recursive:true});
 try{
  for(const [plan,folder] of [['DC','Kontoauszug DC'],['PP+','Kontoauszug_pp+']]){
   const dest=path.join(dir,folder,'Ausgabe_PDF');fs.mkdirSync(dest,{recursive:true});
   fs.writeFileSync(path.join(dest,`${WWID}_Kontoauszug_${plan}.pdf`),'%PDF-1.4\n'+(' '.repeat(200))+'\n%%EOF\n');
  }
  writeJSON(path.join(base,'MCR_PHASE2_LETZTE_INVENTUR.json'),phase2Inventory([{ticketId:ID,source:'POST',descriptionValue:DESCRIPTION}]));
  const proof={...inspectExistingStatements(root,['DC','PP+'],WWID),ticketId:ID,operatorContentReviewed:true,operatorPersonTicketBindingReviewed:true};
  writeJSON(path.join(base,`MCR_PHASE2_PDF_BELEG_${ID}_2026-11-03T08-00-00-000Z.json`),proof);
  return run({root,proof});
 }finally{fs.rmSync(dir,{recursive:true,force:true,maxRetries:5,retryDelay:100});}
}
test('RC42 authentic RC41 GEVO_INTENT can be resumed once only after explicit independent review',()=>fixture(({root,proof})=>{
 const first=preflightPhase2Write(root,ID);assert.equal(first.recoveryNeeded,false);
 first.journal.begin();first.journal.advance('GEVO_INTENT');
 const next=preflightPhase2Write(root,ID);assert.equal(next.recoveryNeeded,true);
 assert.deepEqual(next.journal.read().events.map(e=>e.state),['PREPARED','GEVO_INTENT']);
 assert.throws(()=>next.journal.approveGevoFocusRetry({...next.initial,operatorConfirmed:false,ticketUnchanged:true,noAttachments:true}),e=>e.code==='P2_GEVO_RECOVERY_BLOCKED');
 assert.throws(()=>next.journal.approveGevoFocusRetry({...next.initial,operatorConfirmed:true,ticketUnchanged:false,noAttachments:true}),e=>e.code==='P2_GEVO_RECOVERY_BLOCKED');
 assert.throws(()=>next.journal.approveGevoFocusRetry({...next.initial,operatorConfirmed:true,ticketUnchanged:true,noAttachments:false}),e=>e.code==='P2_GEVO_RECOVERY_BLOCKED');
 assert.throws(()=>next.journal.approveGevoFocusRetry({...next.initial,descriptionSha256:digestDescription('DIFFERENT'),operatorConfirmed:true,ticketUnchanged:true,noAttachments:true}),e=>e.code==='P2_GEVO_RECOVERY_BLOCKED');
 assert.equal(next.journal.approveGevoFocusRetry({...next.initial,operatorConfirmed:true,ticketUnchanged:true,noAttachments:true}).state,'GEVO_INTENT');
 assert.equal(next.journal.read().recoveryCount,1);
 assert.throws(()=>preflightPhase2Write(root,ID),e=>e.code==='P2_ALREADY_ATTEMPTED');
 assert.throws(()=>next.journal.approveGevoFocusRetry({...next.initial,operatorConfirmed:true,ticketUnchanged:true,noAttachments:true}),e=>e.code==='P2_GEVO_RECOVERY_BLOCKED');
 for(const step of ['GEVO_VERIFIED','UPLOAD_INTENT'])next.journal.advance(step);
 assert.throws(()=>preflightPhase2Write(root,ID),e=>e.code==='P2_ALREADY_ATTEMPTED');
}));
test('RC42 no automatic recovery from PREPARED, GEVO_VERIFIED, UPLOAD_INTENT, SAVE or REVIEW',()=>fixture(({root})=>{
 const p=preflightPhase2Write(root,ID),j=p.journal;j.begin();
 assert.throws(()=>preflightPhase2Write(root,ID),e=>e.code==='P2_ALREADY_ATTEMPTED');
 j.advance('GEVO_INTENT');j.advance('GEVO_VERIFIED');
 assert.throws(()=>preflightPhase2Write(root,ID),e=>e.code==='P2_ALREADY_ATTEMPTED');
 j.advance('UPLOAD_INTENT');
 assert.throws(()=>preflightPhase2Write(root,ID),e=>e.code==='P2_ALREADY_ATTEMPTED');
 assert.equal(j.mayRetryGevoFocus(p.initial),false);
}));
