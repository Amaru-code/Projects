import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
import {setPhase2Gevo,uploadControl,attachLocalFiles,observedAttachments,savePhase2Draft,savePhase2Ticket,
 selectReviewMode,selectReviewAssignee,executeReview} from '../lib/phase2-comarch-actions.mjs';

// The old RC39 fixture was prefilled with "Anfrage Member". This scenario
// proves the entire pilot-facing action sequence from an EMPTY, overlaid GEVO
// through two native PDF files, distinct saves and exactly one review action.
test('RC42 full Chromium: blank overlaid GEVO, verified manual focus, two PDFs, one draft/save/review and zero sends',{timeout:80000},async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC42-REVIEW-'));
 const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-P2-DOM-'));
 let browser,cdp;
 try{
  const files=['11368989_Kontoauszug_DC.pdf','11368989_Kontoauszug_PP+.pdf'].map(n=>path.join(dir,n));
  for(const file of files)fs.writeFileSync(file,'%PDF-1.4\n'+('0'.repeat(210))+'\n%%EOF\n');
  browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,
   extraArgs:['--disable-background-networking','--disable-sync',...(process.platform!=='win32'&&process.getuid?.()===0?['--no-sandbox']:[])]});
  ({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.url==='about:blank');
  await page.call(function(){document.body.innerHTML=`<main style="position:relative;height:400px">
   <input id="mainForm:gevo-value-id" value="" style="position:absolute;top:50px;left:30px;width:220px;height:30px">
   <div id="veil" style="position:absolute;top:0;left:0;width:300px;height:110px;background:#bbb;z-index:10"></div>
   <div id="suggestion" role="option" onclick="void 0" style="display:none;position:absolute;top:90px;left:30px;width:220px;height:25px">Anfrage Member</div>
   <input id="emailAttachmentFileUpload" name="files[]" type="file" multiple style="display:none;position:absolute;top:145px;left:30px">
   <ul id="serverAttachments"></ul><a href="#" id="draft" style="position:absolute;top:210px;left:25px">Entwurf speichern</a>
   <a href="#" id="save" style="position:absolute;top:245px;left:25px">Ticket speichern</a>
   <select id="review" style="position:absolute;top:280px;left:25px"><option value=""> </option><option value="FORWARD_TO_REVIEW">Weiterleiten zur Überprüfung</option></select>
   <input id="mainForm:next-persona-assignment-id" value="Baindl Mark (mark.baindl)" style="position:absolute;top:310px;left:25px">
   <button id="execute" style="position:absolute;top:350px;left:25px">Schritt ausführen</button>
   <button id="send" style="position:absolute;top:380px;left:25px">Senden</button></main>`;
   window._p2={focusManual:0,option:0,upload:0,draft:0,save:0,review:0,send:0,serverNames:[]};
   const field=document.getElementById('mainForm:gevo-value-id');const opt=document.getElementById('suggestion');
   field.addEventListener('keyup',()=>opt.style.display='block');
   opt.addEventListener('click',()=>{window._p2.option++;field.value='Anfrage Member';document.getElementById('emailAttachmentFileUpload').style.display='block';});
   document.getElementById('emailAttachmentFileUpload').addEventListener('change',ev=>{
    window._p2.upload++;window._p2.serverNames=[...ev.target.files].map(x=>x.name);
    document.getElementById('serverAttachments').innerHTML=window._p2.serverNames.map(x=>'<li>'+x+'</li>').join('');
   });
   for(const [key,id] of [['draft','draft'],['save','save'],['review','execute'],['send','send']])document.getElementById(id).addEventListener('click',e=>{e.preventDefault();window._p2[key]++;});
  });
  const res=await setPhase2Gevo(page,{manualFocus:async()=>{
   await page.call(()=>{document.getElementById('veil').remove();window._p2.focusManual++});
   await page.mouseClick(48,63);
  },manualSelect:async()=>assert.fail('Expected exact suggestion click')});
  assert.equal(res.ok,true);
  assert.equal((await uploadControl(page)).ok,true);
  await attachLocalFiles(page,files);
  assert.deepEqual((await observedAttachments(page,files.map(f=>path.basename(f)))).present,[true,true]);
  await savePhase2Draft(page);await savePhase2Ticket(page);
  // The fake COMARCH server re-displays the persisted names on re-entry.
  await page.call(()=>{
   const names=[...window._p2.serverNames];
   document.getElementById('serverAttachments').replaceChildren();
   for(const n of names){const li=document.createElement('li');li.textContent=n;document.getElementById('serverAttachments').appendChild(li);}
  });
  assert.deepEqual((await observedAttachments(page,files.map(f=>path.basename(f)))).present,[true,true]);
  await selectReviewMode(page);await selectReviewAssignee(page);await executeReview(page);
  assert.deepEqual(await page.eval('window._p2'),{
   focusManual:1,option:1,upload:1,draft:1,save:1,review:1,send:0,serverNames:files.map(f=>path.basename(f))});
  console.log('PASS RC42_GEVO_THROUGH_TWO_PDFS_AND_SINGLE_REVIEW');
 }finally{
  try{await cleanupTemporaryTestBrowser({profile,browser,cdp});}
  finally{fs.rmSync(dir,{recursive:true,force:true,maxRetries:5,retryDelay:100});}
 }
});
