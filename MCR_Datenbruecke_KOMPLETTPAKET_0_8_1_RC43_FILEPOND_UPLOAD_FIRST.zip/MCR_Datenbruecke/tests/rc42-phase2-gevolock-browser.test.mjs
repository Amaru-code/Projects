import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
import {setPhase2Gevo} from '../lib/phase2-comarch-actions.mjs';

const options={timeout:65000};
test('RC42 Chromium blank and obstructed GEVO: operator physical focus, trusted typing and committed exact option; no save/send',options,async()=>{
 const profile=fs.mkdtempSync(os.tmpdir()+'/MCR-P2-DOM-');let browser,cdp;
 try{
  browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,
   extraArgs:['--disable-background-networking','--disable-sync',...(process.platform!=='win32'&&process.getuid?.()===0?['--no-sandbox']:[])]});
  ({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.url==='about:blank');
  await page.call(function(){
   document.body.innerHTML=`<div id="panel" style="position:relative;height:330px">
    <input id="mainForm:gevo-value-id" value="" style="position:absolute;left:30px;top:40px;width:210px;height:30px" />
    <div id="overlay" style="position:absolute;left:0;top:0;width:280px;height:110px;background:#aaa;z-index:10"></div>
    <div role="option" id="option" style="display:none;position:absolute;left:30px;top:78px;width:210px;height:25px">Anfrage Member</div>
    </div><button id="send">Senden</button><button id="save">Ticket speichern</button>`;
   window.__rc42={manual:0,selection:0,send:0,save:0,keyup:0};
   const f=document.getElementById('mainForm:gevo-value-id');
   f.addEventListener('keyup',()=>{window.__rc42.keyup++;document.getElementById('option').style.display='block';});
   document.getElementById('option').addEventListener('click',()=>{window.__rc42.selection++;f.value='Anfrage Member';});
   document.getElementById('send').addEventListener('click',()=>window.__rc42.send++);
   document.getElementById('save').addEventListener('click',()=>window.__rc42.save++);
  });
  let asked=0;
  const result=await setPhase2Gevo(page,{manualFocus:async(reason)=>{
   asked++;assert.match(reason,/OCCLUDED|OFFSCREEN|NOT_CONFIRMED/);
   // Simulate the operator removing an obstruction and PHYSICALLY clicking
   // the exact field using Chromium's trusted mouse path, not JS focus().
   await page.call(()=>document.getElementById('overlay').remove());
   await page.mouseClick(60,52);
   const state=await page.call(()=>({focused:document.activeElement?.id,value:document.getElementById('mainForm:gevo-value-id').value}));
   assert.equal(state.focused,'mainForm:gevo-value-id');assert.equal(state.value,'');
  },manualSelect:async()=>assert.fail('COMARCH option must be clickable in this test')});
  assert.equal(result.ok,true);assert.equal(asked,1);
  const resultState=await page.call(()=>({...window.__rc42,value:document.getElementById('mainForm:gevo-value-id').value}));
  assert.equal(resultState.value,'Anfrage Member');assert.equal(resultState.selection,1);
  assert.equal(resultState.send,0);assert.equal(resultState.save,0);
  console.log('PASS RC42_BLANK_OCCLUDED_GEVO_TRUSTED_MANUAL_FOCUS');
 }finally{await cleanupTemporaryTestBrowser({profile,browser,cdp});}
});
test('RC42 Chromium blocked GEVO: fake operator confirmation without actual focus cannot type, save or send',options,async()=>{
 const profile=fs.mkdtempSync(os.tmpdir()+'/MCR-P2-DOM-');let browser,cdp;
 try{
  browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,
   extraArgs:['--disable-background-networking','--disable-sync',...(process.platform!=='win32'&&process.getuid?.()===0?['--no-sandbox']:[])]});
  ({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.url==='about:blank');
  await page.call(function(){
   document.body.innerHTML=`<div style="position:relative;height:280px"><input id="mainForm:gevo-value-id" value="" style="position:absolute;left:30px;top:40px;width:220px;height:30px"/><div style="position:absolute;left:0;top:0;width:290px;height:110px;z-index:10;background:#aaa"></div></div><button>Senden</button>`;
   window.calls=0;document.querySelector('button').onclick=()=>window.calls++;
  });
  let attempts=0;
  await assert.rejects(setPhase2Gevo(page,{manualFocus:async()=>{attempts++;},manualSelect:async()=>assert.fail('Must not reach dropdown')}),e=>e.code==='MANUAL_INPUT_FOCUS_UNVERIFIED');
  assert.equal(attempts,1);
  const state=await page.call(()=>({value:document.getElementById('mainForm:gevo-value-id').value,focus:document.activeElement?.id,calls:window.calls}));
  assert.equal(state.value,'');assert.notEqual(state.focus,'mainForm:gevo-value-id');assert.equal(state.calls,0);
  console.log('PASS RC42_INVALID_MANUAL_FOCUS_BLOCKS_BEFORE_TYPING');
 }finally{await cleanupTemporaryTestBrowser({profile,browser,cdp});}
});
