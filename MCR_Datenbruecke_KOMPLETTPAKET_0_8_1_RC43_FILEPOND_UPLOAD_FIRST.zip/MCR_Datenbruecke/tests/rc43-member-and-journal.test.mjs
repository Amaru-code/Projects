import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
import {readPhase2MemberEvidence} from '../lib/phase2-member-evidence.mjs';
import {phase2Journal,digestDescription} from '../lib/phase2-write-journal.mjs';

test('RC43 Member INTL01 reference is an exact bound hint, never a substitute for a labelled WWID',{timeout:40000},async()=>{
 const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-P2-DOM-RC43-MEMBER-'));let browser,cdp;
 try{
  browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,
   extraArgs:['--disable-background-networking','--disable-sync',...(process.platform!=='win32'&&process.getuid?.()===0?['--no-sandbox']:[])]});
  ({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.url==='about:blank');
  await page.call(()=>{document.body.innerHTML=`<form id="mainForm"><input id="mainForm:member-value-id" value="Huertgen Frank (INTL01-11368989)"/>
   <table><tbody><tr><td>Mercer ID</td><td>INTL01-11368989</td></tr><tr><td>Vorname</td><td>Frank</td></tr><tr><td>Nachname</td><td>Huertgen</td></tr></tbody></table></form>`;
   window.clicks=0;document.addEventListener('click',()=>window.clicks++);});
  let r=await readPhase2MemberEvidence(page);
  assert.equal(r.profileVerified,true);assert.equal(r.memberReferenceWwid,'11368989');assert.equal(r.wwid,null);assert.equal(await page.eval('window.clicks'),0);
  await page.call(()=>document.getElementById('mainForm:member-value-id').value='Someone Else (INTL01-11368989)');
  r=await readPhase2MemberEvidence(page);assert.equal(r.memberReferenceWwid,null);
  await page.call(()=>{document.getElementById('mainForm:member-value-id').value='Huertgen Frank (INTL01-11368989)';
   const row=document.createElement('tr');row.innerHTML='<td>WWID</td><td>77123456</td>';document.querySelector('tbody').append(row);});
  r=await readPhase2MemberEvidence(page);assert.equal(r.wwid,'77123456');assert.equal(r.memberReferenceWwid,'11368989');
  console.log('PASS RC43_BOUND_MEMBER_REFERENCE');
 }finally{await cleanupTemporaryTestBrowser({profile,browser,cdp});}
});

test('RC43 new journal means PDF UPLOAD before GEVO, old GEVO_INTENT may migrate only once and only with review',()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC43-JOURNAL-'));
 const ID='87278094',initial={ticketId:ID,descriptionSha256:digestDescription('USC 20/ DC;PP+\nStandardantwort versendet\nMöchte Kontoauszug'),pdfHashes:[{plan:'PP+',sha256:'a'.repeat(64)},{plan:'DC',sha256:'b'.repeat(64)}]};
 try{
  let journal=phase2Journal(dir,ID,{initial});journal.begin();
  for(const state of ['UPLOAD_INTENT','UPLOAD_VERIFIED','GEVO_INTENT','GEVO_VERIFIED','DESCRIPTION_INTENT'])journal.advance(state);
  assert.deepEqual(journal.read().events.map(x=>x.state),['PREPARED','UPLOAD_INTENT','UPLOAD_VERIFIED','GEVO_INTENT','GEVO_VERIFIED','DESCRIPTION_INTENT']);
  assert.equal(journal.mayRetryGevoFocus(initial),false);
  const oldId='87393963',old=phase2Journal(dir,oldId,{initial:{...initial,ticketId:oldId}});old.begin();old.advance('GEVO_INTENT');
  assert.equal(old.mayRetryGevoFocus(initial),true);
  assert.throws(()=>old.approveGevoFocusRetry({...initial,operatorConfirmed:false,ticketUnchanged:true,noAttachments:true}),e=>e.code==='P2_GEVO_RECOVERY_BLOCKED');
  old.approveGevoFocusRetry({...initial,operatorConfirmed:true,ticketUnchanged:true,noAttachments:true});
  old.advance('UPLOAD_INTENT');old.advance('UPLOAD_VERIFIED');old.advance('GEVO_INTENT');old.advance('GEVO_VERIFIED');
  assert.equal(old.read().recoveryCount,1);assert.equal(old.mayRetryGevoFocus(initial),false);
  assert.deepEqual(old.read().events.map(x=>x.state),['PREPARED','GEVO_INTENT','GEVO_FOCUS_RETRY_OPERATOR_AUTHORIZED','UPLOAD_INTENT','UPLOAD_VERIFIED','GEVO_INTENT','GEVO_VERIFIED']);
  console.log('PASS RC43_UPLOAD_FIRST_WITH_LEGACY_JOURNAL');
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
