import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import {spawnSync} from 'node:child_process';
import {ROOT} from './helpers.mjs';import {certifyForwardDemo} from '../tools/proof.mjs';
for(const [scenario,account] of [['missing-comarch-member','Victor.Gutierrez'],['missing-comarch-member-mark','mark.baindl']]){
 test('RC32 Chromium: two unknown-in-COMARCH tickets safely routed without email: '+account,{timeout:195000},()=>{
  const temp=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC32-NOCOMARCH-'));
  try{
   for(const n of ['src','lib','examples','config'])fs.cpSync(path.join(ROOT,n),path.join(temp,n),{recursive:true});
   const p=path.join(temp,'config/local-runner-queue-send.json'),config=JSON.parse(fs.readFileSync(p));
   fs.writeFileSync(p,JSON.stringify({...config,profileDirectory:'.runtime/edge-profile',downloadDirectory:'.runtime/downloads',runtimeDirectory:'.runtime',diagnosticDirectory:'diagnostics'}));
   const r=spawnSync(process.execPath,[path.join(temp,'src/local-bot-full-run.mjs'),'--demo','--close-browser'],{
    cwd:temp,encoding:'utf8',env:{...process.env,MCR_DEMO_SCENARIO:scenario,MCR_RUN_ID:'rc32-no-comarch-'+account},timeout:185000,maxBuffer:10*1024*1024});
   assert.equal(r.status,0,JSON.stringify({stdout:r.stdout?.slice(-2800),stderr:r.stderr?.slice(-1000),signal:r.signal}));
   assert.match(r.stdout,/PERSON_IN_COMARCH_NICHT_GEFUNDEN/);
   assert.doesNotMatch(r.stdout,/SEND_DIALOGS_CONFIRMED/);
   const d=JSON.parse(fs.readFileSync(path.join(temp,'diagnostics/last-result.json'),'utf8'));
   certifyForwardDemo(d);
   assert.equal(d.send.clicked,false);assert.equal(d.loop.processed,2);assert.equal(d.loop.forwarded,2);
   assert.deepEqual(d.loop.processedTickets.map(x=>x.assignee),[account==='mark.baindl'?'1':'2',account==='mark.baindl'?'1':'2']);
   assert.deepEqual(d.loop.processedTickets.map(x=>x.lookup),['NOT_IN_COMARCH','NOT_IN_COMARCH']);
   console.log('PASS RC32_NO_COMARCH_TWO_TICKETS_NO_EMAIL '+account);
  }finally{fs.rmSync(temp,{recursive:true,force:true,maxRetries:5,retryDelay:250});}
 });
}
test('RC32 Chromium: existing profile hint cannot be mislabeled unknown and cannot save/forward',{timeout:80000},()=>{
 const temp=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC32-NEGATIVE-'));
 try{
  for(const n of ['src','lib','examples','config'])fs.cpSync(path.join(ROOT,n),path.join(temp,n),{recursive:true});
  const p=path.join(temp,'config/local-runner-queue-send.json'),cfg=JSON.parse(fs.readFileSync(p));
  fs.writeFileSync(p,JSON.stringify({...cfg,profileDirectory:'.runtime/edge-profile',downloadDirectory:'.runtime/downloads',runtimeDirectory:'.runtime',diagnosticDirectory:'diagnostics'}));
  const r=spawnSync(process.execPath,[path.join(temp,'src/local-bot-full-run.mjs'),'--demo','--close-browser'],{
   cwd:temp,encoding:'utf8',env:{...process.env,MCR_DEMO_SCENARIO:'missing-comarch-profile-hint',MCR_RUN_ID:'rc32-negative'},timeout:70000,maxBuffer:10*1024*1024});
  assert.notEqual(r.status,0);
  assert.match(r.stderr,/STOP DEMO_COMARCH_MEMBER_UNRESOLVED/);
  const d=JSON.parse(fs.readFileSync(path.join(temp,'diagnostics/last-result.json'),'utf8'));
  assert.equal(d.send.clicked,false);assert.equal(d.save.clicked,false);assert.equal(d.loop.processed,0);
  assert.equal(d.lastError,'DEMO_COMARCH_MEMBER_UNRESOLVED');
  console.log('PASS RC32_PROFILE_HINT_BLOCKS_UNKNOWN_FORWARD');
 }finally{fs.rmSync(temp,{recursive:true,force:true,maxRetries:5,retryDelay:250});}
});
