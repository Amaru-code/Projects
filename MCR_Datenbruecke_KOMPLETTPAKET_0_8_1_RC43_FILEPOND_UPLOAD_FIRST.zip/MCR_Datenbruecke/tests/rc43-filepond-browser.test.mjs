import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
import {phase2UploadSurface,attachPhase2Files,filepondItems} from '../lib/phase2-filepond.mjs';
import {setPhase2Gevo,observedAttachments,savePhase2Draft,savePhase2Ticket,selectReviewMode,selectReviewAssignee,executeReview} from '../lib/phase2-comarch-actions.mjs';

const makePdf=file=>fs.writeFileSync(file,'%PDF-1.4\n'+('0'.repeat(250))+'\n%%EOF\n');
const fixture=async(run)=>{
 const temp=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC43-FILEPOND-'));
 const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-P2-DOM-RC43-'));
 let browser,cdp;
 try{
  const files=['11368989_Kontoauszug_PP+.pdf','11368989_Kontoauszug_DC.pdf'].map(n=>path.join(temp,n));files.forEach(makePdf);
  browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,
   extraArgs:['--disable-background-networking','--disable-sync',...(process.platform!=='win32'&&process.getuid?.()===0?['--no-sandbox']:[])]});
  ({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.url==='about:blank');
  return await run({page,files,profile});
 }finally{try{await cleanupTemporaryTestBrowser({profile,browser,cdp});}finally{fs.rmSync(temp,{recursive:true,force:true,maxRetries:5,retryDelay:100});}}
};

test('RC43 FilePond dynamic label opens native chooser, two exact PDFs attached BEFORE GEVO, zero sends',{timeout:70000},()=>fixture(async({page,files})=>{
 await page.call(function(){document.body.innerHTML=`<div id="main" style="position:relative;min-height:700px">
 <div class="filepond--root"><input type="file" multiple id="filepond--browser-dyn999AbC" class="filepond--browser" style="position:absolute;left:30px;top:30px;width:1px;height:1px;opacity:0" />
 <label id="filepond--drop-label-dyn999AbC" for="filepond--browser-dyn999AbC" style="position:absolute;top:45px;left:30px;height:60px;width:440px;border:1px solid gray">Dateien hierher ziehen oder zum Auswählen klicken</label><ul id="filepondItems"></ul></div>
 <input id="mainForm:gevo-value-id" style="position:absolute;top:180px;left:30px;width:240px;height:32px" value="" />
 <div role="option" id="suggestion" style="display:none;position:absolute;top:215px;left:30px;width:220px;height:32px">Anfrage Member</div>
 <a id="draft" href="#" style="position:absolute;top:300px;left:30px">Entwurf speichern</a>
 <a id="ticketSave" href="#" style="position:absolute;top:345px;left:30px">Ticket speichern</a>
 <select id="review" style="position:absolute;top:380px;left:30px"><option value="">--</option><option value="FORWARD_TO_REVIEW">Weiterleiten zur Überprüfung</option></select>
 <input id="mainForm:next-persona-assignment-id" value="Baindl Mark (mark.baindl)" style="position:absolute;top:425px;left:30px"/>
 <button id="execute" style="position:absolute;top:465px;left:30px">Schritt ausführen</button><button id="send" style="position:absolute;top:520px;left:30px">Senden</button></div>`;
 window.rc43={selected:[],upload:0,gevo:0,draft:0,ticketSave:0,review:0,send:0,events:[]};
 const input=document.getElementById('filepond--browser-dyn999AbC');
 input.addEventListener('change',e=>{
  window.rc43.upload++;window.rc43.selected=[...e.target.files].map(f=>f.name);
  window.rc43.events.push('PDF');
  const list=document.getElementById('filepondItems');list.replaceChildren();
  for(const f of e.target.files){const item=document.createElement('li');item.className='filepond--item';item.setAttribute('data-filepond-item-state','processing-complete');
   const info=document.createElement('span');info.className='filepond--file-info-main';info.textContent=f.name;item.append(info);list.append(item);}
 });
 const gevo=document.getElementById('mainForm:gevo-value-id');const suggestion=document.getElementById('suggestion');
 gevo.addEventListener('keyup',()=>suggestion.style.display='block');
 suggestion.addEventListener('click',()=>{gevo.value='Anfrage Member';window.rc43.gevo++;window.rc43.events.push('GEVO');});
 for(const [id,key] of [['draft','draft'],['ticketSave','ticketSave'],['execute','review'],['send','send']]){
  document.getElementById(id).addEventListener('click',e=>{e.preventDefault();window.rc43[key]++;window.rc43.events.push(key);});
 }
 });
 assert.equal((await phase2UploadSurface(page)).mode,'FILEPOND');
 const upload=await attachPhase2Files(page,files);
 assert.equal(upload.mode,'FILEPOND');assert.deepEqual((await filepondItems(page,files.map(f=>path.basename(f)))).items.map(x=>x.status),['processing-complete','processing-complete']);
 assert.deepEqual((await observedAttachments(page,files.map(f=>path.basename(f)))).present,[true,true]);
 assert.equal((await setPhase2Gevo(page)).ok,true);
 await savePhase2Draft(page);await savePhase2Ticket(page);
 await selectReviewMode(page);await selectReviewAssignee(page);await executeReview(page);
 const proof=await page.eval('window.rc43');
 assert.deepEqual(proof.events,['PDF','GEVO','draft','ticketSave','review']);
 assert.equal(proof.send,0);
 assert.deepEqual(proof.selected,files.map(x=>path.basename(x)));
 console.log('PASS RC43_FILEPOND_NATIVE_PDFS_BEFORE_GEVO');
}));

test('RC43 FilePond label must be unoccluded or no chooser and no file selection',{timeout:35000},()=>fixture(async({page,files})=>{
 await page.call(function(){document.body.innerHTML=`<input type="file" id="filepond--browser-abc123" style="position:absolute;left:30px;top:30px;opacity:0;width:1px;height:1px"/><label id="filepond--drop-label-abc123" for="filepond--browser-abc123" style="position:absolute;left:30px;top:40px;width:300px;height:70px">Dateien hierher ziehen oder zum Auswählen klicken</label><div id="opaque" style="position:absolute;left:0;top:0;width:700px;height:300px;z-index:10;background:#aaa"></div>`;
 window.picked=false;document.querySelector('input').addEventListener('change',()=>window.picked=true);});
 await assert.rejects(()=>attachPhase2Files(page,[files[0]]),e=>e.code==='P2_FILEPOND_LABEL_BLOCKED');
 assert.equal(await page.eval('window.picked'),false);
 console.log('PASS RC43_FILEPOND_OCCLUDED_BLOCK');
}));

test('RC43 FilePond single-file chooser accepts two independent files and rebinds a changed dynamic ID',{timeout:50000},()=>fixture(async({page,files})=>{
 await page.call(function(){document.body.innerHTML=`<div class="filepond--root"><input type="file" id="filepond--browser-first123" style="position:absolute;left:20px;top:15px;opacity:0;width:1px;height:1px"/>
 <label id="filepond--drop-label-first123" for="filepond--browser-first123" style="position:absolute;left:20px;top:35px;width:420px;height:70px">Dateien hierher ziehen oder zum Auswählen klicken</label><ul id="filepondItems"></ul></div>`;
 window.saved=[];
 const decorate=el=>el.addEventListener('change',e=>{
  for(const f of e.target.files){window.saved.push(f.name);const li=document.createElement('li');li.className='filepond--item';li.setAttribute('data-filepond-item-state','idle');
   const span=document.createElement('span');span.className='filepond--file-info-main';span.textContent=f.name;li.append(span);document.getElementById('filepondItems').append(li);}
  // FilePond rebuilds the underlying input after every selection.
  const suffix=window.saved.length===1?'second456':'third789',old=document.querySelector('input[type=file]');
  const next=old.cloneNode();next.id='filepond--browser-'+suffix;old.replaceWith(next);decorate(next);
  const label=document.querySelector('label');label.id='filepond--drop-label-'+suffix;label.htmlFor=next.id;
 });
 decorate(document.querySelector('input[type=file]'));
 });
 assert.equal((await phase2UploadSurface(page)).multiple,false);
 await attachPhase2Files(page,files);
 assert.deepEqual(await page.eval('window.saved'),files.map(f=>path.basename(f)));
 assert.deepEqual((await observedAttachments(page,files.map(f=>path.basename(f)))).present,[true,true]);
 console.log('PASS RC43_FILEPOND_SINGLE_DYNAMIC_REBIND');
}));
