/** RC39 independent PHASE-2 supervised ONE-TICKET pilot. No Phase-1 send
 * orchestration, no automatic rerun, no arbitrary PDF generation.
 * Supports only an earlier operator-reviewed proof for DC and/or PP+.
 */
import fs from 'node:fs';import path from 'node:path';import readline from 'node:readline/promises';
import {fileURLToPath} from 'node:url';
import {requireThat as need} from '../lib/core.mjs';
import {readJSON,writeJSON,plainPath,ledger,stamp} from '../lib/control.mjs';
import {resolveConfig} from '../lib/config.mjs';import {loadActiveMapping} from '../lib/active-mapping.mjs';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachFreshPage,sleep} from '../lib/cdp.mjs';
import {phase2Inventory,readPhase2Queue} from '../lib/phase2-readonly.mjs';
import {inspectExistingStatements} from '../lib/phase2-pdf-evidence.mjs';
import {phase2DraftPreview} from '../lib/phase2-draft-preview.mjs';
import {readPhase2MemberEvidence} from '../lib/phase2-member-evidence.mjs';
import {phase2Journal,digestDescription} from '../lib/phase2-write-journal.mjs';
import {setPhase2Gevo,observedAttachments,selectReviewMode,
 selectReviewAssignee,savePhase2Draft,savePhase2Ticket,executeReview,phase2FieldSnapshot,reviewAssignmentState} from '../lib/phase2-comarch-actions.mjs';
import {forwardingNotices,forwardConfirmed} from '../lib/forwarding.mjs';
import {phase2UploadSurface,attachPhase2Files} from '../lib/phase2-filepond.mjs';
import * as UI from '../lib/browser-workflow.mjs';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const normalize=s=>String(s??'').replace(/\r\n?/g,'\n').trim();
async function ask(rl,q){return String(await rl.question(q)).trim();}
function phase2Dir(root){const p=path.join(root,'.runtime','phase2');plainPath(p);return p;}
function proofForTicket(root,id){
 const dir=phase2Dir(root),files=fs.readdirSync(dir).filter(f=>f.startsWith('MCR_PHASE2_PDF_BELEG_'+id+'_')&&f.endsWith('.json')).sort().reverse();
 need(files.length,'P2_PDF_PROOF_REQUIRED','Erst Menue 11 mit lokaler Inhaltspruefung abschliessen.');
 const proof=readJSON(path.join(dir,files[0]),256*1024);
 need(proof.schema==='MCR_PHASE2_PDF_PROOF_V1'&&proof.ticketId===id&&proof.operatorContentReviewed===true&&proof.operatorPersonTicketBindingReviewed===true,
  'P2_PDF_PROOF_INVALID','PDFs nicht ausreichend geprueft.');
 need(Date.now()-Date.parse(proof.verifiedAt)<7*24*60*60*1000,'P2_PDF_PROOF_OLD','PDF-Inhaltspruefung veraltet, Menue 11 erneut ausfuehren.');
 const ids=(proof.artifacts||[]).map(x=>/^(\d{4,15})_Kontoauszug_(DC|PP\+)\.pdf$/i.exec(x.name));
 need(ids.length===proof.artifacts.length&&ids.every(Boolean)&&new Set(ids.map(m=>m[1])).size===1,
  'P2_WWID_FILENAMES','Nur exakte WWID-Dateinamen mit identischer Personkennung.');
 const wwid=ids[0][1],verified=inspectExistingStatements(root,proof.targets,wwid);
 need(verified.artifacts.length===proof.artifacts.length&&verified.artifacts.every((a,i)=>{
  const expected=proof.artifacts.find(x=>x.plan===a.plan);return expected&&expected.sha256===a.sha256&&expected.bytes===a.bytes&&expected.name===a.name;
 }), 'P2_PDF_CHANGED','Pruefbelege oder PDFs wurden seit Menue 11 veraendert.');
 return {proof,verified,wwid};
}
export function preflightPhase2Write(root,ticketId){
 const inventory=readJSON(path.join(phase2Dir(root),'MCR_PHASE2_LETZTE_INVENTUR.json'),2*1024*1024);
 need(inventory?.schema==='MCR_PHASE2_INVENTORY_V1'&&inventory.readOnly,'P2_INVENTORY_REQUIRED','Menue 9 erneut ausfuehren.');
 need(Date.now()-Date.parse(inventory.generatedAt)<60*60*1000,'P2_INVENTORY_STALE','Bitte frische Inventur ueber Menue 9.');
 const item=inventory.items.find(x=>x.ticketId===ticketId);
 need(item?.kind==='NEEDS_VERIFIED_WWID','P2_TICKET_BLOCKED','Kein eindeutig vorbereiteter Kontoauszug-Kandidat.');
 need(!ledger(root).pending.some(x=>x.ticketId===ticketId),'P2_PHASE1_JOURNAL_PENDING','Phase-1-Journal noch ungeklärt.');
 const {proof,verified,wwid}=proofForTicket(root,ticketId);
 need(item.targets.length===proof.targets.length&&item.targets.every(x=>proof.targets.includes(x)),
  'P2_PLAN_CONFLICT','COMARCH-Planarten und PDF-Pruefung widersprechen sich.');
 const preview=phase2DraftPreview({ticketId,source:item.source,description:item.descriptionValue,pdfProof:proof});
 const initial={ticketId,descriptionSha256:digestDescription(item.descriptionValue),pdfHashes:proof.artifacts.map(x=>({plan:x.plan,sha256:x.sha256}))};
 const journal=phase2Journal(root,ticketId,{initial});
 const existing=journal.read();
 // RC42: existing GEVO_INTENT may be inspected for ONE audited pre-upload
 // focus retry. All other open write intents remain permanently blocked.
 const recoveryNeeded=!!existing;
 need(!existing||journal.mayRetryGevoFocus(initial),'P2_ALREADY_ATTEMPTED',
  'Phase-2-Aktion begonnen oder abgeschlossen. Nur GEVO_INTENT ohne weitere Aktion ist kontrolliert fortsetzbar.');
 return {item,proof,verified,wwid,preview,journal,initial,recoveryNeeded};
}

/** Intentionally every stage is a distinct monotonic ledger state.
 * Browser/OS crashes leave the last INTENT state requiring manual review.
 */
export async function phase2ComarchPilot({root=ROOT,askFn=ask,log=console.log,memberLookup=readPhase2MemberEvidence}={}){
 loadActiveMapping(root);
 const rl=readline.createInterface({input:process.stdin,output:process.stdout});
 let browser=null,cdp=null,armed=false;
 try{
  log('\nPHASE 2: Einzelticket-Pilot. KEINE E-MAIL, keine Generatorausfuehrung.');
  const id=await askFn(rl,'Vorbereitetes Kontoauszug-Ticket (z.B. 87278094): ');
  need(/^\d{6,12}$/.test(id),'P2_TICKET_ID','Ticketnummer erforderlich.');
  const {item,proof,verified,wwid,preview,journal,initial:journalInput,recoveryNeeded}=preflightPhase2Write(root,id);
  log('TICKET '+id+' | '+item.targets.join('+')+' | '+wwid+' | '+verified.artifacts.map(x=>x.name).join(' + '));
  const cfg=resolveConfig(root),exe=findEdgeExecutable(cfg.edgePath);need(exe,'P2_EDGE','Edge fehlt.');
  browser=await launchBrowser({executable:exe,userDataDir:cfg.profileDirectory,startUrl:'about:blank'});
  ({cdp}=await connectBrowser(browser.port));const page=await attachFreshPage(cdp,cfg.comarchUrl);
  need((await askFn(rl,'In Bot-Edge anmelden. COMARCH bereit? START / ABBRUCH: ')).toUpperCase()==='START',
   'P2_OPERATOR_ABORT','Keine Bearbeitung gestartet.');
  await UI.navigateToScope(page,'IN_BEARBEITUNG',{startup:true});
  const raw=await readPhase2Queue(page);need(raw.ok,'P2_QUEUE',raw.reason||'COMARCH-Vorgangsliste nicht lesbar.');
  const row=raw.rows.find(x=>x.ticketId===id);need(row,'P2_NOT_IN_TASKS','Ticket ist nicht mehr in Meine Vorgaenge.');
  const same=phase2Inventory([row],{pendingIds:ledger(root).pending.map(x=>x.ticketId)}).items[0];
  need(same.kind==='NEEDS_VERIFIED_WWID'&&normalize(row.descriptionValue)===normalize(item.descriptionValue),
   'P2_TICKET_CHANGED','Ticketstatus/Anfrage veraendert. Bitte Menue 9 erneut.');
  await UI.openTicket(page,row);await UI.assertTicket(page,id);
  const member=await memberLookup(page);
  need(member.profileVerified&&member.profile?.first&&member.profile?.last,'P2_MEMBER_NOT_BOUND','Kein eindeutiges COMARCH-Memberprofil.');
  need(!member.wwid||member.wwid===wwid,'P2_WWID_MISMATCH','Explizite COMARCH-WWID unterscheidet sich von beiden PDFs.');
  need(member.wwid||!member.memberReferenceWwid||member.memberReferenceWwid===wwid,'P2_MEMBER_REFERENCE_MISMATCH',
   'INTL01-Referenz aus dem ausgewaehlten Member stimmt nicht mit der bereits geprueften PDF-WWID ueberein.');
  await UI.ensureEdit(page);await UI.assertTicket(page,id);
  const expectedFixed={responsibility:'Second Level',category:'Allgemeine Schriftwechsel',subcategory:'Personenschriftwechsel'};
  const fixedOkay=f=>Object.entries(expectedFixed).every(([k,v])=>String(f?.[k]||'').trim()===v);
  if(!fixedOkay(await UI.fixedFieldValues(page))){
   log('PFLICHTFELDER: In COMARCH Second Level / Allgemeine Schriftwechsel / Personenschriftwechsel exakt setzen. Keine E-Mail senden.');
   need((await askFn(rl,'Pflichtfelder geprueft? ENTER / ABBRUCH: ')).toUpperCase()!=='ABBRUCH',
    'P2_OPERATOR_ABORT','Pflichtfelder nicht freigegeben.');
  }
  need(fixedOkay(await UI.fixedFieldValues(page)),'P2_FIXED_FIELDS','COMARCH-Pflichtfelder nicht eindeutig eingestellt.');
  const initial=await UI.additionalDescriptionState(page);
  need(initial.ok&&initial.editable&&normalize(initial.value)===normalize(item.descriptionValue),
   'P2_DESCRIPTION_CHANGED','Die vorhandenen drei Beschreibungszeilen sind nicht unveraendert editierbar.');
  // RC43: Check the real visible FilePond label before arming any write.
  // The previous implementation demanded GEVO first and only recognized
  // emailAttachmentFileUpload; the production UI exposes a dynamic FilePond
  // label/input instead.
  const names=verified.artifacts.map(a=>a.name);
  const existingAttachments=await observedAttachments(page,names);
  need(existingAttachments.present.every(x=>!x),'P2_ATTACHMENT_ALREADY_PRESENT','Eine Anlage steht bereits im Ticket. Keine doppelte Anlage.');
  let surface=await phase2UploadSurface(page);
  if(!surface.available){
   log('P2_ANHANGSBEREICH: COMARCH-Anhaenge hinzufuegen im Bot-Edge oeffnen, ohne Dateien auszuwaehlen.');
   need((await askFn(rl,'Anhangsbereich offen? ENTER / ABBRUCH: ')).toUpperCase()!=='ABBRUCH',
    'P2_OPERATOR_ABORT','Anhangsbereich nicht geoeffnet.');
   surface=await phase2UploadSurface(page);
  }
  need(surface.available,'P2_UPLOAD_NOT_READY','Kein eindeutiges FilePond-Label und kein altes Datei-Eingabefeld. Keine COMARCH-Aktion begonnen.');
  log('COMARCH-MEMBER: '+member.profile.first+' '+member.profile.last+' | verifizierte PDF-WWID '+wwid+
   (member.memberReferenceWwid?' | INTL01-'+member.memberReferenceWwid+' im ausgewählten Member bestaetigt':' | Member hat keine eindeutig beschriftete WWID'));
  log('PDF-ANLAGE ZUERST: '+names.join(' + ')+' | '+surface.mode+'. Danach Anfrage Member und Speicherung.');
  log('Vorbereitung nur fuer dieses Ticket. Noch keine Datei uebergeben.');
  // One approval for new runs; for legacy GEVO_INTENT the operator must
  // independently rule out ANY earlier upload/save/forward side effects.
  if(recoveryNeeded){
   log('P2_ALTES_GEVO_JOURNAL: Der RC41/RC42-Lauf hatte nur den GEVO-Fokus begonnen, bevor es irgendeine Upload-Absicht gab.');
   // Der alte Freigabecode GEVO_OHNE_AKTIONEN_GEPRUEFT wird durch eine einzige gemeinsame, strengere Freigabe ersetzt.
   log('Vor der Freigabe COMARCH ausserhalb des Bots pruefen: keine Anlage, kein gespeicherter Entwurf, kein Ticket-Speichern, keine Weiterleitung.');
   need((await askFn(rl,'Gleiches Ticket, PDFs, Rechte geprueft UND keinerlei fruehere Aktion erfolgt? PHASE2_FREIGABE_UND_WIEDERAUFNAHME / ABBRUCH: ')).toUpperCase()==='PHASE2_FREIGABE_UND_WIEDERAUFNAHME',
    'P2_GEVO_RECOVERY_DECLINED','Altes Journal bleibt gesperrt; keine wiederholte Dateianlage.');
   journal.approveGevoFocusRetry({...journalInput,operatorConfirmed:true,ticketUnchanged:true,noAttachments:true});
   log('PASS P2_LEGACY_FOCUS_RECOVERY_AUTHORIZED: Alter Journalstand wird ohne Reset fuer den FilePond-Upload fortgesetzt.');
  }else{
   need((await askFn(rl,'Originalvorgang, Member, WWID, PDF-Inhalt und Rechte geprueft? PHASE2_FREIGABE / ABBRUCH: ')).toUpperCase()==='PHASE2_FREIGABE',
    'P2_OPERATOR_ABORT','Keine Bearbeitung gestartet.');
   journal.begin();
  }
  armed=true;
  const advance=next=>{const val=journal.advance(next);log('P2_JOURNAL '+next);return val;};
  const bound=()=>UI.assertTicket(page,id);
  advance('UPLOAD_INTENT');await bound();
  const files=verified.artifacts.toSorted((a,b)=>a.plan==='PP+'?-1:b.plan==='PP+'?1:0).map(a=>a.file);
  const assertUnchanged=()=>{const now=inspectExistingStatements(root,item.targets,wwid);
   need(now.artifacts.length===verified.artifacts.length&&now.artifacts.every(a=>{
    const p=verified.artifacts.find(x=>x.plan===a.plan);return p?.sha256===a.sha256&&p?.bytes===a.bytes;
   }),'P2_PDF_CHANGED','PDF-Dateien seit Freigabe geaendert. Keine weitere COMARCH-Aktion.');};
  assertUnchanged();
  await attachPhase2Files(page,files,{log});
  let confirmed=false;
  for(let z=0;z<70;z++){
   const e=await observedAttachments(page,names);
   if(e.present.every(Boolean)){confirmed=true;break;}
   await sleep(200);
  }
  need(confirmed,'P2_UPLOAD_UNVERIFIED','FilePond hat die beiden PDFs nicht eindeutig angezeigt; keine zweite Dateiauswahl.');
  assertUnchanged();advance('UPLOAD_VERIFIED');
  log('PASS P2_FILEPOND_FILES_STAGED: Zwei PDFs im COMARCH-Anhangsbereich sichtbar (serverseitige Speicherung steht noch aus).');
  // Now enter the type of request – only after the PDFs were accepted by the
  // FilePond UI, as in the operator's actual workflow.
  advance('GEVO_INTENT');await bound();
  const f=await phase2FieldSnapshot(page);
  need(f.gevo.count===1&&f.gevo.visible&&f.gevo.enabled,'P2_GEVO_MISSING','Anfrage-Art-Feld fehlt nach PDF-Anlage.');
  await setPhase2Gevo(page,{
   manualFocus:async(reason)=>{
    log('P2_GEVO_MANUAL_FOCUS: '+reason+'. Nur GEVO im EIGENEN Bot-Edge fokussieren; keine andere Aktion.');
    need((await askFn(rl,'GEVO-Eingabefeld angeklickt? FOKUS / ABBRUCH: ')).toUpperCase()==='FOKUS',
     'P2_OPERATOR_ABORT','GEVO-Fokus nicht bestaetigt. Keine weiteren Aktionen.');
   },
   manualSelect:async()=>{
    log('Im COMARCH-Vorschlag genau Anfrage Member waehlen.');
    need((await askFn(rl,'Anfrage Member ausgewaehlt? AUSGEWAEHLT / ABBRUCH: ')).toUpperCase()==='AUSGEWAEHLT',
     'P2_OPERATOR_ABORT','Auswahl abgebrochen.');
   }
  });advance('GEVO_VERIFIED');
  need((await observedAttachments(page,names)).present.every(Boolean),'P2_FILEPOND_LOST_AFTER_GEVO',
   'COMARCH hat nach Anfrage Member die ausgewaehlten PDF-Anlagen nicht mehr angezeigt. Keine Speicherung oder Wiederholung.');
  advance('DESCRIPTION_INTENT');await bound();
  const before=await UI.additionalDescriptionState(page);
  need(before.ok&&before.editable&&normalize(before.value)===normalize(item.descriptionValue),
   'P2_DESCRIPTION_CHANGED','Originaltext vor Statusaenderung nicht mehr identisch.');
  const update=await UI.appendStandardAnswerMarker(page,'Bearbeitet not reviewed');
  need(update.ok&&normalize(update.value)===normalize(preview.descriptionAfter),'P2_MARKER_WRITE','Vierte Zeile nicht sicher angehaengt.');
  need(await UI.verifyDescription(page,preview.descriptionAfter),'P2_MARKER_VERIFY','Mehrzeiliger Tickettext nicht eindeutig im Editor.');
  advance('DESCRIPTION_VERIFIED');
  advance('DRAFT_SAVE_INTENT');await bound();await savePhase2Draft(page);
  // A draft click alone does NOT prove server persistence. Require both names
  // in the COMARCH attachment area before permitting the final ticket save.
  need((await observedAttachments(page,names)).present.every(Boolean),'P2_DRAFT_ATTACHMENTS_UNVERIFIED',
   'Entwurf nicht als dauerhaft angehaengt nachgewiesen; keine weitere Aktion.');
  advance('DRAFT_SAVE_VERIFIED');
  advance('TICKET_SAVE_INTENT');await bound();await savePhase2Ticket(page);
  let saved=false;for(let z=0;z<70;z++){
   try{await UI.navigateToScope(page,'IN_BEARBEITUNG',{refresh:true});const r=await readPhase2Queue(page);
    if(r.ok){const current=r.rows.find(x=>x.ticketId===id);
     if(current&&normalize(current.descriptionValue)===normalize(preview.descriptionAfter)){saved=true;break;}}
   }catch{}await sleep(300);
  }
  need(saved,'P2_SAVE_UNVERIFIED','Ticketbeschreibung nach einem Speicherklick nicht bestaetigt. Keinen zweiten Speicherklick ausfuehren.');
  advance('TICKET_SAVE_VERIFIED');
  log('PASS P2_DRAFT_AND_TICKET_SAVED: Tickettext gespeichert; dauerhafte PDF-Bestaetigung folgt nach erneutem Oeffnen.');
  // Review is explicitly gated and performed separately from saving.
  log('Pruefung: Beide Anhaenge und Entwurf in COMARCH jetzt visuell pruefen. Nicht selbst weiterleiten.');
  const choice=await askFn(rl,'An Mark Baindl zur Ueberpruefung weiterleiten? WEITERLEITEN / OFFEN_LASSEN: ');
  if(choice!=='WEITERLEITEN'){
   log('P2_OFFEN: Ticket gespeichert, Review noch nicht ausgefuehrt. Journal bleibt auf TICKET_SAVE_VERIFIED; kein automatischer Neustart.');
   return {ticketId:id,status:'SAVED_PENDING_REVIEW',journal:journal.file};
  }
  const current=await readPhase2Queue(page);const sameRow=current.rows?.find(r=>r.ticketId===id);
  need(sameRow,'P2_REVIEW_BIND','Nach Speichern ist das Ticket nicht mehr in Meine Vorgaenge.');
  await UI.openTicket(page,sameRow);await UI.assertTicket(page,id);
  need(fixedOkay(await UI.fixedFieldValues(page)),'P2_FIXED_NOT_SAVED','Pflichtfelder nach Speichern nicht mehr exakt. Keine Weiterleitung.');
  // Reopen from server-backed task view to verify attachments survive save.
  const attachmentAfterReopen=await observedAttachments(page,names);
  need(attachmentAfterReopen.present.every(Boolean),'P2_SAVED_ATTACHMENTS_NOT_VISIBLE',
   'Nach erneutem Oeffnen sind nicht alle PDF-Anlagen nachweisbar. Keine Weiterleitung.');
  const savedDescription=await UI.additionalDescriptionState(page);
  need(!savedDescription.ok||normalize(savedDescription.value)===normalize(preview.descriptionAfter),
   'P2_SAVED_DESCRIPTION_CHANGED','Tickettext nach erneutem Oeffnen veraendert.');
  assertUnchanged();
  advance('REVIEW_INTENT');await selectReviewMode(page);
  let visible=false;for(let z=0;z<35;z++){const a=await phase2FieldSnapshot(page);if(a.nextPersona.count===1&&a.nextPersona.visible&&a.nextPersona.enabled){visible=true;break;}await sleep(200);}
  need(visible,'P2_REVIEW_TARGET_FIELD','Prueferfeld mainForm:next-persona-assignment-id fehlt.');
  await selectReviewAssignee(page,{manualSelect:async()=>{
   log('Im Bot-Edge EXAKT Baindl Mark (mark.baindl) als Pruefer auswaehlen.');
   need((await askFn(rl,'Mark Baindl ausgewaehlt? ENTER / ABBRUCH: ')).toUpperCase()!=='ABBRUCH','P2_OPERATOR_ABORT','Pruefer abgebrochen.');
  }});
  need((await reviewAssignmentState(page)).ok,'P2_REVIEW_TARGET_CHANGED','Pruefer-Zuordnung nicht eindeutig.');
  advance('REVIEW_VERIFIED');
  const notices=await forwardingNotices(page);
  advance('EXECUTE_INTENT');await bound();await executeReview(page);
  let evidence={ok:false};for(let z=0;z<40;z++){
   evidence=await forwardConfirmed(page,{display:'Baindl Mark',account:'mark.baindl'},notices);
   if(evidence.ok)break;await sleep(300);
  }
  need(evidence.ok,'P2_REVIEW_UNVERIFIED','Nach einem Schritt-Ausfuehren-Klick keine neue Erfolgsmeldung. Nicht wiederholen.');
  let absent=false;for(let z=0;z<25;z++){
   try{await UI.navigateToScope(page,'IN_BEARBEITUNG',{refresh:true});const r=await readPhase2Queue(page);if(r.ok&&!r.rows.some(x=>x.ticketId===id)){absent=true;break;}}catch{}
   await sleep(300);
  }
  need(absent,'P2_REVIEW_NOT_REMOVED','Weiterleitungsmeldung vorhanden, Ticket aber weiter in eigenen Vorgängen. Manuell prüfen.');
  advance('ROUTED_VERIFIED');
  const receipt={schema:'MCR_PHASE2_REVIEW_RECEIPT_V1',ticketId:id,status:'ROUTED_VERIFIED',reviewer:'mark.baindl',pdfHashes:proof.artifacts.map(x=>({plan:x.plan,sha256:x.sha256})),createdAt:new Date().toISOString()};
  const rec=path.join(phase2Dir(root),'MCR_PHASE2_ABSCHLUSS_'+id+'_'+stamp()+'.json');writeJSON(rec,receipt);
  log('PASS P2_REVIEW_ROUTE_VERIFIED | '+id+' | mark.baindl | '+rec);
  return receipt;
 }finally{rl.close();try{cdp?.close();}catch{}try{browser?.child?.kill();}catch{}if(armed)log('P2_AUDIT: Schreibjournal bleibt dauerhaft erhalten. Bei Unterbrechung keine automatische Wiederholung.');}
}
