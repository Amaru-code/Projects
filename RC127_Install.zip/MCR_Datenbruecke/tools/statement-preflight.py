"""Check the configured generator's inputs without importing it or opening Excel."""
import ast
import builtins
from datetime import datetime
import hashlib
import io
import os
import re
import shutil
import stat
import uuid
import json
from pathlib import Path
import sys
import tempfile
import tokenize
import types

PP_SCRIPT = "kontoauszug_generator.py"
DC_SCRIPT = "kontoauszug_dc_generator.py"
TEMPLATE = "IPP Kontoausz\u00fcge Updates_Template.xlsm"
CENTRAL_DATA_ROOT = r"K:\INTL01\6_AU (Admin)\~ Data\~ Bestand Intel Gesamtübersicht"


def garbled_spellings(correct):
    variants = {correct}
    for _ in range(2):
        for old in tuple(variants):
            for encoding in ("cp1252", "latin1"):
                try:
                    variants.add(old.encode("utf-8").decode(encoding))
                except UnicodeError:
                    continue
    return variants - {correct}


def template_spellings():
    return garbled_spellings(TEMPLATE)


def fix_pp_data_root(tree):
    # Only the known PP+ assignment, and only if the intended directory exists.
    variants = garbled_spellings(CENTRAL_DATA_ROOT)
    for stmt in tree.body:
        if (isinstance(stmt, ast.Assign) and len(stmt.targets) == 1 and
                isinstance(stmt.targets[0], ast.Name) and stmt.targets[0].id == "CENTRAL_DATA_ROOT" and
                named_call(stmt.value, {"Path"}) and len(stmt.value.args) == 1 and not stmt.value.keywords):
            path = stmt.value.args[0]
            if (isinstance(path, ast.Constant) and isinstance(path.value, str) and path.value in variants
                    and not Path(path.value).is_dir() and Path(CENTRAL_DATA_ROOT).is_dir()):
                path.value = CENTRAL_DATA_ROOT


def checked_source(script, *, terminal_inputs=False):
    with tokenize.open(script) as source:
        text = source.read()
    tree = ast.parse(text, filename=str(script))
    variants = template_spellings()
    changes = 0
    if script.name == PP_SCRIPT and any(isinstance(node, ast.Constant) and isinstance(node.value, str)
                                        and node.value in variants for node in ast.walk(tree)):
        literals = path_literals(tree)
        if any(node.value in variants for node in literals):
            node = template_literal(tree)
            node.value = TEMPLATE
            changes = 1
    if terminal_inputs:
        fix_pp_data_root(tree)
        enable_pp_field_reader(tree)
        enable_existing_input_branches(tree)
        tree = ast.fix_missing_locations(TrackInputRefusal().visit(tree))
    code = compile(tree, str(script), "exec", dont_inherit=True)
    return code, changes


def require_readable(file):
    if not file.is_file():
        raise FileNotFoundError(f"Datei fehlt: {file}")
    with file.open("rb") as stream:
        if not stream.read(1):
            raise ValueError(f"Datei ist leer: {file}")


def path_literals(tree):
    """Select the literal that provides the template path; never edit a comment,
    print statement, docstring or a different workbook with a similar name."""
    spellings = template_spellings() | {TEMPLATE}
    matches = []

    def exact(node):
        return isinstance(node, ast.Constant) and isinstance(node.value, str) and node.value in spellings

    for node in ast.walk(tree):
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Div) and exact(node.right):
            matches.append(node.right)
        elif isinstance(node, (ast.Assign, ast.AnnAssign)) and exact(node.value):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            if any(isinstance(t, ast.Name) and ("TEMPLATE" in t.id.upper() or "VORLAGE" in t.id.upper())
                   for t in targets):
                matches.append(node.value)
        elif isinstance(node, ast.Call):
            path_function = (isinstance(node.func, ast.Name) and node.func.id == "Path" or
                             isinstance(node.func, ast.Attribute) and node.func.attr in {"joinpath", "Path"} or
                             isinstance(node.func, ast.Attribute) and node.func.attr == "join" and
                             isinstance(node.func.value, ast.Attribute) and node.func.value.attr == "path")
            if path_function:
                matches.extend(arg for arg in node.args if exact(arg))
    return matches


def template_literal(tree):
    matches = path_literals(tree)
    if len(matches) != 1:
        raise ValueError("Der PP+-Vorlagenpfad im Quelltext ist nicht eindeutig. Gefundene Pfad-Literale: " + str(len(matches)))
    return matches[0]


def repaired_bytes(raw, filename):
    encoding, _ = tokenize.detect_encoding(io.BytesIO(raw).readline)
    text = raw.decode(encoding)
    if text.encode(encoding) != raw:
        raise ValueError("Quellkodierung kann nicht bytegenau beibehalten werden.")
    tree = ast.parse(text, filename)
    node = template_literal(tree)
    if node.value == TEMPLATE:
        return raw
    # AST columns are UTF-8 byte offsets, including in non-UTF-8 sources.
    # Work with the original line endings and only replace the STRING token.
    lines = text.splitlines(keepends=True)
    def position(number, column):
        prefix = lines[number-1].encode("utf-8")[:column].decode("utf-8")
        return sum(map(len, lines[:number-1])) + len(prefix)
    start = position(node.lineno, node.col_offset)
    end = position(node.end_lineno, node.end_col_offset)
    token = text[start:end]
    tokens = [t for t in tokenize.generate_tokens(io.StringIO(token).readline) if t.type == tokenize.STRING]
    if len(tokens) != 1 or tokens[0].string != token:
        raise ValueError("Zusammengesetzter Vorlagenname. Quelltext muss manuell geprueft werden.")
    new_literal = json.dumps(TEMPLATE, ensure_ascii=False)
    try:
        new_literal.encode(encoding)
    except UnicodeEncodeError:
        new_literal = json.dumps(TEMPLATE, ensure_ascii=True)
    updated = (text[:start] + new_literal + text[end:]).encode(encoding)
    compile(updated, filename, "exec", dont_inherit=True)
    if template_literal(ast.parse(updated, filename)).value != TEMPLATE:
        raise ValueError("Rueckpruefung des korrigierten Vorlagenpfads fehlgeschlagen.")
    return updated


def replace_script(staged, script):
    if os.name != "nt":
        os.replace(staged, script)
        return
    # ReplaceFile preserves the original Windows file's metadata and ACLs.
    # A sharing violation or metadata merge failure must leave a clear error.
    import ctypes
    from ctypes import wintypes
    replace = ctypes.WinDLL("kernel32", use_last_error=True).ReplaceFileW
    replace.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.LPCWSTR,
                        wintypes.DWORD, wintypes.LPVOID, wintypes.LPVOID]
    replace.restype = wintypes.BOOL
    if not replace(str(script), str(staged), None, 0, None, None):
        raise ctypes.WinError(ctypes.get_last_error())


def repair_pp(script):
    if script.name != PP_SCRIPT or script.is_symlink() or not script.is_file():
        raise ValueError("Bitte den genauen Pfad der regulaeren Datei " + PP_SCRIPT + " angeben.")
    script = script.resolve()
    require_readable(script.parent / TEMPLATE)
    lock = script.with_name("." + script.name + ".mcr-repair.lock")
    # Coordinate concurrent repair invocations. External editor changes during
    # prepare/backup are checked again immediately before replacement.
    with lock.open("xb"):
        pass
    backup = None
    staged = None
    try:
        original_stat = script.stat()
        original = script.read_bytes()
        updated = repaired_bytes(original, str(script))
        digest = lambda data: hashlib.sha256(data).hexdigest()
        if updated == original:
            return {"ok": True, "status": "PP_TEMPLATE_ALREADY_CORRECT", "script": str(script), "sha256": digest(original)}

        backup = script.with_name(script.name + ".mcr-" + uuid.uuid4().hex + ".bak")
        with backup.open("xb") as f:
            f.write(original)
            f.flush()
            os.fsync(f.fileno())
        if backup.read_bytes() != original:
            raise OSError("Die Originalsicherung konnte nicht bestaetigt werden: " + str(backup))

        with tempfile.NamedTemporaryFile(prefix=".mcr-pp-template-", suffix=".tmp", dir=script.parent, delete=False) as f:
            staged = Path(f.name)
            f.write(updated)
            f.flush()
            os.fsync(f.fileno())
        shutil.copymode(script, staged)
        if staged.read_bytes() != updated:
            raise OSError("Staging-Datei wurde vor dem Ersetzen geaendert.")
        current = script.lstat()
        unchanged = (current.st_dev, current.st_ino, current.st_mtime_ns, current.st_size) == (
            original_stat.st_dev, original_stat.st_ino, original_stat.st_mtime_ns, original_stat.st_size)
        if not stat.S_ISREG(current.st_mode) or not unchanged or script.read_bytes() != original:
            raise OSError("Generator seit Beginn der Reparatur geaendert. Vorhandene Version bleibt erhalten.")
        replace_script(staged, script)
        if script.read_bytes() != updated:
            raise OSError("Generator nach dem Ersetzen nicht bytegenau bestaetigt.")
        return {"ok": True, "status": "PP_TEMPLATE_REPAIRED", "script": str(script), "backup": str(backup),
                "originalSha256": digest(original), "sha256": digest(updated)}
    except (OSError, ValueError, SyntaxError, LookupError) as exc:
        if backup is not None:
            raise RuntimeError(str(exc) + " | Sicherung: " + str(backup)) from exc
        raise
    finally:
        if staged is not None:
            staged.unlink(missing_ok=True)
        lock.unlink(missing_ok=True)


def probe(plan, folder, output):
    if plan not in {"PP+", "DC"} or output != folder / "Ausgabe_PDF":
        raise ValueError("Generatorplan oder Ausgabeordner ist nicht gebunden.")
    script = folder / (PP_SCRIPT if plan == "PP+" else DC_SCRIPT)
    require_readable(script)
    _, repairs = checked_source(script)
    if plan == "PP+":
        required = [folder / TEMPLATE, folder / "IPP_Kontoauszuege_Arbeitsdatei.xlsm",
                    folder / "Kontostand_Kontrolle_Arbeitsdatei.xlsm",
                    folder.parent / "Daten" / "eckwerte_runtime.py",
                    folder.parent / "Daten" / "Personenordner_Zuordnung.csv"]
    else:
        required = [folder / "_2026_LNW_DC_Output.xlsm", folder / "Personenordner_Zuordnung.csv"]
        work = folder / "_2026_LNW_DC_Arbeitsdatei.xlsm"
        if work.exists():
            required.append(work)
    for file in required:
        require_readable(file)
    output.mkdir(exist_ok=True)
    # Exercise create, write, close and delete with our own unique temporary file.
    with tempfile.NamedTemporaryFile(prefix=".mcr_preflight_", suffix=".tmp", dir=output) as stream:
        stream.write(b"1")
        stream.flush()
    return {"ok": True, "templateRepair": bool(plan == "PP+" and repairs)}


def named_call(node, names):
    return isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in names


def input_blocker(body):
    """Recognise a pure PP_INPUT_REQUIRED exit, never a mixed business/validation branch."""
    if not body:
        return False
    marker = any(isinstance(n, ast.Constant) and isinstance(n.value, str) and
                 "PP_INPUT_REQUIRED" in n.value for stmt in body for n in ast.walk(stmt))
    def is_exit(stmt):
        if isinstance(stmt, ast.Raise):
            return True
        if isinstance(stmt, ast.Expr):
            call = stmt.value
            return (named_call(call, {"exit", "quit"}) or
                    isinstance(call, ast.Call) and isinstance(call.func, ast.Attribute) and
                    isinstance(call.func.value, ast.Name) and call.func.value.id == "sys" and call.func.attr == "exit")
        return (isinstance(stmt, ast.Return) and isinstance(stmt.value, ast.Constant)
                and type(stmt.value.value) is int and stmt.value.value != 0)
    return (marker and is_exit(body[-1]) and
            all(isinstance(s, ast.Expr) and named_call(s.value, {"print"}) for s in body[:-1]))


def input_mode(node):
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.Not):
        return input_mode(node.operand)
    name = node.id if isinstance(node, ast.Name) else node.attr if isinstance(node, ast.Attribute) else ""
    return (name.lower() in {"interactive", "is_interactive", "non_interactive", "noninteractive",
                            "bot_mode", "is_bot", "unattended", "allow_input", "allow_prompt", "allow_prompts",
                            "allow_interactive", "interactive_mode"} or
            isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "isatty" and
            isinstance(node.func.value, ast.Attribute) and node.func.value.attr == "stdin" and
            isinstance(node.func.value.value, ast.Name) and node.func.value.value.id == "sys")


def enable_pp_field_reader(tree):
    """Adapt the installed ask(label, optional=False) at its CLI-only refusal."""
    functions = {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}
    ask = functions.get("ask")
    if ask is None or [a.arg for a in ask.args.args] != ["label", "optional"]:
        return
    body = ask.body[1:] if ast.get_docstring(ask, clean=False) is not None else ask.body
    if len(body) < 2:
        return
    guard, reader = body[:2]
    cli_test = ast.parse("'--wwid' in sys.argv", mode="eval").body
    if not (isinstance(guard, ast.If) and not guard.orelse and input_blocker(guard.body)
            and ast.dump(guard.test) == ast.dump(cli_test) and isinstance(reader, ast.While)
            and any(named_call(n, {"input"}) for n in ast.walk(reader))):
        return
    # The original loop, labels and optional flag still handle each question.
    guard.test = ast.copy_location(ast.Constant(False), guard.test)
    collect = functions.get("collect_missing")
    if collect is None:
        return
    original = ast.parse("parse(field, ask(label, field == 'LE'))", mode="eval").body
    for stmt in ast.walk(collect):
        if isinstance(stmt, ast.Assign) and ast.dump(stmt.value) == ast.dump(original):
            adapted = ast.parse("_mcr_pp_parse_field(parse, ask, field, label, field == 'LE')", mode="eval").body
            stmt.value = ast.copy_location(adapted, stmt.value)


def parse_pp_field(parse, ask, field, label, optional):
    question = label
    while True:
        value = ask(question, optional)
        try:
            return parse(field, value)
        except ValueError:
            if field in {"Geburtsdatum", "Eintritt", "Austritt"}:
                question = label + " – bitte ein gültiges Datum im Format TT.MM.JJJJ eingeben"
            elif field == "LE":
                question = label + " – bitte eine ganze Zahl eingeben"
            else:
                raise


def enable_existing_input_branches(tree):
    """Expose the installed generator's own field reader at a pure bot-mode
    refusal. Leave CLI dispatch, business conditions, validation and writes intact.
    A bare error with no original interactive reader stays an error.
    """
    funcs = [n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)]
    readers = {"input"}
    def asks(statements):
        return any(named_call(n, readers) for s in statements for n in ast.walk(s))
    # Include existing labelled input helper calls, e.g. ask_date -> ask_text -> input.
    while True:
        expanded = readers | {f.name for f in funcs if asks(f.body)}
        if readers == expanded:
            break
        readers = expanded

    guards = {f.name for f in funcs if input_blocker(
        f.body[1:] if ast.get_docstring(f, clean=False) is not None else f.body)}

    for parent in ast.walk(tree):
        for _, statements in ast.iter_fields(parent):
            if not isinstance(statements, list):
                continue
            for index, stmt in enumerate(statements):
                if isinstance(stmt, ast.If) and input_mode(stmt.test):
                    # A guard-before-read or an explicit alternative read. Never
                    # enable a guard when the manual branch is missing/unknown.
                    if input_blocker(stmt.body) and asks(stmt.orelse or statements[index+1:index+2]):
                        stmt.test = ast.copy_location(ast.Constant(False), stmt.test)
                    elif input_blocker(stmt.orelse) and asks(stmt.body):
                        stmt.test = ast.copy_location(ast.Constant(True), stmt.test)
                if (isinstance(stmt, ast.Assign) and len(stmt.targets) == 1 and
                        isinstance(stmt.value, ast.Name) and stmt.value.id in guards):
                    dest = stmt.targets[0]
                    if ((isinstance(dest, ast.Name) and dest.id == "input") or
                            isinstance(dest, ast.Attribute) and dest.attr == "input" and
                            isinstance(dest.value, ast.Name) and dest.value.id in ("builtins", "__builtins__")):
                        stmt.value = ast.copy_location(ast.Name(id="_mcr_pp_ask", ctx=ast.Load()), stmt.value)


class TrackInputRefusal(ast.NodeTransformer):
    """Remember only the line of a generator marker that actually executes."""
    def visit_Raise(self, node):
        return self.note(node)

    def visit_Expr(self, node):
        return self.note(node) if isinstance(node.value, ast.Call) else node

    def note(self, node):
        if not any(isinstance(n, ast.Constant) and isinstance(n.value, str) and
                   "PP_INPUT_REQUIRED" in n.value for n in ast.walk(node)):
            return node
        remember = ast.Expr(ast.Call(ast.Name("_mcr_pp_refusal", ast.Load()),
                                     [ast.Constant(node.lineno)], []))
        return [ast.copy_location(remember, node), node]


def selects_job(field, wwid, stichtag):
    # A question may label its person/period as context (e.g. "Geburtsort
    # für WWID 123456"). A request to select or change them isn't a data field.
    keys = r"(?:wwid|clienteeid|(?:abrechnungs)?stichtag|ticket(?:nummer|-id)?)"
    given = rf"(?:wwid\s*[:#]?\s*{re.escape(wwid)}|(?:abrechnungs)?stichtag\s*:?\s*{re.escape(stichtag)})"
    context = rf"(?:\(\s*{given}\s*\)|\[\s*{given}\s*\]|\bf[üu]r\s+{given}(?![\w.]))"
    without_context = re.sub(context, "", field, flags=re.I)
    return (not any(c.isalpha() for c in without_context) or
            re.search(rf"(?i)\b{keys}\b", without_context) is not None)


def terminal_reader(args, run_id):
    if (not re.fullmatch(r"[A-Za-z0-9._-]{8,128}", run_id) or len(args) != 4 or
            args[0] != "--wwid" or not re.fullmatch(r"[0-9]{4,15}", args[1]) or args[2] != "--stichtag" or
            not re.fullmatch(r"[0-9]{2}\.[0-9]{2}\.[0-9]{4}", args[3])):
        raise ValueError("Unerwartete PP+-Ticketbindung.")
    datetime.strptime(args[3], "%d.%m.%Y")
    seq = 0
    incoming, outgoing = sys.stdin, sys.stdout
    def stop():
        # Bypass ordinary generator 'except Exception' retry loops but allow its
        # normal finally blocks (e.g. Excel cleanup) to run on operator refusal.
        raise SystemExit("PP_INPUT_REQUIRED: Eingabe beendet oder nicht eindeutig gebunden.")
    def ask(prompt=""):
        nonlocal seq
        if not isinstance(prompt, str):
            stop()
        field = " ".join(prompt.strip().splitlines()).strip()
        if not field or len(field) > 512 or not field.isprintable():
            stop()
        if selects_job(field, args[1], args[3]):
            stop()  # CLI already selected one person and period.
        optional = re.search(r"\[optional\]\s*:?\Z", field) is not None
        seq += 1
        key = {"run": run_id, "wwid": args[1], "stichtag": args[3], "seq": seq}
        print("\nMCR_PP_INPUT " + json.dumps({**key, "field": field, "optional": optional}, ensure_ascii=True), file=outgoing, flush=True)
        raw = incoming.readline(16385)
        if not raw.endswith("\n") or len(raw) > 16384:
            stop()
        try:
            answer = json.loads(raw)
        except (UnicodeError, ValueError):
            stop()
        if (not isinstance(answer, dict) or type(answer.get("seq")) is not int or
                any(answer.get(k) != v for k, v in key.items()) or answer.get("approved") is not True):
            stop()
        value = answer.get("value")
        if optional and value == "":
            return ""
        if not isinstance(value, str) or not value.strip() or len(value) > 1024 or not value.isprintable():
            stop()
        return value
    return ask


def run_pp(script, args):
    if script.name != PP_SCRIPT or script.parent != Path.cwd().resolve():
        raise ValueError("Unerwarteter Generatorpfad.")
    require_readable(script.parent / TEMPLATE)
    run_id = os.environ.get("MCR_PP_INPUT_RUN")
    reader = terminal_reader(args, run_id) if run_id is not None else None
    code, _ = checked_source(script, terminal_inputs=reader is not None)
    module = types.ModuleType("__main__")
    module.__file__ = str(script)
    sys.modules["__main__"] = module
    sys.argv[:] = [str(script), *args]
    sys.path[0] = str(script.parent)
    if reader is None:
        exec(code, module.__dict__)
        return
    refusal_line = None
    def note(line):
        nonlocal refusal_line
        refusal_line = line
    module.__dict__.update(_mcr_pp_ask=reader, _mcr_pp_refusal=note, _mcr_pp_parse_field=parse_pp_field)
    original_input, original_stdin, original_dunder_stdin = builtins.input, sys.stdin, sys.__stdin__
    with open(os.devnull, "r", encoding="utf-8") as no_unbound_input:
        try:
            builtins.input = reader
            sys.stdin = sys.__stdin__ = no_unbound_input
            exec(code, module.__dict__)
        except BaseException as failure:
            line = refusal_line
            if line is None:
                tb = failure.__traceback__
                while tb:
                    if tb.tb_frame.f_code.co_filename == str(script):
                        line = tb.tb_lineno
                    tb = tb.tb_next
            if line and not (isinstance(failure, SystemExit) and failure.code in (None, 0)):
                print("\nMCR_PP_SOURCE " + str(line), file=sys.__stderr__, flush=True)
            raise
        finally:
            builtins.input, sys.stdin, sys.__stdin__ = original_input, original_stdin, original_dunder_stdin


if __name__ == "__main__":
    if sys.argv[1] == "check":
        try:
            result = probe(sys.argv[2], Path(sys.argv[3]).resolve(), Path(sys.argv[4]).resolve())
        except (OSError, ValueError, SyntaxError, LookupError) as error:
            result = {"ok": False, "reason": str(error)}
        print(json.dumps(result, ensure_ascii=True))
        sys.exit(0 if result["ok"] else 1)
    elif sys.argv[1] == "repair-pp" and len(sys.argv) == 3:
        try:
            result = repair_pp(Path(sys.argv[2]))
        except (OSError, ValueError, RuntimeError, SyntaxError, LookupError) as error:
            result = {"ok": False, "status": "PP_TEMPLATE_REPAIR_FAILED", "reason": str(error)}
        print(json.dumps(result, ensure_ascii=True))
        sys.exit(0 if result["ok"] else 1)
    elif sys.argv[1] == "run-pp":
        run_pp(Path(sys.argv[2]).resolve(), sys.argv[3:])
    else:
        raise SystemExit("Unbekannte Aktion.")
