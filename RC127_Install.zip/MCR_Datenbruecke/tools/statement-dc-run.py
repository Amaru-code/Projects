"""Run the original DC program with its own argv, cwd and Excel logic.

Separate a documented standalone personal-folder copy from primary generation.
A successful Excel PDF export is reported immediately. Optional cleanup has its own status.
Calls whose return value is used keep their original synchronous behavior.
"""
import ast
import atexit
import errno
import hashlib
import inspect
import json
import os
from pathlib import Path
import shutil
import sys
import threading
import time
import tokenize
import types


class WorkbookBusy(Exception):
    pass


def exclusive_workbook_lock(lock_path):
    handle = lock_path.open("a+b")
    try:
        if os.name == "nt":
            import msvcrt
            if not lock_path.stat().st_size:
                handle.write(b"0")
                handle.flush()
            handle.seek(0)
            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError as error:
        handle.close()
        if error.errno in {errno.EAGAIN, errno.EACCES, errno.EDEADLK}:
            raise WorkbookBusy() from error
        raise
    return handle


def fingerprint(path):
    st = path.stat()
    return st.st_size, st.st_mtime_ns, st.st_ctime_ns, st.st_ino


class ParentStream:
    """Allow an already-finalized export to finish if the UI process exits."""
    def __init__(self, stream):
        self.stream = stream

    def __getattr__(self, attr):
        return getattr(self.stream, attr)

    def write(self, text):
        try:
            return self.stream.write(text)
        except BrokenPipeError:
            self.stream = open(os.devnull, "w")
            return len(text)

    def flush(self):
        try:
            self.stream.flush()
        except BrokenPipeError:
            self.stream = open(os.devnull, "w")


def track_person_copy(function, args, kwargs, source):
    """Observe a successful standard-library file copy, without rereading a network share."""
    copied = False
    targets = {shutil.copy.__code__, shutil.copy2.__code__, shutil.copyfile.__code__}
    source_key = os.path.normcase(os.path.abspath(source))
    def profile(frame, action, result):
        nonlocal copied
        if (action == "return" and frame.f_code in targets and
                isinstance(result, (str, os.PathLike))):
            origin = frame.f_locals.get("src")
            if isinstance(origin, (str, os.PathLike)):
                copied |= (os.path.normcase(os.path.abspath(origin)) == source_key and
                           os.path.normcase(os.path.abspath(result)) != source_key)
    if sys.getprofile() is not None:
        return function(*args, **kwargs), False
    sys.setprofile(profile)
    try:
        answer = function(*args, **kwargs)
        return answer, copied
    finally:
        sys.setprofile(None)


def run():
    script = Path.cwd() / "kontoauszug_dc_generator.py"
    if len(sys.argv) != 4 or Path(sys.argv[1]).name != script.name or sys.argv[2] != "--wwid":
        raise ValueError("Unerwarteter DC-Aufruf.")
    wwid = sys.argv[3]
    job = Path(os.environ["MCR_DC_RECEIPT"])
    nonce = job.stem
    output = script.parent / "Ausgabe_PDF"
    canonical = output / (wwid + "_Kontoauszug_DC.pdf")
    sys.stdout, sys.stderr = ParentStream(sys.stdout), ParentStream(sys.stderr)
    state = {"run": nonce, "wwid": wwid, "pid": os.getpid(), "started": time.time()}
    def event(kind, **details):
        state.update(details, event=kind)
        data = json.dumps(state, ensure_ascii=True)
        # Persist before publishing. A later terminal session can read the
        # final state even if the original stdout pipe has been closed.
        temp = job.with_suffix(".tmp")
        try:
            temp.write_text(data + "\n", encoding="utf-8")
            os.replace(temp, job)
        except OSError:
            # Without a durable receipt the parent uses only a regular exit.
            return
        try:
            print("MCR_DC_EVENT " + data, flush=True)
        except (BrokenPipeError, OSError):
            pass

    try:
        # Different installations using the same central workbook contend on
        # the same OS-owned byte lock; the file itself is never removed.
        lock = exclusive_workbook_lock(output / ".mcr-dc-workbook.lock")
    except WorkbookBusy:
        event("WORKBOOK_BUSY")
        return 1

    initial = fingerprint(canonical) if canonical.is_file() else None
    def export_digest():
        if not canonical.is_file() or canonical.is_symlink():
            return None
        before = fingerprint(canonical)
        if before == initial or not 128 < before[0] <= 50 * 1024 * 1024:
            return None
        data = canonical.read_bytes()
        if (len(data) != before[0] or fingerprint(canonical) != before or
                not data.startswith(b"%PDF-") or not data.rstrip().endswith(b"%%EOF")):
            return None
        return {"name": canonical.name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}

    def observe_excel(method, function, *args, **kwargs):
        # Bind the original call target and arguments once. Excel exceptions
        # propagate unchanged; only a returned export to *this* path counts.
        result = function(*args, **kwargs)
        try:
            options = {key.casefold(): value for key, value in kwargs.items()}
            if method == "exportasfixedformat":
                is_pdf = options.get("type", args[0] if args else None) == 0
                target = options.get("filename", args[1] if len(args) > 1 else None)
            else:
                is_pdf = True
                target = options.get("path", args[0] if args else None)
            if is_pdf and isinstance(target, (str, os.PathLike)) and Path(target).samefile(canonical):
                receipt = export_digest()
                if receipt:
                    event("EXCEL_PDF_EXPORTED", exportedPdf=receipt)
        except (OSError, ValueError, TypeError):
            pass
        return result

    def inspect_output(function, args, kwargs):
        try:
            values = inspect.signature(function).bind(*args, **kwargs).arguments
            refs = [Path(value) for value in values.values()
                    if isinstance(value, (str, os.PathLike)) and str(value).lower().endswith(".pdf")]
            # Some deployed generators spell the WWID argument in capitals or
            # bind a keyword-only employee_wwid after a wrapper function.
            ids = [str(value).strip() for key, value in values.items()
                   if key.casefold() in {"wwid", "employee_wwid", "member_wwid"}]
            if (ids != [wwid] or len(refs) != 1 or
                    not canonical.is_file() or canonical.is_symlink() or not refs[0].samefile(canonical)):
                return None
            receipt = export_digest()
            return (refs[0], receipt) if receipt else None
        except (TypeError, ValueError, OSError):
            return None

    jobs = []
    processing_copy = False
    def schedule(function, *args, **kwargs):
        # An expression statement discards the copy's return value. Any other
        # call site is deliberately left in the original program.
        if processing_copy:
            return function(*args, **kwargs)
        checked = inspect_output(function, args, kwargs)
        if checked is None or getattr(getattr(function, "__code__", None), "co_filename", None) != str(script):
            return function(*args, **kwargs)
        jobs.append((function, args, kwargs, checked[0], checked[1]))
        event("EXPORT_SEEN", name=canonical.name)

    globals_ok = False
    fault = False
    previous_unraisable = sys.unraisablehook
    def on_unraisable(problem):
        nonlocal fault
        fault = True
        previous_unraisable(problem)
    sys.unraisablehook = on_unraisable
    previous_thread_error = threading.excepthook
    def on_thread_error(problem):
        nonlocal fault
        fault = True
        previous_thread_error(problem)
    threading.excepthook = on_thread_error

    # Registered BEFORE importing the generator, so its own atexit functions
    # and joined non-daemon threads run first. A failing save/finally/cleanup
    # prevents handoff even if the PDF was exported earlier.
    outcome = 1
    def postprocess():
        nonlocal processing_copy
        processing_copy = True
        try:
            if (not globals_ok or fault or sys.unraisablehook is not on_unraisable or
                    threading.excepthook is not on_thread_error):
                event("PRIMARY_FAILED", exit_code=outcome or 1)
                return
            if len(jobs) > 1:
                event("PRIMARY_UNVERIFIED")
                for function, args, kwargs, _, _ in jobs:
                    function(*args, **kwargs)
                return
            for function, args, kwargs, source, receipt in jobs:
                if inspect_output(function, args, kwargs) != (source, receipt):
                    event("PRIMARY_UNVERIFIED")
                    return
                event("PDF_FINALIZED", pdf=receipt)
                try:
                    _, copied = track_person_copy(function, args, kwargs, source)
                    event("COPY_OK" if copied else "COPY_RETURNED")
                except Exception as error:
                    # This work starts only after the original main and its
                    # registered cleanup succeeded. It cannot mask a primary error.
                    event("COPY_FAILED", error_type=type(error).__name__)
        finally:
            event("EXIT", exit_code=outcome, previous=state["event"], deferred=bool(jobs))
            lock.close()

    atexit.register(postprocess)
    with tokenize.open(script) as fh:
        tree = ast.parse(fh.read(), filename=str(script))
    class DeferArchiveCopy(ast.NodeTransformer):
        def visit_Call(self, node):
            node = self.generic_visit(node)
            attr = node.func
            if (isinstance(attr, ast.Attribute) and
                    attr.attr.casefold() in {"exportasfixedformat", "to_pdf"}):
                node.args[:0] = [ast.Constant(attr.attr.casefold()), attr]
                node.func = ast.copy_location(ast.Name("_mcr_observe_excel", ast.Load()), attr)
                ast.fix_missing_locations(node)
            return node

        def visit_Expr(self, node):
            call = node.value
            if (isinstance(call, ast.Call) and isinstance(call.func, ast.Name) and
                    call.func.id == "copy_to_person_folder"):
                call.args.insert(0, call.func)
                call.func = ast.copy_location(ast.Name("_mcr_schedule_archive_copy", ast.Load()), call)
            return self.generic_visit(node)

    DeferArchiveCopy().visit(tree)
    main_module = types.ModuleType("__main__")
    main_module.__file__ = str(script)
    main_module.__dict__["_mcr_schedule_archive_copy"] = schedule
    main_module.__dict__["_mcr_observe_excel"] = observe_excel
    sys.modules["__main__"] = main_module
    sys.path[0] = str(script.parent)
    sys.argv[:] = [str(script), "--wwid", wwid]
    event("STARTED")
    try:
        exec(compile(tree, str(script), "exec"), main_module.__dict__)
    except SystemExit as stop:
        outcome = stop.code if isinstance(stop.code, int) else 0 if stop.code is None else 1
        globals_ok = outcome == 0
        raise
    outcome = 0
    globals_ok = True
    return outcome


if __name__ == "__main__":
    if sys.argv[1:] == ["--check-output-idle"]:
        # This check acquires the same nonblocking OS byte lock as generation.
        # A leftover lock file after a Windows restart does not imply ownership.
        try:
            with exclusive_workbook_lock(Path.cwd() / "Ausgabe_PDF" / ".mcr-dc-workbook.lock"):
                print("DC_WORKBOOK_IDLE", flush=True)
        except WorkbookBusy:
            print("DC_WORKBOOK_BUSY", flush=True)
            sys.exit(1)
    else:
        sys.exit(run())
