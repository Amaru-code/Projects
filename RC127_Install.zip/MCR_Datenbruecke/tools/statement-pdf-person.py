"""Return identity status and hash of the inspected statement. Never emit its text."""
from datetime import datetime
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import unicodedata


def extract(data, *, whole=False):
    try:
        from pypdf import PdfReader
    except ImportError:
        try:
            from PyPDF2 import PdfReader
        except ImportError:
            PdfReader = None
    if PdfReader:
        reader = PdfReader(io.BytesIO(data))
        if whole and len(reader.pages) > 40:
            return ''
        return '\n'.join(page.extract_text() or '' for page in reader.pages[:40 if whole else 2])
    tool = shutil.which('pdftotext')
    if tool:
        args = [tool, *([] if whole else ['-f', '1', '-l', '2']), '-enc', 'UTF-8', '-', '-']
        result = subprocess.run(args, input=data, capture_output=True, check=True, timeout=15)
        return result.stdout.decode('utf-8')
    return ''


def words(s):
    return re.findall(r'[^\W_]+', unicodedata.normalize('NFC', s).casefold(), re.UNICODE)


def labelled_wwids(text):
    return re.findall(r'(?i)\b(?:WWID|ClientEEID|EmployeeIDNumber)\s*[:#-]?\s*([0-9]{4,15})\b', text)


def identify(text, file, wwid, first, last, plan):
    fields = labelled_wwids(text)
    if any(value != wwid for value in fields):
        return 'MISMATCH'
    canonical = os.path.basename(file).casefold() == f'{wwid}_Kontoauszug_{plan}.pdf'.casefold()
    stream = ' ' + ' '.join(words(text)) + ' '
    names = (first + ' ' + last, last + ' ' + first)
    if (canonical or fields) and any((' ' + ' '.join(words(name)) + ' ') in stream for name in names):
        return 'MATCH'
    return 'REVIEW'


def statement_details(text):
    # Dates from unrelated financial lines or the print footer do not establish the reporting period.
    title = bool(re.search(r"(?i)\b(?:kontoauszug|account statement|leistungsnachweis)\b", text))
    document_plans = set(re.findall(r"(?i)(?<![\w+])(DC(?:\+)?|PP\+)(?![\w+])", text))
    document_plans = {"DC" if p.upper() in {"DC", "DC+"} else "PP+" for p in document_plans}
    dates = set(re.findall(r"(?i)\b(?:stichtag|abrechnungsstichtag|kontoauszug zum|statement as (?:of|at))\s*[:–-]?\s*(\d{2}\.\d{2}\.(?:19|20)\d{2})\b", text))
    years = set(re.findall(r"(?i)\b(?:abrechnungsjahr|berichtsjahr|statement year)\s*[:–-]?\s*((?:19|20)\d{2})\b", text))
    try:
        for date in dates:
            datetime.strptime(date, "%d.%m.%Y")
    except ValueError:
        # A malformed explicit reporting date invalidates the combined period evidence.
        dates.clear()
        years.clear()
    return {"statementPlan": next(iter(document_plans)) if title and len(document_plans) == 1 else None,
            "periodDates": sorted(dates), "periodYears": sorted(years)}

if __name__ == '__main__':
    with open(sys.argv[1], 'rb') as source:
        data = source.read(50 * 1024 * 1024 + 1)
    fields = []
    details = {}
    try:
        text = extract(data, whole='--statement-period' in sys.argv[6:]) if len(data) <= 50 * 1024 * 1024 else ''
        fields = labelled_wwids(text)
        result = identify(text, *sys.argv[1:6])
        details = statement_details(text)
    except Exception:
        result = 'REVIEW'
    print(json.dumps({**details, 'status': result, 'wwidInText': bool(fields) and set(fields) == {sys.argv[2]}, 'sha256': hashlib.sha256(data).hexdigest()}))
