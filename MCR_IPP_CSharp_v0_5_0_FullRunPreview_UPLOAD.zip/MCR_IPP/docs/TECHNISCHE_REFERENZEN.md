# Technische Referenzen (keine fachlichen IPP-Regeln)

- Adobe PDF 1.7 / ISO 32000-1: https://opensource.adobe.com/dc-acrobat-sdk-docs/pdfstandards/PDF32000_2008.pdf
  Technische Grundlage: PDF-Objekte, Text-/Hexstrings, Page Tree, Standardfonts,
  WinAnsiEncoding und klassische Querverweistabelle. Implementiert wird nur ein
  eingeschraenkter PDF-1.4-Entwurfswriter ohne aktive Inhalte. Keine PDF/A-Zertifizierung.
- PDF Association, Spezifikationsarchiv: https://pdfa.org/resource/pdf-specification-archive/
- Microsoft .NET SDK-Aufloesung: https://learn.microsoft.com/en-us/dotnet/core/tools/global-json
- Microsoft, Windows-Targeting auf anderem OS: https://learn.microsoft.com/en-us/dotnet/core/tools/sdk-errors/netsdk1100

Keine Quelle hier entscheidet die offenen IPP-Mappings oder wirtschaftlichen Regeln.
Diese stammen ausschliesslich aus den vom Nutzer bereitgestellten Codes/Audits bzw.
muessen noch fachlich bestaetigt werden.
