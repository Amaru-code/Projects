## V0.4.0

Aktuelle Dokumentation: ../BETRAGSFIX_UND_VORLAGENEXPORT_LESEN.md.
212 Testdefinitionen, neu ContributionAmountPolicy und TemplateJsonExport.
Keine Kundenblätter oder Schriftdateien im Paket. Kein Build hier ausgeführt.

## V0.3.1 Technischer PDF-/Dateiabschluss

16 zusätzliche Testdefinitionen T165–T180, insgesamt 180. T158 wurde angepasst:
Abbruch verhindert weiterhin den fertigen Gesamtlauf, löscht aber die bereits
geschriebenen Entwürfe nicht mehr. Alle anderen 163 bisherigen Testblöcke sind
unverändert. T179 ist ein IN-MEMORY-Test mit 1.040 synthetischen Personen und
sechs Monaten, kein Windows-Dateisperren-Nachweis.

`OutputPublication` kapselt den einzigen abschließenden Verzeichniswechsel des
Gesamtlaufs. Interne Friend-Assembly für deterministische I/O-Fehlereinspritzung
in den Tests. Maximal sechs Versuche bei Fehlercodes 5/32/33, insgesamt 4.650 ms
Wartezeit; keine Wartezeit für andere Fehler. Keine ACL-/Registry-Änderung,
kein Prozessabbruch, kein Überschreiben eines bestehenden Zielverzeichnisses.

Hier kein .NET-SDK. Abruf der offiziellen Linux-Testtoolchain scheiterte an der
Netzwerk-/Namensauflösung. Statische Prüfungen und unabhängiges Python-Modell sind
kein C#- oder Windows-Test. Der lokale Starter bleibt zwingend.

---
Historischer Änderungsvertrag:

## V0.3.0 ATTC-Fix und Beitrags-PDFs

164 Tests (125 alte unverändert; T91/T105/T128 korrigiert, T129–T164 neu). `RunRequest` und GUI verwenden
`ReviewTariffIssues=true` / `AllowMissingTariff=false`. Der reine Engine-Default bleibt
für strenge Kompatibilitätsprüfungen unverändert. Das neue Flag muss dort explizit
gewählt werden. Gleichzeitige Review- und AllowMissingTariff-Option ist ein Fehler.

CLI-Exitcode 4 = Beitragsteilergebnis mit offenen Personen-/Tarifmonaten oder PDF-Entwurfsfehlern;
Exitcode 3 = angeforderte IPP-Vorlage blockiert. Bei beiden bleibt die Datei nach
Prüfung als Teilergebnis lesbar; keine Freigabe eines Gesamtlaufs.
`config/options.review.json` dokumentiert den GUI/CLI-Standard,
`config/options.strict.json` bleibt die ausdrücklich streng abbrechende Alternative.

# Entwicklung und Qualifikation

## Toolchain

C# 14, .NET 10, Standardbibliothek; WinForms nur im Desktopprojekt.
Keine PackageReference und keine Online-NuGet-Quelle. Ein bestehendes portables Windows-
.NET-SDK kann außerhalb des Ordners verbleiben; der Pfad wird lokal gespeichert.
Build: `BUILD_UND_TEST.cmd`. Bedienoberfläche: `START.cmd`. Synthetischer CLI-Lauf: `DEMO.cmd`.
Die Wrapper haben CRLF, ASCII-Inhalt und kein BOM. Es wird kein langes PowerShell-
Skript in eine Konsole kopiert. Keine Backtick-Zeilenfortsetzungen.

Linux-/macOS-Coretests sind mit vorhandenem .NET-10-SDK prinzipiell separat möglich;
der Desktop-Build benötigt Windows-Desktop-Referenzen. Die gepackte Anwendung wurde
hier nicht kompiliert. Für den aktuellen realen Build ist evidence/local/DIAGNOSE.txt maßgeblich;
die enthaltene Lauf-ID bindet die Protokolle in evidence/local/runs.
Ältere CSharp-Berichte sind kein Nachweis eines aktuellen erfolgreichen Testlaufs. Schlägt ein Test fehl, nicht auskommentieren, um
die Oberfläche freizuschalten, sondern Ursache/Referenz prüfen.

CLI Beispiel (nach Build, eine Zeile):

```
dotnet src/Mcr.Ipp.Cli/bin/Release/net10.0/Mcr.Ipp.Cli.dll contribute --baseline examples/Bestand_Synthetisch.xlsx --txt examples/Monatsdaten/Aenderungen_012026.txt --out Output
```

`--ipp` fügt die geprüfte Vorbereitungsstufe hinzu; `--options` erlaubt explizite
Eingabeoptionen. Exitcodes: 0=Beitragsexport ohne offene Personen-/Tarifprüffälle, 2=Fehler, 3=Beitragspfad
fertig, angeforderte IPP-Stufe blockiert, 4=Personen-/Tarif-Teilergebnis oder PDF-Entwurfsfehler. 0 bedeutet niemals Produktions-PDF-freigegeben.

## Tests

180 benannte C#-Tests ohne externe Testframeworks. Die numerischen Sweeps vergleichen
6684 Beitragsergebnisse und 5030 Rundungsergebnisse mit gespeicherten Python-Vektoren.
Daneben: Tarif98/99, Rückwechsel, Fallback, Wiederaufnahme ohne ATTC, Ein-/Austritt,
Claim-Filter, Reihenfolge, Duplikate, Nullwerte, IDs, Parser, sichere XLSX-Texte,
Roundtrip, Demo-E2E und Ablehnung falscher IPP-Vorlagen. JUnit und JSON werden nur
nach tatsächlichem lokalen C#-Lauf erzeugt. Das Paket enthält keinen fiktiven PASS.

Die Demo stammt aus artifact_tool und nicht aus dem C#-Writer. Alle Personen sind
synthetisch. Nullwerte/Datumswerte/IDs werden dabei unabhängig vom Writer eingelesen.
Die reinen Formelreferenzen stammen aus dem Python-Funktionsauszug (offengelegte T01-
Korrektur und Datum-/NA-Adapter), nicht aus erwarteten C#-Ergebnissen.

Es fehlen noch: vollständige User-Python-Gesamtpipeline-Parität unter exakt gepinntem
Python/pandas-Stand, reale input/output Golden Cases, echte COM-Läufe, geänderte
Vorlagenversionen, unterschriebene/geschützte Sonderdateien, Produktionslast/Absturztests.
Die Input-Grammatik ist bewusst enger als pandas; siehe REGELVERTRAG.md.

## Nächster geschlossener Workstream

Zuerst den realen Windows-Build qualifizieren und alle Testfehler mit Belegen beheben.
Anschließend anonymisierte Realdaten von Baseline+TXT gegen den tatsächlich benutzten
Python-Stand vergleichen. Jede Abweichung als Eingabeschutz, Bugfix oder fachliche
Änderung klassifizieren; keine stillen Redefinitionen.

Für IPP nur die vom Nutzer benannte Vorlage und ihre explizit freigegebenen Datenquellen
verwenden. Den fehlenden Mappingvertrag anhand echter IPP-Belege schließen. Keine erneute
DC-/Benchmark-Projektsuche. Keine Mehrjahres-/Jahressummenannahme aus Spaltenpositionen.
VBA/Add-in nicht selbsttätig aktivieren. Erst nach Mapping-/Parameterfreigabe originale
und neue Personenergebnisse vergleichen, dann Excel-Renderpfad produktionsqualifizieren.

## Weitergabe eines Fehlerberichts

Für technische Buildprobleme sind build.log, tests.log, csharp_tests.json und ggf. JUnit
relevant. Keine Bestandsdateien, Monats-TXT, Beiträge oder PDFs ungeprüft hochladen.
Dateien im Output sind personenbezogene Kundendaten, keine automatisch anonymisierten
Support-Artefakte. Das Programm sendet nichts an externe Dienste.

## Launcher-Update 0.1.1

Gemeinsames SDK zuerst; Auswahl wird mit `--list-sdks`, `--version` im Projektordner
und `--list-runtimes` geprüft. `global.json` bleibt unverändert. Alle nativen
Exitcodes werden ausdrücklich auf Ungleichheit zu 0 geprüft; ein negativer
Host-Fehler darf nicht als Erfolg behandelt werden. START/DEMO verwenden denselben
Host, den BUILD_UND_TEST qualifiziert hat. SDK- und Compilerverzeichnis bleiben
unverändert; nutzerspezifische CLI-Zustände liegen im Projektordner.

Die Startfix-Änderungen wurden statisch und auf Paketintegrität geprüft, nicht
unter Windows ausgeführt. Es wurde kein C#-Code geändert oder Test übersprungen.

## Native Monats-PDFs

`--draft-pdfs true` schaltet interne Beitragsentwürfe ein. `DraftPdf` schreibt
einen begrenzten Standardfont-PDF; `ContributionDocuments` bindet Snapshot,
Personen-ID, Monatsumfang, offene Fälle und Dateihashes. Keine Pension-/LNW-
Berechnung und kein Excel-Start. Zulässiger Zeichensatz: Windows-1252.
Das unabhängige Python-Modell unter scripts/check_pdf_layout_model.py dient
nur der Layout-/Formatprüfung, nicht dem Produktivbetrieb oder C#-Nachweis.
