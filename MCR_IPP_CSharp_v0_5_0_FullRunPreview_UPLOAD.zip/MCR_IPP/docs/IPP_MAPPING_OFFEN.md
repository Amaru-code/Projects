# IPP-Mapping: belegte Ausgangslage und bewusst fehlende Freigabe

## Projektgrenze

Autoritative Dokumentvorlage laut Nutzer:
`Kopie BA von IPP Unverfallbarkeitsbescheinigung_Template.xlsm`.
SHA256: `A9F51A8CC0614A96903AE8975F6967D26549011CD8EDFB0DA0F028EABD0C591B`.
Die 17 bei einer früheren Projektsuche gefundenen DC-/Benchmark-Artefakte sind ausgeschlossen.
Ein ähnlicher Blattname macht eine andere Arbeitsmappe nicht zur Projektgrundlage.

## Vorliegende Informationen

Die vom Nutzer bereitgestellten Audits belegen Importbereiche für IPP-LNW mit
Schlussüberschuss, UVA und verfallbare Fälle. Die eigentlichen Exportmakros setzen
I1 als Datensatzselektor, lesen L2/L3 als Grenzen, filtern G82:G85 und exportieren
über Excel. Die Auswahl eines aktiven Zielblatts ist im neuen Produktionspfad noch
nicht autorisiert. Der alte Spezialexport Alter60 nutzte einen fest codierten Index.

Die Bestandseingabe `Contribution Calculation IPP 2026 - Template - neu.xlsx`
hatte nur ein Werteblatt mit ClientID, Stammdaten, BaseSalary_1 und PartTimeFactor_1.
Sie ist strukturell als Beitragseingabe geeignet; Herkunft und fachlicher Stichtag
sind dadurch nicht bewiesen.

Die untersuchte Halbjahresausgabe enthielt Monatsfelder bis AD=Betrag_6. In einer
UVA-Beispielzeile O570 wird dagegen AF der verknüpften Halbjahresdatei als
Beitragsbereitstellung abgefragt. Im untersuchten Dateistand wurde AF nicht mit
Inhalten nachgewiesen. Daher wird weder AF durch AD ersetzt noch automatisch
SUM(Betrag_1..6) als autoritative Bereitstellung geschrieben.

Salden-Beispielverweise N570/T570 zeigen auf P/S der verknüpften PP+-2026-Datei.
Andere Zeilen referenzieren ältere Dateien. Gleicher Dateiname beweist keine Version,
und ein gespeicherter Link beweist keine erfolgreiche Neuberechnung.

Das Dokument enthält Funkt_EBC.xla-Verweise (Alter und UnverfD), beschädigte Formeln in
LNW-Blättern und abweichende Formelbelegungen. In Import verfallbar!K2/K40 wird
TAB_Input24 referenziert; dieser Tabellenname gehört zu Import Austritte UVA, nicht
zum eigenen Blatt. Diese Befunde werden nicht automatisch „korrigiert“.

## Was die V0.1-Kopie tatsächlich ändert

Nur drei bestehende Paketbestandteile werden für neue Blätter angepasst:
`[Content_Types].xml`, `xl/workbook.xml`, `xl/_rels/workbook.xml.rels`.
Zwei neue XML-Arbeitsblätter enthalten Status und Monatsdaten. Das Workbook-Ansichts-
feld wird, sofern vorhanden, auf das Statusblatt gesetzt. Sonstige ursprüngliche
Paketbestandteile bleiben inhaltlich gleich und werden auf Payload-SHA256 geprüft.

Insbesondere unverändert: alle ursprünglichen Importblätter, Formeln, cached values,
Zins-/Plan-Tabellen, Zeichnungen, VBA-Binary und externe Verknüpfungen. Die ZIP-Bytes
selbst ändern sich natürlich beim Repacken. Ein Office-Paket mit `_xmlsignatures`
wird nicht verändert. Das ist technische Staging-Vorbereitung, keine LNW-Aktualisierung.

## Freigaben vor automatischer Bescheinigung

Die nächste Entwicklungsphase muss folgende Fragen anhand autorisierter IPP-Belege
schließen, nicht anhand einer DC-Referenz oder Modellvermutung:

- Zeitraum der Beitragsbereitstellung, Aggregation/Rundung, Leer-/Nullsemantik,
  Korrekturen und rückwirkende Lieferungen.
- Eindeutige Zuordnung ClientID/WWID/Versorgungsteil und der relevanten Personenmenge.
- Herkunft/Stichtag von Basis- und Schattensalden, Zins SK und planabhängigen Werten.
- Gültige Eckwerte und Zinsen; keine unbemerkte approximate-lookup-Ersatzregel.
- Entscheidung zwischen UVA, verfallbar und LNW; Sprachwahl und zuständiges Vorlageblatt.
- Version und Ergebnisparität von Alter(...,3) und UnverfD; kein automatisches Aktivieren
  fremder Add-ins. Ein vorhandener Prüfzellenwert ersetzt keine Entscheidungskette.
- Fehlende/überschriebene Formeln und typische Sonderfälle einschließlich 60/63/65,
  Eintritt/Austritt, doppelter Kennungen und mehrerer Tarifwechsel.
- Nachweis korrekter Layout-/Druckbereiche und finaler Dokumentfelder je Person.

Erst dann darf ein eigener versionierter Mappingvertrag Importspalten befüllen.
Die gegenwärtige `config/mapping.NOT_BOUND.json` ist Dokumentation, keine aktivierbare
Produktions-Policy. Ein Boolean auf true zu setzen würde die fehlenden Belege nicht ersetzen.
