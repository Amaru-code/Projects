# Quellen und Abgrenzung

## Vom Nutzer bereitgestellt

Der zuletzt gepostete Python-Code und die im IPP-Projektchat übermittelten statischen
XLSM-/Import-/Quellen-Audits. Der ursprüngliche makrobasierte Exportcode ist im Chat
enthalten. Die privaten Originalarbeitsmappen und kundenbezogenen PDF-Exporte werden
nicht in diesem Paket verteilt. Kein Datenmaterial aus dem DC-Benchmark wurde benutzt.

Bekannte Identitäten aus den Nutzer-Audits:

- IPP-Dokumentvorlage: A9F51A8CC0614A96903AE8975F6967D26549011CD8EDFB0DA0F028EABD0C591B
- Contribution-Bestandsvorlage: AD46F5D65C9B4168D06F0E1FD18F0A66DD5BD48A708974743D647AF476E53C72
- Halbjahresbeitragsdatei: A5308247DBBA57A23B8B5A41D6D7233F187C50140F1689E7A0A677AC02BE1C85

Die C#-Implementierung ist ein neuer Port, kein durch vollständige Tests bestätigtes
Duplikat aller pandas-Sonderfälle. Die Grenzen sind separat dokumentiert.

## Technische Primärdokumentation, abgerufen 29.09.2026

- .NET 10 und SDK/Runtime-Binaries: https://dotnet.microsoft.com/en-us/download/dotnet/10.0
- Python round und Binärzahl-Effekte: https://docs.python.org/3/library/functions.html#round
- Excel AutomationSecurity: https://learn.microsoft.com/en-us/office/vba/api/excel.application.automationsecurity
- Excel CalculateFullRebuild: https://learn.microsoft.com/en-us/office/vba/api/excel.application.calculatefullrebuild
- Excel Worksheet.ExportAsFixedFormat: https://learn.microsoft.com/en-us/office/vba/api/excel.worksheet.exportasfixedformat

Diese Quellen dokumentieren technische APIs, nicht die wirtschaftliche Gültigkeit
von IPP-Parametern, Zinsen, Unverfallbarkeit oder Bereitstellungszeiträumen.
