@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "ERRORLEVEL="
cd /d "%~dp0"
if not "%errorlevel%"=="0" goto failed
call BUILD_UND_TEST.cmd
set "IPP_START_RC=%errorlevel%"
if not "%IPP_START_RC%"=="0" goto failed
if not defined IPP_DOTNET goto failed
if not exist "src\Mcr.Ipp.Desktop\bin\Release\net10.0-windows\Mcr.Ipp.Desktop.dll" goto failed
"%IPP_DOTNET%" exec "src\Mcr.Ipp.Desktop\bin\Release\net10.0-windows\Mcr.Ipp.Desktop.dll"
set "IPP_START_RC=%errorlevel%"
if not "%IPP_START_RC%"=="0" goto app_failed
exit /b 0
:app_failed
>>"evidence\local\DIAGNOSE.txt" echo UI_EXIT=%IPP_START_RC%
>>"evidence\local\DIAGNOSE.txt" echo UI_RESULT=FAILED
:failed
echo.
echo Start abgebrochen. Details: evidence\local\DIAGNOSE.txt
pause
exit /b 1
