# V0.4.0: Betrag berechnen ist nicht Tarif oder Dokument freigeben

## Ursache und neue Regel

V0.3.1 hatte den ATTC-Fallback korrigiert, ließ aber `Amount=null`, sobald
`TariffReviewRequired` gesetzt war. Die Nutzerevidenz zeigt genau diesen Fall:
Januar-ATTC aus BaseSalary_1 vorhanden, Tarif unbekannt, Betrag leer.
Der ursprüngliche Python-Code schließt dagegen nur ausdrücklich bekannte 98/99 aus;
rein fehlende Tarife verhindern dort eine Berechnung mit gültigen Eingaben nicht.

Neue Einstellung `calculateMissingTariffProvisionally`:
- GUI, RunRequest und CLI ohne externe Optionen: **true**, sichtbar abschaltbar.
- Niedriger ContributionEngine-Aufruf mit `new ContributionOptions()`: **false**;
  expliziter Aufrufer muss zugleich `reviewTariffIssues=true` setzen.
- Profilkennung bleibt historisch; `AmountPolicy` und tatsächlich gespeicherte Optionen
  sind die maßgeblichen Rechenmodus-Informationen. Keine pauschale Voll-Parität behauptet.

Vorläufig erlaubt sind ausschließlich:
`NO_TXT_RECORD_NO_PRIOR_TARIFF`, `TARIFF_EMPTY_NO_PRIOR_TARIFF`, `TARIFF_COLUMN_MISSING`.
Die Berechnung ändert keinen Tarifwert. Unbekannt bleibt null.
`TARIFF_VALUE_INVALID`, `TARIFF_VALUES_CONFLICT`, `TARIFF_UNRESOLVED_AFTER_CONFLICT`
bleiben gehalten. Der letzte Status hat jetzt Vorrang vor fehlender Tarifspalte, damit
widersprüchliche Historie nicht im Folgemonat als harmlose Lücke zugelassen wird.

98/99 und die vorhandenen Masken bleiben unverändert. Gleiches gilt für negative
Gehaltswerte: der bestätigte Datenfehler wird nicht in eine neue Korrekturregel verwandelt.
Fehlendes ATTC, fehlender/Null-TZG, nicht ausgewählte Monate und nicht abgedeckte
Berechnungszeiträume werden nicht automatisch zu Geldbeträgen ergänzt.

## Getrennte Rechenergebnisse und Prüffälle

AmountStatus: `CALCULATED_PROVISIONAL_MISSING_TARIFF`.
AmountPolicy: `PYTHON_PROVISIONAL_MISSING_ONLY_CONFLICTS_HELD_V1`.
Der Fall bleibt OFFEN. Personenzuordnung, DAT_AD2, Tarif und Salden werden nicht erfunden.
`Ergebnis.xlsx` enthält numerische vorläufige Beträge und `MCR_Betragstatus_n` am Ende
(nicht zwischen bisherige Finanzspalten eingeschoben). Gelbe Markierung bleibt.
In Tarifpruefung.xlsx, Blatt Monate, steht der tatsächliche Betragsstatus.
Run_Report/00_LAUF_LESEN zählen vorläufige Beträge und tarifbedingt gehaltene getrennt.
Die Zahl offener Tarifmonate kann also unverändert bleiben, obwohl mehr Zahlen entstehen.

PDF-Entwürfe kennzeichnen diese Monatswerte mit VORLAEUFIG*. Weiterhin keine Gesamtsumme
bei offener Tarifprüfung. Die PDF-Prüfung akzeptiert vorläufige Zahlen nur, wenn
Rechenmodus, Ursache, Eingabewerte und erneute Formelberechnung dazu passen; ein
beliebiger Betrag unter einem offenen Tarif löst weiterhin DRAFT_UNSAFE_AMOUNT aus.
Die PDF-Datenbindung und Abschlussmechanik aus V0.3.1 bleiben erhalten.

Synthetisches Kontrollbeispiel nach dem vorhandenen Rechenkern:
Januar 2026, ATTC 10.180,64, TZG 100 → 166,90.
Das ist eine Formelauswertung, keine fachliche Anspruchsbestätigung.

## JSON-Export statt unvollständigem CSV

Die neue Excel mit den drei Vorlagen ist bisher nicht geliefert worden. Die Anwendung
liest genau die lokal ausgewählte Mappe, ohne sie zu verändern/Excel zu starten.
Sie erfasst Rohdaten für späteren Nachbau; keine behauptete universelle Excel-Engine.

Enthalten: Blattreihenfolge/Status, Zelladresse und Styleindex, Rohwerte und Text,
Formel-XML inklusive Shared-/Array-Metadaten, Richtext, Styles/Theme, Zeilen/Spalten,
Verbindungen, Druckbereiche/-titel, Papier/Margen/Seitenumbrüche/Header/Footer,
Zeichnungen/Textfelder/Charts/Tabellen sowie referenzierte Bilddaten.
Gespeicherte Formelwerte werden deutlich als **nicht neu berechnet** gekennzeichnet.
Originale Formeln werden nicht repariert, übersetzt oder zu ausgedachten Regeln gemacht.

Nicht enthalten: Ausführung von VBA/XLM, OLE-/ActiveX-Binärinhalten, Abfragen,
externer Verknüpfungs-Caches, installierten Schriftdateien oder Autorenmetadaten.
Externe Zielordner in Relationship-Records werden durch Basename+Pfadhash ersetzt;
Formeln, definierte Namen, Zeichnungs-XML können trotzdem vertrauliche Inhalte tragen.
Keine Anonymisierungs- oder exakte PDF-Layoutgarantie. Fehlende Fonts/Druckertreiber/UDFs
und nicht unterstützte Zeichnungstypen können beim späteren Rendering relevant sein.

Text/Layout in Vorlagen.json und VORLAGEN_TEIL_*.json; Bildbytes in separaten
BILDER_TEIL_*.json (Base64, Hash, Bytelänge, verknüpfter Paketpfad).
Große Records/Assets werden gehasht und in Textfragmente geteilt. Fragmentnummer,
Gesamtzahl und JSON-Text müssen beim Zusammenfügen erhalten bleiben. Keine OCR.

## Nächster echter Dokumentenschritt

Drei Vorlagen auswerten: tatsächliche Namen und Struktur erhalten, Platzhalter und
Quellen pro Feld bestimmen, explizite Fall-/Sprachregel für die Auswahl definieren.
Erst danach Integration und Vergleich von vollständigen Musterfällen.
Kein Prototyp-Feld oder PDF-Beitragsentwurf wird als echte LNW-Freigabe ausgegeben.

## Tests

180 bisherige Testdefinitionen unverändert plus 32 neue (212).
Kernformel, 11.714 Vektoren, SDK-Auswahl, Personenbestätigung und OutputPublication
sind gegenüber V0.3.1 bytegleich. Tests 181–198 und 211–212 decken Rechenmodus ab;
199–210 definieren JSON-/Pfad-/Bild-/Hash-/Datenschutz-/Fragmentprüfungen.
Hier kein .NET-SDK; die C#-Tests und der echte GUI-/JSON-Export sind NICHT ausgeführt.
Unabhängige Python-Modelle und statische Prüfungen sind getrennt gekennzeichnet.
