@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
if not "%errorlevel%"=="0" exit /b 1
call BUILD_UND_TEST.cmd
set "IPP_RC=%errorlevel%"
if not "%IPP_RC%"=="0" goto failed
"%IPP_DOTNET%" exec "src\Mcr.Ipp.Desktop\bin\Release\net10.0-windows\Mcr.Ipp.Desktop.dll" --export-templates
set "IPP_RC=%errorlevel%"
if not "%IPP_RC%"=="0" goto failed
exit /b 0
:failed
echo Export/Build nicht abgeschlossen. Fehler und Diagnose beachten.
pause
exit /b 1
