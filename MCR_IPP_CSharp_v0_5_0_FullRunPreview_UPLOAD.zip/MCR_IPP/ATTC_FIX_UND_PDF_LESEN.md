> Historischer Versionshinweis. **V0.4.0:** Rein fehlende Tarife können jetzt sichtbar vorläufig berechnet werden; Konflikte bleiben gehalten. Aktuell maßgeblich: BETRAGSFIX_UND_VORLAGENEXPORT_LESEN.md und START_HIER.md.

# Aenderungsvertrag 0.2.1 -> 0.3.0

## Korrigierter Fehler

Die C#-Tarifpruefung hatte `TariffReviewRequired` vor die ATTC-Uebernahme gestellt.
Dadurch wurden vorhandene TXT-Gehaelter und insbesondere der Januar-Fallback aus
`BaseSalary_1` verworfen. Der Folgefehler leerte teilweise auch die Gehaltsfortschreibung.

0.3.0 trennt nun Gehaltsdaten von der tariflichen Berechnungsfreigabe:

| Zustand | ATTC | Betrag |
|---|---|---|
| eindeutiger Tarif, passende TXT-Angabe | TXT | berechnen wie bisher |
| keine passende TXT-Angabe im Januar | BaseSalary_1, sofern vorhanden | nur ohne offene Tarifpruefung |
| spaeterer Monat ohne passende TXT-Angabe | direkter Vormonats-ATTC | nur ohne offene Tarifpruefung |
| unbekannter / widerspruechlicher Tarif | vorhandenes Gehalt/Fallback sichtbar | leer, Prueffall |
| gesicherter Tarif 98/99 | leer wie Python | leer wie Python |
| vor DAT_AD2 / nach wirksamem AUGUAN-Austritt | leer wie bisher | leer wie bisher |

Kein Rueckfuellen aus spaeteren Monaten. Kein Ueberspringen einer fehlenden
Vormonatsspalte. Ein nach gesichertem Tarif 99 geleerter ATTC wird nicht allein
aufgrund eines spaeter erlaubten Tarifs neu hergestellt. Ein Fehler in Gehalts-
oder Teilzeitdaten wird nicht durch die Tarifpruefung verborgen.

Der Testvertrag T91, T105 und T128 wurde ausdruecklich geaendert: Die alte Erwartung
`ATTC leer bei Tarifpruefung` war der gemeldete Fehler, kein beizubehaltendes Soll.
36 neue Tests T129..T164 decken den Gehalts-Fallback und den Dokumentenweg ab.
128 alte Tests minus 3 geaenderte Erwartungen plus dieselben 3 neuen Erwartungen
plus 36 neue Tests = 164 Testdefinitionen.

`Calculation.cs`, Personenpruefung/-bestaetigung, Golden-Vektoren, Eingabebeispiele,
SDK-Resolver und global.json bleiben unveraendert. V0.3.0 benutzt keine DC-Referenz.

## PDF-Entwurf ist NICHT LNW

Der neue native C#-Adapter erzeugt eigene interne Monatsuebersichten, keine Nachbildung
der autoritativen IPP-Bescheinigung. Inhalt: Name/ID, ausgewaehlte Monate, ATTC, TZG,
Monatsbetrag, Status, Gehaltsherkunft und Hash des Beitrags-Snapshots.
Keine Salden/Zinsen, Initialbausteine, Renten, Vertragszitate oder erfundenen Leistungszusagen.

Regeln:
- Auf jeder Seite `ENTWURF - INTERN - NICHT VERSENDEN`.
- Personen mit Tarifluecken erhalten einen als unvollstaendig markierten Entwurf;
  Betragsluecken werden nicht mit 0 gefuellt.
- Nicht bestaetigte TXT-Personen erhalten keinen Entwurf. Der Plan nennt diesen Grund.
- Keine Summierung bei mindestens einem nicht numerischen Monatsbetrag.
- Bei vollstaendig numerischen Monaten nur arithmetische Summe der genau gezeigten
  Monatswerte; ausdruecklich keine Beitragsbereitstellung oder Jahreskontostand.
- Dateiname benutzt die normalisierte ID und das Jahr, niemals einen geratenen Namen.
- Ein PDF enthaelt nur die betreffende Person, nicht die Prueffallnamen anderer Personen.
- Strenges WinAnsi/Windows-1252; ununterstuetzte Zeichen erzeugen einen PDF-Prueffall,
  keine stille Transliteration oder Fragezeichen. JSON/Excel behalten den Namen.
- PDF 1.4 Standardfonts, keine eingebetteten Fontdateien, kein PDF/A-/PDF/UA-Versprechen.
- Quelldaten werden als Hex-Text in PDF geschrieben; keine PDF-Syntax aus Namensfeldern.
- Hash des `Contribution_Result.json` wird vor dem Export gegen das aktuelle
  Rechenergebnis geprueft. Kein Import beliebiger alter/manuell bearbeiteter Ergebnisse.
- Schreiben in neuen Laufordner; kein Ueberschreiben von bestehenden PDF-Ordnern.
- Abbruch verhindert die Veroeffentlichung des Gesamtlaufordners.
- Pro-Dokument-Zeichen-/Layoutfehler isoliert; Dateisystem-/Strukturfehler brechen ab.

`PdfStatus=NOT_AUTHORIZED` bleibt Produktionsstatus. Zusaetzlich gibt es jetzt
`DraftPdfStatus`, `DraftPdfsCreated` und `DraftPdfFailures`. Historische Felder wie
`pdfsCreated` im Run_Report zaehlen jetzt real erzeugte ENTWUERFE;
`productionPdfsCreated` ist weiterhin 0.

In der UI ist die Entwurfsoption eingeschaltet. Bei API/CLI-Aufrufen ist sie aus,
sofern `CreateContributionDraftPdfs=true` bzw. `--draft-pdfs true` nicht gesetzt wird.

## Grenzen / Fehlerbehebung

Noch kein Realdatenvergleich gegen den vollstaendigen pandas-Ablauf. Die Beitrags-
berechnung bei unbekanntem Tarif bleibt strenger als Python (Betrag wird zurueckgehalten).
Eine vollstaendige Gehalts-Uebernahme ist daher kein Vollstaendigkeitssiegel fuer Beitraege.

Die Anzahl offener Tarifpruefungen kann identisch bleiben, obwohl deutlich mehr
ATTC-Werte sichtbar sind. Das ist erwartet: Gehalt erhalten bedeutet nicht Tarif geklaert.

Bei Problemen nur den geprueften aktuellen `00_LAUF_LESEN.txt` oder, wenn der Start
scheitert, `evidence/local/DIAGNOSE.txt` weitergeben. Keine Kundendaten pauschal hochladen.
