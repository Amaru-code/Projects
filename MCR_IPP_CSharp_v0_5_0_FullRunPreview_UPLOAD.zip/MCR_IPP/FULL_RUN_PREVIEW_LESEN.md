# MCR IPP 0.5.0 - erster Full-Run-Preview

Diese Version bindet genau eine uebertragene PDF-Vorlage ein:

- Template-ID: `UVA_OHNE_ZINS_DE_V1`
- Quellblatt: `Aktiv -> UVA ohne Zins`
- Quell-Workbook: `Mappe1.xlsx`
- Quell-SHA256: `B750B8A7770CD6F2FE492533A4226FE5ED129633A55B5047400F9A9D4161233F`
- Integrierte Definition: `config/templates/UVA_OHNE_ZINS_V1.json`

## Was ein normaler GUI-Lauf nun tut

1. Bestand + Monats-TXT einlesen.
2. Personen- und Tarifpruefung wie bisher.
3. `Ergebnis.xlsx` und Rechenprotokolle erzeugen.
4. Fuer Personen mit Austrittsdatum einen dreiseitigen PDF-Preview nach der UVA-Vorlage erzeugen.
5. Nicht anwendbare Personen und offene Vorlagenfelder getrennt protokollieren.
6. Ausgabehashes pruefen und den Run atomar abschliessen.

Neue Artefakte:

- `UVA_PDF_Entwuerfe/*.pdf`
- `UVA_Dokumentenplan.xlsx` / `.json`
- `UVA_Feldluecken.xlsx` / `.json`

## Wichtige Grenze des ersten Full Runs

Die Layout-/Textvorlage ist integriert, aber mehrere wirtschaftliche Felder sind noch nicht an eine aktuelle, autoritative Quelle gebunden. Diese werden im PDF **OFFEN** dargestellt und in `UVA_Feldluecken.xlsx` gelistet. Sie werden niemals als 0 interpretiert.

Noch nicht produktiv gebunden sind insbesondere:

- Beitragsfaehige Bezuege
- Garantierente
- Garantiezins
- Saldovortrag
- Beitragsbereitstellung (nur ein klar markierter Kandidat bei vollstaendigen 12/12 Monaten waere moeglich)
- Kuerzungsbetrag Initialbaustein
- Schlussueberschuss
- Zins
- Initialbaustein
- Todesfallkapital

`ClientID` wird nur im Preview als Kennung verwendet, wenn keine explizite `WWID` im Bestand vorhanden ist. Das ist **keine** bestaetigte ClientID-WWID-Gleichsetzung.

Diese PDFs tragen deshalb den Wasserzeichen-Hinweis `MCR FULL RUN PREVIEW - NICHT VERSENDEN`.

## Naechster fachlicher Workstream

Nach dem ersten Full-Run-Preview ist der naechste Schritt die Bindung der noch offenen wirtschaftlichen Felder an die autoritative IPP-Datenbasis. Erst danach kann die Wasserzeichen-/Preview-Sperre entfernt und ein produktiver UVA-PDF-Lauf qualifiziert werden.
