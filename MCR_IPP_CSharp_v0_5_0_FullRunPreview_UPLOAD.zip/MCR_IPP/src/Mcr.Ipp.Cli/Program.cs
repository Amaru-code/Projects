using Mcr.Ipp.Core;
using System.Text.Json;

if (args.Length == 0 || args[0] is "help" or "--help")
{
    Console.WriteLine("""
    MCR IPP 0.5.0 - C# Contribution + UVA-Vorlagen Full-Run-Preview (nicht DC)

    contribute --baseline Bestand.xlsx --txt Aenderung_012026.txt --txt Aenderung_022026.txt --out Output
               [--ipp Original_IPP.xlsm] [--options options.json] [--decisions Personenfreigaben.json] [--draft-pdfs true|false] [--uva-preview true|false] [--uva-template template.json]
    inspect --ipp Original_IPP.xlsm --out IPP_Pruefung.json
    export-templates --workbook DreiVorlagen.xlsx --out Vorlagenexport

    UVA-Vorlage ist als JSON eingebunden. Offene wirtschaftliche Felder bleiben im Preview sichtbar OFFEN; keine produktiven IPP-PDFs.
    """);
    return 0;
}
try
{
    var arguments = new Dictionary<string, List<string>>(StringComparer.Ordinal);
    for (int i = 1; i < args.Length; i++)
    {
        if (!args[i].StartsWith("--", StringComparison.Ordinal) || i + 1 >= args.Length) throw new IppException("ARGUMENT", "Argument erwartet --name wert.");
        string key = args[i++]; if (!arguments.TryGetValue(key, out var values)) arguments[key] = values = new(); values.Add(args[i]);
    }
    string Required(string key) => arguments.TryGetValue(key, out var v) && v.Count == 1 ? v[0] : throw new IppException("ARGUMENT", "Genau ein Wert erforderlich: " + key);
    string? Optional(string key) => arguments.ContainsKey(key) ? Required(key) : null;
    if (args[0] == "contribute")
    {
        foreach (var k in arguments.Keys) if (!new[] { "--baseline", "--txt", "--out", "--ipp", "--options", "--decisions", "--draft-pdfs", "--uva-preview", "--uva-template" }.Contains(k)) throw new IppException("ARGUMENT", "Unbekannte Option: " + k);
        bool drafts = false;
        if (Optional("--draft-pdfs") is { } draftOption && !bool.TryParse(draftOption, out drafts))
            throw new IppException("ARGUMENT", "--draft-pdfs erwartet true oder false.");
        bool uvaPreview = false; if (Optional("--uva-preview") is { } uvaOption && !bool.TryParse(uvaOption, out uvaPreview)) throw new IppException("ARGUMENT", "--uva-preview erwartet true oder false.");
        var request = new RunRequest { BaselinePath = Required("--baseline"), TxtPaths = arguments.GetValueOrDefault("--txt") ?? new(), OutputDirectory = Required("--out"), IppTemplatePath = Optional("--ipp"), PersonDecisionsPath = Optional("--decisions"), CreateContributionDraftPdfs = drafts, CreateUvaTemplatePreviewPdfs = uvaPreview, UvaTemplateJsonPath = Optional("--uva-template"), Options = Optional("--options") is { } file ? JsonFiles.Read<ContributionOptions>(file) : new() { ReviewTariffIssues = true, CalculateMissingTariffProvisionally = true } };
        var result = new Pipeline().Execute(request, Console.WriteLine);
        Console.WriteLine(JsonSerializer.Serialize(result, JsonFiles.Options));
        return result.IppStatus.StartsWith("BLOCKED", StringComparison.Ordinal) ? 3 : result.OpenPersonCases > 0 || result.OpenTariffMonths > 0 || result.DraftPdfFailures > 0 || result.UvaTemplatePdfFailures > 0 || result.UvaTemplateWithMappingGaps > 0 ? 4 : 0;
    }
    if (args[0] == "export-templates")
    {
        foreach (var k in arguments.Keys) if (k is not ("--workbook" or "--out")) throw new IppException("ARGUMENT", "Unbekannte Option: " + k);
        var exported = TemplateJsonExport.Export(Required("--workbook"), Required("--out"));
        Console.WriteLine(JsonSerializer.Serialize(exported, JsonFiles.Options)); return 0;
    }
    if (args[0] == "inspect")
    {
        var target = Required("--out");
        if (File.Exists(target)) throw new IppException("OUTPUT_EXISTS", "Diagnoseziel existiert bereits; wird nicht ueberschrieben.");
        JsonFiles.Write(target, TemplatePreparation.Inspect(SourceBlob.Read(Required("--ipp"))));
        Console.WriteLine("Statischer IPP-Pruefbericht erstellt. Kein Excel-Start."); return 0;
    }
    throw new IppException("COMMAND", "Unbekanntes Kommando.");
}
catch (Exception ex)
{
    Console.Error.WriteLine((ex is IppException ie ? ie.Code : ex.GetType().Name) + ": " + ex.Message);
    return 2;
}
