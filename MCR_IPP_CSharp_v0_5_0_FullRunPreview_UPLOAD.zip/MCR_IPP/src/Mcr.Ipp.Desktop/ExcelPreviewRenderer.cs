using System.Diagnostics;
using System.Runtime.InteropServices;
using Mcr.Ipp.Core;

namespace Mcr.Ipp.Desktop;

public sealed class PreviewJob
{
    public string Mode { get; set; } = "PREVIEW_ONLY";
    public string Workbook { get; set; } = "";
    public string ExpectedSha256 { get; set; } = "";
    public string OutputDirectory { get; set; } = "";
    public string Sheet { get; set; } = "Aktiv -> UVA ohne Zins";
    public List<int> DatasetIndices { get; set; } = new();
}
/// <summary>Explicit developer preview adapter, NOT an end-to-end IPP authorizer.
/// Refuses external references/active content and the unresolved production mapping.
/// Always uses a copy, flags every PDF as a draft, and never writes original inputs.</summary>
public static class ExcelPreviewRenderer
{
    private static void Release(object? o) { if (o is not null && Marshal.IsComObject(o)) Marshal.FinalReleaseComObject(o); }
    private static object? Read(dynamic sheet, string address)
    {
        object? range = null;
        try { range = sheet.Range[address]; return ((dynamic)range).Value2; }
        finally { Release(range); }
    }
    private static void Write(dynamic sheet, string address, object value)
    {
        object? range = null;
        try { range = sheet.Range[address]; ((dynamic)range).Value2 = value; }
        finally { Release(range); }
    }
    private static void WaitForCalculation(dynamic excel)
    {
        var timer = Stopwatch.StartNew();
        while ((int)excel.CalculationState != 0) { if (timer.Elapsed > TimeSpan.FromSeconds(90)) throw new IppException("EXCEL_TIMEOUT", "Excel-Berechnung nicht fertig."); Thread.Sleep(100); }
    }
    public static string Render(string jobFile)
    {
        var job = JsonFiles.Read<PreviewJob>(jobFile);
        if (job.Mode != "PREVIEW_ONLY" || job.DatasetIndices.Count == 0 || job.DatasetIndices.Count > 100 || job.DatasetIndices.Any(n => n < 1) || job.DatasetIndices.Distinct().Count() != job.DatasetIndices.Count)
            throw new IppException("PREVIEW_JOB_INVALID", "Nur explizite, eindeutige Vorschau-Datensaetze 1..n; maximal 100.");
        if (job.Sheet is not ("Aktiv -> UVA ohne Zins" or "Schattenzis Korrektur")) throw new IppException("PREVIEW_SHEET", "V0.1-Vorschau nur fuer belegte IPP-UVA-Vorlagen.");
        if (string.IsNullOrWhiteSpace(job.OutputDirectory)) throw new IppException("PREVIEW_OUTPUT", "Ausgabeordner fehlt.");
        var source = SourceBlob.Read(job.Workbook);
        if (job.ExpectedSha256.Length != 64 || !source.Info.Sha256.Equals(job.ExpectedSha256, StringComparison.OrdinalIgnoreCase)) throw new IppException("PREVIEW_HASH", "Quellenhash nicht gebunden.");
        var audit = TemplatePreparation.Inspect(source);
        if (!audit.Sheets.Contains("Import Austritte UVA") || audit.Sheets.Any(s => s.StartsWith("LNW DC", StringComparison.OrdinalIgnoreCase))) throw new IppException("PREVIEW_SCOPE", "Keine IPP-UVA-Vorlage.");
        if (audit.ExternalFileNames.Count > 0 || audit.ActiveParts.Count > 0 || audit.Blockers.Contains("NON_WORKBOOK_EXTERNAL_REFERENCE"))
            throw new IppException("PREVIEW_DEPENDENCIES", "Vorschau gesperrt: externe Quellen/UDFs oder aktive Bestandteile. Original-IPP-Datei ist noch nicht freigegeben; nichts automatisch entfernen.");
        if (audit.BrokenFormulaAddresses.Count > 0) throw new IppException("PREVIEW_BROKEN_FORMULAS", "Vorschau gesperrt: ungueltige Formelbezuge.");
        var processes = Process.GetProcessesByName("EXCEL");
        bool busy = processes.Length > 0; foreach (var p in processes) p.Dispose();
        if (busy) throw new IppException("EXCEL_RUNNING", "Bitte Excel nach Sicherung Ihrer Arbeiten schliessen. Keine Prozesse werden beendet.");
        string output = Path.GetFullPath(job.OutputDirectory); Directory.CreateDirectory(output);
        string name = "IPP_PREVIEW_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + "_" + Guid.NewGuid().ToString("N")[..8];
        string stage = Path.Combine(output, ".inprogress_" + name), final = Path.Combine(output, name); Directory.CreateDirectory(stage);
        string copy = Path.Combine(stage, "IPP_ARBEITSKOPIE.xlsm"); File.WriteAllBytes(copy, source.Bytes);
        object? app = null, books = null, seed = null, book = null, sheets = null, sheet = null, import = null, page = null;
        var generated = new List<object>();
        bool success = false;
        try
        {
            var excelType = Type.GetTypeFromProgID("Excel.Application") ?? throw new IppException("EXCEL_MISSING", "Excel Desktop nicht verfuegbar.");
            app = Activator.CreateInstance(excelType) ?? throw new IppException("EXCEL_START", "Excel konnte nicht gestartet werden.");
            dynamic excel = app;
            excel.AutomationSecurity = 3; excel.EnableEvents = false; excel.DisplayAlerts = false; excel.AskToUpdateLinks = false; excel.Visible = false;
            books = excel.Workbooks; seed = ((dynamic)books).Add(); excel.Calculation = -4135; excel.CalculateBeforeSave = false;
            excel.AutomationSecurity = 3;
            book = ((dynamic)books).Open(copy, 0, false);
            sheets = ((dynamic)book).Worksheets;
            sheet = ((dynamic)sheets).Item[job.Sheet]; import = ((dynamic)sheets).Item["Import Austritte UVA"];
            dynamic ws = sheet; ws.Activate();
            page = ws.PageSetup;
            if (string.IsNullOrWhiteSpace((string)((dynamic)page).PrintArea)) throw new IppException("PRINT_AREA_UNBOUND", "Druckbereich muss in der geprueften Arbeitskopie explizit festgelegt sein.");
            ((dynamic)page).CenterHeader = "&BENTWURF - NICHT FREIGEGEBEN";
            foreach (int index in job.DatasetIndices)
            {
                var id = Parse.Text(Read((dynamic)import, "B" + (index + 1))) ?? throw new IppException("PREVIEW_ROW_EMPTY", "Leere WWID fuer Datensatz " + index);
                Write(ws,"I1",index);
                excel.CalculateFullRebuild(); WaitForCalculation(excel);
                if (Parse.Text(Read(ws,"I21")) != id) throw new IppException("PREVIEW_ID_MISMATCH", "Selektor passt nicht zur importierten WWID.");
                foreach (var required in new[] { "I14", "I23", "I24", "I26", "I27", "F86" }) if (Read(ws,required) is null) throw new IppException("PREVIEW_REQUIRED_VALUE", "Pflichtfeld leer: " + required);
                object? used = null, cells = null;
                try
                {
                    used = ws.UsedRange; cells = ((dynamic)used).Cells;
                    int count = (int)((dynamic)cells).Count;
                    if (count > 10000) throw new IppException("PREVIEW_SHEET_LIMIT", "Vorschau-Blatt ueber 10000 Zellen.");
                    for (int i=1; i<=count; i++)
                    {
                        object? cell = null;
                        try { cell = ((dynamic)cells).Item[i]; string text = Convert.ToString(((dynamic)cell).Text) ?? ""; if (text.StartsWith("#",StringComparison.Ordinal)) throw new IppException("PREVIEW_EXCEL_ERROR", "Fehler oder unlesbare Anzeige in der Vorschau."); }
                        finally { Release(cell); }
                    }
                }
                finally { Release(cells); Release(used); }
                object? rows = null, filter = null;
                try
                {
                    rows = ws.Rows; ((dynamic)rows).Hidden = false;
                    filter = ws.Range["G82:G85"];
                    // Preserve the actual old VBA AutoFilter range: row 82 is its header.
                    ((dynamic)filter).AutoFilter(1, "<>0");
                    string filename = "ENTWURF_IPP_Datensatz_" + index.ToString("D6") + ".pdf";
                    string path = Path.Combine(stage,filename);
                    ws.ExportAsFixedFormat(0,path,0,true,false,Type.Missing,Type.Missing,false);
                    byte[] bytes = File.ReadAllBytes(path);
                    if (bytes.Length < 100 || System.Text.Encoding.ASCII.GetString(bytes,0,5)!="%PDF-") throw new IppException("PDF_INVALID", "Excel lieferte keine gueltige PDF-Datei.");
                    generated.Add(new { dataset=index, file=filename, sha256=Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(bytes)) });
                    ws.AutoFilterMode=false;
                }
                finally { Release(filter); Release(rows); }
            }
            JsonFiles.Write(Path.Combine(stage,"Preview_Report.json"),new { status="PREVIEW_ONLY_NOT_BUSINESS_CERTIFIED", source=source.Info, files=generated, productionAuthorized=false, noMappingPerformed=true });
            success=true;
        }
        finally
        {
            Release(page); Release(import); Release(sheet); Release(sheets);
            if (book is not null) { try { ((dynamic)book).Close(false); } catch { } }
            if (seed is not null) { try { ((dynamic)seed).Close(false); } catch { } }
            Release(book); Release(seed); Release(books);
            if (app is not null) { try { ((dynamic)app).Quit(); } catch { } }
            Release(app); GC.Collect(); GC.WaitForPendingFinalizers();
            if (!success) JsonFiles.Write(Path.Combine(stage,"FAILED.json"),new { status="PREVIEW_FAILED_NOT_PUBLISHED", productionAuthorized=false });
        }
        if (success) { Directory.Move(stage,final); return "Nur Entwurfs-PDFs erstellt: " + final; }
        throw new IppException("PREVIEW_FAILED","Keine Freigabe.");
    }
}
