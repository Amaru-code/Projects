using System.Diagnostics;
using System.Windows.Forms;
using Mcr.Ipp.Core;

namespace Mcr.Ipp.Desktop;

internal static class TemplateExportDialog
{
    public static void Run(IWin32Window? owner = null)
    {
        using var select = new OpenFileDialog
        {
            Title = "Die Excel-Datei mit deinen drei IPP-Vorlagen auswaehlen",
            Filter = "Excel-Vorlagen (*.xlsx;*.xlsm;*.xltx;*.xltm)|*.xlsx;*.xlsm;*.xltx;*.xltm",
            CheckFileExists = true, Multiselect = false
        };
        if (select.ShowDialog(owner) != DialogResult.OK) return;
        if (MessageBox.Show(owner,
            "Der Export enthaelt Texte, Formeln, gespeicherte Werte, auch ausgeblendete Zellen und Bilder. " +
            "Bitte nur die Vorlagenkopie ohne unnoetige Kundendaten verwenden. " +
            "Excel wird nicht gestartet und die Quelldatei wird nicht gespeichert. Fortfahren?",
            "Vorlagen nach JSON - Datenschutz", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) != DialogResult.OK) return;
        try
        {
            Cursor.Current = Cursors.WaitCursor;
            string root = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MCR_IPP_Vorlagenexport");
            var exported = TemplateJsonExport.Export(select.FileName, root);
            Cursor.Current = Cursors.Default;
            Process.Start(new ProcessStartInfo("notepad.exe") { ArgumentList = { Path.Combine(exported.Directory, "00_START_HIER.txt") }, UseShellExecute = false });
            Process.Start(new ProcessStartInfo(exported.Directory) { UseShellExecute = true });
            MessageBox.Show(owner,
                $"{exported.Sheets} Blaetter und {exported.Assets} Bilder erfasst.\n" +
                $"{exported.LayoutParts} VORLAGEN-Teile, {exported.ImageParts} BILDER-Teile.\n\n" +
                "Zuerst 00_START_HIER.txt und VORLAGEN_TEIL_...json pruefen und kopieren.\n" +
                "Dies ist noch kein Import/keine Aktivierung der neuen PDF-Vorlagen.\n\n" + exported.Directory,
                "Vorlagenexport abgeschlossen");
        }
        catch (Exception ex)
        {
            Environment.ExitCode = 2;
            MessageBox.Show(owner, (ex is IppException ie ? ie.Code + ": " : "") + ex.Message +
                "\n\nBei einer Dateisperre die Vorlage in Excel schliessen. Keine Sicherheitsoptionen aendern.",
                "Vorlagenexport nicht abgeschlossen", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        finally { Cursor.Current = Cursors.Default; }
    }
}
