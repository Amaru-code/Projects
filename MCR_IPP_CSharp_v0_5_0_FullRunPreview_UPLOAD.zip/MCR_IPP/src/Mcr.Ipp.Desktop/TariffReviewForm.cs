using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Mcr.Ipp.Core;

namespace Mcr.Ipp.Desktop;

public sealed class TariffReviewForm : Form
{
    public TariffReviewForm(string runDirectory)
    {
        var report = JsonFiles.Read<TariffReviewReport>(Path.Combine(runDirectory, "Tarif_Pruefung.json"));
        Text = "IPP | Tarifpruefung - Personen und Monate";
        Width = 1160; Height = 760; MinimumSize = new Size(850, 620);
        Font = new Font("Segoe UI", 10); StartPosition = FormStartPosition.CenterParent;
        var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 4, Padding = new Padding(12) };
        layout.RowStyles.Add(new(SizeType.AutoSize)); layout.RowStyles.Add(new(SizeType.Percent, 100));
        layout.RowStyles.Add(new(SizeType.Absolute, 160)); layout.RowStyles.Add(new(SizeType.AutoSize));
        var heading = new Label { AutoSize = true, Padding = new Padding(0,0,0,12), Text = $"{report.AffectedPersons} Personen / {report.OpenMonthCases} offene Tarifmonate. ATTC bleibt erhalten; Beitraege dieser Monate sind gesperrt.\nNamen stammen aus dem Bestand. Kein Tarif wird automatisch ergaenzt oder rueckwirkend aus Folgemonaten uebernommen." };
        var grid = new DataGridView { Dock = DockStyle.Fill, AutoGenerateColumns = false, ReadOnly = true,
            AllowUserToAddRows = false, AllowUserToDeleteRows = false, SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            MultiSelect = false, RowHeadersVisible = false, BackgroundColor = Color.White };
        foreach (var col in new[] { ("ClientId", "ClientID", 120), ("DisplayName", "Name aus Bestand", 210), ("Month", "Monat", 90),
            ("Classification", "Ursache", 310), ("Resolution", "Pruefstatus", 140), ("SourceFile", "Quelldatei", 220) })
            grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = col.Item1, HeaderText = col.Item2, Width = col.Item3 });
        var details = new TextBox { Dock = DockStyle.Fill, Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Both };
        void ShowDetails()
        {
            if (grid.CurrentRow?.DataBoundItem is not TariffCase c) { details.Text = "Keine Faelle vorhanden."; return; }
            details.Text = c.Note + Environment.NewLine + "Original-ID im Bestand: " + c.OriginalClientId + Environment.NewLine
                + "Fundstellen (logische Datenrecords, nicht zwingend physische Textzeilen):" + Environment.NewLine
                + (c.Occurrences.Count == 0 ? "Keine Zeile fuer diese ID im betreffenden TXT gefunden."
                    : string.Join(Environment.NewLine, c.Occurrences.Select(o => $"{o.File} | Record {o.DataRecord} | ID {o.OriginalId} | Tarifspalte {o.TariffColumn ?? "[FEHLT]"} | Wert {o.RawTariff ?? "[LEER]"} | {o.Error ?? ""}")));
        }
        grid.SelectionChanged += (_, _) => ShowDetails();
        var controls = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, Padding = new Padding(0,8,0,0) };
        var all = new CheckBox { Text = "Auch nicht mehr berechnungsrelevante Faelle zeigen", AutoSize = true };
        void Bind() { grid.DataSource = (all.Checked ? report.Cases : report.Cases.Where(c => c.Open).ToList()); ShowDetails(); }
        all.CheckedChanged += (_, _) => Bind();
        var excel = new Button { Text = "Tarifpruefung.xlsx oeffnen", AutoSize = true };
        excel.Click += (_, _) => { try { Process.Start(new ProcessStartInfo(Path.Combine(runDirectory,"Tarifpruefung.xlsx")) { UseShellExecute = true }); } catch(Exception ex) { MessageBox.Show(this, ex.Message); } };
        var close = new Button { Text = "Schliessen", AutoSize = true }; close.Click += (_, _) => Close();
        controls.Controls.Add(all); controls.Controls.Add(excel); controls.Controls.Add(close);
        layout.Controls.Add(heading,0,0); layout.Controls.Add(grid,0,1); layout.Controls.Add(details,0,2); layout.Controls.Add(controls,0,3);
        Controls.Add(layout); Bind();
    }
}
