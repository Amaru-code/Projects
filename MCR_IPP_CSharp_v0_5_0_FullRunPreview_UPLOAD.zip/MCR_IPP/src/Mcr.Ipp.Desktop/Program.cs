using System.Drawing;
using System.Windows.Forms;
namespace Mcr.Ipp.Desktop;
internal static class Program
{
    [STAThread]
    private static void Main(string[] args)
    {
        Application.SetHighDpiMode(HighDpiMode.PerMonitorV2);
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        if (args.Length == 2 && args[0] == "--render-preview")
        {
            try { var outcome = ExcelPreviewRenderer.Render(args[1]); MessageBox.Show(outcome, "IPP PDF-Vorschau"); }
            catch (Exception ex) { MessageBox.Show(ex.Message, "IPP PDF gesperrt/fehlgeschlagen", MessageBoxButtons.OK, MessageBoxIcon.Warning); Environment.ExitCode = 2; }
            return;
        }
        if (args.Length == 1 && args[0] == "--export-templates")
        {
            TemplateExportDialog.Run(); return;
        }
        Application.Run(new MainForm());
    }
}
