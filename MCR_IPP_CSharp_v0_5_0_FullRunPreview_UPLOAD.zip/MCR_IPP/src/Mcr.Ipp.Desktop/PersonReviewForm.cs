using System.Drawing;
using System.Windows.Forms;
using Mcr.Ipp.Core;
using System.Diagnostics;

namespace Mcr.Ipp.Desktop;

public sealed class PersonReviewForm : Form
{
    public PersonReviewForm(string runDirectory, string decisionsPath)
    {
        Text = "IPP | Personenpruefung - keine stillen Auslassungen";
        Width = 1120; Height = 650; StartPosition = FormStartPosition.CenterParent;
        Font = new Font("Segoe UI", 10);
        var report = JsonFiles.Read<PersonReviewReport>(Path.Combine(runDirectory, "Personen_Pruefung.json"));
        var title = new Label { Dock = DockStyle.Top, Height = 65, Padding = new Padding(12), Text = $"{report.OpenCases} offen / {report.AddedPersons} bestaetigt aufgenommen.\nNur gepruefte Neueintritte bestaetigen. Namen/Daten aus TXT sind Hinweise, keine HR-Freigabe." };
        var grid = new DataGridView { Dock = DockStyle.Fill, ReadOnly = true, AllowUserToAddRows = false, AllowUserToDeleteRows = false, MultiSelect = false, SelectionMode = DataGridViewSelectionMode.FullRowSelect, AutoGenerateColumns = false, RowHeadersVisible = false };
        foreach (var col in new[] { ("ClientId", "ID", 125), ("DisplayName", "Name", 210), ("Classification", "Einordnung", 250), ("Resolution", "Status", 200), ("Note", "Hinweis", 400) })
            grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = col.Item1, HeaderText = col.Item2, Width = col.Item3 });
        grid.DataSource = report.Cases;
        var buttons = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 70, Padding = new Padding(10) };
        var approve = new Button { Text = "Neueintritt pruefen / bestaetigen...", AutoSize = true };
        var details = new Button { Text = "Pruefliste / Fundstellen oeffnen", AutoSize = true };
        var close = new Button { Text = "Schliessen", AutoSize = true };
        details.Click += (_, _) => Process.Start(new ProcessStartInfo(Path.Combine(runDirectory, "Prueffaelle.xlsx")) { UseShellExecute = true });
        close.Click += (_, _) => Close();
        approve.Click += (_, _) =>
        {
            if (grid.CurrentRow?.DataBoundItem is not PersonCase c) return;
            if (c.Added) { MessageBox.Show(this, "Dieser Fall wurde in diesem Lauf bereits aufgenommen."); return; }
            if (c.Classification is "KENNUNG_UNGUELTIG" or "IDENTITAETSDATEN_KONFLIKT" or "MOEGLICHER_BESTANDSTREFFER_ANDERE_ID")
            { MessageBox.Show(this, "Diesen Identitaets-/Dublettenfall bitte anhand ID und Fundstellen untersuchen. Keine automatische Zuordnung und keine Neuanlage."); return; }
            using var form = new ConfirmNewPersonForm(c, report.ContextSha256);
            if (form.ShowDialog(this) != DialogResult.OK || form.Decision is null) return;
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(decisionsPath))!);
                // Exclusive lock avoids lost updates from two local application instances. Existing file is backed up.
                using var gate = new FileStream(decisionsPath + ".lock", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
                var decisions = File.Exists(decisionsPath) ? JsonFiles.Read<List<NewPersonDecision>>(decisionsPath) : new();
                if (File.Exists(decisionsPath)) File.Copy(decisionsPath, decisionsPath + "." + Guid.NewGuid().ToString("N") + ".bak");
                decisions.RemoveAll(d => d.ContextSha256 == report.ContextSha256 && d.CaseId == c.CaseId);
                decisions.Add(form.Decision);
                string tmp = decisionsPath + "." + Guid.NewGuid().ToString("N") + ".tmp";
                JsonFiles.Write(tmp, decisions); File.Move(tmp, decisionsPath, true);
                MessageBox.Show(this, "Bestaetigung gespeichert. Jetzt erneut 'Beitraege erstellen' mit denselben Eingaben.\nErst nach erneuter Identitaets-, Dubletten- und Monatsdatenpruefung wird die Person aufgenommen. Vorhandene Laufdateien bleiben unveraendert.", "IPP - Bestaetigung gespeichert");
            }
            catch (Exception ex) { MessageBox.Show(this, ex.Message, "Freigabe konnte nicht gespeichert werden", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
        };
        buttons.Controls.Add(approve); buttons.Controls.Add(details); buttons.Controls.Add(close);
        Controls.Add(grid); Controls.Add(buttons); Controls.Add(title);
    }
}

internal sealed class ConfirmNewPersonForm : Form
{
    public NewPersonDecision? Decision { get; private set; }
    public ConfirmNewPersonForm(PersonCase c, string context)
    {
        Text = "Neueintritt bestaetigen | ID " + c.ClientId;
        Width = 750; Height = 600; StartPosition = FormStartPosition.CenterParent;
        Font = new Font("Segoe UI", 10);
        var layout = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(18), ColumnCount = 2, RowCount = 9 };
        layout.ColumnStyles.Add(new(SizeType.Absolute, 230)); layout.ColumnStyles.Add(new(SizeType.Percent, 100));
        var surname = new TextBox { Text = c.Surname ?? "", Dock = DockStyle.Fill };
        var first = new TextBox { Text = c.FirstName ?? "", Dock = DockStyle.Fill };
        var birth = new TextBox { Text = c.BirthDate?.ToString("dd.MM.yyyy") ?? "", Dock = DockStyle.Fill };
        var entry = new TextBox { Text = c.DatAd2?.ToString("dd.MM.yyyy") ?? "", Dock = DockStyle.Fill };
        var reviewer = new TextBox { Text = Environment.UserName, Dock = DockStyle.Fill };
        var reason = new TextBox { Multiline = true, Dock = DockStyle.Fill, ScrollBars = ScrollBars.Vertical };
        var fields = new (string Name, Control Field)[] { ("Nachname (geprueft)", surname), ("Vorname (geprueft)", first), ("Geburtsdatum TT.MM.JJJJ", birth), ("DAT_AD2 / Beitragsbeginn", entry), ("Geprueft von", reviewer), ("Beleg / Grund fuer Neueintritt", reason) };
        for (int i = 0; i < fields.Length; i++)
        {
            layout.RowStyles.Add(new(SizeType.Absolute, i == 5 ? 95 : 42));
            layout.Controls.Add(new Label { Text = fields[i].Name, AutoSize = true }, 0, i); layout.Controls.Add(fields[i].Field, 1, i);
        }
        var instruction = new Label { Text = "DAT_AD2 ist der bestaetigte Beitragsbeginn. Nicht aus dem ersten TXT-Fund oder aus JoiningDate raten. Bestehende Person unter anderer ID: abbrechen und untersuchen.", Dock = DockStyle.Fill };
        layout.RowStyles.Add(new(SizeType.Absolute, 65)); layout.Controls.Add(instruction, 0, 6); layout.SetColumnSpan(instruction, 2);
        var check = new CheckBox { Text = "Ich habe Neueintritt, Identitaet, Beitragsbeginn und fehlende Dublette geprueft.", AutoSize = true };
        layout.RowStyles.Add(new(SizeType.Absolute, 45)); layout.Controls.Add(check, 0, 7); layout.SetColumnSpan(check, 2);
        var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill };
        var save = new Button { Text = "Bestaetigung speichern", AutoSize = true };
        var cancel = new Button { Text = "Abbrechen", AutoSize = true, DialogResult = DialogResult.Cancel };
        buttons.Controls.Add(save); buttons.Controls.Add(cancel); layout.Controls.Add(buttons, 0, 8); layout.SetColumnSpan(buttons, 2);
        save.Click += (_, _) =>
        {
            try
            {
                var b = Parse.Date(birth.Text, "BirthDate"); var e = Parse.Date(entry.Text, "DAT_AD2");
                if (!check.Checked || b is null || e is null || b >= e || string.IsNullOrWhiteSpace(surname.Text) || string.IsNullOrWhiteSpace(first.Text) || string.IsNullOrWhiteSpace(reviewer.Text) || string.IsNullOrWhiteSpace(reason.Text))
                    throw new IppException("CONFIRMATION_MISSING", "Alle Felder und die ausdrueckliche Bestaetigung werden benoetigt.");
                Decision = new() { ContextSha256 = context, CaseId = c.CaseId, ClientId = c.ClientId, Surname = surname.Text.Trim(), FirstName = first.Text.Trim(), BirthDate = b.Value, DatAd2 = e.Value, Reviewer = reviewer.Text.Trim(), Evidence = reason.Text.Trim(), ConfirmedUtc = DateTimeOffset.UtcNow, IdentityAndNewEntryVerified = true };
                DialogResult = DialogResult.OK; Close();
            }
            catch (Exception ex) { MessageBox.Show(this, ex.Message, "Angaben pruefen", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
        };
        Controls.Add(layout); CancelButton = cancel;
    }
}
