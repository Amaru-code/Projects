using System.IO.Compression;
using System.Security.Cryptography;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Xml;
using System.Xml.Linq;

namespace Mcr.Ipp.Core;

public sealed class TemplateCapture
{
    public string Schema { get; set; } = "MCR_IPP_TEMPLATE_LAYOUT_V1";
    public SourceInfo Source { get; set; } = new("", "", 0);
    public bool Recalculated { get; set; } = false;
    public bool MacrosExecuted { get; set; } = false;
    public bool ExactPdfLayoutCertified { get; set; } = false;
    public List<string> SheetNames { get; set; } = new();
    public List<JsonObject> Records { get; set; } = new();
    // Raw image data travels separately to keep the initial copy/paste report short.
    public List<JsonObject> Assets { get; set; } = new();
    public List<string> Notices { get; set; } = new();
}
public sealed record TemplateExportOutcome(string Directory, int Sheets, int Assets, int LayoutParts, int ImageParts, string SourceSha256);

/// <summary>Static OOXML layout capture, not an Excel formula engine or a PDF renderer.</summary>
public static class TemplateJsonExport
{
    public static readonly JsonSerializerOptions Options = new(JsonFiles.Options) { Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping };
    private static string Xml(XElement e) => e.ToString(SaveOptions.DisableFormatting);
    private static Dictionary<string, string> Attr(XElement e) => e.Attributes().Where(a => !a.IsNamespaceDeclaration)
        .ToDictionary(a => a.Name.ToString(), a => a.Value, StringComparer.Ordinal);
    private static XElement? Child(XElement e, string name) => e.Elements().FirstOrDefault(n => n.Name.LocalName == name);
    private static IEnumerable<XElement> Children(XElement e, string name) => e.Elements().Where(n => n.Name.LocalName == name);
    private static string Sha(byte[] data) => Convert.ToHexString(SHA256.HashData(data));
    private static string PlainText(XElement? e) => e is null ? "" : string.Concat(e.Descendants().Where(n => n.Name.LocalName == "t" && !n.Ancestors().Any(a => a.Name.LocalName == "rPh")).Select(n => n.Value));
    private static string RelId(XElement e) => e.Attributes().FirstOrDefault(a => a.Name.LocalName == "id" && a.Name.NamespaceName.Length > 0)?.Value
        ?? throw new IppException("TEMPLATE_RELATION", "Relationship-ID fehlt.");
    private static string Resolve(string from, string target)
    {
        if (string.IsNullOrWhiteSpace(target) || target.Contains('\\')) throw new IppException("TEMPLATE_PATH", "Ungueltiger Paketpfad.");
        var u = new Uri(new Uri("https://package.invalid/" + from), target);
        if (u.Authority != "package.invalid" || u.Scheme != "https" || u.Query.Length != 0 || u.Fragment.Length != 0)
            throw new IppException("TEMPLATE_PATH", "Externes Paket-Ziel wird nicht geoeffnet.");
        string p = Uri.UnescapeDataString(u.AbsolutePath.TrimStart('/'));
        if (p.Split('/').Any(s => s is ".." or ".") || p.Contains('\\')) throw new IppException("TEMPLATE_PATH", "Ungueltiger Paketpfad.");
        return p;
    }
    private static string ExternalLabel(string target)
    {
        if (Uri.TryCreate(target, UriKind.Absolute, out var u) && (u.Scheme is "http" or "https")) target = u.AbsolutePath;
        return Uri.UnescapeDataString(target).Replace('\\', '/').Split('/').LastOrDefault() ?? "";
    }

    public static TemplateCapture Capture(SourceBlob source, CancellationToken cancel = default)
    {
        cancel.ThrowIfCancellationRequested();
        if (!new[] { ".xlsx", ".xlsm", ".xltx", ".xltm" }.Contains(Path.GetExtension(source.Info.Name).ToLowerInvariant()))
            throw new IppException("TEMPLATE_FORMAT", "Bitte eine unverschluesselte XLSX/XLSM-Vorlagenkopie auswaehlen; keine XLS/XLSB.");
        if (source.Bytes.LongLength > 64L * 1024 * 1024) throw new IppException("TEMPLATE_SIZE", "Vorlagenmappe ueber 64 MiB.");
        if (Sha(source.Bytes) != source.Info.Sha256 || source.Bytes.LongLength != source.Info.Bytes)
            throw new IppException("TEMPLATE_SOURCE_HASH", "Quell-Snapshot und Hash stimmen nicht ueberein.");
        using var memory = new MemoryStream(source.Bytes, false);
        using var zip = new ZipArchive(memory, ZipArchiveMode.Read);
        if (zip.Entries.Count > 10000 || zip.Entries.Sum(e => e.Length) > 128L * 1024 * 1024)
            throw new IppException("TEMPLATE_SIZE", "Zu viele oder zu grosse Paketbestandteile.");
        var entries = new Dictionary<string, ZipArchiveEntry>(StringComparer.Ordinal);
        foreach (var e in zip.Entries)
        {
            if (e.FullName.StartsWith('/') || e.FullName.Contains('\\') || e.FullName.Split('/').Contains("..") || !entries.TryAdd(e.FullName, e))
                throw new IppException("TEMPLATE_PATH", "Doppelter oder unsicherer ZIP-Pfad.");
        }
        var read = new HashSet<string>(StringComparer.Ordinal);
        byte[] Bytes(string p)
        {
            cancel.ThrowIfCancellationRequested();
            if (!entries.TryGetValue(p, out var e)) throw new IppException("TEMPLATE_PART_MISSING", "Paketbestandteil fehlt: " + p);
            if (e.Length > 16L * 1024 * 1024) throw new IppException("TEMPLATE_SIZE", "Ein Paketbestandteil ist groesser als 16 MiB: " + p);
            using var s = e.Open(); using var m = new MemoryStream(); s.CopyTo(m); read.Add(p); return m.ToArray();
        }
        XElement Root(string p)
        {
            using var s = new MemoryStream(Bytes(p), false);
            using var x = XmlReader.Create(s, new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null, MaxCharactersInDocument = 16777216 });
            return XDocument.Load(x, LoadOptions.PreserveWhitespace).Root ?? throw new IppException("TEMPLATE_XML", "XML-Wurzel fehlt: " + p);
        }
        List<XElement> Relations(string p)
        {
            int slash = p.LastIndexOf('/'); string rp = p[..(slash + 1)] + "_rels/" + p[(slash + 1)..] + ".rels";
            return entries.ContainsKey(rp) ? Children(Root(rp), "Relationship").ToList() : new();
        }
        XElement FindRelation(List<XElement> rels, string id) => rels.SingleOrDefault(x => (string?)x.Attribute("Id") == id)
            ?? throw new IppException("TEMPLATE_RELATION", "Relationship nicht gefunden: " + id);
        string Target(string p, XElement rel)
        {
            if ((string?)rel.Attribute("TargetMode") == "External") throw new IppException("TEMPLATE_PATH", "Externe Datei wird nicht geoeffnet.");
            return Resolve(p, (string?)rel.Attribute("Target") ?? "");
        }
        var capture = new TemplateCapture { Source = source.Info };
        void Add(string kind, string owner, object data) => capture.Records.Add(new JsonObject
        {
            ["kind"] = kind, ["owner"] = owner, ["data"] = JsonSerializer.SerializeToNode(data, Options)
        });
        capture.Notices.Add("Enthaelt alle Zellwerte, Formeln, gespeicherte Formelwerte, auch ausgeblendete Inhalte und Bilder. Keine Anonymisierung. Vor Weitergabe pruefen.");
        capture.Notices.Add("Gespeicherte Formelwerte sind kein Neuberechnungsnachweis. Fonts/Formel-UDFs/Druckertreiber sind nicht enthalten; Layouttreue ist noch nicht getestet.");
        capture.Notices.Add("VBA, XLM-Ausfuehrung, ActiveX, OLE, externe Daten-Caches, Abfragen, eingebettete Schriftdateien und Dokument-Autorenmetadaten werden nicht exportiert/ausgefuehrt.");
        var workbook = Root("xl/workbook.xml");
        var wr = Relations("xl/workbook.xml");
        var sheetNodes = Child(workbook, "sheets")?.Elements().Where(x => x.Name.LocalName == "sheet").ToList() ?? new();
        if (sheetNodes.Count == 0) throw new IppException("TEMPLATE_SHEETS", "Keine Blaetter vorhanden.");
        if (sheetNodes.Count != 3) capture.Notices.Add("BLATTANZAHL=" + sheetNodes.Count + "; nicht drei. Es wird nichts abgeschnitten; drei Vorlagen koennen auch anders verteilt sein.");
        Add("workbook", "xl/workbook.xml", new { attributes = Attr(workbook), settingsXml = workbook.Elements().Where(x => x.Name.LocalName is "workbookPr" or "calcPr" or "bookViews" or "definedNames").Select(Xml).ToList() });
        var sharedRel = wr.FirstOrDefault(r => ((string?)r.Attribute("Type"))?.EndsWith("/sharedStrings", StringComparison.Ordinal) == true);
        List<XElement> strings = sharedRel is null ? new() : Children(Root(Target("xl/workbook.xml", sharedRel)), "si").ToList();
        foreach (var rel in wr.Where(r => ((string?)r.Attribute("Type"))?.EndsWith("/styles", StringComparison.Ordinal) == true || ((string?)r.Attribute("Type"))?.EndsWith("/theme", StringComparison.Ordinal) == true))
        { string p = Target("xl/workbook.xml", rel); Add("globalStyleXml", p, new { xml = Xml(Root(p)) }); }

        var related = new Queue<string>();
        void SaveRelationships(string p, List<XElement> rels, bool traverse)
        {
            foreach (var rel in rels)
            {
                string raw = (string?)rel.Attribute("Target") ?? "", type = (string?)rel.Attribute("Type") ?? "";
                bool external = (string?)rel.Attribute("TargetMode") == "External";
                string dest = external ? ExternalLabel(raw) : Resolve(p, raw);
                Add("relationship", p, new { id = (string?)rel.Attribute("Id"), type, external, target = dest,
                    externalPathSha256 = external ? Sha(Encoding.UTF8.GetBytes(raw)) : null });
                if (traverse && !external) related.Enqueue(dest);
            }
        }
        SaveRelationships("xl/workbook.xml", wr, false);
        // External link ordinal is local to this workbook. Deliberately omit sheetDataSet caches.
        int externalIndex = 0;
        foreach (var rel in Child(workbook, "externalReferences")?.Elements() ?? Enumerable.Empty<XElement>())
        {
            string p = Target("xl/workbook.xml", FindRelation(wr, RelId(rel)));
            var root = Root(p); var book = Child(root, "externalBook"); var rels = Relations(p);
            Add("externalReference", p, new { index = ++externalIndex,
                sheetNames = book is null ? new List<string>() : Child(book, "sheetNames")?.Elements().Select(x => (string?)x.Attribute("val") ?? "").ToList() ?? new(),
                cacheExported = false });
            SaveRelationships(p, rels, false);
        }
        int cellCount = 0;
        foreach (var sheet in sheetNodes)
        {
            cancel.ThrowIfCancellationRequested();
            string name = (string?)sheet.Attribute("name") ?? "", p = Target("xl/workbook.xml", FindRelation(wr, RelId(sheet)));
            var rel = FindRelation(wr, RelId(sheet));
            if (!(((string?)rel.Attribute("Type"))?.EndsWith("/worksheet", StringComparison.Ordinal) ?? false))
            { capture.Notices.Add("NICHT_ERFASSTER_BLATTTYP: " + name + " | " + (string?)rel.Attribute("Type")); continue; }
            var root = Root(p); capture.SheetNames.Add(name);
            Add("sheet", p, new { name, attributes = Attr(sheet), codeName = (string?)Child(root, "sheetPr")?.Attribute("codeName"),
                dimension = (string?)Child(root, "dimension")?.Attribute("ref") });
            foreach (var node in root.Elements().Where(n => n.Name.LocalName != "sheetData"))
                Add("sheetLayoutXml", p, new { element = node.Name.LocalName, xml = Xml(node) });
            foreach (var row in Child(root, "sheetData")?.Elements() ?? Enumerable.Empty<XElement>())
            {
                var cells = new List<object>();
                foreach (var c in Children(row, "c"))
                {
                    if (++cellCount > 50000) throw new IppException("TEMPLATE_CELL_LIMIT", "Ueber 50000 gespeicherte Zellen. Bitte nur die drei Vorlagen ohne grossen Datenbestand exportieren.");
                    string? value = Child(c, "v")?.Value, kind = (string?)c.Attribute("t");
                    XElement? rich = Child(c, "is");
                    if (kind == "s")
                    {
                        if (!int.TryParse(value, out int i) || i < 0 || i >= strings.Count) throw new IppException("TEMPLATE_STRING", "Shared-String-Verweis ungueltig.");
                        rich = strings[i];
                    }
                    cells.Add(new { address = (string?)c.Attribute("r"), attributes = Attr(c), storedValue = value,
                        text = rich is not null ? PlainText(rich) : kind is "str" or "e" ? value : null,
                        richTextXml = rich is null ? null : Xml(rich), formulaXml = Child(c, "f") is { } f ? Xml(f) : null,
                        formulaCacheUnverified = Child(c, "f") is not null });
                }
                Add("row", p, new { attributes = Attr(row), cells });
            }
            SaveRelationships(p, Relations(p), true);
        }
        if (capture.SheetNames.Count == 0) throw new IppException("TEMPLATE_SHEETS", "Keine unterstuetzten Arbeitsblaetter.");
        var seenRelated = new HashSet<string>(StringComparer.Ordinal);
        while (related.TryDequeue(out string? p))
        {
            if (!seenRelated.Add(p)) continue;
            string ext = Path.GetExtension(p).ToLowerInvariant();
            bool image = p.StartsWith("xl/media/", StringComparison.Ordinal) && new[] { ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tif", ".tiff", ".svg", ".emf", ".wmf" }.Contains(ext);
            bool xml = (p.StartsWith("xl/drawings/", StringComparison.Ordinal) || p.StartsWith("xl/charts/", StringComparison.Ordinal) || p.StartsWith("xl/tables/", StringComparison.Ordinal)) && (ext is ".xml" or ".vml");
            if (image)
            {
                byte[] bytes = Bytes(p); string hash = Sha(bytes);
                capture.Assets.Add(new JsonObject { ["kind"] = "image", ["part"] = p, ["sha256"] = hash, ["bytes"] = bytes.LongLength, ["extension"] = ext, ["base64"] = Convert.ToBase64String(bytes) });
                Add("imageReference", p, new { sha256 = hash, bytes = bytes.LongLength, extension = ext, transport = "BILDER_TEIL_*.json" });
            }
            else if (xml)
            { Add("relatedLayoutXml", p, new { xml = Xml(Root(p)) }); SaveRelationships(p, Relations(p), true); }
            else capture.Notices.Add("NICHT_EXPORTIERTER_VERKNUePFTER_BESTANDTEIL: " + p);
        }
        Add("coverage", "package", new { cellCount, sourceSheetEntries = sheetNodes.Count, capturedSheets = capture.SheetNames.Count,
            usedSharedStringsOnly = true, omittedParts = entries.Keys.Where(p => !read.Contains(p) && !p.EndsWith('/')).OrderBy(p => p, StringComparer.Ordinal).ToList() });
        return capture;
    }

    // Each transport file is valid JSON. Big records are losslessly split, never truncated.
    public static List<JsonObject> Frames(IReadOnlyList<JsonObject> records)
    {
        var frames = new List<JsonObject>();
        for (int i = 0; i < records.Count; i++)
        {
            string text = records[i].ToJsonString(Options);
            if (text.Length <= 6500) frames.Add(new JsonObject { ["record"] = i, ["value"] = records[i].DeepClone() });
            else
            {
                var pieces = new List<string>();
                for (int pos = 0; pos < text.Length;)
                {
                    int count = Math.Min(5000, text.Length - pos);
                    if (pos + count < text.Length && char.IsHighSurrogate(text[pos + count - 1])) count--;
                    pieces.Add(text.Substring(pos, count)); pos += count;
                }
                string hash = Sha(Encoding.UTF8.GetBytes(text));
                for (int part = 0; part < pieces.Count; part++) frames.Add(new JsonObject { ["record"] = i, ["fragment"] = part + 1, ["fragments"] = pieces.Count, ["recordSha256"] = hash, ["jsonTextFragment"] = pieces[part] });
            }
        }
        return frames;
    }
    private static List<string> WriteParts(string folder, string prefix, SourceInfo source, IReadOnlyList<JsonObject> records)
    {
        var groups = new List<List<JsonObject>>(); var group = new List<JsonObject>(); int size = 0;
        foreach (var frame in Frames(records))
        {
            int n = frame.ToJsonString(Options).Length;
            if (group.Count > 0 && size + n > 12000) { groups.Add(group); group = new(); size = 0; }
            group.Add(frame); size += n;
        }
        if (group.Count > 0) groups.Add(group);
        var names = new List<string>();
        for (int i = 0; i < groups.Count; i++)
        {
            string name = $"{prefix}_TEIL_{i + 1:D3}.json"; names.Add(name);
            var root = new { schema = "MCR_IPP_TEMPLATE_TRANSPORT_V1", group = prefix, source, part = i + 1, totalParts = groups.Count, records = groups[i] };
            File.WriteAllText(Path.Combine(folder, name), JsonSerializer.Serialize(root, Options), new UTF8Encoding(false));
        }
        return names;
    }
    public static TemplateExportOutcome Export(string input, string outputRoot, CancellationToken cancel = default)
    {
        string stage = "";
        try
        {
            using var source = new FileStream(input, FileMode.Open, FileAccess.Read, FileShare.Read);
            if (source.Length > 64L * 1024 * 1024) throw new IppException("TEMPLATE_SIZE", "Vorlagenmappe ueber 64 MiB.");
            using var buffer = new MemoryStream(); source.CopyTo(buffer); byte[] bytes = buffer.ToArray(); string before = Sha(bytes);
            var blob = new SourceBlob(bytes, new(Path.GetFileName(input), before, bytes.LongLength));
            var capture = Capture(blob, cancel);
            source.Position = 0; string after = Convert.ToHexString(SHA256.HashData(source));
            if (before != after) throw new IppException("TEMPLATE_CHANGED", "Quelldatei waehrend Export geaendert.");
            Directory.CreateDirectory(outputRoot);
            string run = "IPP_Run_Vorlagen_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + "_" + Guid.NewGuid().ToString("N")[..8];
            string final = Path.Combine(outputRoot, run); stage = Path.Combine(outputRoot, ".inprogress_" + run); Directory.CreateDirectory(stage);
            var header = new JsonObject { ["kind"] = "export", ["data"] = JsonSerializer.SerializeToNode(new { capture.Schema, capture.Source, capture.SheetNames, capture.Recalculated, capture.MacrosExecuted, capture.ExactPdfLayoutCertified, capture.Notices, sourceUnchanged = "PASS", imageCount = capture.Assets.Count }, Options) };
            var records = new List<JsonObject> { header }; records.AddRange(capture.Records);
            File.WriteAllText(Path.Combine(stage, "Vorlagen.json"), JsonSerializer.Serialize(new { schema = capture.Schema, source = capture.Source, records }, Options), new UTF8Encoding(false));
            var main = WriteParts(stage, "VORLAGEN", blob.Info, records);
            var images = WriteParts(stage, "BILDER", blob.Info, capture.Assets);
            File.WriteAllText(Path.Combine(stage, "00_START_HIER.txt"),
                $"MCR_IPP_TEMPLATE_EXPORT=1.0\nSTATUS=EXPORTED_LAYOUT_DATA\nQUELLE_UNVERAENDERT=PASS\nSHA256={before}\nDATEI={blob.Info.Name}\nBLAETTER={capture.SheetNames.Count}\n" +
                string.Join("\n", capture.SheetNames.Select((n, i) => $"BLATT_{i + 1}={n}")) +
                $"\nBILDER={capture.Assets.Count}\nVORLAGEN_TEILE={main.Count}\nBILDER_TEILE={images.Count}\n" +
                "Zuerst diese Uebersicht und die VORLAGEN_TEIL-Dateien in Reihenfolge uebertragen. Bilderteile getrennt, falls benoetigt. Keine Original-XLSM umbenennen.\n" +
                "Die Teile sind gueltige JSON-Dateien. Grosse Datensaetze sind Textfragmente mit Hash; keine Kuerzung.\n" +
                string.Join("\n", capture.Notices) + "\n" + string.Join("\n", main.Concat(images).Select(n => "BERICHT=" + n)), new UTF8Encoding(false));
            JsonFiles.Write(Path.Combine(stage, "Manifest.json"), Directory.GetFiles(stage).OrderBy(p => p, StringComparer.Ordinal).Select(p => new { file = Path.GetFileName(p), bytes = new FileInfo(p).Length, sha256 = Sha(File.ReadAllBytes(p)) }).ToList());
            cancel.ThrowIfCancellationRequested(); OutputPublication.MoveRun(stage, final, progress: null, cancel: cancel);
            return new(final, capture.SheetNames.Count, capture.Assets.Count, main.Count, images.Count, before);
        }
        catch (Exception ex) { if (stage.Length > 0) ex.Data["TemplateExportPendingDirectory"] = stage; throw; }
    }
}
