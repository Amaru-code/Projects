using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace Mcr.Ipp.Core;

public sealed record PersonOccurrence(string File, string Sha256, string Month, int DataRecord, string OriginalId, Dictionary<string, string> IdentityFields);
public sealed class PersonCase
{
    public string CaseId { get; set; } = "";
    public string ClientId { get; set; } = "";
    public string DisplayName { get; set; } = "NAME_NICHT_GELIEFERT";
    public string? Surname { get; set; }
    public string? FirstName { get; set; }
    public DateOnly? BirthDate { get; set; }
    public DateOnly? DatAd2 { get; set; }
    public string Classification { get; set; } = "UNBEKANNT_NEUEINTRITT_NICHT_BELEGT";
    public string Resolution { get; set; } = "OFFEN";
    public string Note { get; set; } = "";
    public List<string> PossibleBaselineIds { get; set; } = new();
    public List<PersonOccurrence> Occurrences { get; set; } = new();
    public bool Added => Resolution == "NEUAUFNAHME_BESTAETIGT";
}
public sealed class PersonReviewReport
{
    public string Schema { get; set; } = "MCR_IPP_PERSON_REVIEW_V1";
    public string ContextSha256 { get; set; } = "";
    public int BaselinePersons { get; set; }
    public List<SourceInfo> Inputs { get; set; } = new();
    public Dictionary<string, List<string>> TxtHeaders { get; set; } = new();
    public List<PersonCase> Cases { get; set; } = new();
    public List<string> Notices { get; set; } = new();
    public int OpenCases => Cases.Count(c => !c.Added);
    public int AddedPersons => Cases.Count(c => c.Added);
}
// A local operator decision is not proof from an HR system. It is bound to one exact input snapshot.
public sealed class NewPersonDecision
{
    public string ContextSha256 { get; set; } = "";
    public string CaseId { get; set; } = "";
    public string ClientId { get; set; } = "";
    public string Surname { get; set; } = "";
    public string FirstName { get; set; } = "";
    public DateOnly BirthDate { get; set; }
    public DateOnly DatAd2 { get; set; }
    public string Reviewer { get; set; } = "";
    public string Evidence { get; set; } = "";
    public DateTimeOffset ConfirmedUtc { get; set; }
    public bool IdentityAndNewEntryVerified { get; set; }
}
public sealed record PreparedPersons(InputTable Baseline, List<MonthFile> Months, PersonReviewReport Report);

public static class PersonReview
{
    // These are display/candidate aliases, NEVER authority for an automatic new admission.
    private static readonly Dictionary<string, string[]> Aliases = new()
    {
        ["Surname"] = new[] { "SURNAME", "NACHNAME", "FAMILIENNAME", "KDMANACHNAME" },
        ["FirstName"] = new[] { "FIRSTNAME", "VORNAME", "KDMAVORNAME" },
        ["FullName"] = new[] { "FULLNAME", "NAME", "KDMANAME" },
        ["BirthDate"] = new[] { "BIRTHDATE", "GEBURTSDATUM", "DATGEBURT", "KDMAGEBURTSDATUM" },
        ["DAT_AD2"] = new[] { "DATAD2" }
    };
    private static string Normal(string? text) => Regex.Replace((text ?? "").Trim().ToUpperInvariant(), @"\s+", " ");
    private static string Hash(string text) => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(text)));
    private static bool IsField(string name) => Aliases.Values.Any(a => a.Contains(Parse.Header(name), StringComparer.Ordinal));
    private static List<string> Values(PersonCase c, string field) => c.Occurrences.SelectMany(o => o.IdentityFields)
        .Where(kv => Aliases[field].Contains(Parse.Header(kv.Key), StringComparer.Ordinal)).Select(kv => kv.Value)
        .Distinct(StringComparer.Ordinal).OrderBy(x => x, StringComparer.Ordinal).ToList();
    private static string? SingleName(PersonCase c, string field, ref bool conflict)
    {
        var vals = Values(c, field);
        if (vals.Select(Normal).Distinct(StringComparer.Ordinal).Count() > 1) conflict = true;
        return vals.FirstOrDefault();
    }
    private static DateOnly? SingleDate(PersonCase c, string field, ref bool conflict)
    {
        var dates = new List<DateOnly>();
        foreach (var value in Values(c, field))
        {
            try { if (Parse.Date(value, field) is { } d) dates.Add(d); }
            catch (IppException) { conflict = true; }
        }
        if (dates.Distinct().Count() > 1) conflict = true;
        return dates.Count == 0 ? null : dates[0];
    }
    private static List<string> SimilarIds(InputTable baseline, string surname, string firstName, DateOnly? birth)
    {
        if (string.IsNullOrWhiteSpace(surname) || string.IsNullOrWhiteSpace(firstName)) return new();
        // Exact normalized names are only a review hint, NOT a merge key. Even different birthdates stay visible.
        return baseline.Rows.Where(r => Normal(Parse.Text(r.GetValueOrDefault("Surname"))) == Normal(surname)
            && Normal(Parse.Text(r.GetValueOrDefault("FirstName"))) == Normal(firstName))
            .Select(r => Parse.Id(r.GetValueOrDefault("ClientID"))).Distinct(StringComparer.Ordinal).OrderBy(x => x, StringComparer.Ordinal).ToList();
    }
    public static PreparedPersons Prepare(InputTable baseline, SourceInfo baselineSource, IReadOnlyList<MonthFile> input,
        IReadOnlyList<NewPersonDecision>? decisions = null, CancellationToken cancel = default)
    {
        cancel.ThrowIfCancellationRequested();
        if (input.Count == 0) throw new IppException("TXT_SELECTION_EMPTY", "Mindestens eine TXT-Datei auswaehlen.");
        var months = input.OrderBy(m => m.Month).ToList();
        if (months.Select(m => m.Month.Year).Distinct().Count() != 1) throw new IppException("MULTI_YEAR", "Pro Lauf nur ein Kalenderjahr.");
        if (months.Select(m => m.Month).Distinct().Count() != months.Count) throw new IppException("DUPLICATE_MONTH", "Mehrere TXT-Dateien fuer denselben Monat.");
        if (baseline.Columns.Any(c => Regex.IsMatch(c, @"^(ATTC|TZG|Betrag)_\d+$"))) throw new IppException("BASELINE_NOT_PRISTINE", "Urspruenglichen Bestand statt Monatsergebnis auswaehlen.");
        var ids = new HashSet<string>(StringComparer.Ordinal);
        foreach (var row in baseline.Rows) if (!ids.Add(Parse.Id(row.GetValueOrDefault("ClientID"))))
            throw new IppException("DUPLICATE_BASELINE_ID", "Doppelte/normalisiert kollidierende ClientID im Bestand.");
        var report = new PersonReviewReport { BaselinePersons = baseline.Rows.Count, Inputs = new() { baselineSource } };
        report.Inputs.AddRange(months.Select(m => m.Source));
        report.ContextSha256 = Hash("MCR_IPP_PERSON_REVIEW_V1\n" + baselineSource.Sha256 + "\n" + baseline.Sheet + "\n" + string.Join("\n", months.Select(m => m.Month.ToString("yyyy-MM-dd", Parse.Inv) + ":" + m.Source.Sha256)));
        var cases = new SortedDictionary<string, PersonCase>(StringComparer.Ordinal);
        foreach (var month in months)
        {
            cancel.ThrowIfCancellationRequested();
            report.TxtHeaders[month.Month.ToString("yyyy-MM", Parse.Inv) + " | " + month.Name] = month.Rows.SelectMany(r => r.Keys).Distinct(StringComparer.Ordinal).ToList();
            for (int i = 0; i < month.Rows.Count; i++)
            {
                var row = month.Rows[i]; string rawId = Parse.Text(row.GetValueOrDefault("KDMA_IDENT")) ?? "[LEER]";
                string id; bool valid = true;
                try { id = Parse.Id(row.GetValueOrDefault("KDMA_IDENT")); }
                catch (IppException) { id = rawId; valid = false; }
                if (valid && ids.Contains(id)) continue;
                // Empty identifiers must not collapse unrelated records into a single alleged person.
                string key = valid ? "ID:" + id : rawId == "[LEER]" ? "EMPTY:" + month.Month + ":" + i : "INVALID:" + rawId;
                if (!cases.TryGetValue(key, out var c))
                {
                    c = new PersonCase { ClientId = id, CaseId = Hash(report.ContextSha256 + "\n" + key), Classification = valid ? "UNBEKANNT_NEUEINTRITT_NICHT_BELEGT" : "KENNUNG_UNGUELTIG" };
                    cases.Add(key, c);
                }
                var fields = row.Where(kv => IsField(kv.Key) && Parse.Text(kv.Value) is not null).ToDictionary(kv => kv.Key, kv => Parse.Text(kv.Value)!, StringComparer.Ordinal);
                c.Occurrences.Add(new(month.Name, month.Source.Sha256, month.Month.ToString("yyyy-MM", Parse.Inv), i + 1, rawId, fields));
            }
        }
        foreach (var c in cases.Values)
        {
            bool conflict = false;
            c.Surname = SingleName(c, "Surname", ref conflict); c.FirstName = SingleName(c, "FirstName", ref conflict);
            string? full = SingleName(c, "FullName", ref conflict);
            c.BirthDate = SingleDate(c, "BirthDate", ref conflict); c.DatAd2 = SingleDate(c, "DAT_AD2", ref conflict);
            c.DisplayName = string.Join(" ", new[] { c.FirstName, c.Surname }.Where(s => !string.IsNullOrWhiteSpace(s)));
            if (full is not null && (c.Surname is null || c.FirstName is null)) c.DisplayName = full;
            if (string.IsNullOrWhiteSpace(c.DisplayName)) c.DisplayName = "NAME_NICHT_GELIEFERT";
            c.PossibleBaselineIds = SimilarIds(baseline, c.Surname ?? "", c.FirstName ?? "", c.BirthDate);
            if (c.Classification != "KENNUNG_UNGUELTIG")
            {
                if (conflict) c.Classification = "IDENTITAETSDATEN_KONFLIKT";
                else if (c.PossibleBaselineIds.Count > 0) c.Classification = "MOEGLICHER_BESTANDSTREFFER_ANDERE_ID";
                else if (c.DatAd2 is { } d && d.Year == months[0].Month.Year && d <= months[^1].Month.AddMonths(1).AddDays(-1)) c.Classification = "NEUEINTRITT_KANDIDAT";
            }
            c.Note = "Fehlen im Bestand beweist keinen Neueintritt. Name/Datum sind TXT-Hinweise; keine automatische Zusammenfuehrung.";
            if (c.DisplayName == "NAME_NICHT_GELIEFERT") c.Note += " Keine passende Namensspalte befuellt/erkannt; ID und Fundstellen lokal pruefen.";
            report.Cases.Add(c);
        }
        decisions ??= Array.Empty<NewPersonDecision>();
        if (decisions.Any(d => d is null)) { report.Notices.Add("Leere Freigabeeintraege nicht angewendet."); decisions = decisions.Where(d => d is not null).ToList(); }
        int stale = decisions.Count(d => d.ContextSha256 != report.ContextSha256);
        if (stale > 0) report.Notices.Add($"{stale} Freigaben anderer Eingabestaende NICHT angewendet. Neue/veraenderte Eingaben benoetigen neue Bestaetigung.");
        var added = new List<Dictionary<string, object?>>();
        foreach (var c in report.Cases)
        {
            cancel.ThrowIfCancellationRequested();
            var applicable = decisions.Where(d => d.ContextSha256 == report.ContextSha256 && d.CaseId == c.CaseId).ToList();
            if (applicable.Count == 0) continue;
            try
            {
                if (applicable.Count != 1) throw new IppException("DECISION_CONFLICT", "Mehrere Freigaben fuer denselben Fall.");
                var d = applicable[0]; ValidateDecision(c, d, baseline, months);
                var newRow = new Dictionary<string, object?>(StringComparer.Ordinal)
                {
                    ["ClientID"] = d.ClientId, ["Surname"] = d.Surname.Trim(), ["FirstName"] = d.FirstName.Trim(),
                    ["BirthDate"] = d.BirthDate, ["DAT_AD2"] = d.DatAd2,
                    ["BaseSalary_1"] = null, ["PartTimeFactor_1"] = null, ["TerminationDate"] = null
                };
                // No invented starting salary or replacement for JoiningDate/DAT_Zusage.
                var selectedMonths = months.Select(m => m with { Rows = m.Rows.Where(r => SafeId(r) == c.ClientId).ToList() }).ToList();
                var proof = new ContributionEngine().Run(new InputTable("Neueintritt", newRow.Keys.ToList(), new() { newRow }, false), selectedMonths, new ContributionOptions(), cancel: cancel);
                var p = proof.Persons.Single();
                var relevant = p.Months.Values.Where(m => m.SalaryDate >= new DateOnly(d.DatAd2.Year, d.DatAd2.Month, 1)).ToList();
                if (relevant.Any(m => m.EffectiveTariff is not (98 or 99) && (m.Attc is null || m.Tzg is null || (m.Tzg > 0 && m.Amount is null))))
                    throw new IppException("NEW_PERSON_PAYROLL_INCOMPLETE", "Nach Eintritt fehlen ATTC/TZG/Beitrag. Keine Aufnahme mit unvollstaendigen Monatsdaten.");
                if (!ids.Add(c.ClientId)) throw new IppException("NEW_PERSON_DUPLICATE", "Kennung bereits enthalten.");
                added.Add(newRow); c.Resolution = "NEUAUFNAHME_BESTAETIGT";
                c.Surname = d.Surname.Trim(); c.FirstName = d.FirstName.Trim(); c.BirthDate = d.BirthDate; c.DatAd2 = d.DatAd2;
                c.DisplayName = c.FirstName + " " + c.Surname;
                c.Note = "Aufnahme nach ausdruecklicher Benutzerbestaetigung; Quelle unveraendert. Beleg: " + d.Evidence + "; geprueft von " + d.Reviewer;
            }
            catch (IppException ex) { c.Resolution = "FREIGABE_NICHT_ANWENDBAR"; c.Note = ex.Code + ": " + ex.Message; }
        }
        // Same-snapshot new admissions must not create name duplicates among themselves either.
        var nameDuplicates = added.GroupBy(r => Normal(Parse.Text(r.GetValueOrDefault("Surname"))) + "\n" + Normal(Parse.Text(r.GetValueOrDefault("FirstName"))))
            .Where(g => g.Count() > 1).SelectMany(g => g).ToList();
        foreach (var row in nameDuplicates)
        {
            var id = Parse.Id(row["ClientID"]); added.Remove(row); ids.Remove(id);
            var c = report.Cases.Single(c => c.ClientId == id); c.Resolution = "FREIGABE_NICHT_ANWENDBAR";
            c.Note = "MOEGLICHE_DUBLETTE_ZWISCHEN_NEUAUFNAHMEN: gleicher Name bei mehreren neuen IDs; manuell untersuchen.";
        }
        var cols = baseline.Columns.Concat(added.SelectMany(r => r.Keys)).Distinct(StringComparer.Ordinal).ToList();
        var effective = new InputTable(baseline.Sheet, cols, baseline.Rows.Concat(added).ToList(), baseline.Date1904);
        var filtered = months.Select(m => m with { Rows = m.Rows.Where(r => { var id = SafeId(r); return id is not null && ids.Contains(id); }).ToList() }).ToList();
        return new(effective, filtered, report);
    }
    private static string? SafeId(Dictionary<string, string?> row) { try { return Parse.Id(row.GetValueOrDefault("KDMA_IDENT")); } catch (IppException) { return null; } }
    public static void ValidateDecision(PersonCase c, NewPersonDecision d, InputTable baseline, IReadOnlyList<MonthFile> months)
    {
        if (!d.IdentityAndNewEntryVerified || string.IsNullOrWhiteSpace(d.Reviewer) || string.IsNullOrWhiteSpace(d.Evidence) || d.ConfirmedUtc == default)
            throw new IppException("NEW_PERSON_NOT_CONFIRMED", "Pruefer, Beleg und ausdrueckliche Identitaets-/Neueintrittsbestaetigung fehlen.");
        if (c.Classification is "KENNUNG_UNGUELTIG" or "IDENTITAETSDATEN_KONFLIKT" or "MOEGLICHER_BESTANDSTREFFER_ANDERE_ID")
            throw new IppException("NEW_PERSON_IDENTITY_REVIEW", "Identitaetskonflikt oder moegliche Dublette zuerst klaeren; keine automatische Neuanlage.");
        if (string.IsNullOrWhiteSpace(d.Surname) || string.IsNullOrWhiteSpace(d.FirstName))
            throw new IppException("NEW_PERSON_MASTER_MISSING", "Vor- und Nachname fehlen.");
        if (d.Surname.Length > 300 || d.FirstName.Length > 300 || d.Reviewer.Length > 200 || d.Evidence.Length > 2000)
            throw new IppException("NEW_PERSON_TEXT_LIMIT", "Stammdaten/Beleg zu lang; Beleg knapp referenzieren.");
        if (Parse.Id(d.ClientId) != c.ClientId) throw new IppException("NEW_PERSON_ID_MISMATCH", "Freigabe passt nicht zur Kennung.");
        if (string.IsNullOrWhiteSpace(d.Surname) || string.IsNullOrWhiteSpace(d.FirstName) || d.BirthDate == default || d.DatAd2 == default || d.BirthDate >= d.DatAd2)
            throw new IppException("NEW_PERSON_MASTER_MISSING", "Vorname, Nachname, Geburtsdatum und bestaetigtes DAT_AD2 benoetigt.");
        if (d.DatAd2.Year != months[0].Month.Year || !months.Any(m => m.Month == new DateOnly(d.DatAd2.Year, d.DatAd2.Month, 1)))
            throw new IppException("NEW_PERSON_PERIOD", "Eintrittsmonat muss im ausgewaehlten Kalenderjahr und in den TXT-Monaten liegen. Altfaelle separat klaeren.");
        if (c.Occurrences.Any(o => string.CompareOrdinal(o.Month, d.DatAd2.ToString("yyyy-MM", Parse.Inv)) < 0))
            throw new IppException("NEW_PERSON_EARLIER_OBSERVATION", "Kennung bereits vor bestaetigtem Eintrittsmonat in TXT vorhanden; zuerst klaeren.");
        if (c.Surname is not null && Normal(c.Surname) != Normal(d.Surname) || c.FirstName is not null && Normal(c.FirstName) != Normal(d.FirstName)
            || c.BirthDate is not null && c.BirthDate != d.BirthDate || c.DatAd2 is not null && c.DatAd2 != d.DatAd2)
            throw new IppException("NEW_PERSON_MASTER_CONFLICT", "Bestaetigung widerspricht den erkannten TXT-Stammdaten.");
        if (SimilarIds(baseline, d.Surname, d.FirstName, d.BirthDate).Count > 0)
            throw new IppException("NEW_PERSON_NAME_MATCH", "Gleicher Vor-/Nachname bereits unter anderer Bestands-ID; keine automatische Doppelanlage.");
    }
    public static void Write(string folder, PersonReviewReport report)
    {
        JsonFiles.Write(Path.Combine(folder, "Personen_Pruefung.json"), report);
        var rows = report.Cases.Select(c => new List<object?> { c.ClientId, c.DisplayName, c.Classification, c.Resolution,
            c.BirthDate, c.DatAd2, c.Occurrences.Count, string.Join(", ", c.PossibleBaselineIds), c.Note }).ToList();
        var findings = report.Cases.SelectMany(c => c.Occurrences.Select(o => new List<object?> { c.ClientId, o.OriginalId, o.Month, o.File, o.DataRecord,
            string.Join(" | ", o.IdentityFields.Select(kv => kv.Key + "=" + kv.Value)), o.Sha256 })).ToList();
        foreach (var row in rows.Concat(findings))
            for (int i = 0; i < row.Count; i++) if (row[i] is string text && text.Length > 30000) row[i] = text[..30000] + " [GEKUERZT; siehe JSON]";
        SpreadsheetWriter.Write(Path.Combine(folder, "Prueffaelle.xlsx"),
            new OutputSheet("Personen", new() { "ClientID", "Name aus TXT / Freigabe", "Einordnung", "Bearbeitungsstatus", "Geburtsdatum", "DAT_AD2", "Fundstellen", "Moegliche Bestands-IDs", "Pruefhinweis" }, rows) { ReviewLayout = true },
            new OutputSheet("Fundstellen", new() { "ClientID", "Original-Kennung", "Monat", "TXT-Datei", "Datenrecord (nicht Textzeile)", "Gelieferte Identitaetsfelder", "TXT SHA256" }, findings) { ReviewLayout = true });
    }
    public static OutputSheet BaselineCopy(InputTable table)
    {
        var dates = new HashSet<string>(new[] { "BirthDate", "JoiningDate", "OriginalDateOfHire", "DAT_Zusage", "DAT_AD2", "TerminationDate" }, StringComparer.Ordinal);
        return new OutputSheet("Bestand", table.Columns, table.Rows.Select(r => table.Columns.Select(c => c == "ClientID" ? (object?)Parse.Text(r.GetValueOrDefault(c)) : dates.Contains(c) ? Parse.Date(r.GetValueOrDefault(c), c, table.Date1904) : r.GetValueOrDefault(c)).ToList()).ToList());
    }
}
