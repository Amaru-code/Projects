using System.Numerics;

namespace Mcr.Ipp.Core;

public static class PythonRound
{
    /// <summary>Exact ties-to-even decimal-place rounding of the represented binary64 value.
    /// Unlike Math.Round(x, 2), this does not first round x*100 as a double.
    /// Kept explicit to preserve Python's round(2.675, 2) == 2.67.</summary>
    public static double Round(double value, int digits)
    {
        if (!double.IsFinite(value)) return value;
        if (digits is < 0 or > 8) throw new ArgumentOutOfRangeException(nameof(digits));
        if (value == 0) return value;
        long raw = BitConverter.DoubleToInt64Bits(value);
        bool negative = raw < 0;
        ulong bits = (ulong)raw;
        int expBits = (int)((bits >> 52) & 0x7ff);
        ulong mantissa = bits & 0xfffffffffffffUL;
        int exponent;
        if (expBits == 0) exponent = -1074;
        else { mantissa |= 1UL << 52; exponent = expBits - 1023 - 52; }
        BigInteger numerator = new BigInteger(mantissa) * BigInteger.Pow(10, digits);
        BigInteger denominator = BigInteger.One;
        if (exponent >= 0) numerator <<= exponent; else denominator <<= -exponent;
        var quotient = BigInteger.DivRem(numerator, denominator, out var remainder);
        int compare = (remainder * 2).CompareTo(denominator);
        if (compare > 0 || (compare == 0 && !quotient.IsEven)) quotient++;
        string text = quotient.ToString(Parse.Inv).PadLeft(digits + 1, '0');
        if (digits > 0) text = text.Insert(text.Length - digits, ".");
        double result = double.Parse(text, Parse.Inv);
        return negative ? -result : result;
    }
}
public static class ContributionFormula
{
    public static readonly IReadOnlyList<RulePeriod> Periods = new List<RulePeriod>
    {
        new(new(2012,4,1),new(2013,3,31),5475,8216.67),
        new(new(2013,4,1),new(2014,3,31),5583.33,8383.33),
        new(new(2014,4,1),new(2015,3,31),5725,8591.67),
        new(new(2015,4,1),new(2016,3,31),5900,8858.33),
        new(new(2016,4,1),new(2017,3,31),6050,9075),
        new(new(2017,4,1),new(2018,3,31),6233.33,9350),
        new(new(2018,4,1),new(2019,3,31),6425,9633.33),
        new(new(2019,4,1),new(2020,3,31),6633.33,9941.67),
        new(new(2020,4,1),new(2021,3,31),6816.67,10216.67),
        new(new(2021,4,1),new(2022,3,31),7008.33,10508.33),
        new(new(2022,4,1),new(2023,3,31),7225,10825),
        new(new(2023,4,1),new(2024,3,31),7225,10825),
        new(new(2024,4,1),new(2025,6,30),7466.67,11183.33),
        new(new(2025,7,1),new(2026,3,31),7841.67,11741.67),
        // T01: User's decimal-comma tuple repaired; no economic recalibration.
        // T02: Open-ended interval avoids pandas timestamp resolution restrictions.
        new(new(2026,4,1),null,8116.67,12158.33)
    }.AsReadOnly();
    public static double? Calculate(double? attc, double? tzg, DateOnly salaryDate)
    {
        if (attc is null || tzg is null || tzg <= 0) return null;
        if (!double.IsFinite(attc.Value) || !double.IsFinite(tzg.Value)) throw new IppException("NONFINITE", "Nichtendlicher Eingabewert.");
        double factor = tzg.Value;
        if (factor > 1) factor /= 100.0;
        if (factor <= 0) return null;
        var p = Periods.SingleOrDefault(p => p.From <= salaryDate && (p.To is null || salaryDate <= p.To));
        if (p is null) return null;
        double salary = PythonRound.Round(attc.Value / factor, 2);
        double stage2 = PythonRound.Round((p.Eckwert2 - p.Eckwert1) / p.Eckwert1 * 100 * 42 / 12 + 62.5, 2);
        double amount;
        if (salary > p.Eckwert2) amount = stage2 + ((salary - p.Eckwert2) / p.Eckwert2) * 100 * 80 / 12;
        else if (salary > p.Eckwert1) amount = 62.5 + ((salary - p.Eckwert1) / p.Eckwert1) * 100 * 42 / 12;
        else amount = (salary / p.Eckwert1) * 100 * 7.5 / 12;
        return PythonRound.Round(amount * factor, 2);
    }
}
