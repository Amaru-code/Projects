namespace Mcr.Ipp.Core;

/// <summary>Missing information is not the same as known exclusion or contradictory information.</summary>
public static class ContributionAmountPolicy
{
    public const string Hold = "HOLD_AMOUNT_WHILE_TARIFF_REVIEW_OPEN_V1";
    public const string Provisional = "PYTHON_PROVISIONAL_MISSING_ONLY_CONFLICTS_HELD_V1";
    public const string ProvisionalStatus = "CALCULATED_PROVISIONAL_MISSING_TARIFF";
    public static bool IsPureMissing(string? issue) => issue is
        "NO_TXT_RECORD_NO_PRIOR_TARIFF" or "TARIFF_EMPTY_NO_PRIOR_TARIFF" or "TARIFF_COLUMN_MISSING";
    public static bool CanCalculate(ContributionOptions options, MonthlyResult row) =>
        options.ReviewTariffIssues && options.CalculateMissingTariffProvisionally &&
        row.TariffReviewRequired && row.EffectiveTariff is null && IsPureMissing(row.TariffIssue);
    public static bool IsValidProvisional(ContributionResult result, MonthlyResult row) =>
        result.AmountPolicy == Provisional && row.AmountIsProvisional && row.TariffReviewRequired &&
        row.EffectiveTariff is null && IsPureMissing(row.TariffIssue) &&
        row.Attc is >= 0 && row.Tzg is > 0 &&
        row.Amount == ContributionFormula.Calculate(row.Attc, row.Tzg, row.SalaryDate);
}
