using System.Globalization;
using System.Text;

namespace Mcr.Ipp.Core;

public sealed record DraftLine(string Text, bool Emphasis = false, bool Alert = false);
public sealed record DraftPdfBytes(byte[] Bytes, int Pages);

/// <summary>
/// Small, intentionally restricted PDF 1.4 writer for internal contribution drafts.
/// Standard fonts only, no JavaScript/actions/attachments, no Excel, no external packages.
/// Variable text uses fixed-width Courier and strict Windows-1252. Unsupported glyphs
/// stop that person's document, never silently replace an identity character.
/// Not PDF/A, not PDF/UA, not a statutory pension statement.
/// </summary>
public static class DraftPdf
{
    public const int Columns = 91;
    public const int LinesPerPage = 44;
    private static readonly Encoding WinAnsi = CreateEncoding();
    private static Encoding CreateEncoding()
    {
        Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
        return Encoding.GetEncoding(1252, EncoderFallback.ExceptionFallback, DecoderFallback.ExceptionFallback);
    }
    public static List<DraftLine> Wrap(string text, bool emphasis = false, bool alert = false)
    {
        if (text.Length > 20000) throw new IppException("PDF_TEXT_TOO_LONG", "PDF-Text zu lang; kein Abschneiden von Personenangaben.");
        var answer = new List<DraftLine>();
        foreach (string input in text.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n'))
        {
            string rest = input.Replace('\t', ' ');
            if (rest.Length == 0) { answer.Add(new("", emphasis, alert)); continue; }
            while (rest.Length > Columns)
            {
                int split = rest.LastIndexOf(' ', Columns - 1, Columns);
                if (split < Columns / 3) split = Columns;
                answer.Add(new(rest[..split], emphasis, alert));
                rest = rest[split..].TrimStart(' ');
            }
            if (rest.Length > 0) answer.Add(new(rest, emphasis, alert));
        }
        return answer;
    }
    private static string Hex(string value)
    {
        // All user-controlled text is a PDF hex string, not executable PDF syntax.
        try
        {
            if (value.Any(c => char.IsControl(c))) throw new IppException("PDF_TEXT_UNSUPPORTED", "Steuerzeichen in PDF-Text; Angaben lokal pruefen.");
            var bytes = WinAnsi.GetBytes(value);
            if (bytes.Any(b => b is 0x7F or 0x81 or 0x8D or 0x8F or 0x90 or 0x9D or 0xAD))
                throw new IppException("PDF_TEXT_UNSUPPORTED", "Nicht unterstuetztes Zeichen im PDF-Text. JSON/Excel bleiben unveraendert.");
            return "<" + Convert.ToHexString(bytes) + ">";
        }
        catch (EncoderFallbackException)
        {
            throw new IppException("PDF_TEXT_UNSUPPORTED", "Name/Text liegt ausserhalb Windows-1252. Kein PDF mit ersetzten Namenszeichen; JSON/Excel bleiben erhalten.");
        }
    }
    private static string Num(double x) => x.ToString("0.###", CultureInfo.InvariantCulture);
    private static void Text(StringBuilder content, string text, double x, double y, string font, double size, string color)
    {
        content.Append(color).Append(" rg BT /").Append(font).Append(' ').Append(Num(size))
            .Append(" Tf 1 0 0 1 ").Append(Num(x)).Append(' ').Append(Num(y))
            .Append(" Tm ").Append(Hex(text)).Append(" Tj ET\n");
    }
    public static DraftPdfBytes Render(string clientId, IReadOnlyList<DraftLine> lines)
    {
        if (Parse.Id(clientId) != clientId) throw new IppException("PDF_ID", "PDF erwartet normalisierte ClientID.");
        if (lines.Count == 0 || lines.Count > 440) throw new IppException("PDF_LAYOUT_LIMIT", "PDF-Inhalt muss 1..440 Zeilen umfassen.");
        if (lines.Any(x => x.Text.Length > Columns)) throw new IppException("PDF_LAYOUT_WIDTH", "PDF-Zeile zu breit; kein stilles Abschneiden.");
        // Validate all text before emitting a single byte to disk.
        foreach (var line in lines) _ = Hex(line.Text);
        int pages = (lines.Count + LinesPerPage - 1) / LinesPerPage;
        var objects = new List<string>
        {
            "<< /Type /Catalog /Pages 2 0 R >>",
            "", // Page tree populated after page allocation.
            "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>",
            "<< /Type /Font /Subtype /Type1 /BaseFont /Courier /Encoding /WinAnsiEncoding >>",
            "<< /Type /Font /Subtype /Type1 /BaseFont /Courier-Bold /Encoding /WinAnsiEncoding >>"
        };
        var pageIds = new List<int>();
        for (int p = 0; p < pages; p++)
        {
            int pageId = objects.Count + 1, streamId = pageId + 1;
            pageIds.Add(pageId);
            var content = new StringBuilder();
            content.Append("0.09 0.20 0.30 rg 0 734 595 108 re f\n");
            Text(content, "MCR / IPP", 36, 808, "F1", 13, "1 1 1");
            Text(content, "Beitragsuebersicht", 36, 780, "F1", 23, "1 1 1");
            Text(content, "ENTWURF - INTERN - NICHT VERSENDEN", 36, 754, "F3", 11, "1 0.85 0.52");
            Text(content, "ClientID " + clientId, 36, 714, "F2", 10, "0.09 0.20 0.30");
            double y = 690;
            foreach (var line in lines.Skip(p * LinesPerPage).Take(LinesPerPage))
            {
                if (line.Alert) content.Append("1 0.93 0.78 rg 33 ").Append(Num(y - 3)).Append(" 529 13.4 re f\n");
                Text(content, line.Text, 36, y, line.Emphasis ? "F3" : "F2", 9.5, "0.09 0.14 0.20");
                y -= 13.4;
            }
            content.Append("0.7 0.75 0.8 RG 0.5 w 36 75 m 559 75 l S\n");
            Text(content, "Kein Leistungsnachweis / keine Unverfallbarkeitsbescheinigung.", 36, 59, "F2", 8, "0.3 0.3 0.3");
            Text(content, "Keine Versandfreigabe. Offene Werte sind nicht 0 EUR.", 36, 45, "F2", 8, "0.3 0.3 0.3");
            Text(content, $"Seite {p + 1}/{pages}", 492, 30, "F2", 8, "0.3 0.3 0.3");
            string stream = content.ToString();
            objects.Add($"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R /F2 4 0 R /F3 5 0 R >> >> /Contents {streamId} 0 R >>");
            objects.Add($"<< /Length {Encoding.ASCII.GetByteCount(stream)} >>\nstream\n{stream}endstream");
        }
        objects[1] = $"<< /Type /Pages /Count {pages} /Kids [ {string.Join(" ", pageIds.Select(i => i + " 0 R"))} ] >>";
        using var ms = new MemoryStream();
        void Put(string s) { var b = Encoding.ASCII.GetBytes(s); ms.Write(b, 0, b.Length); }
        Put("%PDF-1.4\n%MCR_IPP_DRAFT_ONLY\n");
        var offsets = new List<long> { 0 };
        for (int i = 0; i < objects.Count; i++)
        {
            offsets.Add(ms.Position); Put($"{i + 1} 0 obj\n{objects[i]}\nendobj\n");
        }
        long xref = ms.Position;
        Put($"xref\n0 {objects.Count + 1}\n0000000000 65535 f \n");
        foreach (long offset in offsets.Skip(1)) Put(offset.ToString("D10", Parse.Inv) + " 00000 n \n");
        Put($"trailer\n<< /Size {objects.Count + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n");
        return new(ms.ToArray(), pages);
    }
}
