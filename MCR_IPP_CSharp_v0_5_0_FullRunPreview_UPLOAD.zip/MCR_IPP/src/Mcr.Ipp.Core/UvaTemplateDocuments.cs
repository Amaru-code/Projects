using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace Mcr.Ipp.Core;

public sealed class UvaTemplateDefinition
{
    public string Schema { get; set; } = "";
    public string TemplateId { get; set; } = "";
    public string Status { get; set; } = "";
    public UvaTemplateSource Source { get; set; } = new();
    public UvaTemplatePage Page { get; set; } = new();
    public List<UvaTemplatePageDef> Pages { get; set; } = new();
    public List<UvaTemplateField> Fields { get; set; } = new();
    public Dictionary<string, string> Texts { get; set; } = new(StringComparer.Ordinal);
    public UvaTemplateSafety Safety { get; set; } = new();
}
public sealed class UvaTemplateSource
{
    public string Name { get; set; } = "";
    public string Sha256 { get; set; } = "";
    public string Sheet { get; set; } = "";
    public string SourceDimension { get; set; } = "";
    public string PrintArea { get; set; } = "";
    public List<int> PageBreakRows { get; set; } = new();
    public string ImageSha256 { get; set; } = "";
    public int ImageBytes { get; set; }
    public bool ImageTransportReceived { get; set; }
    public bool ImageBinaryEmbedded { get; set; }
    public string ImageRenderFallback { get; set; } = "";
}
public sealed class UvaTemplatePage
{
    public string Size { get; set; } = "A4";
    public string Orientation { get; set; } = "portrait";
    public string Font { get; set; } = "Arial";
    public string ThemeDarkRgb { get; set; } = "003865";
    public string AccentRgb { get; set; } = "009DE0";
}
public sealed class UvaTemplatePageDef { public int Number { get; set; } public string Name { get; set; } = ""; public string SourceRows { get; set; } = ""; }
public sealed class UvaTemplateField
{
    public string Key { get; set; } = "";
    public string SourceCell { get; set; } = "";
    public bool ProductionRequired { get; set; }
    public string Binding { get; set; } = "";
    public string Status { get; set; } = "";
}
public sealed class UvaTemplateSafety { public bool ProductionAuthorized { get; set; } public string Watermark { get; set; } = ""; public string Reason { get; set; } = ""; }

public static class UvaTemplateLoader
{
    public static string FindDefault(string? explicitPath = null)
    {
        if (!string.IsNullOrWhiteSpace(explicitPath)) return Path.GetFullPath(explicitPath);
        string fromBin = Path.Combine(AppContext.BaseDirectory, "templates", "UVA_OHNE_ZINS_V1.json");
        if (File.Exists(fromBin)) return fromBin;
        var d = new DirectoryInfo(AppContext.BaseDirectory);
        while (d is not null)
        {
            string p = Path.Combine(d.FullName, "config", "templates", "UVA_OHNE_ZINS_V1.json");
            if (File.Exists(p)) return p;
            d = d.Parent;
        }
        throw new IppException("UVA_TEMPLATE_MISSING", "Integrierte UVA-Vorlage nicht gefunden: config/templates/UVA_OHNE_ZINS_V1.json");
    }
    public static UvaTemplateDefinition Load(string? explicitPath = null)
    {
        string path = FindDefault(explicitPath);
        var def = JsonFiles.Read<UvaTemplateDefinition>(path);
        if (def.Schema != "MCR_IPP_UVA_TEMPLATE_V1" || def.TemplateId != "UVA_OHNE_ZINS_DE_V1")
            throw new IppException("UVA_TEMPLATE_SCHEMA", "UVA-Vorlagen-JSON hat nicht den erwarteten Vertrag.");
        if (!System.Text.RegularExpressions.Regex.IsMatch(def.Source.Sha256, "^[0-9A-Fa-f]{64}$") || def.Source.Sheet != "Aktiv -> UVA ohne Zins")
            throw new IppException("UVA_TEMPLATE_SOURCE", "UVA-Vorlagen-JSON hat eine unbekannte Quellidentitaet.");
        if (def.Pages.Count != 3 || !def.Source.PageBreakRows.SequenceEqual(new[] { 56, 102 }))
            throw new IppException("UVA_TEMPLATE_LAYOUT", "UVA-Vorlage erwartet genau drei Seiten mit den dokumentierten Seitenumbruechen.");
        if (def.Safety.ProductionAuthorized)
            throw new IppException("UVA_TEMPLATE_AUTHORITY", "Preview-Vorlage darf keine Produktionsfreigabe behaupten.");
        return def;
    }
}

public sealed class UvaFieldValue
{
    public string Key { get; set; } = "";
    public string Display { get; set; } = "";
    public string Status { get; set; } = "";
    public string Source { get; set; } = "";
    public bool ProductionRequired { get; set; }
}
public sealed class UvaTemplateDocumentItem
{
    public string ClientId { get; set; } = "";
    public string Name { get; set; } = "";
    public string Status { get; set; } = "";
    public string? File { get; set; }
    public string? Sha256 { get; set; }
    public long? Bytes { get; set; }
    public int? Pages { get; set; }
    public int MissingProductionFields { get; set; }
    public string Note { get; set; } = "";
    public List<UvaFieldValue> Fields { get; set; } = new();
}
public sealed class UvaTemplateDocumentReport
{
    public string Schema { get; set; } = "MCR_IPP_UVA_FULL_RUN_PREVIEW_V1";
    public string TemplateId { get; set; } = "";
    public string TemplateSourceSha256 { get; set; } = "";
    public string Status { get; set; } = "NOT_RUN";
    public bool ProductionAuthorized { get; set; }
    public int Created => Items.Count(x => x.Status == "PREVIEW_CREATED");
    public int Failed => Items.Count(x => x.Status == "PREVIEW_FAILED");
    public int NotApplicable => Items.Count(x => x.Status.StartsWith("NOT_APPLICABLE", StringComparison.Ordinal));
    public int WithMappingGaps => Items.Count(x => x.MissingProductionFields > 0 && x.Status == "PREVIEW_CREATED");
    public List<UvaTemplateDocumentItem> Items { get; set; } = new();
}

public static class UvaPersonFields
{
    private static readonly CultureInfo De = CultureInfo.GetCultureInfo("de-DE");
    private static string? T(PersonResult p, string key) => Parse.Text(p.Master.GetValueOrDefault(key));
    private static DateOnly? D(PersonResult p, string key)
    {
        try { return Parse.Date(p.Master.GetValueOrDefault(key), key); }
        catch { return null; }
    }
    private static string DateText(DateOnly? d) => d?.ToString("dd.MM.yyyy", De) ?? "OFFEN";
    private static string Money(double? v) => v is null ? "OFFEN" : v.Value.ToString("N2", De) + " EUR";
    private static string GenderSalutation(PersonResult p)
    {
        string? g = T(p, "Gender") ?? T(p, "GESCHLECHT");
        if (g is null) return "OFFEN";
        g = g.Trim().ToUpperInvariant();
        return g is "M" or "MALE" or "1" ? "Herrn" : g is "F" or "W" or "FEMALE" or "2" ? "Frau" : "OFFEN";
    }
    public static string DisplayName(PersonResult p)
    {
        string first = T(p, "FirstName") ?? T(p, "VORNAME") ?? "";
        string last = T(p, "Surname") ?? T(p, "NACHNAME") ?? "";
        string n = (first + " " + last).Trim(); return n.Length == 0 ? "NAME OFFEN" : n;
    }
    public static string Street(PersonResult p)
    {
        string street = T(p, "Address") ?? T(p, "Street") ?? T(p, "STRASSE") ?? "";
        string house = T(p, "HouseNumber") ?? T(p, "HAUSNUMMER") ?? "";
        string value = (street + (street.Length > 0 && house.Length > 0 ? " " : "") + house).Trim();
        return value.Length > 0 ? value : "OFFEN";
    }
    public static string City(PersonResult p)
    {
        string zip = T(p, "PostalCode") ?? T(p, "PLZ") ?? T(p, "PLZ_STRASSE") ?? "";
        string city = T(p, "City") ?? T(p, "ORT") ?? "";
        string value = (zip + (zip.Length > 0 && city.Length > 0 ? " " : "") + city).Trim();
        return value.Length > 0 ? value : "OFFEN";
    }
    public static DateOnly? Birth(PersonResult p) => D(p, "BirthDate") ?? D(p, "DAT_GEBURT");
    public static DateOnly? Joining(PersonResult p) => D(p, "JoiningDate") ?? D(p, "DAT_EINTRITT_FIRMA");
    public static string PersonalId(PersonResult p, out bool qualified)
    {
        string? wwid = T(p, "WWID"); qualified = wwid is not null;
        return wwid ?? p.ClientId;
    }
    public static List<UvaFieldValue> Bind(UvaTemplateDefinition def, ContributionResult result, PersonResult p)
    {
        DateOnly? exit = p.TerminationDate ?? D(p, "TerminationDate");
        bool idQualified; string pid = PersonalId(p, out idQualified);
        double? candidateProvision = null;
        bool fullYear = result.Months.SequenceEqual(Enumerable.Range(1, 12));
        bool completeAmounts = fullYear && p.Months.Values.All(m => m.Amount is not null && !m.AmountIsProvisional && !m.TariffReviewRequired);
        if (completeAmounts) candidateProvision = p.Months.Values.Sum(m => m.Amount!.Value);
        var map = new Dictionary<string, (string Display, string Status, string Source)>(StringComparer.Ordinal)
        {
            ["Anrede"] = (GenderSalutation(p), GenderSalutation(p)=="OFFEN" ? "MISSING" : "BOUND", "Gender"),
            ["Name"] = (DisplayName(p), DisplayName(p)=="NAME OFFEN" ? "MISSING" : "BOUND", "FirstName+Surname"),
            ["Adresse"] = (Street(p), Street(p)=="OFFEN" ? "MISSING" : "BOUND", "Bestand/TXT Adresse"),
            ["PLZ"] = (City(p), City(p)=="OFFEN" ? "MISSING" : "BOUND", "Bestand/TXT PLZ+Ort"),
            ["Stichtag"] = (DateText(exit), exit is null ? "MISSING" : "BOUND", "TerminationDate"),
            ["WWID"] = (pid, idQualified ? "BOUND" : "PREVIEW_CLIENTID_NOT_WWID", idQualified ? "WWID" : "ClientID preview"),
            ["Geburtsdatum"] = (DateText(Birth(p)), Birth(p) is null ? "MISSING" : "BOUND", "BirthDate"),
            ["Eintritt"] = (DateText(Joining(p)), Joining(p) is null ? "MISSING" : "BOUND", "JoiningDate"),
            ["Austritt"] = (DateText(exit), exit is null ? "MISSING" : "BOUND", "TerminationDate"),
            ["BeitragsfaehigeBezuege"] = ("OFFEN", "MAPPING_REQUIRED", "kein bestaetigter Vertrag"),
            ["Garantierente"] = ("OFFEN", "MAPPING_REQUIRED", "Planabhaengige Quelle nicht gebunden"),
            ["Garantiezins"] = ("OFFEN", "MAPPING_REQUIRED", "Eckwerte/Zins-Quelle nicht gebunden"),
            ["Saldovortrag"] = ("OFFEN", "MAPPING_REQUIRED", "Vorsaldo-Quelle nicht gebunden"),
            ["Beitragsbereitstellung"] = candidateProvision is null
                ? ("OFFEN", "MAPPING_REQUIRED", fullYear ? "unvollstaendige/vorlaeufige Monatsbeitraege" : $"nur {result.Months.Count}/12 Monate ausgewaehlt")
                : (Money(PythonRound.Round(candidateProvision.Value, 0)), "CANDIDATE_NOT_APPROVED", "12/12 MCR-Monatsbeitraege, auf volle EUR gerundet"),
            ["KuerzungsbetragIB"] = ("OFFEN", "MAPPING_REQUIRED", "Initialbaustein-Regel nicht gebunden"),
            ["Schlussueberschuss"] = ("OFFEN", "MAPPING_REQUIRED", "Schattenkonto/Vorsaldo nicht gebunden"),
            ["Zins"] = ("OFFEN", "MAPPING_REQUIRED", "Zins-/Stichtagsregel nicht gebunden"),
            ["Initialbaustein"] = ("OFFEN", "MAPPING_REQUIRED", "Planabhaengige Quelle nicht gebunden"),
            ["Todesfallkapital"] = ("OFFEN", "MAPPING_REQUIRED", "Leistungsberechnung nicht gebunden")
        };
        return def.Fields.Select(f =>
        {
            var v = map.TryGetValue(f.Key, out var x) ? x : ("OFFEN", "MAPPING_REQUIRED", "kein Binder");
            return new UvaFieldValue { Key = f.Key, Display = v.Item1, Status = v.Item2, Source = v.Item3, ProductionRequired = f.ProductionRequired };
        }).ToList();
    }
}

public static class UvaTemplateDocuments
{
    public const string FolderName = "UVA_PDF_Entwuerfe";
    public static UvaTemplateDocumentReport Write(string runDirectory, ContributionResult result, bool createPdfs, string? templateJsonPath = null,
        Action<string>? progress = null, CancellationToken cancel = default)
    {
        cancel.ThrowIfCancellationRequested();
        var def = UvaTemplateLoader.Load(templateJsonPath);
        var report = new UvaTemplateDocumentReport { TemplateId = def.TemplateId, TemplateSourceSha256 = def.Source.Sha256, ProductionAuthorized = false };
        string folder = Path.Combine(runDirectory, FolderName);
        if (createPdfs)
        {
            if (Directory.Exists(folder) || File.Exists(folder)) throw new IppException("UVA_OUTPUT_EXISTS", "UVA-PDF-Ordner existiert bereits; keine Ueberschreibung.");
            Directory.CreateDirectory(folder);
        }
        int processed = 0;
        foreach (var p in result.Persons)
        {
            cancel.ThrowIfCancellationRequested();
            string name = UvaPersonFields.DisplayName(p);
            DateOnly? exit = p.TerminationDate;
            var item = new UvaTemplateDocumentItem { ClientId = p.ClientId, Name = name };
            if (exit is null)
            {
                item.Status = "NOT_APPLICABLE_NO_TERMINATION_DATE";
                item.Note = "Vorlage 'Aktiv -> UVA ohne Zins' gilt nur fuer Austrittsfaelle; kein TerminationDate vorhanden.";
                report.Items.Add(item);
                continue;
            }
            item.Fields = UvaPersonFields.Bind(def, result, p);
            item.MissingProductionFields = item.Fields.Count(f => f.ProductionRequired && f.Status != "BOUND");
            item.Note = item.MissingProductionFields > 0
                ? $"Full-Run-Preview mit {item.MissingProductionFields} offenen produktionsrelevanten Feldern. NICHT versenden."
                : "Technisch vollstaendig gebunden, dennoch keine Produktionsfreigabe.";
            if (!createPdfs)
            {
                item.Status = "PREVIEW_NOT_REQUESTED"; report.Items.Add(item); continue;
            }
            string filename = $"PREVIEW_UVA_ohne_Zins_{p.ClientId}_{exit:yyyyMMdd}.pdf";
            try
            {
                var pdf = UvaTemplatePdf.Render(def, result, p, item.Fields);
                using var fs = new FileStream(Path.Combine(folder, filename), FileMode.CreateNew, FileAccess.Write, FileShare.None);
                fs.Write(pdf.Bytes); fs.Flush(true);
                item.Status = "PREVIEW_CREATED"; item.File = FolderName + "/" + filename; item.Pages = pdf.Pages;
                item.Bytes = pdf.Bytes.LongLength; item.Sha256 = Convert.ToHexString(SHA256.HashData(pdf.Bytes));
            }
            catch (IppException ex) when (ex.Code.StartsWith("UVA_PDF_", StringComparison.Ordinal) || ex.Code == "PDF_TEXT_UNSUPPORTED")
            { item.Status = "PREVIEW_FAILED"; item.Note = ex.Code + ": " + ex.Message; }
            report.Items.Add(item);
            if (++processed % 50 == 0) progress?.Invoke($"UVA-Vorlagen-PDFs: {processed} Austrittsfaelle bearbeitet; {report.Created} erstellt; {report.Failed} Fehler.");
        }
        report.Status = !createPdfs ? "UVA_PREVIEW_NOT_REQUESTED"
            : report.Failed > 0 ? "UVA_PREVIEW_PARTIAL_WITH_ERRORS"
            : report.Created == 0 ? "UVA_PREVIEW_NO_APPLICABLE_PERSONS"
            : report.WithMappingGaps > 0 ? "UVA_PREVIEW_CREATED_WITH_MAPPING_GAPS"
            : "UVA_PREVIEW_CREATED_NOT_PRODUCTION_AUTHORIZED";
        JsonFiles.Write(Path.Combine(runDirectory, "UVA_Dokumentenplan.json"), report);
        var rows = report.Items.Select(i => new List<object?> { i.ClientId, i.Name, i.Status, i.File, i.MissingProductionFields, i.Pages, i.Note, i.Sha256 }).ToList();
        SpreadsheetWriter.Write(Path.Combine(runDirectory, "UVA_Dokumentenplan.xlsx"), new OutputSheet("UVA", new()
            { "ClientID", "Name", "Status", "PDF-Datei relativ", "Offene produktionsrelevante Felder", "Seiten", "Hinweis", "PDF SHA256" }, rows)
            { ReviewLayout = true, ColumnWidths = new() { 16, 28, 36, 42, 25, 10, 55, 40 } });
        var gaps = report.Items.Where(i => i.Fields.Count > 0).SelectMany(i => i.Fields.Where(f => f.Status != "BOUND")
            .Select(f => new List<object?> { i.ClientId, i.Name, f.Key, f.Display, f.Status, f.Source, f.ProductionRequired ? "JA" : "NEIN" })).ToList();
        SpreadsheetWriter.Write(Path.Combine(runDirectory, "UVA_Feldluecken.xlsx"), new OutputSheet("Felder", new()
            { "ClientID", "Name", "Vorlagenfeld", "Anzeige", "Status", "Quelle/Grund", "Produktionsrelevant" }, gaps)
            { ReviewLayout = true, ColumnWidths = new() { 16, 28, 28, 24, 30, 55, 20 } });
        JsonFiles.Write(Path.Combine(runDirectory, "UVA_Feldluecken.json"), report.Items.Select(i => new { i.ClientId, i.Name, fields = i.Fields.Where(f => f.Status != "BOUND") }).ToList());
        return report;
    }
}

internal sealed record UvaPdfResult(byte[] Bytes, int Pages);
internal static class UvaTemplatePdf
{
    private static readonly Encoding WinAnsi = CreateEncoding();
    private static readonly CultureInfo De = CultureInfo.GetCultureInfo("de-DE");
    private static Encoding CreateEncoding() { Encoding.RegisterProvider(CodePagesEncodingProvider.Instance); return Encoding.GetEncoding(1252, EncoderFallback.ExceptionFallback, DecoderFallback.ExceptionFallback); }
    private static string Hex(string value)
    {
        try
        {
            if (value.Any(c => char.IsControl(c) && c is not '\n' and not '\r' and not '\t')) throw new IppException("UVA_PDF_TEXT", "Steuerzeichen im Vorlagentext.");
            return "<" + Convert.ToHexString(WinAnsi.GetBytes(value.Replace('\t',' '))) + ">";
        }
        catch (EncoderFallbackException) { throw new IppException("PDF_TEXT_UNSUPPORTED", "Vorlagen-/Personentext liegt ausserhalb Windows-1252."); }
    }
    private static string N(double x) => x.ToString("0.###", CultureInfo.InvariantCulture);
    private static void Text(StringBuilder c, string text, double x, double y, string font="F1", double size=9.2, string rgb="0 0 0")
        => c.Append(rgb).Append(" rg BT /").Append(font).Append(' ').Append(N(size)).Append(" Tf 1 0 0 1 ").Append(N(x)).Append(' ').Append(N(y)).Append(" Tm ").Append(Hex(text)).Append(" Tj ET\n");
    private static List<string> Wrap(string text, int max)
    {
        var result = new List<string>();
        foreach (var input in text.Replace("\r\n","\n").Replace('\r','\n').Split('\n'))
        {
            string rest=input.Trim(); if(rest.Length==0){result.Add("");continue;}
            while(rest.Length>max){int cut=rest.LastIndexOf(' ',Math.Min(max,rest.Length-1),Math.Min(max,rest.Length)); if(cut<max/2)cut=max; result.Add(rest[..cut].TrimEnd()); rest=rest[cut..].TrimStart();}
            result.Add(rest);
        }
        return result;
    }
    private static double Paragraph(StringBuilder c, string text, double x, double y, int chars=95, double leading=11.5, bool bold=false)
    { foreach(var line in Wrap(text,chars)){Text(c,line,x,y,bold?"F2":"F1",8.8);y-=leading;} return y; }
    private static string F(List<UvaFieldValue> f,string key)=>f.Single(x=>x.Key==key).Display;
    private static string Missing(List<UvaFieldValue> f,string key)=>f.Single(x=>x.Key==key).Status=="BOUND"?F(f,key):"[OFFEN: "+key+"]";
    private static void Header(StringBuilder c,UvaTemplateDefinition d,string pageName,int page)
    {
        Text(c,"Mercer",38,812,"F2",17,"0 0.22 0.40"); Text(c,"Deutschland GmbH",38,797,"F1",8.5,"0.25 0.3 0.35");
        Text(c,d.Safety.Watermark,310,812,"F2",8.5,"0.72 0.28 0.05"); Text(c,pageName,430,797,"F1",8,"0.35 0.35 0.35");
        c.Append("0 0.22 0.40 RG 0.8 w 38 786 m 557 786 l S\n");
        Text(c,$"Seite {page}/3",510,24,"F1",7.5,"0.45 0.45 0.45");
    }
    private static void LabelValue(StringBuilder c,string label,string value,double y,bool alert=false)
    {
        if(alert)c.Append("1 0.94 0.78 rg 300 ").Append(N(y-3)).Append(" 250 13 re f\n");
        Text(c,label,55,y,"F1",8.7); Text(c,value,305,y,alert?"F2":"F1",8.7,alert?"0.62 0.20 0.04":"0 0 0");
    }
    public static UvaPdfResult Render(UvaTemplateDefinition def, ContributionResult result, PersonResult p, List<UvaFieldValue> fields)
    {
        if (p.TerminationDate is null) throw new IppException("UVA_PDF_NOT_APPLICABLE", "Austrittsdatum fehlt.");
        var contentPages=new List<string>();
        string name=UvaPersonFields.DisplayName(p), sal=F(fields,"Anrede"), street=F(fields,"Adresse"), city=F(fields,"PLZ");
        string exit=F(fields,"Austritt"), birth=F(fields,"Geburtsdatum"), join=F(fields,"Eintritt"), pid=F(fields,"WWID");
        string today=DateTime.Today.ToString("dd. MMMM yyyy",De), company="Intel Deutschland GmbH";
        // Page 1 - Anschreiben
        var c1=new StringBuilder(); Header(c1,def,"Anschreiben",1);
        Text(c1,def.Texts["confidential"],55,752,"F2",9); Text(c1,sal,55,735); Text(c1,name,55,722,"F2",9.3); Text(c1,street,55,709); Text(c1,city,55,696);
        Text(c1,def.Texts["contactPrompt"],340,735,"F1",7.5); Text(c1,def.Texts["contactEmail"],340,722,"F2",7.8,"0 0.22 0.40"); Text(c1,"München, "+today,390,675,"F1",8.5);
        Text(c1,$"##INTL01-{pid}##",55,665,"F1",8.3); Text(c1,$"INTL01 / PN {pid}",400,665,"F1",8.3);
        Text(c1,$"Betriebliche Altersversorgung der {company}",55,645,"F2",9.4);
        string surname = Parse.Text(p.Master.GetValueOrDefault("Surname")) ?? Parse.Text(p.Master.GetValueOrDefault("NACHNAME")) ?? name;
        string greeting = sal == "Herrn" ? $"Sehr geehrter Herr {surname}," : sal == "Frau" ? $"Sehr geehrte Frau {surname}," : $"[ANREDE OFFEN] {name}";
        Text(c1,greeting,55,620,"F1",9);
        double y=597; y=Paragraph(c1,$"die {company} hat unser Haus mit der Verwaltung der Ansprüche ihrer Mitarbeiter aus der betrieblichen Altersversorgung beaufragt. Die arbeitsrechtliche Verpflichtung der {company} Ihnen gegenüber bleibt davon unberührt.",55,y,95,11.2);
        y-=9; y=Paragraph(c1,$"Am {exit} endete Ihr Dienstverhältnis mit der {company}. In Bezug auf Ihre Anwartschaft auf betriebliche Versorgungsleistungen teilen wir Ihnen Folgendes mit:",55,y,95,11.2);
        y-=8; y=Paragraph(c1,$"1. Bei Ihrem Ausscheiden am {exit} hatten Sie die gesetzlichen Voraussetzungen für die Aufrechterhaltung einer unverfallbaren Anwartschaft gemäß dem Gesetz zur Verbesserung der betrieblichen Altersversorgung (BetrAVG) erfüllt.",55,y,95,11.2);
        y-=7; y=Paragraph(c1,def.Texts["paragraph2"],55,y,95,11.2); y-=7; y=Paragraph(c1,def.Texts["paragraph3"],55,y,95,11.2);
        y-=7; y=Paragraph(c1,def.Texts["section4a"],55,y,95,11.2); y-=7; y=Paragraph(c1,def.Texts["closing"],55,y,95,11.2);
        Text(c1,def.Texts["onBehalf"],55,102,"F1",8.7); Text(c1,company,55,88,"F1",8.7); Text(c1,def.Texts["mercer"],55,62,"F2",8.7);
        contentPages.Add(c1.ToString());
        // Page 2 - Berechnungsbogen
        var c2=new StringBuilder(); Header(c2,def,"Berechnungsbogen",2);
        Text(c2,def.Texts["title"],55,758,"F2",12,"0 0.22 0.40"); Text(c2,def.Texts["subtitlePrefix"]+" "+exit,55,742,"F1",8.8); Text(c2,def.Texts["plan"],350,742,"F2",8.8);
        LabelValue(c2,"Personalnummer:",pid,712,fields.Single(x=>x.Key=="WWID").Status!="BOUND"); LabelValue(c2,"Eintrittsdatum:",join,696,join=="OFFEN"); LabelValue(c2,"Geburtsdatum:",birth,680,birth=="OFFEN"); LabelValue(c2,"Austrittsdatum:",exit,664,exit=="OFFEN");
        Text(c2,$"Ausgangsdaten gültig für das Geschäftsjahr {p.TerminationDate.Value.Year}",55,637,"F2",9.2);
        LabelValue(c2,def.Texts["eligiblePay"],Missing(fields,"BeitragsfaehigeBezuege"),615,true); LabelValue(c2,def.Texts["guaranteedPension"],Missing(fields,"Garantierente"),599,true);
        Text(c2,def.Texts["incremental"],55,579,"F1",8.6); LabelValue(c2,def.Texts["guaranteedInterest"],Missing(fields,"Garantiezins"),563,true);
        Text(c2,"Kontostand zum "+exit,55,532,"F2",10,"0 0.22 0.40");
        Text(c2,"Datum",55,512,"F2",8.5); Text(c2,"Aktion",135,512,"F2",8.5); Text(c2,"Umsatz",407,512,"F2",8.5); Text(c2,"Wert",492,512,"F2",8.5);
        c2.Append("0.3 0.3 0.3 RG 0.4 w 52 505 m 548 505 l S\n");
        double ty=487; LabelValue(c2,def.Texts["openingBalance"],Missing(fields,"Saldovortrag"),ty,true); ty-=21;
        LabelValue(c2,def.Texts["contributionProvision"],Missing(fields,"Beitragsbereitstellung"),ty,fields.Single(x=>x.Key=="Beitragsbereitstellung").Status!="BOUND"); ty-=21;
        LabelValue(c2,def.Texts["initialCorrection"],Missing(fields,"KuerzungsbetragIB"),ty,true); ty-=21;
        LabelValue(c2,def.Texts["surplus"],Missing(fields,"Schlussueberschuss"),ty,true); ty-=21;
        LabelValue(c2,def.Texts["interestCredit"],Missing(fields,"Zins"),ty,true); ty-=30;
        LabelValue(c2,"Initialbaustein:",Missing(fields,"Initialbaustein"),ty,true); ty-=35;
        y=Paragraph(c2,$"Zum {exit} hätte sich im Todesfall bzw. im Fall der unbefristeten Erwerbsminderung eine Leistung von {Missing(fields,"Todesfallkapital")} ergeben. Diese schließt eine eventuelle Schlussüberschussgutschrift sowie einen Anhebungsbetrag ein. Bei der befristeten Erwerbsminderung beträgt die monatliche Rente 0,4% des Todesfallkapitals.",55,ty,94,11.2);
        Text(c2,def.Texts["machineGenerated"],55,112,"F1",8); Text(c2,"München, "+today,55,92,"F1",8.5); Text(c2,def.Texts["mercer"],55,72,"F2",8.5);
        Text(c2,"OFFENE FELDER SIND ABSICHTLICH NICHT AUF 0 GESETZT.",55,48,"F2",7.8,"0.62 0.20 0.04");
        contentPages.Add(c2.ToString());
        // Page 3 - Anlage
        var c3=new StringBuilder(); Header(c3,def,"Anlage",3);
        Text(c3,def.Texts["annexTitle"],55,758,"F2",12,"0 0.22 0.40");
        y=Paragraph(c3,def.Texts["annexIntro"],55,732,95,11.2); y-=10;
        Text(c3,def.Texts["benefitHeading"],55,y,"F2",10,"0 0.22 0.40"); y-=18; y=Paragraph(c3,def.Texts["benefitIntro"],55,y,95,11.2);
        foreach(string key in new[]{"benefit1","benefit2","benefit3","benefit4"}) { y-=7; y=Paragraph(c3,def.Texts[key],65,y,91,11.2); }
        y-=12; Text(c3,def.Texts["paymentHeading"],55,y,"F2",10,"0 0.22 0.40"); y-=18;
        foreach(string key in new[]{"payment1","payment2","payment3","payment4"}) { y=Paragraph(c3,def.Texts[key],55,y,95,11.2); y-=5; }
        y-=6; Text(c3,def.Texts["interestHeading"],55,y,"F2",9.5,"0 0.22 0.40"); y-=18; y=Paragraph(c3,def.Texts["interest1"],65,y,91,11.2); y-=5; y=Paragraph(c3,def.Texts["interest2"],65,y,91,11.2);
        Text(c3,def.Texts["footnote3"],55,66,"F1",7.2,"0.28 0.28 0.28");
        contentPages.Add(c3.ToString());
        return Build(contentPages);
    }
    private static UvaPdfResult Build(List<string> streams)
    {
        foreach (string s in streams) _ = WinAnsi.GetBytes(s);
        var objects=new List<string>{"<< /Type /Catalog /Pages 2 0 R >>","","<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>","<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>"};
        var pageIds=new List<int>();
        foreach(string stream in streams)
        {
            int pageId=objects.Count+1, streamId=pageId+1; pageIds.Add(pageId);
            objects.Add($"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents {streamId} 0 R >>");
            objects.Add($"<< /Length {Encoding.ASCII.GetByteCount(stream)} >>\nstream\n{stream}endstream");
        }
        objects[1]=$"<< /Type /Pages /Count {streams.Count} /Kids [ {string.Join(" ",pageIds.Select(i=>i+" 0 R"))} ] >>";
        using var ms=new MemoryStream(); void Put(string s){var b=Encoding.ASCII.GetBytes(s);ms.Write(b);}
        Put("%PDF-1.4\n%MCR_IPP_UVA_TEMPLATE_PREVIEW\n"); var offs=new List<long>{0};
        for(int i=0;i<objects.Count;i++){offs.Add(ms.Position);Put($"{i+1} 0 obj\n{objects[i]}\nendobj\n");}
        long xref=ms.Position; Put($"xref\n0 {objects.Count+1}\n0000000000 65535 f \n"); foreach(long o in offs.Skip(1))Put(o.ToString("D10",CultureInfo.InvariantCulture)+" 00000 n \n");
        Put($"trailer\n<< /Size {objects.Count+1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n"); return new(ms.ToArray(),streams.Count);
    }
}
