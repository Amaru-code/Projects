using System.Globalization;
using System.IO.Compression;
using System.Xml;
using System.Xml.Linq;

namespace Mcr.Ipp.Core;

public sealed record WorkbookSheet(string Name, string State, string Part, string Kind);
public sealed record XCell(string Address, object? Value, string? Formula);
public sealed record InputTable(string Sheet, List<string> Columns, List<Dictionary<string, object?>> Rows, bool Date1904);

/// <summary>Read-only, bounded OpenXML reader. It NEVER evaluates or refreshes formulas.</summary>
public sealed class SpreadsheetReader : IDisposable
{
    public static readonly XNamespace Main = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
    public static readonly XNamespace Rel = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
    public static readonly XNamespace Pkg = "http://schemas.openxmlformats.org/package/2006/relationships";
    private readonly MemoryStream stream;
    private readonly ZipArchive zip;
    public XDocument Workbook { get; }
    public List<WorkbookSheet> Sheets { get; } = new();
    public bool Date1904 => Workbook.Root?.Elements().FirstOrDefault(x => x.Name.LocalName == "workbookPr")?.Attribute("date1904")?.Value is "1" or "true";
    public IEnumerable<string> Parts => zip.Entries.Select(e => e.FullName);
    private readonly string[] shared;

    public SpreadsheetReader(byte[] bytes)
    {
        stream = new MemoryStream(bytes, false);
        try { zip = new ZipArchive(stream, ZipArchiveMode.Read, false); }
        catch (Exception e) { stream.Dispose(); throw new IppException("WORKBOOK_NOT_OPENXML", "Keine lesbare XLSX/XLSM-Datei (ggf. verschluesselt): " + e.Message); }
        try
        {
            if (zip.Entries.Count > 20000 || zip.Entries.Sum(e => e.Length) > 512L * 1024 * 1024) throw new IppException("ZIP_LIMIT", "Arbeitsmappe zu gross.");
            if (zip.Entries.Select(e => e.FullName).Distinct(StringComparer.OrdinalIgnoreCase).Count() != zip.Entries.Count) throw new IppException("ZIP_DUPLICATE", "Doppelte ZIP-Eintraege.");
            Workbook = Xml("xl/workbook.xml");
            var ns = Workbook.Root!.Name.Namespace;
            if (ns != Main) throw new IppException("WORKBOOK_DIALECT", "Nur Transitional OpenXML ist in V0.1 freigegeben; Strict/Binaerdatei nicht unterstuetzt.");
            foreach (var s in Workbook.Descendants(ns + "sheet"))
            {
                var r = Relationship("xl/workbook.xml", (string?)s.Attribute(Rel + "id") ?? "");
                Sheets.Add(new((string?)s.Attribute("name") ?? "", (string?)s.Attribute("state") ?? "visible", Resolve("xl/workbook.xml", r), (string?)r.Attribute("Type") ?? ""));
            }
            shared = Has("xl/sharedStrings.xml") ? Xml("xl/sharedStrings.xml").Root!.Elements(Main + "si").Select(RichText).ToArray() : Array.Empty<string>();
        }
        catch { zip.Dispose(); stream.Dispose(); throw; }
    }
    public bool Has(string part) => zip.GetEntry(part) is not null;
    public XDocument Xml(string part)
    {
        var e = zip.GetEntry(part) ?? throw new IppException("XML_MISSING", $"Fehlender Bestandteil: {part}");
        if (e.Length > 64L * 1024 * 1024) throw new IppException("XML_LIMIT", "XML-Bestandteil ueber 64 MiB.");
        using var es = e.Open();
        using var xr = XmlReader.Create(es, new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null, MaxCharactersInDocument = 64L * 1024 * 1024 });
        return XDocument.Load(xr, LoadOptions.PreserveWhitespace);
    }
    public XElement Relationship(string part, string id)
    {
        int slash = part.LastIndexOf('/');
        var rp = part[..(slash + 1)] + "_rels/" + part[(slash + 1)..] + ".rels";
        var matches = Xml(rp).Root!.Elements(Pkg + "Relationship").Where(x => (string?)x.Attribute("Id") == id).ToList();
        if (matches.Count != 1) throw new IppException("RELATIONSHIP_INVALID", "Relationship fehlt/mehrdeutig: " + id);
        return matches[0];
    }
    public static string Resolve(string from, XElement rel)
    {
        if ((string?)rel.Attribute("TargetMode") == "External") throw new IppException("EXTERNAL_OPEN_REFUSED", "Externes Oeffnen verweigert.");
        var target = (string?)rel.Attribute("Target") ?? "";
        if (target.Length == 0) throw new IppException("RELATIONSHIP_INVALID", "Leeres Ziel.");
        var u = new Uri(new Uri("https://package.invalid/" + from), target);
        if (u.Host != "package.invalid" || u.Scheme != "https" || u.Query.Length > 0 || u.Fragment.Length > 0 || u.UserInfo.Length > 0) throw new IppException("ZIP_PATH", "Ungueltiger Paketpfad.");
        return Uri.UnescapeDataString(u.AbsolutePath.TrimStart('/'));
    }
    private static string RichText(XElement x) => string.Concat(x.Descendants(Main + "t").Where(t => !t.Ancestors(Main + "rPh").Any()).Select(t => t.Value));
    public List<XCell> Cells(WorkbookSheet sheet)
    {
        if (!sheet.Kind.EndsWith("/worksheet", StringComparison.Ordinal)) throw new IppException("SHEET_TYPE", "Kein regulaeres Arbeitsblatt.");
        return Xml(sheet.Part).Descendants(Main + "sheetData").Elements(Main + "row").Elements(Main + "c").Select(c =>
        {
            var address = (string?)c.Attribute("r") ?? throw new IppException("CELL_ADDRESS", "Zelladresse fehlt.");
            var v = c.Element(Main + "v")?.Value;
            object? value = null;
            var type = (string?)c.Attribute("t");
            if (type == "s" && v is not null)
            {
                if (!int.TryParse(v, out var ix) || ix < 0 || ix >= shared.Length) throw new IppException("STRING_INDEX", "Shared-String-Index ungueltig.");
                value = shared[ix];
            }
            else if (type == "inlineStr") value = c.Element(Main + "is") is { } inline ? RichText(inline) : null;
            else if (type == "e") value = new CellError(v ?? "#ERROR");
            else if (type == "b" && v is not null) value = v == "1";
            else if (type is "str" or "d") value = v;
            else if (!string.IsNullOrWhiteSpace(v)) value = double.Parse(v, CultureInfo.InvariantCulture);
            var f = c.Element(Main + "f");
            return new XCell(address, value, f is null ? null : f.ToString(SaveOptions.DisableFormatting));
        }).ToList();
    }
    public InputTable Baseline(string? requestedSheet)
    {
        var candidates = new List<(WorkbookSheet Sheet, List<XCell> Cells)>();
        foreach (var s in Sheets.Where(x => x.Kind.EndsWith("/worksheet", StringComparison.Ordinal)))
        {
            if (requestedSheet is not null && s.Name != requestedSheet) continue;
            var cells = Cells(s);
            if (cells.Any(c => Row(c.Address) == 1 && Parse.Text(c.Value) == "ClientID")) candidates.Add((s, cells));
        }
        if (candidates.Count != 1) throw new IppException("BASELINE_SHEET", "Genau ein Bestandsblatt mit ClientID in Zeile 1 erforderlich. Nicht die IPP-Dokumentvorlage waehlen.");
        var selected = candidates[0];
        var headers = selected.Cells.Where(c => Row(c.Address) == 1 && Parse.Text(c.Value) is not null).OrderBy(c => ColumnNumber(c.Address)).ToList();
        if (headers.Any(h => h.Formula is not null)) throw new IppException("HEADER_FORMULA", "Kopfzeile darf keine Formeln enthalten.");
        var byColumn = headers.ToDictionary(c => ColumnNumber(c.Address), c => Parse.Text(c.Value)!);
        if (byColumn.Values.Distinct(StringComparer.Ordinal).Count() != byColumn.Count) throw new IppException("HEADER_DUPLICATE", "Doppelte Spaltenueberschrift.");
        foreach (var req in new[] { "ClientID", "BaseSalary_1", "PartTimeFactor_1" }) if (!byColumn.Values.Contains(req)) throw new IppException("BASELINE_SCHEMA", "Bestandsfeld fehlt: " + req);
        var rows = new List<Dictionary<string, object?>>();
        foreach (var group in selected.Cells.Where(c => Row(c.Address) > 1).GroupBy(c => Row(c.Address)).OrderBy(g => g.Key))
        {
            if (!group.Any(c => c.Value is not null || c.Formula is not null)) continue;
            var r = byColumn.Values.ToDictionary(h => h, _ => (object?)null, StringComparer.Ordinal);
            foreach (var cell in group)
            {
                if (!byColumn.TryGetValue(ColumnNumber(cell.Address), out var h)) continue;
                if (cell.Formula is not null) throw new IppException("BASELINE_FORMULA", $"{selected.Sheet.Name}!{cell.Address}: Bestand muss gespeicherte Werte enthalten; Cache wird nicht als Berechnung uebernommen.");
                if (cell.Value is CellError) throw new IppException("BASELINE_CELL_ERROR", $"Excel-Fehler in {cell.Address}.");
                r[h] = cell.Value;
            }
            if (r.Values.All(v => Parse.Text(v) is null)) continue;
            rows.Add(r);
        }
        if (rows.Count == 0) throw new IppException("BASELINE_EMPTY", "Keine Bestandsdatensaetze.");
        return new(selected.Sheet.Name, byColumn.Values.ToList(), rows, Date1904);
    }
    public static int Row(string address) => int.Parse(new string(address.Where(char.IsDigit).ToArray()), CultureInfo.InvariantCulture);
    public static int ColumnNumber(string address)
    {
        int n = 0;
        foreach (char c in address) { if (c == '$') continue; if (!char.IsLetter(c)) break; n = checked(n * 26 + char.ToUpperInvariant(c) - 'A' + 1); }
        if (n < 1 || n > 16384) throw new IppException("CELL_ADDRESS", "Zellspalte ungueltig.");
        return n;
    }
    public static string Column(int n) { string s = ""; while (n > 0) { n--; s = (char)('A' + n % 26) + s; n /= 26; } return s; }
    public void Dispose() { zip.Dispose(); stream.Dispose(); }
    private sealed record CellError(string Text);
}

public sealed record OutputSheet(string Name, List<string> Headers, List<List<object?>> Rows)
{
    public bool ReviewLayout { get; init; }
    public List<double>? ColumnWidths { get; init; }
    public HashSet<string> ReviewCells { get; init; } = new(StringComparer.Ordinal);
}
public static class SpreadsheetWriter
{
    private static readonly XNamespace N = SpreadsheetReader.Main;
    private static readonly XNamespace R = SpreadsheetReader.Rel;
    private static readonly XNamespace P = SpreadsheetReader.Pkg;
    private static readonly XNamespace C = "http://schemas.openxmlformats.org/package/2006/content-types";
    public static XDocument SheetXml(OutputSheet sheet, bool styled = true)
    {
        if (sheet.ColumnWidths is not null && (sheet.ColumnWidths.Count != sheet.Headers.Count || sheet.ColumnWidths.Any(w => w < 8 || w > 40)))
            throw new IppException("OUTPUT_WIDTHS", "Ungueltige Spaltenbreiten.");
        var rows = new XElement(N + "sheetData");
        XElement Cell(object? v, string a, int style)
        {
            var c = new XElement(N + "c", new XAttribute("r", a));
            if (styled) c.Add(new XAttribute("s", style));
            if (v is null) return c;
            if (v is double d) { if (!double.IsFinite(d)) throw new IppException("OUTPUT_NONFINITE", "Nichtendlicher Ausgabewert."); c.Add(new XElement(N + "v", d.ToString("R", Parse.Inv))); }
            else if (v is int or long) c.Add(new XElement(N + "v", Convert.ToString(v, Parse.Inv)));
            else if (v is bool b) { c.Add(new XAttribute("t", "b"), new XElement(N + "v", b ? "1" : "0")); }
            else { string text = v is DateOnly date ? date.ToString("dd.MM.yyyy", Parse.Inv) : Convert.ToString(v, Parse.Inv) ?? ""; if (text.Length > 32767) throw new IppException("CELL_TOO_LONG", "Zelltext ueber 32767 Zeichen."); c.Add(new XAttribute("t", "inlineStr"), new XElement(N + "is", new XElement(N + "t", new XAttribute(XNamespace.Xml + "space", "preserve"), text))); }
            return c;
        }
        var header = new XElement(N + "row", new XAttribute("r", 1), new XAttribute("ht", sheet.ColumnWidths is null ? 32 : 52), new XAttribute("customHeight", 1));
        for (int col = 0; col < sheet.Headers.Count; col++) header.Add(Cell(sheet.Headers[col], SpreadsheetReader.Column(col + 1) + "1", 1));
        rows.Add(header);
        for (int i = 0; i < sheet.Rows.Count; i++)
        {
            if (sheet.Rows[i].Count != sheet.Headers.Count) throw new IppException("OUTPUT_SCHEMA", "Ausgabespalten ungleich.");
            var row = new XElement(N + "row", new XAttribute("r", i + 2));
            if (sheet.ReviewLayout)
            {
                double height = 64;
                if (sheet.ColumnWidths is not null)
                {
                    int lines = sheet.Rows[i].Select((v, col) => (Convert.ToString(v, Parse.Inv) ?? "").Split('\n')
                        .Sum(line => Math.Max(1, (int)Math.Ceiling(line.Length / Math.Max(8, sheet.ColumnWidths[col] - 3))))).DefaultIfEmpty(1).Max();
                    height = Math.Clamp(lines * 15 + 8, 32, 240);
                }
                row.Add(new XAttribute("ht", height), new XAttribute("customHeight", 1));
            }
            for (int col = 0; col < sheet.Headers.Count; col++)
            {
                var v = sheet.Rows[i][col];
                string address = SpreadsheetReader.Column(col + 1) + (i + 2);
                bool reviewCell = sheet.ReviewCells.Contains(address);
                if (v is null && !reviewCell) continue;
                row.Add(Cell(v, address, reviewCell ? (v is double ? 5 : 4) : sheet.ReviewLayout ? 3 : v is double && !sheet.Headers[col].StartsWith("Tarifklasse", StringComparison.Ordinal) ? 2 : 0));
            }
            rows.Add(row);
        }
        string range = "A1:" + SpreadsheetReader.Column(sheet.Headers.Count) + (sheet.Rows.Count + 1);
        return new XDocument(new XElement(N + "worksheet",
            new XElement(N + "dimension", new XAttribute("ref", range)),
            new XElement(N + "sheetViews", new XElement(N + "sheetView", new XAttribute("workbookViewId", "0"), new XElement(N + "pane", new XAttribute("ySplit", 1), new XAttribute("topLeftCell", "A2"), new XAttribute("activePane", "bottomLeft"), new XAttribute("state", "frozen")))),
            new XElement(N + "sheetFormatPr", new XAttribute("defaultRowHeight", 20)),
            new XElement(N + "cols", Enumerable.Range(0, sheet.Headers.Count).Select(col => new XElement(N + "col",
                new XAttribute("min", col + 1), new XAttribute("max", col + 1),
                new XAttribute("width", sheet.ColumnWidths?[col] ?? (sheet.ReviewLayout ? 30 : 19)), new XAttribute("customWidth", 1)))),
            rows, new XElement(N + "autoFilter", new XAttribute("ref", range)),
            new XElement(N + "pageMargins", new XAttribute("left", .3), new XAttribute("right", .3), new XAttribute("top", .5), new XAttribute("bottom", .5), new XAttribute("header", .2), new XAttribute("footer", .2))));
    }
    public static void Put(ZipArchive zip, string name, XDocument xml)
    {
        var e = zip.CreateEntry(name, CompressionLevel.Optimal); using var s = e.Open();
        using var writer = XmlWriter.Create(s, new XmlWriterSettings { Encoding = new System.Text.UTF8Encoding(false), Indent = false }); xml.Save(writer);
    }
    public static void Write(string path, params OutputSheet[] sheets)
    {
        using var f = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None);
        using var zip = new ZipArchive(f, ZipArchiveMode.Create);
        var wbSheets = new XElement(N + "sheets");
        var relationships = new XElement(P + "Relationships");
        var types = new XElement(C + "Types", new XElement(C + "Default", new XAttribute("Extension", "rels"), new XAttribute("ContentType", "application/vnd.openxmlformats-package.relationships+xml")), new XElement(C + "Default", new XAttribute("Extension", "xml"), new XAttribute("ContentType", "application/xml")), new XElement(C + "Override", new XAttribute("PartName", "/xl/workbook.xml"), new XAttribute("ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml")), new XElement(C + "Override", new XAttribute("PartName", "/xl/styles.xml"), new XAttribute("ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml")));
        for (int i = 0; i < sheets.Length; i++)
        {
            if (sheets[i].Name.Length > 31) throw new IppException("SHEET_NAME", "Blattname zu lang.");
            string id = "rId" + (i + 1), part = "worksheets/sheet" + (i + 1) + ".xml";
            wbSheets.Add(new XElement(N + "sheet", new XAttribute("name", sheets[i].Name), new XAttribute("sheetId", i + 1), new XAttribute(R + "id", id)));
            relationships.Add(new XElement(P + "Relationship", new XAttribute("Id", id), new XAttribute("Type", R.NamespaceName + "/worksheet"), new XAttribute("Target", part)));
            types.Add(new XElement(C + "Override", new XAttribute("PartName", "/xl/" + part), new XAttribute("ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml")));
            Put(zip, "xl/" + part, SheetXml(sheets[i]));
        }
        relationships.Add(new XElement(P + "Relationship", new XAttribute("Id", "rStyles"), new XAttribute("Type", R.NamespaceName + "/styles"), new XAttribute("Target", "styles.xml")));
        Put(zip, "[Content_Types].xml", new(types));
        Put(zip, "_rels/.rels", new(new XElement(P + "Relationships", new XElement(P + "Relationship", new XAttribute("Id", "rWorkbook"), new XAttribute("Type", R.NamespaceName + "/officeDocument"), new XAttribute("Target", "xl/workbook.xml")))));
        Put(zip, "xl/workbook.xml", new(new XElement(N + "workbook", new XAttribute(XNamespace.Xmlns + "r", R), wbSheets)));
        Put(zip, "xl/_rels/workbook.xml.rels", new(relationships));
        Put(zip, "xl/styles.xml", XDocument.Parse("""
        <styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
          <fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Calibri"/></font></fonts>
          <fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF17324D"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFFFE8B3"/><bgColor indexed="64"/></patternFill></fill></fills>
          <borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
          <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
          <cellXfs count="6"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf><xf numFmtId="4" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf><xf numFmtId="0" fontId="0" fillId="3" borderId="0" xfId="0" applyFill="1"/><xf numFmtId="4" fontId="0" fillId="3" borderId="0" xfId="0" applyNumberFormat="1" applyFill="1" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf></cellXfs>
          <cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
        </styleSheet>
        """));
    }
    public static OutputSheet Contributions(ContributionResult result, string name = "Ergebnis")
    {
        var columns = new List<string> { "ClientID" }; columns.AddRange(result.MasterColumns.Where(c => c != "TerminationDate"));
        columns.AddRange(new[] { "Tarifklasse_alt", "Tarifklasse_neu", "DAT_Änderung", "TerminationDate" });
        foreach (int m in result.Months) columns.AddRange(new[] { $"ATTC_{m}", $"TZG_{m}", $"Betrag_{m}" });
        if (result.TariffReview is not null) columns.AddRange(new[] { "MCR_Tarifstatus", "MCR_Tarifmonate_offen" });
        foreach (int m in result.Months) columns.Add($"MCR_Betragstatus_{m}");
        var rows = new List<List<object?>>();
        foreach (var p in result.Persons)
        {
            var r = new List<object?> { p.ClientId }; foreach (var col in result.MasterColumns.Where(c => c != "TerminationDate")) r.Add(p.Master.GetValueOrDefault(col));
            r.Add(p.TariffOld); r.Add(p.TariffNew); r.Add(p.TariffChangeDate); r.Add(p.TerminationDate);
            foreach (int m in result.Months) { r.Add(p.Months[m].Attc); r.Add(p.Months[m].Tzg); r.Add(p.Months[m].Amount); }
            if (result.TariffReview is not null)
            {
                var blocked = p.Months.Values.Where(m => m.TariffReviewRequired).ToList();
                r.Add(blocked.Count > 0 ? "TARIF_OFFEN_BETRAGSSTATUS_BEACHTEN" : "KEIN_OFFENER_TARIFFALL");
                r.Add(string.Join(", ", blocked.Select(m => m.SalaryDate.ToString("yyyy-MM", Parse.Inv))));
            }
            foreach (int m in result.Months) r.Add(p.Months[m].AmountStatus);
            rows.Add(r);
        }
        var marked = new HashSet<string>(StringComparer.Ordinal);
        for (int i = 0; i < result.Persons.Count; i++)
            foreach (var m in result.Persons[i].Months.Values.Where(m => m.TariffReviewRequired))
                foreach (string col in new[] { $"ATTC_{m.Month}", $"Betrag_{m.Month}" })
                    marked.Add(SpreadsheetReader.Column(columns.IndexOf(col) + 1) + (i + 2));
        return new(name, columns, rows) { ReviewCells = marked };
    }
}
