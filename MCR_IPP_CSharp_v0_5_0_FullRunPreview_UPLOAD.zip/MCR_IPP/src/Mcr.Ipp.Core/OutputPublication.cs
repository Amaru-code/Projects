using System.Security.Cryptography;

[assembly: System.Runtime.CompilerServices.InternalsVisibleTo("Mcr.Ipp.Tests")]

namespace Mcr.Ipp.Core;

/// <summary>One publication boundary for a complete run, never for each PDF folder.
/// Retry only Windows access/sharing/lock errors; never change permissions, overwrite
/// a target, kill another process or delete the source. Persistent failure stays pending.</summary>
internal static class OutputPublication
{
    internal static readonly int[] RetryDelaysMs = { 150, 300, 600, 1200, 2400 };
    private static readonly StringComparison PathComparison = OperatingSystem.IsWindows()
        ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal;

    internal static int MoveRun(string source, string destination, Action<string>? progress, CancellationToken cancel)
        => MoveRunCore(source, destination, Directory.Move,
            (ms, token) => { if (token.WaitHandle.WaitOne(ms)) token.ThrowIfCancellationRequested(); }, progress, cancel);

    // Injectable OS operation/wait for deterministic fault tests. Not a business-policy switch.
    internal static int MoveRunCore(string source, string destination, Action<string, string> move,
        Action<int, CancellationToken> wait, Action<string>? progress = null, CancellationToken cancel = default)
    {
        source = Path.GetFullPath(source); destination = Path.GetFullPath(destination);
        const string prefix = ".inprogress_";
        string sourceName = Path.GetFileName(source);
        if (!sourceName.StartsWith(prefix + "IPP_Run_", StringComparison.Ordinal)
            || !string.Equals(Path.GetFileName(destination), sourceName[prefix.Length..], PathComparison)
            || !string.Equals(Path.GetDirectoryName(source), Path.GetDirectoryName(destination), PathComparison))
            throw new IppException("OUTPUT_PUBLISH_PATH", "Laufabschluss erwartet das eigene Laufverzeichnis und sein benachbartes Ziel.");
        try
        {
            for (int attempt = 1; ; attempt++)
            {
                cancel.ThrowIfCancellationRequested();
                if (Directory.Exists(destination) || File.Exists(destination))
                    throw new IppException("OUTPUT_PUBLISH_EXISTS", "Ziel-Lauf existiert bereits. Keine Ueberschreibung.");
                if (!Directory.Exists(source))
                    throw new IppException("OUTPUT_PUBLISH_SOURCE_MISSING", "Zwischenverzeichnis fehlt. Kein erfolgreicher Laufabschluss.");
                try
                {
                    move(source, destination);
                    return attempt;
                }
                catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
                {
                    ex.Data["PublishAttempts"] = attempt;
                    int code = ex.HResult & 0xffff;
                    if (code is not (5 or 32 or 33) || attempt > RetryDelaysMs.Length) throw;
                    progress?.Invoke($"Laufabschluss: Dateizugriff gesperrt (Code {code}), Versuch {attempt}/{RetryDelaysMs.Length + 1}. Dateien bleiben erhalten; kurzer Wiederholungsversuch.");
                    wait(RetryDelaysMs[attempt - 1], cancel);
                }
            }
        }
        catch (Exception ex)
        {
            ex.Data["OutputStep"] = "RUN_DIRECTORY_PUBLISH";
            ex.Data["SourceDirectory"] = source;
            ex.Data["DestinationDirectory"] = destination;
            throw;
        }
    }

    /// <summary>Hash every output with a closed, read-only file handle. A transient reader
    /// lock is retried; a persistent failure never results in a fabricated hash/manifest.</summary>
    internal static string HashOutput(string path, Action<string>? progress, CancellationToken cancel)
    {
        for (int attempt = 1; ; attempt++)
        {
            cancel.ThrowIfCancellationRequested();
            try
            {
                using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
                return Convert.ToHexString(SHA256.HashData(stream));
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
            {
                ex.Data["OutputStep"] = "OUTPUT_MANIFEST_HASH";
                ex.Data["OutputFile"] = path;
                ex.Data["ReadAttempts"] = attempt;
                int code = ex.HResult & 0xffff;
                if (code is not (5 or 32 or 33) || attempt > RetryDelaysMs.Length) throw;
                progress?.Invoke($"Hashpruefung: {Path.GetFileName(path)} voruebergehend gesperrt; Versuch {attempt}/{RetryDelaysMs.Length + 1}.");
                if (cancel.WaitHandle.WaitOne(RetryDelaysMs[attempt - 1])) cancel.ThrowIfCancellationRequested();
            }
        }
    }
}
