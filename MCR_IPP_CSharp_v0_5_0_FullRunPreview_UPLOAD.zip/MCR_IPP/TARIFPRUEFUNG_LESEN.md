> Historischer Versionshinweis. **V0.4.0:** Rein fehlende Tarife können jetzt sichtbar vorläufig berechnet werden; Konflikte bleiben gehalten. Aktuell maßgeblich: BETRAGSFIX_UND_VORLAGENEXPORT_LESEN.md und START_HIER.md.

# MCR IPP V0.3.0 – Tariflücken pro Person und Monat prüfen

## Warum dieses Update?

V0.2.0 sammelte unbekannte Personen bereits separat, stoppte aber im nächsten Schritt
noch den gesamten Lauf bei der ersten Bestands-Person ohne bekannten Tarif. Das ist
kein weiterer Neueintrittsnachweis. Der neue Desktop-Standard ersetzt genau diese
pauschale Tarif-Sperre durch nachvollziehbare Prüffälle je Person und Monat.

Der gemeldete Kundenlauf hatte 1.040 Bestands-Personen, vier offene Personenfälle und
brach mit `TARIFF_UNKNOWN` ab. Der alte Fehlerbericht nannte keine betroffene Tarif-ID.
Aus den übermittelten Headerlisten ist ersichtlich, dass die Spalte TARIFKLASSE in
allen sechs ausgewählten TXT-Dateien vorhanden war. Welche Person im Januar keinen
Tarif hatte, ist ohne deren Zeilen nicht belegt. Dieses Paket enthält keine der
übermittelten Personennamen, Kennungen oder Kundendaten.

## Verhalten im normalen Bedienablauf

- Unbekannte Personen: unverändert `Prueffaelle.xlsx` und `Personen_Pruefung.json`.
  Ohne anwendbare bestätigte Neuaufnahme nicht im Beitragsbestand.
- Bekannte Personen mit Tariflücke: `Tarifpruefung.xlsx` / `Tarif_Pruefung.json`.
  Personen bleiben im Export. ATTC aus TXT/Bestand/Vormonat bleibt als Gehaltswert
  sichtbar; nur Betrag ist in ungeklärten Monaten leer. Beide Zellen werden gelb markiert.
- TZG kann unabhängig vom Tarif sichtbar bleiben. Es ist kein Nachweis, dass ein
  Beitrag zulässig oder der Monat vollständig geprüft ist.
- Eine gültige frühere Tarifbeobachtung wird bei leeren Folgeangaben vorwärts
  fortgeschrieben, auch 98/99. Es gibt keine Rückfüllung aus späteren Monaten.
- Lesefehler in Tarifwerten oder unterschiedliche Tarife im selben Monat werden
  nicht durch den letzten Wert überstimmt. Sie unterbrechen die Fortschreibung,
  bis wieder ein eindeutiger gültiger Tarif geliefert wird.
- Ein vor bestätigtem DAT_AD2 liegender Monat bleibt wie bisher beitragsleer und
  benötigt keinen Tarif. DAT_AD2 wird für Bestands-Personen nicht neu aus TXT-Feldern
  importiert oder durch JoiningDate ersetzt.
- Der bestehende abschließende AUGUAN-Austrittsfilter bleibt erhalten. Eine dadurch
  ohnehin geleerte Monatsposition ist kein offener Beitragstarif-Fall mehr;
  der ursprüngliche Befund bleibt im Tarifbericht als nicht mehr relevant sichtbar.

**Leer ist nicht 0 Euro. Unvollständige Monatsbeiträge dürfen nicht als vollständige
Beitragsbereitstellung summiert oder in Bescheinigungen freigegeben werden.**

Seit V0.3.0 bleibt die ATTC-Fallback-Kette bei Tariflücken erhalten: im Januar
BaseSalary_1, danach nur der direkte vorhandene Vormonat. Der spätere Tarif
wirkt nicht rückwärts. Ein wegen gesichertem Tarif 98/99 geleertes Gehalt
wird ohne neue passende Gehaltsquelle nicht wiederhergestellt. Vorhandene sonstige Datenprüfungen (z.B. negative Bezüge,
fehlerhafte Zahlen/Datum, doppelte Bestands-IDs) bleiben wirksam und können weiterhin
abbrechen. Das Update ist keine allgemeine Funktion „alle Fehler ignorieren“.

## Benutzeroberfläche

Nach „Beiträge erstellen“ kann **„Tarife prüfen...“** geöffnet werden. Die Ansicht
zeigt ID, Namen aus dem Bestand, Monat, Ursache und Datei; unten die Fundstellen und
rohen Tarifwerte. Die Ansicht ist lesend. Es gibt keinen Default-Tarif 10 und keinen
Button, der ungeklärte Tarife pauschal als zulässig markiert.

Das bisherige Kontrollkästchen „Unbekannte Tarife mit Warnung zulassen“ ist aus dem
normalen Bedienablauf entfernt. Der historische Kompatibilitätsmodus bleibt nur für
explizite Entwickler-/CLI-Optionen und Tests erhalten, ohne fachliche/PDF-Freigabe.

Neueintrittsbestätigungen bleiben unter `local/Personenfreigaben.json` erhalten.
Codeänderungen ändern nicht die Hashes der Eingaben. Vorhandene Bestätigungen werden
wie zuvor nur im exakt passenden Eingabekontext und nach erneuter Datenprüfung verwendet.
Dieses Update bestätigt keine der vier offenen Personen automatisch.

## Dateien und Zähler

`Tarifpruefung.xlsx` enthält:

| Blatt | Inhalt |
|---|---|
| Personen | ID, Bestandsname und zusammengefasste offene Tarifmonate |
| Monate | Ursache und Status je Personenmonat, vorheriger Tarif nur als Hinweis |
| Fundstellen | Original-ID, Quelldatei, originaler logischer Datenrecord, roher Tarif, Quellenhash |
| Abdeckung | TXT-Records insgesamt, bekannte Records, Personen mit/ohne TXT-Zeile und offene Tarifmonate |

Die Recordnummer bleibt nach dem Herausfiltern unbekannter Personen erhalten. Sie
ist **keine physische Textzeilennummer**. Zwei TXT-Records einer Person sind nicht
zwei Personenfälle. Ohne TXT-Zeile gibt es auch keine erfundene Fundstelle: der
Bericht nennt dann die erfolglos zugeordnete Datei und ID explizit.

`Ergebnis.xlsx` behält die bestehenden Finanzspalten und hängt
`MCR_Tarifstatus` / `MCR_Tarifmonate_offen` an. Das Monatsprotokoll enthält ebenfalls
Tarifstatus und Prüfflag. `KEIN_OFFENER_TARIFFALL` ist keine vollständige Daten- oder
Fachfreigabe. Alle leeren Werte haben weiterhin ihre jeweiligen Gründe.

Mögliche Laufstatus:

- `PARTIAL_PERSON_REVIEW_REQUIRED`: offene Personen, keine offenen Tarifmonate.
- `PARTIAL_TARIFF_REVIEW_REQUIRED`: Personenbestand zugeordnet, offene Tarifmonate.
- `PARTIAL_PERSON_AND_TARIFF_REVIEW_REQUIRED`: beide Arten offener Fälle.
- `EXPORTED_NOT_BUSINESS_CERTIFIED`: Export ohne diese offenen Fälle, weiterhin keine Fachfreigabe.
- `FAILED_NOT_PUBLISHED`: ein anderer schwerer Fehler hat den Lauf beendet.

CLI-Exitcode 4 signalisiert Personen-/Tarif-Teilergebnis oder PDF-Entwurfsfehler; 3 bleibt die angeforderte,
aber blockierte IPP-Stufe. 0 bedeutet niemals Produktions-PDF-Freigabe.

Die Tarifprüfung wird vor der eigentlichen Beitragsrechnung gespeichert und zum Ende
aktualisiert. Bricht danach eine andere Prüfung ab, bleiben beide Prüflisten unter
`.inprogress_*` zur Diagnose erhalten. Fertige Läufe stehen unter `IPP_Run_*`.

## Fachliche Klärung

Fehlende TXT-Zeilen können unterschiedliche Ursachen haben. Weder Neueintritt noch
Austritt noch unveränderter Tarif sind allein durch Fehlen belegt. Ein bloßer
Headerfund beweist ebenfalls keinen personenbezogenen Tarifwert.

Zuerst die Ursache je Person/Monat prüfen. Eine Korrektur benötigt nachvollziehbare
zeitlich passende Daten. Keine Klasse aus Februar auf Januar zurückdatieren und
keinen pauschalen Tarif setzen. Eine gesonderte manuelle Tarif-Freigabedatei wird von
V0.3.0 noch nicht eingelesen; die Ansicht dient der Diagnose, nicht der Änderung der
ursprünglichen Arbeitsmappen oder TXT-Dateien.

## Update und Prüfstand

ZIP-Ordner `MCR_IPP` mit bestehendem Projekt zusammenführen; eigene Codeänderungen
zuvor sichern. `local`, `Output`, Eingaben und den gemeinsamen Compiler behalten.
`START.cmd` baut und testet mit dem vorhandenen SDK, ohne Download oder Installation.

164 Tests sind enthalten. T91/T105/T128 wurden für den ATTC-Fix korrigiert;
T129–T164 prüfen Fallback und PDF-Beitragsentwürfe zusätzlich. Der Geldrechenkern, die 11.714 Referenzvektoren, der SDK-Resolver und die
Personenbestätigungslogik sind unverändert. Der Build-Launcher enthält nur die neue
Versionskennzeichnung.

**Neue C#-Tests, Windows-Oberfläche und Excel-COM wurden hier nicht ausgeführt.**
Ein SDK war hier nicht installiert; der versuchte SDK-Download scheiterte an der
Netzwerkverbindung. Statische Code-/Projekt-/XML-Prüfungen, unveränderte Kernartefakte
und ZIP/Manifest-Integrität wurden geprüft. Die Python-Zustandsmodellprüfung in den
Belegen ist ausdrücklich keine Ausführung des C#-Codes und kein fachlicher Nachweis.
