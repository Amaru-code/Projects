"""Reproduce fixed formula vectors using the user's literal function.
No Excel files, pandas or original person data are read.
Only T01 (decimal tuple) is edited. A minimal pd date/NA adapter supports
stdlib dates (T02 portability); this is NOT a full pandas pipeline oracle.
"""
from datetime import date, timedelta
from pathlib import Path
import json, math, random, hashlib, struct

ROOT = Path(__file__).resolve().parents[1]
class DateNaAdapter:
    @staticmethod
    def Timestamp(*args):
        if len(args) == 3: return date(*args)
        if isinstance(args[0], date): return args[0]
        return date.fromisoformat(args[0])
    @staticmethod
    def isna(value):
        return value is None or isinstance(value, float) and math.isnan(value)

received = (ROOT/'reference/python_formula_received.txt').read_text(encoding='utf-8')
namespace = {'pd': DateNaAdapter}
exec(compile(received, 'python_formula_received.txt', 'exec'), namespace)
assert len(namespace['TABLE_DATA'][-1]) == 6
try:
    namespace['calculate_contibution_ipp'](8000, 100, date(2026,4,1))
except ValueError as exc:
    assert 'too many values to unpack' in str(exc)
else:
    raise AssertionError('Expected six-element tuple failure was not observed')
fixed = received.replace('8116,67, 12158,33', '8116.67, 12158.33')
assert fixed != received
namespace = {'pd': DateNaAdapter}
exec(compile(fixed, 'normalized_formula_candidate', 'exec'), namespace)
periods = namespace['TABLE_DATA']
for i,p in enumerate(periods):
    assert len(p)==4 and p[0]<=p[1] and 0<p[2]<p[3]
    if i: assert periods[i-1][1]+timedelta(days=1)==p[0]
func = namespace['calculate_contibution_ipp']
vectors = []
def add(a,t,d):
    value=func(a,t,d)
    vectors.append({'attc':a,'tzg':t,'date':d.isoformat(),'expected':None if math.isnan(value) else value})
for p in periods:
    for d in [p[0], p[1] if p[1].year < 9999 else date(2028,12,1)]:
        for t in [0,0.01,0.5,1,50,80,100]:
            factor = t/100 if t>1 else t
            for full in [0, p[2]-.01,p[2],p[2]+.01,p[3]-.01,p[3],p[3]+.01,20000]:
                add(round(full*factor,4),t,d)
for a,t,d in [(8000,100,date(2012,3,31)),(None,100,date(2026,4,1)),(8000,None,date(2026,4,1)),(8000,-1,date(2026,4,1))]: add(a,t,d)
rng=random.Random(20260929)
for _ in range(5000):
    year=rng.randrange(2013,2029); month=rng.randrange(1,13)
    add(rng.randrange(0,4000000)/100,rng.choice([.2,.5,1,20,50,80,90,100]),date(year,month,1))
rounding = [{'value':x,'digits':d,'expected':round(x,d)} for x in [2.675,1.005,2.685,-2.675,-1.005,0.125,0.375,62.505,236.725,8116.665] for d in [0,2,4]]
for _ in range(5000):
    x=rng.uniform(-1e7,1e7); d=rng.choice([0,1,2,3,4,8]); rounding.append({'value':x,'digits':d,'expected':round(x,d)})
# Independently model the BigInteger algorithm used in C#, then compare to Python's built-in.
def integer_round(x,d):
    num,den=abs(x).as_integer_ratio(); num*=10**d
    q,rem=divmod(num,den)
    if rem*2>den or (rem*2==den and q%2): q+=1
    text=str(q).zfill(d+1)
    if d: text=text[:-d]+'.'+text[-d:]
    answer=float(text)
    return -answer if x<0 else answer
for r in rounding: assert integer_round(r['value'],r['digits'])==r['expected']
output={'schema':'IPP_SYNTHETIC_FORMULA_VECTORS_V1','source':'literal user formula excerpt + T01 and stdlib date adapter','fullPipelineOracle':False,'contributions':vectors,'rounding':rounding}
(ROOT/'tests/golden_vectors.json').write_text(json.dumps(output,ensure_ascii=False,separators=(',',':'),allow_nan=False),encoding='utf-8')
report={'pythonVersion':__import__('sys').version,'receivedTupleFaultReproduced':True,'tableIntervalsChecked':len(periods),'formulaVectorsGenerated':len(vectors),'roundingVectors':len(rounding),'integerRoundingModelVsPython':'PASS','csharpExecuted':False,'fullPandasPipelineExecuted':False,'realBusinessDataTested':False,'sourceExcerptSha256':hashlib.sha256(received.encode()).hexdigest()}
(ROOT/'evidence/python_vector_generation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
