@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "ERRORLEVEL="
cd /d "%~dp0"
if not "%errorlevel%"=="0" goto failed
if "%~1"=="" goto usage
call BUILD_UND_TEST.cmd
set "IPP_PREVIEW_RC=%errorlevel%"
if not "%IPP_PREVIEW_RC%"=="0" goto failed
if not defined IPP_DOTNET goto failed
if not exist "src\Mcr.Ipp.Desktop\bin\Release\net10.0-windows\Mcr.Ipp.Desktop.dll" goto failed
"%IPP_DOTNET%" exec "src\Mcr.Ipp.Desktop\bin\Release\net10.0-windows\Mcr.Ipp.Desktop.dll" --render-preview "%~1"
set "IPP_PREVIEW_RC=%errorlevel%"
if not "%IPP_PREVIEW_RC%"=="0" goto failed
exit /b 0
:usage
echo Nur fuer gepruefte, externe-abhaengigkeitsfreie IPP-Arbeitskopien.
echo Beispiel: PDF_VORSCHAU_ENTWICKLUNG.cmd "C:\Pfad\preview-job.json"
echo Die bekannte IPP-Datei ist wegen offener Abhaengigkeiten NICHT hierfuer freigegeben.
echo Siehe docs\PDF_PREVIEW.md. Keine produktiven PDFs.
:failed
pause
exit /b 1
