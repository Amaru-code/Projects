Vorrangig wird der vorhandene gemeinsame Compiler verwendet:
%USERPROFILE%\projects\Compiler\csharp\tools\dotnet\dotnet.exe

Das SDK muss NICHT in dieses Projekt kopiert werden. Kein Download/keine Installation.
MCR_IPP\tools\dotnet\dotnet.exe ist nur ein Fallback, falls bereits vorhanden.
Weitere Fallbacks: IPP_DOTNET, settings.local.txt, PATH; immer mit SDK-Validierung.
Ein vorhandenes Windows-.NET-10-SDK (z.B. 10.0.400) passt zu global.json.
Windows-Desktop-Runtime und Desktop-Referenzpakete werden fuer WinForms benoetigt.
Kein globaler PATH, keine Registry-Aenderung, keine Adminrechte erforderlich.
Paketwurzel MCR_IPP bleibt stabil. Compiler- und Output-Ordner nicht loeschen.
