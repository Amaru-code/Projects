# SDK-Startfix · Paket 0.1.1

Der Beitragscode, die 56 C#-Tests, alle Referenzvektoren, Beispiel-Eingaben,
Projektdateien, `global.json`, IPP-Mapping- und PDF-Freigabegrenzen sind gegenüber
Paket 0.1.0 unverändert. Dieses Update ändert die Start-/Build-Steuerung.

## Bestehenden Projektordner weiterverwenden

Die ZIP enthält wieder genau den Ordner `MCR_IPP`. In denselben übergeordneten
Ordner entpacken wie bisher und die enthaltenen Projektdateien ersetzen.
Nicht versehentlich `MCR_IPP\MCR_IPP` erzeugen; den bisherigen Ordner nicht löschen.
Eigene Quellcodeänderungen vor dem Ersetzen sichern. Ausgaben, Kundeneingaben und
`projects\Compiler\csharp` müssen weder gelöscht noch verschoben werden.

Anschließend `START.cmd` doppelklicken. Kein PowerShell-Kopierblock notwendig.

## SDK-Auswahl

Der erste Kandidat ist:
`%USERPROFILE%\projects\Compiler\csharp\tools\dotnet\dotnet.exe`

Falls dort kein verwendbares SDK gefunden wird: Compilerwurzel, explizite Variable,
gespeicherter Pfad, lokaler SDK-Ordner und vorhandener PATH werden geprüft.
Eine Laufzeit ohne kompatibles SDK wird nicht mehr als Compiler akzeptiert.
Der Bericht zeigt auch verworfene Kandidaten. Es erfolgt keine Installation.

Die bereits vorhandene Einstellung `10.0.100` + `latestFeature` akzeptiert höhere
stabile 10.0-Feature-Bands, einschließlich des früher dokumentierten SDK 10.0.400.
Es gibt keinen Grund, `global.json` zu löschen oder auf .NET 8/9 umzustellen.

## Fehlerbehandlung

Vorher prüften CMD-Dateien mit `if errorlevel 1`, also nur auf Codes >= 1.
Der .NET-Host kann unter Windows Fehler als negative Codes zurückgeben.
Jetzt beendet JEDER Exitcode ungleich 0 die aktuelle Stufe; Tests werden nach
fehlgeschlagenem Build nicht aufgerufen. Das UI wird nur nach Build/Test gestartet.
Vorhandene DLLs sind kein Ersatz für den erfolgreichen aktuellen Build.

Jeder Build bekommt eine eigene Lauf-ID. Einzige Rückgabedatei für Support:
`evidence\local\DIAGNOSE.txt`

Sie enthält SDK-Pfad/-Version, Exitcodes und aktuelle SDK-/Build-/Testprotokolle.
Nicht gestartete Stufen stehen auf NOT_RUN. Alte Logs werden nicht als neuer PASS
präsentiert. Die Datei kann Benutzernamen/Pfade enthalten, deshalb lokal prüfen.
Nicht automatisch Kundendaten, Excel-Dateien oder TXT-Eingaben mitsenden.

## Tatsächlich ausgeführte Prüfungen dieses Updates

- Änderungen gegen das Originalpaket und unveränderte Anwendungs-/Testdateien: geprüft.
- CMD-Text-/Strukturprüfungen, Labels, Exitcode-Gates und Encoding: statisch geprüft.
- ZIP-CRC, sichere Pfade, Manifest-/Dateihashes und Musterprüfung auf Secrets: geprüft.
- Windows-CMD-Ausführung, C#-Kompilierung/Tests, WinForms und Excel-COM: NICHT hier ausgeführt.

Das SDK steht nicht in dieser Erstellungsumgebung bereit; das verbundene Gerät war
nicht online. Das Paket enthält daher keine Behauptung erfolgreicher lokaler Tests.
Die früher erzeugten Python-Vektoren bleiben als solche gekennzeichnet.

Technische Dokumentation:
- https://learn.microsoft.com/en-us/dotnet/core/tools/global-json
- https://learn.microsoft.com/en-us/dotnet/core/tools/dotnet
- https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/if
