Hier werden NEUE Laufunterordner angelegt. Originaldateien werden nicht ueberschrieben.
.inprogress_* bedeutet: nicht veroeffentlicht / abgebrochen / fehlgeschlagen.
IPP_Run_* bedeutet: Beitragsexport abgeschlossen; IPP/PDF-Status separat im Run_Report.json lesen.
Ein abgeschlossener Beitragsexport ist keine wirtschaftliche Freigabe fuer eine Bescheinigung.
