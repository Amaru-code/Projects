$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$Root = Split-Path -Parent $PSScriptRoot
$Manifest = Get-Content -LiteralPath (Join-Path $Root 'PACKAGE_MANIFEST.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$Count = 0
foreach ($Item in $Manifest.payloads) {
    $Relative = [string]$Item.path
    if ($Relative -match '(^/|\\|(^|/)\.\.(/|$)|:)' -or [string]::IsNullOrWhiteSpace($Relative)) { throw 'Unsafe manifest path.' }
    $Path = Join-Path $Root ($Relative.Replace('/', [IO.Path]::DirectorySeparatorChar))
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw "Missing: $Relative" }
    $Actual = (Get-FileHash -LiteralPath $Path -Algorithm SHA256 -ErrorAction Stop).Hash
    if ($Actual -notmatch '\A[0-9A-Fa-f]{64}\z' -or $Actual -cne $Item.sha256) { throw "Hash mismatch: $Relative" }
    if ((Get-Item -LiteralPath $Path).Length -ne $Item.bytes) { throw "Size mismatch: $Relative" }
    $Count++
}
Write-Host "PACKAGE_PAYLOAD_HASHES=PASS | FILES=$Count"
Write-Host 'This is integrity only, not CSharp compilation or business approval.'
