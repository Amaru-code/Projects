@echo off
rem Called from project-root wrappers, within the caller's SETLOCAL.
rem Probe an actual SDK, not just an arbitrary dotnet runtime on PATH.
set "ERRORLEVEL="
set "IPP_DOTNET_REQUESTED=%IPP_DOTNET%"
if defined IPP_DOTNET_REQUESTED set "IPP_DOTNET_REQUESTED=%IPP_DOTNET_REQUESTED:"=%"
set "IPP_DOTNET="
set "IPP_SDK_VERSION="
for %%D in ("%~dp0..") do set "IPP_PROJECT_ROOT=%%~fD"
if not defined IPP_LOG_DIR set "IPP_LOG_DIR=%IPP_PROJECT_ROOT%\evidence\local\sdk_probe"
if not exist "%IPP_LOG_DIR%" mkdir "%IPP_LOG_DIR%"
if not exist "%IPP_LOG_DIR%" exit /b 2
set "DOTNET_CLI_HOME=%IPP_PROJECT_ROOT%\.dotnet_home"
set "DOTNET_CLI_TELEMETRY_OPTOUT=1"
set "DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1"
set "DOTNET_NOLOGO=1"
set "DOTNET_CLI_WORKLOAD_UPDATE_NOTIFY_DISABLE=1"
set "DOTNET_MULTILEVEL_LOOKUP=0"
set "MSBUILDDISABLENODEREUSE=1"
set "MSBuildSDKsPath="
set "MSBUILD_EXE_PATH="
set "NUGET_PACKAGES=%IPP_PROJECT_ROOT%\.packages"
>"%IPP_LOG_DIR%\sdk_resolution.log" echo MCR_IPP_SDK_RESOLVER=1.1
>>"%IPP_LOG_DIR%\sdk_resolution.log" echo PROJECT=%IPP_PROJECT_ROOT%

rem Reuse the user's known shared compiler, without copying or downloading it.
call :probe "%USERPROFILE%\projects\Compiler\csharp\tools\dotnet\dotnet.exe"
if defined IPP_DOTNET goto selected
call :probe "%USERPROFILE%\projects\Compiler\csharp\dotnet.exe"
if defined IPP_DOTNET goto selected

rem Fallbacks are accepted only after the same SDK and desktop runtime checks.
if defined IPP_DOTNET_REQUESTED call :probe "%IPP_DOTNET_REQUESTED%"
if defined IPP_DOTNET goto selected
set "IPP_SAVED_PATH="
if exist "%IPP_PROJECT_ROOT%\settings.local.txt" set /p "IPP_SAVED_PATH="<"%IPP_PROJECT_ROOT%\settings.local.txt"
if defined IPP_SAVED_PATH set "IPP_SAVED_PATH=%IPP_SAVED_PATH:"=%"
if defined IPP_SAVED_PATH call :probe "%IPP_SAVED_PATH%"
if defined IPP_DOTNET goto selected
call :probe "%IPP_PROJECT_ROOT%\tools\dotnet\dotnet.exe"
if defined IPP_DOTNET goto selected
for /f "delims=" %%D in ('where dotnet.exe 2^>nul') do call :probe "%%D"
if defined IPP_DOTNET goto selected

echo Kein verwendbares Windows-.NET-10-SDK gefunden.
echo Shared SDK erwartet: %USERPROFILE%\projects\Compiler\csharp\tools\dotnet\dotnet.exe
echo Keine Installation und kein Download gestartet. Details im SDK-Protokoll.
exit /b 2

:selected
>"%IPP_PROJECT_ROOT%\settings.local.txt" echo %IPP_DOTNET%
if not "%errorlevel%"=="0" exit /b 2
>"%IPP_LOG_DIR%\sdk_selected.txt" echo DOTNET_EXE=%IPP_DOTNET%
>>"%IPP_LOG_DIR%\sdk_selected.txt" echo SDK_VERSION=%IPP_SDK_VERSION%
>>"%IPP_LOG_DIR%\sdk_selected.txt" echo DOTNET_ROOT=%DOTNET_ROOT%
>>"%IPP_LOG_DIR%\sdk_selected.txt" echo SDK_SELECTION=PASS
>>"%IPP_LOG_DIR%\sdk_resolution.log" echo SELECTED=%IPP_DOTNET%
echo SDK: %IPP_SDK_VERSION%
echo Compiler: %IPP_DOTNET%
exit /b 0

:probe
if defined IPP_DOTNET exit /b 0
set "IPP_CANDIDATE=%~1"
if not defined IPP_CANDIDATE exit /b 0
>>"%IPP_LOG_DIR%\sdk_resolution.log" echo.
>>"%IPP_LOG_DIR%\sdk_resolution.log" echo CANDIDATE=%IPP_CANDIDATE%
if not exist "%IPP_CANDIDATE%" goto missing
for %%D in ("%IPP_CANDIDATE%") do set "DOTNET_ROOT=%%~dpD"
set "DOTNET_HOST_PATH=%IPP_CANDIDATE%"
set "DOTNET_MSBUILD_SDK_RESOLVER_CLI_DIR=%DOTNET_ROOT%"

"%IPP_CANDIDATE%" --list-sdks >"%IPP_LOG_DIR%\sdk_list.probe.txt" 2>&1
set "IPP_PROBE_RC=%errorlevel%"
>>"%IPP_LOG_DIR%\sdk_resolution.log" echo LIST_SDKS_EXIT=%IPP_PROBE_RC%
type "%IPP_LOG_DIR%\sdk_list.probe.txt" >>"%IPP_LOG_DIR%\sdk_resolution.log"
if not "%IPP_PROBE_RC%"=="0" goto rejected

rem Run within the project root so global.json actually qualifies the candidate.
"%IPP_CANDIDATE%" --version >"%IPP_LOG_DIR%\sdk_version.probe.txt" 2>&1
set "IPP_PROBE_RC=%errorlevel%"
>>"%IPP_LOG_DIR%\sdk_resolution.log" echo SDK_VERSION_EXIT=%IPP_PROBE_RC%
type "%IPP_LOG_DIR%\sdk_version.probe.txt" >>"%IPP_LOG_DIR%\sdk_resolution.log"
if not "%IPP_PROBE_RC%"=="0" goto rejected
set "IPP_PROBE_VERSION="
for /f "delims=" %%V in ('findstr /r /x /c:"10\.0\.[0-9][0-9]*" "%IPP_LOG_DIR%\sdk_version.probe.txt"') do set "IPP_PROBE_VERSION=%%V"
if not defined IPP_PROBE_VERSION goto rejected

"%IPP_CANDIDATE%" --list-runtimes >"%IPP_LOG_DIR%\sdk_runtimes.probe.txt" 2>&1
set "IPP_PROBE_RC=%errorlevel%"
>>"%IPP_LOG_DIR%\sdk_resolution.log" echo LIST_RUNTIMES_EXIT=%IPP_PROBE_RC%
type "%IPP_LOG_DIR%\sdk_runtimes.probe.txt" >>"%IPP_LOG_DIR%\sdk_resolution.log"
if not "%IPP_PROBE_RC%"=="0" goto rejected
findstr /l /b /c:"Microsoft.NETCore.App 10.0." "%IPP_LOG_DIR%\sdk_runtimes.probe.txt" >nul
if not "%errorlevel%"=="0" goto rejected
findstr /l /b /c:"Microsoft.WindowsDesktop.App 10.0." "%IPP_LOG_DIR%\sdk_runtimes.probe.txt" >nul
if not "%errorlevel%"=="0" goto rejected

set "IPP_DOTNET=%IPP_CANDIDATE%"
set "IPP_SDK_VERSION=%IPP_PROBE_VERSION%"
>>"%IPP_LOG_DIR%\sdk_resolution.log" echo RESULT=SDK_AND_DESKTOP_RUNTIME_ACCEPTED
exit /b 0
:missing
>>"%IPP_LOG_DIR%\sdk_resolution.log" echo RESULT=PATH_NOT_FOUND
exit /b 0
:rejected
>>"%IPP_LOG_DIR%\sdk_resolution.log" echo RESULT=REJECTED_NO_COMPATIBLE_SDK_OR_RUNTIME
exit /b 0
