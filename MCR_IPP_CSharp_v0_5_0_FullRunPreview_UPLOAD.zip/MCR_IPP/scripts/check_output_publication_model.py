"""Independent specification model; stdlib only. NOT execution of C# or Windows I/O."""
from pathlib import Path
import tempfile, json, shutil, hashlib
ROOT = Path(__file__).resolve().parents[1]
DELAYS = [150,300,600,1200,2400]

class Injected(Exception):
    def __init__(self, code): self.code=code

def publish(source, dest, errors):
    attempts=0; waits=[]
    while True:
        if dest.exists(): raise FileExistsError(dest)
        if not source.is_dir(): raise FileNotFoundError(source)
        attempts+=1
        try:
            if errors: raise Injected(errors.pop(0))
            source.rename(dest)
            return attempts, waits
        except Injected as ex:
            if ex.code not in [5,32,33] or attempts>len(DELAYS):
                ex.attempts=attempts; ex.waits=waits; raise
            waits.append(DELAYS[attempts-1])

results=[]
for name, errors, expected in [
    ('normal',[],1),('access_once',[5],2),('sharing_then_lock',[32,33],3),
    ('all_retries_then_success',[5]*5,6),('persistent',[5]*6,None),('disk_full',[112],None)]:
    with tempfile.TemporaryDirectory(prefix='ipp_publication_model_') as d:
        parent=Path(d);stage=parent/'.inprogress_IPP_Run_test';final=parent/'IPP_Run_test'
        (stage/'PDF_Entwuerfe').mkdir(parents=True)
        payload=b'synthetic diagnostic payload, not a real C# PDF'
        (stage/'PDF_Entwuerfe'/'synthetic.pdf').write_bytes(payload)
        try:
            attempts,waits=publish(stage,final,errors.copy())
            assert expected==attempts and not stage.exists() and final.exists()
            assert (final/'PDF_Entwuerfe'/'synthetic.pdf').read_bytes()==payload
            results.append({'case':name,'status':'PASS_MODEL','attempts':attempts,'waitsMs':waits})
        except Injected as ex:
            assert expected is None and stage.exists() and not final.exists()
            assert (stage/'PDF_Entwuerfe'/'synthetic.pdf').read_bytes()==payload
            assert ex.attempts==(6 if name=='persistent' else 1)
            results.append({'case':name,'status':'PASS_MODEL','attempts':ex.attempts,'retained':True})
# Source contract checks, NOT a compiler.
source=(ROOT/'src/Mcr.Ipp.Core/ContributionDocuments.cs').read_text()
assert 'Directory.Move' not in source and 'Directory.Delete' not in source
assert 'stream.Flush(flushToDisk: true)' in source
assert 'Dokumentenplan_Zwischenstand.json' in source
p=(ROOT/'src/Mcr.Ipp.Core/Pipeline.cs').read_text()
assert 'OutputPublication.MoveRun(stage, final, progress, token)' in p
assert 'hresult = "0x"' in p and 'exception = ex.ToString()' in p
report={'schema':'MCR_IPP_OUTPUT_PUBLICATION_MODEL_V1','status':'PASS_MODEL_AND_SOURCE_CHECKS_ONLY',
        'csharpExecuted':False,'windowsIoExecuted':False,'rootCauseOfUserLockIdentified':False,
        'maximumRetryWaitMs':sum(DELAYS),'cases':results,
        'sourceChecks':{'noInnerDirectoryMove':True,'noPdfEvidenceDeletion':True,'outputHandlesFlushed':True,'originalExceptionLogged':True}}
(ROOT/'evidence/output_publication_model_checks.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
