"""Independent Python checks for V0.4.0; never C# build/runtime evidence.
Reads frozen formula vectors without changing them; models missing vs conflict policy;
checks lossless JSON fragment transport and a synthetic provisional PDF layout.
"""
from pathlib import Path
from datetime import date
import hashlib,json,math,importlib.util
ROOT=Path(__file__).resolve().parents[1]
class PD:
    @staticmethod
    def Timestamp(*a):
        if len(a)==3:return date(*a)
        return a[0] if isinstance(a[0],date) else date.fromisoformat(a[0])
    @staticmethod
    def isna(x):return x is None or isinstance(x,float) and math.isnan(x)

def main():
    vectors=json.loads((ROOT/'tests/golden_vectors.json').read_text())
    ns={'pd':PD};text=(ROOT/'reference/python_formula_received.txt').read_text().replace('8116,67, 12158,33','8116.67, 12158.33')
    exec(compile(text,'literal-user-formula-with-recorded-decimal-fix','exec'),ns)
    fn=ns['calculate_contibution_ipp']
    for v in vectors['contributions']:
        value=fn(v['attc'],v['tzg'],date.fromisoformat(v['date']))
        assert (math.isnan(value) if v['expected'] is None else value==v['expected'])
    for v in vectors['rounding']:assert round(v['value'],v['digits'])==v['expected']
    example=fn(10180.64,100,date(2026,1,1));assert example==166.90
    permitted={'NO_TXT_RECORD_NO_PRIOR_TARIFF','TARIFF_EMPTY_NO_PRIOR_TARIFF','TARIFF_COLUMN_MISSING'}
    reasons=list(sorted(permitted))+['TARIFF_VALUES_CONFLICT','TARIFF_VALUE_INVALID','TARIFF_UNRESOLVED_AFTER_CONFLICT']
    policy=[]
    for enabled in [False,True]:
        for reason in reasons:
            calculated=enabled and reason in permitted
            value=fn(8000,100,date(2026,1,1)) if calculated else None
            assert (value is not None)==calculated
            policy.append({'enabled':enabled,'reason':reason,'numeric':calculated,'tariffResolved':False})
    # Independent fragment model, including JSON escapes and non-BMP Unicode.
    obj={'kind':'synthetic','text':'"Ä😀\\\n'*7000}
    serialized=json.dumps(obj,ensure_ascii=False,indent=2)
    pieces=[serialized[i:i+5000] for i in range(0,len(serialized),5000)]
    frames=[{'record':0,'fragment':i+1,'fragments':len(pieces),'recordSha256':hashlib.sha256(serialized.encode()).hexdigest().upper(),'jsonTextFragment':p} for i,p in enumerate(pieces)]
    recovered=''.join(json.loads(json.dumps(f,ensure_ascii=False))['jsonTextFragment'] for f in frames)
    assert recovered==serialized and json.loads(recovered)==obj
    # No C# renderer is executed: independent existing PDF primitives model.
    spec=importlib.util.spec_from_file_location('pdfmodel',ROOT/'scripts/check_pdf_layout_model.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    lines=module.synthetic_lines(True)
    lines=[(s.replace('2 Tarifmonate offen. Gehalt sichtbar, Beitrag zurueckgehalten.','2 Tarifmonate offen. Vorlaeufige Betraege sind keine Freigabe.'),b,a) for s,b,a in lines]
    for i,(s,b,a) in enumerate(lines):
        if s.startswith(('2026-01  ','2026-02  ')):
            s=s[:10]+'8.000,00'.rjust(15)+' '+'100,00'.rjust(10)+' '+'69,57'.rjust(16)+'  VORLAEUFIG*';lines[i]=(s,b,a)
    lines.extend(module.wrap('VORLAEUFIG*: Tarif fehlt; wie Python gerechnet, nicht bestaetigt. Kein Versand.'))
    content,pages=module.pdf_model('90000001',lines)
    folder=ROOT/'evidence/v040_model';folder.mkdir(exist_ok=True)
    name='MODELL_VORLAEUFIG_NICHT_CSHARP.pdf';(folder/name).write_bytes(content)
    import fitz
    with fitz.open(stream=content,filetype='pdf') as doc:
        assert not doc.is_repaired and len(doc)==pages
        alltext=''
        for page in doc:
            t=page.get_text();alltext+=t;assert 'ENTWURF - INTERN - NICHT VERSENDEN' in t
            for block in page.get_text('dict')['blocks']:
                for line in block.get('lines',[]):
                    for span in line['spans']:
                        x0,y0,x1,y1=span['bbox'];assert 0<=x0<x1<=595 and 0<=y0<y1<=842
            page.get_pixmap(matrix=fitz.Matrix(1.25,1.25)).save(folder/f'page_{page.number+1}.png')
        assert 'VORLAEUFIG*' in alltext and 'Keine Gesamtsumme' in alltext
    report={'schema':'MCR_IPP_V040_INDEPENDENT_MODELS_V1','status':'PASS_PYTHON_MODEL_ONLY','literalFormulaVectorChecks':len(vectors['contributions']),'pythonRoundingChecks':len(vectors['rounding']),'unchangedVectorsSha256':hashlib.sha256((ROOT/'tests/golden_vectors.json').read_bytes()).hexdigest().upper(),'syntheticExample':{'salary':10180.64,'tzg':100,'date':'2026-01-01','amount':example,'tariffAssumption':'unknown/not approved'},'policyCases':policy,'jsonFragmentRoundtrip':'PASS_INDEPENDENT_MODEL','pdfModel':{'pages':pages,'allTextWithinPages':True,'repaired':False,'sha256':hashlib.sha256(content).hexdigest().upper()},'csharpBuildExecuted':False,'actualCsharpExporterExecuted':False,'actualCsharpPdfRendered':False,'realTemplateWorkbookAvailable':False,'realDataParityCertified':False}
    (ROOT/'evidence/v040_model_checks.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
