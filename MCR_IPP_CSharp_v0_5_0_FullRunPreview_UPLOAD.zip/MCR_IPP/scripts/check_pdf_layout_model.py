"""Synthetic, independent Python model of DraftPdf's PDF primitives/layout.
NOT a C# execution or business-parity proof. Optional PyMuPDF is needed only
for this developer check. No customer files or installed font files are used.
"""
from pathlib import Path
import hashlib, json, re
ROOT=Path(__file__).resolve().parents[1]
COLUMNS=91
PER_PAGE=44

def wrap(s, bold=False, alert=False):
    answer=[]
    for row in s.replace('\r\n','\n').replace('\r','\n').split('\n'):
        rest=row.replace('\t',' ')
        if not rest:
            answer.append(('',bold,alert));continue
        while len(rest)>COLUMNS:
            i=rest.rfind(' ',0,COLUMNS)
            if i<COLUMNS//3:i=COLUMNS
            answer.append((rest[:i],bold,alert));rest=rest[i:].lstrip(' ')
        if rest:answer.append((rest,bold,alert))
    return answer

def hx(s):
    if any(ord(c)<32 or 127<=ord(c)<=159 for c in s):raise ValueError('control')
    b=s.encode('cp1252',errors='strict')
    if any(c in (0x7f,0x81,0x8d,0x8f,0x90,0x9d,0xad) for c in b):raise ValueError('unsupported')
    return '<'+b.hex().upper()+'>'

def number(x):
    return ('%.3f'%x).rstrip('0').rstrip('.')

def pdf_model(client_id,lines):
    assert re.fullmatch('[0-9]{1,15}',client_id)
    assert 0<len(lines)<=440 and all(len(l[0])<=COLUMNS for l in lines)
    for text,_,_ in lines:hx(text)
    pages=(len(lines)+PER_PAGE-1)//PER_PAGE
    objects=['<< /Type /Catalog /Pages 2 0 R >>','',
        '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>',
        '<< /Type /Font /Subtype /Type1 /BaseFont /Courier /Encoding /WinAnsiEncoding >>',
        '<< /Type /Font /Subtype /Type1 /BaseFont /Courier-Bold /Encoding /WinAnsiEncoding >>']
    pageids=[]
    for p in range(pages):
        pageid=len(objects)+1;streamid=pageid+1;pageids.append(pageid);content=[]
        def text(s,x,y,font,size,color):
            content.append(f'{color} rg BT /{font} {number(size)} Tf 1 0 0 1 {number(x)} {number(y)} Tm {hx(s)} Tj ET\n')
        content.append('0.09 0.20 0.30 rg 0 734 595 108 re f\n')
        text('MCR / IPP',36,808,'F1',13,'1 1 1')
        text('Beitragsuebersicht',36,780,'F1',23,'1 1 1')
        text('ENTWURF - INTERN - NICHT VERSENDEN',36,754,'F3',11,'1 0.85 0.52')
        text('ClientID '+client_id,36,714,'F2',10,'0.09 0.20 0.30')
        y=690
        for s,bold,alert in lines[p*PER_PAGE:(p+1)*PER_PAGE]:
            if alert:content.append(f'1 0.93 0.78 rg 33 {number(y-3)} 529 13.4 re f\n')
            text(s,36,y,'F3' if bold else 'F2',9.5,'0.09 0.14 0.20');y-=13.4
        content.append('0.7 0.75 0.8 RG 0.5 w 36 75 m 559 75 l S\n')
        text('Kein Leistungsnachweis / keine Unverfallbarkeitsbescheinigung.',36,59,'F2',8,'0.3 0.3 0.3')
        text('Keine Versandfreigabe. Offene Werte sind nicht 0 EUR.',36,45,'F2',8,'0.3 0.3 0.3')
        text(f'Seite {p+1}/{pages}',492,30,'F2',8,'0.3 0.3 0.3')
        s=''.join(content)
        objects.append(f'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R /F2 4 0 R /F3 5 0 R >> >> /Contents {streamid} 0 R >>')
        objects.append(f'<< /Length {len(s.encode("ascii"))} >>\nstream\n{s}endstream')
    objects[1]=f'<< /Type /Pages /Count {pages} /Kids [ '+ ' '.join(f'{i} 0 R' for i in pageids)+' ] >>'
    out=bytearray(b'%PDF-1.4\n%MCR_IPP_DRAFT_ONLY\n');offsets=[0]
    for i,obj in enumerate(objects,1):
        offsets.append(len(out));out.extend(f'{i} 0 obj\n{obj}\nendobj\n'.encode('ascii'))
    xref=len(out);out.extend(f'xref\n0 {len(objects)+1}\n0000000000 65535 f \n'.encode())
    for offset in offsets[1:]:out.extend(f'{offset:010d} 00000 n \n'.encode())
    out.extend(f'trailer\n<< /Size {len(objects)+1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n'.encode())
    return bytes(out),pages

def synthetic_lines(held):
    lines=[]
    def add(s='',b=False,a=False):lines.extend(wrap(s,b,a))
    add('MODELLPRUEFUNG - SYNTHETISCH; NICHT MIT C# ERZEUGT',True,True)
    add('Person: Jörg Muster-Müller',True)
    add('Ausgewaehlte Monate: 2026-01, 2026-02, 2026-03, 2026-04, 2026-05, 2026-06')
    add('PRUEFSTATUS: 2 Tarifmonate offen. Gehalt sichtbar, Beitrag zurueckgehalten.' if held else 'PRUEFSTATUS: Keine offene Tarifpruefung; keine fachliche Gesamtfreigabe.',True,held)
    add('Die Angaben zeigen Monatsbeitraege, keine Leistungs- oder Rentenberechnung.')
    add();add('MONAT          ATTC EUR       TZG**      BEITRAG EUR  STATUS',True);add('-'*88)
    for m in range(1,7):
        open_month=held and m<3
        amount='--' if open_month else '200,00'
        add(f'2026-{m:02}'.ljust(10)+'8.000,00'.rjust(15)+' '+'100,00'.rjust(10)+' '+amount.rjust(16)+'  '+('TARIF OFFEN' if open_month else 'BERECHNET*'),False,open_month)
    add('-'*88)
    if held:add('Keine Gesamtsumme: mindestens ein Monat fehlt, ist gesperrt oder ausgenommen.',True,True)
    else:
        add('Summe genau dieser ausgewiesenen Monatsbetraege: 1.200,00 EUR',True)
        add('Nur Rechensumme; KEINE Beitragsbereitstellung, kein Jahres- oder Kontosaldo.')
    add();add('HERKUNFT UND MONATSPRUEFUNG',True)
    for m in range(1,7):
        origin='Bestand: BaseSalary_1' if m==1 else 'direkter Vormonat'
        add(f'2026-{m:02} | ATTC: {origin} | Tarif: '+('unbekannt' if held and m<3 else '10'))
        if held and m<3:add('  Hinweise: TARIFF_REVIEW_REQUIRED')
    add()
    for s in [
        '* Berechnet bedeutet NICHT fachlich freigegeben. -- ist leer, nicht 0 EUR.',
        '** TZG wird wie in Ergebnis.xlsx gezeigt; Faktor-/Prozenteinheit lokal pruefen.',
        'ATTC aus Bestand/TXT/Vormonat ist ein Gehaltswert, keine Tarifbestaetigung.',
        'Salden, Zinsen, Initialbausteine und Garantierenten sind hier NICHT berechnet.',
        'Offene TXT-Personen wurden nicht aufgenommen; siehe Prueffaelle.xlsx.',
        '', 'QUELLENBINDUNG: SYNTHETISCHER MODELLTEST / KEINE ECHTDATEN', 'A'*64,
        'Werte sind fuer den Layouttest erfunden, keine Berechnungsreferenz.']:
        add(s)
    return lines

def main():
    import fitz
    out=ROOT/'evidence/pdf_model';out.mkdir(exist_ok=True)
    # Check key layout constants against the source; does not prove language/runtime parity.
    source=(ROOT/'src/Mcr.Ipp.Core/DraftPdf.cs').read_text()
    for snippet in ['Columns = 91','LinesPerPage = 44','double y = 690','y -= 13.4','595 842','36, 59','36, 45']:
        assert snippet in source,snippet
    cases={
        'MODELL_SYNTHETISCH_offener_Tarif.pdf':synthetic_lines(True),
        'MODELL_SYNTHETISCH_numerische_Monate.pdf':synthetic_lines(False),
        'MODELL_SYNTHETISCH_3_Seiten.pdf':[('MODELLPRUEFUNG - KEIN C#-LAUF / SEITENUMBRUCH',True,True)]+[(f'Zeile {i:03}: '+'Z'*75,False,i%9==0) for i in range(100)]
    }
    reports=[]
    for name,lines in cases.items():
        b,count=pdf_model('90000001',lines);p=out/name;p.write_bytes(b)
        x=int(re.search(rb'startxref\n([0-9]+)',b)[1]);assert b[x:x+4]==b'xref'
        with fitz.open(stream=b,filetype='pdf') as doc:
            assert len(doc)==count
            assert not doc.is_repaired and not doc.is_encrypted
            chars=''
            for page in doc:
                txt=page.get_text();chars+=txt
                assert 'ENTWURF - INTERN - NICHT VERSENDEN' in txt
                assert 'Keine Versandfreigabe.' in txt
                assert 'Seite '+str(page.number+1)+'/'+str(count) in txt
                for block in page.get_text('dict')['blocks']:
                    for line in block.get('lines',[]):
                        for span in line['spans']:
                            x0,y0,x1,y1=span['bbox']
                            assert 0<=x0<x1<=595 and 0<=y0<y1<=842,(name,span)
                page.get_pixmap(matrix=fitz.Matrix(1.5,1.5)).save(out/(p.stem+f'_Seite{page.number+1}.png'))
            if 'Tarif' in name: assert '8.000,00' in chars and 'Keine Gesamtsumme' in chars and 'Jörg Muster-Müller' in chars
            if 'numerische' in name: assert '1.200,00' in chars and 'KEINE Beitragsbereitstellung' in chars
        assert pdf_model('90000001',lines)[0]==b
        reports.append({'file':name,'pages':count,'sha256':hashlib.sha256(b).hexdigest().upper(),'rendered':'PyMuPDF','allTextWithinPage':True,'readerRepairRequired':False})
    for bad in ['漢字','X\0Y','A\u00adB']:
        try:pdf_model('1001',[(bad,False,False)]);raise AssertionError('bad text accepted')
        except (UnicodeError,ValueError):pass
    report={'schema':'MCR_IPP_PDF_LAYOUT_MODEL_V1','status':'PASS_SYNTHETIC_PYTHON_MODEL_ONLY',
        'csharpExecuted':False,'windowsUiExecuted':False,'actualCsharpOutputRendered':False,
        'businessRulesValidated':False,'cases':reports,
        'limitations':'Independent layout/serialization model only; C# tests and real output must run locally. No font files embedded or shipped.'}
    (ROOT/'evidence/pdf_layout_model_checks.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
