"""Independent policy-model checks + source wiring checks, NOT execution of C#/.NET.
Uses synthetic states only. Standard-library Python; no customer files are read.
"""
from itertools import product
from pathlib import Path
import json, re, xml.etree.ElementTree as ET
ROOT = Path(__file__).resolve().parents[1]

def model(rows, entry_month=1):
    prev = None
    answers = []
    for m, vals in enumerate(rows, 1):
        invalid = any(v == 'invalid' for v in vals)
        valid = set(v for v in vals if isinstance(v, int))
        if invalid or len(valid) > 1:
            eff = None
        elif valid:
            eff = next(iter(valid))
        else:
            eff = prev
        answers.append((eff, eff is None and m >= entry_month))
        prev = eff
    return answers

states = ((), (None,), (10,), (99,), ('invalid',), (10,99), (10,10), (10,'invalid'))
sequences = 0
checks = 0
for sequence in product(states, repeat=4):
    result = model(sequence)
    sequences += 1
    for i, vals in enumerate(sequence):
        assert result[:i+1] == model(sequence[:i+1]), 'future evidence changed prefix'
        checks += 1
        if any(v == 'invalid' for v in vals) or len({v for v in vals if isinstance(v,int)})>1:
            assert result[i] == (None, True)
            checks += 1
        if len(set(vals)) == 1 and vals[0] in (10,99):
            assert result[i] == (vals[0],False)
            checks += 1
assert model(((),(10,))) == [(None,True),(10,False)]
assert model(((99,),())) == [(99,False),(99,False)]
assert model(((10,),('invalid',),(),(10,))) == [(10,False),(None,True),(None,True),(10,False)]
assert model(((),(10,)),entry_month=2) == [(None,False),(10,False)]

engine=(ROOT/'src/Mcr.Ipp.Core/ContributionEngine.cs').read_text()
pipeline=(ROOT/'src/Mcr.Ipp.Core/Pipeline.cs').read_text()
ui=(ROOT/'src/Mcr.Ipp.Desktop/MainForm.cs').read_text()
assert 'TariffReview.Analyze' in engine and 'tariffReviewReady?.Invoke' in engine
assert 'if (row.Attc is null)' in engine and 'row.AttcSource = "BLOCKED_TARIFF_REVIEW"' not in engine
assert 'if (effective is not (98 or 99))' in engine
assert 'row.Amount = row.TariffReviewRequired ? null' in engine
assert 'ReviewTariffIssues=true, AllowMissingTariff=false' in ui
assert 'allowMissingTariff.Checked' not in ui
assert 'PARTIAL_PERSON_AND_TARIFF_REVIEW_REQUIRED' in pipeline
assert 'TariffReview.Write(stage, report)' in pipeline
assert engine.index('tariffReviewReady?.Invoke') < engine.index('foreach (var month in months)')
writer=(ROOT/'src/Mcr.Ipp.Core/Spreadsheet.cs').read_text()
style=re.search(r'<styleSheet.*?</styleSheet>',writer,re.S).group(0)
xml=ET.fromstring(style); ns={'x':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
for tag in ('fonts','fills','borders','cellStyleXfs','cellXfs','cellStyles'):
    e=xml.find('x:'+tag,ns); assert int(e.attrib['count'])==len(e)
fills=len(xml.find('x:fills',ns))
for e in xml.find('x:cellXfs',ns): assert int(e.attrib['fillId'])<fills
assert len(xml.find('x:cellXfs',ns))==6
assert xml.find('x:cellXfs',ns)[5].attrib['fillId']=='3'
assert xml.find('x:cellXfs',ns)[5].attrib['numFmtId']=='4'

# Independent synthetic salary model, NOT executing the C# implementation.
# None tariff does not mask salary. Only explicit 98/99 does so.
def salaries(baseline, months):
    out={}
    for m, raw, tariff in months:
        value=raw if tariff not in (98,99) else None
        if value is None:
            value=baseline if m==1 else out.get(m-1)
        out[m]=None if tariff in (98,99) else value
    return out
salary_examples=[
    (8000,[(1,None,None)],{1:8000}),
    (8000,[(1,9750,None)],{1:9750}),
    (8000,[(1,None,None),(2,None,10)],{1:8000,2:8000}),
    (8000,[(1,None,None),(2,None,None),(3,None,10)],{1:8000,2:8000,3:8000}),
    (8000,[(1,None,98)],{1:None}),
    (8000,[(1,8000,99),(2,None,10)],{1:None,2:None}),
    (8000,[(1,8000,99),(2,9200,10)],{1:None,2:9200}),
    (None,[(1,None,None)],{1:None}),
    (8000,[(1,None,None),(3,None,10)],{1:8000,3:None}),
    (8000,[(1,None,None),(2,8200,99)],{1:8000,2:None}),
]
for baseline,monthly,expected in salary_examples:
    assert salaries(baseline,monthly)==expected
report={'schema':'MCR_IPP_TARIFF_POLICY_MODEL_CHECKS_V1','status':'PASS_MODEL_AND_STATIC_ONLY',
        'syntheticStateSequences':sequences,'prefixAndSafetyAssertions':checks,
        'handPickedExamples':4,'salaryFallbackExamples':len(salary_examples),'version':'0.3.0','sourceWiringChecks':'PASS_STATIC_ONLY',
        'embeddedStylesheetXml':'PASS_STRUCTURE_ONLY',
        'csharpExecuted':False,'windowsUiExecuted':False,'excelRendered':False,'realDataExecuted':False,
        'limitations':'Independent policy model is not a C# execution result or business authorization.'}
(ROOT/'evidence/tariff_policy_model_checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
