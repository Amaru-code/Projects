# Synthetischer Testbestand

12 erfundene Personen 1001–1012, Januar bis Juni 2026. Keine Echtdaten und keine
referenzfähigen wirtschaftlichen Leistungszusagen. `Bestand_Synthetisch.xlsx` wurde
unabhängig vom C#-Writer mit artifact_tool erzeugt.

Die Fälle zeigen reguläre Beiträge, 99→10, 10→98→10, AUGUAN-Austritt, Eintritt im Mai,
ATTC-Fallback, Teilzeit, mehrere Tarifwechsel, TZG=0, doppelte TXT-Zeilen und fehlende
ATTC-Wiederaufnahme nach Sperre. Dies ist kein fertiger IPP-LNW-Golden-Datensatz.

Die Demo kann über die Oberfläche oder DEMO.cmd gestartet werden. Sie braucht kein
Excel und kein Python im Betrieb. Erwartete Struktur: 12 Personen, 6 Monate, keine
produktiven LNW-PDFs. Seit V0.3.0 erzeugt DEMO.cmd zusaetzlich interne
PDF-Beitragsentwuerfe fuer diese 12 erfundenen Personen. Offene/leere Monatswerte
bleiben markiert; dies sind keine Versicherungs- oder Rentenbescheinigungen. Testdetails und Referenzbeträge siehe tests und reference.
