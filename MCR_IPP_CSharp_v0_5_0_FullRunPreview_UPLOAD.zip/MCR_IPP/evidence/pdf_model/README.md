# Synthetische Layoutmodell-Pruefung

Die drei PDFs in diesem Ordner wurden mit dem unabhaengigen Python-Modell
`scripts/check_pdf_layout_model.py` erzeugt, NICHT mit dem C#-Programm. Sie
belegen nur, dass das nachgebildete PDF-Format und Layout renderbar sind.
Alle Personen und Zahlen sind erfunden; keine finanzielle Berechnungsreferenz.

Ein-/Mehrseiten wurden mit PyMuPDF gerendert, Textgrenzen programmatisch
geprueft und ausgewaehlte PNGs visuell gelesen. Die Einseite mit offenem Tarif
wurde zusaetzlich ueber den PDF-Skill-Renderer gerendert und visuell geprueft.
Keine C#-Ausfuehrung, Windows-UI- oder IPP-LNW-Qualifikation. Keine Fontdateien.

Die produktiven internen Entwurfsdateien entstehen erst beim lokalen
`START.cmd`-Build und anschliessenden neuen Beitraglauf mit PDF-Option.
