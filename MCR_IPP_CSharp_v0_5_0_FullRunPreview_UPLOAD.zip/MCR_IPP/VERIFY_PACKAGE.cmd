@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "ERRORLEVEL="
cd /d "%~dp0"
if not "%errorlevel%"=="0" goto failed
powershell.exe -NoLogo -NoProfile -File "%~dp0scripts\Verify-Package.ps1"
set "IPP_VERIFY_RC=%errorlevel%"
if not "%IPP_VERIFY_RC%"=="0" goto failed
pause
exit /b 0
:failed
echo Verification failed or local script policy blocked execution. Do not change company policies.
pause
exit /b 1
