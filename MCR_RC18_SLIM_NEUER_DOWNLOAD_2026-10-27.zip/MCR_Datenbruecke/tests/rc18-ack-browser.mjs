/** Browser proof: a prior COMARCH acknowledgement must be detected BEFORE
 * fixed-field or editor writes, and must never be sent twice. */
import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';import os from 'node:os';
import {spawn} from 'node:child_process';import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const temp=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC18-ACK-'));
try{
 for(const dir of ['src','lib','config','examples'])fs.cpSync(path.join(root,dir),path.join(temp,dir),{recursive:true});
 const conf=path.join(temp,'config/local-runner-queue-send.json');const cfg=JSON.parse(fs.readFileSync(conf));
 Object.assign(cfg,{runtimeDirectory:'.runtime',profileDirectory:'.runtime/edge-profile',downloadDirectory:'.runtime/downloads',diagnosticDirectory:'diagnostics'});fs.writeFileSync(conf,JSON.stringify(cfg,null,2)+'\n');
 const {code,out}=await new Promise((resolve,reject)=>{
  let out='';const proc=spawn(process.execPath,[path.join(temp,'src/local-bot-full-run.mjs'),'--demo','--close-browser'],{cwd:temp,env:{...process.env,MCR_DEMO_SCENARIO:'rc18-existing-ack'},stdio:['ignore','pipe','pipe']});
  proc.stdout.on('data',b=>out+=b.toString());proc.stderr.on('data',b=>out+=b.toString());
  const timer=setTimeout(()=>proc.kill(),90000);proc.on('error',reject);proc.once('exit',code=>{clearTimeout(timer);resolve({code,out});});
 });
 const d=JSON.parse(fs.readFileSync(path.join(temp,'diagnostics/last-result.json'),'utf8'));
 assert.notEqual(code,0);assert.equal(d.lastError,'REPLY_ALREADY_IN_HISTORY');
 assert.equal(d.send.clicked,false);assert.equal(d.save.clicked,false);assert.equal(d.loop.processed,0);
 assert.ok(out.includes('NAME_DISCOVERY: HISTORY_DOM_CURRENT'));
 assert.ok(!out.includes('PASS FIXED_FIELDS_ALL_VERIFIED'));
 console.log('PASS RC18_HISTORY_PREEXISTING_ACK_STOP_BEFORE_FIELD_EDITOR_SEND_SAVE');
}finally{fs.rmSync(temp,{recursive:true,force:true,maxRetries:8,retryDelay:200});}
