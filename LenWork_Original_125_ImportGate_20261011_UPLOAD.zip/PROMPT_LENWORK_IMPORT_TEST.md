# LenWork: 125 synthetische Mails - Import-/Verarbeitungstest

Benutze ausschliesslich meinen bereits vorhandenen ORIGINAL-Skill `inbox-urlaub-rueckblicke-v2` und dessen ORIGINAL-Datei `absender.md`. Aendere keine Prioritaetsdefinitionen, keine Absenderregeln, keine Step-2-/Step-3-/Step-4-Anweisungen.

Dies ist ausschliesslich ein OFFLINE-TEST fuer die Uebernahme und die vollstaendige Verarbeitung von 125 Testnachrichten. Die mitgelieferten Daten sind 100% synthetisch und stammen NICHT aus Outlook. Rufe `msgraph_email` fuer diesen Test NICHT auf. Schreibe nichts in Outlook.

Lies `manifest.json` und die fuenf Dateien `mail_batch_0001.md` bis `mail_batch_0005.md` vollstaendig. Die Dateien bilden eine synthetische Nachbildung des lokalen PowerShell-Exports mit jeweils 25 Nachrichten; alle Nachrichten tragen `is_unread=true` und liegen am 11.10.2026. Falls du die .jsonl-Dateien fuer eine Programmpruefung ebenfalls hochgeladen bekommst: Sie spiegeln EXAKT dieselben Nachrichten wie die .md-Dateien wider; nicht doppelt zaehlen.

Prüfe die fuenf Batch-Zahlen und die 125 eindeutigen `message_id`-Werte. Verarbeite alle Nachrichten mit den unveraenderten Priorisierungsregeln des Original-Skills in Gruppen von hoechstens 25. Gib eine Prioritaetenuebersicht in Deutsch aus. Wenn Metadaten/Vorschau fuer einzelne Faelle keine sichere Handlungsempfehlung erlauben, schreibe `unklar` statt eine Aufgabe zu erfinden. Die originalen vier Kategorien ROT/GELB/BLAU/WEISS bleiben verbindlich.

Erstelle ZUSAETZLICH einen knappen rein technischen Bericht OHNE Einzeldaten:
- INPUT_SOURCE=SYNTHETIC_FIXTURE
- INPUT_COUNT (Soll 125)
- UNIQUE_COUNT
- ANALYZED_COUNT
- CLASSIFIED_COUNT
- MISSING_COUNT
- DUPLICATE_COUNT
- BATCH_COUNT (Soll 5)
- CATEGORY_SUM (muss insgesamt 125 ergeben, wenn alle klassifiziert wurden)
- INPUT_STATUS und ANALYSIS_STATUS
- `IMPORT_125_PASS` NUR, wenn 125 eindeutige Nachrichten tatsaechlich eingelesen, im Ledger beruecksichtigt und ohne Luecken verarbeitet wurden.

Bei Tool-/Dateibeschraenkungen eindeutig `IMPORT_INCOMPLETE` melden, NICHT behaupten, es seien 125 Nachrichten verarbeitet worden. Ausgabe der originalen Prioritaeten unveraendert.
