# LenWork Original-Skill – 125er Import-Gate

Dieses Paket enthaelt **125 vollstaendig synthetische, ungelesene E-Mails**, die alle am selben Kalendertag (11.10.2026) liegen. Damit wird die **Dateiuebergabe und Verarbeitung** in LenWork unabhaengig vom 50er-Limit des Outlook-Connectors getestet. Es werden keine realen Nachrichten oder Zugangsdaten verteilt.

## Unveraendert

Der produktive Original-Skill und `absender.md` werden NICHT geaendert. Auch keine neue Python/JavaScript-Priorisierung! Die Dateien emulieren ausschliesslich die Ausgabe von `Export-InboxReadOnly.ps1` als Batchformat.

## Testabfolge

1. Im internen genehmigten LenWork-Chat den Original-Skill auswaehlen.
2. `manifest.json` und `batches/mail_batch_0001.md` bis `_0005.md` hochladen. Falls es moeglich und notwendig ist, koennen stattdessen alle fuenf `.jsonl`-Dateien zusammen mit dem Manifest hochgeladen werden – jede Mail nur einmal zaehlen.
3. Den Text aus `PROMPT_LENWORK_IMPORT_TEST.md` einfuegen.
4. Nur den anonymen technischen Bericht mit `IMPORT_125_PASS` bzw. `IMPORT_INCOMPLETE` hierher zurueckgeben.
5. Erst nach echtem `IMPORT_125_PASS` mit 125/125 den Priority-Mail-Generator fuer den Live-Inbox-Integrationstest verwenden.

**Nicht verwechseln:** Dieser Test bestaetigt KEINEN automatischen Zugriff des LenWork-Chats auf lokale Outlook-Dateien. Ohne lokal freigegebenen Connector / Bridge bleibt der Ablauf: lokales COM-Skript ausfuehren, im genehmigten LenWork-Workspace Dateien bereitstellen, dann original priorisieren.

## Live-Test nach Import-PASS

Mit dem bestaetigten `Export-InboxReadOnly.ps1` den gewuenschten Tag bzw. die letzten 14 Tage mit `-UnreadOnly -BatchSize 25` exportieren, lokal `verify_export.py` ausfuehren und die Batchdateien + Manifest nur in den genehmigten LenWork-Workspace hochladen. Keine Nachricht als gelesen markieren, keine echten E-Mails hier hochladen.
