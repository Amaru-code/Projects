#!/usr/bin/env python3
"""Pure standard-library verifier for the synthetic fixture, never accesses Outlook."""
import json, pathlib, hashlib, sys

def check(root):
    root=pathlib.Path(root).resolve()
    m=json.loads((root/'manifest.json').read_text(encoding='utf-8'))
    assert m['schema']=='LENWORK_SYNTHETIC_INBOX_EXPORT_V1' and m['test_data_only'] is True
    assert m['source']=='synthetic_fixture' and m['status']=='SYNTHETIC_FIXTURE_COMPLETE'
    assert m['unread_only'] is True and m['batch_count']==5 and m['unique_records']==125
    ids=set(); nd=0
    files=m['files']; assert len(files)==10
    paths={}
    for f in files:
        name=f['path']; p=pathlib.PurePosixPath(name)
        assert not p.is_absolute() and '..' not in p.parts and p.parts[0]=='batches'
        data=(root/name).read_bytes(); assert hashlib.sha256(data).hexdigest()==f['sha256']
        paths[name]=f
        if f['format']=='jsonl':
            rows=[json.loads(x) for x in data.decode('utf-8').splitlines() if x.strip()]
            assert len(rows)==f['records']==25
            for row in rows:
                assert row['source']=='synthetic_fixture' and row['folder']=='inbox'
                assert row['is_unread'] is True and row['received_at_local'].startswith('2026-10-11')
                assert row['message_id'] not in ids
                ids.add(row['message_id']); nd+=1
        elif f['format']=='md':
            assert data.decode('utf-8').count('```json')==f['records']==25
        else: raise AssertionError('unknown format')
    assert nd==125 and len(ids)==125
    assert len({p for p in paths})==10
    print(f'SYNTHETIC_FIXTURE_PASS: UNIQUE={nd} BATCHES=5 FILES=10')

if __name__=='__main__':
    check(sys.argv[1] if len(sys.argv)>1 else pathlib.Path(__file__).parent)
