import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';
import {temp,mapping,putActive} from './helpers.mjs';
import {withPhase2Browser,installPhase2Fixture} from './rc52-browser-fixture.mjs';
import {openTicket} from '../lib/browser-workflow.mjs';import {openPhase2Ticket} from '../lib/phase2-navigation.mjs';
import {phase2Journal} from '../lib/phase2-write-journal.mjs';import {phase2WorkJournal} from '../lib/phase2-work-journal.mjs';
import {readPhase2Queue,phase2Inventory} from '../lib/phase2-readonly.mjs';
import {writeJSON} from '../lib/control.mjs';import {inspectExistingStatements} from '../lib/phase2-pdf-evidence.mjs';
import {preflightPhase2Write,phase2ComarchPilot} from '../src/phase2-comarch-pilot.mjs';
import {handlePhase2Work} from '../src/phase2-work-handler.mjs';
import {PRIVATE_MBC_REQUEST,privateMbcDraft} from '../lib/phase2-work-rules.mjs';
import {finishPhase2Route} from '../lib/phase2-review-flow.mjs';
const member=async()=>({profileVerified:true,profile:{first:'Max',last:'Mustermann',mercerId:'99900001'},wwid:'11368989'});
const noAsk=async q=>{throw Error('UNEXPECTED_PROMPT: '+q);};

test('RC52 Chromium reproduces old QUEUE_OPEN on repeated reference text; scoped ticket column opens once',{timeout:25000},()=>withPhase2Browser(async page=>{
 await installPhase2Fixture(page,[{ticketId:'87278094',description:'USC 1/ DC'}],{duplicateReference:true});
 const r=(await readPhase2Queue(page)).rows[0];
 await assert.rejects(()=>openTicket(page,r),e=>e.code==='QUEUE_OPEN');assert.equal(await page.eval('_counts.open'),0);
 await openPhase2Ticket(page,r);assert.equal(await page.eval('_counts.open'),1);assert.equal(await page.eval('_current'),r.ticketId);
}));

test('RC52 Chromium passive wait clears temporary overlay, exactly one row click; duplicate rows remain blocked',{timeout:25000},()=>withPhase2Browser(async page=>{
 await installPhase2Fixture(page,[{ticketId:'87278094',description:'USC 1/ DC'}]);
 await page.call(()=>{const n=document.createElement('div');n.id='veil';n.style='position:fixed;inset:0;background:#ddd;z-index:99';document.body.append(n);setTimeout(()=>n.remove(),650);});
 await openPhase2Ticket(page,{ticketId:'87278094'});assert.equal(await page.eval('_counts.open'),1);
 await page.call(()=>{_server.push({..._server[0]});showQueue();});
 await assert.rejects(()=>openPhase2Ticket(page,{ticketId:'87278094'},{timeoutMs:250}),e=>e.code==='P2_QUEUE_OPEN');assert.equal(await page.eval('_counts.open'),1);
}));

test('RC52 Chromium exact RC51 pending readback -> review dropdown -> next persona -> one execute; zero new saves/uploads',{timeout:50000},()=>withPhase2Browser(async page=>{
 const parent=temp(),root=path.join(parent,'MCR_Datenbruecke');fs.mkdirSync(root);putActive(root);
 const original='USC 100/ DC;PP+\nStandardantwort versendet\nMöchte Kontoauszug';const id='87278094',names=['11368989_Kontoauszug_DC.pdf','11368989_Kontoauszug_PP+.pdf'];
 try{
  const dir=path.join(root,'.runtime','phase2');fs.mkdirSync(dir,{recursive:true});
  for(const [plan,folder] of [['DC','Kontoauszug_DC'],['PP+','Kontoauszug_pp+']]){const dest=path.join(parent,folder,'Ausgabe_PDF');fs.mkdirSync(dest,{recursive:true});fs.writeFileSync(path.join(dest,'11368989_Kontoauszug_'+plan+'.pdf'),'%PDF-1.4\n'+plan+' '.repeat(240)+'\n%%EOF\n');}
  const proof={...inspectExistingStatements(root,['DC','PP+'],'11368989'),ticketId:id,operatorContentReviewed:true,operatorPersonTicketBindingReviewed:true};
  writeJSON(path.join(dir,'MCR_PHASE2_PDF_BELEG_'+id+'_2026-11-03.json'),proof);
  writeJSON(path.join(dir,'MCR_PHASE2_LETZTE_INVENTUR.json'),phase2Inventory([{ticketId:id,source:'E-MAIL',descriptionValue:original}]));
  const p=preflightPhase2Write(root,id);p.journal.begin();
  for(const state of ['UPLOAD_INTENT','UPLOAD_VERIFIED','GEVO_INTENT','GEVO_VERIFIED','DESCRIPTION_INTENT','DESCRIPTION_VERIFIED','DRAFT_SAVE_INTENT','DRAFT_SAVE_VERIFIED','TICKET_SAVE_INTENT'])p.journal.advance(state);
  p.journal.approveTicketSaveRecovery({...p.initial,operatorConfirmed:true,noPriorClick:true,ticketUnchanged:true,attachmentsReviewed:true,notForwarded:true});
  p.journal.recordTicketSaveGevoRepairIntent({observedValue:''});p.journal.recordTicketSaveGevoRepairVerified();p.journal.recordTicketSaveAutoClickIntent();p.journal.recordTicketSaveNetworkObservation({status:'NETWORK_QUIET',writeStarts:2});
  const prefix=p.journal.read().events;
  await installPhase2Fixture(page,[{ticketId:id,description:original+'\nBearbeitet not reviewed',gevo:'Anfrage Member',pdfs:names}],{duplicateReference:true});
  writeJSON(path.join(dir,'MCR_PHASE2_LETZTE_INVENTUR.json'),phase2Inventory((await readPhase2Queue(page)).rows));
  assert.equal(preflightPhase2Write(root,id).recoveryMode,'SERVER_READBACK_ONLY');
  let prompts=0;const result=await phase2ComarchPilot({root,ticketId:id,session:{page,rl:{}},memberLookup:member,reviewAuthorized:true,log:()=>{},askFn:async(_rl,q)=>{
   assert(q.includes('Gespeicherte PDFs geprueft?'),q);prompts++;return 'GESPEICHERTE_PDFS_GEPRUEFT';
  }});
  assert.equal(result.status,'ROUTED_VERIFIED');assert.equal(prompts,1);
  assert.deepEqual(await page.eval('_counts'),{open:1,save:0,draft:0,review:1,direct:0,send:0,upload:0});
  assert.equal(p.journal.read().state,'ROUTED_VERIFIED');assert.deepEqual(p.journal.read().events.slice(0,prefix.length),prefix);
  assert.equal((await page.eval('_routeInfo'))[0].field,'mainForm:next-persona-assignment-id');
 }finally{fs.rmSync(parent,{recursive:true,force:true});}
}));

test('RC52 Chromium DB direct rule saves marker and uses persona-assignment/current-performer, not review or mail',{timeout:45000},()=>withPhase2Browser(async page=>{
 const root=temp();try{
  await installPhase2Fixture(page,[{ticketId:'87278095',description:'USC 100/ DB+\nStandardantwort versendet'}],{duplicateReference:true});
  const row=(await readPhase2Queue(page)).rows[0];
  const result=await handlePhase2Work({root,page,row,mapping:mapping(),ask:noAsk,log:()=>{},memberLookup:member});
  assert.equal(result.status,'ROUTED_VERIFIED');assert.equal(result.route,'DIRECT');
  assert.deepEqual(await page.eval('_counts'),{open:2,save:1,draft:0,review:0,direct:1,send:0,upload:0});
  const info=(await page.eval('_routeInfo'))[0];assert.equal(info.field,'mainForm:persona-assignment-id');assert.equal(info.mode,'');
  assert.equal(await page.eval('_server[0].description'),'USC 100/ DB+\nStandardantwort versendet\nBearbeitet not reviewed');
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));

test('RC52 Chromium private MBC exact user draft persisted before review, one draft/save/execute, no mail',{timeout:50000},()=>withPhase2Browser(async page=>{
 const root=temp();try{
  await installPhase2Fixture(page,[{ticketId:'87278096',description:'USC 100/ DC\nStandardantwort versendet\n'+PRIVATE_MBC_REQUEST}]);
  const result=await handlePhase2Work({root,page,row:(await readPhase2Queue(page)).rows[0],mapping:mapping(),ask:noAsk,log:()=>{},memberLookup:member});
  assert.equal(result.status,'ROUTED_VERIFIED');assert.equal(result.route,'REVIEW');
  assert.deepEqual(await page.eval('_counts'),{open:2,save:1,draft:1,review:1,direct:0,send:0,upload:0});
  assert.equal((await page.eval('_server[0].draft')).replace(/\n{3,}/g,'\n\n'),privateMbcDraft({lastName:'Mustermann',gender:'M'}));
  assert.equal(phase2WorkJournal(root,'87278096').read().state,'ROUTED_VERIFIED');
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));

test('RC52 Chromium next ticket follows first confirmed routing in same browser; no duplicate execution',{timeout:65000},()=>withPhase2Browser(async page=>{
 const root=temp();try{
  await installPhase2Fixture(page,[{ticketId:'87278095',description:'USC 100/ DB\nStandardantwort versendet'},{ticketId:'87278096',description:'USC 100/ DC\nStandardantwort versendet\n'+PRIVATE_MBC_REQUEST}]);
  for(const id of ['87278095','87278096']){
   const q=await readPhase2Queue(page);assert(q.ok);assert.equal(q.rows[0].ticketId,id);
   const result=await handlePhase2Work({root,page,row:q.rows[0],mapping:mapping(),ask:noAsk,log:()=>{},memberLookup:member});assert.equal(result.status,'ROUTED_VERIFIED');
  }
  assert.deepEqual((await readPhase2Queue(page)).rows,[]);assert.deepEqual(await page.eval('_routeInfo.map(r=>r.id)'),['87278095','87278096']);assert.equal(await page.eval('_counts.send'),0);
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));

import {phase2Run} from '../src/phase2-run.mjs';
test('RC52 Chromium actual Menu-12 orchestration refreshes inventory and completes two cases automatically',{timeout:65000},()=>withPhase2Browser(async page=>{
 const root=temp();putActive(root);try{
  await installPhase2Fixture(page,[{ticketId:'87278095',description:'USC 100/ DB\nStandardantwort versendet'},{ticketId:'87278096',description:'USC 100/ DC\nStandardantwort versendet\n'+PRIVATE_MBC_REQUEST}]);
  const prompts=[],logs=[];
  const result=await phase2Run({root,session:{page,rl:{}},memberLookup:member,log:s=>logs.push(s),askFn:async(_rl,q)=>{
   prompts.push(q);if(q.startsWith('Start-Ticket'))return '87278095';if(q.includes('Weiterleitung starten?'))return 'START';throw Error('UNEXPECTED_PROMPT: '+q);
  }});
  assert.equal(result.processed,2);assert.equal(prompts.length,2);assert.equal(result.status,'COMPLETED_VISIBLE_SCOPE');
  assert.deepEqual(result.receipts.map(x=>x.ticketId),['87278095','87278096']);assert(logs.some(x=>x.includes('P2_NAECHSTES_TICKET: 87278096')));
  assert.equal(await page.eval('_counts.send'),0);assert.equal(fs.readdirSync(path.join(root,'.runtime/phase2')).filter(x=>x.endsWith('.log')).length,1);
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));

test('RC52 Chromium occupied draft stops before editing, saving or routing',{timeout:25000},()=>withPhase2Browser(async page=>{
 const root=temp();try{
  await installPhase2Fixture(page,[{ticketId:'87278096',description:'USC 100/ DC\nStandardantwort versendet\n'+PRIVATE_MBC_REQUEST,draft:'Bestehender fremder Entwurf'}]);
  await assert.rejects(()=>handlePhase2Work({root,page,row:(()=>({ticketId:'87278096',descriptionValue:'USC 100/ DC\nStandardantwort versendet\n'+PRIVATE_MBC_REQUEST}))(),mapping:mapping(),ask:noAsk,log:()=>{},memberLookup:member}),e=>e.code==='P2_MBC_EXISTING_DRAFT');
  assert.deepEqual(await page.eval('_counts'),{open:1,save:0,draft:0,review:0,direct:0,send:0,upload:0});
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));

test('RC52 Chromium silent queue return is not fabricated as routing proof and never clicks twice',{timeout:30000},()=>withPhase2Browser(async page=>{
 const root=temp();try{
  await installPhase2Fixture(page,[{ticketId:'87278095',description:'USC 100/ DB+\nStandardantwort versendet'}],{silentRoute:true});
  const row=(await readPhase2Queue(page)).rows[0];
  await assert.rejects(()=>handlePhase2Work({root,page,row,mapping:mapping(),ask:async q=>{assert(q.includes('WEITERLEITUNG_GEPRUEFT'));return 'ABBRUCH';},log:()=>{},memberLookup:member}),e=>e.code==='P2_ROUTE_UNVERIFIED');
  assert.equal(await page.eval('_counts.direct'),1);assert.equal(await page.eval('_counts.send'),0);assert.equal(phase2WorkJournal(root,'87278095').read().state,'EXECUTE_INTENT');
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));
