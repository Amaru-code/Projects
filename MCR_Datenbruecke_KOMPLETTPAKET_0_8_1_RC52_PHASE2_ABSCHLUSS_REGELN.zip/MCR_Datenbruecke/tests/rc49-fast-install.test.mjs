import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';import {ROOT} from './helpers.mjs';
import {verifyPackage} from '../tools/integrity.mjs';
test('RC49 fast installer does not invoke any full QA/demos during Menu 1, maintains verified migration',()=>{
 const s=fs.readFileSync(path.join(ROOT,'tools/cli.mjs'),'utf8');
 const body=s.slice(s.indexOf('async function setup()'),s.indexOf('async function real('));
 assert(body.includes('beginMigrationPriority'));
 assert(body.includes('planInstall(root,target,{migration})'));
 assert(body.includes('installSoftware(p,{migration})'));
 assert(body.includes('migration.release()'));
 assert(!body.includes('await selftest()'));
 assert(!body.includes('await demo()'));
 assert(!body.includes('writeJSON(path.join(controlDir(target),\'complete-demo-pass.json\')'));
 assert(s.includes('else if(a===\'6\'){await status();await selftest();}'));
 assert(s.includes('else if(a===\'2\')await demo()'));
 assert.equal(verifyPackage(ROOT).version,'0.8.1-rc.52');
});
