import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';
import {ROOT} from './helpers.mjs';import {sha256} from '../lib/core.mjs';
import {VERSION} from '../lib/control.mjs';import {verifyPackage} from '../tools/integrity.mjs';
test('RC51 exact original RC50 manifest is pinned and only shipped software is sealed',()=>{
 assert.equal(VERSION,'0.8.1-rc.52');
 assert.equal(sha256(fs.readFileSync(path.join(ROOT,'tools/reference/complete-0.8.1-rc.50-manifest.json'))),
  '9ae83a42de963eda1e4b31ae95a1f3511ec97c4cd273667af83e93013cebe9ae');
 const manifest=JSON.parse(fs.readFileSync(path.join(ROOT,'MANIFEST.json')));
 assert.equal(manifest.version,VERSION);
 for(const pathRequired of ['tests/rc51-save-recovery.test.mjs','tests/rc51-save-persistence-browser.test.mjs','tests/rc51-upgrade.test.mjs',
  'lib/phase2-save-settle.mjs','lib/phase2-write-journal.mjs','src/phase2-comarch-pilot.mjs',
  'docs/RC51_TICKET_SAVE_AJAX_UND_RC50_WIEDERAUFNAHME.md','tools/reference/complete-0.8.1-rc.50-manifest.json'])
  assert(manifest.payload.some(x=>x.path===pathRequired),pathRequired);
 assert(manifest.payload.every(x=>!/^(private_data|\.runtime|diagnostics|reports|Ergebnis)\//i.test(x.path)&&!x.path.endsWith('.zip')));
 assert.equal(verifyPackage(ROOT).version,VERSION);
});
