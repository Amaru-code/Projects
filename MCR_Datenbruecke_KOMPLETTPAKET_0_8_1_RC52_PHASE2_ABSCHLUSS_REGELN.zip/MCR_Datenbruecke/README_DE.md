# MCR Datenbruecke 0.8.1-rc.52

Vollständiges Softwarepaket. Produktivdaten, Mapping, Konfiguration, Browserprofil
und Laufjournale bleiben bei der Installation an ihrem bisherigen Ort.

## Start
1. Vollständiges ZIP in einen NEUEN Ordner außerhalb der Installation entpacken.
2. Neue START.cmd öffnen, Menü 1, vorhandene Installation übernehmen.
3. Nach PASS INSTALLATION_COMPLETE die installierte START.cmd verwenden.
4. Menü 12: Startticket eingeben, anmelden, START. Inventur erfolgt automatisch.

Menü 1 ist die Schnellinstallation ohne lange Tests/Demos. Menü 6 bietet die
Selbsttests, Menü 2 die fiktiven Browserproben. Eine feste Installationsdauer
wird nicht zugesichert; Dateiprüfungen, Sicherung und Prozesskontrolle bleiben.

## Phase 2
- Kontoauszug mit bereits geprüften DC-/PP+-PDFs und Prüfschritt an Mark Baindl.
- DB/DB+ in Zeile 1 und Standardantwort versendet in Zeile 2: direkte Weiterleitung.
- Exakte private-MBC-Anfrage in Zeile 3: vorgegebener Antwortentwurf zur Prüfung.
- Alle Wege: Anfrage Member, Bearbeitet not reviewed; kein E-Mail-Versand.
- Nach verifiziertem Abschluss: automatisch nächstes passendes sichtbares Ticket.
- RC51-Speicherklick + QUEUE_OPEN: nur Serverzustand nachlesen, nicht erneut speichern.

Details: docs/RC52_PHASE2_ABSCHLUSS_UND_REGELN.md.
Prüfstand: docs/RC52_PRUEFBERICHT.json. Echte COMARCH-Abnahme bleibt offen.
