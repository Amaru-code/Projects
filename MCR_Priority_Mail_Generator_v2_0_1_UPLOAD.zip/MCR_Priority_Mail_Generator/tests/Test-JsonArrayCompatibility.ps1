﻿#requires -Version 5.1
[CmdletBinding()]
param()
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$script:JsonArrayAssertions = 0

function Assert-JsonArrayCondition {
    param([bool]$Condition, [string]$Message)
    $script:JsonArrayAssertions++
    if(-not $Condition){throw ('FAIL JSON array compatibility: '+$Message)}
}

function Write-LegacyArrayContainer {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][object[]]$Rows)
    # Model the non-enumerating output contract of ConvertFrom-Json in PS 5.1.
    # This is a local test function; no aliases or built-in commands are replaced.
    $PSCmdlet.WriteObject($Rows, $false)
}

function Write-EnumeratedArrayRows {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][object[]]$Rows)
    foreach($row in $Rows){$PSCmdlet.WriteObject($row, $false)}
}

function Assert-FlatRows {
    param([object[]]$Actual, [int]$ExpectedCount, [string]$Label)
    Assert-JsonArrayCondition ($Actual.Count -eq $ExpectedCount) ($Label+': expected '+$ExpectedCount+', actual '+$Actual.Count)
    for($i=0; $i -lt $ExpectedCount; $i++){
        Assert-JsonArrayCondition ($Actual[$i] -is [System.Management.Automation.PSCustomObject]) ($Label+': flat object row '+$i)
        Assert-JsonArrayCondition ($Actual[$i].Id -eq $i) ($Label+': row order '+$i)
        Assert-JsonArrayCondition (@($Actual[$i].To).Count -eq 2) ($Label+': nested recipient array retained '+$i)
        Assert-JsonArrayCondition (@($Actual[$i].Cc).Count -eq 0) ($Label+': empty nested CC array retained '+$i)
        Assert-JsonArrayCondition ($Actual[$i].Body -ceq 'Hallo First,') ($Label+': scalar body retained '+$i)
    }
}

foreach($count in @(1,2,21,24)){
    $rows = @(for($i=0; $i -lt $count; $i++){
        [pscustomobject][ordered]@{Id=$i;To=@('first.last@example.test','second.person@example.test');Cc=@();Body='Hallo First,'}
    })

    # Regression witness: the old expression counts containers, not records.
    $old = @(Write-LegacyArrayContainer -Rows $rows)
    Assert-JsonArrayCondition ($old.Count -eq 1) 'Original wrapping error is reproducible'
    Assert-JsonArrayCondition ($old[0] -is [System.Array]) 'Original output contains an array as one item'
    Assert-JsonArrayCondition ($old[0].Length -eq $count) 'No records lost; original wrapper counts the wrong level'

    # The exact grouping used by Test-Integration works with both output contracts.
    $legacy = @((Write-LegacyArrayContainer -Rows $rows))
    Assert-FlatRows -Actual $legacy -ExpectedCount $count -Label 'Legacy container, corrected expression'
    $enumerated = @((Write-EnumeratedArrayRows -Rows $rows))
    Assert-FlatRows -Actual $enumerated -ExpectedCount $count -Label 'Enumerated rows, corrected expression'

    # Also test the real cmdlet on the user's installed runtime, not just the model.
    $json = ConvertTo-Json -InputObject $rows -Depth 6
    $native = @((ConvertFrom-Json -InputObject $json))
    Assert-FlatRows -Actual $native -ExpectedCount $count -Label 'Native ConvertFrom-Json'
}
Write-Host ('PASS JSON array compatibility: '+$script:JsonArrayAssertions+' assertions; legacy container, enumerated rows and native JSON; no Outlook used.')
