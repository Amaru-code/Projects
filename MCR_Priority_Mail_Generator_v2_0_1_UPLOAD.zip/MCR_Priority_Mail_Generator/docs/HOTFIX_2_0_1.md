﻿# Hotfix 2.0.1: JSON-Listen im Integrationstest

## Fehler

`FAIL Integration: Offline 24 messages / 21 cases` unmittelbar nach einem
Exportergebnis mit den korrekten Zahlen 21 / 24.

Der Fehler liegt in der Testdatei `tests/Test-Integration.ps1`, nicht in der
Definition der vier Prioritaeten und nicht im Outlook-Versand.
Windows PowerShell 5.1 gibt das gesamte JSON-Array als ein Pipelineobjekt
aus. Die alte Array-Subexpression packte dieses in eine weitere Liste.

```powershell
# Alt: 1 Container, nicht 24 Datensaetze (unter Windows PowerShell 5.1)
$inputs = @(ConvertFrom-Json -InputObject $json)

# Neu: die Datensaetze werden aus dem ausgewerteten Ausdruck gesammelt
$inputs = @((ConvertFrom-Json -InputObject $json))
```

Dasselbe ist fuer `$oracle` korrigiert. Nicht einfach `.Count` gegen 1
vergleichen oder die Pruefung entfernen: Auch die nachfolgenden Tests
brauchen die einzelnen Nachrichten bzw. Sollfallobjekte.

## Umfang

Die Sollzahlen bleiben 24 Nachrichten / 21 Faelle. Sie werden jetzt einzeln
mit Soll/Ist geprueft. Zusaetzlich muessen alle Zeilen flache JSON-Objekte
sein und die erwartete ID-/Scope-Eigenschaft besitzen.

Der neue Test `Test-JsonArrayCompatibility.ps1` prueft:
- die urspruengliche falsche Verschachtelung als Negativbeleg;
- die korrigierte Klammerung mit nicht enumerierendem Ausgabe-Verhalten;
- enumerierendes Ausgabe-Verhalten;
- echtes ConvertFrom-Json auf der aufrufenden PowerShell-Runtime;
- 1, 2, 21 und 24 Eintraege sowie unveraenderte To-/CC-Unterarrays.

Keine System-Cmdlets werden ersetzt, keine Outlook-Verbindung wird aufgebaut.
Die modellierte Array-Ausgabe ist kein Ersatz fuer einen nativen PS-5.1-Test.

## Bestehende Installation

Generator schliessen, die bestehenden Programmdateien sichern und die fuenf
in LIES_MICH.txt genannten Dateien ersetzen bzw. hinzufuegen. Eigene
`absender.md`, `config`, `data` und `Output` bleiben dabei erhalten.
Ein vollstaendig frisches Entpacken funktioniert ebenfalls; persoenliche
Konfigurationen dann bewusst aus der alten Installation uebernehmen.

`SELBSTTEST.cmd` ausfuehren. Erwartete neue Erfolgsmeldung:

```text
PASS Integration: Offline 24 messages / 21 cases; flat JSON arrays verified.
```

Danach muessen auch die weiteren Pruefungen und `SELBSTTEST=PASS` erscheinen.
Erst anschliessend `STARTEN.cmd` verwenden. Keine Tests ueberspringen.

## Quelle zum PowerShell-Ausgabeverhalten

PowerShell-Projekt, Issue #3424:
https://github.com/PowerShell/PowerShell/issues/3424

Die offizielle Issue-Diskussion dokumentiert explizite Klammerung als
Workaround fuer nicht enumerierte JSON-Arrays. Das heutige NoEnumerate
wird hier absichtlich nicht verwendet: Es ist kein PS-5.1-Parameter.

## Nachweise und Grenzen

`PRUEFBERICHT.txt` trennt den Nutzerlauf, lokale statische Pruefungen und
hier nicht ausgefuehrte native Tests. Keine Regeln automatisch geaendert,
keine echten E-Mails versendet.
