﻿#requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$script:PriorityNames = @('urgent','important','info','ignore')
$script:InvariantCulture = [Globalization.CultureInfo]::InvariantCulture
$script:Utf8Bom = New-Object System.Text.UTF8Encoding($true,$true)

function ConvertTo-TestRecipients {
    [CmdletBinding()]
    param([Parameter(Mandatory = $true)][AllowEmptyString()][AllowNull()][string]$Text)

    if ([string]::IsNullOrWhiteSpace($Text)) {
        throw 'Bitte mindestens eine Empfängeradresse eingeben.'
    }
    foreach ($character in $Text.ToCharArray()) {
        if ([char]::IsControl($character) -and $character -ne [char]13 -and $character -ne [char]10) {
            throw 'Empfänger dürfen keine Steuerzeichen enthalten; als Trenner sind nur Komma, Semikolon und Zeilenumbruch erlaubt.'
        }
    }
    # Only ordinary ASCII addr-spec values, without display names, quotes or headers.
    $atom = '[A-Za-z0-9!#$%&''*+/=?^_`{|}~-]+'
    $localPattern = $atom + '(?:\.' + $atom + ')*'
    $label = '[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?'
    $pattern = '^(' + $localPattern + ')@(' + $label + '(?:\.' + $label + ')*)$'
    $seen = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    $recipients = New-Object 'System.Collections.Generic.List[string]'
    foreach ($part in [regex]::Split($Text, '[;,\r\n]+')) {
        $candidate = $part.Trim()
        if ($candidate.Length -eq 0) { continue }
        $match = [regex]::Match($candidate, $pattern, [System.Text.RegularExpressions.RegexOptions]::CultureInvariant)
        if (-not $match.Success -or $candidate.Length -gt 254 -or $match.Groups[1].Value.Length -gt 64 -or $match.Groups[2].Value.Length -gt 253) {
            throw ('Ungültige Empfängeradresse: "{0}". Bitte reine E-Mail-Adressen ohne Anzeigenamen verwenden.' -f $candidate)
        }
        $canonical = $match.Groups[1].Value + '@' + $match.Groups[2].Value.ToLowerInvariant()
        if ($seen.Add($canonical)) {
            [void]$recipients.Add($canonical)
            if ($recipients.Count -gt 20) { throw 'Pro Lauf sind höchstens 20 unterschiedliche Empfänger erlaubt.' }
        }
    }
    if ($recipients.Count -eq 0) { throw 'Bitte mindestens eine Empfängeradresse eingeben.' }
    foreach ($recipient in $recipients) { Write-Output $recipient }
}


function Get-RequiredJsonProperty {
    param([AllowNull()][object]$Object, [string]$Name, [string]$Context)
    if ($null -eq $Object -or -not ($Object -is [System.Management.Automation.PSCustomObject])) {
        throw ($Context + ' muss ein JSON-Objekt sein.')
    }
    $property = $Object.PSObject.Properties[$Name]
    if ($null -eq $property) { throw ($Context + ': Pflichtfeld "' + $Name + '" fehlt.') }
    # Return the value without unrolling arrays, including empty and one-element arrays.
    return ,$property.Value
}


function Invoke-ArrayShuffle {
    param([object[]]$Items, [System.Random]$Random)
    for ($i = $Items.Length - 1; $i -gt 0; $i--) {
        $j = $Random.Next($i + 1)
        $temporary = $Items[$i]
        $Items[$i] = $Items[$j]
        $Items[$j] = $temporary
    }
    return ,$Items
}


function ConvertTo-ExcelCsvCell {
    param([AllowNull()][object]$Value)
    $text = if ($null -eq $Value) { '' } else { [string]$Value }
    # CSV quoting alone does not prevent Excel from interpreting formula cells.
    if ($text -match '^[\s]*[=+\-@]' -or $text -match '^[\t\r\n]') { $text = "'" + $text }
    return '"' + $text.Replace('"', '""') + '"'
}


function Write-DurableUtf8File {
    param([string]$Path, [string]$Text, [bool]$Replace = $false)
    $target = [System.IO.Path]::GetFullPath($Path)
    $writePath = $target
    if ($Replace) { $writePath = $target + '.tmp-' + [guid]::NewGuid().ToString('N') }
    $stream = $null
    $writer = $null
    try {
        $stream = [System.IO.File]::Open($writePath, [System.IO.FileMode]::CreateNew, [System.IO.FileAccess]::Write, [System.IO.FileShare]::Read)
        $writer = New-Object System.IO.StreamWriter($stream, $script:Utf8Bom)
        $writer.Write($Text)
        $writer.Flush()
        $stream.Flush($true)
        $writer.Dispose()
        $writer = $null
        $stream = $null
        if ($Replace) {
            if ([System.IO.File]::Exists($target)) { [System.IO.File]::Replace($writePath, $target, [System.Management.Automation.Language.NullString]::Value) }
            else { [System.IO.File]::Move($writePath, $target) }
        }
    } finally {
        if ($null -ne $writer) { $writer.Dispose() }
        elseif ($null -ne $stream) { $stream.Dispose() }
        if ($Replace -and [System.IO.File]::Exists($writePath)) { [System.IO.File]::Delete($writePath) }
    }
}


function Write-TestMailEvent {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][string]$TestId,
        [Parameter(Mandatory = $true)][ValidateSet('planned', 'attempting', 'submitted', 'failed', 'unknown', 'cancelled')][string]$Status,
        [AllowEmptyString()][string]$Detail = ''
    )

    if ($TestId -match '[\r\n]') { throw 'Die Test-ID darf keine Zeilenumbrüche enthalten.' }
    $fullPath = [System.IO.Path]::GetFullPath($Path)
    $parentPath = [System.IO.Path]::GetDirectoryName($fullPath)
    if (-not [System.IO.Directory]::Exists($parentPath)) { throw 'Der Ordner für das Versandjournal fehlt.' }
    $entry = [pscustomobject][ordered]@{
        Timestamp = [DateTimeOffset]::UtcNow.ToString('o', $script:InvariantCulture)
        TestId = $TestId
        Status = $Status.ToLowerInvariant()
        Detail = $Detail
    }
    $line = (ConvertTo-Json -InputObject $entry -Depth 5 -Compress) + "`r`n"
    $stream = $null
    $writer = $null
    try {
        $stream = [System.IO.File]::Open($fullPath, [System.IO.FileMode]::Append, [System.IO.FileAccess]::Write, [System.IO.FileShare]::Read)
        $writer = New-Object System.IO.StreamWriter($stream, $script:Utf8Bom)
        $writer.Write($line)
        $writer.Flush()
        $stream.Flush($true)
    } finally {
        if ($null -ne $writer) { $writer.Dispose() }
        elseif ($null -ne $stream) { $stream.Dispose() }
    }
}



function Get-RecipientName {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Email)
    $addresses = @(ConvertTo-TestRecipients -Text $Email)
    if ($addresses.Count -ne 1) { throw 'Für die Namensermittlung genau eine Adresse angeben.' }
    $local = (($addresses[0] -split '@')[0] -split '\+')[0]
    $parts = @($local -split '\.')
    if ($parts.Count -lt 2) { throw 'Für die persönliche Anrede ist vorname.nachname@domain erforderlich.' }
    $culture = [Globalization.CultureInfo]::GetCultureInfo('de-DE')
    $names = @()
    foreach ($part in $parts) {
        if ($part -notmatch "^[A-Za-z]+(?:[-'][A-Za-z]+)*$") {
            throw ('Name nicht eindeutig aus der Adresse ableitbar: ' + $Email + '. Erwartet: vorname.nachname@domain.')
        }
        $names += $culture.TextInfo.ToTitleCase($part.ToLowerInvariant())
    }
    [pscustomobject]@{ Email=$addresses[0]; FirstName=$names[0]; FullName=($names -join ' ') }
}

function Get-GeneratorSettings {
    param([Parameter(Mandatory=$true)][string]$Path)
    $raw = [IO.File]::ReadAllText($Path,[Text.Encoding]::UTF8)
    $s = ConvertFrom-Json -InputObject $raw
    if ($s.schema_version -ne 1) { throw 'generator_settings.json: unbekannte Version.' }
    $days = @($s.working_days)
    if ($days.Count -eq 0 -or @($days | Where-Object { $_ -notin @(0,1,2,3,4,5,6) }).Count -gt 0) { throw 'working_days muss Wochentage 0..6 enthalten (Sonntag=0).' }
    if (@($days | Select-Object -Unique).Count -ne $days.Count) { throw 'working_days enthält Duplikate.' }
    foreach ($h in @($s.holidays)) {
        $null = [datetime]::ParseExact([string]$h,'yyyy-MM-dd',$script:InvariantCulture)
    }
    return $s
}

function Add-TestWorkingDays {
    param([datetime]$Date,[ValidateRange(-366,366)][int]$Days,[Parameter(Mandatory=$true)]$Settings)
    $d=$Date.Date
    $remaining=[Math]::Abs($Days)
    $direction=1
    if ($Days -lt 0) { $direction=-1 }
    for ($guard=0; $remaining -gt 0; $guard++) {
        if ($guard -gt 5000) { throw 'Kein gültiger Arbeitstag im Testkalender gefunden.' }
        $d=$d.AddDays($direction)
        if (@($Settings.working_days) -contains [int]$d.DayOfWeek -and @($Settings.holidays) -notcontains $d.ToString('yyyy-MM-dd')) { $remaining-- }
    }
    return $d
}

function Get-FileSha256 {
    param([string]$Path)
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Read-TestSenderRules {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Path)
    $raw=[IO.File]::ReadAllText($Path,[Text.Encoding]::UTF8)
    $rules=New-Object 'System.Collections.Generic.List[object]'
    $section=''
    foreach($line in ($raw -split '\r?\n')) {
        $t=$line.Trim()
        if($t -match '^##\s+VIP') { $section='vip';continue }
        if($t -match '^##\s+Immer.*Zur Kenntnis') { $section='info';continue }
        if($t -match '^##\s+Immer.*Ignorieren') { $section='ignore';continue }
        if($t -match '^##') { $section='';continue }
        if(-not $section -or -not $t -or $t.StartsWith('#') -or $t.StartsWith('[') -or $t.StartsWith('<!--')) { continue }
        $t=$t -replace '^[-*]\s+',''
        $field='sender'
        if($t -match '^Betreff enthält:\s*(.+)$') { $field='subject';$values=@($Matches[1] -split ',') }
        elseif($t -match '^Absender enthält:\s*(.+)$') { $field='sender';$values=@($Matches[1] -split ',') }
        else { $values=@($t) }
        foreach($v in $values) {
            $value=$v.Trim()
            if(-not $value) { throw 'Leeres Muster in absender.md.' }
            $type=$field
            if($field -eq 'sender') {
                if($value.StartsWith('@')) { $type='domain' }
                elseif($value.Contains('@')) { $type='email' }
            }
            [void]$rules.Add([pscustomobject]@{Group=$section;Field=$type;Pattern=$value})
        }
    }
    if($rules.Count -eq 0) { throw 'absender.md enthält keine aktiven Regeln oder unbekannte Überschriften.' }
    [pscustomobject]@{Rules=$rules.ToArray();Text=$raw;Sha256=(Get-FileSha256 $Path)}
}

function Get-TestRuleMatches {
    param($Rules,[string]$SenderSmtp,[string]$SenderName,[string]$Subject)
    foreach($r in $Rules.Rules) {
        $hit=$false
        switch($r.Field) {
            'email' { $hit=[string]::Equals($SenderSmtp,$r.Pattern,[StringComparison]::OrdinalIgnoreCase) }
            'domain' { $hit=$SenderSmtp.EndsWith($r.Pattern,[StringComparison]::OrdinalIgnoreCase) }
            'subject' { $hit=$Subject.IndexOf($r.Pattern,[StringComparison]::OrdinalIgnoreCase) -ge 0 }
            'sender' { $hit=($SenderSmtp+' '+$SenderName).IndexOf($r.Pattern,[StringComparison]::OrdinalIgnoreCase) -ge 0 }
        }
        if($hit) { $r }
    }
}

function Get-TestScenarioPriority {
    <# This is an oracle for declared SYNTHETIC facts, not an email NLP scanner. #>
    param($Template,$Rules,[string]$SenderSmtp='',[string]$SenderName='',[string]$Subject='')
    $matches=@(Get-TestRuleMatches -Rules $Rules -SenderSmtp $SenderSmtp -SenderName $SenderName -Subject $Subject)
    $groups=@($matches | ForEach-Object {$_.Group} | Select-Object -Unique)
    if($groups.Count -gt 1) { throw ('Widersprüchliche Absender-/Betreff-Regeln für Vorlage '+$Template.id+': '+($groups -join ', ')+'. Bitte absender.md eindeutig konfigurieren.') }
    $priority=''
    $reason=''
    if($groups -contains 'vip') {
        $priority='important'
        if($null -ne $Template.deadline_workdays -or $Template.rule -in @('DIRECT_TO','REMINDER')) { $priority='urgent' }
        $reason='VIP-Regel aus absender.md; Frage/Frist führt zu Rot, sonst mindestens Gelb.'
    } elseif($groups -contains 'info') {
        $priority='info';$reason='Immer Zur Kenntnis laut absender.md.'
    } elseif($Template.rule -eq 'PERSONAL_HR_IT') {
        $priority='important'
        if([int]$Template.deadline_workdays -le 2) { $priority='urgent' }
        $reason='Persönliche HR-/IT-Frist: ausdrückliche Ausnahme vor Ignorieren; bis 2 Arbeitstage oder überfällig Rot, sonst Gelb.'
    } elseif($groups -contains 'ignore') {
        $priority='ignore';$reason='Ignorieren nach Absender-/Betreff-Regel; keine persönliche HR-/IT-Frist in diesem Szenario.'
    } else {
        switch($Template.rule) {
            'DIRECT_TO' { $priority='urgent';$reason='Direkte Frage/Aufforderung an den An-Empfänger; bei Rot/Gelb-Überschneidung höhere Stufe.' }
            'DUE_SOON' { $priority='urgent';$reason='Explizite offene Frist innerhalb von 2 Arbeitstagen.' }
            'REMINDER' { $priority='urgent';$reason='Offene persönliche Erinnerung oder Eskalation.' }
            'STATUS' { $priority='info';$reason='Status/Entscheidung ohne offenen eigenen Auftrag.' }
            'FINISHED' { $priority='info';$reason='Szenariotext bestätigt Abschluss und nennt das erledigende Test-Team.' }
            'IGNORE_CONTENT' { $priority='ignore';$reason='Allgemeiner Newsletter, freiwilliges Werbeangebot oder Abwesenheitsmitteilung ohne Ausnahme.' }
            default { throw ('Unbekannte Szenarioregel: '+$Template.rule) }
        }
    }
    [pscustomobject]@{Priority=$priority;Reason=$reason;Matches=(@($matches | ForEach-Object {$_.Group+':'+$_.Pattern}) -join ' | ')}
}

function Assert-ScenarioText {
    param($Value,[string]$Context,[bool]$Subject=$false)
    if($Value -isnot [string] -or [string]::IsNullOrWhiteSpace($Value)) { throw ($Context+': Text fehlt.') }
    if($Subject -and ($Value.Length -gt 180 -or $Value -match '[\r\n\x00-\x1F]')) { throw ($Context+': ungültiger Betreff.') }
    if($Value -match '[\x00-\x08\x0B\x0C\x0E-\x1F]') { throw ($Context+': Steuerzeichen nicht erlaubt.') }
    $rest=[regex]::Replace($Value,'\{(?:greeting|name|full_name|email|case|project|due_date|past_date|today)\}','')
    if($rest.Contains('{') -or $rest.Contains('}')) { throw ($Context+': unbekannter Platzhalter.') }
}

function Get-TestMailTemplates {
    param([Parameter(Mandatory=$true)][string]$Path)
    $root=ConvertFrom-Json -InputObject ([IO.File]::ReadAllText($Path,[Text.Encoding]::UTF8))
    if($root.schema_version -ne 2) { throw 'Vorlagendatei: schema_version 2 erforderlich; alte V1-Vorlagen sind nicht kompatibel.' }
    $ids=New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach($p in $root.classes.PSObject.Properties) { if($p.Name -notin $script:PriorityNames) { throw ('Unbekannte Klasse: '+$p.Name) } }
    foreach($priority in $script:PriorityNames) {
        $templates=Get-RequiredJsonProperty $root.classes $priority 'classes'
        if($templates -isnot [array] -or $templates.Count -eq 0) { throw ('Vorlagen fehlen: '+$priority) }
        foreach($t in $templates) {
            foreach($key in @('id','subject','body','rule','deadline_workdays','recipient_role','done')) { $null=Get-RequiredJsonProperty $t $key 'Vorlage' }
            if($t.id -notmatch '^[A-Z][A-Z0-9_-]{1,30}$' -or -not $ids.Add([string]$t.id)) { throw ('Ungültige/doppelte Vorlagen-ID: '+$t.id) }
            Assert-ScenarioText $t.subject ('Betreff '+$t.id) $true
            Assert-ScenarioText $t.body ('Text '+$t.id)
            if(-not $t.body.StartsWith('{greeting}')) { throw ('Vorlage '+$t.id+' muss mit {greeting} beginnen.') }
            if($t.recipient_role -notin @('to','cc')) { throw 'recipient_role muss to oder cc sein.' }
            if($t.recipient_role -eq 'cc' -and $priority -ne 'info') { throw 'CC-only nur für blaue Statusszenarien erlaubt.' }
            if($t.done -isnot [bool]) { throw 'done muss ein JSON-Boolean sein.' }
            if($t.rule -notin @('DIRECT_TO','DUE_SOON','REMINDER','PERSONAL_HR_IT','STATUS','FINISHED','IGNORE_CONTENT')) { throw ('Unbekannte Regel '+$t.rule) }
            if($t.rule -in @('DUE_SOON','PERSONAL_HR_IT')) {
                if($null -eq $t.deadline_workdays -or ($t.deadline_workdays -isnot [int] -and $t.deadline_workdays -isnot [long]) -or [Math]::Abs($t.deadline_workdays) -gt 10) { throw 'Fristszenario benötigt ganze deadline_workdays zwischen -10 und 10.' }
            } elseif($null -ne $t.deadline_workdays) { throw 'Diese Szenarioregel erlaubt keine versteckte Frist.' }
            if($t.rule -eq 'DUE_SOON' -and $t.deadline_workdays -gt 2) { throw 'DUE_SOON darf nicht mehr als 2 Arbeitstage haben.' }
            if(($t.rule -eq 'FINISHED') -ne [bool]$t.done) { throw 'FINISHED und done müssen übereinstimmen.' }
        }
    }
    return $root
}

function Get-RandomPriorityCounts {
    param([ValidateRange(1,10000)][int]$Total,[Parameter(Mandatory=$true)][Random]$Random,$PreviousCounts=$null)
    # Uniform weak compositions via three distinct separator positions. For >=5
    # messages reserve one per class. N=1..4 allows zeros so repetition can be avoided.
    $minimum=0
    if($Total -ge 5) { $minimum=1 }
    $surplus=$Total-4*$minimum
    for($attempt=0;$attempt -lt 64;$attempt++) {
        $cuts=New-Object 'System.Collections.Generic.HashSet[int]'
        while($cuts.Count -lt 3) { [void]$cuts.Add($Random.Next(0,$surplus+3)) }
        $v=@($cuts | Sort-Object)
        $c=@($v[0],($v[1]-$v[0]-1),($v[2]-$v[1]-1),($surplus+2-$v[2]))
        $obj=[ordered]@{}
        for($i=0;$i -lt 4;$i++) { $obj[$script:PriorityNames[$i]]=[int]($c[$i]+$minimum) }
        $same=$null -ne $PreviousCounts
        foreach($p in $script:PriorityNames) { if($null -eq $PreviousCounts -or $obj[$p] -ne $PreviousCounts.$p) {$same=$false} }
        if(-not $same) { return [pscustomobject]$obj }
    }
    # Bounded deterministic fallback: at least one count exceeds minimum for every allowed N.
    for($i=0;$i -lt 4;$i++) {
        $p=$script:PriorityNames[$i]
        if($obj[$p] -gt $minimum) { $obj[$p]--; $obj[$script:PriorityNames[($i+1)%4]]++;break }
    }
    return [pscustomobject]$obj
}

function Expand-TestMailTokens {
    param([string]$Text,[Collections.IDictionary]$Tokens)
    foreach($k in $Tokens.Keys) { $Text=$Text.Replace(('{'+$k+'}'),[string]$Tokens[$k]) }
    return $Text
}

function New-TestMailBatch {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][ValidateRange(1,10000)][int]$Total,
        [Parameter(Mandatory=$true)][string[]]$Recipients,
        [Parameter(Mandatory=$true)][string]$TemplatePath,
        [Parameter(Mandatory=$true)][string]$SenderRulesPath,
        [Parameter(Mandatory=$true)][string]$SettingsPath,
        [int]$Seed=0,[datetime]$ReferenceDate=(Get-Date),$PreviousCounts=$null,
        [string]$SenderSmtp='',[string]$SenderName='',
        [bool]$SetOutlookImportance=$false,[bool]$IncludeCcExamples=$true
    )
    # Read sender policy BEFORE assigning any labels.
    $rules=Read-TestSenderRules $SenderRulesPath
    $settings=Get-GeneratorSettings $SettingsPath
    $templates=Get-TestMailTemplates $TemplatePath
    $recipientsChecked=@(ConvertTo-TestRecipients ($Recipients -join ';'))
    if($recipientsChecked.Count -gt $settings.max_recipients -or $Total -gt $settings.max_messages) { throw 'Mengenlimit in generator_settings.json überschritten.' }
    $people=@($recipientsChecked | ForEach-Object {Get-RecipientName $_})
    $nameText=(@($people | ForEach-Object {$_.FirstName}) -join ' und ')
    $fullText=(@($people | ForEach-Object {$_.FullName}) -join ' und ')
    $random=New-Object System.Random($Seed)
    $counts=Get-RandomPriorityCounts -Total $Total -Random $random -PreviousCounts $PreviousCounts
    $created=[DateTimeOffset]::UtcNow
    $run=$created.ToString('yyyyMMddTHHmmssfffZ')+'-'+[guid]::NewGuid().ToString('N').Substring(0,12)
    $labels=New-Object 'System.Collections.Generic.List[object]'
    $pools=@{};$positions=@{}
    foreach($p in $script:PriorityNames) {
        $eligible=New-Object 'System.Collections.Generic.List[object]'
        foreach($t in $templates.classes.$p) {
            if(-not $IncludeCcExamples -and $t.recipient_role -eq 'cc') {continue}
            $check=Get-TestScenarioPriority -Template $t -Rules $rules -SenderSmtp $SenderSmtp -SenderName $SenderName -Subject $t.subject
            if($check.Priority -eq $p) { [void]$eligible.Add($t) }
        }
        if($counts.$p -gt 0 -and $eligible.Count -eq 0) { throw ('Mit diesem Absender und absender.md sind keine passenden '+$p+'-Beispiele verfügbar. Anderes berechtigtes Testkonto verwenden oder getrennte Offline-Testdaten prüfen; keine Absender werden gefälscht.') }
        $pools[$p]=[object[]]$eligible.ToArray();$positions[$p]=0
        for($i=0;$i -lt $counts.$p;$i++) {[void]$labels.Add($p)}
    }
    $shuffled=Invoke-ArrayShuffle -Items $labels.ToArray() -Random $random
    $cycles=@{};foreach($p in $script:PriorityNames){$cycles[$p]=@()}
    $projects=@('TEST01','TEST02','TEST03','TEST04','TEST05','TEST06')
    $messages=New-Object 'System.Collections.Generic.List[object]'
    for($offset=0;$offset -lt $Total;$offset++) {
        $p=[string]$shuffled[$offset]
        if($positions[$p] -ge $cycles[$p].Count) {
            $cycles[$p]=Invoke-ArrayShuffle -Items ([object[]]$pools[$p].Clone()) -Random $random
            $positions[$p]=0
        }
        $t=$cycles[$p][$positions[$p]];$positions[$p]++
        $id=$run+'-'+($offset+1).ToString('D5')
        $deadline='';$dueText='unklar';$overdue=$false
        if($null -ne $t.deadline_workdays) {
            $due=(Add-TestWorkingDays -Date $ReferenceDate -Days ([int]$t.deadline_workdays) -Settings $settings).AddHours(17)
            $deadline=$due.ToString('yyyy-MM-ddTHH:mm:ss')
            $dueText=$due.ToString('dd.MM.yyyy')
            $overdue=$due -lt $ReferenceDate
        }
        $tokens=[ordered]@{greeting=('Hallo '+$nameText+',');name=$nameText;full_name=$fullText;email=($recipientsChecked -join '; ');case=('TEST-'+$random.Next(10000,100000));project=$projects[$random.Next($projects.Count)];due_date=$dueText;past_date=$ReferenceDate.AddDays(-3).ToString('dd.MM.yyyy');today=$ReferenceDate.ToString('dd.MM.yyyy')}
        $subjectTemplate=$t.subject
        if($people.Count -gt 1){$subjectTemplate=$subjectTemplate.Replace('{full_name}','die genannten Empfänger')}
        $subject='[PRIO-TEST '+$id+'] '+(Expand-TestMailTokens $subjectTemplate $tokens)
        if($overdue -and $subject -notmatch 'ÜBERFÄLLIG'){$subject+=' - ÜBERFÄLLIG'}
        if($subject.Length -gt 250){throw 'Erzeugter Betreff ist zu lang. Vorlage oder Empfängerzahl prüfen.'}
        $assessment=Get-TestScenarioPriority -Template $t -Rules $rules -SenderSmtp $SenderSmtp -SenderName $SenderName -Subject $subject
        if($assessment.Priority -ne $p) {throw 'Empfänger-/Datumsersetzung trifft eine vorrangige Absenderregel. Lauf abgebrochen; keine Nachricht versendet.'}
        $body=Expand-TestMailTokens $t.body $tokens
        $body=[regex]::Replace($body,'\r\n|\r|\n',"`r`n")
        $body+="`r`n`r`n---`r`nSynthetische Testnachricht; keine echte Arbeitsanweisung und keine echten Kundendaten.`r`nTest-ID: "+$id
        $importance=1
        if($SetOutlookImportance) {if($p -eq 'urgent'){$importance=2};if($p -eq 'ignore'){$importance=0}}
        [void]$messages.Add([pscustomobject][ordered]@{
            Index=($offset+1);TestId=$id;ExpectedPriority=$p;TemplateId=$t.id;RuleId=$t.rule;ExpectedReason=$assessment.Reason;MatchedSenderRules=$assessment.Matches;
            Subject=$subject;Body=$body;RecipientRole=$t.recipient_role;OutlookImportance=$importance;
            AssessmentDate=$ReferenceDate.ToString('yyyy-MM-dd');DeadlineLocal=$deadline;Overdue=$overdue;ExpectedDone=[bool]$t.done;
            TransportKind='INDEPENDENT_MAIL';ThreadCoverage='SINGLE_MESSAGE_ONLY';Status='planned';Error='';SubmittedAt=''
        })
    }
    [pscustomobject][ordered]@{
        SchemaVersion=2;GeneratorVersion='2.0.1';PolicyId=$templates.policy_id;RunId=$run;CreatedAt=$created.ToString('o');
        AssessmentDate=$ReferenceDate.ToString('yyyy-MM-dd');AssessmentTimeLocal=$ReferenceDate.ToString('o');LocalTimeZone=[TimeZoneInfo]::Local.Id;Seed=$Seed;Counts=$counts;Recipients=[string[]]$recipientsChecked;
        RecipientNames=$people;SenderSmtp=$SenderSmtp;SenderName=$SenderName;SenderRulesSha256=$rules.Sha256;SenderRulesText=$rules.Text;
        TemplatesSha256=(Get-FileSha256 $TemplatePath);SettingsSha256=(Get-FileSha256 $SettingsPath);WorkingCalendar=$settings;
        SetOutlookImportance=$SetOutlookImportance;IncludeCcExamples=$IncludeCcExamples;Messages=$messages.ToArray()
    }
}

function Get-TestMailCsv {
    param($Batch,[bool]$IncludeResults)
    $columns=@('TestId','ExpectedPriority','TemplateId','RuleId','ExpectedReason','MatchedSenderRules','Subject','Recipients','RecipientRole','SenderSmtp','Seed','AssessmentDate','DeadlineLocal','Overdue','ExpectedDone','OutlookImportance','TransportKind','ThreadCoverage')
    if($IncludeResults){$columns+=@('Status','Error','SubmittedAt')}
    $b=New-Object System.Text.StringBuilder
    [void]$b.AppendLine((@($columns | ForEach-Object {ConvertTo-ExcelCsvCell $_}) -join ';'))
    foreach($m in $Batch.Messages){
        $cells=@()
        foreach($c in $columns){
            if($c -eq 'Recipients'){$v=$Batch.Recipients -join '; '}
            elseif($c -in @('Seed','SenderSmtp')){$v=$Batch.$c}
            else{$v=$m.$c}
            $cells+=ConvertTo-ExcelCsvCell $v
        }
        [void]$b.AppendLine(($cells -join ';'))
    }
    return $b.ToString()
}

function Get-TestMailSummary {
    param([Parameter(Mandatory=$true)]$Batch)
    $s=[ordered]@{Total=@($Batch.Messages).Count;planned=0;submitted=0;failed=0;unknown=0;cancelled=0;UrgentSubmitted=0;ImportantSubmitted=0;InfoSubmitted=0;IgnoreSubmitted=0}
    $map=@{urgent='UrgentSubmitted';important='ImportantSubmitted';info='InfoSubmitted';ignore='IgnoreSubmitted'}
    foreach($m in $Batch.Messages){
        if($m.Status -notin @('planned','submitted','failed','unknown','cancelled') -or $m.ExpectedPriority -notin $script:PriorityNames){throw 'Ungültiger Status oder Priorität.'}
        $s[$m.Status]++
        if($m.Status -eq 'submitted'){$s[$map[$m.ExpectedPriority]]++}
    }
    return [pscustomobject]$s
}

function Save-TestMailPlan {
    param([Parameter(Mandatory=$true)]$Batch,[Parameter(Mandatory=$true)][string]$Directory)
    $dir=[IO.Path]::GetFullPath($Directory)
    if([IO.Directory]::Exists($dir) -and [IO.Directory]::GetFileSystemEntries($dir).Length -ne 0){throw 'Vorhandene Laufdaten werden nicht überschrieben.'}
    [void][IO.Directory]::CreateDirectory($dir)
    $s=Get-TestMailSummary $Batch
    if($s.planned -ne $s.Total){throw 'Ein neuer Plan darf nur planned enthalten.'}
    $b=New-Object System.Text.StringBuilder
    [void]$b.AppendLine(('MCR Priority Mail Generator 2.0.1 – Vorschau; Stichtag '+$Batch.AssessmentDate))
    foreach($m in $Batch.Messages){
        [void]$b.AppendLine(('='*72))
        [void]$b.AppendLine(('Nachricht '+$m.Index+' / Rolle '+$m.RecipientRole+' / Empfänger '+($Batch.Recipients -join '; ')))
        [void]$b.AppendLine($m.Subject);[void]$b.AppendLine($m.Body)
    }
    Write-DurableUtf8File (Join-Path $dir 'plan.json') ((ConvertTo-Json -InputObject $Batch -Depth 20)+"`r`n")
    Write-DurableUtf8File (Join-Path $dir 'expected_priorities.csv') (Get-TestMailCsv $Batch $false)
    Write-DurableUtf8File (Join-Path $dir 'mail_previews.txt') $b.ToString()
    Write-DurableUtf8File (Join-Path $dir 'absender.snapshot.md') $Batch.SenderRulesText
    Write-DurableUtf8File (Join-Path $dir 'TESTGRENZEN.txt') @"
Vier Szenarioklassen zum Stichtag $($Batch.AssessmentDate). Fristen sind lokal und im Text ausdrücklich genannt.
Reale Testmails, keine echten Arbeitsaufträge. Absender: ausgewähltes berechtigtes Outlook-Konto; keine Rollenfälschung.
TO/CC werden wirklich gesetzt. Keine zusätzlichen Empfänger. Jede Mail geht an alle eingegebenen Adressen.
Nur unabhängige MailItems. Keine echten MeetingRequests, Anhänge, VIP-Wechsel, rückdatierten Empfangszeiten oder Antwortthreads.
Abschlussinformationen stehen nur im Szenariotext. Keine Prüfung/Erzeugung echter Antworten in Gesendet.
Originalkopien aus Selbstversand in Gesendet dürfen NICHT als Antworten gezählt werden.
Die unveränderlichen Sollklassen sind Test-Oracle, keine Behauptung über eine Scanner-Trefferquote.
Outlook- oder Postfachregeln können Ablage und Zustellung beeinflussen; Eingang und Ungelesenstatus werden nicht erzwungen.
Ab morgen können sich Prioritäten wegen Fristen ändern. Für Vergleiche denselben Stichtag verwenden oder neu generieren.
Erweiterte Sender-/Thread-/Kalenderszenarien nur in OFFLINE_TESTDATEN.cmd, niemals automatisch versendet.
"@
    foreach($name in @('plan.json','expected_priorities.csv','absender.snapshot.md')){
        $p=Join-Path $dir $name
        [IO.File]::SetAttributes($p,([IO.File]::GetAttributes($p) -bor [IO.FileAttributes]::ReadOnly))
    }
    [pscustomobject]@{Directory=$dir;PlanPath=(Join-Path $dir 'plan.json')}
}

function Save-TestMailResult {
    param([Parameter(Mandatory=$true)]$Batch,[Parameter(Mandatory=$true)][string]$Directory)
    $plan=Join-Path $Directory 'plan.json'
    if(-not [IO.File]::Exists($plan)){throw 'Versandplan fehlt.'}
    $original=ConvertFrom-Json -InputObject ([IO.File]::ReadAllText($plan,[Text.Encoding]::UTF8))
    if($original.RunId -cne $Batch.RunId){throw 'Plan und Ergebnis gehören nicht zusammen.'}
    $summary=Get-TestMailSummary $Batch
    $result=[ordered]@{SchemaVersion=2;RunId=$Batch.RunId;PolicyId=$Batch.PolicyId;AssessmentDate=$Batch.AssessmentDate;ExpectedCounts=$Batch.Counts;SenderSmtp=$Batch.SenderSmtp;Recipients=$Batch.Recipients;SenderRulesSha256=$Batch.SenderRulesSha256;SubmittedMeaning='Ohne Fehler an Outlook übergeben; tatsächliche Zustellung ungeprüft.'}
    foreach($p in $summary.PSObject.Properties){$result[$p.Name]=$p.Value}
    Write-DurableUtf8File (Join-Path $Directory 'results.csv') (Get-TestMailCsv $Batch $true) -Replace $true
    Write-DurableUtf8File (Join-Path $Directory 'summary.json') ((ConvertTo-Json -InputObject $result -Depth 12)+"`r`n") -Replace $true
    [pscustomobject]@{Summary=$summary;Directory=$Directory}
}

Export-ModuleMember -Function ConvertTo-TestRecipients,Get-RecipientName,Get-GeneratorSettings,Add-TestWorkingDays,Get-FileSha256,Read-TestSenderRules,Get-TestScenarioPriority,Get-TestMailTemplates,Get-RandomPriorityCounts,New-TestMailBatch,Get-TestMailCsv,Get-TestMailSummary,Save-TestMailPlan,Save-TestMailResult,Write-TestMailEvent,Write-DurableUtf8File,Expand-TestMailTokens
