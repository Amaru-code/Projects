﻿#requires -Version 5.1
<# MCR Priority Mail Generator 2.0.1. Start via STARTEN.cmd. #>
[CmdletBinding()]
param([switch]$SelfTest)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
if ($SelfTest) {
    & (Join-Path $PSScriptRoot 'tests/Run-Tests.ps1')
    exit 0
}
if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) {
    throw 'Das Eingabefenster benoetigt Windows. Die Kernpruefungen sind mit -SelfTest auch ohne Outlook moeglich.'
}
if ([Threading.Thread]::CurrentThread.ApartmentState -ne 'STA') {
    throw 'Bitte STARTEN.cmd verwenden. Das Fenster und Outlook benoetigen den STA-Modus.'
}
# Local preflight only: no Outlook object and no real emails.
& (Join-Path $PSScriptRoot 'tests/Run-Tests.ps1')
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()
Import-Module (Join-Path $PSScriptRoot 'lib/PriorityMail.Core.psm1') -ErrorAction Stop
Import-Module (Join-Path $PSScriptRoot 'lib/PriorityMail.Outlook.psm1') -ErrorAction Stop

$script:batch = $null
$script:connection = $null
$script:lastFolder = ''
$script:busy = $false
$script:cancelRequested = $false
$script:batchAttempted = $false
$script:activeAccount = $null
$script:stateRoot = Join-Path $env:LOCALAPPDATA 'MCR/PriorityMailGenerator'
$script:statePath = Join-Path $script:stateRoot 'last_distribution_v2.json'
$script:senderRulesPath = Join-Path $PSScriptRoot 'absender.md'
$script:settingsPath = Join-Path $PSScriptRoot 'config/generator_settings.json'
$script:nextIndex = 0
$script:templatePath = Join-Path $PSScriptRoot 'data/templates.json'
$script:outputRoot = Join-Path $PSScriptRoot 'Output'
$script:priorityNames = @{ urgent = 'Rot: Sofort beantworten'; important = 'Gelb: Diese Woche'; info = 'Blau: Zur Kenntnis'; ignore = 'Weiss: Ignorierbar' }
$script:statusNames = @{ planned = 'Geplant'; submitted = 'Übergeben'; failed = 'Fehler'; unknown = 'Unklar'; cancelled = 'Nicht gestartet' }

function New-Label {
    param([string]$Text, [int]$X, [int]$Y, [int]$Width = 160, [int]$Height = 25)
    $control = New-Object Windows.Forms.Label
    $control.Text = $Text
    $control.Location = [Drawing.Point]::new($X, $Y)
    $control.Size = [Drawing.Size]::new($Width, $Height)
    return $control
}

function New-Number {
    param([int]$X, [int]$Y, [decimal]$Min, [decimal]$Max, [decimal]$Value, [int]$Width = 82)
    $control = New-Object Windows.Forms.NumericUpDown
    $control.Location = [Drawing.Point]::new($X, $Y)
    $control.Size = [Drawing.Size]::new($Width, 28)
    $control.Minimum = $Min
    $control.Maximum = $Max
    $control.Value = $Value
    return $control
}

function Show-UiError {
    param([string]$Text)
    $statusLabel.Text = $Text
    [void][Windows.Forms.MessageBox]::Show($form, $Text, 'Bitte prüfen', 'OK', 'Warning')
}

function Read-PreviousDistribution {
    if (-not [IO.File]::Exists($script:statePath)) { return $null }
    try {
        $state = ConvertFrom-Json -InputObject ([IO.File]::ReadAllText($script:statePath, [Text.Encoding]::UTF8))
        if ($state.Total -ne [int]$countBox.Value) { return $null }
        foreach ($p in @('urgent','important','info','ignore')) {
            if ($null -eq $state.Counts.PSObject.Properties[$p]) { return $null }
        }
        return $state.Counts
    } catch { return $null }
}

function Update-Salutation {
    try {
        $a = @(ConvertTo-TestRecipients -Text $toBox.Text)
        $names = @($a | ForEach-Object { (Get-RecipientName $_).FirstName })
        $salutationLabel.Text = 'Anrede: Hallo ' + ($names -join ' und ') + ',  | Jede Mail an alle ' + $a.Count + ' Adressen; blaue CC-Faelle nur in CC.'
    } catch {
        $salutationLabel.Text = 'Format: vorname.nachname@domain; mehrere Adressen mit ; trennen (max. 20).'
    }
}

function Update-Distribution {
    if ($null -eq $script:batch) {
        $distributionLabel.Text = 'Wird beim Erzeugen jedes Laufs neu zufällig bestimmt.'
        $distributionLabel.ForeColor = [Drawing.Color]::DimGray
        return
    }
    $counts = $script:batch.Counts
    $distributionLabel.Text = 'Rot {0} | Gelb {1} | Blau {2} | Weiss {3}' -f $counts.urgent, $counts.important, $counts.info, $counts.ignore
    $distributionLabel.ForeColor = [Drawing.Color]::FromArgb(30, 83, 103)
}

function Invalidate-Plan {
    if ($script:busy) { return }
    $script:batch = $null
    $script:batchAttempted = $false
    $mailList.Items.Clear()
    $bodyBox.Clear()
    $progress.Value = 0
    $statusLabel.Text = 'Eingaben wählen, dann Vorschau erzeugen oder E-Mails senden.'
    Update-Distribution
}

function Set-UiBusy {
    param([bool]$Value)
    $script:busy = $Value
    $settingsPanel.Enabled = -not $Value
    $previewButton.Enabled = -not $Value
    $sendButton.Enabled = -not $Value
    $cancelButton.Enabled = $Value
}

function Connect-Outlook {
    if ($script:busy) { return }
    $statusLabel.Text = 'Klassisches Outlook verbinden …'
    $statusLabel.Refresh()
    if ($null -ne $script:connection) {
        Close-TestOutlookConnection -Connection $script:connection
        $script:connection = $null
    }
    $accountBox.Items.Clear()
    $script:connection = Get-TestOutlookConnection
    foreach ($entry in $script:connection.Accounts) { [void]$accountBox.Items.Add($entry) }
    if ($accountBox.Items.Count -eq 1) { $accountBox.SelectedIndex = 0 }
    else { $accountBox.SelectedIndex = -1 }
    $statusLabel.Text = 'Outlook verbunden. Absenderkonto und Empfänger prüfen, dann E-Mails senden.'
}

function New-BatchFromForm {
    $recipients = @(ConvertTo-TestRecipients -Text $toBox.Text)
    $smtp = ''; $senderName = ''
    if ($null -ne $accountBox.SelectedItem) {
        $smtp = [string]$accountBox.SelectedItem.Smtp
        $senderName = [string]$accountBox.SelectedItem.ComAccount.DisplayName
    }
    $batchArgs = @{
        Total = [int]$countBox.Value
        Recipients = $recipients
        TemplatePath = $script:templatePath
        SenderRulesPath = $script:senderRulesPath
        SettingsPath = $script:settingsPath
        SenderSmtp = $smtp
        SenderName = $senderName
        Seed = Get-Random -Minimum 1 -Maximum ([int]::MaxValue)
        ReferenceDate = Get-Date
        PreviousCounts = Read-PreviousDistribution
        IncludeCcExamples = [bool]$ccBox.Checked
        SetOutlookImportance = [bool]$importanceBox.Checked
    }
    $newBatch = New-TestMailBatch @batchArgs
    $folder = Join-Path $script:outputRoot $newBatch.RunId
    $null = Save-TestMailPlan -Batch $newBatch -Directory $folder
    [void][IO.Directory]::CreateDirectory($script:stateRoot)
    $state = [pscustomobject]@{ Total=$newBatch.Messages.Count; Counts=$newBatch.Counts }
    Write-DurableUtf8File -Path $script:statePath -Text (ConvertTo-Json $state -Depth 5) -Replace $true
    $script:batch = $newBatch
    $script:lastFolder = $folder
    $script:batchAttempted = $false
    $folderButton.Enabled = $true
    $mailList.BeginUpdate()
    try {
        $mailList.Items.Clear()
        foreach ($message in $script:batch.Messages) {
            $item = New-Object Windows.Forms.ListViewItem([string]$message.Index)
            [void]$item.SubItems.Add($script:priorityNames[$message.ExpectedPriority])
            [void]$item.SubItems.Add('Geplant')
            [void]$item.SubItems.Add($message.Subject + ' [' + $message.RecipientRole.ToUpperInvariant() + ']')
            $item.Tag = $message
            [void]$mailList.Items.Add($item)
        }
    } finally { $mailList.EndUpdate() }
    $bodyBox.Clear()
    if ($mailList.Items.Count -gt 0) { $mailList.Items[0].Selected = $true }
    $progress.Maximum = $script:batch.Messages.Count
    $progress.Value = 0
    $statusLabel.Text = '{0} Testmails; Stichtag {1}; {2} Empfaenger je Mail. Sollklassen nur lokal, nicht in den Mails.' -f $script:batch.Messages.Count, $script:batch.AssessmentDate, $script:batch.Recipients.Count
    Update-Distribution
}

function Finish-Sending {
    param([string]$Reason)
    $timer.Stop()
    foreach ($message in $script:batch.Messages) {
        if ($message.Status -eq 'planned') {
            $message.Status = 'cancelled'
            $message.Error = $Reason
            $mailList.Items[$message.Index - 1].SubItems[2].Text = 'Nicht gestartet'
        }
    }
    $saveError = ''
    try { $null = Save-TestMailResult -Batch $script:batch -Directory $script:lastFolder }
    catch { $saveError = "`r`nErgebnisdateien konnten nicht vollständig gespeichert werden: " + $_.Exception.Message }
    $summary = Get-TestMailSummary -Batch $script:batch
    Set-UiBusy -Value $false
    $statusLabel.Text = '{0} von {1} an Outlook übergeben. {2} Fehler, {3} unklar, {4} nicht gestartet.' -f $summary.submitted, $summary.Total, $summary.failed, $summary.unknown, $summary.cancelled
    $text = @"
An Outlook zum Versand übergeben: $($summary.submitted) von $($summary.Total) E-Mails

Davon:
  $($summary.UrgentSubmitted) Rot - Sofort beantworten
  $($summary.ImportantSubmitted) Gelb - Diese Woche
  $($summary.InfoSubmitted) Blau - Zur Kenntnis
  $($summary.IgnoreSubmitted) Weiss - Ignorierbar

Bewertungsstichtag: $($script:batch.AssessmentDate)

Fehler vor dem Sendeaufruf: $($summary.failed)
Unklarer Ausgang des Sendeaufrufs: $($summary.unknown)
Nicht gestartet: $($summary.cancelled)

$Reason

Outlook übernimmt den weiteren Versand. Die Zustellung beim Empfänger wird hier nicht bestätigt.

Ergebnisse: $($script:lastFolder)$saveError
"@
    $icon = [Windows.Forms.MessageBoxIcon]::Information
    if ($summary.failed -gt 0 -or $summary.unknown -gt 0 -or $summary.cancelled -gt 0 -or $saveError) {
        $icon = [Windows.Forms.MessageBoxIcon]::Warning
    }
    [void][Windows.Forms.MessageBox]::Show($form, $text, 'Ergebnis des Testmail-Laufs', [Windows.Forms.MessageBoxButtons]::OK, $icon)
}

function Start-Sending {
    if ($script:busy) { return }
    # Validate before connecting Outlook. No recipients are inferred.
    $null = @(ConvertTo-TestRecipients -Text $toBox.Text)
    if ($null -eq $script:connection) { Connect-Outlook }
    if ($null -eq $accountBox.SelectedItem) { throw 'Bitte das gewünschte Absenderkonto auswählen und erneut auf E-Mails senden klicken.' }
    if ($script:connection.Session.Offline) { throw 'Outlook ist offline. Bitte die Verbindung in Outlook herstellen und erneut starten.' }
    if ($null -eq $script:batch -or $script:batchAttempted -or
        $script:batch.SenderSmtp -ine [string]$accountBox.SelectedItem.Smtp -or
        $script:batch.AssessmentDate -ne (Get-Date).ToString('yyyy-MM-dd') -or
        $script:batch.SenderRulesSha256 -ne (Get-FileSha256 $script:senderRulesPath) -or
        $script:batch.TemplatesSha256 -ne (Get-FileSha256 $script:templatePath) -or
        $script:batch.SettingsSha256 -ne (Get-FileSha256 $script:settingsPath)) { New-BatchFromForm }
    $c = $script:batch.Counts
    $confirmText = 'Jetzt ' + $script:batch.Messages.Count + ' synthetische Testmails senden?' + "`r`n`r`n" +
        'Von: ' + $accountBox.SelectedItem.Smtp + "`r`n" +
        'Empfaenger je Mail: ' + ($script:batch.Recipients -join '; ') + "`r`n" +
        'Rot / Gelb / Blau / Weiss: ' + $c.urgent + ' / ' + $c.important + ' / ' + $c.info + ' / ' + $c.ignore + "`r`n`r`n" +
        'CC-Beispiele erhalten die angegebenen Empfaenger nur in CC. Keine weiteren Empfaenger. Keine echten Kundendaten.' + "`r`n" +
        'Nur an eigene oder freigegebene Testpostfaecher senden. Die Vorschau ist im Fenster und Ergebnisordner verfuegbar.'
    if ([Windows.Forms.MessageBox]::Show($form,$confirmText,'Testversand bestaetigen','YesNo','Warning','Button2') -ne [Windows.Forms.DialogResult]::Yes) { return }
    $script:activeAccount = $accountBox.SelectedItem
    $senderInfo = [pscustomobject]@{
        RunId = $script:batch.RunId
        SenderSmtp = $script:activeAccount.Smtp
        Recipients = $script:batch.Recipients
        StartedAtUtc = [DateTime]::UtcNow.ToString('o')
        IntervalSeconds = [double]$delayBox.Value
        OutlookImportanceEnabled = [bool]$importanceBox.Checked
    }
    [IO.File]::WriteAllText((Join-Path $script:lastFolder 'sender.json'), ($senderInfo | ConvertTo-Json -Depth 5), [Text.UTF8Encoding]::new($false))
    $script:batchAttempted = $true
    $script:cancelRequested = $false
    $script:nextIndex = 0
    $timer.Interval = [int]($delayBox.Value * 1000)
    Set-UiBusy -Value $true
    $statusLabel.Text = 'Versand läuft. Ein Outlook-Hinweis kann eine Bestätigung im Outlook-Fenster erfordern.'
    $timer.Start()
}

$form = New-Object Windows.Forms.Form
$form.Text = 'MCR Priority Mail Generator 2.0.1 - Urlaubs-Rueckblick'
$form.StartPosition = 'CenterScreen'
$form.ClientSize = [Drawing.Size]::new(1080, 810)
$form.MinimumSize = [Drawing.Size]::new(1080, 700)
$form.AutoScaleMode = 'Font'
$form.Font = [Drawing.Font]::new('Segoe UI', 10)
$form.BackColor = [Drawing.Color]::White

$layout = New-Object Windows.Forms.TableLayoutPanel
$layout.Dock = 'Fill'
$layout.Padding = [Windows.Forms.Padding]::new(18)
$layout.ColumnCount = 1
$layout.RowCount = 5
[void]$layout.RowStyles.Add([Windows.Forms.RowStyle]::new([Windows.Forms.SizeType]::Absolute, 65))
[void]$layout.RowStyles.Add([Windows.Forms.RowStyle]::new([Windows.Forms.SizeType]::Absolute, 264))
[void]$layout.RowStyles.Add([Windows.Forms.RowStyle]::new([Windows.Forms.SizeType]::Percent, 100))
[void]$layout.RowStyles.Add([Windows.Forms.RowStyle]::new([Windows.Forms.SizeType]::Absolute, 65))
[void]$layout.RowStyles.Add([Windows.Forms.RowStyle]::new([Windows.Forms.SizeType]::Absolute, 45))
$form.Controls.Add($layout)

$heading = New-Object Windows.Forms.Panel
$heading.Dock = 'Fill'
$title = New-Label -Text 'Testmails für den Urlaubs-Rückblick' -X 0 -Y 0 -Width 980 -Height 34
$title.Font = [Drawing.Font]::new('Segoe UI', 19, [Drawing.FontStyle]::Bold)
$title.ForeColor = [Drawing.Color]::FromArgb(20, 50, 78)
$heading.Controls.Add($title)
$heading.Controls.Add((New-Label -Text 'Anzahl wählen · Inhalte mischen · über dein Outlook-Konto versenden' -X 1 -Y 39 -Width 980))
$layout.Controls.Add($heading, 0, 0)

$settingsPanel = New-Object Windows.Forms.Panel
$settingsPanel.Size = [Drawing.Size]::new(1038, 264)
$settingsPanel.Dock = 'Fill'
$settingsPanel.Controls.Add((New-Label -Text 'Empfänger' -X 0 -Y 3 -Width 150))
$toBox = New-Object Windows.Forms.TextBox
$toBox.Location = [Drawing.Point]::new(160, 0)
$toBox.Size = [Drawing.Size]::new(845, 47)
$toBox.Anchor = 'Top, Left, Right'
$toBox.Multiline = $true
$toBox.ScrollBars = 'Vertical'
$settingsPanel.Controls.Add($toBox)
$salutationLabel = New-Label -Text 'Format: vorname.nachname@domain; mehrere Adressen mit ; trennen (max. 20).' -X 160 -Y 49 -Width 855 -Height 26
$settingsPanel.Controls.Add($salutationLabel)

$settingsPanel.Controls.Add((New-Label -Text 'Anzahl E-Mails' -X 0 -Y 85 -Width 150))
$countBox = New-Number -X 160 -Y 80 -Min 1 -Max 10000 -Value 50 -Width 90
$settingsPanel.Controls.Add($countBox)
$settingsPanel.Controls.Add((New-Label -Text 'Prioritätsverteilung' -X 280 -Y 85 -Width 150))
$distributionLabel = New-Label -Text 'Wird beim Erzeugen jedes Laufs neu zufällig bestimmt.' -X 435 -Y 85 -Width 570
$settingsPanel.Controls.Add($distributionLabel)

$importanceBox = New-Object Windows.Forms.CheckBox
$importanceBox.Text = 'Outlook-Wichtigkeit zusaetzlich setzen (Rot=hoch, Weiss=niedrig, sonst normal)'
$importanceBox.Location = [Drawing.Point]::new(160, 132)
$importanceBox.Size = [Drawing.Size]::new(825, 25)
$importanceBox.Checked = $false
$settingsPanel.Controls.Add($importanceBox)
$ccBox = New-Object Windows.Forms.CheckBox
$ccBox.Text = 'Echte CC-Beispiele zulassen (nur blaue Statusmails; alle eingegebenen Adressen in CC)'
$ccBox.Location = [Drawing.Point]::new(160, 160)
$ccBox.Size = [Drawing.Size]::new(850,25)
$ccBox.Checked = $true
$settingsPanel.Controls.Add($ccBox)
$importanceHint = New-Label -Text 'Vier Szenarioklassen, kein neuer Scanner. Absenderregeln: absender.md. Vorher Vorschau prüfen.' -X 160 -Y 237 -Width 850
$importanceHint.ForeColor = [Drawing.Color]::DimGray
$settingsPanel.Controls.Add($importanceHint)

$settingsPanel.Controls.Add((New-Label -Text 'Absenderkonto' -X 0 -Y 209 -Width 150))
$accountBox = New-Object Windows.Forms.ComboBox
$accountBox.Location = [Drawing.Point]::new(160, 204)
$accountBox.Size = [Drawing.Size]::new(480, 28)
$accountBox.DropDownStyle = 'DropDownList'
$accountBox.DisplayMember = 'Name'
$settingsPanel.Controls.Add($accountBox)
$connectButton = New-Object Windows.Forms.Button
$connectButton.Text = 'Outlook verbinden'
$connectButton.Location = [Drawing.Point]::new(650, 202)
$connectButton.Size = [Drawing.Size]::new(157, 32)
$settingsPanel.Controls.Add($connectButton)
$settingsPanel.Controls.Add((New-Label -Text 'Pause (s)' -X 823 -Y 209 -Width 83))
$delayBox = New-Number -X 914 -Y 204 -Min 0.2 -Max 60 -Value 0.5 -Width 70
$delayBox.DecimalPlaces = 1
$delayBox.Increment = 0.1
$settingsPanel.Controls.Add($delayBox)
$layout.Controls.Add($settingsPanel, 0, 1)

$split = New-Object Windows.Forms.SplitContainer
$split.Dock = 'Fill'
$split.Orientation = 'Horizontal'
$split.Size = [Drawing.Size]::new(1030, 330)
$split.SplitterDistance = 175
$split.Panel1MinSize = 90
$split.Panel2MinSize = 70
$mailList = New-Object Windows.Forms.ListView
$mailList.Dock = 'Fill'
$mailList.View = 'Details'
$mailList.FullRowSelect = $true
$mailList.HideSelection = $false
$mailList.MultiSelect = $false
$mailList.GridLines = $true
[void]$mailList.Columns.Add('Nr.', 48)
[void]$mailList.Columns.Add('Erwartete Klasse', 210)
[void]$mailList.Columns.Add('Status', 130)
[void]$mailList.Columns.Add('Betreff und echte Empfaengerrolle', 610)
$split.Panel1.Controls.Add($mailList)
$bodyBox = New-Object Windows.Forms.TextBox
$bodyBox.Dock = 'Fill'
$bodyBox.Multiline = $true
$bodyBox.ReadOnly = $true
$bodyBox.ScrollBars = 'Vertical'
$bodyBox.BackColor = [Drawing.Color]::FromArgb(247, 249, 252)
$split.Panel2.Controls.Add($bodyBox)
$layout.Controls.Add($split, 0, 2)

$actions = New-Object Windows.Forms.FlowLayoutPanel
$actions.Dock = 'Fill'
$actions.Padding = [Windows.Forms.Padding]::new(0, 14, 0, 0)
$previewButton = New-Object Windows.Forms.Button
$previewButton.Text = 'Vorschau erzeugen'
$previewButton.Size = [Drawing.Size]::new(180, 38)
$actions.Controls.Add($previewButton)
$sendButton = New-Object Windows.Forms.Button
$sendButton.Text = 'E-Mails senden'
$sendButton.Size = [Drawing.Size]::new(180, 38)
$sendButton.BackColor = [Drawing.Color]::FromArgb(25, 93, 149)
$sendButton.ForeColor = [Drawing.Color]::White
$sendButton.FlatStyle = 'Flat'
$actions.Controls.Add($sendButton)
$cancelButton = New-Object Windows.Forms.Button
$cancelButton.Text = 'Abbrechen'
$cancelButton.Size = [Drawing.Size]::new(135, 38)
$cancelButton.Enabled = $false
$actions.Controls.Add($cancelButton)
$folderButton = New-Object Windows.Forms.Button
$folderButton.Text = 'Ergebnisordner öffnen'
$folderButton.Size = [Drawing.Size]::new(205, 38)
$folderButton.Enabled = $false
$actions.Controls.Add($folderButton)
$layout.Controls.Add($actions, 0, 3)

$footer = New-Object Windows.Forms.Panel
$footer.Dock = 'Fill'
$statusLabel = New-Label -Text 'Empfänger und Anzahl wählen. Mit „Vorschau erzeugen“ kannst du alle Texte vorab ansehen.' -X 0 -Y 0 -Width 1010 -Height 25
$statusLabel.Dock = 'Top'
$footer.Controls.Add($statusLabel)
$progress = New-Object Windows.Forms.ProgressBar
$progress.Dock = 'Bottom'
$progress.Height = 10
$footer.Controls.Add($progress)
$layout.Controls.Add($footer, 0, 4)

$timer = New-Object Windows.Forms.Timer
$timer.Add_Tick({
    $timer.Stop()
    if (-not $script:busy) { return }
    try {
        if ($script:cancelRequested) { Finish-Sending -Reason 'Der Lauf wurde abgebrochen. Bereits übergebene E-Mails bleiben versendet bzw. im Outlook-Postausgang.'; return }
        if ($script:nextIndex -ge $script:batch.Messages.Count) { Finish-Sending -Reason 'Alle geplanten E-Mails wurden an Outlook übergeben.'; return }
        if ($script:batch.AssessmentDate -ne (Get-Date).ToString('yyyy-MM-dd')) { Finish-Sending -Reason 'Datum gewechselt. Bitte einen neuen Lauf mit aktuellen Fristen erzeugen.'; return }
        $message = $script:batch.Messages[$script:nextIndex]
        $outcome = Invoke-TestMailSubmission -Message $message -Recipients $script:batch.Recipients -Outlook $script:connection.Application -Account $script:activeAccount.ComAccount -AccountSmtp $script:activeAccount.Smtp -EventPath (Join-Path $script:lastFolder 'events.jsonl')
        $mailList.Items[$script:nextIndex].SubItems[2].Text = $script:statusNames[$message.Status]
        $script:nextIndex++
        $progress.Value = $script:nextIndex
        $statusLabel.Text = '{0} von {1} bearbeitet. Letzte Mail: {2}.' -f $script:nextIndex, $script:batch.Messages.Count, $script:statusNames[$message.Status]
        if ($outcome.Halt) { Finish-Sending -Reason $outcome.Detail; return }
        if ($script:nextIndex -ge $script:batch.Messages.Count) { Finish-Sending -Reason 'Alle geplanten E-Mails wurden an Outlook übergeben.'; return }
        $timer.Start()
    } catch {
        Finish-Sending -Reason ('Der Lauf wurde wegen eines Fehlers angehalten: ' + $_.Exception.Message)
    }
})

$previewButton.Add_Click({ try { New-BatchFromForm } catch { Show-UiError $_.Exception.Message } })
$connectButton.Add_Click({ try { Connect-Outlook } catch { Show-UiError $_.Exception.Message } })
$sendButton.Add_Click({ try { Start-Sending } catch { Set-UiBusy -Value $false; Show-UiError $_.Exception.Message } })
$cancelButton.Add_Click({
    $script:cancelRequested = $true
    $cancelButton.Enabled = $false
    $statusLabel.Text = 'Abbruch angefordert. Weitere E-Mails werden nicht gestartet.'
})
$folderButton.Add_Click({
    try {
        if ($script:lastFolder -and [IO.Directory]::Exists($script:lastFolder)) { Start-Process -FilePath $script:lastFolder }
    } catch { Show-UiError $_.Exception.Message }
})
$mailList.Add_SelectedIndexChanged({
    if ($mailList.SelectedItems.Count -gt 0) {
        $selected = $mailList.SelectedItems[0].Tag
        $bodyBox.Text = 'Empfaengerrolle: ' + $selected.RecipientRole + ' | Frist: ' + $selected.DeadlineLocal + "`r`n" +
            'Soll: ' + $script:priorityNames[$selected.ExpectedPriority] + ' | Grund: ' + $selected.ExpectedReason + "`r`n`r`n" +
            $selected.Subject + "`r`n`r`n" + $selected.Body
    }
})
$toBox.Add_TextChanged({ Invalidate-Plan; Update-Salutation })
$countBox.Add_ValueChanged({ Invalidate-Plan })
$importanceBox.Add_CheckedChanged({ Invalidate-Plan })
$ccBox.Add_CheckedChanged({ Invalidate-Plan })
$accountBox.Add_SelectedIndexChanged({ Invalidate-Plan })
$form.Add_FormClosing({
    param($sender, $eventArgs)
    if ($script:busy) {
        $eventArgs.Cancel = $true
        $script:cancelRequested = $true
        $statusLabel.Text = 'Lauf wird beendet. Danach kann das Fenster geschlossen werden.'
    }
})

Update-Distribution
try { [void]$form.ShowDialog() }
finally {
    $timer.Stop()
    $timer.Dispose()
    Close-TestOutlookConnection -Connection $script:connection
    $form.Dispose()
}
