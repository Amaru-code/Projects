import fs from 'node:fs';
import path from 'node:path';
import Core from '../lib/data-core.cjs';
import {readWorkbook} from '../lib/xlsx.mjs';
import {sha256} from '../lib/core.mjs';
export function makeMapping(book, {mode='LOCAL_WORKBOOK',headerLConfirmed=false}={}) {
  Core.need(headerLConfirmed, 'HEADER_L_CONFIRM', 'Bedeutung von Spalte L erst bestaetigen.');
  const groups = new Map(), unattributed = [];
  for (const row of book.allRows()) {
    if (!['B','C','D','E','L'].some(c => Core.text(row[c]))) continue;
    let key;
    try {key = Core.id(Core.text(row.B));}
    catch {unattributed.push({sourceRow:row.row,code:'NO_VALID_CLIENTEEID'});continue;}
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(row);
  }
  const entries = Object.create(null), blocked = Object.create(null);
  for (const [clientId, rows] of groups) {
    if (rows.length !== 1) {blocked[clientId]={sourceRows:rows.map(r=>r.row),codes:['DUPLICATE_ID']};continue;}
    const r=rows[0];
    try {
      Core.need(Object.keys(r.errors).length === 0,'CELL_ERROR','Excel-Fehler/fehlender Formelcache.');
      const e = {clientId,sourceRow:r.row,usc:Core.text(r.L),dc:Core.flag(r.C,'C'),ppPlus:Core.flag(r.D,'D'),dbPlus:Core.flag(r.E,'E'),formulas:r.formulas};
      e.description=Core.description(e);entries[clientId]=e;
    } catch (err) {blocked[clientId]={sourceRows:[r.row],codes:[err.code ?? 'INVALID_ROW']};}
  }
  const payload={mode,generatedAt:new Date().toISOString(),rule:Core.RULE,
    source:{...book.meta,headerLConfirmed:true,formulaPolicy:'CACHED_VALUES_ONLY_NOT_RECALCULATED'},
    summary:{validKeys:Object.keys(entries).length,blockedKeys:Object.keys(blocked).length,unattributedRows:unattributed.length},
    entries,blocked,unattributed};
  const map={schema:Core.SCHEMA,payloadSha256:sha256(JSON.stringify(payload)),payload};
  Core.validateMap(map);return map;
}
export function exportMapping(filename, outputDir, options) {
  const book=readWorkbook(filename);
  if(options?.expectedSha) Core.need(book.meta.sha256===options.expectedSha,'SOURCE_CHANGED','Quelldatei hat sich nach der Freigabe geaendert. Erneut pruefen.');
  const map=makeMapping(book,options);
  Core.need(map.payload.summary.validKeys > 0,'NO_VALID_RECORDS','Kein nutzbarer Datensatz. Kein Mapping geschrieben.');
  fs.mkdirSync(outputDir,{recursive:true});
  const stamp=new Date().toISOString().replace(/[:.]/g,'-');
  const dest=path.join(outputDir,`INTL01_mapping_${stamp}_${book.meta.sha256.slice(0,8)}.json`);
  const tmp=dest+'.tmp', raw=JSON.stringify(map,null,2)+'\n';
  try {fs.writeFileSync(tmp,raw,{flag:'wx',mode:0o600});fs.renameSync(tmp,dest);}
  finally {if(fs.existsSync(tmp)) fs.unlinkSync(tmp);}
  const fileHash=sha256(raw);
  fs.writeFileSync(dest+'.sha256',fileHash+'  '+path.basename(dest)+'\n',{flag:'wx',mode:0o600});
  return {dest,fileHash,summary:map.payload.summary,source:map.payload.source};
}
