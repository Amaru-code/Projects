import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
import {sha256} from '../lib/core.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
try {
 const [major,minor]=process.versions.node.split('.').map(Number);
 if(major<22||(major===22&&minor<15))throw new Error('Node.js >=22.15 wird fuer dieses Paket vorausgesetzt.');
 const manifest=JSON.parse(fs.readFileSync(path.join(root,'MANIFEST.json'),'utf8'));
 for(const p of manifest.payload){
  if(p.path.startsWith('/')||p.path.includes('..')||p.path.includes('\\')||p.path.includes(':'))throw new Error('Unsicherer Manifestpfad.');
  const raw=fs.readFileSync(path.join(root,p.path));
  if(raw.length!==p.bytes||sha256(raw)!==p.sha256)throw new Error('Hash/Laenge abweichend: '+p.path);
 }
 console.log('Paketintegritaet PASS | Dateien:',manifest.payload.length,'| Node:',process.versions.node);
} catch(e){console.error('STOP:',e.message);process.exitCode=1;}
