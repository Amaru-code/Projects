@echo off
start "" "%~dp0DEMO.html"
