# Testbericht – MCR Datenbrücke 0.2

Stand: 29.09.2026. **Entwicklungsnachweis, kein Produktivnachweis für COMARCH.**

## Node-Tests: 91 / 91 bestanden

Ausgeführt unter Node.js 22.16.0, Linux. Keine npm-Abhängigkeiten.
55 Tests der aus dem vorhandenen v0.1.0-Paket übernommenen Regel- und XLSX-Bausteine und 36 neue Tests.
Vollständige TAP-Ausgabe: `NODE_TEST_RESULT.tap`.

Abgedeckt: alle sieben nichtleeren DC/PP+/DB+-Kombinationen; exakte ID-Zuordnung; führende Nullen als gespeicherte Zeichen;
Duplikatsperren; ungültige/fehlende Flags und USC; keine Merkmale; fehlende Kennungen;
Formelkennzeichnung; erforderliche L-Freigabe; Integrität des JSON-Payloads;
Mail-Header/Signatur als Kandidaten, numerischer Login als ID-Hinweis;
keine Telefon-/Ticketnummern als frei geratene Personenkennung;
mehrere Adressen/Weiterleitung; keine Gender-/Empfängerentscheidung;
XLSX-End-to-End-Export der enthaltenen fiktiven Datei; Quelldatei dabei bytegleich unverändert;
Erkennung einer nach Quellenfreigabe abweichenden SHA256.

## Browser-Funktionsprüfungen: 19 / 19 bestanden

Linux Chromium, Playwright als **Testwerkzeug**. Die Nutzersoftware selbst benötigt Playwright nicht.
Ergebnisse: `BROWSER_TEST_RESULT.json`. Reproduktionsskript: `tests/browser_qualification.py`.

Die Container-Browserrichtlinie blockiert Navigation einschließlich `file://`.
Diese Richtlinie wurde **nicht geändert oder umgangen**. Stattdessen wurde eine ausschließlich synthetische DOM-Testseite direkt im Testbrowser bereitgestellt.
Auf `about:blank` fehlt der sichere Ursprung für die native WebCrypto-API.
Der Test stellte daher für `crypto.subtle.digest('SHA-256', ...)` einen Testadapter zu Python `hashlib.sha256` bereit.
Das Produktionsbundle blieb unverändert und verlangt weiterhin eine tatsächlich verfügbare WebCrypto-API.
**Dies qualifiziert weder native HTTPS-/Datei-Navigation, noch die Windows-Zwischenablage, noch Unternehmens-CSP, noch native WebCrypto-Berechtigungen.**

Geprüft wurden: Initialisierung; Wiederinstallation ohne doppeltes Panel; Dateiauswahl und Mapping-Validierung;
gezielte Textauswahl; Member-Feld mit Doppelpunkt-ID;
Quellen-/Identitätsfreigaben; korrekte Lookup-Vorschau;
unveränderte Kategorie/Beschreibung und null Send-/Save-Aufrufe;
Erkennung eines geänderten Member-Feldes; Ablehnung von `body` als Mailquelle;
gezieltes Same-Origin-Frame-Lesen; Abweisung des Ausgangseditors;
Mail-/Member-ID-Konflikt;
Diagnose ohne Identifikatoren, Namen oder Mailinhalte;
Browser-generiertes Diagnose-ZIP mit CRC, Manifest und SHA256-Prüfung;
Hashabweichung bei verändertem Mapping;
keine vom Helfer verursachten Netzwerkrequests im geprüften Lese-/Lookup-Ablauf;
Schließen und Entfernen des Panels/API.

## Hier nicht ausgeführt

- Echtes Windows oder die Windows-CMD-Starter.
- Die private Datei auf K: oder tatsächliche Personen-/Plan-Daten.
- Die konkrete COMARCH-Installation, echte Auswahl-Commit-Logik oder Navigationswechsel.
- Mailtextgewinnung aus Bild-PDFs, Canvas oder nicht zugreifbaren Cross-Origin-Viewern.
- Automatische richtige Personenzuordnung für beliebige E-Mails.
- Ermittlung einer Anrede oder automatischer Empfängerwechsel.
- Automatischer Versand, Popup-Freigaben, Speichern oder Queue-Verarbeitung.

Es gibt im neuen Helfer keine produktiven Send-/Save-/Formularschreibfunktionen.
Die direkte Dateiauswahl lädt das vollständige minimierte Lookup-Mapping in den DOM-Seitenkontext;
der Kontext ist keine Datenschutz-Sandbox gegenüber anderen Skripten dieser Seite.

## Paketintegrität

Das Auslieferungs-ZIP wird abschließend auf CRC, sichere eindeutige Pfade und SHA256 für alle Manifest-Payloads geprüft.
Ein einfacher Muster-Scan sucht eingebettete private Schlüssel, übliche Tokenformate und versehentlich kopierte reale Mailadressen.
Das ist **kein vollständiger DLP-/Malware- oder Sicherheitsnachweis**.
Es befinden sich keine echten Mappings, Mailinhalte oder Browserprofile im Paket; nur fiktive Demo-Daten.
