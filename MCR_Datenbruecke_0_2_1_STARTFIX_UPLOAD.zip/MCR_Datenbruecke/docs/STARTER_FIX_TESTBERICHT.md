# Starterfix 0.2.1 – Prüfnachweis

Ausgeführt unter Linux mit Node.js 22.16.0. Keine echten personenbezogenen Daten.

## Tatsächlich ausgeführt

- 91 bestehende Node-Tests für Regeln, XLSX, Mapping und Mail-Kandidaten: PASS.
- 8 zusätzliche statische Starter-Quelltexttests: PASS.
- Gesamter Testlauf: **99 PASS, 0 FAIL, 0 SKIP**. Rohdaten: `STARTER_FIX_NODE_TEST_RESULT.tap`.
- Die JavaScript-Versionsprobe des Starters direkt mit dem vorhandenen Linux-Node: PASS.
- Demo-CLI-Export mit der vorhandenen fiktiven XLSX: PASS, neue JSON-Datei erzeugt.
- SHA256 der Demo-XLSX vor/nach Export gleich: Quelldatei unverändert.
- Unveränderte Fachlogik/Browserdateien byteweise gegen das ausgelieferte 0.2.0-Archiv geprüft.
- Die 99 Tests werden zusätzlich aus dem entpackten ZIP in einem anderen Pfad mit Leerzeichen ausgeführt.
  Auch das ist ein Linux-Test, keine Windows-CMD-Ausführung.

## Was die acht statischen Tests nachweisen

ASCII/CRLF; Dateiname `node.exe` vor Kandidatenaufruf geprüft; Existenz/Verzeichnisprüfung vor Aufruf;
beide früher dokumentierten Portable-Suchorte enthalten; getrennte Node-/Excel-Prompts;
Anführungszeichenbereinigung und deaktivierte Delayed Expansion; Node-Version vor Annahme;
kein CALL eines Benutzerpfades, keine Installation oder Policy-Umgehung.

**Diese Tests führen CMD nicht aus. Ein echter Windows-Start ist weiterhin nicht in diesem Container geprüft.**
Die Existenz deiner Portable-Node-Dateien wird erst beim lokalen Start geprüft.
Kein Nachweis für die tatsächliche K:-Datei, eine reale COMARCH-Verbindung oder Unternehmensrichtlinien.
Browsercode unverändert; dessen früherer Testbericht bleibt ein historischer Nachweis aus 0.2.0.

## Änderungen

`RUN.cmd`, Eingabeaufforderung/Banner in `src/export-mapping.mjs`, Paketversion,
Startdokumentation, neuer statischer Startertest und neue Prüfarbelege.
Zusätzlich die bestehende Testdatei `tests/bridge.test.mjs`: `fileURLToPath` statt URL-`pathname`,
damit die Demo-Testpfade auch mit Leerzeichen und Windows-Laufwerksbuchstaben korrekt entstehen.
Es wurden keine Assertions entfernt oder abgeschwächt.
Kein geändertes Spaltenmapping, keine neue Quellenfreigabe, keine Browser-Feldbefüllung,
kein Versand, kein Excel-Schreibzugriff, keine mitgelieferte Runtime.

## Paketprüfung

Beim Verpacken werden CRC, sichere eindeutige ZIP-Pfade, Manifest-Payload-SHA256 und
SHA256SUMS geprüft. `MANIFEST.json` enthält die Hashes aller Payload-Dateien;
`SHA256SUMS.txt` enthält zusätzlich den Hash des Manifests. Der ZIP-Hash wird extern ausgegeben.
Ein einfacher Musterscan ist kein vollständiger DLP-, Malware- oder Sicherheitsnachweis.
