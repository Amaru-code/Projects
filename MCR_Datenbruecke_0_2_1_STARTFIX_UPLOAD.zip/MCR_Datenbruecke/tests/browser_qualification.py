import json, pathlib, zipfile, io, hashlib, time, re
from playwright.sync_api import sync_playwright
R=pathlib.Path(__file__).resolve().parents[1]
results=[]
def mark(name):
 results.append({'name':name,'status':'PASS'}); print('PASS',name,flush=True)
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True)
 page=browser.new_page(viewport={'width':1500,'height':1100})
 # Navigation is blocked by container policy. Do not change it. Inject a local
 # synthetic document instead; only SHA-256 is provided by the Python harness
 # because about:blank is not a secure context. Production bundle unchanged.
 html=re.sub(r'<script[^>]*>[\s\S]*?</script>','',(R/'DEMO.html').read_text())
 page.set_content(html)
 page.expose_function('__mcrTestSha256',lambda bytes_:list(hashlib.sha256(bytes(bytes_)).digest()))
 page.evaluate('''Object.defineProperty(crypto,'subtle',{value:{digest:async (algorithm,data)=>{if(algorithm!=='SHA-256')throw Error('Unsupported test digest');return new Uint8Array(await window.__mcrTestSha256(Array.from(new Uint8Array(data)))).buffer;}}})''')
 page.evaluate("globalThis.testSends=0;globalThis.testSaves=0;document.getElementById('mainForm:send-new-message-button').onclick=()=>testSends++;document.getElementById('save').onclick=()=>testSaves++;void 0;")
 page.evaluate((R/'COMARCH_DATENBRUECKE.js').read_text())
 print('origin',page.evaluate('({url:location.href, secure:isSecureContext, api:!!window.MCR_DATA, crypto:!!crypto.subtle})'),flush=True)
 assert page.evaluate('!!window.MCR_DATA')
 mark('Lokale Demo und Konsole-Bundle initialisieren')
 script=(R/'COMARCH_DATENBRUECKE.js').read_text()
 page.evaluate(script)
 assert page.locator('#__mcr_data_bridge_v2').count()==1
 mark('Wiederholte Installation erzeugt genau ein Panel')
 outgoing=[]
 page.on('request',lambda request: outgoing.append(request.url))
 map_text=(R/'examples/DEMO_mapping.json').read_text()
 page.locator('#__mcr_data_bridge_v2 input[type=file]').set_input_files(str(R/'examples/DEMO_mapping.json'))
 page.get_by_text('Mapping geprüft.',exact=False).wait_for()
 assert page.evaluate('MCR_DATA.diagnostic().mapping.validKeys')==7
 mark('Dateiauswahl liest und prueft JSON-Mapping')
 # Select only incoming text in page, preserving selection when pressing helper button.
 page.evaluate('''()=>{const s=getSelection(),r=document.createRange();r.selectNodeContents(document.getElementById('incoming'));s.removeAllRanges();s.addRange(r);}''')
 page.get_by_role('button',name='Markierten Mailtext lesen',exact=True).click()
 page.get_by_text('Mailtext lokal gelesen.',exact=False).wait_for()
 assert page.evaluate('MCR_DATA.diagnostic().mail.idCandidates')>=1
 mark('Gezielt markierter Mailtext wird gelesen und analysiert')
 page.get_by_role('button',name='Ausgewählten Member lesen',exact=True).click()
 assert page.evaluate('MCR_DATA.diagnostic().member.fieldRead')
 mark('Konkretes Member-Input mit Doppelpunkten in ID gelesen')
 err=page.evaluate('''()=>{try{MCR_DATA.preview();return null;}catch(e){return e.code;}}''')
 assert err=='SOURCE_REVIEW',err
 mark('Lookup ohne Quellenfreigabe blockiert')
 page.get_by_label('Diese Excel-Version und Spalte L',exact=False).check()
 err=page.evaluate('''()=>{try{MCR_DATA.preview();return null;}catch(e){return e.code;}}''')
 assert err=='IDENTITY_REVIEW',err
 mark('Lookup ohne Identitaetsfreigabe blockiert')
 page.get_by_label('Den richtigen Member',exact=False).check()
 result=page.evaluate('MCR_DATA.preview()')
 assert result['description']=='USC 10/ PP+'
 mark('JSON-Mapping + Member -> USC 10/ PP+')
 state=page.evaluate('''()=>({desc:document.getElementById('description').value,send:testSends,save:testSaves,cat:document.getElementById('mainForm:category-value-id').value})''')
 assert state==dict(desc='UNVERAENDERT',send=0,save=0,cat='unverändert'),state
 mark('Ticketfelder und Versand/Speichern unveraendert')
 page.evaluate("document.getElementById('mainForm:member-value-id').value='Andere Person (INTL01-99900002)'")
 err=page.evaluate('''()=>{try{MCR_DATA.preview();return null;}catch(e){return e.code;}}''')
 assert err=='MEMBER_CHANGED',err
 mark('Member-Wechsel invalidiert vorherige Freigabe')
 page.evaluate("document.getElementById('mainForm:member-value-id').value='Testperson Alex (INTL01-99900001)'")
 err=page.evaluate('''()=>{try{MCR_DATA.readElement(document.body);return null;}catch(e){return e.code;}}''')
 assert err=='ELEMENT_TOO_BROAD'
 mark('Gesamte Seite/Body als Mailquelle verweigert')
 frame_result=page.evaluate("MCR_DATA.readElement(document.getElementById('incomingFrame').contentDocument.getElementById('mail'))")
 assert frame_result['idCandidates']==1
 mark('Same-Origin-Frame: gezieltes Textelement ausgelesen')
 err=page.evaluate('''()=>{try{MCR_DATA.readElement(document.getElementById('outgoingFrame').contentDocument.body.firstChild.parentElement);return null;}catch(e){return e.code;}}''')
 assert err=='ELEMENT_TOO_BROAD'
 # inner editable child
 page.evaluate("document.getElementById('outgoingFrame').contentDocument.body.innerHTML='<p id=out>Dies ist die ausgehende Nachricht.</p>'")
 err=page.evaluate('''()=>{try{MCR_DATA.readElement(document.getElementById('outgoingFrame').contentDocument.getElementById('out'));return null;}catch(e){return e.code;}}''')
 assert err=='NOT_MAIL_TEXT',err
 mark('Ausgehender Editor wird nicht mit Eingangsmail verwechselt')
 # Identity mismatch
 page.evaluate("document.getElementById('incoming').innerText='ClientEEID: 99900002'")
 page.evaluate("MCR_DATA.readElement(document.getElementById('incoming'))")
 page.get_by_label('Den richtigen Member',exact=False).check()
 err=page.evaluate('''()=>{try{MCR_DATA.preview();return null;}catch(e){return e.code;}}''')
 assert err=='MAIL_MEMBER_CONFLICT',err
 mark('Widerspruch Mail-Kennung vs Member blockiert')
 page.evaluate("document.getElementById('incoming').innerText='ClientEEID: 99900001'")
 page.evaluate("MCR_DATA.readElement(document.getElementById('incoming'))")
 page.get_by_label('Den richtigen Member',exact=False).check()
 page.evaluate('MCR_DATA.preview()')
 diagnostic=page.evaluate('MCR_DATA.diagnostic()')
 serialized=json.dumps(diagnostic)
 for secret in ['99900001','Alex Testperson','alex@example.invalid','USC 10/ PP+']:
  assert secret not in serialized, secret
 mark('Diagnose enthaelt keine IDs, Namen, Mailinhalte oder Lookup-Werte')
 raw=bytes(page.evaluate('async()=>Array.from(await MCR_DATA.diagnosticBytes())'))
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  assert z.testzip() is None
  assert sorted(z.namelist())==sorted(['diagnostic.json','manifest.json','SHA256SUMS.txt'])
  man=json.loads(z.read('manifest.json'))
  assert hashlib.sha256(z.read('diagnostic.json')).hexdigest()==man['payload'][0]['sha256']
  for line in z.read('SHA256SUMS.txt').decode().splitlines():
   digest,name=line.split('  ');assert hashlib.sha256(z.read(name)).hexdigest()==digest
 mark('Browser-Diagnose-ZIP: CRC und Hashes geprueft')
 tampered=json.loads(map_text);tampered['payload']['entries']['99900001']['usc']='20';tampered['payload']['entries']['99900001']['description']='USC 20/ PP+'
 err=page.evaluate('''async text=>{try{await MCR_DATA.loadMapText(text);return null;}catch(e){return e.code;}}''',json.dumps(tampered))
 assert err=='MAP_HASH_MISMATCH',err
 mark('Manipulierte JSON-Nutzdaten durch Hashpruefung blockiert')
 assert not outgoing,outgoing
 mark('Keine Netzwerkrequests des Helfers waehrend Lese-/Lookup-Test')
 page.evaluate('MCR_DATA.close()')
 assert page.locator('#__mcr_data_bridge_v2').count()==0
 assert not page.evaluate('!!window.MCR_DATA')
 mark('Schliessen entfernt API und Panel')
 browser.close()
(R/'docs/BROWSER_TEST_RESULT.json').write_text(json.dumps({'environment':'Linux Chromium; injected synthetic DOM on about:blank; navigation blocked by existing container policy (unchanged). WebCrypto SHA-256 supplied by test harness using Python hashlib, not native browser secure-context qualification. Not COMARCH/Windows.','tests':results},indent=2)+'\n')
