import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const raw=fs.readFileSync(new URL('../RUN.cmd',import.meta.url));
const cmd=raw.toString('ascii');
const guard=cmd.slice(cmd.lastIndexOf('\r\n:tryNode\r\n'));
// Static source-contract tests, NOT a Windows CMD execution test.
test('Starter: ASCII with CRLF for Windows CMD',()=>{
 assert.ok(raw.every(b=>b<128)); assert.ok(cmd.includes('\r\n'));
 assert.ok(!/(?<!\r)\n/.test(cmd));
});
test('Starter: basename guard precedes candidate execution',()=>{
 assert.ok(guard.includes('if /i not "%%~nxF"=="node.exe" exit /b 1'));
 assert.ok(guard.indexOf('%%~nxF')<guard.indexOf('"%MCR_CANDIDATE%" -e'));
});
test('Starter: existence and directory guards precede execution',()=>{
 const invoke=guard.indexOf('"%MCR_CANDIDATE%" -e');
 for(const s of ['if not exist "%MCR_CANDIDATE%" exit /b 1','if exist "%MCR_CANDIDATE%\\" exit /b 1']){
  assert.ok(guard.indexOf(s)>=0);assert.ok(guard.indexOf(s)<invoke);
 }
});
test('Starter: known portable locations are included',()=>{
 assert.ok(cmd.includes('%USERPROFILE%\\projects\\Compiler\\javascript\\tools\\node\\node.exe'));
 assert.ok(cmd.includes('%USERPROFILE%\\projects\\Aktive_Projekte\\node\\tools\\node\\node.exe'));
});
test('Starter: Node program and Excel data prompts are separated',()=>{
 assert.ok(cmd.includes('SCHRITT 1/2: Node.js'));assert.ok(cmd.includes('SCHRITT 2/2:'));
 const exporter=fs.readFileSync(new URL('../src/export-mapping.mjs',import.meta.url),'utf8');
 assert.ok(exporter.includes('EXCEL-DATEI (.xlsx), nicht node.exe'));
});
test('Starter: quotes removed and delayed expansion off',()=>{
 assert.ok(cmd.includes('setlocal EnableExtensions DisableDelayedExpansion'));
 assert.ok(guard.indexOf('set "MCR_CANDIDATE=%MCR_CANDIDATE:"=%"')<guard.indexOf('%%~nxF'));
});
test('Starter: runtime version and release gate precedes acceptance',()=>{
 assert.ok(guard.includes("process.release.name!=='node'"));
 assert.ok(guard.includes('v[0]<22||(v[0]===22&&v[1]<15)'));
 assert.ok(guard.indexOf('if errorlevel 1 exit /b 1')<guard.indexOf('set "MCR_NODE=%MCR_CANDIDATE%"'));
});
test('Starter: no CALL of user path, installers or execution policy bypass',()=>{
 assert.ok(!/^call\s+"?%MCR_/im.test(cmd));
 assert.ok(!/ExecutionPolicy|powershell|winget|curl|npm install|start "".*MCR_CANDIDATE/i.test(cmd));
});
