import test from 'node:test';
import assert from 'node:assert/strict';
import {identifier,memberIdentifier,ticketIdentifier,makeDescription,makeMessage,email,emailsFromText,recipientMatches,buildPlan,ACK_BODY} from '../lib/core.mjs';
for(const [C,D,E,expected]of [[1,0,0,'DC'],[0,1,0,'PP+'],[0,0,1,'DB+'],[1,1,0,'DC;PP+'],[1,0,1,'DC;DB+'],[0,1,1,'PP+;DB+'],[1,1,1,'DC;PP+;DB+']]){
 test('Kürzelkombination '+expected,()=>assert.equal(makeDescription({C,D,E,L:10}),'USC 10/ '+expected));
}
test('Kein Kürzel bedeutet Halt',()=>assert.throws(()=>makeDescription({C:0,D:0,E:0,L:10}),/Keines/));
for(const value of ['',null,2,'true','1.0','x'])test('Ungültiges Eligibility-Merkmal '+String(value),()=>assert.throws(()=>makeDescription({C:value,D:1,E:0,L:10})));
for(const value of ['',null,'#N/A','20%', '10;DC'])test('Ungültiger USC '+String(value),()=>assert.throws(()=>makeDescription({C:1,D:0,E:0,L:value})));
test('Kennungen bleiben exakt',()=>{assert.equal(identifier('001234'),'001234');assert.equal(identifier(99900001),'99900001');assert.notEqual(identifier('001234'),identifier('1234'));});
for(const value of [0,'0','abc','1e8','123.0',-1,Number.MAX_SAFE_INTEGER])test('Kennungsfehler '+String(value),()=>assert.throws(()=>identifier(value)));
test('Member hat Mandant und exakt eine Kennung',()=>{assert.equal(memberIdentifier('Testperson (INTL01-99900001)'),'99900001');assert.throws(()=>memberIdentifier('TEST01-99900001'));assert.throws(()=>memberIdentifier('INTL01-1 INTL01-2'));});
test('Ticketwert statt ganzer Seite',()=>{assert.equal(ticketIdentifier('Ticket-ID: 90000001'),'90000001');assert.throws(()=>ticketIdentifier('Ticket-ID: 90000001 weitere Felder'));});
test('Vorlage exakt erhalten',()=>{const msg=makeMessage('Herr','Beispiel');assert.equal(msg,'Sehr geehrter Herr Beispiel,\n\n'+ACK_BODY);assert.equal(makeMessage('Frau','Beispiel').split('\n')[0],'Sehr geehrte Frau Beispiel,');assert.equal(makeMessage('Neutral','Beispiel').split('\n')[0],'Guten Tag Beispiel,');});
test('Keine automatische Anrede oder HTML-Injektion',()=>{assert.throws(()=>makeMessage('', 'Beispiel'));assert.throws(()=>makeMessage('Herr','<img src=x>'));assert.throws(()=>makeMessage('Herr','A\nB'));});
test('Genau ein Empfänger',()=>{assert.equal(email('x@example.invalid'),'x@example.invalid');assert.throws(()=>email('x@example.invalid;y@example.invalid'));assert.throws(()=>email('x@example.invalid\nBcc:z@example.invalid'));});
test('Adressliste/Empfängervergleich',()=>{assert.deepEqual(emailsFromText('An: X@EXAMPLE.INVALID'),['x@example.invalid']);assert.equal(recipientMatches('An: x@example.invalid','x@example.invalid'),true);assert.equal(recipientMatches('x@example.invalid y@example.invalid','x@example.invalid'),false);});
const meta={sheet:'Output',sha256:'test'},row={row:3,B:'99900001',C:0,D:1,E:0,L:10,formulas:[]};
const input={sourceSha:'test',clientId:'99900001',ticketId:'90000001',recipient:'x@example.invalid',lastName:'Beispiel',salutation:'Herr',sourceConfirmed:true,identityConfirmed:true,recipientConfirmed:true,greetingConfirmed:true};
test('Vollständiger Vorschauvertrag',()=>{const p=buildPlan(input,()=>row,meta);assert.equal(p.description,'USC 10/ PP+');assert.equal(p.excel.row,3);});
for(const key of ['sourceConfirmed','identityConfirmed','recipientConfirmed','greetingConfirmed'])test('Freigabe ist Pflicht '+key,()=>assert.throws(()=>buildPlan({...input,[key]:false},()=>row,meta)));
test('Quelldateihash verbindlich',()=>assert.throws(()=>buildPlan({...input,sourceSha:'other'},()=>row,meta)));
test('Formelcache ausdrücklich freigeben',()=>{assert.throws(()=>buildPlan(input,()=>({...row,formulas:['L']}),meta));assert.equal(buildPlan({...input,cacheConfirmed:true},()=>({...row,formulas:['L']}),meta).excel.formulas[0],'L');});
