Hier erzeugte echte JSON-Mappings lokal behalten. Nicht hochladen, nicht committen.
Der Ordner ist weder verschluesselt noch eine Zugriffsgrenze. Betrieblich freigegebenen Speicherort verwenden.
