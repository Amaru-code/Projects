@echo off
start "" notepad.exe "%~dp0COMARCH_DATENBRUECKE.js"
