# MCR Datenbrücke 0.2.1 – Starterkorrektur

**Erweiterung für den bestehenden Ticketassistenten, kein fertiger Versandbot.**
Stand: 29.09.2026. Dieses Paket ersetzt oder startet den früheren `MCR_Ticket_Assistent` nicht.
Als Unterordner im Projekt ablegen oder separat entpacken. Der alte Assistent bleibt unverändert.

## Was jetzt funktioniert

1. Die genannte `Output`-Tabelle lokal mit Node lesen und als minimiertes JSON-Mapping exportieren.
2. Einen von dir ausgewählten Mailtext in COMARCH gezielt lesen; Namen, Adressen und beschriftete Kennungen als **Kandidaten** anzeigen.
3. Die Kennung aus dem von dir tatsächlich gewählten Member lesen und exakt im Mapping nachschlagen.
4. Die Beschreibung `USC {L}/ DC;PP+;DB+` als Vorschau erzeugen und auf ausdrücklichen Klick kopieren.
5. Ein datensparsames Diagnose-ZIP ohne Mailtext, Namen, Kennungen oder Mapping-Inhalte erzeugen.

**Keine Ticketfelder werden beschrieben. Keine Person wird automatisch gewählt. Keine E-Mail wird gesendet und kein Ticket gespeichert.**
Auch keine automatische Anrede, kein automatischer Empfängerwechsel und kein Queue-Runner.

## 1. Zuerst optional eine vollständige lokale Demo

`DEMO_STARTEN.cmd` öffnen. In der rechten Bedienoberfläche `examples/DEMO_mapping.json` wählen.
Den eingehenden Beispieltext markieren, **Markierten Mailtext lesen** klicken, dann **Ausgewählten Member lesen**.
Die beiden Bestätigungen für Quelle und Member setzen. **USC / DC / PP+ / DB+ berechnen** liefert:

`USC 10/ PP+`

Alle Demo-Personen und -Kennungen sind fiktiv. Die Schaltflächen im Demo-Formular zählen nur lokale Klicks.
Eine lokale HTML-Datei kann durch Unternehmensrichtlinien gesperrt sein. Nicht umgehen; der eigentliche COMARCH-Helfer wird in der freigegebenen HTTPS-Seite verwendet.

## 2. Das echte JSON-Mapping erzeugen

`MAPPING_ERSTELLEN.cmd` doppelklicken. Zuerst wird **die Programmdatei `node.exe`** gesucht, noch nicht Excel.
Zusätzlich zu den bisherigen Runtime-Ordnern, PATH und üblichen Installationsorten werden diese vorhandenen Portable-Pfade geprüft:

- `%USERPROFILE%\projects\Compiler\javascript\tools\node\node.exe`
- `%USERPROFILE%\projects\Aktive_Projekte\node\tools\node\node.exe`

Ein fehlender oder unpassender Kandidat wird übersprungen. Es wird nichts installiert oder heruntergeladen.
Falls eine Eingabe nötig ist: vollständigen Pfad **zur `node.exe`** eintragen. Die Excel-Datei ist hier falsch und wird abgewiesen.
Erst nach erfolgreicher Runtime- und Paketprüfung folgt **Schritt 2: die Frage nach der `.xlsx`**.
Kein Administrator, Python oder `npm install` erforderlich.
Voraussetzung für dieses Paket: Node >=22.15.

Der voreingestellte Pfad ist:

```text
K:\INTL01\6_AU (Admin)\~ Data\~ Bestand Intel Gesamtübersicht\INTL01_Gesamtdatenbestand_30.09.2025.xlsx
```

**Enter** übernimmt diesen Pfad; ein anderer Pfad kann direkt eingegeben werden.
Das Programm zeigt Dateiname, Änderungszeit, SHA256, Spaltenüberschriften, Datensatzanzahl und Formel-/Duplikatanzahl.
Mit `JA` bestätigen, dass genau diese Datenquelle und Spalte L als USC richtig sind.
Eine nach dieser Bestätigung veränderte Quelldatei wird abgewiesen.

Erzeugt wird eine neue Datei in `private_data/INTL01_mapping_<Zeit>_<Hash>.json` sowie eine SHA256-Datei.
Vorhandene Snapshots werden nicht überschrieben. Eine neu exportierte Datei ist **nicht** automatisch fachlich aktueller: Der Quellenstand kann weiterhin 30.09.2025 sein.

### Datenvertrag

| Spalte | Bedeutung |
|---|---|
| B | ClientEEID, exakter Suchschlüssel als Zeichenfolge |
| L | USC |
| C | 1 -> DC |
| D | 1 -> PP+ |
| E | 1 -> DB+ |

Erforderliche Header: B `ClientEEID`, C `IsEligible_DC`, D `IsEligible_IPP`, E `IsEligible_PensIntel` (Leerraum/Unterstriche werden für diesen Headervergleich normalisiert).
L wird nicht geraten: Der angezeigte Header muss als USC bestätigt werden.
Es werden nur B/C/D/E/L und technische Quellenmetadaten übernommen, keine Namen, Geburtsdaten oder E-Mail-Adressen.
**Kennungen zusammen mit Planmerkmalen sind trotzdem personenbezogen – das Mapping ist nicht anonym.**

Doppelte Kennungen werden gesperrt, auch bei gleichen Werten. Leere oder abweichende Flags werden nicht zu 0 umgedeutet.
Fehlerhafte USC-Werte, Excel-Fehler und fehlende Formel-Caches sperren den betroffenen Schlüssel. C=D=E=0 wird zur manuellen Klärung gesperrt.
Weitere gültige Schlüssel können verwendet werden. Sperren stehen im JSON unter `blocked`.
Grundlegende Struktur-/Header-/Kennungsfehler können den gesamten Export stoppen.
Unzuordenbare Datenzeilen werden gezählt und mit Zeilennummer, nicht mit allen Inhalten, dokumentiert.

Text-IDs behalten führende Nullen. Excel-Zellformatierungen werden nicht angewandt; eine ausschließlich durch Zahlenformatierung angezeigte Null ist kein gespeichertes Zeichen der Kennung.
Normale, unverschlüsselte `.xlsx`-Dateien sind unterstützt; kein `.xls`, `.xlsb`, ZIP64 oder allgemein beliebiges Excel-Format.
Maximal 80 MiB komprimierte XLSX-Datei, zusätzliche Entpackgrenzen. Die JSON-Auswahl im Browser ist auf 32 MiB begrenzt.

Formeln werden **nicht neu berechnet**. Verwendet wird der in der XLSX gespeicherte letzte Berechnungswert; betroffene Zeilen bleiben markiert.
Die Aktualität solcher Werte musst du prüfen, bevor du eine Beschreibung verwendest. Keine automatischen Updates externer Excel-Verknüpfungen.

## 3. In COMARCH einsetzen

COMARCH wie gewohnt öffnen und das gewünschte Ticket selbst in den Bearbeitungsmodus bringen.
Schon dein manueller Klick auf **Bearbeiten** kann das Ticket übernehmen; „nur lesen“ bezieht sich auf den Helfercode, nicht auf diese Bedienhandlung.

1. `KONSOLE_OEFFNEN.cmd` öffnen. Das öffnet den vollständigen Helfertext in Notepad.
2. **Strg+A, Strg+C**. Nicht die `.js` per Doppelklick im Windows Script Host ausführen.
3. Edge **F12 -> Konsole**, als Ausführungskontext möglichst `top` wählen.
4. Den vollständigen Text einfügen und Enter drücken. Keine Downloads, Fetch-Befehle oder zusätzlichen Imports nötig.
5. Im Panel das echte Mapping aus `private_data` auswählen und den Quellenstand bestätigen.

Keine DevTools-/Unternehmenssperren automatisiert umgehen. Bei blockierter Skriptausführung mit der IT klären.
Der alte V1-Inspector wird im aktuellen zugreifbaren Top-Kontext angehalten. Seine gespeicherten Aufzeichnungen bleiben bestehen.
Bei einem anderen Browserfenster oder einem Seiten-Neuladen den Helfer dort neu einfügen und das Mapping neu laden.

### Mail gezielt lesen

**Bevorzugt:** Im Nachrichtenverlauf nur den Text der aktuellen eingehenden Nachricht mit der Maus markieren, einschließlich passender Header/Signatur. Dann **Markierten Mailtext lesen**.
Nicht die ganze Historie, Seitenleisten, Dokumentsignaturen oder die ausgehende Nachricht markieren.

**Alternative:** Auf die konkrete Textzelle im Nachrichtenverlauf rechtsklicken -> **Untersuchen**. Danach in der Konsole:

```javascript
MCR_DATA.readElement($0)
```

`$0` muss die konkrete Textzelle/Textpassage sein. `body`, `html`, Gesamtformular, Bild, Canvas, Link und bearbeitbarer Ausgangseditor werden abgelehnt.
Bei Bedarf im Elemente-Baum das passende `td`, `div` oder `p` wählen. Die tatsächliche Mailpassage muss sichtbar sein.
Enthält die Darstellung nur ein Bild/Canvas oder liegt der Text in einem nicht direkt zugreifbaren Frame, liest der Helfer daraus **keinen erfundenen Text**.
Dann die Textdarstellung des Nachrichtenverlaufs verwenden oder den relevanten Mailtext bewusst in das Helfer-Textfeld kopieren und **Diesen Text auswerten** anklicken.
OCR und das Herunterladen von Mail-Anhängen sind in dieser Version nicht enthalten.

Die Ausgabe unterscheidet Namen aus beschrifteten Headern/Signaturen, E-Mail-Adressen und explizite ID-Hinweise.
Unbeschriftete Zahlen wie Telefonnummern oder Ticketnummern werden nicht als Personenkennung interpretiert.
Dies ist eine regelbasierte Unterstützung, **keine zuverlässige allgemeine Personenidentifikation für beliebige E-Mails**.
Weitere Personen, Weiterleitungen und Bitten um Empfängeränderung benötigen fachliche Prüfung. Die Warnungen erkennen nicht alle möglichen Formulierungen.

### Member und Beschreibung

Du wählst den passenden Member tatsächlich aus der COMARCH-Liste.
**Ausgewählten Member lesen** liest `mainForm:member-value-id` und verlangt darin genau eine `INTL01-...`-Kennung.
Das Lesen des Feldwerts allein beweist keine serverseitige Zuordnung; die ausdrückliche Bestätigung deiner tatsächlichen Auswahl bleibt Pflicht.
Quelle und Member bestätigen; bei Formeln zusätzlich den geprüften Berechnungsstand bestätigen.
**USC / DC / PP+ / DB+ berechnen** erzeugt dann die Vorschau mit Quellzeile und Einzelwerten.
Ein Widerspruch zwischen einer im Mailtext gefundenen Kennung und dem ausgewählten Member stoppt. Mehrere Mail-Kennungen stoppen ebenfalls.
Keine Mail-Kennung bedeutet nicht automatisch einen Fehler: Die Identität kann von dir anhand des Namens/Anliegens überprüft werden.

**Beschreibung kopieren** schreibt nur auf ausdrücklichen Klick in deine Zwischenablage. Du kannst sie selbst im Ticket einfügen oder zur Kontrolle mit dem bisherigen Assistenten vergleichen.
Vor dem nächsten Ticket **Neuer Fall** drücken; dadurch werden Mail, Member und Fallfreigaben verworfen. Das Mapping bleibt bis Schließen/Neuladen im Arbeitsspeicher.

## Datenschutz und lokale Speicherung

Nur auf dem freigegebenen Arbeitsplatz und im betrieblich erlaubten COMARCH-Kontext verwenden.
Das Skript hat keine eigenen HTTP-Aufrufe und ruft keine externen KI-Dienste auf. Normale Netzwerkkommunikation von COMARCH selbst läuft davon unabhängig weiter.
Die Dateiauswahl lädt das **gesamte minimierte Mapping in den Seitenkontext**. Dieser Kontext ist keine Sandbox gegenüber anderer Software derselben Seite.
Ein Shadow-DOM-Panel schützt nicht vor Zugriff durch Seitenskripte. Nur auf der autorisierten COMARCH-Seite laden.
Die Dateien unter `private_data` sind nicht verschlüsselt; `.gitignore` ist lediglich ein Schutz vor versehentlicher Versionsverwaltung.
Keine echten Mappings, Quelldateien, Anmeldesitzungen oder vollständigen Konsolenprotokolle hochladen.

## Diagnose für Weiterarbeit

Im Panel **Diagnose-ZIP** klicken. Ergebnis: genau eine `MCR_DATA_BRIDGE_<Zeit>_UPLOAD.zip`.
Sie enthält nur Strukturpfade ohne Werte, Zähler, Statuscodes und bekannte technische Feldkennungen, plus Manifest/Prüfsummen.
Mailtext, Namen, Personen-/Ticketnummern, Mailadressen, URLs, Cookies und Mappingzeilen werden nicht aufgenommen.
Eine strukturelle Mailpfad-Aufnahme mit `nth-of-type` ist noch kein dauerhaft stabiler Selektor. Der Pfad wird als erneuter Prüfhinweis dokumentiert.
Das Panel zeigt den äußeren ZIP-SHA256 an. Vor Weitergabe die ZIP prüfen; nur diese Diagnose hochladen.

## Bekannte offene Integrationspunkte

`docs/COMARCH_BINDINGS.json` trennt beobachtete IDs von ungeeigneten V1-Captures.
`body#document:body` ist kein Treffer für eine Kategorie-/Member-/Signatur-Option.
IDs mit `j_id...`, Queue-Zeilenpfade und Frame-Indizes sind nicht als dauerhaft stabil qualifiziert.
Die Kategorie-/Signatur-Inputs sind gefunden; ihre tatsächliche Auswahlbestätigung in COMARCH ist noch nicht qualifiziert.
Der Nachrichteneditor wurde nur als bearbeitbares `html` in einem Frame erfasst; der geeignete Editoradapter ist offen.
Keine neue Sendefreigabe, keine Qualifikation der zwei OK-Dialoge, kein Nachweis produktiver Speicherpersistenz.

## Tests / technische Details

`SELBSTTEST.cmd` prüft Manifest und alle 91 Node-Tests (55 übernommene Regel-/XLSX-Tests plus 36 Datenbrücken-Tests).
`docs/TESTBERICHT.md` enthält die genauen Testgrenzen. Das echte Windows-/COMARCH-System und die reale Excel-Datei wurden hier nicht ausgeführt.
Die Browser-Tests sind eine optionale Entwickler-Qualifikation mit Python/Playwright in einem Linux-Testcontainer, **keine Voraussetzung für deine Verwendung**.
Sie umgehen keine Browserrichtlinie; Details zur Test-Digest-Schnittstelle stehen im Testbericht.

`src/build.mjs` bündelt `lib/data-core.cjs` und `browser/ui.js` zu `COMARCH_DATENBRUECKE.js`.
Die Payload-Prüfsumme des Mappings schützt gegen Beschädigung, ist aber **keine digitale Signatur und keine Freigabe der Datenaktualität**.

## Technische Quellen

- Microsoft Edge DevTools, `$0`: https://learn.microsoft.com/en-us/microsoft-edge/devtools/console/utilities
- MDN, same-origin `contentDocument`: https://developer.mozilla.org/en-US/docs/Web/API/HTMLIFrameElement/contentDocument
- Microsoft, gespeicherte Formelwerte: https://learn.microsoft.com/en-us/office/open-xml/spreadsheet/working-with-formulas
- MDN, ausdrückliche Dateiauswahl: https://developer.mozilla.org/en-US/docs/Web/API/File_API/Using_files_from_web_applications
