/* Source fragment: bundled with data-core.cjs by src/build.mjs. Reads only. */
'use strict';
const W = window;
try {W.MCR_DATA?.close();} catch {}
let T=W;
try {void W.top.document.body;T=W.top;} catch {}
// The V1 Inspector left click handlers even when its panel was hidden.
// They call this global dispatch function, so suspend it; do not clear V1 data.
try {
  if(T.__mcrInspectorTimer) {T.clearInterval(T.__mcrInspectorTimer);T.__mcrInspectorTimer=null;}
  if(T.__MCR_CAPTURE_CLICK) T.__MCR_CAPTURE_CLICK=()=>{};
  T.document.getElementById('__mcr_comarch_inspector')?.remove();
} catch {}
const D=T.document;
D.getElementById('__mcr_data_bridge_v2')?.remove();
const host=D.createElement('div');host.id='__mcr_data_bridge_v2';
Object.assign(host.style,{position:'fixed',right:'12px',top:'12px',zIndex:'2147483647',width:'430px',maxWidth:'94vw'});
const shadow=host.attachShadow({mode:'open'});
const style=D.createElement('style');
style.textContent=`:host{font:13px/1.4 Segoe UI,Arial,sans-serif;color:#142330}*{box-sizing:border-box}section{background:#f9fbfd;border:2px solid #234660;border-radius:9px;box-shadow:0 4px 28px #0005;padding:13px;max-height:90vh;overflow:auto}h2{font-size:17px;margin:0 0 8px}p{margin:8px 0}button,input,textarea{font:inherit}button{padding:6px 9px;cursor:pointer;margin:3px 3px 3px 0}textarea{width:100%;min-height:90px;padding:6px}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#eaf0f5;padding:9px;max-height:170px;overflow:auto}label{display:block;margin:7px 0}input[type=file]{max-width:100%}.note{font-size:12px;color:#4b5660}.status{font-weight:600}details{margin:8px 0}summary{cursor:pointer;font-weight:600}`;
shadow.append(style);const panel=D.createElement('section');shadow.append(panel);
const ui={};
function el(tag,txt,parent=panel) {const n=D.createElement(tag);if(txt!==undefined)n.textContent=txt;parent.append(n);return n;}
function button(label,fn,parent=panel){const b=el('button',label,parent);b.type='button';b.addEventListener('mousedown',e=>e.preventDefault());b.onclick=()=>Promise.resolve().then(fn).catch(showError);return b;}
function check(label){const l=el('label');const c=D.createElement('input');c.type='checkbox';l.append(c,D.createTextNode(' '+label));return c;}
function showError(e){lastError=e.code??'ERROR';ui.status.textContent=lastError+': '+e.message;ui.result.textContent='Keine aktuelle Vorschau.';}
function clearResult(){ui.result.textContent='Keine aktuelle Vorschau.';lastLookup=false;}
let map=null, member=null, analysis=null, mailSource=null, lastError=null, lastLookup=false, closed=false, generation=0;
el('h2','MCR Datenbrücke 0.2 · nur lesen');
el('p','Kein Senden, Speichern oder automatisches Auswählen. Das Mapping wird in den Arbeitsspeicher dieser COMARCH-Seite geladen.').className='note';
ui.status=el('p','Start: Mapping auswählen oder zuerst Mailtext lesen.');ui.status.className='status';
ui.file=el('input');ui.file.type='file';ui.file.accept='.json,application/json';
ui.source=el('pre','Noch kein Mapping geladen.');
ui.sourceOK=check('Diese Excel-Version und Spalte L als USC sind fachlich richtig und aktuell genug.');
button('Markierten Mailtext lesen',readSelection);
const details=el('details');el('summary','Mailtext / alternative manuelle Eingabe',details);
el('p','Nur die aktuelle eingehende Nachricht markieren, nicht den gesamten Verlauf. Keine Ausgabe an Server/LLM. Bei Bedarf den relevanten Text hier selbst einfügen.',details).className='note';
ui.mail=el('textarea',undefined,details);ui.mail.placeholder='Hier nur den Text des aktuellen Anliegens, Header und Signatur einfügen.';
button('Diesen Text auswerten',()=>setMail(ui.mail.value,{kind:'MANUAL_TEXT'}),details);
ui.mail.addEventListener('input',()=>{analysis=null;mailSource=null;ui.identityOK.checked=false;clearResult();});
ui.candidates=el('pre','Noch kein Mailtext erfasst.');
button('Ausgewählten Member lesen',readMember);
ui.member=el('pre','Noch kein Member gelesen.');
ui.identityOK=check('Den richtigen Member aus der COMARCH-Trefferliste ausgewählt und mit diesem Ticket abgeglichen.');
ui.cacheOK=check('Falls diese Zeile Formeln enthält: gespeicherte Berechnungsergebnisse geprüft.');
button('USC / DC / PP+ / DB+ berechnen',preview);
ui.result=el('pre','Keine aktuelle Vorschau.');
button('Beschreibung kopieren',async()=>{
  const r=preview();Core.need(navigator.clipboard,'CLIPBOARD','Zwischenablage nicht verfügbar. Vorschau manuell markieren.');
  await navigator.clipboard.writeText(r.description);ui.status.textContent='Beschreibung kopiert. Kein COMARCH-Feld wurde verändert.';
});
button('Neuer Fall',resetCase);button('Diagnose-ZIP',downloadDiagnostic);button('Schließen',close);
for(const c of [ui.sourceOK,ui.identityOK,ui.cacheOK])c.addEventListener('change',clearResult);
D.body.append(host);

function documents() {
 const items=[],seen=new Set();
 function visit(doc,frames,depth){
   if(!doc||seen.has(doc)||depth>8||items.length>=64)return;
   seen.add(doc);items.push({doc,frames,accessible:true});
   const fs=[...doc.querySelectorAll('iframe,frame')];
   fs.slice(0,64).forEach((f,i)=>{let child=null;try{child=f.contentDocument;}catch{}if(child)visit(child,[...frames,i],depth+1);else items.push({doc:null,frames:[...frames,i],accessible:false});});
 }
 visit(D,[],0);return items;
}
function frameInventory(){return documents().map(x=>({frames:x.frames,accessible:x.accessible,
  editable:x.doc?x.doc.designMode==='on'||!!x.doc.querySelector('[contenteditable="true"]'):null}));}
function nodePath(node){
 const parts=[];let cur=node;
 for(let i=0;cur&&cur.nodeType===1&&i<14;i++,cur=cur.parentElement){
  const tag=cur.tagName.toLowerCase(),siblings=cur.parentElement?[...cur.parentElement.children].filter(n=>n.tagName===cur.tagName):[cur];
  parts.unshift(tag+':nth-of-type('+(siblings.indexOf(cur)+1)+')');
 }
 return parts.join(' > ');
}
function sourceOf(node,kind){
 const item=documents().find(x=>x.doc===node.ownerDocument);
 return {kind,frames:item?.frames??null,cssStructural:nodePath(node),tag:node.tagName.toLowerCase(),reusableWithoutRevalidation:false};
}
function setMail(text,source){
 const result=Core.analyzeMail(text); // no execution of any mail content
 ui.mail.value=text;analysis=result;mailSource=source;ui.identityOK.checked=false;clearResult();lastError=null;
 ui.candidates.textContent=JSON.stringify(result,null,2);
 ui.status.textContent='Mailtext lokal gelesen. Alle Namen, Kennungen und Adressen sind nur Kandidaten; keine Person ausgewählt.';
 return {characters:result.characters,idCandidates:result.idHints.length,nameCandidates:result.names.length,addressCandidates:result.emails.length};
}
function readSelection(){
 const selections=[];
 for(const item of documents()){
  if(!item.doc)continue;
  const s=item.doc.defaultView.getSelection();
  if(!s||s.isCollapsed||!s.toString().trim())continue;
  const node=s.anchorNode?.nodeType===1?s.anchorNode:s.anchorNode?.parentElement;
  if(!node||node.getRootNode()===shadow||node.closest?.('#__mcr_data_bridge_v2'))continue;
  Core.need(!node.isContentEditable && item.doc.designMode!=='on','OUTGOING_EDITOR','Das ist ein bearbeitbarer Editor, nicht die eingegangene Mail.');
  selections.push({text:s.toString(),source:sourceOf(node,'EXPLICIT_TEXT_SELECTION')});
 }
 Core.need(selections.length===1,'SELECTION_REQUIRED','Bitte genau den Text einer eingehenden Nachricht markieren. Alternativ Rechtsklick -> Untersuchen -> MCR_DATA.readElement($0).');
 return setMail(selections[0].text,selections[0].source);
}
function readElement(node){
 Core.need(node?.nodeType===1 && node.isConnected,'ELEMENT_REQUIRED','Ein verbundenes DOM-Element über $0 übergeben.');
 Core.need(documents().some(x=>x.doc===node.ownerDocument),'FRAME_UNAVAILABLE','Element gehört nicht zu einem direkt zugreifbaren Frame dieser Seite. Keinen Origin-Schutz umgehen.');
 Core.need(!['HTML','BODY','FORM','IFRAME','FRAME','CANVAS','IMG','OBJECT','EMBED'].includes(node.tagName),'ELEMENT_TOO_BROAD','Bitte die konkrete Mailzelle/Textpassage wählen, nicht Seite, Formular, Bild oder Viewer.');
 Core.need(!node.isContentEditable && node.ownerDocument.designMode!=='on' && !node.closest('input,textarea,button,a'),'NOT_MAIL_TEXT','Editor, Link oder Eingabefeld statt Mailpassage ausgewählt. Eine Textzelle wählen.');
 Core.need(node.getClientRects().length && node.getRootNode()!==shadow,'HIDDEN_ELEMENT','Element ist nicht sichtbar oder gehört zum Assistenten.');
 return setMail(node.innerText??'',sourceOf(node,'EXPLICIT_ELEMENT'));
}
function readMember(){
 member=null;ui.identityOK.checked=false;ui.member.textContent='Member wird gelesen ...';clearResult();
 const found=documents().flatMap(x=>x.doc?[...x.doc.querySelectorAll('[id="mainForm:member-value-id"]')]:[]).filter(n=>n.getClientRects().length);
 Core.need(found.length===1,'MEMBER_FIELD','Genau ein sichtbares Member-Feld erwartet. Ticket muss im Bearbeitungsmodus stehen.');
 const item=Core.selectedMember(found[0].value);
 member={...item,element:found[0]};ui.identityOK.checked=false;clearResult();lastError=null;
 ui.member.textContent='ClientEEID: '+item.clientId+'\nCOMARCH: '+item.display;
 ui.status.textContent='Kennung gelesen. Tatsächliche Auswahl aus der Trefferliste bitte bestätigen.';
 return {clientId:item.clientId};
}
async function sha(data){
 Core.need(globalThis.crypto?.subtle,'CRYPTO_REQUIRED','SHA-256 nicht verfügbar. Im freigegebenen HTTPS-COMARCH-Kontext ausführen.');
 const bytes=typeof data==='string'?new TextEncoder().encode(data):data;
 return [...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(x=>x.toString(16).padStart(2,'0')).join('');
}
async function loadMapText(text){
 const mine=++generation;map=null;ui.sourceOK.checked=false;ui.source.textContent='Mapping wird geprüft ...';clearResult();
 Core.need(text.length<=32*1024*1024,'MAP_SIZE','Mapping zu groß (maximal 32 MiB).');
 const parsed=JSON.parse(text);Core.validateMap(parsed);
 const demoContext=location.protocol==='file:'||location.href==='about:blank'||['localhost','127.0.0.1','[::1]'].includes(location.hostname);
 Core.need(parsed.payload.mode!=='DEMO'||demoContext,'DEMO_NOT_IN_COMARCH','DEMO-Mapping nur in der lokalen Demo verwenden. Für COMARCH das echte XLSX exportieren.');
 Core.need(await sha(JSON.stringify(parsed.payload))===parsed.payloadSha256,'MAP_HASH_MISMATCH','JSON-Prüfsumme stimmt nicht. Mapping neu exportieren.');
 Core.need(!closed&&mine===generation,'CANCELLED','Import durch neueren Vorgang ersetzt.');
 map=parsed;
 const p=parsed.payload;
 ui.source.textContent=[p.mode==='DEMO'?'DEMO - KEINE ECHTEN PERSONEN':'LOKALER EXCEL-SNAPSHOT',p.source.filename,'Blatt: '+p.source.sheet,'L: '+p.source.headers.L,'Datei geändert: '+(p.source.modifiedAt??'unbekannt'),'Exportiert: '+p.generatedAt,'Gültig: '+Object.keys(p.entries).length+' | Gesperrt: '+Object.keys(p.blocked).length,'Quelle SHA256: '+p.source.sha256].join('\n');
 ui.status.textContent='Mapping geprüft. Aktualität und Bedeutung der Quelldatei jetzt bestätigen.';lastError=null;
 return {validKeys:Object.keys(p.entries).length,blockedKeys:Object.keys(p.blocked).length,mode:p.mode};
}
ui.file.onchange=async()=>{try{const f=ui.file.files?.[0];if(!f)return;Core.need(f.size<=32*1024*1024,'MAP_SIZE','Datei zu groß.');await loadMapText(await f.text());}catch(e){map=null;showError(e);}};
function preview(){
 clearResult();Core.need(map,'MAP_REQUIRED','Zuerst ein Mapping laden.');
 Core.need(ui.sourceOK.checked,'SOURCE_REVIEW','Datenquelle und USC-Spalte bestätigen.');
 Core.need(member?.element?.isConnected,'MEMBER_REQUIRED','Den ausgewählten Member erneut lesen.');
 Core.need(member.element.value===member.display,'MEMBER_CHANGED','Member wurde seit dem Lesen geändert. Neu lesen und prüfen.');
 Core.need(ui.identityOK.checked,'IDENTITY_REVIEW','Richtigen Member bewusst bestätigen.');
 const mailIds=[...new Set(analysis?.idHints.map(x=>x.clientId)??[])];
 Core.need(mailIds.length<=1,'MAIL_AMBIGUOUS','Mehrere Kennungen im Mailtext. Nur die aktuelle Nachricht erfassen bzw. manuell klären.');
 Core.need(mailIds.length===0||mailIds[0]===member.clientId,'MAIL_MEMBER_CONFLICT','Kennung aus der Mail passt nicht zum ausgewählten Member. Manuell klären.');
 const e=Core.lookup(map,member.clientId);
 Core.need(!e.formulas.length||ui.cacheOK.checked,'FORMULA_CACHE_REVIEW','Diese Zeile enthält Formeln; gespeicherte Ergebnisse zuerst prüfen.');
 const result={clientId:e.clientId,sourceRow:e.sourceRow,usc:e.usc,dc:e.dc,ppPlus:e.ppPlus,dbPlus:e.dbPlus,description:Core.description(e)};
 ui.result.textContent=JSON.stringify(result,null,2);lastLookup=true;lastError=null;
 ui.status.textContent='VORSCHAU BEREIT. Keine COMARCH-Daten geändert, nichts versendet.';
 return result;
}
function resetCase(){member=null;analysis=null;mailSource=null;lastError=null;clearResult();ui.mail.value='';ui.candidates.textContent='Noch kein Mailtext erfasst.';ui.member.textContent='Noch kein Member gelesen.';ui.identityOK.checked=false;ui.cacheOK.checked=false;ui.status.textContent='Neuer Fall. Mapping bleibt im Arbeitsspeicher.';}
function diagnostic(){
 return {schema:'MCR_DATA_BRIDGE_DIAGNOSTIC_V1',version:'0.2.0',createdAt:new Date().toISOString(),
   capabilities:{sends:false,saves:false,writesComarchFields:false,readsSelectedMail:true},
   frames:frameInventory(),mailSource,
   mail:{read:!!analysis,characters:analysis?.characters??0,nameCandidates:analysis?.names.length??0,idCandidates:analysis?.idHints.length??0,addressCandidates:analysis?.emails.length??0},
   member:{fieldRead:!!member},mapping:{loaded:!!map,validKeys:map?Object.keys(map.payload.entries).length:0,blockedKeys:map?Object.keys(map.payload.blocked).length:0},
   lookupPreviewSucceeded:lastLookup,lastError,
   knownFields:['mainForm:responsibility-value-id','mainForm:category-value-id','mainForm:category-sub-value-id','mainForm:member-value-id','mainForm:signature-value-id','mainForm:send-new-message-button'].map(id=>({id,count:documents().reduce((sum,x)=>sum+(x.doc?.querySelectorAll('[id="'+id+'"]').length??0),0)}))};
}
function crc32(bytes){let c=0xffffffff;for(const b of bytes){c^=b;for(let k=0;k<8;k++)c=(c&1)?0xedb88320^(c>>>1):c>>>1;}return(c^0xffffffff)>>>0;}
function storeZip(files){
 let offset=0;const local=[],central=[],enc=new TextEncoder();
 const concat=parts=>{const all=new Uint8Array(parts.reduce((n,p)=>n+p.length,0));let i=0;for(const p of parts){all.set(p,i);i+=p.length;}return all;};
 for(const [name,text] of files){
  const n=enc.encode(name),data=enc.encode(text),crc=crc32(data),h=new Uint8Array(30),v=new DataView(h.buffer);
  v.setUint32(0,0x04034b50,true);v.setUint16(4,20,true);v.setUint16(6,0x800,true);v.setUint16(12,33,true);v.setUint32(14,crc,true);v.setUint32(18,data.length,true);v.setUint32(22,data.length,true);v.setUint16(26,n.length,true);
  const c=new Uint8Array(46),cv=new DataView(c.buffer);cv.setUint32(0,0x02014b50,true);cv.setUint16(4,20,true);cv.setUint16(6,20,true);cv.setUint16(8,0x800,true);cv.setUint16(14,33,true);cv.setUint32(16,crc,true);cv.setUint32(20,data.length,true);cv.setUint32(24,data.length,true);cv.setUint16(28,n.length,true);cv.setUint32(42,offset,true);
  local.push(h,n,data);central.push(c,n);offset+=h.length+n.length+data.length;
 }
 const cd=concat(central),end=new Uint8Array(22),ev=new DataView(end.buffer);ev.setUint32(0,0x06054b50,true);ev.setUint16(8,files.length,true);ev.setUint16(10,files.length,true);ev.setUint32(12,cd.length,true);ev.setUint32(16,offset,true);
 return concat([...local,cd,end]);
}
async function diagnosticBytes(){
 const report=JSON.stringify(diagnostic(),null,2)+'\n',hash=await sha(report);
 const manifest=JSON.stringify({schema:'MCR_DIAGNOSTIC_MANIFEST_V1',payload:[{path:'diagnostic.json',sha256:hash}],privacy:'No mail text, names, IDs, addresses, mapping rows, URLs, cookies, auth headers or form values are exported.'},null,2)+'\n';
 const sums=hash+'  diagnostic.json\n'+await sha(manifest)+'  manifest.json\n';
 return storeZip([['diagnostic.json',report],['manifest.json',manifest],['SHA256SUMS.txt',sums]]);
}
async function downloadDiagnostic(){
 const bytes=await diagnosticBytes(),hash=await sha(bytes),blob=new Blob([bytes],{type:'application/zip'}),url=URL.createObjectURL(blob),a=D.createElement('a');
 a.href=url;a.download='MCR_DATA_BRIDGE_'+new Date().toISOString().replace(/[:.]/g,'-')+'_UPLOAD.zip';a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);
 ui.status.textContent='Diagnose-ZIP erstellt. ZIP-SHA256: '+hash;
 return {zipSha256:hash};
}
function close(){closed=true;generation++;map=null;member=null;analysis=null;mailSource=null;host.remove();if(W.MCR_DATA===api)delete W.MCR_DATA;}
const api=Object.freeze({version:'0.2.0',readSelection,readElement,readMember,preview,loadMapText,diagnostic,diagnosticBytes,resetCase,close});
W.MCR_DATA=api;
console.info('MCR Datenbrücke 0.2 aktiv. Nur lesen. Bei gezielter DOM-Auswahl: MCR_DATA.readElement($0). Keine Ticketwerte automatisch in der Konsole.');
