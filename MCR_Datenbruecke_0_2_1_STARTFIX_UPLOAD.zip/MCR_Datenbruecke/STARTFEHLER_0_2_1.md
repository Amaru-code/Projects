# Starterkorrektur 0.2.1

## Ursache des fotografierten Fehlers

Der alte Starter fragte nach `node.exe`. Eingetragen wurde eine `.xlsx`-Datei.
`RUN.cmd` prüfte nur die Existenz des Pfades und versuchte anschließend, genau diesen Pfad aufzurufen.
Der Screenshot zeigt, dass damit Excel geöffnet wurde, statt den Node-Exporter zu starten.
**Der Mapping-Export hatte an dieser Stelle noch nicht begonnen.**

## Anwenden

1. Das alte schwarze MCR-Konsolenfenster schließen. Keine offenen Excel-Änderungen verwerfen.
2. Das neue ZIP vollständig entpacken. Es enthält wieder den Ordner `MCR_Datenbruecke`.
3. Diesen Ordner mit dem vorhandenen gleichnamigen Paketordner zusammenführen und die Paketdateien ersetzen. Nicht zuerst den alten Ordner löschen. Vorhandene `private_data`-JSONs und Runtime-Dateien nicht löschen; das ZIP enthält keine echten Mappingdaten. Bei lokal geändertem Code vorher eine Kopie des Paketordners aufbewahren.
4. `MAPPING_ERSTELLEN.cmd` im aktualisierten Ordner öffnen. Oben muss **0.2.1** stehen.
5. Node wird zuerst gesucht. Nur wenn das fehlschlägt, eine vorhandene `node.exe` angeben.
6. Erst bei **EXCEL-DATEI (.xlsx)** den lokalen XLSX-Pfad eingeben; Enter übernimmt alternativ den bekannten K:-Pfad.
7. Quelle und Spalte L prüfen, mit `JA` bestätigen. Erfolg ist die Meldung **MAPPING ERZEUGT** und eine neue JSON-Datei unter `private_data`.

Excel muss für den Export nicht gestartet sein. Die gespeicherte XLSX wird direkt und ausschließlich lesend verarbeitet.
Ungespeicherte Änderungen einer in Excel geöffneten Arbeitsmappe gehören nicht zum gelesenen Dateistand.

## Die beiden Pfade nicht verwechseln

| Schritt | Gesuchte Datei |
|---|---|
| 1 – Laufzeit | `...\node.exe` |
| 2 – Eingabedaten | `...\INTL01_Gesamtdatenbestand_30.09.2025.xlsx` |

Bekannter Portable-Node-Kandidat aus deinem bisherigen Projektaufbau:
`%USERPROFILE%\projects\Compiler\javascript\tools\node\node.exe`

Alternativer früherer Portable-Pfad:
`%USERPROFILE%\projects\Aktive_Projekte\node\tools\node\node.exe`

Diese Pfade werden auf deinem Gerät geprüft; ihre heutige Existenz wird nicht vorausgesetzt.
Es gibt keine Neuinstallation, kein `npm install`, keine Policy-/Registry-/PATH-Änderung und keinen Netzwerkdownload.
Die übrige Browser-, Lookup- und Fachlogik ist unverändert. Kein Versand oder Schreiben in COMARCH.

## Was geändert wurde

- Beschränkte zusätzliche Node-Suchorte statt rekursiver Festplattensuche.
- Vor jedem Runtime-Kandidatenaufruf: Name `node.exe`, vorhandener Pfad, keine Verzeichniswahl.
- Danach Runtime-/Versionsprüfung auf Node.js mindestens 22.15.
- Falsche Auswahl: verständliche Fehlermeldung und erneute Frage statt Öffnen der Excel-Datei.
- Eindeutige Schritt-1-/Schritt-2-Hinweise und Excel-Eingabeaufforderung.
- Paketmanifest und Prüfsummen für diese Ausgabe aktualisiert.

## Prüfnachweis und Grenze

Siehe `docs/STARTER_FIX_TESTBERICHT.md`. Die CMD-Korrektur ist statisch geprüft, nicht auf echtem Windows ausgeführt.
Vorherige Browsernachweise beziehen sich auf den unveränderten Helfer aus 0.2.0; sie sind kein neuer Windows-Nachweis.
