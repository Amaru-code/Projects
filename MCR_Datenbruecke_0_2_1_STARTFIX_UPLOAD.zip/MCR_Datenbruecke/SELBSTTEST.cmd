@echo off
call "%~dp0RUN.cmd" test
