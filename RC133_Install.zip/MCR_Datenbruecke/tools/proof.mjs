import {validSendAcknowledgements} from '../lib/phase1/send-dialog-policy.mjs';
import {requireThat as need} from '../lib/core.mjs';
export function certifyPilot(d){need(d?.mode==='REAL'&&!d.lastError&&validSendAcknowledgements(d.send)&&d.loop?.completed&&d.loop.finishReason==='PILOT_LIMIT_AFTER_VERIFIED_SAVE'&&d.loop.processed===1&&d.loop.myTasksProcessed+d.loop.queueProcessed===1&&d.send?.verified===true&&d.save?.verified===true&&d.loop.processedTickets?.length===1&&['HISTORY_INCREMENT','EDITOR_RESET_AFTER_CONFIRMED_DIALOGS','BOUND_NEW_OUTGOING_HISTORY','OPERATOR_VERIFIED_OUTGOING'].includes(d.loop.processedTickets[0].sendAck)&&['MY_TASKS_ALL_DESCRIPTION_CONTENT_MATCH','QUEUE_ALL_DESCRIPTION_CONTENT_MATCH'].includes(d.loop.processedTickets[0].save),'PILOT_NOT_VERIFIED','Genau ein gesendetes und gespeichertes echtes Ticket nicht bestaetigt.');return true;}

export function certifyForwardWithoutEmail(d){
 need(d?.mode==='REAL'&&!d.lastError&&d.loop?.completed&&d.loop?.processed===1&&d.loop?.forwarded===1&&d.loop?.processedTickets?.length===1&&d.loop.processedTickets[0].type==='FORWARDED_WITHOUT_EMAIL'&&d.forward?.verified===true&&d.forward?.noEmail===true&&d.forward?.fixedFieldsVerified===true&&d.send?.clicked!==true&&d.save?.verified===true,'FORWARD_NOT_VERIFIED','Weiterleitung ohne Antwortmail nicht eindeutig nachgewiesen.');
 return true;
}
