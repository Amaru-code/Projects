"""RC105 AO adapter: execute the central generator without duplicating its math.

No Excel values are calculated here. The central create_pdf function owns all
business data and workbook changes. This adapter binds input, serializes bot
calls, owns only its new Excel process, and verifies the returned PDF/audit.
"""
from __future__ import annotations

import argparse
import ast
import builtins
import contextlib
import shutil
import unicodedata
import hashlib
import io
import json
import os
from pathlib import Path
import re
import sys
import threading
import time
from datetime import datetime

MARKER = 'MCR_AO_BRIDGE_RESULT '
MAX_SOURCE = 2 * 1024 * 1024
MAX_PDF = 50 * 1024 * 1024


class BridgeError(Exception):
    def __init__(self, code, reason, missing_fields=None, details=None):
        super().__init__(reason)
        self.code = code
        self.missing_fields = missing_fields or []
        self.details = details or {}


def require(condition, code, reason):
    if not condition:
        raise BridgeError(code, reason)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_source(generator, expected_sha=None):
    generator = Path(generator).resolve(strict=True)
    require(generator.is_file() and generator.name == 'auszahlungsoption_generator.py',
            'AO_SCRIPT_PATH', 'Unerwarteter zentraler AO-Skriptname.')
    data = generator.read_bytes()
    require(0 < len(data) <= MAX_SOURCE, 'AO_SCRIPT_SIZE', 'Zentraler AO-Generator ist leer oder zu gross.')
    source_sha = sha(data)
    require(expected_sha is None or source_sha == expected_sha,
            'AO_SCRIPT_CHANGED', 'Zentraler Generator wurde nach der Vorpruefung geaendert.')
    tree = ast.parse(data, filename=str(generator))
    functions = {node.name: node for node in tree.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}
    require({'create_pdf', 'ask_stichtag', 'default_stichtag', 'lookup_person',
             'is_missing_contact_value', 'request_missing_address'}.issubset(functions),
            'AO_SCRIPT_CONTRACT', 'AO-Generator hat nicht die bestaetigte create_pdf/Stichtag-Schnittstelle.')
    args = functions['create_pdf'].args
    require(len(args.args) == 1 and not args.vararg and not args.kwarg,
            'AO_SCRIPT_CONTRACT', 'create_pdf erwartet nicht genau eine WWID.')
    return generator, data, source_sha


def probe(generator):
    # Read-only: do not import or call the business module at preflight time.
    _, _, source_sha = read_source(generator)
    import win32com.client  # noqa: F401
    import win32api  # noqa: F401
    import win32event  # noqa: F401
    import win32process  # noqa: F401
    return {'status': 'PROBE_OK', 'sourceSha256': source_sha}


@contextlib.contextmanager
def generator_lock(folder, wait_seconds=30):
    # One lock for the shared workbook, not one lock per WWID. The OS releases
    # it on a process crash; an old lock filename cannot block later runs.
    lock_path = Path(folder) / '.mcr_ao_generation.lock'
    stream = open(lock_path, 'a+b', buffering=0)
    locked = False
    try:
        if lock_path.stat().st_size == 0:
            stream.write(b'\0')
        deadline = time.monotonic() + wait_seconds
        while not locked:
            stream.seek(0)
            try:
                if os.name == 'nt':
                    import msvcrt
                    msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                locked = True
            except OSError:
                if time.monotonic() >= deadline:
                    raise BridgeError('AO_GENERATOR_BUSY', 'Ein anderer Bot berechnet bereits eine AO in dieser Arbeitsdatei.')
                time.sleep(0.2)
        yield
    finally:
        if locked:
            stream.seek(0)
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(stream.fileno(), fcntl.LOCK_UN)
        stream.close()


class DiscardOutput(io.TextIOBase):
    # Generator output can contain personal or financial data. The final result
    # below carries only the metadata needed for the specific attachment proof.
    def write(self, text):
        return len(text)

    def flush(self):
        pass


class OwnedExcel:
    """Keep process handles to DispatchEx instances; never kill by name/PID reuse."""
    def __init__(self):
        self.handles = []
        self.guard = threading.Lock()
        self.original = None
        self.client = None

    def install(self):
        import win32com.client as client
        import win32api
        import win32process
        self.client = client
        self.original = client.DispatchEx

        def dispatch(name, *args, **kwargs):
            require(str(name).lower() == 'excel.application', 'AO_COM_CLASS', 'Unerwartete COM-Anwendung im AO-Generator.')
            before_pids = set(win32process.EnumProcesses())
            app = self.original(name, *args, **kwargs)
            try:
                _, pid = win32process.GetWindowThreadProcessId(int(app.Hwnd))
                require(pid not in before_pids, 'AO_EXCEL_OWNERSHIP', 'DispatchEx hat keine neue eigene Excel-Instanz erstellt.')
                # PROCESS_TERMINATE | SYNCHRONIZE. Keeping this handle prevents
                # a later recycled PID from pointing cleanup at another app.
                handle = win32api.OpenProcess(0x0001 | 0x00100000, False, pid)
                with self.guard:
                    self.handles.append(handle)
            except Exception:
                # If DispatchEx unexpectedly reused an existing Excel process,
                # neither Quit nor process termination may touch that process.
                if 'pid' in locals() and pid not in before_pids:
                    try:
                        app.Quit()
                    except Exception:
                        pass
                raise BridgeError('AO_EXCEL_OWNERSHIP', 'Eigene Excel-Instanz konnte nicht eindeutig fuer die Bereinigung gebunden werden.')
            return app

        client.DispatchEx = dispatch

    def checkpoint(self):
        with self.guard:
            return len(self.handles)

    def cleanup(self, grace_ms=5000, since=0):
        import win32api
        import win32event
        with self.guard:
            handles, self.handles = self.handles[since:], self.handles[:since]
        for handle in handles:
            try:
                state = win32event.WaitForSingleObject(handle, grace_ms)
                if state == 258:
                    win32api.TerminateProcess(handle, 3)
                    state = win32event.WaitForSingleObject(handle, 1000)
                require(state == 0, 'AO_EXCEL_CLOSE_FAILED', 'Eigene Excel-Instanz konnte nicht beendet werden.')
            finally:
                handle.Close()

    def restore(self):
        if self.client is not None and self.original is not None:
            self.client.DispatchEx = self.original


def name_token(value):
    text = unicodedata.normalize('NFC', str(value or '')).lower()
    for old, new in (('ä', 'ae'), ('ö', 'oe'), ('ü', 'ue'), ('ß', 'ss')):
        text = text.replace(old, new)
    return re.sub(r'[^a-z0-9]+', '', text)


def result_filename(stichtag, name, wwid):
    return re.sub(r'[\\/:*?"<>|]+', '_', f'{stichtag:%Y-%m-%d}_Auszahlungsoption_{name}_{wwid}').strip(' ._') + '.pdf'


def result_snapshot(namespace, wwid, stichtag, person, request_id):
    """Keep the prior same-name PDF as a historical reference before export.

    The central calculator deliberately uses the same canonical filename for
    each year/person. Never mistake that previous file for this attempt's output.
    The bot lock covers the snapshot, history copy, generation and validation.
    """
    output, audits = Path(namespace['OUTPUT']), Path(namespace['AUDIT'])
    pdf = output / result_filename(stichtag, str(person['Name']).strip(), wwid)
    old_audits = {p.name.lower() for p in audits.iterdir() if p.name.lower().endswith('_' + wwid + '.json')} if audits.exists() else set()
    old_pdf = None
    if pdf.exists():
        require(pdf.is_file() and not pdf.is_symlink(), 'AO_RESULT_PATH', 'Vorhandene AO ist keine regulaere PDF-Datei.')
        before = pdf.stat()
        require(0 < before.st_size <= MAX_PDF, 'AO_RESULT_SIZE', 'Vorhandene AO kann nicht sicher archiviert werden.')
        old_hash = stable_file_digest(pdf)
        history = output / '.mcr_historie' / request_id
        require(history.parent.resolve() == output.resolve() / '.mcr_historie', 'AO_HISTORY_PATH', 'Historienordner ist nicht am freigegebenen Ausgabeort.')
        history.mkdir(parents=True, exist_ok=False)
        archive = history / pdf.name
        try:
            shutil.copy2(pdf, archive)
            after = pdf.stat()
            require((before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns) and
                    stable_file_digest(archive) == old_hash and stable_file_digest(pdf) == old_hash,
                    'AO_HISTORY_CHANGED', 'Vorhandene AO aenderte sich waehrend der Sicherung; keine Neuberechnung.')
            # Copy matching historic success audits with the archived original.
            # They remain references, never evidence for the new result.
            for old_audit in audits.iterdir() if audits.exists() else ():
                if old_audit.name.lower() not in old_audits or not old_audit.is_file() or old_audit.is_symlink() or old_audit.stat().st_size > 256 * 1024:
                    continue
                try:
                    data = json.loads(old_audit.read_text(encoding='utf-8-sig'))
                    if data.get('status') == 'success' and str(data.get('wwid')) == wwid and Path(data.get('pdf', '')).resolve() == pdf.resolve():
                        shutil.copy2(old_audit, history / old_audit.name)
                except (ValueError, OSError):
                    continue
        except OSError as exc:
            raise BridgeError('AO_HISTORY_BACKUP_FAILED', 'Vorhandene AO konnte nicht sicher gesichert werden; kein Berechnungsstart.') from exc
        old_pdf = (before.st_size, before.st_mtime_ns, old_hash)
    return {'pdf': pdf, 'previousPdf': old_pdf, 'auditNames': old_audits}


def verify_result(result, namespace, wwid, stichtag, started, source_sha, request_id, baseline, contact_fields=()):
    require(isinstance(result, tuple) and len(result) == 4,
            'AO_RESULT_SHAPE', 'Zentraler Generator hat kein vollstaendiges PDF/Audit-Ergebnis geliefert.')
    pdf, audit, record, person = result
    require(isinstance(person, dict) and str(person.get('WWID')) == str(int(wwid)),
            'AO_RESULT_WWID', 'Ergebnis-Person passt nicht zur freigegebenen WWID.')
    name = str(person.get('Name') or '').strip()
    require(bool(name) and len(name) <= 200, 'AO_RESULT_NAME', 'Membername fehlt im Generatorergebnis.')
    pdf = Path(pdf).resolve(strict=True)
    audit = Path(audit).resolve(strict=True)
    output = Path(namespace['OUTPUT']).resolve(strict=True)
    audits = Path(namespace['AUDIT']).resolve(strict=True)
    base = Path(namespace['BASE']).resolve(strict=True)
    require(output == base / 'Ausgabe PDF' and audits == base / 'Audit_Logs',
            'AO_OUTPUT_CONTRACT', 'Zentrale AO-Ausgabe-/Auditordner weichen vom bestaetigten Vertrag ab.')
    require(pdf.parent == output and audit.parent == audits and pdf.is_file() and audit.is_file(),
            'AO_RESULT_PATH', 'PDF oder Audit liegt ausserhalb des zentralen AO-Ausgabeordners.')
    expected_name = result_filename(stichtag, name, wwid)
    require(pdf.name == expected_name, 'AO_RESULT_FILENAME', 'AO-Dateiname stimmt nicht mit WWID, Name und Stichtag ueberein.')
    started_ms = int(started * 1000)
    require(pdf == baseline['pdf'].resolve() and audit.name.lower() not in baseline['auditNames'],
            'AO_RESULT_STALE', 'AO-Ergebnis oder Audit ist kein neuer Aufruf; alter Audit bleibt historische Referenz.')
    require(pdf.stat().st_mtime_ns / 1_000_000 >= started_ms and audit.stat().st_mtime_ns / 1_000_000 >= started_ms,
            'AO_RESULT_STALE', 'PDF oder Audit ist nicht eindeutig aus diesem Generatoraufruf.')
    require(128 <= pdf.stat().st_size <= MAX_PDF and 0 < audit.stat().st_size <= 1024 * 1024,
            'AO_RESULT_SIZE', 'PDF oder Audit hat keine gueltige Dateigroesse.')
    pdf_before = pdf.stat()
    pdf_data = pdf.read_bytes()
    require(pdf_data.startswith(b'%PDF-') and b'%%EOF' in pdf_data[-2048:],
            'AO_RESULT_PDF', 'PDF ist nicht vollstaendig geschrieben.')
    pdf_after = pdf.stat()
    require((pdf_before.st_size, pdf_before.st_mtime_ns) == (pdf_after.st_size, pdf_after.st_mtime_ns),
            'AO_RESULT_CHANGED', 'PDF wurde waehrend der Pruefung geaendert.')
    require(baseline['previousPdf'] is None or (pdf_after.st_size, pdf_after.st_mtime_ns, sha(pdf_data)) != baseline['previousPdf'],
            'AO_RESULT_STALE', 'Vorhandene PDF wurde nicht neu erzeugt.')
    audit_before = audit.stat()
    audit_data = audit.read_bytes()
    audit_after = audit.stat()
    require((audit_before.st_size, audit_before.st_mtime_ns) == (audit_after.st_size, audit_after.st_mtime_ns),
            'AO_RESULT_CHANGED', 'Audit wurde waehrend der Pruefung geaendert.')
    payload = json.loads(audit_data.decode('utf-8-sig'))
    require(payload.get('status') == 'success' and str(payload.get('wwid')) == wwid and
            payload.get('name') == name and payload.get('stichtag') == stichtag.strftime('%d.%m.%Y') and
            payload.get('record') == record and payload.get('contact_supplied') is bool(contact_fields) and Path(payload.get('pdf', '')).resolve(strict=True) == pdf,
            'AO_AUDIT_MISMATCH', 'Audit bestaetigt diesen Member, Stichtag und diese PDF nicht vollstaendig.')
    audit_time = datetime.fromisoformat(payload.get('timestamp', ''))
    require(int(started) <= audit_time.timestamp() <= time.time() + 2,
            'AO_AUDIT_STALE', 'AO-Audit stammt nicht aus diesem Aufruf.')
    return {'schema': 'MCR_AO_GENERATOR_PROOF_V1', 'requestId': request_id,
            'wwid': wwid, 'name': name, 'stichtag': stichtag.strftime('%d.%m.%Y'),
            'stichtagIso': stichtag.strftime('%Y-%m-%d'), 'file': str(pdf), 'auditFile': str(audit),
            'sha256': sha(pdf_data), 'bytes': len(pdf_data), 'auditSha256': sha(audit_data),
            'sourceSha256': source_sha, 'generatedAt': datetime.now().astimezone().isoformat(),
            'auditTimestamp': payload['timestamp'],
            **({'contactInput': {'schema': 'MCR_AO_GENERATOR_CONTACT_V2', 'fields': list(contact_fields), 'generatorSaveReported': True}} if contact_fields else {}),
            'freshness': {'schema': 'MCR_AO_FRESH_GENERATION_V1', 'startedAtMs': started_ms,
                          'pdfMtimeMs': pdf_after.st_mtime_ns / 1_000_000,
                          'auditMtimeMs': audit_after.st_mtime_ns / 1_000_000, 'newPdf': True, 'newAudit': True}}


def stable_file_digest(filename):
    file = Path(filename)
    before = file.stat()
    require(file.is_file(), 'WORKBOOK_LOCKED_OR_IO', 'Berechnungsquelle ist keine lesbare Datei.')
    digest = hashlib.sha256()
    with file.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    after = file.stat()
    require((before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns),
            'WORKBOOK_LOCKED_OR_IO', 'Berechnungsquelle wurde waehrend der Lesepruefung geaendert.')
    return digest.hexdigest()


class ActiveTimeWatchdog:
    """Budget for technical work only; a real contact prompt can wait indefinitely."""
    def __init__(self, seconds):
        self.seconds = seconds
        self.condition = threading.Condition()
        self.deadline = None
        self.paused_at = None
        self.done = False

    def start(self):
        with self.condition:
            self.deadline = time.monotonic() + self.seconds

    @contextlib.contextmanager
    def human_input(self):
        with self.condition:
            self.paused_at = time.monotonic()
            self.condition.notify_all()
        try:
            yield
        finally:
            with self.condition:
                self.deadline += time.monotonic() - self.paused_at
                self.paused_at = None
                self.condition.notify_all()

    def wait_expired(self):
        with self.condition:
            while not self.done:
                if self.paused_at is not None:
                    self.condition.wait()
                    continue
                remaining = self.deadline - time.monotonic()
                if remaining <= 0:
                    return True
                self.condition.wait(remaining)
            return False

    def finish(self):
        with self.condition:
            self.done = True
            self.condition.notify_all()


def classify_generator_failure(exc):
    """Use the real exception and the central call stack, never infer missing balances."""
    import traceback
    frames = [f.name for f in traceback.extract_tb(exc.__traceback__)]
    text = str(exc).casefold()
    if isinstance(exc, BridgeError):
        return exc.code, exc.details.get('operation', 'generator')
    if 'save_contact_to_master' in frames:
        if isinstance(exc, PermissionError) and 'schreibgeschützt' in text:
            return 'MASTER_OPENED_READONLY', 'open_contact_write'
        return 'AO_CONTACT_SAVE_UNVERIFIED', 'save_contact_to_master'
    if 'kein historischer basiskontostand' in text or 'kein historischer schattenkontostand' in text or 'unvollständige gehalts-' in text or 'kein gehalt/tzg' in text or 'keine mitarbeiterdaten in der kontrollmappe' in text:
        return 'AO_PROGRESSION_HISTORY_MISSING', 'progression_balances'
    if 'keine numerischen basis-/schattenkontowerte' in text:
        return 'AO_BALANCE_SOURCE_MISSING', 'lookup_balances'
    if ('wurde in kontrolle!a nicht gefunden' in text or 'vorjahreszeile' in text):
        return 'AO_CONTROL_YEAR_MISSING', 'lookup_balances'
    if 'fortschreibungszeitraum' in text or 'ungültiger teilzeitgrad' in text or 'kein beitragszeitraum' in text:
        return 'AO_PROGRESSION_FAILED', 'progression_balances'
    if 'lookup_person' in frames and isinstance(exc,(LookupError,ValueError)):
        return 'AO_MASTER_PERSON_INVALID', 'lookup_person'
    if 'progression_balances' in frames or 'progression_balance_fallback' in frames:
        return 'AO_GENERATOR_FAILED', 'progression_balances'
    if 'lookup_balances' in frames:
        return 'AO_GENERATOR_FAILED', 'lookup_balances'
    return 'AO_GENERATOR_FAILED', 'create_pdf'


def safe_reason(value, contact_values=()):
    text = str(value)
    for private in sorted(set(str(v) for v in contact_values if v), key=len, reverse=True):
        text = text.replace(private, '[Kontaktwert entfernt]')
    return re.sub(r'[\x00-\x1f\x7f]', ' ', text)[:2000]


def audit_names(folder, wwid):
    return {p.name.lower() for p in folder.iterdir() if p.name.lower().endswith('_'+wwid+'.json')} if folder.exists() else set()


def find_failed_audit(folder, wwid, started, before, exc, contact_values=()):
    """The supplied generator writes failed audits without a stichtag or requestId.
    Bind by WWID, new filename/time, exact exception reason and unique candidate.
    Never take a historical or ambiguous log as evidence of this invocation.
    """
    candidates = []
    try:
        for p in folder.iterdir():
            if not re.fullmatch(r'\d{8}_\d{6}_'+re.escape(wwid)+r'\.json',p.name,re.I) or p.name.lower() in before or p.is_symlink() or not p.is_file():
                continue
            a=p.stat()
            if not 0<a.st_size<=256*1024 or a.st_mtime_ns/1e9 < int(started):
                continue
            raw=p.read_bytes(); b=p.stat()
            if (a.st_size,a.st_mtime_ns)!=(b.st_size,b.st_mtime_ns): continue
            try:
                record=json.loads(raw.decode('utf-8-sig'))
                stamp=datetime.fromisoformat(record['timestamp']).timestamp()
                if not (record.get('status')=='failed' and str(record.get('wwid'))==wwid and int(started)<=stamp<=time.time()+2 and record.get('reason')==str(exc)): continue
            except (ValueError,KeyError,TypeError,AttributeError): continue
            detail={'audit_path':str(p.resolve()), 'audit_reason':safe_reason(record['reason'],contact_values), 'audit_sha256':sha(raw)}
            if isinstance(record.get('balance_source'),str):detail['balance_source']=safe_reason(record['balance_source'],contact_values)
            if isinstance(record.get('progression'),dict) and isinstance(record['progression'].get('method'),str):detail['progression_method']=safe_reason(record['progression']['method'],contact_values)
            candidates.append(detail)
        return candidates[0] if len(candidates)==1 else {'audit_state':'AMBIGUOUS' if candidates else 'NO_BOUND_FAILURE_AUDIT'}
    except OSError:
        return {'audit_state':'AUDIT_READ_FAILED'}


def valid_contact(field,value):
    return (isinstance(value,str) and 0<len(value.strip())<=(120 if field=='PLZ' else 300)
        and not any(ord(c)<32 or ord(c)==127 for c in value) and value.strip()[0] not in '=+-@'
        and (field!='PLZ' or (re.fullmatch(r'[0-9]{5}\s+\S.*',value.strip()) is not None and any(c.isalpha() for c in value.strip()[5:]))))


def generate(generator, wwid, request_id, expected_sha, timeout_seconds, emit, stichtag=None, stage=lambda name: None, expected_first=None, expected_last=None, contact_io=None, contact_write_allowed=True):
    """RC116: execute the original calculator with its own Excel lifecycle.
    No extra Excel lookup, preflight, save hook, or contact readback. The only
    instrumentation is input mediation, pure person/result binding, an output
    snapshot and ownership tracking of Excel instances created by the generator.
    """
    require(re.fullmatch(r'[0-9]{4,15}',wwid) is not None,'AO_WWID','WWID muss numerisch sein.')
    require(re.fullmatch(r'[a-f0-9]{32}',request_id) is not None,'AO_REQUEST_ID','Generatoraufruf ist nicht gebunden.')
    generator,source,source_sha=read_source(generator,expected_sha)
    excel=OwnedExcel(); budget=ActiveTimeWatchdog(timeout_seconds); original_input=builtins.input
    old_sys_path=list(sys.path)
    started=time.time(); before=set(); supplied={}; private_values=[]; baseline=None; person_seen=None; asked_date=False; missing=[]
    audits=generator.parent/'Audit_Logs'
    def watchdog():
        if not budget.wait_expired():return
        try:excel.cleanup(0)
        finally:
            emit({'status':'FAILED','requestId':request_id,'wwid':wwid,'error':'AO_GENERATOR_TIMEOUT','reason':'Generator-Zeitlimit erreicht; kein Upload und kein zweiter Aufruf.'})
            os._exit(4)
    def mediated_input(prompt=''):
        nonlocal asked_date
        if re.fullmatch(r'Stichtag \(TT\.MM\.JJJJ\) \[\d{2}\.\d{2}\.\d{4}\]:\s*',str(prompt)) and not asked_date and person_seen is None:
            require(str(prompt).split('[')[1].split(']')[0]==selected.strftime('%d.%m.%Y'),'AO_STICHTAG_MISMATCH','Generator meldet anderen Standardstichtag.')
            asked_date=True;return ''
        match=re.fullmatch(r'(Adresse|PLZ):\s*',str(prompt))
        require(person_seen is not None and match is not None,'AO_UNEXPECTED_INPUT','Unbekannte Generator-Eingabe; kein Raten.')
        field=match.group(1)
        require(field in missing and field not in supplied,'AO_UNEXPECTED_INPUT','Kontaktfrage nicht an fehlendes Feld gebunden.')
        if not contact_write_allowed:raise BridgeError('AO_QUEUE_PAUSED_MASTER_WRITE','Kontaktfelder fehlen; zentraler Schreibzugriff in diesem Lauf pausiert.',list(missing))
        if contact_io is None:raise BridgeError('AO_CONTACT_DATA_REQUIRED','Adresse oder PLZ fehlt. Angefordertes Feld: '+field,list(missing))
        try:
            with budget.human_input(): value=contact_io(field)
        except BridgeError as exc:
            exc.missing_fields=list(missing);raise
        require(valid_contact(field,value) and not namespace['is_missing_contact_value'](value),'AO_CONTACT_INPUT_INVALID','Ungueltige Kontakteingabe.')
        value=value.strip();supplied[field]=value;private_values.append(value)
        if set(supplied)==set(missing):stage('CONTACTS_COMPLETE')
        return value
    try:
        with generator_lock(generator.parent):
            require(not (generator.parent/'~$IPP_Leistungsberechnungen_Arbeitsdatei.xlsm').exists(),'AO_WORKBOOK_BUSY','AO-Arbeitsdatei ist bereits in Excel geoeffnet.')
            excel.install() # only observes the original DispatchEx, creates no separate Excel instance
            namespace={'__name__':'_mcr_central_ao_generator','__file__':str(generator),'__package__':None}
            sys.path.insert(0,str(generator.parent))
            budget.start();threading.Thread(target=watchdog,daemon=True).start()
            with contextlib.redirect_stdout(DiscardOutput()),contextlib.redirect_stderr(DiscardOutput()):
                exec(compile(source,str(generator),'exec'),namespace)
                require(Path(namespace['BASE']).resolve()==generator.parent and Path(namespace['OUTPUT']).resolve()==generator.parent/'Ausgabe PDF' and Path(namespace['AUDIT']).resolve()==audits and Path(namespace['WORKBOOK']).resolve()==generator.parent/'IPP_Leistungsberechnungen_Arbeitsdatei.xlsm','AO_OUTPUT_CONTRACT','Unerwartete zentrale AO-Ausgabepfade.')
                default=namespace['default_stichtag']();selected=datetime.strptime(stichtag,'%d.%m.%Y') if stichtag else default
                require(selected==default and (default.month,default.day)==(12,31) and default.year==datetime.now().year,'AO_STICHTAG_MISMATCH','Stichtag weicht vom Standardjahresende ab.')
                original_lookup=namespace['lookup_person']
                def bound_lookup(app,requested):
                    nonlocal baseline,person_seen,missing
                    require(person_seen is None and str(requested)==wwid,'AO_PREFLIGHT_WWID','Generator hat den gebundenen Personensuchlauf gewechselt.')
                    person=original_lookup(app,requested) # exactly the original lookup with its own app
                    require(isinstance(person,dict) and str(person.get('WWID'))==str(int(wwid)) and bool(str(person.get('Name') or '').strip()),'AO_PREFLIGHT_PERSON','IPP-Person nicht eindeutig gebunden.')
                    if expected_first is not None or expected_last is not None:
                        require(bool(expected_first and expected_last) and name_token(person['Name'])==name_token(expected_last)+name_token(expected_first),'P2_AO_GENERATOR_PERSON','IPP-Name stimmt nicht mit COMARCH ueberein.')
                    person_seen=dict(person)
                    private_values.extend(str(person.get(k)) for k in ('Adresse','PLZ') if person.get(k) and not namespace['is_missing_contact_value'](person.get(k)))
                    missing=[k for k in ('Adresse','PLZ') if namespace['is_missing_contact_value'](person.get(k)) or not str(person.get(k) or '').strip()]
                    baseline=result_snapshot(namespace,wwid,selected,person,request_id)
                    return person
                namespace['lookup_person']=bound_lookup
                builtins.input=mediated_input
                before=audit_names(audits,wwid)
                while datetime.now().strftime('%Y%m%d_%H%M%S_')+wwid+'.json' in before:time.sleep(.05)
                started=time.time();stage('GENERATION')
                try:
                    result=namespace['create_pdf'](wwid)
                    require(asked_date and baseline is not None and set(supplied)==set(missing),'AO_INPUT_CONTRACT','Generatorlauf nicht vollstaendig gebunden.')
                    proof=verify_result(result,namespace,wwid,selected,started,source_sha,request_id,baseline,tuple(supplied))
                    # The original generator reports success after saving its master
                    # and working workbook. Do not assert an independent readback.
                    if supplied:proof['contactInput']={'schema':'MCR_AO_GENERATOR_CONTACT_V2','fields':list(supplied),'generatorSaveReported':True}
                except Exception as exc:
                    code,operation=classify_generator_failure(exc)
                    detail={**getattr(exc,'details',{}),'operation':operation,'exception_type':type(exc).__name__}
                    detail.update(find_failed_audit(audits,wwid,started,before,exc,private_values))
                    if operation in ('save_contact_to_master','open_contact_write'):detail['source']='master'
                    reason=detail.get('audit_reason') or safe_reason(exc,private_values) or type(exc).__name__
                    raise BridgeError(code,reason,getattr(exc,'missing_fields',[]) or (missing if code.startswith('AO_CONTACT_') else []),detail) from exc
            excel.cleanup()
            return {'status':'SUCCESS','proof':proof}
    finally:
        builtins.input=original_input
        sys.path[:]=old_sys_path
        excel.restore()
        try:excel.cleanup()
        finally:budget.finish()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--probe', action='store_true')
    parser.add_argument('--generator', required=True)
    parser.add_argument('--wwid')
    parser.add_argument('--stichtag')
    parser.add_argument('--non-interactive', action='store_true')
    parser.add_argument('--interactive-contacts', action='store_true')
    parser.add_argument('--contact-write-paused', action='store_true')
    parser.add_argument('--request-id')
    parser.add_argument('--expected-first')
    parser.add_argument('--expected-last')
    parser.add_argument('--expected-source-sha256')
    parser.add_argument('--timeout-seconds', type=int, default=540)
    args = parser.parse_args()
    original_stdout = sys.stdout
    emit_lock = threading.Lock()

    def emit(payload):
        with emit_lock:
            original_stdout.write(MARKER + json.dumps(payload, ensure_ascii=True) + '\n')
            original_stdout.flush()

    try:
        if args.probe:
            result = probe(args.generator)
        else:
            require(5 <= args.timeout_seconds <= 1800, 'AO_TIMEOUT', 'Generator-Wartezeit ungueltig.')
            require(args.non_interactive != args.interactive_contacts and args.stichtag, 'AO_INPUT_CONTRACT', 'Bot-Aufruf benoetigt einen eindeutigen Eingabemodus und --stichtag.')
            def stage(name):
                with emit_lock:
                    original_stdout.write('MCR_AO_BRIDGE_STAGE ' + name + '\n')
                    original_stdout.flush()
            def contact_io(field):
                with emit_lock:
                    original_stdout.write('MCR_AO_BRIDGE_CONTACT ' + json.dumps({'requestId': args.request_id, 'wwid': args.wwid, 'field': field}) + '\n')
                    original_stdout.flush()
                line = sys.stdin.readline(8192)
                try:
                    answer = json.loads(line)
                except ValueError:
                    answer = {}
                require(answer.get('requestId') == args.request_id and answer.get('field') == field and answer.get('approved') is True, 'AO_CONTACT_INPUT_DEFERRED', 'Kontakteingabe nicht freigegeben; kein Upload.')
                return answer.get('value')
            result = generate(args.generator, args.wwid or '', args.request_id or '',
                              args.expected_source_sha256, args.timeout_seconds, emit, args.stichtag, stage, args.expected_first, args.expected_last, contact_io if args.interactive_contacts else None, contact_write_allowed=not args.contact_write_paused)
        emit(result)
        return 0
    except Exception as exc:
        code = getattr(exc, 'code', 'AO_GENERATOR_FAILED')
        blocked = code in {'AO_CONTACT_DATA_REQUIRED', 'WORKBOOK_LOCKED_OR_IO', 'AO_MASTER_PERSON_INVALID',
                           'AO_MASTER_PERSON_CHANGED', 'AO_WORKBOOK_BUSY', 'AO_GENERATOR_BUSY',
                           'MASTER_FILE_NOT_FOUND', 'MASTER_PATH_UNAVAILABLE', 'MASTER_WORKBOOK_LOCKED',
                           'MASTER_READ_ACCESS_DENIED', 'MASTER_OPEN_FAILED', 'AO_SOURCE_READ_LOCKED',
                           'AO_SOURCE_PATH_UNAVAILABLE', 'AO_SOURCE_READ_ACCESS_DENIED', 'AO_SOURCE_READ_FAILED',
                           'AO_SOURCE_CHANGED_DURING_READ', 'AO_EXCEL_INIT_FAILED', 'AO_EXCEL_CLOSE_FAILED', 'AO_CONTACT_INPUT_DEFERRED', 'AO_CONTACT_INPUT_INVALID', 'AO_CONTACT_SAVE_UNVERIFIED',
                           'MASTER_WORKBOOK_WRITE_LOCKED', 'MASTER_WRITE_PERMISSION_DENIED', 'MASTER_OPENED_READONLY',
                           'MASTER_SAVE_IO_RETRY_REQUIRED', 'MASTER_WRITE_OPEN_FAILED', 'MASTER_CONTACT_UPDATE_FAILED', 'AO_QUEUE_PAUSED_MASTER_WRITE'}
        emit({'status': 'BLOCKED' if blocked else 'FAILED', 'requestId': args.request_id,
              'wwid': args.wwid, 'error': code, 'missing_fields': getattr(exc, 'missing_fields', []),
              'reason': str(exc)[:2000] if isinstance(exc, BridgeError) else safe_reason(exc), 'details': getattr(exc, 'details', {})})
        return 2 if blocked else 1


if __name__ == '__main__':
    sys.exit(main())
