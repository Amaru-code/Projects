/** Collect disposable program output only after a committed, exclusive install. */
import fs from 'node:fs';
import path from 'node:path';
import {sha256,requireThat as need} from '../lib/core.mjs';
import {phase1ResultPath,plainPath,readJSON,writeJSON,VERSION} from '../lib/control.mjs';
import {resolveConfig} from '../lib/config.mjs';
import {pruneMappingArchives} from '../lib/workbook/active-mapping.mjs';
import {readZip} from '../lib/zip.mjs';
import {isKnownPreviousManifest} from './integrity.mjs';

const runnerSchema='MCR_LOCAL_RUNNER_DIAGNOSTIC_V2';
const diagnosticName=/^MCR_LOCAL_RUNNER_\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2}-\d{3}Z_[a-f0-9]{8}_UPLOAD\.zip$/i;
const parse=bytes=>JSON.parse(bytes.toString('utf8').replace(/^\uFEFF/,''));

function generatedDiagnostic(zip){
 if(zip.names.length!==2||!['diagnostic.json','manifest.json'].every(n=>zip.names.includes(n)))return false;
 const manifest=parse(zip.get('manifest.json')),raw=zip.get('diagnostic.json');
 return manifest.schema==='MCR_DIAGNOSTIC_MANIFEST_V1'&&manifest.payload?.length===1&&
  manifest.payload[0].path==='diagnostic.json'&&manifest.payload[0].sha256===sha256(raw)&&parse(raw).schema===runnerSchema;
}

function originalInstaller(zip,version){
 const prefix='MCR_Datenbruecke/',raw=zip.get(prefix+'MANIFEST.json');
 if(!isKnownPreviousManifest(version,sha256(raw)))return false;
 const m=parse(raw);
 if(m.version!==version||m.schema!=='MCR_COMPLETE_PACKAGE_V1'||m.package!=='MCR_Datenbruecke'||
    !Array.isArray(m.payload)||zip.names.length!==m.payload.length+2)return false;
 const sums=Buffer.from(m.payload.map(r=>r.sha256+'  '+r.path+'\n').join(''));
 if(!zip.get(prefix+'SHA256SUMS.txt').equals(sums))return false;
 return m.payload.every(r=>{const data=zip.get(prefix+r.path);return data.length===r.bytes&&sha256(data)===r.sha256;});
}

function migrateResult(root,file){
 const old=readJSON(file);
 if(old.schema!==runnerSchema||typeof old.runId!=='string'||!old.runId)return false;
 if(old.mode==='DEMO')return true;
 if(old.mode!=='REAL')return false;
 const dest=phase1ResultPath(root);
 if(fs.existsSync(dest)){
  const current=readJSON(dest);
  if(current.schema!==runnerSchema||current.mode!=='REAL')return false;
  if(JSON.stringify(old)===JSON.stringify(current))return true;
  const state=path.join(root,'.runtime','beta-control','last-run.json');
  const last=fs.existsSync(state)?readJSON(state,65536):null;
  if(current.runId===last?.runId&&old.runId!==last.runId)return true;
  if(old.runId!==last?.runId)return false;
 }
 fs.mkdirSync(path.dirname(dest),{recursive:true});plainPath(path.dirname(dest));
 writeJSON(dest,old);
 return true;
}

function clearDiagnostics(dir,count){
 // lstat via the directory entries; unlink links themselves without traversing
 // their targets (including Windows junctions). The migration owns this tree.
 for(const entry of fs.readdirSync(dir,{withFileTypes:true})){
  const file=path.join(dir,entry.name);
  if(entry.isDirectory()&&!entry.isSymbolicLink())clearDiagnostics(file,count);
  else{
   const size=fs.lstatSync(file).size;
   fs.unlinkSync(file);
   count.bytes+=size;
   if(entry.isFile()&&entry.name.toLowerCase().endsWith('.zip'))count.diagnosticZips++;
  }
 }
 fs.rmdirSync(dir);
}

export function cleanupInstallationOutputs(root){
 const count={diagnosticZips:0,installerZips:0,mappings:0,legacyPointers:0,bytes:0,warnings:[]};
 function warn(file,error){count.warnings.push(path.relative(root,file)+' | '+(error.code||error.name));}
 function remove(file,bytes){fs.unlinkSync(file);count.bytes+=bytes;}
 try{
  const lockPath=path.join(root,'.runtime','beta-control','operation.lock.json');
  const lock=fs.existsSync(lockPath)?readJSON(lockPath,65536):{};
  need(lock.schema==='MCR_OPERATION_LOCK_V1'&&lock.pid===process.pid&&lock.operation==='MIGRATION',
   'CLEANUP_LOCK','Bereinigung nur unter eigener Installationssperre.');
  const cfg=resolveConfig(root),diagnostic=cfg.diagnosticDirectory,dedicated=path.join(root,'diagnostics');
  const output=path.dirname(phase1ResultPath(root));
  const folders=new Set([root,output,diagnostic,dedicated]);
  for(const dir of folders){
   if(!fs.lstatSync(dir,{throwIfNoEntry:false})?.isDirectory())continue;
   plainPath(dir);
   if(dir===dedicated){
    const overlaps=Object.entries(cfg).some(([key,value])=>{
     if(typeof value!=='string'||!/(?:Path|Directory)$/.test(key)||(key==='diagnosticDirectory'&&value===dir))return false;
     const rel=path.relative(dir,path.resolve(root,value));
     return rel===''||(!rel.startsWith('..'+path.sep)&&rel!=='..'&&!path.isAbsolute(rel));
    });
    if(overlaps){warn(dir,{code:'CONFIG_PATH_IN_DIAGNOSTICS'});continue;}
    const file=path.join(dir,'last-result.json');
    if(fs.lstatSync(file,{throwIfNoEntry:false})){
     if(!migrateResult(root,file)){warn(file,{code:'UNRESOLVED_RUN_RESULT'});continue;}
    }
    clearDiagnostics(dir,count);
    continue;
   }
   for(const entry of fs.readdirSync(dir,{withFileTypes:true})){
    if(!entry.isFile())continue;
    const file=path.join(dir,entry.name);
    try{
     if(dir===diagnostic&&entry.name==='last-result.json'){
      const bytes=fs.lstatSync(file).size;
      if(migrateResult(root,file))remove(file,bytes);
      continue;
     }
     const installer=dir===root&&/^RC(\d+)_Install\.zip$/i.exec(entry.name);
     if(!installer&&!diagnosticName.test(entry.name))continue;
     const version=installer?'0.8.1-rc.'+installer[1]:null;
     if(version===VERSION)continue;
     const before=fs.lstatSync(file,{bigint:true});
     if(!before.isFile()||before.size>80n*1024n*1024n)continue;
     const zip=readZip(fs.readFileSync(file));
     if(installer?!originalInstaller(zip,version):!generatedDiagnostic(zip))continue;
     const after=fs.lstatSync(file,{bigint:true});
     if(!after.isFile()||before.ino!==after.ino||before.size!==after.size||before.ctimeNs!==after.ctimeNs)continue;
     remove(file,Number(before.size));count[installer?'installerZips':'diagnosticZips']++;
    }catch(error){warn(file,error);}
   }
  }
  const pruned=pruneMappingArchives(root);
  count.mappings=pruned.mappings;count.legacyPointers=pruned.legacyPointers;count.bytes+=pruned.bytes;
 }catch(error){warn(root,error);}
 return count;
}
