"""Return identity status and hash of the inspected statement. Never emit its text."""
from datetime import datetime
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import unicodedata


def extract(data, *, whole=False):
    try:
        from pypdf import PdfReader
    except ImportError:
        try:
            from PyPDF2 import PdfReader
        except ImportError:
            PdfReader = None
    if PdfReader:
        try:
            reader = PdfReader(io.BytesIO(data))
            if whole and len(reader.pages) > 40:
                return ''
            text = '\n'.join(page.extract_text() or '' for page in reader.pages[:40 if whole else 2])
            if text.strip():
                return text
        except Exception:
            pass
    # Some Windows workstations have PyMuPDF in the generator interpreter.
    try:
        import pymupdf
        with pymupdf.open(stream=data, filetype='pdf') as document:
            if whole and len(document) > 40:
                return ''
            limit = len(document) if whole else min(2, len(document))
            text = '\n'.join(document[i].get_text(sort=True) for i in range(limit))
            if text.strip():
                return text
    except (ImportError, OSError, ValueError, RuntimeError):
        pass
    tool = shutil.which('pdftotext')
    if tool:
        args = [tool, *([] if whole else ['-f', '1', '-l', '2']), '-enc', 'UTF-8', '-', '-']
        result = subprocess.run(args, input=data, capture_output=True, check=True, timeout=15)
        return result.stdout.decode('utf-8')
    return ''


def words(s):
    return re.findall(r'[^\W_]+', unicodedata.normalize('NFC', s).casefold(), re.UNICODE)


def labelled_wwids(text):
    return re.findall(r'(?i)\b(?:WW[ -]?ID|ClientEEID|Employee[ -]?ID(?:[ -]?Number)?)\s*[:#–-]?\s*([0-9]{4,15})\b', text)


def identify(text, file, wwid, first, last, plan):
    fields = labelled_wwids(text)
    if any(value != wwid for value in fields):
        return 'MISMATCH'
    canonical = os.path.basename(file).casefold() == f'{wwid}_Kontoauszug_{plan}.pdf'.casefold()
    stream = ' ' + ' '.join(words(text)) + ' '
    names = (first + ' ' + last, last + ' ' + first)
    if (canonical or fields) and any((' ' + ' '.join(words(name)) + ' ') in stream for name in names):
        return 'MATCH'
    return 'REVIEW'


def statement_details(text):
    # Dates from unrelated financial lines or the print footer do not establish the reporting period.
    title = bool(re.search(r"(?i)\b(?:kontoauszug|account statement|leistungsnachweis)\b", text))
    document_plans = set(re.findall(r"(?i)(?<![\w+])(DC(?:\+)?|PP\+)(?![\w+])", text))
    document_plans = {"DC" if p.upper() in {"DC", "DC+"} else "PP+" for p in document_plans}
    if re.search(r"(?i)\bPensionsplan\s*(?:\+|Plus\b)", text):
        document_plans.add("PP+")
    date_label = r"(?:Stichtag|Abrechnungsstichtag|Bewertungsstichtag|(?:Kontoauszug|Leistungsnachweis|Kontostand)\s+(?:per|zum)|Stand\s+(?:zum|per)|statement as (?:of|at))"
    date_values = re.findall(r"(?i)\b" + date_label + r"\s*[:–-]?\s*(\d{1,2}\.\s*\d{1,2}\.\s*(?:19|20)\d{2})\b", text)
    dates = set()
    bad_date = False
    for value in date_values:
        try:
            dates.add(datetime.strptime(re.sub(r"\s+", "", value), "%d.%m.%Y").strftime("%d.%m.%Y"))
        except ValueError:
            bad_date = True
    years = set(re.findall(r"(?i)\b(?:Abrechnungsjahr|Berichtsjahr|statement year|(?:Kontoauszug|Leistungsnachweis)(?:\s+(?:DC\+?|PP\+|Pensionsplan(?:\s*Plus|\s*\+)))?(?:\s+(?:für|fuer)(?:\s+das\s+Jahr)?)?)\s*[:–-]?\s*((?:19|20)\d{2})\b", text))
    conflicting_period = bad_date or len(dates) > 1 or len(years) > 1 or bool(dates and years and {d[-4:] for d in dates} != years)
    return {"statementPlan": next(iter(document_plans)) if title and len(document_plans) == 1 else None,
            "ambiguousPlan": len(document_plans) > 1, "ambiguousPeriod": conflicting_period,
            "periodDates": sorted(dates), "periodYears": sorted(years)}


if __name__ == '__main__':
    with open(sys.argv[1], 'rb') as source:
        data = source.read(50 * 1024 * 1024 + 1)
    fields = []
    details = {}
    text = ''
    try:
        text = extract(data, whole='--statement-period' in sys.argv[6:]) if len(data) <= 50 * 1024 * 1024 else ''
        fields = labelled_wwids(text)
        result = identify(text, *sys.argv[1:6])
        details = statement_details(text)
    except Exception:
        result = 'REVIEW'
    print(json.dumps({**details, 'status': result, 'hasText': bool(text.strip()), 'wwidInText': bool(fields) and set(fields) == {sys.argv[2]}, 'sha256': hashlib.sha256(data).hexdigest()}))
