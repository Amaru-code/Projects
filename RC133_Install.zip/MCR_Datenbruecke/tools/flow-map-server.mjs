/** Dedicated, read-only map service; no COMARCH imports and no browser commands. */
import path from 'node:path';import fs from 'node:fs';import {fileURLToPath} from 'node:url';
import {createFlowServer} from '../lib/runtime/flow-server.mjs';import {getFlowBridge} from '../lib/runtime/flow-launcher.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
if(!await getFlowBridge(root)){
 const dir=path.join(root,'.runtime','flow');fs.mkdirSync(dir,{recursive:true});const lock=path.join(dir,'server-start.lock');let fd;
 try{fd=fs.openSync(lock,'wx');}catch{try{if(Date.now()-fs.statSync(lock).mtimeMs>30000)fs.unlinkSync(lock);}catch{}process.exit(0);}
 try{if(!await getFlowBridge(root)){const svc=await createFlowServer(root);for(const sig of ['SIGINT','SIGTERM'])process.once(sig,async()=>{await svc.close();process.exit(0);});
  const check=setInterval(async()=>{if(fs.existsSync(path.join(root,'BETA_UMSTELLUNG_LAEUFT.txt'))||fs.existsSync(path.join(root,'.runtime','beta-control','migration-priority.json'))){clearInterval(check);await svc.close();process.exit(0);}},500);check.unref();
 }}finally{fs.closeSync(fd);try{fs.unlinkSync(lock);}catch{}}
}
