# RC94 shared native shell. Geometry only; no ticket data or approval stored.
# Hide means hide, NOT stop. A pending manual approval moves to the terminal.
$script:userHidden=$false
$script:shellDragging=$false
$script:panelPersistAt=[DateTime]::MaxValue
$script:panelFullSize=$form.ClientSize
$script:panelCollapsed=$false
$script:panelSettings=$env:MCR_PANEL_SETTINGS
function Save-McrPanel {
 if(-not $script:panelSettings -or $script:finishing){return}
 try {
  $folder=[System.IO.Path]::GetDirectoryName($script:panelSettings)
  if(-not [System.IO.Directory]::Exists($folder)){[void][System.IO.Directory]::CreateDirectory($folder)}
  $data=@{version=1;x=$form.Left;y=$form.Top;hidden=$script:userHidden;collapsed=$script:panelCollapsed}
  [System.IO.File]::WriteAllText($script:panelSettings,($data|ConvertTo-Json -Compress),(New-Object System.Text.UTF8Encoding($false)))
 }catch{}
}
function Show-McrPanel {
 if(-not $script:userHidden){$form.Show()}
}
function Hide-McrPanel {
 $script:userHidden=$true;$form.Hide();Save-McrPanel
 Send-Control @{event='visibility';visible=$false}
 if($script:challenge){$tray.ShowBalloonTip(3000,'MCR - Freigabe im Terminal','Das Fenster ist verborgen. Die Freigabe erfolgt jetzt per ENTER im Terminal.',[System.Windows.Forms.ToolTipIcon]::Info)}
}
function Restore-McrPanel {
 $script:userHidden=$false;[void]$form.SetMousePassThrough($false);$form.Opacity=1.0;$form.Show();Save-McrPanel
 Send-Control @{event='visibility';visible=$true}
}
$form.ShowInTaskbar=$true
$form.BackColor=[System.Drawing.Color]::FromArgb(247,251,249)
$form.ForeColor=[System.Drawing.Color]::FromArgb(23,52,44)
$form.Opacity=1.0
foreach($ctrl in $form.Controls){
 if($ctrl -is [System.Windows.Forms.Label]){$ctrl.ForeColor=[System.Drawing.Color]::FromArgb(23,52,44)}
 if($ctrl -is [System.Windows.Forms.Button]){
  $ctrl.FlatStyle='Flat';$ctrl.FlatAppearance.BorderSize=1
  $ctrl.FlatAppearance.BorderColor=[System.Drawing.Color]::FromArgb(185,211,200)
  $ctrl.BackColor=[System.Drawing.Color]::White;$ctrl.ForeColor=$form.ForeColor
 }
}
$ok.BackColor=[System.Drawing.Color]::FromArgb(14,110,76);$ok.ForeColor=[System.Drawing.Color]::White
$stop.ForeColor=[System.Drawing.Color]::FromArgb(155,46,39)
$title.Text='MCR  |  Ticketsteuerung';$title.Width=$form.ClientSize.Width-112
$title.Font=New-Object System.Drawing.Font('Segoe UI',10,[System.Drawing.FontStyle]::Bold)
$title.Cursor=[System.Windows.Forms.Cursors]::SizeAll
# Real pointer-drag works on any monitor, without a fixed bottom-left anchor.
$title.Add_MouseDown({param($sender,$e) if($e.Button -eq [System.Windows.Forms.MouseButtons]::Left){$script:shellDragging=$true;$script:shellOrigin=[System.Windows.Forms.Cursor]::Position;$script:shellStart=$form.Location;$title.Capture=$true}})
$title.Add_MouseMove({param($sender,$e) if($script:shellDragging){$at=[System.Windows.Forms.Cursor]::Position;$v=[System.Windows.Forms.SystemInformation]::VirtualScreen;$x=[Math]::Max($v.Left,[Math]::Min($v.Right-70,$script:shellStart.X+$at.X-$script:shellOrigin.X));$y=[Math]::Max($v.Top,[Math]::Min($v.Bottom-35,$script:shellStart.Y+$at.Y-$script:shellOrigin.Y));$form.Location=[System.Drawing.Point]::new([int]$x,[int]$y)}})
$title.Add_MouseUp({$script:shellDragging=$false;$title.Capture=$false;Save-McrPanel})
$min=New-Object System.Windows.Forms.Button;$min.Text='-';$min.AccessibleName='Panel einklappen';$min.Location=[System.Drawing.Point]::new(($form.ClientSize.Width-94),7);$min.Size=[System.Drawing.Size]::new(36,25);$min.FlatStyle='Flat';$min.FlatAppearance.BorderSize=0;$form.Controls.Add($min)
$hide=New-Object System.Windows.Forms.Button;$hide.Text='x';$hide.AccessibleName='Panel verstecken, Bot laeuft weiter';$hide.Location=[System.Drawing.Point]::new(($form.ClientSize.Width-51),7);$hide.Size=[System.Drawing.Size]::new(36,25);$hide.FlatStyle='Flat';$hide.FlatAppearance.BorderSize=0;$form.Controls.Add($hide)
$min.Add_Click({$script:panelCollapsed=-not $script:panelCollapsed;$form.ClientSize=if($script:panelCollapsed){[System.Drawing.Size]::new($script:panelFullSize.Width,39)}else{$script:panelFullSize};Save-McrPanel})
$hide.Add_Click({Hide-McrPanel})
$tray=New-Object System.Windows.Forms.NotifyIcon;$tray.Icon=[System.Drawing.SystemIcons]::Information;$tray.Text='MCR Ticketsteuerung - Doppelklick zum Einblenden';$tray.Visible=$true
$trayMenu=New-Object System.Windows.Forms.ContextMenuStrip
[void]$trayMenu.Items.Add('Panel anzeigen',$null,{Restore-McrPanel})
[void]$trayMenu.Items.Add('Panel verstecken',$null,{Hide-McrPanel})
[void]$trayMenu.Items.Add('Lauf stoppen',$null,{Send-Control @{event='abort'};$form.Close()})
$tray.ContextMenuStrip=$trayMenu;$tray.Add_DoubleClick({Restore-McrPanel})
try {
 if($script:panelSettings -and [System.IO.File]::Exists($script:panelSettings)){
  $v=Get-Content -LiteralPath $script:panelSettings -Raw|ConvertFrom-Json
  if($v.version -eq 1){
   $screen=[System.Windows.Forms.SystemInformation]::VirtualScreen
   $form.Location=[System.Drawing.Point]::new([int][Math]::Max($screen.Left,[Math]::Min($screen.Right-$form.Width,[int]$v.x)),[int][Math]::Max($screen.Top,[Math]::Min($screen.Bottom-40,[int]$v.y)))
   $script:userHidden=($v.hidden -eq $true);$script:panelCollapsed=($v.collapsed -eq $true)
   if($script:panelCollapsed){$form.ClientSize=[System.Drawing.Size]::new($script:panelFullSize.Width,39)}
  }
 }
}catch{}
$form.Add_Shown({
 Send-Control @{event='visibility';visible=(-not $script:userHidden)}
 if($script:userHidden){[void]$form.BeginInvoke([System.Action]{ $form.Hide() })}
})
$form.Add_FormClosed({Save-McrPanel;$tray.Visible=$false;$tray.Dispose();$trayMenu.Dispose()})
