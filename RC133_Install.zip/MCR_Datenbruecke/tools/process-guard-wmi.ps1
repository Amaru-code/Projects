# RC103: independently enumerated Windows process snapshot via classic WMI.
# Never substitute Get-Process alone: the command line is needed to establish
# exact MCR ownership without taking control of another application.
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$records = @(Get-WmiObject -Class Win32_Process -ErrorAction Stop)
$items = @($records | ForEach-Object {
    $created = $null
    if ($null -ne $_.CreationDate -and -not [string]::IsNullOrWhiteSpace([string]$_.CreationDate)) {
        $created = [System.Management.ManagementDateTimeConverter]::ToDateTime([string]$_.CreationDate).ToUniversalTime().ToString('o')
    }
    [ordered]@{
        pid = [int]$_.ProcessId
        parentPid = [int]$_.ParentProcessId
        name = [string]$_.Name
        createdAt = $created
        executablePath = $(if ($null -eq $_.ExecutablePath) { $null } else { [string]$_.ExecutablePath })
        commandLine = $(if ($null -eq $_.CommandLine) { $null } else { [string]$_.CommandLine })
    }
})
[ordered]@{schema='MCR_WINDOWS_PROCESS_SNAPSHOT_V1';checked=$true;processes=$items} | ConvertTo-Json -Depth 5 -Compress
