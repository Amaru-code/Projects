param([Parameter(Mandatory=$true)][string]$RequestPath)
# RC97. No Excel application, macro, calculation or UI automation. Keep an
# exclusive OS handle from original-hash verification through durable readback.
$ErrorActionPreference = 'Stop'
$stream = $null
$original = $null
$mutationStarted = $false
$transaction = $null
function Get-BytesHash([byte[]]$Bytes) {
    $hasher = [System.Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($hasher.ComputeHash($Bytes))).Replace('-', '').ToLowerInvariant() }
    finally { $hasher.Dispose() }
}
function Read-StreamBytes($Handle) {
    if ($Handle.Length -gt 83886080 -or $Handle.Length -lt 22) { throw 'WORKBOOK_SIZE' }
    $Handle.Position = 0
    $data = New-Object byte[] ([int]$Handle.Length)
    $offset = 0
    while ($offset -lt $data.Length) {
        $n = $Handle.Read($data, $offset, $data.Length - $offset)
        if ($n -le 0) { throw 'WORKBOOK_SHORT_READ' }
        $offset += $n
    }
    return ,$data
}
function Save-Journal($Value) {
    $json = $Value | ConvertTo-Json -Depth 8 -Compress
    $raw = [Text.Encoding]::UTF8.GetBytes($json)
    $j = [IO.FileStream]::new($request.transactionPath, [IO.FileMode]::Create, [IO.FileAccess]::Write, [IO.FileShare]::None)
    try { $j.Write($raw, 0, $raw.Length); $j.Flush($true) } finally { $j.Dispose() }
}
try {
    $request = [IO.File]::ReadAllText($RequestPath, [Text.Encoding]::UTF8) | ConvertFrom-Json
    if ($request.schema -ne 'MCR_WORKBOOK_COMMIT_V1' -or
        $request.beforeSha256 -notmatch '^[a-f0-9]{64}$' -or
        $request.afterSha256 -notmatch '^[a-f0-9]{64}$') { throw 'WORKBOOK_COMMIT_REQUEST' }
    foreach ($p in @($request.path, $request.stagedPath, $request.backupPath, $request.transactionPath)) {
        if (-not [IO.Path]::IsPathRooted($p)) { throw 'WORKBOOK_COMMIT_PATH' }
    }
    $paths = @($request.path, $request.stagedPath, $request.backupPath, $request.transactionPath) | ForEach-Object { [IO.Path]::GetFullPath($_).ToLowerInvariant() }
    if (@($paths | Select-Object -Unique).Count -ne 4) { throw 'WORKBOOK_COMMIT_PATH' }
    $replacement = [IO.File]::ReadAllBytes($request.stagedPath)
    if ($replacement.Length -gt 83886080 -or (Get-BytesHash $replacement) -ne $request.afterSha256) { throw 'WORKBOOK_STAGE_CHANGED' }
    # If Excel or another program holds a conflicting handle, Open fails before
    # any write. The parent leaves this contact in its retry queue.
    $stream = [IO.FileStream]::new($request.path, [IO.FileMode]::Open, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
    $original = Read-StreamBytes $stream
    if ((Get-BytesHash $original) -ne $request.beforeSha256) { throw 'WORKBOOK_CONCURRENT_CHANGE' }
    $backup = [IO.FileStream]::new($request.backupPath, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
    try { $backup.Write($original,0,$original.Length); $backup.Flush($true) } finally { $backup.Dispose() }
    if ((Get-BytesHash ([IO.File]::ReadAllBytes($request.backupPath))) -ne $request.beforeSha256) { throw 'WORKBOOK_BACKUP_VERIFY' }
    $transaction = [ordered]@{schema='MCR_WORKBOOK_TRANSACTION_V1'; state='WRITE_INTENT'; path=$request.path;
        beforeSha256=$request.beforeSha256; afterSha256=$request.afterSha256; backupPath=$request.backupPath;
        stagedPath=$request.stagedPath; startedAt=[DateTime]::UtcNow.ToString('o')}
    Save-Journal $transaction
    $mutationStarted = $true
    $stream.Position = 0
    $stream.Write($replacement,0,$replacement.Length)
    $stream.SetLength($replacement.Length)
    $stream.Flush($true)
    if ((Get-BytesHash (Read-StreamBytes $stream)) -ne $request.afterSha256) { throw 'WORKBOOK_COMMIT_READBACK' }
    $transaction.state='COMMITTED_VERIFIED'; $transaction.finishedAt=[DateTime]::UtcNow.ToString('o')
    Save-Journal $transaction
    @{ok=$true; code='WORKBOOK_COMMITTED_VERIFIED'} | ConvertTo-Json -Compress
} catch {
    $reason = $_.Exception.Message
    $code = if ($reason -match '^WORKBOOK_[A-Z_]+$') { $reason } else { 'WORKBOOK_LOCKED_OR_IO' }
    if ($mutationStarted -and $null -ne $stream -and $null -ne $original) {
        try {
            # Restore only our own partial write while the same exclusive
            # handle is still held. Never restore over a later foreign edit.
            $stream.Position=0; $stream.Write($original,0,$original.Length)
            $stream.SetLength($original.Length); $stream.Flush($true)
            if ((Get-BytesHash (Read-StreamBytes $stream)) -ne $request.beforeSha256) { throw 'RESTORE_READBACK' }
            $transaction.state='RESTORED_VERIFIED'; $transaction.errorCode=$code
            Save-Journal $transaction
            $code='WORKBOOK_WRITE_RESTORED'
        } catch { $code='WORKBOOK_COMMIT_UNCERTAIN' }
    }
    @{ok=$false; code=$code} | ConvertTo-Json -Compress
    exit 1
} finally {
    if ($null -ne $stream) { $stream.Dispose() }
}
