﻿# RC54 Phase-2: local two-way anonymous pipes; no browser/OS input injection.
# RC94: geometry/visibility preferences only are saved locally.
# Panel confirms click-through (or safe hiding) before automated CDP input.
$ErrorActionPreference = 'Stop'
try {
 [Console]::InputEncoding = New-Object System.Text.UTF8Encoding($false)
 [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
 Add-Type -AssemblyName System.Windows.Forms
 Add-Type -AssemblyName System.Drawing
 Add-Type -ReferencedAssemblies System.Windows.Forms,System.Drawing @'
using System;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
// Console.In.ReadLineAsync is synchronous on .NET Framework. Keep all reads
// on one background thread, never on the Forms message pump.
public sealed class McrPipeReader {
 private readonly System.Collections.Generic.Queue<string> lines=new System.Collections.Generic.Queue<string>();
 public volatile bool Done;
 public bool Empty { get { lock(lines){return lines.Count==0;} } }
 public McrPipeReader(){var t=new System.Threading.Thread(Read);t.IsBackground=true;t.Name="MCR anonymous pipe reader";t.Start();}
 private void Read(){try{string line;while((line=Console.In.ReadLine())!=null){lock(lines){if(lines.Count>=512||line.Length>8192)break;lines.Enqueue(line);}}}catch{}finally{Done=true;}}
 public string Take(){lock(lines){return lines.Count==0?null:lines.Dequeue();}}
}
public class McrControlForm : Form {
 protected override bool ShowWithoutActivation { get { return true; } }
 protected override CreateParams CreateParams { get { var p=base.CreateParams; p.ExStyle |= 0x08000000 | 0x00000080; return p; } }
 [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr h, int n);
 [DllImport("user32.dll")] public static extern int SetWindowLong(IntPtr h, int n, int v);
 public bool SetMousePassThrough(bool enable) {
  int current=GetWindowLong(Handle,-20);
  int desired=enable?current|0x00000020:current&~0x00000020;
  if(desired!=current)SetWindowLong(Handle,-20,desired);
  return ((GetWindowLong(Handle,-20)&0x00000020)!=0)==enable;
 }
 public void MakeTransparentToMouse(){SetMousePassThrough(true);}

}
public class McrModeSwitch : Control {
 private bool value;
 public event EventHandler CheckedChanged;
 public bool Checked { get { return value; } set { if(this.value==value)return;this.value=value;Invalidate();if(CheckedChanged!=null)CheckedChanged(this,EventArgs.Empty); } }
 public McrModeSwitch(){ SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer,true);Cursor=Cursors.Hand;AccessibleName="Versandmodus Manuell oder Auto"; }
 protected override void OnClick(EventArgs e){ Checked=!Checked;base.OnClick(e); }
 protected override void OnPaint(PaintEventArgs e){
  base.OnPaint(e);var g=e.Graphics;g.SmoothingMode=SmoothingMode.AntiAlias;
  using(var pen=new SolidBrush(Color.FromArgb(23,52,44))){
   g.DrawString("MANUELL",Font,pen,0,9);g.DrawString("AUTO",Font,pen,163,9);
  }
  using(var track=new SolidBrush(value?Color.FromArgb(25,142,76):Color.FromArgb(90,105,126)))
  using(var knob=new SolidBrush(Color.White)){
   g.FillEllipse(track,87,4,27,27);g.FillRectangle(track,100,4,31,27);g.FillEllipse(track,118,4,27,27);
   g.FillEllipse(knob,value?121:90,7,21,21);
  }
 }
}
// Completed tickets are independent immutable, noninteractive cards. They do
// not consume the next ticket's approval and cannot intercept browser input.
public class McrTicketGhost : McrControlForm {
 private readonly DateTime started=DateTime.UtcNow;
 private readonly int startY,endY,left;
 public McrTicketGhost(Form source, Rectangle work) {
  FormBorderStyle=FormBorderStyle.None;StartPosition=FormStartPosition.Manual;
  ShowInTaskbar=false;TopMost=true;ClientSize=source.ClientSize;
  BackColor=Color.FromArgb(18,58,37);ForeColor=Color.White;
  left=work.Left+16;startY=work.Bottom-Height-16;endY=work.Top+16;
  Location=new Point(left,startY);
  foreach(Control c in source.Controls) {
   Label l=c as Label;if(l==null)continue;
   var copy=new Label();copy.Text=l.Text;copy.Font=l.Font;copy.Location=l.Location;
   copy.Size=l.Size;copy.AutoEllipsis=true;copy.ForeColor=Color.White;
   if(l.Top<35){copy.Text="ABGESCHLOSSEN | "+source.Tag;copy.ForeColor=Color.LightGreen;}
   Controls.Add(copy);
  }
  var status=new Label();status.Text="Weiterleitung bestaetigt - kein E-Mail-Versand";
  status.Font=source.Font;status.ForeColor=Color.LightGreen;status.Location=new Point(13,Height-35);
  status.Size=new Size(Width-26,22);Controls.Add(status);
  Show();MakeTransparentToMouse();
 }
 public bool Step(DateTime now) {
  double t=Math.Max(0,Math.Min(1,(now-started).TotalMilliseconds/5000.0));
  double ease=3*t*t-2*t*t*t;
  Location=new Point(left,(int)Math.Round(startY+(endY-startY)*ease));
  Opacity=Math.Max(0,1-ease);
  if(t>=1){Close();Dispose();return true;}return false;
 }
}

'@
 function Send-Control($data) {
  $data.schema = 'MCR_CONTROL_V1'
  [Console]::Out.WriteLine(($data | ConvertTo-Json -Compress))
  [Console]::Out.Flush()
 }
 $form=New-Object McrControlForm
 $form.Text='MCR Ticketsteuerung'
 $form.FormBorderStyle='None';$form.StartPosition='Manual';$form.ShowInTaskbar=$false;$form.TopMost=$true
 $form.ClientSize=New-Object System.Drawing.Size(440,372)
 $form.BackColor=[System.Drawing.Color]::FromArgb(22,32,46);$form.ForeColor=[System.Drawing.Color]::White
 $work=[System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
 $form.Location=New-Object System.Drawing.Point(($work.Left+16),($work.Bottom-388))
 # RC87: operator can drag by the title; location stays for this run.
 # No coordinate or personal information is written to disk.
 $script:dragging=$false;$script:dragOrigin=[System.Drawing.Point]::Empty;$script:windowOrigin=[System.Drawing.Point]::Empty
 $dragStart={param($sender,$e)
  if($e.Button -eq [System.Windows.Forms.MouseButtons]::Left){
   $script:dragging=$true;$script:dragOrigin=[System.Windows.Forms.Cursor]::Position
   $script:windowOrigin=$form.Location
  }
 }
 $dragMove={param($sender,$e)
  if(-not $script:dragging){return}
  if(([System.Windows.Forms.Control]::MouseButtons -band [System.Windows.Forms.MouseButtons]::Left) -eq 0){$script:dragging=$false;return}
  $at=[System.Windows.Forms.Cursor]::Position
  $v=[System.Windows.Forms.SystemInformation]::VirtualScreen
  $x=[Math]::Max($v.Left,[Math]::Min($v.Right-$form.Width,$script:windowOrigin.X+$at.X-$script:dragOrigin.X))
  $y=[Math]::Max($v.Top,[Math]::Min($v.Bottom-$form.Height,$script:windowOrigin.Y+$at.Y-$script:dragOrigin.Y))
  $form.Location=[System.Drawing.Point]::new([int]$x,[int]$y)
 }
 $dragEnd={param($sender,$e) $script:dragging=$false}

 $font=New-Object System.Drawing.Font('Segoe UI',9)
 $bold=New-Object System.Drawing.Font('Segoe UI',10,[System.Drawing.FontStyle]::Bold)
 $form.Font=$font
 $title=New-Object System.Windows.Forms.Label
 $title.Text='MCR | PHASE 2 - EIN TICKET (ziehen)';$title.Font=$bold;$title.Location=New-Object System.Drawing.Point(13,10);$title.Size=New-Object System.Drawing.Size(410,24);$form.Controls.Add($title)
 $title.Cursor=[System.Windows.Forms.Cursors]::SizeAll
 $title.Add_MouseDown($dragStart);$title.Add_MouseMove($dragMove);$title.Add_MouseUp($dragEnd)
 $form.Add_MouseDown($dragStart);$form.Add_MouseMove($dragMove);$form.Add_MouseUp($dragEnd)

 $values=@{};$n=0
 foreach($key in @('ticket','name','id','usc','answered','kind','request','recipient','phase')){
  $lab=New-Object System.Windows.Forms.Label;$lab.Text=@('Ticket','Person','MercerID','USC / Plaene','Antwort','Fall','Anfrage','Pruefer','Schritt')[$n]
  $lab.Location=New-Object System.Drawing.Point(13,(40+23*$n));$lab.Size=New-Object System.Drawing.Size(90,22);$form.Controls.Add($lab)
  $val=New-Object System.Windows.Forms.Label;$val.Text='-';$val.AutoEllipsis=$true;$val.Location=New-Object System.Drawing.Point(105,(40+23*$n));$val.Size=New-Object System.Drawing.Size(322,22);$form.Controls.Add($val);$values[$key]=$val;$n++
 }
 $toggle=New-Object McrModeSwitch
 $toggle.Location=New-Object System.Drawing.Point(13,264);$toggle.Size=New-Object System.Drawing.Size(210,33);$toggle.Checked=$false
 $form.Controls.Add($toggle)
 $modeLabel=New-Object System.Windows.Forms.Label;$modeLabel.Location=New-Object System.Drawing.Point(272,273);$modeLabel.Size=New-Object System.Drawing.Size(120,20);$modeLabel.Text='MANUELL aktiv';$form.Controls.Add($modeLabel)
 $ok=New-Object System.Windows.Forms.Button;$ok.Text='Schritt freigeben';$ok.Location=New-Object System.Drawing.Point(13,310);$ok.Size=New-Object System.Drawing.Size(330,44);$ok.Enabled=$false;$form.Controls.Add($ok)
 $skip=New-Object System.Windows.Forms.Button;$skip.Text='Unveraendert lassen';$skip.Location=New-Object System.Drawing.Point(183,310);$skip.Size=New-Object System.Drawing.Size(160,44);$skip.Visible=$false;$skip.Enabled=$false;$form.Controls.Add($skip)
 $stop=New-Object System.Windows.Forms.Button;$stop.Text='STOP';$stop.Location=New-Object System.Drawing.Point(354,310);$stop.Size=New-Object System.Drawing.Size(70,44);$form.Controls.Add($stop)
 $script:ticket='';$script:challenge='';$script:syncing=$false;$script:finishing=$false;$script:finishAt=[DateTime]::MinValue;$script:resumeAt=[DateTime]::MaxValue
 $toggle.Add_CheckedChanged({
  $mode=if($toggle.Checked){'AUTO'}else{'MANUAL'}
  $modeLabel.Text=if($toggle.Checked){'AUTO aktiv'}else{'MANUELL aktiv'}
  $toggle.Invalidate()
  if(-not $script:syncing){Send-Control @{event='mode';mode=$mode}}
 })
 $ok.Add_Click({if($script:challenge){Send-Control @{event='approve';ticket=$script:ticket;challenge=$script:challenge};$ok.Enabled=$false;$skip.Enabled=$false}})
 $skip.Add_Click({if($script:challenge -and $skip.Enabled){Send-Control @{event='skip';ticket=$script:ticket;challenge=$script:challenge};$ok.Enabled=$false;$skip.Enabled=$false}})
 $script:paused=$false
 $stop.Add_Click({
  $script:paused=-not $script:paused
  $stop.Text=$(if($script:paused){'CONTINUE'}else{'STOP'})
  $stop.BackColor=$(if($script:paused){[System.Drawing.Color]::DarkOrange}else{[System.Drawing.SystemColors]::Control})
  $pauseEvent=if($script:paused){'pause'}else{'continue'}
  Send-Control @{event=$pauseEvent}
 })
  $script:closing=$false;$script:completedTicket='';$script:ghosts=New-Object 'System.Collections.Generic.List[McrTicketGhost]'
 . (Join-Path $PSScriptRoot 'panel-shell.ps1')
 $reader=New-Object McrPipeReader
 $timer=New-Object System.Windows.Forms.Timer;$timer.Interval=16
 $timer.Add_Tick({
  for($budget=0;$budget -lt 32;$budget++){
   $line=$reader.Take()
   if($null -eq $line){break}
   try {
     $m=$line|ConvertFrom-Json -ErrorAction Stop
     if($m.schema -eq 'MCR_PROGRESS_V2'){
      if($m.event -eq 'suspend'){
       $script:resumeAt=[DateTime]::MaxValue
       # The window remains visible but passes mouse clicks through to Edge.
       # If Windows does not confirm WS_EX_TRANSPARENT, use old fail-safe Hide.
       if($form.SetMousePassThrough($true)){
        $form.Opacity=0.78
       }else{
        $form.Hide();[System.Windows.Forms.Application]::DoEvents()
       }
       Send-Control @{event='hidden';seq=[int]$m.seq}
      }
      elseif($m.event -eq 'resume'){$script:resumeAt=[DateTime]::UtcNow.AddMilliseconds(160)}
      elseif($m.event -eq 'pause_state'){$script:paused=($m.paused -eq $true);$stop.Text=$(if($script:paused){'CONTINUE'}else{'STOP'});[void]$form.SetMousePassThrough($false);Show-McrPanel}
      elseif($m.event -eq 'mode'){$script:syncing=$true;$toggle.Checked=($m.mode -eq 'AUTO');$script:syncing=$false}
      elseif($m.event -eq 'ticket_start'){
       $script:ticket=[string]$m.ticket;$script:challenge='';$script:completedTicket='';$form.Tag=$script:ticket
       foreach($key in $values.Keys){$values[$key].Text='-'}
       $title.Text='MCR | TICKET '+$script:ticket;$title.ForeColor=[System.Drawing.Color]::FromArgb(23,52,44)
       $ok.Text='Schritt freigeben';$ok.Enabled=$false;$ok.Width=330;$skip.Visible=$false;$skip.Enabled=$false;Show-McrPanel
      }
      elseif($m.event -eq 'approval'){
       if([string]$m.ticket -eq $script:ticket){$script:challenge=[string]$m.challenge;$ok.Text=[string]$m.label;$ok.Enabled=$true;$skip.Visible=($m.allowSkip -eq $true);$skip.Enabled=$skip.Visible;$ok.Width=if($skip.Visible){164}else{330};Show-McrPanel}
      }
      elseif($m.event -eq 'ticket_deferred'){
       if([string]$m.ticket -eq $script:ticket){
        $script:challenge='';$ok.Enabled=$false;$skip.Enabled=$false;$skip.Visible=$false
        $script:completedTicket=$script:ticket;$script:resumeAt=[DateTime]::MaxValue
        $values['phase'].Text='Zur manuellen Pruefung zurueckgestellt';Show-McrPanel
       }
      }
      elseif($m.event -eq 'ticket_complete'){
       if([string]$m.ticket -eq $script:ticket -and $script:completedTicket -ne $script:ticket){
        $script:challenge='';$ok.Enabled=$false;$values['phase'].Text=[string]$m.phase
        $script:completedTicket=$script:ticket;$form.Tag=$script:ticket
        # Keep the compact panel in place; no moving/fading ghost window.
        $title.Text='MCR | TICKET '+$script:ticket+' – abgeschlossen (ziehen)'
        $title.ForeColor=[System.Drawing.Color]::FromArgb(14,110,76)
        [void]$form.SetMousePassThrough($false);$form.Opacity=1.0
        Show-McrPanel;$script:resumeAt=[DateTime]::MaxValue
       }
      }
      elseif($m.event -eq 'approval_consumed'){$ok.Enabled=$false;$skip.Enabled=$false;$skip.Visible=$false;$script:challenge=''}
      elseif($m.event -eq 'error'){$title.Text='MCR | PRUEFUNG ERFORDERLICH';$title.ForeColor=[System.Drawing.Color]::Orange;$ok.Enabled=$false;$skip.Enabled=$false;$skip.Visible=$false}
      elseif($m.event -eq 'finish'){
       $script:finishing=$true;$script:finishAt=[DateTime]::UtcNow;$form.Hide();$form.Controls.Clear()
       $form.BackColor=[System.Drawing.Color]::Black;$form.TransparencyKey=[System.Drawing.Color]::Black
       $form.Location=$work.Location;$form.Size=$work.Size;$form.Opacity=1.0
       $big=New-Object System.Windows.Forms.Label;$big.Text=[string]$m.title;$big.ForeColor=[System.Drawing.Color]::LimeGreen;$big.BackColor=[System.Drawing.Color]::Black
       $big.Font=New-Object System.Drawing.Font('Segoe UI',([Math]::Max(24,[Math]::Min(58,$work.Width/33))),[System.Drawing.FontStyle]::Bold)
       $big.TextAlign='MiddleCenter';$big.Location=New-Object System.Drawing.Point(20,([int]($work.Height/2)-110));$big.Size=New-Object System.Drawing.Size(($work.Width-40),150);$form.Controls.Add($big)
       $sub=New-Object System.Windows.Forms.Label;$sub.Text=[string]$m.subtitle;$sub.Font=$bold;$sub.ForeColor=[System.Drawing.Color]::LightGreen;$sub.TextAlign='MiddleCenter'
       $sub.Location=New-Object System.Drawing.Point(20,([int]($work.Height/2)+40));$sub.Size=New-Object System.Drawing.Size(($work.Width-40),50);$form.Controls.Add($sub)
       $form.MakeTransparentToMouse();Show-McrPanel
      }
      elseif($m.event -eq 'close' -and -not $script:finishing){$script:closing=$true;$form.Hide()}
      if(-not $script:finishing){foreach($key in @('ticket','name','id','usc','answered','kind','request','recipient','phase')){if($null -ne $m.$key){$values[$key].Text=[string]$m.$key}}}
     }
   }catch{}
  }
  if($reader.Done -and $reader.Empty -and -not $script:finishing){$script:closing=$true;$form.Hide()}
  for($i=$script:ghosts.Count-1;$i -ge 0;$i--){if($script:ghosts[$i].Step([DateTime]::UtcNow)){$script:ghosts.RemoveAt($i)}}
  if($script:closing -and $script:ghosts.Count -eq 0){$timer.Stop();$form.Close()}
  if($script:finishing){
   $t=[Math]::Min(1.0,([DateTime]::UtcNow-$script:finishAt).TotalMilliseconds/5000.0)
   $form.Opacity=[Math]::Max(0.0,1.0-(3*$t*$t-2*$t*$t*$t))
   if($t -ge 1.0){$timer.Stop();$form.Close()}
  }elseif(-not $script:closing -and $script:completedTicket -ne $script:ticket -and [DateTime]::UtcNow -ge $script:resumeAt){$script:resumeAt=[DateTime]::MaxValue;$form.SetMousePassThrough($false);$form.Opacity=1.0;Show-McrPanel}
 })
 $form.Add_Shown({Send-Control @{event='ready'}})
 $timer.Start();[System.Windows.Forms.Application]::Run($form)
 $timer.Dispose();$form.Dispose();$font.Dispose();$bold.Dispose()
}catch{exit 1}
