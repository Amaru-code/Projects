import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {sha256,requireThat as need} from '../lib/core.mjs';
import {readJSON,plainPath,VERSION} from '../lib/control.mjs';
import {resolveConfig} from '../lib/config.mjs';
const PACKAGE_ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
// Manifests of independently verified historical releases (two for RC94).
const priorReleases=new Map([
 ['0.8.1-rc.64',['67b836e15f7a11bc9ed8f6cb8e5765396a58da4bf6824db1e7678802c8e65c0e']],
 ['0.8.1-rc.65',['f8cf24bcb95e68d12209f49bfc602bf0b452102eefb226de4e935c089dfa6512']],
 ['0.8.1-rc.67',['e97f8d9b78b770a8e0f8a50253af0a51bc9175866f47d20e0df8d3cd44f7b73f']],
 ['0.8.1-rc.68',['23dcfe5c56741d1844e0fabf862284223c2341fde90caa446bc00cf8f6b9a71f']],
 ['0.8.1-rc.69',['6943e16e8906aa30789540571c1b8553e61430d5498f1f44b4874ba6647ac40e']],
 ['0.8.1-rc.70',['4b22f1d3816e4d389640304906f4001d46bf64dc7874118f53b92ef9a6e540c3']],
 ['0.8.1-rc.71',['de11bdd7a1a08167de48ef76078c3908d8b74626c1ab6755b15391aa4bd9a0c6']],
 ['0.8.1-rc.72',['f4cba0ab9511ab17bff4fb795b32b218179abcc98155fd8231afecd624bd6633']],
 ['0.8.1-rc.73',['7dc28bd66f8caba0c5932a3288ae3984546fc09da3eb33ac754c2e1f79141f86']],
 ['0.8.1-rc.74',['bb63bdbbbab32b84a40d47281dd2aa5506a7aee6d7aa1407c351842a396df65c']],
 ['0.8.1-rc.75',['ab916367c9c2fb3b188c7140afa36edf68283f15a319c88736fc365b1bbbbc5c']],
 ['0.8.1-rc.76',['ede7beb828558ba0b6cbead64b791284731764600daa65f78625b02bfcdabde2']],
 ['0.8.1-rc.77',['f98c4a2259ae1a38deb553fc929148db1e4bc39f7ce8d4f3f452fb09e8950529']],
 ['0.8.1-rc.78',['8d99a070a092639427217d9a932c5d36c0f063826a77582c475f2f2768a1785c']],
 ['0.8.1-rc.79',['3dcac2c8c14deaff1a55bde99b6d4f45f7c7b50a5dd97710ad61e950a5517239']],
 ['0.8.1-rc.80',['a0644c23a00915d68ffa244faf5ba3e33b8f49c91091347e98f50c00473aac71']],
 ['0.8.1-rc.81',['b7924db25c8bf2a52f230f9cdfe02d97866d8dd7c509a018d99598831925fce6']],
 ['0.8.1-rc.82',['f87b30ac30d59cdc3aaecf4081a5b3f794a7bf4367e4fb0e3b473947cf6d7b27']],
 ['0.8.1-rc.83',['6fc1bc461cfeb5a39f974ea5b2ed8f3a6695159ee6196eaa80fb1ad72287a74c']],
 ['0.8.1-rc.84',['c6d50ff7bba1fccbd425ad8f872dee0ca0c6f71fdadb5fb208311251f181e015']],
 ['0.8.1-rc.85',['df122b594acdade1073b172f3acf40b9ac31dc740f75033cb04cee740b1282b6']],
 ['0.8.1-rc.86',['7820f91b57dcfca6a769e211f7fcc4472053bb53f068b3e9e05c8d069f98c029']],
 ['0.8.1-rc.87',['1f1bfbc5cabb59a4852e55856623dc9b505c5e25efe8aca3f2f1c34a974231c6']],
 ['0.8.1-rc.88',['559e29acfd833104ba95f4856c89ee4825ea10250fe86be0e5d12e825180b69b']],
 ['0.8.1-rc.89',['6d5c825760394bce6b4e128587578c95a248acd93e4b9a8795f1167a74665580']],
 ['0.8.1-rc.90',['dab7966bb862344b340087bd2d69346f5e3c1ff7fb603375f83607e9a0c08676']],
 ['0.8.1-rc.91',['42778da89875190ecfab5297187446895700ed65524a59ac7476050f622eab9a']],
 ['0.8.1-rc.92',['2b5d9c9264aa0ae3bf02afc05e750cef2090e0fbfbf47099411c4eadbfe5e9ec']],
 ['0.8.1-rc.93',['335301830d3d6582b0bab659b5a414171647e3180a4695aa38bbe8c6ac683bbf']],
 ['0.8.1-rc.94',['9203e5d680c6b774873ea7ea2f92574e27bdb20bd84c6b6cd0c5670c0554b971', '86f82e42b6aa2d78e33240b2eeb497b191778b95921cee6cde48129a298177a7']],
 ['0.8.1-rc.95',['6aebdab2ccd7ad79337c7a03f23c6b653e5f0b35589d236b56fad8b13c609ff9']],
 ['0.8.1-rc.96',['18e867c7e05b74f433497429eef3af238c77cd7745334c0d698e0bf5b1558f0f']],
 ['0.8.1-rc.97',['1643c7c8cde2806776a21a777231bac21f99af0cbf55af2a3ba6a1fc35967c3d']],
 ['0.8.1-rc.98',['3ee7396e87f717f55d03c7ed6176e114c36d98e063c8c78fa1b8632595707a94']],
 ['0.8.1-rc.99',['6238414a74e00a2a7c1c77cd62907a36ab65af0aa251474df12d4a85bef3abee']],
 ['0.8.1-rc.100',['adabf8d5c3716e52488c333e421bf45036ae043ee383fe5a684f2a2d9f02fb3d']],
 ['0.8.1-rc.101',['7617fcc2826188662966c68da4754fd3f68395ad148e295a414f130fefc0ca89']],
 ['0.8.1-rc.102',['77d63d0d575b0454024c0b0609debacf9f38361d55ef77c649cf6cdb5f8d37b4']],
 ['0.8.1-rc.103',['afd896e89985eb13983743fa575c7e295c8b7cde23a068382d8d33634d40e032']],
 ['0.8.1-rc.104',['0f2439b7fa6b138cc2778455223d345b496878ac7e6bd2e8307e267a1de21fcf']],
 ['0.8.1-rc.105',['32ad587fc3141e77358ca920058aa5e7caf647e5c56dd0e9d0043c93c55773a8']],
 ['0.8.1-rc.106',['91a81e1998f091a81eeb1b2c336f8f08e2f9791d9e88527ce1ef6ea641049f85']],
 ['0.8.1-rc.107',['42bbc96aa5a59f1f9fc22d04b50479502521d4863b7643496be38624873c1769']],
 ['0.8.1-rc.108',['f67fc8cb4b39dcf1318f41928d3d50e839d9107a0da5bfccc42b0da3ebd5f4e7']],
 ['0.8.1-rc.109',['9fee2fc9f2756b33b0435b9d4c79ac7fd3d5675319cc1d264bc86cd4c99cdb3e']],
 ['0.8.1-rc.110',['d52669d25ecabe6d2e61053d741ed6a35870a294481e381c51a385a26cedae20']],
 ['0.8.1-rc.111',['7c6b73fd474828a6a47e8cbaba5e24d538cbaec0ee454951838db5c18773523d']],
 ['0.8.1-rc.112',['06231a8ac6ff17a4067637b09d9778bc7c7df57ff43cc45197bd23ba83657a8e']],
 ['0.8.1-rc.113',['2e5b8fc7af248c75ad1de7628d8c8f9d1d6e1595cd3ceb957a25c79501c395ad']],
 ['0.8.1-rc.114',['f4b4e413d0f17509e6bb92c716283790b834a50e7f75cc82f262d3eb4830dd10']],
 ['0.8.1-rc.115',['6015d9373d6e4ae05368f9a6e2a137b7114065517fb6f274a181edf4a61391e6']],
 ['0.8.1-rc.116',['6572da1618183e84f4dd3b83303c255df6997ce86d899800317b2a37d659e423']],
 ['0.8.1-rc.117',['e8eda96ac314b645a3bfebfa06c5dbe86b22fb6f223de8effd60907ae8f45a19']],
 ['0.8.1-rc.118',['44cf073eab85626bf177d6f6691ca23acf0f9cd96a35b3593f61063bb702fb86']],
 ['0.8.1-rc.119',['ce959245f13fba38ee6caf9f0aacb66354ff044d6dfc20e80d803ffeba97063e']],
 ['0.8.1-rc.120',['73fb2013586116e0f00bfd449f377b3a32556a8fff08a11102a018611b13d615']],
 ['0.8.1-rc.121',['3692f1b0afe4cfe759d89311f8e4f6833ff0b77e7b2ea33681eb6f88cc3efc12']],
 ['0.8.1-rc.122',['9e4c8aa5905978f51f0f63ed28fc9a0036eff20131be761ab68c4b307e051fcb']],
 ['0.8.1-rc.123',['d178e9d9b725d3a346b188c2c47ef3ffe2a00652a5686e43f9e7bc98d149f9cf']],
 ['0.8.1-rc.124',['e0a014bf5ee780b86562a47561ade801129cd3213bf183b9f7d13b5c6202317a']],
 ['0.8.1-rc.125',['2222dbdf0536f9632a2e0dd0a86a23e41e714d145d60ceeef73d29f5d5718646']],
 ['0.8.1-rc.126',['71156d7e51c02f5b0093834b0064f71de7c96387bbc5344a20fbd9cb41700219']],
 ['0.8.1-rc.127',['c941e525c3d8b00dafac116b069cc1e4c849113eb82799f05aba5aa656bcd792']],
 ['0.8.1-rc.128',['a66ae483e88ec1773c25571462754dcae1ae8ec558e405ed5cc7b1e04b4f5b77']],
 ['0.8.1-rc.129',['74eef4199b3715337e9cf45a9c794170ac61025ac526fd76cfa8ffb8d7c2d8ee']],
 ['0.8.1-rc.132',['34ad8246433366cc4290f3b06f8bf0be3f5c0d29a894730c84a47291f306c491']],
 ['0.8.1-rc.131',['6a0c0517d6cc7c646f202e69beacfc9e20444d77f4bd8e80ac590af9253be8d8']],
 ['0.8.1-rc.130',['60e60fb28ee404a158c4c66881e114175e7b162890fffddfbebaae3b038d07c0']],
 ]);
export function isKnownPreviousManifest(version,digest){
 if(version===VERSION)return digest===sha256(fs.readFileSync(path.join(PACKAGE_ROOT,'MANIFEST.json')));
 return priorReleases.get(version)?.includes(digest)===true;
}
const CODE_DIRS=['src','lib','tools','tests','examples'];
export const safeRelative=p=>typeof p==='string'&&p.length>0&&!/[\\:\x00-\x1f]/.test(p)&&!p.startsWith('/')&&!p.split('/').some(x=>!x||x==='.'||x==='..');
export function verifyRecords(root,records,{skipConfig=false}={}){
 need(Array.isArray(records)&&records.length>0&&records.length<2000,'MANIFEST_INVALID','Manifest fehlt/zu gross.');
 const seen=new Set();
 for(const r of records){
  need(r&&safeRelative(r.path)&&!seen.has(r.path.toLowerCase())&&Number.isSafeInteger(r.bytes)&&r.bytes>=0&&/^[a-f0-9]{64}$/.test(r.sha256),'MANIFEST_INVALID','Manifestpfad/Hash falsch.');
  seen.add(r.path.toLowerCase());
  if(skipConfig&&r.path==='config/local-runner-queue-send.json')continue;
  const p=plainPath(path.join(root,...r.path.split('/'))),st=fs.statSync(p);
  need(st.isFile()&&st.size===r.bytes&&st.size<32*1024*1024,'PACKAGE_SIZE','Dateilaenge abweichend: '+r.path);
  need(sha256(fs.readFileSync(p))===r.sha256,'PACKAGE_HASH','Programmdatei abweichend: '+r.path);
 }
 return seen;
}
function verifyCodeTree(root,seen){
 const visited=new Set();let count=0;
 function walk(p,rel){plainPath(p);need(fs.existsSync(p),'CODE_TREE_MISSING','Programmpfad fehlt: '+rel);
  for(const n of fs.readdirSync(p).sort()){
   const f=path.join(p,n),r=rel+'/'+n,k=r.toLowerCase();
   need(++count<=10000&&safeRelative(r)&&!visited.has(k),'CODE_TREE_LIMIT','Unzulaessiger Dateipfad: '+r);
   visited.add(k);plainPath(f);const st=fs.statSync(f);
   if(st.isDirectory()){walk(f,r);continue;}
   need(st.isFile()&&seen.has(k),'UNSEALED_CODE','Nicht manifestierter Programmcode: '+r);
  }
 }
 for(const d of CODE_DIRS){
  const dir=path.join(root,d);
  if((d==='tests'||d==='examples')&&!fs.lstatSync(dir,{throwIfNoEntry:false}))continue;
  walk(dir,d);
 }
}
export function verifyPackage(root,{strictConfig=false}={}){
 plainPath(root);const m=readJSON(path.join(root,'MANIFEST.json'),2*1024*1024);
 need(m.schema==='MCR_COMPLETE_PACKAGE_V1'&&m.package==='MCR_Datenbruecke'&&m.version===VERSION,'PACKAGE_VERSION','Paketversion stimmt nicht mit der erwarteten Version '+VERSION+' ueberein.');
 need(!m.payload.some(r=>/^tests\/fixtures\/complete-0\.8\.1-rc\.\d+\.zip$/i.test(r.path||'')),'PACKAGE_RECURSION','Kein altes Komplettpaket einbetten.');
 const seen=verifyRecords(root,m.payload,{skipConfig:!strictConfig});verifyCodeTree(root,seen);resolveConfig(root);
 return {version:m.version,files:m.payload.length,manifestSha256:sha256(fs.readFileSync(path.join(root,'MANIFEST.json')))};
}
export function verifyPrevious(root){
 plainPath(root);const m=readJSON(path.join(root,'MANIFEST.json'),2*1024*1024);
 need(m.schema==='MCR_COMPLETE_PACKAGE_V1'&&m.package==='MCR_Datenbruecke','PREVIOUS_COMPLETE_VERSION','Das Manifest muss eine verifizierbare MCR-Bestandsinstallation ausweisen.');
 const digest=sha256(fs.readFileSync(path.join(root,'MANIFEST.json')));
 need(m.version===VERSION||priorReleases.has(m.version),'PREVIOUS_COMPLETE_VERSION','Version gehoert nicht zu den unterstuetzten Installationen.');
 need(isKnownPreviousManifest(m.version,digest),'PREVIOUS_MANIFEST_CHANGED','Bestandssoftware weicht vom unveraenderten Release ab.');
 const seen=verifyRecords(root,m.payload,{skipConfig:true});verifyCodeTree(root,seen);resolveConfig(root);
 return {version:m.version,files:m.payload.length,manifestSha256:digest,state:'COMPLETE_RELEASE_VERIFIED',legacyResiduals:[],authorization:'SOFTWARE_UPDATE_ONLY'};
}
export function treeDigest(root){plainPath(root);const rows=[];let count=0,total=0;
 function visit(p,rel){plainPath(p);const st=fs.statSync(p);need(++count<10000,'TREE_LIMIT','Zu viele Dateien.');
  if(st.isDirectory()){rows.push(['D',rel]);for(const n of fs.readdirSync(p).sort())visit(path.join(p,n),rel?rel+'/'+n:n);}
  else{need(st.isFile()&&st.size<32*1024*1024,'TREE_FILE','Keine normale Softwaredatei.');total+=st.size;need(total<128*1024*1024,'TREE_LIMIT','Software zu gross.');rows.push(['F',rel,st.size,sha256(fs.readFileSync(p))]);}
 }visit(root,'');return sha256(JSON.stringify(rows));}
