/** RC46: ordinary checks are read-only; only migration may stop owned PIDs. */
import path from 'node:path';import {fileURLToPath} from 'node:url';import {execFileSync} from 'node:child_process';
import {requireThat as need,McrError} from '../lib/core.mjs';
import {resolveConfig} from '../lib/config.mjs';
import {classifyWindowsProcesses,processProof,sameProcessIdentity,splitWindowsCommandLine,windowsPath} from './process-policy.mjs';
const script=name=>fileURLToPath(new URL('./'+name,import.meta.url));
const powershell=()=>path.join(process.env.SystemRoot||'C:\\Windows','System32/WindowsPowerShell/v1.0/powershell.exe');
/* RC103: No Windows process check can be skipped, but one slow/broken CIM
 * provider must not prevent a fresh, independently checked WMI snapshot.
 * A preference remembers the working provider, never the process list.
 */
let preferredSnapshotProvider='CIM';
const snapshotProviders=Object.freeze([
 {name:'CIM',file:'process-guard.ps1',timeout:18000},
 {name:'WMI',file:'process-guard-wmi.ps1',timeout:23000}
]);
function failureClass(error){
 const code=String(error?.code||'').toUpperCase();
 if(code==='ETIMEDOUT'||error?.killed===true||error?.signal==='SIGTERM')return 'TIMEOUT';
 if(code==='ENOENT')return 'POWERSHELL_NOT_FOUND';
 if(code==='EACCES'||code==='EPERM')return 'POWERSHELL_BLOCKED';
 const msg=String(error?.stderr||error?.message||'').slice(0,2048);
 if(/access is denied|zugriff verweigert|accessdenied|unauthorizedaccess/i.test(msg))return 'ACCESS_DENIED';
 if(/not recognized|nicht erkannt|commandnotfound/i.test(msg))return 'COMMAND_UNAVAILABLE';
 if(code==='ENOBUFS')return 'OUTPUT_TOO_LARGE';
 if(error?.status!==undefined&&error?.status!==null)return 'POWERSHELL_EXIT_'+String(error.status).replace(/[^0-9]/g,'').slice(0,4);
 return 'EXECUTION_FAILED';
}
function runPowerShell(name,input=null,timeout=8000,{runner=execFileSync}={}){
 let raw;
 try{raw=runner(powershell(),['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',script(name)],{
  ...(input===null?{}:{input:JSON.stringify(input)}),encoding:'utf8',timeout,windowsHide:true,maxBuffer:32*1024*1024});}
 catch(error){throw new McrError('PROCESS_CHECK_UNAVAILABLE','Prozesspruefung '+name+': '+failureClass(error));}
 try{return JSON.parse(String(raw).trim().replace(/^\uFEFF/,''));}
 catch{throw new McrError('PROCESS_CHECK_UNAVAILABLE','Prozesspruefung '+name+': JSON_INVALID');}
}
function validSnapshot(snapshot,ownPid){
 need(snapshot?.schema==='MCR_WINDOWS_PROCESS_SNAPSHOT_V1'&&snapshot.checked===true&&
  Array.isArray(snapshot.processes)&&snapshot.processes.length>0&&snapshot.processes.length<=32768,
  'PROCESS_CHECK_UNAVAILABLE','Prozessliste unvollstaendig.');
 const seen=new Set();
 for(const p of snapshot.processes){
  need(p&&Number.isSafeInteger(p.pid)&&p.pid>=0&&Number.isSafeInteger(p.parentPid)&&p.parentPid>=0&&
   typeof p.name==='string'&&p.name.length>0&&!seen.has(p.pid),
   'PROCESS_CHECK_UNAVAILABLE','Prozessliste ungueltig oder nicht eindeutig.');
  seen.add(p.pid);
 }
 need(seen.has(ownPid),'PROCESS_CHECK_UNAVAILABLE','Eigener Node-Prozess fehlt in der Prozessliste.');
 return snapshot;
}
export function readWindowsProcessSnapshot({timeout=null,runner=execFileSync,ownPid=process.pid,prefer=null}={}){
 const sequence=(prefer??preferredSnapshotProvider)==='WMI'?[snapshotProviders[1],snapshotProviders[0]]:snapshotProviders;
 const failures=[];
 for(const provider of sequence){
  try{
   const snapshot=validSnapshot(runPowerShell(provider.file,null,
    Number.isFinite(timeout)&&timeout>0?Math.min(timeout,provider.timeout):provider.timeout,{runner}),ownPid);
   if(prefer===null)preferredSnapshotProvider=provider.name;
   // Metadata is not trusted proof. Every caller still reclassifies a newly
   // retrieved complete snapshot and verifies its own PID.
   return {...snapshot,provider:provider.name};
  }catch(error){
   const detail=String(error?.message||'');
   const reason=/Eigener Node-Prozess fehlt/.test(detail)?'SELF_PID_MISSING':
    /Prozessliste unvollstaendig/.test(detail)?'LIST_INCOMPLETE':
    /Prozessliste ungueltig/.test(detail)?'LIST_INVALID':
    (/Prozesspruefung .*?: (.*)$/.exec(detail)||[])[1]||'SNAPSHOT_INVALID';
   failures.push(provider.name+':'+reason);
  }
 }
 throw new McrError('PROCESS_CHECK_UNAVAILABLE',
  'Windows-Prozesspruefung ueber CIM und WMI nicht verfuegbar ('+failures.join(', ')+
  '). Eigene Bot-Prozesse nicht verifiziert; Edge wird nicht gestartet.');
}
function optionsFor(root,{profileDirectory,excludePid=process.pid,extraProtectedPids=[]}={}){
 return {root,profileDirectory:profileDirectory??resolveConfig(root).profileDirectory,excludePid,extraProtectedPids};
}
function details(proof){return [...proof.targetProcesses,...proof.unknownProcesses].map(p=>'PID '+p.pid+' '+p.name+' ('+p.reason+')').join('; ');}
function checkIdle(proof){
 if(proof.blockedCount||proof.unknownCount)throw Object.assign(new McrError('MCR_PROCESSES_ACTIVE',
  'Zur Installation gehoerende Prozesse: '+details(proof)+'. Fuer ein Softwareupdate Menue 1 des neuen Pakets verwenden.'),{processProof:proof});
 return proof;
}
export function windowsIdle(root,{platform=process.platform,readSnapshot=readWindowsProcessSnapshot,...options}={}){
 need(platform==='win32','WINDOWS_REQUIRED','Echte Einrichtung/Echtlauf nur auf Windows.');
 const snapshot=readSnapshot();
 // Exact sealed, read-only service only; never exempt an arbitrary Node worker.
 const viewerPids=snapshot.processes.filter(p=>{const a=splitWindowsCommandLine(p.commandLine);
  return p.name.toLowerCase()==='node.exe'&&a?.length===2&&windowsPath(a[1])===windowsPath(path.win32.join(root,'tools','flow-map-server.mjs'));
 }).map(p=>p.pid);
 const proof=processProof(classifyWindowsProcesses(snapshot,optionsFor(root,{...options,extraProtectedPids:[...(options.extraProtectedPids||[]),...viewerPids]})));
 if(snapshot.provider)proof.snapshotProvider=snapshot.provider;
 return checkIdle(proof);
}
/** Caller first reserves migration priority. Every batch is classified from
 * a new complete snapshot; stale PIDs are never silently retried. */
export function windowsStopForMigration(root,{log=()=>{},platform=process.platform,readSnapshot=readWindowsProcessSnapshot,
 stopProcesses=(plan,{timeout})=>runPowerShell('process-stop.ps1',plan,timeout),...options}={}){
 need(platform==='win32','WINDOWS_REQUIRED','Automatisches Beenden fuer Migration nur auf Windows.');
 const cfg={...optionsFor(root,options),blockProtectedTargetAncestors:true},stopped=[],knownTargets=new Map();
 const deadline=Date.now()+30000;
 const remaining=limit=>{
  const available=deadline-Date.now();
  need(available>0,'MIGRATION_PROCESS_TIMEOUT','Prozessbeendigung nach 30 Sekunden ohne sicheren Leerlauf abgebrochen. Software noch nicht ersetzt.');
  return Math.min(limit,available);
 };
 const collect=()=>{
  const snapshot=readSnapshot({timeout:remaining(8000)}),classified=classifyWindowsProcesses(snapshot,cfg);
  // An exited parent does not make an identical surviving worker unrelated.
  // Keep its original ownership until that exact process instance is gone.
  for(const expected of knownTargets.values()){
   const current=snapshot.processes.find(p=>p.pid===expected.pid);
   if(!current||!sameProcessIdentity(expected,current)||classified.owned.some(p=>p.pid===current.pid))continue;
   need(!classified.protectedPids.includes(current.pid),'MIGRATION_PROCESS_PROTECTED','Ehemals zugeordneter Prozess ist jetzt Teil des Installers. Keine Beendigung.');
   classified.unknown=classified.unknown.filter(p=>p.pid!==current.pid);
   classified.owned.push({...expected,reason:'PREVIOUSLY_VERIFIED_OWNED_INSTANCE'});
   const item=classified.inspectedProcesses.find(p=>p.pid===current.pid);if(item){item.relation='OWNED';item.reason='PREVIOUSLY_VERIFIED_OWNED_INSTANCE';}
  }
  return classified;
 };
 for(let round=0;round<2;round++){
  const classified=collect(),proof=processProof(classified);
  if(proof.unknownCount)throw Object.assign(new McrError('MIGRATION_PROCESS_UNCLEAR',
   'Target-Prozess nicht sicher zuordenbar: '+proof.unknownProcesses.map(p=>'PID '+p.pid+' '+p.name+' ('+p.reason+')').join('; ')+'. Keine fremden Prozesse beendet.'),{processProof:proof});
  if(!proof.blockedCount){
   log('PASS MIGRATION_PROCESSES_IDLE: '+stopped.filter(p=>p.status==='STOPPED'||p.status==='CLOSED').length+' zugehoerige Prozesse beendet; '+proof.ignoredUnrelatedUnreadableCount+' fremde unlesbare Prozesse ohne MCR-Zuordnung ignoriert.');
   return {...proof,stoppedProcesses:stopped};
  }
  for(const p of classified.owned)log('MIGRATION_STOP_OWNED: PID '+p.pid+' '+p.name+' | '+p.reason);
  for(const p of classified.owned)knownTargets.set(p.pid+'|'+p.createdAt,p);
  const result=stopProcesses({schema:'MCR_MIGRATION_PROCESS_STOP_V1',callerPid:cfg.excludePid,
   protectedPids:classified.protectedPids,targets:classified.owned.map(({pid,parentPid,name,createdAt,executablePath,commandLine,reason})=>
    ({pid,parentPid,name,createdAt,executablePath,commandLine,reason}))},{timeout:remaining(16000)});
  need(result?.schema==='MCR_MIGRATION_PROCESS_STOP_RESULT_V1'&&Array.isArray(result.results)&&result.results.length===classified.owned.length,
   'PROCESS_STOP_UNVERIFIED','Prozessbeendigung hat keinen vollstaendigen Nachweis.');
  for(let i=0;i<result.results.length;i++){
   const r=result.results[i],expected=classified.owned[i];
   need(r?.pid===expected.pid&&['GONE','CLOSED','STOPPED','IDENTITY_CHANGED','PROTECTED','FAILED'].includes(r.status),
    'PROCESS_STOP_UNVERIFIED','Prozessbeendigung passt nicht zur geprueften Zielliste.');
   stopped.push({pid:r.pid,name:expected.name,status:r.status});
  }
  const problems=result.results.filter(r=>!['GONE','CLOSED','STOPPED'].includes(r.status));
  if(problems.length)throw new McrError('MIGRATION_PROCESS_STOP_FAILED',
   'Zugehoeriger Prozess konnte nicht sicher beendet werden: '+problems.map(r=>'PID '+r.pid+' '+r.status).join('; ')+'. Software noch nicht ersetzt.');
 }
 const proof=processProof(collect());checkIdle(proof);
 log('PASS MIGRATION_PROCESSES_IDLE: Zugehoerige Prozesse beendet und durch neue Prozessliste bestaetigt.');
 return {...proof,stoppedProcesses:stopped};
}
