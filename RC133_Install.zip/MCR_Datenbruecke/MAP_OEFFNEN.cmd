@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
call "%~dp0tools\find-node.cmd"
if not "%errorlevel%"=="0" goto failed
"%MCR_NODE%" "%~dp0tools\cli.mjs" --map
if not "%errorlevel%"=="0" goto failed
exit /b 0
:failed
echo Live-Karte konnte nicht geoeffnet werden. Keine Botaktion ausgefuehrt.
pause
exit /b 1
