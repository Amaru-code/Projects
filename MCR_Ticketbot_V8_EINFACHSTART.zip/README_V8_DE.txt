# MCR Ticketbot – gezielte V8-Demo-Speicherreparatur (21.10.2026)

## Exakter V7-Nachweis

`DEMO_SAVE_PROBE` meldete `sendClicks=1`, aber `saveClicks=0`. Die fiktive
HTML-Speicheraktion wurde beim Trusted-Mouse-Klick nicht an den synthetischen
`<a id="saveTicket">` weitergeleitet. Das ist kein Nachweis eines Fehlers
in der echten COMARCH-Speicherfunktion.

## Korrektur

Wie beim ursprünglichen erfolgreichen RC1.1-Selbsttest startet die Demo jetzt
**headless**, mit `MCR_DEMO_MULTIROW=1` und dem ursprünglichen Demo-Ticketlimit 5.
Das behebt zusätzlich die abweichende Browserlaufart von V7.

Nur die temporäre, vollstaendig isolierte **DEMO-Kopie** erhält einen direkten
Browser-DOM-Klick auf genau den bekannten fiktiven Speichern-Anker. Vorher
muss ein fiktiver Versand mehr als ein fiktives Speichern gezählt sein;
nach dem Klick muss `saveClicks` **exakt +1** sein und die Demo muss
**exakt zwei Zeilen** im Zustand übernommen haben. Andernfalls Abbruch
`DEMO_SAVE_HANDLER_UNVERIFIED`. Die originale Listenprüfung
`MY_TASKS_ALL_DESCRIPTION_CONTENT_MATCH` / `QUEUE_ALL_DESCRIPTION_CONTENT_MATCH`
bleibt aktiv.

Der REAL-Zweig von `saveTicket()` bleibt `page.mouseClick` und unverändert.
Die Baseline 0.7.4, der originale RC1.1-Runner, Identity-Code, aktive Bestände,
Browserprofile, E-Mail-Empfang und -Versand werden nicht überschrieben.

Die historische generierte Mapping-Prüfsumme `c147a9eb...76fdc40` ist eine
**getrennte** zweite Prüfung. Sie wurde im letzten V7-Demolauf noch nicht
qualifiziert (aktueller Mapping-Hash `b8f96f54...`). Die V8-Demo kann daher
auch nach 2/2 erfolgreichen Tickets an `DEMO_MULTIROW_RESULT_MISMATCH`
stoppen. Solch ein Stopp ist wichtig: **KEIN ECHTVERSAND**, bis die
Abweichung nachvollziehbar geklärt ist. Keine künstliche Freigabe.

## Start

1. `MCR_Ticketbot_V8_EINFACHSTART.zip` in einen **neuen Ordner** entpacken.
2. `START_V8_DEMO.cmd` doppelklicken. Es prüft das innere ZIP und entpackt in
   einen neuen lokalen Ordner, führt AUSSCHLIESSLICH die fiktive Demo aus.
3. Wenn das originale RC1.1-Archiv weiterhin unter Downloads liegt, ist
   keine Dateiauswahl nötig.
4. Ausgabe von `DEMO_SAVE_PROBE`, `RUN COMPLETE` und
   `HISTORIC_DEMO_MULTIROW_SHA256_MATCH` bzw. `DEMO_MULTIROW_RESULT_MISMATCH`
   mitteilen. NICHT `JETZT_REPARIEREN_UND_STARTEN.cmd` aufrufen, solange
   keine ausdrückliche reale Pilotfreigabe vorliegt.

## Grenzen

V8: lokale Syntax-, Integritaets-, Sicherheits- und Regressionstests;
keine Behauptung eines auf dem Firmen-Laptop erfolgreichen Windows-/COMARCH-Laufs.
Der isolierte Browser-Klick prueft die Testoberflaeche, nicht die echte
COMARCH-Serverpersistenz. Ein Echtticket darf erst nach eigener Freigabe,
bei beaufsichtigter Kontrolle und mit klarer Doppelversand-Sperre laufen.
