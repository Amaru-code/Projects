# MCR Datenbrücke – 0.8.1-rc.51

**RC49: zwei PDF-Anhänge bleiben erhalten; kontrollierte Wiederaufnahme ab dem in RC48 fehlgeschlagenen Ticket-Speicherklick.** Das echte RC48-Protokoll bestätigt `GEVO_VERIFIED`, `DESCRIPTION_VERIFIED` und `DRAFT_SAVE_VERIFIED`; anschließend scheiterte der vertrauenswürdige Klick auf `Ticket speichern` an `ACTION_OCCLUDED_OR_OFFSCREEN`, bevor ein Botklick erfolgte.

## Update

Dieses Komplettpaket in einen **neuen Ordner** entpacken, `START.cmd` aufrufen, **Menü 1** wählen und die bisherige Installation übernehmen. Die automatische Migrationssperre, die nachweislich zugeordneten Bot-Prozesse, SHA-256-Paketprüfung, Datenbindung, Staging, Sicherung und Rückweg bleiben verpflichtend. Menü 1 führt **nicht mehr die 480+ Unit-/Browser-Tests und vier fiktiven Szenarien** aus. Lange Tests: **Menü 6**, vier Browserdemos: **Menü 2**. Eine feste 10-Sekunden-Dauer lässt sich auf Windows mit Antivirus und Dateisperren nicht garantieren.

## Unterbrochenes Ticket 87278094

Nach dem Update: installierte `START.cmd`, Menü **9**, danach **12** und Ticket `87278094`. Die kontrollierte Wiederaufnahme ist ausschließlich zulässig, wenn beide PDFs und die korrekte WWID/Person geprüft sind, **kein früherer Ticket-Speicherklick** (siehe RC48-Log) und keine Weiterleitung erfolgt ist und die Beschreibung/GEVO weiterhin passen. Dann `SAVE_OHNE_KLICK_GEPRUEFT` eingeben. Der Bot führt keinen erneuten Upload und keinen neuen Entwurf-Speicherklick aus; er versucht die Ticket-Speicherung **einmalig**. Bei weiterhin verdeckter Schaltfläche ist ein einzelner **physischer** Klick im Bot-Edge erforderlich. Erst nach Prüfung des gespeicherten Tickettexts und von GEVO/Anlagen folgt die separate Prüferfreigabe für `mark.baindl`. Keine E-Mail.

Bei unklarer Anlage oder einem bereits ausgeführten Speicherklick **nicht** bestätigen: Das Journal bleibt erhalten und der Bot führt keine Wiederholung aus. Die Pakettests ersetzen keine Live-Bestätigung im COMARCH.

Details: [RC49 – Speichern/Wiederanlauf/Schnellinstallation](docs/RC49_SPEICHERN_WIEDERAUFNAHME_SCHNELLINSTALLATION.md).

Ältere Änderungen: Dokumente `docs/RC40_...` bis `docs/RC48_...`.
