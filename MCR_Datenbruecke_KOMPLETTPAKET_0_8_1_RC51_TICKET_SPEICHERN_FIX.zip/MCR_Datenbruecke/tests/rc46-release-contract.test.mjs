import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';
import {ROOT} from './helpers.mjs';
import {sha256} from '../lib/core.mjs';
import {VERSION} from '../lib/control.mjs';
import {verifyPackage} from '../tools/integrity.mjs';

test('RC46 accepts both original RC44 and RC45 as pinned update sources',()=>{
 assert.equal(VERSION,'0.8.1-rc.51');
 assert.equal(JSON.parse(fs.readFileSync(path.join(ROOT,'package.json'))).version,VERSION);
 const code=fs.readFileSync(path.join(ROOT,'tools/integrity.mjs'),'utf8');
 for(const [release,digest,count] of [
  ['44','31d1f1c31f209cedce3cbd51faea6324d5ef9bfd08b9e051fb5b8b668348dec8',293],
  ['45','3c9228da2770c9ff6be90160e25cc3ba3cf1092628b449b16fb686df143bb444',302]
 ]){
  const bytes=fs.readFileSync(path.join(ROOT,`tools/reference/complete-0.8.1-rc.${release}-manifest.json`));
  assert.equal(sha256(bytes),digest);
  const old=JSON.parse(bytes);assert.equal(old.version,'0.8.1-rc.'+release);assert.equal(old.payload.length,count);
  assert(code.includes("m.version==='0.8.1-rc."+release+"'"));assert(code.includes(digest));
 }
 assert.equal(verifyPackage(ROOT).version,VERSION);
});

test('RC46 package includes migration and attachment regressions without runtime data or recursive release ZIPs',()=>{
 const manifest=JSON.parse(fs.readFileSync(path.join(ROOT,'MANIFEST.json')));
 assert.equal(manifest.version,VERSION);
 assert(manifest.payload.every(x=>! /^(?:private_data|\.runtime|diagnostics|Ergebnis|reports)\//i.test(x.path)));
 assert(manifest.payload.every(x=>! /(?:^|\/)complete-0\.8\.1-rc\.\d+\.zip$/i.test(x.path)));
 for(const file of ['tests/rc45-filepond-browser.test.mjs','tests/rc45-filepond-model.test.mjs',
  'tests/rc45-upload-recovery.test.mjs','tests/rc46-process-guard.test.mjs',
  'tests/rc46-release-contract.test.mjs','tests/rc46-upgrade.test.mjs',
  'tests/rc46-migration-priority.test.mjs','tests/rc46-migration-recovery.test.mjs',
  'lib/migration-priority.mjs','tools/process-policy.mjs','tools/process-stop.ps1']){
  assert(manifest.payload.some(x=>x.path===file),'Required regression absent: '+file);
 }
});
