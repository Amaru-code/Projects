using Mcr.Ipp.Core;
using System.Text;
using System.Text.Json;
using System.Xml.Linq;
using System.Security.Cryptography;

string root = args.Length > 0 ? Path.GetFullPath(args[0]) : Directory.GetCurrentDirectory();
var results = new List<(string Name, string? Error)>();
int vectorComparisons = 0;
void Check(bool condition, string message) { if (!condition) throw new Exception(message); }
void Equal(double? actual, double? expected) => Check(actual == expected, $"Erwartet {expected}, erhalten {actual}");
void Throws(string code, Action action) { try { action(); } catch (IppException e) { Check(e.Code==code,$"Erwartet {code}, erhalten {e.Code}: {e.Message}"); return; } throw new Exception("Erwarteter Fehler fehlt: "+code); }
void Test(string name, Action action) { try { action(); results.Add((name,null)); Console.WriteLine("PASS " + name); } catch(Exception e) { results.Add((name,e.ToString())); Console.WriteLine("FAIL " + name + ": " + e.Message); } }
Dictionary<string,object?> BaseRow() => new() { ["ClientID"]="1001", ["Surname"]="Demo", ["FirstName"]="Test", ["BirthDate"]="01.01.1980", ["BaseSalary_1"]=8000d, ["PartTimeFactor_1"]=100d, ["DAT_AD2"]=null, ["TerminationDate"]=null };
InputTable Base(Dictionary<string,object?>? row=null) { row ??= BaseRow(); return new("Tabelle1",row.Keys.ToList(),new(){row},false); }
Dictionary<string,string?> Row(string? tariff="10", string? attc="8000",string? tzg="100",string? claim="AKTAN",string? term=null,string type="ATTC_BAV",string id="1001") => new() { ["KDMA_IDENT"]=id,["Tarifklasse"]=tariff,["BETRAG1"]=attc,["ARBZEIT_PROZ"]=tzg,["ANSPRUCHSTYP"]=claim,["DAT_AUSTRITT"]=term,["BETRAG1_TYP"]=type };
MonthFile Month(int month, params Dictionary<string,string?>[] rows) => new($"Change_{month:D2}2026.txt",new(2026,month,1),rows.ToList(),"Tarifklasse",new("synthetic",new string('0',64),0));
ContributionResult Run(InputTable? baseline, params MonthFile[] months) => new ContributionEngine().Run(baseline ?? Base(),months,new());

Test("T01_intervals_are_contiguous",()=> { for(int i=0;i<ContributionFormula.Periods.Count;i++) { var p=ContributionFormula.Periods[i]; Check(p.Eckwert1>0&&p.Eckwert2>p.Eckwert1,"Eckwerte"); if(i>0)Check(ContributionFormula.Periods[i-1].To!.Value.AddDays(1)==p.From,"Intervalluebergang"); } });
Test("T02_reference_known_rounding",()=> { Equal(PythonRound.Round(2.675,2),2.67); Equal(PythonRound.Round(-2.675,2),-2.67); Equal(PythonRound.Round(.125,2),.12); });
Test("T03_all_python_rounding_vectors",()=> { using var j=JsonDocument.Parse(File.ReadAllText(Path.Combine(root,"tests","golden_vectors.json"))); foreach(var v in j.RootElement.GetProperty("rounding").EnumerateArray()) { Equal(PythonRound.Round(v.GetProperty("value").GetDouble(),v.GetProperty("digits").GetInt32()),v.GetProperty("expected").GetDouble()); vectorComparisons++; } });
Test("T04_all_python_formula_vectors",()=> { using var j=JsonDocument.Parse(File.ReadAllText(Path.Combine(root,"tests","golden_vectors.json"))); double? N(JsonElement e)=>e.ValueKind==JsonValueKind.Null?null:e.GetDouble(); foreach(var v in j.RootElement.GetProperty("contributions").EnumerateArray()) { Equal(ContributionFormula.Calculate(N(v.GetProperty("attc")),N(v.GetProperty("tzg")),DateOnly.Parse(v.GetProperty("date").GetString()!,Parse.Inv)),N(v.GetProperty("expected"))); vectorComparisons++; } });
Test("T05_normal_month",()=> { var r=Run(null,Month(1,Row())); Equal(r.Persons[0].Months[1].Attc,8000); Equal(r.Persons[0].Months[1].Tzg,100); Check(r.Persons[0].Months[1].Amount>0,"Beitrag fehlt"); });
Test("T06_january_fallback",()=> { var r=Run(null,Month(1,Row(attc:null,tzg:null))); Equal(r.Persons[0].Months[1].Attc,8000); Equal(r.Persons[0].Months[1].Tzg,100); });
Test("T07_previous_month_fallback",()=> { var r=Run(null,Month(1,Row(attc:"9000",tzg:"80")),Month(2,Row(attc:null,tzg:null))); Equal(r.Persons[0].Months[2].Attc,9000); Equal(r.Persons[0].Months[2].Tzg,80); });
Test("T08_tariff_99_only_current_month",()=> { var r=Run(null,Month(1,Row(tariff:"99")),Month(2,Row(tariff:"10"))); Equal(r.Persons[0].Months[1].Amount,null); Equal(r.Persons[0].Months[2].Attc,8000); Check(r.Persons[0].TariffOld==99&&r.Persons[0].TariffNew==10,"Tarifhistorie"); });
Test("T09_tariff_98_only_current_month",()=> { var r=Run(null,Month(1,Row(tariff:"10")),Month(2,Row(tariff:"98")),Month(3,Row(tariff:"10"))); Check(r.Persons[0].Months[1].Amount>0&&r.Persons[0].Months[3].Amount>0,"Monatssperre"); Equal(r.Persons[0].Months[2].Amount,null); });
Test("T10_no_restore_of_blocked_attc_without_new_value",()=> { var p=Run(null,Month(1,Row(tariff:"99")),Month(2,Row(tariff:"10",attc:null))).Persons[0]; Equal(p.Months[2].Attc,null); });
Test("T11_latest_change_can_return_to_original_tariff",()=> { var p=Run(null,Month(1,Row(tariff:"10")),Month(2,Row(tariff:"20")),Month(3,Row(tariff:"10"))).Persons[0]; Check(p.TariffOld==10&&p.TariffNew==10&&p.TariffChangeDate==new DateOnly(2026,3,1),"Rueckwechsel"); });
Test("T12_missing_monthly_tariff_carried_forward",()=> { var p=Run(null,Month(1,Row(tariff:"99")),Month(2,Row(tariff:null))).Persons[0]; Equal(p.Months[2].EffectiveTariff,99); Equal(p.Months[2].Attc,null); });
Test("T13_unknown_initial_tariff_blocks",()=>Throws("TARIFF_UNKNOWN",()=>Run(null,Month(1,Row(tariff:null)))));
Test("T14_unknown_tariff_opt_in_is_visible",()=> { var r=new ContributionEngine().Run(Base(),new[]{Month(1,Row(tariff:null))},new(){AllowMissingTariff=true}); Check(r.Warnings.Any(w=>w.Code=="UNKNOWN_TARIFF_ALLOWED"),"Warnung fehlt"); });
Test("T15_new_person_blocks",()=>Throws("TXT_PERSON_MISSING",()=>Run(null,Month(1,Row(id:"9999")))));
Test("T16_unknown_person_ignore_matches_left_join",()=> { var r=new ContributionEngine().Run(Base(),new[]{Month(1,Row(),Row(id:"9999"))},new(){AllowUnknownTxtPersons=true}); Check(r.Persons.Count==1&&r.Warnings.Any(w=>w.Code=="TXT_PERSON_IGNORED"),"Left join"); });
Test("T17_duplicate_baseline_blocks",()=> { var b=Base(); b.Rows.Add(BaseRow()); Throws("DUPLICATE_BASELINE_ID",()=>Run(b,Month(1,Row()))); });
Test("T18_duplicate_normalized_ids_block",()=> { var b=Base(); var r=BaseRow();r["ClientID"]="001001";b.Rows.Add(r); Throws("DUPLICATE_BASELINE_ID",()=>Run(b,Month(1,Row()))); });
Test("T19_baseline_alphanumeric_ids_block",()=> { var b=BaseRow();b["ClientID"]="1001 W";Throws("ID_UNSUPPORTED",()=>Run(Base(b),Month(1,Row()))); });
Test("T20_akta_filter_then_fallback",()=> { var p=Run(null,Month(1,Row(attc:"9999",claim:"AUGUAN"))).Persons[0]; Equal(p.Months[1].Attc,8000); });
Test("T21_last_matching_salary_row",()=> { var p=Run(null,Month(1,Row(attc:"8500"),Row(attc:"100",tzg:"80",type:"OTHER"))).Persons[0]; Equal(p.Months[1].Attc,8500); Equal(p.Months[1].Tzg,80); });
Test("T22_last_row_salary_wins",()=>Equal(Run(null,Month(1,Row(attc:"8500"),Row(attc:"9000"))).Persons[0].Months[1].Attc,9000));
Test("T23_factor_to_percent",()=>Equal(Run(null,Month(1,Row(tzg:"0,5"))).Persons[0].Months[1].Tzg,50));
Test("T24_one_means_full_time_in_raw_txt",()=>Equal(Run(null,Month(1,Row(tzg:"1"))).Persons[0].Months[1].Tzg,100));
Test("T25_one_percent_legacy_ambiguity_reported",()=>Check(Run(null,Month(1,Row(tzg:"0.01"))).Warnings.Any(w=>w.Code=="TZG_ONE_AMBIGUOUS"),"Warnung fehlt"));
Test("T26_zero_tzg_empty_amount",()=>Equal(Run(null,Month(1,Row(tzg:"0"))).Persons[0].Months[1].Amount,null));
Test("T27_negative_salary_blocks",()=>Throws("ATTC_NEGATIVE",()=>Run(null,Month(1,Row(attc:"-1")))));
Test("T28_negative_tzg_blocks",()=>Throws("TZG_RANGE",()=>Run(null,Month(1,Row(tzg:"-1")))));
Test("T29_entry_month_allowed_not_prorated",()=> { var b=BaseRow();b["DAT_AD2"]="15.02.2026";var p=Run(Base(b),Month(1,Row()),Month(2,Row())).Persons[0]; Equal(p.Months[1].Attc,null); Check(p.Months[2].Amount>0,"Eintrittsmonat"); });
Test("T30_entry_after_all_selected_months",()=> { var b=BaseRow();b["DAT_AD2"]="01.04.2026";var p=Run(Base(b),Month(1,Row()),Month(2,Row())).Persons[0]; Check(p.Months.Values.All(m=>m.Attc is null&&m.Tzg is null&&m.Amount is null),"Vor Eintritt"); });
Test("T31_no_entry_substitution",()=> { var b=BaseRow();b.Remove("DAT_AD2");b["JoiningDate"]="15.02.2026";var r=Run(Base(b),Month(1,Row())); Check(r.Persons[0].Months[1].Amount>0&&r.Warnings.Any(w=>w.Code=="ENTRY_DATE_ABSENT"),"DAT_AD2 ersetzt"); });
Test("T32_auguan_exit_after_month_cleared",()=> { var p=Run(null,Month(1,Row()),Month(2,Row(claim:"AUGUAN",term:"15.01.2026"))).Persons[0]; Check(p.Months[1].Amount>0,"Austrittsmonat"); Equal(p.Months[2].Amount,null); });
Test("T33_aktan_does_not_cut_exit",()=> { var p=Run(null,Month(1,Row()),Month(2,Row(term:"15.01.2026"))).Persons[0]; Check(p.Months[2].Amount>0,"Unzulassiger Cutoff"); });
Test("T34_blank_termination_not_a_deletion",()=> { var p=Run(null,Month(1,Row(term:"15.01.2026")),Month(2,Row(term:null))).Persons[0]; Check(p.TerminationDate==new DateOnly(2026,1,15),"Termination overwritten"); });
Test("T35_reordered_files_same_results",()=> { var a=Run(null,Month(2,Row()),Month(1,Row())); var b=Run(null,Month(1,Row()),Month(2,Row())); Check(JsonSerializer.Serialize(a,JsonFiles.Options)==JsonSerializer.Serialize(b,JsonFiles.Options),"Order parity"); });
Test("T36_duplicate_months_block",()=>Throws("DUPLICATE_MONTH",()=>Run(null,Month(1,Row()),Month(1,Row()))));
Test("T37_mixed_years_block",()=> { var m=Month(2,Row()) with { Month=new DateOnly(2027,2,1) };Throws("MULTI_YEAR",()=>Run(null,Month(1,Row()),m)); });
Test("T38_empty_selection_blocks",()=>Throws("TXT_SELECTION_EMPTY",()=>Run(null)));
Test("T39_month_filename",()=>Check(MonthReader.ExtractMonth("change_042026.txt")==new DateOnly(2026,4,1),"Month parse"));
Test("T40_bad_month_filename",()=>Throws("MONTH_FILENAME",()=>MonthReader.ExtractMonth("data.txt")));
Test("T41_bad_month_number",()=>Throws("MONTH_INVALID",()=>MonthReader.ExtractMonth("data_132026.txt")));
Test("T42_parse_german_date",()=>Check(Parse.Date("29.02.2024","date")==new DateOnly(2024,2,29),"Datum"));
Test("T43_bad_date_rejected",()=>Throws("INVALID_DATE",()=>Parse.Date("31.02.2026","date")));
Test("T44_excel_date_serial",()=>Check(Parse.Date(45808d,"date")==new DateOnly(2025,5,31),"Excelserial"));
Test("T45_decimal_comma",()=>Equal(Parse.Number("8116,67","x"),8116.67));
Test("T46_thousands_separator_rejected",()=>Throws("INVALID_NUMBER",()=>Parse.Number("8.116,67","x")));
Test("T47_id_leading_zero_reference_normalization",()=>Check(Parse.Id("001001")=="1001","ID"));
Test("T48_csv_semicolon_and_quoting",()=> { var text="KDMA_IDENT;ARBZEIT_PROZ;BETRAG1;BETRAG1_TYP;ANSPRUCHSTYP;Tarifklasse\n1001;100;8000;ATTC_BAV;AKTAN;10\n";var b=new SourceBlob(Encoding.UTF8.GetBytes(text),new("change_012026.txt",new string('0',64),0));Check(MonthReader.Read(b,new(){TextEncoding="utf-8"}).Rows.Count==1,"CSV"); });
Test("T49_missing_claim_column_blocks",()=> { var b=new SourceBlob(Encoding.UTF8.GetBytes("KDMA_IDENT;ARBZEIT_PROZ;BETRAG1;BETRAG1_TYP;Tarifklasse\n1001;100;8000;ATTC_BAV;10"),new("change_012026.txt",new string('0',64),0));Throws("TXT_SCHEMA",()=>MonthReader.Read(b,new())); });
Test("T50_output_id_is_text_formula_injection_safe",()=> { var r=Run(null,Month(1,Row()));r.Persons[0].Master["Surname"]="=HYPERLINK(\"https://invalid\")";var doc=SpreadsheetWriter.SheetXml(SpreadsheetWriter.Contributions(r));Check(!doc.Descendants(SpreadsheetReader.Main+"f").Any(),"Formula injection"); });
Test("T51_result_roundtrip",()=> { string file=Path.Combine(Path.GetTempPath(),Guid.NewGuid()+".xlsx");try { var r=Run(null,Month(1,Row()));SpreadsheetWriter.Write(file,SpreadsheetWriter.Contributions(r));using var reader=new SpreadsheetReader(File.ReadAllBytes(file));Check(reader.Sheets.Single().Name=="Ergebnis","Sheet");Check(reader.Cells(reader.Sheets[0]).Any(c=>c.Address=="A2"&&Convert.ToString(c.Value)=="1001"),"ID roundtrip"); } finally { File.Delete(file); } });
Test("T52_source_missing_rejected",()=>Throws("INPUT_MISSING",()=>SourceBlob.Read(Path.Combine(Path.GetTempPath(),Guid.NewGuid()+".xlsx"))));
Test("T53_template_unknown_cannot_be_staged",()=> { string file=Path.Combine(Path.GetTempPath(),Guid.NewGuid()+".xlsx");try {SpreadsheetWriter.Write(file,new OutputSheet("Tabelle1",new(){"ClientID"},new(){new(){"1001"}}));var b=SourceBlob.Read(file);Check(!TemplatePreparation.Inspect(b).MatchesKnownIppTemplate,"Identity");Throws("IPP_TEMPLATE_IDENTITY",()=>TemplatePreparation.CreateStagingCopy(b,Run(null,Month(1,Row())),file+".xlsm"));}finally{File.Delete(file);} });
Test("T54_raw_monthly_result_not_accepted_as_baseline",()=> {var b=Base();b.Columns.Add("ATTC_1");Throws("BASELINE_NOT_PRISTINE",()=>Run(b,Month(1,Row())));});
Test("T55_full_demo_pipeline_and_no_pdf_claim",()=>
{
    string output=Path.Combine(Path.GetTempPath(),"MCR_IPP_TEST_"+Guid.NewGuid());
    string baseline=Path.Combine(root,"examples","Bestand_Synthetisch.xlsx");
    var hash=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(baseline)));
    try
    {
        var result=new Pipeline().Execute(new RunRequest { BaselinePath=baseline,TxtPaths=Directory.GetFiles(Path.Combine(root,"examples","Monatsdaten"),"*.txt").ToList(),OutputDirectory=output });
        Check(result.Persons==12&&result.Months==6,"Demoumfang");Check(File.Exists(Path.Combine(result.Directory,"Ergebnis.xlsx")),"Output");Check(result.PdfStatus=="NOT_AUTHORIZED","False readiness");
        Check(hash==Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(baseline))),"Input changed");
    }
    finally { if(Directory.Exists(output))Directory.Delete(output,true); }
});
Test("T56_cancellation_prevents_successful_publish",()=> { using var c=new CancellationTokenSource();c.Cancel();try{new ContributionEngine().Run(Base(),new[]{Month(1,Row())},new(),cancel:c.Token);}catch(OperationCanceledException){return;}throw new Exception("Cancellation ignored");});


// V0.2: nonblocking person reconciliation is an orchestration layer; T15/T16 still test strict legacy core modes.
Dictionary<string,string?> Named(string id="9999",string surname="Neumann",string first="Nora",string birth="02.02.1990",string? entry=null)
{
    var r=Row(id:id);r["Surname"]=surname;r["FirstName"]=first;r["BirthDate"]=birth;r["DAT_AD2"]=entry;return r;
}
SourceInfo BSource(string hash="A") => new("synthetic.xlsx",new string(hash[0],64),100);
PreparedPersons PrepareTest(IReadOnlyList<MonthFile> months,IReadOnlyList<NewPersonDecision>? decisions=null,InputTable? b=null) => PersonReview.Prepare(b??Base(),BSource(),months,decisions);
NewPersonDecision Approve(PreparedPersons p,string id="9999",string entry="01.02.2026")
{
    var c=p.Report.Cases.Single(c=>c.ClientId==id);
    return new(){ContextSha256=p.Report.ContextSha256,CaseId=c.CaseId,ClientId=id,Surname=c.Surname??"Neumann",FirstName=c.FirstName??"Nora",BirthDate=c.BirthDate??new DateOnly(1990,2,2),DatAd2=Parse.Date(entry,"DAT_AD2")!.Value,Reviewer="synthetic-test",Evidence="synthetic HR fixture - no real person",ConfirmedUtc=new DateTimeOffset(2026,9,29,0,0,0,TimeSpan.Zero),IdentityAndNewEntryVerified=true};
}
Test("T57_unknown_collected_and_known_continue",()=> {var m=new[]{Month(1,Row(),Named())};var p=PrepareTest(m);Check(p.Report.OpenCases==1&&p.Report.Cases[0].DisplayName=="Nora Neumann","Case missing");Check(p.Months[0].Rows.Count==1,"Unknown not isolated");var r=new ContributionEngine().Run(p.Baseline,p.Months,new());Check(r.Persons.Count==1&&r.Persons[0].Months[1].Amount>0,"Known did not continue");});
Test("T58_all_months_same_unknown_one_case",()=> {var p=PrepareTest(new[]{Month(2,Row(),Named()),Month(1,Named(),Row(),Named())});Check(p.Report.Cases.Count==1&&p.Report.Cases[0].Occurrences.Count==3,"Dedup lost findings");Check(p.Report.Cases[0].Occurrences[0].Month=="2026-01","Chronology");});
Test("T59_missing_name_never_invented",()=> {var p=PrepareTest(new[]{Month(1,Row(),Row(id:"9999"))});Check(p.Report.Cases.Single().DisplayName=="NAME_NICHT_GELIEFERT","Name invented");});
Test("T60_found_record_and_raw_id_preserved",()=> {var p=PrepareTest(new[]{Month(1,Row(),Named(id:"009999"))});var o=p.Report.Cases.Single().Occurrences.Single();Check(o.DataRecord==2&&o.OriginalId=="009999"&&p.Report.Cases[0].ClientId=="9999","Provenance");});
Test("T61_invalid_id_is_case_not_whole_run_failure",()=> {var p=PrepareTest(new[]{Month(1,Row(),Named(id:"1001 W"))});Check(p.Report.Cases[0].Classification=="KENNUNG_UNGUELTIG"&&p.Months[0].Rows.Count==1,"Unsupported ID ignored or normalized");});
Test("T62_empty_ids_not_merged_as_one_person",()=> {var p=PrepareTest(new[]{Month(1,Row(),Named(id:""),Named(id:""))});Check(p.Report.Cases.Count==2,"Empty IDs merged");});
Test("T63_same_name_other_id_flagged_not_merged",()=> {var p=PrepareTest(new[]{Month(1,Row(),Named(surname:"Demo",first:"Test",birth:"01.01.1980"))});Check(p.Report.Cases[0].Classification=="MOEGLICHER_BESTANDSTREFFER_ANDERE_ID"&&p.Report.Cases[0].PossibleBaselineIds.Single()=="1001","Match hint");});
Test("T64_identity_conflict_remains_open",()=> {var p=PrepareTest(new[]{Month(1,Row(),Named()),Month(2,Row(),Named(first:"Andere"))});Check(p.Report.Cases[0].Classification=="IDENTITAETSDATEN_KONFLIKT","Conflict lost");});
Test("T65_entry_hint_is_not_approval",()=> {var p=PrepareTest(new[]{Month(1,Row()),Month(2,Row(),Named(entry:"01.02.2026"))});Check(p.Report.Cases[0].Classification=="NEUEINTRITT_KANDIDAT"&&p.Report.AddedPersons==0&&p.Report.OpenCases==1,"False auto approval");});
Test("T66_confirmed_entry_added_and_before_entry_blank",()=> {var m=new[]{Month(1,Row()),Month(2,Row(),Named(entry:"15.02.2026"))};var p=PrepareTest(m);var q=PrepareTest(m,new[]{Approve(p,entry:"15.02.2026")});Check(q.Report.AddedPersons==1&&q.Report.OpenCases==0,"Not admitted: "+q.Report.Cases[0].Note);var r=new ContributionEngine().Run(q.Baseline,q.Months,new());var n=r.Persons.Single(p=>p.ClientId=="9999");Check(n.Months[1].Amount is null&&n.Months[2].Amount>0,"Entry timing");});
Test("T67_stale_context_approval_not_applied",()=> {var m=new[]{Month(1,Row()),Month(2,Row(),Named())};var p=PrepareTest(m);var d=Approve(p);d.ContextSha256=new string('B',64);var q=PrepareTest(m,new[]{d});Check(q.Report.OpenCases==1&&q.Report.AddedPersons==0&&q.Report.Notices.Count>0,"Stale approval accepted");});
Test("T68_no_explicit_confirmation_no_admission",()=> {var m=new[]{Month(1,Row()),Month(2,Row(),Named())};var p=PrepareTest(m);var d=Approve(p);d.IdentityAndNewEntryVerified=false;var q=PrepareTest(m,new[]{d});Check(q.Report.AddedPersons==0&&q.Report.Cases[0].Resolution=="FREIGABE_NICHT_ANWENDBAR","Unconfirmed accepted");});
Test("T69_missing_payroll_blocks_only_new_admission",()=> {var row=Named();row["BETRAG1"]=null;var m=new[]{Month(1,Row()),Month(2,Row(),row)};var p=PrepareTest(m);var q=PrepareTest(m,new[]{Approve(p)});Check(q.Report.AddedPersons==0&&q.Months[1].Rows.Count==1,"Incomplete new salary admitted");});
Test("T70_duplicate_decisions_visible_no_admission",()=> {var m=new[]{Month(1,Row()),Month(2,Row(),Named())};var p=PrepareTest(m);var d=Approve(p);var q=PrepareTest(m,new[]{d,d});Check(q.Report.AddedPersons==0&&q.Report.Cases[0].Note.Contains("DECISION_CONFLICT"),"Duplicate decisions accepted");});
Test("T71_confirmation_conflicting_txt_rejected",()=> {var m=new[]{Month(1,Row()),Month(2,Row(),Named())};var p=PrepareTest(m);var d=Approve(p);d.Surname="Anders";var q=PrepareTest(m,new[]{d});Check(q.Report.AddedPersons==0&&q.Report.Cases[0].Note.Contains("MASTER_CONFLICT"),"Mismatch admitted");});
Test("T72_missing_evidence_not_admitted",()=> {var m=new[]{Month(1,Row()),Month(2,Row(),Named())};var p=PrepareTest(m);var d=Approve(p);d.Evidence="";Check(PrepareTest(m,new[]{d}).Report.AddedPersons==0,"Missing evidence");});
Test("T73_two_new_same_name_not_both_added",()=> {var m=new[]{Month(1,Row()),Month(2,Row(),Named(),Named(id:"9998"))};var p=PrepareTest(m);var q=PrepareTest(m,new[]{Approve(p),Approve(p,id:"9998")});Check(q.Report.AddedPersons==0&&q.Report.OpenCases==2&&q.Baseline.Rows.Count==1,"Double new person");});
Test("T74_baseline_not_mutated_by_new_admission",()=> {var b=Base();var m=new[]{Month(1,Row()),Month(2,Row(),Named())};var p=PrepareTest(m,b:b);var q=PrepareTest(m,new[]{Approve(p)},b);Check(b.Rows.Count==1&&q.Baseline.Rows.Count==2,"Baseline mutation");});
Test("T75_old_entry_not_invented_as_current_new",()=> {var m=new[]{Month(1,Row(),Named(entry:"01.01.2010"))};var p=PrepareTest(m);Check(p.Report.Cases[0].Classification=="UNBEKANNT_NEUEINTRITT_NICHT_BELEGT","Old becomes new");var d=Approve(p,entry:"01.01.2010");Check(PrepareTest(m,new[]{d}).Report.AddedPersons==0,"Old admitted");});
Test("T76_joining_date_not_used_as_dat_ad2",()=> {var row=Named();row["JoiningDate"]="01.01.2026";var p=PrepareTest(new[]{Month(1,Row(),row)});Check(p.Report.Cases[0].DatAd2 is null&&p.Report.Cases[0].Classification=="UNBEKANNT_NEUEINTRITT_NICHT_BELEGT","Date substitution");});
Test("T77_id_normalized_known_not_new",()=> {var p=PrepareTest(new[]{Month(1,Row(id:"001001"))});Check(p.Report.Cases.Count==0&&p.Months[0].Rows.Count==1,"Known normalization");});
Test("T78_header_inventory_available_without_identity_values",()=> {var row=Row(id:"9999");row["PAYROLL_CUSTOM_NAME"]="Test";var p=PrepareTest(new[]{Month(1,Row(),row)});Check(p.Report.TxtHeaders.Values.Single().Contains("PAYROLL_CUSTOM_NAME")&&p.Report.Cases[0].DisplayName=="NAME_NICHT_GELIEFERT","Header inventory");});
Test("T79_review_workbook_injection_safe",()=> {var p=PrepareTest(new[]{Month(1,Row(),Named(surname:"=HYPERLINK(1)"))});string dir=Path.Combine(Path.GetTempPath(),"IPP_review_"+Guid.NewGuid());Directory.CreateDirectory(dir);try {PersonReview.Write(dir,p.Report);using var r=new SpreadsheetReader(File.ReadAllBytes(Path.Combine(dir,"Prueffaelle.xlsx")));Check(r.Sheets.All(s=>!r.Cells(s).Any(c=>c.Formula is not null)),"Formula injected");Check(r.Sheets.Count==2,"Review sheets");}finally{Directory.Delete(dir,true);}});
Test("T80_context_order_independent",()=> {var a=Month(1,Row(),Named());var b=Month(2,Row(),Named());var p=PrepareTest(new[]{a,b});var q=PrepareTest(new[]{b,a});Check(p.Report.ContextSha256==q.Report.ContextSha256&&p.Report.Cases[0].CaseId==q.Report.Cases[0].CaseId,"Context input order");});
Test("T81_baseline_hash_change_requires_reconfirmation",()=> {var m=new[]{Month(1,Row()),Month(2,Row(),Named())};var p=PrepareTest(m);var q=PersonReview.Prepare(Base(),BSource("C"),m,new[]{Approve(p)});Check(q.Report.OpenCases==1&&q.Report.AddedPersons==0,"Baseline hash not bound");});
Test("T82_month_hash_change_requires_reconfirmation",()=> {var m=new[]{Month(1,Row()),Month(2,Row(),Named())};var p=PrepareTest(m);var changed=new[]{m[0],m[1] with {Source=new("synthetic",new string('C',64),0)}};Check(PrepareTest(changed,new[]{Approve(p)}).Report.AddedPersons==0,"TXT hash not bound");});
Test("T83_earlier_observation_requires_manual_review",()=> {var m=new[]{Month(1,Row(),Named()),Month(2,Row(),Named())};var p=PrepareTest(m);var q=PrepareTest(m,new[]{Approve(p)});Check(q.Report.Cases[0].Note.Contains("EARLIER_OBSERVATION")&&q.Report.AddedPersons==0,"Earlier occurrence ignored");});
Test("T84_invalid_tariff_new_candidate_does_not_stop_known",()=> {var row=Named();row["Tarifklasse"]="invalid";var m=new[]{Month(1,Row()),Month(2,Row(),row)};var p=PrepareTest(m);var q=PrepareTest(m,new[]{Approve(p)});Check(q.Report.OpenCases==1&&q.Report.AddedPersons==0,"Bad tariff new admission");Check(new ContributionEngine().Run(q.Baseline,q.Months,new()).Persons.Count==1,"Known failed");});
Test("T85_review_cancellation_respected",()=> {using var c=new CancellationTokenSource();c.Cancel();try{PersonReview.Prepare(Base(),BSource(),new[]{Month(1,Row())},cancel:c.Token);}catch(OperationCanceledException){return;}throw new Exception("Cancellation ignored");});
Test("T86_empty_result_never_means_all_persons_processed",()=> {var m=new[]{Month(1,Named())};var p=PrepareTest(m);Check(p.Report.OpenCases==1&&p.Baseline.Rows.Count==1,"Review lost absent base");});
Test("T87_same_names_in_confirmation_checked_even_if_txt_names_absent",()=> {var m=new[]{Month(1,Row()),Month(2,Row(),Row(id:"9999"))};var p=PrepareTest(m);var d=Approve(p);d.Surname="Demo";d.FirstName="Test";Check(PrepareTest(m,new[]{d}).Report.AddedPersons==0,"Manual duplicate creation");});
Test("T88_full_pipeline_partial_status_and_persistent_cases",()=>
{
    string dir=Path.Combine(Path.GetTempPath(),"IPP_partial_"+Guid.NewGuid());Directory.CreateDirectory(dir);
    try
    {
        string b=Path.Combine(dir,"base.xlsx"),t=Path.Combine(dir,"change_012026.txt");
        var br=BaseRow();SpreadsheetWriter.Write(b,new OutputSheet("Bestand",br.Keys.ToList(),new(){br.Values.ToList()}));
        File.WriteAllText(t,"KDMA_IDENT;ARBZEIT_PROZ;BETRAG1;BETRAG1_TYP;ANSPRUCHSTYP;Tarifklasse;Surname;FirstName;BirthDate\n1001;100;8000;ATTC_BAV;AKTAN;10;Demo;Test;01.01.1980\n9999;100;8000;ATTC_BAV;AKTAN;10;Neumann;Nora;02.02.1990\n",Encoding.UTF8);
        var outcome=new Pipeline().Execute(new RunRequest{BaselinePath=b,TxtPaths=new(){t},OutputDirectory=Path.Combine(dir,"out")});
        Check(outcome.Persons==1&&outcome.OpenPersonCases==1&&outcome.ContributionStatus=="PARTIAL_PERSON_REVIEW_REQUIRED","False completion");
        Check(File.Exists(Path.Combine(outcome.Directory,"Prueffaelle.xlsx"))&&File.Exists(Path.Combine(outcome.Directory,"Ergebnis.xlsx")),"Published files missing");
        Check(outcome.PdfStatus=="NOT_AUTHORIZED","PDF authority changed");
    }
    finally{Directory.Delete(dir,true);}
});
Test("T89_later_known_error_keeps_person_findings",()=>
{
    string dir=Path.Combine(Path.GetTempPath(),"IPP_failed_review_"+Guid.NewGuid());Directory.CreateDirectory(dir);
    try
    {
        string b=Path.Combine(dir,"base.xlsx"),t=Path.Combine(dir,"change_012026.txt");
        var br=BaseRow();SpreadsheetWriter.Write(b,new OutputSheet("Bestand",br.Keys.ToList(),new(){br.Values.ToList()}));
        File.WriteAllText(t,"KDMA_IDENT;ARBZEIT_PROZ;BETRAG1;BETRAG1_TYP;ANSPRUCHSTYP;Tarifklasse\n1001;100;-1;ATTC_BAV;AKTAN;10\n9999;100;8000;ATTC_BAV;AKTAN;10\n",Encoding.UTF8);
        try {new Pipeline().Execute(new RunRequest{BaselinePath=b,TxtPaths=new(){t},OutputDirectory=Path.Combine(dir,"out")});throw new Exception("Expected failure");}
        catch(IppException ex){Check(ex.Code=="ATTC_NEGATIVE","Unexpected failure");Check(ex.Data["RunDirectory"] is string p&&File.Exists(Path.Combine(p,"Personen_Pruefung.json"))&&File.Exists(Path.Combine(p,"FAILED.json")),"Findings lost");}
    }
    finally{Directory.Delete(dir,true);}
});
Test("T90_full_pipeline_confirmed_entry_and_updated_baseline",()=>
{
    string dir=Path.Combine(Path.GetTempPath(),"IPP_new_"+Guid.NewGuid());Directory.CreateDirectory(dir);
    try
    {
        string b=Path.Combine(dir,"base.xlsx"),t=Path.Combine(dir,"change_012026.txt"),decisions=Path.Combine(dir,"decisions.json");
        var br=BaseRow();SpreadsheetWriter.Write(b,new OutputSheet("Bestand",br.Keys.ToList(),new(){br.Values.ToList()}));
        File.WriteAllText(t,"KDMA_IDENT;ARBZEIT_PROZ;BETRAG1;BETRAG1_TYP;ANSPRUCHSTYP;Tarifklasse;Surname;FirstName;BirthDate;DAT_AD2\n1001;100;8000;ATTC_BAV;AKTAN;10;Demo;Test;01.01.1980;\n9999;100;8000;ATTC_BAV;AKTAN;10;Neumann;Nora;02.02.1990;01.01.2026\n",Encoding.UTF8);
        var request=new RunRequest{BaselinePath=b,TxtPaths=new(){t},OutputDirectory=Path.Combine(dir,"out"),PersonDecisionsPath=decisions};
        var first=new Pipeline().Execute(request);var report=JsonFiles.Read<PersonReviewReport>(Path.Combine(first.Directory,"Personen_Pruefung.json"));
        var c=report.Cases.Single();JsonFiles.Write(decisions,new List<NewPersonDecision>{new(){ContextSha256=report.ContextSha256,CaseId=c.CaseId,ClientId=c.ClientId,Surname="Neumann",FirstName="Nora",BirthDate=new(1990,2,2),DatAd2=new(2026,1,1),Reviewer="test",Evidence="Synthetic fixture",ConfirmedUtc=DateTimeOffset.UtcNow,IdentityAndNewEntryVerified=true}});
        var second=new Pipeline().Execute(request);Check(second.Persons==2&&second.NewPersonsAdded==1&&second.OpenPersonCases==0,"Admission failed");
        using var reader=new SpreadsheetReader(File.ReadAllBytes(Path.Combine(second.Directory,"Bestand_Fortgeschrieben.xlsx")));Check(reader.Baseline(null).Rows.Count==2,"Baseline copy missing new person");
        var third=new Pipeline().Execute(request);Check(third.Persons==2&&third.NewPersonsAdded==1,"Repeat duplicates person");
    }
    finally{Directory.Delete(dir,true);}
});

// V0.2.1: casewise tariff policy. The original strict engine tests above remain unchanged.
ContributionResult ReviewRun(InputTable? b, params MonthFile[] files) => new ContributionEngine().Run(b ?? Base(), files, new() { ReviewTariffIssues = true });
InputTable TwoPeople()
{
    var b = Base(); var other = BaseRow(); other["ClientID"] = "1002"; other["Surname"] = "Zweite"; other["FirstName"] = "Person"; b.Rows.Add(other); return b;
}
Test("T91_unknown_tariff_preserves_attc_holds_only_amount", () =>
{
    var r = ReviewRun(null, Month(1, Row(tariff: null))); var m = r.Persons.Single().Months[1];
    Check(m.Attc == 8000 && m.Amount is null && m.Tzg == 100 && m.TariffReviewRequired, "Salary lost or amount released");
    var c = r.TariffReview!.Cases.Single(); Check(c.ClientId == "1001" && c.DisplayName == "Test Demo" && c.Month == "2026-01", "Identity missing");
    Check(c.Classification == "TARIFF_EMPTY_NO_PRIOR_TARIFF" && c.Open, "Case cause");
});
Test("T92_absent_january_record_does_not_backfill_from_february", () =>
{
    var r = ReviewRun(null, Month(1), Month(2, Row())); var p = r.Persons.Single();
    Check(p.Months[1].Amount is null && p.Months[2].Amount > 0, "Backfill or later month lost");
    Check(r.TariffReview!.Cases.Single().Classification == "NO_TXT_RECORD_NO_PRIOR_TARIFF", "No-row evidence");
    Check(r.TariffReview.Cases[0].Occurrences.Count == 0 && r.TariffReview.Coverage[0].PersonsWithoutTxtRecord == 1, "Absent != blank");
});
Test("T93_known_prior_tariff_and_salary_can_carry_forward", () =>
{
    var p = ReviewRun(null, Month(1, Row(attc:"9000")), Month(2)).Persons.Single();
    Check(p.Months[2].EffectiveTariff == 10 && p.Months[2].Attc == 9000 && p.Months[2].Amount > 0, "Prior evidence lost");
});
Test("T94_known_99_is_not_unknown_and_stays_blocked", () =>
{
    var r = ReviewRun(null, Month(1, Row(tariff:"99")), Month(2));
    Check(r.TariffReview!.OpenMonthCases == 0 && r.Persons.Single().Months[2].Amount is null, "99 mistaken for review");
});
Test("T95_confirmed_future_entry_has_no_premature_tariff_case", () =>
{
    var row = BaseRow(); row["DAT_AD2"] = "01.02.2026";
    var r = ReviewRun(Base(row), Month(1), Month(2, Row()));
    Check(r.TariffReview!.OpenMonthCases == 0 && r.Persons.Single().Months[1].Attc is null, "Before entry");
});
Test("T96_conflicting_tariffs_are_not_last_row_wins_in_review", () =>
{
    var r = ReviewRun(null, Month(1, Row(tariff:"10"), Row(tariff:"99")), Month(2, Row(tariff:"20")));
    Check(r.TariffReview!.Cases.Single().Classification == "TARIFF_VALUES_CONFLICT", "Conflict not flagged");
    Check(r.Persons.Single().Months[1].Amount is null && r.Persons.Single().Months[2].Amount > 0, "Conflict not isolated");
});
Test("T97_invalid_tariff_interrupts_old_status_until_new_evidence", () =>
{
    var r = ReviewRun(null, Month(1, Row()), Month(2, Row(tariff:"invalid")), Month(3, Row(tariff:null)), Month(4, Row(tariff:"20")));
    var p = r.Persons.Single(); Check(p.Months[2].Amount is null && p.Months[3].Amount is null && p.Months[4].Amount > 0, "Old tariff guessed");
    Check(r.TariffReview!.OpenMonthCases == 2 && r.TariffReview.Cases[1].Classification == "TARIFF_UNRESOLVED_AFTER_CONFLICT", "Continuity case");
});
Test("T98_equal_repeated_tariffs_not_a_conflict", () =>
{
    var r = ReviewRun(null, Month(1, Row(), Row(tariff:"10,0")));
    Check(r.TariffReview!.Cases.Count == 0 && r.Persons.Single().Months[1].Amount > 0, "False conflict");
});
Test("T99_blank_tariff_after_known_tariff_can_carry", () =>
{
    var r = ReviewRun(null, Month(1, Row()), Month(2, Row(tariff:null)));
    Check(r.TariffReview!.OpenMonthCases == 0 && r.Persons.Single().Months[2].EffectiveTariff == 10, "Blank treated as deletion");
});
Test("T100_other_person_continues_with_valid_tariff", () =>
{
    var r = ReviewRun(TwoPeople(), Month(1, Row(tariff:null), Row(id:"1002")));
    Check(r.Persons.Single(p=>p.ClientId=="1002").Months[1].Amount > 0 && r.TariffReview!.AffectedPersons == 1, "Other person blocked");
});
Test("T101_missing_tariff_column_becomes_review_case", () =>
{
    var text = "KDMA_IDENT;ARBZEIT_PROZ;BETRAG1;BETRAG1_TYP;ANSPRUCHSTYP\n1001;100;8000;ATTC_BAV;AKTAN\n";
    var b = new SourceBlob(Encoding.UTF8.GetBytes(text),new("change_012026.txt",new string('0',64),0));
    var m = MonthReader.Read(b,new(){ReviewTariffIssues=true}); var r = ReviewRun(null,m);
    Check(r.TariffReview!.Cases.Single().Classification == "TARIFF_COLUMN_MISSING", "Missing header not reported");
});
Test("T102_strict_reader_keeps_missing_tariff_column_gate", () =>
{
    var b = new SourceBlob(Encoding.UTF8.GetBytes("KDMA_IDENT;ARBZEIT_PROZ;BETRAG1;BETRAG1_TYP;ANSPRUCHSTYP\n1001;100;8000;ATTC_BAV;AKTAN\n"),new("change_012026.txt",new string('0',64),0));
    Throws("TARIFF_COLUMN_MISSING",()=>MonthReader.Read(b,new()));
});
Test("T103_tariff_record_numbers_survive_person_filtering", () =>
{
    var b = new SourceBlob(Encoding.UTF8.GetBytes("KDMA_IDENT;ARBZEIT_PROZ;BETRAG1;BETRAG1_TYP;ANSPRUCHSTYP;Tarifklasse\n9999;100;8000;ATTC_BAV;AKTAN;10\n1001;100;8000;ATTC_BAV;AKTAN;\n"),new("change_012026.txt",new string('0',64),0));
    var m=MonthReader.Read(b,new(){ReviewTariffIssues=true}); var p=PrepareTest(new[]{m}); var r=ReviewRun(p.Baseline,p.Months.ToArray());
    Check(r.TariffReview!.Cases.Single().Occurrences.Single().DataRecord==2, "Evidence renumbered");
    Check(r.TariffReview.Coverage.Single().SourceRecords==2&&r.TariffReview.Coverage.Single().KnownRecords==1, "Counts conflate sources and retained rows");
});
Test("T104_future_99_not_applied_backwards", () =>
{
    var r=ReviewRun(null,Month(1,Row(tariff:null)),Month(2,Row(tariff:"99")));
    Check(r.Persons.Single().Months[1].EffectiveTariff is null&&r.Persons.Single().TariffOld==99&&r.TariffReview!.OpenMonthCases==1,"Backwards tariff");
});
Test("T105_unknown_tariff_no_longer_breaks_salary_fallback", () =>
{
    var p=ReviewRun(null,Month(1,Row(tariff:null)),Month(2,Row(attc:null))).Persons.Single();
    Check(p.Months[1].Attc==8000&&p.Months[1].Amount is null&&p.Months[2].Attc==8000&&p.Months[2].Amount>0,"Salary continuity lost or unknown amount released");
});
Test("T106_strict_unknown_error_names_id_and_month", () =>
{
    try{Run(null,Month(1,Row(tariff:null)));throw new Exception("Missing exception");}
    catch(IppException e){Check(e.Code=="TARIFF_UNKNOWN"&&e.Message.Contains("1001")&&e.Message.Contains("2026-01"),"Unhelpful exception");}
});
Test("T107_contradictory_tariff_options_rejected", () => Throws("TARIFF_POLICY_CONFLICT",()=>new ContributionEngine().Run(Base(),new[]{Month(1,Row())},new(){ReviewTariffIssues=true,AllowMissingTariff=true})));
Test("T108_unknown_person_and_known_tariff_case_stay_separate", () =>
{
    var p=PrepareTest(new[]{Month(1,Row(tariff:null),Named())}); var r=ReviewRun(p.Baseline,p.Months.ToArray());
    Check(p.Report.OpenCases==1&&r.TariffReview!.Cases.Count==1&&r.TariffReview.Cases[0].ClientId=="1001","Case ownership mixed");
});
Test("T109_partial_tariff_pipeline_publishes_audits_not_false_success", () =>
{
    string dir=Path.Combine(Path.GetTempPath(),"IPP_tariff_"+Guid.NewGuid()); Directory.CreateDirectory(dir);
    try
    {
        string b=Path.Combine(dir,"base.xlsx"),t=Path.Combine(dir,"change_012026.txt"); var table=TwoPeople();
        SpreadsheetWriter.Write(b,PersonReview.BaselineCopy(table));
        File.WriteAllText(t,"KDMA_IDENT;ARBZEIT_PROZ;BETRAG1;BETRAG1_TYP;ANSPRUCHSTYP;Tarifklasse\n1001;100;8000;ATTC_BAV;AKTAN;\n1002;100;8000;ATTC_BAV;AKTAN;10\n");
        var o=new Pipeline().Execute(new(){BaselinePath=b,TxtPaths=new(){t},OutputDirectory=Path.Combine(dir,"out")});
        Check(o.ContributionStatus=="PARTIAL_TARIFF_REVIEW_REQUIRED"&&o.OpenTariffMonths==1&&o.PersonsWithOpenTariffs==1,"Wrong status");
        foreach(var n in new[]{"Tarif_Pruefung.json","Tarifpruefung.xlsx","Ergebnis.xlsx","Personen_Pruefung.json"})Check(File.Exists(Path.Combine(o.Directory,n)),"Missing "+n);
        Check(o.PdfStatus=="NOT_AUTHORIZED"&&!Directory.GetFiles(o.Directory,"*.pdf").Any(),"PDF falsely allowed");
    }finally{Directory.Delete(dir,true);}
});
Test("T110_combined_partial_status", () =>
{
    string dir=Path.Combine(Path.GetTempPath(),"IPP_combined_"+Guid.NewGuid()); Directory.CreateDirectory(dir);
    try
    {
        string b=Path.Combine(dir,"base.xlsx"),t=Path.Combine(dir,"change_012026.txt"); SpreadsheetWriter.Write(b,PersonReview.BaselineCopy(Base()));
        File.WriteAllText(t,"KDMA_IDENT;ARBZEIT_PROZ;BETRAG1;BETRAG1_TYP;ANSPRUCHSTYP;Tarifklasse\n1001;100;8000;ATTC_BAV;AKTAN;\n9999;100;8000;ATTC_BAV;AKTAN;10\n");
        var o=new Pipeline().Execute(new(){BaselinePath=b,TxtPaths=new(){t},OutputDirectory=Path.Combine(dir,"out")});
        Check(o.ContributionStatus=="PARTIAL_PERSON_AND_TARIFF_REVIEW_REQUIRED"&&o.OpenPersonCases==1&&o.OpenTariffMonths==1,"Combined review not visible");
    }finally{Directory.Delete(dir,true);}
});
Test("T111_tariff_findings_survive_independent_numeric_error", () =>
{
    string dir=Path.Combine(Path.GetTempPath(),"IPP_tariff_failure_"+Guid.NewGuid()); Directory.CreateDirectory(dir);
    try
    {
        string b=Path.Combine(dir,"base.xlsx"),t=Path.Combine(dir,"change_012026.txt"); SpreadsheetWriter.Write(b,PersonReview.BaselineCopy(TwoPeople()));
        File.WriteAllText(t,"KDMA_IDENT;ARBZEIT_PROZ;BETRAG1;BETRAG1_TYP;ANSPRUCHSTYP;Tarifklasse\n1001;100;8000;ATTC_BAV;AKTAN;\n1002;100;-1;ATTC_BAV;AKTAN;10\n");
        try{new Pipeline().Execute(new(){BaselinePath=b,TxtPaths=new(){t},OutputDirectory=Path.Combine(dir,"out")});throw new Exception("Error swallowed");}
        catch(IppException e){Check(e.Code=="ATTC_NEGATIVE"&&e.Data["RunDirectory"] is string,"Wrong failure");var f=(string)e.Data["RunDirectory"]!;Check(File.Exists(Path.Combine(f,"Tarif_Pruefung.json"))&&File.Exists(Path.Combine(f,"Tarifpruefung.xlsx"))&&File.Exists(Path.Combine(f,"FAILED.json")),"Diagnostics lost");Check(!File.Exists(Path.Combine(f,"Ergebnis.xlsx")),"Error got published");}
    }finally{Directory.Delete(dir,true);}
});
Test("T112_tariff_review_respects_cancellation", () =>
{
    using var c=new CancellationTokenSource(); c.Cancel();
    try{TariffReview.Analyze(new List<PersonResult>(),new[]{Month(1,Row())},c.Token);throw new Exception("Cancellation ignored");}catch(OperationCanceledException){}
});
Test("T113_tariff_cases_deterministic_under_file_order", () =>
{
    var a=Month(1,Row(tariff:null));var b=Month(2,Row(tariff:"invalid"));
    Check(JsonSerializer.Serialize(ReviewRun(null,a,b),JsonFiles.Options)==JsonSerializer.Serialize(ReviewRun(null,b,a),JsonFiles.Options),"Order dependence");
});
Test("T114_blank_vs_no_record_are_distinguished", () =>
{
    var a=ReviewRun(null,Month(1,Row(tariff:" ")));var b=ReviewRun(null,Month(1));
    Check(a.TariffReview!.Cases.Single().Occurrences.Count==1&&b.TariffReview!.Cases.Single().Occurrences.Count==0,"Blank and no row conflated");
});
Test("T115_tariff_workbook_literals_do_not_become_formulas", () =>
{
    string dir=Path.Combine(Path.GetTempPath(),"IPP_tariff_excel_"+Guid.NewGuid()); Directory.CreateDirectory(dir);
    try
    {
        var b=BaseRow();b["Surname"]="=HYPERLINK(1)";
        var r=ReviewRun(Base(b),Month(1,Row(tariff:"=HYPERLINK()"))); TariffReview.Write(dir,r.TariffReview!);
        using var reader=new SpreadsheetReader(File.ReadAllBytes(Path.Combine(dir,"Tarifpruefung.xlsx")));
        Check(reader.Sheets.Count==4&&reader.Sheets.All(s=>reader.Cells(s).All(c=>c.Formula is null)),"Formula injection / sheets");
        TariffReview.Write(dir,r.TariffReview!);Check(!Directory.GetFiles(dir,".tariff_*").Any(),"Atomic rewrite leftover");
    }finally{Directory.Delete(dir,true);}
});
Test("T116_contribution_sheet_has_tariff_flags_and_blank_money", () =>
{
    var r=ReviewRun(null,Month(1,Row(tariff:null)));var s=SpreadsheetWriter.Contributions(r);int amount=s.Headers.IndexOf("Betrag_1");
    Check(s.Headers.Contains("MCR_Tarifstatus")&&s.Rows.Single()[amount] is null&&s.Rows.Single()[s.Headers.IndexOf("MCR_Tarifmonate_offen")]?.ToString()=="2026-01","Unflagged or zeroed amount");
});
Test("T117_zero_tzg_does_not_invent_tariff", () =>
{
    var r=ReviewRun(null,Month(1,Row(tariff:null,tzg:"0")));Check(r.TariffReview!.OpenMonthCases==1&&r.Persons.Single().Months[1].Amount is null,"Tariff inferred from zero TZG");
});
Test("T118_new_admission_proof_remains_strict_on_tariff", () =>
{
    var n=Named();n["Tarifklasse"]=null;var m=new[]{Month(1,Row()),Month(2,Row(),n)};var p=PrepareTest(m);var q=PrepareTest(m,new[]{Approve(p)});
    Check(q.Report.OpenCases==1&&q.Report.AddedPersons==0,"New entry silently allowed unknown tariff");
});
Test("T119_clean_review_has_zero_cases", () =>
{
    var r=ReviewRun(null,Month(1,Row()));Check(r.TariffReview!.OpenMonthCases==0&&r.TariffReview.AffectedPersons==0,"False open case");
});
Test("T120_exit_mask_removes_irrelevant_open_tariff_case", () =>
{
    var r=ReviewRun(null,Month(1,Row(tariff:null,claim:"AUGUAN",term:"31.12.2025")));
    Check(r.TariffReview!.Cases.Single().Resolution=="NOT_REQUIRED_AFTER_AUGUAN_EXIT"&&r.TariffReview.OpenMonthCases==0,"Post-exit remains open");
    Check(!r.Persons.Single().Months[1].TariffReviewRequired&&r.Persons.Single().Months[1].Amount is null,"Post-exit money released");
});
Test("T121_invalid_and_valid_tariff_same_month_still_review", () =>
{
    var r=ReviewRun(null,Month(1,Row(),Row(tariff:"invalid")));
    Check(r.TariffReview!.Cases.Single().Classification=="TARIFF_VALUE_INVALID"&&r.Persons.Single().Months[1].Amount is null,"Invalid update ignored");
});
Test("T122_review_never_invents_initial_tariff_from_baseline_salary", () =>
{
    var r=ReviewRun(null,Month(1));Check(r.Persons.Single().TariffOld is null&&r.Persons.Single().Months[1].EffectiveTariff is null,"Salary used as tariff proof");
});
Test("T123_review_does_not_mutate_source_rows", () =>
{
    var b=TwoPeople();var m=Month(1,Row(tariff:null),Row(id:"1002"));string before=JsonSerializer.Serialize(new{b,m.Rows},JsonFiles.Options);
    ReviewRun(b,m);Check(before==JsonSerializer.Serialize(new{b,m.Rows},JsonFiles.Options),"Inputs mutated");
});
Test("T124_first_known_tariff_after_gap_not_a_proven_change_date", () =>
{
    var p=ReviewRun(null,Month(1,Row(tariff:null)),Month(2,Row(tariff:"20"))).Persons.Single();
    Check(p.TariffOld==20&&p.TariffNew is null&&p.TariffChangeDate is null,"Invented change date");
});
Test("T125_missing_column_after_prior_proof_can_carry", () =>
{
    var r=ReviewRun(null,Month(1,Row()),Month(2,Row(tariff:null)) with {TariffColumn=null});
    Check(r.TariffReview!.OpenMonthCases==0&&r.Persons.Single().Months[2].EffectiveTariff==10,"Prior proof discarded");
});
Test("T126_coverage_counts_people_not_repeated_records", () =>
{
    var r=ReviewRun(TwoPeople(),Month(1,Row(tariff:null),Row(tariff:null),Row(id:"1002")));
    var c=r.TariffReview!.Coverage.Single();Check(c.PersonsWithTxtRecord==2&&c.KnownRecords==3&&c.OpenTariffCases==1&&r.TariffReview.AffectedPersons==1,"Records counted as people");
});

Test("T127_review_preserves_financial_results_for_known_tariffs", () =>
{
    var months=new[]{Month(1,Row(tariff:"99")),Month(2,Row(attc:"9000",tzg:"80")),Month(3,Row(tariff:null,attc:null,tzg:null)),Month(4,Row(tariff:"20",attc:"9500"))};
    var strict=Run(null,months);var reviewResult=ReviewRun(null,months);var a=strict.Persons.Single();var b=reviewResult.Persons.Single();
    Check(reviewResult.TariffReview!.OpenMonthCases==0&&a.TariffOld==b.TariffOld&&a.TariffNew==b.TariffNew&&a.TariffChangeDate==b.TariffChangeDate,"Known tariff history changed");
    foreach(int m in strict.Months){Equal(a.Months[m].Attc,b.Months[m].Attc);Equal(a.Months[m].Tzg,b.Months[m].Tzg);Equal(a.Months[m].Amount,b.Months[m].Amount);}
});
Test("T128_retained_salary_and_held_amount_have_distinct_excel_styles", () =>
{
    var sheet=SpreadsheetWriter.Contributions(ReviewRun(null,Month(1,Row(tariff:null))));var xml=SpreadsheetWriter.SheetXml(sheet);
    Check(sheet.ReviewCells.Count==2,"Expected ATTC and amount marks");
    foreach(string address in sheet.ReviewCells)
    {
        var cell=xml.Descendants(SpreadsheetReader.Main+"c").Single(c=>(string?)c.Attribute("r")==address);
        bool salary = address.StartsWith(SpreadsheetReader.Column(sheet.Headers.IndexOf("ATTC_1")+1),StringComparison.Ordinal);
        Check(salary ? (string?)cell.Attribute("s")=="5" && (string?)cell.Element(SpreadsheetReader.Main+"v")=="8000"
            : (string?)cell.Attribute("s")=="4" && !cell.Elements().Any(), "Review formatting/value mismatch");
    }
});


// V0.3.0 regression coverage: ATTC is a salary fact; only the amount is held.
Test("T129_january_baseline_fallback_with_no_txt_person_row",()=>
{
    var r=ReviewRun(null,Month(1));var m=r.Persons.Single().Months[1];
    Equal(m.Attc,8000);Check(m.AttcSource=="BASE_SALARY_1"&&m.Amount is null&&m.AmountStatus=="HELD_TARIFF_REVIEW","Missing baseline fallback / bad release");
});
Test("T130_unknown_tariff_retains_matching_txt_salary_over_baseline",()=>
{
    var m=ReviewRun(null,Month(1,Row(tariff:null,attc:"9750"))).Persons.Single().Months[1];
    Equal(m.Attc,9750);Check(m.AttcSource=="TXT_ATTC_BAV_AKTAN"&&m.Amount is null,"TXT priority");
});
Test("T131_unknown_tariff_blank_salary_uses_baseline",()=>
{
    var m=ReviewRun(null,Month(1,Row(tariff:null,attc:null))).Persons.Single().Months[1];Equal(m.Attc,8000);Check(m.AttcSource=="BASE_SALARY_1","Fallback provenance");
});
Test("T132_unknown_tariff_non_matching_claim_still_uses_fallback",()=>
{
    var m=ReviewRun(null,Month(1,Row(tariff:null,attc:"9999",claim:"AUGUAN"))).Persons.Single().Months[1];Equal(m.Attc,8000);Check(m.Amount is null,"Unknown amount allowed");
});
Test("T133_known_98_still_masks_baseline_salary",()=>
{
    var m=ReviewRun(null,Month(1,Row(tariff:"98",attc:null))).Persons.Single().Months[1];Check(m.Attc is null&&m.Amount is null&&m.AmountStatus=="EXCLUDED_TARIFF_98_99","98 gate lost");
});
Test("T134_unknown_salary_chain_continues_until_first_known_tariff",()=>
{
    var p=ReviewRun(null,Month(1),Month(2),Month(3,Row(attc:null))).Persons.Single();
    Check(p.Months[1].Attc==8000&&p.Months[2].Attc==8000&&p.Months[3].Attc==8000,"Chain broken");
    Check(p.Months[1].Amount is null&&p.Months[2].Amount is null&&p.Months[3].Amount>0,"Wrong amount timing");
});
Test("T135_no_backfill_of_tariff_even_when_salary_preserved",()=>
{
    var p=ReviewRun(null,Month(1),Month(2,Row(tariff:"99"))).Persons.Single();
    Check(p.Months[1].Attc==8000&&p.Months[1].EffectiveTariff is null&&p.Months[1].Amount is null&&p.Months[2].Attc is null,"Tariff backfilled");
});
Test("T136_known_99_still_breaks_salary_chain_until_new_salary",()=>
{
    var p=ReviewRun(null,Month(1,Row(tariff:"99")),Month(2,Row(attc:null)),Month(3,Row(attc:"9200"))).Persons.Single();
    Check(p.Months[2].Attc is null&&p.Months[3].Attc==9200,"Excluded salary restored");
});
Test("T137_tariff_conflict_keeps_salary_fact_not_amount",()=>
{
    var m=ReviewRun(null,Month(1,Row(attc:"8100"),Row(tariff:"99",attc:"8300"))).Persons.Single().Months[1];
    Check(m.Attc==8300&&m.EffectiveTariff is null&&m.Amount is null,"Conflict fact/approval mixed");
});
Test("T138_bad_salary_cannot_hide_behind_unknown_tariff",()=>Throws("INVALID_NUMBER",()=>ReviewRun(null,Month(1,Row(tariff:null,attc:"not-a-number")))));
Test("T139_entry_mask_still_applies_with_retained_salary",()=>
{
    var b=BaseRow();b["DAT_AD2"]="15.02.2026";var p=ReviewRun(Base(b),Month(1),Month(2,Row(attc:null))).Persons.Single();
    Check(p.Months[1].Attc is null&&p.Months[1].AmountStatus=="BEFORE_DAT_AD2","Entry gate lost");
    // Reference stage order: fallback happens before entry mask, not an unapproved new entry-date rule.
    Check(p.Months[2].Attc==8000,"Reference stage order altered");
});
Test("T140_exit_mask_still_applies_with_retained_salary",()=>
{
    var p=ReviewRun(null,Month(1,Row(tariff:null,claim:"AUGUAN",term:"31.12.2025"))).Persons.Single();
    Check(p.Months[1].Attc is null&&p.Months[1].AmountStatus=="AFTER_AUGUAN_EXIT","Exit gate lost");
});
Test("T141_missing_baseline_not_invented",()=>
{
    var b=BaseRow();b["BaseSalary_1"]=null;var m=ReviewRun(Base(b),Month(1)).Persons.Single().Months[1];Check(m.Attc is null&&m.AttcSource=="MISSING","Invented salary");
});
Test("T142_salary_only_profile_matches_legacy_unknown_tariff_fallback",()=>
{
    var months=new[]{Month(1,Row(tariff:null,attc:null,tzg:null)),Month(2,Row(tariff:null,attc:null,tzg:null)),Month(3,Row(tariff:"20",attc:null,tzg:null))};
    var legacy=new ContributionEngine().Run(Base(),months,new(){AllowMissingTariff=true}).Persons.Single();var actual=ReviewRun(null,months).Persons.Single();
    foreach(var m in actual.Months.Keys){Equal(actual.Months[m].Attc,legacy.Months[m].Attc);Equal(actual.Months[m].Tzg,legacy.Months[m].Tzg);}
    Check(actual.Months[1].Amount is null&&legacy.Months[1].Amount>0,"Intentional amount difference not explicit");
});
Test("T143_direct_previous_month_not_last_available_month",()=>
{
    var p=ReviewRun(null,Month(1),Month(3,Row(attc:null))).Persons.Single();Check(p.Months[1].Attc==8000&&p.Months[3].Attc is null,"Gap bridged without rule");
});
Test("T144_snapshot_declares_salary_and_amount_policy",()=>
{
    var r=ReviewRun(null,Month(1));Check(r.AttcPolicy=="SOURCE_OR_FALLBACK_INDEPENDENT_OF_TARIFF_REVIEW_V1"&&r.AmountPolicy=="HOLD_AMOUNT_WHILE_TARIFF_REVIEW_OPEN_V1","Policy evidence absent");
});
void DraftTemp(ContributionResult result, Action<string> action)
{
    string d=Path.Combine(Path.GetTempPath(),"IPP_draft_test_"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(d);
    try{JsonFiles.Write(Path.Combine(d,"Contribution_Result.json"),result);action(d);}finally{Directory.Delete(d,true);}
}
Test("T145_pdf_header_and_classic_xref_are_structural",()=>
{
    var r=ReviewRun(null,Month(1,Row()));var pdf=DraftPdf.Render("1001",ContributionDocuments.PersonLines(r,r.Persons[0],new string('A',64)));
    string text=Encoding.ASCII.GetString(pdf.Bytes);Check(text.StartsWith("%PDF-1.4\n",StringComparison.Ordinal)&&text.EndsWith("%%EOF\n",StringComparison.Ordinal),"PDF magic");
    int x=int.Parse(text.Split("startxref\n",StringSplitOptions.None)[1].Split('\n')[0],Parse.Inv);Check(text[x..].StartsWith("xref\n",StringComparison.Ordinal),"startxref offset");
    var table=text[x..].Split('\n');int count=int.Parse(table[1].Split(' ')[1],Parse.Inv);
    for(int i=1;i<count;i++){int offset=int.Parse(table[2+i][..10],Parse.Inv);Check(text[offset..].StartsWith(i+" 0 obj\n",StringComparison.Ordinal),"xref entry "+i);}
});
Test("T146_pdf_repeats_draft_notice_on_all_pages",()=>
{
    var lines=Enumerable.Range(0,100).Select(i=>new DraftLine("Testzeile "+i)).ToList();var p=DraftPdf.Render("1001",lines);
    Check(p.Pages==3,"Pagination");string text=Encoding.ASCII.GetString(p.Bytes);string notice=Convert.ToHexString(Encoding.ASCII.GetBytes("ENTWURF - INTERN - NICHT VERSENDEN"));
    Check(text.Split(notice,StringSplitOptions.None).Length-1==3,"Draft notice absent from page");
});
Test("T147_pdf_keeps_german_name_and_hex_encodes_syntax",()=>
{
    Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);string name="Jörg Müller (A) \\ Test";
    var p=DraftPdf.Render("1001",DraftPdf.Wrap(name));string text=Encoding.ASCII.GetString(p.Bytes);
    Check(text.Contains(Convert.ToHexString(Encoding.GetEncoding(1252).GetBytes(name)))&&!text.Contains(name),"Hex encoding failed");
});
Test("T148_unsupported_name_is_not_silently_replaced",()=>Throws("PDF_TEXT_UNSUPPORTED",()=>DraftPdf.Render("1001",DraftPdf.Wrap("Test 漢字"))));
Test("T149_control_character_is_rejected",()=>Throws("PDF_TEXT_UNSUPPORTED",()=>DraftPdf.Render("1001",new[]{new DraftLine("A\u0000B")})));
Test("T150_long_name_wrap_preserves_all_characters",()=>
{
    string name=new('Z',270);var lines=DraftPdf.Wrap(name);Check(lines.All(x=>x.Text.Length<=DraftPdf.Columns)&&string.Concat(lines.Select(x=>x.Text))==name,"Name truncated");
});
Test("T151_unknown_tariff_pdf_shows_salary_but_no_total",()=>
{
    var r=ReviewRun(null,Month(1));var text=string.Join("\n",ContributionDocuments.PersonLines(r,r.Persons[0],new string('A',64)).Select(x=>x.Text));
    Check(text.Contains("8.000,00")&&text.Contains("TARIF OFFEN")&&text.Contains("Keine Gesamtsumme")&&!text.Contains("Summe genau dieser"),"False amount/total");
});
Test("T152_complete_numeric_months_total_is_only_display_sum",()=>
{
    var r=ReviewRun(null,Month(1,Row()),Month(2,Row()));var text=string.Join("\n",ContributionDocuments.PersonLines(r,r.Persons[0],new string('A',64)).Select(x=>x.Text));
    Check(text.Contains("Summe genau dieser")&&text.Contains("KEINE Beitragsbereitstellung")&&text.Contains("keine Leistungs- oder Rentenberechnung"),"Draft pretends to be LNW");
});
Test("T153_pdf_batch_person_identity_and_manifest",()=>
{
    var r=ReviewRun(TwoPeople(),Month(1,Row(),Row(id:"1002")));
    DraftTemp(r,d=>{var p=ContributionDocuments.Write(d,r,true);Check(p.Created==2&&p.Failed==0&&!p.ProductionAuthorized,"Batch result");foreach(var item in p.Items){byte[] b=File.ReadAllBytes(Path.Combine(d,item.File!));Check(Convert.ToHexString(SHA256.HashData(b))==item.Sha256&&b.Length==item.Bytes,"File hash");}Check(File.Exists(Path.Combine(d,"Dokumentenplan.xlsx")),"Document plan");});
});
Test("T154_open_person_not_given_another_persons_pdf",()=>
{
    var r=ReviewRun(null,Month(1,Row()));r.PersonReview=new(){Cases=new(){new(){ClientId="9999",DisplayName="Neue Person"}}};
    DraftTemp(r,d=>{var p=ContributionDocuments.Write(d,r,true);Check(p.Created==1&&p.PersonsNotAdmitted==1&&p.Items.Single(i=>i.ClientId=="9999").File is null,"Open person exported");});
});
Test("T155_pdf_unicode_failure_does_not_stop_other_person",()=>
{
    var r=ReviewRun(TwoPeople(),Month(1,Row(),Row(id:"1002")));r.Persons[0].Master["Surname"]="漢字";
    DraftTemp(r,d=>{var p=ContributionDocuments.Write(d,r,true);Check(p.Created==1&&p.Failed==1&&p.Status=="PARTIAL_DRAFTS_WITH_ERRORS","Per-document isolation");Check(p.Items.Single(i=>i.ClientId=="1001").File is null,"Broken name published");});
});
Test("T156_modified_snapshot_blocks_pdf_batch",()=>
{
    var r=ReviewRun(null,Month(1,Row()));DraftTemp(r,d=>{File.AppendAllText(Path.Combine(d,"Contribution_Result.json")," ");Throws("DRAFT_SOURCE_CHANGED",()=>ContributionDocuments.Write(d,r,true));});
});
Test("T157_existing_pdf_directory_not_overwritten",()=>
{
    var r=ReviewRun(null,Month(1,Row()));DraftTemp(r,d=>{ContributionDocuments.Write(d,r,true);Throws("DRAFT_OUTPUT_EXISTS",()=>ContributionDocuments.Write(d,r,true));});
});
Test("T158_draft_cancel_retains_unpublished_evidence",()=>
{
    var r=ReviewRun(null,Month(1,Row()));DraftTemp(r,d=>{using var c=new CancellationTokenSource();c.Cancel();try{ContributionDocuments.Write(d,r,true,cancel:c.Token);throw new Exception("Cancellation ignored");}catch(OperationCanceledException){}Check(!Directory.Exists(Path.Combine(d,ContributionDocuments.FolderName)),"Cancelled draft published");
        using var mid=new CancellationTokenSource();try{ContributionDocuments.Write(d,r,true,_=>mid.Cancel(),mid.Token);throw new Exception("Mid-batch cancellation ignored");}catch(OperationCanceledException){}
        Check(Directory.GetFiles(Path.Combine(d,ContributionDocuments.FolderName),"*.pdf").Length==1,"Cancelled evidence was deleted");
        Check(!File.Exists(Path.Combine(d,"Dokumentenplan.json")),"Incomplete plan marked successful");
        Check(JsonFiles.Read<ContributionDocumentReport>(Path.Combine(d,"Dokumentenplan_Zwischenstand.json")).Status=="INTERRUPTED_NOT_PUBLISHED","Missing cancellation status");});
});
Test("T159_false_ipp_authority_is_rejected_by_draft_adapter",()=>
{
    var r=ReviewRun(null,Month(1,Row()));r.PdfAuthorized=true;DraftTemp(r,d=>Throws("DRAFT_SCOPE",()=>ContributionDocuments.Write(d,r,true)));
});
Test("T160_duplicate_pdf_id_rejected",()=>
{
    var r=ReviewRun(null,Month(1,Row()));r.Persons.Add(r.Persons[0]);DraftTemp(r,d=>Throws("DRAFT_DUPLICATE_ID",()=>ContributionDocuments.Write(d,r,true)));
});
Test("T161_unsafe_amount_on_open_tariff_rejected",()=>
{
    var r=ReviewRun(null,Month(1));r.Persons[0].Months[1].Amount=100;DraftTemp(r,d=>Throws("DRAFT_UNSAFE_AMOUNT",()=>ContributionDocuments.Write(d,r,true)));
});
Test("T162_draft_opt_out_produces_only_plan",()=>
{
    var r=ReviewRun(null,Month(1,Row()));DraftTemp(r,d=>{var p=ContributionDocuments.Write(d,r,false);Check(p.Created==0&&p.Status=="DRAFT_NOT_REQUESTED"&&!Directory.Exists(Path.Combine(d,ContributionDocuments.FolderName)),"Opt out ignored");});
});
Test("T163_pdf_is_deterministic_for_same_snapshot",()=>
{
    var r=ReviewRun(null,Month(1,Row()));var lines=ContributionDocuments.PersonLines(r,r.Persons[0],new string('A',64));Check(DraftPdf.Render("1001",lines).Bytes.SequenceEqual(DraftPdf.Render("1001",lines).Bytes),"Random draft content");
});
Test("T164_pipeline_combines_salary_fix_and_drafts_with_recursive_hashes",()=>
{
    string d=Path.Combine(Path.GetTempPath(),"IPP_full_draft_"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(d);
    try
    {
        string b=Path.Combine(d,"base.xlsx"),t=Path.Combine(d,"input_012026.txt");SpreadsheetWriter.Write(b,PersonReview.BaselineCopy(TwoPeople()));
        File.WriteAllText(t,"KDMA_IDENT;ARBZEIT_PROZ;BETRAG1;BETRAG1_TYP;ANSPRUCHSTYP;Tarifklasse\n1002;100;9000;ATTC_BAV;AKTAN;10\n");
        var o=new Pipeline().Execute(new(){BaselinePath=b,TxtPaths=new(){t},OutputDirectory=Path.Combine(d,"out"),CreateContributionDraftPdfs=true});
        Check(o.DraftPdfsCreated==2&&o.OpenTariffMonths==1&&o.PdfStatus=="NOT_AUTHORIZED","Pipeline state");
        var r=JsonFiles.Read<ContributionResult>(Path.Combine(o.Directory,"Contribution_Result.json"));Equal(r.Persons.Single(p=>p.ClientId=="1001").Months[1].Attc,8000);
        using var manifest=JsonDocument.Parse(File.ReadAllText(Path.Combine(o.Directory,"Manifest.json")));
        int pdfs=0;foreach(var item in manifest.RootElement.EnumerateArray()){string file=item.GetProperty("file").GetString()!;byte[] bytes=File.ReadAllBytes(Path.Combine(o.Directory,file));Check(item.GetProperty("sha256").GetString()==Convert.ToHexString(SHA256.HashData(bytes)),"Manifest mismatch "+file);if(file.EndsWith(".pdf",StringComparison.Ordinal))pdfs++;}Check(pdfs==2,"PDFs missing in manifest");
    }finally{Directory.Delete(d,true);}
});



// V0.3.1: OS I/O fault tests use injected operations; these are not a claim that
// a particular antivirus/file handle caused a user's Windows error.
void PublishTemp(Action<string,string,string> action)
{
    string d=Path.Combine(Path.GetTempPath(),"IPP_publish_"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(d);
    string final=Path.Combine(d,"IPP_Run_test"),stage=Path.Combine(d,".inprogress_IPP_Run_test");Directory.CreateDirectory(stage);
    File.WriteAllText(Path.Combine(stage,"keep.txt"),"synthetic evidence");
    try{action(d,stage,final);}finally{if(Directory.Exists(d))Directory.Delete(d,true);}
}
IOException WinIo(int code) => new("Injected OS error - synthetic test only",unchecked((int)0x80070000)|code);
Test("T165_pdf_is_written_under_parent_transaction_without_inner_rename",()=>
{
    var r=ReviewRun(null,Month(1,Row()));DraftTemp(r,d=>
    {
        bool observed=false;
        var doc=ContributionDocuments.Write(d,r,true,_=>
        {
            observed=true;
            Check(Directory.GetFiles(Path.Combine(d,ContributionDocuments.FolderName),"*.pdf").Length==1,"No PDF under parent transaction");
            Check(!Directory.GetDirectories(d,".pdf_inprogress_*").Any(),"Redundant inner staging still used");
        });
        Check(observed&&doc.Created==1,"Missing progress/document");
    });
});
Test("T166_document_plan_failure_keeps_pdfs_and_first_exception",()=>
{
    var r=ReviewRun(null,Month(1,Row()));DraftTemp(r,d=>
    {
        Directory.CreateDirectory(Path.Combine(d,"Dokumentenplan.xlsx"));
        Exception? caught=null;try{ContributionDocuments.Write(d,r,true);}catch(Exception ex){caught=ex;}
        Check(caught is IOException or UnauthorizedAccessException,"Expected plan I/O failure");
        Check(Directory.GetFiles(Path.Combine(d,ContributionDocuments.FolderName),"*.pdf").Length==1,"PDF evidence deleted");
        Check(caught!.Data["OutputStep"]?.ToString()=="PDF_DRAFT_WRITE_OR_DOCUMENT_PLAN","No phase");
        var report=JsonFiles.Read<ContributionDocumentReport>(Path.Combine(d,"Dokumentenplan_Zwischenstand.json"));
        Check(report.Created==1&&report.Status=="INTERRUPTED_NOT_PUBLISHED","Progress not retained");
    });
});
Test("T167_run_publish_moves_once_with_closed_handles",()=>PublishTemp((d,s,f)=>
{
    int n=OutputPublication.MoveRun(s,f,null,default);
    Check(n==1&&Directory.Exists(f)&&!Directory.Exists(s)&&File.ReadAllText(Path.Combine(f,"keep.txt"))=="synthetic evidence","Move mismatch");
}));
Test("T168_run_publish_retries_access_denied_then_moves",()=>PublishTemp((d,s,f)=>
{
    int calls=0,waits=0;
    int n=OutputPublication.MoveRunCore(s,f,(a,b)=>{if(++calls==1)throw WinIo(5);Directory.Move(a,b);},(ms,t)=>{waits++;Check(ms==150,"Delay");});
    Check(n==2&&calls==2&&waits==1&&Directory.Exists(f),"Retry failed");
}));
Test("T169_run_publish_retries_sharing_and_lock_codes",()=>PublishTemp((d,s,f)=>
{
    int calls=0,waits=0;
    int n=OutputPublication.MoveRunCore(s,f,(a,b)=>{calls++;if(calls<=2)throw WinIo(calls==1?32:33);Directory.Move(a,b);},(ms,t)=>waits++);
    Check(n==3&&calls==3&&waits==2&&Directory.Exists(f),"Share/lock retry failed");
}));
Test("T170_run_publish_persistent_access_denied_is_bounded_and_preserved",()=>PublishTemp((d,s,f)=>
{
    int calls=0,waits=0;var injected=WinIo(5);Exception? caught=null;
    try{OutputPublication.MoveRunCore(s,f,(a,b)=>{calls++;throw injected;},(ms,t)=>waits++);}catch(Exception ex){caught=ex;}
    Check(ReferenceEquals(caught,injected)&&calls==6&&waits==5,"Error replaced or unbounded retries");
    Check(Directory.Exists(s)&&!Directory.Exists(f)&&File.Exists(Path.Combine(s,"keep.txt")),"Evidence lost");
    Check(caught!.Data["PublishAttempts"]?.ToString()=="6"&&caught.Data["OutputStep"]?.ToString()=="RUN_DIRECTORY_PUBLISH","Missing diagnosis");
}));
Test("T171_run_publish_nontransient_io_is_not_retried",()=>PublishTemp((d,s,f)=>
{
    int calls=0,waits=0;var injected=WinIo(112);Exception? caught=null;
    try{OutputPublication.MoveRunCore(s,f,(a,b)=>{calls++;throw injected;},(ms,t)=>waits++);}catch(Exception ex){caught=ex;}
    Check(ReferenceEquals(caught,injected)&&calls==1&&waits==0&&Directory.Exists(s),"Nontransient error hidden");
}));
Test("T172_run_publish_pre_cancel_never_moves",()=>PublishTemp((d,s,f)=>
{
    using var c=new CancellationTokenSource();c.Cancel();int calls=0;bool cancelled=false;
    try{OutputPublication.MoveRunCore(s,f,(a,b)=>calls++,(ms,t)=>{},cancel:c.Token);}catch(OperationCanceledException){cancelled=true;}
    Check(cancelled&&calls==0&&Directory.Exists(s)&&!Directory.Exists(f),"Cancel ignored");
}));
Test("T173_run_publish_cancel_during_retry_preserves_pending_run",()=>PublishTemp((d,s,f)=>
{
    using var c=new CancellationTokenSource();int calls=0;bool cancelled=false;
    try{OutputPublication.MoveRunCore(s,f,(a,b)=>{calls++;throw WinIo(32);},(ms,t)=>c.Cancel(),cancel:c.Token);}catch(OperationCanceledException){cancelled=true;}
    Check(cancelled&&calls==1&&Directory.Exists(s)&&!Directory.Exists(f),"Mid-retry cancel ignored");
}));
Test("T174_run_publish_never_overwrites_existing_directory",()=>PublishTemp((d,s,f)=>
{
    Directory.CreateDirectory(f);File.WriteAllText(Path.Combine(f,"existing.txt"),"keep");int calls=0;
    Throws("OUTPUT_PUBLISH_EXISTS",()=>OutputPublication.MoveRunCore(s,f,(a,b)=>calls++,(ms,t)=>{}));
    Check(calls==0&&Directory.Exists(s)&&File.ReadAllText(Path.Combine(f,"existing.txt"))=="keep","Existing run modified");
}));
Test("T175_run_publish_never_overwrites_existing_file",()=>PublishTemp((d,s,f)=>
{
    File.WriteAllText(f,"keep");int calls=0;
    Throws("OUTPUT_PUBLISH_EXISTS",()=>OutputPublication.MoveRunCore(s,f,(a,b)=>calls++,(ms,t)=>{}));
    Check(calls==0&&Directory.Exists(s)&&File.ReadAllText(f)=="keep","Existing file modified");
}));
Test("T176_run_publish_rejects_unrelated_destination",()=>PublishTemp((d,s,f)=>
{
    Throws("OUTPUT_PUBLISH_PATH",()=>OutputPublication.MoveRunCore(s,Path.Combine(d,"other"),(a,b)=>throw new Exception("Must not run"),(ms,t)=>{}));
    Check(Directory.Exists(s),"Invalid request touched source");
}));
Test("T177_pipeline_cancel_after_pdf_preserves_unpublished_files",()=>
{
    string d=Path.Combine(Path.GetTempPath(),"IPP_cancel_pdf_"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(d);
    try
    {
        string b=Path.Combine(d,"base.xlsx"),t=Path.Combine(d,"input_012026.txt"),output=Path.Combine(d,"out");
        SpreadsheetWriter.Write(b,PersonReview.BaselineCopy(Base()));
        File.WriteAllText(t,"KDMA_IDENT;ARBZEIT_PROZ;BETRAG1;BETRAG1_TYP;ANSPRUCHSTYP;Tarifklasse\n1001;100;8000;ATTC_BAV;AKTAN;10\n");
        using var c=new CancellationTokenSource();Exception? caught=null;
        try{new Pipeline().Execute(new(){BaselinePath=b,TxtPaths=new(){t},OutputDirectory=output,CreateContributionDraftPdfs=true},text=>{if(text.StartsWith("Dokumentenplan: 1/1",StringComparison.Ordinal))c.Cancel();},c.Token);}catch(OperationCanceledException ex){caught=ex;}
        Check(caught is not null,"Cancellation missing");string stage=(string)caught!.Data["RunDirectory"]!;
        Check(Path.GetFileName(stage).StartsWith(".inprogress_",StringComparison.Ordinal)&&!Directory.GetDirectories(output,"IPP_Run_*").Any(),"False completed run");
        Check(Directory.GetFiles(Path.Combine(stage,ContributionDocuments.FolderName),"*.pdf").Length==1,"Evidence deleted");
        using var failed=JsonDocument.Parse(File.ReadAllText(Path.Combine(stage,"FAILED.json")));
        Check(failed.RootElement.GetProperty("status").GetString()=="FAILED_NOT_PUBLISHED"&&failed.RootElement.TryGetProperty("hresult",out _),"Failure diagnosis absent");
    }finally{Directory.Delete(d,true);}
});
Test("T178_closed_progress_view_cannot_invalidate_completed_run",()=>
{
    string d=Path.Combine(Path.GetTempPath(),"IPP_publish_view_"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(d);
    try
    {
        string b=Path.Combine(d,"base.xlsx"),t=Path.Combine(d,"input_012026.txt"),output=Path.Combine(d,"out");
        SpreadsheetWriter.Write(b,PersonReview.BaselineCopy(Base()));
        File.WriteAllText(t,"KDMA_IDENT;ARBZEIT_PROZ;BETRAG1;BETRAG1_TYP;ANSPRUCHSTYP;Tarifklasse\n1001;100;8000;ATTC_BAV;AKTAN;10\n");
        var o=new Pipeline().Execute(new(){BaselinePath=b,TxtPaths=new(){t},OutputDirectory=output},text=>{if(text.StartsWith("Beitragsexport erstellt.",StringComparison.Ordinal))throw new InvalidOperationException("Synthetic closed view");});
        Check(Directory.Exists(o.Directory)&&!Directory.GetDirectories(output,".inprogress_*").Any()&&!File.Exists(Path.Combine(o.Directory,"FAILED.json")),"Successful commit invalidated");
    }finally{Directory.Delete(d,true);}
});
Test("T179_1040_synthetic_persons_six_months_inmemory_pdf_stress",()=>
{
    var rows=Enumerable.Range(0,1040).Select(i=>{var b=BaseRow();b["ClientID"]=(2000+i).ToString(Parse.Inv);return b;}).ToList();
    var table=new InputTable("Tabelle1",rows[0].Keys.ToList(),rows,false);
    var months=Enumerable.Range(1,6).Select(m=>Month(m,rows.Select(b=>Row(id:(string)b["ClientID"]!)).ToArray())).ToArray();
    var r=ReviewRun(table,months);var hashes=new HashSet<string>(StringComparer.Ordinal);
    string sourceHash=Convert.ToHexString(SHA256.HashData(JsonSerializer.SerializeToUtf8Bytes(r,JsonFiles.Options)));
    foreach(var person in r.Persons)
    {
        var pdf=DraftPdf.Render(person.ClientId,ContributionDocuments.PersonLines(r,person,sourceHash));
        Check(Encoding.ASCII.GetString(pdf.Bytes).StartsWith("%PDF-1.4",StringComparison.Ordinal)&&pdf.Pages>=1,"Invalid PDF bytes");
        Check(hashes.Add(Convert.ToHexString(SHA256.HashData(pdf.Bytes))),"Duplicate person PDF");
    }
    Check(hashes.Count==1040&&!r.PdfAuthorized&&r.IppMappingStatus=="NOT_BOUND","Stress count/authority");
});
Test("T180_output_hash_matches_file_and_missing_file_never_fabricates_hash",()=>
{
    string d=Path.Combine(Path.GetTempPath(),"IPP_hash_"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(d);
    try
    {
        string p=Path.Combine(d,"data.txt");File.WriteAllText(p,"synthetic");
        Check(OutputPublication.HashOutput(p,null,default)==Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(p))),"Hash mismatch");
        bool missing=false;try{OutputPublication.HashOutput(Path.Combine(d,"missing.txt"),null,default);}catch(FileNotFoundException){missing=true;}
        Check(missing,"Missing file accepted");
    }finally{Directory.Delete(d,true);}
});


// V0.4.0: explicit provisional calculation and static template JSON capture.
ContributionResult ProvisionalRun(InputTable? b, params MonthFile[] months) => new ContributionEngine().Run(b ?? Base(),months,new(){ReviewTariffIssues=true,CalculateMissingTariffProvisionally=true});
Test("T181_missing_initial_tariff_computes_baseline_provisionally",()=>
{
    var r=ProvisionalRun(null,Month(1));var m=r.Persons.Single().Months[1];
    Equal(m.Attc,8000);Equal(m.Amount,ContributionFormula.Calculate(8000,100,new(2026,1,1)));
    Check(m.AmountIsProvisional&&m.EffectiveTariff is null&&r.TariffReview!.OpenMonthCases==1,"Missing tariff falsely approved");
});
Test("T182_empty_tariff_current_salary_computes_provisionally",()=>
{
    var m=ProvisionalRun(null,Month(1,Row(tariff:null,attc:"9750"))).Persons[0].Months[1];
    Equal(m.Amount,ContributionFormula.Calculate(9750,100,new(2026,1,1)));Check(m.AttcSource=="TXT_ATTC_BAV_AKTAN"&&m.AmountIsProvisional,"Source lost");
});
Test("T183_missing_tariff_carry_salary_without_backfilling_tariff",()=>
{
    var r=ProvisionalRun(null,Month(1),Month(2),Month(3,Row(tariff:"99")));var p=r.Persons[0];
    Check(p.Months[1].AmountIsProvisional&&p.Months[2].AmountIsProvisional&&p.Months[1].EffectiveTariff is null,"Backfilled tariff");
    Check(p.Months[3].Amount is null&&p.Months[3].Attc is null,"99 lost");
});
Test("T184_known_98_and_99_still_excluded_with_new_mode",()=>
{
    var p=ProvisionalRun(null,Month(1,Row(tariff:"98")),Month(2,Row(tariff:"99"))).Persons[0];
    Check(p.Months.Values.All(m=>m.Amount is null&&m.Attc is null&&!m.AmountIsProvisional),"Excluded tariff allowed");
});
Test("T185_conflicting_tariffs_never_use_provisional_missing_mode",()=>
{
    var m=ProvisionalRun(null,Month(1,Row(),Row(tariff:"99"))).Persons[0].Months[1];
    Check(m.Amount is null&&m.AmountStatus=="HELD_TARIFF_REVIEW"&&m.TariffIssue=="TARIFF_VALUES_CONFLICT","Conflict allowed");
});
Test("T186_invalid_tariff_and_following_missing_column_remain_held",()=>
{
    var p=ProvisionalRun(null,Month(1,Row(tariff:"invalid")),Month(2,Row(tariff:null)) with{TariffColumn=null},Month(3,Row())).Persons[0];
    Check(p.Months[1].Amount is null&&p.Months[2].Amount is null&&p.Months[2].TariffIssue=="TARIFF_UNRESOLVED_AFTER_CONFLICT","Conflict continuity bypassed");
    Check(p.Months[3].Amount is not null&&!p.Months[3].TariffReviewRequired,"New explicit tariff not restored");
});
Test("T187_missing_tariff_column_without_conflict_is_provisional",()=>
{
    var m=ProvisionalRun(null,Month(1,Row(tariff:null)) with{TariffColumn=null}).Persons[0].Months[1];
    Check(m.AmountIsProvisional&&m.TariffIssue=="TARIFF_COLUMN_MISSING","Missing column unresolved");
});
Test("T188_entry_mask_has_priority_over_provisional_calculation",()=>
{
    var b=BaseRow();b["DAT_AD2"]="01.02.2026";var p=ProvisionalRun(Base(b),Month(1),Month(2,Row())).Persons[0];
    Check(p.Months[1].Amount is null&&!p.Months[1].AmountIsProvisional&&p.Months[1].AmountStatus=="BEFORE_DAT_AD2","Entry mask lost");
});
Test("T189_exit_mask_has_priority_over_provisional_calculation",()=>
{
    var r=ProvisionalRun(null,Month(1,Row(tariff:null,claim:"AUGUAN",term:"31.12.2025")));var m=r.Persons[0].Months[1];
    Check(m.Amount is null&&!m.AmountIsProvisional&&r.TariffReview!.OpenMonthCases==0,"Exit mask lost");
});
Test("T190_zero_tzg_and_missing_salary_not_fabricated",()=>
{
    Check(ProvisionalRun(null,Month(1,Row(tariff:null,tzg:"0"))).Persons[0].Months[1].Amount is null,"Zero factor computed");
    var b=BaseRow();b["BaseSalary_1"]=null;Check(ProvisionalRun(Base(b),Month(1)).Persons[0].Months[1].Amount is null,"Salary fabricated");
});
Test("T191_explicit_hold_mode_remains_available",()=>
{
    var r=ReviewRun(null,Month(1));Check(r.Persons[0].Months[1].Amount is null&&r.AmountPolicy==ContributionAmountPolicy.Hold,"Hold mode changed");
});
Test("T192_provisional_requires_review_and_rejects_legacy_allow",()=>
{
    Throws("TARIFF_POLICY_CONFLICT",()=>new ContributionEngine().Run(Base(),new[]{Month(1)},new(){CalculateMissingTariffProvisionally=true}));
    Throws("TARIFF_POLICY_CONFLICT",()=>new ContributionEngine().Run(Base(),new[]{Month(1)},new(){ReviewTariffIssues=true,AllowMissingTariff=true,CalculateMissingTariffProvisionally=true}));
});
Test("T193_provisional_matches_legacy_numeric_missing_tariff_cases",()=>
{
    var months=new[]{Month(1),Month(2,Row(tariff:null,attc:"9100")),Month(3,Row(tariff:null,attc:null)),Month(4,Row())};
    var old=new ContributionEngine().Run(Base(),months,new(){AllowMissingTariff=true}).Persons[0];var now=ProvisionalRun(null,months).Persons[0];
    foreach(int m in old.Months.Keys){Equal(now.Months[m].Attc,old.Months[m].Attc);Equal(now.Months[m].Tzg,old.Months[m].Tzg);Equal(now.Months[m].Amount,old.Months[m].Amount);}
});
Test("T194_xlsx_numeric_provisional_amount_and_per_month_status",()=>
{
    var r=ProvisionalRun(null,Month(1));var s=SpreadsheetWriter.Contributions(r);int a=s.Headers.IndexOf("Betrag_1"),st=s.Headers.IndexOf("MCR_Betragstatus_1");
    Equal((double?)s.Rows[0][a],r.Persons[0].Months[1].Amount);Check((string?)s.Rows[0][st]==ContributionAmountPolicy.ProvisionalStatus,"Status missing");
    Check(s.ReviewCells.Contains(SpreadsheetReader.Column(a+1)+"2"),"Provisional amount unmarked");
});
Test("T195_pdf_labels_provisional_and_refuses_false_total",()=>
{
    var r=ProvisionalRun(null,Month(1));var lines=ContributionDocuments.PersonLines(r,r.Persons[0],new string('A',64));
    string text=string.Join("\n",lines.Select(l=>l.Text));Check(text.Contains("VORLAEUFIG*")&&text.Contains("Keine Gesamtsumme")&&!text.Contains("Summe genau dieser"),"False complete PDF");
    DraftTemp(r,d=>Check(ContributionDocuments.Write(d,r,true).Created==1,"No provisional draft"));
});
Test("T196_pdf_rejects_forged_provisional_value_or_conflict",()=>
{
    var r=ProvisionalRun(null,Month(1));r.Persons[0].Months[1].Amount+=1;DraftTemp(r,d=>Throws("DRAFT_UNSAFE_AMOUNT",()=>ContributionDocuments.Write(d,r,true)));
    r=ProvisionalRun(null,Month(1));r.Persons[0].Months[1].TariffIssue="TARIFF_VALUES_CONFLICT";DraftTemp(r,d=>Throws("DRAFT_UNSAFE_AMOUNT",()=>ContributionDocuments.Write(d,r,true)));
});
Test("T197_tariff_review_retains_open_case_and_actual_amount_status",()=>
{
    var r=ProvisionalRun(null,Month(1));Check(r.TariffReview!.Cases[0].Open&&r.TariffReview.Cases[0].AmountStatus==ContributionAmountPolicy.ProvisionalStatus&&r.TariffReview.Policy==ContributionAmountPolicy.Provisional,"Review cleared");
});
Test("T198_default_request_enables_visible_provisional_mode",()=>
{
    var o=new RunRequest().Options;Check(o.ReviewTariffIssues&&o.CalculateMissingTariffProvisionally&&!o.AllowMissingTariff,"Request default incorrect");
    var round=JsonSerializer.Deserialize<ContributionOptions>(JsonSerializer.Serialize(o,JsonFiles.Options),JsonFiles.Options)!;
    Check(round.CalculateMissingTariffProvisionally,"Config lost");
});

SourceBlob LayoutFixture(Dictionary<string,string>? extra=null, bool duplicate=false)
{
    const string ns="http://schemas.openxmlformats.org/spreadsheetml/2006/main";
    const string rn="http://schemas.openxmlformats.org/officeDocument/2006/relationships";
    const string pr="http://schemas.openxmlformats.org/package/2006/relationships";
    var parts=new Dictionary<string,string>
    {
        ["xl/workbook.xml"]=$"<workbook xmlns='{ns}' xmlns:r='{rn}'><workbookPr date1904='1'/><sheets><sheet name='Vorlage A' sheetId='1' r:id='r1'/><sheet name='Vorlage B' sheetId='2' state='hidden' r:id='r2'/><sheet name='Vorlage C' sheetId='3' state='veryHidden' r:id='r3'/></sheets><definedNames><definedName name='_xlnm.Print_Area' localSheetId='0'>'Vorlage A'!$A$1:$D$9</definedName></definedNames><externalReferences><externalReference r:id='e1'/></externalReferences></workbook>",
        ["xl/_rels/workbook.xml.rels"]=$"<Relationships xmlns='{pr}'><Relationship Id='r1' Type='{rn}/worksheet' Target='worksheets/sheet1.xml'/><Relationship Id='r2' Type='{rn}/worksheet' Target='worksheets/sheet2.xml'/><Relationship Id='r3' Type='{rn}/worksheet' Target='worksheets/sheet3.xml'/><Relationship Id='ss' Type='{rn}/sharedStrings' Target='sharedStrings.xml'/><Relationship Id='st' Type='{rn}/styles' Target='styles.xml'/><Relationship Id='e1' Type='{rn}/externalLink' Target='externalLinks/externalLink1.xml'/></Relationships>",
        ["xl/sharedStrings.xml"]=$"<sst xmlns='{ns}'><si><r><rPr><b/></rPr><t>Vorlage Ä</t></r></si><si><t>UNUSED_PERSON_SECRET</t></si></sst>",
        ["xl/styles.xml"]=$"<styleSheet xmlns='{ns}'><fonts count='1'><font><name val='Arial'/><sz val='11'/></font></fonts><cellXfs count='1'><xf fontId='0' numFmtId='4'/></cellXfs></styleSheet>",
        ["xl/worksheets/sheet1.xml"]=$"<worksheet xmlns='{ns}' xmlns:r='{rn}'><dimension ref='A1:D9'/><cols><col min='1' max='1' width='21.5' customWidth='1'/></cols><sheetData><row r='1' ht='30' customHeight='1'><c r='A1' t='s' s='0'><v>0</v></c></row><row r='3'><c r='C3'><f t='shared' si='0' ref='C3:C4'>SUM(A3:B3)</f><v>2</v></c><c r='D3' t='inlineStr'><is><r><t>Literal</t></r><r><t> text</t></r></is></c></row><row r='4'><c r='C4'><f t='shared' si='0'/><v>4</v></c></row></sheetData><mergeCells count='1'><mergeCell ref='A1:D1'/></mergeCells><pageMargins left='0.3' right='0.3' top='0.4' bottom='0.4' header='0.2' footer='0.2'/><pageSetup orientation='landscape' paperSize='9'/><headerFooter><oddFooter>Footer</oddFooter></headerFooter><drawing r:id='d1'/></worksheet>",
        ["xl/worksheets/sheet2.xml"]=$"<worksheet xmlns='{ns}'><sheetData/></worksheet>",
        ["xl/worksheets/sheet3.xml"]=$"<worksheet xmlns='{ns}'><sheetData/></worksheet>",
        ["xl/worksheets/_rels/sheet1.xml.rels"]=$"<Relationships xmlns='{pr}'><Relationship Id='d1' Type='{rn}/drawing' Target='../drawings/drawing1.xml'/><Relationship Id='o1' Type='{rn}/oleObject' Target='../embeddings/oleObject1.bin'/></Relationships>",
        ["xl/drawings/drawing1.xml"]="<xdr:wsDr xmlns:xdr='http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing' xmlns:a='http://schemas.openxmlformats.org/drawingml/2006/main'><xdr:oneCellAnchor><xdr:from><xdr:col>0</xdr:col><xdr:row>0</xdr:row></xdr:from><xdr:sp><a:t>Text box</a:t></xdr:sp></xdr:oneCellAnchor></xdr:wsDr>",
        ["xl/drawings/_rels/drawing1.xml.rels"]=$"<Relationships xmlns='{pr}'><Relationship Id='img1' Type='{rn}/image' Target='../media/image1.png'/></Relationships>",
        ["xl/externalLinks/externalLink1.xml"]=$"<externalLink xmlns='{ns}' xmlns:r='{rn}'><externalBook r:id='path'><sheetNames><sheetName val='Source'/></sheetNames><sheetDataSet><sheetData><row><cell><v>PRIVATE_EXTERNAL_CACHE</v></cell></row></sheetData></sheetDataSet></externalBook></externalLink>",
        ["xl/externalLinks/_rels/externalLink1.xml.rels"]=$"<Relationships xmlns='{pr}'><Relationship Id='path' Type='{rn}/externalLinkPath' Target='file:///C:/ConfidentialFolder/source.xlsx' TargetMode='External'/></Relationships>",
        ["xl/embeddings/oleObject1.bin"]="PRIVATE_OLE_CONTENT", ["xl/vbaProject.bin"]="PRIVATE_MACRO_CONTENT", ["docProps/core.xml"]="PRIVATE_AUTHOR_DATA"
    };
    if(extra is not null)foreach(var pair in extra)parts[pair.Key]=pair.Value;
    using var ms=new MemoryStream();
    using(var zip=new System.IO.Compression.ZipArchive(ms,System.IO.Compression.ZipArchiveMode.Create,true))
    {
        foreach(var pair in parts){using var sw=new StreamWriter(zip.CreateEntry(pair.Key).Open(),new UTF8Encoding(false));sw.Write(pair.Value);}
        using(var im=zip.CreateEntry("xl/media/image1.png").Open())im.Write(Convert.FromBase64String("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aF9sAAAAASUVORK5CYII="));
        if(duplicate){using var w=new StreamWriter(zip.CreateEntry("xl/styles.xml").Open());w.Write("<x/>");}
    }
    byte[] bytes=ms.ToArray();return new(bytes,new("Synthetic_Three_Templates.xlsx",Convert.ToHexString(SHA256.HashData(bytes)),bytes.Length));
}
Test("T199_template_capture_includes_all_three_hidden_states",()=>
{
    var c=TemplateJsonExport.Capture(LayoutFixture());string text=JsonSerializer.Serialize(c,TemplateJsonExport.Options);
    Check(c.SheetNames.Count==3&&text.Contains("veryHidden")&&text.Contains("Vorlage B")&&!c.Recalculated&&!c.MacrosExecuted,"Missing sheets/scope");
});
Test("T200_template_capture_preserves_print_layout_and_styles",()=>
{
    string t=JsonSerializer.Serialize(TemplateJsonExport.Capture(LayoutFixture()),TemplateJsonExport.Options);
    foreach(string x in new[]{"Print_Area","landscape","pageMargins","21.5","mergeCell","numFmtId","Footer","Text box"})Check(t.Contains(x),"Lost "+x);
});
Test("T201_template_capture_preserves_strings_and_shared_formulas",()=>
{
    string t=JsonSerializer.Serialize(TemplateJsonExport.Capture(LayoutFixture()),TemplateJsonExport.Options);
    foreach(string x in new[]{"Vorlage Ä","Literal text","SUM(A3:B3)","C3:C4","formulaCacheUnverified"})Check(t.Contains(x),"Lost "+x);
});
Test("T202_template_capture_excludes_macro_ole_unused_strings_and_external_cache",()=>
{
    string t=JsonSerializer.Serialize(TemplateJsonExport.Capture(LayoutFixture()),TemplateJsonExport.Options);
    foreach(string x in new[]{"PRIVATE_MACRO_CONTENT","PRIVATE_OLE_CONTENT","UNUSED_PERSON_SECRET","PRIVATE_EXTERNAL_CACHE","PRIVATE_AUTHOR_DATA","ConfidentialFolder"})Check(!t.Contains(x),"Leaked "+x);
    Check(t.Contains("source.xlsx")&&t.Contains("externalPathSha256"),"Link metadata missing");
});
Test("T203_template_images_separate_and_hash_bound",()=>
{
    var c=TemplateJsonExport.Capture(LayoutFixture());Check(c.Assets.Count==1,"Image missing");var image=c.Assets[0];
    Check(Convert.ToHexString(SHA256.HashData(Convert.FromBase64String(image["base64"]!.GetValue<string>())))==image["sha256"]!.GetValue<string>(),"Image hash");
    Check(!JsonSerializer.Serialize(c.Records).Contains("iVBORw0"),"Image bloats initial layout report");
});
Test("T204_template_rejects_duplicate_paths_and_source_hash_mismatch",()=>
{
    Throws("TEMPLATE_PATH",()=>TemplateJsonExport.Capture(LayoutFixture(duplicate:true)));
    var b=LayoutFixture();Throws("TEMPLATE_SOURCE_HASH",()=>TemplateJsonExport.Capture(b with{Info=b.Info with{Sha256=new string('0',64)}}));
});
Test("T205_template_rejects_unsafe_paths_and_unsupported_binary_workbook",()=>
{
    Throws("TEMPLATE_PATH",()=>TemplateJsonExport.Capture(LayoutFixture(new(){["../escape.xml"]="x"})));
    var b=LayoutFixture();Throws("TEMPLATE_FORMAT",()=>TemplateJsonExport.Capture(b with{Info=b.Info with{Name="input.xlsb"}}));
});
Test("T206_template_dtd_is_never_processed",()=>
{
    var b=LayoutFixture(new(){["xl/styles.xml"]="<!DOCTYPE x [<!ENTITY e SYSTEM 'file:///must-not-read'>]><x>&e;</x>"});
    bool rejected=false;try{TemplateJsonExport.Capture(b);}catch(System.Xml.XmlException){rejected=true;}
    Check(rejected,"DTD accepted");
});
Test("T207_template_capture_cancellation_before_read",()=>
{
    using var c=new CancellationTokenSource();c.Cancel();bool rejected=false;try{TemplateJsonExport.Capture(LayoutFixture(),c.Token);}catch(OperationCanceledException){rejected=true;}Check(rejected,"Cancel ignored");
});
Test("T208_template_transport_fragments_roundtrip_with_unicode",()=>
{
    var record=new System.Text.Json.Nodes.JsonObject{["text"]=string.Concat(Enumerable.Repeat("\"Ä😀\\\n",5000))};
    var frames=TemplateJsonExport.Frames(new[]{record});Check(frames.Count>1,"No splitting");
    string text=string.Concat(frames.Select(f=>f["jsonTextFragment"]!.GetValue<string>()));
    Check(text==record.ToJsonString(TemplateJsonExport.Options),"Transport truncated");
    Check(Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(text)))==frames[0]["recordSha256"]!.GetValue<string>(),"Record hash");
    foreach(var f in frames)using(JsonDocument.Parse(f.ToJsonString())){}
});
Test("T209_template_export_produces_manifest_valid_json_and_unchanged_source",()=>
{
    string d=Path.Combine(Path.GetTempPath(),"IPP_layout_"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(d);
    try
    {
        var b=LayoutFixture();string input=Path.Combine(d,b.Info.Name);File.WriteAllBytes(input,b.Bytes);
        var o=TemplateJsonExport.Export(input,Path.Combine(d,"out"));Check(o.Sheets==3&&o.Assets==1&&o.LayoutParts>0&&o.ImageParts>0,"Export counts");
        Check(Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(input)))==b.Info.Sha256,"Source written");
        foreach(var p in Directory.GetFiles(o.Directory,"*.json"))using(JsonDocument.Parse(File.ReadAllText(p))){}
        using var j=JsonDocument.Parse(File.ReadAllText(Path.Combine(o.Directory,"Manifest.json")));
        foreach(var e in j.RootElement.EnumerateArray())Check(e.GetProperty("sha256").GetString()==Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(Path.Combine(o.Directory,e.GetProperty("file").GetString()!)))),"Manifest mismatch");
    }finally{Directory.Delete(d,true);}
});
Test("T210_template_image_parts_do_not_imply_pdf_activation",()=>
{
    var c=TemplateJsonExport.Capture(LayoutFixture());Check(!c.ExactPdfLayoutCertified&&c.Notices.Count>=3,"False template activation");
    Check(c.Records.Any(x=>x["kind"]!.GetValue<string>()=="coverage"),"Capture gaps not listed");
});
Test("T211_default_pipeline_counts_provisional_without_approving_tariff",()=>
{
    string d=Path.Combine(Path.GetTempPath(),"IPP_provisional_"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(d);
    try
    {
        string b=Path.Combine(d,"base.xlsx"),t=Path.Combine(d,"test_012026.txt");SpreadsheetWriter.Write(b,PersonReview.BaselineCopy(Base()));
        File.WriteAllText(t,"KDMA_IDENT;ARBZEIT_PROZ;BETRAG1;BETRAG1_TYP;ANSPRUCHSTYP;Tarifklasse\n1001;100;8000;ATTC_BAV;AKTAN;\n");
        var o=new Pipeline().Execute(new(){BaselinePath=b,TxtPaths=new(){t},OutputDirectory=Path.Combine(d,"out"),CreateContributionDraftPdfs=true});
        Check(o.ProvisionalAmounts==1&&o.HeldTariffAmounts==0&&o.OpenTariffMonths==1&&o.DraftPdfsCreated==1&&o.PdfStatus=="NOT_AUTHORIZED","Provisional pipeline state");
    }finally{Directory.Delete(d,true);}
});
Test("T212_known_tariff_results_unchanged_by_provisional_mode",()=>
{
    var months=new[]{Month(1,Row()),Month(2,Row(attc:"12000",tzg:"80")),Month(3,Row(tariff:"99")),Month(4,Row(tariff:"10"))};
    var a=ReviewRun(null,months).Persons[0];var b=ProvisionalRun(null,months).Persons[0];
    foreach(int m in a.Months.Keys){Equal(a.Months[m].Attc,b.Months[m].Attc);Equal(a.Months[m].Amount,b.Months[m].Amount);Check(!b.Months[m].AmountIsProvisional,"Known tariff marked provisional");}
});


string UvaTemplatePath()=>Path.Combine(root,"config","templates","UVA_OHNE_ZINS_V1.json");
Test("T213_integrated_uva_template_json_identity",()=>
{
    var d=UvaTemplateLoader.Load(UvaTemplatePath());
    Check(d.TemplateId=="UVA_OHNE_ZINS_DE_V1"&&d.Source.Sha256=="B750B8A7770CD6F2FE492533A4226FE5ED129633A55B5047400F9A9D4161233F"&&d.Pages.Count==3&&!d.Safety.ProductionAuthorized,"Template identity/authority");
});
Test("T214_uva_preview_not_applicable_without_exit",()=>
{
    var r=ReviewRun(null,Month(1,Row()));
    string d=Path.Combine(Path.GetTempPath(),"IPP_uva_na_"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(d);
    try{var rep=UvaTemplateDocuments.Write(d,r,true,UvaTemplatePath());Check(rep.Created==0&&rep.NotApplicable==1&&rep.Status=="UVA_PREVIEW_NO_APPLICABLE_PERSONS","No-exit template misuse");}
    finally{Directory.Delete(d,true);}
});
Test("T215_uva_preview_creates_three_pages_and_mapping_gaps",()=>
{
    var b=BaseRow();b["TerminationDate"]="15.06.2026";b["Gender"]="M";b["JoiningDate"]="01.01.2020";var r=ReviewRun(Base(b),Month(1,Row(term:"15.06.2026",claim:"AUGUAN")));
    string d=Path.Combine(Path.GetTempPath(),"IPP_uva_pdf_"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(d);
    try{var rep=UvaTemplateDocuments.Write(d,r,true,UvaTemplatePath());var item=rep.Items.Single();Check(rep.Created==1&&item.Pages==3&&item.MissingProductionFields>0&&rep.WithMappingGaps==1,"Preview/gaps");Check(File.ReadAllBytes(Path.Combine(d,item.File!.Replace('/',Path.DirectorySeparatorChar))).AsSpan(0,8).SequenceEqual("%PDF-1.4"u8),"PDF header");}
    finally{Directory.Delete(d,true);}
});
Test("T216_uva_open_financial_fields_are_not_zero",()=>
{
    var b=BaseRow();b["TerminationDate"]="15.06.2026";var r=ReviewRun(Base(b),Month(1,Row(term:"15.06.2026",claim:"AUGUAN")));
    var f=UvaPersonFields.Bind(UvaTemplateLoader.Load(UvaTemplatePath()),r,r.Persons.Single());
    foreach(string key in new[]{"Saldovortrag","Beitragsbereitstellung","Zins","Todesfallkapital"}){var x=f.Single(v=>v.Key==key);Check(x.Display=="OFFEN"&&x.Status!="BOUND","False zero/binding "+key);}
});
Test("T217_txt_identity_enrichment_supports_template_address",()=>
{
    var b=BaseRow();b["TerminationDate"]="15.06.2026";var row=Row(term:"15.06.2026",claim:"AUGUAN");row["GESCHLECHT"]="M";row["STRASSE"]="Musterweg";row["HAUSNUMMER"]="7";row["PLZ_STRASSE"]="80331";row["ORT"]="Muenchen";
    var r=ReviewRun(Base(b),Month(1,row));var p=r.Persons.Single();Check((string?)p.Master["Street"]=="Musterweg"&&(string?)p.Master["HouseNumber"]=="7"&&(string?)p.Master["PostalCode"]=="80331"&&(string?)p.Master["City"]=="Muenchen","TXT enrichment");
});
Test("T218_half_year_never_claims_contribution_provision",()=>
{
    var b=BaseRow();b["TerminationDate"]="15.06.2026";var months=Enumerable.Range(1,6).Select(m=>Month(m,Row(term:"15.06.2026",claim:"AUGUAN"))).ToArray();var r=ReviewRun(Base(b),months);
    var x=UvaPersonFields.Bind(UvaTemplateLoader.Load(UvaTemplatePath()),r,r.Persons.Single()).Single(v=>v.Key=="Beitragsbereitstellung");Check(x.Display=="OFFEN"&&x.Source.Contains("6/12"),"Half year promoted to annual provision");
});
Test("T219_full_year_complete_amounts_are_candidate_not_approved",()=>
{
    var b=BaseRow();b["TerminationDate"]="31.12.2026";var months=Enumerable.Range(1,12).Select(m=>Month(m,Row(term:"31.12.2026",claim:"AUGUAN"))).ToArray();var r=ReviewRun(Base(b),months);
    var x=UvaPersonFields.Bind(UvaTemplateLoader.Load(UvaTemplatePath()),r,r.Persons.Single()).Single(v=>v.Key=="Beitragsbereitstellung");Check(x.Display!="OFFEN"&&x.Status=="CANDIDATE_NOT_APPROVED","Candidate provision gate");
});
Test("T220_pipeline_writes_uva_full_run_preview_artifacts",()=>
{
    string d=Path.Combine(Path.GetTempPath(),"IPP_uva_pipeline_"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(d);
    try
    {
        string b=Path.Combine(d,"base.xlsx"),t=Path.Combine(d,"change_012026.txt");var br=BaseRow();br["TerminationDate"]="15.06.2026";br["Gender"]="M";SpreadsheetWriter.Write(b,new OutputSheet("Bestand",br.Keys.ToList(),new(){br.Values.ToList()}));
        File.WriteAllText(t,"KDMA_IDENT;ARBZEIT_PROZ;BETRAG1;BETRAG1_TYP;ANSPRUCHSTYP;Tarifklasse;GESCHLECHT;STRASSE;HAUSNUMMER;PLZ_STRASSE;ORT;DAT_AUSTRITT\n1001;100;8000;ATTC_BAV;AUGUAN;10;M;Musterweg;7;80331;Muenchen;15.06.2026\n");
        var o=new Pipeline().Execute(new(){BaselinePath=b,TxtPaths=new(){t},OutputDirectory=Path.Combine(d,"out"),CreateUvaTemplatePreviewPdfs=true,UvaTemplateJsonPath=UvaTemplatePath()});
        Check(o.UvaTemplatePdfsCreated==1&&o.UvaTemplateWithMappingGaps==1&&File.Exists(Path.Combine(o.Directory,"UVA_Dokumentenplan.xlsx"))&&Directory.GetFiles(Path.Combine(o.Directory,UvaTemplateDocuments.FolderName),"*.pdf").Length==1,"Pipeline UVA artifacts");
    }finally{Directory.Delete(d,true);}
});

Test("T221_excel_legal_wide_columns_are_accepted",()=>
{
    var sheet=new OutputSheet("Breiten",new(){"A","B","C"},new(){new(){"x","y","z"}}){ReviewLayout=true,ColumnWidths=new(){8,55,255}};
    var xml=SpreadsheetWriter.SheetXml(sheet);
    var widths=xml.Descendants(SpreadsheetReader.Main+"col").Select(x=>double.Parse((string)x.Attribute("width")!,Parse.Inv)).ToArray();
    Check(widths.SequenceEqual(new[]{8d,55d,255d}),"Gueltige Excel-Spaltenbreiten wurden veraendert oder abgelehnt");
});
Test("T222_invalid_column_widths_still_fail_closed",()=>
{
    Throws("OUTPUT_WIDTHS",()=>SpreadsheetWriter.SheetXml(new OutputSheet("Breite",new(){"A"},new(){new(){"x"}}){ColumnWidths=new(){256}}));
    Throws("OUTPUT_WIDTHS",()=>SpreadsheetWriter.SheetXml(new OutputSheet("Breite",new(){"A"},new(){new(){"x"}}){ColumnWidths=new(){double.NaN}}));
});

Directory.CreateDirectory(Path.Combine(root,"evidence","local"));
string report=Path.Combine(root,"evidence","local","csharp_tests.json");
var failures=results.Count(r=>r.Error is not null);
JsonFiles.Write(report,new { status=failures==0?"PASS":"FAIL",utc=DateTimeOffset.UtcNow,runtime=System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription,operatingSystem=System.Runtime.InteropServices.RuntimeInformation.OSDescription,tests=results.Count,passed=results.Count-failures,failed=failures,vectorComparisons,fullPythonWorkflowParityCertified=false,realExcelComTested=false,details=results.Select(r=>new{name=r.Name,passed=r.Error is null,error=r.Error}) });
var junit=new XDocument(new XElement("testsuite",new XAttribute("name","MCR_IPP"),new XAttribute("tests",results.Count),new XAttribute("failures",failures),results.Select(r=>new XElement("testcase",new XAttribute("name",r.Name),r.Error is null?null:new XElement("failure",r.Error)))));
junit.Save(Path.Combine(root,"evidence","local","csharp_tests.junit.xml"));
Console.WriteLine($"\n{results.Count-failures}/{results.Count} tests; {vectorComparisons} vector comparisons; failures={failures}");
return failures==0?0:1;
