# MCR IPP 0.5.1 – Spaltenbreiten-Hotfix

## Ursache
Der lokale Windows-Build von V0.5.0 war erfolgreich (0 Warnungen, 0 Fehler), aber 11/220 Tests brachen mit `OUTPUT_WIDTHS / Ungueltige Spaltenbreiten.` ab.

Die Ursache lag im XLSX-Writer: Er akzeptierte nur Breiten von 8 bis 40, waehrend die neue UVA-Pruef-/Feldluecken-Ausgabe bewusst Spaltenbreiten 42 und 55 verwendet. Diese Werte sind als Excel-Spaltenbreiten zulaessig. Der Fehler lag daher in der internen MCR-Validierung, nicht in den Eingabe- oder Personendaten.

## Fix
`SpreadsheetWriter` akzeptiert jetzt endliche Breiten von 8 bis 255. Nichtendliche Werte, Breiten unter 8, Breiten ueber 255 und eine falsche Anzahl an Breiten werden weiterhin fail-closed abgelehnt.

## Scope
Keine Beitragsformel, Tarifregel, Personenpruefung, UVA-Feldbindung oder PDF-Semantik wurde durch diesen Hotfix geaendert.

## Neue Regressionstests
- T221: Breiten 8 / 55 / 255 werden akzeptiert und unveraendert serialisiert.
- T222: 256 und NaN bleiben `OUTPUT_WIDTHS`.

V0.5.1 muss lokal erneut ueber `START.cmd` gebaut und getestet werden.
