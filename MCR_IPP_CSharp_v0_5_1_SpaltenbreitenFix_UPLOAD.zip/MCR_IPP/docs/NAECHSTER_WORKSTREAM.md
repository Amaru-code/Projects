## Aktueller Schritt V0.5.1

Die drei vom Nutzer zusammengestellten Vorlagen werden zunächst statisch nach JSON
exportiert; tatsächliche Inhalte und Fallauswahl sind noch nicht bekannt. Kein
Vorlagenersatz aus Vermutungen. Anschließend Layout-/Feldvertrag und Realdatenvergleich.

# Naechster Workstream: IPP-Uebergabe und echte Bescheinigung

## Jetzt implementierter Weg

Bestandsvorlage + Monats-TXT -> Personenpruefung -> Tarifpruefung und ATTC-Fallback
-> Ergebnis.xlsx / Beitrags-Snapshot -> Dokumentenplan -> interne Monats-PDFs je
Ergebnisperson. Die optionale IPP-Kopie wird nur mit Zusatzblaettern vorbereitet.

## Warum die Monats-PDFs noch keine IPP-LNW sind

Eine echte Bescheinigung benoetigt mehr als die Monatsbetraege. Nicht durch dieses
Update entschieden sind:

1. Beitragsbereitstellung: Zeitraum, Aufsummierung, Cent-/Euro-Rundung, Korrekturen.
   Die bisherige AF-Verknuepfung ist nicht hinreichend durch die Halbjahresdatei belegt.
2. Stammdaten und Salden: ClientID/WWID/Versorgungsteil, Stichtag und Herkunft von
   Basis-/Schattensalden sowie Initialbausteinen/Garantierenten. Keine Nullersatzsalden.
3. Dokumentauswahl: UVA, verfallbar oder LNW; Sprache und genaues Vorlageblatt;
   pruefbare Auswahl des Personenbereichs statt manueller ActiveSheet-Annahme.
4. Rechen-/Layoutreferenz: gepruefte Funkt_EBC-Funktionen Alter/UnverfD,
   reparierte und belegte Formelbezuge, Referenzberechnung und Referenz-PDF.

Der naechste Codebaustein soll ein versionierter IPP-Uebergabevertrag plus Validator
sein. Er darf nur bestaetigte Felder in eine frische Arbeitskopie schreiben und muss
bei fehlendem Pflichtwert den jeweiligen Dokumentfall nennen. Erst nach Vergleich
mit einer fachlich bestaetigten Beispielbescheinigung darf Excel-COM die echte
Bescheinigung pro Person ausgeben. DC-Dateien bleiben ausserhalb dieses Scopes.

Keine Suche durch fremde Projekte und keine Aktivierung unbekannter Add-ins.
Die bereits bereitgestellten IPP-Audits bleiben Grundlage. Offene Mappings werden
nicht durch heuristische Summen oder Namensvergleiche ersetzt.

## Technischer Arbeitsplan

- Realdatenparitaet: gleicher Bestand, gleiche TXT-Dateien, Python-Korrekturstand und
  C#; ATTC/TZG/Betraege mit bekannten vs. unbekannten Tarifen getrennt vergleichen.
- Einen bestaetigten IPP-Fall als Referenz von Eingang bis Bescheinigung einfrieren.
- Importspalten aus dokumentierter Quelle zuordnen, Stichtage und Rollen belegen.
- Snapshot-ID + Eingabehashes + Mappingversion fuer jeden PDF-Fall binden.
- Kopie befuellen, berechnen, Identitaet/Fehlerfelder/Summen pruefen, getrennt exportieren.
- Sonderfaelle (98/99, Neueintritt, Austritt, 60/63/65, fehlende Werte) gegen Referenzen testen.

Das ist nicht im V0.3.0-Produktionspfad freigeschaltet. Die ausgelieferten
PDF-Beitragsentwuerfe testen bereits die technisch sichere Personen-/Dateizuordnung,
aber bestaetigen weder Leistungsplan noch Vertragsansprueche.
