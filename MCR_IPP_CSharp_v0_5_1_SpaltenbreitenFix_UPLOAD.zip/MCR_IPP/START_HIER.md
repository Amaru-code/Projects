# MCR IPP V0.5.1 – Start und Update

## Bestehendes Projekt aktualisieren

Programm schließen. ZIP nach
`C:\Users\Amaru-Zegarra\projects\Aktive_Projekte\INTL_UVA_LNW`
entpacken und den enthaltenen **MCR_IPP**-Ordner mit dem vorhandenen zusammenführen.
Enthaltene Projektdateien ersetzen, eigene Quellcodeänderungen vorher sichern.
Kein MCR_IPP/MCR_IPP anlegen. **local, Output, Kundeneingaben und Compiler nicht löschen.**
`local/Personenfreigaben.json` enthält eigene Entscheidungen und bleibt erhalten.

`START.cmd` doppelklicken. Der Starter verwendet den vorhandenen gemeinsamen Compiler,
prüft SDK/Laufzeit, baut und führt 222 Testdefinitionen aus. Erst danach öffnet er die GUI.
Die ZIP enthält keinen Compiler, keine kompilierten EXE und keinen Installer.

## Fehlende Monatsbeträge

Die neue sichtbare Checkbox lautet:
**Fehlender Tarif: Beitrag wie Python VORLAEUFIG berechnen (keine Freigabe)**.
Sie ist standardmäßig an. Derselbe Gehalts-Fallback gilt: Januar BaseSalary_1;
sonst direkte verfügbare Vormonatszelle. Kein Zurückfüllen aus späteren Monaten.

Ist nur der Tarif noch unbekannt, werden aus vorhandenen gültigen ATTC-/TZG-Daten
nun vorläufige Monatsbeiträge berechnet, statt sie allein deshalb leer zu lassen.
`MCR_Betragstatus_n`, JSON, Prüfbericht und PDF kennzeichnen dies ausdrücklich.
Tarif-Prüffälle werden dadurch NICHT erledigt und keine Klassifizierung erfunden.
Unlesbare oder widersprüchliche Tarife (einschließlich ungeklärter Folgemonate),
98/99 sowie bisherige Eingabe-, Eintritts- und Austrittsregeln bleiben gesondert wirksam.
Checkbox aus: alte Variante mit zurückgehaltenen Beiträgen bei offenen Tarifen.

Mit denselben Eingaben einen **neuen Lauf** starten. Alte Ausgaben bleiben unverändert.
`00_LAUF_LESEN.txt` zeigt nun vorläufig berechnete und weiter zurückgehaltene Monate getrennt.
Die bisherigen Monats-PDFs bleiben ENTWURF – INTERN – NICHT VERSENDEN.

## Drei tatsächliche Vorlagen als JSON exportieren

1. Eine Vorlagenkopie mit den drei echten Layouts verwenden, möglichst ohne reale Namen,
   Adressen, Gehälter oder sonstige Kundendaten. Originalvorlagen nicht überschreiben.
2. Die Vorlagenkopie in Excel schließen.
3. In MCR **Vorlagen nach JSON...** klicken oder **VORLAGEN_JSON.cmd** doppelklicken.
4. Genau diese neue Datei mit den drei Vorlagen auswählen. Nicht die Bestandsdatei,
   nicht Ergebnis.xlsx und nicht automatisch die alte IPP-Kopie auswählen.
5. Datenschutzhinweis bestätigen. Notepad öffnet 00_START_HIER.txt, Explorer den Exportordner.

Alternativ ein einzelner PowerShell-Befehl (nach Entpacken des Updates):
```
& "$env:USERPROFILE\projects\Aktive_Projekte\INTL_UVA_LNW\MCR_IPP\VORLAGEN_JSON.cmd"
```

Export liegt unter `%LOCALAPPDATA%/MCR_IPP_Vorlagenexport/IPP_Run_Vorlagen_...`.
Zuerst **00_START_HIER.txt** und **VORLAGEN_TEIL_001.json** usw. in Reihenfolge prüfen
und per Copy/Paste übermitteln. **BILDER_TEIL_...json** zunächst behalten; nur bei Bedarf
separat übertragen. Vorlagen.json ist die vollständige Text-/Layoutdatei; nicht zusätzlich
zu allen Teilen nochmals übertragen. Jeder Teil ist eigenständig gültiges JSON.
Große Records werden verlustfrei in gehashte Textfragmente zerlegt, nie still gekürzt.

Export kann auch ausgeblendete Zellen/Blätter, vertrauliche Formeln und Bilder enthalten.
Dateinamensbestandteile und Fehlermeldungen prüfen. Keine Garantie der Anonymisierung.
Grenzen: unverschlüsseltes XLSX/XLSM/XLTX/XLTM, 64 MiB Quelldatei, 50.000 gespeicherte
Zellen. Alle regulären Worksheets; andere Blatttypen/ausgelassene Bestandteile werden
benannt. Keine Makros, OLE/ActiveX-Inhalte, externen Cache-Daten oder Schriftdateien.

Dieser Export aktiviert die drei Layouts **noch nicht** als PDF-Vorlagen. Nach der
Auswertung müssen Felder und Auswahlregeln der drei Varianten sowie Quellen für
benötigte IPP-Kontowerte festgelegt und an vollständigen Fällen verglichen werden.
Keine beschädigte Formel/fehlende Quelle wird aus allgemeinem Wissen ersetzt.

## Fehler und Prüfung

Bei Buildfehler: evidence/local/DIAGNOSE.txt. Bei Laufabbruch: FAILED.json im temporären
Laufordner. Keine Ordner manuell als erfolgreich umbenennen, keine Rechte erweitern.
Die neue C#-Version und der reale Vorlagenexport müssen lokal getestet werden;
alle in dieser Umgebung ausgeführten Prüfungen sind in evidence/verification.json benannt.


## V0.5.1 Hotfix
Der V0.5.0-Windows-Build war erfolgreich, aber 11/220 Tests scheiterten ausschliesslich an `OUTPUT_WIDTHS`. Ursache: die neue UVA-Pruefausgabe nutzt Breiten bis 55, der interne Writer erlaubte faelschlich maximal 40. V0.5.1 erlaubt endliche Excel-Spaltenbreiten 8..255. Siehe `SPALTENBREITEN_FIX_LESEN.md`.
