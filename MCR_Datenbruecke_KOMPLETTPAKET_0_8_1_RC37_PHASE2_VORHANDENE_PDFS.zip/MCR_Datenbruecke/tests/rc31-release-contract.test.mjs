import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';
import {ROOT} from './helpers.mjs';import {sha256} from '../lib/core.mjs';
import {VERSION} from '../lib/control.mjs';
test('RC31 original RC30 manifest is pinned and upgrade-only',()=>{
 assert.equal(VERSION,'0.8.1-rc.37');
 const p=path.join(ROOT,'tools/reference/complete-0.8.1-rc.30-manifest.json');
 assert.equal(JSON.parse(fs.readFileSync(p)).version,'0.8.1-rc.30');
 assert.equal(sha256(fs.readFileSync(p)),'4961fddef4a3b086b17e78dc2c98fd1e142263800fe40a97eb0296d54099b149');
});
test('RC31 no automatic repeat forward, exact field is mandatory',()=>{
 const s=fs.readFileSync(path.join(ROOT,'lib/forwarding.mjs'),'utf8');
 assert.match(s,/mainForm:persona-assignment-id/);
 assert.doesNotMatch(s,/assigneeFieldPoint|routeAssignee|r\.right>br\.left/);
 assert.match(s,/ASSIGNEE_SELECTION_PROOF/);
 assert.match(s,/VISIBLE_NEW_SUCCESS_MESSAGE/);
});
