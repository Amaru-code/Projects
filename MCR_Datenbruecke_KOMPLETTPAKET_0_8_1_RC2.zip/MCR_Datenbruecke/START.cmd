@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
if not "%errorlevel%"=="0" goto pathError
if exist "%~dp0BETA_UMSTELLUNG_LAEUFT.txt" goto migration
if not exist "%~dp0tools\cli.mjs" goto incomplete
if not exist "%~dp0tools\find-node.cmd" goto incomplete
call "%~dp0tools\find-node.cmd"
if not "%errorlevel%"=="0" goto nodeError
"%MCR_NODE%" "%~dp0tools\cli.mjs" --menu
set "RC=%errorlevel%"
if not "%RC%"=="0" pause
exit /b %RC%
:migration
echo STOP: Softwareumstellung offen. START.cmd aus dem NEUEN separat entpackten Paket starten, Menue 7: Rueckweg.
pause
exit /b 2
:incomplete
echo STOP: ZIP nicht vollstaendig entpackt. Rechtsklick auf ZIP - Alle extrahieren.
pause
exit /b 2
:nodeError
echo STOP: Node.js nicht gefunden. Erwartet: %%USERPROFILE%%\projects\Compiler\javascript\tools\node\node.exe
pause
exit /b 3
:pathError
echo STOP: Projektverzeichnis nicht erreichbar. ZIP vollstaendig entpacken.
pause
exit /b 2
