# Technischer Nachweis und Abgrenzung

## Hashfehler

Der übergebene Generator `makeMultirowMapping()` setzt `generatedAt` standardmäßig
auf `new Date().toISOString()` und hasht den kompletten Payload einschließlich dieses
Feldes. Identische Fachwerte können deshalb bei verschiedenen Läufen unterschiedliche
Payload-Hashes haben. Der neue Test trennt Datei-Integrität und fachliche Semantik;
er verwendet zusätzlich einen festen Zeitpunkt für seine neue synthetische Quelle.
Das produktive Mapping wird NICHT umgeschrieben oder auf einen anderen Stand gesetzt.

## Speicherklick

Die V7-Diagnose meldete sendClicks=1, saveClicks=0. In einem echten Chromium-Test
mit einem umgebrochenen Inline-Link wurde reproduziert, dass die Mitte von
getBoundingClientRect() außerhalb aller tatsächlich anklickbaren Teilrechtecke
liegen kann. Der neue Code wählt ein sichtbares getClientRects()-Rechteck und
prüft mit elementFromPoint(), dass das Ziel dort getroffen wird.

Normative Referenzen: W3C CSSOM View Module, Abschnitt Element.getClientRects /
getBoundingClientRect / Document.elementFromPoint; Chrome DevTools Protocol,
Input.dispatchMouseEvent (Koordinaten relativ zum Hauptframe-Viewport in CSS-Pixeln).

Das reproduziert einen möglichen geometrischen Auslöser des gemeldeten Fehlers;
es behauptet nicht, nachträglich die genaue Geometrie des damaligen Windows-Fensters
zu kennen. Die integrierten E2E-Tests prüfen echte CDP-Mausklicks und event.isTrusted
bei Versand UND Speicherung, einschließlich mehrerer Fensterbreiten.

## Bewusst striktere Schutzregeln

- Fehlende Quelle ist nicht mehr stillschweigend E-MAIL.
- Geöffnete Ticket-ID wird vor Bearbeitung und vor Send/Save erneut gebunden.
- Empfänger, Member, Beschreibung und Antwort werden vor dem Versand erneut geprüft.
- Eine bestehende nichtleere Antwort wird nicht überschrieben.
- Ein unbekannter Versandstatus löst keinen automatischen zweiten Klick aus.
- Persistentes Journal ergänzt den bisherigen nur im RAM vorhandenen Doppelversandschutz.

## Paket und Daten

Das Update ersetzt nur bekannte Softwareeinträge. Config, private_data, .runtime,
diagnostics und weitere lokale Archive werden nicht verschoben. Neue Kontrollbelege
werden unter .runtime/beta-control hinzugefügt; die alte last-run.json wird dabei
nicht als erledigt markiert. Der normale START erfordert keinen Download alter Runner.

Die Dateisystemtests verwenden explizit synthetische Installationsbäume und injizierte
Fehler. Sie sind kein behaupteter Test des Firmen-Windows oder des echten Browserprofils.


## RC2 – Übergang von RC1 mit alten Beta-4-Dateien

- Aktive Paketprüfung bleibt strikt; kein `allowUnsealed`-Schalter.
- `verifyPrevious()` erkennt das veröffentlichte RC1-Manifest anhand seines festen Hashs.
- Vorhandene versiegelte Dateien werden vollständig bytegeprüft, bevor bekannte Altdateien zugelassen werden.
- 15 bekannte Beta-4-Restpfade werden nur als archiviertes Update-Eingangsmaterial akzeptiert; Pfad, Größe und Hash müssen übereinstimmen.
- Der bestehende Installer sichert ganze alte Softwareverzeichnisse und ersetzt sie vollständig.
- Rückweg akzeptiert bereits bytegleiche Originaldateien am Ziel, ohne Backups zu überschreiben.
- Neu: 26 zusätzliche Regressionstests mit dem unveränderten, veröffentlichten RC1-ZIP als Ausgangsbestand.
- Runner, Browseraktionen, Identity-Prüfung, Mapping- und Versandlogik unverändert gegenüber Komplettpaket RC1. `lib/control.mjs` ändert nur die Versionskonstante.
