# MCR Datenbruecke 0.8.1 RC2 – Prüfbericht

## Anlass und nachgewiesene Ursache

Nutzermeldung: `STOP UNSEALED_CODE: Unerwartete Programmdatei: lib/mail-download.cjs`.
Das ausgelieferte RC1-ZIP enthält diese frühere Beta-4-Datei nicht. Seine
Paketprüfung prüft zuerst alle versiegelten Dateien, dann zusätzliche Dateien in
`src`, `lib`, `tools`, `tests` und `examples`. Ein zusätzlicher alter Dateibestand
kann deshalb den Start blockieren, obwohl die neuen Dateien vollständig sind.
Die Meldung allein sagt nicht, wie der Mischbestand entstanden ist.

Reproduktion: Originales veröffentlichtes RC1-ZIP, ergänzt ausschließlich um die
im Chat übergebene originale Beta-4-Datei `lib/mail-download.cjs` (1.528 Byte,
SHA-256 `7c2d9d444fc241fe4cb2335df12039a201ef3c27d9b23f9692c2662d3d651ce2`).
Originalprüfung und Original-CLI liefern exakt die gemeldete Sperre. Die alte
Updateprüfung konnte diesen Zustand ebenfalls nicht übernehmen.

## Korrektur

RC2 erkennt den vollständigen, bytegeprüften RC1-Stand als Updatequelle. 15
bekannte überzählige Beta-4-Pfade sind mit Größe und Hash hinterlegt. Nur solche
unveränderten Dateien dürfen Teil des archivierten Ausgangsstands sein. Es gibt
keine Ausnahme für unbekannten oder veränderten Code und keine Ausnahme bei der
normalen Startprüfung. Die alte Software wird vollständig gesichert; die neuen
Programmordner werden anschließend vollständig eingesetzt, nicht zusammengemischt.

Die Rückwegprüfung wurde zusätzlich für Dateien korrigiert, die in Alt- und
Neuversion bytegleich sind. Eine bereits identische Originaldatei am Ziel wird
akzeptiert; ihr geprüftes Backup bleibt erhalten. Keine automatische Löschung
von Bestandsdaten, Browserprofilen oder Versandjournalen.

Gegenüber RC1 bleiben `src/local-bot-full-run.mjs`, die Browseraktionen, Identity-
Prüfung und fachliche Mapping-/Versandlogik byteidentisch. `lib/control.mjs`
ändert lediglich die Versionskonstante. Details: `docs/RC2_AENDERUNGEN.json`.

## Tatsächlich ausgeführte Prüfungen

| Prüfung | Ergebnis |
|---|---|
| Node-Selbsttests insgesamt | 134/134 bestanden, 0 Fehler, 0 übersprungen |
| Davon neue Tests zum Update-/Altdateiproblem | 26/26 bestanden |
| Echter CLI-Start mit nachgestelltem Mischbestand | Vorher Exit 1/UNSEALED_CODE; nach Update neues Menü, Exit 0 |
| Update des gemischten RC1 mit originaler Altdatei | Bestanden; Altdatei im Softwarearchiv, nicht mehr im aktiven Code |
| Sauberes RC1-Update / erneutes Update aktueller Version | Bestanden |
| Unbekannte Dateien, veränderte Altdateien, manipuliertes Manifest | Erwarteter Stopp vor Änderungen |
| Updatefehler und Software-Rückweg | Bestanden; ursprüngliche Software wiederhergestellt |
| Bestandsmapping, Config, Profil-Sentinel, alte Diagnose, Laufstatus und Versandjournal | In Testbeständen erhalten |
| Chromium-Prüfungen | 8/8 bestanden |
| Normale Browserabläufe bei 720, 1280 und 1920 Pixel Breite | Je 2/2 fiktive Tickets; je zwei echte Browser-Sende- und Speicherklicks |
| Absichtlich verkürzte oder fehlende Speicherung | Erwarteter SAVE_UNVERIFIED-Stopp, keine Weiterbearbeitung |
| CLI-Demo des Komplettpakets | 2/2 fiktive Tickets; DEMO_GESAMTPAKET_2_TICKETS bestanden |

Die Browserprüfungen wurden vollständig neu ausgeführt. Ein erster äußerer
Werkzeugaufruf wurde vom Zeitlimit beendet; er wurde nicht als bestandene Suite
gewertet. Die vollständige Wiederholung endete mit 8/8 bestandenen Prüfungen.
Die anfänglich neu entdeckten Rückweg-Kollisionen wurden korrigiert und die
vollständigen Selbsttests danach erneut ausgeführt.

## Installation

Das ZIP in einen **neuen Ordner** entpacken. `START.cmd` aus diesem neuen Ordner,
Menü 1 wählen, vorhandenen Projektpfad übernehmen. Bei bekannten Altdateien
erscheint `PASS BEKANNTE_BETA4_ALTDATEIEN_VERIFIZIERT`. Nach Tests mit `EINRICHTEN`
bestätigen. Das Ergebnis muss `PASS INSTALLATION_COMPLETE` sein. Danach wieder
`START.cmd` im bestehenden Projektordner benutzen.

Nicht selbst `mail-download.cjs` oder weitere Dateien löschen. Das Manifest nicht
ändern. Den neuen Ordner nicht über den bisherigen Ordner kopieren. Die Sicherung
liegt unter `_MCR_Archiv/complete_<Zeitpunkt>/software`. Ein Rückweg zu einem zuvor
gesperrten Mischbestand stellt diesen exakt wieder her und behauptet keine
wiedergewonnene Startfähigkeit.

## Grenzen

Prüfumgebung: Linux, Node.js und Chromium. Windows-CMD, Windows-CIM-Prozessprüfung
und echtes COMARCH wurden hier nicht ausgeführt. Die echten Windows-Prozessprüfungen
bleiben im ausgelieferten Installer aktiv. Die Migrationstests benutzen synthetische
Benutzerdaten, nicht die Bestandsdaten des Nutzers. Erst ein erfolgreicher echter
Einzelticket-Pilot erlaubt den regulären Lauf. Frühere ungeklärte Versandzustände
werden durch dieses Update nicht freigegeben.
