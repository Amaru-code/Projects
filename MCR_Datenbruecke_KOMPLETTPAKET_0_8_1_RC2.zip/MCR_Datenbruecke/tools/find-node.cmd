@echo off
set "MCR_NODE="
if exist "%USERPROFILE%\projects\Compiler\javascript\tools\node\node.exe" set "MCR_NODE=%USERPROFILE%\projects\Compiler\javascript\tools\node\node.exe"
if defined MCR_NODE exit /b 0
for /f "delims=" %%N in ('where node.exe 2^>nul') do if not defined MCR_NODE set "MCR_NODE=%%N"
if defined MCR_NODE exit /b 0
exit /b 1
