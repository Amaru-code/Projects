$ErrorActionPreference = 'Stop'
$root = [System.IO.Path]::GetFullPath($env:MCR_GUARD_ROOT).TrimEnd('\').ToLowerInvariant()
$exclude = [int]$env:MCR_GUARD_EXCLUDE_PID
$blocked = 0
$unknown = 0
Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('node.exe','msedge.exe','chrome.exe','chromium.exe') } | ForEach-Object {
    if ($_.ProcessId -ne $exclude) {
        if ([string]::IsNullOrWhiteSpace($_.CommandLine)) { $unknown++ }
        elseif ($_.CommandLine.ToLowerInvariant().Contains($root)) { $blocked++ }
    }
}
[ordered]@{schema='MCR_PROCESS_GUARD_V1';checked=$true;blockedCount=$blocked;unknownCount=$unknown} | ConvertTo-Json -Compress
