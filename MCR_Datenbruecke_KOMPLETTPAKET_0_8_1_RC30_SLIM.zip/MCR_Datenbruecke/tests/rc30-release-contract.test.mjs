import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';
import {ROOT} from './helpers.mjs';import {sha256} from '../lib/core.mjs';
import {VERSION} from '../lib/control.mjs';
test('RC30 previous RC29 software manifest is pinned byte-for-byte for safe upgrade',()=>{
 const r=path.join(ROOT,'tools/reference/complete-0.8.1-rc.29-manifest.json');
 assert.equal(VERSION,'0.8.1-rc.30');
 assert.equal(JSON.parse(fs.readFileSync(r)).version,'0.8.1-rc.29');
 assert.equal(sha256(fs.readFileSync(r)),'3bda8c968b28f6b181bdec0ec44ef134611ef39c21aca7fae5036d8bc46d4cb3');
});
test('RC30 phase2 remains preview-only: no subprocess/file-upload code in planner',()=>{
 const source=fs.readFileSync(path.join(ROOT,'lib/phase2-account-statement-plan.mjs'),'utf8');
 assert.doesNotMatch(source,/child_process|spawnSync|execSync|\.click\(|dispatchMouseEvent|setFileInputFiles|writeFileSync/);
});
