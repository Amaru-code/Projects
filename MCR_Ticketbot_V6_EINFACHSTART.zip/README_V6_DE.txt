# MCR Ticketbot – Wiederanlauf V6 (21.10.2026)

## Anlass und Root Cause

Am 21.10.2026 meldete Windows nach korrekt geprüfter V5-ZIP-Extraktion und bestandener Runner-/Bestandsprüfung:

`STOPP DEMO_MAPPING_NOT_FICTIONAL: Legacy-Demo-Zeile enthaelt nicht die festgelegten synthetischen ID-/USC-Werte.`

Das **war die neue V5-Vorprüfung**, noch nicht der Originalrunner oder COMARCH. Die V5-Prüfung setzte für **jede** Quellzeile `clientId=99900001` UND `usc=10` voraus. Die archivierte 2/2-Beta-5-Demo beweist lediglich, dass ein synthetischer Member `99900001` verarbeitet wurde und die ZIEL-Beschreibungszeilen `USC 10/ PP+;TPP` und `USC 10/ DB+` erzeugt wurden. Die Original-JSON ist hier nicht vorhanden und beweist nicht, dass alle sonstigen Quelldatensätze diese Werte haben.

V6 korrigiert die fachlich unbelegte Gleichsetzung von *Member des bearbeiteten Tickets*, *USC der resultierenden Ausgabe* und *sämtlichen Legacy-Quellzeilen*.

## Veränderte Vorprüfung

- Die Demo-Datei wird weiterhin ausschließlich aus der Originaldatei `examples/DEMO_mapping.json` gelesen, nie aus `private_data`, aktivem Mapping oder produktiver Excel.
- Die JSON-Struktur `schema/payload/payloadSha256`, die interne SHA256 über `JSON.stringify(payload)`, die erlaubten Spalten, numerischen Flags, Formel- und Pfadverbote bleiben verbindlich.
- Jede Demo-Quellzeile muss eine MercerID aus dem reservierten fiktiven Zahlenraum `999` + 5 bis 9 Ziffern besitzen. **Mehrere fiktive IDs sind erlaubt.** Mindestens eine Zeile muss zur historisch dokumentierten ID `99900001` gehören.
- Jeder Quellzeilen-USC muss eine kurze Ganzzahl sein; verschiedene USC-Werte zwischen Zeilen sind erlaubt. Eine vorhandene Beschreibung muss zum USC **derselben Zeile** passen, nicht pauschal zu USC 10.
- Die ursprüngliche fiktive Mapping-Payload wird **nicht verändert**. Ihre Historienprüfsumme `c147a9eb9c93d5c6d4a47f208c9f98c2afd0b0144cbf63b2c50b1c06676fdc40` wird weiterhin **nach dem Original-Demolauf** als Fingerprint der neu generierten Mehrzeilenabbildung gefordert. Sie ist kein SHA der Datei.
- Auch nach passender Mehrzeilenabbildung sind `DEMO`, exakt **2 fiktive Tickets**, erfolgreiche fiktive Sende-/Speicherprüfungen und störungsfreier Originalrunner obligatorisch. Ein realer Versand wird durch die Demo **nicht** ausgelöst.
- Bei einer Verweigerung liefert `Ergebnis\REPARATUR_ERGEBNIS.json` zusätzlich `demoInspection` mit **ausschließlich Zählern** (Gesamtzeilen, reservierte fiktive IDs, bekannte Demo-ID-Zeilen, numerische USC-Werte). Niemals IDs, Namen, USC-Werte, Pfade oder Mailtexte hochladen.

## Sicherster Start

1. Das beiliegende **äußere Rettungspaket** `MCR_Ticketbot_V6_EINFACHSTART.zip` per Windows „Alle extrahieren“ in einen beliebigen eigenen Ordner entpacken.
2. `START_V6_DEMO.cmd` doppelklicken. Der Starter verifiziert die feste ZIP-SHA-256 des eingebetteten V6-Kits, extrahiert es vollständig unter `%LOCALAPPDATA%\MCR\Ticketbot_Wiederherstellung`, kontrolliert die Verzeichnisstruktur und startet **nur** `DEMO_TESTEN_OHNE_VERSAND.cmd`.
3. Für die Demo müssen die bisherigen Gates und `FICTIONAL_LEGACY_MAPPING_VERIFIED`, `HISTORIC_DEMO_MULTIROW_SHA256_MATCH`, `OFFLINE_DEMO_2_TICKETS_VERIFIED` erscheinen. Erst dann ist **die fiktive Demo auf diesem Laptop** qualifiziert.
4. **Der Demo-Rettungsstarter verschickt niemals echte Mails.** Nur nach vollständigem Demo-PASS und nach bewusster Entscheidung des Nutzers: `JETZT_REPARIEREN_UND_STARTEN.cmd` aus dem vom Starter geöffneten V6-Kit ausführen. Dieser darf dann **höchstens ein echtes Ticket** bearbeiten; keine automatische Freigabe der gesamten INTL01-Warteschlange. Für unbekannte Sende-/Speicherzustände gilt unverändert `REVIEW_REQUIRED` ohne erneuten Versand.

## Abgrenzung

V6 wurde in einer separaten Linux-Testumgebung mit Node 22.16.0 geprüft: **163/163 lokale synthetische Regressionstests PASS**. Der tatsächliche vollständige RC1.1-Runner, die originale Legacy-Demo-Datei sowie COMARCH stehen hier nicht zur Verfügung. Deshalb wird **nicht** behauptet, die Demo sei bereits auf Windows erfolgreich gestartet oder ein Ticket sei verschickt worden. Der ursprüngliche Beta-4-Runner, der geprüfte Identity-Runner, der reparierte Identity-Helper, `START.cmd`, das aktive Mapping und das Browserprofil werden von V6 **nicht geändert**.

## Bleibende harten Stopps

`DEMO_MAPPING_NOT_FICTIONAL`, `DEMO_MAPPING_PRIVATE_REFERENCE`, `DEMO_MAPPING_PAYLOAD_INTEGRITY`, `DEMO_MULTIROW_RESULT_MISMATCH`, `OFFLINE_DEMO_NOT_VERIFIED`, `PREVIOUS_SEND_UNCERTAIN` und `REVIEW_REQUIRED` blockieren weiterhin die automatische Freigabe. Ist der neue datensparsame `demoInspection`-Block vorhanden, bitte nur den Block und die Konsolenmeldung senden; niemals die eigentliche `DEMO_mapping.json` oder personenbezogene COMARCH-Daten.
