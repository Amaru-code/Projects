# MCR DATENBRUECKE 0.8.1-rc.67 – Kompakte Auslieferung

RC67 ist ein vollständiges, kompaktes Softwarepaket zur **direkten Aktualisierung von RC64**.
Es enthält die produktiven Skripte und gezielte aktuelle Tests; historische Release-Referenzen,
veraltete Testprotokolle und historische Upgrade-Tests sind **nicht Bestandteil des Downloads**.
Die vollständige alte Software wird bei der Installation lokal im bestehenden `_MCR_Archiv` gesichert.

## Installation

ZIP in einen NEUEN Ordner entpacken, START.cmd ausführen, Menü 1 wählen und den
bestehenden `MCR_Datenbruecke`-Installationsordner als Ziel verwenden. Danach
**nur** die installierte START.cmd öffnen. Menü 13 ist der Master Run.

## Beibehalten aus RC64 – INTL01-Signatur vor Versand

- Bei ICEfaces-Fokus-/Ajax-Reset wird die Signatur nach erneuter Feldprüfung höchstens einmal erneut anhand des **exakten COMARCH-Vorschlags** ausgewählt.
- Danach werden Signatur und übrige Pflichtfelder erneut stabil geprüft. Ist das nicht möglich, kann ein Bediener die Signatur ausdrücklich aus der COMARCH-Vorschlagsliste wählen; eine Textbehauptung genügt nicht.
- Unbekannte bzw. fremde Signatur: unverändert stoppen, kein Versand. Keine erneute E-Mail bei offenen Versandjournalen.
- Der RC63-Schutz bleibt bestehen: ausschließlich `In_Bearbeitung` und `INTL01`, kein Klick auf fremde Vorgänge.

## Änderungen aus RC63

- Phase 1 darf automatisch nur die Navigationsknoten `In_Bearbeitung` und `INTL01`
  sowie die dazugehörigen exakt benannten Vorgangstabellen verwenden.
  Es gibt **keinen** Fallback auf `Meine Vorgänge`, `Offene Vorgänge`, sonstige
  Tabellen oder unbekannte Tickets. Wenn die Intel-Knoten nicht sichtbar sind,
  wird angehalten, statt andere Vorgänge zu öffnen.
- Der Versandnachweis erlaubt nun die in COMARCH bestätigte Kombination aus
  `secureemail@mmc.com`, neuem Ausgangseintrag und `[MARSH#Ticket-ID]`.
  Er verlangt weiterhin Richtung OUTGOING, identischen Empfänger, neue eindeutige
  Dokument-ID, Standardantworttext und stabile Ticketbindung.
- Die Folgeticket-Öffnung wird ausschließlich an die zuvor geprüfte Intel-Tabelle
  gebunden. `Bearbeiten` wird über mehrere sichere Klickpositionen erreicht.
- Kein zweiter Versand bei ungeklärtem Erfolg. Kein neues Senden von Tickets mit
  früherem offenem `SEND_INTENT`.

## Daten und Grenzen

`private_data`, `config`, `.runtime`, Browserprofile und Ticketjournale bleiben am
installierten Ort und werden vom Installer nicht gelöscht. Programmdateien werden
lokal vor dem Softwarewechsel für den Rückweg archiviert. Dieses ZIP enthält
keine Bestandsdaten und keinen Node-/Edge-Browser. Andere ältere Releaseversionen
als RC64 sind absichtlich keine Updatequelle dieses kompakten Pakets.

Fehlende Prüfergebnisse oder COMARCH-Zwischenzustände dürfen nicht als Erfolg
gewertet werden. Produktive Windows/COMARCH-Prüfung ist nach Installation nötig.

Phase 2: siehe docs/RC67_RELEASE.md. Nach erfolgreicher Phase 1 direkt Menue 12 starten; Menue 13 startet sonst zuerst wieder Phase 1. Alte SEND_INTENT-Journale nur nach SHA-gebundenem gespeichertem Status und einziger dokumentierter ausgehender Antwort automatisch abschliessen.
