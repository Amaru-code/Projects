/** RC67 slim, fail-closed package verifier. Upgrade nur von verifizierten RC64-/RC65-Installationen (SHA-gebunden). Historical releases remain in the local
 * rollback archive, not the distributed executable package. */
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {sha256,requireThat as need} from '../lib/core.mjs';
import {readJSON,plainPath,VERSION} from '../lib/control.mjs';
import {resolveConfig} from '../lib/config.mjs';
const PACKAGE_ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const RC65_MANIFEST_SHA='f8cf24bcb95e68d12209f49bfc602bf0b452102eefb226de4e935c089dfa6512';
const RC64_MANIFEST_SHA='67b836e15f7a11bc9ed8f6cb8e5765396a58da4bf6824db1e7678802c8e65c0e';
const CODE_DIRS=['src','lib','tools','tests','examples'];
export const safeRelative=p=>typeof p==='string'&&p.length>0&&!/[\\:\x00-\x1f]/.test(p)&&!p.startsWith('/')&&!p.split('/').some(x=>!x||x==='.'||x==='..');
export function verifyRecords(root,records,{skipConfig=false}={}){
 need(Array.isArray(records)&&records.length>0&&records.length<2000,'MANIFEST_INVALID','Manifest fehlt/zu gross.');
 const seen=new Set();
 for(const r of records){
  need(r&&safeRelative(r.path)&&!seen.has(r.path.toLowerCase())&&Number.isSafeInteger(r.bytes)&&r.bytes>=0&&/^[a-f0-9]{64}$/.test(r.sha256),'MANIFEST_INVALID','Manifestpfad/Hash falsch.');
  seen.add(r.path.toLowerCase());
  if(skipConfig&&r.path==='config/local-runner-queue-send.json')continue;
  const p=plainPath(path.join(root,...r.path.split('/'))),st=fs.statSync(p);
  need(st.isFile()&&st.size===r.bytes&&st.size<32*1024*1024,'PACKAGE_SIZE','Dateilaenge abweichend: '+r.path);
  need(sha256(fs.readFileSync(p))===r.sha256,'PACKAGE_HASH','Programmdatei abweichend: '+r.path);
 }
 return seen;
}
function verifyCodeTree(root,seen){
 const visited=new Set();let count=0;
 function walk(p,rel){plainPath(p);need(fs.existsSync(p),'CODE_TREE_MISSING','Programmpfad fehlt: '+rel);
  for(const n of fs.readdirSync(p).sort()){
   const f=path.join(p,n),r=rel+'/'+n,k=r.toLowerCase();
   need(++count<=10000&&safeRelative(r)&&!visited.has(k),'CODE_TREE_LIMIT','Unzulaessiger Dateipfad: '+r);
   visited.add(k);plainPath(f);const st=fs.statSync(f);
   if(st.isDirectory()){walk(f,r);continue;}
   need(st.isFile()&&seen.has(k),'UNSEALED_CODE','Nicht manifestierter Programmcode: '+r);
  }
 }
 for(const d of CODE_DIRS)walk(path.join(root,d),d);
}
export function verifyPackage(root,{strictConfig=false}={}){
 plainPath(root);const m=readJSON(path.join(root,'MANIFEST.json'),2*1024*1024);
 need(m.schema==='MCR_COMPLETE_PACKAGE_V1'&&m.package==='MCR_Datenbruecke'&&m.version===VERSION,'PACKAGE_VERSION','Nicht das freigegebene RC67-Paket.');
 need(!m.payload.some(r=>/^tests\/fixtures\/complete-0\.8\.1-rc\.\d+\.zip$/i.test(r.path||'')),'PACKAGE_RECURSION','Kein altes Komplettpaket einbetten.');
 const seen=verifyRecords(root,m.payload,{skipConfig:!strictConfig});verifyCodeTree(root,seen);resolveConfig(root);
 return {version:m.version,files:m.payload.length,manifestSha256:sha256(fs.readFileSync(path.join(root,'MANIFEST.json')))};
}
export function verifyPrevious(root){
 plainPath(root);const m=readJSON(path.join(root,'MANIFEST.json'),2*1024*1024);
 need(m.schema==='MCR_COMPLETE_PACKAGE_V1'&&m.package==='MCR_Datenbruecke','PREVIOUS_COMPLETE_VERSION','Nur unveraenderte RC64-/RC65-/RC67-Installationen erlaubt.');
 const expected=m.version==='0.8.1-rc.65'?RC65_MANIFEST_SHA:m.version==='0.8.1-rc.64'?RC64_MANIFEST_SHA:m.version===VERSION?sha256(fs.readFileSync(path.join(PACKAGE_ROOT,'MANIFEST.json'))):null;
 need(expected,'PREVIOUS_COMPLETE_VERSION','Kompaktes Update von RC64 oder RC65 nach RC67; andere Version erst gesondert migrieren.');
 const digest=sha256(fs.readFileSync(path.join(root,'MANIFEST.json')));
 need(digest===expected,'PREVIOUS_MANIFEST_CHANGED','Bestandssoftware weicht vom unveraenderten Release ab.');
 const seen=verifyRecords(root,m.payload,{skipConfig:true});verifyCodeTree(root,seen);resolveConfig(root);
 return {version:m.version,files:m.payload.length,manifestSha256:digest,state:'COMPLETE_RELEASE_VERIFIED',legacyResiduals:[],authorization:'SOFTWARE_UPDATE_ONLY'};
}
export function treeDigest(root){plainPath(root);const rows=[];let count=0,total=0;
 function visit(p,rel){plainPath(p);const st=fs.statSync(p);need(++count<10000,'TREE_LIMIT','Zu viele Dateien.');
  if(st.isDirectory()){rows.push(['D',rel]);for(const n of fs.readdirSync(p).sort())visit(path.join(p,n),rel?rel+'/'+n:n);}
  else{need(st.isFile()&&st.size<32*1024*1024,'TREE_FILE','Keine normale Softwaredatei.');total+=st.size;need(total<128*1024*1024,'TREE_LIMIT','Software zu gross.');rows.push(['F',rel,st.size,sha256(fs.readFileSync(p))]);}
 }visit(root,'');return sha256(JSON.stringify(rows));}
