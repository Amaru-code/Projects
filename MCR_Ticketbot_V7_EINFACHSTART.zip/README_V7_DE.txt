MCR Ticketbot – Original-Demo-Korrektur V7 (21.10.2026)

1. MCR_Ticketbot_V7_EINFACHSTART.zip herunterladen.
2. ZIP in einen neuen Ordner entpacken, START_V7_DEMO.cmd starten.
3. Der Starter prueft den inneren ZIP-SHA256, entpackt vollstaendig und
   startet AUSSCHLIESSLICH die fiktive Zwei-Ticket-Demo.
4. Die vorhandene ORIGINAL-ZIP RC1.1 muss in Downloads erreichbar sein.
   Wenn eine andere Quelle gefunden wird: im entpackten V7-Kit
   QUELLE_AUSWAEHLEN.cmd starten, Original-RC1.1-ZIP waehlen, dann
   DEMO_TESTEN_OHNE_VERSAND.cmd im SELBEN Kit-Ordner ausfuehren.
5. Bei STOPP die Zeile DEMO_SAVE_PROBE und Ergebnis/REPARATUR_ERGEBNIS.json
   senden, nicht die echten Bestandsdaten. Nach STOPP kein Echtversand.

Fix: V6 waehlt potentiell eine gleichnamige fremde Demo. V7 bindet
Paket/tools/demo/DEMO_mapping.json an den manifestierten Original-SHA256.
Der Kern-Runner und die produktiven Versandsperren werden nicht veraendert.

167/167 Offline-Selbsttests PASS, Windows-/COMARCH-Nachweis noch offen.
