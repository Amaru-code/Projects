@echo off
setlocal DisableDelayedExpansion
title MCR Ticketbot V7 - Nur fiktive Demo

echo.
echo ==============================================================
echo  MCR TICKETBOT V7 - SICHERER WIEDERANLAUF
 echo  NUR ORIGINALE RC1.1 DEMO, KEIN ECHTVERSAND
 echo ==============================================================
echo.

set "MCR_V7_ARCHIVE=%~dp0MCR_Ticketbot_RC11_DEMO_FIX_V7.zip"
set "MCR_V7_EXPECTED_SHA=7cd75e04e9ac67090695f11579fc417054b1939bfc0093566458cb1ecd8331b3"
set "MCR_RESULT=1"
if not exist "%MCR_V7_ARCHIVE%" (
 echo STOPP V7_ARCHIV_FEHLT: Die V7-ZIP muss neben diesem CMD liegen.
 set "MCR_RESULT=11"
 goto finish
)
if not defined LOCALAPPDATA (
 echo STOPP LOCALAPPDATA_NICHT_VERFUEGBAR
 set "MCR_RESULT=12"
 goto finish
)
set "MCR_BASE=%LOCALAPPDATA%\MCR\Ticketbot_Wiederherstellung"
set "MCR_V7_DEST=%MCR_BASE%\V7_%RANDOM%_%RANDOM%"
if exist "%MCR_V7_DEST%" (
 echo STOPP ZIELVERZEICHNIS_BEREITS_BELEGT
 set "MCR_RESULT=13"
 goto finish
)
if not exist "%MCR_BASE%" mkdir "%MCR_BASE%"
if not exist "%MCR_BASE%" (
 echo STOPP BASISPFAD_NICHT_ERSTELLBAR
 set "MCR_RESULT=14"
 goto finish
)
set "MCR_PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%MCR_PS%" (
 echo STOPP WINDOWS_POWERSHELL_NICHT_GEFUNDEN
 set "MCR_RESULT=15"
 goto finish
)
echo INFO  Pruefe V7-ZIP SHA-256 und entpacke neu.
"%MCR_PS%" -NoProfile -NonInteractive -Command "$ErrorActionPreference='Stop'; try { $actual=(Get-FileHash -LiteralPath $env:MCR_V7_ARCHIVE -Algorithm SHA256).Hash.ToLowerInvariant(); if ($actual -ne $env:MCR_V7_EXPECTED_SHA) { Write-Host 'STOPP V7_ZIP_SHA256_FALSCH'; exit 21 }; Write-Host 'PASS  V7_ZIP_SHA256_ORIGINAL'; Expand-Archive -LiteralPath $env:MCR_V7_ARCHIVE -DestinationPath $env:MCR_V7_DEST -ErrorAction Stop; Write-Host 'PASS  ZIP_VOLLSTAENDIG_ENTPACKT'; exit 0 } catch { Write-Host 'STOPP ZIP_EXTRAKTION_FEHLGESCHLAGEN'; exit 22 }"
set "MCR_PS_EXIT=%ERRORLEVEL%"
if not "%MCR_PS_EXIT%"=="0" (
 echo STOPP V7-Archiv konnte nicht nachweisbar entpackt werden. Exitcode %MCR_PS_EXIT%.
 set "MCR_RESULT=16"
 goto finish
)
set "MCR_KIT=%MCR_V7_DEST%\MCR_Ticketbot_RC11_DEMO_FIX_V7"
if not exist "%MCR_KIT%\tools\run.cmd" (
 echo STOPP V7_STARTPFAD_FEHLT: tools\run.cmd fehlt.
 set "MCR_RESULT=17"
 goto finish
)
if not exist "%MCR_KIT%\tools\recover.mjs" (
 echo STOPP V7_STARTPFAD_FEHLT: tools\recover.mjs fehlt.
 set "MCR_RESULT=18"
 goto finish
)
if not exist "%MCR_KIT%\MANIFEST_SHA256.json" (
 echo STOPP V7_MANIFEST_FEHLT
 set "MCR_RESULT=19"
 goto finish
)
if not exist "%MCR_KIT%\DEMO_TESTEN_OHNE_VERSAND.cmd" (
 echo STOPP V7_DEMO_STARTER_FEHLT
 set "MCR_RESULT=20"
 goto finish
)
echo PASS  V7_VERZEICHNISSTRUKTUR_VOLLSTAENDIG
echo INFO  Starte AUSSCHLIESSLICH die fiktive Demo.
echo.
pushd "%MCR_KIT%"
if errorlevel 1 (
 echo STOPP V7_ZIELVERZEICHNIS_NICHT_ERREICHBAR
 set "MCR_RESULT=23"
 goto finish
)
call ".\DEMO_TESTEN_OHNE_VERSAND.cmd"
set "MCR_DEMO_EXIT=%ERRORLEVEL%"
popd
if not "%MCR_DEMO_EXIT%"=="0" (
 echo.
 echo STOPP V7_DEMO_EXITCODE_%MCR_DEMO_EXIT%
 echo Im entpackten V7-Ordner steht Ergebnis\REPARATUR_ERGEBNIS.json.
 echo Unter %MCR_KIT%
 echo Bei STOPP bitte DEMO_SAVE_PROBE oder Ergebnis\REPARATUR_ERGEBNIS.json mitteilen.
 echo Kein echter Versand durch diesen Starter.
 set "MCR_RESULT=%MCR_DEMO_EXIT%"
 goto finish
)
echo.
echo PASS  V7_DEMO_STARTER_BEENDET
echo Die Tests haben KEINEN echten Versand ausgefuehrt.
echo Bitte keinen Echtlauf ohne eigene Freigabe starten.
echo Der entpackte V7-Ordner wird geoeffnet.
start "" "%MCR_KIT%"
set "MCR_RESULT=0"
:finish
echo.
echo MCR V7 Rettungsstarter Exitcode: %MCR_RESULT%
echo.
pause
exit /b %MCR_RESULT%
