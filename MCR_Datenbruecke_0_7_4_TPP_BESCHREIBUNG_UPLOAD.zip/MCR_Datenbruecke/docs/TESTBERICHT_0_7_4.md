# Prüfbericht 0.7.4 — TPP-Beschreibung / zitierte Signaturen

## Ausgeführt

- **507 Node-Tests bestanden, 0 Fehler, 0 übersprungen**:
  `node --test tests/*.test.mjs`. Protokoll: `TPP_074_NODE_TESTS.tap`.
- **12 CLI-Prüfungen** des tatsächlich ausgelieferten `src/activate-tpp.mjs`:
  Abbruch ohne Änderung, BOM-Zeiger, Migration V1 → V2 ohne XLSX, korrekte Zeilen,
  unveränderte Altdaten, Aktivierungsbackup, idempotente Wiederholung,
  manipulierter aktiver Snapshot → Stopp. `TPP_074_CLI.json`.
- **10 CLI-Prüfungen** des erneuten XLSX-Imports mit fiktiver Arbeitsmappe:
  Quellenbindung, neuer V2-Snapshot, Aktivierung und Datenunverändertheit.
  `TPP_074_XLSX_EXPORT_CLI.json`.
- **13 Browserprüfungen** mit der produktiven Beschreibungs-Writer-/Reader-Funktion
  und fiktiver Tabelle: `USC 20/ DB+;TPP` plus zweite Zeile ohne TPP,
  Zeilenumbrüche, Wiederholung ohne erneutes Schreiben, Ablehnung eines belegten
  Feldes, 450-Zeichen-Limit, Seitenkürzung erkannt, Kommentar unberührt,
  keine Send-/Save-Klicks in diesem isolierten Feldtest. `TPP_074_BROWSER.json`.
- **Synthetischer Zweiticket-Vollrunnerlauf bis RUN COMPLETE**:
  `node src/local-bot-full-run.mjs --demo --auto --headless --close-browser --full-run`.
  Zwei Quellzeilen pro Ticket, erste mit TPP; Beschreibung nach Speichern in
  beiden Listen rückgelesen. Zwei Send- und zwei Save-Aktionslogzeilen im Lauf.
  `TPP_074_DEMO_FULL_RUN.log`.

## Gezielte neue Fälle

Alle 16 Kombinationen von C/D/E/F, nur TPP, DB+ mit und ohne TPP in zwei Zeilen,
identische Quellzeilen, null/0, Fehlerwerte/fehlender Cache, unveränderte Gender-
Widersprüche, neu überschrittene 450-Zeichen-Grenze, Hash-Tamper, widersprüchlicher
Aktivierungszeiger, fehlende gespeicherte Sperrzeilen und unveränderte Altdaten.

Für die Namensanalyse: `>`, `>>`, `> >` vor Grußformel und Name; getrennte
Zitatstufen dürfen nicht zusammengezogen werden; technische Namen bleiben
abgewiesen. Die tatsächliche Produktionsfunktion `choosePerson` wurde mit einem
Zitat getestet: JA gibt frei, NEIN verweigert, ein normaler unzitierter Name
behält den bisherigen automatischen Pfad. Kein Namens-/Gender-Raten.

## Umgebung und Aussagegrenzen

Node.js 22.16.0 unter Linux; Chromium headless. Alle Testbestände, Mails und
Browserformulare sind fiktiv. Der Demo-Vollrunner setzt feste Felder über seinen
vorhandenen DEMO-Zweig; dies qualifiziert nicht erneut die echten COMARCH-
Kategorie-/Signaturadapter. Es gibt keine Verbindung zu COMARCH und keine echte
Mailzustellung in diesen Tests.

Windows-CMD wurde statisch geprüft (CRLF, Shared-Node-Pfad, Prüfsummenprüfung,
Abbruch bei jedem Nichtnull-Exitcode), **nicht unter Windows ausgeführt**.
Die Original-Excel-Datei, das aktive JSON des Nutzers und die betroffene Original-
MSG liegen hier nicht vor. Daher ist weder ein realer 0.7.4-Fulllauf noch die
vollständige Original-MSG-Auswertung behauptet.

Die Versand-/Dialog-/Speicherfunktionen wurden gegenüber 0.7.3 nicht umgebaut.
Die vorhandene Editor-Reset-Heuristik ist kein externer Zustellbeleg, und es gibt
keine neue Garantie gegen Doppelversand nach einem Prozess-/Hostabbruch.

## Paket

Quelle: geprüftes 0.7.3-ZIP, SHA256
`0379130bb24bbe74bf72d6c00c26e3eb85d6fce416f6fd947b8ad9107217d900`.
Änderungsübersicht: `TPP_074_CHANGESET.json`. Vollständiges Manifest und
SHA256SUMS werden nach dem Build neu erzeugt; keine Laufzeitprofile, Downloads,
realen Mappingdateien oder personenbezogenen Diagnosepakete im Ergebnis-ZIP.
Archiv-CRC/Manifestprüfung und ein erneuter Testlauf nach Entpacken in einen
anderen Ordner sind im externen Abschlussprüfbericht dokumentiert.
