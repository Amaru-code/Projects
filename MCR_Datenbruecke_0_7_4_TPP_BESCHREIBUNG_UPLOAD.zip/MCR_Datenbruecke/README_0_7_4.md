# MCR 0.7.4 — TPP im Text jeder Bestandszeile

## Änderung

In 0.7.3 wurde F als `tpp` gespeichert, aber nach der damaligen Textregel nicht
in die Beschreibung geschrieben. 0.7.4 ergänzt `F = 1 → TPP` als letzten Code
**derselben** Quellzeile. E bleibt `PensIntel → DB+`. Reihenfolge:
`DC;PP+;DB+;TPP`. `0` und leere Zellen (`null`) erzeugen kein Kürzel.

Mehrere Bestandszeilen werden weiterhin separat und in physischer Excel-Reihenfolge
ausgegeben. Auch vollständig identische Ausgabezeilen bleiben erhalten. Kein OR,
keine erste/letzte Zeile, kein TPP-Override und weiterhin eine Nachricht pro Ticket.

Für den bestätigten Kontrollfall ergibt sich:

```
USC 20/ DB+;TPP
USC 20/ DB+
```

## Update und Aktivierung

1. Laufenden Bot beenden. ZIP vollständig entpacken und den enthaltenen Ordner
   `MCR_Datenbruecke` mit dem bisherigen gleichnamigen Projektordner zusammenführen.
   Gelieferte Paketdateien ersetzen; **private_data und .runtime nicht löschen**.
   Kein älteres Patch-Manifest darüberkopieren.
2. `MAPPING_TPP_AKTIVIEREN.cmd` starten. Verwendet die vorhandene Node-Installation
   (ab 22.15), keine PowerShell-JSON-Umwandlung und keine zusätzliche Installation.
3. Das Skript prüft `private_data/active-mapping.json`, Datei- und Payload-Hash des
   aktivierten 0.7.3-Snapshots. Die bereits gespeicherten B/C/D/E/F/L/O-Werte genügen;
   **die Excel-Datei wird für diese Migration nicht geöffnet oder gelesen**.
4. Vorschau/Statistik prüfen; mit `JA` aktivieren. Neuer JSON-Snapshot und Prüfsummen
   entstehen. Der aktive Zeiger wechselt erst nach erfolgreicher Rückprüfung.
   Bisheriger Snapshot bleibt erhalten; der vorige Zeiger wird gesichert unter
   `private_data/activation_backups`. `NEIN` verändert nichts. Erneute Ausführung
   nach erfolgreicher Aktivierung meldet `BEREITS AKTIV` ohne weitere Datei.
5. `START_FULL_QUEUE_RUN.cmd` starten. Es muss Version 0.7.4 anzeigen. Ein altes
   V1-Mapping wird vom **Vollrunner** vor Browserstart abgelehnt. Kein Fallback auf
   eine andere/ältere Gender-Datei. `START` gibt wie bisher reale Aktionen frei.

Für spätere XLSX-Neuimporte erzeugt `MAPPING_MEHRZEILIG_AKTUALISIEREN.cmd` jetzt
unmittelbar V2 mit TPP-Text. Die vorhandene Quellen-Hashprüfung bleibt bestehen.
Die älteren Konsolenhelfer/Einzelticketstarter sind historische Werkzeuge und nicht
der Startpunkt dieses V2-Vollrunners.

## Bereits versendete Tickets nicht erneut versenden

Die Migration verändert **nur das lokale Mapping**, keine COMARCH-Tickets.
Bereits befüllte Beschreibungen werden vom Queue-Runner weiterhin übersprungen.
Beim bereits versendeten Kontrollticket die vorhandene erste Beschreibungszeile
bei Bedarf **manuell um `;TPP` ergänzen und nur `Ticket speichern` betätigen**.
Die zweite Zeile unverändert lassen. Nicht die Beschreibung leeren, nicht erneut
auf Senden klicken und nicht künstlich für die Queue freimachen.

## Validierung und Grenzen

Der neue Mappingtyp lautet `MCR_INTL01_MULTIROW_LOOKUP_V2`. Die explizite Textregel
ist `ONE_LINE_PER_SOURCE_ROW_KEEP_IDENTICAL_LINES_WITH_TPP_V2`.
Alte V1-Mappings werden mit ihrem unveränderten Validator geprüft, bevor die Werte
neu abgeleitet werden. Kein stilles Umschreiben der V1-Bedeutung.

Alle Quellzeilen und ihre F-Werte bleiben erhalten. Gesperrte Personen benötigen
vollständige gespeicherte Quellzeilen; andernfalls wird die Migration verweigert.
Ein nur wegen fehlendem C/D/E gesperrter Datensatz kann bei F=1 künftig `TPP`
erhalten. Fehlerwerte, fehlender USC und unzulässige Gender-Werte bleiben gesperrt.
Überschreitet die um TPP erweiterte Gesamtbeschreibung die Grenze von 450 Zeichen
(einschließlich konservativ gezählter CRLF), wird **die ganze Person gesperrt**.
Es werden keine Zeilen abgeschnitten oder ausgelassen. Gender-Widersprüche führen
wie bisher zur manuellen Anredeauswahl.

## Zweiter gezeigter Fehler: zitierte Signatur

Die bereitgestellte Bildschirmansicht enthält `>>` vor Grußformel und Name.
Der bisherige Parser prüfte die komplette Zeile und konnte eine so zitierte
Signatur übersehen. Der neue Vollrunner normalisiert ausschließlich für die
Namensanalyse führende `>`, `>>` beziehungsweise `> >`. Der Original-Mailtext
bleibt unverändert. Ein Wechsel der Zitiertiefe darf eine Grußformel nicht mit
einem Namen aus einem anderen Abschnitt verbinden.

**Ein nur aus zitiertem Text bekannter Name erfordert eine Rückfrage:**
`Zitierte Person geprueft? JA:`. Erst nach Bestätigung startet die Member-Suche.
Keine Ableitung aus Absenderinitialen, keine Gender-Ableitung aus Vornamen.
Technische Namen wie Microsoft Outlook bleiben ausgeschlossen. Mehrere Kandidaten
bleiben unterscheidbar; der bekannte nichtzitierte Standardfall ist unverändert.
Der konkrete Original-MSG-Anhang liegt hier nicht vor; dieser Pfad wurde anhand
des sichtbaren Musters mit fiktiven Nachrichten getestet, nicht am echten Ticket.

## Unveränderte Betriebsgrenzen

Queue-Navigation, PAGE_FETCH, Browser-Mitgliedsauswahl, Kategorien, Versanddialoge,
Speichern und Rücknavigation wurden in diesem Patch nicht umgebaut. Der erste
reale 0.7.4-Lauf ist zu beobachten. Ein geleerter Editor allein ist kein externer
Zustellnachweis; die bestehenden Versandprüfungen dürfen nicht als garantierte
Zustellung oder dauerhafte Exactly-once-Garantie interpretiert werden.
Bei unklarem Versandstatus zuerst den tatsächlichen Verlauf kontrollieren und
nicht blind neu starten. Keine Produktivdaten/Original-Mails/Browserprofile als
Diagnose hochladen. Die Diagnose-ZIP-Funktion bleibt datensparsam.

Testdetails: `docs/TESTBERICHT_0_7_4.md`.
