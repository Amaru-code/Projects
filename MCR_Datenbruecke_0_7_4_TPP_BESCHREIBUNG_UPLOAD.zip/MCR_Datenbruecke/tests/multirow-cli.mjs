/** Integration: actual XLSX -> legacy proof -> new mapping activation -> correct loader.
 * Spawns the shipped CLI, responds to its real prompt. All data are synthetic.
 */
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';
import {spawn} from 'node:child_process';import assert from 'node:assert/strict';
import {readWorkbook} from '../lib/xlsx.mjs';import {makeMapping} from '../src/mapping.mjs';
import Core from '../lib/data-core.cjs';import {loadActiveMapping} from '../lib/active-mapping.mjs';
import {sourceRow,workbookBytes,key} from './multirow-fixtures.mjs';import {sha256} from '../lib/core.mjs';
const source=path.resolve(new URL('../',import.meta.url).pathname),root=fs.mkdtempSync(path.join(os.tmpdir(),'mcr-multirow-cli-'));
let checks=0;
try{
 for(const part of ['lib','src','config'])fs.cpSync(path.join(source,part),path.join(root,part),{recursive:true});
 fs.mkdirSync(path.join(root,'private_data'));
 const workbook=path.join(root,'FIKTIV.xlsx'),raw=workbookBytes([sourceRow(),sourceRow({row:11,D:0,E:1,F:0}),sourceRow({row:12,B:'99900002',O:'F'})]);fs.writeFileSync(workbook,raw);
 const legacy=makeMapping(readWorkbook(workbook),{mode:'LOCAL_WORKBOOK',headerLConfirmed:true,flagPolicy:Core.BLANK_OMIT_FLAGS});
 const oldpath=path.join(root,'private_data','INTL01_mapping_gender_OLD.json'),oldraw=JSON.stringify(legacy);
 fs.writeFileSync(oldpath,oldraw);const oldhash=sha256(oldraw);
 assert.ok(legacy.payload.blocked[key].codes.includes('DUPLICATE_ID'));checks++;
 fs.writeFileSync(path.join(root,'config','local-runner-queue-send.json'),JSON.stringify({mappingPath:oldpath,mappingDirectory:path.dirname(oldpath)}));
 async function run(response){
  const child=spawn(process.execPath,['src/export-multirow.mjs','--excel',workbook],{cwd:root,stdio:['pipe','pipe','pipe']});let text='',sent=false;
  const handler=b=>{text+=b.toString();if(!sent&&text.includes('aktivieren? JA:')){sent=true;child.stdin.write(response+'\n');}};
  child.stdout.on('data',handler);child.stderr.on('data',handler);
  const timer=setTimeout(()=>child.kill(),10000);
  const rc=await new Promise((resolve,reject)=>{child.on('error',reject);child.on('exit',resolve);});clearTimeout(timer);return {rc,text};
 }
 let r=await run('NEIN');assert.equal(r.rc,1);assert.ok(!fs.existsSync(path.join(root,'private_data','active-mapping.json')));checks++;
 r=await run('JA');assert.equal(r.rc,0,r.text);assert.ok(r.text.includes('MEHRZEILEN-MAPPING AKTIV'));checks++;
 const first=loadActiveMapping(root);assert.equal(first.map.payload.entries[key].description,'USC 20/ PP+;TPP\nUSC 20/ DB+');checks++;
 assert.equal(first.map.payload.entries[key].records.length,2);checks++;
 assert.equal(sha256(fs.readFileSync(oldpath)),oldhash);assert.deepEqual(fs.readFileSync(workbook),raw);checks++;
 r=await run('JA');assert.equal(r.rc,0,r.text);const second=loadActiveMapping(root);assert.notEqual(second.path,first.path);checks++;
 assert.ok(fs.existsSync(first.path));assert.ok(fs.readdirSync(path.join(root,'private_data','activation_backups')).length>=1);checks++;
 fs.writeFileSync(workbook,workbookBytes([sourceRow({L:99})]));r=await run('JA');assert.equal(r.rc,1);assert.ok(r.text.includes('SOURCE_CHANGED'));checks++;
 assert.equal(loadActiveMapping(root).path,second.path);checks++;
 console.log(JSON.stringify({suite:'multirow-CLI',platform:process.platform,checks,status:'PASS',syntheticOnly:true,sourceUnchanged:true,oldMappingUnchanged:true},null,2));
}finally{fs.rmSync(root,{recursive:true,force:true});}
