/** Test the shipped interactive CLI on faked mappings; no XLSX or COMARCH needed. */
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';
import {spawn} from 'node:child_process';import assert from 'node:assert/strict';
import {makeMultirowMapping as makeV1} from '../lib/multirow-mapping.mjs';
import {SCHEMA as V2} from '../lib/multirow-tpp-mapping.mjs';
import {publishActiveMapping,loadActiveMapping} from '../lib/active-mapping.mjs';
import {sourceRow,book,key} from './multirow-fixtures.mjs';import {sha256} from '../lib/core.mjs';
const source=path.resolve(new URL('../',import.meta.url).pathname),root=fs.mkdtempSync(path.join(os.tmpdir(),'mcr-tpp-cli-'));
let checks=0;
try{
 for(const part of ['lib','src','config'])fs.cpSync(path.join(source,part),path.join(root,part),{recursive:true});
 const m=makeV1(book([sourceRow({D:0,E:1,F:1}),sourceRow({row:11,D:0,E:1,F:0})]),{headerConfirmed:true});
 const original=publishActiveMapping(root,m),hash=sha256(fs.readFileSync(original.path));
 // Simulate a BOM left by old PowerShell tools only on the pointer (its bytes have no external pin).
 fs.writeFileSync(original.pointerPath,'\ufeff'+fs.readFileSync(original.pointerPath,'utf8'));
 const pointerBytes=fs.readFileSync(original.pointerPath);
 async function run(answer){
  const child=spawn(process.execPath,['src/activate-tpp.mjs'],{cwd:root,stdio:['pipe','pipe','pipe']});let text='',sent=false;
  const handler=b=>{text+=b.toString();if(!sent&&text.includes('aktivieren? JA:')){sent=true;child.stdin.write(answer+'\n');}};
  child.stdout.on('data',handler);child.stderr.on('data',handler);
  const timer=setTimeout(()=>child.kill(),10000);const rc=await new Promise((resolve,reject)=>{child.on('error',reject);child.on('exit',resolve);});clearTimeout(timer);return {rc,text};
 }
 let r=await run('NEIN');assert.equal(r.rc,1,r.text);assert.deepEqual(fs.readFileSync(original.pointerPath),pointerBytes);checks++;
 assert.equal(sha256(fs.readFileSync(original.path)),hash);checks++;
 r=await run('JA');assert.equal(r.rc,0,r.text);assert.ok(r.text.includes('FERTIG - TPP-MAPPING AKTIV'));checks++;
 const updated=loadActiveMapping(root);assert.equal(updated.map.schema,V2);checks++;
 assert.equal(updated.map.payload.entries[key].description,'USC 20/ DB+;TPP\nUSC 20/ DB+');checks++;
 assert.equal(sha256(fs.readFileSync(original.path)),hash);checks++;
 assert.equal(fs.readdirSync(path.join(root,'private_data','activation_backups')).length,1);checks++;
 assert.equal(fs.readdirSync(root).some(n=>n.endsWith('.xlsx')),false);assert.ok(!fs.existsSync(path.join(root,'.runtime')));checks++;
 const currentPointer=fs.readFileSync(updated.pointerPath),fileCount=fs.readdirSync(path.join(root,'private_data')).length;
 r=await run('JA');assert.equal(r.rc,0,r.text);assert.ok(r.text.includes('BEREITS AKTIV'));checks++;
 assert.deepEqual(fs.readFileSync(updated.pointerPath),currentPointer);assert.equal(fs.readdirSync(path.join(root,'private_data')).length,fileCount);checks++;
 // Changing even one byte of the pinned mapping is a hard stop, not a fallback.
 fs.appendFileSync(updated.path,' ');r=await run('JA');assert.equal(r.rc,1);assert.ok(r.text.includes('ACTIVE_MAPPING_HASH'));checks++;
 assert.deepEqual(fs.readFileSync(updated.pointerPath),currentPointer);checks++;
 console.log(JSON.stringify({suite:'tpp-actual-CLI',checks,status:'PASS',platform:process.platform,usesExcel:false,usesBrowser:false,syntheticOnly:true},null,2));
}finally{fs.rmSync(root,{recursive:true,force:true});}
