import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {sha256} from '../lib/core.mjs';
import Core from '../lib/data-core.cjs';
import {makeMapping} from '../src/mapping.mjs';
import {makeMultirowMapping,lookupMultirow,validateMultirowMapping,descriptionUnits,SCHEMA,POLICY} from '../lib/multirow-mapping.mjs';
import {readWorkbookBuffer,readWorkbook} from '../lib/xlsx-multirow.mjs';
import {loadActiveMapping,publishActiveMapping} from '../lib/active-mapping.mjs';
import {verifyPackage,RELEASE,REQUIRED} from '../lib/package-integrity.mjs';
import {sourceRow,book,key,workbookBytes} from './multirow-fixtures.mjs';
const map=(rows,options={})=>makeMultirowMapping(book(rows),{headerConfirmed:true,mode:'LOCAL_WORKBOOK',...options});
const code=c=>e=>e.code===c;
const root=path.resolve(new URL('../',import.meta.url).pathname);
const refresh=m=>{m.payloadSha256=sha256(JSON.stringify(m.payload));return m;};
function temp(){return fs.mkdtempSync(path.join(os.tmpdir(),'mcr-multirow-'));}
function withTemp(f){const r=temp();try{return f(r);}finally{fs.rmSync(r,{recursive:true,force:true});}}

test('Single row retains existing C/D/E -> description semantics, stores E/F/O',()=>{
 const e=lookupMultirow(map([sourceRow()]),key);assert.equal(e.rowCount,1);assert.equal(e.description,'USC 20/ PP+');
 assert.equal(e.records[0].dc,null);assert.equal(e.records[0].tpp,1);assert.equal(e.records[0].pensIntel,0);assert.equal(e.gender,'M');
});
test('Different duplicate rows become separate lines without cross-row OR or USC reassignment',()=>{
 const e=lookupMultirow(map([sourceRow(),sourceRow({row:11,C:1,D:0,E:1,F:0,L:'30'})]),key);
 assert.equal(e.description,'USC 20/ PP+\nUSC 30/ DC;DB+');assert.equal(e.rowCount,2);
 assert.deepEqual(e.records.map(r=>r.tpp),[1,0]);assert.deepEqual(e.records.map(r=>r.usc),['20','30']);
});
test('Identical description lines are retained even if only TPP differs',()=>{
 const e=lookupMultirow(map([sourceRow({D:0,E:1,F:1}),sourceRow({row:11,D:0,E:1,F:0})]),key);
 assert.equal(e.description,'USC 20/ DB+\nUSC 20/ DB+');assert.deepEqual(e.descriptionLines,['USC 20/ DB+','USC 20/ DB+']);
 assert.ok(!e.description.includes('TPP'));assert.deepEqual(e.sourceRows,[10,11]);
});
test('Physical source row order, not input array order or tpp preference',()=>{
 const e=lookupMultirow(map([sourceRow({row:50,F:1,L:30}),sourceRow({row:10,F:0,L:10})]),key);
 assert.equal(e.description,'USC 10/ PP+\nUSC 30/ PP+');assert.deepEqual(e.sourceRows,[10,50]);
});
test('All known original source rows re-read, legacy TPP override does not exist in new policy',()=>{
 const m=map([sourceRow({B:'10102131',F:1}),sourceRow({B:'10102131',row:11,F:0})]);
 assert.equal(m.payload.entries['10102131'].rowCount,2);assert.ok(!Object.hasOwn(m.payload.blocked,'10102131'));assert.equal(m.payload.duplicatePolicy,POLICY);
});
test('Multirow schema cannot accidentally be consumed by legacy Core',()=>assert.throws(()=>Core.validateMap(map([sourceRow()])),code('MAP_SCHEMA')));
for(const [gs,status,result] of [
 [['M','M'],'CONSISTENT','M'],[['F','F'],'CONSISTENT','F'],[['M','F'],'CONFLICT',null],
 [['',''],'MISSING',null],[['M',''],'MISSING',null],[['F',''],'MISSING',null]
])test('Gender aggregation '+JSON.stringify(gs),()=>{
 const e=lookupMultirow(map(gs.map((O,i)=>sourceRow({row:10+i,O}))),key);assert.equal(e.genderStatus,status);assert.equal(e.gender,result);
});
for(const field of ['C','D','E','F'])test('blank '+field+' preserved as null provenance',()=>{
 const r=sourceRow({C:1,[field]:''}),e=lookupMultirow(map([r]),key).records[0];assert.ok(e.blankColumns.includes(field));
 assert.equal(e[{C:'dc',D:'ppPlus',E:'dbPlus',F:'tpp'}[field]],null);
});
for(const [extra,err] of [
 [{F:2},'FLAG_INVALID'],[{C:'?'},'FLAG_INVALID'],[{L:''},'USC_INVALID'],[{O:'X'},'GENDER_INVALID'],
 [{errors:{F:'missing cache'}},'CELL_ERROR'],[{errors:{O:'missing cache'}},'CELL_ERROR'],[{C:0,D:0,E:0},'NO_PLAN']
])test('One invalid source row blocks whole person '+err+JSON.stringify(extra),()=>{
 const m=map([sourceRow(),sourceRow({row:11,...extra})]);assert.equal(m.payload.entries[key],undefined);
 assert.ok(m.payload.blocked[key].codes.includes(err));assert.deepEqual(m.payload.blocked[key].sourceRows,[10,11]);assert.equal(m.payload.blocked[key].sourceRecords.length,2);
 assert.throws(()=>lookupMultirow(m,key),code('ID_BLOCKED'));
});
test('Formula provenance F/O included and reviewer gate retained',()=>{
 const e=lookupMultirow(map([sourceRow({formulas:['F','O']})]),key);assert.equal(e.hasCachedFormulas,true);assert.deepEqual(e.records[0].formulas,['F','O']);
});
test('Long descriptions blocked, never trimmed or silently shortened',()=>{
 const m=map(Array.from({length:40},(_,i)=>sourceRow({row:10+i})));assert.ok(m.payload.blocked[key].codes.includes('DESCRIPTION_TOO_LONG'));assert.equal(m.payload.entries[key],undefined);
});
test('CRLF units accounted for conservative 450-char limit',()=>{
 assert.equal(descriptionUnits('a\nb'),4);assert.equal(descriptionUnits('a\r\nb'),4);
});
test('Leading zeros remain part of person ID',()=>{
 const m=map([sourceRow({B:'000001'}),sourceRow({row:11,B:'1'})]);assert.equal(Object.keys(m.payload.entries).length,2);
});
for(const change of [
 e=>e.records[0].pensIntel=1,e=>e.records[0].clientId='99900002',e=>e.records.reverse(),
 e=>e.records[1].sourceRow=e.records[0].sourceRow,e=>e.descriptionLines.pop(),e=>e.description=e.description.replace('\n',' '),
 e=>e.sourceRows=[10],e=>delete e.records[0].tpp,e=>e.gender='F',e=>e.records[0].formulas=['Z']
])test('Derived/row tampering rejected '+change.toString(),()=>{
 const m=map([sourceRow(),sourceRow({row:11})]);change(m.payload.entries[key]);refresh(m);assert.throws(()=>validateMultirowMapping(m));
});
test('Payload hash tamper rejected',()=>{const m=map([sourceRow()]);m.payload.source.filename='changed';assert.throws(()=>validateMultirowMapping(m),code('MAP_HASH_MISMATCH'));});
test('Source mismatch rejected before generating a mapping',()=>assert.throws(()=>map([sourceRow()],{expectedSourceSha:'b'.repeat(64)}),code('SOURCE_CHANGED')));
test('Input rows never mutated',()=>{const rows=[sourceRow(),sourceRow({row:11})],b=JSON.stringify(rows);map(rows);assert.equal(JSON.stringify(rows),b);});
test('XLSX reads exact E F O, both duplicate records',()=>{
 const b=readWorkbookBuffer(workbookBytes([sourceRow({E:1,F:1}),sourceRow({row:11,E:1,F:0})]),'FIKTIV.xlsx');
 assert.equal(b.meta.headers.F,'IsEligible_TPP');assert.equal(b.meta.headers.O,'Gender');
 const m=makeMultirowMapping(b,{headerConfirmed:true});assert.equal(m.payload.entries[key].rowCount,2);assert.deepEqual(m.payload.entries[key].records.map(r=>r.tpp),[1,0]);
});
for(const col of ['F','L','O'])test('XLSX wrong '+col+' header is not silently mapped',()=>{
 assert.throws(()=>readWorkbookBuffer(workbookBytes([sourceRow()],{headers:{[col]:'wrong'}})),code('HEADER_'+col));
});
test('XLSX missing F formula cache stays blocked, not blank omission',()=>{
 const b=readWorkbookBuffer(workbookBytes([sourceRow({xml:{F:'<c r="F10"><f>1</f></c>'}})]));
 const m=makeMultirowMapping(b,{headerConfirmed:true});assert.ok(m.payload.blocked[key].codes.includes('CELL_ERROR'));
});
test('XLSX cached O formula result accepted with provenance',()=>{
 const b=readWorkbookBuffer(workbookBytes([sourceRow({xml:{O:'<c r="O10" t="str"><f>"M"</f><v>M</v></c>'}})]));
 const e=lookupMultirow(makeMultirowMapping(b,{headerConfirmed:true}),key);assert.equal(e.gender,'M');assert.equal(e.hasCachedFormulas,true);
});
test('XLSX duplicate physical row numbers rejected',()=>assert.throws(()=>readWorkbookBuffer(workbookBytes([sourceRow(),sourceRow()])),code('DUPLICATE_ROW_NUMBER')));
test('XLSX read-only input bytes unchanged',()=>withTemp(dir=>{
 const p=path.join(dir,'test.xlsx'),raw=workbookBytes([sourceRow()]);fs.writeFileSync(p,raw);readWorkbook(p);assert.deepEqual(fs.readFileSync(p),raw);
}));
test('Active pointer beats old config path even when old file has future mtime',()=>withTemp(dir=>{
 const old=path.join(dir,'private_data','INTL01_mapping_gender_OLD.json');fs.mkdirSync(path.dirname(old));fs.writeFileSync(old,'{}');
 fs.mkdirSync(path.join(dir,'config'));fs.writeFileSync(path.join(dir,'config','local-runner-queue-send.json'),JSON.stringify({mappingPath:old}));fs.utimesSync(old,new Date('2099-01-01'),new Date('2099-01-01'));
 const a=publishActiveMapping(dir,map([sourceRow(),sourceRow({row:11})]));assert.equal(loadActiveMapping(dir).path,a.path);assert.equal(loadActiveMapping(dir).map.payload.entries[key].rowCount,2);assert.equal(fs.readFileSync(old,'utf8'),'{}');
}));
test('No active pointer means stop, not oldest cfg fallback',()=>withTemp(dir=>{
 fs.mkdirSync(path.join(dir,'private_data'));fs.writeFileSync(path.join(dir,'private_data','INTL01_mapping_gender_OLD.json'),'{}');assert.throws(()=>loadActiveMapping(dir),code('MULTIROW_SETUP_REQUIRED'));
}));
test('Corrupt active map means stop, no prior-file fallback',()=>withTemp(dir=>{
 const a=publishActiveMapping(dir,map([sourceRow()]));publishActiveMapping(dir,map([sourceRow({L:30})]));
 const b=loadActiveMapping(dir);fs.appendFileSync(b.path,' ');assert.throws(()=>loadActiveMapping(dir),code('ACTIVE_MAPPING_HASH'));assert.ok(fs.existsSync(a.path));
}));
test('Missing active map never uses a valid older file',()=>withTemp(dir=>{
 publishActiveMapping(dir,map([sourceRow()]));const b=publishActiveMapping(dir,map([sourceRow({L:30})]));fs.unlinkSync(b.path);assert.throws(()=>loadActiveMapping(dir),code('ACTIVE_MAPPING_MISSING'));
}));
test('Activation path traversal blocked',()=>withTemp(dir=>{
 publishActiveMapping(dir,map([sourceRow()]));const p=path.join(dir,'private_data','active-mapping.json'),x=JSON.parse(fs.readFileSync(p));x.file='../other.json';fs.writeFileSync(p,JSON.stringify(x));assert.throws(()=>loadActiveMapping(dir),code('ACTIVE_MAPPING_PATH'));
}));
test('BOM on pointer read tolerated',()=>withTemp(dir=>{
 publishActiveMapping(dir,map([sourceRow()]));const p=path.join(dir,'private_data','active-mapping.json');fs.writeFileSync(p,'\uFEFF'+fs.readFileSync(p,'utf8'));assert.equal(loadActiveMapping(dir).map.payload.entries[key].gender,'M');
}));
test('Failure before atomic activation leaves previous pointer live',()=>withTemp(dir=>{
 const a=publishActiveMapping(dir,map([sourceRow()]));assert.throws(()=>publishActiveMapping(dir,map([sourceRow({L:30})]),{beforeActivate(){throw Error('injected failure');}}));
 assert.equal(loadActiveMapping(dir).path,a.path);assert.equal(loadActiveMapping(dir).map.payload.entries[key].description,'USC 20/ PP+');
}));
test('Demo mapping rejected in real runner',()=>withTemp(dir=>{
 publishActiveMapping(dir,map([sourceRow()],{mode:'DEMO'}));assert.throws(()=>loadActiveMapping(dir),code('DEMO_NOT_IN_COMARCH'));assert.ok(loadActiveMapping(dir,{allowDemo:true}));
}));
test('Four-file patch manifest cannot masquerade as full package',()=>withTemp(dir=>{
 fs.writeFileSync(path.join(dir,'MANIFEST.json'),JSON.stringify({schema:'MCR_PACKAGE_MANIFEST_V1',package:'MCR_Datenbruecke',version:RELEASE,payload:Array.from({length:4},(_,i)=>({path:'file'+i,bytes:0,sha256:sha256('')}))}));
 assert.throws(()=>verifyPackage(dir),code('PACKAGE_COVERAGE'));
}));
test('Required full runner dependency list includes mapping and sender',()=>{
 for(const s of ['src/local-bot-full-run.mjs','lib/multirow-mapping.mjs','lib/active-mapping.mjs','lib/xlsx-multirow.mjs','lib/cdp.mjs'])assert.ok(REQUIRED.includes(s));
});
test('New Windows launchers avoid PowerShell JSON roundtrip and test all nonzero exits',()=>{
 for(const n of ['START_FULL_QUEUE_RUN.cmd','MAPPING_MEHRZEILIG_AKTUALISIEREN.cmd']){
  const b=fs.readFileSync(new URL('../'+n,import.meta.url),'utf8');assert.ok(b.includes('if not "%errorlevel%"=="0"'));assert.ok(!b.includes('ConvertFrom-Json'));assert.ok(b.includes('verify-package.mjs'));assert.ok(b.includes('\r\n'));assert.ok(!/(?<!\r)\n/.test(b));
 }
});
test('Full runner executes one send/save per ticket, not one per bestandsrecord',()=>{
 const s=fs.readFileSync(new URL('../src/local-bot-full-run.mjs',import.meta.url),'utf8');
 const f=s.slice(s.indexOf('async function processOpenedTicket('),s.indexOf('\nasync function main()'));
 assert.equal((f.match(/await sendAndConfirm\(/g)||[]).length,1);assert.equal((f.match(/await saveTicket\(/g)||[]).length,1);
 assert.ok(f.includes('lookupMultirow(mapping.map,selected.id)'));assert.ok(!f.includes('for(const record'));assert.ok(s.includes('const active=loadActiveMapping(root)'));
});
