import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {sha256} from '../lib/core.mjs';
import {makeMultirowMapping as makeV1,SCHEMA as V1,validateMultirowMapping as validV1} from '../lib/multirow-mapping.mjs';
import {makeMultirowMapping as makeV2,SCHEMA as V2,validateMultirowMapping as validV2,lookupMultirow,DESCRIPTION_POLICY} from '../lib/multirow-tpp-mapping.mjs';
import {upgradeTppMapping} from '../lib/tpp-migration.mjs';
import {publishActiveMapping,loadActiveMapping} from '../lib/active-mapping.mjs';
import {sourceRow,book,key} from './multirow-fixtures.mjs';
import Person from '../lib/person-quoted.cjs';
import BasePerson from '../lib/person.cjs';
const v1=rows=>makeV1(book(rows),{headerConfirmed:true});
const v2=rows=>makeV2(book(rows),{headerConfirmed:true});
const err=code=>e=>e.code===code;
const clone=structuredClone;
const rehash=m=>{m.payloadSha256=sha256(JSON.stringify(m.payload));return m;};
function temp(fn){const root=fs.mkdtempSync(path.join(os.tmpdir(),'mcr-tpp-'));try{return fn(root);}finally{fs.rmSync(root,{recursive:true,force:true});}}

for(let mask=0;mask<16;mask++)test('V2 renders all C/D/E/F combinations independently: '+mask,()=>{
 const C=mask&1?1:0,D=mask&2?1:0,E=mask&4?1:0,F=mask&8?1:0;
 const m=v2([sourceRow({C,D,E,F})]);
 if(mask===0){assert.ok(m.payload.blocked[key].codes.includes('NO_PLAN'));return;}
 const tokens=[C?'DC':null,D?'PP+':null,E?'DB+':null,F?'TPP':null].filter(Boolean);
 assert.equal(lookupMultirow(m,key).description,'USC 20/ '+tokens.join(';'));
});
test('TPP appears only on its physical source row; no cross-row OR',()=>{
 const m=v2([sourceRow({D:0,E:1,F:1}),sourceRow({row:11,D:0,E:1,F:0})]);
 assert.equal(m.payload.entries[key].description,'USC 20/ DB+;TPP\nUSC 20/ DB+');
 assert.deepEqual(m.payload.entries[key].sourceRows,[10,11]);
});
test('Fully identical physical rows still duplicate their rendered lines',()=>{
 const e=lookupMultirow(v2([sourceRow(),sourceRow({row:11})]),key);
 assert.equal(e.description,'USC 20/ PP+;TPP\nUSC 20/ PP+;TPP');
});
for(const F of [0,null,''])test('Blank/zero TPP contributes no label and retains provenance '+JSON.stringify(F),()=>{
 const e=lookupMultirow(v2([sourceRow({F})]),key).records[0];assert.equal(e.description,'USC 20/ PP+');
 assert.equal(e.tpp,F===0?0:null);
});
test('V1 migration preserves every source value and old object bytes',()=>{
 const old=v1([sourceRow({D:0,E:1,F:1}),sourceRow({row:11,D:0,E:1,F:0})]),before=JSON.stringify(old);
 const r=upgradeTppMapping(old);
 assert.equal(r.changed,true);assert.equal(r.changedPersons,1);assert.equal(JSON.stringify(old),before);
 assert.equal(r.map.schema,V2);assert.equal(r.map.payload.descriptionPolicy,DESCRIPTION_POLICY);
 assert.equal(r.map.payload.entries[key].description,'USC 20/ DB+;TPP\nUSC 20/ DB+');
 for(let i=0;i<2;i++){
  const a=clone(old.payload.entries[key].records[i]),b=clone(r.map.payload.entries[key].records[i]);
  delete a.description;delete b.description;assert.deepEqual(a,b);
 }
 assert.deepEqual(old.payload.source,r.map.payload.source);
});
test('Legacy reader rejects V2 and V2 reader rejects V1; no silent reinterpretation',()=>{
 assert.throws(()=>validV1(v2([sourceRow()])),err('MAP_SCHEMA'));
 assert.throws(()=>validV2(v1([sourceRow()])),err('MAP_SCHEMA'));
});
test('V2 activation is idempotent and keeps same object on second migration',()=>{
 const m=v2([sourceRow()]),r=upgradeTppMapping(m);assert.equal(r.changed,false);assert.equal(r.map,m);
});
test('F-only group was blocked in V1 but is correctly usable as TPP in V2',()=>{
 const old=v1([sourceRow({C:0,D:0,E:0,F:1})]);assert.ok(old.payload.blocked[key].codes.includes('NO_PLAN'));
 const r=upgradeTppMapping(old);assert.equal(r.newlyValid,1);assert.equal(r.map.payload.entries[key].description,'USC 20/ TPP');
});
for(const bad of [{F:2},{L:''},{errors:{F:'CACHE_MISSING'}},{O:'X'}])test('Migration keeps invalid person blocked '+JSON.stringify(bad),()=>{
 const r=upgradeTppMapping(v1([sourceRow(),sourceRow({row:11,...bad})]));
 assert.ok(r.map.payload.blocked[key]);assert.ok(!r.map.payload.entries[key]);assert.deepEqual(r.map.payload.blocked[key].sourceRows,[10,11]);
});
test('Missing stored block values refuses migration, not silent unblock',()=>{
 const old=v1([sourceRow({F:3})]);delete old.payload.blocked[key].sourceRecords;rehash(old);
 assert.throws(()=>upgradeTppMapping(old),err('TPP_SOURCE_RECORDS'));
});
test('Corrupt source hash refuses conversion',()=>{
 const old=v1([sourceRow()]);old.payload.entries[key].records[0].tpp=0;
 assert.throws(()=>upgradeTppMapping(old),err('MAP_HASH_MISMATCH'));
});
test('TPP values cannot disagree with rendered line even with recalculated checksum',()=>{
 const m=v2([sourceRow()]);m.payload.entries[key].records[0].tpp=0;rehash(m);assert.throws(()=>validV2(m),err('MAP_DESCRIPTION'));
});
test('Length expansion blocks the whole person; no trimming',()=>{
 const old=v1(Array.from({length:28},(_,i)=>sourceRow({row:10+i,D:0,E:1,F:1})));
 assert.ok(old.payload.entries[key]);const r=upgradeTppMapping(old);
 assert.ok(r.map.payload.blocked[key].codes.includes('DESCRIPTION_TOO_LONG'));assert.equal(r.newlyBlocked,1);
});
test('Gender conflict unchanged after TPP upgrade',()=>{
 const m=upgradeTppMapping(v1([sourceRow(),sourceRow({row:11,O:'F'})])).map;
 assert.equal(m.payload.entries[key].genderStatus,'CONFLICT');assert.equal(m.payload.entries[key].gender,null);
});
test('Active pointer pins V2; old mapping remains and backup is created',()=>temp(root=>{
 const a=publishActiveMapping(root,v1([sourceRow()])),oldHash=sha256(fs.readFileSync(a.path));
 const b=publishActiveMapping(root,upgradeTppMapping(a.map).map);
 assert.equal(loadActiveMapping(root).map.schema,V2);assert.equal(sha256(fs.readFileSync(a.path)),oldHash);
 assert.notEqual(a.path,b.path);assert.equal(fs.readdirSync(path.join(root,'private_data','activation_backups')).length,1);
}));
test('Rehashed pointer with mismatched schema refused',()=>temp(root=>{
 const a=publishActiveMapping(root,v2([sourceRow()]));const p=JSON.parse(fs.readFileSync(a.pointerPath));p.mappingSchema=V1;
 fs.writeFileSync(a.pointerPath,JSON.stringify(p));assert.throws(()=>loadActiveMapping(root),err('ACTIVE_MAPPING_BINDING'));
}));
test('Full runner rejects old active schema before starting browser',()=>{
 const src=fs.readFileSync(new URL('../src/local-bot-full-run.mjs',import.meta.url),'utf8');
 assert.ok(src.includes("active.map.schema===MULTI_SCHEMA,'TPP_MAPPING_SETUP_REQUIRED'"));
 assert.ok(src.indexOf('mapping=autoMapping(cfg)')<src.indexOf('browser=await launchBrowser'));
});
for(const prefix of ['> ','>> ','> > ','>>>'])test('Quoted signature recognized without changing original mail '+JSON.stringify(prefix),()=>{
 const m={senderName:'VExample',body:prefix+'Mit freundlichen Grüßen\n'+prefix+'\n'+prefix+'Anna Beispiel\n'+prefix+'Musterstr. 12'};
 const before=JSON.stringify(m);const c=Person.candidates(m);
 assert.equal(c.length,1);assert.equal(c[0].name,'Anna Beispiel');assert.equal(c[0].quotedOnly,true);assert.equal(JSON.stringify(m),before);
 assert.equal(BasePerson.candidates(m).length,0); // observed old failure pattern
});
test('Quoted technical sender still rejected',()=>{
 const c=Person.candidates({senderName:'Microsoft Outlook',body:'>> Kind regards\n>> Microsoft Outlook'});assert.deepEqual(c,[]);
});
test('Quotation depth boundary cannot connect unrelated sign-off and name',()=>{
 const c=Person.candidates({senderName:'x',body:'> Mit freundlichen Grüßen\nAnna Beispiel'});assert.deepEqual(c,[]);
});
test('Current and quoted names stay two different candidates',()=>{
 const c=Person.candidates({senderName:'x',body:'Viele Grüße\nMax Mustermann\n\n> Mit freundlichen Grüßen\n> Anna Beispiel'});
 assert.equal(c.length,2);assert.equal(c.find(x=>x.name==='Max Mustermann').quotedOnly,false);assert.equal(c.find(x=>x.name==='Anna Beispiel').quotedOnly,true);
});
test('Nonquoted parser output byte-for-byte unchanged',()=>{
 const mail={senderName:'x',body:'Mit freundlichen Grüßen\nAnna Beispiel'};
 assert.deepEqual(Person.candidates(mail),BasePerson.candidates(mail));
});
test('Quoted-only automatic search has explicit operator gate in real runner',()=>{
 const s=fs.readFileSync(new URL('../src/local-bot-full-run.mjs',import.meta.url),'utf8');
 assert.ok(s.includes('candidates[0].quotedOnly&&!DEMO'));assert.ok(s.includes("'QUOTED_NAME_REVIEW'"));
 assert.ok(s.includes('!scored[0].c.quotedOnly&&scored[0].score>=7'));
});
test('TPP CMD has native Node reader, CRLF, no PS JSON conversion',()=>{
 const s=fs.readFileSync(new URL('../MAPPING_TPP_AKTIVIEREN.cmd',import.meta.url),'utf8');
 assert.ok(s.includes('activate-tpp.mjs'));assert.ok(s.includes('verify-package.mjs'));assert.ok(s.includes('if not "%errorlevel%"=="0"'));
 assert.ok(s.includes('\r\n'));assert.ok(!s.includes('ConvertFrom-Json'));
});

// Exercise the production prompt path itself, not only a static presence check.
import vm from 'node:vm';import Core from '../lib/data-core.cjs';
const runnerSrc=fs.readFileSync(new URL('../src/local-bot-full-run.mjs',import.meta.url),'utf8');
function chooser({answer='JA',auto=false}={}){
 const code=runnerSrc.slice(runnerSrc.indexOf('function choosePerson(mail, rl){'),runnerSrc.indexOf('\nasync function memberFieldCenter('));
 const state={mail:{personAuto:false,personManual:false}},prompts=[];
 const clean=v=>String(v??'').replace(/\s+/g,' ').trim();
 const choose=vm.runInNewContext('('+code+')',{Person,Core,diag:state,DEMO:false,AUTO:auto,clean,norm:Person.norm,log(){},need(ok,code,message){if(!ok)throw Object.assign(Error(message),{code});}});
 const rl={question:async q=>{prompts.push(q);return answer;}};
 return {choose:m=>choose(m,rl),state,prompts};
}
const quoted={senderName:'VExample',subject:'12345678',body:'>> Bitte bearbeiten.\n>> Mit freundlichen Grüßen\n>>\n>> Anna Beispiel'};
test('Actual chooser requires confirmation on a sole quoted name, even with --auto in real mode',async()=>{
 const c=chooser({auto:true});const x=await c.choose(quoted);assert.equal(x.person.name,'Anna Beispiel');assert.equal(c.prompts.length,1);
 assert.equal(c.state.mail.personManual,true);assert.equal(c.state.mail.personAuto,false);
});
test('Actual chooser declines quoted name without returning a search person',async()=>{
 const c=chooser({answer:'NEIN'});await assert.rejects(c.choose(quoted),err('QUOTED_NAME_REVIEW'));assert.equal(c.state.mail.personAuto,false);
});
test('Actual chooser retains automatic path for normal unquoted signature',async()=>{
 const c=chooser();const x=await c.choose({...quoted,body:'Mit freundlichen Grüßen\nAnna Beispiel'});
 assert.equal(x.person.name,'Anna Beispiel');assert.equal(c.prompts.length,0);assert.equal(c.state.mail.personAuto,true);
});
