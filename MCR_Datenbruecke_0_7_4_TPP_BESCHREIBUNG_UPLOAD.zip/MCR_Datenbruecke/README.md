# MCR Datenbrücke 0.7.4

**Neu:** Spalte F = 1 ergänzt `TPP` im Beschreibungstext derselben Bestandszeile.
E / PensIntel bleibt `DB+`. Alle Quellzeilen bleiben separat erhalten.

## Start

ZIP vollständig entpacken und mit `MCR_Datenbruecke` zusammenführen. Gelieferte
Dateien ersetzen; `private_data` und `.runtime` **nicht löschen**.

Einmal **`MAPPING_TPP_AKTIVIEREN.cmd`** → Vorschau prüfen → `JA`.
Verwendet das vorhandene aktive 0.7.3-JSON; kein erneuter Excel-Export nötig.

Danach **`START_FULL_QUEUE_RUN.cmd`** → Version 0.7.4 / TPP-Regel prüfen → `START`.
`START` gibt echte Ticketaktionen einschließlich Versand/Speichern frei.

Bereits versendete Tickets nicht leeren/erneut senden. Die lokale Migration ändert
keine bestehenden Tickettexte. Eine bestehende Beschreibung gegebenenfalls manuell
korrigieren und nur Ticket speichern.

Zitierte Signaturen mit `>>` können nun erkannt werden; ein ausschließlich zitierter
Namenshinweis benötigt eine Bestätigung vor der Suche.

Anleitung: **README_0_7_4.md**. Tests: **docs/TESTBERICHT_0_7_4.md**.
Ältere READMEs und Konsolenhelfer sind historische Dokumentation/Werkzeuge.
