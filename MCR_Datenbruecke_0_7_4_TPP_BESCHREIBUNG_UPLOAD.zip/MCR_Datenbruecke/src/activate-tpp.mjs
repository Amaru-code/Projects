import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import readline from 'node:readline/promises';
import {stdin,stdout} from 'node:process';
import Core from '../lib/data-core.cjs';
import {sha256} from '../lib/core.mjs';
import {loadActiveMapping,publishActiveMapping} from '../lib/active-mapping.mjs';
import {upgradeTppMapping} from '../lib/tpp-migration.mjs';
import {SCHEMA,DESCRIPTION_POLICY} from '../lib/multirow-tpp-mapping.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const rl=readline.createInterface({input:stdin,output:stdout});
try{
  console.log('\n==============================================================\n MCR 0.7.4 - TPP in jeder Beschreibungszeile aktivieren\n==============================================================');
  console.log('Nur lokales JSON. Kein Excel-Zugriff, kein Edge, kein Ticket, keine Mail.');
  const old=loadActiveMapping(root);
  console.log('Aktiver Ausgangsstand: '+path.basename(old.path));
  const result=upgradeTppMapping(old.map);
  if(!result.changed){
    console.log('BEREITS AKTIV: TPP-Textregel V2. Keine neuen Dateien geschrieben.');
    console.log('DESCRIPTION_POLICY='+DESCRIPTION_POLICY);
  }else{
    const m=result.map;
    console.log('NEUE REGEL: C=1 -> DC; D=1 -> PP+; E=1 -> DB+; F=1 -> TPP.');
    console.log('Reihenfolge DC;PP+;DB+;TPP. Pro physischer Excel-Zeile eine Beschreibungszeile.');
    console.log('Null/0 ohne Kuerzel; alle Quelldaten bleiben erhalten; keine Zusammenfassung.');
    console.log('Geaenderte Personenbeschreibungen: '+result.changedPersons);
    console.log('Zusaetzlich durch TPP alleine verwendbar: '+result.newlyValid);
    console.log('Neu gesperrt (z.B. 450-Zeichen-Grenze): '+result.newlyBlocked);
    console.log('Neue Zusammenfassung:',m.payload.summary);
    const e=m.payload.entries['10102131'];
    if(e){
      console.log('\nKontrollfall 10102131:');
      for(const r of e.records)console.log('Excel-Zeile '+r.sourceRow+' | E/PensIntel='+r.pensIntel+' | F/TPP='+r.tpp+' | '+r.description);
      console.log('Fertige Beschreibung:\n'+e.description);
    }
    const answer=String(await rl.question('\nTPP-Textregel und neues Mapping aktivieren? JA: ')).trim();
    Core.need(/^ja$/i.test(answer),'ABORT','Abgebrochen. Aktiver Stand und Dateien bleiben unveraendert.');
    // Re-read binding before commit. A concurrent activation must never be overwritten.
    const current=loadActiveMapping(root);
    Core.need(current.path===old.path&&current.fileHash===old.fileHash&&sha256(fs.readFileSync(old.path))===old.fileHash,
      'ACTIVE_MAPPING_CHANGED','Mapping wurde waehrend der Freigabe geaendert. Erneut pruefen.');
    const a=publishActiveMapping(root,m,{beforeActivate(){
      const c=loadActiveMapping(root);
      Core.need(c.path===old.path&&c.fileHash===old.fileHash,'ACTIVE_MAPPING_CHANGED','Parallele Mapping-Aktivierung erkannt.');
    }});
    Core.need(a.map.schema===SCHEMA,'ACTIVE_VERIFY','Neuer TPP-Mappingstand wurde nicht aktiviert.');
    console.log('\n==============================================================\n FERTIG - TPP-MAPPING AKTIV\n==============================================================');
    console.log('NEW_MAPPING='+a.path);console.log('SHA256='+a.fileHash);console.log('ACTIVE_MAPPING='+a.pointerPath);
    console.log('Altes JSON bleibt erhalten; vorheriger Aktivierungszeiger liegt in activation_backups.');
    console.log('Keine bestehenden Ticketbeschreibungen geaendert. Bereits versendete Tickets NICHT leeren/neu versenden.');
    console.log('Naechster Schritt fuer noch offene leere Tickets: START_FULL_QUEUE_RUN.cmd');
  }
}catch(e){console.error('\nSTOP: '+(e.code||'ERROR')+' - '+e.message);process.exitCode=1;}
finally{rl.close();}
