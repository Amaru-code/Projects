# Level 05A.2 TypeScript Mode-1 Parity

Correctness-first independent TypeScript/Node port of the frozen LNW DC 1.0.3 business pipeline.

- TypeScript implements raw parsing, DU/DP classification, filtering, WWID mapping, merge, aggregation and LNW calculation.
- Microsoft Excel is accessed through a narrow PowerShell COM I/O bridge for the frozen XLSM template/recalculation/CSV output.
- No Python Oracle, C# worker or Rust worker is invoked.
- No new native candidate EXE is generated. The compiled TypeScript is JavaScript and runs inside the already installed `node.exe` runtime.
- v0.1.0 is correctness-first and processes source conversions sequentially. Optimization comes only after semantic parity is certified.


## v0.1.1

Compatibility fix for the newer TypeScript compiler installed on the benchmark laptop.

Removed obsolete compiler options that the current compiler rejects:
- `moduleResolution: "Node"` (legacy `node10`)
- `esModuleInterop: false`

The emitted module format remains `CommonJS`; no business logic, benchmark data,
Golden Reference, validator, or runtime contract changed.


## v0.1.2

CSV parity fix only.

The first complete TypeScript run already matched the Golden Reference for
`du_master`, `dp_master`, and `lnw_excel`. The CSV diagnostic found exactly
816 mismatches, all numeric-format-only: rows 2..409, columns A:B.

Excel COM exposes those cells as `Double`. Python's float representation keeps
the `.0` suffix for integral floats (`1.0`, `9999999.0`), while .NET's
`Double.ToString("R")` emitted `1` and `9999999`.

v0.1.2 appends `.0` for integral `Double` values in the CSV serializer.
No LNW business logic, workbook logic, benchmark input, Golden Reference, or
validator behavior changed.
