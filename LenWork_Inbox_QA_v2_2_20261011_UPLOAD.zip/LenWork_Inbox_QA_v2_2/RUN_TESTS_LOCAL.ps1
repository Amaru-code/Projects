<#
  LenWork QA - LOCAL ONLY, standard Python, optional Node.js.
  No Outlook/Graph calls, no mail dispatch.  Use an approved test mailbox separately.
#>
[CmdletBinding()]
param([string]$Results = "")
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$pythonCmd = Get-Command py -ErrorAction SilentlyContinue
$pythonArgs = @('-3')
if (-not $pythonCmd) {
    $pythonCmd = Get-Command python -ErrorAction SilentlyContinue
    $pythonArgs = @()
}
if (-not $pythonCmd) { throw 'Python 3 ist nicht installiert oder nicht auffindbar.' }
$exe = $pythonCmd.Source
Write-Host '== LenWork QA: Python Offline-Selbsttests ==' -ForegroundColor Cyan
& $exe @pythonArgs '-m' 'unittest' 'discover' '-s' 'tests' '-p' 'test_qa_offline.py' '-v'
if ($LASTEXITCODE -ne 0) { throw "Python tests failed with $LASTEXITCODE" }
$node = Get-Command node -ErrorAction SilentlyContinue
if ($node) {
    Write-Host '== LenWork QA: Node.js Offline-Coverage und Fetch-Tree ==' -ForegroundColor Cyan
    & $node.Source '.\tests\test_coverage_planner.js'
    if ($LASTEXITCODE -ne 0) { throw "Node coverage tests failed with $LASTEXITCODE" }
    & $node.Source '.\tests\test_fetch_tree.js'
    if ($LASTEXITCODE -ne 0) { throw "Node tree tests failed with $LASTEXITCODE" }
} else {
    Write-Warning 'Node.js nicht installiert; optionale JS-Tests uebersprungen.'
}
if ($Results) {
    Write-Host '== LenWork QA: echten synthetischen Label-Export pruefen ==' -ForegroundColor Cyan
    & $exe @pythonArgs '.\scripts\validate_qa_results.py' '--results' $Results '--report' '.\outputs\QA_ANON_RESULT.json'
    if ($LASTEXITCODE -ne 0) { throw 'Synthetische QA-Abnahme fehlgeschlagen. Siehe obigen Report.' }
}
Write-Host 'PASS: Offline-Pruefungen beendet; keine Mail versendet.' -ForegroundColor Green
