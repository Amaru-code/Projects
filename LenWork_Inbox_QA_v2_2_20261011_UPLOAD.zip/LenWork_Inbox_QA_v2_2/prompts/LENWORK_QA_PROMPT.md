# LenWork – READ-ONLY QA-Lauf mit 160 synthetischen Testfällen

Bitte fuehre fuer eine **ausdruecklich autorisierte Test-Inbox** und den Skill `inbox-urlaub-rueckblicke-v2` (QA-Kandidat v2.2) einen technisch nachvollziehbaren READ-ONLY-Test aus.

**Vorbereitung / Voraussetzungen:**
- Die Testmails müssen tatsaechlich in der zugelassenen Inbox vorliegen. Lokale `.eml`-Dateien allein reichen NICHT.
- Alle erkennbaren synthetischen Testmails besitzen `TESTFALL-ID: LWQA26-XXXX` im Body-Preview und einen Betreff, der `LWQA26-A`, `LWQA26-B`, `LWQA26-C` oder `LWQA26-D` enthaelt. In jedem Bucket sind laut Generator genau 40 verschiedene Testfälle.
- `oracle/gold.jsonl` NICHT lesen und keine erwarteten Prioritaeten aus externen Testloesungen verwenden.
- Vor jedem Abruf echte `msgraph_email`-Parameter und das reale `search`-Schema verifizieren. KEIN Graph-Token, KEIN direkter Netzwerkaufruf aus JS/Python, KEIN `nextLink`-Parameter erfinden.

**Aufgabe:**
1. Pruefe zuerst mit dem bestehenden Datums-Partitionierungsverfahren, ob der generische Inbox-Abruf des Testzeitraums vollstaendig nachweisbar ist. Markiere jeden Tag mit mindestens 50 Treffern als `SATURATED_DAY`/`UNRESOLVED`; keine falsche generische Vollstaendigkeit behaupten.
2. Wenn alle 160 Testmails am gleichen Tag eingegangen sind und die generische Vollstaendigkeit dadurch nicht nachweisbar ist, pruefe das tatsaechlich vorhandene `msgraph_email.search`-Schema. **Nur wenn** eindeutige serverseitige Suchgruppen fuer A/B/C/D moeglich sind und diese je unter 50 Treffern liefern, darfst du den BEKANNTEN TESTSATZ pro Gruppe suchen und erheben. Bei fehlender Schemafaehigkeit: STOPP mit technischer Meldung, keine erfundene Testabdeckung.
3. Bestaetige `TEST_FIXTURE_COVERAGE` nur durch vollstaendigen Abgleich aller erwarteten synthetischen `LWQA26-XXXX`-Kennungen, nicht durch blosse Summen. Diese Abnahme ist NICHT `COMPLETE_UNDER_TOOL_CONTRACT` fuer die allgemeine Inbox, falls ein einzelner Tag noch gesaettigt bleibt.
4. Falls 160 IDs erfasst: alle 160 Nachrichten nach `SKILL.md` und `absender` priorisieren, insbesondere HR-/IT-Pflichtausnahmen, direkte Fragen, Fristen, Eskalationen, informative CC-Mails, Newsletter und unklare Sachverhalte. Nur explizit belegte Arbeitsauftraege als sicher behaupten; Details bei Bedarf READ-ONLY lesen. **Keine neue Prioritaetspolitik stillschweigend einfuehren**; ROT/GELB-Direktanfragenkonflikte gesondert zaehlen.
5. Threads nur so sicher gruppieren, wie das Tool es erlaubt; identische Betreffzeilen sind kein Beweis fuer identische Threads. Der Goldstandard fuer erwartete Threads steht absichtlich **nicht** im Nachrichtentext. `thread_id` muss die eigene nachvollziehbare Gruppierungsentscheidung enthalten. Wenn Thread-Bindung mangels `conversationId`/Reply-Headers nicht verifizierbar ist: `THREAD_CONFIDENCE=PROVISIONAL`; kein sicherer Thread-PASS.
6. Exportiere `outputs/LWQA_RESULT.jsonl` mit **exakt einer Zeile pro synthetischer Fallnummer**. Schema: `{"case_id":"LWQA26-0001","priority":"ROT","review_required":false,"thread_id":"DEINE_GRUPPIERUNG","evidence_source":"preview"}`. Kein Name, keine echte Outlook-Message-ID, keine Absenderadresse, kein Text in diesem Export. Wenn nicht alle 160 Fälle verarbeitet werden konnten, exportiere den vorhandenen Teil und melde die genaue Restzahl.
7. Erstelle zusätzlich einen anonymisierten Bericht mit: `GENERIC_FETCH_STATUS`, `TEST_FIXTURE_COVERAGE`, `FETCH_CALLS`, `SPLITS`, `LEAF_COUNT`, `FETCH_AUDIT`, `ANALYZED_COUNT`, `REVIEW_REQUIRED_COUNT`, `BODY_FETCH_COUNT`, `PROVISIONAL_THREAD_COUNT`, `PRIORITY_POLICY_CONFLICT_COUNT`, `MUTATING_ACTION_COUNT`, `QA_ANALYSIS_STATUS`.
8. Einen kompletten binären Rekursionsbaum ohne Wiederholungs- oder Kontrollaufrufe nur mit der korrekten Relation `FETCH_CALLS = 2*SPLITS + 1` als auditiert melden. Zusaetzliche Aufrufe gesondert erklären. Wenn Baumprotokolle fehlen, `FETCH_AUDIT=NEEDS_RECONCILIATION`.
9. Niemals E-Mails senden, beantworten, loeschen, verschieben, kategorisieren oder als gelesen markieren. Kein Skill-Code darf Netzwerkrechte oder Tokens behaupten, die LenWork nicht freigegeben hat.

**Abschluss:** Nur synthetische IDs/Klassifikationen zur externen Pruefung exportieren, keine echten Firmeninhalte. Fehlende Nachrichten, unerreichbare Suche oder Abbruch als Teilresultat ausweisen und nicht als PASS maskieren.
