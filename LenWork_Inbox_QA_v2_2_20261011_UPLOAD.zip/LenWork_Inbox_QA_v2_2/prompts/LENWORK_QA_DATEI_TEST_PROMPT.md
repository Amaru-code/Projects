# LenWork QA – Datei-Test für 160 Beispiel-E-Mails (ohne Outlook)

Ich stelle dir entweder `mail_input.md` / `mail_input.jsonl` mit exakt **160 fiktiven E-Mail-Fällen** zur Verfügung ODER separat eine Datei `mail_input_A.md` / `mail_input_B.md` / `mail_input_C.md` / `mail_input_D.md` mit jeweils genau **40 Fällen**. Bitte verarbeite sie mit der Logik des Skills `inbox-urlaub-rueckblicke-v2` (QA-Kandidat v2.2), **OHNE** den Microsoft-365-Connector aufzurufen. Dieser Test bewertet die **Inhaltspriorisierung**, nicht die Inbox-Abrufschicht.

1. Prüfe, ob du die Datei wirklich vollständig lesen kannst. Falls nicht: melde `INPUT_STATUS=INCOMPLETE` statt so zu tun, als ob 160 beziehungsweise 40 Nachrichten verarbeitet worden wären. Jedes Objekt/jeder Abschnitt trägt eine eindeutige `TESTFALL-ID: LWQA26-NNNN`.
2. Ignoriere nicht die fachlichen Inhalte mit der Begründung, sie seien fiktiv. Bewerte jeden einzelnen Fall **so, als ob er eine echte Arbeits-Mail im beschriebenen Szenario wäre**. Die Testmarkierung dient nur zur Kennung und macht die Fachaufgabe nicht automatisch ignorierbar.
3. Wende die Logik von `skill/SKILL.md` einschliesslich der `absender`-Regeln an, sofern diese Skilldateien fuer dich erreichbar sind. Wenn die Regeln nicht lesbar sind, melde `RULES_STATUS=UNAVAILABLE` und kennzeichne die eingeschraenkte Auswertung.
4. Beurteile Handlungsaufforderungen, Terminsignale, direkte oder nur CC-Empfaenger, automatische Benachrichtigungen, die Ausnahmen fuer persoenliche Pflichten und die Unterschiede zwischen rot/gelb/blau/weiss. Fuer die Bewertung beziehe die Header `In-Reply-To`, `Message-ID` und den Inhalt der Nachricht ein. Behandle gleiche Betreffzeilen nicht automatisch als dieselbe Konversation.
5. Lies nicht die Datei `oracle/gold.jsonl` und keine Datei mit bereits festgelegten erwarteten Prioritaeten. Begruende jede Einstufung aus dem bereitgestellten Nachrichtenmaterial. Falls im eigentlichen Skill ROT/GELB fuer unmittelbare, aber nicht dringende Bitten widerspruechlich definiert sind, zaehle solche Faelle als `PRIORITY_POLICY_CONFLICT` und erfinde keine stillschweigende Regelentscheidung.
6. Arbeite in nachvollziehbaren Batches von hoechstens 20 Nachrichten, verliere dabei keinen Testfall. Fuehre einen technischen internen Ledger mit exakt einer Zeile pro `case_id`.
7. Erzeuge `outputs/LWQA_RESULT.jsonl` mit **exakt einer JSON-Zeile pro Fall** (bei vier Einzeldateien stattdessen `LWQA_A.jsonl`, `LWQA_B.jsonl`, `LWQA_C.jsonl` oder `LWQA_D.jsonl`):

   `{"case_id":"LWQA26-0001","priority":"ROT","review_required":false,"thread_id":"eigene_gruppierungsentscheidung","evidence_source":"file_body"}`

   Erlaubte Prioritaeten: `ROT`, `GELB`, `BLAU`, `WEISS`, `UNKLAR`. Keine echten Mailadressen, Inhalte oder Nutzerdaten in diesem Export. `thread_id` beschreibt deine eigene nachvollzogene Gruppenbildung; weise bei Unsicherheit auf provisorische Thread-Zuordnung hin.
8. In einem separaten anonymisierten Testbericht melde: `SOURCE=ATTACHED_SYNTHETIC_FILE`, `INPUT_COUNT`, `ANALYZED_COUNT`, `EXPORT_COUNT`, `UNCERTAIN_COUNT`, `POLICY_CONFLICT_COUNT`, `THREAD_CONFIDENCE`, `RULES_STATUS`, `INPUT_STATUS` und `QA_ANALYSIS_STATUS`.
9. **Nicht `FETCH_STATUS=COMPLETE_UNDER_TOOL_CONTRACT` behaupten:** In diesem Test wird Outlook nicht benutzt. Die 160 Dateien sind ein isolierter Klassifizierungs-Benchmark. Alle Schreib-/Sendeaktionen bleiben untersagt.

Ergebnis-Datei zur **externen, unabhängigen Bewertung** bereitstellen. Wenn du nicht alle 160 (bzw. 40 pro Einzeldokument) IDs zuverlässig nachweisen kannst, melde einen Teiltest und liefere nur belegte Fälle.
