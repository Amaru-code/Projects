#!/usr/bin/env python3
"""Compare LenWork's anonymized QA results with a PRIVATE local oracle.

Offline only. Never connects to Outlook, never sends mail, no dependencies.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path
import sys

VALID = {"ROT", "GELB", "BLAU", "WEISS", "UNKLAR"}
NORMALIZE = {
    "RED": "ROT", "🔴": "ROT", "SOFORT": "ROT", "SOFORT BEANTWORTEN": "ROT",
    "YELLOW": "GELB", "🟡": "GELB", "DIESE WOCHE": "GELB",
    "BLUE": "BLAU", "🔵": "BLAU", "ZUR KENNTNIS": "BLAU",
    "WHITE": "WEISS", "⚪": "WEISS", "IGNORIERBAR": "WEISS",
    "UNCLEAR": "UNKLAR", "UNSICHER": "UNKLAR",
}


def read_jsonl(path: Path) -> list[dict]:
    result = []
    with path.open("r", encoding="utf-8-sig") as f:
        for line_no, raw in enumerate(f, 1):
            if not raw.strip():
                continue
            try:
                entry = json.loads(raw)
            except json.JSONDecodeError as e:
                raise ValueError(f"{path}:{line_no}: invalid JSON: {e.msg}") from e
            if not isinstance(entry, dict) or not isinstance(entry.get("case_id"), str):
                raise ValueError(f"{path}:{line_no}: object and string case_id required")
            result.append(entry)
    return result


def normalized_priority(value) -> str:
    raw = str(value if value is not None else "").strip().upper()
    return NORMALIZE.get(raw, raw)


def evaluate(gold: list[dict], predicted: list[dict]) -> dict:
    gold_by_id = {r["case_id"]: r for r in gold}
    dup_gold = len(gold_by_id) != len(gold)
    first_by_id = {}
    duplicate_ids = []
    for p in predicted:
        key = p["case_id"]
        if key in first_by_id:
            duplicate_ids.append(key)
        else:
            first_by_id[key] = p
    missing = sorted(set(gold_by_id) - set(first_by_id))
    extra = sorted(set(first_by_id) - set(gold_by_id))
    matched, incorrect, red_total, red_correct = 0, [], 0, 0
    high_risk_ignored = []
    review_expected, review_marked = 0, 0
    invalid_labels = []
    confusion = defaultdict(Counter)
    for key in sorted(set(first_by_id) & set(gold_by_id)):
        p, g = first_by_id[key], gold_by_id[key]
        actual = normalized_priority(p.get("priority"))
        expected = g["expected_priority"]
        confusion[expected][actual] += 1
        if actual not in VALID:
            invalid_labels.append(key)
        if actual in g.get("accepted_priorities", [expected]) and (actual != "UNKLAR" or p.get("review_required") is True):
            matched += 1
        else:
            incorrect.append(key)
        if expected == "ROT":
            red_total += 1
            if actual == "ROT":
                red_correct += 1
        if g.get("personal_obligation") and actual == "WEISS":
            high_risk_ignored.append(key)
        if g.get("review_required"):
            review_expected += 1
            if p.get("review_required") is True:
                review_marked += 1
    # Thread groupings are optional to export but must be complete to claim thread PASS.
    participating = {k: first_by_id[k] for k in first_by_id if k in gold_by_id}
    with_thread = {k: str(r.get("thread_id", "")).strip() for k, r in participating.items()
                   if str(r.get("thread_id", "")).strip()}
    threads_evaluated = len(with_thread) == len(gold_by_id) and not missing and not extra
    false_merges = []
    false_splits = []
    if threads_evaluated:
        groups_by_pred = defaultdict(set)
        groups_by_gold = defaultdict(set)
        for key, pred_thread in with_thread.items():
            expected_thread = gold_by_id[key]["expected_thread_id"]
            groups_by_pred[pred_thread].add(expected_thread)
            groups_by_gold[expected_thread].add(pred_thread)
        false_merges = sorted(k for k, v in groups_by_pred.items() if len(v) > 1)
        false_splits = sorted(k for k, v in groups_by_gold.items() if len(v) > 1)
    total = len(gold_by_id)
    accuracy = matched / total if total else 0
    recall_red = red_correct / sum(g.get("expected_priority") == "ROT" for g in gold) if total else 0
    review_recall = review_marked / sum(g.get("review_required", False) for g in gold) if total else 0
    coverage_ok = not dup_gold and not missing and not extra and not duplicate_ids and len(first_by_id) == total
    quality_ok = bool(coverage_ok and accuracy >= 0.95 and recall_red == 1 and review_recall == 1
                      and not high_risk_ignored and not invalid_labels)
    full_ok = quality_ok and threads_evaluated and not false_merges and not false_splits
    return {
        "expected_fixtures": total,
        "reported_rows": len(predicted),
        "unique_reported_ids": len(first_by_id),
        "case_coverage": "PASS" if coverage_ok else "FAIL",
        "missing_count": len(missing), "missing_examples": missing[:10],
        "unexpected_count": len(extra), "unexpected_examples": extra[:10],
        "duplicate_count": len(duplicate_ids), "duplicate_examples": duplicate_ids[:10],
        "priority_accuracy": round(accuracy, 4),
        "priority_correct_count": matched,
        "priority_mismatch_count": len(incorrect), "priority_mismatch_examples": incorrect[:20],
        "red_recall": round(recall_red, 4), "red_correct": red_correct,
        "policy_disputed_cases": sum(bool(g.get("policy_dispute")) for g in gold),
        "policy_disputed_as_red": sum(bool(gold_by_id[k].get("policy_dispute")) and normalized_priority(p.get("priority")) == "ROT" for k, p in first_by_id.items() if k in gold_by_id),
        "policy_decision_required": any(g.get("policy_dispute") for g in gold),
        "review_recall": round(review_recall, 4),
        "personal_obligation_ignored_count": len(high_risk_ignored),
        "personal_obligation_ignored_examples": high_risk_ignored[:10],
        "invalid_label_count": len(invalid_labels),
        "thread_analysis": "EVALUATED" if threads_evaluated else "NOT_EVALUABLE",
        "false_thread_merges": len(false_merges) if threads_evaluated else None,
        "false_thread_splits": len(false_splits) if threads_evaluated else None,
        "priority_quality_gate": "PASS" if quality_ok else "FAIL",
        "end_to_end_qa_gate": "PASS" if full_ok else "FAIL_OR_NOT_EVALUABLE",
        "inbox_fetch_completeness_proven": False,
        "fetch_warning": "This evaluator checks only supplied synthetic case IDs. It cannot prove generic Outlook Inbox completeness or read-only tool actions.",
        "confusion_matrix": {k: dict(v) for k, v in sorted(confusion.items())},
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Offline golden-oracle validator for LenWork QA results JSONL")
    parser.add_argument("--oracle", type=Path,
                        default=Path(__file__).resolve().parents[1] / "oracle" / "gold.jsonl")
    parser.add_argument("--results", type=Path, required=True,
                        help="LenWork export: one JSON object per email, case_id, priority, review_required, thread_id")
    parser.add_argument("--report", type=Path, default=None,
                        help="Optional path to save anonymized metrics JSON (no message content)")
    args = parser.parse_args()
    try:
        report = evaluate(read_jsonl(args.oracle), read_jsonl(args.results))
    except (OSError, ValueError) as exc:
        parser.error(str(exc))
    rendered = json.dumps(report, ensure_ascii=False, indent=2)
    print(rendered)
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(rendered + "\n", encoding="utf-8")
    # Exit status 0 only when all gates including thread analysis pass.
    sys.exit(0 if report["end_to_end_qa_gate"] == "PASS" else 2)


if __name__ == "__main__":
    main()
