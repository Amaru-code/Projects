'use strict';
/* OFFLINE logger audit. Validates reported split-tree structure, NO Outlook or Graph access. */
const fs = require('node:fs');
const { dayNumber } = require('../tests/coverage_planner.js');
function auditTree(log) {
  if (!Array.isArray(log) || log.length === 0) return { status:'FAIL', issues:['No recorded calls'] };
  const issues = [], map = new Map();
  for (const n of log) {
    if (!Number.isInteger(n.id) || map.has(n.id)) issues.push('Duplicate or invalid node id: ' + String(n.id));
    map.set(n.id, n);
    if (n.parent !== null && !Number.isInteger(n.parent)) issues.push(`Node ${n.id}: invalid parent`);
    if (!Number.isInteger(n.hits) || n.hits < 0 || n.hits > 50) issues.push(`Node ${n.id}: invalid hits`);
    try { if (dayNumber(n.start) > dayNumber(n.end)) throw Error('reversed'); }
    catch { issues.push(`Node ${n.id}: invalid date interval`); }
  }
  const roots = log.filter(n=>n.parent===null), children = new Map();
  for (const n of log) {
    if (n.parent !== null) {
      if (!map.has(n.parent)) issues.push(`Node ${n.id}: missing parent ${n.parent}`);
      if (!children.has(n.parent)) children.set(n.parent,[]);
      children.get(n.parent).push(n);
    }
  }
  if (roots.length !== 1) issues.push(`Expected one root, got ${roots.length}`);
  let splits=0, leaves=0, saturatedDays=0;
  for (const n of log) {
    const cs=children.get(n.id)||[];
    if (cs.length) {
      splits++;
      if (n.hits!==50) issues.push(`Node ${n.id}: split without saturation`);
      if (cs.length!==2) issues.push(`Node ${n.id}: split must have exactly two children`);
      if (cs.length===2) {
        const ordered=cs.slice().sort((a,b)=>a.start.localeCompare(b.start));
        try {
          const a=ordered[0],b=ordered[1];
          if (a.start!==n.start || b.end!==n.end || dayNumber(b.start)!==dayNumber(a.end)+1)
            issues.push(`Node ${n.id}: child intervals not contiguous`);
        } catch { /* invalid interval already reported */ }
      }
    } else {
      leaves++;
      if (n.hits===50) {
        if (n.start===n.end) saturatedDays++;
        issues.push(`Node ${n.id}: saturated leaf is incomplete`);
      }
    }
  }
  if (log.length !== 2*splits+1) issues.push(`Node-count mismatch: ${log.length} vs ${2*splits+1} expected`);
  if (leaves !== splits+1) issues.push(`Leaf-count mismatch: ${leaves} vs ${splits+1} expected`);
  if (roots.length===1) {
    const seen = new Set(), stack=[roots[0]];
    while(stack.length){ const n=stack.pop(); if(seen.has(n.id)) {issues.push('Cycle detected'); break;} seen.add(n.id); stack.push(...(children.get(n.id)||[])); }
    if (seen.size!==log.length) issues.push(`Disconnected nodes: ${log.length-seen.size}`);
  }
  return {status:issues.length?'FAIL':'PASS',calls:log.length,splits,leaves,saturatedDays,issues};
}
if (require.main === module) {
  const filename = process.argv[2];
  if (!filename) { process.stderr.write('Usage: node scripts/check_fetch_tree.js <fetch_tree.json>\n'); process.exit(2); }
  try {
    const file=JSON.parse(fs.readFileSync(filename,'utf8'));
    const result=auditTree(Array.isArray(file)?file:file.calls);
    process.stdout.write(JSON.stringify(result,null,2)+'\n');
    if(result.status!=='PASS') process.exitCode=2;
  } catch(e) { process.stderr.write(String(e)+'\n');process.exitCode=2; }
}
module.exports = {auditTree};
