#!/usr/bin/env python3
"""Merge four synthetic-only LenWork JSONL result batches. Pure local file I/O."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from collections import Counter

def merge(inputs: list[Path], output: Path, tag: str = "LWQA26") -> dict:
    if not inputs:
        raise ValueError("At least one input required")
    if output.resolve() in {i.resolve() for i in inputs}:
        raise ValueError("Output path must be different from every input path")
    seen = set()
    entries = []
    per_file = {}
    for file in inputs:
        before = len(entries)
        with file.open("r", encoding="utf-8-sig") as fh:
            for line_no, raw in enumerate(fh, 1):
                if not raw.strip():
                    continue
                record = json.loads(raw)
                if not isinstance(record, dict):
                    raise ValueError(f"{file}:{line_no} expected object")
                cid = record.get("case_id")
                if not isinstance(cid, str) or not cid.startswith(tag+"-"):
                    raise ValueError(f"{file}:{line_no} bad case_id")
                if cid in seen:
                    raise ValueError(f"Duplicate ID across batches: {cid}")
                seen.add(cid)
                entries.append(record)
        per_file[file.name] = len(entries)-before
    entries.sort(key=lambda r: r["case_id"])
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("".join(json.dumps(r, ensure_ascii=False, sort_keys=True)+"\n" for r in entries), encoding="utf-8")
    return {"status":"MERGED", "total":len(entries), "batch_sizes":per_file, "output":str(output)}

def main():
    p = argparse.ArgumentParser(description="Merge read-only synthetic QA result batches")
    p.add_argument("inputs", type=Path, nargs="+")
    p.add_argument("--output", required=True, type=Path)
    p.add_argument("--tag", default="LWQA26")
    args = p.parse_args()
    try: print(json.dumps(merge(args.inputs,args.output,args.tag),ensure_ascii=False,indent=2))
    except (OSError,ValueError,json.JSONDecodeError) as e: p.error(str(e))

if __name__ == '__main__':
    main()
