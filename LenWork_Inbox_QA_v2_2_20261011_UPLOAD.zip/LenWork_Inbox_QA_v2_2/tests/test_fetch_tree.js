'use strict';
const assert = require('node:assert/strict');
const {auditTree} = require('../scripts/check_fetch_tree.js');
const nodes = [
  {id:1,parent:null,start:'2026-10-01',end:'2026-10-04',hits:50},
  {id:2,parent:1,start:'2026-10-01',end:'2026-10-02',hits:50},
  {id:3,parent:1,start:'2026-10-03',end:'2026-10-04',hits:50},
  {id:4,parent:2,start:'2026-10-01',end:'2026-10-01',hits:30},
  {id:5,parent:2,start:'2026-10-02',end:'2026-10-02',hits:30},
  {id:6,parent:3,start:'2026-10-03',end:'2026-10-03',hits:30},
  {id:7,parent:3,start:'2026-10-04',end:'2026-10-04',hits:30},
];
assert.equal(auditTree(nodes).status,'PASS');
assert.equal(auditTree(nodes).calls,7);
assert.equal(auditTree(nodes).splits,3);
assert.equal(auditTree(nodes.slice(0,5)).status,'FAIL');
const fake=nodes.map(x=>({...x}));fake[5].hits=50;
assert.equal(auditTree(fake).status,'FAIL');
const wrong=nodes.map(x=>({...x}));wrong[6].start='2026-10-03';
assert.equal(auditTree(wrong).status,'FAIL');
console.log('PASS fetch-tree validator: normal, missing branches, saturated day, overlapping child');
