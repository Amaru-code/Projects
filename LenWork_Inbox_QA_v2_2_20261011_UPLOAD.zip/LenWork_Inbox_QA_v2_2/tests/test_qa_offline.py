#!/usr/bin/env python3
"""Selftests exercise success AND adversarial failure cases. Only synthetic data."""
from __future__ import annotations
import copy
from datetime import date
import importlib.util
from pathlib import Path
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]

def import_file(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

gen = import_file("generate_qa_corpus", ROOT / "scripts" / "generate_qa_corpus.py")
val = import_file("validate_qa_results", ROOT / "scripts" / "validate_qa_results.py")

class OfflineTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory(prefix="lwqa-")
        cls.root = Path(cls.tmp.name)
        cls.summary = gen.create(cls.root, date(2026, 10, 11), "LWQA26")
        cls.gold = val.read_jsonl(cls.root / "oracle" / "gold.jsonl")
        cls.pred = [{"case_id": g["case_id"], "priority": g["expected_priority"],
                     "thread_id": g["expected_thread_id"], "review_required": bool(g["review_required"]),
                     "evidence_source": "fixture"} for g in cls.gold]
    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def test_total_and_bucket_balance(self):
        self.assertEqual(self.summary["fixture_count"], 160)
        self.assertEqual(set(self.summary["bucket_counts"].values()), {40})
        self.assertEqual(set(self.summary["expected_class_counts"].values()), {40})
        self.assertEqual(self.summary["thread_count"], 140)
        self.assertEqual(self.summary["same_subject_different_thread_cases"], 40)
        self.assertEqual(len(list((self.root / "fixtures").glob("*.eml"))), 160)

    def test_four_md_batches_represent_exactly_160_cases(self):
        seen = set()
        for bucket in "ABCD":
            blob = (self.root / "fixtures" / f"mail_input_{bucket}.md").read_text(encoding="utf-8")
            ids = [line.split()[-1] for line in blob.splitlines() if line.startswith("## Testfall ")]
            self.assertEqual(len(ids), 40)
            self.assertTrue(all(cid not in seen for cid in ids))
            seen.update(ids)
            self.assertNotIn("expected_priority", blob)
        self.assertEqual(len(seen), 160)
        input_data = val.read_jsonl(self.root / "fixtures" / "mail_input.jsonl")
        self.assertEqual(len(input_data), 160)
        self.assertTrue(all("expected_priority" not in row for row in input_data))

    def test_oracle_is_not_in_eml(self):
        for file in (self.root / "fixtures").glob("*.eml"):
            raw = file.read_text(encoding="utf-8")
            self.assertNotIn("expected_priority", raw)
            self.assertNotIn("review_required", raw)
            self.assertIn("TESTFALL-ID:", raw)

    def test_perfect_baseline_pass(self):
        r = val.evaluate(self.gold, self.pred)
        self.assertEqual(r["end_to_end_qa_gate"], "PASS")
        self.assertEqual(r["priority_accuracy"], 1.0)
        self.assertEqual(r["red_recall"], 1.0)

    def test_missing_mail_is_fail(self):
        r = val.evaluate(self.gold, self.pred[1:])
        self.assertEqual(r["case_coverage"], "FAIL")

    def test_duplicate_mail_is_fail(self):
        r = val.evaluate(self.gold, self.pred + [self.pred[0]])
        self.assertEqual(r["case_coverage"], "FAIL")

    def test_urgent_downgrade_is_fail(self):
        p = copy.deepcopy(self.pred)
        pos = next(i for i, g in enumerate(self.gold) if g["expected_priority"] == "ROT")
        p[pos]["priority"] = "BLAU"
        r = val.evaluate(self.gold, p)
        self.assertLess(r["red_recall"], 1.0)
        self.assertEqual(r["priority_quality_gate"], "FAIL")

    def test_personal_obligation_ignored_is_fail(self):
        p = copy.deepcopy(self.pred)
        pos = next(i for i, g in enumerate(self.gold) if g["personal_obligation"])
        p[pos]["priority"] = "WEISS"
        r = val.evaluate(self.gold, p)
        self.assertEqual(r["personal_obligation_ignored_count"], 1)
        self.assertEqual(r["priority_quality_gate"], "FAIL")

    def test_review_omitted_is_fail(self):
        p = copy.deepcopy(self.pred)
        pos = next(i for i, g in enumerate(self.gold) if g["review_required"])
        p[pos]["review_required"] = False
        r = val.evaluate(self.gold, p)
        self.assertLess(r["review_recall"], 1.0)
        self.assertEqual(r["priority_quality_gate"], "FAIL")

    def test_false_thread_merge_is_fail(self):
        p = copy.deepcopy(self.pred)
        candidates = [i for i, g in enumerate(self.gold) if g["subject_collision"]]
        a,b = candidates[:2]
        self.assertNotEqual(self.gold[a]["expected_thread_id"], self.gold[b]["expected_thread_id"])
        p[b]["thread_id"] = p[a]["thread_id"]
        r = val.evaluate(self.gold, p)
        self.assertGreater(r["false_thread_merges"], 0)
        self.assertEqual(r["end_to_end_qa_gate"], "FAIL_OR_NOT_EVALUABLE")

    def test_false_thread_split_is_fail(self):
        p = copy.deepcopy(self.pred)
        pair = [i for i, g in enumerate(self.gold) if "-PAIR" in g["expected_thread_id"]][:2]
        self.assertEqual(self.gold[pair[0]]["expected_thread_id"], self.gold[pair[1]]["expected_thread_id"])
        p[pair[1]]["thread_id"] = "incorrect-new-thread"
        r = val.evaluate(self.gold, p)
        self.assertGreater(r["false_thread_splits"], 0)
        self.assertEqual(r["end_to_end_qa_gate"], "FAIL_OR_NOT_EVALUABLE")

    def test_missing_thread_ids_cannot_claim_full_pass(self):
        p = copy.deepcopy(self.pred)
        for r in p: r.pop("thread_id")
        r = val.evaluate(self.gold, p)
        self.assertEqual(r["thread_analysis"], "NOT_EVALUABLE")
        self.assertEqual(r["end_to_end_qa_gate"], "FAIL_OR_NOT_EVALUABLE")

if __name__ == "__main__":
    unittest.main(verbosity=2)
