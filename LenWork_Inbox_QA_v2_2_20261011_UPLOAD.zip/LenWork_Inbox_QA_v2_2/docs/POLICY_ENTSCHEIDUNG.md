# Offene Owner-Entscheidung: Rot oder Gelb bei direkter Routineanfrage?

Die bisherigen Originalregeln enthalten gleichzeitig:

- ROT: eine direkte Frage oder Bitte an den Nutzer (`To`), auch ohne explizite Eilfrist.
- GELB: eine Bitte an den Nutzer ohne knappe Frist.

Beides kann für **dieselbe Mail** zutreffen. Der letzte reale Bericht zeigte viele gelbe Aufgaben und nur eine rote – ein konsistenter Zielmaßstab ist daraus nicht ableitbar.

Für die QA-Daten wurden 32 Routine-To-Fälle vorsorglich mit **beiden** erwarteten Kategorien akzeptiert und als `policy_dispute=true` gekennzeichnet. Dies ist **keine** fachliche Freigabe für beide Einstufungen in Produktion.

**Entscheidungsoptionen:**

- A – streng: Jede offene direkte Frage an den Nutzer => ROT; GELB nur indirekte/nicht zeitkritische Aufgaben oder Koordination ohne direkte Frage. Vorteil: wenig falsche Niedrigprioritäten; Nachteil: viele ROT.
- B – risikobasiert: ROT nur bei drängendem Handlungsbedarf, persönlichen engen Fristen, Eskalationen oder ausdrücklich zeitnah geforderter Antwort; gewöhnliche direkte Bitten ohne Eilbedarf => GELB. Vorteil: bessere Triage; Nachteil: erfordert zuverlässige Erkennung der Dringlichkeit.

Bis diese Entscheidung getroffen wurde, nutzt v2.2 die alte Regel für direkte ROT-Anfragen und weist Konflikte offen aus. Die Entscheidung ist **vor einer produktiven endgültigen Qualitätsschwelle** nötig.
