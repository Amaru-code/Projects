# LenWork Inbox QA v2.2 – Testlabor und Skill-Kandidat

**Stand:** 11.10.2026. **Keine Freigabe für automatischen E-Mail-Versand.** Keine Netzwerkaufrufe, keine Outlook-Anmeldung, keine Credentials in den Skripten.

## Ausgangslage und Motivation

Der LenWork-Connector `msgraph_email` akzeptiert maximal `count=50` und `date_range` nur auf Kalendertagsebene. Die produktive Strategie aus Skill v2.1 – rekursive Partitionierung – hat laut LenWork-Protokollen 266 Nachrichten sowie später 128/128 technisch abgedeckte Nachrichten geliefert. **Das beweist den Abruf in diesen Intervallen, nicht die Richtigkeit der Prioritäten.** Der 128er-Lauf las nur 6 Volltexte, wies sechs Fälle als unsicher aus und gruppierte Threads ohne gesicherte `conversationId`.

Der neue Skill v2.2 ist ein **QA-Kandidat**, der v2.1 beibehält und Belegpflicht, Unsicherheitsmarkierung, Thread-Prüfung sowie Test-Exports ergänzt. Die bisherige rote/gelbe Regelkollision bleibt eine zu treffende Owner-Entscheidung (siehe `POLICY_ENTSCHEIDUNG.md`).

## Inhalt

- `skill/SKILL.md`: vollständiger überarbeiteter Skill-Kandidat, kopierbar in LenWork.
- `skill/absender`: unveränderte Absenderregeln aus deinem bisherigen Paket. **Enthält reale Firmenadressen: nicht extern veröffentlichen.**
- `fixtures/*.eml`: 160 **nur lokal** erzeugte, fiktive Beispiel-E-Mails, vier Test-Suchgruppen A/B/C/D mit je 40 Nachrichten; keine echte Zustellung.
- `fixtures/mail_input.md` und `fixtures/mail_input.jsonl`: dieselben 160 fiktiven Nachrichten als zusammenhängende Datei für LenWork, falls Dateianhänge vollständig gelesen werden können. **Zusätzlich `mail_input_A.md` bis `mail_input_D.md` mit je 40 Nachrichten** für ressourcenschonende Einzelbatches.
- `fixtures/public_index.jsonl`: synthetische IDs und Gruppen, ohne erwartete Bewertung.
- `oracle/gold.jsonl`: **private lokale Ground-Truth**, pro Testfall Priorität, Thread-Zugehörigkeit und Risikoflag; **niemals vor der Bewertung an LenWork geben**.
- `scripts/generate_qa_corpus.py`: lokale Fixture-Generierung mit Python-Standardbibliothek (160 .eml).
- `scripts/validate_qa_results.py`: Ergebnisse aus LenWork gegen den lokalen Goldstandard vergleichen; Exitcode 0 nur bei bestandenem Gesamt-QA-Gate.
- `scripts/check_fetch_tree.js`: Abrufbaum-Protokolle unabhängig prüfen (Node.js, kein Netzwerk).
- `scripts/merge_qa_results.py`: vier Batch-Exporte zu einem anonymisierten 160-Fall-Ergebnis zusammenführen (verweigert doppelte IDs).
- `tests/test_qa_offline.py`, `tests/test_coverage_planner.js`, `tests/test_fetch_tree.js`: positive/negative QA-Tests.
- `prompts/LENWORK_QA_DATEI_TEST_PROMPT.md`: **erster empfohlener Test** mit `mail_input.md`, ohne Inbox oder Sendetest.
- `prompts/LENWORK_QA_PROMPT.md`: optionaler End-to-End-Auftrag für ein genehmigtes echtes Testpostfach.
- `docs/TESTPLAN_DE.md`: Durchführung, Limits und Akzeptanzgates.
- `RUN_TESTS_LOCAL.ps1`: lokale Test-/Validierungsroutine für Windows; PowerShell-Code **nicht auf Windows ausgeführt**, Python und JS sind offline getestet.

## Empfohlene Reihenfolge

**Zuerst nur Klassifizierung testen:** `fixtures/mail_input.md` in einen LenWork-Testchat laden (nur wenn Datei-Anhänge unterstützt werden) und `prompts/LENWORK_QA_DATEI_TEST_PROMPT.md` verwenden. Falls LenWork grosse Dateien nicht vollständig liest, nacheinander `mail_input_A.md` bis `mail_input_D.md` mit je 40 Nachrichten klassifizieren, jedes Ergebnis als eigenen JSONL-Export sichern und mit `merge_qa_results.py` zusammenführen. Hier ist keine Outlook-Pagination erforderlich. Die Datei umfasst alle 160 synthetischen Faelle und enthält **keine Soll-Kategorien**. Der danach zurückgelieferte Export `LWQA_RESULT.jsonl` wird lokal mit dem nicht hochgeladenen `oracle/gold.jsonl` bewertet. Wenn LenWork 160 Nachrichten aus einer einzigen hochgeladenen Datei nicht sicher verarbeiten kann, ist auch das ein wertvolles Ergebnis.

**Erst danach** bei Bedarf mit genehmigter Testinbox die reale Mailaufnahme prüfen (`LENWORK_QA_PROMPT.md`), getrennt von der Inhaltsbewertung. 160 Mails am selben Tag kollidieren mit der 50/Tages-Grenze und führen ohne verifizierte test-spezifische Suchpartition zu `SATURATED_DAY`.

## Sofort testen (Windows, ohne E-Mail-Versand)

Im entpackten Ordner ausführen:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\RUN_TESTS_LOCAL.ps1
```

Für einen späteren LenWork-Export mit anonymisierten synthetischen IDs:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\RUN_TESTS_LOCAL.ps1 -Results .\outputs\LWQA_RESULT.jsonl
```

Der Export muss **eine JSON-Zeile pro synthetischem Testfall** enthalten, z. B.:

```json
{"case_id":"LWQA26-0001","priority":"ROT","review_required":false,"thread_id":"T001","evidence_source":"preview"}
```

Der `thread_id` ist LenWorks **eigene Gruppierungsentscheidung**, nicht die Ground-Truth aus `oracle/`. Keine echten Message-IDs, Absender oder Texte in den QA-Export.

## Besonders wichtig: Zeitfenster-Limit

**160 jetzt zugestellte Nachrichten gehören alle zum heutigen Kalendertag.** Der Header `Date:` in einer `.eml`-Datei ändert beim normalen Senden nicht das echte Outlook-`receivedDateTime`. Beim jetzigen `msgraph_email`-Tool kann ein Kalendertag mit >50 passenden Nachrichten nicht generisch vollständig erfasst werden. `SATURATED_DAY` ist dann ein erwarteter technischer Grenzbefund, nicht automatisch ein Fehler der Klassifizierung.

Daher: Nur mit freigegebenem **dediziertem Testpostfach** (oder bereits über mehrere Tage verteiltem Bestandsdatensatz) arbeiten. Für einen Tag können die vier bekannten Tags `LWQA26-A/B/C/D` ggf. zum **test-spezifischen** Einzelabruf verwendet werden – aber nur, wenn LenWork die echten `search`-Parameter und Suchsemantik bestätigt. Nachweis aller 160 Test-IDs ist dann nur eine **Test-Fixture-Coverage**, keine allgemeine Inbox-Vollständigkeitsgarantie.

## Was die Skripte NICHT leisten

- Keine authentifizierten Graph-Calls aus LenWork-Skill-Dateien; dort fehlen Netzwerkfreigabe und OAuth-Token.
- Kein Versand, Importieren, Markieren oder Verschieben von E-Mails.
- Keine automatische Interpretation privater Outlook-Postfächer ohne die existierende LenWork-Integration.
- Keine automatische Untersuchung realer Unternehmensdaten durch den externen QA-Validator: ausschliesslich synthetische Fallnummern und Label-Codes.

## Vier Batch-Exporte zusammenführen (ohne Outlook)

```powershell
python .\scripts\merge_qa_results.py --output .\outputs\LWQA_RESULT.jsonl .\outputs\LWQA_A.jsonl .\outputs\LWQA_B.jsonl .\outputs\LWQA_C.jsonl .\outputs\LWQA_D.jsonl
python .\scripts\validate_qa_results.py --results .\outputs\LWQA_RESULT.jsonl
```

Der zweite Befehl liefert `end_to_end_qa_gate=PASS` nur wenn der reale anonymisierte LenWork-Export die vorab festgelegten QA-Schwellen erreicht.
