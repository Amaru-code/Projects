# Abnahmeplan: 160 synthetische E-Mails

## Testdaten

160 vollständig erfundene `.eml`-Nachrichten; je 40 Soll-Fälle für ROT, GELB, BLAU und WEISS. Vier ausgeglichene Suchgruppen `LWQA26-A`, `LWQA26-B`, `LWQA26-C`, `LWQA26-D` zu je 40 Fällen. Insgesamt 140 erwartete Thread-Gruppen, darunter 20 echte Zweier-Threads; 40 Fälle besitzen bewusst denselben Betreff wie eine andere unabhängige Nachricht. Zusätzlich 16 persönliche HR-/IT-Pflichtfälle, 16 explizite Unsicherheitsfälle und 32 rote/gelbe Policy-Konflikt-Fälle.

Synthetische Absender enden auf `.invalid`. Das sichert die lokale Fixture-Eindeutigkeit; bei Versand über einen echten Outlook-Account wird der tatsächliche Absender üblicherweise der autorisierte Account und nicht die frei gesetzte `.eml`-Absenderadresse. **Absenderregeln sind dadurch nicht automatisch end-to-end verifiziert!** Dafür müssen genehmigte Test-Senderaccounts mit zulässigem Versand verwendet werden.

## Ablauf

### A. Offline-QA (jetzt, ohne Postfachzugriff)

1. Skripte und `.eml`-Struktur prüfen (`RUN_TESTS_LOCAL.ps1` oder Python-/Node-Aufrufe).
2. Unabhängige lokale Wahrheit bleibt in `oracle/gold.jsonl`. Nicht in LenWork importieren.
3. Tests weisen bei fehlender Mail, doppelter ID, heruntergestufter ROT, ignorierter Pflichtaufgabe, nicht markierter Ungewissheit und falschem Thread-Merge bewusst FAIL nach.

### B. Sofort nutzbarer Datei-Test in LenWork (ohne Outlook)

1. Falls LenWork Dateiuploads für den Chat lesbar unterstützt: `fixtures/mail_input.md` bereitstellen, nicht `oracle/gold.jsonl`.
2. Prompt `prompts/LENWORK_QA_DATEI_TEST_PROMPT.md` einfügen; 160 Datensätze unabhängig priorisieren lassen.
3. Ergebnis `LWQA_RESULT.jsonl` exportieren und mit `validate_qa_results.py` vergleichen.
4. **Testaussage:** Qualitätsmessung der Dateibasierten Inhaltsanalyse; **kein** Beweis für Mailabruf/-Paging/-Senderauthentizität im Microsoft-365-Connector.

### C. Testmail-Zustellung (nur falls betrieblich freigegeben)

1. Dediziertes QA-Postfach bzw. autorisierten internen Mail-Simulator wählen. Nicht ohne Freigabe 160 Nachrichten an die produktive Firmen-Inbox senden.
2. Falls das Inbox-Tool unverändert bleibt: max. 40–45 an **tatsächlich verschiedenen Empfangstagen**, damit der generische Tagesabruf je ungesättigt bleiben kann; `Date:` in `.eml` ist **keine** Methode zum Zurückdatieren.
3. Für den gewünschten **Soforttest an einem Tag** bewusst zwischen zwei Ergebnissen unterscheiden:
   - `GENERIC_INBOX_FETCH=INCOMPLETE/SATURATED_DAY` (erwarteter Befund beim jetzigen Connector).
   - `TEST_FIXTURE_COVERAGE` kann separat geprüft werden, *falls* LenWork nach dokumentiertem Tool-Schema alle vier Tags A/B/C/D gezielt durchsuchen kann, jede Abfrage mit <50 endet und alle 160 IDs ermittelt. Solche Test-Tag-Suchen sind kein generischer Produktions-Fallback.
4. Eine bereitgestellte MIME-`.eml`-Datei wird nicht automatisch zu einer Mail im Inbox-Ordner. Der eigentliche Versand/Import ist ein separater, genehmigungspflichtiger Arbeitsschritt und gehört **nicht** zu diesen Skripten.

### D. LenWork Skill QA mit Testpostfach (READ-ONLY)

1. In einer **Testkopie** des Skills `skill/SKILL.md` einspielen; Original v2.1 bis zur Freigabe unverändert lassen.
2. QA-Prompt aus `prompts/LENWORK_QA_PROMPT.md` verwenden.
3. `outputs/LWQA_RESULT.jsonl` mit ausschliesslich synthetischen IDs und Statuscodes exportieren (keine Klarnamen, Original-MSG-IDs, Inhalte).
4. Die Datei lokal mit `validate_qa_results.py` gegen `oracle/gold.jsonl` testen.

### E. Abnahmekriterien

- Testdatensatz: **160/160 Fall-IDs**, 0 Dubletten, 0 unbekannte IDs (sonst keine QA-Vollständigkeit).
- Kategorien: >=95 % akzeptierte Klassifizierung (bei 32 Routine-To-Policy-Fällen werden ROT oder GELB provisorisch akzeptiert, bis Policy-Entscheidung gefallen ist).
- ROT-Recall: **100 %** für 40 eindeutig dringende Testfälle.
- Persönliche Pflichtfälle: **0** als WEISS ignoriert.
- Unsichere Fälle: **100 %** der 16 Unsicherheitsfälle durch `review_required=true` gekennzeichnet.
- Thread-Gruppen: **0** fälschlich verbundene, **0** fälschlich getrennte Threads; nur bewertbar, wenn alle 160 Entscheidungen eine testbare `thread_id` enthalten. Ein `conversationId` ist nicht verfügbar, daher kann eine unaufloesbare Threadbindung die volle QA-Freigabe rechtmaessig blockieren. Das ist kein Scheitern der Mailklassifizierung.
- READ-ONLY: über LenWork-Aktionslog separat prüfen; der lokale Validator kann keine Graph-Schreibaktionen ausschließen.
- `TECHNICAL_END_TO_END_PASS` im realen Postfach ist **nicht** gleich `PRIORITY_QUALITY_PASS` gegen eine bekannte Soll-Lösung.

## Bekannte, zuvor beobachtete Risiken

- 128/128 im Verarbeitungsledger; nur **6** Volltextabrufe. Die hohe Zahl allein ist kein Qualitätsbeleg.
- Pflichtschulungen mit abgelaufener Frist wurden als rein informativ beschrieben, ohne belastbaren Abschluss-/Nachholnachweis. In v2.2 wird hierfür `review_required` gefordert.
- Ein HR-Betreff mit persönlichem Bezug wurde ohne Volltext als sicher unmittelbar antwortpflichtig behandelt; v2.2 verlangt Handlungsbeleg oder Unsicherheitsmarkierung.
- Thread-Gruppierung über Betreff ist provisorisch; identische Betreffzeilen verschiedener Arbeitsvorgänge dürfen nicht blind zusammenfallen.
- Rekursionsbaum-Metrik: **7 Splits => 15 Knoten**, abweichende Zählung 16 benötigt separate Aufruf-Erklärung. **4 Blätter => 3 Splits => 7 Knoten**, die im letzten Abschlussbericht gezählten 5 Fetch-Aufrufe lassen zwei innere Split-Knoten unprotokolliert. Kein Beweis, dass der Abruf selbst fehlschlug, aber ein Audit-Gap.
