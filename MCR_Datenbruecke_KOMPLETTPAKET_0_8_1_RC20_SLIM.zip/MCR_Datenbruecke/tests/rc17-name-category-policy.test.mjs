import test from 'node:test';
import assert from 'node:assert/strict';
import Person from '../lib/person-quoted.cjs';
import {fixedQueryObservation} from '../lib/browser-workflow.mjs';

test('RC17 top-level email sender becomes search candidate, never credentials',()=>{
 const candidates=Person.candidates({body:'Bitte um Hilfe.',senderEmail:'martin.freibothe@intel.com'});
 assert.equal(candidates.length,1);
 assert.equal(candidates[0].firstName,'Martin');
 assert.equal(candidates[0].lastName,'Freibothe');
 assert.equal(candidates[0].sources.includes('Absender-E-Mail (Suchhinweis)'),true);
});
test('RC17 shared/role mailbox does not invent a name',()=>{
 for(const a of ['service.intel@mercer.com','no.reply@intel.com','team.support@intel.com']){
  assert.deepEqual(Person.candidates({body:'Bitte um Hilfe.',senderEmail:a}),[]);
 }
});
test('RC17 requires one exact category and never commits shortened input',()=>{
 assert.equal(fixedQueryObservation('Allgemeine Schriftwechsel','Allgemeine Schriftwechse'),'ONE_CHAR_PREFIX');
 assert.equal(fixedQueryObservation('Personenschriftwechsel','Personenschriftwechsel - potenzieller Haftungsfall'),'MISMATCH');
});
