/** Release QA only: actual Chromium, not a normal unit selftest. */
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';
import {fileURLToPath} from 'node:url';import {spawn} from 'node:child_process';import assert from 'node:assert/strict';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
for(const scenario of ['rc17-metadata-sender','rc17-delegated-category','rc17-wrong-category-only']){
 const temp=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC17-CHROMIUM-'));
 try{
  for(const dir of ['src','lib','config','examples'])fs.cpSync(path.join(root,dir),path.join(temp,dir),{recursive:true});
  const cfg=path.join(temp,'config/local-runner-queue-send.json');const json=JSON.parse(fs.readFileSync(cfg,'utf8'));
  Object.assign(json,{runtimeDirectory:'.runtime',profileDirectory:'.runtime/edge-profile',downloadDirectory:'.runtime/downloads',diagnosticDirectory:'diagnostics'});
  fs.writeFileSync(cfg,JSON.stringify(json,null,2)+'\n');
  const {code,out}=await new Promise((resolve,reject)=>{
   const child=spawn(process.execPath,[path.join(temp,'src/local-bot-full-run.mjs'),'--demo','--auto','--headless','--close-browser'],{cwd:temp,env:{...process.env,MCR_DEMO_SCENARIO:scenario},stdio:['ignore','pipe','pipe']});
   let out='';const onData=b=>{out+=b.toString();if(out.length>80000)out=out.slice(-40000);};child.stdout.on('data',onData);child.stderr.on('data',onData);
   const timeout=setTimeout(()=>child.kill(),100000);child.on('error',reject);child.once('exit',(code)=>{clearTimeout(timeout);resolve({code,out});});
  });
  const diag=JSON.parse(fs.readFileSync(path.join(temp,'diagnostics/last-result.json'),'utf8'));
  console.log('SCENARIO',scenario,'CODE',code,'ERROR',diag.lastError,'PROCESSED',diag.loop.processed);
  if(scenario==='rc17-wrong-category-only'){
   assert.notEqual(code,0);assert.equal(diag.send.clicked,false);assert.equal(diag.loop.processed,0);
   assert.ok(['FIXED_OPTION_NOT_FOUND','FIXED_OPTION_AMBIGUOUS'].includes(diag.lastError));
  }else{
   if(code!==0)console.error(out.slice(-5500));
   assert.equal(code,0);assert.equal(diag.loop.processed,2);assert.equal(diag.lastError,null);
   assert.equal(diag.demoBrowser.sendClicks,2);assert.equal(diag.demoBrowser.saveClicks,2);
   assert.equal(diag.demoBrowser.fixedOptionClicks['mainForm:category-value-id'],2);
   assert.equal(diag.manualNameConfirmations,0);
   if(scenario==='rc17-metadata-sender')assert.equal(diag.nameDiscovery.successfulSource,'SYSTEMDATEN_EMAIL_VON');
   if(scenario==='rc17-delegated-category')assert.ok(diag.fixedFieldResolution.some(x=>x.action?.includes('EXACT_OPTION_TRUSTED_CLICK')));
  }
  console.log('PASS '+scenario);
 }finally{fs.rmSync(temp,{recursive:true,force:true,maxRetries:3});}
}
