import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage,sleep} from '../lib/cdp.mjs';
import * as UI from '../lib/browser-workflow.mjs';
import Prep from '../lib/ticket-prep.cjs';

test('RC19 real ICEfaces HTML editable root, recipient input and already-sent proof',async()=>{
 const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC19-EDITOR-'));let browser,cdp;
 try{
  browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,extraArgs:process.platform==='linux'?['--no-sandbox','--disable-dev-shm-usage']:[]});
  ({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.url==='about:blank');
  const reply=Prep.replyText('Herr','Mustermann');
  await page.call(function(reply){
   document.body.innerHTML=`<div><label>E-mail von:</label> <label>max.mustermann@example.invalid</label></div>
   <table id="history"><thead><tr><th>Original</th><th>Von</th><th>An</th><th>Betreff</th><th>Inhalt</th><th>Datum</th></tr></thead><tbody>
    <tr><td><a href="GetFile?docId=1"><img src="images/email_incoming.png"></a></td><td>max.mustermann@example.invalid</td><td>support@example.invalid</td><td>Frage</td><td>Bitte prüfen</td><td>01.01.2026</td></tr>
    <tr id="sent"><td><a href="GetFile?docId=2"><img src="images/email_outgoing.png"></a></td><td>support@example.invalid</td><td>max.mustermann@example.invalid</td><td>[MERCER#90000001] Frage</td><td id="sent-content"></td><td>02.01.2026</td></tr>
   </tbody></table>
   <input id="mainForm:email-to-editable" value="max.mustermann@example.invalid">
   <textarea id="mainForm:emailMessageBodyRichEditor" style="display:none"></textarea>
   <iframe id="ck" style="width:500px;height:200px"></iframe>`;
   document.getElementById('sent-content').textContent=reply;
   const d=document.getElementById('ck').contentDocument;
   d.open();d.write('<html lang="de" contenteditable="true"><head><title>WYSIWYG</title><style id="survives">body{font-family:Arial}</style></head><body><p><br></p></body></html>');d.close();
  },reply);
  assert.equal((await UI.recipient(page)).address,'max.mustermann@example.invalid');
  assert.equal((await UI.priorAcknowledgementProof(page,'90000001')).verified,true);
  assert.equal((await UI.priorAcknowledgementProof(page,'90000002')).verified,false);
  assert.equal((await UI.priorAcknowledgementProof(page,'900000010')).verified,false);
  const ed=await UI.editor(page,reply);assert.ok(ed.ok,JSON.stringify(ed));
  const check=await page.call(function(){const d=document.getElementById('ck').contentDocument;return {head:d.head.querySelector('#survives')!==null,title:d.title,body:d.body.textContent};});
  assert.equal(check.head,true);assert.equal(check.title,'WYSIWYG');assert.ok(check.body.includes('Sehr geehrter Herr Mustermann'));
  // Change original sender; same outgoing text must NOT grant a skip.
  await page.call(()=>{document.querySelector('#history tbody tr:first-child td:nth-child(2)').textContent='other@example.invalid';});
  assert.equal((await UI.priorAcknowledgementProof(page,'90000001')).verified,false);
  console.log('PASS RC19_REAL_ICEFACES_EDITOR_HEAD_PRESERVED_RECIPIENT_CURRENT_TICKET_BOUND_NO_FALSE_SKIP');
 }finally{try{cdp?.close();}catch{}try{browser?.child?.kill();}catch{}await sleep(800);fs.rmSync(profile,{recursive:true,force:true,maxRetries:10,retryDelay:150});}
});
