import test from 'node:test';import assert from 'node:assert/strict';
import {selectCurrentIncomingRow} from '../lib/history-binding.mjs';
import {discoverNameHints} from '../lib/name-probes.mjs';
const from='max.mustermann@example.invalid',sent='support@example.invalid';
const incoming={sender:from,body:'Bitte helfen Sie mir mit meiner Anfrage.',direction:'INCOMING',subject:'Anfrage'};
const outgoing={sender:sent,body:'Vielen Dank, dass Sie sich mit uns in Verbindung gesetzt haben.',direction:'OUTGOING',subject:'Re: Anfrage'};
test('RC18 original inbound selected ahead of newer outgoing reply by bound sender',()=>{
 const r=selectCurrentIncomingRow([outgoing,incoming],from);assert.deepEqual(r,incoming);
 const scan=discoverNameHints({body:r.body,senderName:r.sender,senderEmail:from});
 assert.equal(scan.candidates.length,1);assert.equal(scan.candidates[0].firstName,'Max');assert.equal(scan.candidates[0].lastName,'Mustermann');
});
test('RC18 ignores outgoing-only history and conflicting bound senders',()=>{
 assert.equal(selectCurrentIncomingRow([outgoing],from),null);
 assert.equal(selectCurrentIncomingRow([incoming], 'other.person@example.invalid'),null);
});
test('RC18 legacy history accepted only for exactly one current row',()=>{
 const legacy={...incoming,direction:'UNKNOWN'};
 assert.equal(selectCurrentIncomingRow([legacy]),legacy);
 assert.equal(selectCurrentIncomingRow([legacy,{...legacy,body:'unrelated'}]),null);
});
test('RC18 name still fails closed for role address, ambiguous display and quoted mail',()=>{
 const scan=discoverNameHints({body:'Bitte bearbeiten.\n-----Original Message-----\nName: Max Mustermann',senderEmail:'no.reply@example.invalid'});
 assert.equal(scan.candidates.length,0);
});
