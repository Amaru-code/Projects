/** Browser regression matching the REAL ICEfaces table nesting and mail history,
 * with entirely synthetic identities, domains, dates, and IDs. No PROD HTML. */
import assert from 'node:assert/strict';import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage,sleep} from '../lib/cdp.mjs';
import {ticketSenderMetadata,historyMailSnapshots,acknowledgementAlreadyInHistory,editor} from '../lib/browser-workflow.mjs';
import {selectCurrentIncomingRow} from '../lib/history-binding.mjs';
import {discoverNameHints} from '../lib/name-probes.mjs';
import Prep from '../lib/ticket-prep.cjs';
const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC18-ICEFACES-'));
let browser,cdp;
try{
 browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,extraArgs:process.platform==='linux'?['--no-sandbox','--disable-dev-shm-usage']:[]});
 ({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.url==='about:blank');
 const reply=Prep.replyText('Herr','Mustermann');
 await page.call(function(reply){
  const doc=`<form id="mainForm">
  <table><tbody><tr><td><div><label>E-mail von:</label></div></td>
  <td><label>max.mustermann@example.invalid</label></td></tr>
  <tr><td><div><label>E-Mail an:</label></div></td><td><label>service@example.invalid</label></td></tr></tbody></table>
  <div id="mainForm:j_id5918"><table id="mainForm:j_id5922"><thead><tr>
  <th>Original</th><th>Von</th><th>An</th><th>Betreff</th><th>Inhalt</th><th>Datum</th><th>Anlage</th><th></th>
  </tr></thead><tbody>
  <tr><td><a href="GetFile?docId=123"><img src="images/email_incoming.png"></a></td>
  <td><label>max.mustermann@example.invalid</label></td><td>service@example.invalid</td><td>Anfrage</td><td>Bitte bearbeiten. Kein Name im Nachrichtentext.</td><td>01.01.2026</td><td></td><td></td></tr>
  <tr><td><a href="GetFile?docId=124"><img src="images/email_outgoing.png"></a></td>
  <td><label>service@example.invalid</label></td><td>max.mustermann@example.invalid</td><td>[MERCER#90000001] Anfrage</td><td id="sent-body"></td><td>02.01.2026</td><td></td><td></td></tr>
  </tbody></table></div>
  <textarea id="mainForm:emailMessageBodyRichEditor" style="display:none">&lt;html&gt;&lt;body&gt;&lt;p&gt;Ein bewusst vorhandener anderer Antwortentwurf.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</textarea>
  <iframe id="editorframe" style="width:500px;height:100px"></iframe>
  </form>`;
  document.body.innerHTML=doc;
  document.getElementById('sent-body').textContent=reply;
  const body=document.getElementById('editorframe').contentDocument.body;body.contentEditable='true';body.innerText='Ein anderer vorhandener Entwurf darf nicht ueberschrieben werden.';
 },reply);
 const meta=await ticketSenderMetadata(page);assert.equal(meta.ok,true,JSON.stringify(meta));assert.equal(meta.senderEmail,'max.mustermann@example.invalid');
 const history=await historyMailSnapshots(page);assert.equal(history.ok,true,JSON.stringify(history));assert.equal(history.rows.length,2);
 assert.equal(history.rows[0].direction,'OUTGOING');assert.equal(history.rows[1].direction,'INCOMING');
 const rows=history.rows.map(r=>({sender:r.sender,body:r.content,direction:r.direction}));
 const selected=selectCurrentIncomingRow(rows,meta.senderEmail);assert.ok(selected);assert.equal(selected.direction,'INCOMING');
 assert.equal(selected.sender,meta.senderEmail);
 const scan=discoverNameHints({senderEmail:meta.senderEmail,senderName:selected.sender,body:selected.body});
 assert.equal(scan.candidates.length,1);assert.equal(scan.candidates[0].firstName,'Max');assert.equal(scan.candidates[0].lastName,'Mustermann');
 assert.equal(await acknowledgementAlreadyInHistory(page,reply),true);
 const draft=await editor(page,reply);assert.equal(draft.ok,false);assert.equal(draft.occupied,true);assert.equal(draft.state,'CKEDITOR_DRAFT_OCCUPIED');
 assert.equal((await editor(page)).text,'Ein anderer vorhandener Entwurf darf nicht ueberschrieben werden.');
 console.log('PASS RC18_REAL_ICEFACES_DOM_SENDER_NEXT_TD_OUTGOING_FILTER_NAME_NO_MANUAL_DRAFT_PRESERVED');
}finally{try{cdp?.close();}catch{}try{browser?.child?.kill();}catch{}await sleep(850);try{fs.rmSync(profile,{recursive:true,force:true,maxRetries:10,retryDelay:180});}catch(e){console.error('Browser-Temp-Profil konnte nicht geloescht werden: '+e.code);}}
