# RC19 — bereits beantwortete Tickets sicher überspringen

**Grund:** RC18 meldete `REPLY_ALREADY_IN_HISTORY` und beendete den gesamten Lauf,
obwohl die Namenserkennung und COMARCH-Memberprüfung funktionierten. Für das
autorisierte Ticket war bereits eine ausgehende Empfangsbestätigung vorhanden.

## Änderungen

- Vor Änderungen am Ticket überprüft RC19 nur lesend eine nachweisbare ausgehende
  Empfangsbestätigung im aktuellen Ticket. Dafür müssen Eingangssender,
  Ausgangsempfänger, das Ticketkennzeichen `[MERCER#...]`, die Nachrichtenrichtung
  (COMARCH `email_outgoing`) und der Standardtext zusammenpassen.
- Ein solcher Treffer wird **übersprungen, nicht erneut versendet**, und die
  Suche fährt mit dem nächsten geeigneten Ticket fort. Der vorhandene Entwurf
  und alle Feldwerte bleiben unverändert. Der Speicherzustand des übersprungenen
  Tickets gilt ausdrücklich **nicht** als nachgewiesen.
- Mehrdeutige oder unvollständige Fälle bleiben gesperrt; beim gespeicherten
  Versandjournal und bei fehlender tatsächlicher Pilot-Abnahme gibt es keine
  Freigabe durch das Überspringen.
- Der tatsächliche Empfänger wird aus dem COMARCH-Eingabefeld
  `mainForm:email-to-editable` ausgelesen, nicht bloß aus dem HTML-Text der Zeile.
- Bei CKEditor `<html contenteditable="true">` wird ausschließlich der `<body>`
  des Editors befüllt. Head/Styles werden nicht überschrieben; ein vorhandener
  abweichender Entwurf bleibt blockierend geschützt.
- Bestehende Reihenfolge: `Second Level`, `Allgemeine Schriftwechsel`,
  Member-Fokuswechsel, ausschließlich `Personenschriftwechsel`, Signatur,
  Antwort, einmal senden, OK-Dialoge, einmal speichern.

**Qualifikation:** Synthetische Browsermodelle, keine reale COMARCH-Anmeldung.
`START.cmd` aus neuem entpackten ZIP → Menü 1 → `EINRICHTEN`.
`SICHER_KEIN_VERSAND` nie für ein bereits nachweislich gesendetes Ticket wählen.
