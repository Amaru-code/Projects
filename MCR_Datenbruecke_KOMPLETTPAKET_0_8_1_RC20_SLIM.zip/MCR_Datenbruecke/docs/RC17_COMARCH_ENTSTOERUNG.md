# RC17 – praxisorientierte Entstörung

## Unterschiede zu RC16

1. Name aus `E-Mail von:` in den Systemdaten des aktuellen Tickets zusätzlich zur Mailhistorie und Original-MSG lesen. Dieser Kandidat ist **nie** eine Identitätsfreigabe. Der zugehörige COMARCH Member inklusive Name und ggf. verbindlich genannter MercerID muss passen. Keine Rekonstruktion bei Rollenpostfächern.
2. ICEfaces-Vorschläge mit delegierter Klickbehandlung können als eindeutig sichtbarer, vollständig passender Text innerhalb der Vorschlagsliste ausgewählt werden. Orts- und Sichtbarkeitsbindung ans exakte Eingabefeld, physischer CDP-Mausklick, unmittelbar wiederholte Punktprüfung.
3. Gestufte Eingabeversuche: bereits sichtbarer Vorschlag, echte Tastatur, Fokuswechsel, Legacy-Input-Keyup, kürzerer Suchbegriff. Vor dem nächsten Schritt wird der eindeutige vollständige Vorschlag geklickt und nach Member-Fokus überprüft.
4. Ist die Vorschlagsliste für den Browser nicht eindeutig klickbar, darf ein Bediener sie einmal manuell wählen und der Bot überprüft den Zielwert danach. **Keine generellen Wiederholungen von Senden/Speichern/Weiterleiten**.
5. Gilt ausnahmslos: `Allgemeine Schriftwechsel`, **exakt `Personenschriftwechsel`**, `Second Level`, `INTL01 - Intel Deutschland GmbH`. Die Variante „Personenschriftwechsel - potenzieller Haftungsfall“ wird nicht akzeptiert.

## Sicherheit und Datenschutz

- Bis zu 100 lesende Namensprüfungen, nicht 100 blinde Browserklicks. Auch wenn der Absender fehlt, niemals einen Namen zur ID-Suche erfinden.
- Member-Identität und Bestandsabgleich aus aktivem Mapping unverändert. Alle Quellzeilen/TPP bleiben erhalten.
- Ein Sendeklick und dessen bestätigte OK-Dialoge, danach ein Speicherklick. Bereits gesendete Tickets werden nicht blind wiederholt.
- Die lokale Diagnose protokolliert Methoden/Status, nicht Absender-Adressen oder Mailinhalte.
- Browsermodelltests sind keine echte COMARCH-Abnahme.
