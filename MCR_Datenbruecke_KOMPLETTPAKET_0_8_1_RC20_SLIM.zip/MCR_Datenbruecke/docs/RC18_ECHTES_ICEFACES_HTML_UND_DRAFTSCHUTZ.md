# RC18 – Verbindliche HTML-basierte Korrektur

Datum: 27.10.2026. Quelle: vom Nutzer eingefügter COMARCH/ICEfaces-DOM einer realen Ticketmaske. Der reale HTML-Dump sowie personenbezogene Inhalte werden **nicht** ins Paket aufgenommen. Stattdessen enthält `tests/rc18-html-regression.mjs` eine datensparsame synthetische Nachbildung derselben DOM-Struktur.

## Root Causes

1. `ticketSenderMetadata` prüfte `label.nextElementSibling` und `label.parentElement`. In COMARCH liegt die Adresse unter `Systemdaten > E-mail von:` im **nächsten `<td>` des gleichen `<tr>`**. Deshalb blieb `senderEmail` leer.
2. `historyMailSnapshots` liefert Verlaufseinträge in umgekehrter Reihenfolge. Der neuste Eintrag kann bereits eine ausgehende Bestätigung sein, die bei der Namenserkennung nicht als Original-Eingangsmail behandelt werden darf.
3. `REPLY_WRITE`: Der CKEditor kann bereits einen benutzerseitig verfassten Entwurf enthalten. Der alte Ablauf prüfte auf eine bereits gesendete Standardantwort erst **nach** dem Versuch, den Antworteditor zu befüllen.

## Neue Regeln

- Senderadresse nur aus exakt `E-mail von:` benachbarter **Wertzelle**, oder entsprechend eindeutiger Altansicht. Nie `E-mail an:` oder Inhalt aus dem Nachrichtenverlauf als Systemdatenwert.
- Namenserkennung bindet die eingehende Historienzeile an diesen Sender und schließt Zeilen mit `email_outgoing.png` aus. Die persönliche Adresse ist nur ein Suchkandidat; Identitätsprüfung unverändert.
- Wenn die Standardbestätigung bereits im Verlauf steht, stoppt der Bot vor Bearbeitung des Entwurfs, vor festem Feldschreiben und vor Versand. Die korrekte Speicherung muss separat überprüft werden.
- Vorhandene CKEditor-HTML-Quelltexte, die nicht der vorgesehenen Bestätigung entsprechen, werden als **geschützter Entwurf** behandelt. Keine Überschreibung, kein Versand.
- Eine nachweislich bereits gesendete Nachricht darf nicht als `SICHER_KEIN_VERSAND` zur erneuten Versandfreigabe verwendet werden. Das ist nicht dasselbe wie ein vollständig gespeichertes Ticket.

## Testbedingungen

Tests simulieren zwei Verlaufseinträge im realen ICEfaces-Tabellenaufbau mit bewusst neuester AUSGANGS-Nachricht und älterer EINGANGS-Nachricht. Bei gleichem Zielnamen muss ausschließlich der Eingang als Namensquelle dienen; eine vorliegende Ausgangsbestätigung und ein fremder Entwurf führen vor neuem Sendeklick zum Sicherheitsstopp. Zusätzlich laufen die vier unveränderten Standarddemo-Szenarien und Upgrade-/Rollback-Tests.

## Grenzen

Test ist eine synthetische Chromium-DOM-Probe, kein Zugriff auf den Unternehmensserver. Der Nutzer muss bei einem bereits versendeten Ticket den tatsächlichen Versand und Speicherzustand in COMARCH prüfen. Ein echter neuer Ticketpilot bleibt erforderlich, bevor der reguläre Lauf freigegeben werden darf.
