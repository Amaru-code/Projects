# MCR Datenbrücke RC20 — Nachrichtenverlauf zählen und bereits versendete Standardantworten dokumentieren

**Betriebsstatus:** Release-Kandidat; bisher nur lokale, synthetische Chromium-Prüfungen. Kein Echtversand bei der Entwicklung.

## Überblick

- Im geöffneten, eindeutig gebundenen COMARCH-Ticket wird der sichtbare Nachrichtenverlauf über die sechs Spalten `Original`, `Von`, `An`, `Betreff`, `Inhalt`, `Datum` ausgelesen. Die wechselnden `j_id`-Nummern werden nicht zur Identifikation benötigt.
- Eingehende E-Mails werden anhand des `email_incoming.png`-Symbols erkannt, ausgehende anhand `email_outgoing.png`. Der Bericht zählt `Gesamt`, `Kunde` (eingehende externe Absender), `Von uns` (COMARCH-ausgehend), `System/Rückläufer` und `Unklar`. Automatische Exchange-Unzustellbarkeiten und bekannte Secure-Mail-Gateways werden nicht als Kundenpersonen gezählt. Unklare Richtung wird nicht erraten.
- Eine **bereits versandte Standardantwort** wird nur bei folgenden gemeinsam nachgewiesenen Tatsachen akzeptiert: genau ein ursprünglicher externer Absender, eine COMARCH-ausgehende Mail an exakt diesen Absender, korrekte aktuelle `[MERCER#TICKET-ID]` am Anfang des Betreffs und die beiden charakteristischen Textteile der Standardempfangsbestätigung. Eine abweichende Ticket-ID, reine Texteingabe, eingehende Mail, Rückläufer oder mehrere konkurrierende Antworten erlauben keine automatische Statusmarkierung.
- Bei eindeutigem Nachweis wird die zusätzliche Beschreibung **verlustfrei** mit einer neuen Zeile `Standardantwort versendet` ergänzt. Bestehende USC-, DC-, PP+-, DB+- und TPP-Zeilen bleiben unverändert. Die Markierung wird höchstens einmal ergänzt und anschließend mit **einem** verifizierten Speicherklick im COMARCH-Ticket persistiert. Ein unveränderter E-Mail-Entwurf wird niemals überschrieben. Kein neuer Versand.
- Anschließend folgt die Suche nach dem nächsten unbeantworteten Ticket. Wenn die Markierung nicht sicher geschrieben/gespeichert werden kann, erfolgt ein kontrollierter Stopp, **kein** doppelter Versand und **kein** stillschweigender Erfolg.
- Der laufende Einzelticket-Pilot und die Sperre für Menü 4 bleiben unverändert: Das reine Dokumentieren einer alten Antwort qualifiziert **nicht** als neuer erfolgreicher Versand- und Speicherpilot.

## Datenprüfung und Datenschutz

Im lokalen Diagnosebericht stehen nur Anzahl/Art der Mails, Nachweisstatus sowie die Markierungs-/Speicherbestätigung; keine Namen, Empfängeradressen oder Mailtexte. Unbestimmte Nachrichten werden als `Unklar` gemeldet. Bei mehreren Absendern oder widersprüchlicher Zuordnung wird nicht automatisch als Standardantwort markiert.

Die originale Namenssuche über eingehende Mail, Signatur, Systemdaten und `Von` bleibt erhalten; E-Mail-Adressbestandteile sind ausschließlich Suchkandidaten, keine Identitätsnachweise. COMARCH-Member und MercerID-Regeln gelten unverändert.

**Nicht mit Datenmigration verwechseln:** Ein kompletter Versand ist nicht gleichbedeutend mit erfolgreicher Speicherung. Für den neuen Hinweis gilt die unabhängige Speicherprüfung. Das historische Versandjournal bleibt unberührt.
