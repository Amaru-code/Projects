"""RC105 AO adapter: execute the central generator without duplicating its math.

No Excel values are calculated here. The central create_pdf function owns all
business data and workbook changes. This adapter binds input, serializes bot
calls, owns only its new Excel process, and verifies the returned PDF/audit.
"""
from __future__ import annotations

import argparse
import ast
import builtins
import contextlib
import errno
import stat
import shutil
import unicodedata
import hashlib
import io
import json
import os
from pathlib import Path
import re
import sys
import threading
import time
from datetime import datetime

MARKER = 'MCR_AO_BRIDGE_RESULT '
MAX_SOURCE = 2 * 1024 * 1024
MAX_PDF = 50 * 1024 * 1024


class BridgeError(Exception):
    def __init__(self, code, reason, missing_fields=None, details=None):
        super().__init__(reason)
        self.code = code
        self.missing_fields = missing_fields or []
        self.details = details or {}


def require(condition, code, reason):
    if not condition:
        raise BridgeError(code, reason)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_source(generator, expected_sha=None):
    generator = Path(generator).resolve(strict=True)
    require(generator.is_file() and generator.name == 'auszahlungsoption_generator.py',
            'AO_SCRIPT_PATH', 'Unerwarteter zentraler AO-Skriptname.')
    data = generator.read_bytes()
    require(0 < len(data) <= MAX_SOURCE, 'AO_SCRIPT_SIZE', 'Zentraler AO-Generator ist leer oder zu gross.')
    source_sha = sha(data)
    require(expected_sha is None or source_sha == expected_sha,
            'AO_SCRIPT_CHANGED', 'Zentraler Generator wurde nach der Vorpruefung geaendert.')
    tree = ast.parse(data, filename=str(generator))
    functions = {node.name: node for node in tree.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}
    require({'create_pdf', 'ask_stichtag', 'default_stichtag', 'lookup_person',
             'is_missing_contact_value', 'request_missing_address'}.issubset(functions),
            'AO_SCRIPT_CONTRACT', 'AO-Generator hat nicht die bestaetigte create_pdf/Stichtag-Schnittstelle.')
    args = functions['create_pdf'].args
    require(len(args.args) == 1 and not args.vararg and not args.kwarg,
            'AO_SCRIPT_CONTRACT', 'create_pdf erwartet nicht genau eine WWID.')
    return generator, data, source_sha


def probe(generator):
    # Read-only: do not import or call the business module at preflight time.
    _, _, source_sha = read_source(generator)
    import win32com.client  # noqa: F401
    import win32api  # noqa: F401
    import win32event  # noqa: F401
    import win32process  # noqa: F401
    return {'status': 'PROBE_OK', 'sourceSha256': source_sha}


@contextlib.contextmanager
def generator_lock(folder, wait_seconds=30):
    # One lock for the shared workbook, not one lock per WWID. The OS releases
    # it on a process crash; an old lock filename cannot block later runs.
    lock_path = Path(folder) / '.mcr_ao_generation.lock'
    stream = open(lock_path, 'a+b', buffering=0)
    locked = False
    try:
        if lock_path.stat().st_size == 0:
            stream.write(b'\0')
        deadline = time.monotonic() + wait_seconds
        while not locked:
            stream.seek(0)
            try:
                if os.name == 'nt':
                    import msvcrt
                    msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                locked = True
            except OSError:
                if time.monotonic() >= deadline:
                    raise BridgeError('AO_GENERATOR_BUSY', 'Ein anderer Bot berechnet bereits eine AO in dieser Arbeitsdatei.')
                time.sleep(0.2)
        yield
    finally:
        if locked:
            stream.seek(0)
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(stream.fileno(), fcntl.LOCK_UN)
        stream.close()


class DiscardOutput(io.TextIOBase):
    # Generator output can contain personal or financial data. The final result
    # below carries only the metadata needed for the specific attachment proof.
    def write(self, text):
        return len(text)

    def flush(self):
        pass


class OwnedExcel:
    """Keep process handles to DispatchEx instances; never kill by name/PID reuse."""
    def __init__(self):
        self.handles = []
        self.guard = threading.Lock()
        self.original = None
        self.client = None

    def install(self):
        import win32com.client as client
        import win32api
        import win32process
        self.client = client
        self.original = client.DispatchEx

        def dispatch(name, *args, **kwargs):
            require(str(name).lower() == 'excel.application', 'AO_COM_CLASS', 'Unerwartete COM-Anwendung im AO-Generator.')
            before_pids = set(win32process.EnumProcesses())
            app = self.original(name, *args, **kwargs)
            try:
                _, pid = win32process.GetWindowThreadProcessId(int(app.Hwnd))
                require(pid not in before_pids, 'AO_EXCEL_OWNERSHIP', 'DispatchEx hat keine neue eigene Excel-Instanz erstellt.')
                # PROCESS_TERMINATE | SYNCHRONIZE. Keeping this handle prevents
                # a later recycled PID from pointing cleanup at another app.
                handle = win32api.OpenProcess(0x0001 | 0x00100000, False, pid)
                with self.guard:
                    self.handles.append(handle)
            except Exception:
                # If DispatchEx unexpectedly reused an existing Excel process,
                # neither Quit nor process termination may touch that process.
                if 'pid' in locals() and pid not in before_pids:
                    try:
                        app.Quit()
                    except Exception:
                        pass
                raise BridgeError('AO_EXCEL_OWNERSHIP', 'Eigene Excel-Instanz konnte nicht eindeutig fuer die Bereinigung gebunden werden.')
            return app

        client.DispatchEx = dispatch

    def cleanup(self, grace_ms=5000):
        import win32api
        import win32event
        with self.guard:
            handles, self.handles = self.handles, []
        for handle in handles:
            try:
                if win32event.WaitForSingleObject(handle, grace_ms) == 258:
                    win32api.TerminateProcess(handle, 3)
                    win32event.WaitForSingleObject(handle, 1000)
            finally:
                handle.Close()

    def restore(self):
        if self.client is not None and self.original is not None:
            self.client.DispatchEx = self.original


def name_token(value):
    text = unicodedata.normalize('NFC', str(value or '')).lower()
    for old, new in (('ä', 'ae'), ('ö', 'oe'), ('ü', 'ue'), ('ß', 'ss')):
        text = text.replace(old, new)
    return re.sub(r'[^a-z0-9]+', '', text)


def result_filename(stichtag, name, wwid):
    return re.sub(r'[\\/:*?"<>|]+', '_', f'{stichtag:%Y-%m-%d}_Auszahlungsoption_{name}_{wwid}').strip(' ._') + '.pdf'


def result_snapshot(namespace, wwid, stichtag, person, request_id):
    """Keep the prior same-name PDF as a historical reference before export.

    The central calculator deliberately uses the same canonical filename for
    each year/person. Never mistake that previous file for this attempt's output.
    The bot lock covers the snapshot, history copy, generation and validation.
    """
    output, audits = Path(namespace['OUTPUT']), Path(namespace['AUDIT'])
    pdf = output / result_filename(stichtag, str(person['Name']).strip(), wwid)
    old_audits = {p.name.lower() for p in audits.iterdir() if p.name.lower().endswith('_' + wwid + '.json')} if audits.exists() else set()
    old_pdf = None
    if pdf.exists():
        require(pdf.is_file() and not pdf.is_symlink(), 'AO_RESULT_PATH', 'Vorhandene AO ist keine regulaere PDF-Datei.')
        before = pdf.stat()
        require(0 < before.st_size <= MAX_PDF, 'AO_RESULT_SIZE', 'Vorhandene AO kann nicht sicher archiviert werden.')
        old_hash = stable_file_digest(pdf)
        history = output / '.mcr_historie' / request_id
        require(history.parent.resolve() == output.resolve() / '.mcr_historie', 'AO_HISTORY_PATH', 'Historienordner ist nicht am freigegebenen Ausgabeort.')
        history.mkdir(parents=True, exist_ok=False)
        archive = history / pdf.name
        try:
            shutil.copy2(pdf, archive)
            after = pdf.stat()
            require((before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns) and
                    stable_file_digest(archive) == old_hash and stable_file_digest(pdf) == old_hash,
                    'AO_HISTORY_CHANGED', 'Vorhandene AO aenderte sich waehrend der Sicherung; keine Neuberechnung.')
            # Copy matching historic success audits with the archived original.
            # They remain references, never evidence for the new result.
            for old_audit in audits.iterdir() if audits.exists() else ():
                if old_audit.name.lower() not in old_audits or not old_audit.is_file() or old_audit.is_symlink() or old_audit.stat().st_size > 256 * 1024:
                    continue
                try:
                    data = json.loads(old_audit.read_text(encoding='utf-8-sig'))
                    if data.get('status') == 'success' and str(data.get('wwid')) == wwid and Path(data.get('pdf', '')).resolve() == pdf.resolve():
                        shutil.copy2(old_audit, history / old_audit.name)
                except (ValueError, OSError):
                    continue
        except OSError as exc:
            raise BridgeError('AO_HISTORY_BACKUP_FAILED', 'Vorhandene AO konnte nicht sicher gesichert werden; kein Berechnungsstart.') from exc
        old_pdf = (before.st_size, before.st_mtime_ns, old_hash)
    return {'pdf': pdf, 'previousPdf': old_pdf, 'auditNames': old_audits}


def verify_result(result, namespace, wwid, stichtag, started, source_sha, request_id, baseline):
    require(isinstance(result, tuple) and len(result) == 4,
            'AO_RESULT_SHAPE', 'Zentraler Generator hat kein vollstaendiges PDF/Audit-Ergebnis geliefert.')
    pdf, audit, record, person = result
    require(isinstance(person, dict) and str(person.get('WWID')) == str(int(wwid)),
            'AO_RESULT_WWID', 'Ergebnis-Person passt nicht zur freigegebenen WWID.')
    name = str(person.get('Name') or '').strip()
    require(bool(name) and len(name) <= 200, 'AO_RESULT_NAME', 'Membername fehlt im Generatorergebnis.')
    pdf = Path(pdf).resolve(strict=True)
    audit = Path(audit).resolve(strict=True)
    output = Path(namespace['OUTPUT']).resolve(strict=True)
    audits = Path(namespace['AUDIT']).resolve(strict=True)
    base = Path(namespace['BASE']).resolve(strict=True)
    require(output == base / 'Ausgabe PDF' and audits == base / 'Audit_Logs',
            'AO_OUTPUT_CONTRACT', 'Zentrale AO-Ausgabe-/Auditordner weichen vom bestaetigten Vertrag ab.')
    require(pdf.parent == output and audit.parent == audits and pdf.is_file() and audit.is_file(),
            'AO_RESULT_PATH', 'PDF oder Audit liegt ausserhalb des zentralen AO-Ausgabeordners.')
    expected_name = result_filename(stichtag, name, wwid)
    require(pdf.name == expected_name, 'AO_RESULT_FILENAME', 'AO-Dateiname stimmt nicht mit WWID, Name und Stichtag ueberein.')
    started_ms = int(started * 1000)
    require(pdf == baseline['pdf'].resolve() and audit.name.lower() not in baseline['auditNames'],
            'AO_RESULT_STALE', 'AO-Ergebnis oder Audit ist kein neuer Aufruf; alter Audit bleibt historische Referenz.')
    require(pdf.stat().st_mtime_ns / 1_000_000 >= started_ms and audit.stat().st_mtime_ns / 1_000_000 >= started_ms,
            'AO_RESULT_STALE', 'PDF oder Audit ist nicht eindeutig aus diesem Generatoraufruf.')
    require(128 <= pdf.stat().st_size <= MAX_PDF and 0 < audit.stat().st_size <= 1024 * 1024,
            'AO_RESULT_SIZE', 'PDF oder Audit hat keine gueltige Dateigroesse.')
    pdf_before = pdf.stat()
    pdf_data = pdf.read_bytes()
    require(pdf_data.startswith(b'%PDF-') and b'%%EOF' in pdf_data[-2048:],
            'AO_RESULT_PDF', 'PDF ist nicht vollstaendig geschrieben.')
    pdf_after = pdf.stat()
    require((pdf_before.st_size, pdf_before.st_mtime_ns) == (pdf_after.st_size, pdf_after.st_mtime_ns),
            'AO_RESULT_CHANGED', 'PDF wurde waehrend der Pruefung geaendert.')
    require(baseline['previousPdf'] is None or (pdf_after.st_size, pdf_after.st_mtime_ns, sha(pdf_data)) != baseline['previousPdf'],
            'AO_RESULT_STALE', 'Vorhandene PDF wurde nicht neu erzeugt.')
    audit_before = audit.stat()
    audit_data = audit.read_bytes()
    audit_after = audit.stat()
    require((audit_before.st_size, audit_before.st_mtime_ns) == (audit_after.st_size, audit_after.st_mtime_ns),
            'AO_RESULT_CHANGED', 'Audit wurde waehrend der Pruefung geaendert.')
    payload = json.loads(audit_data.decode('utf-8-sig'))
    require(payload.get('status') == 'success' and str(payload.get('wwid')) == wwid and
            payload.get('name') == name and payload.get('stichtag') == stichtag.strftime('%d.%m.%Y') and
            payload.get('record') == record and payload.get('contact_supplied') is False and Path(payload.get('pdf', '')).resolve(strict=True) == pdf,
            'AO_AUDIT_MISMATCH', 'Audit bestaetigt diesen Member, Stichtag und diese PDF nicht vollstaendig.')
    audit_time = datetime.fromisoformat(payload.get('timestamp', ''))
    require(int(started) <= audit_time.timestamp() <= time.time() + 2,
            'AO_AUDIT_STALE', 'AO-Audit stammt nicht aus diesem Aufruf.')
    return {'schema': 'MCR_AO_GENERATOR_PROOF_V1', 'requestId': request_id,
            'wwid': wwid, 'name': name, 'stichtag': stichtag.strftime('%d.%m.%Y'),
            'stichtagIso': stichtag.strftime('%Y-%m-%d'), 'file': str(pdf), 'auditFile': str(audit),
            'sha256': sha(pdf_data), 'bytes': len(pdf_data), 'auditSha256': sha(audit_data),
            'sourceSha256': source_sha, 'generatedAt': datetime.now().astimezone().isoformat(),
            'auditTimestamp': payload['timestamp'],
            'freshness': {'schema': 'MCR_AO_FRESH_GENERATION_V1', 'startedAtMs': started_ms,
                          'pdfMtimeMs': pdf_after.st_mtime_ns / 1_000_000,
                          'auditMtimeMs': audit_after.st_mtime_ns / 1_000_000, 'newPdf': True, 'newAudit': True}}


def stable_file_digest(filename):
    file = Path(filename)
    before = file.stat()
    require(file.is_file(), 'WORKBOOK_LOCKED_OR_IO', 'Berechnungsquelle ist keine lesbare Datei.')
    digest = hashlib.sha256()
    with file.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    after = file.stat()
    require((before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns),
            'WORKBOOK_LOCKED_OR_IO', 'Berechnungsquelle wurde waehrend der Lesepruefung geaendert.')
    return digest.hexdigest()


def require_contacts(namespace, person):
    missing = [field for field in ('Adresse', 'PLZ')
               if namespace['is_missing_contact_value'](person.get(field))
               or not str(person.get(field) or '').strip()]
    if missing:
        raise BridgeError('AO_CONTACT_DATA_REQUIRED',
                          'Adresse oder PLZ fehlt im Gesamtdatenbestand. Fehlende Felder: '
                          + ', '.join(missing) + '. Kein Berechnungsstart.', missing)
    return False


def check_person(namespace, person, wwid):
    require(isinstance(person, dict) and str(person.get('WWID')) == str(int(wwid))
            and bool(str(person.get('Name') or '').strip()),
            'AO_PREFLIGHT_PERSON', 'Stammdaten nicht eindeutig an die WWID gebunden.')
    require_contacts(namespace, person)


def technical_details(exc, operation, source='master'):
    # No raw COM error string: it may contain personal data or cell contents.
    details = {'operation': operation, 'source': source, 'exception_type': type(exc).__name__}
    for key in ('errno', 'winerror', 'hresult'):
        value = getattr(exc, key, None)
        if isinstance(value, int):
            details[key] = value
    return details


def source_error(exc, operation, source='master'):
    details = technical_details(exc, operation, source)
    winerror = details.get('winerror')
    hresult = details.get('hresult', 0) & 0xffffffff
    if winerror in (32, 33) or hresult in (0x80070020, 0x80070021):
        return BridgeError('MASTER_WORKBOOK_LOCKED' if source == 'master' else 'AO_SOURCE_READ_LOCKED',
                           'Lesender Dateizugriff durch nachgewiesenen Sharing-/Lock-Fehler blockiert.', details=details)
    if winerror in (53, 64, 67, 1201, 1231, 1232, 2250) or hresult in (0x80070035, 0x80070043):
        return BridgeError('MASTER_PATH_UNAVAILABLE' if source == 'master' else 'AO_SOURCE_PATH_UNAVAILABLE',
                           'Netzwerkpfad der Berechnungsquelle nicht erreichbar.', details=details)
    if isinstance(exc, PermissionError) or winerror == 5 or hresult == 0x80070005:
        return BridgeError('MASTER_READ_ACCESS_DENIED' if source == 'master' else 'AO_SOURCE_READ_ACCESS_DENIED',
                           'Lesender Zugriff auf die Berechnungsquelle verweigert.', details=details)
    return BridgeError('MASTER_OPEN_FAILED' if source == 'master' else 'AO_SOURCE_READ_FAILED',
                       'Lesender Zugriff fehlgeschlagen; Ursache nicht als Dateisperre nachgewiesen.', details=details)


def check_readable_master_path(master):
    # A ~$ owner file signals a possible WRITE conflict, not a read conflict.
    # It must not prohibit Excel's ReadOnly=True lookup. Do not delete it.
    try:
        parent = master.parent.stat()
        require(stat.S_ISDIR(parent.st_mode), 'MASTER_PATH_UNAVAILABLE', 'Stammdatenordner nicht erreichbar.')
    except FileNotFoundError as exc:
        raise BridgeError('MASTER_PATH_UNAVAILABLE', 'Stammdatenordner nicht erreichbar.',
                          details=technical_details(exc, 'stat_master_parent')) from exc
    except OSError as exc:
        raise source_error(exc, 'stat_master_parent') from exc
    try:
        info = master.stat()
        require(stat.S_ISREG(info.st_mode), 'MASTER_FILE_NOT_FOUND', 'Stammdatenpfad ist keine Datei.')
    except FileNotFoundError as exc:
        raise BridgeError('MASTER_FILE_NOT_FOUND', 'Stammdatenbestand fehlt im erreichbaren Ordner.',
                          details=technical_details(exc, 'stat_master')) from exc
    except OSError as exc:
        raise source_error(exc, 'stat_master') from exc


def read_person(namespace, app, wwid, operation):
    try:
        return namespace['lookup_person'](app, wwid)
    except BridgeError:
        raise
    except (LookupError, ValueError) as exc:
        raise BridgeError('AO_MASTER_PERSON_INVALID', 'WWID im IPP-Bestand nicht eindeutig oder Pflichtdaten fehlen.',
                          details=technical_details(exc, operation)) from exc
    except Exception as exc:
        raise source_error(exc, operation) from exc


def contact_preflight(namespace, wwid, stage=lambda name: None):
    # The canonical lookup uses Workbooks.Open(ReadOnly=True, UpdateLinks=0).
    # No workbook save, contact write, exclusive open or owner-file test here.
    check_readable_master_path(Path(namespace['MASTER']))
    app = None
    try:
        try:
            app = namespace['win32'].DispatchEx('Excel.Application')
            app.Visible = False
            app.DisplayAlerts = False
            app.AskToUpdateLinks = False
        except BridgeError:
            raise
        except Exception as exc:
            raise BridgeError('AO_EXCEL_INIT_FAILED', 'Eigene Excel-Leseinstanz konnte nicht initialisiert werden.',
                              details=technical_details(exc, 'excel_init')) from exc
        person = read_person(namespace, app, wwid, 'read_contact_data')
        stage('MASTER_READ_OK')
        check_person(namespace, person, wwid)
        return person
    finally:
        if app is not None:
            # Preserve the original read error even if the owned Excel instance
            # has already exited. OwnedExcel.cleanup handles remaining processes.
            pending = sys.exc_info()[0] is not None
            try:
                app.Quit()
            except Exception as exc:
                if not pending:
                    raise BridgeError('AO_EXCEL_CLOSE_FAILED', 'Eigene Excel-Leseinstanz konnte nicht geordnet beendet werden.',
                                      details=technical_details(exc, 'excel_close')) from exc


def generate(generator, wwid, request_id, expected_sha, timeout_seconds, emit, stichtag=None, stage=lambda name: None, expected_first=None, expected_last=None):
    require(re.fullmatch(r'[0-9]{4,15}', wwid) is not None, 'AO_WWID', 'WWID muss numerisch sein.')
    require(re.fullmatch(r'[a-f0-9]{32}', request_id) is not None, 'AO_REQUEST_ID', 'Generatoraufruf ist nicht gebunden.')
    generator, source, source_sha = read_source(generator, expected_sha)
    started = time.time()
    finished = threading.Event()
    excel = OwnedExcel()

    def watchdog():
        if finished.wait(timeout_seconds):
            return
        try:
            excel.cleanup(0)
        finally:
            emit({'status': 'FAILED', 'requestId': request_id, 'error': 'AO_GENERATOR_TIMEOUT',
                  'reason': 'AO-Berechnung hat die Wartezeit ueberschritten. Eigene Excel-Instanz bereinigt; kein automatischer zweiter Aufruf.'})
            os._exit(4)

    timer = threading.Thread(target=watchdog, daemon=True)
    original_input = builtins.input
    phase = {'answered': False}

    def controlled_input(prompt=''):
        contact_prompt = re.match(r'^(Adresse|PLZ)\s*:', str(prompt), re.IGNORECASE)
        if contact_prompt:
            field = 'PLZ' if contact_prompt.group(1).upper() == 'PLZ' else 'Adresse'
            raise BridgeError('AO_CONTACT_DATA_REQUIRED', f'Adresse oder PLZ fehlt im Gesamtdatenbestand. Angefordertes Feld: {field}. Bitte fachlich ergaenzen; keine erfundene Eingabe.', [field])
        raise BridgeError('AO_UNEXPECTED_INPUT', 'Zentraler AO-Generator fordert eine nicht bestaetigte Eingabe an.')

    try:
        with generator_lock(generator.parent):
            # Manual Excel users do not participate in the bot lock. Respect the
            # workbook owner file instead of opening their working file read-only
            # and failing only after export/save.
            require(not (generator.parent / '~$IPP_Leistungsberechnungen_Arbeitsdatei.xlsm').exists(),
                    'AO_WORKBOOK_BUSY', 'AO-Arbeitsdatei ist bereits in Excel geoeffnet. Bitte die Arbeitsdatei schliessen.')
            excel.install()
            builtins.input = controlled_input
            namespace = {'__name__': '_mcr_central_ao_generator', '__file__': str(generator), '__package__': None}
            sys.path.insert(0, str(generator.parent))
            timer.start()
            with contextlib.redirect_stdout(DiscardOutput()), contextlib.redirect_stderr(DiscardOutput()):
                exec(compile(source, str(generator), 'exec'), namespace)
                require(Path(namespace['BASE']).resolve() == generator.parent,
                        'AO_BASE_CONTRACT', 'Zentraler Generator verwendet ein unerwartetes Arbeitsverzeichnis.')
                require(Path(namespace['OUTPUT']).resolve() == generator.parent / 'Ausgabe PDF' and
                        Path(namespace['AUDIT']).resolve() == generator.parent / 'Audit_Logs' and
                        Path(namespace['WORKBOOK']).resolve() == generator.parent / 'IPP_Leistungsberechnungen_Arbeitsdatei.xlsm',
                        'AO_OUTPUT_CONTRACT', 'Generator verwendet unerwartete Arbeits-/Ausgabedateien.')
                default = namespace['default_stichtag']()
                require(isinstance(default, datetime) and (default.month, default.day) == (12, 31) and
                        default.year == datetime.now().year, 'AO_STICHTAG_DEFAULT', 'Generator-Standardstichtag weicht vom bestaetigten Jahresende ab.')
                selected = datetime.strptime(stichtag, '%d.%m.%Y') if stichtag else default
                require(selected == default, 'AO_STICHTAG_MISMATCH', 'Bot-Auftrag weicht vom freigegebenen Standardstichtag ab.')
                stage('PREFLIGHT')
                master_digest_before = None
                try:
                    master_digest_before = stable_file_digest(namespace['MASTER'])
                except (OSError, BridgeError):
                    # A direct file-read problem must not block a valid read-only COM lookup.
                    pass
                try:
                    preflight = contact_preflight(namespace, wwid, stage)
                except BridgeError as exc:
                    if exc.code == 'AO_CONTACT_DATA_REQUIRED' and master_digest_before:
                        try:
                            if stable_file_digest(namespace['MASTER']) == master_digest_before:
                                exc.details['master_sha256'] = master_digest_before
                        except (OSError, BridgeError):
                            pass
                    raise
                if expected_first is not None or expected_last is not None:
                    require(bool(expected_first and expected_last) and name_token(preflight['Name']) == name_token(expected_last) + name_token(expected_first),
                            'P2_AO_GENERATOR_PERSON', 'IPP-Name stimmt nicht mit dem verifizierten COMARCH-Member ueberein. Keine Berechnung.')
                stage('CONTACTS_COMPLETE')
                # Guard the SECOND, live lookup before any calculation or save.
                # No contact values are passed from the ticket or ever written by the bot.
                original_lookup = namespace['lookup_person']
                def guarded_lookup(app, requested):
                    require(str(requested) == wwid, 'AO_PREFLIGHT_WWID', 'Generator hat die freigegebene WWID gewechselt.')
                    try:
                        person = original_lookup(app, requested)
                    except BridgeError:
                        raise
                    except (LookupError, ValueError) as exc:
                        raise BridgeError('AO_MASTER_PERSON_INVALID', 'WWID im IPP-Bestand nicht eindeutig oder Pflichtdaten fehlen.',
                                          details=technical_details(exc, 'recheck_contact_data')) from exc
                    except Exception as exc:
                        raise source_error(exc, 'recheck_contact_data') from exc
                    check_person(namespace, person, wwid)
                    require(person == preflight, 'AO_MASTER_PERSON_CHANGED', 'Stammdaten der Person haben sich nach der Vorpruefung geaendert.')
                    return person
                namespace['lookup_person'] = guarded_lookup
                namespace['request_missing_address'] = lambda person: require_contacts(namespace, person)
                def forbid_contact_write(*args, **kwargs):
                    raise BridgeError('AO_CONTACT_WRITE_FORBIDDEN', 'Bot-Modus schreibt keine Kontaktdaten.')
                namespace['save_contact_to_master'] = forbid_contact_write
                def ask_default():
                    phase['answered'] = True
                    return selected
                namespace['ask_stichtag'] = ask_default
                # Byte digests bind calculation sources. Capture before/after
                # to enable conservative automatic reuse; lack of stable evidence
                # never makes an old result current. No extra financial formulas.
                source_files = {'master': namespace['MASTER'], 'control': namespace['CONTROL_TEMPLATE']}
                source_before = {}
                for key, file in source_files.items():
                    try:
                        source_before[key] = stable_file_digest(file)
                    except BridgeError as exc:
                        raise BridgeError('AO_SOURCE_CHANGED_DURING_READ', 'Berechnungsquelle nicht stabil lesbar; kein Berechnungsstart.',
                                          details={'operation': 'hash_before_generation', 'source': key}) from exc
                    except OSError as exc:
                        raise source_error(exc, 'hash_before_generation', key) from exc
                baseline = result_snapshot(namespace, wwid, selected, preflight, request_id)
                # Central audits have second-resolution names. Wait until a new
                # second if an earlier audit already uses the current timestamp.
                while datetime.now().strftime('%Y%m%d_%H%M%S_') + wwid + '.json' in baseline['auditNames']:
                    time.sleep(0.05)
                stage('GENERATION')
                started = time.time()
                result = namespace['create_pdf'](wwid)
                require(phase['answered'], 'AO_STICHTAG_MISSING', 'Zentraler Generator hat den Standardstichtag nicht bestaetigt.')
                proof = verify_result(result, namespace, wwid, selected, started, source_sha, request_id, baseline)
                try:
                    source_after = {key: stable_file_digest(file) for key, file in source_files.items()}
                    if source_before == source_after:
                        proof['calculationEvidence'] = {'schema': 'MCR_AO_CALCULATION_INPUTS_V1',
                            **source_after, 'workbook': stable_file_digest(namespace['WORKBOOK']),
                            'script': source_sha, 'record': int(result[2])}
                except (OSError, BridgeError):
                    # A fresh PDF proof is still returned, but may not be automatically reused.
                    pass
            excel.cleanup()
            return {'status': 'SUCCESS', 'proof': proof}
    finally:
        builtins.input = original_input
        excel.restore()
        try:
            excel.cleanup()
        finally:
            finished.set()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--probe', action='store_true')
    parser.add_argument('--generator', required=True)
    parser.add_argument('--wwid')
    parser.add_argument('--stichtag')
    parser.add_argument('--non-interactive', action='store_true')
    parser.add_argument('--request-id')
    parser.add_argument('--expected-first')
    parser.add_argument('--expected-last')
    parser.add_argument('--expected-source-sha256')
    parser.add_argument('--timeout-seconds', type=int, default=540)
    args = parser.parse_args()
    original_stdout = sys.stdout
    emit_lock = threading.Lock()

    def emit(payload):
        with emit_lock:
            original_stdout.write(MARKER + json.dumps(payload, ensure_ascii=True) + '\n')
            original_stdout.flush()

    try:
        if args.probe:
            result = probe(args.generator)
        else:
            require(5 <= args.timeout_seconds <= 1800, 'AO_TIMEOUT', 'Generator-Wartezeit ungueltig.')
            require(args.non_interactive and args.stichtag, 'AO_INPUT_CONTRACT', 'Bot-Aufruf benoetigt --non-interactive und --stichtag.')
            def stage(name):
                with emit_lock:
                    original_stdout.write('MCR_AO_BRIDGE_STAGE ' + name + '\n')
                    original_stdout.flush()
            result = generate(args.generator, args.wwid or '', args.request_id or '',
                              args.expected_source_sha256, args.timeout_seconds, emit, args.stichtag, stage, args.expected_first, args.expected_last)
        emit(result)
        return 0
    except Exception as exc:
        code = getattr(exc, 'code', 'AO_GENERATOR_FAILED')
        blocked = code in {'AO_CONTACT_DATA_REQUIRED', 'WORKBOOK_LOCKED_OR_IO', 'AO_MASTER_PERSON_INVALID',
                           'AO_MASTER_PERSON_CHANGED', 'AO_WORKBOOK_BUSY', 'AO_GENERATOR_BUSY',
                           'MASTER_FILE_NOT_FOUND', 'MASTER_PATH_UNAVAILABLE', 'MASTER_WORKBOOK_LOCKED',
                           'MASTER_READ_ACCESS_DENIED', 'MASTER_OPEN_FAILED', 'AO_SOURCE_READ_LOCKED',
                           'AO_SOURCE_PATH_UNAVAILABLE', 'AO_SOURCE_READ_ACCESS_DENIED', 'AO_SOURCE_READ_FAILED',
                           'AO_SOURCE_CHANGED_DURING_READ', 'AO_EXCEL_INIT_FAILED', 'AO_EXCEL_CLOSE_FAILED'}
        emit({'status': 'BLOCKED' if blocked else 'FAILED', 'requestId': args.request_id,
              'wwid': args.wwid, 'error': code, 'missing_fields': getattr(exc, 'missing_fields', []),
              'reason': str(exc)[:500], 'details': getattr(exc, 'details', {})})
        return 2 if blocked else 1


if __name__ == '__main__':
    sys.exit(main())
