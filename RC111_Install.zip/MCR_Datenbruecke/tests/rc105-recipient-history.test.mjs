import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {requireThat as need,sha256} from '../lib/core.mjs';
import {approveChangedRecipient,validRecipientChangeApproval} from '../lib/phase1-recipient-approval.mjs';
import {verifiedNewOutgoingAcknowledgement} from '../lib/mail-history-audit.mjs';
import {approvedEditorStillMatches} from '../lib/phase1-edited-reply.mjs';
import {sentNotice,permitAcknowledgement,validSendAcknowledgements} from '../lib/send-dialog-policy.mjs';
import {safePreactionSkip} from '../lib/preaction-skip.mjs';

const ticket='99990001',original='original@example.invalid',recipient='approved@example.invalid';
const text='Sehr geehrte Frau Beispiel, mit dieser E-Mail möchten wir Ihnen bestätigen, dass wir Ihr Ticket erhalten haben und unser Team derzeit daran arbeitet. Vielen Dank.';
const source='USC 10/ DC';
const snap=rows=>({ok:true,rows});
const inbound={documentId:'810',direction:'INCOMING',sender:original,recipient:'servicelineintel@mercer.com',subject:'[MERCER#99990001] Anfrage',content:'Bitte meinen Kontostand bereitstellen.',date:'before'};
const outgoing={documentId:'811',direction:'OUTGOING',sender:'servicelineintel@mercer.com',recipient,subject:'Re: [MERCER#99990001] Anfrage',content:text,date:'after'};

async function review({from=original,to=recipient,answer='JA',readRecipient=async()=>({ok:true,address:to})}={}){
 return approveChangedRecipient({ticketId:ticket,original:from,readRecipient,assertTicket:async id=>assert.equal(id,ticket),
  ask:async()=>answer,wait:async()=>{}});
}

test('RC105 explicit recipient approval is a frozen receipt for exactly one ticket and destination; ENTER is accepted',async()=>{
 const r=await review({answer:''});assert.equal(r.address,recipient);assert.equal(r.changed,true);
 assert.equal(Object.isFrozen(r.proof),true);assert.equal(Object.isFrozen(r),true);
 assert.equal(validRecipientChangeApproval(r.proof,ticket,recipient),true);
 assert.equal(validRecipientChangeApproval(r.proof,'99990002',recipient),false);
 assert.equal(validRecipientChangeApproval(r.proof,ticket,'third@example.invalid'),false);
 for(const p of [null,{},{...r.proof,operatorApproved:false},{...r.proof,stableReadback:false},{...r.proof,originalRecipient:recipient}])
  assert.equal(validRecipientChangeApproval(p,ticket,recipient),false);
});

test('RC105 changed recipient is verified from one genuinely new outgoing row only with its exact approval receipt',async()=>{
 const {proof}=await review();
 const good=verifiedNewOutgoingAcknowledgement(snap([inbound]),snap([inbound,outgoing]),ticket,recipient,{recipientApproval:proof});
 assert.equal(good.verified,true,good.reason);assert.equal(good.reason,'ONE_NEW_OUTGOING_TO_APPROVED_RECIPIENT');
 for(const p of [undefined,{}, {...proof,ticketId:'99990002'},{...proof,approvedRecipient:'third@example.invalid'}, {...proof,originalRecipient:'foreign@example.invalid'}, {...proof,operatorApproved:false}]){
  const r=verifiedNewOutgoingAcknowledgement(snap([inbound]),snap([inbound,outgoing]),ticket,recipient,{recipientApproval:p});
  assert.equal(r.verified,false,JSON.stringify(p));
 }
});

test('RC105 approved change preserves original document, outgoing direction, exact destination, content and subject checks',async()=>{
 const {proof}=await review();
 const verify=(before,after,extra={})=>verifiedNewOutgoingAcknowledgement(snap(before),snap(after),ticket,recipient,{recipientApproval:proof,...extra});
 const cases=[
  [[inbound],[inbound]],
  [[inbound],[inbound,{...outgoing,recipient:original}]],
  [[inbound],[inbound,{...outgoing,content:'Unrelated body'}]],
  [[inbound],[inbound,{...outgoing,subject:'[MERCER#99990002] Fremdes Ticket'}]],
  [[inbound],[inbound,{...outgoing,direction:'INCOMING'}]],
  [[inbound],[{...inbound,documentId:'900'},outgoing]],
  [[inbound],[{...inbound,content:'A different inbound message'},outgoing]],
  [[inbound],[{...inbound,sender:'foreign@example.invalid'},outgoing]],
  [[inbound],[inbound,outgoing,{...outgoing,documentId:'812'}]],
  [[inbound,outgoing],[inbound,outgoing]],
  [[inbound,{...outgoing,recipient:original}],[inbound,{...outgoing,recipient:original},{...outgoing,documentId:'812'}]],
  [[{...inbound,documentId:null}],[{...inbound,documentId:null},outgoing]],
  [[inbound],[inbound,{...outgoing,documentId:null}]],
 ];
 for(const [before,after]of cases)assert.equal(verify(before,after).verified,false,JSON.stringify(after));
 const custom='Eine ausdrücklich freigegebene individuelle Antwort mit einer konkreten Sachauskunft.';
 assert.equal(verify([inbound],[inbound,{...outgoing,content:custom}],{approvedReply:custom,operatorApproved:true}).verified,true);
 assert.equal(verify([inbound],[inbound,{...outgoing,content:custom+' Eine weitere Änderung.'}],{approvedReply:custom,operatorApproved:true}).verified,false);
});

test('RC105 relay or bounce destination can be corrected explicitly, while old automatic system exclusions remain',async()=>{
 for(const from of ['secureemail@mmc.com','postmaster@example.invalid']){
  const {proof}=await review({from});
  const entry={...inbound,sender:from,subject:from.startsWith('postmaster')?'Delivery status notification - failed':inbound.subject};
  assert.equal(verifiedNewOutgoingAcknowledgement(snap([entry]),snap([entry,outgoing]),ticket,recipient,{recipientApproval:proof}).verified,true);
  assert.equal(verifiedNewOutgoingAcknowledgement(snap([entry]),snap([entry,outgoing]),ticket,recipient).verified,false);
  if(from==='secureemail@mmc.com')assert.equal(verifiedNewOutgoingAcknowledgement(snap([entry]),snap([entry,{...outgoing,sender:'external@example.invalid'}]),ticket,recipient,{recipientApproval:proof}).verified,false);
 }
});

test('RC105 recipient skip carries the required no-send proof; explicit abort remains a run cancellation',async()=>{
 let e;try{await review({answer:'UEBERSPRINGEN'});}catch(error){e=error;}
 assert.equal(e?.code,'RECIPIENT_REVIEW_REQUIRED');
 assert.equal(safePreactionSkip(e.code,'DESCRIPTION_AND_FIXED_FIELDS',{ticketId:ticket,recipientReview:e.recipientReview}),'RECIPIENT_REVIEW');
 assert.equal(safePreactionSkip(e.code,'SEND_AND_SAVE',{ticketId:ticket,recipientReview:e.recipientReview}),null);
 assert.equal(safePreactionSkip(e.code,'DESCRIPTION_AND_FIXED_FIELDS',{ticketId:ticket,recipientReview:e.recipientReview,pending:true}),null);
 await assert.rejects(review({answer:'ABBRUCH'}),{code:'RECIPIENT_REVIEW_CANCELLED'});
});

function sendHarness({proof,currentRecipient=recipient,afterRows=[inbound,outgoing]}={}){
 const events=[],logs=[],diag={};let clock=1000,clicked=false,historyReads=0;
 const page={sessionId:'session',cdp:{on:()=>()=>{}},mouseClick:async()=>assert.fail('No HTML dialog expected')};
 const UI={
  historyMailSnapshots:async()=>{historyReads++;return snap(clicked?afterRows:[inbound]);},
  historyCount:async()=>clicked?afterRows.length:1,editor:async()=>({ok:true,empty:false,text}),
  assertTicket:async(_page,id)=>assert.equal(id,ticket),recipient:async()=>({ok:true,address:currentRecipient}),
  additionalDescriptionState:async()=>({ok:true,editable:true,value:source}),htmlOkProbe:async()=>({state:'NONE'}),
  refreshCurrentTicketHistory:async()=>({ok:true}),
 };
 const journal={begin:id=>{assert.equal(id,ticket);events.push('SEND_INTENT');},observe:(_id,event)=>events.push(event),set:(_id,state)=>events.push(state)};
 const overlay={gate:{revision:0},waitUntilResumed:async()=>{},commitAuthorization:async()=>events.push('COMMIT_APPROVAL')};
 const context={need,sha256,diag,UI,overlay,DEMO:false,DEMO_SCENARIO:'normal',Date:{now:()=>clock},sleep:async ms=>{clock+=ms;},
  validRecipientChangeApproval,verifiedNewOutgoingAcknowledgement,approvedEditorStillMatches,sentNotice,permitAcknowledgement,validSendAcknowledgements,
  log:s=>logs.push(s),show:()=>{},trustedAction:async(_page,_target,beforeClick)=>{await beforeClick();events.push('SEND_CLICK');clicked=true;},
  reviewUnverifiedSend:async()=>{events.push('MANUAL_HISTORY_REVIEW');throw Object.assign(new Error('No automatic proof'),{code:'TEST_MANUAL_HISTORY_REVIEW'});},
  ask:async()=>assert.fail('Unexpected manual prompt'),fail:(code,message)=>need(false,code,message)};
 const runner=fs.readFileSync(new URL('../src/local-bot-full-run.mjs',import.meta.url),'utf8');
 const start=runner.indexOf('async function sendOnce('),end=runner.indexOf('\n/** Ticket saving',start);
 assert(start>=0&&end>start);
 const send=vm.runInNewContext('('+runner.slice(start,end)+')',context);
 return {events,logs,diag,get historyReads(){return historyReads;},run:()=>send(page,{},ticket,journal,recipient,
  {savedDescription:source+'\nStandardantwort versendet',approval:{revision:0},preSendSource:source,approvedReply:text,recipientApproval:proof})};
}

test('RC105 actual sendOnce passes the receipt to the real history verifier and completes with one send, no manual fallback',async()=>{
 const {proof}=await review();const h=sendHarness({proof});await h.run();
 assert.equal(h.events.filter(x=>x==='SEND_CLICK').length,1);
 assert.equal(h.events.filter(x=>x==='SEND_INTENT').length,1);
 assert(h.events.includes('OPERATOR_RECIPIENT_CHANGE_APPROVED'));
 assert(h.events.includes('SENT_CONFIRMED'));assert(!h.events.includes('MANUAL_HISTORY_REVIEW'));
 assert.equal(h.diag.send.ackMode,'BOUND_NEW_OUTGOING_HISTORY');assert.equal(h.diag.send.verified,true);assert(h.historyReads>=3);
});

test('RC105 actual sendOnce refuses stale approval or a third recipient before any send intent',async()=>{
 const {proof}=await review();
 const stale=sendHarness({proof:{...proof,ticketId:'99990002'}});
 await assert.rejects(stale.run(),{code:'RECIPIENT_APPROVAL_BINDING'});assert.deepEqual(stale.events,[]);
 const changed=sendHarness({proof,currentRecipient:'third@example.invalid'});
 await assert.rejects(changed.run(),{code:'RECIPIENT_CHANGED_AT_CLICK'});assert.deepEqual(changed.events,[]);
});

test('RC105 failed outgoing proof in actual sendOnce never triggers a second send',async()=>{
 const {proof}=await review();const h=sendHarness({proof,afterRows:[inbound,{...outgoing,recipient:'wrong@example.invalid'}]});
 await assert.rejects(h.run(),{code:'TEST_MANUAL_HISTORY_REVIEW'});
 assert.equal(h.events.filter(x=>x==='SEND_CLICK').length,1);assert.equal(h.events.filter(x=>x==='SEND_INTENT').length,1);
 assert(!h.events.includes('SENT_CONFIRMED'));assert.equal(h.diag.send.verified,false);
});
