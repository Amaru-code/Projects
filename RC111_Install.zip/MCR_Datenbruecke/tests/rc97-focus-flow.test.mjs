import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {focusInput} from '../lib/input-focus.mjs';
import {setInputQuery,typeTrustedFixedQuery} from '../lib/browser-workflow.mjs';
import {phase1SignatureState,mayChoosePhase1Signature,mayRetryPhase1Signature} from '../lib/phase1-signature-policy.mjs';

const memberId='mainForm:member-value-id';
function inputHarness({value='',focused=false,duplicate=false,covered=false,onClick=null,onRead=null,onPoint=null}={}){
 const calls={mouse:0,manual:0,scroll:[],events:[]};
 const fields=[];
 const doc={activeElement:null,querySelectorAll:()=>fields,getElementById:id=>fields.find(f=>f.id===id),
  elementFromPoint:()=>covered?{tagName:'DIV'}:fields[0]};
 const win={getComputedStyle:()=>({display:'block',visibility:'visible'}),innerWidth:1200,innerHeight:900};
 doc.defaultView=win;
 const create=()=>({id:memberId,tagName:'INPUT',value,isConnected:true,disabled:false,readOnly:false,ownerDocument:doc,
  scrollIntoView:o=>calls.scroll.push(o.block),getClientRects:()=>[{left:20,top:30,right:320,bottom:60}]});
 fields.push(create());if(duplicate)fields.push(create());
 if(focused)doc.activeElement=fields[0];
 const context=vm.createContext({document:doc,setTimeout:fn=>{fn();return 1;}});
 const api={calls,doc,fields,create,replace(){const was=fields[0];was.isConnected=false;fields[0]=create();doc.activeElement=null;return fields[0];}};
 api.page={sessionId:'test',call:async(fn,...args)=>{
  if(fn.name==='inputState')onRead?.(api);
  if(fn.name==='inputPointStillBound')onPoint?.(api);
  context.args=args;
  return vm.runInContext('('+fn.toString()+')(...args)',context);
 },mouseClick:async()=>{calls.mouse++;doc.activeElement=fields[0];await onClick?.(api);},
 cdp:{send:async(method,p)=>{
  calls.events.push({method,...p});
  if(method==='Input.insertText')fields[0].value=p.text;
  if(method==='Input.dispatchKeyEvent'&&p.type==='char')fields[0].value+=p.text;
 }}};
 return api;
}

test('RC97 delayed focus confirmation settles without a manual prompt or second click',async()=>{
 let reads=0;
 const h=inputHarness({onClick:({doc})=>{doc.activeElement=null;},onRead:h=>{
  if(h.calls.mouse&&++reads===3)h.doc.activeElement=h.fields[0];
 }});
 const r=await focusInput(h.page,memberId,{wait:async()=>{},manualGate:async()=>h.calls.manual++});
 assert.equal(r.ok,true);assert.equal(h.calls.mouse,1);assert.equal(h.calls.manual,0);
 assert.equal(h.calls.scroll[0],'nearest');
});

test('RC97 ICEfaces replacement gets at most one fresh same-input focus retry',async()=>{
 const h=inputHarness({value:'Example Person',onClick:h=>{if(h.calls.mouse===1)h.replace();}});
 const r=await focusInput(h.page,memberId,{wait:async()=>{},manualGate:async()=>h.calls.manual++});
 assert.equal(r.ok,true);assert.equal(r.method,'TRUSTED_INPUT_REBOUND');
 assert.equal(h.calls.mouse,2);assert.equal(h.calls.manual,0);assert.equal(h.fields[0].value,'Example Person');
});

test('RC97 changed Member content is never clicked again as a focus retry',async()=>{
 const h=inputHarness({value:'Example Person',onClick:h=>{h.replace();h.fields[0].value='Different Person';}});
 const r=await focusInput(h.page,memberId,{wait:async()=>{}});
 assert.equal(r.ok,false);assert.equal(r.state,'INPUT_VALUE_CHANGED_DURING_FOCUS');assert.equal(h.calls.mouse,1);
});

test('RC97 overlay and duplicate IDs cannot become trusted input clicks',async()=>{
 for(const opts of [{covered:true},{duplicate:true}]){
  const h=inputHarness(opts);const r=await focusInput(h.page,memberId,{wait:async()=>{}});
  assert.equal(r.ok,false);assert.equal(h.calls.mouse,0);assert.equal(h.calls.events.length,0);
 }
});

test('RC97 focus coordinate invalidated before click is re-probed without blind click',async()=>{
 const h=inputHarness({onPoint:h=>{h.doc.elementFromPoint=()=>({tagName:'BUTTON'});}});
 const r=await focusInput(h.page,memberId,{wait:async()=>{}});
 assert.equal(r.ok,false);assert.equal(h.calls.mouse,0);
});

test('RC97 focused input fast path leaves geometry and text untouched',async()=>{
 const h=inputHarness({value:'INTL01-11999001 | Example Person',focused:true});
 const r=await focusInput(h.page,memberId,{wait:async()=>{}});
 assert.equal(r.method,'ALREADY_FOCUSED');assert.equal(h.calls.mouse,0);assert.equal(h.calls.scroll.length,0);
});

test('RC97 Member searches use native typing with a real final digit key event',async()=>{
 const h=inputHarness({focused:true});
 assert.equal(await setInputQuery(h.page,memberId,'999001'),true);
 assert.equal(h.fields[0].value,'999001');
 assert.ok(h.calls.events.some(x=>x.method==='Input.insertText'&&x.text==='99900'));
 assert.ok(h.calls.events.some(x=>x.type==='keyUp'&&x.key==='1'&&x.code==='Digit1'));
 assert.equal(h.calls.mouse,0);
});

test('RC97 native search releases Control if selection is interrupted',async()=>{
 const h=inputHarness({focused:true});const raw=h.page.cdp.send;
 h.page.cdp.send=async(m,p)=>{await raw(m,p);if(p.type==='rawKeyDown'&&p.key==='a')throw Error('CDP interruption');};
 await assert.rejects(()=>typeTrustedFixedQuery(h.page,memberId,'Example Person'),/CDP interruption/);
 assert.ok(h.calls.events.some(x=>x.type==='keyUp'&&x.key==='Control'));
 assert.equal(h.fields[0].value,'');
});

function fixedHarness({already=false,subcategoryNeedsMember=false,foreignSignature=false,unstableSignature=false,duplicateSignature=false,codeOnlySignature=false}={}){
 const source=fs.readFileSync(new URL('../src/local-bot-full-run.mjs',import.meta.url),'utf8');
 const a=source.indexOf('async function fixedFields(page,rl){'),b=source.indexOf('/** The send button gets exactly ONE',a);
 assert.ok(a>0&&b>a);
 const ids={category:'mainForm:category-value-id',subcategory:'mainForm:category-sub-value-id',signature:'mainForm:signature-value-id'};
 const fixed={responsibility:'Second Level',category:'Allgemeine Schriftwechsel',subcategory:'Personenschriftwechsel',signature:'INTL01 - Intel Deutschland GmbH'};
 const fields=Object.fromEntries(Object.entries(ids).map(([k,id])=>[id,{id,value:already?fixed[k]:'',tagName:'INPUT',isConnected:true,disabled:false,readOnly:false,getClientRects:()=>[{}]}]));
 fields[memberId]={id:memberId,value:'INTL01-11999001 | Example Person',isConnected:true,tagName:'INPUT'};
 if(foreignSignature)fields[ids.signature].value='FOREIGN SIGNATURE';
 const responsibility={tagName:'SELECT',disabled:false,selectedOptions:[{textContent:fixed.responsibility}]};
 const doc={activeElement:null,getElementById:id=>id==='mainForm:responsibility-value-id'?responsibility:fields[id],querySelectorAll:()=>Object.values(fields)};
 const calls={focus:[],type:[],mouse:0,manual:0,logs:[],reads:0};let pending=null;
 const ticket={id:'99900002'};let signatureProbes=0,lastQuery=null;
 const ui={detailTicketId:async()=>ticket.id,focusInput:async(p,id)=>{
  calls.focus.push(id);doc.activeElement=fields[id];
  if(subcategoryNeedsMember&&id===ids.signature&&fields[ids.subcategory].value===fixed.subcategory)fields[ids.subcategory].value='';
  if(subcategoryNeedsMember&&id===memberId&&calls.type.includes(ids.subcategory))fields[ids.subcategory].value=fixed.subcategory;
  return {ok:true};
 },typeTrustedFixedQuery:async(p,id,value)=>{calls.type.push(id);doc.activeElement=fields[id];fields[id].value=value;pending=id;lastQuery=value;return 'EXACT';},
  suggestionPoints:async(p,id)=>{
   if(pending!==id)return [];
   const x=Object.values(ids).indexOf(id)+1;
   if(id===ids.signature){
    signatureProbes++;
    if(codeOnlySignature&&lastQuery!=='INTL01')return [];
    if(duplicateSignature&&signatureProbes<=2)return [{x,y:20},{x:x+25,y:20}];
    if(unstableSignature&&signatureProbes<=3)return [{x:x+signatureProbes*10,y:20}];
    if(codeOnlySignature)fields[id].value=fixed.signature;
   }
   return [{x,y:20}];
  },
  focusEditor:async()=>{doc.activeElement={tagName:'DIV'};return true;},
  fixedFieldValues:async()=>({responsibility:fixed.responsibility,...Object.fromEntries(Object.entries(ids).map(([k,id])=>[k,fields[id].value]))})};
 let clock=0;
 const context=vm.createContext({document:doc,UI:ui,Prep:{FIXED:fixed},diag:{},DEMO:true,
  need:(ok,code,message)=>{if(!ok)throw Object.assign(Error(message),{code});},
  log:x=>calls.logs.push(x),ask:async()=>{calls.manual++;return '';},
  sleep:async ms=>{clock+=ms;},Date:{now:()=>clock},
  phase1SignatureState,mayChoosePhase1Signature,mayRetryPhase1Signature});
 const fn=vm.runInContext('('+source.slice(a,b)+')',context);
 const page={call:async(fn,...args)=>{calls.reads++;context.args=args;return vm.runInContext('('+fn.toString()+')(...args)',context);},
  mouseClick:async()=>{calls.mouse++;pending=null;}};
 return {run:()=>fn(page,{}),calls,fields,ids,doc,fixed,ticket};
}

test('RC101 restores neutral Member blur for subcategory before signature',async()=>{
 const h=fixedHarness();await h.run();
 assert.deepEqual(h.calls.focus,[memberId,memberId]);
 assert.deepEqual(h.calls.type,[h.ids.category,h.ids.subcategory,h.ids.signature]);
 assert.equal(h.calls.mouse,3);assert.equal(h.calls.manual,0);
 assert.ok(h.calls.logs.includes('PASS FIXED_FIELDS_ALL_VERIFIED'));
 assert.equal(h.fields[memberId].value,'INTL01-11999001 | Example Person');
});

test('RC97 repeated fixed-field checks reuse a same-ticket commit receipt without further focus actions',async()=>{
 const h=fixedHarness({already:true});await h.run();
 assert.deepEqual(h.calls.focus,[memberId]);
 await h.run();
 assert.deepEqual(h.calls.focus,[memberId]);assert.deepEqual(h.calls.type,[]);assert.equal(h.calls.mouse,0);assert.equal(h.calls.manual,0);
 assert.ok(h.calls.logs.some(line=>line.startsWith('PASS FIXED_FIELDS_REUSED_COMMITTED')));
});

test('RC97 a different ticket cannot borrow the prior fixed-field commit receipt',async()=>{
 const h=fixedHarness({already:true});await h.run();h.ticket.id='99900003';await h.run();
 assert.deepEqual(h.calls.focus,[memberId,memberId]);
});

test('RC97 fixed fields still support the existing no-member/no-email clarification route',async()=>{
 const h=fixedHarness({already:true});h.fields[memberId].value='';await h.run();
 assert.equal(h.fields[memberId].value,'');assert.equal(h.calls.type.length,0);
 assert.ok(h.calls.logs.includes('PASS FIXED_FIELDS_ALL_VERIFIED'));
});

test('RC101 legacy subcategory commit uses proven Member focus, no signature race',async()=>{
 const h=fixedHarness({subcategoryNeedsMember:true});await h.run();
 assert.deepEqual(h.calls.focus,[memberId,memberId]);
 assert.equal(h.calls.type.filter(id=>id===h.ids.subcategory).length,1);
 assert.ok(h.calls.logs.includes('PASS FIXED_FIELDS_ALL_VERIFIED'));
});

test('RC97 foreign signature still blocks automatic replacement',async()=>{
 const h=fixedHarness({already:true,foreignSignature:true});
 await assert.rejects(h.run,{code:'FIXED_SIGNATURE_CONFLICT'});
 assert.equal(h.calls.type.length,0);assert.equal(h.calls.mouse,0);
});

for(const variant of ['unstableSignature','duplicateSignature','codeOnlySignature'])test('RC107 signature recovers '+variant+' without manual or extra option click',async()=>{
 const h=fixedHarness({[variant]:true});await h.run();assert.equal(h.calls.manual,0);assert.equal(h.calls.mouse,3);
 assert.ok(h.calls.logs.some(x=>x.startsWith('PASS P1_SIGNATURE_EXACT_OPTION_CLICK')));
 assert.ok(h.calls.logs.includes('PASS FIXED_FIELDS_ALL_VERIFIED'));
});
