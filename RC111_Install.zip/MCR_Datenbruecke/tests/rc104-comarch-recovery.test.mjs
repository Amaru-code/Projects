import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {approveChangedRecipient} from '../lib/phase1-recipient-approval.mjs';
import {mayRebindPhase2BeforeTicket} from '../lib/phase2-cdp-recovery.mjs';
import {focusBoundInputNatively} from '../lib/input-focus.mjs';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const fast=async()=>{};
const id='89842395',old='old@example.invalid',changed='new@example.invalid';

test('RC104 unchanged recipient needs no additional prompt',async()=>{
 let prompts=0;
 const r=await approveChangedRecipient({ticketId:id,original:old,readRecipient:async()=>({ok:true,address:old}),assertTicket:async x=>assert.equal(x,id),ask:async()=>{prompts++;return 'JA';},wait:fast});
 assert.deepEqual(r,{address:old,changed:false,operatorApproved:false});assert.equal(prompts,0);
});
test('RC104 exact operator-changed recipient requires affirmative approval and second readback',async()=>{
 let checks=0,prompts=0;
 const r=await approveChangedRecipient({ticketId:id,original:old,readRecipient:async()=>{checks++;return {ok:true,address:changed};},assertTicket:async x=>assert.equal(x,id),ask:async q=>{prompts++;assert.match(q,new RegExp(id));assert.match(q,/new@example.invalid/);return 'JA';},wait:fast});
 assert.equal(r.address,changed);assert.equal(r.changed,true);assert.equal(r.operatorApproved,true);assert.equal(r.proof.ticketId,id);assert.equal(r.proof.originalRecipient,old);assert.equal(r.proof.approvedRecipient,changed);assert.equal(prompts,1);assert.ok(checks>=3);
});
test('RC104 recipient change after human approval is not sent without new approval',async()=>{
 const addresses=[changed,changed,'third@example.invalid','third@example.invalid','third@example.invalid'];let ix=0,prompts=0;
 const r=await approveChangedRecipient({ticketId:id,original:old,readRecipient:async()=>({ok:true,address:addresses[Math.min(ix++,addresses.length-1)]}),assertTicket:async()=>{},ask:async()=>{prompts++;return 'JA';},wait:fast});
 assert.equal(r.address,'third@example.invalid');assert.equal(prompts,2);
});
test('RC104 invalid or skipped recipient cannot be approved',async()=>{
 await assert.rejects(approveChangedRecipient({ticketId:id,original:old,readRecipient:async()=>({ok:false,address:'?'}),assertTicket:async()=>{},ask:async()=> 'JA',wait:fast}),{code:'RECIPIENT_REVIEW_REQUIRED'});
 await assert.rejects(approveChangedRecipient({ticketId:id,original:old,readRecipient:async()=>({ok:true,address:changed}),assertTicket:async()=>{},ask:async()=> 'UEBERSPRINGEN',wait:fast}),{code:'RECIPIENT_REVIEW_REQUIRED'});
});
test('RC104 CDP session can be rebound only before first Phase-2 ticket and only to owned master',()=>{
 const e={code:'CDP_ERROR',message:'Session with given id not found'};
 assert.equal(mayRebindPhase2BeforeTicket({error:e,sharedMaster:true}),true);
 for(const mod of [{currentTicket:'89664431'},{visitedCount:1},{alreadyRebound:true},{sharedMaster:false}])
  assert.equal(mayRebindPhase2BeforeTicket({error:e,sharedMaster:true,...mod}),false);
 assert.equal(mayRebindPhase2BeforeTicket({error:{code:'CDP_ERROR',message:'Target closed'},sharedMaster:true}),false);
 assert.equal(mayRebindPhase2BeforeTicket({error:{code:'CDP_TIMEOUT',message:e.message},sharedMaster:true}),false);
});

test('RC104 an occluded uniquely bound input can be focused without synthetic value or mouse click',async()=>{
 const original=globalThis.document;
 let focusCalls=0,scrollCalls=0;
 try{
  const doc={activeElement:null,querySelectorAll:selector=>selector==='input'?[field]:[]};
  const field={id:'mainForm:category-value-id',isConnected:true,value:'',readOnly:false,disabled:false,
   ownerDocument:doc,getClientRects:()=>[{left:1,right:50,top:1,bottom:15}],scrollIntoView:()=>scrollCalls++,focus:()=>{focusCalls++;doc.activeElement=field;}};
  doc.defaultView={getComputedStyle:()=>({display:'block',visibility:'visible',pointerEvents:'auto'})};
  globalThis.document=doc;
  const page={call:async(fn,...args)=>fn(...args)};
  const r=await focusBoundInputNatively(page,field.id,{wait:fast});
  assert.equal(r.ok,true);assert.equal(r.method,'BOUND_NATIVE_FOCUS');assert.equal(field.value,'');
  assert.equal(focusCalls,1);assert.ok(scrollCalls>=1);
 }finally{globalThis.document=original;}
});
test('RC104 a foreign blocking modal forbids even the native-focus fallback',async()=>{
 const original=globalThis.document;let calls=0;
 try{
  const modal={isConnected:true,getClientRects:()=>[{}],contains:()=>false};
  const doc={activeElement:null,querySelectorAll:selector=>selector==='input'?[field]:[modal]};
  const field={id:'mainForm:signature-value-id',isConnected:true,value:'',readOnly:false,disabled:false,
   ownerDocument:doc,getClientRects:()=>[{}],focus:()=>calls++};
  doc.defaultView={getComputedStyle:()=>({display:'block',visibility:'visible',pointerEvents:'auto'})};
  globalThis.document=doc;
  const r=await focusBoundInputNatively({call:async(fn,...args)=>fn(...args)},field.id,{wait:fast});
  assert.equal(r.ok,false);assert.equal(r.state,'INPUT_BLOCKED_BY_MODAL');assert.equal(calls,0);
 }finally{globalThis.document=original;}
});
test('RC104 controls remain bound to exact fixed values and ticket, with single irreversible send',()=>{
 const s=fs.readFileSync(path.join(root,'src/local-bot-full-run.mjs'),'utf8');
 assert.match(s,/await UI\.detailTicketId\(page\)===ticketId/);
 assert.match(s,/PASS SUBCATEGORY_COMMITTED_EXACT_PERSONENSCHRIFTWECHSEL/);
 assert.match(s,/PASS P1_INTL01_SIGNATURE_COMMITTED_EXACT/);
 assert.match(s,/approvedChangedRecipient|approveChangedRecipient/);
 assert.match(s,/BESTAND_EMPFANGER_WECHSEL_NICHT_GESCHRIEBEN/);
 assert.match(s,/sendOnce\(page,rl,row\.ticketId,journal,authorizedRecipient/);
 assert.match(s,/RECIPIENT_CHANGED_AT_CLICK/);
 const phase2=fs.readFileSync(path.join(root,'src/phase2-run.mjs'),'utf8');
 assert.match(phase2,/assertOwnedPageTarget\(cdp,ownedTargetId\)/);
 assert.match(phase2,/P2_CDP_SESSION_REBOUND_SAME_TARGET/);
});

test('RC104 exact INTL01 suggestion can be found in an upwards-opening popup',async()=>{
 const {suggestionPoints}=await import('../lib/browser-workflow.mjs');
 const original=globalThis.document,iw=globalThis.innerWidth,ih=globalThis.innerHeight;
 try{
  const rect={left:120,right:390,top:400,bottom:425};
  const suggestionRect={left:125,right:350,top:310,bottom:340};
  const doc={getElementById:()=>field,querySelectorAll:()=>[choice],elementFromPoint:()=>choice};
  const field={id:'mainForm:signature-value-id',getClientRects:()=>[rect],getBoundingClientRect:()=>rect};
  const choice={isConnected:true,innerText:'INTL01 - Intel Deutschland GmbH',textContent:'INTL01 - Intel Deutschland GmbH',
   getClientRects:()=>[suggestionRect],getBoundingClientRect:()=>suggestionRect,
   ownerDocument:doc,parentElement:null,onmousedown:()=>{},getAttribute:()=>null,contains:()=>false};
  doc.defaultView={getComputedStyle:()=>({display:'block',visibility:'visible',pointerEvents:'auto'})};
  globalThis.document=doc;globalThis.innerWidth=1280;globalThis.innerHeight=720;
  const page={call:async(fn,...args)=>fn(...args)};
  const result=await suggestionPoints(page,field.id,['INTL01 - Intel Deutschland GmbH']);
  assert.equal(result.length,1);assert.ok(result[0].y<rect.top);
 }finally{globalThis.document=original;globalThis.innerWidth=iw;globalThis.innerHeight=ih;}
});
