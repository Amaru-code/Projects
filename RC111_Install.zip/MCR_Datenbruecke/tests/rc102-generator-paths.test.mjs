import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {EventEmitter} from 'node:events';
import {GENERATOR_BAT_SHARE_ROOT,PHASE2_SCRIPTS,accountStatementPlan} from '../lib/phase2-account-statement-plan.mjs';
import {generatorPaths,localGeneratorInventory,inspectExistingStatements} from '../lib/phase2-pdf-evidence.mjs';
import {generatorInputContract,runLocalStatementGenerator} from '../lib/phase2-local-generator.mjs';
import {parsePhase2Description,descriptionPhase2Rule} from '../lib/phase2-description.mjs';
const root=path.join(os.tmpdir(),'mcr-rc102-fixture','MCR_Datenbruecke');
const drive='K:\\INTL01\\6_AU (Admin)\\Berechnungen - UV & Renten (PP+, DC+)';
const starts={
  AO:drive+'\\Auszahlungsoption\\START_Auszahlungsoption.bat',
  UVA:drive+'\\UVA PP+\\START_UVA_PP.bat',
  'PP+':drive+'\\Kontoauszug_PP+\\START_KONTOAUSZUG.bat',
  DC:drive+'\\Kontoauszug_DC\\START_KONTOAUSZUG_DC.bat'
};
test('RC102 exact four mapped K-drive BAT paths, preserving spaces, plus signs and &',()=>{
 assert.equal(GENERATOR_BAT_SHARE_ROOT,drive);
 for(const [plan,expected] of Object.entries(starts)){
  const p=generatorPaths(root,plan);
  assert.equal(p.start,expected);
  assert.equal(p.folder,path.win32.dirname(expected));
  assert.equal(path.win32.isAbsolute(p.start),true);
 }
 assert.deepEqual([...Object.keys(PHASE2_SCRIPTS)].sort(),['AO','DC','PP+','UVA']);
});
test('RC105 AO output shares generator folder; DC/PP output locations retained',()=>{
 const parent=path.resolve(root,'..');
 assert.equal(generatorPaths(root,'DC').output,path.join(parent,'Kontoauszug_DC','Ausgabe_PDF'));
 assert.equal(generatorPaths(root,'PP+').output,path.join(parent,'Kontoauszug_pp+','Ausgabe_PDF'));
 assert.equal(generatorPaths(root,'AO').output,drive+'\\Auszahlungsoption\\Ausgabe PDF');
 assert.equal(generatorPaths(root,'AO').script,drive+'\\Auszahlungsoption\\auszahlungsoption_generator.py');
 assert.equal(generatorPaths(root,'UVA').output,null);
 assert.equal(generatorPaths(root,'UVA').outputConfigured,false);
});
test('RC102 AO now runs as a target plan, UVA cannot be silently attached',()=>{
 const description='USC 20/DC;PP+\nStandardantwort versendet\nMöchte Kontoauszug & Auszahlungsoption';
 const plan=accountStatementPlan({ticketId:'89827030',description,memberName:'Max Mustermann',wwid:'11412817'});
 assert.deepEqual(plan.targets,['DC','PP+','AO']);
 assert.deepEqual(plan.scripts.map(x=>x.plan),['DC','PP+','AO']);
 const p=parsePhase2Description('USC 20/PP+\nStandardantwort versendet\nMöchte UVA');
 assert.equal(p.requestKind,'UNKNOWN_REQUEST');
 const rule=descriptionPhase2Rule({ticketId:'89827030',descriptionValue:p.raw});
 assert.equal(rule.kind,'MARK_DIRECT');
});
test('RC105 legacy DC generator still starts safely with a fixed BAT and validated numeric WWID',async()=>{
 const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'mcr-rc102-gen-'));
 try{
  const scriptFolder=path.join(tmp,'fixed bat dir (&)');fs.mkdirSync(scriptFolder);
  const script=path.join(scriptFolder,'START_KONTOAUSZUG_DC.bat');
  fs.writeFileSync(script,'@echo off\r\nset /p "WWID=WWID:"\r\n');
  let observed=null;
  const mockSpawn=(bin,args,opts)=>{
   const child=new EventEmitter();child.stdout=new EventEmitter();child.stderr=new EventEmitter();
   child.stdin={on:()=>{},end:input=>{observed={bin,args,opts,input};setImmediate(()=>child.emit('close',0));}};
   return child;
  };
  const r=await runLocalStatementGenerator(root,'DC','11412817',{
   isWindows:true,spawnImpl:mockSpawn,paths:()=>({start:script,folder:scriptFolder}),
   wait:()=>new Promise(resolve=>setTimeout(resolve,1))
  });
  assert.equal(r.status,'GENERATOR_EXECUTED');assert.equal(r.contract,'SINGLE_WWID_STDIN');
  assert.equal(observed.bin,'cmd.exe');assert.equal(observed.opts.cwd,scriptFolder);
  assert.deepEqual(observed.args.slice(0,3),['/d','/s','/c']);
  assert.equal(observed.input,'11412817\r\n');assert(observed.args.at(-1).includes(script));
  await assert.rejects(runLocalStatementGenerator(root,'DC','11412817 & del C:',{isWindows:true}),e=>e.code==='P2_WWID_INVALID');
 }finally{fs.rmSync(tmp,{recursive:true,force:true});}
});
test('RC102 UVA generator is registered but unknown BAT input contract is not guessed',async()=>{
 const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'mcr-rc102-gen-'));
 try{
  const script=path.join(tmp,'START_UVA_PP.bat');fs.writeFileSync(script,'@echo off\r\nstart "" powershell.exe -File run.ps1\r\n');
  assert.equal(generatorInputContract(fs.readFileSync(script,'utf8')).mode,'UNKNOWN_INPUT_CONTRACT');
  const r=await runLocalStatementGenerator(root,'UVA','11412817',{
   isWindows:true,paths:()=>({start:script,folder:tmp}),
   spawnImpl:()=>{throw Error('UNKNOWN_INPUT_CONTRACT must never launch');}
  });
  assert.equal(r.status,'MANUAL_WWID_INPUT_REQUIRED');
 }finally{fs.rmSync(tmp,{recursive:true,force:true});}
});
test('RC102 unknown/unavailable K: scripts are reported, not executed, while existing PDFs remain readable',()=>{
 const original=localGeneratorInventory(root);
 assert.deepEqual(original.plans.map(x=>x.plan),['DC','PP+','AO','UVA']);
 assert(original.plans.every(x=>x.start.startsWith(drive)));
 const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'mcr-rc102-pdf-'));
 try{
  const localRoot=path.join(tmp,'MCR_Datenbruecke');fs.mkdirSync(localRoot);
  const testPaths=(r,plan)=>({...generatorPaths(r,plan),output:path.join(tmp,'ao-output')});
  const output=testPaths(localRoot,'AO').output;fs.mkdirSync(output,{recursive:true});
  const filename='2025-12-31_Auszahlungsoption_Nachname_Vorname_11412817.pdf';
  fs.writeFileSync(path.join(output,filename),'%PDF-1.4\n'+'sample data\n'.repeat(35)+'%%EOF');
  const proof=inspectExistingStatements(localRoot,['AO'],'11412817',{first:'Vorname',last:'Nachname',paths:testPaths});
  assert.equal(proof.artifacts.length,1);assert.equal(proof.artifacts[0].name,filename);
 }finally{fs.rmSync(tmp,{recursive:true,force:true});}
});
test('RC102 phase2 missing AO PDF tries generator rather than just skipping',()=>{
 const source=fs.readFileSync(new URL('../src/phase2-pdf-prepare.mjs',import.meta.url),'utf8');
 assert(!source.includes('P2_AO_KEIN_GENERATOR'));
 assert(source.includes("generator(root,'AO',wwid"));
 assert(source.includes('verifyAoGeneratorProof'));
});
