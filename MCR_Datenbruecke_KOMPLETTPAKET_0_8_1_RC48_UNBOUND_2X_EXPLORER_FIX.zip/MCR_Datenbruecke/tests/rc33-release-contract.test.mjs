import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';
import {ROOT} from './helpers.mjs';import {VERSION} from '../lib/control.mjs';import {sha256} from '../lib/core.mjs';
test('RC33 pins untouched RC32 baseline and advances release version',()=>{
 assert.equal(VERSION,'0.8.1-rc.48');
 const p=path.join(ROOT,'tools/reference/complete-0.8.1-rc.32-manifest.json');
 assert.equal(JSON.parse(fs.readFileSync(p,'utf8')).version,'0.8.1-rc.32');
 assert.equal(sha256(fs.readFileSync(p)),'ec087b4bfe4cf2770be165684d0dde1d43d8530ef667995da28413f34ce113d5');
});
test('RC33 actual queue selection is source-neutral and non-email email-send preflight exists',()=>{
 const code=fs.readFileSync(path.join(ROOT,'src/local-bot-full-run.mjs'),'utf8');
 assert.match(code,/q\.rows\.find\(r=>firstPassCandidate\(r\)/);
 assert.doesNotMatch(code,/r\.source\.toUpperCase\(\)==='E-MAIL'/);
 assert.match(code,/nonEmailReplyProof/);assert.match(code,/SKIP_NO_VERIFIED_EMAIL_FOR_SOURCE/);
});
