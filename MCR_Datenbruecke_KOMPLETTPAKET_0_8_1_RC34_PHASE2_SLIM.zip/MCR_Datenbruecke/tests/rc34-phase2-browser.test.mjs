import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {readPhase2Queue,readPhase2DetailContract,phase2Inventory} from '../lib/phase2-readonly.mjs';
test('RC34 Chromium: actual task table and textarea.value read-only, source independent, no clicks',{timeout:60000},async()=>{
 const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-P2-DOM-'));let child,cdp;
 try{
  const b=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,
    extraArgs:['--disable-background-networking','--disable-sync',...(process.platform!=='win32'&&process.getuid?.()===0?['--no-sandbox']:[])]});child=b.child;
  ({cdp}=await connectBrowser(b.port));const page=await attachPage(cdp,t=>t.url==='about:blank');
  await page.call(function(html){document.body.innerHTML=html;},`<table id="mainForm:tasksTableFor_MyTasksList"><thead><tr><th>Ticket-ID</th><th>Quelle</th><th>Zusätzliche Beschreibung</th></tr></thead><tbody><tr><td>87393963</td><td>POST</td><td><textarea id="p2-desc"></textarea></td></tr><tr><td>87086074</td><td>PORTAL</td><td><textarea id="p2-other"></textarea></td></tr></tbody></table><input id="mainForm:gevo-value-id"/><input id="emailAttachmentFileUpload" type="file"/><a>Entwurf speichern</a><a>Ticket speichern</a><select><option value="FORWARD_TO_REVIEW">Review</option></select><input id="mainForm:next-persona-assignment-id"/><input type="submit" value="Schritt ausführen"/>`);
  await page.call(function(){window.phase2Clicks=0;document.addEventListener('click',()=>window.phase2Clicks++);
   document.getElementById('p2-desc').value='USC 20/ DC;PP+\nStandardantwort versendet\nMöchte Kontoauszug';
   document.getElementById('p2-other').value='USC 20/ DB+\nStandardantwort versendet\nMöchte Versorgungsausgleich';});
  const res=await readPhase2Queue(page);assert.equal(res.ok,true);assert.equal(res.rows.length,2);
  assert.match(res.rows[0].descriptionValue,/Möchte Kontoauszug/);
  const inv=phase2Inventory(res.rows);assert.equal(inv.items[0].kind,'NEEDS_VERIFIED_WWID');
  assert.deepEqual(inv.items[0].targets,['DC','PP+']);assert.equal(inv.items[1].kind,'OTHER_PHASE2_REQUEST');
  const ui=await readPhase2DetailContract(page);assert.equal(ui.gevo.exists,true);assert.equal(ui.upload.exists,true);
  assert.equal(ui.reviewSelectCount,1);assert.equal(ui.draftSaveCount,1);assert.equal(ui.ticketSaveCount,1);
  assert.equal(await page.eval('window.phase2Clicks'),0);
  console.log('PASS RC34_CHROMIUM_READ_ONLY_INVENTORY');
 }finally{try{cdp?.close();}catch{}try{child?.kill();}catch{}await new Promise(r=>setTimeout(r,500));fs.rmSync(profile,{recursive:true,force:true,maxRetries:8,retryDelay:250});}
});
