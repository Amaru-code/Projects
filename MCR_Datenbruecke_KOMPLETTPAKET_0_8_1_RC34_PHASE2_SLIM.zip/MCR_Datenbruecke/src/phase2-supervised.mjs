/** RC34 separate Phase-2 operator workflow. All COMARCH access is read-only.
 * PDF generation remains with the user's existing interactive programs.
 */
import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import readline from 'node:readline/promises';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachFreshPage} from '../lib/cdp.mjs';
import {resolveConfig} from '../lib/config.mjs';import {loadActiveMapping} from '../lib/active-mapping.mjs';import {plainPath,writeJSON,readJSON,stamp,ledger} from '../lib/control.mjs';
import {requireThat as need} from '../lib/core.mjs';import * as UI from '../lib/browser-workflow.mjs';
import {phase2Inventory,readPhase2Queue,readPhase2DetailContract} from '../lib/phase2-readonly.mjs';
import {phase2DraftPreview} from '../lib/phase2-draft-preview.mjs';
import {localGeneratorInventory,generatorPaths,snapshotStatementOutputs,verifyNewStatements,approvedPerson,approvedWwid} from '../lib/phase2-pdf-evidence.mjs';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const printed=s=>console.log(s);
async function question(rl,text){return String(await rl.question(text)).trim();}
function reportDir(root){const d=path.join(root,'.runtime','phase2');fs.mkdirSync(d,{recursive:true});plainPath(d);return d;}
function save(root,name,value){const f=path.join(reportDir(root),name);writeJSON(f,value);printed('LOKALER_BERICHT: '+f);return f;}
export async function inventoryLive({root=ROOT,ask=question,log=printed}={}){
 // Require the installed/activated datastore before opening the production profile.
 loadActiveMapping(root);
 const cfg=resolveConfig(root);let browser=null,cdp=null;
 const rl=readline.createInterface({input:process.stdin,output:process.stdout});let leaveOpen=false;
 try{
  const exe=findEdgeExecutable(cfg.edgePath);need(exe,'P2_EDGE_NOT_FOUND','Edge/Chromium fehlt.');
  log('\nPHASE2 COMARCH INVENTUR – KEINE BEARBEITUNG, KEIN VERSAND, KEINE WEITERLEITUNG.');
  browser=await launchBrowser({executable:exe,userDataDir:cfg.profileDirectory,startUrl:'about:blank'});
  ({cdp}=await connectBrowser(browser.port));const page=await attachFreshPage(cdp,cfg.comarchUrl);
  log('Im Bot-Edge anmelden, falls erforderlich. Danach im Terminal START eingeben.');
  need((await ask(rl,'Nur-Lese-Inventur START / ABBRUCH: ')).toUpperCase()==='START','P2_INVENTORY_ABORT','Inventur abgebrochen.');
  await UI.navigateToScope(page,'IN_BEARBEITUNG',{startup:true});
  const raw=await readPhase2Queue(page);need(raw.ok,'P2_QUEUE_READ',raw.reason||'Tabelle nicht lesbar.');
  const pendingIds=ledger(root).pending.map(x=>x.ticketId);
  const result=phase2Inventory(raw.rows,{pendingIds});
  const report={...result,uiSource:'EXACT_MY_TASKS_TABLE',checks:{originalMailNotYetVerified:true,identityNotYetVerified:true,wwidNotYetVerified:true},detail:null};
  log('PHASE2_INVENTUR: '+raw.rows.length+' Tickets in Meine Vorgaenge; '+report.candidates+' Kontoauszug-Kandidaten/Prueffaelle.');
  for(const item of report.items.filter(x=>x.kind!=='NOT_KONTOAUSZUG')){
   log(`TICKET ${item.ticketId} | ${item.kind} | Quelle=${item.source||'(leer)'} | ${item.targets.join('+')||'-'} | ${item.reason}`);
  }
  // Inspect one requested ticket without pressing Bearbeiten / Entwurf speichern.
  const choice=await ask(rl,'Ticket-ID fuer UI-Detailpruefung (ENTER=ueberspringen): ');
  if(choice){const selected=raw.rows.find(x=>x.ticketId===choice);need(selected,'P2_TICKET_NOT_IN_QUEUE','Ticket nicht in dieser Live-Liste.');
   await UI.openTicket(page,selected);await UI.assertTicket(page,choice);report.detail={ticketId:choice,ui:await readPhase2DetailContract(page)};
   log('PHASE2_UI_READ_ONLY '+choice+': '+JSON.stringify(report.detail.ui));
  }
  const stored=save(root,'MCR_PHASE2_LETZTE_INVENTUR.json',report);
  save(root,'MCR_PHASE2_INVENTUR_'+stamp()+'.json',report);
  log('PASS PHASE2_INVENTORY_READ_ONLY; KEINE Ticketaktion, KEIN BAT-Start.');
  const a=(await ask(rl,'Bot-Edge schliessen ENTER / OFFEN zur Kontrolle: ')).toUpperCase();leaveOpen=a==='OFFEN';
  if(leaveOpen)log('Bot-Edge bleibt offen. Vor einem weiteren Lauf manuell schliessen.');
  return {count:report.candidates,file:stored};
 }finally{rl.close();try{cdp?.close();}catch{}if(leaveOpen){try{browser?.child?.unref();}catch{}}else try{browser?.child?.kill();}catch{}}
}
export function generatorPreflight({root=ROOT,log=printed}={}){
 const report=localGeneratorInventory(root),file=save(root,'MCR_PHASE2_GENERATOR_PREFLIGHT_'+stamp()+'.json',report);
 for(const p of report.plans){log(`GENERATOR ${p.plan} | BAT ${p.scriptPresent?'VORHANDEN':'FEHLT'} | PDF-Ordner ${p.outputPresent?'VORHANDEN':'FEHLT'} | vorhandene PDFs=${p.existingPdfCount} | Eingabe=${p.operatorInputHint}`);
  log('  '+p.start);
 }
 log('PASS PHASE2_GENERATORS_READ_ONLY: Keine BAT gestartet. Eingabe-Vertrag noch nicht freigegeben.');return file;
}
export async function manualPdfPilot({root=ROOT,ask=question,log=printed}={}){
 const inventory=path.join(reportDir(root),'MCR_PHASE2_LETZTE_INVENTUR.json');
 need(fs.existsSync(inventory),'P2_INVENTORY_REQUIRED','Zuerst Menue 9 (COMARCH-Inventur) ausfuehren.');
 const source=readJSON(inventory,2*1024*1024);need(source.schema==='MCR_PHASE2_INVENTORY_V1'&&source.readOnly&&Array.isArray(source.items),'P2_INVENTORY_INVALID','Phase-2-Inventur unlesbar.');
 need(Date.now()-Date.parse(source.generatedAt)<60*60*1000,'P2_INVENTORY_EXPIRED','Inventur ist aelter als eine Stunde; erneut lesen.');
 const rl=readline.createInterface({input:process.stdin,output:process.stdout});
 try{
  const id=await ask(rl,'Kontoauszug Ticket-ID aus frischer Inventur: '),item=source.items.find(x=>x.ticketId===id);
  need(item?.kind==='NEEDS_VERIFIED_WWID','P2_TICKET_NOT_READY','Ticket ist nicht als Kontoauszug-Kandidat ohne offene Vorpruefungsfehler registriert.');
  log('TICKET '+id+' | Plaene '+item.targets.join(' + ')+' | Quelle '+item.source+'.');
  log('MercerID ist NICHT WWID. Person, WWID, Berechtigung und Originalvorgang UNABHAENGIG pruefen.');
  const wwId=approvedWwid(await ask(rl,'Unabhaengig verifizierte WWID: '));
  const first=await ask(rl,'Verifizierter Vorname: '),last=await ask(rl,'Verifizierter Nachname: ');approvedPerson(first,last);
  need((await ask(rl,'Identitaet, WWID und Berechtigung extern nachgewiesen? PERSON_UND_WWID_GEPRUEFT: '))==='PERSON_UND_WWID_GEPRUEFT',
   'P2_OPERATOR_PROOF_REQUIRED','Keine unabhängige Personen/WWID-Freigabe.');
  const baseline=snapshotStatementOutputs(root,item.targets);
  log('PDF-AUSGANGSBESTAND fixiert. Bitte die vorhandenen Programme MANUELL separat starten und dort WWID eingeben.');
  for(const plan of item.targets){const p=generatorPaths(root,plan);log('START '+plan+': '+p.start);log('AUSGABE '+plan+': '+p.output);}
  log('Die Datenbruecke startet KEIN Skript und veraendert COMARCH NICHT.');
  need((await ask(rl,'Wenn alle benannten BAT-Laeufe abgeschlossen sind, PDFS_ERZEUGT eingeben (sonst ABBRUCH): '))==='PDFS_ERZEUGT',
   'P2_OPERATOR_ABORT','PDF-Test ohne Dateipruefung beendet.');
  const result=verifyNewStatements(root,baseline,{wwid:wwId,first,last});
  log('Dateinamen, Neuheit, PDF-Merkmale und SHA-256 geprueft. Das ersetzt KEINE inhaltliche Personenpruefung.');
  for(const a of result.artifacts)log(`PDF ${a.plan}: ${a.name} | SHA256 ${a.sha256}`);
  need((await ask(rl,'PDF-Inhalt und Namen mit Originalticket abgeglichen? PDF_INHALT_GEPRUEFT: '))==='PDF_INHALT_GEPRUEFT',
   'P2_PDF_CONTENT_REVIEW','PDF-Inhaltspruefung fehlt.');
  const proof={...result,ticketId:id,operatorContentReviewed:true,comarchStatus:'NOT_ATTACHED_NOT_SAVED_NOT_FORWARDED'};
  save(root,'MCR_PHASE2_PDF_BELEG_'+id+'_'+stamp()+'.json',proof);
  const original=source.items.find(x=>x.ticketId===id);
  // Use the exact multiline textarea text from the bounded live inventory.
  // No retyping: a human transcription error must never alter USC/request data.
  const draft=phase2DraftPreview({ticketId:id,source:original.source,description:original.descriptionValue,pdfProof:proof});
  save(root,'MCR_PHASE2_ENTWURF_VORSCHAU_'+id+'_'+stamp()+'.json',draft);
  log('PHASE2_VORSCHAU: '+JSON.stringify({ticketId:id,plans:draft.expectedDocuments,description:draft.descriptionAfter,reviewAssignee:draft.reviewAssignee}));
  log('PASS PHASE2_MANUAL_GENERATOR_PDF_PROOF: '+result.targets.length+' PDFs belegt, KEINE COMARCH-AKTION.');
  return proof;
 }finally{rl.close();}
}
