import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {createInterface} from 'node:readline/promises';
import {stdin,stdout} from 'node:process';
import {readZip} from './lib/zip.mjs';
import {parseXml,child,children,all,plain} from './lib/xml.mjs';
import {sha256,clean} from './lib/core.mjs';
import Core from './lib/data-core.cjs';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)));
const rl=createInterface({input:stdin,output:stdout});
const DEFAULT_XLSX=String.raw`C:\Users\Amaru-Zegarra\projects\Aktive_Projekte\Ticket_bot\INTL01_Gesamtdatenbestand_30.09.2025.xlsx`;
const OVERRIDES=Object.freeze({
  // User-confirmed on 2026-10-05: for Richard Devereux use the duplicate row with TPP=1.
  '10102131': Object.freeze({policy:'UNIQUE_TPP_1', reason:'USER_CONFIRMED_TPP_ROW'})
});

function fail(code,msg){const e=new Error(msg);e.code=code;throw e;}
function need(ok,code,msg){if(!ok)fail(code,msg);}
function text(v){return String(v??'').replace(/\u00a0/g,' ').trim();}
function norm(v){return text(v).replace(/[\s_]/g,'').toLowerCase();}
function readJson(p){return JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''));}
function hashRaw(raw){return crypto.createHash('sha256').update(raw).digest('hex');}
function arg(name){const i=process.argv.indexOf(name);return i>=0?process.argv[i+1]:null;}

function latestGenderMapping(){
  const d=path.join(root,'private_data');need(fs.existsSync(d),'MAP_DIR','private_data fehlt. Patch in den entpackten MCR_Datenbruecke-Ordner legen.');
  const files=fs.readdirSync(d).filter(n=>/^INTL01_mapping_gender_.*\.json$/i.test(n)).map(n=>path.join(d,n));
  need(files.length,'MAP_NOT_FOUND','Kein INTL01_mapping_gender_*.json in private_data gefunden.');
  files.sort((a,b)=>fs.statSync(b).mtimeMs-fs.statSync(a).mtimeMs);return files[0];
}

function readWorkbookExtended(filename){
  need(fs.existsSync(filename),'XLSX_MISSING','Excel-Datei fehlt: '+filename);
  const buffer=fs.readFileSync(filename);need(buffer.length<=80*1024*1024,'XLSX_SIZE','Excel-Datei zu gross.');
  const zip=readZip(buffer),wb=parseXml(zip.get('xl/workbook.xml'));
  const inventory=children(child(wb,'sheets'),'sheet');
  const sheets=inventory.filter(s=>typeof s.attrs.name==='string'&&text(s.attrs.name).toLowerCase()==='output');
  need(sheets.length===1,'SHEET','Output-Blatt fehlt oder ist nicht eindeutig.');
  const sh=sheets[0],actualSheet=sh.attrs.name;const rid=sh.attrs['r:id']??Object.entries(sh.attrs).find(([k])=>k.endsWith(':id'))?.[1];
  const rels=parseXml(zip.get('xl/_rels/workbook.xml.rels'));const rel=children(rels,'Relationship').filter(r=>r.attrs.Id===rid);
  need(rel.length===1&&!rel[0].attrs.TargetMode,'SHEET_REL','Unbekannte Blattverknuepfung.');
  const target=rel[0].attrs.Target.startsWith('/')?rel[0].attrs.Target.slice(1):path.posix.normalize(path.posix.join('xl',rel[0].attrs.Target));
  need(target.startsWith('xl/')&&!target.includes('..'),'SHEET_PATH','Ungueltiger Blattpfad.');
  const strings=zip.names.includes('xl/sharedStrings.xml')?children(parseXml(zip.get('xl/sharedStrings.xml')),'si').map(s=>all(s,'t').map(plain).join('')):[];
  const xml=parseXml(zip.get(target)),rawRows=[];
  for(const rn of children(child(xml,'sheetData'),'row')){
    const row=Number(rn.attrs.r);if(!Number.isSafeInteger(row)||row<1)continue;
    const values={row,formulas:[],errors:{}};
    for(const c of children(rn,'c')){
      const ref=c.attrs.r??'',m=ref.match(/^([A-Z]{1,3})(\d+)$/);if(!m||Number(m[2])!==row)continue;
      const col=m[1];if(!['B','C','D','E','F','L','O'].includes(col))continue;
      const type=c.attrs.t,v=child(c,'v'),f=child(c,'f');let value=v?plain(v):'';
      if(f)values.formulas.push(col);
      if(type==='s'){
        const idx=Number(value);need(v&&/^\d+$/.test(value)&&idx<strings.length,'SHARED_STRING','Ungueltiger Shared-String-Index.');value=strings[idx];
      } else if(type==='inlineStr') value=all(child(c,'is')??{children:[],name:''},'t').map(plain).join('');
      else if(type==='e') values.errors[col]='Excel-Fehlerwert';
      else if(type&&!['n','str','b'].includes(type)) values.errors[col]='Nicht unterstuetzter Zelltyp';
      if(f&&(!v||(!clean(value)&&type!=='str'&&type!=='inlineStr')))values.errors[col]='Formel ohne gespeichertes Ergebnis';
      values[col]=value;
    }
    rawRows.push(values);
  }
  const headers=rawRows.filter(r=>r.row<=20&&norm(r.B)==='clienteeid');need(headers.length===1,'HEADER_B','ClientEEID-Header in B nicht eindeutig.');
  const h=headers[0];
  need(norm(h.C)==='iseligibledc','HEADER_C','C muss IsEligible_DC sein.');
  need(norm(h.D)==='iseligibleipp','HEADER_D','D muss IsEligible_IPP sein.');
  need(norm(h.E)==='iseligiblepensintel','HEADER_E','E muss IsEligible_PensIntel sein.');
  need(norm(h.F)==='iseligibletpp','HEADER_F','F muss IsEligible_TPP sein.');
  need(text(h.L),'HEADER_L','L/USC Header fehlt.');
  need(norm(h.O)==='gender','HEADER_O','O muss Gender sein.');
  const rows=rawRows.filter(r=>r.row>h.row&&text(r.B));const byId=new Map();
  for(const r of rows){let id;try{id=Core.id(text(r.B));}catch{continue;}if(!byId.has(id))byId.set(id,[]);byId.get(id).push(r);}
  return {meta:{filename:path.basename(filename),sheet:actualSheet,sha256:sha256(buffer),headerRow:h.row,headers:{B:h.B,C:h.C,D:h.D,E:h.E,F:h.F,L:h.L,O:h.O}},rows,byId};
}

function gender(v){const g=text(v).toUpperCase();if(g==='')return null;need(g==='M'||g==='F','GENDER_INVALID','Spalte O: nur M, F oder leer erlaubt.');return g;}
function toEntry(r,policy,clientId){
  need(!Object.keys(r.errors||{}).length,'CELL_ERROR','Relevante Excel-Zelle enthaelt Fehler oder ungespeicherten Formelcache.');
  const e={
    clientId,sourceRow:r.row,usc:text(r.L),
    dc:Core.flag(r.C,'C',policy),ppPlus:Core.flag(r.D,'D',policy),dbPlus:Core.flag(r.E,'E',policy),
    pensIntel:Core.flag(r.E,'E',policy),tpp:Core.flag(r.F,'F',policy),gender:gender(r.O),genderSourceColumn:'O',
    formulas:(r.formulas||[]).filter(c=>['B','C','D','E','L'].includes(c)),
    auxiliaryFormulas:(r.formulas||[]).filter(c=>['F','O'].includes(c))
  };
  if(policy===Core.BLANK_OMIT_FLAGS){e.flagPolicy=policy;e.blankColumns=['C','D','E'].filter(c=>text(r[c])==='');e.auxBlankColumns=['F'].filter(c=>text(r[c])==='');}
  e.description=Core.description(e);return e;
}

try{
  console.log('\n==============================================================');
  console.log(' MCR Mapping E/F Patch 0.1 - PensIntel + TPP + Duplicate Override');
  console.log('==============================================================');
  console.log('Bestehende Mappings und Excel werden NICHT veraendert. Es wird ein neues Mapping erzeugt.');
  console.log('Beschreibung bleibt unveraendert: TPP wird gespeichert, aber NICHT automatisch in den Beschreibungstext aufgenommen.');

  const mappingPath=path.resolve(arg('--mapping')||latestGenderMapping());
  const excelPath=path.resolve(arg('--excel')||DEFAULT_XLSX);
  const map=readJson(mappingPath);Core.validateMap(map);
  need(sha256(JSON.stringify(map.payload))===map.payloadSha256,'MAP_HASH','Mapping-Payload-Hash stimmt nicht.');
  const book=readWorkbookExtended(excelPath);
  need(String(map.payload.source?.sha256||'').toLowerCase()===book.meta.sha256.toLowerCase(),'SOURCE_CHANGED','Excel-Datei entspricht nicht der Quelle des aktuellen Mappings.');
  console.log('Mapping:',path.basename(mappingPath));
  console.log('Excel-Quelle SHA256 PASS');
  console.log('Header E:',book.meta.headers.E,'| F:',book.meta.headers.F,'| O:',book.meta.headers.O);
  console.log('Explizite Felder im neuen JSON: pensIntel <- E | tpp <- F | gender <- O');
  console.log('Bestehende Beschreibung: C=DC, D=PP+, E=DB+ bleibt fuer diesen Patch unveraendert.');
  console.log('Duplicate Override: ClientEEID 10102131 -> eindeutig die Zeile mit F/TPP = 1 verwenden.');
  const answer=(await rl.question('Diesen neuen Mapping-Stand erzeugen? JA: ')).trim();need(answer==='JA','ABORT','Abgebrochen. Keine Datei geschrieben.');

  const policy=Core.policyOf(map.payload);let augmented=0;
  for(const [id,e] of Object.entries(map.payload.entries)){
    const rows=book.byId.get(id)||[];const r=rows.find(x=>Number(x.row)===Number(e.sourceRow));
    need(r,'ROW_MISMATCH','Quellzeile fuer ClientEEID im Excel nicht gefunden.');
    const p=Core.flag(r.E,'E',policy),t=Core.flag(r.F,'F',policy),g=gender(r.O);
    need(e.dbPlus===p,'E_ALIAS_MISMATCH','Bestehendes E/dbPlus stimmt nicht mit Excel Spalte E ueberein.');
    if(Object.hasOwn(e,'gender'))need((e.gender??null)===g,'GENDER_MISMATCH','Bestehendes Gender stimmt nicht mit Spalte O ueberein.');
    e.pensIntel=p;e.tpp=t;e.gender=g;e.genderSourceColumn='O';e.pensIntelSourceColumn='E';e.tppSourceColumn='F';
    if(policy===Core.BLANK_OMIT_FLAGS)e.auxBlankColumns=['F'].filter(c=>text(r[c])==='');
    augmented++;
  }

  let resolved=0;
  for(const [id,o] of Object.entries(OVERRIDES)){
    const rows=book.byId.get(id)||[];need(rows.length>1,'OVERRIDE_NOT_DUPLICATE','Override-ID ist in Excel nicht mehrfach vorhanden: '+id);
    need(o.policy==='UNIQUE_TPP_1','OVERRIDE_POLICY','Unbekannte Override-Policy.');
    const candidates=rows.filter(r=>{try{return Core.flag(r.F,'F',policy)===1;}catch{return false;}});
    need(candidates.length===1,'OVERRIDE_AMBIGUOUS','Fuer '+id+' muss genau eine Dubletten-Zeile F/TPP=1 haben; gefunden: '+candidates.length);
    const chosen=candidates[0];const entry=toEntry(chosen,policy,id);
    entry.pensIntelSourceColumn='E';entry.tppSourceColumn='F';
    entry.duplicateResolution={policy:'USER_CONFIRMED_UNIQUE_TPP_1_V1',candidateSourceRows:rows.map(r=>r.row).sort((a,b)=>a-b),selectedSourceRow:chosen.row,criterion:'F/IsEligible_TPP = 1'};
    map.payload.entries[id]=entry;delete map.payload.blocked[id];resolved++;
    console.log('Duplicate Override PASS:',id,'-> Excel-Zeile',chosen.row,'(TPP=1, PensIntel='+String(entry.pensIntel)+')');
  }

  map.payload.source.headers={...(map.payload.source.headers||{}),E:book.meta.headers.E,F:book.meta.headers.F,O:book.meta.headers.O};
  map.payload.source.pensIntelColumn='E';map.payload.source.tppColumn='F';map.payload.source.genderColumn='O';
  map.payload.auxiliaryFlagPolicy='PENSINTEL_E_TPP_F_CAPTURE_V1';
  map.payload.duplicateResolutionPolicy='EXPLICIT_USER_CONFIRMED_OVERRIDES_ONLY_V1';
  const allEntries=Object.values(map.payload.entries);const genderM=allEntries.filter(e=>e.gender==='M').length,genderF=allEntries.filter(e=>e.gender==='F').length,genderBlank=allEntries.filter(e=>e.gender==null).length;
  map.payload.summary={...(map.payload.summary||{}),validKeys:Object.keys(map.payload.entries).length,blockedKeys:Object.keys(map.payload.blocked).length,efAugmentedEntries:augmented+resolved,duplicateOverridesResolved:resolved,genderM,genderF,genderBlank};
  map.payloadSha256=hashRaw(JSON.stringify(map.payload));Core.validateMap(map);

  const outDir=path.dirname(mappingPath),stamp=new Date().toISOString().replace(/[:.]/g,'-'),source8=book.meta.sha256.slice(0,8);
  const out=path.join(outDir,`INTL01_mapping_gender_ef_tpp_${stamp}_${source8}.json`),raw=JSON.stringify(map,null,2)+'\n';
  fs.writeFileSync(out,raw,{flag:'wx',mode:0o600});fs.writeFileSync(out+'.sha256',hashRaw(raw)+'  '+path.basename(out)+'\n',{flag:'wx',mode:0o600});
  console.log('\n==============================================================');
  console.log(' FERTIG');
  console.log('==============================================================');
  console.log('NEW_MAPPING='+out);
  console.log('SHA256='+hashRaw(raw));
  console.log('Eintraege mit E/F erweitert:',augmented+resolved);
  console.log('Duplicate Overrides aufgeloest:',resolved);
  console.log('Verbleibende gesperrte Kennungen:',Object.keys(map.payload.blocked).length);
  console.log('Der 0.7.2/0.7.1 Runner erkennt dieses neue INTL01_mapping_gender_*.json automatisch als neuesten Stand.');
}catch(e){console.error('\nSTOP:',e.code??'ERROR','-',e.message);process.exitCode=1;}finally{rl.close();}
