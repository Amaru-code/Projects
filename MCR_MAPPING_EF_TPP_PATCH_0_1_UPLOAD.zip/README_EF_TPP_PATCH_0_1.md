# MCR Mapping E/F Patch 0.1

Ziel: bestehendes Gender-Mapping um die Excel-Rohmerkmale `E = IsEligible_PensIntel` und `F = IsEligible_TPP` erweitern, ohne die bestehende Beschreibungsemantik zu verändern.

- `pensIntel` wird explizit aus Spalte E gespeichert.
- `tpp` wird aus Spalte F gespeichert.
- `gender` aus O bleibt erhalten/geprüft.
- Bestehende Beschreibung bleibt vorerst `USC ... / DC;PP+;DB+`; für TPP wird **kein neuer Textcode erfunden**.
- User-confirmed Duplicate Override: ClientEEID `10102131` wird nur dann entsperrt, wenn unter seinen Dubletten **genau eine** Zeile `F/IsEligible_TPP = 1` hat. Diese Zeile wird verwendet. Alle anderen Dubletten bleiben gesperrt.
- Excel und altes Mapping werden niemals überschrieben. Es entsteht ein neues `INTL01_mapping_gender_ef_tpp_*.json` in `private_data`.

Start: `MAPPING_EF_TPP_AKTUALISIEREN.cmd`
