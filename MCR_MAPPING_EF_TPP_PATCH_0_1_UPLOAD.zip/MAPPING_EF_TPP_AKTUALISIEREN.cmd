@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
echo ==============================================================
echo  MCR Mapping E/F Patch 0.1 - PensIntel + TPP
 echo ==============================================================
echo.
if not exist "%~dp0lib\data-core.cjs" (
  echo FEHLER: Dieser Patch muss in den VOLLSTAENDIG ENTPACKTEN MCR_Datenbruecke-Ordner kopiert werden.
  echo Nicht direkt aus der ZIP-Ansicht starten.
  pause
  exit /b 2
)
set "NODE_EXE="
for %%N in (
  "C:\Users\Amaru-Zegarra\projects\Compiler\javascript\tools\node\node.exe"
  "%~dp0tools\node\node.exe"
) do if not defined NODE_EXE if exist "%%~N" set "NODE_EXE=%%~N"
if not defined NODE_EXE for /f "delims=" %%N in ('where node.exe 2^>nul') do if not defined NODE_EXE set "NODE_EXE=%%N"
if not defined NODE_EXE (
  echo FEHLER: node.exe nicht gefunden.
  pause
  exit /b 3
)
"%NODE_EXE%" "%~dp0src\verify-package.mjs"
if errorlevel 1 (
  echo FEHLER: Basispaket-Integritaet fehlgeschlagen.
  pause
  exit /b 4
)
"%NODE_EXE%" "%~dp0patch-ef-tpp.mjs"
set "RC=%errorlevel%"
echo.
if not "%RC%"=="0" echo FEHLER: Mapping-Patch wurde nicht abgeschlossen.
pause
exit /b %RC%
