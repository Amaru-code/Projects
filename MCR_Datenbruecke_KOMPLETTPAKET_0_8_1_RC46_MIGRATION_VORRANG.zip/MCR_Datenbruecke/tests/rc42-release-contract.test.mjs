import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {ROOT} from './helpers.mjs';
import {sha256} from '../lib/core.mjs';
import {VERSION} from '../lib/control.mjs';
import {verifyPackage} from '../tools/integrity.mjs';

test('RC42 pinned exact published RC41 manifest; executable release remains self-consistent',()=>{
 assert.equal(VERSION,'0.8.1-rc.46');
 const pin=fs.readFileSync(path.join(ROOT,'tools/reference/complete-0.8.1-rc.41-manifest.json'));
 assert.equal(sha256(pin),'a380a5a92449b6379ef2f3a2a144092519b478db702918a340e59bf043f1a127');
 assert.equal(JSON.parse(pin).version,'0.8.1-rc.41');
 const code=fs.readFileSync(path.join(ROOT,'tools/integrity.mjs'),'utf8');
 assert.match(code,/m\.version==='0\.8\.1-rc\.41'/);
 const pkg=verifyPackage(ROOT);assert.equal(pkg.version,VERSION);
});
test('RC42 Phase 2 uses exact field focus gate and never exposes email SEND',()=>{
 const actions=fs.readFileSync(path.join(ROOT,'lib/phase2-comarch-actions.mjs'),'utf8');
 const pilot=fs.readFileSync(path.join(ROOT,'src/phase2-comarch-pilot.mjs'),'utf8');
 assert.match(actions,/typeTrustedFixedQuery\(page,GEVO_FIELD,'Anfrage Member',\{manualGate:manualFocus\}\)/);
 assert.match(pilot,/manualFocus:async\(reason\)=>/);
 assert.match(pilot,/GEVO_OHNE_AKTIONEN_GEPRUEFT/);
 assert.match(pilot,/journal\.approveGevoFocusRetry/);
 assert.doesNotMatch(pilot,/\b(?:sendEmail|sendMessage|clickSend|sendStandardAnswer)\s*\(/);
});
