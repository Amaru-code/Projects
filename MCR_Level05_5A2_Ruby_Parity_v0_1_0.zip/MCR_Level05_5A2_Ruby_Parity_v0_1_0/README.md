# MCR Level 05A.2 – Ruby Mode 1 Parity v0.1.0

Correctness-first Ruby implementation for the frozen LNW DC benchmark.

The package uses the existing Ruby interpreter and does **not** generate a new
native candidate EXE. All LNW calculations are implemented in Ruby. Excel is
used only through the same PowerShell/COM workbook bridge already certified by
the C#/TypeScript/JavaScript candidates.

Run `START_5A2_RUBY.ps1`.
