[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][Alias('Case')][ValidateNotNullOrEmpty()][string]$CaseId,
    [Parameter(Mandatory=$true)][Alias('Input')][ValidateNotNullOrEmpty()][string]$InputPath,
    [Parameter(Mandatory=$true)][Alias('Template')][ValidateNotNullOrEmpty()][string]$TemplatePath,
    [Parameter(Mandatory=$true)][Alias('Output')][ValidateNotNullOrEmpty()][string]$OutputPath,
    [int]$Workers = 4
)

$ErrorActionPreference='Stop'
$ModeRoot=$PSScriptRoot
$BuildRoot=Join-Path $ModeRoot 'build'
$Publish=Join-Path $BuildRoot 'publish'
$Main=Join-Path $Publish 'main.rb'
$RubyPointer=Join-Path $BuildRoot 'ruby_path.txt'

if(-not(Test-Path $Main -PathType Leaf)){throw "Ruby Candidate wurde noch nicht gebaut: $Main"}
if(-not(Test-Path $RubyPointer -PathType Leaf)){throw 'ruby_path.txt fehlt. build.ps1 zuerst ausfuehren.'}
$Ruby=(Get-Content $RubyPointer -Raw).Trim()
if(-not(Test-Path $Ruby -PathType Leaf)){throw "Ruby Runtime fehlt: $Ruby"}

Write-Host 'Ruby Candidate Wrapper'
Write-Host "Case:     [$CaseId]"
Write-Host "Input:    [$InputPath]"
Write-Host "Template: [$TemplatePath]"
Write-Host "Output:   [$OutputPath]"
Write-Host "Workers:  [$Workers]"
Write-Host "Runtime:  [$Ruby]"

if(Test-Path $OutputPath){
    Get-ChildItem $OutputPath -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force
}else{
    New-Item -ItemType Directory -Force -Path $OutputPath | Out-Null
}

& $Ruby $Main --case $CaseId --input $InputPath --template $TemplatePath --output $OutputPath --workers $Workers
$Code=$LASTEXITCODE
if($null -eq $Code){throw 'Ruby Candidate returned no interpreter exit code.'}
exit [int]$Code
