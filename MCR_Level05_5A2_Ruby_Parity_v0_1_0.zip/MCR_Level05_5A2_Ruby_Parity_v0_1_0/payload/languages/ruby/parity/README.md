# Level 05A.2 – Ruby Mode 1 Parity v0.1.0

Independent Ruby implementation of the frozen LNW DC pipeline.

- existing `ruby.exe` runtime
- Ruby standard library only
- no generated native candidate EXE
- no Python Oracle / C# / Rust / Node worker
- Microsoft Excel only through the shared PowerShell COM bridge for workbook I/O/recalculation
- DU/DP parsing, filtering, WWID mapping, merge, XLSX generation, aggregation and LNW calculations are implemented in Ruby

Correctness target:
`078fdf618634632de329ebf250bede8b3a84ba7d7b604d8ec49f277ee2095e32`
