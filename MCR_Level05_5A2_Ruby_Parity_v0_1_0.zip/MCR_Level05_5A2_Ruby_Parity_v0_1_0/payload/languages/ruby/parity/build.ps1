[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$ModeRoot = $PSScriptRoot
$SrcRoot = Join-Path $ModeRoot 'src'
$BuildRoot = Join-Path $ModeRoot 'build'
$Publish = Join-Path $BuildRoot 'publish'
$RubyPointer = Join-Path $BuildRoot 'ruby_path.txt'

function Test-Ruby([string]$Path) {
    if ([string]::IsNullOrWhiteSpace($Path) -or -not (Test-Path $Path -PathType Leaf)) { return $false }
    $old=$ErrorActionPreference; $ErrorActionPreference='Continue'
    try { $v=& $Path --version 2>$null; $c=$LASTEXITCODE } finally { $ErrorActionPreference=$old }
    return ($c -eq 0 -and $v -match '^ruby\s+\d+')
}

$Candidates = New-Object System.Collections.Generic.List[string]
$cmd = Get-Command ruby.exe -ErrorAction SilentlyContinue
if ($cmd) { $Candidates.Add($cmd.Source) }

if ($env:USERPROFILE) {
    foreach ($p in @(
        (Join-Path $env:USERPROFILE 'projects\Compiler\ruby\ruby.exe'),
        (Join-Path $env:USERPROFILE 'projects\Compiler\ruby\bin\ruby.exe'),
        (Join-Path $env:USERPROFILE 'projects\Compiler\ruby\tools\ruby\bin\ruby.exe')
    )) {
        if ((Test-Path $p -PathType Leaf) -and -not $Candidates.Contains($p)) { $Candidates.Add($p) }
    }

    $root = Join-Path $env:USERPROFILE 'projects\Compiler\ruby'
    if (Test-Path $root) {
        Get-ChildItem $root -Recurse -Filter ruby.exe -File -ErrorAction SilentlyContinue | ForEach-Object {
            if (-not $Candidates.Contains($_.FullName)) { $Candidates.Add($_.FullName) }
        }
    }
}

$Ruby=$null
foreach($c in $Candidates){ if(Test-Ruby $c){ $Ruby=$c; break } }
if(-not $Ruby){ throw 'Vorhandene Ruby Runtime wurde nicht gefunden. Es wird nichts heruntergeladen.' }

Write-Host '============================================================'
Write-Host ' Level 05A.2 - Ruby Parity Build'
Write-Host '============================================================'
Write-Host "ruby:      $Ruby"
Write-Host "Ruby:      $(& $Ruby --version)"
Write-Host "Source:    $SrcRoot"
Write-Host "Publish:   $Publish"
Write-Host ''
Write-Host 'Dependencies: existing Ruby runtime + stdlib only / OFFLINE'
Write-Host 'Native candidate EXE generation: NONE'
Write-Host ''

$MainSource=Join-Path $SrcRoot 'main.rb'
if(-not(Test-Path $MainSource -PathType Leaf)){throw "Ruby Source fehlt: $MainSource"}

$old=$ErrorActionPreference; $ErrorActionPreference='Continue'
try { & $Ruby -c $MainSource; $Code=$LASTEXITCODE } finally { $ErrorActionPreference=$old }
if($Code -ne 0){throw "Ruby Syntax Check fehlgeschlagen. ExitCode=$Code"}

if(Test-Path $Publish){Remove-Item $Publish -Recurse -Force}
New-Item -ItemType Directory -Force -Path $Publish | Out-Null
Copy-Item $MainSource (Join-Path $Publish 'main.rb') -Force
Copy-Item (Join-Path $SrcRoot 'excel_bridge.ps1') (Join-Path $Publish 'excel_bridge.ps1') -Force
New-Item -ItemType Directory -Force -Path (Join-Path $Publish 'resources') | Out-Null
Copy-Item (Join-Path $SrcRoot 'resources\settings.json') (Join-Path $Publish 'resources\settings.json') -Force
Copy-Item (Join-Path $SrcRoot 'resources\wwid_mapping.csv') (Join-Path $Publish 'resources\wwid_mapping.csv') -Force

New-Item -ItemType Directory -Force -Path $BuildRoot | Out-Null
Set-Content $RubyPointer $Ruby -Encoding UTF8

$Main=Join-Path $Publish 'main.rb'
if(-not(Test-Path $Main -PathType Leaf)){throw "Ruby Build erzeugte kein main.rb: $Main"}

Write-Host ''
Write-Host 'RUBY PARITY BUILD: PASS' -ForegroundColor Green
Write-Host "MAIN: $Main"
Write-Host 'Runtime: existing ruby.exe (no new native EXE)' -ForegroundColor Green
exit 0
