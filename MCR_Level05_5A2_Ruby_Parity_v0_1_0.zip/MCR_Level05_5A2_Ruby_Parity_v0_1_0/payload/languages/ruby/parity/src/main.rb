# frozen_string_literal: true

require 'json'
require 'set'
require 'fileutils'

module McrLevel05Ruby
  MARKER_PREFIXES = [">>>>", "<<<<", ">>>", "<<<", "===="].freeze
  METADATA_LABELS = Set.new([
    "dateiname", "datei name", "info", "informationen", "groesse", "größe",
    "dateigroesse", "dateigröße", "typ", "dateityp", "erstellungsdatum",
    "erstellt am", "geaendert am", "geändert am", "aenderungsdatum", "änderungsdatum"
  ]).freeze
  KNOWN_HEADER_TERMS = Set.new([
    "erstellungsdatum", "vermittlerzentrale", "vermittlernummer", "kundenidentifikator",
    "kunden_identifikator", "depotnummer", "unterdepot", "wkn", "isin", "kag",
    "fondsname", "depotvariante", "anteilspreis", "waehrungpreis", "währungpreis",
    "produktart", "bestandstuecke", "bestand_stuecke", "bestandbetrag", "bestand_betrag",
    "firmenid", "dat", "wwid", "umsatzstuecke", "umsatz_stuecke", "abgerechneterpreis",
    "anlbetrag", "zahlbetrag", "umsatzart", "devisenkurs", "kursdatum", "zvf_id_alt",
    "zvu_id_alt", "eroeffnungsdatum", "währung_bestand", "waehrung_bestand",
    "schlusstag", "bonus", "status", "id-mercer"
  ]).freeze
  DU_PROFILE_MARKERS = Set.new(%w[
    umsatzstuecke abgerechneterpreis anlbetrag zahlbetrag umsatzart devisenkurs zvfidalt zvuidalt
  ]).freeze
  DP_PROFILE_MARKERS = Set.new(%w[
    anteilspreis eroeffnungsdatum bestandstuecke bestandbetrag waehrungbestand schlusstag idmercer
  ]).freeze

  FUND_ALIASES = {
    "dws inv.foc.europe fc" => "dwsi-eur.eq.hi.co.fc",
    "dwsi-eur.eq.hi.co.fc anteile" => "dwsi-eur.eq.hi.co.fc"
  }.freeze

  module_function

  def clean_cell(value)
    (value.nil? ? "" : value.to_s).tr("\u00A0", " ").strip
  end

  def normalize_header(value)
    clean_cell(value).downcase
      .gsub("ä", "ae").gsub("ö", "oe").gsub("ü", "ue").gsub("ß", "ss")
      .gsub(/[^a-z0-9]+/, "")
  end

  def normalize_text(value)
    (value.nil? ? "" : value.to_s).tr("\u00A0", " ").strip.downcase.gsub(/\s+/, " ")
  end

  def normalize_fund(value)
    n = normalize_text(value)
    FUND_ALIASES.fetch(n, n)
  end

  def normalize_wwid(value)
    return "" if value.nil?
    if value.is_a?(Numeric) && value.finite? && value.to_i.to_f == value.to_f
      return value.to_i.to_s
    end
    s = value.to_s.strip
    s = s[0...-2] if s.match?(/^\d+\.0$/)
    s
  end

  def as_number(value)
    return 0.0 if value.nil? || value == ""
    return value.to_f if value.is_a?(Numeric) && value.finite?

    text = value.to_s.strip.gsub(" ", "")
    return 0.0 if text.empty?

    comma = text.rindex(",")
    dot = text.rindex(".")
    if comma && dot
      if comma > dot
        text = text.delete(".").sub(",", ".")
      else
        text = text.delete(",")
      end
    elsif comma
      text = text.delete(".").sub(",", ".")
    end

    Float(text)
  rescue ArgumentError, TypeError
    0.0
  end

  def is_distribution(value)
    t = normalize_text(value)
    t.start_with?("ertragsaussch") && t.end_with?("ttung")
  end

  def profile_from_filename(name)
    base = File.basename(name.to_s)
    ext = File.extname(base)
    stem = ext.empty? ? base : base[0...-ext.length]
    stem = stem.strip.downcase

    matches = lambda do |prefix|
      return true if stem == prefix
      return false unless stem.start_with?(prefix)
      nxt = stem[prefix.length, 1] || ""
      nxt.empty? || nxt == "_" || nxt == "-" || nxt.match?(/\s/)
    end

    return "du" if matches.call("du")
    return "dp" if matches.call("dp")
    nil
  end

  def header_map(header)
    result = {}
    header.each_with_index do |h, i|
      n = normalize_header(h)
      result[n] = i if !n.empty? && !result.key?(n)
    end
    result
  end

  def find_index(map, aliases)
    aliases.each do |a|
      n = normalize_header(a)
      return map[n] if map.key?(n)
    end
    raise "Required master header missing: #{aliases.join(' / ')}"
  end

  def xml_escape(value)
    value.to_s
      .gsub("&", "&amp;")
      .gsub("<", "&lt;")
      .gsub(">", "&gt;")
      .gsub('"', "&quot;")
      .gsub("'", "&apos;")
  end

  def parse_delimited_line(line, delimiter)
    result = []
    field = +""
    quoted = false
    i = 0
    while i < line.length
      c = line[i]
      if c == '"'
        if quoted && i + 1 < line.length && line[i + 1] == '"'
          field << '"'
          i += 1
        else
          quoted = !quoted
        end
      elsif c == delimiter && !quoted
        result << field
        field = +""
      else
        field << c
      end
      i += 1
    end
    result << field
    result
  end

  class WwidMapping
    def initialize
      @exact = {}
      @depot_fallback = {}
      @conflicts = {}
    end

    def self.clean(value)
      text = McrLevel05Ruby.clean_cell(value).gsub(/\A'+|'+\z/, "")
      text = text[0...-2] if text.match?(/^\d+\.0$/)
      text
    end

    def self.normalize_depot(value)
      clean(value).gsub(/\s+/, "")
    end

    def self.normalize_underdepot(value)
      text = clean(value)
      return "" if text.empty?
      digits = text.scan(/\d/).join
      return text if digits.empty?
      Integer(digits, 10).to_s
    rescue ArgumentError
      digits
    end

    def self.normalize_mapping_wwid(value)
      clean(value)
    end

    def self.load(path)
      bytes = File.binread(path)
      text = begin
        b = bytes.sub(/\A\xEF\xBB\xBF/n, "")
        u = b.dup.force_encoding(Encoding::UTF_8)
        u.valid_encoding? ? u : b.force_encoding(Encoding::Windows_1252).encode(Encoding::UTF_8)
      end
      lines = text.split(/\r?\n/)
      result = new
      return result if lines.empty? || lines[0].strip.empty?

      header = McrLevel05Ruby.parse_delimited_line(lines[0].sub(/\A\uFEFF/, ""), ";")
      fields = {}
      header.each_with_index { |h, i| fields[h.strip.downcase] = i }
      find = lambda do |*names|
        names.each { |n| return fields[n.downcase] if fields.key?(n.downcase) }
        -1
      end

      wwid_idx = find.call("WWID")
      dep1_idx = find.call("Depot_01", "Depo_01")
      dep2_idx = find.call("Depot_02", "Depo_02")
      dep3_idx = find.call("Depot_03", "Depo_03")
      raise "WWID mapping header is incomplete." if [wwid_idx, dep1_idx, dep2_idx, dep3_idx].any? { |x| x < 0 }

      candidates = Hash.new { |h, k| h[k] = Set.new }
      depot_candidates = Hash.new { |h, k| h[k] = Set.new }

      lines.drop(1).each do |line|
        next if line.strip.empty?
        row = McrLevel05Ruby.parse_delimited_line(line, ";")
        at = ->(i) { i >= 0 && i < row.length ? row[i] : "" }
        wwid = normalize_mapping_wwid(at.call(wwid_idx))
        next if wwid.empty?

        [["1", dep1_idx], ["2", dep2_idx], ["3", dep3_idx]].each do |under, idx|
          depot = normalize_depot(at.call(idx))
          next if depot.empty?
          key = "#{depot}\0#{under}"
          candidates[key] << wwid
          depot_candidates[depot] << wwid
        end
      end

      candidates.each do |k, set|
        if set.size == 1
          result.instance_variable_get(:@exact)[k] = set.first
        else
          result.instance_variable_get(:@conflicts)[k] = set
        end
      end
      depot_candidates.each do |d, set|
        result.instance_variable_get(:@depot_fallback)[d] = set.first if set.size == 1
      end
      result
    end

    def resolve(depot, underdepot, existing_wwid)
      depot_key = self.class.normalize_depot(depot)
      under_key = self.class.normalize_underdepot(underdepot)
      existing = self.class.normalize_mapping_wwid(existing_wwid)
      return existing if depot_key.empty?

      key = "#{depot_key}\0#{under_key}"
      return @exact[key] if !under_key.empty? && @exact.key?(key)
      return existing if !under_key.empty? && @conflicts.key?(key)
      return @depot_fallback[depot_key] if @depot_fallback.key?(depot_key)
      existing
    end
  end

  class TextParser
    def initialize(settings, mapping)
      @settings = settings
      @mapping = mapping
      @allowed_company_ids = Set.new(settings.fetch("allowed_company_ids").map { |x| normalize_company_id(x) })
    end

    def parse_file(file_path)
      content = read_text_with_fallback(file_path)
      rows = parse_text_rows(content)
      extract_table(rows, true, true, File.basename(file_path))
    end

    def detect_target_profile(source_header, fallback_width, source_name)
      fp = McrLevel05Ruby.profile_from_filename(source_name)
      return fp if fp

      normalized = Set.new(source_header.select { |x| !x.strip.empty? }.map { |x| McrLevel05Ruby.normalize_header(x) })
      du_score = DU_PROFILE_MARKERS.count { |x| normalized.include?(x) }
      dp_score = DP_PROFILE_MARKERS.count { |x| normalized.include?(x) }
      return "du" if du_score >= 2 && du_score > dp_score
      return "dp" if dp_score >= 2 && dp_score > du_score
      fallback_width >= 30 ? "du" : "dp"
    end

    def extract_table(raw_rows, fixed_target_header, apply_company_filter, source_name)
      rows = split_packed_rows(raw_rows)
      rows = remove_noise_rows(rows)

      if rows.empty?
        return { header: [], rows: [], source_name: source_name } unless fixed_target_header
        profile = detect_target_profile([], 0, source_name)
        header = (profile == "du" ? @settings.fetch("du_target_headers") : @settings.fetch("dp_target_headers")).dup
        return { header: header, rows: [], source_name: source_name }
      end

      header_index = nil
      [30, rows.length].min.times do |i|
        if header_match_score(rows[i], nil) >= 5 || looks_like_header(rows[i])
          header_index = i
          break
        end
      end

      detected_source_header = header_index.nil? ? [] : rows[header_index].dup

      if fixed_target_header
        source_width = detected_source_header.empty? ? rows.map(&:length).max : detected_source_header.length
        profile = detect_target_profile(detected_source_header, source_width, source_name)
        header = (profile == "du" ? @settings.fetch("du_target_headers") : @settings.fetch("dp_target_headers")).dup
        data_rows = rows.drop(header_index.nil? ? 0 : header_index + 1)
        width = header.length
        source_header = detected_source_header
        source_company_index = find_company_id_column(source_header, source_header.length, false)
        target_company_index = find_company_id_column(header, width, true)
        target_mapping = build_target_mapping(source_header, header)
      else
        if header_index
          header = make_unique_headers(rows[header_index])
          data_rows = rows.drop(header_index + 1)
          width = header.length
        else
          width = rows.map(&:length).max
          header = Array.new(width) { |i| format("Feld_%02d", i + 1) }
          data_rows = rows
        end
        source_header = header.dup
        source_company_index = find_company_id_column(source_header, width, false)
        target_company_index = source_company_index
        target_mapping = nil
      end

      normalized_header = header.map { |h| McrLevel05Ruby.normalize_header(h) }
      normalized_source_header = source_header.map { |h| McrLevel05Ruby.normalize_header(h) }
      clean_data = []

      data_rows.each do |row|
        next if empty_row?(row) || marker_row?(row) || metadata_row?(row)

        fitted_for_header = normalize_row_width(row, [width, source_header.length].max)
        row_norm = fitted_for_header.map { |x| McrLevel05Ruby.normalize_header(x) }
        target_overlap = pair_overlap(row_norm, normalized_header)
        source_overlap = pair_overlap(row_norm, normalized_source_header)

        next if target_overlap >= [4, [8, (width / 3).floor].min].max ||
                source_overlap >= [4, [8, ([1, source_header.length].max / 3).floor].min].max ||
                header_match_score(row, header) >= 5 ||
                (!source_header.empty? && header_match_score(row, source_header) >= 5)

        company_id = nil
        if apply_company_filter
          company_id = find_allowed_company_id(row, [source_company_index, @settings.fetch("company_id_column_index")])
          next if company_id.nil?
        end

        fitted = map_row_to_target(row, width, target_mapping)

        if fixed_target_header
          idx_map = {}
          header.each_with_index do |h, i|
            n = McrLevel05Ruby.normalize_header(h)
            idx_map[n] = i unless n.empty?
          end
          wwid_idx = idx_map["wwid"]
          depot_idx = idx_map["depotnummer"]
          under_idx = idx_map["unterdepot"]
          unless wwid_idx.nil? || depot_idx.nil?
            existing = fitted[wwid_idx] || ""
            depot = fitted[depot_idx] || ""
            under = under_idx.nil? ? "" : (fitted[under_idx] || "")
            fitted[wwid_idx] = @mapping.resolve(depot, under, existing)
          end
        end

        fitted[target_company_index] = company_id if !company_id.nil? && !target_company_index.nil? && target_company_index < fitted.length
        clean_data << fitted if fitted.any? { |x| x != "" }
      end

      { header: header, rows: clean_data, source_name: source_name }
    end

    private

    def find_allowed_company_id(row, preferred)
      checked = Set.new
      preferred.each do |idx|
        next if idx.nil? || idx < 0 || idx >= row.length || checked.include?(idx)
        checked << idx
        c = normalize_company_id(row[idx])
        return c if @allowed_company_ids.include?(c)
      end
      row.each_index do |i|
        next if checked.include?(i)
        c = normalize_company_id(row[i])
        return c if @allowed_company_ids.include?(c)
      end
      nil
    end

    def find_company_id_column(header, width, fixed)
      norm = header.map { |h| McrLevel05Ruby.normalize_header(h) }
      %w[firmenid companyid firmen_id company_id].each do |c|
        i = norm.index(McrLevel05Ruby.normalize_header(c))
        return i unless i.nil?
      end
      idx = @settings.fetch("company_id_column_index")
      return idx if fixed && idx < width
      nil
    end

    def normalize_company_id(value)
      McrLevel05Ruby.clean_cell(value).upcase
    end

    def header_match_score(row, reference)
      row_norm = Set.new(row.select { |x| !x.strip.empty? }.map { |x| McrLevel05Ruby.normalize_header(x) })
      if reference
        ref_norm = Set.new(reference.select { |x| !x.strip.empty? }.map { |x| McrLevel05Ruby.normalize_header(x) })
        return ref_norm.count { |x| row_norm.include?(x) }
      end

      du_norm = Set.new(@settings.fetch("du_target_headers").map { |x| McrLevel05Ruby.normalize_header(x) })
      dp_norm = Set.new(@settings.fetch("dp_target_headers").map { |x| McrLevel05Ruby.normalize_header(x) })
      du = row_norm.count { |x| du_norm.include?(x) }
      dp = row_norm.count { |x| dp_norm.include?(x) }
      [du, dp].max
    end

    def looks_like_header(row)
      cells = row.map { |x| McrLevel05Ruby.clean_cell(x) }.reject(&:empty?)
      return false if cells.length < 4

      normalized = Set.new(cells.map { |x| McrLevel05Ruby.normalize_header(x) })
      known = Set.new(KNOWN_HEADER_TERMS.map { |x| McrLevel05Ruby.normalize_header(x) })
      hits = normalized.count { |x| known.include?(x) }
      return true if hits >= 3
      return true if header_match_score(cells, nil) >= 5

      alpha_cells = cells.count { |x| x.match?(/[A-Za-zÄÖÜäöüß]/) }
      numeric_cells = cells.count { |x| numeric_like?(x) }
      date_like_first = cells[0].match?(/^\d{8}$/)
      return false if date_like_first || numeric_cells >= [3, (cells.length / 3).floor].max
      alpha_cells >= [4, (cells.length * 0.65).floor].max
    end

    def build_target_mapping(source_header, target_header)
      return nil if source_header.empty?
      source_index = {}
      source_header.each_with_index do |h, i|
        n = McrLevel05Ruby.normalize_header(h)
        source_index[n] = i if !n.empty? && !source_index.key?(n)
      end
      target_norm = target_header.map { |x| McrLevel05Ruby.normalize_header(x) }
      overlap = target_norm.count { |n| !n.empty? && source_index.key?(n) }
      return nil if overlap < [5, (target_norm.length * 0.35).floor].max
      target_norm.each_with_index.map { |n, i| source_index.key?(n) ? source_index[n] : (i < source_header.length ? i : nil) }
    end

    def map_row_to_target(row, target_width, mapping)
      return normalize_row_width(row, target_width) if mapping.nil?
      Array.new(target_width) do |i|
        s = i < mapping.length ? mapping[i] : nil
        !s.nil? && s >= 0 && s < row.length ? McrLevel05Ruby.clean_cell(row[s]) : ""
      end
    end

    def pair_overlap(a, b)
      n = 0
      [a.length, b.length].min.times { |i| n += 1 if !a[i].empty? && a[i] == b[i] }
      n
    end

    def make_unique_headers(headers)
      counts = Hash.new(0)
      headers.each_with_index.map do |h, i|
        name = McrLevel05Ruby.clean_cell(h)
        name = format("Feld_%02d", i + 1) if name.empty?
        counts[name] += 1
        counts[name] > 1 ? "#{name}_#{counts[name]}" : name
      end
    end

    def trim_trailing_empty(row)
      v = row.map { |x| McrLevel05Ruby.clean_cell(x) }
      v.pop while !v.empty? && v[-1].empty?
      v
    end

    def remove_noise_rows(rows)
      rows.map { |r| trim_trailing_empty(r) }.select { |r| !r.empty? && !marker_row?(r) && !metadata_row?(r) }
    end

    def split_packed_rows(rows)
      rows.map do |r|
        c = trim_trailing_empty(r)
        nonempty = c.reject(&:empty?)
        if nonempty.length == 1 && nonempty[0].count(";") >= 3
          McrLevel05Ruby.parse_delimited_line(nonempty[0], ";").map { |x| McrLevel05Ruby.clean_cell(x) }
        else
          c
        end
      end
    end

    def normalize_row_width(row, width)
      Array.new(width) { |i| i < row.length ? McrLevel05Ruby.clean_cell(row[i]) : "" }
    end

    def empty_row?(row)
      !row.any? { |x| McrLevel05Ruby.clean_cell(x) != "" }
    end

    def first_nonempty(row)
      row.map { |x| McrLevel05Ruby.clean_cell(x) }.find { |x| !x.empty? } || ""
    end

    def marker_row?(row)
      f = first_nonempty(row).lstrip
      !f.empty? && MARKER_PREFIXES.any? { |p| f.start_with?(p) }
    end

    def metadata_row?(row)
      c = row.map { |x| McrLevel05Ruby.clean_cell(x) }.reject(&:empty?)
      return false if c.empty? || c.length > 3
      METADATA_LABELS.include?(c[0].downcase.strip.sub(/:\z/, ""))
    end

    def numeric_like?(value)
      s = value.strip
      s.match?(/^[-+]?\d+(?:[.,]\d+)?$/) || s.match?(/^\d{6,14}$/) || s.match?(/^[A-Z]{2}\d{9,12}$/)
    end

    def detect_separator(content)
      lines = content.gsub("\r\n", "\n").gsub("\r", "\n").split("\n").select { |x| !x.strip.empty? }.first(20)
      return nil if lines.empty?
      best = nil
      best_score = 0
      [";", "\t", "|", ","].each do |c|
        score = lines.sum { |line| count_outside_quotes(line, c) }
        if score > best_score
          best = c
          best_score = score
        end
      end
      best_score > 0 ? best : nil
    end

    def count_outside_quotes(line, delimiter)
      quoted = false
      count = 0
      i = 0
      while i < line.length
        if line[i] == '"'
          if quoted && i + 1 < line.length && line[i + 1] == '"'
            i += 1
          else
            quoted = !quoted
          end
        elsif line[i] == delimiter && !quoted
          count += 1
        end
        i += 1
      end
      count
    end

    def parse_text_rows(content)
      sep = detect_separator(content)
      lines = content.gsub("\r\n", "\n").gsub("\r", "\n").split("\n")
      rows = []
      lines.each do |raw|
        next if raw.strip.empty?
        row = sep ? McrLevel05Ruby.parse_delimited_line(raw, sep) : [raw.strip]
        cleaned = row.map { |x| McrLevel05Ruby.clean_cell(x) }
        rows << cleaned if cleaned.any? { |x| !x.empty? }
      end
      rows
    end

    def read_text_with_fallback(path)
      bytes = File.binread(path)
      bytes = bytes.byteslice(3..) if bytes.bytesize >= 3 && bytes.bytes[0, 3] == [0xEF, 0xBB, 0xBF]
      utf8 = bytes.dup.force_encoding(Encoding::UTF_8)
      return utf8 if utf8.valid_encoding?
      bytes.force_encoding(Encoding::Windows_1252).encode(Encoding::UTF_8)
    end
  end

  module XlsxWriter
    module_function

    def crc32(data)
      crc = 0xFFFFFFFF
      data.each_byte do |byte|
        crc ^= byte
        8.times { crc = (crc & 1) == 1 ? ((crc >> 1) ^ 0xEDB88320) : (crc >> 1) }
      end
      (~crc) & 0xFFFFFFFF
    end

    def u16(v) = [v & 0xFFFF].pack("v")
    def u32(v) = [v & 0xFFFFFFFF].pack("V")

    def write_store_zip(file_path, files)
      FileUtils.mkdir_p(File.dirname(file_path))
      parts = []
      entries = []
      offset = 0

      files.each do |name, data|
        name_b = name.encode(Encoding::UTF_8).b
        data_b = data.b
        crc = crc32(data_b)
        size = data_b.bytesize
        local = u32(0x04034b50) + u16(20) + u16(0) + u16(0) + u16(0) + u16(0x0021) +
                u32(crc) + u32(size) + u32(size) + u16(name_b.bytesize) + u16(0) + name_b + data_b
        parts << local
        entries << [name, crc, size, offset]
        offset += local.bytesize
      end

      central_start = offset
      entries.each do |name, crc, size, entry_offset|
        name_b = name.encode(Encoding::UTF_8).b
        c = u32(0x02014b50) + u16(20) + u16(20) + u16(0) + u16(0) + u16(0) + u16(0x0021) +
            u32(crc) + u32(size) + u32(size) + u16(name_b.bytesize) + u16(0) + u16(0) +
            u16(0) + u16(0) + u32(0) + u32(entry_offset) + name_b
        parts << c
        offset += c.bytesize
      end

      central_size = offset - central_start
      parts << u32(0x06054b50) + u16(0) + u16(0) + u16(entries.length) + u16(entries.length) +
               u32(central_size) + u32(central_start) + u16(0)

      File.binwrite(file_path, parts.join)
    end

    def column_name(col)
      s = +""
      while col > 0
        col -= 1
        s = (65 + (col % 26)).chr + s
        col /= 26
      end
      s
    end

    def worksheet_xml(header, rows)
      s = +'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>'
      write_row = lambda do |rnum, values|
        s << %(<row r="#{rnum}">)
        values.each_with_index do |value, i|
          value = value || ""
          next if value.empty?
          cref = "#{column_name(i + 1)}#{rnum}"
          s << %(<c r="#{cref}" t="inlineStr"><is><t)
          s << ' xml:space="preserve"' if value.match?(/^\s|\s$/)
          s << ">" << McrLevel05Ruby.xml_escape(value) << "</t></is></c>"
        end
        s << "</row>"
      end

      write_row.call(1, header)
      rows.each_with_index { |r, i| write_row.call(i + 2, r) }
      s << "</sheetData></worksheet>"
      s
    end

    def write_xlsx(file_path, sheet_name, header, rows)
      content_types = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>'
      root_rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'
      workbook = %(<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="#{McrLevel05Ruby.xml_escape(sheet_name)}" sheetId="1" r:id="rId1"/></sheets></workbook>)
      workbook_rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>'
      sheet = worksheet_xml(header, rows)

      write_store_zip(file_path, [
        ["[Content_Types].xml", content_types.encode("UTF-8")],
        ["_rels/.rels", root_rels.encode("UTF-8")],
        ["xl/workbook.xml", workbook.encode("UTF-8")],
        ["xl/_rels/workbook.xml.rels", workbook_rels.encode("UTF-8")],
        ["xl/worksheets/sheet1.xml", sheet.encode("UTF-8")]
      ])
    end
  end

  module Lnw
    module_function

    def at(row, idx)
      idx >= 0 && idx < row.length ? row[idx] : ""
    end

    def du_key(wwid, fund, movement) = "#{wwid}\0#{fund}\0#{movement}"
    def dp_key(wwid, fund) = "#{wwid}\0#{fund}"

    def aggregate_du(table, investment_value)
      map = McrLevel05Ruby.header_map(table[:header])
      wwid_idx = McrLevel05Ruby.find_index(map, ["WWID"])
      fund_idx = McrLevel05Ruby.find_index(map, ["Fondsname", "Fonds Name"])
      movement_idx = McrLevel05Ruby.find_index(map, ["Umsatzart", "Umsatz Art"])
      shares_idx = McrLevel05Ruby.find_index(map, ["UmsatzStuecke", "Umsatzstücke", "Umsatz Stücke"])
      value_idx = investment_value ?
        McrLevel05Ruby.find_index(map, ["Anlbetrag", "AnlBetrag", "Anl Betrag", "Anlagebetrag"]) :
        McrLevel05Ruby.find_index(map, ["ZahlBetrag", "Zahlbetrag", "Zahl Betrag"])

      out = {}
      table[:rows].each do |row|
        wwid = McrLevel05Ruby.normalize_wwid(at(row, wwid_idx))
        fund = McrLevel05Ruby.normalize_fund(at(row, fund_idx))
        movement = McrLevel05Ruby.normalize_text(at(row, movement_idx))
        next if wwid.empty? || fund.empty? || movement.empty?

        k = du_key(wwid, fund, movement)
        cur = out[k] ||= { shares: 0.0, value: 0.0 }
        cur[:shares] += McrLevel05Ruby.as_number(at(row, shares_idx))
        cur[:value] += McrLevel05Ruby.as_number(at(row, value_idx))
      end
      out
    end

    def aggregate_dp(table)
      map = McrLevel05Ruby.header_map(table[:header])
      wwid_idx = McrLevel05Ruby.find_index(map, ["WWID"])
      fund_idx = McrLevel05Ruby.find_index(map, ["Fondsname", "Fonds Name"])
      shares_idx = McrLevel05Ruby.find_index(map, ["Bestand_Stuecke", "BestandStuecke", "Bestand Stücke", "Bestand_Stücke", "Bestandstücke"])
      value_idx = McrLevel05Ruby.find_index(map, ["Bestand_Betrag", "BestandBetrag", "Bestand Betrag"])

      out = {}
      table[:rows].each do |row|
        wwid = McrLevel05Ruby.normalize_wwid(at(row, wwid_idx))
        fund = McrLevel05Ruby.normalize_fund(at(row, fund_idx))
        next if wwid.empty? || fund.empty?

        k = dp_key(wwid, fund)
        cur = out[k] ||= { shares: 0.0, value: 0.0 }
        cur[:shares] += McrLevel05Ruby.as_number(at(row, shares_idx))
        cur[:value] += McrLevel05Ruby.as_number(at(row, value_idx))
      end
      out
    end

    def bridge_path
      p = File.join(__dir__, "excel_bridge.ps1")
      raise "Excel bridge missing: #{p}" unless File.file?(p)
      p
    end

    def run_bridge(args)
      ok = system("powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", bridge_path, *args)
      raise "Excel bridge failed with exit code #{$?.exitstatus}" unless ok
    end

    def parse_snapshot(file_path)
      header_row = 0
      last_row = 0
      rows = []

      File.read(file_path, encoding: "UTF-8").split(/\r?\n/).each do |line|
        next if line.empty?
        p = line.split("\t", -1)
        if p[0] == "META" && p.length >= 4
          header_row = p[1].to_i
          last_row = p[3].to_i
        elsif p[0] == "ROW" && p.length >= 13
          rows << {
            row: p[1].to_i,
            wwid: McrLevel05Ruby.normalize_wwid(p[2]),
            prev: p[3, 10].map { |x| McrLevel05Ruby.as_number(x) }
          }
        end
      end

      raise "Snapshot metadata invalid" if header_row.zero? || last_row <= header_row
      { header_row: header_row, last_row: last_row, rows: rows }
    end

    def number_text(v)
      v.finite? ? v.to_s : "0"
    end

    def run(template_path, du, dp, output_excel, output_csv, work_dir)
      FileUtils.mkdir_p(work_dir)
      FileUtils.cp(template_path, output_excel)
      snapshot_path = File.join(work_dir, "excel_snapshot.tsv")
      plan_path = File.join(work_dir, "excel_plan.tsv")

      puts "[LNW] Output-Template wird ueber Microsoft Excel geoeffnet ..."
      run_bridge(["-Mode", "Snapshot", "-Workbook", output_excel, "-SnapshotPath", snapshot_path])
      snap = parse_snapshot(snapshot_path)
      puts "[LNW] Zielblatt erkannt: WWID-Header Zeile #{snap[:header_row]}, letzte WWID-Zeile #{snap[:last_row]}."

      puts "[LNW] DU wird nach WWID, Fonds und Umsatzart aggregiert ..."
      du_agg = aggregate_du(du, false)
      purchase_agg = aggregate_du(du, true)
      puts "[LNW] DP wird nach WWID und Fonds aggregiert ..."
      dp_agg = aggregate_dp(dp)

      lines = ["META\t#{snap[:header_row] + 1}\t#{snap[:last_row]}"]
      set = ->(addr, val) { lines << "SET\t#{addr}\t#{number_text(val)}" }

      prev_to_current = [["AJ",0],["AK",1],["AL",2],["AM",3],["AN",4],["AO",5],["AP",6],["AQ",7],["AR",8],["AS",9]]
      purchase_maps = [
        ["DWS EURORENTA", "AV", "AW"],
        ["DWS INS.-ESG EO MO.M.IC", "AY", "AZ"],
        ["DWSI-EUR.EQ.HI.CO.FC", "BB", "BC"]
      ]
      funds = [
        ["DWSI-EUR.EQ.HI.CO.FC", "CL", "CM", "BI", "BJ"],
        ["DWS EURORENTA", "CN", "CO", "BK", "BL"],
        ["DWS INS.-ESG EO MO.M.IC", "CP", "CQ", "BM", "BN"],
        ["SIEMENS EUROINVEST AKTIEN", "CR", "CS", nil, nil],
        ["SIEMENS EUROINVEST RENTEN", "CT", "CU", nil, nil]
      ]

      purchase_movement = McrLevel05Ruby.normalize_text("Kauf")
      realloc_movement = McrLevel05Ruby.normalize_text("Fondsportfolioanpassung")
      dist_fund = McrLevel05Ruby.normalize_fund("DWS EURORENTA")

      puts "[LNW] Schreibplan fuer AJ:CU wird erzeugt ..."
      snap[:rows].each do |s|
        next if s[:wwid].empty?

        prev_to_current.each { |col, i| set.call("#{col}#{s[:row]}", s[:prev][i] || 0.0) }

        purchase_maps.each do |fund, sc, vc|
          v = purchase_agg[du_key(s[:wwid], McrLevel05Ruby.normalize_fund(fund), purchase_movement)] || { shares: 0.0, value: 0.0 }
          set.call("#{sc}#{s[:row]}", v[:shares])
          set.call("#{vc}#{s[:row]}", v[:value])
        end

        ds = 0.0
        dv = 0.0
        du_agg.each do |k, v|
          w, f, m = k.split("\0", 3)
          if w == s[:wwid] && f == dist_fund && McrLevel05Ruby.is_distribution(m)
            ds += v[:shares]
            dv += v[:value]
          end
        end
        set.call("BF#{s[:row]}", ds)
        set.call("BG#{s[:row]}", dv)

        funds.each do |fund, end_s, end_v, rs, rv|
          f = McrLevel05Ruby.normalize_fund(fund)
          if rs && rv
            v = du_agg[du_key(s[:wwid], f, realloc_movement)] || { shares: 0.0, value: 0.0 }
            set.call("#{rs}#{s[:row]}", v[:shares])
            set.call("#{rv}#{s[:row]}", v[:value])
          end
          d = dp_agg[dp_key(s[:wwid], f)] || { shares: 0.0, value: 0.0 }
          set.call("#{end_s}#{s[:row]}", d[:shares])
          set.call("#{end_v}#{s[:row]}", d[:value])
        end
      end

      File.binwrite(plan_path, lines.join("\r\n") + "\r\n")
      puts "[LNW] Konstanten werden geloescht, Werte geschrieben und Excel neu berechnet ..."
      run_bridge(["-Mode", "Apply", "-Workbook", output_excel, "-PlanPath", plan_path, "-CsvPath", output_csv])
      puts "[LNW] Verarbeitung erfolgreich abgeschlossen."
    end
  end

  class Pipeline
    def initialize(parser)
      @parser = parser
    end

    def run(options)
      raise "Input directory missing: #{options[:input_dir]}" unless File.directory?(options[:input_dir])
      raise "Template missing: #{options[:template_path]}" unless File.file?(options[:template_path])

      FileUtils.mkdir_p(options[:output_dir])
      work = File.join(options[:output_dir], "work")
      convert_root = File.join(work, "01_convert_merge")
      du_converted = File.join(convert_root, "DU")
      dp_converted = File.join(convert_root, "DP")
      lnw_dir = File.join(work, "02_LNW")
      [du_converted, dp_converted, lnw_dir].each { |p| FileUtils.mkdir_p(p) }

      files = []
      enumerate_files(options[:input_dir], files)
      filtered = files.reject { |p| File.basename(p).start_with?("~$") }
      du_files = filtered.select { |p| McrLevel05Ruby.profile_from_filename(File.basename(p)) == "du" }.sort_by { |p| File.basename(p).downcase }
      dp_all = filtered.select { |p| McrLevel05Ruby.profile_from_filename(File.basename(p)) == "dp" }.sort_by { |p| File.basename(p).downcase }

      puts "Quelldateien erkannt: #{du_files.length} DU | #{dp_all.length} DP | #{filtered.length - du_files.length - dp_all.length} ignoriert"
      raise "No DU raw files found." if du_files.empty?
      raise "No DP raw files found." if dp_all.empty?

      dp_files = select_dp(dp_all)
      du_master = File.join(options[:output_dir], "DU_MASTER.xlsx")
      dp_master = File.join(options[:output_dir], "DP_MASTER.xlsx")

      du = convert_and_merge("du", du_files, du_converted, du_master, options[:workers])
      dp = convert_and_merge("dp", dp_files, dp_converted, dp_master, options[:workers])

      ext = File.extname(options[:template_path])
      ext = ".xlsm" if ext.empty?
      lnw_excel = File.join(options[:output_dir], "LNW_Output#{ext}")
      lnw_csv = File.join(options[:output_dir], "LNW_Output.csv")

      puts "[LNW] DU- und DP-Master werden an die Ruby LNW-Engine uebergeben ..."
      Lnw.run(options[:template_path], du[:table], dp[:table], lnw_excel, lnw_csv, lnw_dir)

      {
        du_master: du_master,
        dp_master: dp_master,
        lnw_excel: lnw_excel,
        lnw_csv: lnw_csv,
        du_rows: du[:table][:rows].length,
        dp_rows: dp[:table][:rows].length
      }
    end

    private

    def convert_and_merge(profile, source_files, converted_dir, master_path, workers)
      label = profile.upcase
      puts "[#{label}] #{source_files.length} Rohdatei(en) werden konvertiert und zusammengefuehrt ..."
      FileUtils.mkdir_p(converted_dir)
      reservations = reserve_output_paths(source_files, converted_dir)
      results = {}
      errors = []
      completed = 0

      # Correctness-first Ruby implementation. Sequential conversion in v0.1.0.
      source_files.each do |source|
        begin
          table = @parser.parse_file(source)
          XlsxWriter.write_xlsx(reservations[source], "Ziel 1", table[:header], table[:rows])
          results[source] = table
          completed += 1
          puts "[#{label}] #{completed}/#{source_files.length} | #{File.basename(source)} | Datei abgeschlossen"
        rescue => e
          completed += 1
          errors << "#{File.basename(source)}: #{e.message}"
          puts "[#{label}] #{completed}/#{source_files.length} | #{File.basename(source)} | FEHLER: #{e.message}"
        end
      end

      successful = source_files.select { |s| results.key?(s) }
      raise "No #{label} source could be converted.\n#{errors.first(20).join("\n")}" if successful.empty?

      puts "[#{label}] Konvertierung fertig. #{successful.length} Datei(en) werden zum Master zusammengefuehrt ..."
      header = results[successful[0]][:header].dup
      merged = []
      pos = 0

      successful.each do |source|
        pos += 1
        table = results[source]
        begin
          merged.concat(align_rows(table, header))
          puts "[#{label}] Merge #{pos}/#{successful.length + 1} | #{File.basename(reservations[source])} | Datei abgeschlossen | #{merged.length} Zeilen"
        rescue => e
          errors << "#{File.basename(reservations[source])}: #{e.message}"
          puts "[#{label}] Merge #{pos}/#{successful.length + 1} | #{File.basename(reservations[source])} | FEHLER: #{e.message} | #{merged.length} Zeilen"
        end
      end

      XlsxWriter.write_xlsx(master_path, "Gesamtdaten", header, merged)
      puts "[#{label}] Merge #{successful.length + 1}/#{successful.length + 1} | #{File.basename(master_path)} | Masterdatei gespeichert | #{merged.length} Zeilen"
      puts "[#{label}] Master fertig: #{File.basename(master_path)} | #{merged.length} Datenzeilen"

      { table: { header: header, rows: merged, source_name: master_path }, errors: errors }
    end

    def enumerate_files(dir, out)
      Dir.children(dir).each do |name|
        p = File.join(dir, name)
        if File.directory?(p)
          enumerate_files(p, out)
        elsif File.file?(p)
          out << p
        end
      end
    end

    def select_dp(files)
      return files.dup if files.length <= 1
      sorted = files.sort_by { |p| [filename_date(p), File.basename(p).downcase] }
      puts "[DP] #{files.length} DP-Dateien erkannt. Verwendet wird #{File.basename(sorted[0])}."
      [sorted[0]]
    end

    def filename_date(file_path)
      stem = File.basename(file_path, File.extname(file_path))
      vals = stem.scan(/(?<!\d)(20\d{6})(?!\d)/).flatten.map(&:to_i)
      vals.empty? ? 99_999_999 : vals[-1]
    end

    def reserve_output_paths(source_files, output_dir)
      used = Set.new
      map = {}
      source_files.each do |source|
        stem = File.basename(source, File.extname(source))
        stem = File.basename(source) if stem.empty?
        candidate = File.join(output_dir, "#{stem}.xlsx")
        counter = 1
        while used.include?(candidate.downcase)
          candidate = File.join(output_dir, "#{stem}_#{counter}.xlsx")
          counter += 1
        end
        used << candidate.downcase
        map[source] = candidate
      end
      map
    end

    def align_rows(source, master_header)
      source_norm = source[:header].map { |x| McrLevel05Ruby.normalize_header(x) }
      master_norm = master_header.map { |x| McrLevel05Ruby.normalize_header(x) }

      if source_norm.length == master_norm.length && source_norm.each_with_index.all? { |x, i| x == master_norm[i] }
        return source[:rows].map(&:dup)
      end

      source_index = {}
      source_norm.each_with_index { |n, i| source_index[n] = i unless n.empty? }
      common = master_norm.count { |n| source_index.key?(n) }
      raise "Header weicht zu stark von den übrigen Dateien ab." if common < [4, (master_norm.length * 0.60).floor].max

      source[:rows].map do |row|
        master_norm.map do |n|
          i = source_index[n]
          !i.nil? && i < row.length ? row[i] : ""
        end
      end
    end
  end

  def parse_args(argv)
    map = {}
    i = 0
    while i < argv.length
      k = argv[i]
      raise "Unexpected argument: #{k}" unless k.start_with?("--")
      raise "Missing value for #{k}" if i + 1 >= argv.length
      map[k.downcase] = argv[i + 1]
      i += 2
    end

    need = lambda do |k|
      v = map[k]
      raise "Required argument missing: #{k}" if v.nil? || v.strip.empty?
      v
    end

    workers = (map["--workers"] || "4").to_i
    workers = 4 if workers <= 0

    {
      case_id: map["--case"] || "MCR_LNW_001",
      input_dir: File.expand_path(need.call("--input")),
      template_path: File.expand_path(need.call("--template")),
      output_dir: File.expand_path(need.call("--output")),
      workers: [1, workers].max
    }
  end

  def main(argv)
    options = parse_args(argv)
    raise "This candidate is frozen to case MCR_LNW_001." unless options[:case_id] == "MCR_LNW_001"

    settings_path = File.join(__dir__, "resources", "settings.json")
    mapping_path = File.join(__dir__, "resources", "wwid_mapping.csv")
    raise "Candidate resources are missing from build output." unless File.file?(settings_path) && File.file?(mapping_path)

    puts "=" * 72
    puts "MCR LEVEL 05A.2 - RUBY MODE 1 PARITY CANDIDATE"
    puts "=" * 72
    puts "Case:    #{options[:case_id]}"
    puts "Input:   #{options[:input_dir]}"
    puts "Template:#{options[:template_path]}"
    puts "Output:  #{options[:output_dir]}"
    puts "Workers: #{options[:workers]}"
    puts

    FileUtils.mkdir_p(options[:output_dir])
    settings = JSON.parse(File.read(settings_path, encoding: "UTF-8"))
    mapping = WwidMapping.load(mapping_path)
    parser = TextParser.new(settings, mapping)
    result = Pipeline.new(parser).run(options)

    candidate = {
      schema: "mcr.level05.candidate-result.v1",
      status: "success",
      case: options[:case_id],
      language: "ruby",
      mode: "parity",
      artifacts: {
        du_master: File.basename(result[:du_master]),
        dp_master: File.basename(result[:dp_master]),
        lnw_excel: File.basename(result[:lnw_excel]),
        lnw_csv: File.basename(result[:lnw_csv])
      },
      diagnostics: {
        du_master_rows: result[:du_rows],
        dp_master_rows: result[:dp_rows],
        workers: options[:workers],
        runtime: RUBY_DESCRIPTION
      }
    }

    File.write(File.join(options[:output_dir], "candidate_result.json"), JSON.pretty_generate(candidate), encoding: "UTF-8")
    puts
    puts "Ruby candidate completed successfully."
    puts "DU Master Rows: #{result[:du_rows]}"
    puts "DP Master Rows: #{result[:dp_rows]}"
    puts "candidate_result.json written."
    0
  rescue => e
    warn
    warn "RUBY CANDIDATE FAILED"
    warn e.full_message
    1
  end
end

exit(McrLevel05Ruby.main(ARGV))
