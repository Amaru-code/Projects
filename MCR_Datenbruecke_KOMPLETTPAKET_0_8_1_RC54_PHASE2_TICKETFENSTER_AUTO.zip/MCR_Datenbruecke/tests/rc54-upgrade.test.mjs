import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';
import {ROOT,temp,putActive,historyFixture} from './helpers.mjs';
import {sha256} from '../lib/core.mjs';import {readZip} from '../lib/zip.mjs';
import {VERSION,writeJSON,ledger} from '../lib/control.mjs';
import {verifyPrevious,verifyPackage,treeDigest} from '../tools/integrity.mjs';
import {planInstall,installSoftware,journals,restoreSoftware} from '../tools/deploy.mjs';
import {beginMigrationPriority} from '../lib/migration-priority.mjs';
const SHA='5f23ca684e67dbea0e020d1af4ce2ad5cca0402dd4170d2b148c74dbfd954c2e';
test('RC54 original RC53 ZIP upgrade and rollback preserve mapping profile and all pending SEND/Phase2 actions',{timeout:110000},()=>{
 const zip=historyFixture('complete-0.8.1-rc.53.zip');assert.equal(sha256(zip),SHA);
 const parent=temp(),target=path.join(parent,'MCR_Datenbruecke');fs.mkdirSync(target);
 try{
  const input=readZip(zip);
  for(const name of input.names){assert(name.startsWith('MCR_Datenbruecke/'));const file=path.join(target,name.slice('MCR_Datenbruecke/'.length));
   fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,input.get(name));}
  putActive(target);
  const action=path.join(target,'.runtime/phase2/actions/MCR_PHASE2_87278094.json');fs.mkdirSync(path.dirname(action),{recursive:true});
  const states=['PREPARED','UPLOAD_INTENT','UPLOAD_VERIFIED','GEVO_INTENT','GEVO_VERIFIED','DESCRIPTION_INTENT','DESCRIPTION_VERIFIED',
   'DRAFT_SAVE_INTENT','DRAFT_SAVE_VERIFIED','TICKET_SAVE_INTENT','TICKET_SAVE_RECOVERY_OPERATOR_AUTHORIZED',
   'TICKET_SAVE_RECOVERY_GEVO_INTENT','TICKET_SAVE_RECOVERY_GEVO_VERIFIED','TICKET_SAVE_AUTO_CLICK_INTENT','TICKET_SAVE_NETWORK_OBSERVED'];
  writeJSON(action,{schema:'MCR_PHASE2_ACTION_JOURNAL_V1',ticketId:'87278094',state:'TICKET_SAVE_INTENT',ticketSaveRecoveryCount:1,
   descriptionSha256:'a'.repeat(64),pdfHashes:[{plan:'DC',sha256:'b'.repeat(64)},{plan:'PP+',sha256:'c'.repeat(64)}],events:states.map(state=>({state}))});
  const prof=path.join(target,'.runtime/bot-edge-profile');fs.mkdirSync(prof);fs.writeFileSync(path.join(prof,'marker'),'UNCHANGED');
  writeJSON(path.join(target,'.runtime/phase2/actions/MCR_PHASE2_WORK_87316993.json'),{schema:'MCR_PHASE2_WORK_JOURNAL_V1',ticketId:'87316993',state:'TICKET_SAVE_INTENT',events:[{state:'TICKET_SAVE_INTENT'}]});
  const sent=path.join(target,'.runtime/beta-control/ticket-ledger.json');
  ledger(target).begin('88149870','USC 100/ DC\nStandardantwort versendet');
  const priorSent=fs.readFileSync(sent);
  const checks=['private_data','.runtime/phase2','.runtime/bot-edge-profile','config'];
  const prior=Object.fromEntries(checks.map(k=>[k,treeDigest(path.join(target,k))]));
  assert.equal(verifyPrevious(target).version,'0.8.1-rc.53');
  const stopper=()=>({schema:'MCR_PROCESS_GUARD_V1',checked:true,blockedCount:0,unknownCount:0,inspectedPids:[process.pid],
   inspectedProcesses:[{pid:process.pid,relation:'PROTECTED'}],stoppedProcesses:[]});
  const migration=beginMigrationPriority(planInstall(ROOT,target),{stop:stopper});let result;
  try{result=installSoftware(planInstall(ROOT,target,{migration}),{migration});}finally{migration.release();}
  assert.equal(result.state,'COMPLETE');assert.deepEqual(fs.readFileSync(sent),priorSent);assert.equal(verifyPackage(target).version,VERSION);
  for(const k of checks)assert.equal(treeDigest(path.join(target,k)),prior[k],k);
  const rolled=restoreSoftware(journals(target)[0]);assert.equal(rolled.state,'ROLLED_BACK');assert.deepEqual(fs.readFileSync(sent),priorSent);
  assert.equal(verifyPrevious(target).version,'0.8.1-rc.53');
  for(const k of checks)assert.equal(treeDigest(path.join(target,k)),prior[k],k+' rollback');
 }finally{fs.rmSync(parent,{recursive:true,force:true,maxRetries:6,retryDelay:100});}
});
