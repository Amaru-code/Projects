import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {phase2Journal,digestDescription} from '../lib/phase2-write-journal.mjs';
const names=['11368989_Kontoauszug_PP+.pdf','11368989_Kontoauszug_DC.pdf'];
const artifacts=[{plan:'PP+',name:names[0],sha256:'a'.repeat(64)}, {plan:'DC',name:names[1],sha256:'b'.repeat(64)}];
function fixture(fn){const root=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-P2-JOURNAL-RC48-'));
 try{const initial={ticketId:'87278094',descriptionSha256:digestDescription('Original-3-Zeilen'),pdfHashes:artifacts.map(({plan,sha256})=>({plan,sha256}))};
  const j=phase2Journal(root,initial.ticketId,{initial});j.begin();j.advance('GEVO_INTENT');
  j.approveGevoFocusRetry({...initial,operatorConfirmed:true,ticketUnchanged:true,noAttachments:true});j.advance('UPLOAD_INTENT');
  return fn({j,initial});
 }finally{fs.rmSync(root,{recursive:true,force:true});}}
const approval=i=>({...i,operatorConfirmed:true,ticketUnchanged:true,noSaveOrForward:true,existingPlans:[],missingPlans:['PP+','DC']});
test('RC48 RC44->RC47 exact journal may be reviewed AGAIN after the RC47 unbound selection, never replayed automatically',()=>fixture(({j,initial})=>{
 // RC44 interrupted immediately after PP+ native chooser.
 j.recordUploadFileIntent(artifacts[0]);
 assert.equal(j.mayReconcileUpload(initial),true);
 j.approveUploadReconciliation(approval(initial));
 assert.equal(j.read().uploadRecoveryCount,1);
 assert.equal(j.mayReconcileUpload(initial),false,'A new approval without a new selection must fail');
 // RC47 repeated native PP+ file chooser, then stopped at UNBOUND_NAME.
 j.recordUploadFileIntent(artifacts[0]);
 assert.equal(j.mayReconcileUpload(initial),true,'Current user report must be resumable with fresh checks');
 assert.throws(()=>j.approveUploadReconciliation({...approval(initial),operatorConfirmed:false}),e=>e.code==='P2_UPLOAD_RECOVERY_BLOCKED');
 j.approveUploadReconciliation(approval(initial));
 assert.equal(j.read().uploadRecoveryCount,2);
 assert.equal(j.mayReconcileUpload(initial),false);
 // RC48: two DIFFERENT native file choosers; no fake STAGED proof.
 j.recordUploadFileIntent(artifacts[0]);j.recordUploadFileProvisional(artifacts[0]);
 j.recordUploadFileIntent(artifacts[1]);j.recordUploadFileProvisional(artifacts[1]);
 assert.deepEqual(j.read().events.slice(-4).map(e=>e.state),
  ['UPLOAD_FILE_INTENT','UPLOAD_FILE_PROVISIONAL','UPLOAD_FILE_INTENT','UPLOAD_FILE_PROVISIONAL']);
 assert.throws(()=>j.recordUploadVisualReview({names:['not-a-pdf']}),e=>e.code==='P2_UPLOAD_VISUAL_JOURNAL');
 j.recordUploadVisualReview({names});
 const before=j.read();assert.equal(before.events.at(-1).serverUploadVerified,false);
 j.advance('UPLOAD_VERIFIED');assert.equal(j.mayReconcileUpload(initial),false);
 assert.throws(()=>j.recordUploadFileIntent(artifacts[0]),e=>e.code==='P2_UPLOAD_FILE_INTENT');
}));
test('RC48 no new review without new selected file, and no false post-save proof',()=>fixture(({j,initial})=>{
 assert.throws(()=>j.recordUploadFileProvisional(artifacts[0]),e=>e.code==='P2_UPLOAD_PROVISIONAL_JOURNAL');
 assert.throws(()=>j.recordPostSaveAttachmentReview({names}),e=>e.code==='P2_POST_SAVE_REVIEW_JOURNAL');
 j.recordUploadFileIntent(artifacts[0]);
 assert.throws(()=>j.recordUploadVisualReview({names}),e=>e.code==='P2_UPLOAD_VISUAL_JOURNAL');
 j.approveUploadReconciliation(approval(initial));
 assert.equal(j.mayReconcileUpload(initial),false);
}));
test('RC48 original ordinary READY staging remains unchanged',()=>fixture(({j,initial})=>{
 j.recordUploadFileIntent(artifacts[0]);j.recordUploadFileStaged({...artifacts[0],source:'FILEPOND'});
 j.recordUploadFileIntent(artifacts[1]);j.recordUploadFileStaged({...artifacts[1],source:'ATTACHMENT_ROW'});
 j.advance('UPLOAD_VERIFIED');assert.equal(j.read().uploadRecoveryCount,undefined);
 assert.equal(j.read().events.filter(e=>e.state==='UPLOAD_FILE_STAGED').length,2);
 assert.equal(j.mayReconcileUpload(initial),false);
}));
