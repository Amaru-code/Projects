import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';
import {temp} from './helpers.mjs';
import {phase2Journal} from '../lib/phase2-write-journal.mjs';
const init={ticketId:'87278094',descriptionSha256:'a'.repeat(64),pdfHashes:[{plan:'DC',sha256:'b'.repeat(64)},{plan:'PP+',sha256:'c'.repeat(64)}]};
function pending(){const dir=temp(),journal=phase2Journal(dir,init.ticketId,{initial:init});journal.begin();
 for(const s of ['UPLOAD_INTENT','UPLOAD_VERIFIED','GEVO_INTENT','GEVO_VERIFIED','DESCRIPTION_INTENT','DESCRIPTION_VERIFIED',
 'DRAFT_SAVE_INTENT','DRAFT_SAVE_VERIFIED','TICKET_SAVE_INTENT'])journal.advance(s);
 return {dir,journal,clean:()=>fs.rmSync(dir,{recursive:true,force:true})};}
test('RC49 exact pending RC48 save intent is qualified once and does not reset history',()=>{
 const f=pending();try{const before=f.journal.read();assert.equal(before.state,'TICKET_SAVE_INTENT');
 assert.equal(f.journal.mayRecoverTicketSave(init),true);
 assert.equal(f.journal.mayRecoverTicketSave({...init,pdfHashes:[{plan:'DC',sha256:'d'.repeat(64)}]}),false);
 assert.throws(()=>f.journal.approveTicketSaveRecovery({...init,operatorConfirmed:true,noPriorClick:true,ticketUnchanged:true,
  attachmentsReviewed:false,notForwarded:true}),e=>e.code==='P2_SAVE_RECOVERY_BLOCKED');
 assert.deepEqual(f.journal.read(),before,'Declined recovery mutates nothing');
 f.journal.approveTicketSaveRecovery({...init,operatorConfirmed:true,noPriorClick:true,ticketUnchanged:true,
  attachmentsReviewed:true,notForwarded:true});
 assert.equal(f.journal.mayRecoverTicketSave(init),false,'Cannot re-authorize an unknown pending click');
 assert.equal(f.journal.read().ticketSaveRecoveryCount,1);
 f.journal.recordTicketSaveManualIntent();assert.throws(()=>f.journal.recordTicketSaveManualIntent(),e=>e.code==='P2_SAVE_MANUAL_REPLAY');
 f.journal.advance('TICKET_SAVE_VERIFIED');assert.equal(f.journal.read().state,'TICKET_SAVE_VERIFIED');
 assert.equal(f.journal.mayRecoverTicketSave(init),false);
 assert.equal(f.journal.read().events.filter(x=>x.state==='TICKET_SAVE_INTENT').length,1);
 }finally{f.clean();}
});
test('RC49 cannot treat save/forward intent as an upload replay and never repeats review click',()=>{
 const f=pending();try{assert.equal(f.journal.mayReconcileUpload(init),false);
 f.journal.advance('TICKET_SAVE_VERIFIED');f.journal.advance('REVIEW_INTENT');f.journal.advance('REVIEW_VERIFIED');
 f.journal.advance('EXECUTE_INTENT');f.journal.recordReviewExecuteManualIntent();
 assert.throws(()=>f.journal.recordReviewExecuteManualIntent(),e=>e.code==='P2_REVIEW_MANUAL_REPLAY');
 assert.equal(f.journal.mayRecoverTicketSave(init),false);
 }finally{f.clean();}
});
test('RC49 forged duplicate save-state events and a missing draft stage deny recovery',()=>{
 const f=pending();try{const v=f.journal.read();v.events.splice(v.events.findIndex(x=>x.state==='DRAFT_SAVE_VERIFIED'),1);
 fs.writeFileSync(f.journal.file,JSON.stringify(v));assert.equal(f.journal.mayRecoverTicketSave(init),false);
 }finally{f.clean();}
});

import {phase2Inventory} from '../lib/phase2-readonly.mjs';
import {restorePendingSaveCandidate} from '../src/phase2-comarch-pilot.mjs';
import {digestDescription} from '../lib/phase2-write-journal.mjs';
test('RC49 a draft-persisted marker is recoverable only with original description hash',()=>{
 const original='USC 100/ DC;PP+\nmoechte einen Kontoauszug\nStandardantwort versendet';
 const stamped=original+'\nBearbeitet not reviewed';
 const item=phase2Inventory([{ticketId:init.ticketId,source:'E-MAIL',descriptionValue:stamped}]).items[0];
 assert.equal(item.kind,'ALREADY_PREPARED');assert.equal(item.descriptionValue,stamped);
 const old={state:'TICKET_SAVE_INTENT',descriptionSha256:digestDescription(original)};
 const restored=restorePendingSaveCandidate(item,old);
 assert.equal(restored.kind,'NEEDS_VERIFIED_WWID');assert.deepEqual(restored.targets,['DC','PP+']);
 assert.equal(restored.descriptionValue,original);assert.equal(restored.preexistingSavedMarker,true);
 assert.equal(restorePendingSaveCandidate(item,{state:'REVIEW_INTENT',descriptionSha256:old.descriptionSha256}),item);
 assert.throws(()=>restorePendingSaveCandidate(item,{...old,descriptionSha256:'f'.repeat(64)}),e=>e.code==='P2_SAVE_RECOVERY_DESCRIPTION_HASH');
 const bad={...item,descriptionValue:stamped+'\nBearbeitet not reviewed'};
 assert.throws(()=>restorePendingSaveCandidate(bad,old),e=>e.code==='P2_SAVE_RECOVERY_MARKER');
});
