import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';import {execFileSync} from 'node:child_process';
import {ROOT} from './helpers.mjs';import {VERSION} from '../lib/control.mjs';import {sha256} from '../lib/core.mjs';import {verifyPackage} from '../tools/integrity.mjs';
const read=f=>fs.readFileSync(path.join(ROOT,f),'utf8');
test('RC54 pins original RC53 and preserves file upload, migration, installer, Phase1 runner and its panel byte for byte',()=>{
 assert.equal(VERSION,'0.8.1-rc.54');const text=read('tools/reference/complete-0.8.1-rc.53-manifest.json');assert.equal(sha256(text),'5f0a21e1717206c19fa139780e92900d71e3ef35ac05996aa9789818aa2a2806');
 const prior=JSON.parse(text);for(const f of ['lib/phase2-filepond.mjs','tools/deploy.mjs','lib/migration-priority.mjs','src/local-bot-full-run.mjs','tools/delivery-window.ps1'])assert.equal(sha256(fs.readFileSync(path.join(ROOT,f))),prior.payload.find(x=>x.path===f).sha256,f);
 assert.equal(verifyPackage(ROOT).version,VERSION);
});
test('RC54 per-ticket Windows card has independent noninteractive ghosts, five-second smooth movement and fade; next card is reset',()=>{
 const s=read('tools/phase2-ticket-window.ps1');
 for(const x of ['class McrTicketGhost','startY=work.Bottom-Height-16','endY=work.Top+16','/5000.0','3*t*t-2*t*t*t','Opacity=Math.Max(0,1-ease)','MakeTransparentToMouse()',"'ticket_start'","'ticket_complete'",'McrPipeReader','ShowWithoutActivation'])assert(s.includes(x),x);
 assert(s.includes("$values[$key].Text='-'"));assert(s.includes('$script:ghosts.Count -eq 0'));
 assert(!/Invoke-WebRequest|HttpClient|Set-Content|WriteAllText|SendKeys/i.test(s));
 const run=read('src/phase2-run.mjs');for(const x of ['createPhase2TicketConsole','controls.start','controls.complete','controls.protectInput','controls?.close()'])assert(run.includes(x));
 const flow=read('lib/phase2-review-flow.mjs');assert(flow.indexOf('controls.authorize')<flow.indexOf("journal.advance('EXECUTE_INTENT')"));assert(flow.includes('controls.verifyRoute'));
 const completion=read('src/phase1-completion-only.mjs');assert(completion.includes('openPhase2Ticket(page,row,{scope,log})'));assert(!/sendOnce\(|writeEditor\(|executeReview\(|attachLocalFiles\(/.test(completion));
});
test('RC54 native Windows parser accepts the Phase2 ticket-card script',{skip:process.platform!=='win32'},()=>{
 const ps=path.join(process.env.SystemRoot||'C:\\Windows','System32/WindowsPowerShell/v1.0/powershell.exe');
 execFileSync(ps,['-NoProfile','-NonInteractive','-Command','$t=$null;$e=$null;[void][System.Management.Automation.Language.Parser]::ParseFile($env:MCR_TEST_PARSE_SCRIPT,[ref]$t,[ref]$e);if($e.Count -gt 0){$e|Out-String|Write-Error;exit 1}'],{env:{...process.env,MCR_TEST_PARSE_SCRIPT:path.join(ROOT,'tools/phase2-ticket-window.ps1')},timeout:15000,windowsHide:true});
});
test('RC54 native Windows compiles the independent moving/fading card and controller without executing a live ticket',{skip:process.platform!=='win32'},()=>{
 const cs=read('tools/phase2-ticket-window.ps1').split("@'\n")[1].split("\n'@")[0];assert(cs.includes('class McrTicketGhost'));
 const ps=path.join(process.env.SystemRoot||'C:\\Windows','System32/WindowsPowerShell/v1.0/powershell.exe');
 execFileSync(ps,['-NoProfile','-NonInteractive','-Command',"$ErrorActionPreference='Stop';Add-Type -AssemblyName System.Windows.Forms;Add-Type -AssemblyName System.Drawing;Add-Type -ReferencedAssemblies System.Windows.Forms,System.Drawing -TypeDefinition $env:MCR_TEST_CSHARP;if(-not ('McrTicketGhost' -as [type])){exit 1}"],{env:{...process.env,MCR_TEST_CSHARP:cs},timeout:30000,windowsHide:true});
});
