/** RC48 reproduces the EXACT RC47 live log: after native PP+ selection the
 * name appears once in an unbound DOM span, not in FilePond nor an attachment
 * row. The bot must open a fresh chooser for DC before asking for an operator
 * attachment review. This is Chromium CDP, not an in-memory DOM model. */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
import {attachPhase2Files,phase2AttachmentEvidence,phase2ReviewableAttachmentEvidence} from '../lib/phase2-filepond.mjs';
const names=['11368989_Kontoauszug_PP+.pdf','11368989_Kontoauszug_DC.pdf'];
async function fixture(fn,{mode='normal'}={}){
 const base=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC48-UNBOUND-'));
 const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-P2-DOM-RC48-'));
 let browser,cdp;
 try{
  const files=names.map(n=>path.join(base,n));
  files.forEach(f=>fs.writeFileSync(f,'%PDF-1.4\n'+('1'.repeat(180))+'\n%%EOF'));
  browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,
   extraArgs:['--disable-background-networking','--disable-sync',...(process.platform!=='win32'&&process.getuid?.()===0?['--no-sandbox']:[])]});
  ({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.url==='about:blank');
  await page.call(function(mode,names){
   document.body.innerHTML='<div class="filepond--root" style="width:420px;height:20px">Unrelated COMARCH widget</div><button id="opener">Dokument anhängen</button><div id="surf"></div><div id="file-display"></div>';
   window.rc48={chosen:[],open:0,trusted:[],sent:0};
   if(mode==='preexisting-mail'){
    const mail=document.createElement('div');mail.id='email-body';mail.innerHTML='<span></span>';
    mail.firstChild.textContent=names[0];document.body.append(mail);
   }
   const show=()=>{
    window.rc48.open++;
    const n=window.rc48.open,id='filepond--browser-'+n;
    const root=document.createElement('div');root.className='filepond--root';
    const input=document.createElement('input');input.id=id;input.type='file';input.style.cssText='width:1px;height:1px;opacity:0;position:absolute';
    const label=document.createElement('label');label.id='filepond--drop-label-'+n;label.htmlFor=id;
    label.textContent='Dateien hierher ziehen oder zum Auswählen klicken';
    label.style.cssText='display:block;width:400px;height:55px;margin:30px';
    label.addEventListener('click',ev=>window.rc48.trusted.push(ev.isTrusted));
    input.addEventListener('change',()=>{
     for(const file of input.files){window.rc48.chosen.push(file.name);
      const span=document.createElement('span');span.className='comarch-unbound-text';span.textContent=file.name;
      document.getElementById('file-display').append(span);
      if(mode==='duplicate-unbound'){
       const extra=document.createElement('span');extra.textContent=file.name;
       document.getElementById('file-display').append(extra);
      }
     }
     root.remove();document.getElementById('opener').hidden=false;
    });
    root.append(input,label);document.getElementById('surf').append(root);
    document.getElementById('opener').hidden=true;
   };
   document.getElementById('opener').addEventListener('click',ev=>{if(ev.isTrusted)show();});show();
  },mode,names);
  return await fn({page,files});
 }finally{try{await cleanupTemporaryTestBrowser({profile,browser,cdp});}
  finally{fs.rmSync(base,{recursive:true,force:true});}}
}
test('RC48 Chromium live incident: PP+ unbound, fresh chooser for DC, neither falsely staged', {timeout:60000},()=>fixture(async({page,files})=>{
 const before=await phase2AttachmentEvidence(page,names);
 assert.equal(before.rootCount,2);assert.deepEqual(before.items.map(i=>i.status),['ABSENT','ABSENT']);
 const transitions=[];
 const result=await attachPhase2Files(page,files,{
  beforeSelect:async({name})=>transitions.push('INTENT:'+name),
  afterStaged:()=>assert.fail('unbound text is not a verified staged attachment'),
  afterProvisional:async({name,evidence})=>{assert.equal(evidence.items[0].status,'UNBOUND_NAME');transitions.push('PROVISIONAL:'+name);}
 });
 assert.deepEqual(await page.eval('window.rc48.chosen'),names);
 assert.equal(await page.eval('window.rc48.open'),2);
 assert.deepEqual(await page.eval('window.rc48.trusted'),[true,true]);
 assert.deepEqual(result.provisionalNames,names);
 assert.equal(result.evidence.allReady,false);
 assert.equal(phase2ReviewableAttachmentEvidence(result.evidence,names),true);
 assert.deepEqual(transitions,names.flatMap(n=>['INTENT:'+n,'PROVISIONAL:'+n]));
 assert.equal(await page.eval('window.rc48.sent'),0);
}));
test('RC48 Chromium preexisting unbound name blocks upload before any chooser', {timeout:35000},()=>fixture(async({page,files})=>{
 await assert.rejects(()=>attachPhase2Files(page,files),e=>e.code==='P2_ATTACHMENT_ALREADY_PRESENT');
 assert.deepEqual(await page.eval('window.rc48.chosen'),[]);
 assert.equal(await page.eval('window.rc48.open'),1);
},{mode:'preexisting-mail'}));
test('RC48 Chromium duplicate unbound name blocks second chooser', {timeout:35000},()=>fixture(async({page,files})=>{
 await assert.rejects(()=>attachPhase2Files(page,files),e=>e.code==='P2_FILEPOND_UNBOUND_DUPLICATE');
 assert.deepEqual(await page.eval('window.rc48.chosen'),[names[0]]);
 assert.equal(await page.eval('window.rc48.open'),1);
},{mode:'duplicate-unbound'}));
test('RC48 manual visual review gate never accepts absent, hidden or duplicate attachment evidence',()=>{
 const name=names[0],ok={name,present:true,ready:false,status:'UNBOUND_NAME',source:'UNBOUND_VISIBLE_TEXT',count:0,hiddenCount:0,unboundCount:1};
 assert.equal(phase2ReviewableAttachmentEvidence({items:[ok]},[name]),true);
 for(const changed of [{status:'ABSENT',present:false,unboundCount:0},{status:'DUPLICATE',count:2},{hiddenCount:1},{unboundCount:2},{ready:true},{status:'ERROR'}])
  assert.equal(phase2ReviewableAttachmentEvidence({items:[{...ok,...changed}]},[name]),false);
});
