/** RC46: crash recovery must release preparation without weakening proof of
 * stopped processes or changing an unresolved SEND_INTENT/UPLOAD_INTENT. */
import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';
import {temp} from './helpers.mjs';
import {controlDir,ledger,readJSON,writeJSON} from '../lib/control.mjs';
import {archiveStoppedOperationLock,recoverOrphanedMigrationPriority} from '../lib/migration-priority.mjs';
import {sha256} from '../lib/core.mjs';import {treeDigest} from '../tools/integrity.mjs';

const AT='2026-10-25T12:00:00.000Z',OWNER=999999981;
const priorityName='migration-priority.json',barrierName='BETA_UMSTELLUNG_LAEUFT.txt';
const markerText=r=>'MCR_MIGRATION_PRIORITY_V1\nOwner='+r.pid+'\nToken='+r.token+
 '\nNeustart aus dem neuen Paket: Menue 1. Bei offener Softwareumstellung: Menue 7.\n';
const proof=(processes=[])=>({schema:'MCR_PROCESS_GUARD_V1',checked:true,blockedCount:0,unknownCount:0,
 inspectedPids:processes.map(p=>p.pid),inspectedProcesses:processes});
function fixture(t){
 const parent=temp(),target=path.join(parent,'MCR_Datenbruecke');fs.mkdirSync(target);
 const dir=controlDir(target),phase1=ledger(target);phase1.begin('87422280','Preserve unresolved send');
 const phase2=path.join(target,'.runtime','phase2','actions','MCR_PHASE2_87278094.json');
 fs.mkdirSync(path.dirname(phase2),{recursive:true});
 writeJSON(phase2,{schema:'MCR_PHASE2_ACTION_JOURNAL_V1',ticketId:'87278094',state:'UPLOAD_INTENT',
  events:[{state:'PREPARED'},{state:'UPLOAD_INTENT'}]});
 const protectedFiles=[phase1.file,phase2],before=protectedFiles.map(f=>fs.readFileSync(f));
 t.after(()=>fs.rmSync(parent,{recursive:true,force:true,maxRetries:5,retryDelay:100}));
 return {parent,target,dir,priority:path.join(dir,priorityName),marker:path.join(target,barrierName),
  lock:path.join(dir,'operation.lock.json'),
  unchanged(){protectedFiles.forEach((file,i)=>assert.deepEqual(fs.readFileSync(file),before[i],file));
   assert.equal(ledger(target).pending.length,1);assert.equal(readJSON(phase2).state,'UPLOAD_INTENT');}};
}
function reserve(f,{phase='PREPARING',marker=true,operation=null}={}){
 const record={schema:'MCR_MIGRATION_PRIORITY_V1',target:f.target,source:path.join(f.parent,'new-release'),
  pid:OWNER,token:'a'.repeat(48),phase,createdAt:AT,sourceVersion:'0.8.1-rc.46',sourceManifestSha256:'b'.repeat(64)};
 if(operation){
  const old={schema:'MCR_OPERATION_LOCK_V1',operation,pid:operation==='MIGRATION'?OWNER:OWNER-1,
   token:'c'.repeat(48),createdAt:operation==='MIGRATION'?'2026-10-25T12:00:00.100Z':'2026-10-25T11:00:00.000Z'};
  writeJSON(f.lock,old);if(operation==='MIGRATION')record.operationLockToken=old.token;
 }
 writeJSON(f.priority,record);if(marker)fs.writeFileSync(f.marker,markerText(record));return record;
}
function finishedFixture(f,state,{reservationPhase=state,marker=true,operation='MIGRATION'}={}){
 const record=reserve(f,{phase:reservationPhase,marker,operation});
 fs.writeFileSync(path.join(f.target,'START.cmd'),state==='COMPLETE'?'@echo RC46 installed\r\n':'@echo Original software restored\r\n');
 fs.writeFileSync(path.join(f.target,'MANIFEST.json'),JSON.stringify({fixture:true,state})+'\n');
 const records=['START.cmd','MANIFEST.json'].map(name=>({name,hash:treeDigest(path.join(f.target,name))}));
 const archive=path.join(f.parent,'_MCR_Archiv','complete_2026-10-25T12-00-00-000Z_0123abcd');fs.mkdirSync(archive,{recursive:true});
 const journal={schema:'MCR_COMPLETE_INSTALL_JOURNAL_V1',archive,target:f.target,source:record.source,
  migrationToken:record.token,state,incoming:records,oldItems:records,createdAt:AT};
 writeJSON(path.join(archive,'migration.json'),journal);
 writeJSON(f.priority,{...record,archive,sourceManifestSha256:sha256(fs.readFileSync(path.join(f.target,'MANIFEST.json')))});
 return {journal,record:readJSON(f.priority)};
}

for(const stage of [
 {name:'before writing the legacy marker',marker:false,operation:null},
 {name:'before archiving a stopped REAL_RUN lock',marker:true,operation:'REAL_RUN'},
 {name:'before archiving a stopped Phase-2 lock',marker:true,operation:'PHASE2_COMARCH_PILOT'},
 {name:'after acquiring its own migration lock',marker:true,operation:'MIGRATION'}
])test('RC46 rollback-menu recovery of PREPARING '+stage.name+' clears preparation and preserves ticket intents',t=>{
 const f=fixture(t);reserve(f,stage);const oldLock=fs.existsSync(f.lock)?fs.readFileSync(f.lock):null,order=[];
 const recovered=recoverOrphanedMigrationPriority(f.target,{forRollback:true,isAlive:()=>false,
  verifyOld:root=>{assert.equal(root,f.target);order.push('verify-old');},
  stop:root=>{assert.equal(root,f.target);order.push('stop-owned');return proof();}});
 assert.equal(recovered.released,true);assert.deepEqual(order,['verify-old','stop-owned']);
 assert.equal(fs.existsSync(f.priority),false);assert.equal(fs.existsSync(f.marker),false);
 if(stage.operation&&stage.operation!=='MIGRATION')assert.deepEqual(fs.readFileSync(f.lock),oldLock);
 else assert.equal(fs.existsSync(f.lock),false);
 f.unchanged();
});

test('RC46 PREPARING via rollback menu keeps reservation intact when the original software cannot verify',t=>{
 const f=fixture(t);reserve(f,{operation:'REAL_RUN'});
 const protectedFiles=[f.priority,f.marker,f.lock],before=protectedFiles.map(file=>fs.readFileSync(file));let stops=0;
 assert.throws(()=>recoverOrphanedMigrationPriority(f.target,{forRollback:true,isAlive:()=>false,
  verifyOld:()=>{throw Object.assign(new Error('Original package changed'),{code:'PACKAGE_HASH'});},
  stop:()=>{stops++;return proof();}}),{code:'PACKAGE_HASH'});
 assert.equal(stops,0);protectedFiles.forEach((file,i)=>assert.deepEqual(fs.readFileSync(file),before[i]));f.unchanged();
});

test('RC46 a readable unrelated classification cannot release a live lock owner started with a relative Node entry',t=>{
 const f=fixture(t),old={schema:'MCR_OPERATION_LOCK_V1',operation:'REAL_RUN',pid:OWNER-1,
  token:'d'.repeat(48),createdAt:AT};writeJSON(f.lock,old);const before=fs.readFileSync(f.lock);
 // `npm start` uses `node tools/cli.mjs`: a readable command line alone does
 // not establish its working directory or prove that the lock owner exited.
 const active=proof([{pid:old.pid,parentPid:17,name:'node.exe',createdAt:'2026-10-25T11:59:59.000Z',
  relation:'UNRELATED',identityReadable:true,ownershipDecidable:false}]);
 assert.throws(()=>archiveStoppedOperationLock(f.target,{proof:active,guard:()=>active}),{code:'MIGRATION_LOCK_OWNER_ACTIVE'});
 assert.deepEqual(fs.readFileSync(f.lock),before);f.unchanged();
});

test('RC46 proven PID reuse can archive an obsolete lock without touching ticket intents',t=>{
 const f=fixture(t),old={schema:'MCR_OPERATION_LOCK_V1',operation:'PHASE2_MANUAL_PDF',pid:OWNER-1,
  token:'e'.repeat(48),createdAt:AT};writeJSON(f.lock,old);const before=fs.readFileSync(f.lock);
 const reused=proof([{pid:old.pid,parentPid:17,name:'node.exe',createdAt:'2026-10-25T12:00:01.000Z',
  relation:'UNRELATED',identityReadable:true,ownershipDecidable:true}]);
 const result=archiveStoppedOperationLock(f.target,{proof:reused,guard:()=>reused});
 assert.equal(result.released,true);assert.equal(fs.existsSync(f.lock),false);
 const receipt=readJSON(result.receipt);assert.equal(receipt.originalBytesBase64,before.toString('base64'));f.unchanged();
});

for(const createdAt of ['2026-10-25T11:59:59.000Z',AT])
 test('RC46 a living external installer with creation time '+createdAt+' blocks recovery before any stop',t=>{
  const f=fixture(t);reserve(f,{operation:'MIGRATION'});const files=[f.priority,f.marker,f.lock],before=files.map(file=>fs.readFileSync(file)),order=[];
  const observed=proof([{pid:OWNER,parentPid:17,name:'node.exe',createdAt,relation:'UNRELATED',identityReadable:true,ownershipDecidable:true}]);
  assert.throws(()=>recoverOrphanedMigrationPriority(f.target,{isAlive:()=>true,
   guard:()=>{order.push('read-only');return observed;},verifyOld:()=>{order.push('verify-software');},
   stop:()=>{order.push('stop-owned');return proof();}}),{code:'MIGRATION_ALREADY_ACTIVE'});
  assert.deepEqual(order,['read-only']);files.forEach((file,i)=>assert.deepEqual(fs.readFileSync(file),before[i]));f.unchanged();
 });

for(const relation of ['UNRELATED','PROTECTED'])
 test('RC46 migration reservation accepts independently proven PID reuse by a '+relation+' process after a read-only check',t=>{
  const f=fixture(t);reserve(f,{operation:'MIGRATION'});const order=[];
  const reused={pid:OWNER,parentPid:17,name:'node.exe',createdAt:'2026-10-25T12:00:01.000Z',relation,identityReadable:true,ownershipDecidable:true};
  const recovered=recoverOrphanedMigrationPriority(f.target,{isAlive:()=>true,
   guard:root=>{
    assert.equal(root,f.target);order.push('read-only');
    if(relation==='UNRELATED')return proof([reused]);
    // A target bot can still be running while the old migration PID belongs
    // to the new, protected installer. Its full snapshot must remain usable.
    const observed={...proof([reused,{pid:OWNER-2,parentPid:17,name:'node.exe',createdAt:AT,relation:'OWNED'}]),blockedCount:1};
    throw Object.assign(new Error('Target bot still running'),{code:'MCR_PROCESSES_ACTIVE',processProof:observed});
   },verifyOld:()=>{order.push('verify-software');},
   stop:()=>{order.push('stop-owned');return proof([reused]);}});
  assert.equal(recovered.released,true);assert.deepEqual(order,['read-only','verify-software','stop-owned']);
  assert.equal(fs.existsSync(f.priority),false);assert.equal(fs.existsSync(f.marker),false);assert.equal(fs.existsSync(f.lock),false);f.unchanged();
 });

for(const state of ['COMPLETE','ROLLED_BACK'])for(const stage of [
 {name:'before releasing either migration barrier',marker:true,operation:'MIGRATION'},
 {name:'after releasing the operation lock',marker:true,operation:null},
 {name:'after removing the legacy marker but before removing priority',marker:false,operation:null}
])test('RC46 '+state+' crash '+stage.name+' is recoverable with verified software',t=>{
 const f=fixture(t);finishedFixture(f,state,stage);const order=[];
 const recovered=recoverOrphanedMigrationPriority(f.target,{forRollback:state==='ROLLED_BACK',isAlive:()=>false,
  verifyOld:root=>{assert.equal(root,f.target);order.push('verify-software');},
  stop:()=>{order.push('stop-owned');return proof();}});
 assert.equal(recovered.released,true);assert.deepEqual(order,['verify-software','stop-owned']);
 assert.equal(fs.existsSync(f.priority),false);assert.equal(fs.existsSync(f.marker),false);assert.equal(fs.existsSync(f.lock),false);
 assert.equal(readJSON(recovered.receipt).action,'RELEASE_VERIFIED_COMPLETION');f.unchanged();
});

for(const state of ['COMPLETE','ROLLED_BACK'])test('RC46 crash after saving '+state+' journal and before updating MOVING priority is recoverable',t=>{
 const f=fixture(t);finishedFixture(f,state,{reservationPhase:'MOVING'});const before=fs.readFileSync(f.priority);let checks=0;
 const recovered=recoverOrphanedMigrationPriority(f.target,{forRollback:state==='ROLLED_BACK',isAlive:()=>false,
  verifyOld:()=>{checks++;},stop:()=>proof()});
 assert.equal(recovered.released,true);assert.equal(checks,1);
 assert.equal(fs.existsSync(f.priority),false);assert.equal(fs.existsSync(f.marker),false);assert.equal(fs.existsSync(f.lock),false);
 const receipt=readJSON(recovered.receipt);assert.equal(receipt.action,'RELEASE_VERIFIED_COMPLETION');
 assert.equal(receipt.originalPriorityBytesBase64,before.toString('base64'));f.unchanged();
});

for(const invalid of ['changed installed software','different migration token','contradictory terminal journal'])
 test('RC46 completed reservation stays blocked with '+invalid,t=>{
  const f=fixture(t),{journal}=finishedFixture(f,'COMPLETE',{marker:false});
  if(invalid==='changed installed software')fs.appendFileSync(path.join(f.target,'START.cmd'),'echo modified\r\n');
  else{if(invalid==='different migration token')journal.migrationToken='f'.repeat(48);else journal.state='ROLLED_BACK';
   writeJSON(path.join(journal.archive,'migration.json'),journal);}
  const before=fs.readFileSync(f.priority);let stops=0;
  assert.throws(()=>recoverOrphanedMigrationPriority(f.target,{isAlive:()=>false,verifyOld:()=>{},
   stop:()=>{stops++;return proof();}}),e=>['MIGRATION_COMPLETION_CHANGED','MIGRATION_JOURNAL_INVALID'].includes(e.code));
  assert.equal(stops,0);assert.deepEqual(fs.readFileSync(f.priority),before);assert.equal(fs.existsSync(f.lock),true);f.unchanged();
 });
