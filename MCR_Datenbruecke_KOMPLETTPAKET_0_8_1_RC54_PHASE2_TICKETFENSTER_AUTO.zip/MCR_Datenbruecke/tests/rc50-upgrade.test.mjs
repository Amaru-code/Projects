/** RC50: exact published RC49 upgrade/rollback, no modifications to business data.
 * Fixture is retained only externally by QA, never shipped inside release. */
import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';
import {ROOT,temp,putActive,historyFixture} from './helpers.mjs';
import {sha256} from '../lib/core.mjs';import {readZip} from '../lib/zip.mjs';
import {VERSION,ledger,writeJSON} from '../lib/control.mjs';
import {verifyPrevious,verifyPackage,treeDigest} from '../tools/integrity.mjs';
import {planInstall,installSoftware,journals,restoreSoftware} from '../tools/deploy.mjs';
import {beginMigrationPriority} from '../lib/migration-priority.mjs';
const SHA='469fe623e620e3cebe0463e2811dd13984bec9e3de8a036aee2504248f4a57b7';
const name='complete-0.8.1-rc.49.zip';
test('RC50 exact RC49 original ZIP upgrades and rollbacks while preserving unresolved ticket journals',{timeout:120000},()=>{
 const zip=historyFixture(name);assert.equal(sha256(zip),SHA);
 const parent=temp(),target=path.join(parent,'MCR_Datenbruecke');fs.mkdirSync(target);
 try{
  const data=readZip(zip);
  for(const name of data.names){assert(name.startsWith('MCR_Datenbruecke/'));
   const file=path.join(target,name.slice('MCR_Datenbruecke/'.length));fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,data.get(name));}
  putActive(target);
  const p=path.join(target,'.runtime/phase2/actions/MCR_PHASE2_87278094.json');fs.mkdirSync(path.dirname(p),{recursive:true});
  writeJSON(p,{schema:'MCR_PHASE2_ACTION_JOURNAL_V1',ticketId:'87278094',state:'TICKET_SAVE_INTENT',
   descriptionSha256:'a'.repeat(64),pdfHashes:[{plan:'DC',sha256:'b'.repeat(64)},{plan:'PP+',sha256:'c'.repeat(64)}],
   events:['PREPARED','UPLOAD_INTENT','UPLOAD_VERIFIED','GEVO_INTENT','GEVO_VERIFIED','DESCRIPTION_INTENT','DESCRIPTION_VERIFIED','DRAFT_SAVE_INTENT','DRAFT_SAVE_VERIFIED','TICKET_SAVE_INTENT'].map(state=>({state}))});
  const prof=path.join(target,'.runtime/bot-edge-profile');fs.mkdirSync(prof,{recursive:true});fs.writeFileSync(path.join(prof,'stamp'),'NOT_REPLACE');
  const checks=['private_data','.runtime/phase2','.runtime/bot-edge-profile','config'];
  const before=Object.fromEntries(checks.map(k=>[k,treeDigest(path.join(target,k))]));
  assert.equal(verifyPrevious(target).version,'0.8.1-rc.49');
  const stopper=()=>({schema:'MCR_PROCESS_GUARD_V1',checked:true,blockedCount:0,unknownCount:0,
    inspectedPids:[process.pid],inspectedProcesses:[{pid:process.pid,relation:'PROTECTED'}],stoppedProcesses:[]});
  const migration=beginMigrationPriority(planInstall(ROOT,target),{stop:stopper});let installed;
  try{installed=installSoftware(planInstall(ROOT,target,{migration}),{migration});}finally{migration.release();}
  assert.equal(installed.state,'COMPLETE');assert.equal(verifyPackage(target).version,VERSION);
  for(const k of checks)assert.equal(treeDigest(path.join(target,k)),before[k],k);
  assert.equal(JSON.parse(fs.readFileSync(p)).state,'TICKET_SAVE_INTENT');
  const rev=restoreSoftware(journals(target)[0]);assert.equal(rev.state,'ROLLED_BACK');
  assert.equal(verifyPrevious(target).version,'0.8.1-rc.49');
  for(const k of checks)assert.equal(treeDigest(path.join(target,k)),before[k],k+' rollback');
 }finally{fs.rmSync(parent,{recursive:true,force:true,maxRetries:5,retryDelay:100});}
});
