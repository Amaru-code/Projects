import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';
import {ROOT} from './helpers.mjs';import {sha256} from '../lib/core.mjs';
import {VERSION} from '../lib/control.mjs';import {verifyPackage} from '../tools/integrity.mjs';
test('RC48 pins exact published RC47 manifest and contains unbound chooser regression and journal audit',()=>{
 assert.equal(VERSION,'0.8.1-rc.54');
 const manifest=JSON.parse(fs.readFileSync(path.join(ROOT,'MANIFEST.json')));
 assert.equal(manifest.version,VERSION);
 const reference=fs.readFileSync(path.join(ROOT,'tools/reference/complete-0.8.1-rc.47-manifest.json'));
 assert.equal(sha256(reference),'1fa4c46292743fd9afa7d6ba2b462c50a54443036e5c9cc8085bae59f4fd9bf5');
 assert.equal(JSON.parse(reference).version,'0.8.1-rc.47');
 for(const file of ['tests/rc48-unbound-second-chooser-browser.test.mjs','tests/rc48-upload-journal.test.mjs',
  'tests/rc48-release-contract.test.mjs','tests/rc48-upgrade.test.mjs',
  'docs/RC48_UNBOUND_FILEPOND_UND_WIEDERAUFNAHME.md','lib/phase2-write-journal.mjs','src/phase2-comarch-pilot.mjs',
  'tools/reference/complete-0.8.1-rc.47-manifest.json'])
  assert(manifest.payload.some(r=>r.path===file),'Required release file not sealed: '+file);
 assert(manifest.payload.every(x=>! /^(?:private_data|\.runtime|diagnostics|Ergebnis|reports)\//i.test(x.path)));
 assert.equal(verifyPackage(ROOT).version,VERSION);
});
test('RC48 unbound selected text can never be silently treated as READY or a server-upload proof',()=>{
 const p=fs.readFileSync(path.join(ROOT,'lib/phase2-filepond.mjs'),'utf8');
 const j=fs.readFileSync(path.join(ROOT,'lib/phase2-write-journal.mjs'),'utf8');
 const pilot=fs.readFileSync(path.join(ROOT,'src/phase2-comarch-pilot.mjs'),'utf8');
 assert(p.includes('P2_FILE_SELECTED_UNBOUND_PROVISIONAL'));assert(p.includes('serverUploadVerified:false'));
 assert(j.includes('UPLOAD_FILE_PROVISIONAL'));assert(j.includes('OPERATOR_VISIBLE_NOT_SERVER'));
 assert(pilot.includes('BEIDE_PDFS_SICHTBAR'));assert(pilot.includes('GESPEICHERTE_PDFS_GEPRUEFT'));
});
