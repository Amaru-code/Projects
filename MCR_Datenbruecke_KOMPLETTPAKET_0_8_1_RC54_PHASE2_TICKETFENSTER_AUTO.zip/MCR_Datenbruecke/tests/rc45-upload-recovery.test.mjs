import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {phase2Journal,digestDescription} from '../lib/phase2-write-journal.mjs';
import {planPhase2UploadContinuation} from '../lib/phase2-upload-continuation.mjs';
import {preflightPhase2Write} from '../src/phase2-comarch-pilot.mjs';
import {phase2Inventory} from '../lib/phase2-readonly.mjs';
import {inspectExistingStatements} from '../lib/phase2-pdf-evidence.mjs';
import {writeJSON} from '../lib/control.mjs';

const ID='87278094',WWID='11368989',DESCRIPTION='USC 20/ DC;PP+\nStandardantwort versendet\nMöchte Kontoauszug';
const artifacts=[{plan:'DC',name:WWID+'_Kontoauszug_DC.pdf',sha256:'a'.repeat(64)},
 {plan:'PP+',name:WWID+'_Kontoauszug_PP+.pdf',sha256:'b'.repeat(64)}];
const initial={ticketId:ID,descriptionSha256:digestDescription(DESCRIPTION),pdfHashes:artifacts.map(({plan,sha256})=>({plan,sha256}))};
function evidence(existing=[]){return {items:artifacts.map(a=>({name:a.name,present:existing.includes(a.plan),ready:existing.includes(a.plan),
 status:existing.includes(a.plan)?'READY':'ABSENT',source:existing.includes(a.plan)?'ATTACHMENT_ROW':'NONE',count:existing.includes(a.plan)?1:0})),
 allReady:existing.length===2,rootCount:0,serverUploadVerified:false};}
function fixture(run){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC45-UPLOAD-'));
 try{return run({root,journal:phase2Journal(root,ID,{initial})});}
 finally{fs.rmSync(root,{recursive:true,force:true,maxRetries:5,retryDelay:100});}
}
function interruptedLegacy(journal){
 journal.begin();journal.advance('GEVO_INTENT');
 journal.approveGevoFocusRetry({...initial,operatorConfirmed:true,ticketUnchanged:true,noAttachments:true});
 journal.advance('UPLOAD_INTENT');
}
const approval={...initial,operatorConfirmed:true,ticketUnchanged:true,noSaveOrForward:true,existingPlans:['PP+'],missingPlans:['DC']};

test('RC45 actual incident: retained PP+ yields only DC for upload, inexact names never substitute',()=>{
 const p=planPhase2UploadContinuation({artifacts,evidence:evidence(['PP+']),resumeUpload:true});
 assert.deepEqual(p.existing.map(a=>a.plan),['PP+']);assert.deepEqual(p.missing.map(a=>a.plan),['DC']);
 const wrong=evidence(['PP+']);wrong.items[1].name='99123456_Kontoauszug_PP+.pdf';
 assert.throws(()=>planPhase2UploadContinuation({artifacts,evidence:wrong,resumeUpload:true}),e=>e.code==='P2_UPLOAD_EVIDENCE');
});
test('RC45 both retained PDFs require zero new uploads; absent PDFs remain an explicit reviewed decision',()=>{
 assert.equal(planPhase2UploadContinuation({artifacts,evidence:evidence(['DC','PP+']),resumeUpload:true}).missing.length,0);
 const p=planPhase2UploadContinuation({artifacts,evidence:evidence(),resumeUpload:true});
 assert.deepEqual(p.missing.map(a=>a.plan),['PP+','DC']);assert.equal(p.existing.length,0);
});
test('RC45 fresh run never adopts an existing PDF without the separate interrupted-upload review',()=>{
 assert.throws(()=>planPhase2UploadContinuation({artifacts,evidence:evidence(['PP+'])}),e=>e.code==='P2_ATTACHMENT_ALREADY_PRESENT');
 assert.deepEqual(planPhase2UploadContinuation({artifacts,evidence:evidence()}).missing.map(a=>a.plan),['PP+','DC']);
});
test('RC45 duplicate, pending, erroneous and unbound attachment names cannot become a missing-file retry',()=>{
 for(const status of ['DUPLICATE','PENDING','ERROR','AMBIGUOUS','UNKNOWN_FILEPOND_STATE','UNBOUND_NAME','HIDDEN_UNVERIFIED']){
  const snap=evidence();Object.assign(snap.items[1],{status,present:true,count:status==='DUPLICATE'?2:1});
  assert.throws(()=>planPhase2UploadContinuation({artifacts,evidence:snap,resumeUpload:true}),e=>e.code==='P2_UPLOAD_EVIDENCE_UNCLEAR',status);
 }
});
test('RC45 actual RC44 legacy journal is extended once, keeps original events and blocks PP+ replay',()=>fixture(({journal})=>{
 interruptedLegacy(journal);const original=journal.read();
 assert.equal(journal.mayReconcileUpload(initial),true);assert.equal(journal.mayRetryGevoFocus(initial),false);
 journal.approveUploadReconciliation(approval);
 const approved=journal.read();assert.equal(approved.state,'UPLOAD_INTENT');assert.equal(approved.recoveryCount,1);assert.equal(approved.uploadRecoveryCount,1);
 assert.deepEqual(approved.events.slice(0,original.events.length),original.events);
 assert.equal(journal.mayReconcileUpload(initial),false);
 assert.throws(()=>journal.recordUploadFileIntent(artifacts[1]),e=>e.code==='P2_UPLOAD_DUPLICATE');
 journal.recordUploadFileIntent(artifacts[0]);
 assert.throws(()=>journal.recordUploadFileIntent(artifacts[0]),e=>e.code==='P2_UPLOAD_DUPLICATE');
 journal.recordUploadFileStaged({...artifacts[0],source:'ATTACHMENT_ROW'});
 journal.advance('UPLOAD_VERIFIED');journal.advance('GEVO_INTENT');journal.advance('GEVO_VERIFIED');
 assert.equal(journal.read().state,'GEVO_VERIFIED');
 assert.deepEqual(journal.read().events.filter(e=>e.state==='UPLOAD_FILE_INTENT').map(e=>e.plan),['DC']);
}));
test('RC45 recovery decline and incomplete independent checks leave journal byte-for-byte unchanged',()=>fixture(({journal})=>{
 interruptedLegacy(journal);const before=fs.readFileSync(journal.file);
 for(const flag of ['operatorConfirmed','ticketUnchanged','noSaveOrForward']){
  assert.throws(()=>journal.approveUploadReconciliation({...approval,[flag]:false}),e=>e.code==='P2_UPLOAD_RECOVERY_BLOCKED');
  assert.deepEqual(fs.readFileSync(journal.file),before);
 }
 assert.equal(journal.mayReconcileUpload(initial),true);
}));
test('RC45 changed ticket, description or PDF hashes cannot authorize interrupted-upload recovery',()=>fixture(({journal})=>{
 interruptedLegacy(journal);
 assert.equal(journal.mayReconcileUpload({...initial,ticketId:'87393963'}),false);
 assert.equal(journal.mayReconcileUpload({...initial,descriptionSha256:digestDescription('changed')}),false);
 assert.equal(journal.mayReconcileUpload({...initial,pdfHashes:[{plan:'DC',sha256:'f'.repeat(64)},initial.pdfHashes[1]]}),false);
 assert.throws(()=>journal.approveUploadReconciliation({...approval,descriptionSha256:'f'.repeat(64)}),e=>e.code==='P2_UPLOAD_RECOVERY_BLOCKED');
}));
test('RC45 recovery must account for each PDF exactly once',()=>fixture(({journal})=>{
 interruptedLegacy(journal);
 for(const lists of [{existingPlans:['PP+'],missingPlans:[]},{existingPlans:['PP+'],missingPlans:['PP+']},
  {existingPlans:['PP+'],missingPlans:['DB+']},{existingPlans:[],missingPlans:undefined}]){
  assert.throws(()=>journal.approveUploadReconciliation({...approval,...lists}),e=>e.code==='P2_UPLOAD_RECOVERY_BLOCKED');
 }
}));
test('RC45 later GEVO, save or review work cannot be reinterpreted as an interrupted upload',()=>fixture(({journal})=>{
 journal.begin();journal.advance('UPLOAD_INTENT');
 assert.equal(journal.mayReconcileUpload(initial),true);
 for(const state of ['UPLOAD_VERIFIED','GEVO_INTENT','GEVO_VERIFIED','DESCRIPTION_INTENT','DESCRIPTION_VERIFIED',
  'DRAFT_SAVE_INTENT','DRAFT_SAVE_VERIFIED','TICKET_SAVE_INTENT','TICKET_SAVE_VERIFIED','REVIEW_INTENT','REVIEW_VERIFIED','EXECUTE_INTENT','ROUTED_VERIFIED']){
  journal.advance(state);assert.equal(journal.mayReconcileUpload(initial),false,state);
 }
}));
test('RC45 old GEVO-first upload and forged UPLOAD_INTENT after a save stay blocked',()=>fixture(({journal})=>{
 journal.begin();journal.advance('GEVO_INTENT');journal.advance('GEVO_VERIFIED');journal.advance('UPLOAD_INTENT');
 assert.equal(journal.mayReconcileUpload(initial),false);
 const data=journal.read();data.events=[{state:'PREPARED'},{state:'TICKET_SAVE_INTENT'},{state:'UPLOAD_INTENT'}];
 writeJSON(journal.file,data);assert.equal(journal.mayReconcileUpload(initial),false);
}));
test('RC45 file intent survives interruption and staging requires the matching single pending file',()=>fixture(({root,journal})=>{
 journal.begin();journal.advance('UPLOAD_INTENT');journal.recordUploadFileIntent(artifacts[1]);
 const restarted=phase2Journal(root,ID);
 assert.equal(restarted.read().events.at(-1).state,'UPLOAD_FILE_INTENT');
 assert.equal(restarted.mayReconcileUpload(initial),true);
 assert.throws(()=>journal.recordUploadFileStaged({...artifacts[0],source:'ATTACHMENT_ROW'}),e=>e.code==='P2_UPLOAD_FILE_EVIDENCE');
 journal.recordUploadFileStaged({...artifacts[1],source:'FILEPOND'});
 assert.equal(journal.mayReconcileUpload(initial),true);
 assert.throws(()=>journal.recordUploadFileStaged({...artifacts[1],source:'FILEPOND'}),e=>e.code==='P2_UPLOAD_FILE_EVIDENCE');
}));
test('RC45 inconsistent per-file journal events or a journal copied from a different ticket stay blocked',()=>fixture(({journal})=>{
 journal.begin();journal.advance('GEVO_INTENT');
 let x=journal.read();x.ticketId='87393963';writeJSON(journal.file,x);
 assert.equal(journal.mayRetryGevoFocus(initial),false);
 x.ticketId=ID;writeJSON(journal.file,x);
 journal.approveGevoFocusRetry({...initial,operatorConfirmed:true,ticketUnchanged:true,noAttachments:true});journal.advance('UPLOAD_INTENT');
 journal.recordUploadFileIntent(artifacts[0]);x=journal.read();const valid=structuredClone(x);
 x.events.at(-1).name=artifacts[1].name;writeJSON(journal.file,x);
 assert.equal(journal.mayReconcileUpload(initial),false);
 valid.events.push({state:'UPLOAD_FILE_STAGED',plan:'DC',sha256:artifacts[0].sha256,name:'99123456_Kontoauszug_DC.pdf'});
 writeJSON(journal.file,valid);assert.equal(journal.mayReconcileUpload(initial),false);
}));
test('RC45 preflight admits the actual legacy upload only for inspection and preserves its bytes until operator approval',()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC45-PREFLIGHT-')),root=path.join(dir,'MCR_Datenbruecke');
 try{
  const base=path.join(root,'.runtime','phase2');fs.mkdirSync(base,{recursive:true});
  for(const [plan,folder] of [['DC','Kontoauszug_DC'],['PP+','Kontoauszug_pp+']]){
   const dest=path.join(dir,folder,'Ausgabe_PDF');fs.mkdirSync(dest,{recursive:true});
   fs.writeFileSync(path.join(dest,WWID+'_Kontoauszug_'+plan+'.pdf'),'%PDF-1.4\n'+plan+' '.repeat(240)+'\n%%EOF\n');
  }
  writeJSON(path.join(base,'MCR_PHASE2_LETZTE_INVENTUR.json'),phase2Inventory([{ticketId:ID,source:'POST',descriptionValue:DESCRIPTION}]));
  const proof={...inspectExistingStatements(root,['DC','PP+'],WWID),ticketId:ID,operatorContentReviewed:true,operatorPersonTicketBindingReviewed:true};
  writeJSON(path.join(base,'MCR_PHASE2_PDF_BELEG_'+ID+'_2026-11-03T08-00-00-000Z.json'),proof);
  const p=preflightPhase2Write(root,ID);p.journal.begin();p.journal.advance('GEVO_INTENT');
  p.journal.approveGevoFocusRetry({...p.initial,operatorConfirmed:true,ticketUnchanged:true,noAttachments:true});p.journal.advance('UPLOAD_INTENT');
  const before=fs.readFileSync(p.journal.file),r=preflightPhase2Write(root,ID);
  assert.equal(r.recoveryNeeded,true);assert.equal(r.recoveryMode,'UPLOAD_RECONCILIATION');assert.deepEqual(fs.readFileSync(p.journal.file),before);
  r.journal.approveUploadReconciliation({...r.initial,operatorConfirmed:true,ticketUnchanged:true,noSaveOrForward:true,existingPlans:['PP+'],missingPlans:['DC']});
  assert.throws(()=>preflightPhase2Write(root,ID),e=>e.code==='P2_ALREADY_ATTEMPTED');
 }finally{fs.rmSync(dir,{recursive:true,force:true,maxRetries:5,retryDelay:100});}
});
