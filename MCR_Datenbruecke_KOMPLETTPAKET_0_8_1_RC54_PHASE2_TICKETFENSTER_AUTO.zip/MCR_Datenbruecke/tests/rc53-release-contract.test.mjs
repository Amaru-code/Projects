import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';import {execFileSync} from 'node:child_process';
import {ROOT} from './helpers.mjs';import {sha256} from '../lib/core.mjs';import {VERSION} from '../lib/control.mjs';import {verifyPackage} from '../tools/integrity.mjs';
const read=f=>fs.readFileSync(path.join(ROOT,f),'utf8');
test('RC53 package pins original RC52, seals source and preserves the successful PDF upload and migration bytes',()=>{
 assert.equal(VERSION,'0.8.1-rc.54');const text=read('tools/reference/complete-0.8.1-rc.52-manifest.json');
 assert.equal(sha256(text),'107f2bb9f3cd8c816dddc859182f9df3480ce425b579934855be676e47607b63');
 const prior=JSON.parse(text);for(const f of ['lib/phase2-filepond.mjs','tools/deploy.mjs','lib/migration-priority.mjs'])assert.equal(sha256(fs.readFileSync(path.join(ROOT,f))),prior.payload.find(x=>x.path===f).sha256,f);
 assert.equal(verifyPackage(ROOT).version,VERSION);const m=JSON.parse(read('MANIFEST.json'));
 for(const f of ['lib/delivery-console.mjs','tools/delivery-window.ps1','lib/trusted-description.mjs','src/phase1-completion-only.mjs','lib/operator-send-review.mjs','tests/rc53-upgrade.test.mjs'])assert(m.payload.some(x=>x.path===f),f);
 assert(m.payload.every(x=>!/^private_data\/|^\.runtime\/|^diagnostics\/|^Ergebnis\/|\.zip$/i.test(x.path)));
});
test('RC53 menu 1 and live menus never start demos or full tests implicitly',()=>{
 const s=read('tools/cli.mjs'),setup=s.slice(s.indexOf('async function setup()'),s.indexOf('async function real(')),real=s.slice(s.indexOf('async function real('),s.indexOf('async function completionOnly('));
 for(const section of [setup,real]){assert(!section.includes('await selftest()'));assert(!section.includes('await demo()'));}
 assert(real.includes('ECHTLAUF_DIREKT'));assert(real.includes('PILOT_REQUIRED'));
});
test('RC53 native panel source uses nonblocking pipe reader, bottom left, real toggle, input-hide ack and smooth five-second completion',()=>{
 const s=read('tools/delivery-window.ps1');
 for(const text of ['McrPipeReader','t.IsBackground=true','McrModeSwitch','CheckedChanged','($work.Left+16)','($work.Bottom-301)',"event='hidden'",'LimeGreen','/5000.0','3*$t*$t-2*$t*$t*$t','ShowWithoutActivation'])assert(s.includes(text),text);
 assert(!s.includes('$reader.ReadLineAsync()'));assert(!/Invoke-WebRequest|HttpClient|Set-Content|WriteAllText|SendKeys/i.test(s));
 const js=read('lib/delivery-console.mjs');assert(js.includes("initialMode='MANUAL'"));assert(js.includes('OVERLAY_INPUT_BLOCKED'));assert(js.includes('SEND_APPROVAL_CHANGED'));
});
test('RC53 targeted old-send completion has no mail-send or reply-writing method',()=>{
 const s=read('src/phase1-completion-only.mjs');assert(s.includes("prior.state==='SAVE_INTENT'"));assert(s.includes('prior.descriptionSha256'));
 assert(!/sendOnce\(|writeEditor\(|executeReview\(|attachLocalFiles\(/.test(s));assert(s.includes('reviewUnverifiedSend'));
});
test('RC53 native Windows PowerShell parser accepts the new dashboard script',{skip:process.platform!=='win32'},()=>{
 const ps=path.join(process.env.SystemRoot||'C:\\Windows','System32/WindowsPowerShell/v1.0/powershell.exe');
 execFileSync(ps,['-NoProfile','-NonInteractive','-Command','$t=$null; $e=$null; [void][System.Management.Automation.Language.Parser]::ParseFile($env:MCR_TEST_PARSE_SCRIPT,[ref]$t,[ref]$e); if ($e.Count -gt 0) { $e | Out-String | Write-Error; exit 1 }'],{env:{...process.env,MCR_TEST_PARSE_SCRIPT:path.join(ROOT,'tools/delivery-window.ps1')},encoding:'utf8',timeout:15000,windowsHide:true});
});
test('RC53 native Windows compiles dashboard controls and its background pipe reader without launching a window',{skip:process.platform!=='win32'},()=>{
 const ps=path.join(process.env.SystemRoot||'C:\\Windows','System32/WindowsPowerShell/v1.0/powershell.exe');
 const cs=read('tools/delivery-window.ps1').split("@'\n")[1].split("\n'@")[0];assert(cs.includes('class McrPipeReader'));
 execFileSync(ps,['-NoProfile','-NonInteractive','-Command',"$ErrorActionPreference='Stop'; Add-Type -AssemblyName System.Windows.Forms; Add-Type -AssemblyName System.Drawing; Add-Type -ReferencedAssemblies System.Windows.Forms,System.Drawing -TypeDefinition $env:MCR_TEST_CSHARP; if (-not ('McrPipeReader' -as [type]) -or -not ('McrModeSwitch' -as [type])) { exit 1 }"],{env:{...process.env,MCR_TEST_CSHARP:cs},encoding:'utf8',timeout:30000,windowsHide:true});
});
