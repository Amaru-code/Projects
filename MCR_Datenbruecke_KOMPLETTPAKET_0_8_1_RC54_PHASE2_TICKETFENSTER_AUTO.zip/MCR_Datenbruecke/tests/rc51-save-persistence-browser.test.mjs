/** RC51: deterministic CDP request observation plus actual Chromium trusted save.
 * The container's managed Chromium blocks loopback HTTP with
 * ERR_BLOCKED_BY_ADMINISTRATOR, so the POST timing itself is modeled through
 * flat-session CDP events. Chromium click behavior is tested separately. */
import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage,sleep} from '../lib/cdp.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
import {savePhase2Ticket} from '../lib/phase2-comarch-actions.mjs';
import {watchPhase2Save} from '../lib/phase2-save-settle.mjs';
function fakeCdp(){const listeners=new Map();return {
 on(method,fn){if(!listeners.has(method))listeners.set(method,new Set());listeners.get(method).add(fn);return ()=>listeners.get(method).delete(fn);},
 async send(method){assert.equal(method,'Network.enable');return {};},
 emit(method,evt,sid='test-session'){for(const fn of listeners.get(method)||[])fn(evt,sid);}
};}
const fakePage=cdp=>({cdp,sessionId:'test-session',call:async()=> 'https://comarchecm.mercer.com'});

test('RC51 async ICEfaces POST must finish before save verification is allowed',async()=>{
 const cdp=fakeCdp(),observer=await watchPhase2Save(fakePage(cdp),{minWaitMs:100,quietMs:100,maxWaitMs:5000});
 const t=Date.now();setTimeout(()=>cdp.emit('Network.requestWillBeSent',{requestId:'1',request:{url:'https://comarchecm.mercer.com/ecm',method:'POST'}}),80);
 setTimeout(()=>cdp.emit('Network.responseReceived',{requestId:'1',response:{status:200}}),1050);
 setTimeout(()=>cdp.emit('Network.loadingFinished',{requestId:'1'}),1160);
 const result=await observer.settle();assert.equal(result.status,'NETWORK_QUIET');assert.equal(result.writeStarts,1);
 assert(Date.now()-t>=1150,'must not navigate away before asynchronous POST completes');
});

test('RC51 an unsuccessful COMARCH POST is not certified',async()=>{
 const cdp=fakeCdp(),observer=await watchPhase2Save(fakePage(cdp),{minWaitMs:100,quietMs:60,maxWaitMs:2000});
 cdp.emit('Network.requestWillBeSent',{requestId:'x',request:{url:'https://comarchecm.mercer.com/submit',method:'POST'}});
 cdp.emit('Network.responseReceived',{requestId:'x',response:{status:500}});
 cdp.emit('Network.loadingFinished',{requestId:'x'});
 const result=await observer.settle();assert.equal(result.status,'WRITE_REQUEST_ERROR');assert.equal(result.errors,1);
});

test('RC51 unrelated traffic and foreign session never produce fake save proof',async()=>{
 const cdp=fakeCdp(),observer=await watchPhase2Save(fakePage(cdp),{minWaitMs:100,quietMs:100,maxWaitMs:3600});
 cdp.emit('Network.requestWillBeSent',{requestId:'x',request:{url:'https://different.example.net/submit',method:'POST'}});
 cdp.emit('Network.requestWillBeSent',{requestId:'y',request:{url:'https://comarchecm.mercer.com/submit',method:'POST'}},'foreign-session');
 const result=await observer.settle();assert.equal(result.status,'NO_WRITE_SIGNAL');assert.equal(result.writeStarts,0);
});

test('RC51 real Chromium single trusted save click and delayed frontend completion',{timeout:35000},async()=>{
 const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC20-NOTE-RC51-SAVE-'));let browser,cdp;
 try{
  browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,
   extraArgs:process.platform==='linux'?['--no-sandbox','--disable-dev-shm-usage']:[]});
  ({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.url==='about:blank');
  await page.call(()=>{document.body.innerHTML='<a id="save" href="#">Ticket speichern</a>';
   window.saveClicks=0;window.persisted=false;document.getElementById('save').onclick=e=>{e.preventDefault();if(e.isTrusted){window.saveClicks++;setTimeout(()=>window.persisted=true,1050);}};});
  const observer=await watchPhase2Save(page,{minWaitMs:100,quietMs:50,maxWaitMs:5000});
  let intent=0;const click=await savePhase2Ticket(page,{beforeAutoClick:()=>{intent++;}});
  assert.equal(click.automaticClicks,1);assert.equal(intent,1);assert.equal(await page.eval('window.persisted'),false);
  const result=await observer.settle();assert.equal(result.status,'NO_WRITE_SIGNAL');
  assert.equal(await page.eval('window.persisted'),true);assert.equal(await page.eval('window.saveClicks'),1);
 }finally{await cleanupTemporaryTestBrowser({profile,browser,cdp});}
});
