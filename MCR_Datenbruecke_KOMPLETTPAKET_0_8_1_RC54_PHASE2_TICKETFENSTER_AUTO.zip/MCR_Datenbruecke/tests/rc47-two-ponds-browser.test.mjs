/** RC47 regression: real COMARCH reported rootCount=2 for the live ticket before
 * any PDF was selected. Independent/empty FilePond roots are not attachments.
 * Use actual Chromium/CDP, with native file choosers, not an in-memory DOM.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
import {attachPhase2Files,phase2AttachmentEvidence,ensurePhase2UploadSurface} from '../lib/phase2-filepond.mjs';
import {planPhase2UploadContinuation} from '../lib/phase2-upload-continuation.mjs';

const names=['11368989_Kontoauszug_PP+.pdf','11368989_Kontoauszug_DC.pdf'];
async function fixture(fn){
 const base=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC47-TWO-ROOTS-'));
 const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-P2-DOM-RC47-'));
 let browser,cdp;
 try{
  const files=names.map(n=>path.join(base,n));
  files.forEach(f=>fs.writeFileSync(f,'%PDF-1.4\n'+('1'.repeat(180))+'\n%%EOF'));
  browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,
   extraArgs:['--disable-background-networking','--disable-sync',...(process.platform!=='win32'&&process.getuid?.()===0?['--no-sandbox']:[])]});
  ({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.url==='about:blank');
  await page.call(function(){
   document.body.innerHTML='<div class="filepond--root" id="other-pond" style="height:25px;border:1px solid #ccc">Other COMARCH upload widget</div><button id="opener">Dokument anhängen</button><div id="upload"></div><ul id="attachments"></ul>';
   window.rc47={open:0,selected:[],trusted:[],sent:0};
   const show=()=>{
    window.rc47.open++;
    const id='dynamic'+window.rc47.open;
    const pond=document.createElement('div');pond.className='filepond--root';
    const input=document.createElement('input');input.type='file';input.id='filepond--browser-'+id;
    input.style.cssText='position:absolute;width:1px;height:1px;opacity:0';
    const label=document.createElement('label');label.id='filepond--drop-label-'+id;label.htmlFor=input.id;
    label.textContent='Dateien hierher ziehen oder zum Auswählen klicken';
    label.style.cssText='display:block;width:390px;height:50px;margin:25px';
    label.addEventListener('click',e=>window.rc47.trusted.push(e.isTrusted));
    input.addEventListener('change',e=>{
     for(const f of input.files){window.rc47.selected.push(f.name);
      const li=document.createElement('li');li.textContent=f.name;
      document.getElementById('attachments').append(li);
     }
     pond.remove();document.getElementById('opener').hidden=false;
    });
    pond.append(input,label);document.getElementById('upload').append(pond);
    document.getElementById('opener').hidden=true;
   };
   document.getElementById('opener').addEventListener('click',e=>{if(e.isTrusted)show();});
   show();
  });
  return await fn({page,files});
 }finally{
  try{await cleanupTemporaryTestBrowser({profile,browser,cdp});}
  finally{fs.rmSync(base,{recursive:true,force:true});}
 }
}

test('RC47 Chromium actual incident: two FilePond roots permit a first PP+ and a fresh second DC chooser', {timeout:70000},()=>fixture(async({page,files})=>{
 const initial=await phase2AttachmentEvidence(page,names);
 assert.equal(initial.rootCount,2);
 assert.deepEqual(initial.items.map(i=>i.status),['ABSENT','ABSENT']);
 const calls=[];
 const result=await attachPhase2Files(page,files,{
  beforeSelect:async({name})=>calls.push('INTENT:'+name),
  afterStaged:async({name,evidence})=>{assert.equal(evidence.items[0].status,'READY');calls.push('STAGED:'+name);}
 });
 assert.equal(result.files,2);
 assert.deepEqual(await page.eval('window.rc47.selected'),names);
 assert.deepEqual(await page.eval('window.rc47.trusted'),[true,true]);
 assert.equal(await page.eval('window.rc47.open'),2);
 assert.deepEqual(calls,names.flatMap(n=>['INTENT:'+n,'STAGED:'+n]));
 assert.equal((await phase2AttachmentEvidence(page,names)).allReady,true);
 assert.equal(await page.eval('window.rc47.sent'),0);
}));

test('RC47 Chromium: two roots plus existing PP+ reconcile to DC only', {timeout:60000},()=>fixture(async({page,files})=>{
 await page.call(function(name){const li=document.createElement('li');li.textContent=name;document.getElementById('attachments').append(li);},names[0]);
 const evidence=await phase2AttachmentEvidence(page,names);
 assert.equal(evidence.rootCount,2);
 assert.deepEqual(evidence.items.map(i=>i.status),['READY','ABSENT']);
 const plan=planPhase2UploadContinuation({artifacts:files.map((file,i)=>({plan:i?'DC':'PP+',name:names[i],file,sha256:(i?'b':'a').repeat(64)})),evidence,resumeUpload:true});
 assert.deepEqual(plan.existing.map(a=>a.plan),['PP+']);assert.deepEqual(plan.missing.map(a=>a.plan),['DC']);
 await assert.rejects(()=>attachPhase2Files(page,files),e=>e.code==='P2_ATTACHMENT_ALREADY_PRESENT');
 assert.deepEqual(await page.eval('window.rc47.selected'),[]);
 await attachPhase2Files(page,[files[1]]);
 assert.deepEqual(await page.eval('window.rc47.selected'),[names[1]]);
 assert.equal((await phase2AttachmentEvidence(page,names)).allReady,true);
}));

test('RC47 Chromium: exact PDF in two separate roots is a true duplicate and is never reselected', {timeout:35000},()=>fixture(async({page,files})=>{
 await page.call(function(name){
  const roots=document.querySelectorAll('.filepond--root');
  for(const root of roots){const item=document.createElement('li');item.className='filepond--item';item.setAttribute('data-filepond-item-state','idle');const span=document.createElement('span');span.className='filepond--file-info-main';span.textContent=name;item.append(span);root.append(item);}
 },names[0]);
 const evidence=await phase2AttachmentEvidence(page,[names[0]]);
 assert.equal(evidence.rootCount,2);assert.equal(evidence.items[0].count,2);
 assert.equal(evidence.items[0].status,'DUPLICATE');
 await assert.rejects(()=>attachPhase2Files(page,[files[0]]),e=>e.code==='P2_ATTACHMENT_ALREADY_PRESENT');
 assert.deepEqual(await page.eval('window.rc47.selected'),[]);
}));

test('RC47 Chromium: an unrelated root cannot conceal a pending or hidden exact PDF', {timeout:35000},()=>fixture(async({page,files})=>{
 await page.call(function(name){
  const other=document.getElementById('other-pond');const item=document.createElement('li');item.className='filepond--item';item.setAttribute('data-filepond-item-state','processing');
  const span=document.createElement('span');span.className='filepond--file-info-main';span.textContent=name;item.append(span);other.append(item);
 },names[1]);
 let evidence=await phase2AttachmentEvidence(page,[names[1]]);
 assert.equal(evidence.items[0].status,'PENDING');
 await assert.rejects(()=>attachPhase2Files(page,[files[1]]),e=>e.code==='P2_ATTACHMENT_ALREADY_PRESENT');
 await page.call(function(){document.getElementById('other-pond').style.display='none';});
 evidence=await phase2AttachmentEvidence(page,[names[1]]);
 assert.equal(evidence.items[0].status,'HIDDEN_UNVERIFIED');
 await assert.rejects(()=>attachPhase2Files(page,[files[1]]),e=>e.code==='P2_ATTACHMENT_ALREADY_PRESENT');
 assert.deepEqual(await page.eval('window.rc47.selected'),[]);
}));

test('RC47 Chromium: two plausible active chooser labels remain ambiguous and do not trigger selection', {timeout:35000},()=>fixture(async({page,files})=>{
 await page.call(function(){
  const root=document.getElementById('other-pond'),id='filepond--browser-foreign';
  const input=document.createElement('input');input.type='file';input.id=id;
  const label=document.createElement('label');label.id='filepond--drop-label-foreign';label.htmlFor=id;
  label.textContent='Dateien hierher ziehen oder zum Auswählen klicken';
  label.style.cssText='display:block;width:390px;height:50px';root.append(input,label);
 });
 const evidence=await phase2AttachmentEvidence(page,[names[1]]);
 assert.equal(evidence.items[0].status,'ABSENT');
 await assert.rejects(()=>attachPhase2Files(page,[files[1]]),e=>e.code==='FILEPOND_MULTIPLE_OR_UNBOUND');
 assert.deepEqual(await page.eval('window.rc47.selected'),[]);
}));
