import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';
import {snapshotStatementOutputs,verifyNewStatements} from '../lib/phase2-pdf-evidence.mjs';
import {phase2DraftPreview} from '../lib/phase2-draft-preview.mjs';
function env(){const base=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-P2-DC36-')),root=path.join(base,'MCR_Datenbruecke');fs.mkdirSync(root);
 for(const [dir,start] of [['Kontoauszug_DC','START_KONTOAUSZUG_DC.bat'],['Kontoauszug_pp+','START_KONTOAUSZUG.bat']]){
  const d=path.join(base,dir);fs.mkdirSync(path.join(d,'Ausgabe_PDF'),{recursive:true});fs.writeFileSync(path.join(d,start),'@echo off\n');
 }
 const fake=(plan,name)=>fs.writeFileSync(path.join(base,plan==='DC'?'Kontoauszug_DC':'Kontoauszug_pp+','Ausgabe_PDF',name),Buffer.concat([Buffer.from('%PDF-1.5\n'),Buffer.alloc(160,0x20),Buffer.from('\n%%EOF\n')]));
 return {root,base,fake,close:()=>fs.rmSync(base,{recursive:true,force:true})};
}
const args={wwid:'11368989',first:'Frank',last:'Huertgen',year:2026};
const trial=(name,assertion)=>{const a=env();try{const before=snapshotStatementOutputs(a.root,['DC']);a.fake('DC',name);assertion(()=>verifyNewStatements(a.root,before,args));}finally{a.close();}};
test('RC36 exact new WWID_Kontoauszug_DC accepted, no WWID digit guessing',()=>{
 trial('11368989_Kontoauszug_DC.pdf',run=>{const a=run().artifacts[0];assert.equal(a.scheme,'DC_WWID_KONTOAUSZUG');assert.equal(a.wwidInFilename,true);assert.equal(a.manualIdentityReviewRequired,false);});
 trial('11368990_Kontoauszug_DC.pdf',run=>assert.throws(run,x=>x.code==='P2_PDF_NAME'));
 trial('11368989_Kontoauszug_DC_COPY.pdf',run=>assert.throws(run,x=>x.code==='P2_PDF_NAME'));
});
test('RC36 old Intel pattern stays compatible, explicit trailing month only',()=>{
 trial('Intel_11368989_KA_DE_2026.pdf',run=>assert.equal(run().artifacts[0].scheme,'DC_INTEL_WWID_LEGACY'));
 trial('Intel_11368989_KA_DE_2026_01.pdf',run=>assert.equal(run().artifacts[0].scheme,'DC_INTEL_WWID_LEGACY'));
 trial('Intel_11368989_KA_DE_2026_13.pdf',run=>assert.throws(run,x=>x.code==='P2_PDF_NAME'));
});
test('RC36 screenshot pattern with year+surname+initial is WEAK and requires review',()=>{
 trial('2024_DC_Kontoauszug_HürtgenF.pdf',run=>{
  const r=run(),a=r.artifacts[0];assert.equal(a.scheme,'DC_YEAR_SURNAME_INITIAL');assert.equal(a.wwidInFilename,false);assert.equal(a.manualIdentityReviewRequired,true);
  assert.equal(r.operatorNameOnlyRecheckRequired,true);assert.equal(r.automaticAttachmentAuthorized,false);
 });
 trial('2024_DC_Kontoauszug_SchmidtF.pdf',run=>assert.throws(run,x=>x.code==='P2_PDF_NAME'));
 trial('2027_DC_Kontoauszug_HuertgenF.pdf',run=>assert.throws(run,x=>x.code==='P2_PDF_NAME'));
});
test('RC36 weak surname+initial PDF cannot create even a draft preview without extra review',()=>{
 const ticketId='87278094',description='USC 20/ DC;PP+\nStandardantwort versendet\nMöchte Kontoauszug';
 const artifacts=[{plan:'DC',scheme:'DC_YEAR_SURNAME_INITIAL',manualIdentityReviewRequired:true,sha256:'a'.repeat(64),bytes:1000},
  {plan:'PP+',scheme:'PP_FULL_NAME',manualIdentityReviewRequired:false,sha256:'b'.repeat(64),bytes:1000}];
 const pdfProof={schema:'MCR_PHASE2_PDF_PROOF_V1',ticketId,operatorContentReviewed:true,artifacts};
 assert.throws(()=>phase2DraftPreview({ticketId,source:'POST',description,pdfProof}),x=>x.code==='P2_DRAFT_DC_NAME_REVIEW');
 const preview=phase2DraftPreview({ticketId,source:'POST',description,pdfProof:{...pdfProof,operatorNameOnlyRecheckCompleted:true}});
 assert.equal(preview.containsNameOnlyDcEvidence,true);assert.equal(preview.automaticAttachmentAuthorized,false);assert.equal(preview.writeAuthorized,false);
});
test('RC36 still blocks mutated baseline and more than one new DC output',()=>{
 const a=env();try{
  let before=snapshotStatementOutputs(a.root,['DC']);a.fake('DC','11368989_Kontoauszug_DC.pdf');a.fake('DC','Intel_11368989_KA_DE_2026.pdf');
  assert.throws(()=>verifyNewStatements(a.root,before,args),x=>x.code==='P2_PDF_COUNT');
  before=snapshotStatementOutputs(a.root,['DC']);fs.appendFileSync(path.join(a.base,'Kontoauszug_DC','Ausgabe_PDF','11368989_Kontoauszug_DC.pdf'),'x');
  assert.throws(()=>verifyNewStatements(a.root,before,args),x=>x.code==='P2_EXISTING_PDF_OVERWRITTEN');
 }finally{a.close();}
});
