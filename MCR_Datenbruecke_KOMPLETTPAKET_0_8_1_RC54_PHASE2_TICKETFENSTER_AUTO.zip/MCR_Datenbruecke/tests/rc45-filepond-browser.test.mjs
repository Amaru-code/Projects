import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
import {attachPhase2Files,phase2AttachmentEvidence,ensurePhase2UploadSurface} from '../lib/phase2-filepond.mjs';

async function fixture(run){
 const temp=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC45-FILEPOND-'));
 const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-P2-DOM-RC45-'));
 let browser,cdp;
 try{
  const files=['11368989_Kontoauszug_PP+.pdf','11368989_Kontoauszug_DC.pdf'].map(n=>path.join(temp,n));
  files.forEach(file=>fs.writeFileSync(file,'%PDF-1.4\n'+('0'.repeat(250))+'\n%%EOF\n'));
  browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,
   extraArgs:['--disable-background-networking','--disable-sync',...(process.platform!=='win32'&&process.getuid?.()===0?['--no-sandbox']:[])]});
  ({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.url==='about:blank');
  return await run({page,files});
 }finally{try{await cleanupTemporaryTestBrowser({profile,browser,cdp});}finally{fs.rmSync(temp,{recursive:true,force:true,maxRetries:5,retryDelay:100});}}
}

async function closingPond(page){await page.call(function(){
 document.body.innerHTML='<button id="opener">Dokument anhängen</button><div id="surface"></div><ul id="attachments"></ul>';
 window.rc45={open:0,chosen:[],clicked:[],events:[],sends:0};
 const show=()=>{
  window.rc45.open++;
  const key='r'+window.rc45.open+'Dynamic';
  const root=document.createElement('div');root.className='filepond--root';
  const input=document.createElement('input');input.type='file';input.id='filepond--browser-'+key;
  input.style.cssText='position:absolute;width:1px;height:1px;opacity:0';
  const label=document.createElement('label');label.id='filepond--drop-label-'+key;label.htmlFor=input.id;
  label.textContent='Dateien hierher ziehen oder zum Auswählen klicken';
  label.style.cssText='display:block;margin:30px;width:420px;height:50px';
  label.addEventListener('click',e=>{window.rc45.clicked.push(e.isTrusted);window.rc45.events.push('CHOOSER');});
  input.addEventListener('change',e=>{
   window.rc45.chosen.push(...[...e.target.files].map(f=>f.name));
   for(const f of e.target.files){
    const li=document.createElement('li');const link=document.createElement('a');
    link.textContent=f.name;li.append(link);document.getElementById('attachments').append(li);
   }
   // The real failure mode: no FilePond item remains. COMARCH has its own row.
   root.remove();document.getElementById('opener').hidden=false;
  });
  root.append(input,label);document.getElementById('surface').append(root);
  document.getElementById('opener').hidden=true;
 };
 document.getElementById('opener').addEventListener('click',e=>{if(e.isTrusted)show();});
 show();
});}

test('RC45 closed FilePond opens again, two fresh native choosers, one selection per PDF and ordered audit hooks',{timeout:60000},()=>fixture(async({page,files})=>{
 await closingPond(page);
 const calls=[];
 const result=await attachPhase2Files(page,files,{
  beforeSelect:async({name})=>calls.push('INTENT '+name),
  afterStaged:async({name,evidence})=>{assert.equal(evidence.allReady,true);calls.push('STAGED '+name);}
 });
 const proof=await page.eval('window.rc45');
 assert.equal(result.mode,'FILEPOND');assert.equal(result.files,2);assert.equal(result.serverUploadVerified,false);
 assert.deepEqual(proof.chosen,files.map(f=>path.basename(f)));assert.deepEqual(proof.clicked,[true,true]);assert.equal(proof.open,2);
 assert.deepEqual(calls,files.flatMap(f=>['INTENT '+path.basename(f),'STAGED '+path.basename(f)]));
 assert.equal((await phase2AttachmentEvidence(page,files.map(f=>path.basename(f)))).allReady,true);
 assert.equal(proof.sends,0);
}));

test('RC45 a previously present PP+ cannot be selected again; caller can attach only the missing DC',{timeout:60000},()=>fixture(async({page,files})=>{
 await closingPond(page);const pp=path.basename(files[0]);
 await page.call(function(name){const li=document.createElement('li');li.textContent=name;document.getElementById('attachments').append(li);},pp);
 let attempts=0;
 await assert.rejects(()=>attachPhase2Files(page,files,{beforeSelect:async()=>attempts++}),e=>e.code==='P2_ATTACHMENT_ALREADY_PRESENT');
 assert.equal(attempts,0);assert.deepEqual(await page.eval('window.rc45.chosen'),[]);
 await attachPhase2Files(page,[files[1]]);
 assert.deepEqual(await page.eval('window.rc45.chosen'),[path.basename(files[1])]);
 assert.equal((await phase2AttachmentEvidence(page,files.map(f=>path.basename(f)))).allReady,true);
}));

test('RC45 exact visible text in an email is unbound, while hidden, busy, unknown-state and duplicate rows cannot certify an upload',{timeout:50000},()=>fixture(async({page,files})=>{
 const name=path.basename(files[0]);
 await page.call(function(name){
  document.body.innerHTML='<div id="mail"><span></span></div>';
  document.querySelector('span').textContent=name;
 },name);
 let e=await phase2AttachmentEvidence(page,[name]);assert.equal(e.allReady,false);assert.equal(e.items[0].status,'UNBOUND_NAME');
 await page.call(function(name){document.getElementById('mail').innerHTML='<a download href="/example.pdf"></a>';document.querySelector('a').textContent=name;},name);
 e=await phase2AttachmentEvidence(page,[name]);assert.equal(e.items[0].status,'UNBOUND_NAME');assert.equal(e.allReady,false);
 await page.call(function(){document.getElementById('mail').remove();document.body.innerHTML='<ul id="attachments"><li><span></span></li></ul>';},name);
 await page.call(function(name){document.querySelector('span').textContent=name;document.querySelector('li').style.display='none';},name);
 e=await phase2AttachmentEvidence(page,[name]);assert.equal(e.items[0].present,true);assert.equal(e.items[0].status,'HIDDEN_UNVERIFIED');assert.equal(e.allReady,false);
 await page.call(function(){document.querySelector('li').style.display='';document.querySelector('li').setAttribute('aria-busy','true');});
 e=await phase2AttachmentEvidence(page,[name]);assert.equal(e.items[0].status,'PENDING');assert.equal(e.allReady,false);
 await page.call(function(){document.querySelector('li').removeAttribute('aria-busy');});
 e=await phase2AttachmentEvidence(page,[name]);assert.equal(e.items[0].count,1);assert.equal(e.allReady,true);
 await page.call(function(){const li=document.querySelector('li');li.parentElement.append(li.cloneNode(true));});
 e=await phase2AttachmentEvidence(page,[name]);assert.equal(e.items[0].status,'DUPLICATE');assert.equal(e.allReady,false);
 await page.call(function(name){document.body.innerHTML='<div class="filepond--root"><li class="filepond--item"><span class="filepond--file-info-main"></span></li></div>';document.querySelector('span').textContent=name;},name);
 e=await phase2AttachmentEvidence(page,[name]);assert.equal(e.items[0].status,'UNKNOWN_FILEPOND_STATE');assert.equal(e.allReady,false);
}));

test('RC45 per-file write-ahead failure prevents native file selection and all callbacks after staging',{timeout:40000},()=>fixture(async({page,files})=>{
 await closingPond(page);let staged=0;
 await assert.rejects(()=>attachPhase2Files(page,[files[0]],{
  beforeSelect:async()=>{throw Object.assign(new Error('simulated journal I/O failure'),{code:'AUDIT_WRITE_FAILED'});},
  afterStaged:async()=>staged++
 }),e=>e.code==='AUDIT_WRITE_FAILED');
 assert.deepEqual(await page.eval('window.rc45.chosen'),[]);assert.equal(staged,0);
}));

test('RC45 ambiguous Dokument anhängen is not clicked and an unbound direct chooser receives no file',{timeout:35000},()=>fixture(async({page})=>{
 await page.call(function(){document.body.innerHTML='<button>Dokument anhängen</button><button>Dokument anhängen</button>';window.opens=0;
  for(const b of document.querySelectorAll('button'))b.addEventListener('click',()=>window.opens++);});
 const surface=await ensurePhase2UploadSurface(page);assert.equal(surface.available,false);assert.equal(await page.eval('window.opens'),0);
 await page.call(function(){document.body.innerHTML='<button>Dokument anhängen</button><input type="file" id="unboundUpload" style="display:none"/>';window.selections=0;
  const input=document.getElementById('unboundUpload');input.addEventListener('change',()=>window.selections++);
  document.querySelector('button').addEventListener('click',()=>input.click());});
 await assert.rejects(()=>ensurePhase2UploadSurface(page),e=>e.code==='P2_ATTACHMENT_DIRECT_CHOOSER');
 assert.equal(await page.eval('window.selections'),0);
}));

test('RC45 legacy native input still accepts both PDFs one by one with evidence',{timeout:50000},()=>fixture(async({page,files})=>{
 await page.call(function(){document.body.innerHTML='<input type="file" id="emailAttachmentFileUpload" name="files[]" multiple/><ul id="attachments"></ul>';window.chosen=[];
  document.querySelector('input').addEventListener('change',e=>{for(const f of e.target.files){window.chosen.push(f.name);const li=document.createElement('li');li.textContent=f.name;document.querySelector('ul').append(li);}});});
 const result=await attachPhase2Files(page,files);assert.equal(result.mode,'LEGACY');
 assert.deepEqual(await page.eval('window.chosen'),files.map(f=>path.basename(f)));assert.equal(result.evidence.allReady,true);
}));
