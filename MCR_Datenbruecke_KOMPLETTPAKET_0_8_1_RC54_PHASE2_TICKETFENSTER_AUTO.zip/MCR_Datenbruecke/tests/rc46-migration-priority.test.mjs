import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';
import {ROOT,temp,putActive} from './helpers.mjs';
import {controlDir,readJSON,writeJSON,lock,assertNoMigrationPriority,verifySession} from '../lib/control.mjs';
import {beginMigrationPriority,archiveStoppedOperationLock} from '../lib/migration-priority.mjs';
import {planInstall,installSoftware,restoreSoftware,journals} from '../tools/deploy.mjs';
import {treeDigest,verifyPackage} from '../tools/integrity.mjs';

const stamp='2026-01-01T00:00:00.000Z',deadPid=1900909;
const priority=root=>path.join(controlDir(root),'migration-priority.json');
const marker=root=>path.join(root,'BETA_UMSTELLUNG_LAEUFT.txt');
const opLock=root=>path.join(controlDir(root),'operation.lock.json');
function idle(extra=[]){const rows=[{pid:process.pid,name:'node.exe',relation:'PROTECTED',createdAt:'2020-01-01T00:00:00Z',identityReadable:true},...extra];
 return {schema:'MCR_PROCESS_GUARD_V1',checked:true,blockedCount:0,unknownCount:0,inspectedPids:rows.map(p=>p.pid),inspectedProcesses:rows,stoppedProcesses:[]};}
function oldLock(root,operation='REAL_RUN',pid=deadPid){writeJSON(opLock(root),{schema:'MCR_OPERATION_LOCK_V1',operation,pid,token:'a'.repeat(48),createdAt:stamp});return fs.readFileSync(opLock(root));}
function fixture(t){const parent=temp(),target=path.join(parent,'MCR_Datenbruecke');fs.mkdirSync(target);
 for(const d of ['src','lib','tools','docs','config','.runtime/edge-profile'])fs.mkdirSync(path.join(target,d),{recursive:true});
 for(const f of ['START.cmd','README.md','MANIFEST.json','package.json','SHA256SUMS.txt','src/old.mjs','lib/old.cjs','tools/old.mjs','docs/old.md'])fs.writeFileSync(path.join(target,f),'ORIGINAL '+f);
 fs.copyFileSync(path.join(ROOT,'config/local-runner-queue-send.json'),path.join(target,'config/local-runner-queue-send.json'));putActive(target);
 fs.writeFileSync(path.join(target,'.runtime/edge-profile/KEEP'),'profile sentinel');
 const c=controlDir(target);
 for(const [file,data] of Object.entries({'ticket-ledger.json':{state:'SEND_INTENT',ticketId:'87278094'},'phase2-comarch-journal.json':{state:'UPLOAD_INTENT',recoveryCount:1},'last-run.json':{state:'STOP_REVIEW_REQUIRED'}}))writeJSON(path.join(c,file),data);
 const files=['config/local-runner-queue-send.json','private_data','.runtime/edge-profile','.runtime/beta-control/ticket-ledger.json','.runtime/beta-control/phase2-comarch-journal.json','.runtime/beta-control/last-run.json'];
 const hashes=Object.fromEntries(files.map(n=>[n,treeDigest(path.join(target,n))]));
 const software=['START.cmd','README.md','MANIFEST.json','package.json','SHA256SUMS.txt','src','lib','tools','docs'];
 const old=Object.fromEntries(software.map(n=>[n,treeDigest(path.join(target,n))]));
 const check=p=>{for(const [n,h] of Object.entries(old))assert.equal(treeDigest(path.join(p,n)),h);return {version:'TEST_BASELINE',files:software.length};};
 const unchanged=()=>{for(const [n,h] of Object.entries(hashes))assert.equal(treeDigest(path.join(target,n)),h,n);};
 t.after(()=>fs.rmSync(parent,{recursive:true,force:true}));
 return {target,parent,check,unchanged,plan:()=>planInstall(ROOT,target,{verifyOld:check}),minimal:{source:ROOT,target,release:{version:'TEST_RELEASE',manifestSha256:'b'.repeat(64)}}};
}

test('RC46 reserves migration before stopping, blocks all bot starts through QA, and releases cleanly after cancellation',t=>{
 const f=fixture(t);let calls=0;
 const m=beginMigrationPriority(f.minimal,{stop:root=>{calls++;assert.equal(root,f.target);assert(fs.existsSync(priority(root)));assert(fs.existsSync(marker(root)));return idle();}});
 assert.equal(readJSON(priority(f.target)).phase,'PREPARING');assert.equal(readJSON(opLock(f.target)).operation,'MIGRATION');
 for(const operation of ['REAL_RUN','PHASE2_READONLY','PHASE2_MANUAL_PDF','PHASE2_COMARCH_PILOT'])assert.throws(()=>lock(f.target,operation),{code:'MIGRATION_HAS_PRIORITY'});
 assert.throws(()=>assertNoMigrationPriority(f.target),{code:'MIGRATION_HAS_PRIORITY'});
 assert.throws(()=>verifySession(f.target,'a'.repeat(48)),{code:'MIGRATION_HAS_PRIORITY'});
 const before=calls;m.check();assert.equal(calls,before+1,'Late target activity is checked by the stop function again');
 m.release();m.release();
 assert.equal(fs.existsSync(priority(f.target)),false);assert.equal(fs.existsSync(marker(f.target)),false);assert.equal(fs.existsSync(opLock(f.target)),false);
 f.check(f.target);f.unchanged();const next=lock(f.target,'REAL_RUN');next.release();
});

for(const operation of ['REAL_RUN','PHASE2_READONLY','PHASE2_MANUAL_PDF','PHASE2_COMARCH_PILOT'])test('RC46 archives stopped '+operation+' lock without resetting ticket journals',t=>{
 const f=fixture(t),bytes=oldLock(f.target,operation);const m=beginMigrationPriority(f.minimal,{stop:()=>idle()});
 assert.equal(m.recoveredStaleLock,true);assert.equal(readJSON(opLock(f.target)).operation,'MIGRATION');
 const d=path.join(controlDir(f.target),'migration_archive'),arch=fs.readdirSync(d).find(n=>n.startsWith('stopped_operation_lock_'));
 const receipt=readJSON(path.join(d,arch));assert.equal(receipt.old.operation,operation);assert.deepEqual(Buffer.from(receipt.originalBytesBase64,'base64'),bytes);
 f.unchanged();m.release();assert.equal(fs.existsSync(opLock(f.target)),false);f.unchanged();
});

test('RC46 keeps a live, protected or ambiguous lock owner and never treats readability alone as owner exit',t=>{
 const f=fixture(t),original=oldLock(f.target);
 for(const relation of ['PROTECTED','UNKNOWN','UNRELATED']){
  const proof=idle([{pid:deadPid,relation,createdAt:'2025-01-01T00:00:00Z',identityReadable:true,ownershipDecidable:relation==='UNRELATED'}]);
  assert.throws(()=>archiveStoppedOperationLock(f.target,{proof,guard:()=>proof}),{code:'MIGRATION_LOCK_OWNER_ACTIVE'});
  assert.deepEqual(fs.readFileSync(opLock(f.target)),original);
 }
 f.unchanged();
});

test('RC46 failed stop removes only its own preparation and leaves old operation and software intact',t=>{
 const f=fixture(t),bytes=oldLock(f.target);
 assert.throws(()=>beginMigrationPriority(f.minimal,{stop:()=>{throw Object.assign(new Error('Cannot stop owned PID'),{code:'MIGRATION_PROCESS_STOP_FAILED'});}}),{code:'MIGRATION_PROCESS_STOP_FAILED'});
 assert.equal(fs.existsSync(priority(f.target)),false);assert.equal(fs.existsSync(marker(f.target)),false);assert.deepEqual(fs.readFileSync(opLock(f.target)),bytes);f.check(f.target);f.unchanged();
});

test('RC46 never preempts an existing migration, rollback or unknown operation',t=>{
 const f=fixture(t);
 for(const operation of ['MIGRATION','ROLLBACK','UNKNOWN']){const bytes=oldLock(f.target,operation);let stops=0;
  assert.throws(()=>beginMigrationPriority(f.minimal,{stop:()=>{stops++;return idle();}}),{code:'MIGRATION_ALREADY_ACTIVE'});
  assert.equal(stops,0);assert.deepEqual(fs.readFileSync(opLock(f.target)),bytes);assert.equal(fs.existsSync(priority(f.target)),false);assert.equal(fs.existsSync(marker(f.target)),false);
 }
 f.check(f.target);f.unchanged();
});

test('RC46 changed or foreign migration marker is preserved and blocks permit reuse',t=>{
 const f=fixture(t);const m=beginMigrationPriority(f.minimal,{stop:()=>idle()});fs.writeFileSync(marker(f.target),'OTHER MIGRATION');
 assert.throws(()=>m.check(),{code:'MIGRATION_BARRIER_CHANGED'});assert.throws(()=>m.release(),{code:'MIGRATION_BARRIER_CHANGED'});
 assert.equal(fs.readFileSync(marker(f.target),'utf8'),'OTHER MIGRATION');assert(fs.existsSync(priority(f.target)));f.check(f.target);f.unchanged();
});

test('RC46 reserved complete install retains its barrier until release and preserves all business data',t=>{
 const f=fixture(t);const m=beginMigrationPriority(f.plan(),{stop:()=>idle()});
 const p=planInstall(ROOT,f.target,{verifyOld:f.check,migration:m});const r=installSoftware(p,{verifyOld:f.check,migration:m});
 assert.equal(r.state,'COMPLETE');verifyPackage(f.target);f.unchanged();assert.equal(readJSON(priority(f.target)).phase,'COMPLETE');assert(fs.existsSync(marker(f.target)));
 assert.equal(readJSON(path.join(r.archive,'migration.json')).migrationToken,m.token);
 m.release();assert.equal(fs.existsSync(priority(f.target)),false);assert.equal(fs.existsSync(marker(f.target)),false);assert.equal(fs.existsSync(opLock(f.target)),false);
 const next=lock(f.target,'PHASE2_COMARCH_PILOT');next.release();restoreSoftware(journals(f.target)[0],{verifyOld:f.check});f.check(f.target);f.unchanged();
});

test('RC46 reserved move failure records verified automatic rollback before releasing its barrier',t=>{
 const f=fixture(t);const m=beginMigrationPriority(f.plan(),{stop:()=>idle()});const p=planInstall(ROOT,f.target,{verifyOld:f.check,migration:m});
 assert.throws(()=>installSoftware(p,{verifyOld:f.check,migration:m,fault(kind,count){if(kind==='OLD'&&count===2)throw Object.assign(new Error('Move fault'),{code:'TEST_FAULT'});}}),e=>e.code==='TEST_FAULT'&&e.rollback==='SOFTWARE_RESTORED');
 assert.equal(readJSON(priority(f.target)).phase,'ROLLED_BACK');assert(fs.existsSync(marker(f.target)));f.check(f.target);f.unchanged();m.release();assert.equal(fs.existsSync(marker(f.target)),false);
});

test('RC46 incomplete file movement retains recovery barrier and allows the existing software rollback',t=>{
 const f=fixture(t);const m=beginMigrationPriority(f.plan(),{stop:()=>idle()});const p=planInstall(ROOT,f.target,{verifyOld:f.check,migration:m});
 assert.throws(()=>installSoftware(p,{verifyOld:f.check,migration:m,fault(kind,count){if(kind==='OLD'&&count===2)throw Object.assign(new Error('Power loss'),{simulatePowerLoss:true});}}));
 assert.equal(readJSON(priority(f.target)).phase,'MOVING');m.release();assert.equal(fs.existsSync(priority(f.target)),false);assert(fs.existsSync(marker(f.target)));assert.equal(fs.existsSync(opLock(f.target)),false);
 assert.throws(()=>planInstall(ROOT,f.target,{verifyOld:f.check}),{code:'MIGRATION_INCOMPLETE'});
 restoreSoftware(journals(f.target)[0],{verifyOld:f.check});f.check(f.target);f.unchanged();assert.equal(fs.existsSync(marker(f.target)),false);
});
