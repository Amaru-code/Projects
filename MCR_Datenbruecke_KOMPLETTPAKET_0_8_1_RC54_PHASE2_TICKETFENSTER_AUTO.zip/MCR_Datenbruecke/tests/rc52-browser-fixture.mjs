import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
export async function withPhase2Browser(fn){
 const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-P2-DOM-RC52-'));let browser,cdp;
 try{browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,
  extraArgs:['--window-size=1100,1000',...(process.platform==='linux'?['--no-sandbox','--disable-dev-shm-usage']:[])]});
  ({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.url==='about:blank');return await fn(page);
 }finally{await cleanupTemporaryTestBrowser({profile,browser,cdp});}
}
export async function installPhase2Fixture(page,items,options={}){return page.call(function(items,options){
 window._server=structuredClone(items);window._counts={open:0,save:0,draft:0,review:0,direct:0,send:0,upload:0};window._order=[];
 window._routeInfo=[];window._notices=[];window._current=null;
 const escape=s=>String(s??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('"','&quot;');
 const el=id=>document.getElementById(id);
 document.body.innerHTML=`<style>body{font-family:Arial;font-size:14px}input,select,textarea{margin:3px}input[type=text]{width:320px}#workspace{padding:20px}a,button,input[type=submit]{padding:6px}label{display:block}.suggestion{position:absolute;background:white;border:1px solid black;min-width:300px;padding:6px;z-index:3}td{padding:8px}textarea{width:450px;height:90px}[contenteditable]{border:1px solid #aaa;min-height:40px;max-height:150px;overflow:auto}</style><nav id="storedSearchesContainer_MY_TASKS"><a href="#" id="queue">In_Bearbeitung</a></nav><div id="workspace"></div><div id="noticebox"></div>`;
 const notices=()=>{el('noticebox').innerHTML=window._notices.map(x=>'<div role="status">'+escape(x)+'</div>').join('');};
 window.showQueue=()=>{
  window._current=null;el('workspace').innerHTML=`<table id="mainForm:tasksTableFor_MyTasksList"><thead><tr><th>Ticket-ID</th><th>Quelle</th><th>Zusätzliche Beschreibung</th>${options.duplicateReference?'<th>Referenz</th>':''}</tr></thead><tbody>${window._server.filter(t=>!t.routed).map(t=>`<tr><td><a href="#" data-id="${t.ticketId}"> ${t.ticketId} </a></td><td>E-MAIL</td><td><textarea readonly>${escape(t.description)}</textarea></td>${options.duplicateReference?'<td>'+t.ticketId+'</td>':''}</tr>`).join('')}</tbody></table>`;
  for(const a of document.querySelectorAll('[data-id]'))a.onclick=e=>{e.preventDefault();if(e.isTrusted){window._counts.open++;window.showDetail(a.dataset.id);}};
 };
 const makeSuggestion=(fieldId,label,apply)=>{
  const field=el(fieldId);field.onkeyup=()=>{
   document.querySelectorAll('.suggestion').forEach(n=>n.remove());
   const r=field.getBoundingClientRect(),s=document.createElement('div');s.className='suggestion';s.setAttribute('role','option');s.textContent=label;
   s.style.left=(r.left+scrollX)+'px';s.style.top=(r.bottom+scrollY)+'px';
   s.onclick=e=>{if(e.isTrusted){apply(field);s.remove();window._order.push('suggestion:'+fieldId);}};document.body.append(s);
  };
 };
 window.showDetail=id=>{
  const t=window._server.find(x=>x.ticketId===id);window._current=id;
  el('workspace').innerHTML=`<form id="mainForm"><div>Ticket-ID: ${id}</div>
   <input id="mainForm:member-value-id" type="text" value="Mustermann Max (INTL01-99900001)">
   <select id="mainForm:responsibility-value-id"><option selected>Second Level</option></select>
   <input id="mainForm:category-value-id" value="Allgemeine Schriftwechsel"><input id="mainForm:category-sub-value-id" value="Personenschriftwechsel">
   <label>Anfrage-Art<input id="mainForm:gevo-value-id" value="${escape(t.gevo||'')}"></label>
   <section id="mainForm:document-data-section">Zusätzliche Beschreibung<textarea id="additional">${escape(t.description)}</textarea></section>
   <div id="pdfs">${(t.pdfs||[]).map(n=>'<span>'+escape(n)+'</span><br>').join('')}</div>
   <textarea id="mainForm:emailMessageBodyRichEditor" hidden>${escape(t.draft||'')}</textarea><div id="editor" contenteditable="true"></div>
   <a href="#" id="mainForm:j_id6190">Entwurf speichern</a><a href="#" id="save-ticket">Ticket speichern</a>
   <p><select class="iceSelOneMnu" id="mainForm:j_id7870" name="mainForm:j_id7870" size="1"><option value=""></option><option value="CLOSED">Geschlossen</option><option value="FORWARD_TO_REVIEW">Weiterleiten zur Überprüfung</option><option value="NOT_ASSIGNABLE">Nicht zuordenbar</option><option value="REJECT">Verwerfen</option></select></p>
   <input autocomplete="off" class="iceInpTxt iceSelInpTxtTxt mercer-value" id="mainForm:next-persona-assignment-id" style="display:none" type="text" value="">
   <input class="iceCmdBtn workAreaButton" id="mainForm:j_id7894" type="submit" value="Schritt ausführen">
   <p><input autocomplete="off" id="mainForm:persona-assignment-id" type="text" value=""><a class="iceCmdLnk workAreaButton" href="#" id="mainForm:current-performer-assign-link">Weiterleitung</a></p>
   <button id="send-button">Senden</button></form>`;
  el('editor').innerText=t.draft||'';
  makeSuggestion('mainForm:gevo-value-id','Anfrage Member',f=>{f.value='Anfrage Member';});
  makeSuggestion('mainForm:next-persona-assignment-id','Baindl Mark (mark.baindl)',f=>{f.value='Baindl Mark (mark.baindl)';});
  makeSuggestion('mainForm:persona-assignment-id','Baindl Mark (mark.baindl)',f=>{f.value='Baindl Mark (mark.baindl)';});
  el('mainForm:j_id7870').onchange=()=>{window._order.push('mode:'+el('mainForm:j_id7870').value);setTimeout(()=>{const n=el('mainForm:next-persona-assignment-id');if(n)n.style.display='inline-block';},options.modeDelay||350);};
  el('mainForm:j_id6190').onclick=e=>{e.preventDefault();if(e.isTrusted){window._counts.draft++;t.draft=el('editor').innerText;window._order.push('draft');}};
  el('save-ticket').onclick=e=>{e.preventDefault();if(!e.isTrusted)return;window._counts.save++;window._order.push('save');
   const snapshot={description:el('additional').value,gevo:el('mainForm:gevo-value-id').value,draft:el('editor').innerText};
   setTimeout(()=>{Object.assign(t,snapshot);window.showQueue();},options.saveDelay||300);
  };
  const route=(e,kind)=>{e.preventDefault();if(!e.isTrusted)return;
   const field=kind==='review'?'mainForm:next-persona-assignment-id':'mainForm:persona-assignment-id';
   if(el(field).value!=='Baindl Mark (mark.baindl)'||el('mainForm:gevo-value-id').value!=='Anfrage Member'||(kind==='review'&&el('mainForm:j_id7870').value!=='FORWARD_TO_REVIEW'))throw Error('WRONG_ROUTE');
   window._counts[kind]++;window._order.push(kind);window._routeInfo.push({id,kind,field,assignee:el(field).value,mode:el('mainForm:j_id7870').value});
   setTimeout(()=>{t.routed=true;if(!options.silentRoute)window._notices.push('Weiterleitung erfolgreich an Baindl Mark (mark.baindl) '+id);window.showQueue();notices();},250);
  };
  el('mainForm:j_id7894').onclick=e=>route(e,'review');el('mainForm:current-performer-assign-link').onclick=e=>route(e,'direct');
  el('send-button').onclick=e=>{e.preventDefault();window._counts.send++;};el('mainForm').onsubmit=e=>e.preventDefault();
 };
 el('queue').onclick=e=>{e.preventDefault();window.showQueue();};window.showQueue();
},items,options);}
