import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {withPhase2Browser} from './rc52-browser-fixture.mjs';import {temp,mapping} from './helpers.mjs';
import {injectDemo} from '../lib/demo.mjs';import * as UI from '../lib/browser-workflow.mjs';
import {completePendingSentTicket} from '../src/phase1-completion-only.mjs';import {ledger} from '../lib/control.mjs';
import {descriptionWithStatus} from '../lib/status-columns.mjs';import {trustedAction} from '../lib/browser-actions.mjs';
const id='90000001',source='USC 100/ DC',expected=descriptionWithStatus(source);
// Fixture exposes the old outgoing acknowledgement independently of our new
// recovery code. Never invoke the fixture's send handler to simulate success.
async function install(page){
 await injectDemo(page,{scenario:'rc18-existing-ack'});
 // Keep description across opening the mock detail (already persisted in the
 // server in this incident), then let the real recovery read its bound hash.
 const call=page.call.bind(page);page.call=async(fn,...args)=>{
  const result=await call(fn,...args);
  if(String(fn).includes("mainForm:member-value-id")&&String(fn).includes('!f.disabled&&!f.readOnly')){
   await page.eval('if(document.getElementById("desc")&&!document.getElementById("desc").value)document.getElementById("desc").value='+JSON.stringify(source));
  }
  return result;
 };
}
test('RC53 Chromium completion-only confirms existing outgoing, writes status, saves once, sends zero',{timeout:40000},()=>withPhase2Browser(async page=>{
 const root=temp();try{
  await install(page);const j=ledger(root);j.begin(id,expected);let reviewed=0,saved=0,verified=0;
  const r=await completePendingSentTicket({page,journal:j,id,mapping:mapping(),ask:async q=>{assert(q.includes('VERSAND_'+id+'_GEPRUEFT'));reviewed++;return 'VERSAND_'+id+'_GEPRUEFT';},
   save:async(ticket,book)=>{book.set(ticket,'SAVE_INTENT');await trustedAction(page,{text:'Ticket speichern',relocate:true});saved++;},
   verify:async(ticket,text)=>{const s=await UI.navigateToScope(page,'IN_BEARBEITUNG');assert.equal(s.rows.find(r=>r.ticketId===ticket).descriptionRaw,text);verified++;}});
  assert.equal(r.status,'COMPLETE');assert.equal(reviewed,1);assert.equal(saved,1);assert.equal(verified,1);assert.equal(j.pending.length,0);
  assert.equal(await page.eval('__mcrMultirowDemo.sendClicks'),0);assert.equal(await page.eval('__mcrMultirowDemo.saveClicks'),1);
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));
test('RC53 Chromium completion-only rejects declined/foreign-ticket confirmation and changed intended USC',{timeout:30000},()=>withPhase2Browser(async page=>{
 const root=temp();try{
  await install(page);const j=ledger(root);j.begin(id,expected);
  await assert.rejects(()=>completePendingSentTicket({page,journal:j,id,mapping:mapping(),ask:async()=>'',save:async()=>{throw Error('no save');},verify:async()=>{}}),e=>e.code==='SEND_UNVERIFIED');
  assert.equal(j.pending[0].state,'SEND_INTENT');assert.equal(await page.eval('__mcrMultirowDemo.sendClicks'),0);assert.equal(await page.eval('__mcrMultirowDemo.saveClicks'),0);
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));
