/** RC49 Chromium: use exactly one trusted mouse click or one explicit physical
 * operator click. Never click automatically while a permanent overlay exists. */
import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
import {savePhase2Ticket,executeReview} from '../lib/phase2-comarch-actions.mjs';
import {actionPoint} from '../lib/browser-actions.mjs';
const run=async(fn)=>{const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC20-NOTE-RC49-SAVE-'));let browser,cdp;
 try{browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,
  extraArgs:process.platform==='linux'?['--no-sandbox','--disable-dev-shm-usage']:[]});
 ({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.url==='about:blank');return await fn(page);
 }finally{await cleanupTemporaryTestBrowser({profile,browser,cdp});}};
test('RC49 delayed overlay lets repositioned Ticket speichern receive exactly one trusted click',{timeout:35000},async()=>run(async page=>{
 await page.call(()=>{document.body.innerHTML='<style>body{height:2400px}#s{display:block;position:absolute;top:550px;left:80px;padding:12px}#cover{position:fixed;inset:0;z-index:300}</style><a id="s">Ticket speichern</a><div id="cover"></div>';
 window.saveClicks=0;document.getElementById('s').onclick=e=>{if(e.isTrusted)window.saveClicks++;};
 setTimeout(()=>document.getElementById('cover')?.remove(),290);});
 const r=await savePhase2Ticket(page);assert.equal(r.automaticClicks,1);assert.equal(r.operatorClicks,0);
 assert.equal(await page.eval('window.saveClicks'),1);
}));
test('RC49 persistent overlay requires physical operator and issues zero bot clicks',{timeout:35000},async()=>run(async page=>{
 await page.call(()=>{document.body.innerHTML='<style>body{height:1800px}#s{display:block;position:absolute;top:450px;left:80px;padding:12px}#cover{position:fixed;inset:0;z-index:300;background:white}</style><a id="s">Ticket speichern</a><div id="cover"></div>';
 window.saveClicks=0;document.getElementById('s').onclick=e=>{if(e.isTrusted)window.saveClicks++;};});
 let prompted=0;const r=await savePhase2Ticket(page,{manualClick:async()=>{
   prompted++;assert.equal(await page.eval('window.saveClicks'),0);
   await page.call(()=>document.getElementById('cover').remove());
   const p=await actionPoint(page,{text:'Ticket speichern',relocate:true});assert.equal(p.ok,true);
   await page.mouseClick(p.x,p.y);
  }});
 assert.equal(prompted,1);assert.equal(r.operatorClicks,1);assert.equal(r.automaticClicks,0);
 assert.equal(await page.eval('window.saveClicks'),1);
}));
test('RC49 missing/ambiguous save and review controls do not ask for manual override',{timeout:35000},async()=>run(async page=>{
 await page.call(()=>{document.body.innerHTML='<a>Ticket speichern</a><a>Ticket speichern</a><div>Schritt ausführen</div>';});
 let offered=false;await assert.rejects(()=>savePhase2Ticket(page,{manualClick:async()=>offered=true}),e=>e.code==='P2_ACTION_NOT_UNIQUE_OR_MISSING');
 assert.equal(offered,false);
 await assert.rejects(()=>executeReview(page,{manualClick:async()=>offered=true}),e=>e.code==='P2_ACTION_NOT_UNIQUE_OR_MISSING');
 assert.equal(offered,false);
}));
test('RC49 visible reviewed execution is once only, no email action',{timeout:35000},async()=>run(async page=>{
 await page.call(()=>{document.body.innerHTML='<button>Schritt ausführen</button><button>Senden</button>';window.calls={exec:0,send:0};
 [...document.querySelectorAll('button')].forEach(n=>n.onclick=e=>{if(e.isTrusted)window.calls[n.textContent==='Senden'?'send':'exec']++;});});
 const r=await executeReview(page);assert.equal(r.automaticClicks,1);assert.deepEqual(await page.eval('window.calls'),{exec:1,send:0});
}));
