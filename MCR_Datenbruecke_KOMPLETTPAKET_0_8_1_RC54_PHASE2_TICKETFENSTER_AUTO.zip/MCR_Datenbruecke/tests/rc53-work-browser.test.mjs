import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {temp,mapping} from './helpers.mjs';import {withPhase2Browser,installPhase2Fixture} from './rc52-browser-fixture.mjs';
import {handlePhase2Work} from '../src/phase2-work-handler.mjs';import {finishPhase2Route} from '../lib/phase2-review-flow.mjs';
import {phase2WorkJournal} from '../lib/phase2-work-journal.mjs';import {readPhase2Queue} from '../lib/phase2-readonly.mjs';
import {selectReviewMode} from '../lib/phase2-comarch-actions.mjs';import {commitDescription} from '../lib/trusted-description.mjs';
import {choosePhase2Candidate} from '../src/phase2-run.mjs';
const id='87316993',before='USC 100/ DB+\nStandardantwort versendet',after=before+'\nBearbeitet not reviewed';
const noAsk=async q=>{throw Error('Unexpected: '+q);};
function journalAt(root,state){const j=phase2WorkJournal(root,id);j.begin({rule:'DB_DIRECT',descriptionBefore:before,descriptionAfter:after});
 for(const s of ['EDIT_INTENT','EDIT_VERIFIED','TICKET_SAVE_INTENT','TICKET_SAVE_VERIFIED','REVIEW_INTENT']){j.advance(s);if(s===state)break;}return j;}
test('RC53 Chromium trusted SELECT change reveals next persona; assignee precedes one execute',{timeout:35000},()=>withPhase2Browser(async page=>{
 const root=temp();try{
  await installPhase2Fixture(page,[{ticketId:id,description:after,gevo:'Anfrage Member'}]);await page.call(id=>showDetail(id),id);
  await page.call(()=>{const s=document.getElementById('mainForm:j_id7870'),old=s.onchange;window._nativeSelect=[];
   s.onchange=e=>{_nativeSelect.push(e.isTrusted);if(e.isTrusted)old(e);};
   s.value='FORWARD_TO_REVIEW';s.dispatchEvent(new Event('change',{bubbles:true}));s.value='';});
  assert.equal(await page.eval('getComputedStyle(document.getElementById("mainForm:next-persona-assignment-id")).display'),'none');
  const j=journalAt(root,'TICKET_SAVE_VERIFIED');const result=await finishPhase2Route(page,{ticketId:id,journal:j,ask:noAsk,route:'REVIEW'});
  assert.equal(result.status,'ROUTED_VERIFIED');assert.deepEqual(await page.eval('_nativeSelect'),[false,true]);
  const order=await page.eval('_order');assert(order.indexOf('suggestion:mainForm:next-persona-assignment-id')<order.indexOf('review'));
  assert.equal(await page.eval('_counts.review'),1);assert.equal(await page.eval('_counts.direct'),0);assert.equal(await page.eval('_counts.send'),0);
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));
test('RC53 Chromium description persists in blur-only ICEfaces model and then direct assignee is selected',{timeout:40000},()=>withPhase2Browser(async page=>{
 const root=temp();try{
  await installPhase2Fixture(page,[{ticketId:id,description:before}]);
  await page.call(()=>{const original=showDetail;window._blurNative=false;window.showDetail=id=>{
   original(id);const f=document.getElementById('additional'),t=_server.find(t=>t.ticketId===id);let bound=f.value,typed=false;
   f.oninput=e=>{typed=e.isTrusted;};f.onblur=e=>{if(typed&&e.isTrusted){bound=f.value;_blurNative=true;}};
   document.getElementById('save-ticket').onclick=e=>{e.preventDefault();if(!e.isTrusted)return;_counts.save++;
    const snapshot={description:bound,gevo:document.getElementById('mainForm:gevo-value-id').value};setTimeout(()=>{Object.assign(t,snapshot);showQueue();},850);};
  };});
  const result=await handlePhase2Work({root,page,row:(await readPhase2Queue(page)).rows[0],mapping:mapping(),ask:noAsk,log:()=>{}});
  assert.equal(result.status,'ROUTED_VERIFIED');assert.equal(await page.eval('_blurNative'),true);assert.equal(await page.eval('_server[0].description'),after);
  assert.equal(await page.eval('_routeInfo[0].field'),'mainForm:persona-assignment-id');assert.equal(await page.eval('_counts.save'),1);
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));
test('RC53 Chromium failed RC52 DB save can repair only original description after explicit no-route review',{timeout:40000},()=>withPhase2Browser(async page=>{
 const root=temp();try{
  const j=journalAt(root,'TICKET_SAVE_INTENT');j.observe('TICKET_SAVE_AUTO_CLICK_INTENT');const prefix=j.read().events;
  await installPhase2Fixture(page,[{ticketId:id,description:before}]);const row=(await readPhase2Queue(page)).rows[0];
  assert.equal(choosePhase2Candidate([row],{getWorkJournal:()=>j.read()}).row.ticketId,id);
  let prompts=0;const result=await handlePhase2Work({root,page,row,mapping:mapping(),ask:async q=>{assert(q.includes('NICHT_GESPEICHERT_'+id));prompts++;return 'NICHT_GESPEICHERT_'+id;},log:()=>{}});
  assert.equal(result.status,'ROUTED_VERIFIED');assert.equal(prompts,1);assert.deepEqual(j.read().events.slice(0,prefix.length),prefix);
  assert.equal(j.read().events.filter(e=>e.state==='SAVE_REPAIR_AUTHORIZED').length,1);assert.equal(await page.eval('_counts.save'),1);
  assert.equal(await page.eval('_counts.send'),0);assert.equal(await page.eval('_counts.draft'),0);
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));
test('RC53 Chromium saved REVIEW_INTENT resumes assignment only, no save or PDF replay',{timeout:30000},()=>withPhase2Browser(async page=>{
 const root=temp();try{
  const j=journalAt(root,'REVIEW_INTENT');await installPhase2Fixture(page,[{ticketId:id,description:after,gevo:'Anfrage Member'}]);
  const r=await handlePhase2Work({root,page,row:(await readPhase2Queue(page)).rows[0],mapping:mapping(),ask:noAsk,log:()=>{}});
  assert.equal(r.status,'ROUTED_VERIFIED');assert.equal(await page.eval('_counts.save'),0);assert.equal(await page.eval('_counts.direct'),1);assert.equal(await page.eval('_counts.upload'),0);
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));
test('RC53 Chromium wrong description or declined repair never overwrites or forwards',{timeout:25000},()=>withPhase2Browser(async page=>{
 const root=temp();try{
  const j=journalAt(root,'TICKET_SAVE_INTENT');await installPhase2Fixture(page,[{ticketId:id,description:before}]);
  await assert.rejects(()=>handlePhase2Work({root,page,row:(()=>({ticketId:id,descriptionValue:before}))(),mapping:mapping(),ask:async()=>'',log:()=>{}}),e=>e.code==='P2_WORK_REPAIR_DECLINED');
  assert.equal(await page.eval('_counts.save'),0);assert.equal(await page.eval('_counts.direct'),0);
  await assert.rejects(()=>commitDescription(page,{ticketId:id,expected:'new',allowedBefore:['foreign']}),e=>e.code==='DESCRIPTION_CONFLICT');
  assert.equal(j.read().events.filter(e=>e.state==='SAVE_REPAIR_AUTHORIZED').length,0);
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));
