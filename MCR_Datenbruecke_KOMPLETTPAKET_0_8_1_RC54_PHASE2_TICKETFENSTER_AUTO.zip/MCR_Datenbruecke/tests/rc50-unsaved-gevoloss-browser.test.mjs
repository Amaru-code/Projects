/** RC50: live incident: GEVO verified in unsaved RC48 editor disappears after
 * reopening. The attachment/save journal survives, and only the missing GEVO
 * can be reselected after a new independent approval. */
import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
import {phase2Journal} from '../lib/phase2-write-journal.mjs';
import {recoverUnsavedPhase2Gevo,phase2FieldSnapshot} from '../lib/phase2-comarch-actions.mjs';
const init={ticketId:'87278094',descriptionSha256:'a'.repeat(64),pdfHashes:[{plan:'DC',sha256:'b'.repeat(64)},{plan:'PP+',sha256:'c'.repeat(64)}]};
function pending(){const root=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC50-JOURNAL-'));
 const j=phase2Journal(root,init.ticketId,{initial:init});j.begin();
 for(const s of ['UPLOAD_INTENT','UPLOAD_VERIFIED','GEVO_INTENT','GEVO_VERIFIED','DESCRIPTION_INTENT','DESCRIPTION_VERIFIED','DRAFT_SAVE_INTENT','DRAFT_SAVE_VERIFIED','TICKET_SAVE_INTENT'])j.advance(s);
 return {root,j,clean:()=>fs.rmSync(root,{recursive:true,force:true})};}
async function withPage(fn){const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC20-NOTE-RC50-'));let browser,cdp;
 try{browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,extraArgs:process.platform==='linux'?['--no-sandbox','--disable-dev-shm-usage']:[]});
 ({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.url==='about:blank');return await fn(page);
 }finally{await cleanupTemporaryTestBrowser({profile,browser,cdp});}}
const html=async(page,value='')=>page.call(function(v){document.body.innerHTML=`<style>#g{margin:150px 10px;width:320px;height:40px}</style><input type="text" id="mainForm:gevo-value-id" value="${v}"/><button>Ticket speichern</button>`;},value);
test('RC50 actual regression: reload cleared GEVO, reselect once and retain prior journal for one save',{timeout:35000},async()=>withPage(async page=>{
 const f=pending();try{
  await page.call(()=>{document.body.innerHTML='<input id="mainForm:gevo-value-id" value="Anfrage Member"><button>Ticket speichern</button>';});
  assert.equal((await phase2FieldSnapshot(page)).gevo.value,'Anfrage Member');
  // COMARCH replaces the unsaved editor when opening a ticket anew.
  await page.call(()=>{document.body.innerHTML='<input id="mainForm:gevo-value-id" value=""><button>Ticket speichern</button>';});
  assert.equal((await phase2FieldSnapshot(page)).gevo.value,'');
  assert.equal(f.j.mayRecoverTicketSave(init),true);
  f.j.approveTicketSaveRecovery({...init,operatorConfirmed:true,noPriorClick:true,ticketUnchanged:true,attachmentsReviewed:true,notForwarded:true});
  let intent=0,selected=0;
  const r=await recoverUnsavedPhase2Gevo(page,{
   beforeRepair:async(v)=>{assert.equal(v,'');intent++;f.j.recordTicketSaveGevoRepairIntent({observedValue:v});},
   manualSelect:async()=>{selected++;}
  });
  assert.equal(r.status,'REPAIRED_IN_EDITOR');assert.equal(intent,1);assert.equal(selected,1);
  f.j.recordTicketSaveGevoRepairVerified();
  assert.equal((await phase2FieldSnapshot(page)).gevo.value,'Anfrage Member');
  assert.equal(f.j.read().state,'TICKET_SAVE_INTENT');
  assert.equal(f.j.mayRecoverTicketSave(init),false);
  assert.deepEqual(f.j.read().events.slice(-3).map(x=>x.state),[
   'TICKET_SAVE_RECOVERY_OPERATOR_AUTHORIZED','TICKET_SAVE_RECOVERY_GEVO_INTENT','TICKET_SAVE_RECOVERY_GEVO_VERIFIED']);
  assert.equal((await recoverUnsavedPhase2Gevo(page)).modified,false,'do not re-write when value already correct');
  f.j.advance('TICKET_SAVE_VERIFIED');
  assert.equal(f.j.read().events.filter(x=>x.state==='GEVO_VERIFIED').length,1,'old audit kept intact');
 }finally{f.clean();}
}));
test('RC50 already saved GEVO remains unchanged; no new journal event',{timeout:35000},async()=>withPage(async page=>{
 await page.call(()=>{document.body.innerHTML='<input id="mainForm:gevo-value-id" value="Anfrage Member">';});
 const f=pending();try{const old=fs.readFileSync(f.j.file);const r=await recoverUnsavedPhase2Gevo(page,{beforeRepair:async()=>{throw Error('Cannot re-write exact value');}});
 assert.equal(r.status,'ALREADY_EXACT');assert.equal(r.modified,false);assert.deepEqual(fs.readFileSync(f.j.file),old);
 }finally{f.clean();}
}));
test('RC50 conflicting GEVO never silently overwritten and never journals edit intent',{timeout:35000},async()=>withPage(async page=>{
 await page.call(()=>{document.body.innerHTML='<input id="mainForm:gevo-value-id" value="Anderer Antrag">';});
 const f=pending();try{let writes=0;
 await assert.rejects(()=>recoverUnsavedPhase2Gevo(page,{beforeRepair:()=>writes++}),e=>e.code==='P2_SAVE_GEVO_CONFLICT');
 assert.equal(writes,0);assert.equal((await phase2FieldSnapshot(page)).gevo.value,'Anderer Antrag');
 }finally{f.clean();}
}));
test('RC50 restart after GEVO repair intent cannot authorize a second attempt',()=>{
 const f=pending();try{f.j.approveTicketSaveRecovery({...init,operatorConfirmed:true,noPriorClick:true,ticketUnchanged:true,attachmentsReviewed:true,notForwarded:true});
 f.j.recordTicketSaveGevoRepairIntent({observedValue:''});
 assert.equal(f.j.mayRecoverTicketSave(init),false);
 assert.throws(()=>f.j.recordTicketSaveGevoRepairIntent({observedValue:''}),e=>e.code==='P2_SAVE_GEVO_REPAIR_REPLAY');
 assert.equal(f.j.read().events.at(-1).state,'TICKET_SAVE_RECOVERY_GEVO_INTENT');
 }finally{f.clean();}
});
test('RC50 journal rejects repair without explicit prior save recovery authorization',()=>{
 const f=pending();try{assert.throws(()=>f.j.recordTicketSaveGevoRepairIntent({observedValue:''}),e=>e.code==='P2_SAVE_GEVO_REPAIR_REPLAY');}
 finally{f.clean();}
});
