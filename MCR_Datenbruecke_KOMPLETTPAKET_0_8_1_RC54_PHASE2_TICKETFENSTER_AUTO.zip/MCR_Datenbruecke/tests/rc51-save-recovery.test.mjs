import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';
import {phase2Journal} from '../lib/phase2-write-journal.mjs';
const init={ticketId:'87278094',descriptionSha256:'a'.repeat(64),pdfHashes:[{plan:'DC',sha256:'b'.repeat(64)},{plan:'PP+',sha256:'c'.repeat(64)}]};
function pending({geVoRepair=true}={}){const root=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC51-JOURNAL-'));
 const j=phase2Journal(root,init.ticketId,{initial:init});j.begin();
 for(const s of ['UPLOAD_INTENT','UPLOAD_VERIFIED','GEVO_INTENT','GEVO_VERIFIED','DESCRIPTION_INTENT','DESCRIPTION_VERIFIED','DRAFT_SAVE_INTENT','DRAFT_SAVE_VERIFIED','TICKET_SAVE_INTENT'])j.advance(s);
 j.approveTicketSaveRecovery({...init,operatorConfirmed:true,noPriorClick:true,ticketUnchanged:true,attachmentsReviewed:true,notForwarded:true});
 if(geVoRepair){j.recordTicketSaveGevoRepairIntent({observedValue:''});j.recordTicketSaveGevoRepairVerified();}
 return {j,done:()=>fs.rmSync(root,{recursive:true,force:true})};}

test('RC51 original RC50 open save can be reconciled only once after independent non-persistence review',()=>{
 const {j,done}=pending();try{
  assert.equal(j.mayRecoverTicketSave(init),false);
  assert.equal(j.mayRecoverRc50UnconfirmedSave(init),true);
  assert.throws(()=>j.approveRc50UnconfirmedSave({...init,operatorConfirmed:true,notForwarded:true,attachmentsReviewed:true,ticketUnchanged:true}),
   e=>e.code==='P2_RC51_SAVE_RECOVERY_BLOCKED');
  const before=j.read().events.length;
  j.approveRc50UnconfirmedSave({...init,operatorConfirmed:true,noPersistedSave:true,ticketUnchanged:true,attachmentsReviewed:true,notForwarded:true});
  assert.equal(j.read().events.length,before+1);assert.equal(j.mayRecoverRc50UnconfirmedSave(init),false);
  j.recordRc51GevoRepairIntent({observedValue:''});j.recordRc51GevoRepairVerified();
  assert.throws(()=>j.recordRc51GevoRepairIntent({observedValue:''}),e=>e.code==='P2_RC51_GEVO_REPAIR_REPLAY');
  j.recordTicketSaveAutoClickIntent();
  assert.throws(()=>j.recordTicketSaveAutoClickIntent(),e=>e.code==='P2_SAVE_AUTO_REPLAY');
  j.recordTicketSaveNetworkObservation({status:'NETWORK_QUIET',writeStarts:1});
  assert.equal(j.read().state,'TICKET_SAVE_INTENT','a click alone never verifies save');
  assert.equal(j.read().events.at(-1).serverSaved,false);
  j.advance('TICKET_SAVE_VERIFIED');assert.equal(j.read().state,'TICKET_SAVE_VERIFIED');
 }finally{done();}
});

test('RC51 conflicting, foreign, already manually clicked or previously completed save never retries',()=>{
 const f=pending();try{
  assert.equal(f.j.mayRecoverRc50UnconfirmedSave({...init,ticketId:'99999999'}),false);
  assert.equal(f.j.mayRecoverRc50UnconfirmedSave({...init,descriptionSha256:'d'.repeat(64)}),false);
  f.j.recordTicketSaveManualIntent();assert.equal(f.j.mayRecoverRc50UnconfirmedSave(init),false);
 }finally{f.done();}
 const g=pending({geVoRepair:false});try{
  g.j.advance('TICKET_SAVE_VERIFIED');assert.equal(g.j.mayRecoverRc50UnconfirmedSave(init),false);
 }finally{g.done();}
});

test('RC51 save intent cannot be retried automatically after unknown save response',()=>{
 const f=pending();try{
  f.j.approveRc50UnconfirmedSave({...init,operatorConfirmed:true,noPersistedSave:true,ticketUnchanged:true,attachmentsReviewed:true,notForwarded:true});
  f.j.recordTicketSaveAutoClickIntent();
  f.j.recordTicketSaveNetworkObservation({status:'NO_WRITE_SIGNAL',writeStarts:0});
  assert.equal(f.j.read().state,'TICKET_SAVE_INTENT');
  assert.equal(f.j.mayRecoverRc50UnconfirmedSave(init),false);
  assert.throws(()=>f.j.recordTicketSaveNetworkObservation({status:'NO_WRITE_SIGNAL'}),e=>e.code==='P2_SAVE_NETWORK_JOURNAL');
 }finally{f.done();}
});

test('RC51 already server-persisted RC50 ticket is reconciled without another save click',()=>{
 const f=pending();try{
  assert.throws(()=>f.j.approveRc50PersistedSave({...init,operatorConfirmed:true,serverDescriptionVerified:true,
   serverGevoVerified:false,attachmentsReviewed:true,notForwarded:true}),e=>e.code==='P2_RC51_SAVED_RECONCILIATION_BLOCKED');
  f.j.approveRc50PersistedSave({...init,operatorConfirmed:true,serverDescriptionVerified:true,
   serverGevoVerified:true,attachmentsReviewed:true,notForwarded:true});
  assert.equal(f.j.read().events.at(-1).clickedAgain,false);
  assert.equal(f.j.mayRecoverRc50UnconfirmedSave(init),false);
  // The server proof reconciles the existing save; never a synthetic click event.
  f.j.advance('TICKET_SAVE_VERIFIED');assert.equal(f.j.read().state,'TICKET_SAVE_VERIFIED');
  assert(!f.j.read().events.some(e=>e.state==='TICKET_SAVE_AUTO_CLICK_INTENT'));
 }finally{f.done();}
});
