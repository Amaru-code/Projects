import test from 'node:test';import assert from 'node:assert/strict';
import {DeliveryGate} from '../lib/delivery-console.mjs';
import {bodyMatchesRouteAction,assessRouteListReceipt,assessRouteNotices} from '../lib/phase2-route-receipt.mjs';
import {phase2WorkRule,PRIVATE_MBC_REQUEST,MBC_PRIVATE_PARAGRAPHS,privateMbcDraft} from '../lib/phase2-work-rules.mjs';
const msg=(event,more={})=>({schema:'MCR_CONTROL_V1',event,...more});
test('RC54 one action per ticket: stale or foreign approval cannot authorize next card',()=>{
 const g=new DeliveryGate(),a=g.request('87316993',{action:'FORWARD_DIRECT'});
 assert.equal(g.lease(),null);g.accept(msg('approve',{ticket:a.ticket,challenge:a.challenge}));const lease=g.lease();g.consume(lease);
 assert.throws(()=>g.consume(lease));const b=g.request('87278094',{action:'FORWARD_REVIEW'});
 assert.equal(g.accept(msg('approve',{ticket:a.ticket,challenge:a.challenge})),false);assert.equal(g.lease(),null);
 g.accept(msg('approve',{ticket:b.ticket,challenge:b.challenge}));g.consume(g.lease());assert.equal(g.lease(),null);
});
test('RC54 AUTO authorizes next action, but can NEVER certify unknown post-click result',()=>{
 const g=new DeliveryGate();g.accept(msg('mode',{mode:'AUTO'}));g.request('87316993',{action:'FORWARD_DIRECT'});assert(g.lease());g.consume(g.lease());
 const r=g.request('87316993',{manualOnly:true,action:'VERIFY_ROUTED'});assert.equal(g.lease(),null);
 g.accept(msg('mode',{mode:'MANUAL'}));g.accept(msg('mode',{mode:'AUTO'}));assert.equal(g.lease(),null);
 g.accept(msg('approve',{ticket:r.ticket,challenge:r.challenge}));g.consume(g.lease());assert.equal(g.lease(),null);
});
test('RC54 toggling back to MANUAL or STOP revokes an unconsumed automatic action',()=>{
 const g=new DeliveryGate('AUTO');g.request('87316993');const l=g.lease();g.accept(msg('mode',{mode:'MANUAL'}));assert.throws(()=>g.consume(l));
 g.accept(msg('abort'));assert.equal(g.lease(),null);assert.throws(()=>g.request('87278094'));
});
test('RC54 post must name exact routing action; blur, background and different action do not count',()=>{
 const id='mainForm:j_id7894';
 for(const b of ['ice.event.target='+encodeURIComponent(id),'mainForm%3A_idcl='+encodeURIComponent(id),encodeURIComponent(id)+'=Schritt+ausf%C3%BChren'])assert(bodyMatchesRouteAction(b,id));
 for(const b of ['ice.event.target=mainForm%3Agevo-value-id','other='+encodeURIComponent(id),'ice.event.target='+encodeURIComponent(id+'0'),'','{ "action":"'+id+'" }'])assert(!bodyMatchesRouteAction(b,id));
});
function receipt(){const before={ok:true,ids:['87316993','87278094'],errors:0,context:{tableId:'MY_TASKS',page:'1',filter:''}};const after={...structuredClone(before),ids:['87278094']};return {ticketId:'87316993',before,after,refreshed:structuredClone(after),post:{ok:true,matchedPosts:1},actionBound:true};}
test('RC54 correlated route POST plus stable fresh same-context list removal is automatic evidence',()=>{assert.equal(assessRouteListReceipt(receipt()).source,'BOUND_ROUTE_POST_AND_FRESH_SAME_LIST');});
test('RC54 missing row alone, changed filter/page, other missing rows, errors and failed POST never certify route',()=>{
 for(const mutate of [x=>x.post.ok=false,x=>x.actionBound=false,x=>x.after.context.page='2',x=>x.refreshed.context.filter='changed',x=>x.after.ids=[],x=>x.refreshed.ids.push('87316993'),x=>x.after.errors=1,x=>x.before.ids=['87278094']]){const x=receipt();mutate(x);assert(!assessRouteListReceipt(x).ok);}
});
test('RC54 fresh success must name exact account; foreign recipient or error is a contradiction',()=>{
 const good='Weiterleitung erfolgreich an Baindl Mark (mark.baindl) 87316993';assert(assessRouteNotices([], [good], '87316993').ok);
 assert(!assessRouteNotices([good],[good],'87316993').ok);
 assert(assessRouteNotices([],['Weiterleitung erfolgreich an Victor (victor.gutierrez)'],'87316993').contradiction);
 assert(assessRouteNotices([],['Weiterleitung nicht erfolgreich'],'87316993').contradiction);
 assert(!assessRouteNotices([],['Weiterleitung erfolgreich'],'87316993').ok);
});
test('RC54 MBC accepts exactly the two requested Email/E-Mail spellings; physical line and DB precedence remain',()=>{
 const row=line=>({ticketId:'87278096',descriptionValue:'USC 100/ DC\nStandardantwort versendet\n'+line});
 for(const line of [PRIVATE_MBC_REQUEST,'Möchte Log-in MBC mit privater Email'])assert.equal(phase2WorkRule(row(line)).kind,'MBC_PRIVATE_EMAIL');
 for(const line of ['Möchte Log-in MBC mit privater Email bitte','Möchte Log-in MBC mit dienstlicher Email'])assert.notEqual(phase2WorkRule(row(line)).kind,'MBC_PRIVATE_EMAIL');
 assert.equal(phase2WorkRule({ticketId:'87278096',descriptionValue:'USC 100/ DB+\nStandardantwort versendet\n'+PRIVATE_MBC_REQUEST}).kind,'DB_DIRECT');
 assert.notEqual(phase2WorkRule({ticketId:'87278096',descriptionValue:'USC 100/ DC\n\nStandardantwort versendet\n'+PRIVATE_MBC_REQUEST}).kind,'MBC_PRIVATE_EMAIL');
 assert.equal(privateMbcDraft({lastName:'Mustermann',gender:'M'}),'Sehr geehrter Herr Mustermann,\n\n'+MBC_PRIVATE_PARAGRAPHS.join('\n\n'));
});
