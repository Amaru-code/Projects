import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import http from 'node:http';import {EventEmitter} from 'node:events';
import {temp,putActive,mapping} from './helpers.mjs';
import {withPhase2Browser,installPhase2Fixture} from './rc52-browser-fixture.mjs';
import {phase2Run} from '../src/phase2-run.mjs';import {createPhase2TicketConsole} from '../lib/phase2-ticket-console.mjs';
import {finishPhase2Route} from '../lib/phase2-review-flow.mjs';import {phase2WorkJournal} from '../lib/phase2-work-journal.mjs';
import {selectExactPhase2Mark,exactPhase2Assignee,exactMarkSuggestion} from '../lib/phase2-assignee.mjs';
import {openPhase2Ticket} from '../lib/phase2-navigation.mjs';import {privateMbcDraft} from '../lib/phase2-work-rules.mjs';
const member=async()=>({profileVerified:true,profile:{first:'Max',last:'Mustermann',mercerId:'99900001'},wwid:'11368989'});
const noAsk=async q=>{throw Error('UNEXPECTED_TERMINAL: '+q);};
function controller(records,{autoAfterFirst=true}={}){
 let child;const respond=m=>queueMicrotask(()=>child.stdout.emit('data',JSON.stringify({schema:'MCR_CONTROL_V1',...m})+'\n'));
 const launcher=()=>{
  child=new EventEmitter();child.stdout=new EventEmitter();child.stdout.setEncoding=()=>{};child.unref=()=>{};child.kill=()=>{};
  child.stdin=new EventEmitter();child.stdin.writable=true;child.stdin.end=()=>{};
  child.stdin.write=line=>{const m=JSON.parse(line);records.push(m);
   if(m.event==='suspend')respond({event:'hidden',seq:m.seq});
   if(m.event==='approval'&&(m.manualOnly||m.mode==='MANUAL'))respond({event:'approve',ticket:m.ticket,challenge:m.challenge});
   if(m.event==='ticket_complete'&&autoAfterFirst)respond({event:'mode',mode:'AUTO'});
  };respond({event:'ready'});return child;
 };
 return options=>createPhase2TicketConsole({...options,platform:'win32',env:{},launcher});
}
// This environment blocks browser URLs by managed policy. Keep that policy
// intact. The DOM/input flow below runs in real Chromium; action-specific
// Network events are an explicit MODEL, emitted only after a trusted click.
function modelActionNetwork(page){
 const on=page.cdp.on.bind(page.cdp),send=page.cdp.send.bind(page.cdp),listeners=new Map();let observed=0;
 page.cdp.on=(method,fn)=>{
  const off=on(method,fn);if(!listeners.has(method))listeners.set(method,new Set());listeners.get(method).add(fn);
  return ()=>{off();listeners.get(method)?.delete(fn);};
 };
 const emit=(method,p)=>{for(const f of listeners.get(method)||[])f(p,page.sessionId);};
 page.cdp.send=async(method,params={},...rest)=>{
  const result=await send(method,params,...rest);
  if(method==='Input.dispatchMouseEvent'&&params.type==='mouseReleased'){
   const info=await page.eval('({count:window._routeInfo?.length||0,last:window._routeInfo?.at(-1)})');
   if(info.count>observed){observed=info.count;const action=info.last.kind==='review'?'mainForm:j_id7894':'mainForm:current-performer-assign-link';
    const requestId='MODEL_ROUTE_'+observed;
    emit('Network.requestWillBeSent',{requestId,request:{url:'about:blank',method:'POST',postData:'ice.event.target='+encodeURIComponent(action)}});
    emit('Network.responseReceived',{requestId,response:{status:200}});emit('Network.loadingFinished',{requestId});
   }
  }
  return result;
 };
 return ()=>{page.cdp.send=send;page.cdp.on=on;};
}
test('RC54 Chromium Menu12 with MODELLED action-network receipts: manual DB then AUTO MBC Email, independent cards, exact next-persona, no terminal route prompts or mail',{timeout:70000},()=>withPhase2Browser(async page=>{
 const root=temp();putActive(root);const restore=modelActionNetwork(page);try{
  await installPhase2Fixture(page,[{ticketId:'87316993',description:'USC 100/ DB+\nStandardantwort versendet'},{ticketId:'87278096',description:'USC 100/ DC\nStandardantwort versendet\nMöchte Log-in MBC mit privater Email'}],{silentRoute:true});
  const records=[],prompts=[];
  const result=await phase2Run({root,session:{page,rl:{}},memberLookup:member,log:()=>{},consoleFactory:controller(records),askFn:async(_r,q)=>{
   prompts.push(q);if(q.startsWith('Start-Ticket'))return '';if(q.includes('Weiterleitung starten?'))return 'START';throw Error('TERMINAL:'+q);
  }});
  assert.equal(result.processed,2);assert.equal(prompts.length,2);
  assert.deepEqual(result.receipts.map(x=>x.evidence),['BOUND_ROUTE_POST_AND_FRESH_SAME_LIST','BOUND_ROUTE_POST_AND_FRESH_SAME_LIST']);
  assert.deepEqual(records.filter(x=>x.event==='ticket_start').map(x=>x.ticket),['87316993','87278096']);
  assert.deepEqual(records.filter(x=>x.event==='ticket_complete').map(x=>x.ticket),['87316993','87278096']);
  const approvals=records.filter(x=>x.event==='approval');assert.deepEqual(approvals.map(x=>x.mode),['MANUAL','AUTO']);assert(approvals.every(x=>!x.manualOnly));
  assert.deepEqual(await page.eval('_routeInfo.map(x=>x.field)'),['mainForm:persona-assignment-id','mainForm:next-persona-assignment-id']);
  assert.equal((await page.eval('_server[1].draft')).replace(/\n{3,}/g,'\n\n'),privateMbcDraft({lastName:'Mustermann',gender:'M'}));
  assert.equal(await page.eval('_counts.send'),0);assert.equal(await page.eval('_counts.draft'),1);
  assert.equal(phase2WorkJournal(root,'87278096').read().state,'ROUTED_VERIFIED');
 }catch(e){console.log('RC54_BROWSER_DIAG',await page.eval('JSON.stringify({counts:_counts,server:_server,routes:_routeInfo,error:window._routeError,href:location.href})'));throw e;}finally{restore();fs.rmSync(root,{recursive:true,force:true});}
}));
function journal(root,id){const j=phase2WorkJournal(root,id);j.begin({rule:'DB_DIRECT',descriptionBefore:'USC 100/ DB+\nStandardantwort versendet',descriptionAfter:'USC 100/ DB+\nStandardantwort versendet\nBearbeitet not reviewed'});for(const s of ['EDIT_INTENT','EDIT_VERIFIED','TICKET_SAVE_INTENT','TICKET_SAVE_VERIFIED'])j.advance(s);return j;}
test('RC54 exact next-persona selection retries a replaced wrong value; current performer remains untouched',{timeout:30000},()=>withPhase2Browser(async page=>{
 await installPhase2Fixture(page,[{ticketId:'87278094',description:'USC 100/ DC',gevo:'Anfrage Member'}]);await page.call(()=>{showDetail('87278094');const f=document.getElementById('mainForm:next-persona-assignment-id');f.style.display='block';
  document.getElementById('mainForm:persona-assignment-id').value='Unveraenderter Bearbeiter';const fn=f.onkeyup;window._badOnce=false;
  f.onkeyup=e=>{fn(e);const s=document.querySelector('.suggestion');const click=s.onclick;s.onclick=e=>{if(!_badOnce&&e.isTrusted){_badOnce=true;f.value='Falscher Bearbeiter (wrong.user)';s.remove();}else click(e);};};});
 const logs=[];await selectExactPhase2Mark(page,{fieldId:'mainForm:next-persona-assignment-id',log:s=>logs.push(s)});
 assert((await exactPhase2Assignee(page,'mainForm:next-persona-assignment-id')).ok);assert(logs.some(x=>x.includes('P2_PRUEFER_NICHT_UEBERNOMMEN')));
 assert.equal(await page.eval('document.getElementById("mainForm:persona-assignment-id").value'),'Unveraenderter Bearbeiter');assert.equal(await page.eval('_counts.review'),0);
}));
test('RC54 assignee changed while waiting for manual approval blocks execute and retains journal',{timeout:20000},()=>withPhase2Browser(async page=>{
 const root=temp();try{const id='87316993',j=journal(root,id);await installPhase2Fixture(page,[{ticketId:id,description:j.read().descriptionAfter,gevo:'Anfrage Member'}]);await page.call(id=>showDetail(id),id);
  await assert.rejects(()=>finishPhase2Route(page,{ticketId:id,journal:j,route:'REVIEW',ask:noAsk,controls:{authorize:async()=>page.call(()=>document.getElementById('mainForm:next-persona-assignment-id').value='Wrong Person (wrong.user)')}}),e=>e.code==='P2_ROUTE_CHANGED');
  assert.equal(await page.eval('_counts.review'),0);assert.equal(j.read().state,'REVIEW_VERIFIED');
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));
test('RC54 silent route with NO matched POST uses one post-check button rather than inventing automatic success',{timeout:20000},()=>withPhase2Browser(async page=>{
 const root=temp();try{const id='87316993',j=journal(root,id);await installPhase2Fixture(page,[{ticketId:id,description:j.read().descriptionAfter,gevo:'Anfrage Member'}],{silentRoute:true});await page.call(id=>showDetail(id),id);
  let before=0,after=0;const result=await finishPhase2Route(page,{ticketId:id,journal:j,route:'DIRECT',ask:noAsk,controls:{authorize:async()=>{before++;},verifyRoute:async()=>{after++;return {ok:true,source:'OPERATOR_BUTTON_VERIFIED_IN_COMARCH'};}}});
  assert.equal(before,1);assert.equal(after,1);assert.equal(result.evidence,'OPERATOR_BUTTON_VERIFIED_IN_COMARCH');assert.equal(await page.eval('_counts.direct'),1);
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));
test('RC54 Menu5 navigation binds exact Ticket-ID column for own and queue lists, not repeated reference text',{timeout:20000},()=>withPhase2Browser(async page=>{
 await installPhase2Fixture(page,[{ticketId:'88149870',description:'USC 1/ DC'}],{duplicateReference:true});
 await openPhase2Ticket(page,{ticketId:'88149870'});assert.equal(await page.eval('_counts.open'),1);
 await page.call(()=>{showQueue();document.getElementById('mainForm:tasksTableFor_MyTasksList').id='mainForm:tasksTableFor_MyQueuesTasksList';});
 await openPhase2Ticket(page,{ticketId:'88149870'},{scope:'WARTESCHLANGE_INTL01'});assert.equal(await page.eval('_counts.open'),2);
}));
test('RC54 existing full server-rendered Mark assignment is retained, while name-only or duplicate fields are not accepted',{timeout:12000},()=>withPhase2Browser(async page=>{
 await page.call(()=>{document.body.innerHTML='<input id="mainForm:next-persona-assignment-id" value="Baindl Mark (mark.baindl)">';});
 const r=await selectExactPhase2Mark(page,{fieldId:'mainForm:next-persona-assignment-id'});assert.equal(r.method,'EXISTING_EXACT_SERVER_FIELD');
 await page.call(()=>document.getElementById('mainForm:next-persona-assignment-id').value='Baindl Mark');assert(!(await exactPhase2Assignee(page,'mainForm:next-persona-assignment-id')).ok);
 await page.call(()=>{document.getElementById('mainForm:next-persona-assignment-id').value='Baindl Mark (mark.baindl)';document.body.append(document.querySelector('input').cloneNode(true));});assert(!(await exactPhase2Assignee(page,'mainForm:next-persona-assignment-id')).ok);
}));
