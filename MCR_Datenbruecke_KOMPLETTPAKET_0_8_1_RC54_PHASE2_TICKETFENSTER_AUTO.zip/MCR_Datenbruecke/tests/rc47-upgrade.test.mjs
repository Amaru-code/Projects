/** Independent qualification using the exact published RC46 ZIP from the Library.
 * External original ZIP is not shipped in the release. */
import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';
import {ROOT,temp,putActive,historyFixture} from './helpers.mjs';
import {sha256} from '../lib/core.mjs';import {readZip} from '../lib/zip.mjs';
import {VERSION,ledger,writeJSON} from '../lib/control.mjs';
import {verifyPrevious,verifyPackage,treeDigest} from '../tools/integrity.mjs';
import {planInstall,installSoftware,journals,restoreSoftware} from '../tools/deploy.mjs';
import {beginMigrationPriority} from '../lib/migration-priority.mjs';

const SOURCES=[
 {version:'0.8.1-rc.46',sha256:'f45e852afb7c04229caa49e48c385f55ebd67f0a62f69fbc6fcfae42ff97ffff'}
];
function original(source){
 const raw=historyFixture('complete-'+source.version+'.zip');assert.equal(sha256(raw),source.sha256);
 const parent=temp(),target=path.join(parent,'MCR_Datenbruecke');fs.mkdirSync(target);
 const zip=readZip(raw);
 for(const name of zip.names){
  assert(name.startsWith('MCR_Datenbruecke/'));
  const file=path.join(target,name.slice('MCR_Datenbruecke/'.length));
  fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,zip.get(name));
 }
 putActive(target);
 return {parent,target,clean:()=>fs.rmSync(parent,{recursive:true,force:true,maxRetries:5,retryDelay:100})};
}
for(const source of SOURCES){
 test('RC47 upgrade from original '+source.version+' and rollback preserve unresolved ticket actions and all user data',()=>{
  const f=original(source);try{
   const config=path.join(f.target,'config/local-runner-queue-send.json');
   const cfg=JSON.parse(fs.readFileSync(config));
   // The operator's profile differs from the packaged default: overwriting the
   // config with release bytes would invalidate this test, even if both default
   // configs happen to be byte-identical across versions.
   writeJSON(config,{...cfg,profileDirectory:'.runtime/operator-edge-profile',downloadDirectory:'.runtime/operator-downloads'});
   const profile=path.join(f.target,'.runtime/operator-edge-profile');fs.mkdirSync(profile,{recursive:true});
   fs.writeFileSync(path.join(profile,'sentinel'),'Existing browser profile must remain at this path');
   const phase2=path.join(f.target,'.runtime/phase2/actions/MCR_PHASE2_87278094.json');
   fs.mkdirSync(path.dirname(phase2),{recursive:true});
   writeJSON(phase2,{schema:'MCR_PHASE2_ACTION_JOURNAL_V1',ticketId:'87278094',state:'UPLOAD_INTENT',
    descriptionSha256:'a'.repeat(64),pdfHashes:[{plan:'DC',sha256:'b'.repeat(64)},{plan:'PP+',sha256:'c'.repeat(64)}],
    recoveryCount:1,events:[{state:'PREPARED'},{state:'GEVO_INTENT'},
     {state:'GEVO_FOCUS_RETRY_OPERATOR_AUTHORIZED'},{state:'UPLOAD_INTENT'}]});
   const phase1=ledger(f.target);phase1.begin('87422280','USC 10/ PP+');
   const oldRun=path.join(f.target,'.runtime/beta-control/last-run.json');
   writeJSON(oldRun,{schema:'MCR_BETA_RUN_V1',state:'STOP_REVIEW_REQUIRED',operation:'REAL_RUN',version:source.version});
   const protectedPaths=['private_data','config','.runtime/operator-edge-profile','.runtime/phase2',
    path.relative(f.target,phase1.file),path.relative(f.target,oldRun)];
   const before=Object.fromEntries(protectedPaths.map(p=>[p,treeDigest(path.join(f.target,p))]));
   const unchanged=()=>{for(const [p,digest] of Object.entries(before))assert.equal(treeDigest(path.join(f.target,p)),digest,p);};
   assert.equal(verifyPrevious(f.target).version,source.version);
   writeJSON(path.join(f.target,'.runtime/beta-control/operation.lock.json'),{
    schema:'MCR_OPERATION_LOCK_V1',operation:'PHASE2_COMARCH_PILOT',pid:1900909,token:'d'.repeat(48),createdAt:'2026-01-01T00:00:00.000Z'});
   const stop=()=>({schema:'MCR_PROCESS_GUARD_V1',checked:true,blockedCount:0,unknownCount:0,
    inspectedPids:[process.pid],inspectedProcesses:[{pid:process.pid,relation:'PROTECTED'}],stoppedProcesses:[]});
   const migration=beginMigrationPriority(planInstall(ROOT,f.target),{stop});let installed;
   try{installed=installSoftware(planInstall(ROOT,f.target,{migration}),{migration});}
   finally{migration.release();}
   assert.equal(installed.state,'COMPLETE');assert.equal(verifyPackage(f.target).version,VERSION);unchanged();
   assert.equal(installed.recoveredStaleLock,true);
   for(const file of ['.runtime/beta-control/operation.lock.json','.runtime/beta-control/migration-priority.json','BETA_UMSTELLUNG_LAEUFT.txt'])assert.equal(fs.existsSync(path.join(f.target,file)),false,file);
   assert.equal(ledger(f.target).pending.length,1);assert.equal(JSON.parse(fs.readFileSync(phase2)).state,'UPLOAD_INTENT');
   assert.throws(()=>ledger(f.target).begin('87422280','Do not repeat an unresolved send'),e=>e.code==='DUPLICATE_GUARD');
   assert.equal(restoreSoftware(journals(f.target)[0]).state,'ROLLED_BACK');
   assert.equal(verifyPrevious(f.target).version,source.version);unchanged();
  }finally{f.clean();}
 });
 test('RC47 rejects changed '+source.version+' process-guard bytes before installation changes',()=>{
  const f=original(source);try{
   fs.appendFileSync(path.join(f.target,'tools/process-guard.ps1'),'\n');
   const before=treeDigest(f.target);
   assert.throws(()=>planInstall(ROOT,f.target),e=>e.code==='PACKAGE_SIZE');
   assert.equal(treeDigest(f.target),before);assert.equal(fs.existsSync(path.join(f.parent,'_MCR_Archiv')),false);
  }finally{f.clean();}
 });
}
