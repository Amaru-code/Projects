import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import {execFileSync} from 'node:child_process';
import {splitWindowsCommandLine,classifyWindowsProcesses,processProof,sameProcessIdentity} from '../tools/process-policy.mjs';
import {windowsIdle,windowsStopForMigration} from '../tools/process-guard.mjs';
import {ROOT} from './helpers.mjs';

const root='C:\\Users\\Amaru-Zegarra\\projects\\Aktive_Projekte\\Ticket_bot\\MCR_Datenbruecke';
const profile=root+'\\.runtime\\edge-profile';
const source='C:\\Downloads\\RC46\\MCR_Datenbruecke';
const exe=name=>'C:\\Tools\\'+name;
const at=second=>'2026-11-03T12:00:'+String(second).padStart(2,'0')+'.0000000Z';
const proc=(pid,name,commandLine,{parentPid=10,createdAt=at(10),executablePath=exe(name)}={})=>({pid,parentPid,name,commandLine,createdAt,executablePath});
const node=(pid,entry,options={})=>proc(pid,'node.exe','"'+exe('node.exe')+'" "'+entry+'"',options);
const base=()=>[
 proc(4,'System',null,{parentPid:0,createdAt:at(0),executablePath:null}),
 proc(10,'explorer.exe','"C:\\Windows\\explorer.exe"',{parentPid:4,createdAt:at(1)}),
 proc(90,'cmd.exe','"C:\\Windows\\System32\\cmd.exe" /c "'+source+'\\START.cmd"',{parentPid:10,createdAt:at(2)}),
 node(100,source+'\\tools\\cli.mjs',{parentPid:90,createdAt:at(3)}),
 proc(101,'powershell.exe','powershell.exe -NoProfile -File "'+source+'\\tools\\process-guard.ps1"',{parentPid:100,createdAt:at(4)})
];
const snapshot=(additional=[])=>({schema:'MCR_WINDOWS_PROCESS_SNAPSHOT_V1',checked:true,processes:[...base(),...additional]});
const scope={root,profileDirectory:profile,excludePid:100};
const classify=s=>classifyWindowsProcesses(s,scope);
const proof=s=>processProof(classify(s));
const runtime={platform:'win32',profileDirectory:profile,excludePid:100};
const stopped=plan=>({schema:'MCR_MIGRATION_PROCESS_STOP_RESULT_V1',results:plan.targets.map(t=>({pid:t.pid,status:'STOPPED'}))});

test('RC46 quotes, spaces and Unicode Windows paths are parsed without losing file/profile boundaries',()=>{
 const args=splitWindowsCommandLine('"C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe" "--user-data-dir=C:\\Users\\Müller Example\\MCR_Datenbruecke\\.runtime\\edge-profile" --no-first-run');
 assert.deepEqual(args,['C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe','--user-data-dir=C:\\Users\\Müller Example\\MCR_Datenbruecke\\.runtime\\edge-profile','--no-first-run']);
 assert.equal(splitWindowsCommandLine('node.exe "C:\\broken path'),null);
});
test('RC46 foreign unreadable Edge/Node processes do not falsely block an otherwise idle bot',()=>{
 const s=snapshot([proc(200,'msedge.exe',null),proc(201,'node.exe',''),node(202,'C:\\OtherProject\\service.mjs')]);
 const p=windowsIdle(root,{...runtime,readSnapshot:()=>s});
 assert.equal(p.blockedCount,0);assert.equal(p.unknownCount,0);assert.equal(p.ignoredUnrelatedUnreadableCount,2);
 assert(p.inspectedPids.includes(200));assert.equal(p.inspectedProcesses.find(x=>x.pid===200).identityReadable,false);
 assert.equal(p.inspectedProcesses.find(x=>x.pid===202).identityReadable,true);
 assert.equal(p.inspectedProcesses.find(x=>x.pid===200).relation,'UNRELATED');
});
test('RC46 relative entries and unknown flags cannot prove that a live operation-lock owner is foreign',()=>{
 const s=snapshot([node(200,'tools\\cli.mjs'),node(201,'C:\\OtherProject\\service.mjs'),proc(202,'node.exe',null),
  proc(203,'node.exe','node.exe --new-unknown-flag tools\\cli.mjs'),
  proc(204,'node.exe','node.exe --new-unknown-flag "'+root+'\\tools\\cli.mjs"')]);
 const p=proof(s);
 for(const id of [200,202,203])assert.equal(p.inspectedProcesses.find(x=>x.pid===id).ownershipDecidable,false,String(id));
 assert.equal(p.inspectedProcesses.find(x=>x.pid===201).ownershipDecidable,true);
 assert.equal(p.inspectedProcesses.find(x=>x.pid===200).identityReadable,true);
 assert.equal(p.inspectedProcesses.find(x=>x.pid===204).relation,'UNKNOWN');
});
test('RC46 Explorer double-quoted START.cmd launchers are owned, but CMD chains and another root are not',()=>{
 const cmd='"C:\\Windows\\System32\\cmd.exe"';
 const s=snapshot([
  proc(200,'cmd.exe',cmd+' /c ""'+root+'\\START.cmd" "'),
  proc(201,'cmd.exe',cmd+' /d /s /c ""'+root+'\\START.cmd""'),
  proc(202,'cmd.exe',cmd+' /c "'+root+'\\START.cmd"'),
  proc(203,'cmd.exe',cmd+' /c ""'+root+'\\START.cmd" & notepad.exe"'),
  proc(204,'cmd.exe',cmd+' /c ""'+root+'_Other\\START.cmd" "'),
  proc(205,'cmd.exe',cmd+' /c "'+root+'\\START.cmd" > C:\\out.txt'),
  node(206,'tools\\cli.mjs',{parentPid:200,createdAt:at(11)})
 ]);
 const c=classify(s);assert.deepEqual(c.owned.map(x=>x.pid),[200,201,202,206]);
 assert.deepEqual(c.unknown.map(x=>x.pid),[203,205]);
 assert.equal(c.inspectedProcesses.find(x=>x.pid===204).ownershipDecidable,true);
 const unicodeRoot='C:\\Users\\Müller Example\\MCR_Datenbruecke';
 const u=classifyWindowsProcesses(snapshot([proc(207,'cmd.exe',cmd+' /c ""'+unicodeRoot+'\\START.cmd" "')]),
  {...scope,root:unicodeRoot,profileDirectory:unicodeRoot+'\\.runtime\\edge-profile'});
 assert.deepEqual(u.owned.map(x=>x.pid),[207]);
});
test('RC46 ownership uses actual node entry and exact browser profile, never a root substring or unrelated argument',()=>{
 const s=snapshot([
  node(200,root+'\\src\\local-bot-full-run.mjs'),
  proc(201,'msedge.exe','msedge.exe "--user-data-dir='+profile+'"'),
  node(202,root+'_Archiv\\tools\\cli.mjs'),
  proc(203,'msedge.exe','msedge.exe "--user-data-dir='+profile+'-other"'),
  proc(204,'node.exe','node.exe C:\\Other\\script.mjs "'+root+'\\tools\\cli.mjs"'),
  proc(205,'node.exe','node.exe -e "console.log(\''+root.replaceAll('\\','/')+'\')"'),
  proc(206,'msedge.exe','msedge.exe --profile-directory=Default https://example.invalid')
 ]);
 const c=classify(s);assert.deepEqual(c.owned.map(x=>x.pid),[200,201]);
 assert.deepEqual(c.unknown.map(x=>x.pid),[203]);
 assert.equal(c.unknown[0].reason,'EXACT_BROWSER_PROFILE');
});
test('RC46 multiple user-data-dir switches are ambiguous and never become a kill permission',()=>{
 const s=snapshot([proc(200,'msedge.exe','msedge.exe "--user-data-dir='+profile+'" --user-data-dir=C:\\Personal')]);
 assert.equal(proof(s).blockedCount,0);assert.equal(proof(s).unknownCount,1);
 let calls=0;assert.throws(()=>windowsStopForMigration(root,{...runtime,readSnapshot:()=>s,stopProcesses:()=>calls++}),e=>e.code==='MIGRATION_PROCESS_UNCLEAR');
 assert.equal(calls,0);
});
test('RC46 installer, ancestor chain and its own helpers are protected, while a separate old bot under the same explorer is owned',()=>{
 const s=snapshot([node(200,root+'\\tools\\cli.mjs',{parentPid:10}),node(102,root+'\\tools\\cli.mjs',{parentPid:100}),
  proc(103,'msedge.exe','msedge.exe "--user-data-dir='+profile+'"',{parentPid:102})]);
 const c=classify(s);assert.deepEqual(c.owned.map(p=>p.pid),[200]);
 for(const id of [4,10,90,100,101,102,103])assert(c.protectedPids.includes(id),String(id));
});
test('RC46 migration refuses a protected target-bot ancestor; it neither stops it nor certifies the target idle',()=>{
 const s=snapshot([node(200,root+'\\tools\\cli.mjs',{parentPid:10,createdAt:at(2)})]);
 s.processes.find(p=>p.pid===100).parentPid=200;
 assert.equal(proof(s).unknownCount,0);
 let calls=0;
 assert.throws(()=>windowsStopForMigration(root,{...runtime,readSnapshot:()=>s,stopProcesses:()=>calls++}),
  e=>e.code==='MIGRATION_PROCESS_UNCLEAR'&&e.processProof.unknownProcesses.some(p=>p.pid===200&&p.reason==='PROTECTED_TARGET_ANCESTOR'));
 assert.equal(calls,0);
});
test('RC46 verified descendants are included, but a reused parent PID cannot capture an older unrelated process',()=>{
 const s=snapshot([
  node(200,root+'\\tools\\cli.mjs',{createdAt:at(20)}),
  proc(201,'msedge.exe','msedge.exe --type=renderer',{parentPid:200,createdAt:at(21)}),
  proc(202,'helper.exe','helper.exe',{parentPid:201,createdAt:at(22)}),
  proc(203,'notepad.exe','notepad.exe',{parentPid:200,createdAt:at(5)})
 ]);
 assert.deepEqual(classify(s).owned.map(p=>p.pid),[200,201,202]);
 assert.equal(proof(s).inspectedProcesses.find(p=>p.pid===203).relation,'UNRELATED');
});
test('RC46 a truly related unreadable descendant blocks with its own PID instead of terminating blindly',()=>{
 const s=snapshot([node(200,root+'\\src\\local-bot-full-run.mjs'),
  proc(201,'msedge.exe',null,{parentPid:200,createdAt:null,executablePath:null})]);
 let calls=0;
 assert.throws(()=>windowsStopForMigration(root,{...runtime,readSnapshot:()=>s,stopProcesses:()=>calls++}),e=>e.code==='MIGRATION_PROCESS_UNCLEAR'&&e.message.includes('PID 201'));
 assert.equal(calls,0);
});
test('RC46 stale orphaned test runner with exact test files is owned; an unrelated Node test command is not',()=>{
 const s=snapshot([
  proc(200,'node.exe','node.exe --test --test-concurrency=4 "'+root+'\\tests\\one.test.mjs" "'+root+'\\tests\\two.test.mjs"'),
  proc(201,'node.exe','node.exe --test C:\\Other\\tests\\one.test.mjs')
 ]);
 assert.deepEqual(classify(s).owned.map(p=>p.pid),[200]);
});
test('RC46 identity comparison detects PID reuse and command/executable changes before a stop',()=>{
 const p=node(200,root+'\\tools\\cli.mjs');assert.equal(sameProcessIdentity(p,{...p}),true);
 for(const changed of [{createdAt:at(30)},{parentPid:33},{commandLine:'node.exe C:\\Other\\app.mjs'},
  {executablePath:'C:\\Other\\node.exe'},{name:'other.exe'},{pid:300}])assert.equal(sameProcessIdentity(p,{...p,...changed}),false);
});
test('RC46 migration stops only the explicit target identities and certifies a fresh post-stop snapshot',()=>{
 let s=snapshot([node(200,root+'\\tools\\cli.mjs'),proc(201,'msedge.exe','msedge.exe "--user-data-dir='+profile+'"'),
  node(300,'C:\\Other\\service.mjs'),proc(301,'msedge.exe',null)]);
 const plans=[];let reads=0;
 const p=windowsStopForMigration(root,{...runtime,readSnapshot:()=>{reads++;return structuredClone(s);},stopProcesses:plan=>{
  plans.push(plan);s.processes=s.processes.filter(p=>!plan.targets.some(t=>t.pid===p.pid));return stopped(plan);
 }});
 assert.equal(reads,2);assert.equal(plans.length,1);assert.deepEqual(plans[0].targets.map(t=>t.pid),[200,201]);
 assert.equal(p.blockedCount,0);assert.equal(p.stoppedProcesses.length,2);assert(p.inspectedPids.includes(300));assert(p.inspectedPids.includes(301));
 assert(!JSON.stringify(p).includes('commandLine'));
});
test('RC46 surviving identified worker remains owned after its parent exits and is checked again',()=>{
 let s=snapshot([node(200,root+'\\tools\\cli.mjs'),proc(201,'worker.exe','worker.exe',{parentPid:200,createdAt:at(11)})]);
 const batches=[];
 const p=windowsStopForMigration(root,{...runtime,readSnapshot:()=>structuredClone(s),stopProcesses:plan=>{
  batches.push(plan.targets.map(t=>t.pid));
  s.processes=s.processes.filter(p=>batches.length===1?p.pid!==200:p.pid!==201);
  return stopped(plan);
 }});
 assert.deepEqual(batches,[[200,201],[201]]);assert.equal(p.blockedCount,0);
});
test('RC46 changed identity or failed termination never certifies idle or triggers a blind PID retry',()=>{
 const s=snapshot([node(200,root+'\\tools\\cli.mjs')]);
 for(const status of ['IDENTITY_CHANGED','FAILED','PROTECTED']){
  let calls=0;
  assert.throws(()=>windowsStopForMigration(root,{...runtime,readSnapshot:()=>s,stopProcesses:plan=>{
   calls++;return {schema:'MCR_MIGRATION_PROCESS_STOP_RESULT_V1',results:[{pid:200,status}]};
  }}),e=>e.code==='MIGRATION_PROCESS_STOP_FAILED');
  assert.equal(calls,1);
 }
});
test('RC46 false stop success cannot hide a surviving worker, and a newer unrelated PID instance is never stopped',()=>{
 let s=snapshot([node(200,root+'\\tools\\cli.mjs')]);let calls=0;
 assert.throws(()=>windowsStopForMigration(root,{...runtime,readSnapshot:()=>s,stopProcesses:plan=>{calls++;return stopped(plan);}}),e=>e.code==='MCR_PROCESSES_ACTIVE');
 assert.equal(calls,2);
 s=snapshot([node(200,root+'\\tools\\cli.mjs')]);calls=0;
 const p=windowsStopForMigration(root,{...runtime,readSnapshot:()=>structuredClone(s),stopProcesses:plan=>{
  calls++;s=snapshot([node(200,'C:\\Other\\app.mjs',{createdAt:at(30)})]);return stopped(plan);
 }});
 assert.equal(calls,1);assert.equal(p.inspectedProcesses.find(p=>p.pid===200).relation,'UNRELATED');
});
test('RC46 incomplete/duplicate snapshots and missing installer identity are rejected',()=>{
 for(const s of [{schema:'bad',checked:true,processes:[]},snapshot([base()[0]]),
  {schema:'MCR_WINDOWS_PROCESS_SNAPSHOT_V1',checked:true,processes:[]}])
  assert.throws(()=>classify(s),e=>e.code==='PROCESS_CHECK_UNAVAILABLE');
});

test('RC46 native Windows PowerShell 5 parser accepts both shipped scripts',{skip:process.platform!=='win32'},()=>{
 const ps=path.join(process.env.SystemRoot||'C:\\Windows','System32/WindowsPowerShell/v1.0/powershell.exe');
 for(const file of ['process-guard.ps1','process-stop.ps1']){
  execFileSync(ps,['-NoProfile','-NonInteractive','-Command',
   '$parseTokens=$null; $parseErrors=$null; [void][System.Management.Automation.Language.Parser]::ParseFile($env:MCR_TEST_PARSE_SCRIPT,[ref]$parseTokens,[ref]$parseErrors); if ($parseErrors.Count -gt 0) { $parseErrors | Out-String | Write-Error; exit 1 }'],
   {env:{...process.env,MCR_TEST_PARSE_SCRIPT:path.join(ROOT,'tools',file)},encoding:'utf8',timeout:15000,windowsHide:true});
 }
});
test('RC46 native Windows snapshot proves idle for a new empty scoped test directory; no process termination requested',{skip:process.platform!=='win32'},()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC46-PROCESS-'));
 try{
  const p=windowsStopForMigration(dir,{stopProcesses:()=>assert.fail('New empty test directory must own no process')});
  assert.equal(p.blockedCount,0);assert.equal(p.unknownCount,0);assert(p.inspectedPids.includes(process.pid));
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
