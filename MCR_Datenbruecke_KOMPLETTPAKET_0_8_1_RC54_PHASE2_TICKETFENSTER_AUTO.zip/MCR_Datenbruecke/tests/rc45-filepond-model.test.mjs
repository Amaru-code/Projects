/** Controlled DOM/CDP model, NOT a Chromium/Edge/Windows browser test.
 * Production page.call functions execute against this small DOM model; chooser
 * events and upload responses are simulated. Native-browser tests are separate.
 */
import test from 'node:test';import assert from 'node:assert/strict';
import vm from 'node:vm';import path from 'node:path';import fs from 'node:fs';import os from 'node:os';
import {attachPhase2Files,phase2AttachmentEvidence,ensurePhase2UploadSurface} from '../lib/phase2-filepond.mjs';
import {phase2Journal,digestDescription} from '../lib/phase2-write-journal.mjs';
import {planPhase2UploadContinuation} from '../lib/phase2-upload-continuation.mjs';

class ModelElement{
 constructor(doc,tag,attrs={},text=''){
  this.doc=doc;this.tagName=tag.toUpperCase();this.attrs={...attrs};this.children=[];this.parentElement=null;this.ownText=text;
  this.style={display:'block',visibility:'visible',opacity:'1',pointerEvents:'auto'};
  this.box={left:10,top:20,right:430,bottom:80};
 }
 get id(){return this.attrs.id||'';}get className(){return this.attrs.class||'';}get htmlFor(){return this.attrs.for||'';}
 get type(){return this.attrs.type||'';}get name(){return this.attrs.name||'';}get value(){return this.attrs.value;}
 get multiple(){return this.hasAttribute('multiple');}get disabled(){return this.hasAttribute('disabled');}get readOnly(){return this.hasAttribute('readonly');}
 get isConnected(){return this===this.doc.body||!!this.parentElement?.isConnected;}
 get textContent(){return this.ownText+this.children.map(c=>c.textContent).join('');}get innerText(){return this.textContent;}
 set textContent(s){this.ownText=String(s);this.children=[];}
 getAttribute(k){return Object.hasOwn(this.attrs,k)?this.attrs[k]:null;}setAttribute(k,v){this.attrs[k]=String(v);}removeAttribute(k){delete this.attrs[k];}
 hasAttribute(k){return Object.hasOwn(this.attrs,k);}
 append(...children){for(const c of children){c.remove();c.parentElement=this;this.children.push(c);}return this;}
 remove(){if(this.parentElement){const p=this.parentElement;p.children=p.children.filter(x=>x!==this);this.parentElement=null;}}
 contains(other){return other===this||this.children.some(c=>c.contains(other));}
 matches(selector){
  return selector.split(',').some(raw=>{
   let s=raw.trim();const tag=/^[a-z][a-z0-9-]*/i.exec(s);
   if(tag){if(this.tagName!==tag[0].toUpperCase())return false;s=s.slice(tag[0].length);}
   while(s){
    let m=/^\.([a-z0-9_-]+)/i.exec(s);if(m){if(!this.className.split(/\s+/).includes(m[1]))return false;s=s.slice(m[0].length);continue;}
    m=/^#([a-z0-9_-]+)/i.exec(s);if(m){if(this.id!==m[1])return false;s=s.slice(m[0].length);continue;}
    m=/^\[([^=\]]+)(?:=["']?([^\]"']*)["']?)?\]/.exec(s);
    if(m){if(!this.hasAttribute(m[1])||(m[2]!==undefined&&this.getAttribute(m[1])!==m[2]))return false;s=s.slice(m[0].length);continue;}
    throw new Error('Unsupported model selector '+selector);
   }
   return true;
  });
 }
 querySelectorAll(selector){return this.children.flatMap(c=>[...(c.matches(selector)?[c]:[]),...c.querySelectorAll(selector)]);}
 querySelector(selector){return this.querySelectorAll(selector)[0]||null;}
 closest(selector){for(let p=this;p;p=p.parentElement)if(p.matches(selector))return p;return null;}
 getClientRects(){for(let p=this;p;p=p.parentElement)if(p.style.display==='none')return [];return this.isConnected?[this.box]:[];}
 getBoundingClientRect(){return this.box;}scrollIntoView(){}
}
class ModelDocument{
 constructor(){this.body=new ModelElement(this,'body');}
 el(tag,attrs={},text=''){return new ModelElement(this,tag,attrs,text);}
 querySelectorAll(s){return this.body.querySelectorAll(s);}querySelector(s){return this.body.querySelector(s);}
 getElementById(id){return this.querySelectorAll('[id]').find(n=>n.id===id)||null;}
 elementFromPoint(x,y){return this.querySelectorAll('label,button,a,input').findLast(n=>n.getClientRects().length&&n.style.opacity!=='0'&&n.box.left<=x&&n.box.right>=x&&n.box.top<=y&&n.box.bottom>=y)||null;}
}
function model({reopen=true,legacy=false,pondStays=false,multiple=false,onUpload=null,directOpener=false}={}){
 const doc=new ModelDocument(),listeners=new Set(),backend=new Map();let sequence=10,intercept=false;
 const selected=[],clicks=[],callbacks=[];
 const list=doc.el('ul',{id:'attachments'});doc.body.append(list);
 let opens=0;
 const appendRow=(name)=>{const li=doc.el('li');li.append(doc.el('a',{},name));list.append(li);return li;};
 const open=()=>{
  opens++;if(opener)opener.style.display='none';
  if(legacy){
   const input=doc.el('input',{id:'emailAttachmentFileUpload',name:'files[]',type:'file',...(multiple?{multiple:''}:{})});doc.body.append(input);
   input.onFiles=files=>{for(const f of files)appendRow(path.basename(f));};return;
  }
  const root=doc.el('div',{class:'filepond--root'}),key='dynamic'+opens;
  const input=doc.el('input',{type:'file',id:'filepond--browser-'+key,...(multiple?{multiple:''}:{})});input.style.opacity='0';
  const label=doc.el('label',{id:'filepond--drop-label-'+key,for:input.id},'Dateien hierher ziehen oder zum Auswählen klicken');
  root.append(input,label);doc.body.append(root);
  input.onFiles=files=>{
   if(onUpload){onUpload({doc,root,input,files,appendRow});return;}
   for(const f of files){
    if(pondStays){const item=doc.el('li',{class:'filepond--item','data-filepond-item-state':'idle'});item.append(doc.el('span',{class:'filepond--file-info-main'},path.basename(f)));root.append(item);}
    else appendRow(path.basename(f));
   }
   if(!pondStays){root.remove();if(opener)opener.style.display='block';}
  };
 };
 const opener=reopen&&!legacy?doc.el('button',{},'Dokument anhängen'):null;
 if(opener){opener.box={left:10,top:100,right:350,bottom:140};doc.body.append(opener);opener.onClick=directOpener?()=>{
  assert.equal(intercept,true,'unknown native chooser must be intercepted before opening');
  for(const fn of listeners)fn({backendNodeId:sequence++,mode:'selectSingle'},page.sessionId);
 }:open;}
 const context=vm.createContext({document:doc,getComputedStyle:n=>n.style,innerWidth:1000,innerHeight:800,setTimeout});
 const page={sessionId:'MODEL_SESSION',
  call:async(fn,...args)=>{const value=await vm.runInContext(`(${fn.toString()})(...__args)`,Object.assign(context,{__args:args}));return value===undefined?undefined:JSON.parse(JSON.stringify(value));},
  mouseClick:async(x,y)=>{
   const hit=doc.elementFromPoint(x,y);assert.ok(hit,'model click must hit an element');clicks.push(hit.tagName);
   if(hit.tagName==='LABEL'){
    assert.equal(intercept,true);const input=doc.getElementById(hit.htmlFor),id=sequence++;backend.set(id,input);
    for(const fn of listeners)fn({backendNodeId:id,mode:input.multiple?'selectMultiple':'selectSingle'},page.sessionId);
   }else hit.onClick?.();
  },
  cdp:{on:(name,fn)=>{assert.equal(name,'Page.fileChooserOpened');listeners.add(fn);return()=>listeners.delete(fn);},
   send:async(method,params)=>{
    if(method==='Page.setInterceptFileChooserDialog'){intercept=params.enabled;return {};}
    if(method==='DOM.describeNode'){const input=backend.get(params.backendNodeId);return {node:{nodeName:'INPUT',attributes:Object.entries(input.attrs).flat()}};}
    if(method==='DOM.getDocument')return {root:{nodeId:1}};
    if(method==='DOM.querySelector'){const input=doc.querySelector(params.selector),id=sequence++;if(input)backend.set(id,input);return {nodeId:input?id:0};}
    if(method==='DOM.setFileInputFiles'){
     const input=backend.get(params.backendNodeId??params.nodeId);assert.ok(input?.isConnected,'native node must still be bound');
     selected.push(...params.files.map(f=>path.basename(f)));callbacks.push('SELECT '+path.basename(params.files[0]));input.onFiles(params.files);return {};
    }
    throw new Error('Unexpected model CDP call '+method);
   }}
 };
 open();return {doc,page,selected,clicks,callbacks,appendRow,list,get opens(){return opens;}};
}
const files=['/model/11368989_Kontoauszug_PP+.pdf','/model/11368989_Kontoauszug_DC.pdf'];

test('RC45 MODEL: a closing upload surface produces two independent chooser selections and ordered audit hooks',async()=>{
 const m=model();const hooks=[];
 const result=await attachPhase2Files(m.page,files,{
  beforeSelect:async({name})=>{hooks.push('INTENT '+name);m.callbacks.push('INTENT '+name);},
  afterStaged:async({name,evidence})=>{assert.equal(evidence.allReady,true);hooks.push('STAGED '+name);m.callbacks.push('STAGED '+name);}
 });
 assert.deepEqual(m.selected,files.map(f=>path.basename(f)));assert.deepEqual(m.clicks,['LABEL','BUTTON','LABEL']);assert.equal(m.opens,2);
 assert.deepEqual(m.callbacks,files.flatMap(f=>['INTENT '+path.basename(f),'SELECT '+path.basename(f),'STAGED '+path.basename(f)]));
 assert.equal(result.evidence.allReady,true);assert.equal(result.serverUploadVerified,false);
});

test('RC45 MODEL: multiple=true still selects one PDF per chooser; retained FilePond and legacy inputs preserve both',async()=>{
 for(const settings of [{pondStays:true,multiple:true},{legacy:true,multiple:true}]){
  const m=model(settings);const result=await attachPhase2Files(m.page,files);
  assert.deepEqual(m.selected,files.map(f=>path.basename(f)));assert.equal(result.evidence.allReady,true);
  assert.equal(m.callbacks.length,2);if(!settings.legacy)assert.deepEqual(m.clicks,['LABEL','LABEL']);
 }
});

test('RC45 MODEL: busy/hidden/error/duplicate/unknown and free text never certify an attachment',async()=>{
 const m=model();m.doc.querySelector('.filepond--root').remove();
 const name=path.basename(files[0]),row=m.appendRow(name);
 let e=await phase2AttachmentEvidence(m.page,[name]);assert.equal(e.allReady,true);assert.equal(e.items[0].count,1);
 row.setAttribute('aria-busy','true');e=await phase2AttachmentEvidence(m.page,[name]);assert.equal(e.items[0].status,'PENDING');assert.equal(e.allReady,false);
 row.removeAttribute('aria-busy');row.style.display='none';e=await phase2AttachmentEvidence(m.page,[name]);assert.equal(e.items[0].status,'HIDDEN_UNVERIFIED');assert.equal(e.items[0].present,true);assert.equal(e.allReady,false);
 row.style.display='block';row.setAttribute('aria-invalid','true');e=await phase2AttachmentEvidence(m.page,[name]);assert.equal(e.items[0].status,'ERROR');
 row.removeAttribute('aria-invalid');m.appendRow(name);e=await phase2AttachmentEvidence(m.page,[name]);assert.equal(e.items[0].status,'DUPLICATE');
 m.list.remove();m.doc.body.append(m.doc.el('span',{},name));e=await phase2AttachmentEvidence(m.page,[name]);assert.equal(e.items[0].status,'UNBOUND_NAME');assert.equal(e.allReady,false);
 m.doc.querySelector('span').remove();const root=m.doc.el('div',{class:'filepond--root'}),item=m.doc.el('li',{class:'filepond--item'});
 item.append(m.doc.el('span',{class:'filepond--file-info-main'},name));root.append(item);m.doc.body.append(root);
 e=await phase2AttachmentEvidence(m.page,[name]);assert.equal(e.items[0].status,'UNKNOWN_FILEPOND_STATE');assert.equal(e.allReady,false);
 root.style.display='none';e=await phase2AttachmentEvidence(m.page,[name]);assert.equal(e.items[0].status,'HIDDEN_UNVERIFIED');assert.equal(e.items[0].present,true);
});

test('RC45 MODEL: mail download links are unbound, hidden free text is ignored and hidden attachment templates remain ambiguous',async()=>{
 const m=model(),name=path.basename(files[0]);m.doc.querySelector('.filepond--root').remove();
 const mail=m.doc.el('div',{id:'mail'}),link=m.doc.el('a',{download:'',href:'/download.pdf'},name);mail.append(link);m.doc.body.append(mail);
 let evidence=await phase2AttachmentEvidence(m.page,[name]);assert.equal(evidence.items[0].status,'UNBOUND_NAME');assert.equal(evidence.allReady,false);
 mail.style.display='none';evidence=await phase2AttachmentEvidence(m.page,[name]);assert.equal(evidence.items[0].status,'ABSENT');assert.equal(evidence.items[0].present,false);
 mail.remove();m.appendRow(name);const hidden=m.appendRow(name);hidden.style.display='none';
 evidence=await phase2AttachmentEvidence(m.page,[name]);assert.equal(evidence.items[0].status,'AMBIGUOUS');assert.equal(evidence.items[0].count,2);assert.equal(evidence.items[0].hiddenCount,1);assert.equal(evidence.allReady,false);
});

test('RC45 MODEL: existing files, blocked journal writes and ambiguous openers cause no native selection',async()=>{
 let m=model();m.appendRow(path.basename(files[0]));
 await assert.rejects(()=>attachPhase2Files(m.page,files),e=>e.code==='P2_ATTACHMENT_ALREADY_PRESENT');assert.deepEqual(m.selected,[]);
 m=model();let staged=0;
 await assert.rejects(()=>attachPhase2Files(m.page,[files[0]],{beforeSelect:async()=>{throw new Error('journal write failed');},afterStaged:async()=>staged++}),/journal write failed/);
 assert.deepEqual(m.selected,[]);assert.equal(staged,0);
 m=model();m.doc.querySelector('.filepond--root').remove();m.doc.querySelector('button').style.display='block';m.doc.body.append(m.doc.el('button',{},'Dokument anhängen'));
 assert.equal((await ensurePhase2UploadSurface(m.page)).available,false);assert.deepEqual(m.clicks,[]);
 m=model({directOpener:true});m.doc.querySelector('.filepond--root').remove();m.doc.querySelector('button').style.display='block';
 await assert.rejects(()=>ensurePhase2UploadSurface(m.page),e=>e.code==='P2_ATTACHMENT_DIRECT_CHOOSER');assert.deepEqual(m.selected,[]);
});

test('RC45 MODEL INTEGRATION: RC44 legacy focus-recovery UPLOAD_INTENT retains PP+ and adds only DC using the real journal and continuation planner',async()=>{
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC45-MODEL-RECOVERY-'));
 try{
  const artifacts=[{plan:'PP+',name:path.basename(files[0]),sha256:'a'.repeat(64),path:files[0]},
   {plan:'DC',name:path.basename(files[1]),sha256:'b'.repeat(64),path:files[1]}];
  const initial={ticketId:'87278094',descriptionSha256:digestDescription('USC 10/ DC;PP+\nStandardantwort versendet\nMöchte Kontoauszug'),pdfHashes:artifacts.map(({plan,sha256})=>({plan,sha256}))};
  const journal=phase2Journal(root,initial.ticketId,{initial});journal.begin();journal.advance('GEVO_INTENT');
  journal.approveGevoFocusRetry({...initial,operatorConfirmed:true,ticketUnchanged:true,noAttachments:true});journal.advance('UPLOAD_INTENT');
  const original=journal.read().events.map(e=>e.state);assert.equal(journal.read().recoveryCount,1);assert.equal(journal.mayReconcileUpload(initial),true);
  const m=model();m.appendRow(artifacts[0].name);m.list.style.display='none';
  const hiddenEvidence=await phase2AttachmentEvidence(m.page,artifacts.map(x=>x.name));
  assert.equal(hiddenEvidence.items[0].status,'HIDDEN_UNVERIFIED');
  assert.throws(()=>planPhase2UploadContinuation({artifacts,evidence:hiddenEvidence,resumeUpload:true}),e=>e.code==='P2_UPLOAD_EVIDENCE_UNCLEAR');
  await assert.rejects(()=>attachPhase2Files(m.page,files),e=>e.code==='P2_ATTACHMENT_ALREADY_PRESENT');
  assert.deepEqual(m.selected,[]);assert.deepEqual(m.clicks,[]);m.list.style.display='block';
  const plan=planPhase2UploadContinuation({artifacts,evidence:await phase2AttachmentEvidence(m.page,artifacts.map(x=>x.name)),resumeUpload:true});
  assert.deepEqual(plan.existing.map(a=>a.plan),['PP+']);assert.deepEqual(plan.missing.map(a=>a.plan),['DC']);
  journal.approveUploadReconciliation({...initial,operatorConfirmed:true,ticketUnchanged:true,noSaveOrForward:true,
   existingPlans:plan.existing.map(a=>a.plan),missingPlans:plan.missing.map(a=>a.plan)});
  await attachPhase2Files(m.page,plan.missing.map(a=>a.path),{
   beforeSelect:async({name})=>journal.recordUploadFileIntent(artifacts.find(a=>a.name===name)),
   afterStaged:async({name,evidence})=>journal.recordUploadFileStaged({...artifacts.find(a=>a.name===name),source:evidence.items.find(x=>x.name===name).source})
  });
  assert.deepEqual(m.selected,[artifacts[1].name]);assert.equal(m.list.children.filter(row=>row.textContent===artifacts[0].name).length,1);
  assert.equal((await phase2AttachmentEvidence(m.page,artifacts.map(a=>a.name))).allReady,true);
  journal.advance('UPLOAD_VERIFIED');const final=journal.read();
  assert.deepEqual(final.events.slice(0,original.length).map(e=>e.state),original);
  assert.equal(final.events.filter(e=>e.state==='UPLOAD_FILE_INTENT').length,1);
  assert.equal(final.events.find(e=>e.state==='UPLOAD_FILE_INTENT').plan,'DC');assert.equal(final.uploadRecoveryCount,1);
  assert.equal(final.state,'UPLOAD_VERIFIED');assert.equal(journal.mayReconcileUpload(initial),false);
 }finally{fs.rmSync(root,{recursive:true,force:true});}
});
