import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import {temp} from './helpers.mjs';
import {phase2WorkRule,privateMbcDraft,markedPhase2Description,PRIVATE_MBC_REQUEST,MBC_PRIVATE_PARAGRAPHS} from '../lib/phase2-work-rules.mjs';
import {phase2Journal} from '../lib/phase2-write-journal.mjs';
import {phase2WorkJournal} from '../lib/phase2-work-journal.mjs';
import {choosePhase2Candidate} from '../src/phase2-run.mjs';
const row=descriptionValue=>({ticketId:'87278094',source:'POST',descriptionValue});
for(const plan of ['DB','DB+','DC;DB+','DB+;PP+'])test('RC52 exact line-1 plan routes direct: '+plan,()=>{
 assert.equal(phase2WorkRule(row('USC 100/ '+plan+'\nStandardantwort versendet\n'+PRIVATE_MBC_REQUEST)).kind,'DB_DIRECT');
});
test('RC52 DB is not a word substring or a marker on another physical line',()=>{
 for(const s of ['USC 100/ XDB+\nStandardantwort versendet','USC 100/ DBplus\nStandardantwort versendet','USC 100/ DB+\n\nStandardantwort versendet','USC 100/ DC\nStandardantwort versendet\nDB+'])assert.notEqual(phase2WorkRule(row(s)).kind,'DB_DIRECT');
});
test('RC52 exact MBC third line only; request spelling and physical line positions preserved',()=>{
 assert.equal(phase2WorkRule(row('USC 100/ DC\nStandardantwort versendet\n'+PRIVATE_MBC_REQUEST)).kind,'MBC_PRIVATE_EMAIL');
 for(const s of ['USC 100/ DC\n\n'+PRIVATE_MBC_REQUEST,'USC 100/ DC\nStandardantwort versendet\n'+PRIVATE_MBC_REQUEST+'.','USC 100/ DC\nStandardantwort versendet\nMöchte Log-in MBC mit privater E-Mail']){
  if(s.includes('Möchte'))assert.equal(phase2WorkRule(row(s)).kind,'MBC_PRIVATE_EMAIL');
  else assert.notEqual(phase2WorkRule(row(s)).kind,'MBC_PRIVATE_EMAIL');
 }
});
test('RC52 known account rule retained; unknown content not guessed; already prepared stays prepared',()=>{
 assert.equal(phase2WorkRule(row('USC 100/ DC;PP+\nStandardantwort versendet\nMöchte Kontoauszug')).kind,'ACCOUNT_STATEMENT');
 assert.equal(phase2WorkRule(row('USC 100/ DC\nStandardantwort versendet\nMöchte etwas anderes')).kind,'SKIP');
 assert.equal(phase2WorkRule(row('USC 100/ DB\nStandardantwort versendet\nBearbeitet not reviewed')).kind,'ALREADY_PREPARED');
});
test('RC52 marker preserves all original lines, is idempotent and never truncates',()=>{
 const before='USC 1/ DC\nStandardantwort versendet\n'+PRIVATE_MBC_REQUEST,after=before+'\nBearbeitet not reviewed';
 assert.equal(markedPhase2Description(before),after);assert.equal(markedPhase2Description(after),after);
 assert.throws(()=>markedPhase2Description('x'.repeat(449)),e=>e.code==='P2_DESCRIPTION_LIMIT');
 assert.throws(()=>markedPhase2Description(after+'\nBearbeitet not reviewed'),e=>e.code==='P2_MARKER_DUPLICATE');
});
test('RC52 private-MBC template is exactly user text plus verified salutation, never gender guessing',()=>{
 assert.equal(privateMbcDraft({lastName:'Mustermann',gender:'M'}),'Sehr geehrter Herr Mustermann,\n\n'+MBC_PRIVATE_PARAGRAPHS.join('\n\n'));
 assert(privateMbcDraft({lastName:'Musterfrau',gender:'F'}).startsWith('Sehr geehrte Frau Musterfrau,'));
 assert.throws(()=>privateMbcDraft({lastName:'Muster',gender:null}));assert.throws(()=>privateMbcDraft({lastName:'<script>',gender:'M'}));
});
const input={ticketId:'87278094',descriptionSha256:'a'.repeat(64),pdfHashes:[{plan:'DC',sha256:'b'.repeat(64)},{plan:'PP+',sha256:'c'.repeat(64)}]};
function savedIntent(root){const j=phase2Journal(root,input.ticketId,{initial:input});j.begin();for(const s of ['UPLOAD_INTENT','UPLOAD_VERIFIED','GEVO_INTENT','GEVO_VERIFIED','DESCRIPTION_INTENT','DESCRIPTION_VERIFIED','DRAFT_SAVE_INTENT','DRAFT_SAVE_VERIFIED','TICKET_SAVE_INTENT'])j.advance(s);j.recordTicketSaveAutoClickIntent();j.recordTicketSaveNetworkObservation({status:'NETWORK_QUIET',writeStarts:2});return j;}
test('RC52 actual RC51 QUEUE_OPEN journal resumes only server readback, never another save/upload',()=>{
 const root=temp();try{const j=savedIntent(root),before=j.read();assert(j.mayInspectPersistedSave(input));
 assert.throws(()=>j.reconcilePersistedSave({...input,serverDescriptionVerified:true,attachmentsReviewed:true}),e=>e.code==='P2_RC52_PERSISTENCE_REQUIRED');
 assert.deepEqual(j.read(),before);assert.throws(()=>j.recordTicketSaveAutoClickIntent(),e=>e.code==='P2_SAVE_AUTO_REPLAY');
 j.reconcilePersistedSave({...input,serverDescriptionVerified:true,serverGevoVerified:true,attachmentsReviewed:true});
 assert.equal(j.read().state,'TICKET_SAVE_VERIFIED');assert.deepEqual(j.read().events.slice(0,before.events.length),before.events);
 assert.equal(j.read().events.filter(e=>e.state==='TICKET_SAVE_AUTO_CLICK_INTENT').length,1);
 j.advance('REVIEW_INTENT');j.advance('REVIEW_VERIFIED');j.advance('EXECUTE_INTENT');assert(!j.mayInspectPersistedSave(input));
 }finally{fs.rmSync(root,{recursive:true,force:true});}
});
test('RC52 server readback refuses foreign ticket, changed PDF and changed original description',()=>{
 const root=temp();try{const j=savedIntent(root);for(const x of [{...input,ticketId:'99999999'},{...input,descriptionSha256:'d'.repeat(64)},{...input,pdfHashes:[input.pdfHashes[0]]}])assert(!j.mayInspectPersistedSave(x));}finally{fs.rmSync(root,{recursive:true,force:true});}
});
test('RC52 new workflow journal cannot replay any one-way save or step',()=>{
 const root=temp();try{const j=phase2WorkJournal(root,input.ticketId);j.begin({rule:'DB_DIRECT',descriptionBefore:'a',descriptionAfter:'a\nBearbeitet not reviewed'});
 for(const s of ['EDIT_INTENT','EDIT_VERIFIED','TICKET_SAVE_INTENT','TICKET_SAVE_VERIFIED','REVIEW_INTENT','REVIEW_VERIFIED','EXECUTE_INTENT'])j.advance(s);
 assert.throws(()=>j.advance('EXECUTE_INTENT'));assert.throws(()=>j.advance('TICKET_SAVE_INTENT'));j.advance('ROUTED_VERIFIED');assert.throws(()=>j.begin({}));
 }finally{fs.rmSync(root,{recursive:true,force:true});}
});
test('RC52 continuation chooses next unvisited eligible work; skips missing proof and phase1 pending',()=>{
 const a=row('USC 1/ DC\nStandardantwort versendet\nMöchte Kontoauszug'),b={...row('USC 1/ DB+\nStandardantwort versendet'),ticketId:'87278095'},c={...row('USC 1/ DC\nStandardantwort versendet\n'+PRIVATE_MBC_REQUEST),ticketId:'87278096'};
 assert.equal(choosePhase2Candidate([a,b,c],{accountReady:()=>false}).row.ticketId,b.ticketId);
 assert.equal(choosePhase2Candidate([a,b,c],{accountReady:()=>false,visited:new Set([b.ticketId])}).row.ticketId,c.ticketId);
 assert.equal(choosePhase2Candidate([b,c],{blockedIds:[b.ticketId,c.ticketId]}).row,null);
 assert.equal(choosePhase2Candidate([b],{getWorkJournal:()=>({state:'EXECUTE_INTENT'})}).row,null);
});
