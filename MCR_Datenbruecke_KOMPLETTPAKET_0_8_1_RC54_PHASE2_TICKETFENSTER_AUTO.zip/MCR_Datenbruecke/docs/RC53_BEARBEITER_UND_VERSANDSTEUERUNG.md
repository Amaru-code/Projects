# RC53 – Bearbeiterzuweisung, Statusabschluss und Versandsteuerung

## Befund aus dem RC52-Lauf
Der Kontoauszug erreichte den gespeicherten Zustand, stoppte jedoch mit
P2_REVIEW_MODE_NOT_READY vor bestätigter Prüferzuweisung. Daraus folgt kein
Schritt-ausführen-Klick. Der DB-Fall stoppte früher mit
P2_WORK_SERVER_DESCRIPTION. Beim Standardantwort-Piloten kam nach einem
Versandversuch SEND_UNVERIFIED: Versand, Statusspeicherung und Weiterlauf waren
nicht gemeinsam bestätigt. Ein tatsächlich versendeter Ausgang darf deshalb
nicht automatisch ein zweites Mal verschickt werden.

## Änderungen
### Prüfer und direkter Bearbeiter
Die Option FORWARD_TO_REVIEW wird über echte Maus-/Tastatureingaben ausgewählt.
Ein ausschließlich programmatisch gesetzter SELECT-Wert zählt nicht als
Auslösen des ICEfaces-Auswahlablaufs. Danach wird das neu eingeblendete,
editierbare Feld mainForm:next-persona-assignment-id abgewartet. Die echte
Vorschlagszeile Baindl Mark (mark.baindl) wird gewählt, der Wert stabil erneut
geprüft und ein gegebenenfalls nötiger Fokuswechsel abgewartet. Erst dann darf
Schritt ausführen einmal betätigt werden. Keine fest verdrahtete j_id-Nummer.

DB/DB+ verwendet dagegen mainForm:persona-assignment-id und
mainForm:current-performer-assign-link. Auch hier reicht der eingetippte
Suchbegriff nicht. Der Bot muss den tatsächlichen Vorschlag auswählen.

### Beschreibung und Speicherung
Die zusätzliche Beschreibung wird mit fokussierter, nativer Texteingabe und
anschließendem Tab/Fokuswechsel übernommen. Netzwerkruhe und exakter Text im
Editor werden geprüft; erst nach dem Speichern und erneutem Öffnen gilt die
Speicherung als nachgewiesen. Das neue Browsermodell prüft insbesondere eine
Anwendung, die den Text erst beim echten Fokusverlust übernimmt. Das ist eine
gezielt abgedeckte Fehlerklasse, kein Beweis, dass jedes reale COMARCH-Problem
allein diese Ursache hatte.

Vorhandene USC-Zeilen bleiben erhalten. Bei einer USC-Zeile folgt
Standardantwort versendet in Zeile 2. Bei mehreren USC-Zeilen bleiben alle
Zeilen bestehen; der Status folgt ihnen. Ein unklarer Versand erhält niemals
allein wegen eines Klicks diesen Status. Bearbeitet not reviewed bleibt der
separate Phase-2-Abschlussmarker und wird einmalig angehängt.

### Wiederaufnahme der offenen Phase-2-Fälle
Ein bereits gespeicherter Kontoauszug im REVIEW_INTENT wird ohne neue
PDF-Auswahl, neuen Entwurf oder erneuten Ticket-Speicherklick fortgesetzt.
Das tatsächliche gespeicherte Ticket und die Anlagen bleiben Voraussetzung.

Beim DB-/MBC-Arbeitsjournal mit TICKET_SAVE_INTENT und nachweislich noch alter
unveränderter Beschreibung gibt es eine einmalige gezielte Reparatur. Die
Abfrage NICHT_GESPEICHERT_<Ticketnummer> bedeutet: Altes Ergebnis ist nicht
persistiert, keine manuelle Weiterleitung seit dem Abbruch. Fremde Änderungen
oder eine frühere Ausführungsabsicht bleiben gesperrt. Reparatur und eigener
Speicherklick werden separat protokolliert; Journale werden nicht gelöscht.

### Standardantwort: unbestätigten Ausgang abschließen
Bei einem neu auftretenden unklaren Versand bleibt der Bot im selben Ticket.
Er kann eine ausdrücklich manuelle Prüfung des neuen Ausgangs anfordern:
VERSAND_<Ticketnummer>_GEPRUEFT. Prüfe Originalticket, Empfänger, vollständigen
Text und tatsächlichen neuen Ausgang im COMARCH-Verlauf. Dies ist im Journal
als Bedienerprüfung gekennzeichnet, nicht als automatischer Servernachweis.
Ohne diese Bestätigung bleibt der Fall ungeklärt und wird nicht erneut gesendet.

Für den schon unter RC52 unterbrochenen Piloten: Menü 5, gezielt 88149870
angeben. Dieser Weg enthält keine Versandmethode und schreibt keinen neuen
Antwortentwurf. Nach Bestätigung des alten Ausgangs werden nur der ursprünglich
beabsichtigte, hashgebundene USC-/Status-Text und die Speicherung abgeschlossen.
Ein alter SAVE_INTENT wird lediglich zurückgelesen: kein zweiter Speicherklick.
Andere offene Ticketjournale bleiben unverändert.

### Bedienfenster unten links
Jeder neue Menü-3/4-Lauf beginnt MANUELL. Der Schalter wechselt zwischen
MANUELL und AUTO. Manuell: Dieses Ticket senden ist genau einmal für das
angezeigte Ticket freigegeben. Auto: nur nach bewusstem Umschalten, weiterhin
mit Identitäts-, Empfänger-, Text-, Doppelversand- und Speicherprüfungen.
Bei einem erfolgreichen Menü-3-Piloten bleibt die explizite Moduswahl für die
anschließenden bis zu fünf Tickets erhalten. Ein neuer Menüstart ist erneut
manuell. Eine inzwischen geänderte Freigabe darf keinen Versand auslösen.

STOP verhindert weitere automatisierte Browser-Eingaben. Bereits erfolgte
Aktionen werden nicht rückgängig gemacht; offene Absichten bleiben prüfpflichtig.
Das interaktive Fenster wird vor Browser-Eingaben ausgeblendet und bestätigt
sein Ausblenden über die anonyme Prozesspipe. So kann es keine automatisierten
COMARCH-Klicks abfangen. Bei Stillstand/Freigabe wird es wieder sichtbar. Fällt
das Fenster aus, ersetzt eine ticketgebundene Terminalfreigabe die Schaltfläche.
Kein stiller Wechsel zu Auto. Das native Fenster speichert keine Daten und
öffnet keine Netzwerkverbindung.

Nach verifiziertem Laufabschluss wird das kleine Fenster durch große grüne
Schrift FERTIG ersetzt. Eine sanfte Kurve blendet sie innerhalb von fünf
Sekunden aus. Die Unterzeile benennt Anzahl, Laufgrenze oder weitere offene
Prüffälle. Kein Erfolgsbanner bei Fehler und kein voreiliges Banner zwischen
Piloten und Folgelauf. Keine pauschale Behauptung, alle Systemtickets seien
beantwortet. Die Listenseiten-/Laufgrenzen aus RC52 bleiben erhalten.

### Schnellinstallation und Tests
Menü 1 bleibt Schnellinstallation; Menü 3/4 lösen ebenfalls keine fiktiven
Demos mehr aus. Tests sind weiterhin gezielt unter Menü 6 und Demos unter
Menü 2 möglich. Integritätsprüfung, Datenerhalt, Prozesskontrolle, Sicherung
und der verifizierte Rückweg werden nicht übersprungen.

## Start
1. ZIP separat entpacken. Neue START.cmd, Menü 1, vorhandenes Ziel übernehmen.
2. Danach ausschließlich START.cmd der installierten RC53 verwenden.
3. Alten unklaren Standardantwort-Fall zuerst über Menü 5 ohne Neuversand prüfen.
4. Phase 2: Menü 12, 87278094 für den Kontoauszug oder 87316993 für DB; leere
   Startnummer nimmt passende sichtbare eigene Vorgänge. Frische Inventur ist integriert.
5. Standardbearbeitung: Menü 3 für den verifizierten Piloten mit Folgelauf,
   Menü 4 danach für einen regulären Lauf. Manuell/Auto im Fenster wählen.

## Grenzen des Prüfstands
Chromiumtests verwenden nachgebildete Oberflächen, nicht die produktive
COMARCH-Instanz. Dieses Paket wurde nicht auf dem Windows-Rechner des Nutzers
ausgeführt. Die native PowerShell-/WinForms-Anzeige und die reale Weiterleitung
bedürfen des Windows-Laufs. Der Windows-Parsertest ist auf Linux explizit
übersprungen. Das aktuelle JSON im gleichen Ordner dokumentiert die tatsächlich
hier ausgeführten Prüfungen; historische Prüfberichte gelten nur für ihre RC.

## Technische Referenzen
CDP Input: https://chromedevtools.github.io/devtools-protocol/tot/Input/
Microsoft TextReader.ReadLineAsync (Console.In ist synchron):
https://learn.microsoft.com/en-us/dotnet/api/system.io.textreader.readlineasync
Das Dashboard benutzt deshalb einen eigenen Hintergrund-Lesethread für seine
Pipe, nicht Console.In.ReadLineAsync auf dem Windows-Forms-UI-Thread.
Microsoft Form.ShowWithoutActivation:
https://learn.microsoft.com/en-us/dotnet/api/system.windows.forms.form.showwithoutactivation
Microsoft Form.Opacity:
https://learn.microsoft.com/en-us/dotnet/api/system.windows.forms.form.opacity
