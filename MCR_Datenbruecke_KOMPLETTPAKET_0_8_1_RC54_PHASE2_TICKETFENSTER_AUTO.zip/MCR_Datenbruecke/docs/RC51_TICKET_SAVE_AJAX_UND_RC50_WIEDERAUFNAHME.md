# RC51 – Ticket speichern: COMARCH-Quittierung abwarten

## Anlass

Im beaufsichtigten Phase-2-Pilot wurden zwei Dateien `11368989_Kontoauszug_DC.pdf` und `11368989_Kontoauszug_PP+.pdf` im Bot-Edge ausgewählt und vom Bediener auf der Oberfläche bestätigt. GEVO `Anfrage Member` und die vierte Beschreibung `Bearbeitet not reviewed` waren zuvor im Editor ausgewählt. RC48 brach unmittelbar vor dem Speicherklick mit `ACTION_OCCLUDED_OR_OFFSCREEN` ab. RC49 scheiterte an der nach dem Öffnen nicht mehr vorhandenen GEVO-Auswahl; RC50 ergänzte die GEVO-Neuauswahl. Nach Nutzerangabe wird das Ticket noch nicht zuverlässig gespeichert. Ein vollständiger RC50-Lauf-Output liegt für diesen Bericht **nicht** vor; die präzise Ursache am echten COMARCH-Server ist daher noch nicht abschließend bewiesen.

## Zielgerichtete technische Änderungen

1. Vor dem einzigen autorisierten Klick auf **Ticket speichern** startet RC51 eine nur lesende CDP-Netzwerkbeobachtung. Diese zählt gleichursprüngliche POST-/PUT-/PATCH-Schreibrequests, wartet auf deren Ende und auf ein ruhiges Zeitfenster, bevor die Software die Vorgangsliste öffnet. Auch ohne beobachteten Request wird eine Mindestwartezeit eingehalten. Ein HTTP-Fehler oder ein weiterhin laufender Request stoppt die automatische Fortsetzung. **Ein Netzwerk-OK ist ausdrücklich kein Nachweis einer Datenbankspeicherung.**
2. Erst danach navigiert RC51 zur COMARCH-Vorgangsliste und prüft die exakt erwartete vierzeilige Beschreibung. Der Eintrag wird erneut geöffnet und `Anfrage Member` im wieder geöffneten Ticket geprüft. `TICKET_SAVE_VERIFIED` wird erst nach beiden getrennten Nachweisen gesetzt. Keine zweite automatische Speicheraktion.
3. RC51 protokolliert zusätzlich **vor** einem automatischen Speicherklick `TICKET_SAVE_AUTO_CLICK_INTENT` und nach Ende der passiven Beobachtung `TICKET_SAVE_NETWORK_OBSERVED`. Ein unklarer Klick oder unbestätigte Speicherung bleibt offen; kein blindes Replay.
4. Ein altes RC50-Journal mit `TICKET_SAVE_INTENT`, genau einer bereits genehmigten RC49-Wiederaufnahme und optional abgeschlossenem RC50-GEVO-Reparaturintent kann **ein einziges weiteres Mal** nach unabhängiger Prüfung fortgesetzt werden. Voraussetzung: Gleiches Ticket, unveränderte PDF-Prüfsummen, tatsächliche Sichtkontrolle beider Anhänge, Tickettext nicht gespeichert/GEVO nicht persistiert, keine erfolgte Weiterleitung und ausdrückliche Bedienerfreigabe `RC50_NICHT_GESPEICHERT_GEPRUEFT`. Kein Upload und kein erneuter Entwurf-Speicherklick. Die alte Journalhistorie bleibt unverändert erhalten und wird nur erweitert.
5. Ist im frisch geöffneten Ticket bereits die erwartete vierte Zeile **und** `Anfrage Member` serverseitig vorhanden, kann dieser Zustand nach gesonderter Bestätigung `RC50_GESPEICHERT_GEPRUEFT` ohne neuen Speicherklick im Journal nachgeführt werden. Die Freigabe an `mark.baindl` bleibt nach tatsächlichem Speicherungserfolg ein separater Schritt; Menü 12 sendet keine E-Mail.

## Schnellinstallation

Aus einem separat entpackten RC51-ZIP: `START.cmd`, Menü `1`. Es werden nur die dokumentierten Software-/Hash-/Prozess-/Rollback-Prüfungen ausgeführt, nicht alle historischen Browser-/Unit-Tests. Menü `6` hält die Tests bereit. Danach im installierten Bot Menü `9` (frische Inventur) und `12` (nur Ticket 87278094).

## Prüfgrenzen

Der neue Netzwerk-Timingtest nutzt eine deterministische CDP-Ereignissimulation; der echte Chromium-Speicherklick wurde separat getestet. In dieser Ausführungsumgebung blockiert verwaltetes Chromium lokale HTTP-Testseiten (`ERR_BLOCKED_BY_ADMINISTRATOR`). **Die echte COMARCH-Serverspeicherung und die tatsächliche Weiterleitung sind nicht bestätigt.** Ein erneuter fehlgeschlagener Speicherversuch darf nicht durch eine zweite Klickaktion oder einen Journal-Reset verdeckt werden.
