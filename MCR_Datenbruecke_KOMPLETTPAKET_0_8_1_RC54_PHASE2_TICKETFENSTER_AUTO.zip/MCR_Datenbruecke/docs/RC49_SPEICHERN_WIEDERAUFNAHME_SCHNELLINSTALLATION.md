# RC49 – Ticket speichern und Schnellinstallation

## Echter Windows-Befund aus RC48 (03.11.2026)

Ticket `87278094`, WWID `11368989`: beide PDF-Auswahldialoge ausgefuehrt, beide Dateinamen waren sichtbar, Operator bestaetigte `BEIDE_PDFS_SICHTBAR`. Danach bestaetigte das Journal `UPLOAD_VERIFIED`, `GEVO_VERIFIED`, `DESCRIPTION_VERIFIED`, `DRAFT_SAVE_VERIFIED`. **Erst bei `TICKET_SAVE_INTENT`** stoppte `ACTION_OCCLUDED_OR_OFFSCREEN`. Die Funktion `trustedAction` brach dabei **vor** dem Mausklick ab. Keine neue PDF-Auswahl, GEVO-Neuauswahl oder erneute Entwurfspeicherung sind fuer diese Recovery erlaubt.

## Korrektur

1. `Ticket speichern` nutzt passive Positionswechsel (`center/nearest/start/end`) und DOM-Hit-Test. Nur nach eindeutigem Ziel erfolgt genau ein vertrauenswuerdiger Bot-Mausklick. Bei dauerhafter Verdeckung wird **kein** Botklick versucht, sondern die Person wird nach einer vorausprotokollierten Absicht zu genau einem physischen Klick in **ihrem Bot-Edge** aufgefordert. COMARCH-Status muss anschliessend anhand der Vorgangsliste geprueft werden; eine Bestaetigung in der Konsole allein gilt nicht als Speicherung.
2. Dasselbe *Einklick-Prinzip* gilt fuer `Schritt ausfuehren` im anschliessenden Review. Doppelte/fehlende Schaltflaechen fuehren weiter zum kontrollierten Stopp.
3. Das bestehende `TICKET_SAVE_INTENT` darf **genau einmal** kontrolliert fortgesetzt werden, wenn es das urspruengliche gebundene Ticket/PDF-Set ist und der Operator nach Sichtpruefung aus dem RC48-Log bestaetigt, dass kein vorheriger Ticket-Speicherklick und keine Weiterleitung stattgefunden hat. Keine Loeschung/Reset des Journals. Nach dieser Freigabe **kein zweiter automatischer Wiederanlauf**.
4. Wenn sich beide PDFs und die originale/ergaenzte Beschreibung nach erneutem Oeffnen nicht eindeutig pruefen lassen, STOP ohne neuen Upload. Die `Anfrage Member`-Zuordnung muss exakt bestehen. Ein fehlender Statusmarker wird nur in dieser kontrollierten Recovery und nur bei exaktem Originaltext neu eingesetzt. Anschliessend wird nur `Ticket speichern` abgeschlossen.
5. Die aktuelle **GETRENNTE** Review-Freigabe zu `mark.baindl` bleibt bestehen. Kein Email-Versand.

## Menu 1: schnelle Installation

- Menu 1 aktualisiert aus dem separat entpackten ZIP; der Installationsordner wird wie zuvor abgefragt.
- Pflicht bleiben Manifest-Hashpruefung, Altversions-Pin, Migrationsvorrang, gezielte Prozessbeendigung, Datenbindung, geschuetzte Staging-Kopie, Rueckweg und nachtraegliche Paketpruefung.
- **480+ Unit-/Chromiumtests** und **vier fiktive Browserlaeufe** werden nicht mehr bei jeder Installation wiederholt. Sie bleiben explizit unter Menu 6 (Tests) bzw. Menu 2 (Browserproben) verfuegbar. Aus Menu 1 wird kein Demo-PASS vorgetaeuscht. Menue 3/4 behalten ihre vorhandene versionsgebundene Pilotfreigabe.
- Eine feste 10-Sekunden-Garantie gibt es bei Windows-/Antivirus-Dateisperren nicht.

## Bedienung fuer den aktuellen unterbrochenen Lauf

Nach Installation: Menu 9, danach Menu 12 mit Ticket `87278094`. Im realen Bot-Edge den gleichen Member, die beiden PDFs (und Inhalt), `Anfrage Member` und die Beschreibung pruefen. Das System bietet `SAVE_OHNE_KLICK_GEPRUEFT` nur fuer das genau passende offene RC48-Journal an. **Nur bestaetigen, wenn der alte Log-Abbruch vor dem Ticket-Speichern geschah und seitdem niemand manuell gespeichert oder weitergeleitet hat.** Danach nimmt der Bot nur den Speicherschritt wieder auf; bei erneut verdeckter Schaltflaeche ist ein physischer Klick erforderlich. Bei erfolgreicher serverseitiger Speichernachweis folgt die gesonderte Weiterleitungsentscheidung.

Die hier ausgefuehrten Browsertests sind Chromium-Simulationen, keine Bestätigung eines realen COMARCH-Speicherklicks.
