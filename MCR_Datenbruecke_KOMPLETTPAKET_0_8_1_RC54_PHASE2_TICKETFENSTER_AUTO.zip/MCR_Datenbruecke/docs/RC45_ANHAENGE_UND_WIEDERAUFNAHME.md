# RC45 – Anlagen einzeln auswählen und den Teilupload fortsetzen

Version: **0.8.1-rc.45** · Stand: **3. November 2026**

## Ausgangspunkt

Der letzte bereitgestellte Lauf hat RC44 erfolgreich installiert. In Menü 12 wurde für Ticket `87278094` zuerst `11368989_Kontoauszug_PP+.pdf` ausgewählt. Der nächste protokollierte Fehler lautet `P2_FILEPOND_NOT_STAGED`. Der Anwender hat bestätigt, dass PP+ tatsächlich angehängt wurde und die Dateiauswahl anschließend schließt.

Im RC44-Code galt ausschließlich ein FilePond-Item in einer weiterhin vorhandenen FilePond-Oberfläche als vorläufiger Uploadbeleg. Das erkennt eine anschließend angezeigte COMARCH-Anhangszeile nicht. Außerdem fehlte das erneute Öffnen des Anhangsbereichs, falls dieser nach der Auswahl verschwindet. Der aufgezeichnete Einzeldatei-Erfolg ist daher kein Nachweis, dass beide PDFs angehängt oder gespeichert wurden.

Das vorhandene Journal steht nach dem Log auf:

```text
PREPARED
GEVO_INTENT
GEVO_FOCUS_RETRY_OPERATOR_AUTHORIZED
UPLOAD_INTENT
```

RC45 berücksichtigt genau diesen bereits einmal aus einem GEVO-Fokusabbruch übernommenen Zustand. Ein bloßer neuer Upload-Code ohne Wiederaufnahme hätte denselben Pilotvorgang weiterhin blockiert.

## Geänderter Upload

Jede benötigte PDF erhält eine eigene Dateiauswahl. Das gilt auch dann, wenn ein Eingabefeld Mehrfachauswahl unterstützt. Vor jeder Auswahl wird das aktuelle FilePond-Label mit seinem aktuellen `for`-Attribut und dem zugehörigen `input[type=file]` gebunden. Erst der geprüfte echte Browsermausklick öffnet den abgefangenen nativen Dateidialog; anschließend werden die unveränderten, vorab geprüften lokalen PDF-Pfade an genau dieses Input übergeben.

Das vom Anwender belegte Label lautet `Dateien hierher ziehen oder zum Auswählen klicken`. Dynamische `filepond--browser-*`-Kennungen werden nicht fest eingetragen. Wenn der Bereich verschwunden ist, kann der eindeutig sichtbare Aktionsknopf `Dokument anhängen` ihn öffnen. Der neue Bereich muss danach erneut erkannt werden. Öffnet ein solcher Knopf unmittelbar einen anders gebundenen Dateidialog, stoppt `P2_ATTACHMENT_DIRECT_CHOOSER` vor der Dateiauswahl. Für diese bislang unbelegte Oberflächenvariante wird kein Eingabefeld geraten.

Die Übernahme wird entweder an einem bereiten FilePond-Item oder an einer eindeutigen, sichtbaren Zeile im Anhangsbereich geprüft. Ein Dateiname im Mailtext, ein freier Downloadlink oder der Text eines Dateieingabefelds reichen nicht. Versteckte vorhandene Anlagen gelten als ungeklärt und werden nicht erneut ausgewählt. Fehler, laufende Uploads, doppelte Namen und mehrdeutige Bereiche stoppen den Ablauf.

Vor der tatsächlichen Dateiauswahl werden Ticketbindung und lokale PDF-Prüfsummen erneut geprüft. Pro Datei werden `UPLOAD_FILE_INTENT` vor der Auswahl und `UPLOAD_FILE_STAGED` nach einem eindeutigen UI-Beleg geschrieben. Die Meldung `P2_ATTACHMENT_EVIDENCE` nennt bei unklarem Ausgang Dateiname, Status, Belegart und Anzahl.

## Wiederaufnahme im aktuellen Ticket

Eine bestehende, noch nicht fortgesetzte Upload-Unterbrechung kann geprüft werden, wenn sie vor GEVO-Bestätigung, Beschreibungsänderung, Speichern und Weiterleitung liegt. Beschreibung, Ticket-ID und PDF-Prüfsummen müssen mit dem bestehenden Journal übereinstimmen. Alte Ereignisse werden erhalten und um genau eine geprüfte Übernahme ergänzt.

| Tatsächlich nachgewiesener Bestand | Fortsetzung nach Prüfung |
| --- | --- |
| PP+ vorhanden, DC fehlt | PP+ beibehalten; ausschließlich DC auswählen |
| DC vorhanden, PP+ fehlt | DC beibehalten; ausschließlich PP+ auswählen |
| Beide PDFs vorhanden | Keine Dateiauswahl; danach Gesamtprüfung und GEVO |
| Keine PDF vorhanden | Beide nur nach ausdrücklicher unabhängiger Prüfung auswählen |
| Versteckte, doppelte, fehlerhafte oder unklare Anlage | Keine weitere Dateiauswahl; Bestand sichtbar machen bzw. prüfen |
| Speicherung/Weiterleitung bereits begonnen oder Wiederaufnahme bereits verbraucht | Keine automatische Wiederholung |

Vor der Bestätigung zeigt das Terminal `P2_TEILUPLOAD_PRUEFUNG` mit vorhandenen und fehlenden Dateien. Die gemeinsame Bestätigung lautet:

```text
ANHAENGE_GEPRUEFT_UND_FORTSETZEN
```

Sie bestätigt, dass vorhandene PDFs im selben Ticket inhaltlich geprüft wurden, der angezeigte fehlende Bestand stimmt und aus dem unterbrochenen Lauf noch kein Entwurf-/Ticket-Speichern oder Weiterleiten erfolgt ist. Diese Prüfung ist erforderlich, weil das alte `UPLOAD_INTENT` allein den Ausgang der Dateioperation nicht belegt. Eine abgelehnte Bestätigung lässt das Journal unverändert. Die alte GEVO-Wiederaufnahmebestätigung ist für diesen Teilupload nicht die richtige Entscheidung.

Bei einem weiteren Abbruch nach der genehmigten Übernahme erfolgt kein pauschaler Neustart. Das Journal bleibt zur Klärung erhalten. Journaldateien oder vorhandene PDFs sollen nicht gelöscht werden, um die Prüfung zu umgehen.

## Unmittelbar nächster Lauf

1. Das RC45-ZIP vollständig in einen neuen Ordner entpacken.
2. `START.cmd` aus diesem neuen Paket öffnen und **Menü 1** wählen. Als Ziel die vorhandene Installation verwenden. Nach den eingebauten Selbsttests und fiktiven Browserproben übernimmt der Installer die Software und öffnet das installierte Menü.
3. Im installierten Bot **Menü 9** ausführen. Die Inventur für Menü 12 muss frisch sein; eine alte Ausgabe aus dem vorherigen Chat genügt dafür nicht.
4. **Menü 12** wählen und Ticket `87278094` eingeben.
5. Den angezeigten Anlagenbestand prüfen und die passende gemeinsame Bestätigung eingeben. Bei tatsächlich vorhandener PP+-PDF muss die Fortsetzung nur DC als fehlende PDF anzeigen.
6. Nach beiden eindeutigen Anlagen folgen GEVO `Anfrage Member`, die ergänzte vierte Beschreibungszeile `Bearbeitet not reviewed`, Entwurfs- und Ticketspeicherung sowie die bestehende Prüfung vor der Weiterleitung an `mark.baindl`.

Ein noch gültiger PDF-Prüfbeleg aus Menü 11 wird weiterverwendet. Menü 11 ist nur erneut erforderlich, wenn das Programm einen fehlenden/veralteten Beleg oder veränderte PDF-Dateien meldet. Die Generatoren werden durch Menü 12 nicht gestartet. Menü 12 versendet keine E-Mail.

## Pfade und Datenerhalt

DC bleibt dauerhaft unter `Kontoauszug_DC\Ausgabe_PDF`, PP+ unter `Kontoauszug_pp+\Ausgabe_PDF`, jeweils neben dem installierten Ordner `MCR_Datenbruecke`. Es werden nur die tatsächlich benötigten Planarten DC und/oder PP+ verarbeitet.

Das Update akzeptiert den veröffentlichten RC44-Stand anhand des originalen Manifest-Hashes. Mapping, Konfiguration, Browserprofil, Phase-1-Sendejournal und Phase-2-Journal bleiben am bestehenden Ort. Das neue ZIP enthält Software und zugehörige Prüf-/Referenzdateien, keine lokalen Bestandsdaten, Browserprofile oder erzeugten Laufverzeichnisse.

Der zu Beginn des bereitgestellten Outputs beobachtete `PACKAGE_SIZE`-Fehler war mit den gelieferten Original-ZIPs nicht reproduzierbar: RC40 bis RC44 waren intern hinsichtlich Dateilängen und SHA-256 konsistent. Die konkrete Ursache des damaligen lokalen Unterschieds ist deshalb nicht belegt. Ein vollständig separat entpacktes RC45-Paket vermeidet ein ungeprüftes Mischen der neuen Software mit bestehenden Dateien; die Integritätsprüfung bleibt aktiv.

## Grenzen des Prüfnachweises

Die lokalen Regressionen verwenden fiktive Dateien und kontrollierte DOM/CDP-Modelle. Sie prüfen unter anderem das erneute Öffnen, die beiden getrennten Auswahlen, den Teilupload-Wiederanlauf und das Journal vor der Dateioperation. Sie sind kein echter Windows-/Edge-/COMARCH-Nachweis.

Die Build-Umgebung besitzt keine Chromium-Binary; der reguläre Download lieferte eine nicht nutzbare HTML-Antwort. Die vorbereiteten nativen Browserregressionen werden deshalb erst durch den Windows-Selbsttest ausgeführt. Die endgültige COMARCH-Bestätigung muss im nächsten beaufsichtigten Pilot erfolgen. Ein sichtbarer Anlagenname gilt weiterhin zunächst nur als UI-Beleg; dauerhafte Verfügbarkeit wird nach dem Speichern und erneuten Öffnen des Tickets geprüft.

Der genaue lokale Prüfstand und die ausdrücklich nicht ausgeführten Prüfungen stehen in `RC45_PRUEFBERICHT.json`. Frühere Prüfberichte im Paket gelten ausschließlich für ihre darin genannten Versionen.
