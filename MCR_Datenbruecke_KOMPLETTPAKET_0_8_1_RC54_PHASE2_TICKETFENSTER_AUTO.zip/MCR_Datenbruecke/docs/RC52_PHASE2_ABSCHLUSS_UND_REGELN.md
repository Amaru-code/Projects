# RC52 – Abschluss, Wiederaufnahme und weitere Phase-2-Regeln

## Ursache und Grenzen der Diagnose
Im gelieferten RC51-Log wurde genau ein Ticket-Speicherklick protokolliert,
anschließend NETWORK_QUIET mit zwei Schreibrequests. Danach brach das erneute
Öffnen mit QUEUE_OPEN ab. Daraus folgt kein Nachweis, dass Speichern scheiterte.
RC52 wiederholt diesen Klick nicht: Es liest Beschreibung, GEVO und Anlagen
im frisch geöffneten Ticket zurück. Der genaue HTML-Grund für QUEUE_OPEN im
Produktivsystem ist nicht überliefert. Die Positions-/Zeilenerkennung wird
gezielt korrigiert; ein Test bildet u.a. doppelte Ticketreferenztexte nach.

## Installation und Start
ZIP außerhalb der installierten MCR_Datenbruecke entpacken. START.cmd, Menü 1.
Schnellinstallation, Prozessbeendigung, Softwarearchiv und Datenerhalt bleiben.
Keine komplette Testsuite oder Browserdemo bei der Installation.
Anschließend installierte START.cmd, Menü 12, Startticket (z.B. 87278094), START.
ENTER statt Startticket nimmt den ersten passenden sichtbaren Vorgang.
Menü 12 erstellt seine frische Nur-Lese-Inventur selbst; Menü 9 ist optional.
Kein E-Mail-Versand und kein automatischer PDF-Generatorstart.

## Kontoauszug und RC51-Wiederaufnahme
RC48-Dateiauswahl bleibt bytegleich. Bei dem protokollierten RC51-Abbruch wird
kein PDF erneut ausgewählt, kein Entwurf neu gespeichert und kein weiterer
Ticket-Speicherklick ausgeführt. Die alte Ereignisfolge bleibt vollständig.
Nur eine frisch bestätigte vierte Zeile, Anfrage Member und vorhandene PDFs
lassen den Ablauf zur Prüfung fortsetzen. Sind PDFs weiterhin nur als
UNBOUND_NAME erkennbar, bleibt die Inhalts-/Sichtprüfung erforderlich.
Fehlen tatsächliche Serverwerte, stoppt RC52 statt einen zweiten Speicherklick
oder erfolgreiche Speicherung zu erfinden.

## Gemeinsamer Prüfschritt
GEVO Anfrage Member und Status Bearbeitet not reviewed müssen bestätigt sein.
Das sichtbare select wird über option value=FORWARD_TO_REVIEW identifiziert,
nicht über die wechselnde j_id7870. Danach wird auf das freigegebene Feld
mainForm:next-persona-assignment-id gewartet. Nur ein echter anklickbarer
Vorschlag Baindl Mark (mark.baindl) darf gewählt werden. Alte Erfolgsmeldungen
sind keine Vorschläge. Genau ein Klick auf Schritt ausführen. Erst nach
Abschlussnachweis und Rückkehr zur Liste folgt das nächste Ticket.
Eine bloß verschwundene Zeile ist wegen Filterung/Paginierung kein Beweis.
Ohne erkennbare neue Erfolgsmeldung fordert der Bot WEITERLEITUNG_GEPRUEFT;
bei Abbruch bleibt EXECUTE_INTENT bestehen, es gibt keinen zweiten Klick.

## Neue Regeln, Priorität und Originaltext
1. Physische Zeile 1 enthält das eigenständige Plan-Kürzel DB oder DB+ und
   physische Zeile 2 lautet Standardantwort versendet: direkte Weiterleitung
   an Mark. Diese ausdrücklich immer geltende Regel hat Vorrang, auch bei
   gleichzeitigem DC/PP+ oder einer privaten MBC-Anfrage. GEVO und Status
   werden gesetzt/gespeichert; kein PDF, kein Antwortentwurf, kein Versand.
   Auswahl über mainForm:persona-assignment-id, dann genau ein Klick auf
   mainForm:current-performer-assign-link (Weiterleitung). Nicht der Prüfschritt.
2. Physische Zeilen 1 und 2 sind befüllt, Zeile 3 lautet exakt
   Möchte Log-in MBC mit privater E-Mail: Original-Antworttext des Nutzers,
   persönlich angeredet mit Nachnamen aus dem verifizierten Memberprofil.
   Herr/Frau aus der konsistenten Bestands-Anrede, sonst ausdrückliche Wahl
   HERR/FRAU nach Prüfung; keine Namens- oder Geschlechtsvermutung.
   Entwurf speichern, Ticketwerte bestätigen, gemeinsamer Prüfschritt an Mark.
   Ein anderer bestehender Entwurf wird nicht überschrieben.
3. Bekannter Kontoauszug-Fall: vorhandener PDF-Prüfbeleg aus Menü 11 und
   unveränderte PDFs erforderlich. Keine stillschweigende Generatorausführung.

Der Text der MBC-Antwort liegt unverändert (abgesehen von Anrede/Nachname)
in lib/phase2-work-rules.mjs. Alle drei Wege erhalten am Ende der zusätzlichen
Beschreibung genau einmal Bearbeitet not reviewed. Keine Kürzung bestehender
Zeilen, kein Überschreiten der 450-Zeichen-Grenze.

## Fortsetzung und Protokoll
Ein Browser für den Lauf. Nach jedem bestätigten Abschluss wird die aktuelle
Liste neu gelesen. Unbekannte Fälle, fehlende PDF-Belege und gesperrte frühere
Vorgänge werden mit Grund angezeigt, nicht geraten. Der Ablauf arbeitet die
jeweils sichtbare eigene Vorgangsliste ab (einschließlich nachrückender Zeilen),
maximal 100 bestätigte Abschlüsse. Andere Listenseiten werden nicht automatisch
durchgeblättert; COMPLETE ist keine Aussage über unsichtbare Queue-Seiten.
Ein unklarer Schreib-/Weiterleitungsschritt im laufenden Fall stoppt den Lauf.
Lokale Berichte: .runtime/phase2/MCR_PHASE2_LAUF_<Zeitstempel>.log und .json.
Neue DB/MBC-Journale haben eigene Dateien MCR_PHASE2_WORK_<Ticket>.json;
vorhandene PDF-Journale und Phase-1-Sendejournale werden nicht gelöscht.

## Nachweisgrenze
Chromium-Prüfungen nutzen eine nachgebildete COMARCH-Oberfläche mit den
übermittelten Feldverträgen. Es wurde kein echtes COMARCH-Ticket bearbeitet.
Details und tatsächlich ausgeführte Tests stehen in RC52_PRUEFBERICHT.json.
