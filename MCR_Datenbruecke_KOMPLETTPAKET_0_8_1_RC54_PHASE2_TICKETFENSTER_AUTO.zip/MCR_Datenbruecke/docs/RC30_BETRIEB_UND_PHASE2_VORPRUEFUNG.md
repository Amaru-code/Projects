# MCR Datenbrücke 0.8.1-rc.30 – Abnahmeplan

## Erstsichtung: Änderungen

1. Exakt vertauschte Vor-/Nachnamen von E-Mail und den getrennten, ID-gebundenen COMARCH-Profilfeldern werden als spezieller, weiter freigabepflichtiger Konflikt erkannt. Die Anrede verwendet erst nach ausdrücklicher Freigabe den korrigierten Namen. Vor einem Sendeklick werden Profilfeld, Member-ID und Name erneut geprüft. Ein ID-Konflikt wird nie freigegeben.
2. MercerID, Vorname und Nachname: bis drei Versuche mit eindeutiger Meldung. Bei drei Fehleingaben kann eine alternative Kontrolle über Nachnamen oder ID gewählt werden; diese ersetzt **nie** die vollständige Identitätsprüfung. Optional neue COMARCH-Member-Auswahl und erneute vollständige Bestätigung. Ohne eindeutigen Nachweis bleibt das Ticket unbearbeitet und die übrigen Tickets können weiterlaufen, **ausschließlich wenn noch keine Sende-/Speicher-/Weiterleitungsabsicht des betroffenen Tickets begonnen hat**.
3. Pro Tag werden der vollständige, fortlaufende Konsolen-Text für Pilot und Folgelauf in `.runtime/reports/MCR_ECHTLAUF_YYYY-MM-DD.log` und abgeschlossene/ausgesetzte Ticketaktionen in `.runtime/reports/MCR_TICKETVERLAUF_YYYY-MM-DD.csv` geschrieben. Diese Dateien können personenbezogene oder betriebsinterne Angaben enthalten: nur im lokalen gesicherten Bot-Ordner belassen, nicht öffentlich teilen. Die bereits existierenden Diagnosen sind weiterhin auf technische Metadaten beschränkt.
4. Am Ende des echten Piloten bleibt der Bot-Edge bis zur ENTER-Freigabe für die Sichtkontrolle offen. Zur abgesicherten Fortsetzung wird dieses Profil danach geschlossen und ein neuer eindeutig gebundener Browser gestartet. Nach dem letzten Lauf bzw. nach Menü 4 kann `OFFEN` gewählt werden, um die Edge-Ansicht für die Kontrolle stehenzulassen. Vor dem nächsten Start muss der Operator diesen Bot-Edge selbst schließen.
5. Die Laufgeschwindigkeit pro Ticket wird nicht absichtlich verzögert. Das Status-Overlay bleibt getrennt, nicht fokussierbar und browserunabhängig.

## Phase 2: vorerst ausschließlich Lese-/Entscheidungsprobe

Der im HTML genannte `mainForm:tasksTableFor_MyTasksList` und seine Textareas sind plausible Lesestellen; ICEfaces-IDs mit `j_idNNN` sind dynamisch und dürfen nicht als stabile Selektoren benutzt werden. Der Phase-2-Parser in `lib/phase2-account-statement-plan.mjs` erkennt nur eine genau begrenzte dritte Zeile (`Möchte Kontoauszug`, `Möchte KA`, bewusst begrenzter Tippfehler `Möchet KA`) und die belegten USC-Planzeilen. DC + PP+ ergeben **zwei** dokumentierte Ziel-PDFs. Ein falsch geschriebener Versandstatus, z. B. `Stansardantwort versendet`, wird vorerst nicht als verifizierter Versand gewertet.

Die vorhandene MercerID darf **nicht** mit der WWID gleichgesetzt werden. Eine unabhängig verifizierte WWID aus einer autorisierten Quelle und die Betriebsschnittstellen/Exitcodes der tatsächlichen `START_KONTOAUSZUG*.bat`-Skripte fehlen in diesem Paket. Die Planung nennt die vom Benutzer bereitgestellten Pfade, startet aber keine BAT und liest keine privaten PDF-Dateien.

### Bestehende Generatoren (zur späteren Prüfung, NOCH NICHT aufgerufen)

- PP+: `C:\Users\Amaru-Zegarra\projects\Aktive_Projekte\Ticket_bot\Kontoauszug_pp+\START_KONTOAUSZUG.bat`, Ergebnisordner `Kontoauszug_pp+\Ausgabe_PDF`. Genanntes Muster: `{Datum}_Kontoauszug_{Nachname}_{Vorname}.pdf`.
- DC: `C:\Users\Amaru-Zegarra\projects\Aktive_Projekte\Ticket_bot\Kontoauszug_DC\START_KONTOAUSZUG_DC.bat`, Ergebnisordner `Kontoauszug_DC\Ausgabe_PDF`. Genanntes Muster: `Intel_{wwid}_KA_DE_{aktuelles_Jahr}.pdf`.

Ein Dateiname allein ist **kein Nachweis**, dass der erzeugte Kontoauszug tatsächlich zur betroffenen Person gehört. Beide Programme sind interaktive BAT-Starts; insbesondere muss zunächst geprüft werden, ob die WWID per STDIN, als Argument oder auf anderem Weg sicher verarbeitet werden kann und ob Rückgabecode und PDF-Erstellung verlässlich sind.

### Verbindlicher zukünftiger Schrittplan für den separaten Phase-2-Piloten

1. Bereits in Bearbeitung befindliches, exakt gebundenes Ticket identifizieren. Tatsächlichen Ticket-Status, E-Mail-Quelle, zusätzliche Beschreibung und vollständigen Standardantwort-Versandnachweis prüfen; in bestehenden Entwürfen und ungeklärten Fällen nicht eingreifen.
2. `Second Level`, `Allgemeine Schriftwechsel`, `Personenschriftwechsel` aus dem echten Ticket lesen und ggf. unter den vorhandenen verifizierten Selektionsregeln setzen; nicht blind aus der Queue-Tabelle ableiten.
3. `mainForm:gevo-value-id` mit `Anfrage Member` erst nach gesicherter UI-Bindung befüllen und den gewählten Wert rücklesen.
4. Für jedes vorhandene DC/PP+-Planmerkmal die passende vorhandene BAT ausschließlich per **Argument-/Prozessvertrag, nicht durch Shell-Kommandoverkettung**, mit bestätigter WWID kontrolliert aufrufen. Externe Programme nie allein aufgrund von Text aus dem Ticket starten.
5. Neue PDFs gegenüber einem vor dem Start eingefrorenen Dateibestand anhand Inhalt und sicherem Dateimuster, unverwechselbarer WWID bzw. verifiziertem Namen, Programmlauf, Ausgabeordner und eindeutiger Neuheit prüfen. Doppelte/stale/unklare PDFs sperren; nur genau die benötigten Dateien als Dateiupload anhängen und anschließend tatsächliche Anlagen im COMARCH-Entwurf nachweisen.
6. Erst wenn **alle** erwarteten Kontoauszüge nachweislich erzeugt UND angehängt sind, die vierte Zeile `Bearbeitet not reviewed` ausschließlich append-only ergänzen. Vorhandene USC- und Standardantwort-Zeilen sowie die dritte `Möchte ...`-Zeile unverändert erhalten; 450-Zeichen-Grenze beachten.
7. `Entwurf speichern`, `Ticket speichern`, gespeicherten Text und Anlagen rückprüfen; danach `FORWARD_TO_REVIEW` und tatsächlich ausgewählten `Baindl Mark (mark.baindl)` verifizieren. Erst danach **einmal** `Schritt ausführen`. Keine automatische Wiederholung nach unbekanntem Ergebnis.

**Nicht Bestandteil der Freigabe RC30:** automatisches BAT-Ausführen, Datei-Upload, neue Beschreibungsviertezeile, Entwurf speichern, Weiterleitung an Baindl Mark. Erst gesonderte lokale Windows-/COMARCH-Abnahme mit fiktiven PDFs, danach beaufsichtigter Echtpilot und explizite Freigabe.

## Prüfgrenzen

Vorliegende Tests: Javascript/Chromium auf Linux. Windows CMD, Windows-PowerShell-Fenster, produktive COMARCH-Eingaben, externe Kontoauszugs-BATs und echte Downloads sind **nicht** direkt in dieser Umgebung ausführbar. Die Installation bleibt auf Softwareupdate begrenzt; `private_data`, `Config`, Browserprofil und das vorhandene Journal bleiben erhalten.
