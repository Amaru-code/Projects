# RC54 – Phase-2-Ticketfenster, Freigabe und Abschlussnachweis

## Bedienung

Das vollständige Paket separat entpacken; START.cmd und Menü 1 aktualisieren die bestehende Installation ohne automatische Langtests oder Demos. Danach die installierte START.cmd und Menü 12 verwenden. Die Startnummer kann leer bleiben. Bereits im lokalen Journal als ROUTED_VERIFIED abgeschlossene Tickets werden nicht erneut ausgeführt. Ein frischer Lauf startet MANUELL; AUTO wird bewusst im Fenster aktiviert und gilt für die folgenden Tickets desselben Laufs.

Unten links steht genau das aktuelle Ticket mit Member-Anzeige, USC/Plänen, Anfrage, Bearbeitungstyp, Zielkonto und Schritt. Im manuellen Modus führt der Knopf »An Mark weiterleiten« bzw. »Zur Prüfung an Mark« genau die jeweilige abschließende COMARCH-Aktion aus. Vorher werden Entwurf/Beschreibung gespeichert und geprüft, sodass die Bedienperson den vorbereiteten Zustand kontrollieren kann. Im AUTO-Modus entfällt diese einzelne Freigabe. STOP verhindert weitere automatisierte Maus-/Tastatureingaben; eine bereits erfolgte Serveraktion wird dadurch nicht rückgängig gemacht.

Nach bestätigtem Abschluss wird die aktuelle Karte als unabhängiges, nicht anklickbares Fenster über fünf Sekunden von unten links nach oben links bewegt und weich ausgeblendet. Die nächste Ticketkarte erscheint unten links, ohne auf die alte Animation zu warten. Kein Gesamtsammelfenster für mehrere Tickets. Die vorhandene Abschlussanzeige der Phase-1-Menüs 3/4 bleibt unverändert.

## Zielperson und zwei getrennte Wege

Prüfung: FORWARD_TO_REVIEW → ausschließlich mainForm:next-persona-assignment-id → echter exakter Vorschlag Baindl Mark (mark.baindl) → Schritt ausführen.

Direkte DB-/DB+-Weiterleitung: ausschließlich mainForm:persona-assignment-id → echter exakter Vorschlag Baindl Mark (mark.baindl) → mainForm:current-performer-assign-link.

Vorschläge werden unmittelbar vor dem Mausereignis neu gelesen und per Hit-Test überprüft. Ein Name ohne Konto, ein anderes Konto, ein bloßer Suchtext oder das benachbarte Eingabefeld zählt nicht als Auswahl. Eine bereits im HTML serverseitig vorgegebene vollständige Kontoauswahl bleibt nach stabiler Mehrfachprüfung erhalten; bloß eingetippter Text genügt dafür nicht. Nach einer neuen Auswahl und dem Fokuswechsel wird das Ergebnis geprüft. Eine begrenzte Neuauswahl ist nur VOR der Weiterleitung zulässig. Nach der manuellen Wartephase werden Ticket, GEVO, Beschreibung, Anlagen/Entwurf und Empfänger erneut geprüft.

## Ohne die wiederholte Texteingabe WEITERLEITUNG_GEPRUEFT

Im normalen Menü-12-Lauf wird diese Terminalabfrage nicht verwendet. Automatisch anerkannt wird eine neue, zum Zielkonto passende Erfolgsmeldung oder folgende Kombination:

* Genau ein autorisierter COMARCH-Abschlussklick mit bestätigtem Ticket und Empfänger.
* Erfolgreicher gleichursprünglicher POST, dessen Formularparameter genau den ausgeführten Abschlussknopf identifizieren. Ein fremder Hintergrundrequest genügt nicht.
* Rückkehr in dieselbe eigene Liste mit unveränderten Filter-/Seiten-/Sortiermerkmalen; nur das bearbeitete Ticket fehlt, die übrigen vorher sichtbaren Tickets bleiben erhalten. Eine erneute Listenabfrage bestätigt denselben Stand; keine Fehlermeldung ist sichtbar.

Diese kombinierte Beobachtung ist ein UI-/Netzwerknachweis, kein direkter Datenbankzugriff. Bloßes Verschwinden einer Zeile bleibt unzureichend. Fehlt der kombinierte Nachweis (etwa weil COMARCH den auslösenden Formularparameter nicht offenlegt), fordert die Karte »Weiterleitung geprüft« als EINEN manuellen Nachweis an – auch im AUTO-Modus. Es gibt keinen zweiten Weiterleitungsklick. Falscher Empfänger, anderer Ticketbeleg oder Fehlernachricht führen zum Stopp. Wenn das native Fenster nicht startet, ist die ticketgebundene Terminalfreigabe die Rückfallebene; AUTO wird nicht stillschweigend angenommen.

## MBC: private E-Mail

Die dritte physische Beschreibungszeile darf exakt eine der beiden vom Nutzer verwendeten Schreibweisen sein:

»Möchte Log-in MBC mit privater E-Mail« oder »Möchte Log-in MBC mit privater Email«.

Die ersten beiden Zeilen müssen befüllt sein. DB/DB+ mit exakt »Standardantwort versendet« in Zeile 2 hat weiter Vorrang. Der bereits vorgegebene vollständige Antworttext bleibt unverändert; Anrede/Nachname stammen aus dem bestätigten Member/Bestand. Ein abweichender bestehender Entwurf wird nicht überschrieben. Ablauf: GEVO Anfrage Member, Antwortentwurf speichern, Bearbeitet not reviewed einmal ergänzen, Ticket speichern/neu lesen, an mark.baindl zur Prüfung. KEIN E-Mail-Versand.

Die Fallzählung P2_FALLERKENNUNG und die Überspringgründe zeigen, ob ein MBC-Fall überhaupt erkannt wurde. Offene Phase-1-Sendejournale bleiben gesperrt; diese werden nicht für MBC umgangen. Die Inventur umfasst weiterhin die sichtbare eigene Liste, nicht sämtliche paginierten Seiten.

## Menü 5

Der gezielte Abschluss ohne Neuversand öffnet die Ticket-ID jetzt über die exakte Tabellenspalte. Eine gleichlautende Referenz in einer anderen Spalte zählt nicht als zweiter Treffer. Der Modus bleibt ohne Antwort-/Versandfunktion und behält die bisherigen Nachweisprüfungen.

## Grenzen der Qualifikation

Die beigefügten Tests verwenden echte Chromium-Eingaben und eine lokale nachgebildete COMARCH-Oberfläche. Der neue automatische Nachweis wird mit ausdrücklich modellierten, an die tatsächlichen Chromium-Klicks gebundenen Netzwerkereignissen geprüft. Echte Browser-HTTP-Aufrufe sind durch die verwaltete URL-Sperre dieser Umgebung blockiert; diese Sperre wurde nicht verändert. Native Windows-Forms-Ausführung und die produktive COMARCH-Oberfläche stehen in der Entwicklungsumgebung nicht zur Verfügung und werden nicht als ausgeführt ausgewiesen. Insbesondere die echte Fensteranimation und die produktiven Abschluss-POSTs bleiben auf Windows zu bestätigen.
