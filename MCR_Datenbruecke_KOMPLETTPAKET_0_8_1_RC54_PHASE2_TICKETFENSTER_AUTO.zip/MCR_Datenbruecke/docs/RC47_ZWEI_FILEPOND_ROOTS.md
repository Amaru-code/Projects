# RC47 – Zwei FilePond-Wurzeln: fehlende PDFs nicht als mehrdeutig einstufen

## Fehlerbericht aus dem echten RC46-Pilot vom 03.11.2026

Beim Ticket `87278094` / WWID `11368989` wurden bereits **vor der ersten Auswahl** zwei sichtbare `.filepond--root`-Bereiche gefunden. Der RC45-Pruefcode enthielt `if(roots.length>1) { status='AMBIGUOUS'; source='MULTIPLE_FILEPOND_ROOTS'; }`. Das verursachte:

```
P2_ATTACHMENT_EVIDENCE: {"rootCount":2,"items":[...status:"AMBIGUOUS",source:"MULTIPLE_FILEPOND_ROOTS"...]}
STOP P2_UPLOAD_EVIDENCE_UNCLEAR
```

Diese Fehlklassifikation war nicht durch eine nachgewiesene doppelte Datei begruendet. Nach dem STOP wurde das nur fuer diesen Lauf gestartete Bot-Edge geschlossen. Es wurde weder eine PDF ausgewaehlt noch eine Nachricht versendet.

## Exakte Korrektur

Die Mehrzahl sichtbarer FilePond-Container ist nur **Diagnosemetadatum**. **Jede erwartete PDF** wird getrennt nach ihren exakten, gebundenen Dateieintraegen in FilePond und COMARCH-Anhangszeilen klassifiziert. Mehr als ein wirklich zu dieser PDF passender Eintrag bleibt `DUPLICATE` bzw. `AMBIGUOUS` und blockiert. Ein einziger versteckter/beschaeftigter/fehlerhafter/noch unbekannter Eintrag blockiert ebenfalls. Reiner Nachrichtentext, E-Mail-Downloadlink oder fremdes FilePond-Widget ist kein Anlagenbeleg.

Die bereits in RC45 vorhandene Uploadreihenfolge bleibt **PP+ zuerst, dann bei geschlossenem Explorer erneut `Dokument anhaengen` und DC**. Die native Dateiauswahl bleibt pro Datei an ein frisch verifiziertes FilePond-Label/Datei-Input gebunden; zwei gleichzeitig gleich plausible Dateiauswahl-Labels sind weiterhin ein Stop. Kein erneuter Dateiklick bei unklarer Anlage, kein ungeprueftes Journal-Reset.

## Weiterfuehrung des konkreten Tickets

1. RC47 als volles neues ZIP getrennt entpacken und ueber Menue 1 ueber der installierten RC46-Version installieren. Die RC46-Migration darf weiterhin ausschliesslich zu dieser Installation gehoerige Prozesse schliessen. Die bestehenden Runtime-/Ticketdaten bleiben erhalten.
2. Im **installierten RC47** Menue 9 mit frisch angemeldetem Bot-Edge ausfuehren (nur lesen), danach Menue 12 fuer `87278094`.
3. Wenn ein altes `UPLOAD_INTENT` existiert, vor dem Bestaetigen den tatsaechlichen Bestand der beiden PDFs **im selben Ticket** und alle schon ausgefuehrten Aktionen unabhaengig pruefen. Bestaetigung `ANHAENGE_GEPRUEFT_UND_FORTSETZEN` nur bei zutreffendem, unveraendertem Bestand und ohne spaetere Speicherung/Weiterleitung. Eine nachgewiesene PP+ wird nicht erneut angehaengt.
4. Pro nachweislich fehlender PDF genau ein File-Chooser, danach im COMARCH-Anhangsbereich die vorlaeufige Uebernahme pruefen, bevor die naechste ausgewaehlt wird.
5. Wenn nach dem Auswaehlen von PP+ kein eindeutiger Eintrag erscheint, bewusst STOP ohne erneuten Upload. Bei einem echten COMARCH-Dialogfehler muss die zugehoerige UI-Diagnose nachgereicht werden.

## Nachweisgrenze

Die Browserregressionen wurden mit lokalem Headless Chromium und echten CDP/OS-Chooser-Events, jedoch gegen eine kontrollierte COMARCH-DOM-Nachbildung ausgefuehrt. Sie belegen nicht das Verhalten des echten COMARCH-Servers unter Windows. Eine echte Kontoauszug-Anlage, Speicherung oder Weiterleitung wurde aus der Buildumgebung nicht angestossen.
