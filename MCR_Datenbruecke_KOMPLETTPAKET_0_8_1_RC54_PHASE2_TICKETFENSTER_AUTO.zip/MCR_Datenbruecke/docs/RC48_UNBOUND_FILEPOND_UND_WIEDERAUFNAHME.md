# RC48 – COMARCH zeigt Dateinamen nach nativer Auswahl ungebunden

## Reale Beobachtung (RC47, 03.11.2026)

Ticket 87278094, WWID 11368989. Im echten COMARCH wurde `11368989_Kontoauszug_PP+.pdf` per `Page.fileChooserOpened` und `DOM.setFileInputFiles` ausgewaehlt, danach meldete die read-only-Pruefung `rootCount=2` und `UNBOUND_NAME / UNBOUND_VISIBLE_TEXT / unboundCount=1`. Das ist KEIN Nachweis einer serverseitig gespeicherten Anlage. RC47 stoppte dadurch *vor* der zweiten DC-Dateiauswahl.

## Gezielter RC48-Ablauf

1. Nur in einem aktuell identifizierten COMARCH-Ticket und nach aktueller Anlageninventur eine wirklich fehlende PDF per nativem Dateidialog auswaehlen. Das Journal schreibt `UPLOAD_FILE_INTENT` vor der Auswahl.
2. Liefert das UI einen eindeutigen gebundenen READY-Zustand, bleibt der bisherige `UPLOAD_FILE_STAGED`-Pfad unveraendert.
3. Zeigt das UI stattdessen nach der nativen Auswahl genau einen *neuen*, ungebundenen Dateinamen, dann schreibt RC48 `UPLOAD_FILE_PROVISIONAL`, **nicht** `UPLOAD_FILE_STAGED`. Das ist nur eine sichtbare Dateiauswahl; keine Speicherbestaetigung.
4. RC48 kann mit der anderen, weiterhin **fehlenden** PDF fortfahren: Frisches `Dokument anhaengen`, neuer dynamischer FilePond-Input, neuer nativer Windows-Explorer. Die erste Datei wird nicht erneut ausgewaehlt.
5. Sind beide PDFs als gebundene Anlagen READY, geht es automatisch weiter. Sind beide Dateinamen nur visuell und nicht sicher gebunden, erfolgt eine **einmalige** explizite Sicht-/Inhaltskontrolle im Bot-Edge `BEIDE_PDFS_SICHTBAR`; ohne sie kein GEVO und keine Speicherung. Doppel-, versteckte oder Fehler-Eintraege bleiben gesperrt.
6. Erst nach GEVO `Anfrage Member`, Beschreibung `Bearbeitet not reviewed`, Entwurf und Ticket-Speichern ist eine Weiterleitung an `mark.baindl` zulaessig. Sind die PDFs beim erneuten Oeffnen nur als ungebundener Text sichtbar, ist vor der Weiterleitung eine zweite manuelle Kontrolle der *gespeicherten* Anlagen mit `GESPEICHERTE_PDFS_GEPRUEFT` erforderlich. Das Audit unterscheidet diese Sichtkontrolle weiterhin von automatischem Serverbeleg.
7. Menue 12 versendet KEINE E-Mail und startet KEINE Generatoren. Automatische Prozessbeendigung bei Migration und alle gesperrten Phase-1-Laufjournale bleiben unberuehrt.

## Bestehender unterbrochener RC47-Lauf

Das aktuelle Journal enthaelt bereits eine erste `UPLOAD_RECONCILIATION_OPERATOR_AUTHORIZED`-Freigabe und einen erneuten `UPLOAD_FILE_INTENT` fuer PP+. RC48 erlaubt **keine automatische Wiederholung**. Eine erneute Fortsetzung setzt eine neue `Menue 9`-Inventur, die aktuelle Ticket-/Member-/WWID-/PDF-Kontrolle, keinen frueheren Save/Forward und eine *erneute ausdrueckliche* Freigabe voraus. RC48 akzeptiert eine erneute kontrollierte Reconciliation nur bei neuer File-Intent seit der letzten Freigabe und innerhalb eines begrenzten Versuchsbudgets. Keine Loeschung/Aufweichung bestehender Journale.

## Testreichweite

Chromium/CDP-Test reproduziert `UNBOUND_NAME` aus dem Live-Log, zwei sichtbare FilePond-Roots und zwei echte Dateiauswahldialoge mit neuer dynamischer Input-ID. Fehlende/mehrfache Dateinamen und bereits sichtbare PDFs stoppen weiterhin. Das ist ein Test gegen lokales COMARCH-DOM-Modell, kein echter Edge-/COMARCH-Beleg.
