# RC44 – dauerhafte DC-Verzeichnisbezeichnung und sauberes Paket

**Betriebspfad:** `C:\Users\Amaru-Zegarra\projects\Aktive_Projekte\Ticket_bot\Kontoauszug_DC\Ausgabe_PDF`.
Der zweite, unveränderte Pfad ist `C:\Users\Amaru-Zegarra\projects\Aktive_Projekte\Ticket_bot\Kontoauszug_pp+\Ausgabe_PDF`.

Der zentrale Eintrag `PHASE2_SCRIPTS.DC.subfolder` in `lib/phase2-account-statement-plan.mjs` lautet fest `Kontoauszug_DC`. Menüs 10, 11 und 12 benutzen denselben Eintrag über `generatorPaths()`. Es werden ausschließlich exakt WWID-gebundene PDFs wie `11368989_Kontoauszug_DC.pdf` und `11368989_Kontoauszug_PP+.pdf` übernommen. Die Datei wird nicht in COMARCH hochgeladen, ohne dass der bewährte separate Phase-2-Schreibpilot seine Prüfungen bestanden hat.

**Clean ZIP:** Das veröffentlichte ZIP enthält ausschließlich Dateien des neuen `MANIFEST.json` und die zugehörige `SHA256SUMS.txt`. Es enthält keine Diagnose-/Ergebnis-ZIPs, keine privaten Daten, kein Edge-Profil und keine Laufjournale. Bestehende Diagnose- und Ergebnisordner der alten Installation werden beim gesicherten Softwareupdate *nicht gelöscht*; vorhandene Journale und Status bleiben erhalten. Alte Test- und Referenzdateien bleiben bewusst versiegelt, solange der Installer diese für die geprüfte Update- und Wiederanlaufsicherung benötigt. Eine spätere Entkopplung ist ein eigenes, separat zu testendes Release.

**Upgrade:** RC43 wird anhand seines unveränderten Originalmanifests nachgewiesen; der Installer ersetzt nur die freigegebene Software. Der bereits laufende Phase-2-Pilot für Ticket 87278094 muss bei offenem `GEVO_INTENT` weiterhin ausdrücklich und korrekt überprüft werden; dieses Paket beseitigt ausschließlich den Ordnernamen-Fehler und hebt keinerlei Sperren auf.
