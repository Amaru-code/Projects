# RC46 – Migration hat Vorrang

Version: **0.8.1-rc.46** · Stand: **3. November 2026**

## Anlass und Ergebnis

Der vorgelegte Konsolenlauf zeigt zwei abgebrochene Updateversuche von `0.8.1-rc.44` auf `0.8.1-rc.45`. Beide enden vor dem Softwaretausch mit `MCR_PROCESSES_ACTIVE`. Damit belegt dieser Output keine Installation von RC45. Welche konkrete PID den alten Prozesswächter ausgelöst hat, lässt sich aus der pauschalen Meldung nicht feststellen; ein sichtbar aktives Botfenster ist daraus ebenfalls nicht abzuleiten.

RC46 kann die vorhandene RC44-Installation direkt übernehmen. Auch ein bereits installiertes RC45 ist als Ausgangsversion unterstützt. Menü 1 aus dem neuen Paket reserviert die Zielinstallation, beendet ihre eindeutig zugeordneten Botprozesse einschließlich des Bot-Browsers und hält die Installation während der anschließenden Prüfungen und des Softwaretausches gesperrt. Das automatische Beenden gehört zum Updateablauf. Es gibt dafür keinen zusätzlichen Freigabedialog.

Die bestehende Bestätigung `EINRICHTEN` steht weiterhin nach den Selbsttests und fiktiven Proben unmittelbar vor dem Softwaretausch. Zu diesem Zeitpunkt sind die eigenen Botaktivitäten bereits beendet und neue Starts gesperrt.

## Update aus dem neuen Paket

1. Das vollständige RC46-ZIP in einen **neuen, separaten Ordner** entpacken. Die Dateien nicht von Hand über die vorhandene Installation kopieren.
2. `START.cmd` aus diesem neu entpackten Paket öffnen. Die Menüüberschrift muss `MCR DATENBRUECKE 0.8.1-rc.46` anzeigen.
3. **Menü 1 – Einrichten / aktualisieren und testen** wählen. Den vorhandenen Installationsordner als Ziel übernehmen. Für den vorgelegten Fall ist das `C:\Users\Amaru-Zegarra\projects\Aktive_Projekte\Ticket_bot\MCR_Datenbruecke`.
4. Die Migration übernimmt den Vorrang, beendet die zugeordneten Botaktivitäten und prüft den Stillstand anhand einer neuen Prozessliste. Anschließend laufen die Selbsttests und die vier fiktiven Szenarien. Dabei werden keine echten COMARCH-Nachrichten versendet.
5. Nach erfolgreichen Prüfungen bei `Gesichertes Softwareupdate jetzt ausfuehren? EINRICHTEN:` die bestehende Bestätigung `EINRICHTEN` eingeben. Die Prozesse werden vor dem Softwaretausch erneut geprüft.
6. `PASS INSTALLATION_COMPLETE` und den ausgegebenen Sicherungspfad abwarten. Danach öffnet sich automatisch das Menü der installierten Version. Für spätere Starts nur noch `START.cmd` aus der vorhandenen, jetzt aktualisierten Installation verwenden.

Ein vorgeschaltetes RC45-Update ist nicht erforderlich. Menü 1 aus der bereits installierten Standard-Zielinstallation ist weiterhin ein Status-, Selbsttest- und Demoweg; das Versionsupdate wird deshalb aus dem separat entpackten neuen Paket gestartet.

## Was die Migration automatisch beendet

Die Zuordnung verwendet konkrete Installationspfade, das in der Konfiguration angegebene Browserprofil und die verifizierte Abstammung zugehöriger Kindprozesse. Ein geänderter Profilpfad wird dabei berücksichtigt. Prozessnamen wie `node.exe` oder `msedge.exe` allein reichen nicht als Beendigungsgrund.

Für jeden zu beendenden Prozess nennt das Terminal PID, Namen und Zuordnungsgrund. Unmittelbar vor dem Eingriff wird erneut geprüft, ob die PID noch dieselbe Prozessinstanz bezeichnet. Dazu gehören unter anderem Startzeit, ausführbare Datei und Befehlszeile. Ein zwischenzeitlich neu gestarteter fremder Prozess darf nicht wegen einer wiederverwendeten PID beendet werden.

Wenn ein zugehöriger Prozess ein Hauptfenster besitzt, wird zunächst dessen Schließen angefordert. Bleibt die verifizierte Prozessinstanz bestehen, darf der Installer sie gezielt beenden. Danach erfolgt eine unabhängige neue Prozessaufnahme. Ein beendeter Elternprozess genügt nicht als Nachweis, dass auch alle zuvor identifizierten zugehörigen Arbeitsprozesse beendet sind.

Die Migration beendet keine pauschalen Gruppen aller Edge-, Node- oder PowerShell-Prozesse. Andere Browserprofile, andere Installationen und der aktuelle Installer samt seiner benötigten Aufrufkette sind nicht zum Beenden freigegeben. Ist diese Aufrufkette selbst mit einer Zielaktivität verknüpft, bleibt der Softwaretausch bis zur eindeutigen Trennung gesperrt. Eine bereits laufende andere Migration erhält keine automatische Konkurrenz.

Fremde Prozesse mit unlesbarer Befehlszeile blockieren das Update nicht allein wegen eines passenden Prozessnamens. Besteht hingegen ein konkreter, aber unklarer Bezug zur Zielinstallation, stoppt die Migration mit PID und Begründung. Fehlende Zugriffsrechte oder ein nicht belegter Stillstand werden ebenfalls als Fehler behandelt.

## Vorrang während der gesamten Prüfung

Die Migrationsreservierung wird angelegt, bevor der Installer die eigenen Botaktivitäten beendet. Der Startmarker `BETA_UMSTELLUNG_LAEUFT.txt` blockiert auch den bisherigen `START.cmd`-Weg. RC46 prüft die Reservierung zusätzlich beim Menüaufruf, bei Betriebssperren und in aktiven Bot-Sitzungen. Der Vorrang bleibt während Selbsttests, fiktiven Proben, der abschließenden Eingabe und des Softwaretausches bestehen.

Erst wenn die Prozesse nachweislich beendet sind, darf eine zugehörige alte Betriebssperre archiviert werden. Die ursprünglichen Sperrdaten bleiben im Migrationsarchiv unter `.runtime\beta-control\migration_archive` nachvollziehbar. Unklare Sperren, eine andere Migration oder eine laufende Wiederherstellung werden nicht als alte Botaktivität freigegeben.

Typische Meldungen des erfolgreichen Ablaufs sind:

```text
MIGRATION_VORRANG: Beende die dieser Installation zugeordneten Bot-Prozesse und das Bot-Edge.
PASS MIGRATION_BOT_RUHT: Update hat exklusiven Zugriff; neue Botstarts sind gesperrt.
PASS INSTALLATION_COMPLETE
```

Wenn kein zugehöriger Botprozess mehr läuft, entfällt die eigentliche Beendigung; die neue Stillstandsprüfung und die Reservierung bleiben erforderlich.

Bei einem regulären Abbruch vor dem Softwaretausch gibt der Installer seine Reservierung wieder frei. Bereits beendete Botprozesse werden dadurch nicht erneut gestartet. Nach einer unterbrochenen Vorbereitung kann Menü 1 eine verwaiste Reservierung erst nach Prüfung der unveränderten bisherigen Software und des beendeten Migrationsbesitzers archivieren. Ist der Softwaretausch offen, bleibt die Wiederherstellung über **Menü 7** vorgesehen; ein solcher Zustand wird nicht als bloßer alter Botlauf gelöscht. Wurde die Installation oder ihr automatischer Rückweg nachweislich abgeschlossen, kann ein späterer Start die übrig gebliebene Reservierung nach Prüfung des gebundenen Softwarejournals und der installierten Dateien freigeben.

## Daten und offene Ticketaktionen

Das Update archiviert und ersetzt die Software. Bestandsdaten, aktives Mapping, Benutzerkonfiguration, Browserprofil und vorhandene Laufdaten bleiben an ihren bisherigen Orten. Auch bei einem Software-Rückweg bleiben diese Daten erhalten. Neue Prüfbelege und Migrationsnachweise dürfen ergänzt werden; eine archivierte Betriebssperre ist keine Änderung des Ticketjournals.

Ein automatisches Beenden kann einen laufenden Browservorgang unterbrechen. Daraus ergibt sich keine Aussage, ob eine zuvor begonnene COMARCH-Aktion bereits wirksam geworden ist. Deshalb bleiben insbesondere `SEND_INTENT`, Weiterleitungsabsichten und `UPLOAD_INTENT` erhalten. Die Migration setzt diese Zustände nicht zurück, bestätigt sie nicht als erfolgreich und erlaubt dadurch keine erneute Nachricht oder doppelte Dateiauswahl.

Die Einrichtung selbst führt keinen Echtversand aus. Ein Software-Rückweg macht bereits ausgeführte COMARCH-Aktionen ebenfalls nicht rückgängig. Für die Reparatur ist keine Mappingwartung erforderlich.

## Nach dem Update: bisherigen Vorgang prüfen und fortsetzen

Wurde ein echter Phase-1-Lauf unterbrochen, im installierten RC46 **Menü 5 – Vorherigen Lauf prüfen / Wiederanlauf freigeben** aufrufen. Es zeigt den bisherigen Phase-1-Lauf und offene Sende- oder Weiterleitungsabsichten. Für ein allein offenes Phase-2-Uploadjournal ist dort keine neue Phase-1-Freigabe erforderlich. Eine angebotene Bestätigung nur entsprechend dem tatsächlich in COMARCH geprüften Zustand abgeben. Bei Unsicherheit die Bestätigung leer lassen; eine nicht belegte Aussage wie `SICHER_KEIN_VERSAND` ist keine allgemeine Reparaturfreigabe.

**Menü 5 klärt das Phase-1-Journal. Ein offenes Phase-2-`UPLOAD_INTENT` wird dort nicht zurückgesetzt oder freigegeben.** Dessen kontrollierte Fortsetzung erfolgt weiterhin in Menü 12 nach den Regeln aus RC45:

1. **Menü 9** für eine frische, nur lesende COMARCH-Inventur ausführen.
2. **Menü 12** für denselben beaufsichtigten Pilotvorgang starten. Der in der RC45-Dokumentation behandelte Fall ist Ticket `87278094`.
3. Den angezeigten vorhandenen und fehlenden Anlagenbestand prüfen. Wenn PP+ bereits eindeutig vorhanden ist und DC fehlt, darf nur DC ergänzt werden. Sind beide PDFs vorhanden, ist keine neue Dateiauswahl erforderlich.
4. Die vorgesehene Bestätigung `ANHAENGE_GEPRUEFT_UND_FORTSETZEN` nur abgeben, wenn der angezeigte Bestand stimmt, die vorhandenen PDFs inhaltlich zum selben Ticket gehören und aus dem unterbrochenen Vorgang noch kein Entwurf-/Ticket-Speichern oder Weiterleiten erfolgt ist.

Die Fortsetzung ist weiterhin an dasselbe Ticket, dieselbe Beschreibung, unveränderte PDF-Prüfsummen und den zulässigen Journalstand gebunden. Eine bereits verbrauchte Wiederaufnahme oder eine unklare, doppelte beziehungsweise versteckte Anlage wird durch RC46 nicht freigegeben. Das Update gewährt auch keinen zusätzlichen Wiederholungsversuch.

Ein gültiger PDF-Prüfbeleg aus **Menü 11** kann weiterverwendet werden. Menü 11 ist nur erneut nötig, wenn der Beleg fehlt, veraltet ist oder die PDFs geändert wurden. Die Generatoren starten durch die Migration oder Menü 12 nicht automatisch.

Die RC45-Dateiauswahl bleibt enthalten: Für jede fehlende PDF wird das aktuelle FilePond-Label samt zugehörigem Datei-Input neu geprüft und die Auswahl einzeln geöffnet. Auf die Anlagen folgen GEVO `Anfrage Member`, Beschreibung, Entwurfs- und Ticketspeicherung, erneute Prüfung der gespeicherten PDFs und die bestehende Freigabe zur Weiterleitung zur Überprüfung. Menü 12 versendet keine E-Mail.

Die vollständigen Bedingungen stehen in [RC45 – Anlagen und Wiederaufnahme](RC45_ANHAENGE_UND_WIEDERAUFNAHME.md). Die dort beschriebene Fachlogik bleibt in RC46 erhalten; für den Installationsweg gilt dieses RC46-Dokument.

## Wenn die Migration weiterhin stoppt

| Meldung | Bedeutung und nächster Schritt |
| --- | --- |
| `MIGRATION_PROCESS_UNCLEAR` | Ein Prozess hat einen unklaren Bezug zur Zielinstallation. Die ausgegebene PID, den Prozessnamen und den Zuordnungsgrund sichern. Die Software wird nicht auf Verdacht ersetzt. |
| `MIGRATION_PROCESS_STOP_FAILED` | Eine konkrete Prozessinstanz konnte nicht sicher beendet werden oder ihre Identität hat sich geändert. PID und Status aus dem Terminal für die Prüfung verwenden. |
| `PROCESS_CHECK_UNAVAILABLE` / `PROCESS_STOP_UNVERIFIED` | Prozessaufnahme oder Beendigung liefert keinen vollständigen Nachweis. Ohne diesen Nachweis wird kein Softwaretausch freigegeben. |
| `MIGRATION_ALREADY_ACTIVE` | Ein anderer Migrationsbesitzer oder eine andere geschützte Sperre ist noch aktiv. Dessen Vorgang zuerst abschließen; die Reservierung wird nicht überschrieben. |
| `MIGRATION_INCOMPLETE` | Die Softwareumstellung ist unterbrochen oder bereits reserviert. Bei begonnenem Softwaretausch Menü 7 aus dem neuen Paket verwenden. |
| `MCR_PROCESSES_ACTIVE` außerhalb der Migration | Normale Laufprüfungen beenden keine Prozesse. Ein Softwareupdate über Menü 1 des separat entpackten RC46-Pakets starten. |

Für eine Diagnose die vollständige aktuelle STOP-Zeile einschließlich PID und Status aufbewahren. Sperrdateien und Ticketjournale nicht manuell löschen; der Migrationsweg unterscheidet eine beendete Betriebssperre von einer noch ungeklärten Ticketaktion.

## Grenzen des Prüfnachweises

Die Build-Umgebung ist Linux. Die native Windows-Prozessaufnahme und Prozessbeendigung sowie ein echter Edge-/COMARCH-Lauf sind hier **`NOT_RUN`**. Kontrollierte Prozessmodelle prüfen die Zuordnung und die Abläufe einschließlich fremder Prozesse, geänderter Prozessidentität und fehlgeschlagener Beendigung. Lokale Installerprüfungen verwenden Testinstallationen und die ursprünglichen RC44-/RC45-Pakete. Diese Prüfarten belegen keinen tatsächlich auf dem Anwenderrechner geschlossenen Windows-Prozess.

Die versionsbezogenen Ergebnisse und gegebenenfalls übersprungenen Prüfungen stehen im [RC46-Prüfbericht](RC46_PRUEFBERICHT.json). Dieses Dokument nennt keine vorweggenommenen Testzahlen. Ein erfolgreicher Windows-Selbsttest prüft die dort ausführbaren Regressionen; der nächste beaufsichtigte COMARCH-Pilot muss den tatsächlichen Ticket- und Anlagenzustand weiterhin vor Ort bestätigen.
