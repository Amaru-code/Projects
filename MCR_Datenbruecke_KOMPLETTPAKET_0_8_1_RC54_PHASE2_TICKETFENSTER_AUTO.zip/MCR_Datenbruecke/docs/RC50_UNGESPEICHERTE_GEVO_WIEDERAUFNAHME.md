# RC50 – RC49 SAVE-Wiederanlauf: GEVO nach erneutem Öffnen leer

## Tatsächlicher Befund am 03.11.2026

RC48: PP+ und DC wurden in zwei getrennten nativen Dateidialogen ausgewählt; beide Dateinamen waren sichtbar und wurden vom Operator geprüft. Im lokalen Journal wurden `UPLOAD_VERIFIED`, `GEVO_VERIFIED`, `DESCRIPTION_VERIFIED`, `DRAFT_SAVE_VERIFIED` aufgezeichnet. Beim anschließenden `TICKET_SAVE_INTENT` verhinderte `ACTION_OCCLUDED_OR_OFFSCREEN` den Klick auf „Ticket speichern“. RC49 wurde über die Schnellinstallation erfolgreich installiert, brach beim Wiederanlauf jedoch mit `STOP P2_SAVE_RECOVERY_GEVO` ab, **bevor** die Operatorfreigabe eingeholt und der alte Journalzustand verändert wurde.

Wichtig: `GEVO_VERIFIED` war ein Nachweis des **alten, ungespeicherten Formulars**, kein Servernachweis. Dass der Wert beim neuen Öffnen fehlt, ist mit einem zurückgesetzten, nie final gespeicherten Editor vereinbar. Das begründet **keinen** erneuten PDF-Upload und **keine** automatische Weiterleitung.

## RC50-Korrektur

1. Bei derselben unveränderten Ticketnummer / ursprünglichen Beschreibung, identischen PDF-Hashes und sichtbaren, unabhängig kontrollierten Anhängen kann der alte `TICKET_SAVE_INTENT` wie bisher einmalig kontrolliert fortgesetzt werden.
2. Das erneut geöffnete GEVO-Eingabefeld wird read-only geprüft: exakt `Anfrage Member` → unverändert; leer bzw. ein um genau ein Zeichen verkürzter Suchwert → nach Freigabe neu auswählen; anderer Wert / doppeltes Feld → STOP, nicht überschreiben.
3. Vor der GEVO-Neuauswahl wird `TICKET_SAVE_RECOVERY_GEVO_INTENT` im vorhandenen Journal gespeichert; nach exakter Eingabebestätigung `TICKET_SAVE_RECOVERY_GEVO_VERIFIED`. Dadurch kann ein unterbrochener Reparaturversuch nicht blind wiederholt werden.
4. Unmittelbar danach werden **beide Anlagen** erneut geprüft; der Editor muss den ursprünglichen Text oder die exakt einmal vorhandene vierte Zeile zeigen. Die vierte Zeile wird nur bei Bedarf ergänzend geschrieben.
5. Bei einer bereits gespeicherten vierten Zeile wird **trotzdem** genau einmal `Ticket speichern` ausgeführt, wenn GEVO neu ausgewählt werden musste. Eine gespeicherte Beschreibung beweist noch keinen gespeicherten GEVO-Wert. Ist die vierte Zeile bereits gespeichert **und** GEVO unverändert korrekt, entfällt der zusätzliche Klick.
6. Nur wenn der gespeicherte Tickettext nachgewiesen ist, wird `TICKET_SAVE_VERIFIED` protokolliert. Vor der Weiterleitung werden anschließend GEVO, zwei PDFs und die Pflichtfelder nach erneutem Öffnen geprüft; ohne Erfolg keine Weiterleitung. Keine E-Mail.

### Kontrolle vor der Freigabe

**Nicht** das Journal löschen und **keine** Datei erneut hochladen. Menü 9 (Inventur) und Menü 12 (Einzelticket 87278094) verwenden. `SAVE_OHNE_KLICK_GEPRUEFT` nur bestätigen, wenn das Ticket und beide PDFs in COMARCH richtig sind und seit dem RC48-Abbruch keine manuelle Ticketspeicherung oder Weiterleitung stattfand. Wenn ein Speicherklick bereits erfolgte, abgebrochenes Journal zunächst gesondert prüfen – keine Wiederholung. GEVO-Reparatur ist ein neuer **Schreibvorgang im offenen Editor**, nicht die Wiederholung eines externen Versands.

### Prüfstatus

Browsertest mit einer auf `Anfrage Member` gesetzten alten und nach Wiederöffnung leeren Eingabe; Journalfreigabe und ein einzelner Reparatur-Intent; unveränderter schon korrekter Wert; fremder GEVO-Wert; keine zweite Reparatur bei unterbrochener erster; Upgrade/Rückweg mit originalem RC49-Paket. Reales COMARCH/Windows nach RC50 noch nicht getestet.
