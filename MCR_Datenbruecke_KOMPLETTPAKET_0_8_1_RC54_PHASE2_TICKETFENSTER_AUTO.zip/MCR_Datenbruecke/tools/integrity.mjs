/** Package verification is strict for execution. Known old files are accepted
 * ONLY as installation input, and must be archived with the old software. */
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {sha256,requireThat as need} from '../lib/core.mjs';
import {readJSON,plainPath,VERSION} from '../lib/control.mjs';
import {resolveConfig} from '../lib/config.mjs';

const PACKAGE_ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const CODE_DIRS=['src','lib','tools','tests','examples'];
const RC1_MANIFEST_SHA='68a55f739a1c1c60115a8f802e991164cb13342a69f7da3f753d3433a391238b';
const RC2_MANIFEST_SHA='f1d8fa7e80123d4489998c7100405befd33083c86a4f857bfae8fde9693ce4b2';
const RC3_MANIFEST_SHA='c313fc62b2ee567bdff780f51be923242dbd4100c0adee2b5d50d14044735baa';
const RC4_MANIFEST_SHA='ef5de55b2191559baf4f8d427b91f16a1451365c8e568c683f67cc0c869e5c41';
const RC5_MANIFEST_SHA='b5972143db33d54e8cc3ac9a9d40bedf676655a37bba1c89947b75d9baae17e3';
const RC6_MANIFEST_SHA='1be2245c59d005fddc97cb57f7bd840f198dc51ef4480a619206f5ac940eda38';
const RC7_MANIFEST_SHA='c32c5532032f902ababae291941cedb92a92399dcdaad937a7bbd9071ccac20d';
const RC8_MANIFEST_SHA='3c5f49dda136176bdf55c5e0290eb50ff07717fd787bfb22554acca70ba9a6e5';
const RC9_MANIFEST_SHA='949b766eae902f8752b81e49cf3f7bd61d536d46bfd5e0bf0e04d03ea66134d4';
const LEGACY_REGISTRY_SHA='e1116088a7784505cef9c239e899eddefb5dc621c20d5ae0aa345bc8183c2729';
export const safeRelative=p=>typeof p==='string'&&p.length>0&&!/[\\:\x00-\x1f]/.test(p)&&!p.startsWith('/')&&!p.split('/').some(x=>!x||x==='.'||x==='..');

export function verifyRecords(root,records,{skipConfig=false}={}){
  need(Array.isArray(records)&&records.length>0&&records.length<2000,'MANIFEST_INVALID','Manifest fehlt/zu gross.');
  const seen=new Set();
  for(const r of records){
    need(r&&safeRelative(r.path)&&!seen.has(r.path.toLowerCase())&&Number.isSafeInteger(r.bytes)&&r.bytes>=0&&/^[a-f0-9]{64}$/.test(r.sha256),'MANIFEST_INVALID','Manifestpfad/Hash falsch.');
    seen.add(r.path.toLowerCase());
    if(skipConfig&&r.path==='config/local-runner-queue-send.json')continue;
    const p=plainPath(path.join(root,...r.path.split('/'))),s=fs.statSync(p);
    need(s.isFile()&&s.size===r.bytes&&s.size<32*1024*1024,'PACKAGE_SIZE','Dateilaenge abweichend: '+r.path);
    need(sha256(fs.readFileSync(p))===r.sha256,'PACKAGE_HASH','Programmdatei abweichend: '+r.path);
  }
  return seen;
}

function knownBeta4Residuals(){
  const f=plainPath(path.join(PACKAGE_ROOT,'tools/reference/beta4-residuals.json'));
  const r=readJSON(f,65536);
  need(sha256(fs.readFileSync(f))===LEGACY_REGISTRY_SHA&&r.schema==='MCR_KNOWN_BETA4_RESIDUALS_V1'&&Array.isArray(r.files)&&r.files.length===15,'LEGACY_REFERENCE_CHANGED','Altdatei-Referenz veraendert. Keine Uebernahme.');
  return new Map(r.files.map(x=>[x.path.toLowerCase(),x]));
}

function verifyCodeTree(root,seen,{knownResiduals=null}={}){
  const residuals=[],walked=new Set();let count=0;
  function walk(p,rel){
    plainPath(p);
    for(const n of fs.readdirSync(p).sort()){
      const f=path.join(p,n),r=rel+'/'+n,k=r.toLowerCase();
      need(++count<=10000&&safeRelative(r),'CODE_TREE_LIMIT','Zu viele/ungueltige Softwarepfade.');
      need(!walked.has(k),'CODE_PATH_COLLISION','Mehrdeutiger Softwarepfad: '+r);walked.add(k);
      plainPath(f);const st=fs.statSync(f);
      if(st.isDirectory()){walk(f,r);continue;}
      need(st.isFile(),'CODE_FILE','Keine regulaere Softwaredatei: '+r);
      if(seen.has(k))continue;
      const expected=knownResiduals?.get(k);
      need(expected,'UNSEALED_CODE','Unerwartete Programmdatei: '+r+'. Nichts manuell loeschen: START.cmd aus dem NEUEN separat entpackten Komplettpaket, Menue 1.');
      need(st.size===expected.bytes&&sha256(fs.readFileSync(f))===expected.sha256,'LEGACY_RESIDUAL_CHANGED','Bekannte Altdatei hat andere Bytes: '+r+'. Keine automatische Uebernahme.');
      residuals.push({path:r,bytes:expected.bytes,sha256:expected.sha256,sourceVersion:'0.8.0-beta.4'});
    }
  }
  for(const d of CODE_DIRS)walk(path.join(root,d),d);
  return residuals;
}

export function verifyPackage(root,{strictConfig=false}={}){
  plainPath(root);const f=path.join(root,'MANIFEST.json'),m=readJSON(f,2*1024*1024);
  need(m.schema==='MCR_COMPLETE_PACKAGE_V1'&&m.package==='MCR_Datenbruecke'&&m.version===VERSION,'PACKAGE_VERSION','Kein passendes Gesamtpaket.');
  need(!m.payload.some(r=>/^tests\/fixtures\/complete-0\.8\.1-rc\.\d+\.zip$/i.test(r.path||'')),'PACKAGE_RECURSION','Alte Komplettpaket-ZIPs duerfen nicht im aktuellen Release enthalten sein.');
  const seen=verifyRecords(root,m.payload,{skipConfig:!strictConfig});
  verifyCodeTree(root,seen); // No residual-file exception for execution.
  resolveConfig(root);
  return {version:m.version,files:m.payload.length,manifestSha256:sha256(fs.readFileSync(f))};
}

/** Read-only recognition for update/rollback only. No imports from target,
 * no deletion, no relaxed runtime verifier, and no live authorization. */
export function verifyPrevious(root){
  plainPath(root);const file=path.join(root,'MANIFEST.json'),m=readJSON(file,2*1024*1024);
  if(m.schema==='MCR_COMPLETE_PACKAGE_V1'){
    need(m.package==='MCR_Datenbruecke','PACKAGE_VERSION','Fremdes Gesamtpaket.');
    const manifestSha=sha256(fs.readFileSync(file));
    let expectedSha;
    if(m.version==='0.8.1-rc.1'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.1-manifest.json'));
      need(sha256(fs.readFileSync(ref))===RC1_MANIFEST_SHA,'PREVIOUS_REFERENCE_CHANGED','RC1-Referenz veraendert.');
      expectedSha=RC1_MANIFEST_SHA;
    }else if(m.version==='0.8.1-rc.2'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.2-manifest.json'));
      need(sha256(fs.readFileSync(ref))===RC2_MANIFEST_SHA,'PREVIOUS_REFERENCE_CHANGED','RC2-Referenz veraendert.');
      expectedSha=RC2_MANIFEST_SHA;
    }else if(m.version==='0.8.1-rc.3'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.3-manifest.json'));
      need(sha256(fs.readFileSync(ref))===RC3_MANIFEST_SHA,'PREVIOUS_REFERENCE_CHANGED','RC3-Referenz veraendert.');
      expectedSha=RC3_MANIFEST_SHA;
    }else if(m.version==='0.8.1-rc.4'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.4-manifest.json'));
      need(sha256(fs.readFileSync(ref))===RC4_MANIFEST_SHA,'PREVIOUS_REFERENCE_CHANGED','RC4-Referenz veraendert.');
      expectedSha=RC4_MANIFEST_SHA;
    }else if(m.version==='0.8.1-rc.5'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.5-manifest.json'));
      need(sha256(fs.readFileSync(ref))===RC5_MANIFEST_SHA,'PREVIOUS_REFERENCE_CHANGED','RC5-Referenz veraendert.');
      expectedSha=RC5_MANIFEST_SHA;
    }else if(m.version==='0.8.1-rc.6'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.6-manifest.json'));
      need(sha256(fs.readFileSync(ref))===RC6_MANIFEST_SHA,'PREVIOUS_REFERENCE_CHANGED','RC6-Referenz veraendert.');
      expectedSha=RC6_MANIFEST_SHA;
    }else if(m.version==='0.8.1-rc.7'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.7-manifest.json'));
      need(sha256(fs.readFileSync(ref))===RC7_MANIFEST_SHA,'PREVIOUS_REFERENCE_CHANGED','RC7-Referenz veraendert.');
      expectedSha=RC7_MANIFEST_SHA;
    }else if(m.version==='0.8.1-rc.8'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.8-manifest.json'));
      need(sha256(fs.readFileSync(ref))===RC8_MANIFEST_SHA,'PREVIOUS_REFERENCE_CHANGED','RC8-Referenz veraendert.');
      expectedSha=RC8_MANIFEST_SHA;
    }else if(m.version==='0.8.1-rc.9'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.9-manifest.json'));
      need(sha256(fs.readFileSync(ref))===RC9_MANIFEST_SHA,'PREVIOUS_REFERENCE_CHANGED','RC9-Referenz veraendert.');
      expectedSha=RC9_MANIFEST_SHA;
    }else if(m.version==='0.8.1-rc.10'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.10-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='34bd1fee086cf0caf4b0d8046f8a3fca64dd502583eec68c1339def839acc92d','PREVIOUS_REFERENCE_CHANGED','RC10-Referenz veraendert.');
      expectedSha='34bd1fee086cf0caf4b0d8046f8a3fca64dd502583eec68c1339def839acc92d';
    }else if(m.version==='0.8.1-rc.11'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.11-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='403e428f82f9d27dba7b51db83c3e8e17f3e2e9f7ad6fc1fe215c42892221df0','PREVIOUS_REFERENCE_CHANGED','RC11-Referenz veraendert.');
      expectedSha='403e428f82f9d27dba7b51db83c3e8e17f3e2e9f7ad6fc1fe215c42892221df0';
    }else if(m.version==='0.8.1-rc.12'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.12-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='55914baadafd37e27eea684d26f4a69f1fd6ddd1e8ad2263d9f47040a2838bd3','PREVIOUS_REFERENCE_CHANGED','RC12-Referenz veraendert.');
      expectedSha='55914baadafd37e27eea684d26f4a69f1fd6ddd1e8ad2263d9f47040a2838bd3';
    }else if(m.version==='0.8.1-rc.13'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.13-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='68ff6d3bd3486fafd10cc1bb41f7d73c5bc5b766e146bd0fa8cfe52f1bc9e62e','PREVIOUS_REFERENCE_CHANGED','RC13-Referenz veraendert.');
      expectedSha='68ff6d3bd3486fafd10cc1bb41f7d73c5bc5b766e146bd0fa8cfe52f1bc9e62e';
    }else if(m.version==='0.8.1-rc.14'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.14-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='e939bab5dfe166f953943e4646a1961d44e24d211d1bbf92defd25e6312fe326','PREVIOUS_REFERENCE_CHANGED','RC14-Referenz veraendert.');
      expectedSha='e939bab5dfe166f953943e4646a1961d44e24d211d1bbf92defd25e6312fe326';
    }else if(m.version==='0.8.1-rc.15'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.15-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='6c53cd5d8bd19c333cf4cdb4dcd97949f548cc2f35ba05e04955f1e216e33d89','PREVIOUS_REFERENCE_CHANGED','RC15-Referenz veraendert.');
      expectedSha='6c53cd5d8bd19c333cf4cdb4dcd97949f548cc2f35ba05e04955f1e216e33d89';
    }else if(m.version==='0.8.1-rc.16'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.16-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='c79e7f0d38ae3148671d92edc94dc3ea3ceed81e2144a3ef7cfdf53e32c3ec29','PREVIOUS_REFERENCE_CHANGED','RC16-Referenz veraendert.');
      expectedSha='c79e7f0d38ae3148671d92edc94dc3ea3ceed81e2144a3ef7cfdf53e32c3ec29';
    }else if(m.version==='0.8.1-rc.17'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.17-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='cf1c93dfffa12bfbede38e849727b15e8e67a84c8c0b6b2c4df10b255a646551','PREVIOUS_REFERENCE_CHANGED','RC17-Referenz veraendert.');
      expectedSha='cf1c93dfffa12bfbede38e849727b15e8e67a84c8c0b6b2c4df10b255a646551';
    }else if(m.version==='0.8.1-rc.18'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.18-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='73981c1329ab0e0fdaf80fb207c345dfe92c043ab1a5220619a7c5a14e873626','PREVIOUS_REFERENCE_CHANGED','RC18-Referenz veraendert.');
      expectedSha='73981c1329ab0e0fdaf80fb207c345dfe92c043ab1a5220619a7c5a14e873626';
    }else if(m.version==='0.8.1-rc.19'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.19-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='2494c1b3ebf800a54202e66d55031c1b7cba7a5550c087f4b57f98941b7677df','PREVIOUS_REFERENCE_CHANGED','RC19-Referenz veraendert.');
      expectedSha='2494c1b3ebf800a54202e66d55031c1b7cba7a5550c087f4b57f98941b7677df';
    }else if(m.version==='0.8.1-rc.20'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.20-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='826a7bd63f510748e299986a23d84206d251dcce14cb4f7ed5786cb09450c193','PREVIOUS_REFERENCE_CHANGED','RC20-Referenz veraendert.');
      expectedSha='826a7bd63f510748e299986a23d84206d251dcce14cb4f7ed5786cb09450c193';
    }else if(m.version==='0.8.1-rc.21'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.21-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='cc44bd37ea80534f23cdd2a49004dfdbc37ea85409a4ba87d8418c825edfa15e','PREVIOUS_REFERENCE_CHANGED','RC21-Referenz veraendert.');
      expectedSha='cc44bd37ea80534f23cdd2a49004dfdbc37ea85409a4ba87d8418c825edfa15e';
    }else if(m.version==='0.8.1-rc.22'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.22-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='bc4110879a73646c78a01cf7c5a968275117fa189c8ce6387b16f0caea3816da','PREVIOUS_REFERENCE_CHANGED','RC22-Referenz veraendert.');
      expectedSha='bc4110879a73646c78a01cf7c5a968275117fa189c8ce6387b16f0caea3816da';
    }else if(m.version==='0.8.1-rc.23'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.23-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='3dd8b9a460ceeb6f8833db6d425e1cbfc50083737814190b39a3dab0cf917525','PREVIOUS_REFERENCE_CHANGED','RC23-Referenz veraendert.');
      expectedSha='3dd8b9a460ceeb6f8833db6d425e1cbfc50083737814190b39a3dab0cf917525';
    }else if(m.version==='0.8.1-rc.24'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.24-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='2e4be9d2b0f17075a06706b142f0da7080b8090ee4298064ac5aadf5e58409c8','PREVIOUS_REFERENCE_CHANGED','RC24-Referenz veraendert.');
      expectedSha='2e4be9d2b0f17075a06706b142f0da7080b8090ee4298064ac5aadf5e58409c8';
    }else if(m.version==='0.8.1-rc.25'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.25-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='5db2117cbba4bef6d6010adee2e1ab03832a9d598b7276e8148958dd71f29399','PREVIOUS_REFERENCE_CHANGED','RC25-Referenz veraendert.');
      expectedSha='5db2117cbba4bef6d6010adee2e1ab03832a9d598b7276e8148958dd71f29399';
    }else if(m.version==='0.8.1-rc.26'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.26-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='e6c46e59435ac10daf4bec886514d1bec03e40b0925f537c252431134141f37d','PREVIOUS_REFERENCE_CHANGED','RC26-Referenz veraendert.');
      expectedSha='e6c46e59435ac10daf4bec886514d1bec03e40b0925f537c252431134141f37d';
    }else if(m.version==='0.8.1-rc.27'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.27-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='e76f90d730f78b368c8da987a306ccb7ff8c3f743dfdea155c7125fd97b8798b','PREVIOUS_REFERENCE_CHANGED','RC27-Referenz veraendert.');
      expectedSha='e76f90d730f78b368c8da987a306ccb7ff8c3f743dfdea155c7125fd97b8798b';
    }else if(m.version==='0.8.1-rc.28'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.28-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='a6f39118e604372376b69df47dd10fd7d2d5fb2a8d050ca35d33ee80ceb6dad6','PREVIOUS_REFERENCE_CHANGED','RC28-Referenz veraendert.');
      expectedSha='a6f39118e604372376b69df47dd10fd7d2d5fb2a8d050ca35d33ee80ceb6dad6';
    }else if(m.version==='0.8.1-rc.29'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.29-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='3bda8c968b28f6b181bdec0ec44ef134611ef39c21aca7fae5036d8bc46d4cb3','PREVIOUS_REFERENCE_CHANGED','RC29-Referenz veraendert.');
      expectedSha='3bda8c968b28f6b181bdec0ec44ef134611ef39c21aca7fae5036d8bc46d4cb3';
    }else if(m.version==='0.8.1-rc.30'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.30-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='4961fddef4a3b086b17e78dc2c98fd1e142263800fe40a97eb0296d54099b149','PREVIOUS_REFERENCE_CHANGED','RC30-Referenz veraendert.');
      expectedSha='4961fddef4a3b086b17e78dc2c98fd1e142263800fe40a97eb0296d54099b149';
    }else if(m.version==='0.8.1-rc.31'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.31-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='cdc9f8ec15623e37d6b253f0c41d90b513d54c74e34172b6cb44d19c869baa64','PREVIOUS_REFERENCE_CHANGED','RC31-Referenz veraendert.');
      expectedSha='cdc9f8ec15623e37d6b253f0c41d90b513d54c74e34172b6cb44d19c869baa64';
    }else if(m.version==='0.8.1-rc.32'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.32-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='ec087b4bfe4cf2770be165684d0dde1d43d8530ef667995da28413f34ce113d5','PREVIOUS_REFERENCE_CHANGED','RC32-Referenz veraendert.');
      expectedSha='ec087b4bfe4cf2770be165684d0dde1d43d8530ef667995da28413f34ce113d5';
    }else if(m.version==='0.8.1-rc.33'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.33-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='829d0f401ff8c2e21b7ae9608657b09be09d46f6fefbd5276f4fef7c4022556a','PREVIOUS_REFERENCE_CHANGED','RC33-Referenz veraendert.');
      expectedSha='829d0f401ff8c2e21b7ae9608657b09be09d46f6fefbd5276f4fef7c4022556a';
    }else if(m.version==='0.8.1-rc.34'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.34-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='772d34d7fe0580f4f76e9743130f43985e38794d3306bd4a765cd93810e98101','PREVIOUS_REFERENCE_CHANGED','RC34-Referenz veraendert.');
      expectedSha='772d34d7fe0580f4f76e9743130f43985e38794d3306bd4a765cd93810e98101';
    }else if(m.version==='0.8.1-rc.35'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.35-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='54c3a8a0a067a3e8b3cf2c6b81c3ce0754b74397f240619b30e17ce0735057ec','PREVIOUS_REFERENCE_CHANGED','RC35-Referenz veraendert.');
      expectedSha='54c3a8a0a067a3e8b3cf2c6b81c3ce0754b74397f240619b30e17ce0735057ec';
    }else if(m.version==='0.8.1-rc.36'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.36-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='f526390e8800e1ae3fa55c5e935da1549f067d8fa97ac27965262e346614447b','PREVIOUS_REFERENCE_CHANGED','RC36-Referenz veraendert.');
      expectedSha='f526390e8800e1ae3fa55c5e935da1549f067d8fa97ac27965262e346614447b';
    }else if(m.version==='0.8.1-rc.37'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.37-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='96804979375fc942c09e1557d49d64b010b2478454034939b77ad4980658e003','PREVIOUS_REFERENCE_CHANGED','RC37-Referenz veraendert.');
      expectedSha='96804979375fc942c09e1557d49d64b010b2478454034939b77ad4980658e003';
    }else if(m.version==='0.8.1-rc.38'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.38-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='b95a2b93099aad9c66e157db83f49b8c98193fc72a47590af69747ba16127319','PREVIOUS_REFERENCE_CHANGED','RC38-Referenz veraendert.');
      expectedSha='b95a2b93099aad9c66e157db83f49b8c98193fc72a47590af69747ba16127319';
    }else if(m.version==='0.8.1-rc.39'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.39-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='af72e0bc941bb176d0151f9d6c53fd62d693545d8300d4243de869efa5ad214d','PREVIOUS_REFERENCE_CHANGED','RC39-Referenz veraendert.');
      expectedSha='af72e0bc941bb176d0151f9d6c53fd62d693545d8300d4243de869efa5ad214d';
    }else if(m.version==='0.8.1-rc.40'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.40-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='1b0ff59a90cb58d432a9b26f7e6e215a86b2017c683824ef7f40ae966ad9de2b','PREVIOUS_REFERENCE_CHANGED','RC40-Referenz veraendert.');
      expectedSha='1b0ff59a90cb58d432a9b26f7e6e215a86b2017c683824ef7f40ae966ad9de2b';
    }else if(m.version==='0.8.1-rc.41'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.41-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='a380a5a92449b6379ef2f3a2a144092519b478db702918a340e59bf043f1a127','PREVIOUS_REFERENCE_CHANGED','RC41-Referenz veraendert.');
      expectedSha='a380a5a92449b6379ef2f3a2a144092519b478db702918a340e59bf043f1a127';
    }else if(m.version==='0.8.1-rc.42'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.42-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='17bba6bd81cb6ec72a70405565a25e7593a4eda708822922f4edd3c59eef318d','PREVIOUS_REFERENCE_CHANGED','RC42-Referenz veraendert.');
      expectedSha='17bba6bd81cb6ec72a70405565a25e7593a4eda708822922f4edd3c59eef318d';
    }else if(m.version==='0.8.1-rc.43'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.43-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='fa607710ecdfdb0476f592550ec0a6b8691d44d6da2ea011953d6b1e0f6bf9ba','PREVIOUS_REFERENCE_CHANGED','RC43-Referenz veraendert.');
      expectedSha='fa607710ecdfdb0476f592550ec0a6b8691d44d6da2ea011953d6b1e0f6bf9ba';
    }else if(m.version==='0.8.1-rc.44'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.44-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='31d1f1c31f209cedce3cbd51faea6324d5ef9bfd08b9e051fb5b8b668348dec8','PREVIOUS_REFERENCE_CHANGED','RC44-Referenz veraendert.');
      expectedSha='31d1f1c31f209cedce3cbd51faea6324d5ef9bfd08b9e051fb5b8b668348dec8';
    }else if(m.version==='0.8.1-rc.45'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.45-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='3c9228da2770c9ff6be90160e25cc3ba3cf1092628b449b16fb686df143bb444','PREVIOUS_REFERENCE_CHANGED','RC45-Referenz veraendert.');
      expectedSha='3c9228da2770c9ff6be90160e25cc3ba3cf1092628b449b16fb686df143bb444';
    }else if(m.version==='0.8.1-rc.46'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.46-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='3640d26d3acd4f9b9265c7c6b3b7745595f436259864cd247c316a699aa68a79','PREVIOUS_REFERENCE_CHANGED','RC46-Referenz veraendert.');
      expectedSha='3640d26d3acd4f9b9265c7c6b3b7745595f436259864cd247c316a699aa68a79';
    }else if(m.version==='0.8.1-rc.47'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.47-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='1fa4c46292743fd9afa7d6ba2b462c50a54443036e5c9cc8085bae59f4fd9bf5','PREVIOUS_REFERENCE_CHANGED','RC47-Referenz veraendert.');
      expectedSha='1fa4c46292743fd9afa7d6ba2b462c50a54443036e5c9cc8085bae59f4fd9bf5';
    }else if(m.version==='0.8.1-rc.48'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.48-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='27bfea9b60b5522860c539b6692485d1e8c7d3c113ca54ad30dad72b60f1d93c','PREVIOUS_REFERENCE_CHANGED','RC48-Referenz veraendert.');
      expectedSha='27bfea9b60b5522860c539b6692485d1e8c7d3c113ca54ad30dad72b60f1d93c';
    }else if(m.version==='0.8.1-rc.49'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.49-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='3e4782c09f5eb504381e15ba19bbe1b618273075558887173e2b1d94d2530ba3','PREVIOUS_REFERENCE_CHANGED','RC49-Referenz veraendert.');
      expectedSha='3e4782c09f5eb504381e15ba19bbe1b618273075558887173e2b1d94d2530ba3';
    }else if(m.version==='0.8.1-rc.50'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.50-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='9ae83a42de963eda1e4b31ae95a1f3511ec97c4cd273667af83e93013cebe9ae','PREVIOUS_REFERENCE_CHANGED','RC50-Referenz veraendert.');
      expectedSha='9ae83a42de963eda1e4b31ae95a1f3511ec97c4cd273667af83e93013cebe9ae';
    }else if(m.version==='0.8.1-rc.52'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.52-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='107f2bb9f3cd8c816dddc859182f9df3480ce425b579934855be676e47607b63','PREVIOUS_REFERENCE_CHANGED','RC52-Referenz veraendert.');
      expectedSha='107f2bb9f3cd8c816dddc859182f9df3480ce425b579934855be676e47607b63';
    }else if(m.version==='0.8.1-rc.51'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.51-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='564af25ee98c178143ba962a2e7efe0a41aca5dd9d7b131b6329e738ed86b74c','PREVIOUS_REFERENCE_CHANGED','RC51-Referenz veraendert.');
      expectedSha='564af25ee98c178143ba962a2e7efe0a41aca5dd9d7b131b6329e738ed86b74c';
    }else if(m.version==='0.8.1-rc.53'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.53-manifest.json'));
      need(sha256(fs.readFileSync(ref))==='5f0a21e1717206c19fa139780e92900d71e3ef35ac05996aa9789818aa2a2806','PREVIOUS_REFERENCE_CHANGED','RC53-Referenz veraendert.');
      expectedSha='5f0a21e1717206c19fa139780e92900d71e3ef35ac05996aa9789818aa2a2806';
    }else if(m.version===VERSION){
      expectedSha=sha256(fs.readFileSync(plainPath(path.join(PACKAGE_ROOT,'MANIFEST.json'))));
    }else need(false,'PREVIOUS_COMPLETE_VERSION','Diese Gesamtpaketversion ist nicht als Updatequelle bekannt.');
    need(manifestSha===expectedSha,'PREVIOUS_MANIFEST_CHANGED','Manifest der bisherigen Version weicht von der veroeffentlichten Referenz ab.');
    const seen=verifyRecords(root,m.payload,{skipConfig:true});
    const legacyResiduals=verifyCodeTree(root,seen,{knownResiduals:knownBeta4Residuals()});
    resolveConfig(root);
    return {version:m.version,files:m.payload.length,manifestSha256:manifestSha,
      state:legacyResiduals.length?'COMPLETE_WITH_VERIFIED_BETA4_RESIDUALS':'COMPLETE_RELEASE_VERIFIED',
      legacyResiduals,authorization:'SOFTWARE_UPDATE_ONLY'};
  }
  need(m.schema==='MCR_BETA_PACKAGE_V1'&&m.package==='MCR_Ticket_Assistant'&&m.version==='0.8.0-beta.4'&&m.engineVersion==='0.7.4','BASELINE_VERSION','Erwartet wird Beta 4 oder ein bekanntes Gesamtpaket. Keine fremden Ordner ersetzen.');
  verifyRecords(root,m.payload,{skipConfig:true});
  need(m.payload.find(x=>x.path==='src/local-bot-full-run.mjs')?.sha256==='6777ca3b806f0a5085f31e5e371eaa5c6d2caa45e11cb20e475d02ae8b353d72','BASELINE_RUNNER','Unerwarteter Beta-4-Runner.');
  resolveConfig(root);return {version:m.version,files:m.payload.length};
}

export function treeDigest(root){plainPath(root);const rows=[];let count=0,total=0;function visit(f,rel){plainPath(f);const s=fs.statSync(f);need(++count<10000,'TREE_LIMIT','Zu viele Softwaredateien.');if(s.isDirectory()){rows.push(['D',rel]);for(const n of fs.readdirSync(f).sort())visit(path.join(f,n),rel?rel+'/'+n:n);}else{need(s.isFile()&&s.size<32*1024*1024,'TREE_FILE','Keine begrenzte Softwaredatei.');total+=s.size;need(total<128*1024*1024,'TREE_LIMIT','Softwarearchiv zu gross.');rows.push(['F',rel,s.size,sha256(fs.readFileSync(f))]);}}visit(root,'');return sha256(JSON.stringify(rows));}
