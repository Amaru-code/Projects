# MCR Datenbruecke 0.8.1-rc.54

Vollständiges Softwarepaket. Software nur über die separat entpackte START.cmd,
Menü 1, in die bestehende Installation übernehmen. Mapping, Konfiguration,
Browserprofil, PDF-Prüfbelege und Ticketjournale bleiben am Ort.

## Bedienung
- Menü 1: Schnellinstallation mit Integritätsprüfung, Sicherung und Prozesskontrolle.
- Menü 3/4: Echte Standardbearbeitung ohne automatische fiktive Demos.
  Jeder neue Lauf startet MANUELL. Das Fenster unten links bietet Manuell/Auto
  und die einmalige Freigabe des angezeigten Tickets. Pilot plus bis zu fünf
  Folgetickets in Menü 3; Menü 4 weiterhin erst nach verifiziertem Piloten.
- Menü 5: Ein offenes Versandticket ohne Neuversand fertigstellen oder bisherigen
  Lauf prüfen. Bei unklarem Ausgang niemals erneut senden.
- Menü 12: Phase 2 mit Kontoauszügen, DB/DB+-Direktweiterleitung und privatem
  MBC-Login-Entwurf. Kein E-Mail-Versand, kein automatischer Generatorstart.
- Menü 2: optionale fiktive Browserproben. Menü 6: optionale vollständige Selbsttests.

Prüferzuweisung und direkte Weiterleitung bleiben getrennte Wege. Nach jeder
bestätigten Bearbeitung wird gespeichert und der Abschluss geprüft, bevor das
nächste passende Ticket beginnt. Die grüne FERTIG-Anzeige bestätigt den
abgeschlossenen Lauf, nicht pauschal alle Tickets im COMARCH-System.

Aktuelle Anleitung: docs/RC53_BEARBEITER_UND_VERSANDSTEUERUNG.md.
Prüfstand: docs/RC53_PRUEFBERICHT.json. Reale Windows-/COMARCH-Abnahme bleibt offen.
Historische RC-Dokumente im docs-Ordner sind keine aktuellen Startanleitungen.

## Aktuell: RC54

Menü 12 hat ein eigenes Ticketfenster unten links, Manuell/Auto und einen Knopf vor der Abschlussweiterleitung. Abgeschlossene Karten wandern über fünf Sekunden nach oben links und blenden aus. MBC erkennt die beiden exakten Schreibweisen E-Mail und Email. Details und bekannte Prüfgrenzen: `docs/RC54_PHASE2_TICKETFENSTER.md`; Prüfergebnisse: `docs/RC54_PRUEFBERICHT.json`. Die Schnellinstallation bleibt ohne automatische Langtests.
