# MCR DATENBRUECKE 0.8.1-rc.71

Kompaktes, vollstaendiges Softwarepaket. Fuer Bestandsinstallation `START.cmd` im entpackten Paket, Menue 1; danach nur die installierte `START.cmd` verwenden.

## RC71 – Ticket speichern stabilisieren

Die bisherigen Phase-1-, DB-, Kontoauszug- und MBC-Ablaeufe bleiben erhalten. RC71 fuegt einen ticketgebundenen nativen Tastaturweg fuer den einzigen `Ticket speichern`-Knopf hinzu, falls ein Overlay den Maus-Hit-Test blockiert. Er wird nur auf einer eindeutig identifizierten COMARCH-Schaltflaeche ohne aktiven Modal-Dialog eingesetzt und fuehrt genau eine Browseraktion aus. Davor werden GEVO, zusaetzliche Beschreibung und ggf. der MBC-Entwurf erneut kontrolliert.

**Ein POST oder die manuelle Eingabe EINMAL_GEKLICKT ist nie ein Speichernachweis.** Nach jedem Klick wird das Ticket erneut geoeffnet und der Serverstand kontrolliert. Ein alter `TICKET_SAVE_INTENT` wird nur nach Serverpruefung und expliziter Reparaturfreigabe fortgesetzt. Keine zweite E-Mail und kein unkontrolliertes zweites Speichern.

Vorgaenge aus dem letzten Lauf: `88449724` ist nachweislich weitergeleitet, `87647759` ist nach der Speicherung noch ungeklärt. Bitte bei `87647759` die bereits gespeicherten Felder pruefen; nicht blind erneut ausfuehren.

Die Installation archiviert nur die Software und erhaelt `private_data`, Mapping, `.runtime`, Browserprofil und Ticketjournale. Zur Verifizierung siehe `docs/RC71_RELEASE.md`.
