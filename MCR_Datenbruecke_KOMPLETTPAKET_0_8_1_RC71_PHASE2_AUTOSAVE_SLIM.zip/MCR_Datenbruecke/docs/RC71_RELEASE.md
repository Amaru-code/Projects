# RC71 – Phase 2 Save Control und COMARCH-Readback

## Grundlage
Ticket 88449724: ROUTED_VERIFIED an mark.baindl. Ticket 87647759: MBC-Entwurf gespeichert, GEVO und Beschreibung vor dem Speichern im Browser exakt, anschließend manueller Speicherklick behauptet; drei beobachtete POSTs ohne Action-Bindung, Server-Readback unverändert. Weder gespeichert noch weitergeleitet nachgewiesen.

## Aenderung
- Nur eindeutig vorhandenes und ticketgebundenes `Ticket speichern`: bis zu drei passive Hit-Tests (ICEfaces-Overlay abwarten).
- Bei vollstaendiger Verdeckung ohne Modal-Dialog: CDP DOM.focus auf den eindeutigen save-Knoten und genau **eine** native Enter-Aktivierung; keine `element.click()`- oder JS-form-submit-Umgehung.
- Nach Fokussierung GEVO, Beschreibung und ggf. MBC-Entwurf nochmals pruefen. Form-Reset vor der Aktion verhindert einen Speicherklick.
- Unveraendert: `TICKET_SAVE_INTENT` vor jeder Aktion; neuer Server-Readback entscheidet. Allgemeine POST-Anzahl ist kein Nachweis.
- Fehlender eindeutiger Knopf / Dialog / fremde Werte: sicherer Stop oder vorhandene manuelle Ausnahme. Automatische Wiederholung nach unklarem Save bleibt gesperrt.

## Bedienung
ZIP separat entpacken, START.cmd -> Menue 1, danach installierte START.cmd -> Menue 12. Fuer erneutes Pruefen von 87647759 gezielte Ticketnummer verwenden. Reparaturbestaetigung nur, wenn die gespeicherte Beschreibung/GEVO wirklich fehlen und bisher keine Weiterleitung erfolgte. Fuer neue Faelle Startticket leer. MANUELL verlangt weiterhin explizite Freigabe **vor der finalen Weiterleitung**, AUTO muss bewusst eingeschaltet werden.

## Grenzen
Chromium-Nachbildung ist kein produktiver COMARCH-Nachweis. Eine Formularaenderung erst waehrend des Klickevents kann trotz Vorpruefung passieren; in diesem Fall stoppt die unabhängige Readback-Pruefung vor jeder Weiterleitung.
