/** Regression from actual RC73 inventory: human request text after a DB+
 * acknowledgement was incorrectly treated as an unsupported request. */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {sha256} from '../lib/core.mjs';
import {phase2HandoffDescription,phase2HandoffAudit} from '../lib/phase2-handoff.mjs';
import {inspectPhase2Tickets} from '../lib/phase2-intake-audit.mjs';
import {completeVerifiedPhase1Handoff} from '../lib/phase2-handoff-ledger.mjs';
import {choosePhase2Candidate} from '../src/phase2-run.mjs';
import {ledger} from '../lib/control.mjs';
const tid='88149870',usc='USC 20/ DB+',base=usc+'\nStandardantwort versendet';
const body='Sehr geehrter Herr Beispiel, mit dieser E-Mail möchten wir Ihnen bestätigen, dass wir Ihr Ticket erhalten haben und unser Team derzeit daran arbeitet. Wir werden uns bald melden.';
const incoming={direction:'INCOMING',sender:'secureemail@mmc.com',recipient:'servicelineintel@mercer.com',subject:'Re: [MERCER#73384981] benefit question',content:'Dear team, I have a question about my pension from Intel. Please advise.',date:'04.11.2026 10:10',documentId:'13001780'};
const outgoing={direction:'OUTGOING',sender:'servicelineintel@mercer.com',recipient:'secureemail@mmc.com',subject:'[MARSH#88149870] Re: [MERCER#73384981] benefit question',content:body,date:'06.11.2026 10:25',documentId:'13001781'};
const history={ok:true,rows:[incoming,outgoing]};
const bound=(request,{status=true,sha=sha256(base)}={})=>{
 const desc=usc+'\n'+(status?'Standardantwort versendet\n':'')+request;
 const row={ticketId:tid,groupName:'Intel Deutschland GmbH',intelGroupVerified:true,source:'E-MAIL',descriptionValue:desc};
 const prior={ticketId:tid,kind:'SEND',state:'SEND_INTENT',descriptionSha256:sha};
 return {row,prior,history,detailDescription:desc};
};
for(const request of [
 'Möchte eine Bestätigung das sie Firmenrente erhält',
 'Möchte wissen was er zu tun hat zu seinen Austritt',
 'Möchte mehr über seinen Rentenplan erfahren',
 'Möchte wissen wann er wieder für seine Auszahlung kontaktiert wird',
]){
 test('RC74: DB/DB+ arbitrary single real request line preserved, old SEND still proves outgoing: '+request,()=>{
  const b=bound(request);
  const structure=phase2HandoffDescription(b);
  assert.equal(structure.verified,true,structure.reason);
  assert.equal(structure.rule,'DB_DIRECT');assert.equal(structure.hasStatus,true);
  assert.equal(structure.expectedDescription,b.row.descriptionValue,'original text must remain byte-for-byte after description readback');
  const proof=phase2HandoffAudit(b);
  assert.equal(proof.verified,true,proof.reason);
  assert.equal(proof.requiresSave,false);
  assert.equal(inspectPhase2Tickets([b.row],{pending:[b.prior]}).items[0].stage,'PHASE1_EVIDENCE');
 });
}
test('RC74: an old DB status repair preserves the unique third line but never grants a send',()=>{
 const b=bound('Möchte eine Bestätigung das sie Firmenrente erhält',{status:false});
 const a=phase2HandoffAudit({...b,allowRepair:true});
 assert.equal(a.verified,true,a.reason);assert.equal(a.requiresSave,true);
 assert.equal(a.expectedDescription,base+'\nMöchte eine Bestätigung das sie Firmenrente erhält');
 assert.equal(phase2HandoffAudit(b).verified,false,'no automatic status completion without explicit repair');
});
test('RC74: a proven old outgoing clears only its own journal and frees exactly its DB ticket',()=>{
 const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC74-DB-HANDOFF-'));
 try{
  ledger(tmp).begin(tid,base);ledger(tmp).begin('88149999','USC 10/ PP+\nStandardantwort versendet');
  const b=bound('Möchte eine Bestätigung das sie Firmenrente erhält');
  const prior=ledger(tmp).pending.find(p=>p.ticketId===tid);
  assert.equal(choosePhase2Candidate([b.row],{blockedIds:ledger(tmp).pending.map(x=>x.ticketId)}).row,null);
  const p=phase2HandoffAudit({...b,prior});assert(p.verified,p.reason);
  completeVerifiedPhase1Handoff(tmp,prior,p);
  assert.deepEqual(ledger(tmp).pending.map(p=>p.ticketId),['88149999']);
  const next=choosePhase2Candidate([b.row],{blockedIds:ledger(tmp).pending.map(x=>x.ticketId)});
  assert.equal(next.kind,'DB_DIRECT');assert.equal(next.row.ticketId,tid);
 }finally{fs.rmSync(tmp,{recursive:true,force:true});}
});
test('RC74: extra free text never bypasses non-DB phase2 rule',()=>{
 const b=bound('Möchte wissen was er zu tun hat zu seinen Austritt');
 b.row.descriptionValue=b.row.descriptionValue.replace('DB+','PP+');
 b.prior.descriptionSha256=sha256('USC 20/ PP+\nStandardantwort versendet');
 assert.equal(phase2HandoffAudit({...b,detailDescription:b.row.descriptionValue}).verified,false);
});
test('RC74: hard safety gates still block changed USC digest, foreign address and duplicate outgoing',()=>{
 const b=bound('Möchte wissen was er zu tun hat zu seinen Austritt');
 assert.equal(phase2HandoffAudit({...b,prior:{...b.prior,descriptionSha256:'0'.repeat(64)}}).reason,'ORIGINAL_LEDGER_SHA_MISMATCH');
 assert.equal(phase2HandoffAudit({...b,history:{ok:true,rows:[incoming,{...outgoing,recipient:'other@example.com'}]}}).reason,'OUTGOING_ADDRESS_NOT_BOUND');
 assert.equal(phase2HandoffAudit({...b,history:{ok:true,rows:[incoming,outgoing,{...outgoing,documentId:'13001782'}]}}).reason,'OUTGOING_STANDARD_REPLY_NOT_UNIQUE');
});
test('RC74: duplicate status, multiple request lines and unverified note still block',()=>{
 const b=bound('Möchte eine Bestätigung das sie Firmenrente erhält');
 for(const tail of ['\nStandardantwort versendet','\nMöchte noch etwas','\nNotiz: unverbundener Antrag']){
  const desc=b.row.descriptionValue+tail;
  assert.equal(phase2HandoffAudit({...b,row:{...b.row,descriptionValue:desc},detailDescription:desc}).verified,false);
 }
 const note=base+'\nNote: other benefit plan';
 assert.equal(phase2HandoffAudit({...b,row:{...b.row,descriptionValue:note},detailDescription:note}).verified,false);
});
test('RC74: read-only structure hints diagnose screenshot-like status and noncanonical USC without exposing request text',async()=>{
 const {phase2FormatHints}=await import('../lib/phase2-intake-audit.mjs');
 const a=phase2FormatHints('USC 20/ DC;PP+\n Standardantwort versendet \nMöchte Kontoauszug');
 assert.deepEqual({lines:a.lineCount,usc:a.uscLineCount,status:a.statusExactCount,whitespace:a.boundaryWhitespaceLines},{lines:3,usc:1,status:1,whitespace:1});
 const b=phase2FormatHints('DC, IPP, USC 20\nStandardantwort versendet\nMöchte Kontoauszug');
 assert.equal(b.uscLineCount,0);assert.equal(b.statusExactCount,1);
 assert(!JSON.stringify({a,b}).includes('Möchte'),'never copy original request text into hints');
});
