/** RC75 slim, fail-closed package verifier. Upgrade nur von verifizierten RC64-/RC65-/RC67-/RC68-/RC69-/RC70-/RC71-/RC72-/RC73-/RC74-Installationen (SHA-gebunden). Historical releases remain in the local
 * rollback archive, not the distributed executable package. */
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {sha256,requireThat as need} from '../lib/core.mjs';
import {readJSON,plainPath,VERSION} from '../lib/control.mjs';
import {resolveConfig} from '../lib/config.mjs';
const PACKAGE_ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const RC74_MANIFEST_SHA='bb63bdbbbab32b84a40d47281dd2aa5506a7aee6d7aa1407c351842a396df65c';
const RC73_MANIFEST_SHA='7dc28bd66f8caba0c5932a3288ae3984546fc09da3eb33ac754c2e1f79141f86';
const RC72_MANIFEST_SHA='f4cba0ab9511ab17bff4fb795b32b218179abcc98155fd8231afecd624bd6633';
const RC71_MANIFEST_SHA='de11bdd7a1a08167de48ef76078c3908d8b74626c1ab6755b15391aa4bd9a0c6';
const RC70_MANIFEST_SHA='4b22f1d3816e4d389640304906f4001d46bf64dc7874118f53b92ef9a6e540c3';
const RC69_MANIFEST_SHA='6943e16e8906aa30789540571c1b8553e61430d5498f1f44b4874ba6647ac40e';
const RC68_MANIFEST_SHA='23dcfe5c56741d1844e0fabf862284223c2341fde90caa446bc00cf8f6b9a71f';
const RC67_MANIFEST_SHA='e97f8d9b78b770a8e0f8a50253af0a51bc9175866f47d20e0df8d3cd44f7b73f';
const RC65_MANIFEST_SHA='f8cf24bcb95e68d12209f49bfc602bf0b452102eefb226de4e935c089dfa6512';
const RC64_MANIFEST_SHA='67b836e15f7a11bc9ed8f6cb8e5765396a58da4bf6824db1e7678802c8e65c0e';
const CODE_DIRS=['src','lib','tools','tests','examples'];
export const safeRelative=p=>typeof p==='string'&&p.length>0&&!/[\\:\x00-\x1f]/.test(p)&&!p.startsWith('/')&&!p.split('/').some(x=>!x||x==='.'||x==='..');
export function verifyRecords(root,records,{skipConfig=false}={}){
 need(Array.isArray(records)&&records.length>0&&records.length<2000,'MANIFEST_INVALID','Manifest fehlt/zu gross.');
 const seen=new Set();
 for(const r of records){
  need(r&&safeRelative(r.path)&&!seen.has(r.path.toLowerCase())&&Number.isSafeInteger(r.bytes)&&r.bytes>=0&&/^[a-f0-9]{64}$/.test(r.sha256),'MANIFEST_INVALID','Manifestpfad/Hash falsch.');
  seen.add(r.path.toLowerCase());
  if(skipConfig&&r.path==='config/local-runner-queue-send.json')continue;
  const p=plainPath(path.join(root,...r.path.split('/'))),st=fs.statSync(p);
  need(st.isFile()&&st.size===r.bytes&&st.size<32*1024*1024,'PACKAGE_SIZE','Dateilaenge abweichend: '+r.path);
  need(sha256(fs.readFileSync(p))===r.sha256,'PACKAGE_HASH','Programmdatei abweichend: '+r.path);
 }
 return seen;
}
function verifyCodeTree(root,seen){
 const visited=new Set();let count=0;
 function walk(p,rel){plainPath(p);need(fs.existsSync(p),'CODE_TREE_MISSING','Programmpfad fehlt: '+rel);
  for(const n of fs.readdirSync(p).sort()){
   const f=path.join(p,n),r=rel+'/'+n,k=r.toLowerCase();
   need(++count<=10000&&safeRelative(r)&&!visited.has(k),'CODE_TREE_LIMIT','Unzulaessiger Dateipfad: '+r);
   visited.add(k);plainPath(f);const st=fs.statSync(f);
   if(st.isDirectory()){walk(f,r);continue;}
   need(st.isFile()&&seen.has(k),'UNSEALED_CODE','Nicht manifestierter Programmcode: '+r);
  }
 }
 for(const d of CODE_DIRS)walk(path.join(root,d),d);
}
export function verifyPackage(root,{strictConfig=false}={}){
 plainPath(root);const m=readJSON(path.join(root,'MANIFEST.json'),2*1024*1024);
 need(m.schema==='MCR_COMPLETE_PACKAGE_V1'&&m.package==='MCR_Datenbruecke'&&m.version===VERSION,'PACKAGE_VERSION','Nicht das freigegebene RC75-Paket.');
 need(!m.payload.some(r=>/^tests\/fixtures\/complete-0\.8\.1-rc\.\d+\.zip$/i.test(r.path||'')),'PACKAGE_RECURSION','Kein altes Komplettpaket einbetten.');
 const seen=verifyRecords(root,m.payload,{skipConfig:!strictConfig});verifyCodeTree(root,seen);resolveConfig(root);
 return {version:m.version,files:m.payload.length,manifestSha256:sha256(fs.readFileSync(path.join(root,'MANIFEST.json')))};
}
export function verifyPrevious(root){
 plainPath(root);const m=readJSON(path.join(root,'MANIFEST.json'),2*1024*1024);
 need(m.schema==='MCR_COMPLETE_PACKAGE_V1'&&m.package==='MCR_Datenbruecke','PREVIOUS_COMPLETE_VERSION','Nur unveraenderte RC64-/RC65-/RC67-/RC68-/RC69-/RC70-/RC71-/RC72-/RC73-/RC74-Installationen erlaubt.');
 const expected=m.version==='0.8.1-rc.74'?RC74_MANIFEST_SHA:m.version==='0.8.1-rc.73'?RC73_MANIFEST_SHA:m.version==='0.8.1-rc.72'?RC72_MANIFEST_SHA:m.version==='0.8.1-rc.71'?RC71_MANIFEST_SHA:m.version==='0.8.1-rc.70'?RC70_MANIFEST_SHA:m.version==='0.8.1-rc.69'?RC69_MANIFEST_SHA:m.version==='0.8.1-rc.68'?RC68_MANIFEST_SHA:m.version==='0.8.1-rc.67'?RC67_MANIFEST_SHA:m.version==='0.8.1-rc.65'?RC65_MANIFEST_SHA:m.version==='0.8.1-rc.64'?RC64_MANIFEST_SHA:m.version===VERSION?sha256(fs.readFileSync(path.join(PACKAGE_ROOT,'MANIFEST.json'))):null;
 need(expected,'PREVIOUS_COMPLETE_VERSION','Kompaktes Update von verifiziertem RC64, RC65, RC67, RC68, RC69, RC70, RC71, RC72, RC73 oder RC74 nach RC75; andere Version erst gesondert migrieren.');
 const digest=sha256(fs.readFileSync(path.join(root,'MANIFEST.json')));
 need(digest===expected,'PREVIOUS_MANIFEST_CHANGED','Bestandssoftware weicht vom unveraenderten Release ab.');
 const seen=verifyRecords(root,m.payload,{skipConfig:true});verifyCodeTree(root,seen);resolveConfig(root);
 return {version:m.version,files:m.payload.length,manifestSha256:digest,state:'COMPLETE_RELEASE_VERIFIED',legacyResiduals:[],authorization:'SOFTWARE_UPDATE_ONLY'};
}
export function treeDigest(root){plainPath(root);const rows=[];let count=0,total=0;
 function visit(p,rel){plainPath(p);const st=fs.statSync(p);need(++count<10000,'TREE_LIMIT','Zu viele Dateien.');
  if(st.isDirectory()){rows.push(['D',rel]);for(const n of fs.readdirSync(p).sort())visit(path.join(p,n),rel?rel+'/'+n:n);}
  else{need(st.isFile()&&st.size<32*1024*1024,'TREE_FILE','Keine normale Softwaredatei.');total+=st.size;need(total<128*1024*1024,'TREE_LIMIT','Software zu gross.');rows.push(['F',rel,st.size,sha256(fs.readFileSync(p))]);}
 }visit(root,'');return sha256(JSON.stringify(rows));}
