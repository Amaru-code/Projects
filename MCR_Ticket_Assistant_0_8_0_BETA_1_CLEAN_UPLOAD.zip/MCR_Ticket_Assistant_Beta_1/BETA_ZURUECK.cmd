@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
echo ==============================================================
echo  MCR TICKET ASSISTANT - BETA 1 - RUECKWEG
echo ==============================================================
if not exist "%~dp0Paket\tools\setup.mjs" goto incomplete
call "%~dp0_setup\find-node.cmd"
if not "%errorlevel%"=="0" goto nodeError
"%MCR_NODE%" "%~dp0Paket\tools\setup.mjs" --rollback
set "RC=%errorlevel%"
echo.
pause
exit /b %RC%
:incomplete
echo STOP: Das komplette ZIP erst in einen separaten Ordner entpacken.
echo Nicht einzelne CMD-Dateien aus dem ZIP starten.
pause
exit /b 2
:nodeError
pause
exit /b 3
