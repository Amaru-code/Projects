/** Single daily entry point. Frozen 0.7.4 engine; no ticket algorithm here. */
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {spawn,spawnSync} from 'node:child_process';
import readline from 'node:readline/promises';
import {fileURLToPath} from 'node:url';
import {loadActiveMapping} from '../lib/active-mapping.mjs';
import {SCHEMA as TPP_SCHEMA} from '../lib/multirow-tpp-mapping.mjs';
import {PACKAGE_ROOT,RELEASE,ENGINE,need,verifyRelease,jsonRead,atomicJSON,assertPlainPath,controlDir,acquireLock,processAlive,assertWindowsIdle,stamp,sha} from './beta-common.mjs';
const root=PACKAGE_ROOT;
export function title(){console.log('\n==============================================================\n MCR TICKET ASSISTANT | BETA 1\n Paket '+RELEASE+' | bewaehrter Ticketkern '+ENGINE+'\n==============================================================');}
export function status(target=root){
 const pkg=verifyRelease(target);let mapping=null;
 try{const active=loadActiveMapping(target);need(active.map.schema===TPP_SCHEMA,'TPP_MAPPING_REQUIRED','Aktiver Snapshot enthaelt nicht die TPP-Textregel.');mapping={file:path.basename(active.path),hash:active.fileHash,summary:active.map.payload.summary};}
 catch(e){return {package:pkg,mappingReady:false,mappingError:e.code||'MAPPING_ERROR',message:e.message};}
 const run=path.join(target,'.runtime','beta-control','last-run.json');
 return {package:pkg,mappingReady:true,mapping,lastRun:fs.existsSync(run)?jsonRead(run,65536):null};
}
export function printStatus(s){
 console.log('Paketpruefung PASS | '+s.package.files+' Dateien | '+s.package.frozenFiles+' Kern-Dateien bytegleich zu 0.7.4');
 if(!s.mappingReady){console.log('Mapping: NICHT STARTBEREIT ('+s.mappingError+')\n'+s.message);return;}
 console.log('Aktives TPP-Mehrzeilen-Mapping: '+s.mapping.file);
 console.log('SHA256: '+s.mapping.hash);
 console.log('Verwendbare Personen: '+s.mapping.summary.validKeys+' | Gesperrt: '+s.mapping.summary.blockedKeys+' | Mehrzeilig: '+s.mapping.summary.multirowKeys+' | Mit TPP: '+s.mapping.summary.tppKeys);
 console.log('Browserprofil: bestehender Pfad .runtime/edge-profile (nicht umgestellt).');
 if(s.lastRun)console.log('Letzte Beta-Operation: '+s.lastRun.operation+' / '+s.lastRun.state);
}
async function ask(text){const rl=readline.createInterface({input:process.stdin,output:process.stdout});try{return String(await rl.question(text)).trim();}finally{rl.close();}}
export function hasReviewState(p){return !!p&&['RUNNING','INTERRUPTED_REVIEW_REQUIRED','STOP_REVIEW_REQUIRED'].includes(p.state);}
function assertNoReview(target){const f=path.join(target,'.runtime','beta-control','last-run.json');if(fs.existsSync(f))need(!hasReviewState(jsonRead(f,65536)),'REVIEW_REQUIRED','Vorheriger Beta-Lauf war nicht sauber beendet. Menue 7: Verlauf und Diagnose pruefen, danach Wiederanlauf freigeben.');}
export async function spawnInherited(executable,args,options={}){
 return await new Promise((resolve,reject)=>{
  const child=spawn(executable,args,{stdio:'inherit',windowsHide:false,...options});
  child.once('error',reject);child.once('exit',(code,signal)=>resolve({code,signal,pid:child.pid}));
 });
}
async function realRun(){
 const s=status();printStatus(s);need(s.mappingReady,'MAPPING_NOT_READY','Kein gueltiges aktives Mapping. Keine Browseraktion.');
 assertNoReview(root);assertWindowsIdle(root);
 need(!fs.existsSync(path.join(root,'BETA_UMSTELLUNG_LAEUFT.txt')),'MIGRATION_INCOMPLETE','Softwareumstellung noch offen.');
 const limit=Number(process.env.MCR_MAX_TICKETS||100);need(Number.isInteger(limit)&&limit>=1&&limit<=100,'TICKET_LIMIT','MCR_MAX_TICKETS muss zwischen 1 und 100 liegen.');
 const lock=acquireLock(root,'REAL_RUN'),dir=controlDir(root);
 const state={schema:'MCR_BETA_RUN_V1',operation:'REAL_RUN',state:'RUNNING',startedAt:new Date().toISOString(),pid:process.pid,engineVersion:ENGINE,ticketDeliveryVerified:false};
 const statePath=path.join(dir,'last-run.json');atomicJSON(statePath,state);
 const interrupted=()=>{state.state='INTERRUPTED_REVIEW_REQUIRED';state.updatedAt=new Date().toISOString();try{atomicJSON(statePath,state);}catch{}};
 process.on('SIGINT',interrupted);process.on('SIGTERM',interrupted);
 try{
  // The engine still requires START and its existing ambiguity confirmations.
  console.log('\nECHTLAUF: Nach START im Runner werden Nachrichten versendet und Tickets gespeichert.');
  const r=await spawnInherited(process.execPath,[path.join(root,'src/local-bot-full-run.mjs'),'--full-run'],{cwd:root,env:{...process.env,MCR_MAX_TICKETS:String(limit)}});
  state.state=state.state==='INTERRUPTED_REVIEW_REQUIRED'?state.state:(r.code===0?'RUNNER_EXIT_0':'STOP_REVIEW_REQUIRED');state.exitCode=r.code;state.signal=r.signal;state.finishedAt=new Date().toISOString();atomicJSON(statePath,state);
  console.log(r.code===0?'\nBeta-Echtlauf beendet. Massgeblich bleibt der Abschluss im Runnerprotokoll.':'\nSTOP: Nicht blind neu starten. Ticketverlauf und Diagnose pruefen.');
  return r.code===0&&state.state==='RUNNER_EXIT_0'?0:1;
 }catch(e){state.state='STOP_REVIEW_REQUIRED';state.errorCode=e.code||'CHILD_ERROR';state.finishedAt=new Date().toISOString();atomicJSON(statePath,state);throw e;}
 finally{process.removeListener('SIGINT',interrupted);process.removeListener('SIGTERM',interrupted);lock.release();}
}
export function prepareDemo(target=root){
 verifyRelease(target);const dest=fs.mkdtempSync(path.join(os.tmpdir(),'MCR_Beta_Demo_'));
 for(const folder of ['src','lib']){fs.mkdirSync(path.join(dest,folder));for(const file of fs.readdirSync(path.join(target,folder)))fs.copyFileSync(path.join(target,folder,file),path.join(dest,folder,file),fs.constants.COPYFILE_EXCL);}
 fs.mkdirSync(path.join(dest,'examples'));for(const file of ['DEMO_mapping.json','DEMO_Mail.msg'])fs.copyFileSync(path.join(target,'tools','demo',file),path.join(dest,'examples',file),fs.constants.COPYFILE_EXCL);
 fs.mkdirSync(path.join(dest,'config'));fs.copyFileSync(path.join(target,'config/local-runner-queue-send.json'),path.join(dest,'config/local-runner-queue-send.json'),fs.constants.COPYFILE_EXCL);
 return dest;
}
async function demoRun(){
 const demo=prepareDemo();console.log('\nFIKTIVE DEMO: eigener Tempordner, eigenes Browserprofil, keine COMARCH-Anmeldung.');
 console.log('Das aktive Bestandsmapping und das reale Browserprofil werden nicht verwendet.');
 const r=await spawnInherited(process.execPath,[path.join(demo,'src/local-bot-full-run.mjs'),'--demo','--auto','--headless','--close-browser','--full-run'],{cwd:demo,env:{...process.env,MCR_MAX_TICKETS:'5',MCR_DEMO_MULTIROW:'1'}});
 console.log('Demo-Rueckgabecode: '+r.code+' | Fiktive Diagnose verbleibt lokal: '+demo);return r.code??1;
}
async function rebuildMapping(){
 const s=status();printStatus(s);need(s.mappingReady,'MAPPING_NOT_READY','Kein aktives Mapping.');assertWindowsIdle(root);assertNoReview(root);
 console.log('\nWARTUNG: Mapping aus exakt derselben freigegebenen XLSX neu erzeugen.\nEine geaenderte/neue Jahresdatei wird vom bestehenden Quell-Hash-Gate abgewiesen.');
 if((await ask('Fortfahren? NEU: ')).toUpperCase()!=='NEU'){console.log('Keine Aenderung.');return 0;}
 const lock=acquireLock(root,'MAPPING_REBUILD');try{const r=await spawnInherited(process.execPath,[path.join(root,'src/export-multirow.mjs')],{cwd:root});console.log('In der Beta weiterhin START.cmd verwenden; alte Starter-Namen in Kernmeldungen stammen aus 0.7.4.');return r.code??1;}finally{lock.release();}
}
async function recover(){
 verifyRelease(root);assertWindowsIdle(root);const dir=controlDir(root),lf=path.join(dir,'operation.lock.json'),sf=path.join(dir,'last-run.json');
 let lock=null,state=null;if(fs.existsSync(lf)){lock=jsonRead(lf,65536);need(!processAlive(lock.pid),'OPERATION_ALIVE','Der Besitzer der Sperre laeuft noch. Keine Freigabe.');}
 if(fs.existsSync(sf))state=jsonRead(sf,65536);
 if(!lock&&!hasReviewState(state)){console.log('Keine offene Wiederanlaufpruefung.');return 0;}
 console.log('\nEin vorheriger Lauf/Sperrbesitzer wurde unterbrochen. Dieses Menue beweist KEINEN Versand.');
 console.log('COMARCH-Nachrichtenverlauf, Empfaenger und Ticket-Speicherung des letzten Falls manuell pruefen.\nEine erfolgte Nachricht nicht erneut senden. Das Tool startet hier keinen Bot.');
 if((await ask('Nach eigener Pruefung GEPRUEFT eingeben: ')).toUpperCase()!=='GEPRUEFT'){console.log('Gesperrt belassen.');return 0;}
 assertWindowsIdle(root);
 if(lock){const cur=jsonRead(lf,65536);need(JSON.stringify(cur)===JSON.stringify(lock)&&!processAlive(cur.pid),'LOCK_CHANGED','Sperre hat sich geaendert.');const ad=path.join(dir,'lock_archive');fs.mkdirSync(ad,{recursive:true});assertPlainPath(ad);fs.renameSync(lf,path.join(ad,'lock_'+stamp()+'.json'));}
 if(state){atomicJSON(sf,{...state,state:'OPERATOR_REVIEWED_NOT_RETRIED',reviewedAt:new Date().toISOString(),ticketDeliveryVerified:false});}
 console.log('Manuelle Pruefung dokumentiert. Kein Ticket geaendert, kein Versand ausgeloest.');return 0;
}
async function selfTest(){
 verifyRelease(root);const test=path.join(root,'tools/tests/beta.test.mjs');const r=await spawnInherited(process.execPath,['--test',test],{cwd:root});return r.code??1;
}
function openLocal(relative){need(process.platform==='win32','WINDOWS_REQUIRED','Ordner/Handbuch bitte lokal oeffnen.');const dest=path.resolve(root,relative);assertPlainPath(dest);spawn('explorer.exe',[dest],{stdio:'ignore',windowsHide:true}).unref();}
async function menu(){
 for(;;){
  title();console.log('  1  Ticketlauf starten                 [ECHT: Senden + Speichern]\n  2  Paket und aktives Mapping pruefen  [nur lokal lesen]\n  3  Funktionsdemo                     [nur fiktive Tickets]\n  4  Selbsttest                        [ohne Edge/COMARCH]\n  5  Handbuch oeffnen\n  6  Mapping-Wartung                    [selbe XLSX neu auswerten]\n  7  Wiederanlauf nach Abbruch pruefen\n  8  Diagnoseordner oeffnen\n  0  Beenden');
  const selection=await ask('\nAuswahl: ');
  if(selection==='0')return 0;
  try{
   if(selection==='1')await realRun();else if(selection==='2')printStatus(status());else if(selection==='3')await demoRun();else if(selection==='4')await selfTest();else if(selection==='5')openLocal('docs/HANDBUCH.html');else if(selection==='6')await rebuildMapping();else if(selection==='7')await recover();else if(selection==='8')openLocal('diagnostics');else console.log('Bitte 0 bis 8 eingeben.');
  }catch(e){console.error('\nSTOP: '+(e.code||'BETA_ERROR')+' - '+e.message);}
  await ask('\nENTER zum Hauptmenue ...');
 }
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 try{
  const [major,minor]=process.versions.node.split('.').map(Number);need(major>22||major===22&&minor>=15,'NODE_VERSION','Node.js ab 22.15 erforderlich.');verifyRelease(root);
  const action=process.argv[2]||'--menu';
  if(action==='--status'){title();const s=status();printStatus(s);process.exitCode=s.mappingReady?0:2;}
  else if(action==='--selftest')process.exitCode=await selfTest();
  else if(action==='--demo')process.exitCode=await demoRun();
  else if(action==='--run')process.exitCode=await realRun();
  else if(action==='--menu')process.exitCode=await menu();
  else need(false,'ARGUMENT','Unbekannter Startparameter.');
 }catch(e){console.error('\nSTOP: '+(e.code||'BETA_ERROR')+' - '+e.message);process.exitCode=1;}
}
