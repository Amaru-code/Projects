/** Release-only utilities. No browser, network, ticket or business-rule operations. */
import fs from 'node:fs';
import path from 'node:path';
import {createHash,randomBytes} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
export const RELEASE='0.8.0-beta.1';
export const ENGINE='0.7.4';
export const PACKAGE_ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
export const PROTECTED=new Set(['.runtime','private_data','diagnostics','.git','node_modules']);
export const sha=b=>createHash('sha256').update(b).digest('hex');
export function need(ok,code,message){if(!ok)throw Object.assign(new Error(message),{code});}
export const stamp=()=>new Date().toISOString().replace(/[:.]/g,'-')+'_'+randomBytes(4).toString('hex');
export function jsonRead(file,max=64*1024*1024){
 const s=fs.lstatSync(file);need(s.isFile()&&!s.isSymbolicLink()&&s.size<=max,'UNSAFE_FILE','Datei fehlt, ist verknuepft oder zu gross: '+path.basename(file));
 return JSON.parse(fs.readFileSync(file,'utf8').replace(/^\uFEFF/,''));
}
export function atomicJSON(file,value){
 const tmp=file+'.'+randomBytes(6).toString('hex')+'.tmp';const fd=fs.openSync(tmp,'wx',0o600);
 try{fs.writeFileSync(fd,JSON.stringify(value,null,2)+'\n','utf8');fs.fsyncSync(fd);}finally{fs.closeSync(fd);}
 // Same directory. Keep the previous file intact until the rename succeeds.
 try{fs.renameSync(tmp,file);}catch(e){try{fs.unlinkSync(tmp);}catch{}throw e;}
}
export function safeRelative(p){return typeof p==='string'&&p.length>0&&p.length<2048&&!/[\\:\x00-\x1f]/.test(p)&&!p.startsWith('/')&&!p.split('/').some(x=>!x||x==='.'||x==='..');}
export function assertPlainPath(p,{allowMissingLeaf=false}={}){
 const abs=path.resolve(p),parsed=path.parse(abs);let current=parsed.root;
 for(const part of abs.slice(parsed.root.length).split(path.sep).filter(Boolean)){
  current=path.join(current,part);
  if(!fs.existsSync(current)){need(allowMissingLeaf&&current===abs,'PATH_MISSING','Pfad fehlt: '+current);return abs;}
  const s=fs.lstatSync(current);need(!s.isSymbolicLink(),'LINK_BLOCKED','Symbolischer Link/Junction wird nicht verfolgt: '+current);
 }
 return abs;
}
export function fileRecord(base,rel){
 need(safeRelative(rel),'PATH_INVALID','Ungueltiger relativer Pfad.');const p=assertPlainPath(path.join(base,...rel.split('/')));
 const st=fs.lstatSync(p);need(st.isFile()&&st.size<=64*1024*1024,'FILE_INVALID','Keine begrenzte normale Paketdatei: '+rel);
 const raw=fs.readFileSync(p);need(raw.length===st.size,'FILE_CHANGED','Datei beim Lesen geaendert.');return {path:rel,bytes:raw.length,sha256:sha(raw)};
}
export function treeRecord(p){
 assertPlainPath(p);const files=[],dirs=[];let total=0,count=0;
 function walk(dir,prefix){
  for(const e of fs.readdirSync(dir,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name))){
   const rel=prefix?prefix+'/'+e.name:e.name;need(safeRelative(rel),'PATH_INVALID','Sonderpfad im Softwareordner.');
   need(++count<=30000,'SOFTWARE_BUDGET','Zu viele Dateien im Softwareordner. Nicht automatisch archivieren.');
   const f=path.join(dir,e.name),st=fs.lstatSync(f);need(!st.isSymbolicLink(),'LINK_BLOCKED','Verknuepfung im Softwareordner: '+rel);
   if(st.isDirectory()){dirs.push(rel);walk(f,rel);}else{need(st.isFile(),'SPECIAL_FILE','Keine normale Datei: '+rel);const r=fileRecord(p,rel);files.push(r);total+=r.bytes;need(total<=512*1024*1024,'SOFTWARE_BUDGET','Softwareordner ueber 512 MiB. Keine automatische Archivierung.');}
  }
 }
 const s=fs.lstatSync(p);
 if(s.isFile()){const r=fileRecord(path.dirname(p),path.basename(p));return {kind:'file',bytes:r.bytes,files:1,digest:r.sha256};}
 need(s.isDirectory(),'SPECIAL_FILE','Kein normaler Softwareordner.');walk(p,'');return {kind:'directory',bytes:total,files:files.length,digest:sha(JSON.stringify({dirs,files}))};
}
export function verifyRecords(root,records){
 need(Array.isArray(records)&&records.length>0,'MANIFEST_EMPTY','Manifest fehlt.');const seen=new Set();
 for(const r of records){
  need(r&&safeRelative(r.path)&&!seen.has(r.path.toLowerCase()),'MANIFEST_PATH','Unsicherer/doppelter Manifestpfad.');seen.add(r.path.toLowerCase());
  need(Number.isSafeInteger(r.bytes)&&r.bytes>=0&&/^[a-f0-9]{64}$/.test(r.sha256??''),'MANIFEST_RECORD','Ungueltiger Dateinachweis.');
  const actual=fileRecord(root,r.path);need(actual.bytes===r.bytes&&actual.sha256===r.sha256,'PACKAGE_HASH','Datei abweichend: '+r.path);
 }
 return seen;
}
export function verifyRelease(root=PACKAGE_ROOT){
 assertPlainPath(root);const m=jsonRead(path.join(root,'MANIFEST.json'),2*1024*1024);
 need(m.schema==='MCR_BETA_PACKAGE_V1'&&m.package==='MCR_Ticket_Assistant'&&m.version===RELEASE&&m.engineVersion===ENGINE,'PACKAGE_IDENTITY','Kein vollstaendiges Beta-1-Paket. Bitte BETA_EINRICHTEN.cmd verwenden, nicht manuell mischen.');
 const seen=verifyRecords(root,m.payload);
 for(const r of ['START.cmd','package.json','tools/beta-cli.mjs','tools/beta-common.mjs','tools/migration.mjs','tools/process-guard.ps1','tools/reference/engine-lock.json','src/local-bot-full-run.mjs','src/export-multirow.mjs','lib/active-mapping.mjs','lib/multirow-tpp-mapping.mjs','config/local-runner-queue-send.json'])need(seen.has(r.toLowerCase()),'PACKAGE_COVERAGE','Kritische Paketdatei ohne Nachweis: '+r);
 const lock=jsonRead(path.join(root,'tools/reference/engine-lock.json'));
 need(lock.schema==='MCR_ENGINE_LOCK_V1'&&lock.engineVersion===ENGINE&&lock.files.length===17,'ENGINE_LOCK','Unvollstaendiger Kernnachweis.');
 verifyRecords(root,lock.files);for(const r of lock.files)need(seen.has(r.path.toLowerCase()),'ENGINE_COVERAGE','Kern nicht vom Paketmanifest gedeckt.');
 // An old starter must not survive an incorrect merge in the daily entry folder.
 for(const f of fs.readdirSync(root))if(/\.(?:cmd|bat|ps1|mjs|cjs|js|html)$/i.test(f))need(f==='START.cmd','OLD_STARTER_PRESENT','Alter Starter im Hauptordner: '+f+'. Nicht manuell mischen; Umstellung verwenden.');
 return {version:RELEASE,engineVersion:ENGINE,files:m.payload.length,frozenFiles:lock.files.length,manifestHash:sha(fs.readFileSync(path.join(root,'MANIFEST.json')))};
}
export function verifyBaseline(root,referenceRoot=PACKAGE_ROOT){
 const ref=jsonRead(path.join(referenceRoot,'tools/reference/baseline-0.7.4-manifest.json'));
 const local=jsonRead(path.join(root,'MANIFEST.json'));
 need(local.schema===ref.schema&&local.package===ref.package&&local.version===ENGINE,'BASELINE_VERSION','Umstellung benoetigt den vollstaendigen, funktionierenden 0.7.4-Stand.');
 need(JSON.stringify(local)===JSON.stringify(ref),'BASELINE_MANIFEST','0.7.4-Manifest weicht von der gelieferten Referenz ab. Keine automatische Umstellung.');
 verifyRecords(root,ref.payload);return ref;
}
export function assertWindowsIdle(root,{excludePid=process.pid}={}){
 need(process.platform==='win32','WINDOWS_REQUIRED','Die echte Umstellung/der Echtlauf ist fuer Windows vorgesehen.');
 const ps=path.join(process.env.SystemRoot||'C:\\Windows','System32','WindowsPowerShell','v1.0','powershell.exe');
 const file=path.join(PACKAGE_ROOT,'tools/process-guard.ps1');let raw;
 try{raw=execFileSync(ps,['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',file],{env:{...process.env,MCR_GUARD_ROOT:path.resolve(root),MCR_GUARD_EXCLUDE_PID:String(excludePid)},encoding:'utf8',timeout:20000,windowsHide:true,maxBuffer:128*1024});}
 catch{throw Object.assign(new Error('Prozesspruefung nicht verfuegbar. Kein Prozess wird beendet; Umstellung/Echtlauf bleibt gesperrt.'),{code:'PROCESS_CHECK_UNAVAILABLE'});}
 let p;try{p=JSON.parse(raw.trim().replace(/^\uFEFF/,''));}catch{need(false,'PROCESS_CHECK_UNAVAILABLE','Prozesspruefung hat kein gueltiges Ergebnis geliefert.');}
 need(p?.schema==='MCR_PROCESS_GUARD_V1'&&p.checked===true,'PROCESS_CHECK_UNAVAILABLE','Prozesspruefung unvollstaendig.');
 need(p.blockedCount===0&&p.unknownCount===0,'MCR_PROCESSES_ACTIVE','Bitte den alten MCR-Bot und das eigene MCR-Edge-Fenster schliessen. Normale andere Programme werden nicht beendet.');
 return p;
}
export function processAlive(pid){
 if(!Number.isSafeInteger(pid)||pid<1)return false;
 try{process.kill(pid,0);return true;}catch(e){return e.code!=='ESRCH';}
}
export function controlDir(root){
 const runtime=path.join(root,'.runtime');if(!fs.existsSync(runtime))fs.mkdirSync(runtime);
 assertPlainPath(runtime);const dir=path.join(runtime,'beta-control');if(!fs.existsSync(dir))fs.mkdirSync(dir);assertPlainPath(dir);return dir;
}
export function acquireLock(root,operation){
 const dir=controlDir(root),file=path.join(dir,'operation.lock.json');let fd;
 try{fd=fs.openSync(file,'wx',0o600);}catch(e){if(e.code==='EEXIST')need(false,'OPERATION_LOCKED','Eine Beta-Operation laeuft oder wurde unterbrochen. Menue: Wiederanlauf pruefen.');throw e;}
 const token=randomBytes(16).toString('hex');
 try{fs.writeFileSync(fd,JSON.stringify({schema:'MCR_OPERATION_LOCK_V1',pid:process.pid,operation,token,createdAt:new Date().toISOString()})+'\n');fs.fsyncSync(fd);}finally{fs.closeSync(fd);}
 return {file,release(){const p=jsonRead(file,65536);need(p.token===token,'LOCK_CHANGED','Sperrdatei wurde geaendert.');fs.unlinkSync(file);}};
}
