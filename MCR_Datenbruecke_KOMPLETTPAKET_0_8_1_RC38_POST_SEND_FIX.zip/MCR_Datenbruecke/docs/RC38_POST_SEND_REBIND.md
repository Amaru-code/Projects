# RC38 – Nach dem E-Mail-Versand dieselbe Ticketansicht erneut binden

- **Kein erneuter Versand:** Erst nach tatsächlichem Send-Nachweis und passendem `SENT_CONFIRMED`-Journal erfolgt die USC-/Status-Nacharbeit.
- ICEfaces kann nach dem Versand das Form neu erzeugen oder zur Vorgangsliste wechseln. RC38 öffnet dann ausschließlich die ursprüngliche Ticket-ID erneut, prüft den Bearbeitungsmodus und liest das exakt zugeordnete Beschreibungsfeld.
- Bei exakt unveränderten USC-Zeilen wird nur `Standardantwort versendet` angehängt. Bei leerem Feld darf nur die zuvor aus dem verifizierten Mapping gelesene identische USC-Beschreibung restauriert werden. Fremde/geänderte Texte sperren die Aktion.
- Anschließend ist **höchstens ein** gespeicherter, verifizierter COMARCH-Speicherklick erlaubt. Speichernachweise werden über die exakte mehrzeilige Beschreibung (nicht nur zusammengezogene Leerzeichen) geprüft.
- Bei unbestätigtem Versand, nicht auffindbarem Ticket, abweichender Identität oder bereits begonnener ungeklärter Speicherung gilt Fail-Closed. Es werden keine Nachrichten erneut verschickt, keine Tickets als abgeschlossen behauptet.
- Die Phase-2-Menüpunkte 9–11 und die PDF-Belege bleiben unverändert. Kein Ticketabschluss, keine COMARCH-PDF-Aktion.
- Bestehende unresolved Tickets bleiben **gesperrt**; diese Änderung ist kein Freibrief, deren Status durch einen erneuten Versand zu überschreiben. Zum Wiederanlauf müssen Nachrichtenverlauf und Speicherung unabhängig geprüft werden.
