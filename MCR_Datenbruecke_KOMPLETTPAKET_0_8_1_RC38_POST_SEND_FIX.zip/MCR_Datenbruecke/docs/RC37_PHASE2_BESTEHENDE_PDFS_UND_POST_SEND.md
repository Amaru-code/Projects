# RC37 – Phase 2: WWID-PDFs ohne Neuerzeugung, Member-Lookup und Phase-1-Nachweis

## Phase-2-Menü 11

- Eindeutiges Ticket aus frischer Menü-9-Inventur auswählen. COMARCH öffnen (nur lesender Detailaufruf), tatsächliche Ticket-ID und unveränderten Beschreibungstext prüfen.
- Vorhandenen strukturierten COMARCH-Member lesen. MercerID bleibt getrennt. WWID nur aus eindeutig beschriftetem `WWID`, `Workday ID` oder `Worker ID` im selben Formular übernehmen. Wenn WWID dort fehlt, die *beiden* Datei-Namen `{WWID}_Kontoauszug_DC.pdf` und `{WWID}_Kontoauszug_PP+.pdf` als Kandidaten zusammenführen. Dies ist keine Identitätsprüfung!
- Beide vorhandenen Original-PDFs ohne neuen Generatorlauf lesen, PDF-Header/EOF, Größe, SHA256, eindeutigen Dateinamen und unveränderte Datei prüfen.
- Nach dokumentierter einmaliger manueller Inhalts-/Personenprüfung ein **lokales** PDF-Belegpaket und Vorschau der vierten COMARCH-Zeile erstellen. Keine Dateien verschieben, löschen oder überschreiben. Keine automatische Erstellung, kein Upload, keine Mail und keine Weiterleitung.
- Einmalige WWID-Eingabe nur wenn weder eindeutige COMARCH-WWID noch ein gemeinsamer Dateinamenskandidat vorliegt. Keine Vor-/Nachnamen-Eingabe nötig für exakte WWID-Dateinamen.

## Phase 1

Der Benutzerbericht zu Ticket 87647759 endet im Auszug *vor* Versandnachweis und Save-Status. Der tatsächliche Ausgang ist damit offen. Die bereits vorhandene starke Regel bleibt: Auto-Fortsetzung nur nach nachgewiesener neuer ausgehender Antwort **und** nachgewiesener Speicherung der USC-/Statusbeschreibung. RC37 versucht nach nachgewiesenem Versand bis zu dreimal nur das idempotente **Status-Textfeld**, um ICEfaces-DOM-Neuaufbau zu tolerieren. Es wird niemals erneut auf Senden oder Speichern geklickt. Wenn die Bestätigung fehlt, bleibt das Ticket bewusst gesperrt und benötigt Diagnose/Menü 5.

## Schutz

Kein Generator wird automatisch gestartet (BAT-Vertrag noch unbekannt). Insbesondere darf ein gleicher Dateiname niemals eine inhaltliche Kontrolle ersetzen. Die explizit überprüfte Person und der berechtigte Adressat sind vor jeder künftigen Anlage erneut zu verifizieren. Offene Phase-1-Sendejournale bleiben unverändert.
