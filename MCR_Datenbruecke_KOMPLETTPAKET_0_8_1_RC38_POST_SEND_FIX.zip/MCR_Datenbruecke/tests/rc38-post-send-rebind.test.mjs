import test from 'node:test';import assert from 'node:assert/strict';
import {preparePostSendDescription} from '../lib/post-send-editor-rebind.mjs';
import {markAfterVerifiedSend} from '../lib/post-send-status-retry.mjs';
const ticketId='87782495',source='USC 20/ DC;PP+',marker='Standardantwort versendet',expected=source+'\n'+marker;
const defaults={ticketId,source,expected,delay:async()=>{}};
const err=async(fn,code)=>assert.rejects(fn,e=>e.code===code);
test('RC38 COMARCH clears field after send: same ticket rebind restores USC, appends marker, no send method',async()=>{
 let id=ticketId,txt='',ed=false,restores=0,ensures=0;
 const bind=async x=>assert.equal(id,x),read=async()=>({ok:ed,value:txt,editable:ed}),ensureEdit=async()=>{ed=true;ensures++},write=async value=>{txt=value;restores++;return {ok:true}},verify=async value=>txt===value;
 const prepared=await preparePostSendDescription({...defaults,bind,read,ensureEdit,write,verify});
 assert.deepEqual(prepared,{status:'SOURCE_RESTORED',restored:true});assert.equal(txt,source);assert.equal(restores,1);assert.equal(ensures,1);
 const r=await markAfterVerifiedSend({ticketId,expected,marker,assertTicket:bind,append:async m=>{txt+='\n'+m;return {ok:true,value:txt}},verify:async v=>v===txt,delay:async()=>{}});
 assert.equal(r,true);assert.equal(txt,expected);
});
test('RC38 existing correct status is idempotent; no new write, no second save',async()=>{
 let n=0;
 const result=await preparePostSendDescription({...defaults,bind:async()=>{},read:async()=>({ok:true,editable:true,value:expected}),write:async()=>{n++;return {ok:true}}});
 assert.equal(result.status,'EXISTING_CORRECT');assert.equal(n,0);
});
test('RC38 existing source does not append USC twice',async()=>{
 let n=0;const result=await preparePostSendDescription({...defaults,bind:async()=>{},read:async()=>({ok:true,editable:true,value:source}),write:async()=>{n++;return {ok:true}}});
 assert.equal(result.status,'SOURCE_READY');assert.equal(n,0);
});
test('RC38 refuses wrong ticket, competing data, ambiguous field and missing verification before save',async()=>{
 await err(preparePostSendDescription({...defaults,bind:async()=>{throw Object.assign(new Error('wrong ticket'),{code:'TICKET_BINDING'})},read:async()=>({ok:true,editable:true,value:''})}),'TICKET_BINDING');
 await err(preparePostSendDescription({...defaults,bind:async()=>{},read:async()=>({ok:true,editable:true,value:'USC 99/ DB+'})}),'POST_SEND_DESCRIPTION_CONFLICT');
 await err(preparePostSendDescription({...defaults,bind:async()=>{},read:async()=>({ok:false,editable:false}),ensureEdit:async()=>{}}),'POST_SEND_DESCRIPTION_MISSING');
 await err(preparePostSendDescription({...defaults,bind:async()=>{},read:async()=>({ok:true,editable:true,value:''}),write:async()=>({ok:true}),verify:async()=>false}),'POST_SEND_SOURCE_RESTORE_UNVERIFIED');
});
test('RC38 pre-status preparation retries TEXT only and no second send/save surfaces available',async()=>{
 let preps=0,appends=0;
 const got=await markAfterVerifiedSend({ticketId,expected,marker,prepare:async()=>preps++,assertTicket:async()=>{},append:async()=>{appends++;return {ok:true,value:expected}},verify:async()=>appends===2,delay:async()=>{}});
 assert.equal(got,true);assert.equal(preps,2);assert.equal(appends,2);
});
