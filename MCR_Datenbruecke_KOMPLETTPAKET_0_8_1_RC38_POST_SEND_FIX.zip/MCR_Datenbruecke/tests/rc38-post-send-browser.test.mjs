import test from 'node:test';import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';import path from 'node:path';import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
test('RC38 Chromium sends once, ICEfaces resets edit DOM, restores USC and saves once',()=>{
 const r=spawnSync(process.execPath,[path.join(root,'src/local-bot-full-run.mjs'),'--demo','--auto','--headless','--close-browser'],{
  cwd:root,env:{...process.env,MCR_DEMO_SCENARIO:'rc38-postsend-rerender',MCR_DEMO_TICKET_LIMIT:'1',MCR_RUN_ID:'rc38-browser-smoke'},encoding:'utf8',timeout:90000,maxBuffer:4*1024*1024});
 assert.equal(r.status,0,'Fiktiver Browsertest fehlgeschlagen: '+r.stdout.slice(-4000)+' '+r.stderr.slice(-1800));
 assert.match(r.stdout,/PASS POST_SEND_USC_RESTORED_AFTER_DOM_REBIND/);
 assert.match(r.stdout,/Ticket speichern PASS/);
 assert.match(r.stdout,/PASS RC38_DEMO_REBIND_SINGLE_SEND_SINGLE_SAVE/);
});
