import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import {readPhase2MemberEvidence} from '../lib/phase2-member-evidence.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
test('RC37 Chromium Member WWID explicit only, zero clicks',{timeout:60000},async()=>{
const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-P2-DOM-RC37-'));let browser,cdp;
try{
 browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,
  extraArgs:['--disable-background-networking','--disable-sync',...(process.platform!=='win32'&&process.getuid?.()===0?['--no-sandbox']:[])]});
 ({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>t.url==='about:blank');
 await page.call(function(){document.body.innerHTML=`<form id="mainForm">
  <input id="mainForm:member-value-id" value="Max Mustermann (INTL01-99900001)"/>
  <table><tbody><tr><td>Mercer ID</td><td>INTL01-99900001</td></tr>
   <tr><td>Vorname</td><td>Max</td></tr><tr><td>Nachname</td><td>Mustermann</td></tr>
   <tr><td>WWID</td><td>98765432</td></tr></tbody></table></form>`;
  window.rc37Clicks=0;document.addEventListener('click',()=>window.rc37Clicks++);});
 let r=await readPhase2MemberEvidence(page);
 assert.equal(r.profileVerified,true);assert.equal(r.profile.first,'Max');assert.equal(r.profile.last,'Mustermann');
 assert.equal(r.wwid,'98765432');assert.equal(r.wwidEvidence,'EXACT_LABELED_WWID');
 assert.equal(await page.eval('window.rc37Clicks'),0);
 await page.call(function(){document.querySelectorAll('tr')[3].cells[0].textContent='Mercer ID';});
 r=await readPhase2MemberEvidence(page);assert.equal(r.wwid,null);assert.equal(r.profileVerified,true);
 console.log('PASS RC37_BROWSER_MEMBER_WWID_EXPLICIT_ONLY_NO_CLICKS');
}finally{await cleanupTemporaryTestBrowser({profile,browser,cdp});}

});
