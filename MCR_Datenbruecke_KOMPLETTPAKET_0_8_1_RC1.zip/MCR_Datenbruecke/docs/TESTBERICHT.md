# Prüfbericht – MCR Datenbruecke 0.8.1 RC1

## Ergebnis

**108/108 automatisierte Selbsttests bestanden. 8/8 Chromium-Browsertests bestanden.**
Zusätzlich hat der integrierte CLI-Demostart zwei fiktive Tickets vollständig abgearbeitet.

| Prüfung | Beobachtetes Ergebnis |
|---|---|
| Fachregeln, Identität, Mapping-Pointer, Journale, Parser, Paket und Installation | 108 bestanden, 0 fehlgeschlagen, 0 übersprungen |
| Fiktiver Gesamtablauf bei 720, 1280 und 1920 Pixeln | Jeweils 2 Tickets, 2 Sendeklicks und 2 Speicherklicks, vollständige gespeicherte Beschreibung |
| Vertrauenswürdige Browserereignisse | Send/Save in allen drei normalen Läufen mit `event.isTrusted === true` |
| Umgebrochener Inline-Link | Alter Mittelpunkt verfehlt das Ziel; neue Zielprüfung trifft es mit genau einem Browserklick |
| Verdeckt / mehrdeutig | Kein Aktionsklick ausgeführt |
| Absichtlich verkürzte gespeicherte Beschreibung | Erwarteter Stopp `SAVE_UNVERIFIED`, keine Bearbeitung des zweiten Tickets |
| Absichtlich nicht gespeicherte Beschreibung | Erwarteter Stopp `SAVE_UNVERIFIED`, keine Bearbeitung des zweiten Tickets |
| CLI mit mitgelieferten Dateien | `PASS DEMO_GESAMTPAKET_2_TICKETS` |
| Update und Rückweg | Mit synthetischem Altbestand sowie sechs injizierten Verschiebefehlern und einer simulierten Unterbrechung geprüft |
| Daten-/Profil-Schutz im Installer | Synthetische Bestands-, Profil- und Alt-Laufdaten blieben bei Update/Rückweg unverändert |

## Was diese Tests nicht beweisen

Sie wurden unter Linux mit Node.js 22.16.0 und installiertem Chromium ausgeführt.
Die Windows-CMD-Dateien und die Windows-CIM-Prozessabfrage wurden hier nicht ausgeführt.
Der echte COMARCH-Server, das Firmen-Edge-Profil und reale Bestandsdaten wurden nicht benutzt.
Eine echte Sendung und Speicherung müssen deshalb im beaufsichtigten Windows-Piloten
noch bestätigt werden. Eine Anwendungsmeldung ist zudem keine externe Zustellbestätigung.

Der Lieferstand ist ein vollständiger Release-Kandidat, nicht als produktiv abgenommen
etikettiert. Die Live-Sperre wird nicht durch fiktive Testzähler aufgehoben.

## Reproduzierbarkeit

`START.cmd` -> Menü 6: lokale Selbsttests.
`START.cmd` -> Menü 2: fiktiver Zwei-Ticket-Gesamtlauf.
Zusätzliche vollständige Browser-Testmatrix: `node tests/browser-e2e.mjs`.
Die Browser-Testmatrix startet ausschließlich fiktive Testfälle, keinen Echtlauf.

Einzelnachweise im ZIP: `docs/SELFTEST.tap`, `docs/BROWSER_QA.json`,
`docs/CLI_DEMO_ERGEBNIS.json` und `docs/QUALIFIKATION.json`.

## Herkunft

Die Programmdateien wurden aus den übergebenen Quellen konsolidiert und teilweise
modularisiert. Es wird keine Byteidentität zu Beta 4 oder RC1.1 behauptet. Der bekannte
Beta-4-Stand wird beim lokalen Update als Ausgangsbasis geprüft und bytegenau archiviert.
Die neue Version ist vollständig im eigenen Manifest versiegelt.
