# MCR Datenbruecke – vollständiges Paket 0.8.1 RC1

Dieses ZIP enthält das vollständige Programm in einem Ordner `MCR_Datenbruecke`.
Es ist kein Patch und sucht keine RC1.1-, V8-, V9- oder sonstigen Alt-Downloads.
Alle Laufzeitmodule, Identity-Prüfungen, Demo-Daten, Selbsttests und der Installer
sind enthalten. Externe npm-Abhängigkeiten: keine. Verwendet werden die bereits
vorhandene portable Node-Installation (ab 22.15) und Microsoft Edge.

**Prüfstand:** reale Chromium-Tests der fiktiven Oberfläche und lokale Unit-/Dateisystemtests.
Windows/echtes COMARCH sind nicht aus der Entwicklungsumgebung geprüft. RC bedeutet
Release-Kandidat, nicht eine bereits nachgewiesene produktive Freigabe.

## Drei Schritte

1. ZIP über „Alle extrahieren“ nach Downloads oder in einen anderen **neuen** Ordner
   entpacken. Nicht über den bisherigen `MCR_Datenbruecke`-Ordner kopieren.
2. Den alten Ticketbot und sein eigenes Edge-Fenster schließen. Im neuen Ordner
   `START.cmd` starten und **1 – Einrichten / aktualisieren und testen** auswählen.
   Der vorgeschlagene Zielpfad ist:
   `%USERPROFILE%\projects\Aktive_Projekte\Ticket_bot\MCR_Datenbruecke`
3. Nach bestandenen Selbsttests und zwei fiktiven Tickets mit `EINRICHTEN` bestätigen.
   Das Programm archiviert nur die alte Software, installiert die neue Software
   und öffnet das Hauptmenü der bestehenden Installation. Künftig nur dort `START.cmd`.

Die Einrichtung sendet keine echten Nachrichten. Sie verändert weder die
Bestandsdateien unter `private_data` noch die vorhandene Config oder das Browserprofil.
Alte Software liegt separat unter `Ticket_bot\_MCR_Archiv\complete_<Zeitpunkt>\software`.
Der Installer führt vor jedem Update einen Hashvergleich des alten und neuen
Softwarestands durch. Unerwartete Änderungen werden nicht still überschrieben.

## Einmaliger echter Pilot

**Menü 3** ist ein beaufsichtigter Lauf für maximal ein echtes Ticket.
Das startet das eigene Bot-Edge-Fenster mit dem vorhandenen Browserprofil.
Nach Anmeldung `START` im Terminal eingeben. Unmittelbar vor dem Versand zeigt
es Ticket, Person, Empfänger, Beschreibung und Antwort lokal an.
Erst nach eigener Kontrolle mit `SENDEN` bestätigen.

Der Bot klickt Senden einmal, prüft den Anwendungsnachweis, klickt Ticket speichern
einmal und prüft den vollständigen Beschreibungstext in der Ticketliste.
Ein erfolgreiches Ticketlimit wird als normaler begrenzter Abschluss behandelt.
Erst nach `PASS LIVE_PILOT_SEND_AND_SAVE_VERIFIED` kann **Menü 4** den regulären
Lauf durchführen. Der reguläre Lauf verlangt eine eigene START-Freigabe und ein
Limit von 1 bis 100 Tickets. Ein leerer Lauf ist KEINE Pilotabnahme.

## Ein früherer Lauf ist ungeprüft?

Eine bestehende `last-run.json` aus Beta 4 wird übernommen und nicht zurückgesetzt.
Bei `LIVE_REVIEW_REQUIRED`, einer toten Laufsperre oder einer offenen Versandabsicht
**Menü 5** verwenden. Zuerst den letzten echten COMARCH-Nachrichtenverlauf prüfen.

* `SICHER_KEIN_VERSAND` nur wählen, wenn für alle offenen Fälle tatsächlich keine
  Antwort verschickt wurde. Erst diese ausdrückliche Erklärung erlaubt einen Retry.
* `VERSAND_UND_SPEICHERUNG_GEPRUEFT` nur wählen, wenn die bereits versendeten Antworten
  und die gespeicherten Tickets manuell nachgewiesen sind. Bereits beantwortete
  Tickets müssen auch für den alten Bot nicht mehr zulässig sein.
* Bei Unsicherheit ENTER: die Sperre bleibt bestehen.

Die Prüfentscheidung ist eine Bestätigung durch den Bediener, kein automatisch
ermittelter Versandnachweis. Menü 5 sendet und speichert nichts selbst.
Das neue dauerhafte Versandjournal verhindert den automatischen Neuversand nach
unklaren Unterbrechungen. Die einmalige Prüfung alter Beta-4-Läufe bleibt nötig,
weil diese Version noch kein solches ticketbezogenes Journal führte.

## Menü

1. Einrichten / aktualisieren und testen (kein Echtversand)
2. Fiktive Zwei-Ticket-Demo
3. Ein echtes Pilotticket mit SENDEN-Freigabe
4. Regulärer Lauf nach Pilotabnahme
5. Vorherigen Lauf prüfen / Wiederanlauf freigeben
6. Paket-/Mappingstatus und Selbsttests
7. Software-Rückweg
8. Mappingwartung aus derselben freigegebenen XLSX (für Reparatur NICHT nötig)
0. Beenden

## Erhaltene Fachregeln

Zuerst Meine Vorgänge / In_Bearbeitung, danach Warteschlange INTL01.
Nur E-MAIL-Tickets mit vollständig leerer zusätzlicher Beschreibung.
Echte Member-Auswahl und passender Name; nur ausdrücklich aktuelle MercerIDs
sind bindend. Zitierte/contextuelle Nummern werden nicht als aktuelle MercerID geraten.
Das aktive V2-Mehrzeilenmapping bleibt maßgeblich; kein Rückfall auf ältere Snapshots.
Pro physischer Bestandszeile eine Beschreibung, einschließlich identischer Zeilen.
Reihenfolge DC;PP+;DB+;TPP. Leere Flags bleiben leer; ungültige Zeilen sperren die Person.
Anrede aus Spalte O, bei fehlenden/widersprüchlichen Daten manuelle Prüfung.
Eine neutrale Antwort pro Ticket, nicht eine Antwort je Bestandszeile.

## Was tatsächlich geändert wurde

- Ein vollständiger Programmeinstieg ersetzt die vielen Wiederherstellungsstarter.
- Identity-Guard aus dem vorhandenen Reparaturcode integriert, inklusive Zitattrenner-Fix.
- Neue mitgelieferte deterministische fiktive Daten, fachlich dieselbe Zwei-Zeilen-Prüfung.
  Sie werden ausdrücklich NICHT als byteidentisches historisches RC1.1-Archiv bezeichnet.
- Demo-Payload-Zeitstempel ist fest; Originaldatei-, Payload- und fachliche Prüfungen
  werden nicht mehr mit einem historischen Laufhash verwechselt.
- Send/Save nutzen sichtbare Client-Rechtecke plus Zielprüfung vor dem Browserklick.
  Demo und echter Runner verwenden denselben Klickmechanismus; kein spezieller
  JavaScript-Speicheraufruf nur für die Demo.
- Dauerhafte Versandabsicht vor dem Sendeklick, gemeinsame Laufsperre und
  konservativer Wiederanlaufschutz.
- Keine pauschale Löschung alter MSG-Downloads. Jeder neue Download erhält einen
  eigenen Unterordner; die Originalbestandsdateien bleiben unangetastet.
- Ein echter Pilot verlangt zusätzlich die Freigabe der konkret vorbereiteten Antwort.

Der Programmcode wurde aus den im Chat übergebenen Quellen konsolidiert und teilweise
in kleinere Module aufgeteilt. Das ist eine neue, vollständig versiegelte Version,
kein behaupteter bytegleicher 0.7.4-/RC1.1-Stand. Neue Hashes stehen im Manifest.

## Ergebnisdateien

`Ergebnis\STATUS.json`, `Ergebnis\DEMO_ERGEBNIS.json` und
`Ergebnis\LETZTER_ECHTLAUF.json` enthalten Status/Klickzähler, keine Mailinhalte.
Der Demo-Bericht wird aus dem temporären Testordner dauerhaft nach Ergebnis kopiert.
Die aktuellen Diagnosen liegen unter `diagnostics` bzw. für die Demo unter Ergebnis.

**Nicht hochladen:** private_data, echte MSGs, .runtime/edge-profile und das vollständige
lokale Versandjournal. Das Browserprofil enthält private Sitzungsdaten.
Das lokale Journal enthält Ticketkennungen zur Wiederanlaufkontrolle; diese werden
nicht in die datensparsamen Diagnose-ZIPs übernommen.

## Rückweg

START.cmd aus dem **neuen separat entpackten ZIP** -> Menü 7.
Der Rückweg prüft die archivierte Software vor der Wiederherstellung. Neue Software
bleibt im Archiv erhalten; es werden keine Tickets oder versendeten Mails zurückgesetzt.
Bei einer unterbrochenen Installation verhindert `BETA_UMSTELLUNG_LAEUFT.txt` einen
normalen Start. Diesen Marker nicht manuell entfernen. Gegebenenfalls zuerst eine
verwaiste Laufsperre über Menü 5 prüfen, niemals einen laufenden Prozess blind beenden.

## Grenzen

Ein Versandnachweis der Anwendung ist keine externe Zustellbestätigung.
Die fiktive Demo bildet nicht jede ICEfaces-/COMARCH-Serverreaktion ab.
Ein erfolgreicher lokaler Test ersetzt den ersten echten Windows-Piloten nicht.
Bei Dateisystemen ohne verlässliches fsync ist ein absoluter Stromausfallschutz
nicht beweisbar; Hash-Rücklesen, Archiv und konservative Sperren bleiben aktiv.
