import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';
import {ROOT} from './helpers.mjs';import {VERSION} from '../lib/control.mjs';import {sha256} from '../lib/core.mjs';import {verifyPackage} from '../tools/integrity.mjs';
const BASELINE='b7a0d68940652bb1baa65afeffde1c6fab0be992f399134197c16baafb81b7cf';
test('RC58 exact original RC57 manifest pinned; upload, routing, MBC message composer, standard sending, migration and installation unchanged',()=>{
 assert.equal(VERSION,'0.8.1-rc.58');const ref=fs.readFileSync(path.join(ROOT,'tools/reference/complete-0.8.1-rc.57-manifest.json'));
 assert.equal(sha256(ref),BASELINE);
 const previous=JSON.parse(ref);
 for(const name of ['lib/phase2-filepond.mjs','lib/phase2-review-flow.mjs','lib/phase2-assignee.mjs',
  'lib/phase2-mbc-draft.mjs','lib/phase2-work-rules.mjs','lib/phase2-work-journal.mjs','src/local-bot-full-run.mjs',
  'tools/deploy.mjs','tools/cli.mjs','lib/migration-priority.mjs','lib/phase2-ticket-console.mjs']){
  assert.equal(sha256(fs.readFileSync(path.join(ROOT,name))),previous.payload.find(x=>x.path===name).sha256,name);
 }
 assert.equal(verifyPackage(ROOT).version,VERSION);
});
test('RC58 selects real COMARCH INTL01 signature only for private MBC drafts and has no mail send surface',()=>{
 const h=fs.readFileSync(path.join(ROOT,'src/phase2-work-handler.mjs'),'utf8');
 const signature=fs.readFileSync(path.join(ROOT,'lib/phase2-mbc-signature.mjs'),'utf8');
 assert(h.includes('MBC_SIGNATURE_DRAFT_SAVE_INTENT'));assert(h.includes('MBC_SIGNATURE_DRAFT_SAVE_VERIFIED'));
 assert(h.includes('P2_MBC_FINAL_SIGNATURE'));assert(signature.includes('mainForm:signature-value-id'));
 assert(signature.includes('INTL01 - Intel Deutschland GmbH'));
 assert(!/sendOnce\(|sendPhase2Mail\(|sendEmail\(|mainForm:send-new-message-button/.test(h+signature));
});
