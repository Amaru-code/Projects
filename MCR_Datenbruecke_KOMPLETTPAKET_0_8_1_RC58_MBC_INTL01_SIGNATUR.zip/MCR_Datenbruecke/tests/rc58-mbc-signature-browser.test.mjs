import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {temp,mapping} from './helpers.mjs';
import {withPhase2Browser,installPhase2Fixture} from './rc52-browser-fixture.mjs';
import {handlePhase2Work} from '../src/phase2-work-handler.mjs';
import {phase2WorkJournal} from '../lib/phase2-work-journal.mjs';
import {privateMbcDraft,PRIVATE_MBC_REQUEST,markedPhase2Description} from '../lib/phase2-work-rules.mjs';
import {MBC_SIGNATURE_VALUE} from '../lib/phase2-mbc-signature.mjs';
const id='87160524',original='USC 100/ DC\nStandardantwort versendet\n'+PRIVATE_MBC_REQUEST,after=markedPhase2Description(original);
const draft=privateMbcDraft({lastName:'Mustermann',gender:'M'}),row={ticketId:id,descriptionValue:original};
const member=async()=>({profileVerified:true,profile:{first:'Max',last:'Mustermann',mercerId:'99900001'}});
const noAsk=async prompt=>{throw Error('Unexpected prompt '+prompt);};
function oldReview(root){const j=phase2WorkJournal(root,id);j.begin({rule:'MBC_PRIVATE_EMAIL',descriptionBefore:original,descriptionAfter:after,draft,memberId:'99900001'});
 for(const state of ['EDIT_INTENT','DRAFT_SAVE_INTENT','DRAFT_SAVE_VERIFIED','EDIT_VERIFIED','TICKET_SAVE_INTENT','TICKET_SAVE_VERIFIED','REVIEW_INTENT','REVIEW_VERIFIED'])j.advance(state);
 return j;}
const makeOptions={requireMbcSignature:true};

test('RC58 new private-MBC case selects exact INTL01 via trusted COMARCH suggestion BEFORE draft save; no mail send',{timeout:65000},()=>withPhase2Browser(async page=>{
 const root=temp();try{
  await installPhase2Fixture(page,[{ticketId:id,description:original}],makeOptions);
  const logs=[];const result=await handlePhase2Work({root,page,row,mapping:mapping(),memberLookup:member,ask:noAsk,log:s=>logs.push(s)});
  assert.equal(result.status,'ROUTED_VERIFIED');
  assert.equal(await page.eval('_server[0].signature'),MBC_SIGNATURE_VALUE);
  assert.equal(await page.eval('_server[0].draft'),draft);
  assert.equal(await page.eval('_server[0].description'),after);
  const counts=await page.eval('_counts');assert.equal(counts.draft,1);assert.equal(counts.save,1);assert.equal(counts.review,1);assert.equal(counts.send,0);
  const seq=await page.eval('_order');assert(seq.indexOf('signature-selected')<seq.indexOf('draft'));assert(seq.indexOf('draft')<seq.indexOf('save'));assert(seq.indexOf('save')<seq.indexOf('review'));
  assert(logs.some(x=>x.includes('P2_MBC_SIGNATURE_EXACT')));
  const events=phase2WorkJournal(root,id).read().events;assert(events.some(e=>e.state==='MBC_SIGNATURE_DRAFT_SAVE_VERIFIED'));
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));

test('RC58 existing RC57 REVIEW_VERIFIED without EXECUTE_INTENT signs saved MBC once, re-saves only draft and then executes previously prepared Mark route',{timeout:65000},()=>withPhase2Browser(async page=>{
 const root=temp();try{
  const j=oldReview(root),prior=j.read().events;
  await installPhase2Fixture(page,[{ticketId:id,description:after,gevo:'Anfrage Member',draft}],makeOptions);
  const logs=[];const result=await handlePhase2Work({root,page,row:{ticketId:id,descriptionValue:after},mapping:mapping(),memberLookup:()=>{throw Error('No member lookup on resume');},ask:noAsk,log:s=>logs.push(s)});
  assert.equal(result.status,'ROUTED_VERIFIED');assert.deepEqual(j.read().events.slice(0,prior.length),prior);
  assert.equal(await page.eval('_counts.save'),0);assert.equal(await page.eval('_counts.draft'),1);assert.equal(await page.eval('_counts.review'),1);assert.equal(await page.eval('_counts.send'),0);
  assert.equal(await page.eval('_server[0].signature'),MBC_SIGNATURE_VALUE);assert.equal(await page.eval('_server[0].draft'),draft);
  assert(j.read().events.some(e=>e.state==='MBC_SIGNATURE_DRAFT_SAVE_INTENT'));
  assert(logs.some(s=>s.includes('P2_MBC_SIGNATURE_DRAFT_READY')));
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));

test('RC58 already selected INTL01 signature: existing reviewed ticket does not resave draft or ticket again',{timeout:65000},()=>withPhase2Browser(async page=>{
 const root=temp();try{oldReview(root);await installPhase2Fixture(page,[{ticketId:id,description:after,gevo:'Anfrage Member',draft,signature:MBC_SIGNATURE_VALUE}],makeOptions);
  const result=await handlePhase2Work({root,page,row:{ticketId:id,descriptionValue:after},mapping:mapping(),memberLookup:member,ask:noAsk,log:()=>{}});
  assert.equal(result.status,'ROUTED_VERIFIED');assert.equal(await page.eval('_counts.draft'),0);assert.equal(await page.eval('_counts.save'),0);assert.equal(await page.eval('_counts.send'),0);
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));

test('RC58 conflicting signature blocks without draft save, mail send or Mark forwarding',{timeout:55000},()=>withPhase2Browser(async page=>{
 const root=temp();try{const j=oldReview(root);await installPhase2Fixture(page,[{ticketId:id,description:after,gevo:'Anfrage Member',draft,signature:'Fremde Signatur'}],makeOptions);
  await assert.rejects(()=>handlePhase2Work({root,page,row:{ticketId:id,descriptionValue:after},mapping:mapping(),memberLookup:member,ask:noAsk,log:()=>{}}),e=>e.code==='P2_MBC_SIGNATURE_CONFLICT');
  assert.equal(await page.eval('_counts.draft+_counts.save+_counts.review+_counts.send'),0);assert.equal(j.read().state,'REVIEW_VERIFIED');
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));

test('RC58 interrupted signature draft-save is never clicked again, and route does not execute',{timeout:55000},()=>withPhase2Browser(async page=>{
 const root=temp();try{const j=oldReview(root);j.observe('MBC_SIGNATURE_SELECTION_INTENT');j.observe('MBC_SIGNATURE_DRAFT_SAVE_INTENT');
  await installPhase2Fixture(page,[{ticketId:id,description:after,gevo:'Anfrage Member',draft,signature:MBC_SIGNATURE_VALUE}],makeOptions);
  await assert.rejects(()=>handlePhase2Work({root,page,row:{ticketId:id,descriptionValue:after},mapping:mapping(),memberLookup:member,ask:noAsk,log:()=>{}}),e=>e.code==='P2_MBC_SIGNATURE_PREVIOUS_UNCERTAIN');
  assert.equal(await page.eval('_counts.draft+_counts.save+_counts.review+_counts.send'),0);
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}));
