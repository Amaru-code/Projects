# RC57 – Fokussicherung und kontrollierter Wiederanlauf

## Tatsächlicher Fehler aus RC56

Ticket `87160524` wurde als `UNSAVED_REPAIR_REQUIRED` erkannt;
GEVO war auf dem neu geladenen Ticket `EMPTY`, die zusätzliche Beschreibung
`ORIGINAL`. Der alte MBC-Entwurf wurde bereits gespeichert. Nach der ausdrücklichen
Freigabe `NICHT_GESPEICHERT_87160524` stoppte `commitDescription()` bei
`DESCRIPTION_FOCUS`. Der alte Klickpunkt lag nur in der Mitte der TEXAREA.
Die UI kann dort von ICEfaces-Dropdowns, Sticky-Elementen oder Overlays verdeckt sein.
Ein alleiniger Erfolg in der Testoberfläche hatte diesen Zustand nicht abgebildet.

## Korrektur

1. Das zuvor mittels `additionalDescriptionState()` eindeutig gebundene TEXAREA muss
   im richtigen Ticket liegen und den unveränderten erlaubten Ausgangstext tragen.
2. Passiv `scrollIntoView` (center/nearest/start/end), an mehreren viewportbegrenzten
   Koordinaten `elementFromPoint` auf **exakt dasselbe** TEXAREA prüfen.
3. Wenn kein vertrauenswürdiger automatischer Klickpunkt existiert, vor der manuellen
   Übernahme im Terminal `BEREIT_BESCHREIBUNG` eingeben. **Danach** im Edge mit der
   Maus den tatsächlich richtigen Beschreibungstextbereich fokussieren. Der Bot
   liest den aktiven DOM-Fokus des exakten Feldes; keine JavaScript-Fokussierung.
4. Nur bei verifiziertem Fokus wird der neue Text nativ eingegeben, durch Blur
   übernommen und erneut geprüft. Erst danach kann der einzelne Speicherschritt
   starten; Server-Readback und die unveränderte Mark-Baindl-Routinglogik folgen.
5. RC56 hatte `SAVE_REPAIR_AUTHORIZED` schon vor dem gescheiterten Fokusklick
   journalisiert. RC57 lässt eine begrenzte neue Freigabe nur zu, wenn seit
   dieser Autorisierung kein Speicherklick, keine weitere Schreibabsicht und
   keine Weiterleitung protokolliert wurden, der frische Serverzustand noch
   ORIGINAL/EMPTY ist und der gespeicherte MBC-Entwurf exakt übereinstimmt.
   Eine offene Aktion wird niemals durch Überschreiben/Löschen des Journals
   freigegeben.

## Abgrenzung

Alle PDF-Funktionen, die direkte DB-/DB+-Weiterleitung, die bestätigte
Prüferauswahl, der Phase-1-Versand und die Softwaremigration sind unverändert.
Die Browserregressionen nutzen Chromium und simulierte COMARCH-HTML-Seiten.
Der tatsächliche COMARCH-Lauf unter Windows bleibt unabhängig zu bestätigen.
Keine E-Mail und kein Generatorstart im Phase-2-Lauf.
