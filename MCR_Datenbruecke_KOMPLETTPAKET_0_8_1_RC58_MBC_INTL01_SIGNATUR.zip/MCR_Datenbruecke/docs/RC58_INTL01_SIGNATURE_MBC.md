# RC58 – INTL01-Signatur für MBC-Entwürfe

## Auslöser und belegter Stand

Der RC57-Echtlauf für Ticket `87160524` konnte die zuvor fehlenden Ticketfelder
speichern und Mark Baindl exakt als Prüfer nachweisen. Im Anschluss stoppte das
Bedienfenster im MANUELL-Modus mit `OPERATOR_ABORT` vor `EXECUTE_INTENT`.
Der letzte Weiterleitungsklick wurde damit **nicht** nachgewiesen.

Die neue fachliche Anforderung: Für eine vorbereitete MBC-Antwort wird, wie im
Standardprozess, die COMARCH-Signatur **INTL01 - Intel Deutschland GmbH** im
Signaturfeld gewählt – ohne E-Mail-Versand.

## Technische Umsetzung

* Ausschließlich für `MBC_PRIVATE_EMAIL` und ein eindeutig gebundenes Ticket.
* Echtes Feld `mainForm:signature-value-id`; der Wert `INTL01 - Intel Deutschland GmbH`
  wird über die native Browser-Tastatureingabe und den passenden sichtbaren
  Autocomplete-Vorschlag ausgewählt. Kein JavaScript-`click()`, keine unbekannte
  Vorlage, kein E-Mail-`Senden`.
* Der Fokus wechselt vor der verbindlichen Prüfung zum Editor. Ein eingegebener
  Suchstring ohne bestätigte Auswahl zählt nicht als Signatur.
* Neue MBC-Tickets: Nach Einsetzen des geprüften MBC-Textes und vor
  `Entwurf speichern` Signatur auswählen; der Antworttext wird nicht mit einem
  selbst erfundenen HTML-Footer überschrieben.
* Bereits vorbereitete Tickets mit `TICKET_SAVE_VERIFIED` oder `REVIEW_VERIFIED`
  ohne `EXECUTE_INTENT`: Die gespeicherte MBC-Antwort wird zuerst exakt geprüft.
  Wenn die Signatur fehlt, wird sie ausgewählt und **nur derselbe Entwurf**
  erneut gespeichert. Der vorher gespeicherte Tickettext/GEVO bleibt unangetastet;
  beides wird vor der Weiterleitung geprüft.
* Journal-Events `MBC_SIGNATURE_SELECTION_INTENT`,
  `MBC_SIGNATURE_SELECTED_EXACT`, `MBC_SIGNATURE_DRAFT_SAVE_INTENT` und
  `MBC_SIGNATURE_DRAFT_SAVE_VERIFIED` verhindern automatische Doppelaktionen.
  Ein ungeklärter vorheriger Signatur-Schreibversuch bleibt zur Prüfung offen.
* Der bestehende gemeinsame Weg `Weiterleiten zur Überprüfung` →
  `mainForm:next-persona-assignment-id` → `Baindl Mark (mark.baindl)` →
  **ein** `Schritt ausführen` bleibt unverändert. Das Bedienfenster bleibt
  MANUELL, bis der Benutzer AUTO bewusst einschaltet.

## Installation und Prüfung

RC58-ZIP in einen eigenen Ordner entpacken, START.cmd, Menü 1; danach installierte
START.cmd, Menü 12, Ticket `87160524`. Das bestehende RC57-Journal bleibt
bestehen. Bei einer noch offenen manuellen Weiterleitungsfreigabe muss der
Benutzer im Fenster aktiv zustimmen oder bewusst auf AUTO umstellen.

Prüfungen: gezielte echte Chromium/COMARCH-Modelltests für neue Entwürfe,
RC57-Review-Wiederanlauf, vorhandene Signatur, falsche Signatur und unklaren
Signatur-Speicherversuch. Zusätzlich Paket-/Version-/Upgrade-/Rückwegprüfungen.
Die produktive INTL01-Signatur und die konkrete native Windows-Oberfläche sind
noch **nicht** in einem echten COMARCH-Lauf nachgewiesen. Bei einer abweichenden
UI-Reaktion stoppt der Bot ohne Weiterleitung.
