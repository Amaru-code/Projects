/** Package verification is strict for execution. Known old files are accepted
 * ONLY as installation input, and must be archived with the old software. */
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {sha256,requireThat as need} from '../lib/core.mjs';
import {readJSON,plainPath,VERSION} from '../lib/control.mjs';
import {resolveConfig} from '../lib/config.mjs';

const PACKAGE_ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const CODE_DIRS=['src','lib','tools','tests','examples'];
const RC1_MANIFEST_SHA='68a55f739a1c1c60115a8f802e991164cb13342a69f7da3f753d3433a391238b';
const RC2_MANIFEST_SHA='f1d8fa7e80123d4489998c7100405befd33083c86a4f857bfae8fde9693ce4b2';
const RC3_MANIFEST_SHA='c313fc62b2ee567bdff780f51be923242dbd4100c0adee2b5d50d14044735baa';
const RC4_MANIFEST_SHA='ef5de55b2191559baf4f8d427b91f16a1451365c8e568c683f67cc0c869e5c41';
const RC5_MANIFEST_SHA='b5972143db33d54e8cc3ac9a9d40bedf676655a37bba1c89947b75d9baae17e3';
const RC6_MANIFEST_SHA='1be2245c59d005fddc97cb57f7bd840f198dc51ef4480a619206f5ac940eda38';
const RC7_MANIFEST_SHA='c32c5532032f902ababae291941cedb92a92399dcdaad937a7bbd9071ccac20d';
const LEGACY_REGISTRY_SHA='e1116088a7784505cef9c239e899eddefb5dc621c20d5ae0aa345bc8183c2729';
export const safeRelative=p=>typeof p==='string'&&p.length>0&&!/[\\:\x00-\x1f]/.test(p)&&!p.startsWith('/')&&!p.split('/').some(x=>!x||x==='.'||x==='..');

export function verifyRecords(root,records,{skipConfig=false}={}){
  need(Array.isArray(records)&&records.length>0&&records.length<2000,'MANIFEST_INVALID','Manifest fehlt/zu gross.');
  const seen=new Set();
  for(const r of records){
    need(r&&safeRelative(r.path)&&!seen.has(r.path.toLowerCase())&&Number.isSafeInteger(r.bytes)&&r.bytes>=0&&/^[a-f0-9]{64}$/.test(r.sha256),'MANIFEST_INVALID','Manifestpfad/Hash falsch.');
    seen.add(r.path.toLowerCase());
    if(skipConfig&&r.path==='config/local-runner-queue-send.json')continue;
    const p=plainPath(path.join(root,...r.path.split('/'))),s=fs.statSync(p);
    need(s.isFile()&&s.size===r.bytes&&s.size<32*1024*1024,'PACKAGE_SIZE','Dateilaenge abweichend: '+r.path);
    need(sha256(fs.readFileSync(p))===r.sha256,'PACKAGE_HASH','Programmdatei abweichend: '+r.path);
  }
  return seen;
}

function knownBeta4Residuals(){
  const f=plainPath(path.join(PACKAGE_ROOT,'tools/reference/beta4-residuals.json'));
  const r=readJSON(f,65536);
  need(sha256(fs.readFileSync(f))===LEGACY_REGISTRY_SHA&&r.schema==='MCR_KNOWN_BETA4_RESIDUALS_V1'&&Array.isArray(r.files)&&r.files.length===15,'LEGACY_REFERENCE_CHANGED','Altdatei-Referenz veraendert. Keine Uebernahme.');
  return new Map(r.files.map(x=>[x.path.toLowerCase(),x]));
}

function verifyCodeTree(root,seen,{knownResiduals=null}={}){
  const residuals=[],walked=new Set();let count=0;
  function walk(p,rel){
    plainPath(p);
    for(const n of fs.readdirSync(p).sort()){
      const f=path.join(p,n),r=rel+'/'+n,k=r.toLowerCase();
      need(++count<=10000&&safeRelative(r),'CODE_TREE_LIMIT','Zu viele/ungueltige Softwarepfade.');
      need(!walked.has(k),'CODE_PATH_COLLISION','Mehrdeutiger Softwarepfad: '+r);walked.add(k);
      plainPath(f);const st=fs.statSync(f);
      if(st.isDirectory()){walk(f,r);continue;}
      need(st.isFile(),'CODE_FILE','Keine regulaere Softwaredatei: '+r);
      if(seen.has(k))continue;
      const expected=knownResiduals?.get(k);
      need(expected,'UNSEALED_CODE','Unerwartete Programmdatei: '+r+'. Nichts manuell loeschen: START.cmd aus dem NEUEN separat entpackten Komplettpaket, Menue 1.');
      need(st.size===expected.bytes&&sha256(fs.readFileSync(f))===expected.sha256,'LEGACY_RESIDUAL_CHANGED','Bekannte Altdatei hat andere Bytes: '+r+'. Keine automatische Uebernahme.');
      residuals.push({path:r,bytes:expected.bytes,sha256:expected.sha256,sourceVersion:'0.8.0-beta.4'});
    }
  }
  for(const d of CODE_DIRS)walk(path.join(root,d),d);
  return residuals;
}

export function verifyPackage(root,{strictConfig=false}={}){
  plainPath(root);const f=path.join(root,'MANIFEST.json'),m=readJSON(f,2*1024*1024);
  need(m.schema==='MCR_COMPLETE_PACKAGE_V1'&&m.package==='MCR_Datenbruecke'&&m.version===VERSION,'PACKAGE_VERSION','Kein passendes Gesamtpaket.');
  const seen=verifyRecords(root,m.payload,{skipConfig:!strictConfig});
  verifyCodeTree(root,seen); // No residual-file exception for execution.
  resolveConfig(root);
  return {version:m.version,files:m.payload.length,manifestSha256:sha256(fs.readFileSync(f))};
}

/** Read-only recognition for update/rollback only. No imports from target,
 * no deletion, no relaxed runtime verifier, and no live authorization. */
export function verifyPrevious(root){
  plainPath(root);const file=path.join(root,'MANIFEST.json'),m=readJSON(file,2*1024*1024);
  if(m.schema==='MCR_COMPLETE_PACKAGE_V1'){
    need(m.package==='MCR_Datenbruecke','PACKAGE_VERSION','Fremdes Gesamtpaket.');
    const manifestSha=sha256(fs.readFileSync(file));
    let expectedSha;
    if(m.version==='0.8.1-rc.1'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.1-manifest.json'));
      need(sha256(fs.readFileSync(ref))===RC1_MANIFEST_SHA,'PREVIOUS_REFERENCE_CHANGED','RC1-Referenz veraendert.');
      expectedSha=RC1_MANIFEST_SHA;
    }else if(m.version==='0.8.1-rc.2'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.2-manifest.json'));
      need(sha256(fs.readFileSync(ref))===RC2_MANIFEST_SHA,'PREVIOUS_REFERENCE_CHANGED','RC2-Referenz veraendert.');
      expectedSha=RC2_MANIFEST_SHA;
    }else if(m.version==='0.8.1-rc.3'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.3-manifest.json'));
      need(sha256(fs.readFileSync(ref))===RC3_MANIFEST_SHA,'PREVIOUS_REFERENCE_CHANGED','RC3-Referenz veraendert.');
      expectedSha=RC3_MANIFEST_SHA;
    }else if(m.version==='0.8.1-rc.4'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.4-manifest.json'));
      need(sha256(fs.readFileSync(ref))===RC4_MANIFEST_SHA,'PREVIOUS_REFERENCE_CHANGED','RC4-Referenz veraendert.');
      expectedSha=RC4_MANIFEST_SHA;
    }else if(m.version==='0.8.1-rc.5'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.5-manifest.json'));
      need(sha256(fs.readFileSync(ref))===RC5_MANIFEST_SHA,'PREVIOUS_REFERENCE_CHANGED','RC5-Referenz veraendert.');
      expectedSha=RC5_MANIFEST_SHA;
    }else if(m.version==='0.8.1-rc.6'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.6-manifest.json'));
      need(sha256(fs.readFileSync(ref))===RC6_MANIFEST_SHA,'PREVIOUS_REFERENCE_CHANGED','RC6-Referenz veraendert.');
      expectedSha=RC6_MANIFEST_SHA;
    }else if(m.version==='0.8.1-rc.7'){
      const ref=plainPath(path.join(PACKAGE_ROOT,'tools/reference/complete-0.8.1-rc.7-manifest.json'));
      need(sha256(fs.readFileSync(ref))===RC7_MANIFEST_SHA,'PREVIOUS_REFERENCE_CHANGED','RC7-Referenz veraendert.');
      expectedSha=RC7_MANIFEST_SHA;
    }else if(m.version===VERSION){
      expectedSha=sha256(fs.readFileSync(plainPath(path.join(PACKAGE_ROOT,'MANIFEST.json'))));
    }else need(false,'PREVIOUS_COMPLETE_VERSION','Diese Gesamtpaketversion ist nicht als Updatequelle bekannt.');
    need(manifestSha===expectedSha,'PREVIOUS_MANIFEST_CHANGED','Manifest der bisherigen Version weicht von der veroeffentlichten Referenz ab.');
    const seen=verifyRecords(root,m.payload,{skipConfig:true});
    const legacyResiduals=verifyCodeTree(root,seen,{knownResiduals:knownBeta4Residuals()});
    resolveConfig(root);
    return {version:m.version,files:m.payload.length,manifestSha256:manifestSha,
      state:legacyResiduals.length?'COMPLETE_WITH_VERIFIED_BETA4_RESIDUALS':'COMPLETE_RELEASE_VERIFIED',
      legacyResiduals,authorization:'SOFTWARE_UPDATE_ONLY'};
  }
  need(m.schema==='MCR_BETA_PACKAGE_V1'&&m.package==='MCR_Ticket_Assistant'&&m.version==='0.8.0-beta.4'&&m.engineVersion==='0.7.4','BASELINE_VERSION','Erwartet wird Beta 4 oder ein bekanntes Gesamtpaket. Keine fremden Ordner ersetzen.');
  verifyRecords(root,m.payload,{skipConfig:true});
  need(m.payload.find(x=>x.path==='src/local-bot-full-run.mjs')?.sha256==='6777ca3b806f0a5085f31e5e371eaa5c6d2caa45e11cb20e475d02ae8b353d72','BASELINE_RUNNER','Unerwarteter Beta-4-Runner.');
  resolveConfig(root);return {version:m.version,files:m.payload.length};
}

export function treeDigest(root){plainPath(root);const rows=[];let count=0,total=0;function visit(f,rel){plainPath(f);const s=fs.statSync(f);need(++count<10000,'TREE_LIMIT','Zu viele Softwaredateien.');if(s.isDirectory()){rows.push(['D',rel]);for(const n of fs.readdirSync(f).sort())visit(path.join(f,n),rel?rel+'/'+n:n);}else{need(s.isFile()&&s.size<32*1024*1024,'TREE_FILE','Keine begrenzte Softwaredatei.');total+=s.size;need(total<128*1024*1024,'TREE_LIMIT','Softwarearchiv zu gross.');rows.push(['F',rel,s.size,sha256(fs.readFileSync(f))]);}}visit(root,'');return sha256(JSON.stringify(rows));}
