[CmdletBinding()]
param(
    [string]$Level05Root = "C:\Users\Amaru-Zegarra\projects\Aktive_Projekte\New_Language_Benchmark\Level_05"
)

$ErrorActionPreference = 'Stop'
$Harness = Join-Path $Level05Root 'tools\harness\Invoke-Level05Candidate.ps1'
if (-not (Test-Path $Harness)) { throw "Harness fehlt: $Harness" }

$Backup = "$Harness.before_launcher_file_fix"
if (-not (Test-Path $Backup)) { Copy-Item $Harness $Backup -Force }

$HarnessBody = @'
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string]$Language,

    [ValidateSet("parity","production")]
    [string]$Mode = "parity",

    [int]$Runs = 1,

    [int]$WarmupRuns = 0,

    [int]$Workers = 4
)

$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent (
    Split-Path -Parent $PSScriptRoot
)

. (Join-Path $PSScriptRoot "ProcessTree.ps1")

$Spec = Get-Content (
    Join-Path $Root "tools\benchmark_spec.json"
) -Raw | ConvertFrom-Json

if ($Spec.languages -notcontains $Language) {
    throw "Unbekannte Level-05-Sprache: $Language"
}

if ($Runs -lt 1) {
    throw "Runs muss mindestens 1 sein."
}

if ($WarmupRuns -lt 0) {
    throw "WarmupRuns darf nicht negativ sein."
}

$CaseId = [string]$Spec.case.id
$RunScript = Join-Path $Root "languages\$Language\$Mode\run.ps1"

if (-not (Test-Path $RunScript)) {
    throw "Candidate run.ps1 fehlt: $RunScript"
}

$CaseRoot = Join-Path $Root "data\cases\$CaseId"
$RawRoot = Join-Path $CaseRoot "input\raw"
$TemplateRoot = Join-Path $CaseRoot "input\template"

$Template = Get-ChildItem $TemplateRoot -File | Select-Object -First 1
if (-not $Template) {
    throw "Frozen Template wurde nicht gefunden."
}

$ResultsRoot = Join-Path $Root "results\$Mode\$Language"
New-Item -ItemType Directory -Force -Path $ResultsRoot | Out-Null

$Python = & (Join-Path $PSScriptRoot "Resolve-ValidatorPython.ps1")
$Validator = Join-Path $Root "tools\validator\validate_candidate.py"
$Protocol = Join-Path $Root "results\Benchmark_Protocol_Level05.csv"

function ConvertTo-Level05PsLiteral {
    param([Parameter(Mandatory=$true)][AllowEmptyString()][string]$Value)
    return "'" + $Value.Replace("'", "''") + "'"
}

function Invoke-Level05OneRun {
    param(
        [int]$Index,
        [bool]$Warmup
    )

    $Stamp = Get-Date -Format "yyyyMMdd_HHmmss_fff"
    if ($Warmup) {
        $RunName = "warmup_${Stamp}_{0:D2}" -f $Index
    }
    else {
        $RunName = "run_${Stamp}_{0:D2}" -f $Index
    }

    $RunRoot = Join-Path $ResultsRoot $RunName
    $OutputRoot = Join-Path $RunRoot "output"
    New-Item -ItemType Directory -Force -Path $OutputRoot | Out-Null

    $Stdout = Join-Path $RunRoot "stdout.log"
    $Stderr = Join-Path $RunRoot "stderr.log"
    $MetricsPath = Join-Path $RunRoot "run_metrics.json"
    $ValidationPath = Join-Path $RunRoot "validation.json"
    $CandidateResult = Join-Path $OutputRoot "candidate_result.json"
    $LauncherPath = Join-Path $RunRoot "candidate_launcher.ps1"

    # Windows PowerShell 5.1 + Start-Process loses/reshapes nested quoted
    # argument strings in some cases. Put all benchmark paths into a tiny
    # launcher file instead. The launcher receives no benchmark path args.
    $RunLiteral = ConvertTo-Level05PsLiteral $RunScript
    $CaseLiteral = ConvertTo-Level05PsLiteral $CaseId
    $InputLiteral = ConvertTo-Level05PsLiteral $RawRoot
    $TemplateLiteral = ConvertTo-Level05PsLiteral $Template.FullName
    $OutputLiteral = ConvertTo-Level05PsLiteral $OutputRoot

    $LauncherText = @"
`$ErrorActionPreference = 'Stop'
& $RunLiteral ``
    -Case $CaseLiteral ``
    -Input $InputLiteral ``
    -Template $TemplateLiteral ``
    -Output $OutputLiteral ``
    -Workers $Workers

# PowerShell script invocation errors do not reliably populate LASTEXITCODE.
# Never report a wrapper/binding failure as ExitCode 0.
if (-not `$?) { exit 1 }
if (`$null -ne `$LASTEXITCODE) { exit [int]`$LASTEXITCODE }
exit 0
"@

    [System.IO.File]::WriteAllText(
        $LauncherPath,
        $LauncherText,
        [System.Text.UTF8Encoding]::new($false)
    )

    Write-Host ""
    Write-Host "------------------------------------------------------------"
    Write-Host "$Language / $Mode / $RunName" -ForegroundColor Cyan
    Write-Host "------------------------------------------------------------"

    $Timer = [System.Diagnostics.Stopwatch]::StartNew()

    $LaunchArgs = "-NoProfile -ExecutionPolicy Bypass -File `"$LauncherPath`""
    $Process = Start-Process `
        -FilePath "powershell.exe" `
        -ArgumentList $LaunchArgs `
        -RedirectStandardOutput $Stdout `
        -RedirectStandardError $Stderr `
        -PassThru

    [int64]$PeakCandidateRss = 0

    while (-not $Process.HasExited) {
        $CurrentRss = Get-Level05ProcessTreeRssBytes `
            -RootPid $Process.Id `
            -ExcludeRoot

        if ($CurrentRss -gt $PeakCandidateRss) {
            $PeakCandidateRss = $CurrentRss
        }

        Start-Sleep -Milliseconds 100
        $Process.Refresh()
    }

    $Process.WaitForExit()
    $Process.Refresh()
    $Timer.Stop()

    $ExitCode = [int]$Process.ExitCode
    $ValidationPass = $false
    $SemanticSha = $null
    $ValidationExit = $null

    if ($ExitCode -eq 0 -and (Test-Path $CandidateResult)) {
        $OldPreference = $ErrorActionPreference
        $ErrorActionPreference = "Continue"

        try {
            & $Python `
                $Validator `
                --root $Root `
                --candidate-result $CandidateResult `
                --output $ValidationPath

            $ValidationExit = $LASTEXITCODE
        }
        finally {
            $ErrorActionPreference = $OldPreference
        }

        if (Test-Path $ValidationPath) {
            $Validation = Get-Content $ValidationPath -Raw | ConvertFrom-Json
            $ValidationPass = [bool]$Validation.pass

            if ($Validation.overall_semantic_sha256) {
                $SemanticSha = [string]$Validation.overall_semantic_sha256
            }
        }
    }

    $Status = if ($ExitCode -eq 0 -and $ValidationPass) { "PASS" } else { "FAIL" }
    $WallClock = [math]::Round($Timer.Elapsed.TotalSeconds, 6)
    $PeakMiB = [math]::Round($PeakCandidateRss / 1MB, 3)

    $Metrics = [ordered]@{
        schema = "mcr.level05.run-metrics.v1"
        timestamp = (Get-Date).ToString("o")
        case = $CaseId
        language = $Language
        mode = $Mode
        run = $RunName
        warmup = $Warmup
        workers = $Workers
        exit_code = $ExitCode
        wall_clock_seconds = $WallClock
        peak_candidate_process_tree_rss_bytes = $PeakCandidateRss
        peak_candidate_process_tree_rss_mib = $PeakMiB
        candidate_result_found = (Test-Path $CandidateResult)
        validation_exit_code = $ValidationExit
        validation_pass = $ValidationPass
        overall_semantic_sha256 = $SemanticSha
        status = $Status
    }

    $Metrics | ConvertTo-Json -Depth 20 | Set-Content $MetricsPath -Encoding UTF8

    Write-Host ""
    Write-Host "Exit Code:   $ExitCode"
    Write-Host "Wall Clock:  $WallClock s"
    Write-Host "Peak RSS:    $PeakMiB MiB"
    Write-Host "Validation:  $ValidationPass"
    Write-Host "Status:      $Status"

    if (-not $Warmup) {
        [PSCustomObject]@{
            timestamp = (Get-Date).ToString("o")
            case = $CaseId
            mode = $Mode
            language = $Language
            run = $RunName
            status = $Status
            wall_clock_s = $WallClock
            peak_rss_mib = $PeakMiB
            input_sha256 = [string]$Spec.case.input_sha256
            semantic_sha256 = $SemanticSha
            parity_pass = $ValidationPass
            notes = "ExitCode=$ExitCode; Result=$RunRoot"
        } | Export-Csv -Path $Protocol -NoTypeInformation -Append -Encoding UTF8
    }

    return [PSCustomObject]$Metrics
}

for ($i = 1; $i -le $WarmupRuns; $i++) {
    $null = Invoke-Level05OneRun -Index $i -Warmup $true
}

$Scored = @()
for ($i = 1; $i -le $Runs; $i++) {
    $Scored += Invoke-Level05OneRun -Index $i -Warmup $false
}

$Passed = @(
    $Scored |
    Where-Object { $_.status -eq "PASS" }
).Count

Write-Host ""
Write-Host "============================================================"
Write-Host " LEVEL 05 RUN SUMMARY"
Write-Host "============================================================"
Write-Host "Language: $Language"
Write-Host "Mode:     $Mode"
Write-Host "Runs:     $Runs"
Write-Host "PASS:     $Passed"
Write-Host "FAIL:     $($Runs - $Passed)"
Write-Host "============================================================"
Write-Host ""

if ($Passed -ne $Runs) { exit 1 }
exit 0
'@

[System.IO.File]::WriteAllText(
    $Harness,
    $HarnessBody,
    [System.Text.UTF8Encoding]::new($false)
)

Write-Host '      Common Harness launcher-file forwarding: APPLIED' -ForegroundColor Green
Write-Host "      Backup: $Backup"
