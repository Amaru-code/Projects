[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][Alias('Case')][ValidateNotNullOrEmpty()][string]$CaseId,
    [Parameter(Mandatory=$true)][Alias('Input')][ValidateNotNullOrEmpty()][string]$InputPath,
    [Parameter(Mandatory=$true)][Alias('Template')][ValidateNotNullOrEmpty()][string]$TemplatePath,
    [Parameter(Mandatory=$true)][Alias('Output')][ValidateNotNullOrEmpty()][string]$OutputPath,
    [int]$Workers = 4
)

$ErrorActionPreference='Stop'
$ModeRoot=$PSScriptRoot
$BuildRoot=Join-Path $ModeRoot 'build'
$Publish=Join-Path $BuildRoot 'publish'
$Main=Join-Path $Publish 'main.jl'
$JuliaPointer=Join-Path $BuildRoot 'julia_path.txt'

if(-not(Test-Path $Main -PathType Leaf)){throw "Julia Candidate wurde noch nicht gebaut: $Main"}
if(-not(Test-Path $JuliaPointer -PathType Leaf)){throw 'julia_path.txt fehlt. build.ps1 zuerst ausfuehren.'}
$Julia=(Get-Content $JuliaPointer -Raw).Trim()
if(-not(Test-Path $Julia -PathType Leaf)){throw "Julia Runtime fehlt: $Julia"}

Write-Host 'Julia Candidate Wrapper'
Write-Host "Case:     [$CaseId]"
Write-Host "Input:    [$InputPath]"
Write-Host "Template: [$TemplatePath]"
Write-Host "Output:   [$OutputPath]"
Write-Host "Workers:  [$Workers]"
Write-Host "Runtime:  [$Julia]"

if(Test-Path $OutputPath){
    Get-ChildItem $OutputPath -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force
}else{
    New-Item -ItemType Directory -Force -Path $OutputPath | Out-Null
}

& $Julia --startup-file=no --history-file=no $Main --case $CaseId --input $InputPath --template $TemplatePath --output $OutputPath --workers $Workers
$Code=$LASTEXITCODE
if($null -eq $Code){throw 'Julia Candidate returned no interpreter exit code.'}
exit [int]$Code
