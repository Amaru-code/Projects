from __future__ import annotations
import argparse, csv, json
from decimal import Decimal, InvalidOperation
from pathlib import Path


def read_json(p: Path):
    return json.loads(p.read_text(encoding="utf-8-sig"))


def read_csv(p: Path):
    with p.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.reader(f, delimiter=";"))


def number_equal(a: str, b: str) -> bool:
    try:
        return Decimal(a) == Decimal(b)
    except (InvalidOperation, ValueError):
        return False


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--level05-root',type=Path,required=True)
    ap.add_argument('--result-root',type=Path,required=True)
    ap.add_argument('--max',type=int,default=30)
    a=ap.parse_args()
    root=a.level05_root.resolve(); rr=a.result_root.resolve()
    golden=read_json(root/'data/reference/MCR_LNW_001/GOLDEN_REFERENCE.json')
    gname=Path(golden['artifacts']['lnw_csv']['path']).name
    gp=root/'data/reference/MCR_LNW_001/outputs'/gname
    cr=read_json(rr/'output/candidate_result.json')
    cp=Path(cr['artifacts']['lnw_csv'])
    if not cp.is_absolute(): cp=(rr/'output'/cp).resolve()
    erows=read_csv(gp); arows=read_csv(cp)
    maxr=max(len(erows),len(arows)); diffs=[]; numeric_only=0
    for r in range(maxr):
        e=erows[r] if r<len(erows) else []
        x=arows[r] if r<len(arows) else []
        maxc=max(len(e),len(x))
        for c in range(maxc):
            ev=e[c] if c<len(e) else None; av=x[c] if c<len(x) else None
            if ev!=av:
                num=(ev is not None and av is not None and number_equal(ev,av))
                if num: numeric_only += 1
                diffs.append({'row':r+1,'col':c+1,'expected':ev,'actual':av,'numeric_value_equal':num})
    report={'golden':str(gp),'candidate':str(cp),'expected_rows':len(erows),'actual_rows':len(arows),'mismatch_count':len(diffs),'numeric_format_only_count':numeric_only,'examples':diffs[:a.max]}
    out=rr/'csv_diagnostic.json'; out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print('CSV DIAGNOSTIC')
    print('Expected rows:',len(erows),'Actual rows:',len(arows))
    print('Cell mismatches:',len(diffs),'Numeric-format-only:',numeric_only)
    for d in diffs[:a.max]: print(f"R{d['row']}C{d['col']}: expected={d['expected']!r} actual={d['actual']!r} numeric_equal={d['numeric_value_equal']}")
    print('Report:',out)

if __name__=='__main__': main()
