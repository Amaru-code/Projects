RC64: sicherer erneuter INTL01-Signaturvorschlag nach ICEfaces-Reset; stabile Prüfung vor Sendeklick. Kompaktes RC63→RC64 Update. Keine unkontrollierte Wiederholung von Sendungen.
