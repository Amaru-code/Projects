# MCR Mail-Assistent 0.3.5 — Beschreibungsfeld verbinden und einsetzen

## Der bestätigte Teil bleibt unverändert

Dieses Update betrifft ausschließlich die Zielbindung und Übernahme der bereits
berechneten Beschreibung. Member-/MercerID-Module, MSG-Leser, Namenserkennung,
Excel-Import und Regeln für USC/DC/PP+/DB+ wurden nicht geändert.
Das mit 0.3.2 oder neuer erzeugte JSON bleibt verwendbar. **Kein erneuter
Excel-Export, kein npm install, keine neue Node-Installation.**

## Aktualisieren

ZIP vollständig entpacken. Den enthaltenen Ordner **MCR_Datenbruecke** mit dem
vorhandenen gleichnamigen Ordner zusammenführen und gelieferte Dateien ersetzen.
Den bisherigen Ordner nicht löschen: Eigene Excel-Dateien, Mails, `private_data`
und Node-Runtime behalten. Keine Unternehmensrichtlinie umgehen.

**MAIL_ASSISTENT_OEFFNEN.cmd** öffnen, den gesamten JavaScript-Text in Notepad
kopieren und in der Edge-DevTools-Konsole des geöffneten COMARCH-Tickets
(Kontext möglichst `top`) ausführen. Das Panel zeigt **0.3.5**.
Der alte Helfer wird geschlossen; dessen geladene Dateien werden nicht automatisch
übernommen. Vorhandenes JSON und die Mail desselben Tickets erneut auswählen.

## Den bereits ausgewählten Member nicht erneut suchen

Bestandsquelle bestätigen, Original-Mail laden, richtigen Namenshinweis wählen
und Namen/MercerID-Hinweis prüfen. Identitätskästchen bestätigen. Den bestehenden
COMARCH-Member nicht löschen; **Übernommene Person prüfen → Schritt 4** verwenden.
Schritt 4 muss die korrekte berechnete Beschreibung anzeigen. Die Formelbestätigung
ist nur nötig, wenn für die konkrete Quellzeile Formeln ausgewiesen werden.

## Das echte Beschreibungsfeld verbinden

Wenn die bisherige automatische Feldsuche gescheitert ist, diesen Weg direkt
verwenden — nicht erneut die Mail oder das Mapping exportieren:

1. In **Schritt 4** auf **Beschreibungsfeld verbinden** klicken.
2. Innerhalb von 30 Sekunden **ALT gedrückt halten und direkt in das große echte
   COMARCH-Textfeld unter „Zusätzliche Beschreibung“ klicken**.
   Nicht auf dessen Beschriftung, nicht in „Kommentar“ und nicht in den
   Nachrichteneditor klicken.
3. Das Textfeld wird kurz umrandet. Im Panel steht **Beschreibungsfeld verbunden**.
   Bis hierhin wurde noch nichts eingetragen.
4. **Beschreibung in COMARCH einsetzen** anklicken. Erst dieser Klick trägt den
   bereits berechneten Text ein. Der Helfer liest ihn sofort und über etwa eine
   Sekunde erneut aus dem tatsächlichen Feld zurück.
5. Den sichtbaren Text im echten COMARCH-Formular prüfen. Der Helfer betätigt
   weder **Senden** noch **Ticket speichern**. Den übrigen Ticketablauf wie bisher
   selbst abschließen.

**Escape** beendet eine laufende Markierung. Die Verbindung ist nur im Speicher
der aktuellen Seite gültig. Bei einem neuen Fall oder ersetzten Formularfeldern
gegebenenfalls erneut verbinden. Sie wird nicht anhand einer alten Feld-ID
blind wiederhergestellt.

Einzige Entwickleralternative: das echte Textfeld über „Untersuchen“ auswählen
und in der Konsole `MCR_MAIL.bindDescription($0)` ausführen. Dieselben Prüfungen
gelten; auch das verbindet nur und schreibt noch nichts.

## Automatische Erkennung und Fehlerverhalten

Der neue Feldleser prüft explizite Beschriftungen, ARIA-Zuordnungen sowie enge
Label-/Wert-Nachbarschaften mit verschachtelten Wrappern oder Tabellenzellen.
Er verwendet nicht einfach eine historische `j_id…` und auch nicht das erste
Textfeld der Seite. Nur Textareas im selben Formular und Dokument wie das
Member-Feld sind zulässig; Nachricht-/Mail-Frames sind ausgeschlossen.

**Ein Zielfeldfehler löscht das gültige Ergebnis nicht mehr.** Die Beschreibung
bleibt lesbar und kopierbar. Damit ist „Beschreibung kopieren“ weiterhin ein
funktionierender Rückfallweg, auch wenn COMARCH eine unbekannte Maske verwendet.
Wird die Zwischenablage vom Browser verweigert, den sichtbaren Vorschautext
markieren und manuell kopieren.

Vorhandener abweichender Text, Schreibschutz, ein zu kleines Längenlimit oder eine
Formularänderung führen zum Stopp. Der Helfer überschreibt nichts ungefragt,
kürzt nichts und wiederholt einen fehlgeschlagenen Schreibversuch nicht automatisch.
Ein bereits identischer Feldwert wird nicht erneut geschrieben. Ändert COMARCH
den Wert nach dem Einsetzen wieder, wird die lokale Erfolgsanzeige zurückgenommen;
die Vorschau bleibt erhalten. Änderungen von Member, Fall, Quelle oder Identität
machen die Vorschau dagegen weiterhin ungültig.

Das Setzen des Feldwerts und die Ereignisse `input`/`change` können reguläre
COMARCH-Änderungshandler und deren Serveranfragen auslösen. Der Helfer ruft
keinen Submit-Endpunkt direkt auf und betätigt keine Speicher-/Sendeschaltfläche.
**Die lokale Feldprüfung ist kein Nachweis einer dauerhaften Serverspeicherung.**

## Unveränderte Grenzen und Datenschutz

Mehrere Member-Treffer wählt der Anwender. Automatische Member-Auswahl ist nur für
qualifizierte Strukturen vorgesehen und für die tatsächliche COMARCH-Instanz
weiterhin nicht allgemein bestätigt. Die funktionierenden manuellen Wege bleiben.
Kategorien, Signatur, Anrede, Empfänger, Antwort, Versand und Ticket-Speichern
sind NICHT Bestandteil dieses Updates. Vollständige bisherige Bedienhinweise:
`docs/ANLEITUNG_BIS_0_3_4.md` (historische Versionsbezeichnungen beachten).

Mail und gesamtes minimiertes Mapping werden lokal in den COMARCH-Seitenkontext
geladen; dieser ist keine isolierte Datenschutz-Sandbox. Nur betrieblich freigegeben
nutzen. `private_data` ist nicht verschlüsselt, gehört nicht in Git und nicht in den
Chat. Kein externer KI-Dienst wird kontaktiert. Nach dem Ticket **Neuer Fall**,
nach Benutzung **Schließen**. Vollständige Seitenwechsel erfordern gegebenenfalls
erneutes Einsetzen des Codes und Laden der Dateien.

## Diagnose und Nachweise

Nur bei einem weiteren Fehler: über **Diagnose-ZIP** genau ein
`MCR_MAIL_..._UPLOAD.zip` erzeugen und weitergeben. Es enthält nun zusätzlich die
Feldbindungsroute und den lokalen Einfügestatus, aber keine DOM-Selektoren,
Personenkennungen, Namen, Mail-/Feldtexte oder Mappingwerte.

Aktueller Bericht: **docs/DESCRIPTION_TESTBERICHT.md**.
**SELBSTTEST.cmd** prüft die Paketdateien und alle Node-Tests einschließlich der
neuen Beschreibungsprüfungen. Für die Bedienung ist keine Python-Installation nötig.
Browserprüfungen in `tests` sind Entwicklernachweise mit synthetischen Daten.
Windows, COMARCH und der echte Bestandsdatensatz wurden hier nicht ausgeführt.
