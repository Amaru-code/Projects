# Inbox catch-up after absence (Urlaubs-Rückblick)

## Goal
When the user comes back from vacation or another absence, read the emails received during that time and give a prioritized overview in German: what needs an answer now, what can wait, what is just for information, and what can be ignored.

## Hard rules
- READ-ONLY. Never send, reply, forward, delete, move, flag, categorize or mark any email as read. Drafts only if the user asks for them afterwards, and only shown in the chat.
- Output language is ALWAYS German, even if the user writes in English or the emails are in English.
- Use only what is in the emails. Do not invent deadlines, intentions or facts. If something is unclear, write "unklar".
- Before classifying anything, read the file absender.md from this skill (sender and subject rules). Its rules override your own judgment.

## Step 1 – Scope
- If the user gives a period (e.g. "Urlaub 22.09.–06.10."), use exactly that period.
- Otherwise: all UNREAD emails in the Inbox from the last 14 days. State this assumption in the first line of the answer.
- Inbox only, plus subfolders the user names explicitly. Skip Junk, Deleted Items and Archive.

## Step 1b – Mehrfachabruf über das vorhandene `msgraph_email`-Tool (READ-ONLY)

Dieses Kapitel regelt **nur die Beschaffung der E-Mails**. Es ändert keine Priorität, Absenderregel oder Ausgabevorgabe aus Step 2–4. Das Tool ist pro `list`-Aufruf auf `count: 50` begrenzt. Die 50 sind KEINE Gesamtgrenze des Skills.

1. Für den durch Step 1 festgelegten Scope `msgraph_email` mit `action: list`, `folder: inbox`, `count: 50`, korrekt gesetztem `unread_only` und dem gewünschten `date_range` abfragen. Der ursprüngliche Standard bleibt `unread_only: true`; nur bei ausdrücklichem Wunsch nach gelesenen und ungelesenen E-Mails `unread_only: false` verwenden. Keine Parameter erfinden.
2. **Weniger als 50 Treffer** für ein nachweislich wirksam gefiltertes Intervall: vorläufig vollständiges Blatt. **Genau 50 Treffer:** nicht als vollständig behaupten; in zwei aufeinanderfolgende, disjunkte Kalendertagsintervalle aufteilen und beide abfragen. Die Aufteilung wiederholen, bis alle Blätter <50 haben.
3. Ein Einzeltag mit genau 50 Treffern bleibt `UNRESOLVED`, denn `date_range` hat nach der LenWork-Diagnose nur Tagesgranularität. Ohne belegbar vollständige andere Partition darf keine vollständige Auswertung behauptet werden.
4. Ausschließlich Blattdaten zusammenführen, anhand stabiler Message-IDs deduplizieren und tatsächliche Anzahl der Tool-Abrufe sowie nicht vollständig auflösbare Tage dokumentieren. Eine fehlende/instabile ID oder Tool-Fehler bedeutet `FETCH_STATUS=INCOMPLETE`.
5. Gilt `FETCH_STATUS=COMPLETE_UNDER_TOOL_CONTRACT`, fahre mit dem **unveränderten Step 2** fort. Dies ist keine atomare Snapshot-Garantie für das Postfach. Bei `INCOMPLETE` transparent nur als Teilauswertung berichten und ggf. Step 1c anbieten.

## Step 1c – Portabler Outlook-COM-Abruf aus der virtuellen Skill-Datei (READ-ONLY, keine lokale Installation)

**Zweck: ausschließlich Beschaffung, keine neue Priorisierung.** Die Inhalte von Step 2, Step 3, Step 4 und `absender.md` sind autoritativ und unverändert. Für >50 E-Mails am selben Tag oder „alle ungelesenen E-Mails“ diesen Weg bevorzugen, sofern in der LenWork-Umgebung zulässig und vollständig funktionsfähig. Andernfalls nur den belegbaren Step-1b-Mehrfachabruf verwenden und dessen Grenzen transparent anzeigen.

### Voraussetzungen pro Benutzer – ohne manuelle Einrichtung

- Ein Windows-Rechner mit bereits **laufendem klassischen Outlook** (neues Outlook/Web unterstützt COM nicht), eingeloggter Benutzer und lesbarer Inbox. Benutzer darf Zugriff auf seine eigenen Outlook-Daten haben.
- LenWork muss eine freigegebene Windows-PowerShell-5.1-Shell **im selben Benutzer-/Windows-Sitzungskontext** wie Outlook aufrufen können; `Marshal.GetActiveObject`, `GetNamespace('MAPI')` und `GetDefaultFolder(6)` müssen funktionieren. Der hier verwendete Code verlangt keine Administratorrechte, kein Token und keine Änderung der ExecutionPolicy.
- Die virtuelle gebündelte Datei `Export-InboxReadOnly.ps1` muss vom ausführenden LenWork-**Bash**-Tool als lesbare Datei erreichbar sein; Windows PowerShell muss diese Datei **nicht** als Host-Datei erreichen. `read_file`-Zugriff im Modell allein beweist die Bash-Sichtbarkeit noch nicht. Den tatsächlichen virtuellen Pfad aus LenWorks Skill-Dateizugriff ermitteln; nicht blind einen Host-Pfad raten.
- Die Ausführung muss durch die Unternehmens-/LenWork-Richtlinien erlaubt sein. Bei `AllSigned` oder `Restricted` bzw. einem Unternehmensblocker KEINE Umgehung versuchen, sondern die IT-/Connector-Freigabe nutzen. Die lokale Extraktion/Übermittlung der Skriptbytes ist nur zulässig, wenn die Ausführung von gebündeltem Skill-Code autorisiert ist.

### Mechanismus: gebündelten Code durch STDIN zur vorhandenen PowerShell übertragen

Ein `skills/.../Export-InboxReadOnly.ps1` ist ein **virtueller** Skill-Pfad, also NICHT mit `powershell.exe -File` ausführbar. Stattdessen liest das autorisierte Bash-Tool die virtuelle Datei und übergibt ihre Bytes als Base64 über **STDIN** an Windows PowerShell 5.1. Im Windows-Prozess: SHA256 auf den dekodierten Originalbytes prüfen; erst danach den PS-Inhalt als ScriptBlock im bereits bestätigten Benutzerkontext ausführen. Es wird **keine dauerhaft installierte `.ps1`** und kein lokal manuell erstellter Skriptpfad benötigt. Der Code erzeugt ausschließlich die für die Analyse erforderlichen lokalen, vertraulichen Exportdaten (`manifest.json`, JSONL-/Markdown-Batches).

1. Bevor Outlook angesprochen wird: prüfen, ob Bash die virtuelle `.ps1` tatsächlich lesen kann und ob deren **exakter Byte-SHA256** `29b4d7b55382fec0591919000e018fe56d012c648af607eb99054b3ea3f76411` ist. SHA-Abweichung oder fehlender Pfad: `BLOCKED_VIRTUAL_SKILL_ACCESS` bzw. `BLOCKED_BUNDLE_INTEGRITY`; **kein** Ersatzcode aus dem Modell erzeugen.
2. Im selben Bash→PowerShell-Kanal zunächst einen **nicht ausführenden Übertragungs-/SHA256-Probe-Test** durchführen (siehe beigepackte Setupanleitung). Pro Benutzer nur nach positivem Probe-Test Outlook exportieren. Ein Probe-PASS bestätigt den Byte-Transport, noch nicht COM- oder Export-Vollständigkeit.
3. Scope strikt Step 1: Nutzerzeitraum genau verwenden, ohne Zeitraum letzte 14 Tage ungelesen, ausdrückliches „alle ungelesenen E-Mails“ bedeutet `-StartDate '1900-01-01'`, `-EndDate` heutiger lokaler Tag und `-UnreadOnly`. Gelese E-Mails nur bei ausdrücklicher Erlaubnis einbeziehen; dann `-UnreadOnly` weglassen. `-BatchSize 25 -PreviewChars 350` (bei rein technischem Probe-Export `-PreviewChars 0`). Nur Inbox; keine zusätzlichen Ordner ohne ausdrücklichen Auftrag.
4. **Ausführung nach erfolgreichem Transport-Test:** Im autorisierten Bash-Tool wird `SKILL_SOURCE` auf den tatsächlich zugänglichen **virtuellen** Skill-Pfad gesetzt (Beispiel `skills/inbox-urlaub-rueckblicke-v2/Export-InboxReadOnly.ps1`). Für den belegten Scope diese Vorlage anpassen, ohne die Script-Bytes zu ändern:

```bash
set -o pipefail
SKILL_SOURCE='skills/inbox-urlaub-rueckblicke-v2/Export-InboxReadOnly.ps1'
if [ ! -r "$SKILL_SOURCE" ]; then echo 'BLOCKED_VIRTUAL_SKILL_ACCESS'; exit 21; fi
base64 < "$SKILL_SOURCE" | tr -d '\r\n' | powershell.exe -NoProfile -NonInteractive -Command '
$ErrorActionPreference = "Stop"
if ((Get-ExecutionPolicy) -in @("AllSigned", "Restricted")) { throw "BLOCKED_ENTERPRISE_POLICY" }
$encoded = [Console]::In.ReadToEnd().Trim()
$bytes = [Convert]::FromBase64String($encoded)
$actual = [BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash($bytes)).Replace("-", "").ToLowerInvariant()
$expected = "29b4d7b55382fec0591919000e018fe56d012c648af607eb99054b3ea3f76411"
if ($actual -ne $expected) { throw "BLOCKED_BUNDLE_INTEGRITY" }
$code = [Text.Encoding]::UTF8.GetString($bytes)
$action = [ScriptBlock]::Create($code)
$outdir = Join-Path $env:LOCALAPPDATA "LenWorkInboxExports"
& $action -StartDate "1900-01-01" -EndDate (Get-Date -Format "yyyy-MM-dd") -UnreadOnly -BatchSize 25 -PreviewChars 350 -OutputDir $outdir
'
```

In dieser Vorlage bezeichnet `1900-01-01` **nur** den expliziten Auftrag „alle ungelesenen“; bei Standard-14-Tage- oder Nutzerintervall die Werte anpassen. Das `powershell.exe`-Kommando muss eine **Windows PowerShell 5.1** im funktionierenden Windows-Benutzerkontext erreichen, nicht eine abgeschottete Linux-PowerShell. Keine Scriptbytes in Shell-Argumente oder Chats kopieren; nur als STDIN vom Bündel übertragen. Ohne bestätigte Toolfreigabe und bei Unternehmenssperren abbrechen; niemals `-ExecutionPolicy Bypass`, Policy-Änderungen, `Unblock-File`, fremde Konten oder externe Netzwerkdienste verwenden.

5. Das Skript meldet `STATUS`, `MODE`, `SCANNED`, `MATCHED`, `UNIQUE`, `BATCHES`, `ISSUES`, `OUTPUT`. **Prüfe Exitcode und Manifest** im exakten zurückgegebenen `OUTPUT`-Ordner über denselben lokal berechtigten Shell-Kanal; `STATUS=COMPLETE_LOCAL_STORE`, `MODE=INBOX_METADATA`, `issue_codes=[]`, `unread_only=true` (bei ungelesenem Scope), `folder=inbox`. Verifiziere ALLE Dateipfade relativ zum Exportordner, SHA256 pro Datei, JSONL-Zeilen, Message-ID-Eindeutigkeit und `unique_records`. Keine `.md`-Dateien als zusätzliche Nachrichten zählen. Wenn ein Check fehlt: `IMPORT_STATUS=INCOMPLETE`, keine falsche Vollständigkeitsbehauptung.
6. Datenübergabe an LenWorks ursprünglichen Step 2: die Batch-Inhalte (max. 25 pro Batch) über denselben berechtigten Datei-/PowerShell-Kanal einlesen, falls LenWork `read_file` Host-Dateien nicht direkt lesen darf. Ledger mit einer Zeile je `message_id` führen und am Ende `ANALYZED_COUNT = unique_records` nachweisen; bei fehlendem Host→LenWork-Rückkanal `IMPORT_STATUS=BLOCKED_OUTPUT_INGEST`. Den **originalen** Step 2–4 ausführen; niemals priorisieren, bevor die Daten vollständig vorliegen. Für nötige Volltexte nur ausgewählte Nachrichten nach den unveränderten Step-2-Regeln und mit freigegebenen Read-only-Tools abrufen; lokale COM-IDs nicht mit Graph-IDs verwechseln.
7. Datenschutz und Aussagegrenzen: ausschließlich eigenes oder ausdrücklich freigegebenes Postfach; lokale Exportdateien sind vertrauliche Firmendaten und nicht an externe Chats hochzuladen. READ-ONLY gilt für Outlook, nicht für die notwendige Erzeugung lokaler Analysedateien. `COMPLETE_LOCAL_STORE` bezeichnet nur den im klassischen Outlook synchronisierten Bestand, keine atomare Cloud-Gesamtgarantie. Nur nach vollständiger Ledger-/Hashprüfung darf eine technische End-to-End-Vollständigkeit behauptet werden.
8. **Fail-closed / Fallback:** Wenn Bash die virtuelle Datei nicht lesen kann, die STDIN-Pipeline blockiert ist, Outlook nicht läuft, die lokale Sicherheitspolitik es untersagt oder Export/Import scheitert, offen als `BLOCKED_...` berichten und Step 1b mit seiner nachgewiesenen 50-pro-Tag-Grenze benutzen. Kein automatisch installierter Hintergrunddienst, kein weiterer lokaler Setup-Pfad, keine Berechtigungsumgehung.

## Step 2 – Metadata first, full text only when needed
1. List for every email: sender, whether the user is in To or only in CC, subject, received date, importance flag, attachments yes/no, conversation/thread, short preview.
2. Apply absender.md: everything matching "Ignorieren" goes straight to ⚪ without opening it.
3. Group by conversation/thread. Judge each thread by its LATEST message. If the question in a thread was already answered or solved by someone else, put it under "Bereits erledigt" and name who solved it.
4. If possible, check Sent Items for the same period: if the user already replied to a thread, mark it as "bereits beantwortet".
5. Open the full text only for emails that cannot be clearly classified as 🔵 or ⚪ from the metadata.
6. Work in batches of about 20–30 emails. Do not stop early; process all emails in scope.

## Step 3 – Priorities
🔴 Sofort beantworten (today):
- a direct question or request to the user (user in To)
- a deadline that has passed or is within the next 2 working days (mark passed ones as "ÜBERFÄLLIG")
- anything from a VIP in absender.md that contains a question or a deadline
- reminders and escalations ("Erinnerung", "dringend", "nochmals", 2nd follow-up)
- meeting requests for the next days that still need a response

🟡 Diese Woche:
- a request to the user without a tight deadline
- a deadline within the next ~2 weeks
- coordination where the user's input is expected

🔵 Zur Kenntnis:
- user only in CC, status updates, decisions already made, finished threads, past meeting invitations

⚪ Ignorierbar:
- newsletters, HR/IT mass mailings, marketing, automatic notifications, out-of-office replies, expired invitations

When in doubt between two levels, choose the higher one.

## Step 4 – Output (German, short)
Start with one line: Zeitraum, Anzahl gelesener E-Mails, Verteilung (🔴 x / 🟡 x / 🔵 x / ⚪ x).

### 🔴 Sofort beantworten
Table: Nr. | Von | Betreff | Worum geht es (1 Satz) | Was wird von dir erwartet | Frist

### 🟡 Diese Woche
Same table.

### 🔵 Zur Kenntnis
One line per thread: Von – Betreff – Kernaussage in 1 Satz.

### ⚪ Ignorierbar
Counts by group only, no details (e.g. "HR-Rundmails: 4, Newsletter: 7, Systembenachrichtigungen: 12").

### 📅 Fristen und Termine
Chronological list of all deadlines and dates found: Datum – was – von wem.

### ✅ Bereits erledigt / beantwortet
One line each: Betreff – erledigt durch wen.

End with exactly one question: "Soll ich für die 🔴-Mails Antwortentwürfe vorbereiten?"
Keep every summary to one sentence. No long quotes from emails.
