# LenWork-Probe: rein technischer Byte-Transport aus dem virtuellen Skill (KEIN Outlook-Abruf)

Bitte führe in deiner freigegebenen Bash-/PowerShell-Ausführungsumgebung die folgende Prüfung durch. Benutze den tatsächlich zugänglichen virtuellen Pfad zur mitgelieferten `Export-InboxReadOnly.ps1`, den du zuvor durch die Skill-Dateiliste oder einen Lesetest ermittelt hast. `SKILL_SOURCE` in der Vorlage anpassen, falls der Pfad bei dir anders ist.

**Dies ist keine Aufforderung, externe Sicherheitsbeschränkungen zu umgehen.** Es darf weder Outlook gelesen noch eine E-Mail verändert werden; es wird nur der gebündelte Skriptinhalt gehasht.

```bash
set -o pipefail
SKILL_SOURCE='skills/inbox-urlaub-rueckblicke-v2/Export-InboxReadOnly.ps1'
if [ ! -r "$SKILL_SOURCE" ]; then echo 'SOURCE_STATUS=BLOCKED_VIRTUAL_SKILL_NOT_SHELL_READABLE'; exit 21; fi
base64 < "$SKILL_SOURCE" | tr -d '\r\n' | powershell.exe -NoProfile -NonInteractive -Command '
$ErrorActionPreference="Stop"
Write-Output ("PS_VERSION="+$PSVersionTable.PSVersion.ToString())
Write-Output ("POLICY="+(Get-ExecutionPolicy))
$bytes=[Convert]::FromBase64String([Console]::In.ReadToEnd().Trim())
$hash=[BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash($bytes)).Replace("-", "").ToLowerInvariant()
if ($hash -ne "29b4d7b55382fec0591919000e018fe56d012c648af607eb99054b3ea3f76411") { throw "HASH_MISMATCH" }
Write-Output "VIRTUAL_SKILL_STREAM=PASS"
Write-Output ("SCRIPT_BYTES="+$bytes.Length)
Write-Output "OUTLOOK_READ=NOT_STARTED"
'
```

Ergebnis ausschließlich als technische Zeilen melden:
`VIRTUAL_SOURCE_READ`, `PS_VERSION`, `POLICY`, `VIRTUAL_SKILL_STREAM`, `SCRIPT_BYTES`, `OUTLOOK_READ`, `NEXT_STEP_ALLOWED`.

- PASS nur wenn der reale virtuelle Skriptinhalt über Standard-Eingabe bis in Windows PowerShell gelangt und die SHA-Prüfung besteht.
- Wenn Bash die Datei nicht sieht, darfst du keinen erfolgreichen Transfer behaupten. Dokumentiere den Blocker; Step 1b bleibt verfügbar.
- Führe **noch keinen** echten Outlook-Export aus. Priorisierungsdateien niemals verändern.
