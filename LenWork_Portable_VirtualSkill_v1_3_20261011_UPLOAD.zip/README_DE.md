# Shareable Skill v1.3 – vollständig im virtuellen LenWork-Skill

## Was gehört in LenWork? (flache Struktur)

Nur diese drei Dateien im Skill selbst:

- `SKILL.md` – Original-Regeln, nur Step 1c (Outlook-Abruf) erweitert
- `absender.md` – SHA256-/byteidentisch mit der Version 1.2
- `Export-InboxReadOnly.ps1` – SHA256-/byteidentisch mit dem auf dem ursprünglichen Laptop bereits getesteten Exporter

**KEINE manuelle Datei-Installation** auf dem Laptop, keine `scripts/`-Unterordner, keine Test-Mail-Dateien, keine separate Python-Datei. Eine Kopie des Skills enthält diese Quellen für jedes Teammitglied.

## So löst der Skill das Problem mit dem virtuellen Pfad

Ein Windows-Prozess kann `skills/.../Export-InboxReadOnly.ps1` nicht über `-File` als lokale Datei öffnen. Sofern das autorisierte Bash-Ausführungstool die gebündelte Datei als Quelle lesen kann, wird der Inhalt per Base64 über eine Standard-Eingabe-Pipe zur laufenden Windows PowerShell 5.1 übertragen. Dort wird der originale SHA256 überprüft und erst danach das Skript für den eigenen Inbox-Abruf gestartet. Der Skriptcode benötigt keinen physisch installierten Pfad und ändert nicht die Outlook-Nachrichten.

Die Shell überträgt nur den Skill-**Programmcode**, keine E-Mails. Outlook-Daten verbleiben unter dem jeweiligen lokalen Benutzerprofil und werden bei der Analyse durch LenWorks autorisierten Kanal eingelesen. Es wird keine Datei auf einen externen Service hochgeladen.

## Abnahmereihenfolge

1. Drei Dateien in die **Testkopie** des LenWork-Skills übernehmen, alte 125-Synthetic-Testdateien entfernen.
2. `LENWORK_TRANSPORT_PROBE.md` als Chatprompt (nicht als Skill-Datei) verwenden. Der Test führt keinen Outlook-Abruf aus.
3. Nur falls `VIRTUAL_SKILL_STREAM=PASS`: einen kleinen READ-ONLY-Export über Step 1c aus LenWork ausführen (zuerst 1–7 Tage, PreviewChars 0) und dessen Manifest/Hashes prüfen.
4. Erst bei erfolgreichem Host-Datei-Rückkanal: 100+ künstliche ungelesene E-Mails mit dem Test-Mail-Generator erzeugen; anschließend im Chat den Original-Skill aufrufen und das Ledger für alle eindeutigen IDs prüfen.
5. Fertige Version innerhalb der Organisation teilen, nachdem IT/LenWork-Owner die PowerShell-Shell-Befugnis und Datenverarbeitung freigegeben haben.

## Grenzen

- Portabel **als Skill-Bundle**, aber nicht automatisch auf jedem Gerät ausführbar: klassisches Outlook, Windows PowerShell 5.1, laufende Sitzung und autorisierter Bash→PowerShell-Kanal sind erforderlich.
- `read_file` allein ist kein Beweis, dass das Bash-Tool auf virtuelle Skill-Dateien zugreifen darf. Genau das klärt der Probe-Test.
- Windows-PowerShell-Policy `AllSigned` oder `Restricted` bzw. vergleichbare Unternehmensblocker: nicht umgehen. In solchen Umgebungen ist eine durch die IT genehmigte Script-Host-/Graph-Connector-Integration nötig.
- Die Original-Priorisierung aus Step 2–4 wurde nicht geändert.
- Offline-Paketprüfung ist kein echter LenWork-Shell-Test; Live-Freigabe erst nach Probe und COM-Export.
