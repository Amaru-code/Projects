import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawn} from 'node:child_process';
import {NAMES,demand,sha,readBytes,readJson,inside,walk,readZip,verifyFiles} from './recovery-core.mjs';

export function scanDiagnostics(base,since=0) {
  const result=[];
  for(const p of walk(base,{maxDepth:8,maxFiles:25000})) {
    if(!/\.(json|zip)$/i.test(p)||fs.statSync(p).size>8*1024*1024) continue;
    if(fs.statSync(p).mtimeMs < since-2000) continue;
    const add=obj=>{
      if(obj?.schema==='MCR_LOCAL_RUNNER_DIAGNOSTIC_V1'&&Date.parse(obj.createdAt)>=since) result.push(obj);
      else if(obj?.diagnostic?.schema==='MCR_LOCAL_RUNNER_DIAGNOSTIC_V1'&&Date.parse(obj.diagnostic.createdAt)>=since) result.push(obj.diagnostic);
    };
    try {
      if(p.endsWith('.json')) add(readJson(p));
      else if(/diagnos|export|upload|run|result/i.test(path.basename(p)))
        for(const [name,b] of readZip(readBytes(p,8*1024*1024))) if(name.endsWith('.json')&&b.length<1024*1024) {try{add(JSON.parse(b.toString('utf8').replace(/^\uFEFF/,'')));}catch{}}
    } catch { /* Unrelated JSON/ZIP is not evidence. */ }
  }
  result.sort((a,b)=>Date.parse(b.createdAt)-Date.parse(a.createdAt)); return result;
}
export async function runControlled(base,mode,hashes) {
  const meta=inside(base,NAMES.metadata);fs.mkdirSync(meta,{recursive:true});
  const session=path.join(meta,'session.json');
  demand(!fs.existsSync(session),'SESSION_EXISTS','Ein alter Startnachweis ist noch vorhanden.');
  verifyFiles(base,hashes);
  const token=crypto.randomBytes(32).toString('hex');
  const begun=Date.now();
  fs.writeFileSync(session,JSON.stringify({schema:'MCR_CONTROLLED_RUN_V1',mode,parentPid:process.pid,tokenSha256:sha(token),createdAtMs:begun,hashes}),{flag:'wx'});
  const env={...process.env};
  // Isolate the fictional demo; preserve existing real runtime settings except the explicit session and ticket limit.
  if(mode==='DEMO')for(const key of Object.keys(env))if(/^MCR_/i.test(key))delete env[key];
  Object.assign(env,{MCR_RECOVERY_SESSION:token,MCR_MAX_TICKETS:mode==='PILOT'?'1':mode==='QUEUE'?'100':'3'});
  const args=[inside(base,NAMES.overlay),...(mode==='DEMO'?['--demo','--auto','--close-browser']:['--full-run'])];
  let interrupted=false;
  const child=spawn(process.execPath,args,{cwd:base,env,stdio:'inherit',windowsHide:false});
  // Never remove the parent's lock while its child might still be running.
  const stop=()=>{interrupted=true;try{child.kill('SIGTERM');}catch{}};
  process.on('SIGINT',stop);process.on('SIGTERM',stop);
  const exit=await new Promise(resolve=>{child.once('error',()=>resolve(-1));child.once('exit',(code)=>resolve(code??-1));});
  process.removeListener('SIGINT',stop);process.removeListener('SIGTERM',stop);
  if(fs.existsSync(session))fs.unlinkSync(session);
  const d=scanDiagnostics(base,begun)[0]||null;
  return {exit,diagnostic:d,interrupted};
}
