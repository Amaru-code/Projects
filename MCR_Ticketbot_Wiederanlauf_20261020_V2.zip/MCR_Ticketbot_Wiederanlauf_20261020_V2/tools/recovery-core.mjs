/* MCR local recovery 2026-10-20. Built-in Node modules only. */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import {spawnSync} from 'node:child_process';

export const PINS = Object.freeze({
  baseline: '6777ca3b806f0a5085f31e5e371eaa5c6d2caa45e11cb20e475d02ae8b353d72',
  candidate: 'e63c12081c0b6991af3ad2f9cf60a96c1203e592b6d83de63c59f0a7d52789ed',
  identity: 'fe9e1afbca8ec4b5e3c8d7eb5bc53c741bfedc16d45429cfc2bda9a4dc5cd97a',
  repairedIdentity: '9283decde920ace1c2487504c542a2a0b0079f789637666396eb15419860d2d8',
  archives: Object.freeze([
    'b5d47c4c864442761027c6de307293ca5a4a6402b7e7b76fe026b0582ecd28da',
    '9306a252d7fb6625dd54c9cd38605f56c481715ccb9815a688959341f98f0d27',
    'c44bc0cb3e278c4107d09edf210d8741698bc41bd6bf12822300dd9b6723a901',
    'aa1ce62e5753ec630082b430fdc606dc4c53d74a28978098947ac4ef379e16fe'
  ])
});
export const NAMES = Object.freeze({
  original: 'src/local-bot-full-run.mjs',
  overlay: 'src/local-bot-recovery-20261020.mjs',
  helper: 'lib/identity-evidence-recovery-20261020.cjs',
  gate: 'lib/mcr-recovery-gate-20261020.mjs',
  metadata: '.mcr-recovery-20261020',
  pointer: 'private_data/active-mapping.json'
});
export const PREFIX = "import '../lib/mcr-recovery-gate-20261020.mjs';\n";
export function demand(ok, code, message) {
  if (!ok) throw Object.assign(new Error(message || code), {code});
}
export const sha = b => crypto.createHash('sha256').update(b).digest('hex');
export function readBytes(file, max = 64 * 1024 * 1024) {
  const s = fs.lstatSync(file);
  demand(s.isFile() && !s.isSymbolicLink() && s.size <= max, 'FILE_UNSAFE', 'Datei ist kein regulaeres, ausreichend kleines Original.');
  return fs.readFileSync(file);
}
export const hashFile = file => sha(readBytes(file));
export const readJson = file => JSON.parse(readBytes(file, 16*1024*1024).toString('utf8').replace(/^\uFEFF/, ''));
export function safeRelative(name) {
  demand(typeof name === 'string' && name.length > 0 && name.length < 500 && !name.includes('\0'), 'PATH_UNSAFE');
  name = name.replaceAll('\\', '/');
  demand(!name.startsWith('/') && !name.includes(':') && !/[<>"|?*]/.test(name), 'PATH_UNSAFE');
  const chunks = name.split('/');
  demand(chunks.every((s, i) => (s && s !== '.' && s !== '..' && !/[. ]$/.test(s) && !/^(?:con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(s)) || (i === chunks.length-1 && s === '')), 'PATH_UNSAFE');
  return name;
}
export function inside(root, relative) {
  relative = safeRelative(relative);
  const target = path.resolve(root, relative);
  demand(target.startsWith(path.resolve(root) + path.sep), 'PATH_ESCAPE');
  let p = path.resolve(root);
  demand(!fs.lstatSync(p).isSymbolicLink(), 'ROOT_LINK');
  for (const bit of relative.split('/').filter(Boolean)) {
    p = path.join(p, bit);
    if (fs.existsSync(p)) demand(!fs.lstatSync(p).isSymbolicLink(), 'PATH_LINK');
  }
  return target;
}
export function atomicJson(file, data) {
  const temp = file + '.' + crypto.randomBytes(8).toString('hex') + '.tmp';
  const fd = fs.openSync(temp, 'wx');
  try { fs.writeFileSync(fd, JSON.stringify(data, null, 2) + '\n'); fs.fsyncSync(fd); }
  finally { fs.closeSync(fd); }
  try { fs.renameSync(temp, file); } catch (e) { try {fs.unlinkSync(temp);} catch {} throw e; }
}
const SKIP = /^(?:\.git|node_modules|\.venv|venv|__pycache__|target|dist|private_data|browser[_-]?profiles?|edge[_-]?profiles?|profiles?|user[ _-]?data|\.mcr-recovery-20261020|cache|code cache|gpuCache|default)$/i;
export function walk(root, {maxDepth=7, maxFiles=20000, skip=SKIP}={}) {
  const files = []; let count = 0;
  function visit(dir, depth) {
    if (!fs.existsSync(dir)) return;
    demand(!fs.lstatSync(dir).isSymbolicLink(), 'ROOT_LINK');
    for (const e of fs.readdirSync(dir, {withFileTypes: true})) {
      if (e.isSymbolicLink()) continue;
      demand(++count <= maxFiles, 'SCAN_LIMIT', 'Suchgrenze erreicht; eindeutigen lokalen Pfad in recovery-settings.json eintragen.');
      const p = path.join(dir, e.name);
      if (e.isDirectory() && depth < maxDepth && !skip.test(e.name)) visit(p, depth+1);
      else if (e.isFile()) files.push(p);
    }
  }
  visit(root, 0); return files;
}
const crcTable = Array.from({length:256}, (_,n) => {
  for (let k=0;k<8;k++) n = n & 1 ? 0xedb88320 ^ (n >>> 1) : n >>> 1;
  return n >>> 0;
});
export function crc32(b) { let n=0xffffffff; for(const c of b) n=crcTable[(n^c)&255]^(n>>>8); return (n^0xffffffff)>>>0; }
export function readZip(buf) {
  demand(Buffer.isBuffer(buf) && buf.length >= 22 && buf.length <= 16*1024*1024, 'ZIP_SIZE');
  let end=-1;
  for(let p=buf.length-22;p>=Math.max(0,buf.length-65557);p--)
    if(buf.readUInt32LE(p)===0x06054b50 && p+22+buf.readUInt16LE(p+20)===buf.length){end=p;break;}
  demand(end>=0,'ZIP_END');
  const count=buf.readUInt16LE(end+10), size=buf.readUInt32LE(end+12), offset=buf.readUInt32LE(end+16);
  demand(buf.readUInt16LE(end+4)===0 && buf.readUInt16LE(end+6)===0 && buf.readUInt16LE(end+8)===count && count<3000 && offset+size===end,'ZIP_LAYOUT');
  const result=new Map(), seen=new Set(); let p=offset,total=0;
  for(let i=0;i<count;i++) {
    demand(p+46<=end && buf.readUInt32LE(p)===0x02014b50,'ZIP_DIRECTORY');
    const flags=buf.readUInt16LE(p+8), method=buf.readUInt16LE(p+10), crc=buf.readUInt32LE(p+16);
    const comp=buf.readUInt32LE(p+20), unc=buf.readUInt32LE(p+24), nl=buf.readUInt16LE(p+28), el=buf.readUInt16LE(p+30), cl=buf.readUInt16LE(p+32);
    const attrs=buf.readUInt32LE(p+38), local=buf.readUInt32LE(p+42);
    demand(p+46+nl+el+cl<=end && !(flags&1) && [0,8].includes(method) && unc<=8*1024*1024 && ((attrs>>>16)&0xf000)!==0xa000,'ZIP_ENTRY');
    const rawName=buf.subarray(p+46,p+46+nl);
    demand((flags&0x800) || [...rawName].every(c=>c<128),'ZIP_ENCODING');
    const name=safeRelative(rawName.toString('utf8'));
    demand(!seen.has(name.toLowerCase()),'ZIP_DUPLICATE'); seen.add(name.toLowerCase());
    demand(local+30<=offset && buf.readUInt32LE(local)===0x04034b50,'ZIP_LOCAL');
    const lnl=buf.readUInt16LE(local+26), lel=buf.readUInt16LE(local+28), start=local+30+lnl+lel;
    demand(start+comp<=offset && buf.readUInt16LE(local+8)===method && buf.readUInt16LE(local+6)===flags && buf.subarray(local+30,local+30+lnl).equals(rawName),'ZIP_LOCAL_MISMATCH');
    const raw=buf.subarray(start,start+comp);
    const out=method===0 ? Buffer.from(raw) : zlib.inflateRawSync(raw,{maxOutputLength:8*1024*1024});
    total+=out.length;
    demand(out.length===unc && total<=64*1024*1024 && crc32(out)===crc,'ZIP_CRC_OR_SIZE');
    if(!name.endsWith('/')) result.set(name,out);
    p+=46+nl+el+cl;
  }
  demand(p===end,'ZIP_DIRECTORY_END');
  for(const name of result.keys()) {
    const bits=name.toLowerCase().split('/');
    for(let i=1;i<bits.length;i++) demand(!result.has(bits.slice(0,i).join('/')) && ![...result.keys()].some(k=>k.toLowerCase()===bits.slice(0,i).join('/')),'ZIP_FILE_DIRECTORY_CONFLICT');
  }
  return result;
}
export function staticDependencies(text) {
  const specs = new Set();
  const re=/(?:\bfrom\s*|\bimport\s*(?:\(\s*)?|\brequire\s*\(\s*)['"]([^'"\r\n]+)['"]/g;
  for(const m of String(text).matchAll(re)) if(m[1].startsWith('.')) specs.add(m[1]);
  return [...specs];
}
export function dependencyFiles(root, candidate, helper) {
  const files = new Map(), visiting=new Set();
  function visit(rel, bytes) {
    demand(!visiting.has(rel),'DEPENDENCY_CYCLE');
    if(files.has(rel)) return;
    visiting.add(rel); files.set(rel, bytes);
    if(/\.(mjs|cjs|js)$/.test(rel)) for(const spec of staticDependencies(bytes.toString('utf8'))) {
      const next=path.posix.normalize(path.posix.join(path.posix.dirname(rel),spec.replaceAll('\\','/')));
      safeRelative(next);
      demand(next.startsWith('lib/') || next.startsWith('src/'), 'DEPENDENCY_OUTSIDE_CODE');
      if(files.has(next)) continue;
      visit(next, next===NAMES.helper ? helper : readBytes(inside(root,next),8*1024*1024));
    }
    visiting.delete(rel);
  }
  visit(NAMES.original,candidate); return files;
}
export function checkSyntax(file) {
  const r=spawnSync(process.execPath,['--check',file],{encoding:'utf8',timeout:20000,windowsHide:true});
  demand(!r.error && r.status===0,'SYNTAX_FAIL','Node-Syntaxpruefung fehlgeschlagen: '+path.basename(file));
}
export function verifyPins(root, candidate, helper, pins=PINS) {
  demand(hashFile(inside(root,NAMES.original))===pins.baseline,'BASELINE_CHANGED','Der installierte Runner weicht vom dokumentierten Beta-4-Original ab. Nichts wird ueberschrieben.');
  demand(sha(candidate)===pins.candidate,'CANDIDATE_HASH','Identity-Runner stimmt nicht mit dem geprueften Original ueberein.');
  demand(sha(helper)===pins.identity,'HELPER_HASH','Identity-Modul stimmt nicht mit dem geprueften Original ueberein.');
}
export function retargetIdentity(candidate) {
  const old = "const Identity = require('../lib/identity-evidence.cjs');";
  const target = "const Identity = require('../lib/identity-evidence-recovery-20261020.cjs');";
  const text = candidate.toString('utf8');
  demand(text.split(old).length === 2, 'IDENTITY_IMPORT_ANCHOR', 'Der bekannte Identity-Import ist nicht genau einmal vorhanden.');
  return Buffer.from(text.replace(old,target),'utf8');
}
export function makeOverlay(candidate) { return Buffer.concat([Buffer.from(PREFIX),retargetIdentity(candidate)]); }
export function verifyFiles(root, expected) {
  for(const [rel,hash] of Object.entries(expected)) demand(hashFile(inside(root,rel))===hash,'CODE_CHANGED','Programmdateien wurden seit der Pruefung veraendert.');
}
export function installAdditions(root, files, snapshot, options={}) {
  const meta=inside(root,NAMES.metadata); fs.mkdirSync(meta,{recursive:true});
  const jp=path.join(meta,'transaction.json');
  if(fs.existsSync(jp)) {
    const prior=readJson(jp);
    demand(prior.state==='COMPLETE' || prior.state==='ROLLED_BACK','TRANSACTION_PENDING','Eine fruehere Installation ist nicht abgeschlossen.');
    if(prior.state==='COMPLETE') {
      demand(prior.files.length===files.size && prior.files.every(f=>files.has(f.relative)&&sha(files.get(f.relative))===f.sha256),'TRANSACTION_VERSION');
      verifyFiles(root, prior.snapshot);
      verifyFiles(root, Object.fromEntries(prior.files.map(f=>[f.relative,f.sha256])));
      return prior;
    }
  }
  const state={schema:'MCR_RECOVERY_TRANSACTION_V1',state:'PREPARING',createdAt:new Date().toISOString(),files:[],snapshot};
  for(const [rel,bytes] of files) {
    const p=inside(root,rel), existed=fs.existsSync(p);
    if(existed) demand(hashFile(p)===sha(bytes),'ADDITION_CONFLICT','Eine Zusatzdatei existiert mit anderem Inhalt.');
    state.files.push({relative:rel,sha256:sha(bytes),created:!existed});
  }
  atomicJson(jp,state);
  try {
    let writes=0;
    for(const f of state.files) if(f.created) {
      fs.writeFileSync(inside(root,f.relative),files.get(f.relative),{flag:'wx'});
      demand(hashFile(inside(root,f.relative))===f.sha256,'WRITE_VERIFY');
      writes++;
      if(options.failAfterWrites===writes) throw Object.assign(new Error('simulated failure'),{code:'TEST_FAIL'});
    }
    verifyFiles(root,snapshot); state.state='COMPLETE'; atomicJson(jp,state); return state;
  } catch(e) {
    let restored=true;
    for(const f of state.files.filter(f=>f.created).reverse()) {
      const p=inside(root,f.relative);
      if(fs.existsSync(p)) { if(hashFile(p)===f.sha256) fs.unlinkSync(p); else restored=false; }
    }
    state.state=restored?'ROLLED_BACK':'REVIEW_REQUIRED'; atomicJson(jp,state); throw e;
  }
}
export function rollback(root) {
  const p=inside(root,NAMES.metadata+'/transaction.json'), state=readJson(p);
  demand(['COMPLETE','ROLLED_BACK'].includes(state.state),'TRANSACTION_PENDING');
  if(state.state==='ROLLED_BACK') return;
  verifyFiles(root,state.snapshot);
  for(const f of state.files.filter(x=>x.created)) {
    const p=inside(root,f.relative);
    if(fs.existsSync(p)) demand(hashFile(p)===f.sha256,'ROLLBACK_DRIFT');
  }
  for(const f of state.files.filter(x=>x.created).reverse()) {
    const p=inside(root,f.relative); if(fs.existsSync(p)) fs.unlinkSync(p);
  }
  state.state='ROLLED_BACK'; atomicJson(p,state);
}
export function isVerifiedRun(d, mode, count) {
  return Boolean(d && d.schema==='MCR_LOCAL_RUNNER_DIAGNOSTIC_V1' && d.mode===mode &&
    d.loop?.processed===count && d.send?.verified===true && d.save?.verified===true && !d.lastError);
}
export function uncertainSend(d) { return Boolean(d?.send?.clicked===true && (d?.send?.verified!==true || d?.save?.verified!==true)); }
export function publicDiagnostic(d) {
  if(!d) return null;
  return {mode:['REAL','DEMO'].includes(d.mode)?d.mode:'UNKNOWN', processed:Number.isInteger(d.loop?.processed)?d.loop.processed:null,
    sendClicked:d.send?.clicked===true,sendVerified:d.send?.verified===true,saveVerified:d.save?.verified===true,
    errorCode:/^[A-Z][A-Z0-9_]{0,79}$/.test(d.lastError?.code||'')?d.lastError.code:null};
}
