/* User-controlled picker for a pre-existing exact RC1.1 ZIP or runner file.
 * Does not download, alter or run the chosen source. Writes only local kit settings. */
import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {readJson,atomicJson,hashFile,inside,PINS,demand} from './recovery-core.mjs';
import {verifyCandidateFile} from './source-locator.mjs';
const kit=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const settingsFile=path.join(kit,'recovery-settings.json');
function verifyKit(){
 const manifest=readJson(path.join(kit,'MANIFEST_SHA256.json'));
 demand(manifest.schema==='MCR_RECOVERY_KIT_MANIFEST_V1','KIT_MANIFEST');
 for(const [rel,hash]of Object.entries(manifest.files))demand(hashFile(inside(kit,rel))===hash,'KIT_CHANGED','Reparaturpaket wurde veraendert.');
}
function showPicker(){
 demand(process.platform==='win32','FILE_SELECTION_REQUIRED','Datei als Argument angeben.');
 const ps=path.join(process.env.SystemRoot||'C:\\Windows','System32','WindowsPowerShell','v1.0','powershell.exe');
 const script=[
 "Add-Type -AssemblyName System.Windows.Forms",
 "$d = New-Object System.Windows.Forms.OpenFileDialog",
 "$d.Title = 'Original MCR RC1.1 ZIP oder Identity-Runner auswaehlen'",
 "$d.Filter = 'RC1.1 ZIP / Runner (*.zip;*.mjs)|*.zip;*.mjs|Alle Dateien (*.*)|*.*'",
 "$d.Multiselect = $false",
 "if ($d.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { [Console]::Out.Write($d.FileName) }",
 ];
 const r=spawnSync(ps,['-NoProfile','-STA','-Command',script.join('; ')],{encoding:'utf8',windowsHide:false,timeout:180000,maxBuffer:1024*1024});
 demand(!r.error&&r.status===0,'PICKER_UNAVAILABLE','Dateiauswahl nicht verfuegbar. Ziehe stattdessen das RC1.1-ZIP auf QUELLE_AUSWAEHLEN.cmd.');
 return r.stdout.replace(/^\uFEFF/,'').trim();
}
try{
 verifyKit();
 const selected=process.argv[2] || showPicker();
 demand(selected,'SOURCE_NOT_SELECTED','Keine Datei ausgewaehlt. Ohne Quelle kein neuer Start.');
 const p=path.resolve(selected);
 demand(fs.existsSync(p)&&fs.lstatSync(p).isFile()&&!fs.lstatSync(p).isSymbolicLink(),'SOURCE_INVALID','Bitte die originale ZIP oder local-bot-full-run.mjs als Datei auswaehlen.');
 demand(/\.(zip|mjs)$/i.test(p),'SOURCE_INVALID','Nur originale ZIP oder local-bot-full-run.mjs.');
 const result=verifyCandidateFile(p,PINS);
 demand(result,'CANDIDATE_HASH_MISMATCH','Quelle hat nicht den dokumentierten SHA256. Kein Versand. Anderes ORIGINAL-ZIP waehlen.');
 const settings=readJson(settingsFile);
 demand(settings&&typeof settings==='object'&&!Array.isArray(settings),'SETTINGS_INVALID');
 settings.candidateRunner=p;
 atomicJson(settingsFile,settings);
 console.log('PASS  RC1.1_QUELLE_SHA256_GEPRUEFT');
 console.log('PASS  QUELLE_FUER_NAECHSTEN_START_HINTERLEGT');
 console.log('KEIN VERSAND. Jetzt JETZT_REPARIEREN_UND_STARTEN.cmd verwenden.');
}catch(e){
 const code=/^[A-Z0-9_]+$/.test(e?.code||'')?e.code:'SOURCE_SELECTION_ERROR';
 console.error('STOPP '+code+': '+String(e?.message||'Fehler').replace(/(?:[A-Z]:\\|\/Users\/|\/home\/)[^\r\n]*/gi,'[lokaler Pfad]'));
 console.error('Kein Quellpfad gespeichert, kein echter Versand.');
 process.exitCode=1;
}
