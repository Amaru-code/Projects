# MCR Ticketbot – Quellensuche-Fix V2 (20.10.2026)

## Warum dein bisheriger Starter bei CANDIDATE_NOT_FOUND stoppt

Die alte Wiederanlauf-Version 2026-10-20.1 lieferte nur das getestete Identity-Hilfsmodul und ein Recovery-Geruest mit. Der vollstaendige RC1.1-Runner war absichtlich NICHT enthalten. Die Quellensuche sah nicht alle ueblichen Windows-Fundorte und bot keine Dateiauswahl. Deshalb konnte sie auch bei unveraenderter urspruenglicher Installation stoppen.

**V2 ersetzt nur den externen Reparaturordner, nicht die Datenbruecke.** Bisheriges MCR_Datenbruecke, aktives Mapping und Original-START nicht loeschen. Den V2-ZIP in einen NEUEN Ordner entpacken. Nicht Teile aus zwei Recovery-Versionen mischen.

### Schnellster Weg

1. Den neuen V2-Ordner auf Windows entpacken. Im bisher verwendeten Reparaturordner nichts umbenennen.
2. `QUELLE_SUCHEN_OHNE_VERSAND.cmd` ausfuehren. Die Suche deckt nun Downloads, Desktop, Dokumente, Projektordner und passende OneDrive-Ordner ab und bestaetigt ausschliesslich sha256-gepruefte Originalbytes. Weder COMARCH noch der echte Versand werden angetastet.
3. Wenn `PINNED_SOURCE_AVAILABLE` gemeldet wird, `JETZT_REPARIEREN_UND_STARTEN.cmd` ausfuehren. Dieser laesst nur die vorhandenen Sicherheits-/Demo-Pruefungen zu und danach hoechstens ein echtes Ticket.
4. Falls stattdessen `CANDIDATE_NOT_FOUND` gemeldet wird: Das originale `MCR_Ticket_Assistant_Beta5_RC1_1_STARTFIX_OFFLINE_UPLOAD.zip` aus dem vorherigen Chat **auf den Windows-Laptop herunterladen**. Nichts entpacken muessen. `QUELLE_AUSWAEHLEN.cmd` doppelklicken und genau das ZIP auswaehlen. Alternativ die ZIP-Datei im Windows-Explorer auf `QUELLE_AUSWAEHLEN.cmd` ziehen. Das ZIP wird nur nach zweimaliger SHA256-Pruefung anerkannt (Archiv und enthaltener Runner).
5. Danach `JETZT_REPARIEREN_UND_STARTEN.cmd` aus dem V2-Ordner erneut ausfuehren.

Wenn die Originaldatei auf dem Laptop wirklich fehlt, kann ein Reparaturskript sie nicht aus einem alten Chat auf dem Server herunterladen: es gibt bewusst KEIN automatisches Netzwerk-Download-/Authentifizierungsverfahren. Die Library/der alte Chat zeigt das Originalpaket an, aber das Paket ist nicht Bestandteil dieses V2-ZIPs. Ein Quellpfad auf eine neu geschriebene/unbekannte Runnerdatei wird nicht akzeptiert.

**Keinen alten Bot-Lauf wiederholen, wenn Senden geklickt, die Speicherung aber nicht bestaetigt wurde.** Die wiederverwendeten Review-Sperren bleiben aktiv.

### V2-Erweiterungen

- Quelle wird nur lokal gelesen. Fundorte/Dateinamen sind nicht Teil des datensparsamen Ergebnisberichts; dort stehen lediglich Suchstatistik und Status.
- Erkennung eines vollstaendigen gepinnten RC1.1-Archivs sowie des einzelnen originalen Runnerfiles – auch wenn das Archiv verschoben/umbenannt ist, sofern es explizit ausgewaehlt wird.
- Klare Fehlermeldungen fuer nicht vorhandene Pfade (`SOURCE_PATH_NOT_FOUND`), unverifizierte Originale (`CANDIDATE_HASH_MISMATCH`) und zu grosse explizit gewaehlte Ordner (`SOURCE_FOLDER_TOO_LARGE`).
- Zusätzliche lokale Suchpruefung `QUELLE_SUCHEN_OHNE_VERSAND.cmd` und Dateiauswahl `QUELLE_AUSWAEHLEN.cmd` (kein Versand).
- Beibehaltung der urspruenglichen Baseline-, Identity-, Mapping-, Offline-Demo-, Receipt- und Queue-Sicherheitspruefungen. Kein Vertrauen nur aufgrund eines Dateinamens.

### Testgrenzen V2

Zusätzlich zu den 96 bisherigen synthetischen/Identity-Tests wurden 18 unabhaengige Quellensuche-Regressionstests in Node.js 22.16.0 unter Linux bestanden. **114/114 PASS** fuer das gesamte mitgelieferte Testset. Der echte RC1.1-Runner ist hier nicht als originale Datei vorhanden; daher wurde kein Windows-/Edge-/COMARCH-Live-Test hier ausgefuehrt. Ob der Quellrunner auf dem lokalen Laptop vorhanden ist, muss das Quellensuchskript nachweisen. Der Installer wird keinen Echtversand behaupten, bevor der lokale Einzelticketlauf den Send/Save-Beleg zurueckmeldet.

---

# MCR Ticketbot – Wiederanlauf vom 20.10.2026

## Sofort verwenden

Das ZIP vollständig in einen eigenen, dauerhaft erreichbaren Ordner entpacken. Den vorhandenen Bot-Ordner nicht ersetzen.

**`JETZT_REPARIEREN_UND_STARTEN.cmd` doppelklicken.** Dieser ausdrücklich benannte Starter kann nach seinen Prüfungen eine echte Standardantwort senden und ein echtes Ticket speichern. Er beginnt mit höchstens **einem** echten Ticket. Die normale COMARCH-Anmeldung und erforderliche Rückfragen des bisherigen Runners bleiben bestehen.

Nach der Meldung **`LIVE_PILOT_SEND_AND_SAVE_VERIFIED`** den regulären Betrieb mit **`TICKETBOT_STARTEN.cmd`** starten. Dieser verarbeitet wie der alte Runner höchstens 100 Tickets pro Start, zuerst „Meine Vorgänge > In_Bearbeitung“, danach „Warteschlange > INTL01“. Er wird nur nach einem nachgewiesenen erfolgreichen Einzelticketlauf zugelassen.

`START.cmd` der alten Installation wurde nicht ersetzt und zeigt weiter auf den alten Stand. Für den reparierten Stand die beiden hier genannten Starter verwenden. Die Offline-RC1-/RC2-Starter bleiben unverändert offline.

## Was dieses Paket ist – und was nicht

Dies ist ein **lokales Reparatur- und Wiederanlaufpaket**, kein neu erfundener Vollbot und kein vollständiger Ersatz für deine vorhandene Installation. Es verwendet den früheren Originalrunner mit dem bereits geprüften Identity-Fix und deine lokalen Laufzeitbibliotheken. Die vollständigen alten ZIP-Archive konnten in dieser Chat-Umgebung nicht als Bytes abgerufen werden; deshalb werden sie nicht als neu geprüft oder im Paket enthalten ausgegeben.

Die beiden Quellen für die lokale Reparatur sind bereits auf deinem Rechner dokumentiert:

- Installation: `%USERPROFILE%\projects\Aktive_Projekte\Ticket_bot\MCR_Datenbruecke`
- Node: `%USERPROFILE%\projects\Compiler\javascript\tools\node\node.exe`
- Aktives Mapping: `private_data\active-mapping.json` innerhalb der Installation. Der vorhandene Pointer bleibt maßgeblich. Keine Auswahl eines anderen Bestands, kein Excel-Neuexport.
- Kandidat: die vorhandene Identity-Preview unter Downloads und/oder das bereits heruntergeladene RC1.1-Paket. Der Starter sucht nur in den relevanten lokalen MCR-/Ticketbot-Ordnern und verwendet ausschließlich den dokumentierten Kandidatenhash.

Die bekannten RC1-/RC2-Archivhashes sind zusätzlich hinterlegt. Die reine Dateibezeichnung genügt nie als Nachweis. Existiert ein passendes komplettes Archiv, werden auch die benötigten unveränderten Laufzeitmodule damit verglichen. Bei ausschließlich vorhandenem, hashgeprüftem Previewrunner werden die installierten Bibliotheken verwendet und die fehlende unabhängige Archivbindung ausdrücklich als Information protokolliert; eine isolierte lokale Demo bleibt trotzdem zwingend.

**Wenn die Installation bewusst verschoben wurde:** `recovery-settings.json` bearbeiten. `installRoot` ist der existierende Projektordner; `candidateRunner` optional die bereits vorhandene vollständige Previewdatei. Bei Standardpfaden nichts eintragen. Beispiel für JSON-Schreibweise: `"C:\\Pfad\\MCR_Datenbruecke"`. Andere Programmdateien nicht manuell verändern.

## Der tatsächlich korrigierte Fehler

Das Originalmodul wurde aus dem alten Chat bytegenau zurückgewonnen. Sein SHA-256 entspricht deinem damaligen PATCH_REPORT:

`fe9e1afbca8ec4b5e3c8d7eb5bc53c741bfedc16d45429cfc2bda9a4dc5cd97a`

Ein zusätzlicher Fehler wurde mit einem ausführbaren Regressionstest nachgewiesen:

```text
Guten Tag
Am 20.10.2026 um 10:03 schrieb Max Mustermann <max@example.invalid>:
MercerID: 99
```

Das bisherige Muster erkannte „Am … schrieb:“ ohne Autor, aber nicht den oben gezeigten üblichen Autor hinter „schrieb“. Deshalb wurde die MercerID im alten Zitat weiterhin als aktuelle ID gewertet. Der minimale Fix erlaubt den Autor zwischen „schrieb“ und dem Doppelpunkt. Der vollständige Ein-Zeilen-Diff steht in `evidence/IDENTITY_FIX.diff`.

Die fachlichen Identitätsregeln bleiben: aktuelle ausdrücklich genannte MercerID bindet; unterschiedliche aktuelle IDs blockieren; Vor- und Nachname müssen zum COMARCH-Member passen; führende Nullen bleiben erhalten. Die Reparatur macht aus einem echten Identitätskonflikt keinen erlaubten Versand.

## Ablauf des Reparaturstarters

1. Eigenes Paket prüfen, vorhandenes Node verwenden und laufende andere Bot-Prozesse prüfen. Es werden keine Prozesse beendet und keine Berechtigungen geändert.
2. Exakten Beta-4-Quellhash, Kandidatenhash und aktiven Mapping-Pointer prüfen. Unbekannte oder bereits anders veränderte Installationen werden nicht überschrieben.
3. Benötigte Laufzeitdateien prüfen. Eine neue Offline-Demo aus isoliert kopierten Code-Dateien ausführen. Keine echten Mappingdaten, keine Konfiguration mit realer COMARCH-Adresse und kein persönliches Browserprofil werden in diese Demo übernommen. Synthetische Ressourcen stammen gegebenenfalls aus einem archivhashgeprüften Paket.
4. Für die Demo müssen zwei fiktive Tickets einschließlich Versand- und Speichernachweis erfolgreich sein. Ein bloßer Exitcode 0 reicht nicht. Fehlt ein auswertbarer Diagnosebeleg oder ein benötigtes Demoasset, wird ohne Live-Installation gestoppt.
5. Nur drei zusätzliche Programmdateien im bisherigen Projekt anlegen; den Originalrunner, bestehende Identity-Dateien, `START.cmd`, Konfiguration, aktives Mapping und Browserprofil nicht überschreiben.
6. Einen kontrollierten echten Lauf mit `MCR_MAX_TICKETS=1` starten. Die vorherige Standardantwort und der tatsächliche Empfänger werden weiterhin vom bestehenden Runner ermittelt; die Reparatur erfindet keinen Mailtext und keine neue fachliche Fallbearbeitung.
7. Erst nach nachgewiesenem Senden **und** Speichern ist der reguläre Starter freigeschaltet. Kein automatischer Vollqueue-Start im Anschluss an das erste Ticket.

Die drei Zusatzdateien sind:

```text
src/local-bot-recovery-20261020.mjs
lib/identity-evidence-recovery-20261020.cjs
lib/mcr-recovery-gate-20261020.mjs
```

Der neue Runner wird lokal aus dem exakten bisherigen Kandidaten gebaut. Er erhält einen vorgeschalteten Startschutz und genau eine geänderte Identity-Importadresse. Der sonstige Runnercode wird nicht neu geschrieben. USC-/Mehrzeilen-/TPP-Regeln, Anrede, Queueauswahl sowie Sende- und Speicherablauf verbleiben im vorhandenen Code. Das ist eine Änderungsabgrenzung, **kein hier neu durchgeführter Kompletttest des alten Bots**.

## Protokolle und Fehler

`Ergebnis\REPARATUR_ERGEBNIS.json` entsteht neben den Startern. Dieser Bericht enthält Status, Prüfschritte, Hashes und reduzierte Diagnosefelder, aber keine Namen, IDs, Mailtexte, Zugangsdaten, Browserdaten oder persönlichen Pfade. Die Konsolenausgabe des alten Bots wird nicht von diesem Paket in eine neue Datei mitgeschrieben; sie kann wie zuvor personenbezogene Informationen anzeigen. Die eigenen ursprünglichen Logs des Bots bleiben unverändert.

Die Wiederanlaufkontrolle liegt lokal unter `.mcr-recovery-20261020` im Projekt. Ein unterbrochener oder ungeklärter Versand wird nicht automatisch wiederholt. Alte Sperren, ursprüngliche Protokolle, RC-Freigaben und unklare Versandzustände werden nicht gelöscht oder stillschweigend zurückgesetzt.

Wichtige Status:

| Status | Bedeutung |
|---|---|
| `BASELINE_CHANGED` | Installierter Runner ist nicht mehr das bekannte Beta-4-Original; kein Überschreiben. |
| `CANDIDATE_NOT_FOUND` | Exakte Preview/RC1-Quelldatei lokal nicht gefunden; vorhandenen Download nicht löschen, optional bekannten Dateipfad in Einstellungen angeben. |
| `CORE_DIFFERS_FROM_RC1` | Benötigte Laufzeitdatei weicht vom archivgebundenen Referenzstand ab. |
| `OFFLINE_DEMO_NOT_VERIFIED` | Kein erfolgreicher Zwei-Ticket-Demonachweis; keine Live-Installation. |
| `PREVIOUS_SEND_UNCERTAIN` / `PREVIOUS_RUN_UNCERTAIN` / `REVIEW_REQUIRED` | Zuerst den realen COMARCH-Verlauf kontrollieren. Kein blindes erneutes Senden. |
| `NO_ELIGIBLE_TICKET` | Kein passendes Ticket vorhanden. Das ist kein erfolgreicher Live-Pilot. |
| `PILOT_VERIFIED_READY_FOR_QUEUE` | Genau ein echtes Ticket nachgewiesen gesendet und gespeichert; regulärer Starter bereit. |

Bei einem Stopp ist der datensparsame `REPARATUR_ERGEBNIS.json` der vorgesehene Rückkanal – nicht private Bestandsdaten, Browserprofile oder komplette Mailinhalte.

## Rückweg

`ZURUECK_ZUM_ALTEN_STAND.cmd` entfernt nur Zusatzdateien, die tatsächlich durch diese Reparatur angelegt wurden und seitdem unverändert sind. Der Originalrunner und ursprüngliche Startpfad bleiben ohnehin erhalten. Geänderte Zusatzdateien oder ungeklärte Live-Zustände werden nicht automatisch beseitigt. Die Nachweisdateien bleiben zur Nachvollziehbarkeit bestehen.

## Prüfung dieses gelieferten Pakets

**96/96 Tests bestanden, 0 Fehler, 0 übersprungen** in der hier verfügbaren Linux-Umgebung mit Node.js 22.16.0. Getestet wurden das originale und reparierte Identity-Modul, sichere ZIP-/Pfadverarbeitung, additive Installation, Rücknahme und simulierte Abbrüche, Hashabweichungen, Startschutz, Einzelticketlimit, Simulations-/Echtlauftrennung und die Prüfung frischer Sende-/Speichernachweise anhand synthetischer Runner.

Diese 96 Tests sind **nicht** die 72 oder 91 Tests aus dem alten Chat und werden nicht mit ihnen addiert. Die synthetischen Runner öffnen kein COMARCH und versenden keine E-Mail. Der bekannte Identitätsfehler wurde am tatsächlichen zurückgewonnenen Modul reproduziert; der alte vollständige Runner konnte hier nicht erneut ausgeführt werden.

**Nicht hier ausgeführt:** Windows-CMD-Starter, Windows-Prozessabfrage, echte Edge-/COMARCH-Demo mit dem vollständigen alten Runner und ein echter Ticketlauf auf deinem Rechner. Desktop Commander meldete das einzige vorhandene Gerät offline. Deshalb wird nicht behauptet, der Bot sei bereits auf deinem PC gestartet. Die echte lokale Demo und der Einzelticketlauf werden erst durch den oben genannten Starter ausgeführt und getrennt protokolliert.

`SELBSTTEST.cmd` führt nur die mitgelieferten synthetischen Tests lokal aus. Der Symlink-Test kann unter Windows mangels erforderlicher Rechte explizit übersprungen werden; die produktive Prüfung von symbolischen Links bleibt aktiv.

## Technische Referenzen

Die Implementierung verwendet ausschließlich eingebaute Node-Module. Prozessstarts des Runners erfolgen mit `spawn(process.execPath, argv)` ohne Shell; CMD-Starter benutzen korrekt gequotete Windows-Pfade. Referenz: offizielle Node.js-Dokumentation `https://nodejs.org/api/child_process.html`.

Projektbelege sind der hier hochgeladene Chat-Export, dein PATCH_REPORT und die über die Dateibibliothek gelesenen RC1-/RC2-Prüfsummendateien. Es wurden keine Bestands-/Mail-/Browserdaten in dieses ZIP aufgenommen.
