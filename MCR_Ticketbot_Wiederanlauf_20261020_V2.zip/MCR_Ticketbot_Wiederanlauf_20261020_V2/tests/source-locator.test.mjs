import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {sha,readZip} from '../tools/recovery-core.mjs';
import {verifyCandidateFile,discoverCandidate} from '../tools/source-locator.mjs';
const kit=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const archive=fs.readFileSync(path.join(kit,'tests','fixtures','test-source-rc1.zip'));
const src=Buffer.from('/* synthetic QA runner, no COMARCH */\nexport const ok = true;\n');
const pins={baseline:'a'.repeat(64),identity:'b'.repeat(64),candidate:sha(src),archives:[sha(archive)]};
const temp=t=>{const root=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-source-scan-test-'));t.after(()=>fs.rmSync(root,{recursive:true,force:true}));return root;};
const put=(root,rel,data)=>{const p=path.join(root,rel);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,data);return p;};
const context=(base,settings={})=>({settings,home:path.join(base,'home'),kit:path.join(base,'kit'),installRoot:path.join(base,'home','projects','Aktive_Projekte','Ticket_bot','MCR_Datenbruecke'),pins});
test('fixture only: archive synthetic runner is exact and contains no real environment content',()=>{
 const z=readZip(archive);assert.equal(sha(z.get('MCR_Ticket_Assistant_Beta_5_RC1/src/local-bot-full-run.mjs')),pins.candidate);
 assert.ok(!archive.toString('utf8').includes('mercer.com'));
});
test('direct synthetic RC1.1 archive is valid by archive hash AND embedded runner hash',t=>{
 const r=temp(t),p=put(r,'MCR_Ticket_RC1_1.zip',archive),got=verifyCandidateFile(p,pins);
 assert.equal(got.source,'PINNED_LOCAL_ARCHIVE');assert.equal(got.archiveSha256,pins.archives[0]);assert.deepEqual(got.bytes,src);
});
test('unmodified synthetic candidate file is accepted by exact SHA',t=>{
 const r=temp(t),p=put(r,'local-bot-full-run.mjs',src),got=verifyCandidateFile(p,pins);
 assert.equal(got.source,'PINNED_LOCAL_PREVIEW');assert.deepEqual(got.bytes,src);
});
test('pinned archive with wrong expected runner cannot be mistaken for original',t=>{
 const r=temp(t),p=put(r,'MCR_Ticket_RC1_1.zip',archive);
 assert.equal(verifyCandidateFile(p,{...pins,candidate:'0'.repeat(64)}),null);
});
test('corrupted archive is rejected by fingerprint before ZIP parsing',t=>{
 const r=temp(t),bad=Buffer.from(archive);bad[12]^=0x11;
 assert.equal(verifyCandidateFile(put(r,'MCR_Ticket_RC1_1.zip',bad),pins),null);
});
test('auto search: Downloads archive found with original RC1 filename',t=>{
 const r=temp(t),c=context(r);
 const p=put(r,'home/Downloads/MCR_Ticket_Assistant_Beta5_RC1_1_STARTFIX_OFFLINE_UPLOAD.zip',archive);
 const got=discoverCandidate(c);
 assert.equal(got.source,'PINNED_LOCAL_ARCHIVE');assert.equal(got.stats.rootsChecked[0],'Downloads');
 assert.equal(fs.readFileSync(p).equals(archive),true);
});
test('auto search: moved and renamed preview source under project',t=>{
 const r=temp(t),c=context(r);
 put(r,'home/projects/Aktive_Projekte/Ticket_bot/recovered/preview/src/local-bot-full-run.mjs',src);
 const got=discoverCandidate(c);assert.equal(got.source,'PINNED_LOCAL_PREVIEW');
 assert.ok(got.stats.rootsChecked.includes('TicketBotProject'));
});
test('auto search: deeper extracted preview with Windows-style version folder',t=>{
 const r=temp(t),c=context(r);
 put(r,'home/Downloads/MCR_BETA5_IDENTITY_FIX_SOURCE_PREVIEW_NODEFIX/MCR_BETA5_IDENTITY_FIX_SOURCE_PREVIEW_NODEFIX/candidate_preview_28498_6447/src/local-bot-full-run.mjs',src);
 const got=discoverCandidate(c);assert.equal(got.source,'PINNED_LOCAL_PREVIEW');
});
test('auto search: missing Downloads can be recovered from Documents',t=>{
 const r=temp(t),c=context(r);put(r,'home/Documents/MCR archive/MCR RC1.1 ZIP.zip',archive);
 const got=discoverCandidate(c);assert.equal(got.source,'PINNED_LOCAL_ARCHIVE');
 assert.ok(got.stats.rootsChecked.includes('Documents'));
});
test('auto search: discovered source in OneDrive root',t=>{
 const r=temp(t),c={...context(r),env:{OneDrive:path.join(r,'synced')}};
 put(r,'synced/Office/Tools/MCR_Ticket_RC1_1.zip',archive);
 const got=discoverCandidate(c);assert.equal(got.source,'PINNED_LOCAL_ARCHIVE');
});
test('explicit archive may be renamed arbitrarily, still accepted with exact hash',t=>{
 const r=temp(t),srcFile=put(r,'backup/stuff.zip',archive),c=context(r,{candidateRunner:srcFile});
 const got=discoverCandidate(c);assert.equal(got.source,'PINNED_LOCAL_ARCHIVE');
});
test('explicit candidate file may have arbitrary basename when SHA matches',t=>{
 const r=temp(t),srcFile=put(r,'backup/runner-copy.mjs',src),c=context(r,{candidateRunner:srcFile});
 const got=discoverCandidate(c);assert.equal(got.source,'PINNED_LOCAL_PREVIEW');
});
test('explicit source directory is scanned',t=>{
 const r=temp(t),folder=path.join(r,'backup'),c=context(r,{candidateRunner:folder});
 put(r,'backup/sources/local-bot-full-run.mjs',src);
 const got=discoverCandidate(c);assert.equal(got.source,'PINNED_LOCAL_PREVIEW');
});
test('explicit source nonexistent fails with a descriptive code',t=>{
 const r=temp(t),c=context(r,{candidateRunner:path.join(r,'file-missing.zip')});
 assert.throws(()=>discoverCandidate(c),{code:'SOURCE_PATH_NOT_FOUND'});
});
test('explicit wrong ZIP blocks rather than silently choosing another archive',t=>{
 const r=temp(t),other=put(r,'backup/MCR_Ticket.zip','not an original'),c=context(r,{candidateRunner:other});
 put(r,'home/Downloads/MCR_Ticket_RC1_1.zip',archive);
 assert.throws(()=>discoverCandidate(c),{code:'CANDIDATE_HASH_MISMATCH'});
});
test('auto mode rejects unpinned candidate with explanatory counters',t=>{
 const r=temp(t),c=context(r);put(r,'home/Downloads/MCR_Ticket_RC1_1.zip','not the source');
 assert.throws(()=>discoverCandidate(c),e=>e.code==='CANDIDATE_NOT_FOUND'&&e.stats.checked===1&&e.stats.hashMismatchCount===1);
});
test('source scanner does not access private_data for candidate search',t=>{
 const r=temp(t),c=context(r);
 put(r,'home/Downloads/MCR_Datenbruecke/private_data/local-bot-full-run.mjs',src);
 assert.throws(()=>discoverCandidate(c),{code:'CANDIDATE_NOT_FOUND'});
});
test('candidate source path never becomes a send authorization or installed file',t=>{
 const r=temp(t),p=put(r,'home/Downloads/MCR_Ticket_RC1.zip',archive),c=context(r);
 discoverCandidate(c);
 assert.equal(fs.readdirSync(path.dirname(p)).length,1);
 assert.equal(fs.existsSync(path.join(c.installRoot,'.mcr-recovery-20261020')),false);
});
