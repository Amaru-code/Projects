import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
import {spawnSync} from 'node:child_process';
import {PINS,NAMES,PREFIX,sha,hashFile,readJson,safeRelative,inside,atomicJson,walk,crc32,readZip,
  staticDependencies,dependencyFiles,checkSyntax,verifyPins,makeOverlay,retargetIdentity,verifyFiles,
  installAdditions,rollback,isVerifiedRun,uncertainSend,publicDiagnostic} from '../tools/recovery-core.mjs';
const kit=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const req=createRequire(import.meta.url), I=req('../payload/identity-evidence.cjs');
const helper=fs.readFileSync(path.join(kit,'payload','identity-evidence.cjs'));
const temp=t=>{const r=fs.mkdtempSync(path.join(os.tmpdir(),'mcr-recovery-test-'));t.after(()=>fs.rmSync(r,{recursive:true,force:true}));return r;};
const put=(root,rel,text)=>{const p=path.join(root,rel);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,text);return p;};
const person={firstName:'Max',lastName:'Mustermann'};
const member={source:'PROFILE_ROWS',firstName:'Max',lastName:'Mustermann',id:'42'};

// Original identity code: unchanged, not a newly invented heuristic.
test('archived original identity bytes match user PATCH_REPORT exactly',()=>assert.equal(sha(fs.readFileSync(path.join(kit,'payload','identity-evidence.original.cjs'))),PINS.identity));
test('repaired helper has independently pinned hash',()=>assert.equal(sha(helper),PINS.repairedIdentity));
test('current explicit MercerID binds the selected member',()=>assert.equal(I.requireMatched(member,person,I.buildEvidence({body:'MercerID: 42'})),true));
test('different explicit ID blocks',()=>assert.throws(()=>I.requireMatched(member,person,I.buildEvidence({body:'MercerID: 99'})),{code:'MEMBER_ID_CONFLICT'}));
test('two explicit current IDs block',()=>assert.throws(()=>I.buildEvidence({body:'MercerID: 42\nINTL01-99'}),{code:'MAIL_ID_AMBIGUOUS'}));
test('same ID twice is not ambiguous',()=>assert.equal(I.buildEvidence({body:'MercerID: 42\nINTL01-42'}).expectedId,'42'));
test('quoted number does not create a conflict',()=>assert.equal(I.buildEvidence({body:'Hallo\n> MercerID: 99'}).expectedId,null));
test('German reply separator excludes prior identity',()=>assert.equal(I.buildEvidence({body:'Hallo\nAm Montag schrieb Alt:\nMercerID: 99'}).expectedId,null));
test('English reply separator excludes prior identity',()=>assert.equal(I.buildEvidence({body:'Hello\nOn Monday somebody wrote:\nMercerID: 99'}).expectedId,null));
test('forwarded-message separator excludes prior identity',()=>assert.equal(I.buildEvidence({body:'Hallo\n-----Original Message-----\nMercerID: 99'}).expectedId,null));
test('generic employee number remains advisory',()=>assert.equal(I.buildEvidence({body:'Personalnummer: 99'},[{clientId:'99'}]).expectedId,null));
test('current explicit ID overrides unrelated quoted ID',()=>assert.equal(I.buildEvidence({body:'MercerID: 42\n> MercerID: 99'}).expectedId,'42'));
test('subject explicit ID remains binding as in original contract',()=>assert.equal(I.buildEvidence({subject:'INTL01-42',body:'Hallo'}).expectedId,'42'));
test('wrong name never passes on matching numeric ID alone',()=>assert.throws(()=>I.requireMatched({...member,lastName:'Anders'},person,{expectedId:'42'}),{code:'MEMBER_NAME_MISMATCH'}));
test('field containing only ID is not identity proof',()=>assert.equal(I.memberNameMatches({source:'MEMBER_FIELD',display:'INTL01-42',id:'42'},person),false));
test('field with full name and ID passes',()=>assert.equal(I.memberNameMatches({source:'MEMBER_FIELD',display:'Mustermann Max (INTL01-42)',id:'42'},person),true));
test('unknown source blocks',()=>assert.equal(I.memberNameMatches({...member,source:'GUESSED'},person),false));
test('leading zero is not silently removed',()=>assert.throws(()=>I.requireMatched(member,person,{expectedId:'042'}),{code:'MEMBER_ID_CONFLICT'}));
test('umlaut transliteration is limited to the name comparison',()=>assert.equal(I.fold('Müller'),I.fold('Mueller')));
test('missing mail blocks',()=>assert.throws(()=>I.buildEvidence(null),{code:'MAIL_ID_EVIDENCE'}));
test('no ID still needs a matching name',()=>assert.equal(I.requireMatched(member,person,I.buildEvidence({body:'Guten Tag'})),true));

for(const bad of ['../outside','/absolute','C:/outside','a/../../outside','a\\..\\outside','a:b','a/CON.txt','a/b.','a/b ','a\0b'])
 test('unsafe path rejected '+JSON.stringify(bad),()=>assert.throws(()=>safeRelative(bad)));
test('normal Windows separator is normalized',()=>assert.equal(safeRelative('src\\local.mjs'),'src/local.mjs'));
test('atomic JSON writes and replaces valid JSON',t=>{const r=temp(t),p=path.join(r,'s.json');atomicJson(p,{a:1});atomicJson(p,{a:2});assert.deepEqual(readJson(p),{a:2});assert.deepEqual(fs.readdirSync(r),['s.json']);});
test('symlink target is rejected', {skip:process.platform==='win32'?'Requires symlink privilege; production still checks links.':false}, t=>{const r=temp(t),other=temp(t);fs.symlinkSync(other,path.join(r,'src'));assert.throws(()=>inside(r,'src/code.mjs'),{code:'PATH_LINK'});});
test('walk excludes private mapping and browser profile contents',t=>{const r=temp(t);put(r,'src/a.mjs','');put(r,'private_data/secret.json','secret');put(r,'browser-profile/private.json','secret');assert.deepEqual(walk(r).map(x=>path.relative(r,x)),[path.join('src','a.mjs')]);});
test('walk has a finite explicit bound',t=>{const r=temp(t);put(r,'a','');put(r,'b','');assert.throws(()=>walk(r,{maxFiles:1}),{code:'SCAN_LIMIT'});});
test('CRC32 reference vector',()=>assert.equal(crc32(Buffer.from('123456789')),0xcbf43926));
test('stored ZIP and deflated ZIP decode the same exact file',()=>{for(const file of ['stored.zip','deflated.zip']){const z=readZip(fs.readFileSync(path.join(kit,'tests','fixtures',file)));assert.equal(z.get('pkg/src/demo.mjs').toString(),'export const ok = true;\n');}});
for(const name of ['traversal.zip','case-collision.zip','symlink.zip','corrupt-crc.zip','file-dir-conflict.zip'])
 test('reject malformed or unsafe ZIP '+name,()=>assert.throws(()=>readZip(fs.readFileSync(path.join(kit,'tests','fixtures',name)))));
test('arbitrary text is not ZIP',()=>assert.throws(()=>readZip(Buffer.from('this is not an archive at all'))));
test('truncated archive is rejected',()=>{const b=fs.readFileSync(path.join(kit,'tests','fixtures','stored.zip'));assert.throws(()=>readZip(b.subarray(0,b.length-1)));});
test('dependency parsing recognizes import, from and require',()=>assert.deepEqual(staticDependencies("import fs from 'node:fs';import {x} from '../lib/x.mjs';const y=require('../lib/y.cjs'); import('./z.mjs')"),['../lib/x.mjs','../lib/y.cjs','./z.mjs']));
test('dependency closure reads original lib files but overlays only identity',t=>{const r=temp(t);put(r,'lib/a.mjs',"import './b.cjs';");put(r,'lib/b.cjs',"module.exports={};");const c=Buffer.from("import '../lib/a.mjs'; import '../lib/identity-evidence-recovery-20261020.cjs';");const d=dependencyFiles(r,c,helper);assert.equal(d.size,4);assert.equal(d.get(NAMES.helper),helper);});
test('dependency outside code directories rejected',t=>{const r=temp(t);assert.throws(()=>dependencyFiles(r,Buffer.from("import '../private_data/x.json';"),helper),{code:'DEPENDENCY_OUTSIDE_CODE'});});
test('valid JS syntax accepted without execution',t=>{const r=temp(t);const p=put(r,'a.mjs',"throw new Error('MUST NOT EXECUTE');");assert.doesNotThrow(()=>checkSyntax(p));});
test('invalid syntax rejected',t=>{const r=temp(t);const p=put(r,'a.mjs','const = ;');assert.throws(()=>checkSyntax(p),{code:'SYNTAX_FAIL'});});
test('pin verification rejects changed baseline before deployment',t=>{const r=temp(t);put(r,NAMES.original,'fake');assert.throws(()=>verifyPins(r,Buffer.from('fake'),helper),{code:'BASELINE_CHANGED'});});
test('overlay changes only gate prefix and one identity-module path',()=>{const c=Buffer.from("const Identity = require('../lib/identity-evidence.cjs');\r\n// unchanged code\r\n");const o=makeOverlay(c);assert.equal(o.subarray(0,Buffer.byteLength(PREFIX)).toString(),PREFIX);assert.deepEqual(o.subarray(Buffer.byteLength(PREFIX)),retargetIdentity(c));assert.equal(o.toString().endsWith('// unchanged code\r\n'),true);});
test('missing identity anchor blocks instead of blind patching',()=>assert.throws(()=>makeOverlay(Buffer.from('// no anchor')),{code:'IDENTITY_IMPORT_ANCHOR'}));
test('duplicate identity anchor blocks',()=>assert.throws(()=>makeOverlay(Buffer.from("const Identity = require('../lib/identity-evidence.cjs');\nconst Identity = require('../lib/identity-evidence.cjs');")),{code:'IDENTITY_IMPORT_ANCHOR'}));
function txFixture(t){const r=temp(t);put(r,NAMES.original,'original');put(r,'lib/base.cjs','base');put(r,NAMES.pointer,'{"original":true}');const snapshot={[NAMES.original]:hashFile(path.join(r,NAMES.original)),'lib/base.cjs':hashFile(path.join(r,'lib/base.cjs'))};const additions=new Map([[NAMES.helper,Buffer.from('helper')],[NAMES.gate,Buffer.from('gate')],[NAMES.overlay,Buffer.from('overlay')]]);return {r,snapshot,additions};}
test('additive install preserves original runner and active mapping',t=>{const {r,snapshot,additions}=txFixture(t);installAdditions(r,additions,snapshot);verifyFiles(r,snapshot);assert.equal(fs.readFileSync(path.join(r,NAMES.pointer),'utf8'),'{"original":true}');assert.equal(readJson(path.join(r,NAMES.metadata,'transaction.json')).state,'COMPLETE');});
test('idempotent second install preserves rollback provenance',t=>{const {r,snapshot,additions}=txFixture(t);installAdditions(r,additions,snapshot);installAdditions(r,additions,snapshot);rollback(r);for(const rel of additions.keys())assert.equal(fs.existsSync(path.join(r,rel)),false);verifyFiles(r,snapshot);});
for(const writes of [1,2,3])test('interrupted installation rolls back added files after write '+writes,t=>{const {r,snapshot,additions}=txFixture(t);assert.throws(()=>installAdditions(r,additions,snapshot,{failAfterWrites:writes}),{code:'TEST_FAIL'});for(const rel of additions.keys())assert.equal(fs.existsSync(path.join(r,rel)),false);verifyFiles(r,snapshot);assert.equal(readJson(path.join(r,NAMES.metadata,'transaction.json')).state,'ROLLED_BACK');});
test('preexisting identical helper survives rollback',t=>{const {r,snapshot,additions}=txFixture(t);put(r,NAMES.helper,'helper');installAdditions(r,additions,snapshot);rollback(r);assert.equal(fs.readFileSync(path.join(r,NAMES.helper),'utf8'),'helper');});
test('conflicting helper cannot be overwritten',t=>{const {r,snapshot,additions}=txFixture(t);put(r,NAMES.helper,'different');assert.throws(()=>installAdditions(r,additions,snapshot),{code:'ADDITION_CONFLICT'});assert.equal(fs.readFileSync(path.join(r,NAMES.helper),'utf8'),'different');});
test('rollback blocks when an added file was subsequently modified',t=>{const {r,snapshot,additions}=txFixture(t);installAdditions(r,additions,snapshot);put(r,NAMES.overlay,'user modification');assert.throws(()=>rollback(r),{code:'ROLLBACK_DRIFT'});assert.equal(fs.readFileSync(path.join(r,NAMES.overlay),'utf8'),'user modification');});
test('rollback never removes original files',t=>{const {r,snapshot,additions}=txFixture(t);installAdditions(r,additions,snapshot);rollback(r);rollback(r);verifyFiles(r,snapshot);assert.equal(fs.existsSync(path.join(r,NAMES.pointer)),true);});
test('modified dependency blocks verification',t=>{const {r,snapshot}=txFixture(t);put(r,'lib/base.cjs','changed');assert.throws(()=>verifyFiles(r,snapshot),{code:'CODE_CHANGED'});});
test('pending transaction is not treated as success',t=>{const {r,snapshot,additions}=txFixture(t);put(r,NAMES.metadata+'/transaction.json',JSON.stringify({state:'PREPARING'}));assert.throws(()=>installAdditions(r,additions,snapshot),{code:'TRANSACTION_PENDING'});});
const diag={schema:'MCR_LOCAL_RUNNER_DIAGNOSTIC_V1',mode:'REAL',loop:{processed:1},send:{clicked:true,verified:true},save:{verified:true},lastError:null};
test('pilot success requires send AND save evidence',()=>{assert.equal(isVerifiedRun(diag,'REAL',1),true);assert.equal(isVerifiedRun({...diag,save:{verified:false}},'REAL',1),false);assert.equal(isVerifiedRun({...diag,send:{verified:false}},'REAL',1),false);});
test('a demo cannot certify a real ticket',()=>assert.equal(isVerifiedRun({...diag,mode:'DEMO'},'REAL',1),false));
test('zero tickets do not count as a successful pilot',()=>assert.equal(isVerifiedRun({...diag,loop:{processed:0}},'REAL',1),false));
test('uncertain send requires manual review',()=>assert.equal(uncertainSend({...diag,save:{verified:false}}),true));
test('unknown diagnostic cannot be successful',()=>assert.equal(isVerifiedRun(null,'REAL',1),false));
test('shareable diagnostic drops PII, IDs and arbitrary error strings',()=>{const d=publicDiagnostic({...diag,name:'Personal Name',member:{id:'111'},lastError:{code:'private@example.invalid'}});assert.equal(JSON.stringify(d).includes('Personal'),false);assert.equal(d.errorCode,null);assert.equal('member'in d,false);});
function gateFixture(t,{mode='PILOT',max='1',mutate=null,token='test-session-token',age=0,parent=process.pid,argv=[]}={}) {
 const r=temp(t);const gate=fs.readFileSync(path.join(kit,'payload',path.basename(NAMES.gate)));
 put(r,NAMES.gate,gate);put(r,'lib/marker.mjs',"import fs from 'node:fs'; fs.writeFileSync(new URL('../executed.txt',import.meta.url),'executed');");
 put(r,NAMES.original,'// baseline');put(r,NAMES.overlay,PREFIX+"import '../lib/marker.mjs'; console.log('RUNNER_REACHED');");
 const hashes=Object.fromEntries([NAMES.gate,NAMES.original,NAMES.overlay,'lib/marker.mjs'].map(rel=>[rel,hashFile(path.join(r,rel))]));
 put(r,NAMES.metadata+'/session.json',JSON.stringify({schema:'MCR_CONTROLLED_RUN_V1',mode,parentPid:parent,tokenSha256:sha(token),createdAtMs:Date.now()-age,hashes}));
 if(mutate)put(r,'lib/marker.mjs',mutate);
 const env={...process.env,MCR_RECOVERY_SESSION:token,MCR_MAX_TICKETS:max};
 const result=spawnSync(process.execPath,[path.join(r,NAMES.overlay),...argv],{cwd:r,env,encoding:'utf8',timeout:15000});
 return {r,result};
}
test('controlled single-ticket gate admits only parent-bound session',t=>{const {r,result}=gateFixture(t);assert.equal(result.status,0,result.stderr);assert.equal(fs.existsSync(path.join(r,'executed.txt')),true);assert.equal(fs.existsSync(path.join(r,NAMES.metadata,'session.json')),false);});
test('direct guarded runner invocation stops before other module side effects',t=>{const {r}=gateFixture(t);fs.unlinkSync(path.join(r,'executed.txt'));const x=spawnSync(process.execPath,[path.join(r,NAMES.overlay)],{encoding:'utf8',timeout:15000});assert.notEqual(x.status,0);assert.equal(fs.existsSync(path.join(r,'executed.txt')),false);});
for(const [label,opts]of [['pilot with 100 tickets',{max:'100'}],['wrong parent',{parent:-1}],['expired session',{age:120000}],['changed dependency',{mutate:'// changed'}],['demo flag in real session',{argv:['--demo']}],['unrecognized mode',{mode:'UNBOUNDED'}]])
 test('gate rejects '+label,t=>{const {r,result}=gateFixture(t,opts);assert.notEqual(result.status,0);assert.equal(fs.existsSync(path.join(r,'executed.txt')),false);});
test('separate demo mode accepted only with demo argument',t=>{const {result}=gateFixture(t,{mode:'DEMO',max:'3',argv:['--demo']});assert.equal(result.status,0,result.stderr);});
test('queue mode uses original bounded limit 100',t=>{const {result}=gateFixture(t,{mode:'QUEUE',max:'100'});assert.equal(result.status,0,result.stderr);});

test('regression: original separator binds a quoted ID, repaired separator excludes it',()=>{
 const old=req('../payload/identity-evidence.original.cjs');
 const mail={body:'Guten Tag\nAm 20.10.2026 um 10:03 schrieb Max Mustermann <max@example.invalid>:\nMercerID: 99'};
 assert.equal(old.buildEvidence(mail).expectedId,'99');
 assert.equal(I.buildEvidence(mail).expectedId,null);
});
test('German separator without author remains supported',()=>assert.equal(I.buildEvidence({body:'Hallo\nAm Montag schrieb:\nMercerID: 99'}).expectedId,null));
test('current explicit ID stays binding above a German quoted author header',()=>assert.equal(I.buildEvidence({body:'MercerID: 42\nAm Montag schrieb Max Mustermann:\nMercerID: 99'}).expectedId,'42'));
test('a current conflicting ID still blocks despite German quote fix',()=>assert.throws(()=>I.requireMatched(member,person,I.buildEvidence({body:'MercerID: 77\nAm Montag schrieb Max Mustermann:\nMercerID: 42'})),{code:'MEMBER_ID_CONFLICT'}));

// Workflow simulation only: these child runners do not open COMARCH or send mail.
import {scanDiagnostics,runControlled} from '../tools/runner-control.mjs';
function workflowFixture(t,{emitDiagnostic=true,exit=0,save=true,error=null,oldTimestamp=false}={}) {
 const r=temp(t);
 const gate=fs.readFileSync(path.join(kit,'payload',path.basename(NAMES.gate)));
 put(r,NAMES.gate,gate);put(r,NAMES.helper,helper);
 const source=`import fs from 'node:fs';
 import path from 'node:path';
 const Identity = require('../lib/identity-evidence.cjs');
 `;
 // A real createRequire declaration is needed in the synthetic ESM runner as in the original.
 const candidate=Buffer.from(`import {createRequire} from 'node:module';
 const require=createRequire(import.meta.url);
 ${source}
 const demo=process.argv.includes('--demo');
 const n=demo?2:Number(process.env.MCR_MAX_TICKETS);
 if (${emitDiagnostic}) {
  fs.mkdirSync('outputs',{recursive:true});
  fs.writeFileSync('outputs/DIAGNOSTIC.json',JSON.stringify({schema:'MCR_LOCAL_RUNNER_DIAGNOSTIC_V1',
   createdAt:${oldTimestamp?"'2000-01-01T00:00:00.000Z'":"new Date().toISOString()"},mode:demo?'DEMO':'REAL',
   loop:{processed:n},send:{clicked:true,verified:true},save:{verified:${save}},lastError:${JSON.stringify(error)}}));
 }
 process.exitCode=${exit};
 `);
 put(r,NAMES.original,candidate);put(r,NAMES.overlay,makeOverlay(candidate));
 const hashes=Object.fromEntries([NAMES.original,NAMES.overlay,NAMES.helper,NAMES.gate].map(rel=>[rel,hashFile(path.join(r,rel))]));
 return {r,hashes};
}
test('simulated controlled pilot gets exactly one ticket limit and a fresh diagnostic',async t=>{const {r,hashes}=workflowFixture(t);const got=await runControlled(r,'PILOT',hashes);assert.equal(got.exit,0);assert.equal(isVerifiedRun(got.diagnostic,'REAL',1),true);});
test('simulated demo reports two fictional tickets, not real evidence',async t=>{const {r,hashes}=workflowFixture(t);const got=await runControlled(r,'DEMO',hashes);assert.equal(got.exit,0);assert.equal(isVerifiedRun(got.diagnostic,'DEMO',2),true);assert.equal(isVerifiedRun(got.diagnostic,'REAL',1),false);});
test('simulated queue retains original maximum of 100',async t=>{const {r,hashes}=workflowFixture(t);const got=await runControlled(r,'QUEUE',hashes);assert.equal(got.diagnostic.loop.processed,100);});
test('successful process exit alone is not a successful pilot',async t=>{const {r,hashes}=workflowFixture(t,{emitDiagnostic:false});const got=await runControlled(r,'PILOT',hashes);assert.equal(got.exit,0);assert.equal(got.diagnostic,null);assert.equal(isVerifiedRun(got.diagnostic,'REAL',1),false);});
test('failed simulated process remains failed despite plausible diagnostic',async t=>{const {r,hashes}=workflowFixture(t,{exit:5});const got=await runControlled(r,'PILOT',hashes);assert.equal(got.exit,5);});
test('simulated send without save remains uncertain',async t=>{const {r,hashes}=workflowFixture(t,{save:false});const got=await runControlled(r,'PILOT',hashes);assert.equal(uncertainSend(got.diagnostic),true);});
test('previously created diagnostic cannot be reused as new evidence',async t=>{const {r,hashes}=workflowFixture(t,{oldTimestamp:true});const got=await runControlled(r,'PILOT',hashes);assert.equal(got.diagnostic,null);});
test('changed runtime is blocked before a child starts',async t=>{const {r,hashes}=workflowFixture(t);put(r,NAMES.helper,'changed');await assert.rejects(()=>runControlled(r,'PILOT',hashes),{code:'CODE_CHANGED'});assert.equal(fs.existsSync(path.join(r,'outputs')),false);});
test('stale session file is not silently overwritten',async t=>{const {r,hashes}=workflowFixture(t);put(r,NAMES.metadata+'/session.json','{}');await assert.rejects(()=>runControlled(r,'PILOT',hashes),{code:'SESSION_EXISTS'});});
test('unrelated JSON and private data are not accepted as runtime proof',t=>{const r=temp(t);put(r,'outputs/other.json','{"ok":true}');put(r,'private_data/secret.json',JSON.stringify({...diag,createdAt:new Date().toISOString()}));assert.deepEqual(scanDiagnostics(r),[]);});

test('unverified send is uncertain even if a legacy diagnostic claims saving',()=>assert.equal(uncertainSend({...diag,send:{clicked:true,verified:false},save:{verified:true}}),true));
