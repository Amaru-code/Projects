@echo off
setlocal DisableDelayedExpansion
echo.
echo ==============================================================
echo  MCR RC1.1 QUELLE LOKAL SUCHEN, NUR PRUEFEN
echo ==============================================================
call "%~dp0tools\run.cmd" source-check
set "MCR_EXIT=%ERRORLEVEL%"
echo.
if not "%MCR_EXIT%"=="0" echo Datei fehlt noch - QUELLE_AUSWAEHLEN.cmd verwenden.
pause
exit /b %MCR_EXIT%
