@echo off
setlocal DisableDelayedExpansion
echo.
echo ============================================================== 
echo  MCR RC1.1 ORIGINALDATEI AUSWAEHLEN + SHA256 PRUEFEN
echo  KEIN COMARCH, KEIN TICKETVERSAND
echo ============================================================== 
echo.
call "%~dp0tools\run.cmd" source-select "%~1"
set "MCR_EXIT=%ERRORLEVEL%"
echo.
if not "%MCR_EXIT%"=="0" echo STOPP - Der Quellnachweis fehlt weiterhin.
echo.
pause
exit /b %MCR_EXIT%
