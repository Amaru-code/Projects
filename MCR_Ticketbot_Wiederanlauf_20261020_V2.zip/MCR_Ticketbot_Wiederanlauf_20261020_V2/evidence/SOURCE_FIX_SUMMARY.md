# V2 Source recovery fix

Issue: `CANDIDATE_NOT_FOUND` after `REPAIR_KIT_INTEGRITY` and `NO_OTHER_BOT_PROCESS`.

Scope: source discovery only. Original installed bot stays unchanged and cannot be started using unverified code.

Added `tools/source-locator.mjs` (read-only extended search), `tools/select-source.mjs` (local picker/drag-and-drop SHA pin), `QUELLE_SUCHEN_OHNE_VERSAND.cmd`, `QUELLE_AUSWAEHLEN.cmd`.

Source authority: RC1.1 archive SHA in `PINS.archives` and its nested runner's exact `PINS.candidate` SHA. Loose runner candidate must match byte-for-byte.

Actual source bytes are not shipped. If source is absent, download earlier RC1.1 original to the Windows machine. No automagic bypass, no network download, no claim of resumed COMARCH operation.

Current Linux tests: 96 core/recovery tests PASS, 18 source locator tests PASS. Local Windows verification pending.
