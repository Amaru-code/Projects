/* MCR identity evidence beta5 candidate: pure, local, no I/O or network.
 * Never treat contextual/quoted numbers as mandatory MercerIDs.
 * Never accept a member ID without a matching person name.
 */
'use strict';

const fold = value => String(value ?? '')
  .normalize('NFC')
  .replace(/\u00a0/g, ' ')
  .replace(/Ä/g, 'Ae').replace(/Ö/g, 'Oe').replace(/Ü/g, 'Ue')
  .replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue')
  .replace(/ß/g, 'ss')
  .toLocaleLowerCase('de-DE')
  .replace(/[.,]/g, '')
  .replace(/\s+/g, ' ').trim();

function error(code, message) {
  return Object.assign(new Error(message), {code});
}

/* A reply's older correspondence is not evidence about the CURRENT requester.
 * Ignore explicit IDs after common reply separators, and >-prefixed lines.
 */
function currentBodyPart(body) {
  const lines = String(body ?? '').replace(/\r\n?/g, '\n').split('\n');
  const current = [];
  const separator = /^(?:\s*>|\s*-{2,}\s*(?:original message|urspruengliche nachricht|ursprüngliche nachricht|weitergeleitete nachricht|forwarded message)|\s*on\s.{3,180}\swrote\s*:|\s*am\s.{3,180}\sschrieb(?:\s+[^:\r\n]{1,180})?\s*:|\s*(?:von|from)\s*:\s*\S+.{0,150}@)/i;
  for (const line of lines) {
    if (separator.test(line)) break;
    current.push(line);
  }
  return current.join('\n');
}

function explicitIds(text) {
  const result = new Set();
  const patterns = [
    /\bINTL01-(\d{1,15})(?![\w.-])/gi,
    /\b(?:Mercer\s*ID|Client\s*EE\s*ID)\s*(?:[:=#]|\s)\s*(?:INTL01-)?(\d{1,15})(?![\w.-])/gi
  ];
  for (const re of patterns) {
    for (const match of String(text ?? '').matchAll(re)) {
      if (!/^0+$/.test(match[1])) result.add(match[1]);
    }
  }
  return [...result];
}

function buildEvidence(mail, allHints = []) {
  if (!mail || typeof mail !== 'object') throw error('MAIL_ID_EVIDENCE', 'Mail fehlt.');
  const subject = String(mail.subject ?? '');
  const current = currentBodyPart(mail.body);
  const candidates = explicitIds(subject + '\n' + current);
  if (candidates.length > 1) {
    throw error('MAIL_ID_AMBIGUOUS', 'Mehrere ausdrueckliche MercerIDs in der aktuellen Nachricht. Manuelle Pruefung erforderlich.');
  }
  const hints = Array.isArray(allHints) ? allHints : [];
  const supplementalIds = new Set();
  for (const hint of hints) {
    if (hint && /^\d{1,15}$/.test(String(hint.clientId ?? ''))) supplementalIds.add(String(hint.clientId));
  }
  // These counts may enter the privacy-safe diagnostic; values must not.
  return Object.freeze({
    expectedId: candidates[0] ?? null,
    mode: candidates.length ? 'CURRENT_EXPLICIT_ID' : 'NAME_AND_COMARCH_ONLY',
    hasExplicit: candidates.length === 1,
    weakerHintCount: supplementalIds.size,
    quotedOrContextualHintsNotBinding: true
  });
}

function memberNameMatches(selected, person) {
  if (!selected || !person || !person.firstName || !person.lastName || !/^\d{1,15}$/.test(String(selected.id ?? ''))) return false;
  if (selected.source === 'PROFILE_ROWS') {
    return fold(selected.firstName) === fold(person.firstName) && fold(selected.lastName) === fold(person.lastName);
  }
  if (selected.source !== 'MEMBER_FIELD') return false;
  const display = String(selected.display ?? '').split(/\s*\(?INTL01-\d{1,15}\b/i)[0].trim().replace(/[\s(,-]+$/, '');
  const v = fold(display);
  return Boolean(v) && [fold(person.lastName + ' ' + person.firstName), fold(person.lastName + ', ' + person.firstName), fold(person.firstName + ' ' + person.lastName)].includes(v);
}

function requireMatched(selected, person, evidence) {
  if (!memberNameMatches(selected, person)) {
    throw error('MEMBER_NAME_MISMATCH', 'Name und eindeutige COMARCH-Member-Zuordnung passen nicht zusammen. Keine automatische Bearbeitung.');
  }
  if (evidence?.expectedId && String(selected.id) !== evidence.expectedId) {
    throw error('MEMBER_ID_CONFLICT', 'Aktuelle Mail nennt ausdruecklich eine andere MercerID als COMARCH. Manuelle Pruefung erforderlich.');
  }
  return true;
}

module.exports = Object.freeze({fold, currentBodyPart, explicitIds, buildEvidence, memberNameMatches, requireMatched});
