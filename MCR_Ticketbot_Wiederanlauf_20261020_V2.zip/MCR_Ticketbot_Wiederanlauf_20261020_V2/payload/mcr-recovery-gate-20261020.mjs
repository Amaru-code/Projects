/* This gate executes before the original runner's other imports. No network. */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const fail=()=>{throw Object.assign(new Error('RECOVERY_CONTROLLED_START_REQUIRED: Bitte den Wiederanlauf-Starter verwenden.'),{code:'RECOVERY_CONTROLLED_START_REQUIRED'});};
const hash=x=>crypto.createHash('sha256').update(x).digest('hex');
try {
  const p=path.join(root,'.mcr-recovery-20261020','session.json');
  if(fs.lstatSync(p).isSymbolicLink()) fail();
  const s=JSON.parse(fs.readFileSync(p,'utf8'));
  if(s.schema!=='MCR_CONTROLLED_RUN_V1'||s.parentPid!==process.ppid||!process.env.MCR_RECOVERY_SESSION||hash(process.env.MCR_RECOVERY_SESSION)!==s.tokenSha256) fail();
  if(!Number.isFinite(s.createdAtMs)||Date.now()-s.createdAtMs>60000||s.createdAtMs>Date.now()+2000) fail();
  const demo=process.argv.includes('--demo');
  if(!['DEMO','PILOT','QUEUE'].includes(s.mode)||demo!==(s.mode==='DEMO')) fail();
  if((s.mode==='PILOT'&&process.env.MCR_MAX_TICKETS!=='1')||(s.mode==='QUEUE'&&process.env.MCR_MAX_TICKETS!=='100')) fail();
  if(!s.hashes||typeof s.hashes!=='object'||Object.keys(s.hashes).length<4) fail();
  for(const [rel,expected] of Object.entries(s.hashes)) {
    if(!/^(src|lib)\/[A-Za-z0-9_./-]+$/.test(rel)||rel.split('/').includes('..')||!/^[a-f0-9]{64}$/.test(expected)) fail();
    let p=root;
    for(const bit of rel.split('/')){p=path.join(p,bit);if(fs.lstatSync(p).isSymbolicLink())fail();}
    if(hash(fs.readFileSync(p))!==expected) fail();
  }
  // One process consumes each session. Parent retains its separate operation lock.
  fs.unlinkSync(p);
  delete process.env.MCR_RECOVERY_SESSION;
} catch { fail(); }
