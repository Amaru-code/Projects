import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';
import {ROOT} from './helpers.mjs';
import {VERSION} from '../lib/control.mjs';
import {sha256} from '../lib/core.mjs';
import {verifyPackage} from '../tools/integrity.mjs';

test('RC47 pins the original complete RC46 manifest byte for byte, and adds only targeted upload logic',()=>{
 assert.equal(VERSION,'0.8.1-rc.49');
 const m=JSON.parse(fs.readFileSync(path.join(ROOT,'MANIFEST.json')));
 const previous=fs.readFileSync(path.join(ROOT,'tools/reference/complete-0.8.1-rc.46-manifest.json'));
 assert.equal(sha256(previous),'3640d26d3acd4f9b9265c7c6b3b7745595f436259864cd247c316a699aa68a79');
 assert.equal(JSON.parse(previous).version,'0.8.1-rc.46');
 assert.equal(m.version,VERSION);assert.equal(JSON.parse(fs.readFileSync(path.join(ROOT,'package.json'))).version,VERSION);
 for(const file of ['tests/rc47-two-ponds-browser.test.mjs','tests/rc47-release-contract.test.mjs',
  'tests/rc47-upgrade.test.mjs','tools/reference/complete-0.8.1-rc.46-manifest.json',
  'lib/phase2-filepond.mjs','tests/rc45-filepond-browser.test.mjs','lib/migration-priority.mjs'])
  assert(m.payload.some(x=>x.path===file),'Required regression/reference missing: '+file);
 assert(m.payload.every(x=>! /^(?:private_data|\.runtime|diagnostics|Ergebnis|reports)\//i.test(x.path)));
 assert(m.payload.every(x=>! /(?:^|\/)complete-0\.8\.1-rc\.\d+\.zip$/i.test(x.path)));
 assert.equal(verifyPackage(ROOT).version,VERSION);
});

test('RC47 no blanket MULTIPLE_FILEPOND_ROOTS rejection while true duplicate matches still block',()=>{
 const source=fs.readFileSync(path.join(ROOT,'lib/phase2-filepond.mjs'),'utf8');
 assert(!source.includes("source='MULTIPLE_FILEPOND_ROOTS'"));
 assert(source.includes("if(count>1)"));
 assert(source.includes("if(hiddenCount)"));
 assert(source.includes("if(ponds.length===1)"));
});
