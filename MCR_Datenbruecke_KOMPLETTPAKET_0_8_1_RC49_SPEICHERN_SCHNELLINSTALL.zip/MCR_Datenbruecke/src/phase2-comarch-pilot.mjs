/** RC39 independent PHASE-2 supervised ONE-TICKET pilot. No Phase-1 send
 * orchestration, no automatic rerun, no arbitrary PDF generation.
 * Supports only an earlier operator-reviewed proof for DC and/or PP+.
 */
import fs from 'node:fs';import path from 'node:path';import readline from 'node:readline/promises';
import {fileURLToPath} from 'node:url';
import {requireThat as need} from '../lib/core.mjs';
import {readJSON,writeJSON,plainPath,ledger,stamp} from '../lib/control.mjs';
import {resolveConfig} from '../lib/config.mjs';import {loadActiveMapping} from '../lib/active-mapping.mjs';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachFreshPage,sleep} from '../lib/cdp.mjs';
import {phase2Inventory,readPhase2Queue,classifyPhase2Row} from '../lib/phase2-readonly.mjs';
import {inspectExistingStatements} from '../lib/phase2-pdf-evidence.mjs';
import {phase2DraftPreview} from '../lib/phase2-draft-preview.mjs';
import {readPhase2MemberEvidence} from '../lib/phase2-member-evidence.mjs';
import {phase2Journal,digestDescription} from '../lib/phase2-write-journal.mjs';
import {setPhase2Gevo,selectReviewMode,
 selectReviewAssignee,savePhase2Draft,savePhase2Ticket,executeReview,phase2FieldSnapshot,reviewAssignmentState} from '../lib/phase2-comarch-actions.mjs';
import {forwardingNotices,forwardConfirmed} from '../lib/forwarding.mjs';
import {ensurePhase2UploadSurface,phase2AttachmentEvidence,attachPhase2Files,phase2ReviewableAttachmentEvidence} from '../lib/phase2-filepond.mjs';
import {planPhase2UploadContinuation} from '../lib/phase2-upload-continuation.mjs';
import * as UI from '../lib/browser-workflow.mjs';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const normalize=s=>String(s??'').replace(/\r\n?/g,'\n').trim();
async function ask(rl,q){return String(await rl.question(q)).trim();}
function phase2Dir(root){const p=path.join(root,'.runtime','phase2');plainPath(p);return p;}
function proofForTicket(root,id){
 const dir=phase2Dir(root),files=fs.readdirSync(dir).filter(f=>f.startsWith('MCR_PHASE2_PDF_BELEG_'+id+'_')&&f.endsWith('.json')).sort().reverse();
 need(files.length,'P2_PDF_PROOF_REQUIRED','Erst Menue 11 mit lokaler Inhaltspruefung abschliessen.');
 const proof=readJSON(path.join(dir,files[0]),256*1024);
 need(proof.schema==='MCR_PHASE2_PDF_PROOF_V1'&&proof.ticketId===id&&proof.operatorContentReviewed===true&&proof.operatorPersonTicketBindingReviewed===true,
  'P2_PDF_PROOF_INVALID','PDFs nicht ausreichend geprueft.');
 need(Date.now()-Date.parse(proof.verifiedAt)<7*24*60*60*1000,'P2_PDF_PROOF_OLD','PDF-Inhaltspruefung veraltet, Menue 11 erneut ausfuehren.');
 const ids=(proof.artifacts||[]).map(x=>/^(\d{4,15})_Kontoauszug_(DC|PP\+)\.pdf$/i.exec(x.name));
 need(ids.length===proof.artifacts.length&&ids.every(Boolean)&&new Set(ids.map(m=>m[1])).size===1,
  'P2_WWID_FILENAMES','Nur exakte WWID-Dateinamen mit identischer Personkennung.');
 const wwid=ids[0][1],verified=inspectExistingStatements(root,proof.targets,wwid);
 need(verified.artifacts.length===proof.artifacts.length&&verified.artifacts.every((a,i)=>{
  const expected=proof.artifacts.find(x=>x.plan===a.plan);return expected&&expected.sha256===a.sha256&&expected.bytes===a.bytes&&expected.name===a.name;
 }), 'P2_PDF_CHANGED','Pruefbelege oder PDFs wurden seit Menue 11 veraendert.');
 return {proof,verified,wwid};
}
/** Read-only RC49 canonicalization for a pending RC48 save. A saved marker
 * may have appeared during Entwurf speichern; only a bound old journal can
 * reconstruct the original, and only if its complete digest still matches. */
export function restorePendingSaveCandidate(item,previous){
 if(item?.kind!=='ALREADY_PREPARED'||previous?.state!=='TICKET_SAVE_INTENT')return item;
 const lines=String(item.descriptionValue||'').replace(/\r\n?/g,'\n').replace(/\n+$/,'').split('\n');
 need(lines.at(-1)?.trim()==='Bearbeitet not reviewed'&&
  lines.filter(x=>x.trim()==='Bearbeitet not reviewed').length===1,
  'P2_SAVE_RECOVERY_MARKER','Keine einzelne exakt angehaengte Statuszeile im Server-Ticket.');
 const original=lines.slice(0,-1).join('\n');
 need(digestDescription(original)===previous.descriptionSha256,'P2_SAVE_RECOVERY_DESCRIPTION_HASH',
  'Die urspruengliche Ticketbeschreibung stimmt nicht mit dem unveraenderten Journal ueberein.');
 const classified=classifyPhase2Row({...item,descriptionValue:original});
 need(classified.kind==='NEEDS_VERIFIED_WWID','P2_SAVE_RECOVERY_SOURCE',
  'Das Server-Ticket ist nicht mehr derselbe Kontoauszug-Vorgang.');
 return {...item,kind:classified.kind,targets:classified.targets,descriptionValue:original,
  preexistingSavedMarker:true};
}

export function preflightPhase2Write(root,ticketId){
 const inventory=readJSON(path.join(phase2Dir(root),'MCR_PHASE2_LETZTE_INVENTUR.json'),2*1024*1024);
 need(inventory?.schema==='MCR_PHASE2_INVENTORY_V1'&&inventory.readOnly,'P2_INVENTORY_REQUIRED','Menue 9 erneut ausfuehren.');
 need(Date.now()-Date.parse(inventory.generatedAt)<60*60*1000,'P2_INVENTORY_STALE','Bitte frische Inventur ueber Menue 9.');
 let item=inventory.items.find(x=>x.ticketId===ticketId);
 // Entwurf speichern may already persist the fourth line. Never infer an
 // original ticket text except by exact match to the existing save journal.
 const previous=phase2Journal(root,ticketId).read();
 item=restorePendingSaveCandidate(item,previous);
 need(item?.kind==='NEEDS_VERIFIED_WWID','P2_TICKET_BLOCKED','Kein eindeutig vorbereiteter Kontoauszug-Kandidat.');
 need(!ledger(root).pending.some(x=>x.ticketId===ticketId),'P2_PHASE1_JOURNAL_PENDING','Phase-1-Journal noch ungeklärt.');
 const {proof,verified,wwid}=proofForTicket(root,ticketId);
 need(item.targets.length===proof.targets.length&&item.targets.every(x=>proof.targets.includes(x)),
  'P2_PLAN_CONFLICT','COMARCH-Planarten und PDF-Pruefung widersprechen sich.');
 const preview=phase2DraftPreview({ticketId,source:item.source,description:item.descriptionValue,pdfProof:proof});
 const initial={ticketId,descriptionSha256:digestDescription(item.descriptionValue),pdfHashes:proof.artifacts.map(x=>({plan:x.plan,sha256:x.sha256}))};
 const journal=phase2Journal(root,ticketId,{initial});
 const existing=journal.read();
 // RC45 also permits inspection of an upload-first interruption. This does
 // not authorize a file selection: current attachments and the operator's
 // independent review must be reconciled below before the journal advances.
 const recoveryMode=!existing?null:journal.mayRetryGevoFocus(initial)?'GEVO_FOCUS':
  journal.mayReconcileUpload(initial)?'UPLOAD_RECONCILIATION':
  journal.mayRecoverTicketSave(initial)?'TICKET_SAVE_ONLY':null;
 const recoveryNeeded=!!existing;
 need(!existing||recoveryMode,'P2_ALREADY_ATTEMPTED',
  'Phase-2-Aktion begonnen oder abgeschlossen. Nur ein genau gepruefter Fokus-, Upload- oder vor dem Speicherklick abgebrochener Phase-2-Schritt ist kontrolliert fortsetzbar.');
 return {item,proof,verified,wwid,preview,journal,initial,recoveryNeeded,recoveryMode};
}

/** Intentionally every stage is a distinct monotonic ledger state.
 * Browser/OS crashes leave the last INTENT state requiring manual review.
 */
export async function phase2ComarchPilot({root=ROOT,askFn=ask,log=console.log,memberLookup=readPhase2MemberEvidence}={}){
 loadActiveMapping(root);
 const rl=readline.createInterface({input:process.stdin,output:process.stdout});
 let browser=null,cdp=null,armed=false;
 try{
  log('\nPHASE 2: Einzelticket-Pilot. KEINE E-MAIL, keine Generatorausfuehrung.');
  const id=await askFn(rl,'Vorbereitetes Kontoauszug-Ticket (z.B. 87278094): ');
  need(/^\d{6,12}$/.test(id),'P2_TICKET_ID','Ticketnummer erforderlich.');
  const {item,proof,verified,wwid,preview,journal,initial:journalInput,recoveryMode}=preflightPhase2Write(root,id);
  log('TICKET '+id+' | '+item.targets.join('+')+' | '+wwid+' | '+verified.artifacts.map(x=>x.name).join(' + '));
  const cfg=resolveConfig(root),exe=findEdgeExecutable(cfg.edgePath);need(exe,'P2_EDGE','Edge fehlt.');
  browser=await launchBrowser({executable:exe,userDataDir:cfg.profileDirectory,startUrl:'about:blank'});
  ({cdp}=await connectBrowser(browser.port));const page=await attachFreshPage(cdp,cfg.comarchUrl);
  need((await askFn(rl,'In Bot-Edge anmelden. COMARCH bereit? START / ABBRUCH: ')).toUpperCase()==='START',
   'P2_OPERATOR_ABORT','Keine Bearbeitung gestartet.');
  await UI.navigateToScope(page,'IN_BEARBEITUNG',{startup:true});
  const raw=await readPhase2Queue(page);need(raw.ok,'P2_QUEUE',raw.reason||'COMARCH-Vorgangsliste nicht lesbar.');
  const row=raw.rows.find(x=>x.ticketId===id);need(row,'P2_NOT_IN_TASKS','Ticket ist nicht mehr in Meine Vorgaenge.');
  const same=phase2Inventory([row],{pendingIds:ledger(root).pending.map(x=>x.ticketId)}).items[0];
  const sameOriginal=same.kind==='NEEDS_VERIFIED_WWID'&&normalize(row.descriptionValue)===normalize(item.descriptionValue);
  const sameSaved=recoveryMode==='TICKET_SAVE_ONLY'&&item.preexistingSavedMarker===true&&
   same.kind==='ALREADY_PREPARED'&&normalize(row.descriptionValue)===normalize(preview.descriptionAfter);
  need(sameOriginal||sameSaved,'P2_TICKET_CHANGED','Ticketstatus/Anfrage veraendert. Bitte Menue 9 erneut.');
  await UI.openTicket(page,row);await UI.assertTicket(page,id);
  const member=await memberLookup(page);
  need(member.profileVerified&&member.profile?.first&&member.profile?.last,'P2_MEMBER_NOT_BOUND','Kein eindeutiges COMARCH-Memberprofil.');
  need(!member.wwid||member.wwid===wwid,'P2_WWID_MISMATCH','Explizite COMARCH-WWID unterscheidet sich von beiden PDFs.');
  need(member.wwid||!member.memberReferenceWwid||member.memberReferenceWwid===wwid,'P2_MEMBER_REFERENCE_MISMATCH',
   'INTL01-Referenz aus dem ausgewaehlten Member stimmt nicht mit der bereits geprueften PDF-WWID ueberein.');
  await UI.ensureEdit(page);await UI.assertTicket(page,id);
  const expectedFixed={responsibility:'Second Level',category:'Allgemeine Schriftwechsel',subcategory:'Personenschriftwechsel'};
  const fixedOkay=f=>Object.entries(expectedFixed).every(([k,v])=>String(f?.[k]||'').trim()===v);
  if(!fixedOkay(await UI.fixedFieldValues(page))){
   log('PFLICHTFELDER: In COMARCH Second Level / Allgemeine Schriftwechsel / Personenschriftwechsel exakt setzen. Keine E-Mail senden.');
   need((await askFn(rl,'Pflichtfelder geprueft? ENTER / ABBRUCH: ')).toUpperCase()!=='ABBRUCH',
    'P2_OPERATOR_ABORT','Pflichtfelder nicht freigegeben.');
  }
  need(fixedOkay(await UI.fixedFieldValues(page)),'P2_FIXED_FIELDS','COMARCH-Pflichtfelder nicht eindeutig eingestellt.');
  const initial=await UI.additionalDescriptionState(page);
  need(initial.ok&&initial.editable&&
   (normalize(initial.value)===normalize(item.descriptionValue)||
    (recoveryMode==='TICKET_SAVE_ONLY'&&normalize(initial.value)===normalize(preview.descriptionAfter))),
   'P2_DESCRIPTION_CHANGED','Ticketbeschreibung weicht vom genehmigten Original oder der genau einmal ergaenzten Statuszeile ab.');
  const names=verified.artifacts.map(a=>a.name);
  const bound=()=>UI.assertTicket(page,id);
  const assertUnchanged=()=>{const now=inspectExistingStatements(root,item.targets,wwid);
   need(now.artifacts.length===verified.artifacts.length&&now.artifacts.every(a=>{
    const p=verified.artifacts.find(x=>x.plan===a.plan);return p?.sha256===a.sha256&&p?.bytes===a.bytes;
   }),'P2_PDF_CHANGED','PDF-Dateien seit Freigabe geaendert. Keine weitere COMARCH-Aktion.');};
  const currentUploadPlan=async()=>{
   const evidence=await phase2AttachmentEvidence(page,names);
   try{return planPhase2UploadContinuation({artifacts:verified.artifacts,evidence,
    resumeUpload:recoveryMode==='UPLOAD_RECONCILIATION'});}
   catch(e){log('P2_ATTACHMENT_EVIDENCE: '+JSON.stringify({rootCount:evidence.rootCount,items:evidence.items}));throw e;}
  };
  let operatorUiApproved=false;
  const saveManual=async()=>{
   journal.recordTicketSaveManualIntent();
   log('P2_SPEICHERN_MANUELL: Ticket speichern ist trotz passiver Scroll-/Hit-Test-Pruefung verdeckt.');
   log('Im EIGENEN Bot-Edge genau EINMAL Ticket speichern anklicken. Der Bot fuehrt dann KEINEN weiteren Speicherklick aus.');
   need((await askFn(rl,'Genau ein manueller Speicherklick ausgefuehrt? EINMAL_GEKLICKT / ABBRUCH: ')).toUpperCase()==='EINMAL_GEKLICKT',
    'P2_SAVE_CLICK_UNCLEAR','Manueller Speicherklick ungeklaert; Journal bleibt zur Sichtpruefung gesperrt.');
  };
  const checkSaved=async()=>{
   for(let z=0;z<70;z++){
    try{await UI.navigateToScope(page,'IN_BEARBEITUNG',{refresh:true});const r=await readPhase2Queue(page);
     if(r.ok){const current=r.rows.find(x=>x.ticketId===id);
      if(current&&normalize(current.descriptionValue)===normalize(preview.descriptionAfter))return true;}}
    catch{}await sleep(300);
   }
   return false;
  };
  if(recoveryMode==='TICKET_SAVE_ONLY'){
   // The prior observed ACTION_OCCLUDED_OR_OFFSCREEN never issued mouseClick.
   // However, this was not journaled at the time: require fresh independent
   // operator review, an unchanged ticket, and a new one-time approval.
   log('P2_RC48_SAVE_WIEDERAUFNAHME: GEVO und Entwurf sind bereits im alten Journal. KEINE PDFs erneut auswaehlen, KEINEN Entwurf erneut speichern.');
   await bound();assertUnchanged();
   const existing=await phase2AttachmentEvidence(page,names);
   need(existing.allReady||phase2ReviewableAttachmentEvidence(existing,names),
    'P2_SAVE_RECOVERY_ATTACHMENTS','Beide PDFs im wiedergeoeffneten Ticket nicht eindeutig sichtbar; kein erneuter Upload.');
   operatorUiApproved=!existing.allReady;
   const g=await phase2FieldSnapshot(page);
   need(g.gevo.count===1&&g.gevo.value==='Anfrage Member','P2_SAVE_RECOVERY_GEVO',
    'Anfrage Member wurde im wiedergeoeffneten Ticket nicht bestaetigt. Kein erneuter GEVO-Schreibversuch.');
   const desc=await UI.additionalDescriptionState(page);
   need(desc.ok&&desc.editable&&[normalize(item.descriptionValue),normalize(preview.descriptionAfter)].includes(normalize(desc.value)),
    'P2_SAVE_RECOVERY_DESCRIPTION','Status oder Originalbeschreibung nicht eindeutig wiederhergestellt.');
   log('Pruefe exakt Ticket '+id+', die beiden PDF-Inhalte, Anfrage Member und den RC48-Fehler vor dem Speicherklick.');
   need((await askFn(rl,'Sicher KEIN Ticket-Speicherklick/keine Weiterleitung im vorigen Lauf und beide PDFs geprueft? SAVE_OHNE_KLICK_GEPRUEFT / ABBRUCH: ')).toUpperCase()==='SAVE_OHNE_KLICK_GEPRUEFT',
    'P2_SAVE_RECOVERY_DECLINED','Keine Wiederholung ohne unabhaengige Freigabe.');
   await bound();assertUnchanged();
   need((await phase2AttachmentEvidence(page,names)).allReady||
    phase2ReviewableAttachmentEvidence(await phase2AttachmentEvidence(page,names),names),
    'P2_SAVE_RECOVERY_CHANGED','Anlagenzustand seit Sichtpruefung veraendert.');
   journal.approveTicketSaveRecovery({...journalInput,operatorConfirmed:true,noPriorClick:true,ticketUnchanged:true,
    attachmentsReviewed:true,notForwarded:true});armed=true;
   if(sameSaved){
    need(normalize(desc.value)===normalize(preview.descriptionAfter),'P2_SAVE_ALREADY_PERSISTED_CONFLICT',
     'Server zeigt Statuszeile, Ticketeditor weicht ab. Keine weitere Aktion.');
    log('P2_SAVE_SERVER_ROW_ALREADY_UPDATED: Gepruefter Eintrag bereits serverseitig in Meine Vorgaenge; kein neuer Ticket-Speicherklick.');
    journal.advance('TICKET_SAVE_VERIFIED');log('P2_JOURNAL TICKET_SAVE_VERIFIED');
   }else{
   if(normalize(desc.value)===normalize(item.descriptionValue)){
    const update=await UI.appendStandardAnswerMarker(page,'Bearbeitet not reviewed');
    need(update.ok&&normalize(update.value)===normalize(preview.descriptionAfter),'P2_SAVE_RECOVERY_MARKER','Statuszeile nicht hergestellt.');
   }
   need(await UI.verifyDescription(page,preview.descriptionAfter),'P2_SAVE_RECOVERY_MARKER','Statuszeile nicht exakt.');
   log('P2_SAVE_ONLY: Kein neuer Upload, keine GEVO-Neuauswahl, kein neuer Entwurf-Speicherklick.');
   await bound();await savePhase2Ticket(page,{manualClick:saveManual});
   need(await checkSaved(),'P2_SAVE_UNVERIFIED','COMARCH hat den einmaligen Speicherklick nicht nachweislich uebernommen. Nicht wiederholen.');
   journal.advance('TICKET_SAVE_VERIFIED');log('P2_JOURNAL TICKET_SAVE_VERIFIED');
   } // End the controlled one-click save recovery
  }else{
  // A collapsed, but already populated, attachment area is not an absence
  // proof. Open only its UI before classifying existing versus missing PDFs.
  const firstEvidence=await phase2AttachmentEvidence(page,names);
  let surface=null;
  if(!firstEvidence.allReady&&firstEvidence.items.every(e=>['READY','ABSENT','HIDDEN_UNVERIFIED'].includes(e.status))){
   surface=await ensurePhase2UploadSurface(page,{log});
   if(!surface.available){
    log('P2_ANHANGSBEREICH: Dokument anhaengen im Bot-Edge oeffnen, ohne Dateien auszuwaehlen.');
    need((await askFn(rl,'Anhangsbereich offen? ENTER / ABBRUCH: ')).toUpperCase()!=='ABBRUCH',
     'P2_OPERATOR_ABORT','Anhangsbereich nicht geoeffnet.');
    surface=await ensurePhase2UploadSurface(page,{log});
   }
   need(surface.available,'P2_UPLOAD_NOT_READY','Kein eindeutiger Anhangsbereich. Noch keine Dateiauswahl.');
  }
  let uploadPlan=await currentUploadPlan();
  log('COMARCH-MEMBER: '+member.profile.first+' '+member.profile.last+' | verifizierte PDF-WWID '+wwid+
   (member.memberReferenceWwid?' | INTL01-'+member.memberReferenceWwid+' im ausgewählten Member bestaetigt':' | Member hat keine eindeutig beschriftete WWID'));
  log('PDF-ANLAGE ZUERST: '+names.join(' + ')+' | '+(surface?.mode||'VORHANDENE_ANLAGEN')+'. Danach Anfrage Member und Speicherung.');
  log('Vorbereitung nur fuer dieses Ticket. Noch keine Datei uebergeben.');
  // One approval for new runs; for legacy GEVO_INTENT the operator must
  // independently rule out ANY earlier upload/save/forward side effects.
  if(recoveryMode==='UPLOAD_RECONCILIATION'){
   log('P2_TEILUPLOAD_PRUEFUNG: Vorhanden: '+(uploadPlan.existing.map(a=>a.name).join(' + ')||'keine')+
    ' | Fehlend: '+(uploadPlan.missing.map(a=>a.name).join(' + ')||'keine')+'.');
   log('Vorhandene PDFs im selben COMARCH-Ticket inhaltlich pruefen. Noch kein Entwurf-/Ticket-Speichern und keine Weiterleitung aus dem unterbrochenen Lauf.');
   need((await askFn(rl,'Anlagenbestand/Inhalt geprueft UND noch nicht gespeichert/weitergeleitet? ANHAENGE_GEPRUEFT_UND_FORTSETZEN / ABBRUCH: ')).toUpperCase()==='ANHAENGE_GEPRUEFT_UND_FORTSETZEN',
    'P2_UPLOAD_RECOVERY_DECLINED','Teilupload bleibt zur Pruefung erhalten. Keine Dateiauswahl wiederholt.');
   await bound();assertUnchanged();
   const unchanged=await UI.additionalDescriptionState(page);
   need(unchanged.ok&&unchanged.editable&&normalize(unchanged.value)===normalize(item.descriptionValue),
    'P2_DESCRIPTION_CHANGED','Ticket wurde waehrend der Anlagenpruefung veraendert.');
   const rechecked=await currentUploadPlan();
   need(JSON.stringify(rechecked.existing.map(a=>a.name))===JSON.stringify(uploadPlan.existing.map(a=>a.name)),
    'P2_UPLOAD_EVIDENCE_CHANGED','Anlagenbestand seit der Anzeige veraendert. Erneut unabhaengig pruefen.');
   uploadPlan=rechecked;
   journal.approveUploadReconciliation({...journalInput,operatorConfirmed:true,ticketUnchanged:true,noSaveOrForward:true,
    existingPlans:uploadPlan.existing.map(a=>a.plan),missingPlans:uploadPlan.missing.map(a=>a.plan)});
   log('PASS P2_UPLOAD_RECONCILED: '+uploadPlan.existing.length+' vorhandene PDF(s) beibehalten; '+uploadPlan.missing.length+' fehlende PDF(s) anhaengen.');
  }else if(recoveryMode==='GEVO_FOCUS'){
   log('P2_ALTES_GEVO_JOURNAL: Der RC41/RC42-Lauf hatte nur den GEVO-Fokus begonnen, bevor es irgendeine Upload-Absicht gab.');
   // Der alte Freigabecode GEVO_OHNE_AKTIONEN_GEPRUEFT wird durch eine einzige gemeinsame, strengere Freigabe ersetzt.
   log('Vor der Freigabe COMARCH ausserhalb des Bots pruefen: keine Anlage, kein gespeicherter Entwurf, kein Ticket-Speichern, keine Weiterleitung.');
   need((await askFn(rl,'Gleiches Ticket, PDFs, Rechte geprueft UND keinerlei fruehere Aktion erfolgt? PHASE2_FREIGABE_UND_WIEDERAUFNAHME / ABBRUCH: ')).toUpperCase()==='PHASE2_FREIGABE_UND_WIEDERAUFNAHME',
    'P2_GEVO_RECOVERY_DECLINED','Altes Journal bleibt gesperrt; keine wiederholte Dateianlage.');
   journal.approveGevoFocusRetry({...journalInput,operatorConfirmed:true,ticketUnchanged:true,noAttachments:true});
   log('PASS P2_LEGACY_FOCUS_RECOVERY_AUTHORIZED: Alter Journalstand wird ohne Reset fuer den FilePond-Upload fortgesetzt.');
  }else{
   need((await askFn(rl,'Originalvorgang, Member, WWID, PDF-Inhalt und Rechte geprueft? PHASE2_FREIGABE / ABBRUCH: ')).toUpperCase()==='PHASE2_FREIGABE',
    'P2_OPERATOR_ABORT','Keine Bearbeitung gestartet.');
   journal.begin();
  }
  armed=true;
  const advance=next=>{const val=journal.advance(next);log('P2_JOURNAL '+next);return val;};
  if(recoveryMode!=='UPLOAD_RECONCILIATION')advance('UPLOAD_INTENT');await bound();
  const files=uploadPlan.missing.map(a=>a.file);
  assertUnchanged();
  let uploadResult=null;
  if(files.length)uploadResult=await attachPhase2Files(page,files,{log,
   beforeSelect:async({file,name})=>{
    await bound();assertUnchanged();
    const artifact=uploadPlan.missing.find(a=>a.file===file&&a.name===name);
    need(artifact,'P2_UPLOAD_FILE_BIND','Datei gehoert nicht zu den geprueften fehlenden Anlagen.');
    const snapshot=await phase2AttachmentEvidence(page,names);
    const target=snapshot.items.find(e=>e.name===name);
    need(target?.present===false&&target.count===0&&target.status==='ABSENT',
     'P2_UPLOAD_DUPLICATE','Diese PDF ist bereits vorhanden oder ihr Status ist unklar. Keine erneute Auswahl.');
    journal.recordUploadFileIntent(artifact);log('P2_DATEI_INTENT: '+name);
   },
   afterStaged:async({file,name,evidence})=>{
    const artifact=uploadPlan.missing.find(a=>a.file===file&&a.name===name);
    const item=evidence?.items?.find(e=>e.name===name);
    need(artifact&&item?.ready&&item.count===1,'P2_UPLOAD_FILE_EVIDENCE','Einzelanlage nicht eindeutig bestaetigt.');
    journal.recordUploadFileStaged({...artifact,source:item.source});log('PASS P2_DATEI_SICHTBAR: '+name);
   },
   afterProvisional:async({file,name,evidence})=>{
    const artifact=uploadPlan.missing.find(a=>a.file===file&&a.name===name);
    need(artifact&&evidence?.items?.[0]?.status==='UNBOUND_NAME',
     'P2_UPLOAD_PROVISIONAL','Dateiauswahl stimmt nicht mit dem Uploadplan ueberein.');
    journal.recordUploadFileProvisional(artifact);
    log('P2_DATEI_NICHT_AUTOMATISCH_VERIFIZIERT: '+name+' | Explorer-Auswahl erfolgt, Dateiname sichtbar, COMARCH-Anhangszuordnung offen.');
   }
  });
  let confirmed=false;
  for(let z=0;z<35;z++){
   const e=await phase2AttachmentEvidence(page,names);
   if(e.allReady){confirmed=true;break;}
   await sleep(200);
  }
  operatorUiApproved=false;
  if(!confirmed){
   const uncertain=await phase2AttachmentEvidence(page,names);
   need(phase2ReviewableAttachmentEvidence(uncertain,names)&&uploadResult?.provisionalNames?.length,
    'P2_UPLOAD_UNVERIFIED','Nicht alle PDFs sind im COMARCH-Ticket sichtbar; keine weiteren Aktionen.');
   log('P2_DATEIAUSWAHL_DOPPELT: Jede benoetigte PDF wurde ueber einen eigenen nativen Explorer-Dialog ausgewaehlt.');
   log('P2_MANUELLE_ANLAGENKONTROLLE: COMARCH zeigt Dateinamen ausserhalb erkannter Anhangszeilen.');
   log('Im Bot-Edge im Abschnitt Dokument anhaengen BEIDE Dateien und den Inhalt pruefen: '+names.join(' + '));
   need((await askFn(rl,'Beide neuen PDF-Anlagen im RICHTIGEN Ticket tatsaechlich sichtbar und inhaltlich geprueft? BEIDE_PDFS_SICHTBAR / ABBRUCH: ')).toUpperCase()==='BEIDE_PDFS_SICHTBAR',
    'P2_UPLOAD_REVIEW_DECLINED','Dateiauswahl bleibt im Journal; kein GEVO, keine Speicherung.');
   await bound();assertUnchanged();
   const checked=await phase2AttachmentEvidence(page,names);
   need(phase2ReviewableAttachmentEvidence(checked,names),
    'P2_UPLOAD_UI_CHANGED','Dateinamen nach der Sichtkontrolle veraendert. Keine Speicherung.');
   journal.recordUploadVisualReview({names});operatorUiApproved=true;
   log('PASS P2_UPLOAD_OPERATOR_UI_REVIEW: Beide PDFs im Uploadbereich manuell bestaetigt; serverseitige Speicherung noch nicht bewiesen.');
  }
  const stagingPresent=async()=>{
   const e=await phase2AttachmentEvidence(page,names);
   return e.allReady||(operatorUiApproved&&phase2ReviewableAttachmentEvidence(e,names));
  };
  assertUnchanged();advance('UPLOAD_VERIFIED');
  log('PASS P2_FILEPOND_FILES_STAGED: '+names.length+' PDF(s) vor GEVO sichtbar; '+
   (operatorUiApproved?'UI-Sichtpruefung durch Operator, serverseitige Speicherung offen':'automatische COMARCH-Anlagenzuordnung, serverseitige Speicherung offen')+'.');
  // Now enter the type of request – only after the PDFs were accepted by the
  // FilePond UI, as in the operator's actual workflow.
  advance('GEVO_INTENT');await bound();
  const f=await phase2FieldSnapshot(page);
  need(f.gevo.count===1&&f.gevo.visible&&f.gevo.enabled,'P2_GEVO_MISSING','Anfrage-Art-Feld fehlt nach PDF-Anlage.');
  await setPhase2Gevo(page,{
   manualFocus:async(reason)=>{
    log('P2_GEVO_MANUAL_FOCUS: '+reason+'. Nur GEVO im EIGENEN Bot-Edge fokussieren; keine andere Aktion.');
    need((await askFn(rl,'GEVO-Eingabefeld angeklickt? FOKUS / ABBRUCH: ')).toUpperCase()==='FOKUS',
     'P2_OPERATOR_ABORT','GEVO-Fokus nicht bestaetigt. Keine weiteren Aktionen.');
   },
   manualSelect:async()=>{
    log('Im COMARCH-Vorschlag genau Anfrage Member waehlen.');
    need((await askFn(rl,'Anfrage Member ausgewaehlt? AUSGEWAEHLT / ABBRUCH: ')).toUpperCase()==='AUSGEWAEHLT',
     'P2_OPERATOR_ABORT','Auswahl abgebrochen.');
   }
  });advance('GEVO_VERIFIED');
  need(await stagingPresent(),'P2_FILEPOND_LOST_AFTER_GEVO',
   'COMARCH hat nach Anfrage Member die ausgewaehlten PDF-Anlagen nicht mehr angezeigt. Keine Speicherung oder Wiederholung.');
  advance('DESCRIPTION_INTENT');await bound();
  const before=await UI.additionalDescriptionState(page);
  need(before.ok&&before.editable&&normalize(before.value)===normalize(item.descriptionValue),
   'P2_DESCRIPTION_CHANGED','Originaltext vor Statusaenderung nicht mehr identisch.');
  const update=await UI.appendStandardAnswerMarker(page,'Bearbeitet not reviewed');
  need(update.ok&&normalize(update.value)===normalize(preview.descriptionAfter),'P2_MARKER_WRITE','Vierte Zeile nicht sicher angehaengt.');
  need(await UI.verifyDescription(page,preview.descriptionAfter),'P2_MARKER_VERIFY','Mehrzeiliger Tickettext nicht eindeutig im Editor.');
  advance('DESCRIPTION_VERIFIED');
  advance('DRAFT_SAVE_INTENT');await bound();await savePhase2Draft(page);
  // A draft click alone does NOT prove server persistence. Require both names
  // in the COMARCH attachment area before permitting the final ticket save.
  need(await stagingPresent(),'P2_DRAFT_ATTACHMENTS_UNVERIFIED',
   'Entwurf nicht als dauerhaft angehaengt nachgewiesen; keine weitere Aktion.');
  advance('DRAFT_SAVE_VERIFIED');
  advance('TICKET_SAVE_INTENT');await bound();await savePhase2Ticket(page,{manualClick:saveManual});
  need(await checkSaved(),'P2_SAVE_UNVERIFIED','Ticketbeschreibung nach einem Speicherklick nicht bestaetigt. Keinen zweiten Speicherklick ausfuehren.');
  advance('TICKET_SAVE_VERIFIED');
  } // End regular PP+/DC upload/GEVO/draft path; save-only recovery rejoins here.

  log('PASS P2_DRAFT_AND_TICKET_SAVED: Tickettext gespeichert; dauerhafte PDF-Bestaetigung folgt nach erneutem Oeffnen.');
  // Review is explicitly gated and performed separately from saving.
  log('Pruefung: Beide Anhaenge und Entwurf in COMARCH jetzt visuell pruefen. Nicht selbst weiterleiten.');
  const choice=await askFn(rl,'An Mark Baindl zur Ueberpruefung weiterleiten? WEITERLEITEN / OFFEN_LASSEN: ');
  if(choice!=='WEITERLEITEN'){
   log('P2_OFFEN: Ticket gespeichert, Review noch nicht ausgefuehrt. Journal bleibt auf TICKET_SAVE_VERIFIED; kein automatischer Neustart.');
   return {ticketId:id,status:'SAVED_PENDING_REVIEW',journal:journal.file};
  }
  const current=await readPhase2Queue(page);const sameRow=current.rows?.find(r=>r.ticketId===id);
  need(sameRow,'P2_REVIEW_BIND','Nach Speichern ist das Ticket nicht mehr in Meine Vorgaenge.');
  await UI.openTicket(page,sameRow);await UI.assertTicket(page,id);
  need(fixedOkay(await UI.fixedFieldValues(page)),'P2_FIXED_NOT_SAVED','Pflichtfelder nach Speichern nicht mehr exakt. Keine Weiterleitung.');
  // RC49: the GEVO search input was verified before draft save; verify that
  // COMARCH still shows the *committed exact* value after reopening, too.
  let savedGevo=false;
  for(let z=0;z<15;z++){const g=await phase2FieldSnapshot(page);
   if(g.gevo.count===1&&g.gevo.visible&&g.gevo.value==='Anfrage Member'){savedGevo=true;break;}
   await sleep(200);
  }
  need(savedGevo,'P2_SAVED_GEVO_NOT_COMMITTED','Anfrage Member nach Ticket-Speichern nicht mehr exakt sichtbar. Keine Weiterleitung.');
  log('PASS P2_SAVED_GEVO_EXACT: Anfrage Member im wiedergeoeffneten Ticket.');
  // Reopen from server-backed task view to verify attachments survive save.
  const attachmentAfterReopen=await phase2AttachmentEvidence(page,names);
  if(!attachmentAfterReopen.allReady){
   need(operatorUiApproved&&phase2ReviewableAttachmentEvidence(attachmentAfterReopen,names),
    'P2_SAVED_ATTACHMENTS_NOT_VISIBLE',
    'Nach erneutem Oeffnen sind nicht alle PDF-Anlagen nachweisbar. Keine Weiterleitung.');
   log('P2_SERVER_ATTACHMENT_MANUAL_REVIEW: COMARCH zeigt im NEU geoefneten Ticket weiterhin nur ungebundene Dateinamen.');
   log('Pruefe im GEPEICHERTEN COMARCH-Ticket beide PDF-Anlagen und ihren Inhalt/WWID: '+names.join(' + '));
   need((await askFn(rl,'Beide PDFs nach erneutem Oeffnen als GESPEICHERTE Anlagen vorhanden und Inhalt kontrolliert? GESPEICHERTE_PDFS_GEPRUEFT / ABBRUCH: ')).toUpperCase()==='GESPEICHERTE_PDFS_GEPRUEFT',
    'P2_POST_SAVE_REVIEW_DECLINED','Keine Weiterleitung ohne gepruefte gespeicherte PDFs.');
   await bound();
   need(phase2ReviewableAttachmentEvidence(await phase2AttachmentEvidence(page,names),names),
    'P2_SAVED_ATTACHMENTS_CHANGED','Anlagenanzeige nach der manuellen Kontrolle veraendert. Keine Weiterleitung.');
   journal.recordPostSaveAttachmentReview({names});
   log('PASS P2_POST_SAVE_OPERATOR_ATTACHMENT_REVIEW: Nach erneutem Oeffnen manuell bestaetigt, nicht durch automatischen Downloadbeleg.');
  }
  const savedDescription=await UI.additionalDescriptionState(page);
  need(!savedDescription.ok||normalize(savedDescription.value)===normalize(preview.descriptionAfter),
   'P2_SAVED_DESCRIPTION_CHANGED','Tickettext nach erneutem Oeffnen veraendert.');
  assertUnchanged();
  advance('REVIEW_INTENT');await selectReviewMode(page);
  let visible=false;for(let z=0;z<35;z++){const a=await phase2FieldSnapshot(page);if(a.nextPersona.count===1&&a.nextPersona.visible&&a.nextPersona.enabled){visible=true;break;}await sleep(200);}
  need(visible,'P2_REVIEW_TARGET_FIELD','Prueferfeld mainForm:next-persona-assignment-id fehlt.');
  await selectReviewAssignee(page,{manualSelect:async()=>{
   log('Im Bot-Edge EXAKT Baindl Mark (mark.baindl) als Pruefer auswaehlen.');
   need((await askFn(rl,'Mark Baindl ausgewaehlt? ENTER / ABBRUCH: ')).toUpperCase()!=='ABBRUCH','P2_OPERATOR_ABORT','Pruefer abgebrochen.');
  }});
  need((await reviewAssignmentState(page)).ok,'P2_REVIEW_TARGET_CHANGED','Pruefer-Zuordnung nicht eindeutig.');
  advance('REVIEW_VERIFIED');
  const notices=await forwardingNotices(page);
  advance('EXECUTE_INTENT');await bound();await executeReview(page,{manualClick:async()=>{
   journal.recordReviewExecuteManualIntent();
   log('P2_PRUEFER_MANUELL: Schritt ausfuehren verdeckt. Nur im EIGENEN Bot-Edge einmal anklicken; keine E-Mail.');
   need((await askFn(rl,'Schritt ausfuehren genau einmal geklickt? EINMAL_AUSGEFUEHRT / ABBRUCH: ')).toUpperCase()==='EINMAL_AUSGEFUEHRT',
    'P2_REVIEW_CLICK_UNCLEAR','Weiterleitung ungeklaert, kein automatischer Zweitklick.');
  }});
  let evidence={ok:false};for(let z=0;z<40;z++){
   evidence=await forwardConfirmed(page,{display:'Baindl Mark',account:'mark.baindl'},notices);
   if(evidence.ok)break;await sleep(300);
  }
  need(evidence.ok,'P2_REVIEW_UNVERIFIED','Nach einem Schritt-Ausfuehren-Klick keine neue Erfolgsmeldung. Nicht wiederholen.');
  let absent=false;for(let z=0;z<25;z++){
   try{await UI.navigateToScope(page,'IN_BEARBEITUNG',{refresh:true});const r=await readPhase2Queue(page);if(r.ok&&!r.rows.some(x=>x.ticketId===id)){absent=true;break;}}catch{}
   await sleep(300);
  }
  need(absent,'P2_REVIEW_NOT_REMOVED','Weiterleitungsmeldung vorhanden, Ticket aber weiter in eigenen Vorgängen. Manuell prüfen.');
  advance('ROUTED_VERIFIED');
  const receipt={schema:'MCR_PHASE2_REVIEW_RECEIPT_V1',ticketId:id,status:'ROUTED_VERIFIED',reviewer:'mark.baindl',pdfHashes:proof.artifacts.map(x=>({plan:x.plan,sha256:x.sha256})),createdAt:new Date().toISOString()};
  const rec=path.join(phase2Dir(root),'MCR_PHASE2_ABSCHLUSS_'+id+'_'+stamp()+'.json');writeJSON(rec,receipt);
  log('PASS P2_REVIEW_ROUTE_VERIFIED | '+id+' | mark.baindl | '+rec);
  return receipt;
 }finally{rl.close();try{cdp?.close();}catch{}try{browser?.child?.kill();}catch{}if(armed)log('P2_AUDIT: Schreibjournal bleibt dauerhaft erhalten. Bei Unterbrechung keine automatische Wiederholung.');}
}
