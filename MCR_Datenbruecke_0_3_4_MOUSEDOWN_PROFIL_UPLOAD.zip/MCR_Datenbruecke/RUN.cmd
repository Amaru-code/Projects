@echo off
setlocal EnableExtensions DisableDelayedExpansion
pushd "%~dp0"
if errorlevel 1 exit /b 1
echo.
echo ==============================================================
echo  MCR Datenbruecke 0.3.4 - mousedown und MercerID-Ausgabe
echo ==============================================================
echo.
echo SCHRITT 1/2: Node.js suchen - noch KEINE Excel-Datei angeben.
echo Es werden nur bekannte lokale Programmordner geprueft.
echo Keine Installation, kein Download, keine Systemaenderung.
echo.
set "MCR_NODE="
set "MCR_CANDIDATE=%NODE_EXE%"
call :tryNode
set "MCR_CANDIDATE=%~dp0runtime\node.exe"
call :tryNode
set "MCR_CANDIDATE=%~dp0runtime\node\node.exe"
call :tryNode
set "MCR_CANDIDATE=%~dp0..\runtime\node.exe"
call :tryNode
set "MCR_CANDIDATE=%~dp0..\runtime\node\node.exe"
call :tryNode
set "MCR_CANDIDATE=%~dp0node.exe"
call :tryNode
set "MCR_CANDIDATE=%USERPROFILE%\projects\Compiler\javascript\tools\node\node.exe"
call :tryNode
set "MCR_CANDIDATE=%USERPROFILE%\projects\Aktive_Projekte\node\tools\node\node.exe"
call :tryNode
set "MCR_CANDIDATE=%ProgramFiles%\nodejs\node.exe"
call :tryNode
set "MCR_CANDIDATE=%LOCALAPPDATA%\Programs\nodejs\node.exe"
call :tryNode
if not defined MCR_NODE for /f "delims=" %%I in ('where node.exe 2^>nul') do (
 set "MCR_CANDIDATE=%%I"
 call :tryNode
)
if defined MCR_NODE goto nodeReady

:askNode
echo.
echo Node.js wurde an den geprueften Orten nicht gefunden.
echo HIER wird die PROGRAMMDATEI node.exe benoetigt, NICHT die Excel-Datei.
echo Moeglicher vorhandener Compiler-Pfad:
echo "%USERPROFILE%\projects\Compiler\javascript\tools\node\node.exe"
echo.
set "MCR_CANDIDATE="
set /p "MCR_CANDIDATE=Pfad zu node.exe - Enter bricht ab: "
if not defined MCR_CANDIDATE goto cancelled
call :tryNode
if defined MCR_NODE goto nodeReady
echo.
echo FEHLER: Keine verwendbare node.exe ab Version 22.15 ausgewaehlt.
echo Eine Excel-Datei oder ein Ordner wird NICHT gestartet.
echo Bitte nur den Pfad zu einer vorhandenen, vertrauten node.exe eingeben.
goto askNode

:nodeReady
echo.
echo Node.js erfolgreich geprueft:
echo "%MCR_NODE%"
echo.
"%MCR_NODE%" src\verify-package.mjs
if errorlevel 1 goto failed
if /i "%~1"=="test" goto runTests
if /i "%~1"=="check" goto runCheck
if /i "%~1"=="demo" goto runDemo
echo.
echo SCHRITT 2/2: Jetzt folgt die Frage nach der EXCEL-DATEI .xlsx.
echo Hier darf der Pfad deiner lokalen Datei oder der K:-Pfad stehen.
echo Excel wird dafuer nicht geoeffnet. Die Datei wird nur gelesen.
"%MCR_NODE%" src\export-mapping.mjs
set "MCR_RESULT=%ERRORLEVEL%"
goto finished

:runCheck
"%MCR_NODE%" src\check-member.mjs
set "MCR_RESULT=%ERRORLEVEL%"
goto finished

:runDemo
"%MCR_NODE%" src\export-mapping.mjs --demo
set "MCR_RESULT=%ERRORLEVEL%"
goto finished

:runTests
"%MCR_NODE%" --test tests\core.test.mjs tests\xlsx.test.mjs tests\bridge.test.mjs tests\starter.test.mjs tests\sheetfix.test.mjs tests\msg.test.mjs tests\mail_static.test.mjs tests\memberfix.test.mjs tests\blankselect.test.mjs tests\widget_static.test.mjs tests\discovery.test.mjs
set "MCR_RESULT=%ERRORLEVEL%"
goto finished

:cancelled
echo Abgebrochen. Es wurde kein Mapping erzeugt.
set "MCR_RESULT=2"
goto finished

:failed
set "MCR_RESULT=1"
goto finished

:finished
echo.
echo Fenster mit beliebiger Taste schliessen.
pause
popd
exit /b %MCR_RESULT%

:tryNode
rem No file is executed until its basename, existence and type were checked.
rem Never use CALL with a user-supplied filename as its argument.
if defined MCR_NODE exit /b 0
if not defined MCR_CANDIDATE exit /b 1
set "MCR_CANDIDATE=%MCR_CANDIDATE:"=%"
if not defined MCR_CANDIDATE exit /b 1
for %%F in ("%MCR_CANDIDATE%") do if /i not "%%~nxF"=="node.exe" exit /b 1
if not exist "%MCR_CANDIDATE%" exit /b 1
if exist "%MCR_CANDIDATE%\" exit /b 1
"%MCR_CANDIDATE%" -e "const v=process.versions.node.split('.').map(Number);if(process.release.name!=='node'||v[0]<22||(v[0]===22&&v[1]<15)){console.error('FEHLER: Node.js ab 22.15 ist erforderlich.');process.exit(1)}console.log('Node.js '+process.version+' erkannt.');"
if errorlevel 1 exit /b 1
set "MCR_NODE=%MCR_CANDIDATE%"
exit /b 0
