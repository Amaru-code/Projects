/* Guided single-ticket data assistant. No send/save/categorisation/queue traversal. */
'use strict';
const W=window;let T=W;try{void W.top.document.body;T=W.top;}catch{}
const demo=location.protocol==='file:'||location.href==='about:blank'||['localhost','127.0.0.1','[::1]'].includes(location.hostname);
if(!demo&&location.hostname!=='comarchecm.mercer.com')throw new Error('MCR: Nur im freigegebenen COMARCH-Fenster oder in der lokalen Demo verwenden.');
try{T.MCR_MAIL?.close();W.MCR_MAIL?.close();T.MCR_DATA?.close();W.MCR_DATA?.close();}catch{}
try{if(T.__mcrInspectorTimer)T.clearInterval(T.__mcrInspectorTimer);T.__mcrInspectorTimer=null;if(T.__MCR_CAPTURE_CLICK)T.__MCR_CAPTURE_CLICK=()=>{};T.document.getElementById('__mcr_comarch_inspector')?.remove();}catch{}
const D=T.document,HID='__mcr_mail_assistant_v3';D.getElementById(HID)?.remove();
const host=D.createElement('div');host.id=HID;
Object.assign(host.style,{position:'fixed',top:'12px',right:'12px',zIndex:'2147483647',width:'450px',maxWidth:'96vw'});
const shadow=host.attachShadow({mode:'open'}),style=D.createElement('style');
style.textContent=`:host{font:14px/1.45 'Segoe UI',Arial,sans-serif;color:#172d40}*{box-sizing:border-box}section{background:#fff;border:2px solid #275875;border-radius:12px;box-shadow:0 6px 30px #0005;max-height:94vh;overflow:auto;padding:16px}h2{font-size:19px;margin:0 0 6px}details.step{margin:12px 0;border:1px solid #beced9;border-radius:7px;padding:10px}summary{font-weight:700;cursor:pointer}p{margin:7px 0}.note{font-size:12px;color:#485c6a}label{display:block;margin:8px 0}input,textarea,select,button{font:inherit}input[type=text],select,textarea{width:100%;padding:7px;border:1px solid #91a5b5;border-radius:4px}input[type=file]{max-width:100%;font-size:12px}textarea{min-height:110px}button{padding:8px 11px;margin:4px 5px 4px 0;cursor:pointer;border:1px solid #6c899d;border-radius:5px;background:#edf3f8;color:#15354b}button:disabled{opacity:.5;cursor:not-allowed}.primary{background:#1d5778;color:white}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:12px/1.5 Consolas,monospace;padding:8px;background:#eff4f8;max-height:170px;overflow:auto}.status{padding:10px;border-left:4px solid #23747c;background:#edf7f6;font-weight:600}.error{border-color:#b24033;background:#fff0e9}.result{font:700 20px/1.4 'Segoe UI',Arial,sans-serif;background:#e7f4ef;padding:12px}.row{display:flex;gap:10px}.row>label{flex:1;min-width:0}small{font-size:12px}`;
shadow.append(style);const panel=D.createElement('section');shadow.append(panel);D.body.append(host);
let map=null,mail=null,analysis=null,candidates=[],chosen=null,context=null,waiting=false,member=null,result=null;
let alive=true,caseEpoch=0,mapEpoch=0,lastError=null,lastOutcome=null,proof=null,stable=null,autoCandidate=null,autoAttempted=false;
let waitStarted=0,selectionMode=null,descriptionWritten=false,format=null,fieldAtSearch=null;
let lastWidgetScan=null,autoClickAt=0;
let lastDomScan=null,learnedList=null,pendingLearning=null,lastManualShape=[];
let profileBinding=null,lastProfileScan=null,customBinding=null,pendingCustom=null,lastCustomScan=null;
let pickMode=null,pickUntil=0,pickSuppress=null,manualRequest=false;
let fieldSignals={input:0,keyup:0,change:0},selectionTrace=[];
function recordState(state){if(selectionTrace.at(-1)?.state!==state){selectionTrace.push({state,elapsedMs:waiting?Math.min(120000,Math.max(0,Date.now()-waitStarted)):0});if(selectionTrace.length>16)selectionTrace.shift();}}
function inspectLive(field){const r=Widget.inspect(field);lastWidgetScan=r.safe;const dom=ListDOM.inspect(field,learnedList);lastDomScan=dom.safe;const custom=Suggest.inspect(field,customBinding);lastCustomScan=custom.safe;return {r,dom,custom};}

let lastBlocking=null,idHints=[],selectionCommitted=false,lookupAttempted=false,lastSelectionState="NOT_STARTED";
const listeners=new Map(),ui={};
function el(tag,text,parent=panel){const n=D.createElement(tag);if(text!==undefined)n.textContent=text;parent.append(n);return n;}
function safe(fn){return async()=>{try{return await fn();}catch(e){error(e);}};}
function btn(text,fn,parent=panel){const n=el('button',text,parent);n.type='button';n.onclick=safe(fn);return n;}
function check(text,parent){const l=el('label',undefined,parent),n=D.createElement('input');n.type='checkbox';l.append(n,D.createTextNode(' '+text));return n;}
function input(label,id,parent){const l=el('label',label,parent),n=el('input',undefined,l);n.type='text';n.id=id;return n;}
function step(title){const n=el('details',undefined,panel);n.className='step';el('summary',title,n);return n;}
function status(text,bad=false){ui.status.textContent=text;ui.status.className='status'+(bad?' error':'');}
function go(n){[ui.s1,ui.s2,ui.s3,ui.s4].forEach((e,i)=>e.open=i===n-1);}
function clearResult(){result=null;descriptionWritten=false;ui.result.textContent='Noch kein Ergebnis.';ui.copy.disabled=true;ui.apply.disabled=true;ui.row.textContent='';}
function invalidate(reason){pickMode=null;manualRequest=false;pendingCustom=null;lastCustomScan=null;lastProfileScan=null;pendingLearning=null;lastDomScan=null;fieldSignals={input:0,keyup:0,change:0};selectionTrace=[];lastManualShape=[];lastBlocking=null;selectionCommitted=false;lookupAttempted=false;lastSelectionState='NOT_STARTED';lastWidgetScan=null;autoClickAt=0;waiting=false;proof=null;stable=null;autoCandidate=null;autoAttempted=false;context=null;chosen=null;member=null;selectionMode=null;clearResult();if(reason)status(reason);}
function error(e){
 lastError=/^[A-Z_0-9]+$/.test(e.code??'')?e.code:'ERROR';
 // An early Continue click is NOT a fatal error and must not disable watching.
 if(['MEMBER_NOT_SELECTED','MEMBER_COMMIT_PENDING'].includes(lastError)&&chosen&&context&&mail&&map&&ui.mailOK.checked&&ui.sourceOK.checked){
  waiting=true;if(!waitStarted||Date.now()-waitStarted>120000)waitStarted=Date.now();
  go(3);lastSelectionState=lastError==='MEMBER_COMMIT_PENDING'?'WAITING_FOR_COMMIT':'WAITING_FOR_REAL_CHOICE';recordState(lastSelectionState);
  ui.memberInfo.textContent=lastError==='MEMBER_COMMIT_PENDING'?'Die MercerID-Ausgabe ist noch leer oder technisch nicht gebunden. Wenn sie in COMARCH bereits gefüllt ist: „MercerID-Anzeige verbinden“ verwenden.':'Noch kein übernommener Member. Den echten Vorschlag anklicken; die Beobachtung läuft weiter.';
  status('Warte auf die nachgewiesene MercerID-Ausgabe. Bereits gefüllte Anzeige bei Bedarf gezielt verbinden.');return;
 }
 waiting=false;clearResult();
 status(lastError+': '+(e.message||'Vorgang fehlgeschlagen.'),true);
 if(lastError==='ID_BLOCKED'){
  lastBlocking=e.blocking??null;go(4);ui.result.textContent='Member zugeordnet · Bestandszeile gesperrt';
  ui.row.textContent=[...(lastBlocking?.messages??[]),'Grund: '+(lastBlocking?.codes??[]).join(', '),'Excel-Quellzeile(n): '+(lastBlocking?.sourceRows??[]).join(', '),
   ...(lastBlocking?.issues??[]).map(x=>'Spalte '+x.column+': '+x.state+' ('+x.code+')'),
   lastBlocking?.legacyDetails?'Dieses ältere Mapping speichert keine Spaltendetails. MAPPING_PRUEFEN.cmd zeigt lokal die betroffene Originalzeile.':'Quelle gezielt prüfen. Danach Mapping neu erzeugen, nicht die JSON-Datei von Hand ändern.',
   Core.policyOf(map?.payload)===Core.STRICT_FLAGS?'Altes Mapping: MAPPING_ERSTELLEN.cmd 0.3.4 starten und das NEUE JSON laden. Leere C/D/E bleiben darin als leer dokumentiert; kein Kürzel.':'Quelle gezielt prüfen: Nur leere C/D/E sind ohne Kürzel zulässig, andere Fehler bleiben gesperrt.'].join('\n');
  ui.retry.textContent='Bestand erneut prüfen';
 }else if(lastError==='ID_NOT_FOUND'){
  go(4);ui.result.textContent='Member zugeordnet · nicht im geladenen Bestand';ui.row.textContent=e.message;
 }else if(lastError.startsWith('MEMBER_')||lastError==='SELECTION_REVIEW'){
  go(3);ui.memberInfo.textContent=e.message;
 }
}
function visible(n){try{return n.isConnected&&n.getClientRects().length>0&&n.ownerDocument.defaultView.getComputedStyle(n).visibility!=='hidden'&&n.ownerDocument.defaultView.getComputedStyle(n).display!=='none';}catch{return false;}}
function documents(){const out=[];function walk(doc,depth){if(!doc||depth>5||out.length>=32||out.includes(doc))return;out.push(doc);for(const f of doc.querySelectorAll('iframe,frame'))try{walk(f.contentDocument,depth+1);}catch{}}walk(D,0);return out;}
function memberField(){const all=documents().flatMap(d=>[...d.querySelectorAll('input[id="mainForm:member-value-id"]')]).filter(visible);Core.need(all.length===1,'MEMBER_FIELD','Bitte EIN Ticket öffnen, unten Bearbeiten anklicken und das Member-Feld anzeigen.');Core.need(!all[0].disabled&&!all[0].readOnly,'MEMBER_READONLY','Member-Feld ist noch nicht bearbeitbar.');return all[0];}
function detectedTicket(){
 const found=new Set();
 for(const doc of [D])for(const n of [...doc.querySelectorAll('label,span,td,div,b,strong,p')].slice(0,12000)){
  if(!visible(n))continue;const s=n.textContent?.trim()??'';if(s.length>70)continue;
  let m=s.match(/^Ticket[\s-]*ID\s*:?\s*(\d{4,15})$/i);if(m){found.add(m[1]);continue;}
  if(/^Ticket[\s-]*ID\s*:?$/i.test(s)){
   const next=n.nextElementSibling?.textContent?.trim();if(/^\d{4,15}$/.test(next??''))found.add(next);
   const p=n.parentElement?.textContent?.trim()??'';if(p.length<90&&(m=p.match(/^Ticket[\s-]*ID\s*:?\s*(\d{4,15})$/i)))found.add(m[1]);
  }
 }
 return found.size===1?[...found][0]:null;
}
// The ticket/document anchor protects against switching cases. It is NEVER
// used as the JSON lookup key and never needs to be replaced with a MercerID.
function documentKey(field){
 const scope=field.closest('form')??field.ownerDocument;const ids=new Set();
 for(const a of scope.querySelectorAll('a[href]'))try{
  const u=new URL(a.getAttribute('href'),field.ownerDocument.baseURI);
  if(u.origin!==field.ownerDocument.location.origin||!/(?:^|\/)GetFile\/?$/i.test(u.pathname))continue;
  for(const [k,v] of u.searchParams)if(/^docid$/i.test(k)&&/^\d{1,15}$/.test(v))ids.add(v);
 }catch{}
 return ids.size?[...ids].sort().join('|'):null;
}
function bindContext(){
 const actual=detectedTicket(),field=memberField(),docKey=documentKey(field);
 ui.ticket.value=actual??'nicht automatisch erkannt';
 ui.caseInfo.textContent=actual?'Vorgang erkannt. Diese Nummer wird NICHT im Bestand gesucht.':docKey?'Aktuelles Dokument als Fallgrenze erkannt. Keine Ticketnummer eingeben.':'Fall nur an dieses Formular gebunden. Bei Seitenwechsel oder Formularersetzung neu bestätigen.';
 return {id:actual,detected:!!actual,documentKey:docKey,url:T.location.href,field,mode:actual?'TICKET':docKey?'DOCUMENT':'FORM_ONLY'};
}
function contextOK(){
 Core.need(context&&context.url===T.location.href,'TICKET_CHANGED','Seite gewechselt. Mit Neuer Fall beginnen.');
 const actual=detectedTicket();
 Core.need(context.detected?actual===context.id:!actual,'TICKET_CHANGED','Vorgangskennung hat sich geändert. Neu beginnen.');
 const field=memberField(),key=documentKey(field);
 Core.need(key===context.documentKey,'TICKET_CHANGED','Originaldokumente des Tickets haben sich geändert. Neu beginnen.');
 if(!context.detected&&!context.documentKey)Core.need(field===context.field,'TICKET_REBIND','Ohne verlässliche Fallkennung wurde das Formular ersetzt. Person und Ticket erneut bestätigen.');
 return field;
}
// Distinguish an autocomplete suggestion from the populated MercerID profile.
// Only read short semantic values in the same form, never the mail iframe.
function committedProfile(field){const result=Profile.inspect(field,profileBinding);lastProfileScan=result.safe;return result;}
// Explicitly bind a selected output, never by writing a number into a data field.
function bindProfileOutput(element){
 if(!chosen){chosen={...freezeName(),expectedId:expectedId()};gates();context=bindContext();}
 gates();const f=contextOK(),selected=Core.selectedMember(f.value);checkExpected(selected);
 Core.need(Person.memberMatches(selected.display,chosen),'MEMBER_NAME_CONFLICT','Name stimmt nicht mit dem ausgewählten COMARCH-Member überein.');
 const binding=Profile.bind(f,element);const p=Profile.inspect(f,binding);
 Core.need(!p.ambiguous&&p.clientId===selected.clientId,'MEMBER_PROFILE_CONFLICT','Gewählte MercerID-Anzeige passt nicht eindeutig zum Member.');
 profileBinding=binding;recordState('PROFILE_OUTPUT_BOUND');lastError=null;
 return acceptMember(true);
}
function armPick(mode){
 if(!chosen){chosen={...freezeName(),expectedId:expectedId()};gates();context=bindContext();}
 gates();contextOK();pickMode=mode;pickUntil=Date.now()+30000;waiting=true;waitStarted=Date.now();
 // ALT is mandatory, so ordinary COMARCH clicks never become unintended bindings.
 status(mode==='PROFILE'?'ALT gedrückt halten und die bereits gefüllte MercerID-Anzeige unter dem Member-Feld anklicken (nicht den Vorschlag).':'ALT gedrückt halten und eine echte Vorschlagszeile anklicken. Das markiert die Liste, wählt aber noch keine Person.');
}
function capturePick(event){
 if(pickSuppress&&Date.now()<pickSuppress.until&&event.isTrusted&&(pickSuppress.target===event.target||pickSuppress.target.contains?.(event.target))){event.preventDefault();event.stopImmediatePropagation();return;}
 if(!pickMode||!event.isTrusted||!event.altKey||event.button!==0||event.composedPath().includes(host))return;
 if(Date.now()>pickUntil){pickMode=null;return;}
 event.preventDefault();event.stopImmediatePropagation();
 const mode=pickMode;pickMode=null;pickSuppress={target:event.target,until:Date.now()+650};
 try{
  if(mode==='PROFILE'){bindProfileOutput(event.target);return;}
  gates();const f=contextOK(),hit=Suggest.capture(f,event.target);
  Core.need(hit,'SUGGESTION_BIND_TARGET','Keine Vorschlagszeile mit mousedown-Ereignis erkannt. Keine Aktion ausgeführt.');
  Core.need(chosen.expectedId,'PERSON_ID_REQUIRED','Für die automatische Auswahl eine MercerID aus der Mail prüfen. Sonst den echten Vorschlag selbst anklicken.');
  Core.need(!!candidateIdentity(hit.row,'COMARCH_MOUSEDOWN_ID'),'SELECTION_REVIEW','Diese Zeile passt nicht zum geprüften Namen und zur MercerID.');
  customBinding=hit.binding;lastCustomScan=Suggest.inspect(f,customBinding).safe;autoCandidate=null;
  waiting=true;waitStarted=Date.now();status('Vorschlagsliste verbunden. Ein passender Einzeltreffer wird einmal ausgewählt; mehrere Treffer bleiben manuell.');
 }catch(e){error(e);}
}

function expectedId(){return Person.personId(ui.expected.value);}
function checkExpected(selected){
 const expected=expectedId();Core.need(expected===chosen.expectedId,'PERSON_ID_CHANGED','Personenkennung wurde geändert. Identität erneut bestätigen.');
 Core.need(!expected||expected===selected.clientId,'MAIL_MEMBER_CONFLICT','Geprüfte MercerID aus der Mail passt nicht zum ausgewählten COMARCH-Member. Nicht die Ticketnummer umschreiben.');
}
function freezeName(){return Person.query(ui.first.value,ui.last.value);}
function gates(){Core.need(map&&ui.sourceOK.checked,'MAPPING_REVIEW','JSON aus private_data laden und Quellenstand bestätigen.');Core.need(mail&&ui.mailOK.checked,'MAIL_REVIEW','Original-Mail laden und Zuordnung zu diesem Ticket bestätigen.');const p=freezeName();Core.need(chosen&&p.query===chosen.query&&expectedId()===chosen.expectedId,'NAME_CHANGED','Name wurde geändert. Suche neu starten.');return p;}
async function sha(value){Core.need(crypto?.subtle,'CRYPTO_REQUIRED','SHA-256 ist in diesem Browserkontext nicht verfügbar. HTTPS-COMARCH verwenden.');const b=typeof value==='string'?new TextEncoder().encode(value):value;return [...new Uint8Array(await crypto.subtle.digest('SHA-256',b))].map(x=>x.toString(16).padStart(2,'0')).join('');}
el('h2','MCR Mail-Assistent 0.3.4');
el('p','Original-Mail → geprüfter Name → Member → USC / Pläne').className='note';
ui.status=el('p','1 · Deine vorhandene JSON-Datei laden.');ui.status.className='status';
ui.s1=step('1 · Bestand laden (einmal pro Sitzung)');ui.s1.open=true;
el('p','JSON aus private_data auswählen — NICHT die Excel-Datei.',ui.s1);
ui.mapFile=el('input',undefined,ui.s1);ui.mapFile.type='file';ui.mapFile.accept='.json';ui.mapFile.id='mapFile';
ui.mapInfo=el('pre','Noch kein Mapping geladen.',ui.s1);
ui.sourceOK=check('Diese Bestandsversion und Spalte L als USC sind fachlich richtig und aktuell genug.',ui.s1);
ui.s2=step('2 · Original-Mail dieses Tickets laden');
el('p','Im COMARCH-Nachrichtenverlauf die Original-Mail herunterladen und Speichern wählen. Die .msg hier auswählen; Outlook muss nicht geöffnet werden.',ui.s2);
ui.mailFile=el('input',undefined,ui.s2);ui.mailFile.type='file';ui.mailFile.accept='.msg,.txt';ui.mailFile.id='mailFile';
ui.mailInfo=el('pre','Noch keine Mail geladen.',ui.s2);
const alternative=el('details',undefined,ui.s2);el('summary','Alternative: Mailtext selbst einfügen',alternative);
ui.raw=el('textarea',undefined,alternative);ui.raw.setAttribute('aria-label','Alternativer Mailtext');
btn('Diesen Text analysieren',()=>setMail({format:'MANUAL',subject:'',senderName:'',senderEmail:'',body:ui.raw.value,warnings:[],diagnostic:{plainText:true,attachmentsRead:false}}),alternative);
const review=el('details',undefined,ui.s2);el('summary','Gelesenen Text lokal prüfen',review);ui.body=el('pre','Noch kein Text.',review);
ui.s3=step('3 · Name prüfen und Member auswählen');
el('p','Der Name ist ein Vorschlag, kein Identitätsnachweis. Absender und betroffene Person können verschieden sein.',ui.s3).className='note';
const namesLabel=el('label','Namensvorschläge aus der Mail',ui.s3);ui.names=el('select',undefined,namesLabel);ui.names.id='nameCandidates';
const row=el('div',undefined,ui.s3);row.className='row';ui.first=input('Vorname','firstName',row);ui.last=input('Nachname','lastName',row);
btn('Vorname / Nachname tauschen',()=>{[ui.first.value,ui.last.value]=[ui.last.value,ui.first.value];nameChanged();},ui.s3);
ui.expected=input('MercerID / ClientEEID der Person (optional, aus der Mail)','expectedClientId',ui.s3);
ui.expected.placeholder='z. B. INTL01-12345678 oder 12345678';
ui.idInfo=el('pre','Kein Kennungshinweis aus der Mail.',ui.s3);
el('p','Nur die Kennung des tatsächlich ausgewählten COMARCH-Members wird in Excel/JSON gesucht.',ui.s3).className='note';
const technical=el('details',undefined,ui.s3);el('summary','Vorgangsnummer · nur zur Absicherung',technical);
ui.ticket=input('Ticket-ID (nicht MercerID, nur lesen)','ticketId',technical);ui.ticket.readOnly=true;
ui.caseInfo=el('p','Keine Ticketnummer eintippen. Der Assistent bindet den geöffneten Fall separat.',technical);ui.caseInfo.className='note';
ui.mailOK=check('Mail gehört zu diesem Ticket; Vorname, Nachname und ein ggf. angezeigter MercerID-Hinweis sind geprüft. Member-Suche freigeben.',ui.s3);
ui.autoOne=check('Einen technisch gebundenen Einzeltreffer automatisch auswählen. Bei ICEfaces zusätzlich nur mit oben geprüfter MercerID. Mehrere Treffer wähle ich selbst.',ui.s3);ui.autoOne.checked=true;
ui.search=btn('Member suchen',startSearch,ui.s3);ui.search.className='primary';
btn('Suchnamen kopieren',async()=>{const p=freezeName();await navigator.clipboard.writeText(p.query);status('Suchname kopiert: im Member-Feld bei Bedarf selbst einfügen.');},ui.s3);
ui.memberInfo=el('pre','Noch keine Member-Suche gestartet.',ui.s3);
ui.inspect=btn('Auswahlliste prüfen',()=>{const f=memberField(),r=inspectLive(f),p=committedProfile(f);ui.memberInfo.textContent='COMARCH-Auswahl: '+r.custom.safe.state+' | Ereignis: mousedown\nGelieferte Zeilen: '+(r.custom.safe.entryCount??r.r.safe.entryCount??'unbekannt')+'\nMercerID-Ausgabe: '+p.safe.state+' | Pfad: '+(p.safe.route??'noch nicht erkannt')+'\nBei unbekannter Struktur die tatsächliche Zeile/Anzeige einmal verbinden.';},ui.s3);
btn('Member-Suchfeld anzeigen (keine Auswahl)',()=>{const f=memberField();f.scrollIntoView({block:'center',behavior:'instant'});const before=f.style.outline;f.style.outline='3px solid #1d5778';setTimeout(()=>{if(f.isConnected)f.style.outline=before;},1800);status('Member-Suchfeld markiert. Das Anzeigen wählt keine Person und löst keine neue Suche aus.');},ui.s3);
el('p','Unbekannte Liste? Einmal den richtigen echten Vorschlag anklicken. Der Helfer beobachtet den Klick und die übernommenen Stammdaten. Eine sicher gebundene Liste kann er für diese Seite lernen.',ui.s3).className='note';
// Preserve the COMARCH dropdown focus while inspecting it.
ui.inspect.addEventListener('pointerdown',event=>event.preventDefault());
ui.inspect.addEventListener('mousedown',event=>event.preventDefault());
ui.confirm=btn('Übernommene Person prüfen → Schritt 4',()=>acceptMember(true),ui.s3);ui.confirm.className='primary';
const repair=el('details',undefined,ui.s3);el('summary','Nur bei Erkennungsproblemen: Element einmal verbinden',repair);
ui.bindProfile=btn('MercerID-Anzeige verbinden',()=>armPick('PROFILE'),repair);
ui.bindChoice=btn('Vorschlagszeile verbinden',()=>armPick('CHOICE'),repair);
for(const b of [ui.bindProfile,ui.bindChoice])for(const type of ['pointerdown','mousedown'])b.addEventListener(type,e=>e.preventDefault());
el('p','Nach dem Klick ALT halten und das echte Element in COMARCH anklicken. Kein Eintragen von Kennungen, kein Speichern/Versand. Escape beendet das Verbinden.',repair).className='note';
btn('Suche / Warten stoppen',()=>invalidate('Gestoppt. Kein Versand, kein Speichern.'),ui.s3);
ui.s4=step('4 · Beschreibung übernehmen');
ui.result=el('div','Noch kein Ergebnis.',ui.s4);ui.result.className='result';ui.row=el('pre','',ui.s4);
ui.retry=btn('Bestand erneut prüfen',()=>acceptMember(true),ui.s4);
ui.formulaOK=check('Falls die Quellzeile Formeln enthält: gespeicherte Berechnungswerte geprüft.',ui.s4);
ui.copy=btn('Beschreibung kopieren',async()=>{checkCurrentResult();await navigator.clipboard.writeText(result.description);status('Beschreibung kopiert. Noch kein Ticket gespeichert.');},ui.s4);ui.copy.disabled=true;
ui.apply=btn('Beschreibung in COMARCH einsetzen',applyDescription,ui.s4);ui.apply.disabled=true;
el('p','Kein automatischer Versand, kein „Ticket speichern“. Kategorien, Signatur und Antwort sind weiterhin separat zu prüfen.',ui.s4).className='note';
btn('Neuer Fall',resetCase);btn('Diagnose-ZIP',downloadDiagnostic);btn('Schließen',close);
el('p','Nur im betrieblich freigegebenen Kontext verwenden. Mail und Mapping liegen im Speicher dieser COMARCH-Seite; keine isolierte Datenschutz-Sandbox.',panel).className='note';
async function loadMapText(value){
 const epoch=++mapEpoch;invalidate();map=null;go(1);ui.sourceOK.checked=false;ui.mapInfo.textContent='Mapping wird geprüft …';
 Core.need(value.length<=32*1024*1024,'MAP_SIZE','Mapping zu groß.');const obj=JSON.parse(value);Core.validateMap(obj);
 Core.need(demo||obj.payload.mode!=='DEMO','DEMO_NOT_IN_COMARCH','Demo-Mapping nicht in COMARCH einsetzen.');
 Core.need(await sha(JSON.stringify(obj.payload))===obj.payloadSha256,'MAP_HASH_MISMATCH','Mapping-Prüfsumme stimmt nicht.');Core.need(alive&&mapEpoch===epoch,'CANCELLED','Import ersetzt/geschlossen.');map=obj;
 const p=obj.payload;ui.mapInfo.textContent=[p.mode==='DEMO'?'DEMO · fiktive Daten':'Bestand geladen',p.source.filename,'Blatt: '+p.source.sheet+' | L: '+p.source.headers.L,'Stand: '+(p.source.modifiedAt??'unbekannt'),'Export: '+p.generatedAt,'Gültige Kennungen: '+Object.keys(p.entries).length,'Gesperrte Kennungen: '+Object.keys(p.blocked).length,'Merkmalsregel: '+(Core.policyOf(p)===Core.BLANK_OMIT_FLAGS?'Nur 1 → Kürzel; 0 / leer → kein Kürzel (leer bleibt null)':'ALTES STRICT-Mapping: auch leer gesperrt; für Leerzellen mit 0.3.4 neu exportieren')].join('\n');
 lastError=null;status('Mapping geprüft. Quellenstand bestätigen, dann Original-Mail laden.');return {validKeys:Object.keys(p.entries).length};
}
ui.mapFile.onchange=safe(async()=>{const f=ui.mapFile.files?.[0];if(!f)return;const epoch=++mapEpoch;invalidate();map=null;ui.sourceOK.checked=false;Core.need(f.size<=32*1024*1024,'MAP_SIZE','Mapping zu groß.');const text=await f.text();Core.need(alive&&epoch===mapEpoch,'CANCELLED','Import ersetzt/geschlossen.');await loadMapText(text);});
ui.sourceOK.onchange=()=>{invalidate();if(map&&ui.sourceOK.checked){go(2);status('2 · Original-Mail (.msg) auswählen. Dein Mapping bleibt geladen.');}};
function setMail(data){
 ++caseEpoch;invalidate();mail=null;analysis=null;candidates=[];ui.mailOK.checked=false;ui.formulaOK.checked=false;ui.first.value='';ui.last.value='';ui.names.replaceChildren();ui.body.textContent='';ui.mailInfo.textContent='';format=data.format;lastOutcome=null;
 analysis=Core.analyzeMail((data.subject?'Betreff: '+data.subject+'\n':'')+data.body);if(/^(?:WG|FW|FWD)\s*:/i.test(data.subject??''))analysis.warnings.push('WEITERLEITUNG: Absender und betroffene Person getrennt prüfen.');candidates=Person.candidates(data);mail=data;
 idHints=Person.identifierHints(data,analysis.idHints,candidates);const uniqueIds=[...new Set(idHints.map(x=>x.clientId))];
 ui.expected.value=uniqueIds.length===1?uniqueIds[0]:'';
 ui.idInfo.textContent=idHints.length?idHints.map(x=>x.clientId+' — '+(x.strength==='EXPLICIT'?'beschriftete Kennung':'Namensnähe: nur Hinweis, prüfen')).join('\n'):'Kein Kennungshinweis. Die spätere ausgewählte MercerID reicht für den Bestandsabgleich.';
 ui.body.textContent=data.body;
 ui.mailInfo.textContent=['Format: '+data.format,'Betreff: '+(data.subject||'(nicht vorhanden)'),'Absender: '+(data.senderName||'(nicht vorhanden)'),...data.warnings,...analysis.warnings].join('\n');
 el('option','Bitte Namensvorschlag wählen oder unten selbst eingeben',ui.names).value='';
 candidates.forEach((c,i)=>{const o=el('option',c.name+' — '+c.sources.join(', '),ui.names);o.value=String(i);});
 if(candidates.length===1){ui.names.value='0';chooseName(0);}else ui.names.value='';
 const ticket=detectedTicket();ui.ticket.value=ticket??'nicht automatisch erkannt';
 go(3);lastError=null;status(candidates.length===1?'3 · Name und ggf. MercerID-Hinweis prüfen, dann „Member suchen“.':candidates.length?'3 · Mehrere Namenshinweise: richtige Person auswählen.':'3 · Kein eindeutiger Name erkannt. Vorname und Nachname aus dem Text selbst eintragen.');
 return {nameCandidates:candidates.length,idCandidates:new Set(idHints.map(x=>x.clientId)).size};
}
async function loadMailBytes(bytes,extension){
 const epoch=++caseEpoch;invalidate();mail=null;analysis=null;ui.mailOK.checked=false;ui.mailInfo.textContent='Original-Mail wird lokal gelesen …';
 Core.need(alive,'CLOSED','Helfer ist geschlossen.');
 const item=extension.toLowerCase()==='.msg'?Msg.parseMsg(bytes):extension.toLowerCase()==='.txt'?Msg.parseText(bytes):Core.fail('MAIL_FORMAT','Bitte die Original-.msg oder UTF-8-.txt verwenden. .eml ist hier noch nicht unterstützt.');
 Core.need(alive&&epoch===caseEpoch,'CANCELLED','Mailimport ersetzt.');return setMail(item);
}
ui.mailFile.onchange=safe(async()=>{const f=ui.mailFile.files?.[0];if(!f)return;const epoch=++caseEpoch;invalidate();mail=null;analysis=null;ui.mailOK.checked=false;Core.need(f.size<=Msg.MAX_FILE,'MSG_SIZE','Maildatei zu groß (32 MiB).');const bytes=await f.arrayBuffer();Core.need(alive&&epoch===caseEpoch,'CANCELLED','Mailimport durch anderen Fall ersetzt.');await loadMailBytes(bytes,(/\.[^.]+$/.exec(f.name)??[''])[0]);});
function chooseName(i){const c=candidates[i];if(!c)return;ui.first.value=c.firstName;ui.last.value=c.lastName;nameChanged();if(c.needsSplit)status('Mehrteiliger Name: Vorname und vollständigen Nachnamen bitte selbst zuordnen.');}
ui.names.onchange=()=>{if(ui.names.value!=='')chooseName(Number(ui.names.value));};
function nameChanged(){invalidate();ui.mailOK.checked=false;}
ui.first.oninput=nameChanged;ui.last.oninput=nameChanged;ui.expected.oninput=nameChanged;ui.mailOK.onchange=()=>{if(!ui.mailOK.checked)invalidate();};
function setNativeValue(field,value,withChange=true){const owner=field.ownerDocument.defaultView;const p=field.tagName==='TEXTAREA'?owner.HTMLTextAreaElement.prototype:owner.HTMLInputElement.prototype;Object.getOwnPropertyDescriptor(p,'value').set.call(field,value);field.dispatchEvent(new owner.Event('input',{bubbles:true}));if(withChange)field.dispatchEvent(new owner.Event('change',{bubbles:true}));}
function startSearch(){
 invalidate();chosen={...freezeName(),expectedId:expectedId()};gates();context=bindContext();const f=memberField();
 if(/INTL01-\d/.test(f.value))return acceptMember(true);
 attachDocument(f.ownerDocument);fieldAtSearch=f;waiting=true;waitStarted=Date.now();lastError=null;lastSelectionState='WAITING_FOR_CHOICE';autoAttempted=false;ui.memberInfo.textContent='Suche: '+chosen.query+'\nTrefferliste in COMARCH abwarten. Bei mehreren Treffern selbst anklicken.';
 f.focus();setNativeValue(f,chosen.query,false);
 // No change/blur before the search key: old AJAX controls may replace the field.
 // A real character key (never Enter/Tab) supplies legacy keyCode/which metadata.
 const key=chosen.query.slice(-1),keyCode=key.toUpperCase().charCodeAt(0),owner=f.ownerDocument.defaultView;
 if(f.isConnected&&f===contextOK())f.dispatchEvent(new owner.KeyboardEvent('keyup',{key,keyCode,which:keyCode,bubbles:true}));
 recordState('SEARCH_INPUT_SENT');
 status('Warte auf COMARCH-Treffer. Falls keine Liste erscheint: im Member-Feld ein Zeichen löschen und neu tippen. Kein Enter auf Senden.');
}
function observeChoice(event){
 if(!waiting||!event.isTrusted||!chosen||event.button!==0)return;
 if(event.composedPath().includes(host))return;
 let f;try{f=contextOK();}catch{return;}
 if(event.target?.ownerDocument!==f.ownerDocument)return;
 lastManualShape=ListDOM.clickShape(event.target);
 const custom=Suggest.capture(f,event.target);
 const scan=ListDOM.capture(f,event.target);lastDomScan=scan.safe;
 let n=event.target;for(let i=0;n&&i<6;i++,n=n.parentElement){
  if(n.nodeType!==1||['BODY','HTML','FORM'].includes(n.tagName))break;
  const text=n.innerText??n.textContent??'';if(text.length>350)continue;
  try{const selected=Core.selectedMember(text);if(Person.memberMatches(text,chosen)&&(!chosen.expectedId||selected.clientId===chosen.expectedId)){
   proof={id:selected.clientId,until:Date.now()+30000,mode:'USER_CLICK'};recordState('REAL_CHOICE_OBSERVED');
   if(custom)pendingCustom={binding:custom.binding,clientId:selected.clientId};
   const row=scan.entries?.find(row=>row===event.target||row.contains(event.target));
   if(row&&scan.binding)pendingLearning={binding:scan.binding,clientId:selected.clientId};
   return;
  }}catch{}
 }
}
function observeFieldSignal(event){
 if(!waiting||event.target?.id!=='mainForm:member-value-id')return;
 if(Object.hasOwn(fieldSignals,event.type))fieldSignals[event.type]=Math.min(99,fieldSignals[event.type]+1);
}
function cancelPick(event){if(event.key==='Escape'&&pickMode){pickMode=null;status('Element-Verbindung abgebrochen. Keine Daten verändert.');}}
function attachDocument(doc){
 if(listeners.has(doc))return;
 doc.addEventListener('pointerdown',capturePick,true);doc.addEventListener('mousedown',capturePick,true);doc.addEventListener('click',capturePick,true);doc.addEventListener('mouseup',capturePick,true);
 doc.addEventListener('keydown',cancelPick,true);doc.addEventListener('pointerdown',observeChoice,true);doc.addEventListener('mousedown',observeChoice,true);
 for(const type of ['input','change','keyup'])doc.addEventListener(type,observeFieldSignal,true);
 listeners.set(doc,true);
}
function candidateIdentity(element,kind,extra={}){
 const text=element.innerText??'';
 if(text.length>350||!Person.memberMatches(text,chosen))return null;
 try{
  const selected=Core.selectedMember(text);
  if(chosen.expectedId&&chosen.expectedId!==selected.clientId)return null;
  const ids=[...new Set(analysis.idHints.map(x=>x.clientId))];
  if(ids.length>1||(ids.length===1&&ids[0]!==selected.clientId))return null;
  // Identity selection and plan lookup are separate. Even a blocked map row
  // must reach the explicit diagnostics AFTER COMARCH commits the member.
  return {element,id:selected.clientId,text,kind,...extra};
 }catch{return null;}
}
function strictSingle(f){
 if(!ui.autoOne.checked||autoAttempted||context?.mode==='FORM_ONLY')return null;
 const refs=(f.getAttribute('aria-controls')||f.getAttribute('aria-owns')||'').trim().split(/\s+/).filter(Boolean);
 if(refs.length===1){
  const list=f.ownerDocument.getElementById(refs[0]);
  if(list&&visible(list)&&list.getAttribute('role')==='listbox'&&list.getAttribute('aria-busy')==='false'){
   const options=[...list.querySelectorAll('[role="option"]')];
   if(options.length!==1)return null;
   const o=options[0];
   if(visible(o)&&o.getAttribute('aria-setsize')==='1'&&o.getAttribute('aria-posinset')==='1'&&o.getAttribute('aria-disabled')!=='true')return candidateIdentity(o,'LINKED_SINGLE');
  }
 }
 const {r:scan,dom,custom}=inspectLive(f);
 if(custom.safe.state==='MULTIPLE_RENDERED'||custom.safe.state==='HIDDEN_ENTRY'||custom.safe.state==='AMBIGUOUS_POPUP')return null;
 if(custom.safe.state==='SINGLE_RENDERED'){
  if(!chosen.expectedId){lastCustomScan={...custom.safe,state:'REVIEWED_ID_REQUIRED'};return null;}
  const profile=committedProfile(f);
  if(!profile.labelFound||profile.ambiguous){lastCustomScan={...custom.safe,state:'COMMIT_PROFILE_REQUIRED'};return null;}
  return candidateIdentity(custom.entries[0],'COMARCH_MOUSEDOWN_ID',{list:custom.list});
 }
 // Never override an existing conflicting/busy/multiple registry result.
 if(scan.safe.state!=='SINGLE_RENDERED'){
  if(!['REGISTRY_UNAVAILABLE'].includes(scan.safe.state)||!learnedList||dom.safe.state!=='SINGLE_RENDERED')return null;
  if(!chosen.expectedId){lastDomScan={...dom.safe,state:'REVIEWED_ID_REQUIRED'};return null;}
  const profile=committedProfile(f);if(!profile.labelFound||profile.ambiguous)return null;
  return candidateIdentity(dom.entries[0],'LEARNED_DOM_ID',{list:dom.list});
 }
 // Legacy component only declares the number it rendered. A confirmed exact ID
 // plus an exact name is mandatory; no automatic identity inference from names.
 if(!chosen.expectedId){lastWidgetScan={...scan.safe,state:'REVIEWED_ID_REQUIRED'};return null;}
 // Need a readable committed-profile field before any automatic ICE selection.
 // Otherwise we could not distinguish its synchronous label from server commit.
 const profile=committedProfile(f);
 if(!profile.labelFound||profile.ambiguous){lastWidgetScan={...scan.safe,state:'COMMIT_PROFILE_REQUIRED'};return null;}
 return candidateIdentity(scan.entries[0],'ICE_SINGLE_ID',{instance:scan.instance,list:scan.list});
}

function tick(){
 if(!alive)return;
 for(const doc of documents())attachDocument(doc);
 if(result){try{checkCurrentResult();}catch(e){error(e);}return;}
 if(!waiting)return;
 if(pickMode){if(Date.now()>pickUntil){pickMode=null;status('Element-Verbindung abgelaufen. Erneut starten.');}else return;}
 try{
  gates();const f=contextOK();
  if(autoAttempted&&autoClickAt&&Date.now()-autoClickAt>30000){waiting=false;lastSelectionState='AUTO_COMMIT_UNCONFIRMED';status('Auswahl einmal ausgelöst, aber nicht rechtzeitig bestätigt. Kein zweiter Klick. COMARCH-Zuordnung prüfen und anschließend manuell bestätigen.',true);return;}
  if(Date.now()-waitStarted>120000){waiting=false;status('Warten pausiert. Person auswählen und mit „Übernommene Person prüfen → Schritt 4“ fortfahren.');return;}
  let value=null;try{value=Core.selectedMember(f.value);}catch{}
  if(value){
   if(!Person.memberMatches(value.display,chosen)){error(Object.assign(new Error('Ausgewählter Name passt nicht zum bestätigten Suchnamen. Vorname/Nachname und Person prüfen.'),{code:'MEMBER_NAME_CONFLICT'}));return;}
   checkExpected(value);const profile=committedProfile(f);
   Core.need(!profile.ambiguous,'MEMBER_PROFILE_AMBIGUOUS','MercerID-Stammdaten sind nicht eindeutig. Nicht automatisch fortfahren.');
   if(profile.clientId&&profile.clientId!==value.clientId){stable=null;lastSelectionState='WAITING_FOR_COMMIT';recordState('WAITING_FOR_COMMIT');status('COMARCH verarbeitet die Auswahl: MercerID-Stammdaten passen noch nicht. Kein Lookup, bis beide Kennungen übereinstimmen.');return;}
   ui.memberInfo.textContent='Member-Feld: '+value.display+'\nMercerID-Ausgabe: '+profile.safe.state;
   if(profile.labelFound&&!profile.clientId){stable=null;lastSelectionState='WAITING_FOR_COMMIT';recordState('WAITING_FOR_COMMIT');ui.memberInfo.textContent+='\nIst die MercerID darunter bereits ausgefüllt? Dann „MercerID-Anzeige verbinden“ verwenden.';status('Warte auf erkannte MercerID-Stammdaten. Sichtbar gefüllte Daten können über „Element einmal verbinden“ zugeordnet werden.');return;}
   if(!stable||stable.value!==f.value||stable.profileId!==profile.clientId)stable={value:f.value,profileId:profile.clientId,since:Date.now()};
   lastSelectionState='MEMBER_VALUE_READY';
   if(manualRequest&&Date.now()-stable.since>=900){acceptMember(true);return;}
   if(Date.now()-stable.since>=900&&(!['ICE_SINGLE_ID','LEARNED_DOM_ID','COMARCH_MOUSEDOWN_ID'].includes(proof?.mode)||profile.clientId===value.clientId)&&proof?.id===value.clientId&&proof.until>Date.now()&&(context.detected||context.documentKey))acceptMember(false);
   else status('Member erkannt. Falls es nicht automatisch weitergeht: „Übernommene Person prüfen → Schritt 4“.');
   return;
  }
  stable=null;const one=strictSingle(f);
  if(!one){autoCandidate=null;lastSelectionState='WAITING_FOR_USER_OR_UNQUALIFIED_LIST';recordState('WAITING_FOR_REAL_CHOICE');ui.memberInfo.textContent='Vorschlag noch nicht ausgewählt. '+(lastWidgetScan?.state==='MULTIPLE_RENDERED'?'Mehrere Treffer: richtigen COMARCH-Vorschlag selbst anklicken.':lastWidgetScan?.state==='REVIEWED_ID_REQUIRED'?'ICEfaces-Liste erkannt, aber geprüfte MercerID fehlt. Person selbst auswählen.':lastWidgetScan?.state==='COMMIT_PROFILE_REQUIRED'?'Liste erkannt, aber Übernahmeprüfung nicht eindeutig. Person selbst auswählen.':'Keine sichere automatische Auswahlbindung. Den echten Vorschlag einmal selbst anklicken; ich beobachte die Übernahme.')+'\nKomponente: '+(lastWidgetScan?.state??'ARIA_PRUEFUNG')+' | Lokale Liste: '+(lastDomScan?.state??'unbekannt')+' | COMARCH: '+(lastCustomScan?.state??'unbekannt');return;}
  if(!autoCandidate||autoCandidate.element!==one.element||autoCandidate.text!==one.text||autoCandidate.kind!==one.kind||autoCandidate.instance!==one.instance){autoCandidate={...one,since:Date.now()};return;}
  if(Date.now()-autoCandidate.since>=1500){
   // Revalidate linkage, query, names, count and ID immediately before one click.
   gates();const field=contextOK();const fresh=strictSingle(field);
   if(!fresh||fresh.element!==one.element||fresh.id!==one.id||fresh.text!==one.text||fresh.kind!==one.kind||fresh.instance!==one.instance){autoCandidate=null;return;}
   Core.need(field.value===chosen.query,'SEARCH_CHANGED','Suchfeld wurde geändert. Erneut prüfen.');
   autoAttempted=true;autoClickAt=Date.now();proof={id:one.id,until:Date.now()+30000,mode:one.kind};lastSelectionState='AUTO_CLICK_SENT';
   status('Eindeutigen Vorschlag einmal angeklickt. Warte auf die von COMARCH übernommenen MercerID-Stammdaten.');
   if(one.kind==='COMARCH_MOUSEDOWN_ID'){Suggest.activate(one.element);recordState('MOUSEDOWN_DISPATCHED');}
   else one.element.click();
  }
 }catch(e){error(e);}
}
function acceptMember(explicit){
 if(explicit&&!chosen){chosen={...freezeName(),expectedId:expectedId()};gates();context=bindContext();}
 gates();const f=contextOK(),s=Core.selectedMember(f.value);checkExpected(s);
 const profile=committedProfile(f);Core.need(!profile.ambiguous,'MEMBER_PROFILE_AMBIGUOUS','MercerID-Stammdaten nicht eindeutig.');
 if(explicit){manualRequest=true;waiting=true;if(!waitStarted||Date.now()-waitStarted>120000)waitStarted=Date.now();}
 Core.need(!profile.labelFound||profile.clientId,'MEMBER_COMMIT_PENDING','Vorschlag noch nicht übernommen: In COMARCH den Treffer anklicken und warten, bis MercerID/Vorname/Nachname ausgefüllt sind.');
 Core.need(!profile.clientId||profile.clientId===s.clientId,'MEMBER_PROFILE_CONFLICT','Member-Feld und MercerID-Stammdaten widersprechen sich.');
 Core.need(Person.memberMatches(s.display,chosen),'MEMBER_NAME_CONFLICT','COMARCH-Member stimmt nicht mit geprüftem Vor-/Nachnamen überein. Namen prüfen, nicht die Kennung erraten.');
 Core.need(explicit||(proof?.id===s.clientId&&proof.until>Date.now()),'SELECTION_REVIEW','Person aus der tatsächlichen Trefferliste auswählen und bestätigen.');
 const ids=[...new Set(analysis.idHints.map(x=>x.clientId))];Core.need(ids.length<=1,'MAIL_AMBIGUOUS','Mehrere Personenkennungen in der Mail. Dieser Fall braucht manuelle Klärung.');Core.need(!ids.length||ids[0]===s.clientId,'MAIL_MEMBER_CONFLICT','Mail-Kennung und ausgewählter Member widersprechen sich.');
 // Defer even explicit confirmation until the same field/profile values stayed
 // stable. COMARCH may replace its form nodes after a blur/full iceSubmit.
 if(explicit&&(!stable||stable.value!==f.value||stable.profileId!==profile.clientId||Date.now()-stable.since<900)){
  if(!stable||stable.value!==f.value||stable.profileId!==profile.clientId)stable={value:f.value,profileId:profile.clientId,since:Date.now()};
  status('Übernommene Person wird geprüft. Warte kurz auf stabile MercerID-Daten …');return null;
 }
 if(pendingCustom?.clientId===s.clientId&&profile.clientId===s.clientId&&proof?.mode==='USER_CLICK'&&proof.until>Date.now()){
  customBinding=pendingCustom.binding;recordState('CUSTOM_LIST_LEARNED');
 }
 manualRequest=false;pendingCustom=null;
 if(pendingLearning?.clientId===s.clientId&&profile.clientId===s.clientId&&proof?.mode==='USER_CLICK'&&proof.until>Date.now()){
  learnedList=pendingLearning.binding;recordState('LOCAL_LIST_LEARNED');
 }
 pendingLearning=null;member={...s,element:f};waiting=false;selectionMode=explicit?'USER_CONFIRMATION':proof.mode;selectionCommitted=true;lastSelectionState='MEMBER_CONFIRMED';
 lookupAttempted=true;recordState('LOOKUP_ATTEMPTED');lastBlocking=null;go(4);const entry=Core.lookup(map,s.clientId);
 if(entry.formulas.length&&!ui.formulaOK.checked){status('Quellzeile enthält Formeln. Gespeicherte Werte prüfen und unten bestätigen.');ui.row.textContent='Quellzeile '+entry.sourceRow+' | Formeln in '+entry.formulas.join(', ');return null;}
 result={...entry,description:Core.description(entry),ticket:context.id,memberDisplay:s.display};ui.result.textContent=result.description;
 const showFlag=v=>v===null?'leer → kein Kürzel':String(v);
 ui.row.textContent=['ClientEEID: '+s.clientId,'Excel-Zeile: '+entry.sourceRow,'L / USC: '+entry.usc,'C / DC: '+showFlag(entry.dc)+' | D / PP+: '+showFlag(entry.ppPlus)+' | E / DB+: '+showFlag(entry.dbPlus)].join('\n');
 ui.copy.disabled=false;ui.apply.disabled=false;lastError=null;lastOutcome='LOOKUP_READY';status('4 · Beschreibung bereit. Nur auf deinen Klick wird sie in COMARCH eingesetzt. Noch kein Versand oder Speichern.');return {sourceRow:entry.sourceRow,description:result.description};
}
ui.formulaOK.onchange=safe(()=>{if(member&&ui.formulaOK.checked)return acceptMember(true);clearResult();});
function checkCurrentResult(){Core.need(result&&member,'RESULT_REQUIRED','Zuerst den Member bestätigen und Bestandsabgleich durchführen.');gates();const f=contextOK();Core.need(f===member.element&&f.value===result.memberDisplay,'MEMBER_CHANGED','Member oder Formular wurde nach dem Lookup geändert. Neu bestätigen.');const profile=committedProfile(f);Core.need(!profile.ambiguous&&(!profile.labelFound||profile.clientId===result.clientId),'MEMBER_PROFILE_CONFLICT','MercerID-Stammdaten nach dem Lookup geändert. Neu prüfen.');Core.need(!result.formulas.length||ui.formulaOK.checked,'FORMULA_CACHE_REVIEW','Gespeicherte Formelwerte nicht bestätigt.');return f;}
function descriptionField(){
 const found=new Set();
 for(const doc of documents()){
  for(const l of doc.querySelectorAll('label'))if(/^Zusätzliche Beschreibung\s*:?$/i.test(l.textContent.trim())&&l.htmlFor){const n=doc.getElementById(l.htmlFor);if(n?.tagName==='TEXTAREA'&&visible(n))found.add(n);}
  const candidate=doc.getElementById('mainForm:j_id7019');
  if(candidate?.tagName==='TEXTAREA'&&visible(candidate)){
   // Observed dynamic ID is accepted only with a nearby semantic label, never alone.
   const p=candidate.parentElement;let text=p?.textContent??'';if(text.length<500&&/Zusätzliche Beschreibung/i.test(text))found.add(candidate);
   const prev=candidate.previousElementSibling;if(prev&&/^Zusätzliche Beschreibung\s*:?$/i.test(prev.textContent.trim()))found.add(candidate);
  }
 }
 Core.need(found.size===1,'DESCRIPTION_FIELD','Beschreibungsfeld nicht eindeutig gebunden. „Beschreibung kopieren“ verwenden und selbst einsetzen.');return [...found][0];
}
function applyDescription(){
 checkCurrentResult();const f=descriptionField();Core.need(!f.disabled&&!f.readOnly,'DESCRIPTION_READONLY','Beschreibungsfeld nicht bearbeitbar.');
 Core.need(!f.value.trim()||f.value===result.description,'DESCRIPTION_EXISTS','Vorhandene Beschreibung wird nicht überschrieben. Bitte manuell prüfen.');
 setNativeValue(f,result.description);Core.need(f.value===result.description,'DESCRIPTION_VERIFY','Einsetzen konnte nicht geprüft werden.');descriptionWritten=true;lastOutcome='DESCRIPTION_INSERTED';status('Beschreibung eingesetzt. Noch NICHT gespeichert, keine Antwort versendet. Restlichen Ticketablauf selbst abschließen.');
}
function resetCase(){profileBinding=null;customBinding=null;++caseEpoch;invalidate();mail=null;analysis=null;candidates=[];ui.mailFile.value='';ui.raw.value='';ui.body.textContent='Noch kein Text.';ui.mailInfo.textContent='Noch keine Mail geladen.';ui.names.replaceChildren();ui.first.value='';ui.last.value='';ui.expected.value='';idHints=[];ui.idInfo.textContent='Kein Kennungshinweis aus der Mail.';ui.ticket.value='';ui.mailOK.checked=false;ui.formulaOK.checked=false;ui.memberInfo.textContent='Noch keine Member-Suche gestartet.';lastError=null;lastOutcome=null;format=null;lastWidgetScan=null;go(map&&ui.sourceOK.checked?2:1);status('Neuer Fall. Mapping bleibt geladen. Jetzt die Original-Mail des nächsten Tickets auswählen.');}
function diagnostic(){
 let widget={fieldPresent:false,linkedList:false,declaredCompleteSingle:false,profileLabelFound:false,profileIdPresent:false};
 try{const f=memberField(),p=committedProfile(f);widget={fieldPresent:true,linkedList:!!(f.getAttribute('aria-controls')||f.getAttribute('aria-owns')),declaredCompleteSingle:!!autoCandidate,profileLabelFound:p.labelFound,profileIdPresent:!!p.clientId};}catch{}
 return {schema:'MCR_MAIL_DIAGNOSTIC_V1',version:'0.3.4',createdAt:new Date().toISOString(),
 capabilities:{readsMsg:true,networkUpload:false,automaticSend:false,automaticSave:false,confirmedMemberSearch:true,confirmedDescriptionInsert:true},
 mapping:{loaded:!!map,flagPolicy:map?Core.policyOf(map.payload):null,sourceConfirmed:ui.sourceOK.checked,selectedKeyBlocked:!!lastBlocking,blockedCodes:lastBlocking?.codes??[],blockedIssues:lastBlocking?.issues??[],blockedSourceRowCount:lastBlocking?.sourceRows.length??0},
 mail:{format,nameCandidates:candidates.length,idCandidates:new Set(idHints.map(x=>x.clientId)).size,explicitIdCandidates:analysis?.idHints.length??0,plainText:!!mail},
 flow:{waiting,selectionMode,selectionCommitted,lastSelectionState,ticketAutoBound:context?.detected??false,caseBinding:context?.mode??null,lookupAttempted,lookupKeySource:lookupAttempted?'SELECTED_MEMBER':null,lookupReady:!!result,descriptionWritten,lastOutcome,autoClickAttempted:autoAttempted,selectionEvent:proof?.mode==='COMARCH_MOUSEDOWN_ID'?'mousedown':autoAttempted?'click':null,manualConfirmationPending:manualRequest},widget:{...widget,profile:lastProfileScan,custom:lastCustomScan,ice:lastWidgetScan,localList:lastDomScan,learnedList:!!learnedList,fieldSignals:{...fieldSignals},choiceStructure:lastManualShape},selectionTrace:selectionTrace.map(x=>({...x})),lastError};
}
function crc32(bytes){let c=0xffffffff;for(const b of bytes){c^=b;for(let k=0;k<8;k++)c=(c&1)?0xedb88320^(c>>>1):c>>>1;}return(c^0xffffffff)>>>0;}
function storeZip(files){
 let offset=0;const local=[],central=[],enc=new TextEncoder();
 const concat=parts=>{const all=new Uint8Array(parts.reduce((n,p)=>n+p.length,0));let i=0;for(const p of parts){all.set(p,i);i+=p.length;}return all;};
 for(const [name,text] of files){
  const n=enc.encode(name),data=enc.encode(text),crc=crc32(data),h=new Uint8Array(30),v=new DataView(h.buffer);
  v.setUint32(0,0x04034b50,true);v.setUint16(4,20,true);v.setUint16(6,0x800,true);v.setUint16(12,33,true);v.setUint32(14,crc,true);v.setUint32(18,data.length,true);v.setUint32(22,data.length,true);v.setUint16(26,n.length,true);
  const c=new Uint8Array(46),cv=new DataView(c.buffer);cv.setUint32(0,0x02014b50,true);cv.setUint16(4,20,true);cv.setUint16(6,20,true);cv.setUint16(8,0x800,true);cv.setUint16(14,33,true);cv.setUint32(16,crc,true);cv.setUint32(20,data.length,true);cv.setUint32(24,data.length,true);cv.setUint16(28,n.length,true);cv.setUint32(42,offset,true);
  local.push(h,n,data);central.push(c,n);offset+=h.length+n.length+data.length;
 }
 const cd=concat(central),end=new Uint8Array(22),ev=new DataView(end.buffer);ev.setUint32(0,0x06054b50,true);ev.setUint16(8,files.length,true);ev.setUint16(10,files.length,true);ev.setUint32(12,cd.length,true);ev.setUint32(16,offset,true);
 return concat([...local,cd,end]);
}

async function diagnosticBytes(){
 const report=JSON.stringify(diagnostic(),null,2)+'\n',hash=await sha(report);
 const manifest=JSON.stringify({schema:'MCR_DIAGNOSTIC_MANIFEST_V1',payload:[{path:'diagnostic.json',sha256:hash}],privacy:'No mail bytes/text, names, identifiers, filenames, addresses, URLs, cookies, mapping values or document HTML.'},null,2)+'\n';
 return storeZip([['diagnostic.json',report],['manifest.json',manifest],['SHA256SUMS.txt',hash+'  diagnostic.json\n'+await sha(manifest)+'  manifest.json\n']]);
}
async function downloadDiagnostic(){const bytes=await diagnosticBytes(),hash=await sha(bytes),url=URL.createObjectURL(new Blob([bytes],{type:'application/zip'})),a=D.createElement('a');a.href=url;a.download='MCR_MAIL_'+new Date().toISOString().replace(/[:.]/g,'-')+'_UPLOAD.zip';a.click();setTimeout(()=>URL.revokeObjectURL(url),20000);status('Diagnose-ZIP erstellt (ohne Mail/Mapping). ZIP-SHA256: '+hash);}
function close(){alive=false;++caseEpoch;++mapEpoch;clearInterval(timer);for(const doc of listeners.keys()){doc.removeEventListener('pointerdown',capturePick,true);doc.removeEventListener('mousedown',capturePick,true);doc.removeEventListener('click',capturePick,true);doc.removeEventListener('mouseup',capturePick,true);doc.removeEventListener('keydown',cancelPick,true);doc.removeEventListener('pointerdown',observeChoice,true);doc.removeEventListener('mousedown',observeChoice,true);for(const type of ['input','change','keyup'])doc.removeEventListener(type,observeFieldSignal,true);}listeners.clear();map=null;mail=null;analysis=null;candidates=[];member=null;result=null;proof=null;chosen=null;context=null;ui.raw.value='';ui.body.textContent='';ui.first.value='';ui.last.value='';ui.expected.value='';idHints=[];lastBlocking=null;learnedList=null;pendingLearning=null;lastManualShape=[];profileBinding=null;customBinding=null;pendingCustom=null;pickMode=null;host.remove();if(T.MCR_MAIL===api)delete T.MCR_MAIL;if(W.MCR_MAIL===api)delete W.MCR_MAIL;}
const timer=setInterval(tick,350);
const api=Object.freeze({version:'0.3.4',loadMapText,loadMailBytes,setMail,startSearch,acceptMember,bindProfile:bindProfileOutput,resetCase,diagnostic,diagnosticBytes,close});
T.MCR_MAIL=api;W.MCR_MAIL=api;
console.info('MCR Mail-Assistent 0.3.4 aktiv. Keine Mail-/Personenwerte in der Konsole. Kein Versand, kein Ticket-Speichern.');
