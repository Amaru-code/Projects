"""0.3.4 synthetic DOM/mousedown integration tests. No private COMARCH code.
Fixtures model the supplied call trace and previously unhandled profile layouts.
Runs against native Chromium + a test-only SHA256 bridge on about:blank.
No customer data, actual COMARCH, Windows or production network is accessed.
"""
from pathlib import Path
import json,hashlib,io,zipfile,os
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];GROUP=int(os.environ.get('MCR_GROUP','0'));results=[]
OUT=R/'docs'/('MOUSEDOWN_BROWSER_'+str(GROUP)+'.json')
HTML='''<!doctype html><html lang="de"><meta charset="utf-8"><style>
body{font:16px Arial;margin:24px;background:#eef3f7}form{width:720px;background:white;padding:18px}#searchComponent{position:relative}input{width:530px;padding:8px}#actualPopup{position:absolute;z-index:200;background:#e5f3f6;border:1px solid #689;min-width:530px;max-height:300px;overflow:auto}#actualPopup>div{padding:7px;cursor:pointer;border-bottom:1px solid #abc}td{padding:8px}#profileArea{margin-top:12px}button{padding:8px}textarea{width:550px;height:90px}#mailText{margin-top:30px}</style>
<h1>Fiktiver COMARCH-Adaptertest 0.3.4</h1><p>Nachgebildete Ereignisse und DOM-Strukturen. Keine Produktivverbindung.</p>
<form id="caseForm" onsubmit="return false"><p>Ticket-ID: <span id="ticket">90000001</span></p>
<label>Member</label><div id="searchComponent"><input id="mainForm:member-value-id" autocomplete="off"></div>
<div id="profileArea"><table><tr><td><span><label>MercerID:</label></span></td><td><span><b id="profileValue"></b></span></td><td>PayrollID:</td><td></td></tr></table></div>
<label for="mainForm:j_id7019">Zusätzliche Beschreibung:</label><textarea id="mainForm:j_id7019"></textarea>
<p><button type="button" id="send">Senden</button><button type="button" id="save">Ticket speichern</button></p>
<div id="mailText">Nachrichtenverlauf: fiktive Nachricht</div></form><div id="actualPopup" style="display:none"></div></html>'''
JS='''(()=>{
window.f=document.getElementById('mainForm:member-value-id');window.popup=document.getElementById('actualPopup');
window.mode='one';window.downs=0;window.clicks=0;window.submits=0;window.sends=0;window.saves=0;window.focuses=0;window.eventTypes=[];
// A non-executable script element records only the fixture component signature.
const marker=document.createElement('script');marker.type='application/mcr-fixture';marker.src='about:suggestions.js';document.head.append(marker);
window.iceSubmit=function(){submits++;};window.initWithShowAllOption=function(){focuses++;};
f.onfocus=function(){initWithShowAllOption();};
window.commit=function(id){const p=document.getElementById('profileValue');if(p)p.textContent='INTL01-'+id;};
window.render=()=>{
 popup.replaceChildren();if(!f.value.trim()||f.value.includes('INTL01-')){popup.style.display='none';return;}
 const a=f.getBoundingClientRect();popup.style.left=a.left+'px';popup.style.top=(a.bottom+1)+'px';popup.style.display='block';
 const count=['many','hiddenMany'].includes(mode)?2:1;
 for(let i=0;i<count;i++){
  const row=document.createElement('div'),name=document.createElement('span'),date=document.createElement('span');
  const id=mode==='wrongId'?'99900002':'9990000'+(i+1);
  name.textContent=(mode==='wrongName'?'Andermann Anna':'Mustermann Max')+' (INTL01-'+id+')';date.textContent=' - 1970-01-01';row.append(name,date);
  if(mode==='hiddenMany'&&i===1)row.style.display='none';
  row.onmousedown=function(event){downs++;eventTypes.push(event.type);iceSubmit();f.value='Mustermann Max (INTL01-'+id+')';popup.style.display='none';
   if(mode==='removeField'){setTimeout(()=>{const n=f.cloneNode();f.replaceWith(n);window.f=n;commit(id);},150);}
   else if(mode!=='neverCommit')setTimeout(()=>commit(mode==='wrongCommit'?'99900002':id),150);
  };
  row.onclick=()=>clicks++;popup.append(row);
 }
};
f.onkeyup=()=>render();document.getElementById('send').onclick=()=>sends++;document.getElementById('save').onclick=()=>saves++;
})();'''
base=json.loads((R/'examples/DEMO_mapping.json').read_text());base['payload']['flagPolicy']='ONE_ONLY_BLANK_OMIT_V1'
for e in base['payload']['entries'].values():e.update(flagPolicy='ONE_ONLY_BLANK_OMIT_V1',blankColumns=[])
base['payload']['entries']['99900001'].update(dc=None,blankColumns=['C'])
def mark(name):results.append({'name':name,'status':'PASS'});print('PASS',name,flush=True)
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True)
 page=browser.new_page(viewport={'width':1650,'height':1200});page.set_default_timeout(8000);errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.expose_function('__testSha',lambda v:list(hashlib.sha256(bytes(v)).digest()))
 def reset(mode='one',expected=True,old=False,layout=None,approve=True):
  global page
  page.close();page=browser.new_page(viewport={'width':1650,'height':1200});page.set_default_timeout(8000)
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.expose_function('__testSha',lambda v:list(hashlib.sha256(bytes(v)).digest()))
  page.set_content(HTML)
  page.evaluate("Object.defineProperty(crypto,'subtle',{configurable:true,value:{digest:async(_,data)=>new Uint8Array(await __testSha(Array.from(new Uint8Array(data)))).buffer}})")
  page.evaluate(JS);page.evaluate('(v)=>mode=v',mode)
  if layout is not None:page.locator('#profileArea').evaluate('(n,s)=>n.innerHTML=s',layout)
  if old:
   code=(R/'tests/support/MAIL_033_REFERENCE.js').read_text()
  else:code=(R/'COMARCH_MAIL_ASSISTENT.js').read_text()
  page.evaluate(code)
  page.evaluate('''async raw=>{const m=JSON.parse(raw);const d=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(m.payload)));m.payloadSha256=Array.from(new Uint8Array(d),x=>x.toString(16).padStart(2,'0')).join('');await MCR_MAIL.loadMapText(JSON.stringify(m));}''',json.dumps(base))
  root=page.locator('#__mcr_mail_assistant_v3');root.get_by_label('Diese Bestandsversion',exact=False).check()
  page.evaluate("x=>MCR_MAIL.setMail({format:'MANUAL',subject:x?'Fwd: Max Mustermann, 99900001':'Frage',senderName:'Max Mustermann',senderEmail:'',body:'Mit freundlichen Grüßen\\nMax Mustermann',warnings:[]})",expected)
  if approve:root.get_by_label('Mail gehört zu diesem Ticket',exact=False).check()
  return root
 def start(root):root.get_by_role('button',name='Member suchen',exact=True).click()
 def diag():return page.evaluate('MCR_MAIL.diagnostic()')
 def ready():page.wait_for_function('MCR_MAIL.diagnostic().flow.lookupReady',polling=100,timeout=10000)
 def zeros():assert page.evaluate('[sends,saves]')==[0,0]
 def delay(ms=2600):page.wait_for_timeout(ms)
 def confirm(root):root.get_by_role('button',name='Übernommene Person prüfen → Schritt 4',exact=True).click()
 def manual():page.locator('#actualPopup>div').first.click()
 def bind_section(root):root.get_by_text('Nur bei Erkennungsproblemen: Element einmal verbinden',exact=True).click()
 try:
  if GROUP in (0,1):
   root=reset(old=True);start(root);delay();assert page.evaluate('downs')==0
   manual();delay(1800);assert not diag()['flow']['lookupReady'];assert not diag()['widget']['profileIdPresent']
   assert page.locator('#profileValue').inner_text()=='INTL01-99900001'
   mark('Reproduced 0.3.3 false WAITING_FOR_COMMIT on visible nested table-cell MercerID (synthetic markup)')
   root=reset();page.evaluate("f.value='Mustermann Max';render();popup.firstElementChild.click()")
   assert page.evaluate('[downs,clicks,submits]')==[0,1,0]
   mark('Reproduced click() does not activate mousedown-only COMARCH-like suggestion')
   root=reset();start(root);ready();d=diag();assert d['flow']['selectionMode']=='COMARCH_MOUSEDOWN_ID'
   assert page.evaluate('[downs,clicks,submits]')==[1,0,1];assert page.evaluate('eventTypes')==['mousedown']
   assert d['widget']['profileIdPresent'] and d['widget']['profile']['route']=='WRAPPED_LABEL_VALUE'
   assert 'USC 10/ PP+' in root.locator('.result').inner_text();zeros()
   mark('Custom suggestions signature + exact reviewed ID/name: one mousedown, nested profile read, lookup ready')
   assert page.locator('[id="mainForm:j_id7019"]').input_value()=='';delay();assert page.evaluate('downs')==1
   mark('No repeated selection, automatic description write, send or save')
   root.get_by_role('button',name='Beschreibung in COMARCH einsetzen',exact=True).click();assert page.locator('[id="mainForm:j_id7019"]').input_value()=='USC 10/ PP+';zeros()
   mark('Explicit description write only after selected-member/profile validation')
   page.screenshot(path=str(R/'docs/MOUSEDOWN_READY.png'),full_page=True)
   raw=bytes(page.evaluate('async()=>Array.from(await MCR_MAIL.diagnosticBytes())'))
   with zipfile.ZipFile(io.BytesIO(raw)) as z:
    assert z.testzip() is None
    for line in z.read('SHA256SUMS.txt').decode().splitlines():h,n=line.split('  ');assert hashlib.sha256(z.read(n)).hexdigest()==h
    dtext=z.read('diagnostic.json').decode()
    for no in ['99900001','90000001','Mustermann','Max','profileValue','actualPopup','mainForm','USC 10/ PP+','http']:assert no not in dtext,no
   mark('ZIP diagnostic includes only event/route/boolean/count data; checksums and no private values verified')
  if GROUP in (0,6):
   root=reset();page.evaluate("f.value='Mustermann Max (INTL01-99900001)';commit('99900001')");confirm(root);ready();assert page.evaluate('downs')==0;zeros()
   mark('Already manually selected member resumes directly to step 4 without re-search or selection')
   root=reset();page.evaluate("f.value='Mustermann Max (INTL01-99900001)';commit('99900001')");start(root);ready();assert page.evaluate('downs')==0
   mark('Member suchen on already selected member checks existing state instead of clearing it')
   for mode in ['many','hiddenMany','wrongId','wrongName']:
    root=reset(mode);start(root);delay();assert page.evaluate('downs')==0;assert not diag()['flow']['lookupAttempted'];zeros();mark('No auto-selection for '+mode)
   root=reset('many');start(root);delay(600);manual();ready();assert diag()['flow']['selectionMode']=='USER_CLICK';zeros()
   mark('Genuine user selection from multiple candidates resumes after matching profile')
  if GROUP in (0,4):
   root=reset(expected=False);start(root);delay();assert page.evaluate('downs')==0;manual();ready();zeros()
   mark('Without reviewed mail ID no custom auto-selection; manual selection still yields lookup')
  if GROUP in (0,2):
   root=reset('neverCommit');start(root);page.wait_for_function('downs===1');delay(1700)
   assert not diag()['flow']['lookupAttempted'];confirm(root);delay(1300);assert not diag()['flow']['lookupAttempted'];assert page.evaluate('downs')==1;zeros()
   mark('No lookup or repeated submit for input text without committed profile, even after Continue')
   root=reset('wrongCommit');start(root);page.wait_for_function('downs===1');delay(1600);assert not diag()['flow']['lookupAttempted'];zeros()
   mark('Conflicting committed MercerID remains blocked')
   root=reset('removeField');start(root);ready();assert page.evaluate('downs')==1;zeros()
   mark('Server-like input replacement accepted only with unchanged ticket/document and correct new profile')
   root=reset();start(root);ready();page.evaluate("commit('99900002')");delay(600);assert not diag()['flow']['lookupReady'];assert diag()['lastError']=='MEMBER_PROFILE_CONFLICT';zeros()
   mark('Changing independent profile after lookup invalidates copy/apply immediately')
  if GROUP in (0,7):
   root=reset();start(root);delay(500);page.evaluate("document.getElementById('ticket').textContent='90000002'");delay(1800);assert page.evaluate('downs')==0;assert diag()['lastError']=='TICKET_CHANGED';zeros()
   mark('Changing ticket before selection blocks activation')
   root=reset();start(root);delay(400);page.evaluate("mode='many';render()");delay();assert page.evaluate('downs')==0
   mark('Late second candidate invalidates one-row stabilization')
   root=reset(approve=False);start(root);delay(600);assert page.evaluate('downs')==0;assert diag()['lastError']=='MAIL_REVIEW'
   mark('Unapproved identity cannot start selection')
   # Unknown handlers have an explicit, non-mutating ALT binding path.
   root=reset();page.evaluate("f.onfocus=null;document.querySelector('script[src]').remove()");start(root);delay();assert page.evaluate('downs')==0
   bind_section(root);root.get_by_role('button',name='Vorschlagszeile verbinden',exact=True).click()
   page.locator('#actualPopup>div span').first.click(modifiers=['Alt']);assert page.evaluate('downs')==0
   ready();assert page.evaluate('[downs,submits,clicks]')==[1,1,0];zeros()
   mark('Explicit ALT row binding does not select during marking; later validated auto uses one mousedown')
  if GROUP in (0,5):
   # Profile output far from its label, but nearby the member: binding fallback.
   layout='<span>MercerID:</span><div>Profilansicht</div><div><b id="profileValue"></b></div>'
   root=reset(layout=layout);page.evaluate("f.value='Mustermann Max (INTL01-99900001)';commit('99900001')");confirm(root);delay(1200);assert not diag()['flow']['lookupReady']
   bind_section(root);root.get_by_role('button',name='MercerID-Anzeige verbinden',exact=True).click();page.locator('#profileValue').click(modifiers=['Alt']);ready();assert page.evaluate('downs')==0;zeros()
   mark('Explicit ALT atomic profile binding recovers unknown markup without reselecting or writing an ID')
   # API path equivalent to user selecting the same node in DevTools.
   root=reset(layout=layout);page.evaluate("f.value='Mustermann Max (INTL01-99900001)';commit('99900001');MCR_MAIL.bindProfile(document.getElementById('profileValue'))");ready();zeros()
   mark('Explicit bindProfile($0) recovery supported with same identity gates')
   root=reset();start(root);delay(500)
   failed=page.evaluate("(()=>{try{MCR_MAIL.bindProfile(f);return false}catch(e){return e.code}})()")
   assert failed in ['MEMBER_NOT_SELECTED','PROFILE_BIND_TARGET'];zeros()
   mark('Member input cannot masquerade as independent profile output')
   root=reset();page.evaluate("f.value='Mustermann Max (INTL01-99900001)';commit('99900002')")
   failed=page.evaluate("(()=>{try{MCR_MAIL.bindProfile(document.getElementById('profileValue'));return false}catch(e){return e.code}})()")
   assert failed=='MEMBER_PROFILE_CONFLICT';zeros()
   mark('Explicit binding cannot override conflicting person identity')
   root=reset();start(root);delay(300);root.get_by_role('button',name='Suche / Warten stoppen',exact=True).click();delay();assert page.evaluate('downs')==0
   mark('Stop disarms pending automation')
  if GROUP in (0,3):
   page.evaluate('window.MCR_MAIL?.close()');page.set_content(HTML);page.evaluate((R/'lib/member-profile.cjs').read_text())
   layouts=[
    ('direct sibling','<span>MercerID:</span><b>INTL01-99900001</b>'),
    ('table nested label wrappers','<table><tr><td><div><span><label>MercerID:</label></span></div></td><td><div><span>INTL01-99900001</span></div></td><td>PayrollID:</td><td>88888888</td></tr></table>'),
    ('definition list','<dl><dt><b>MercerID:</b></dt><dd><span>INTL01-99900001</span></dd></dl>'),
    ('sibling wrappers','<div><span>MercerID:</span></div><div><span><b>INTL01-99900001</b></span></div>'),
    ('text node','<span>MercerID:</span> INTL01-99900001'),
    ('readonly input','<label for="profile">MercerID:</label><input readonly id="profile" value="INTL01-99900001">'),
    ('NBSP','<span>MercerID\u00a0:</span><b>INTL01-99900001</b>')]
   for label,markup in layouts:
    page.locator('#profileArea').evaluate('(n,v)=>n.innerHTML=v',markup)
    p=page.evaluate("MCRMemberProfile.inspect(document.getElementById('mainForm:member-value-id'))")
    assert p['clientId']=='99900001' and not p['ambiguous'],(label,p);mark('Profile layout: '+label)
   negatives=[
    ('empty label','<span>MercerID:</span><b></b>'),
    ('name suggestion not ID','<span>MercerID:</span><b>Mustermann Max (INTL01-99900001)</b>'),
    ('hidden value','<span>MercerID:</span><b hidden>INTL01-99900001</b>'),
    ('writable field','<label for="x">MercerID:</label><input id="x" value="INTL01-99900001">'),
    ('nearby unlabeled digits','<span>MercerID:</span><b></b><span>INTL01-99900001</span>'),
    ('value includes extra label','<span>MercerID:</span><div>PayrollID: <b>99900001</b></div>')]
   for label,markup in negatives:
    page.locator('#profileArea').evaluate('(n,v)=>n.innerHTML=v',markup)
    p=page.evaluate("MCRMemberProfile.inspect(document.getElementById('mainForm:member-value-id'))")
    assert p['clientId'] is None,(label,p);mark('Profile rejection: '+label)
   page.locator('#profileArea').evaluate("n=>n.innerHTML='<span>MercerID:</span><b>INTL01-99900001</b><span>MercerID:</span><b>INTL01-99900002</b>'")
   p=page.evaluate("MCRMemberProfile.inspect(document.getElementById('mainForm:member-value-id'))");assert p['ambiguous'] and p['clientId'] is None;mark('Two conflicting profile outputs reject rather than choose a convenient match')
   root=reset();start(root);delay(400);root.get_by_role('button',name='Member-Suchfeld anzeigen (keine Auswahl)',exact=True).click();assert page.evaluate('focuses')==1;zeros()
   mark('Show-field button only scrolls/highlights and does not refocus/resubmit search')
   root=reset();start(root);delay(400);page.evaluate('MCR_MAIL.close()');delay(2400);assert page.evaluate('downs')==0;assert not page.locator('#__mcr_mail_assistant_v3').count();zeros()
   mark('Closing helper cancels pending timers and removes listeners')
  assert not errors,errors
  OUT.write_text(json.dumps({'group':GROUP,'environment':{'os':'Linux','browser':'Chromium','url':'about:blank','shaBridge':'test-only','actualCOMARCH':False,'originalSuggestionsSourceAvailable':False},'tests':results,'passed':len(results),'pageErrors':errors},indent=2)+'\n')
  print('TOTAL PASS',len(results))
 except Exception as e:
  try:page.screenshot(path=str(R/'docs/MOUSEDOWN_FAILED.png'),full_page=True);print(json.dumps(diag(),indent=2),flush=True)
  except:pass
  OUT.write_text(json.dumps({'tests':results,'passedBeforeFailure':len(results),'error':str(e),'pageErrors':errors},indent=2)+'\n');raise
 finally:browser.close()
