import {mapping as stockFixture,row as stockRow} from './helpers.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {runAccountStatement,accountCommand} from '../lib/phase2-statement-generator.mjs';
import {generatorPaths} from '../lib/phase2-pdf-evidence.mjs';
import {preparePhase2PdfEvidence} from '../src/phase2-pdf-prepare.mjs';
import {preflightPhase2Write} from '../src/phase2-comarch-pilot.mjs';
import {choosePhase2Candidate} from '../src/phase2-run.mjs';
import {phase2Inventory} from '../lib/phase2-readonly.mjs';
import {planPhase2UploadContinuation} from '../lib/phase2-upload-continuation.mjs';
import {writeJSON} from '../lib/control.mjs';
import {hasAutomaticDocumentPreparation} from '../lib/phase2-ao-proof.mjs';

const id='99000001',wwid='1378',person={first:'Mara',last:'Muster',mercerId:'77000000'};
const member={wwid,profileVerified:true,profile:person};
const pdfReader=fileURLToPath(new URL('../tools/statement-pdf-person.py',import.meta.url));
const smallPdf='%PDF-1.4\n'+'synthetic\n'.repeat(30)+'%%EOF\n';
const sha=x=>createHash('sha256').update(x).digest('hex');
const row={ticketId:id,descriptionValue:'USC 20/DC;PP+\nStandardantwort versendet\nMöchte KA',source:'E-MAIL',intelGroupVerified:true,groupName:'Intel Deutschland GmbH'};

function fixture(t){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'mcr-test-statement-'));
 t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
 fs.mkdirSync(path.join(root,'.runtime','phase2'),{recursive:true});
 const paths=(root,plan)=>{
  const folder=path.join(root,'K (DC & PP+)','Kontoauszug_'+plan);
  return {folder,statementOutput:path.join(folder,'Ausgabe_PDF')};
 };
 for(const plan of ['DC','PP+']){
  const p=paths(root,plan);fs.mkdirSync(p.statementOutput,{recursive:true});
  fs.writeFileSync(path.join(p.folder,accountCommand(plan,wwid)[0]),'# fixture only');
  const required=plan==='DC'?['_2026_LNW_DC_Output.xlsm','Personenordner_Zuordnung.csv']:
   ['IPP Kontoauszüge Updates_Template.xlsm','IPP_Kontoauszuege_Arbeitsdatei.xlsm','Kontostand_Kontrolle_Arbeitsdatei.xlsm',
    '../Daten/eckwerte_runtime.py','../Daten/Personenordner_Zuordnung.csv'];
  for(const dep of required){const f=path.resolve(p.folder,dep);fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,'fixture');}
 }
 return {root,paths};
}

test('new DC and PP+ paths and literal CLI arguments under K:',()=>{
 for(const plan of ['DC','PP+']){
  const p=generatorPaths('/fixture',plan);
  assert.equal(p.statementOutput,path.win32.join(p.folder,'Ausgabe_PDF'));
  assert(p.folder.startsWith('K:'));assert(p.folder.includes(' & '));
 }
 assert.deepEqual(accountCommand('DC',wwid),['kontoauszug_dc_generator.py','--wwid',wwid]);
 assert.deepEqual(accountCommand('PP+',wwid),['kontoauszug_generator.py','--wwid',wwid,'--stichtag','31.12.2026']);
 assert.throws(()=>accountCommand('PP+','1378 & echo 1'),{code:'P2_WWID_INVALID'});
});

test('bound CLI output retains original filename from current process and ignores distinct secondary copy',async t=>{
 const {root,paths}=fixture(t),p=paths(root,'DC');
 const filename=path.join(p.statementOutput,'2026_DC_Kontoauszug_Muster M.pdf');
 const other=path.join(root,'persoenlicher Ordner.pdf');
 const script=accountCommand('DC',wwid)[0];
 fs.writeFileSync(path.join(p.folder,script),[
  'import os, sys, pathlib',
  "assert sys.argv[1:] == ['--wwid', '1378'] and sys.stdin.read() == ''",
  'assert pathlib.Path.cwd() == pathlib.Path(__file__).parent',
  'f=pathlib.Path('+JSON.stringify(filename)+')',
  'f.write_text('+JSON.stringify(smallPdf)+')',
  'g=pathlib.Path('+JSON.stringify(other)+')',
  'g.write_bytes(f.read_bytes())',
  'print("PERSON_FOLDER_UNAVAILABLE")',
  'print("PDF:" + str(f))',
  'print("Personenordner: " + str(g))'
 ].join('\n'));
 const result=await runAccountStatement(root,'DC',wwid,{paths,person});
 assert.equal(result.status,'GENERATOR_EXECUTED',JSON.stringify(result));
 assert.equal(result.warning,'P2_KONTOAUSZUG_PERSON_FOLDER_UNAVAILABLE');
 assert.equal(result.artifact.file,filename);assert.equal(result.artifact.sha256,sha(smallPdf));
 assert.equal(result.artifact.statementReceipt.personCheck,'OPERATOR_REQUIRED');
});

test('numeric balance alone never binds an identity; canonical filename or labeled WWID plus full name does',()=>{
 const py="import runpy,sys; identify=runpy.run_path(sys.argv[1])['identify']; name='example.pdf'; args=('1378','Mara','Muster','DC'); assert identify('Mara Muster Betrag 1378',name,*args)=='REVIEW'; assert identify('Mara Muster WWID: 1378',name,*args)=='MATCH'; assert identify('Mara Muster WWID: 1378 WWID: 2222',name,*args)=='MISMATCH'; assert identify('Muster, Mara','1378_Kontoauszug_DC.pdf',*args)=='MATCH'; assert identify('Mara Muster WWID: 1234','1378_Kontoauszug_DC.pdf',*args)=='MISMATCH'; assert identify('Muster WWID 1378',name,*args)=='REVIEW'";
 const r=spawnSync('python',['-c',py,pdfReader],{encoding:'utf8'});assert.equal(r.status,0,r.stderr);
});

for(const [label,code] of [
 ['input','INPUT_REQUIRED'],['copy','PERSON_FOLDER_UNAVAILABLE'],['nonzero','GENERATOR_FAILED'],
 ['no_stdout','PDF_MISSING'],['stale','PDF_MISSING'],['outside','PDF_MISSING'],['ambiguous','AUDIT_REQUIRED'],
 ['wrong_id','AUDIT_REQUIRED'],['changed_during_read','AUDIT_REQUIRED'],['foreign_reader_bytes','AUDIT_REQUIRED'],['wrong_person','AUDIT_REQUIRED']
]){
 test('statement generator isolates '+label+' with no stale upload',async t=>{
  const {root,paths}=fixture(t),p=paths(root,'PP+');
  const file=path.join(p.statementOutput,label==='wrong_id'?'7788_Kontoauszug_PP+.pdf':'Statement.pdf');
  if(label==='stale')fs.writeFileSync(file,smallPdf);
  const result=await runAccountStatement(root,'PP+',wwid,{paths,person,run:async args=>{
   if(args[0]===pdfReader){
    if(label==='changed_during_read')fs.appendFileSync(file,'x');
    const status=label==='wrong_person'?'MISMATCH':'MATCH';
    return {exitCode:0,stderr:'',stdout:JSON.stringify({sha256:label==='foreign_reader_bytes'?'0'.repeat(64):sha(smallPdf),status})};
   }
   if(label!=='stale')fs.writeFileSync(file,smallPdf);
   const other=path.join(label==='ambiguous'?p.statementOutput:root,'Copy.pdf');fs.writeFileSync(other,smallPdf);
   return {exitCode:['input','copy','nonzero'].includes(label)?1:0,
    stderr:label==='input'?'PP_INPUT_REQUIRED':label==='copy'?'PERSON_FOLDER_UNAVAILABLE':'',
    stdout:label==='no_stdout'?'OK':label==='outside'?other:label==='ambiguous'?[file,other].join('\n'):file};
  }});
  assert.equal(result.error,'P2_KONTOAUSZUG_'+code,JSON.stringify(result));assert.equal(result.artifact,undefined);
 });
}

test('fresh multi-plan CLI -> ticket proof -> exact new files and journal including original filenames',async t=>{
 const {root,paths}=fixture(t),plans=[];
 const gen=(root,plan,id,opts)=>runAccountStatement(root,plan,id,{...opts,run:async args=>{
  if(args[0]===pdfReader)return {exitCode:0,stdout:JSON.stringify({status:'MATCH',sha256:sha(smallPdf+plan)}),stderr:''};
  const p=paths(root,plan);const out=path.join(p.statementOutput,plan+' Kontoauszug Muster.pdf');
  plans.push(plan);fs.writeFileSync(out,smallPdf+plan);return {exitCode:0,stdout:out,stderr:''};
 }});
 const neverAsk=()=>assert.fail('current member + positive PDF identities must not require manual pre-upload approval');
 const opts={root,page:{},row,mapping:stockFixture([stockRow({B:wwid,C:1,D:1})]),ask:neverAsk,memberLookup:async()=>member,log:()=>{},
  paths,statementGenerator:gen,ui:{assertTicket:async()=>{}},openTicket:async()=>{}};
 const prepared=await preparePhase2PdfEvidence(opts);assert.equal(prepared.status,'PDF_PROOF_READY',JSON.stringify(prepared));
 assert.deepEqual(plans,['DC','PP+']);assert(hasAutomaticDocumentPreparation(prepared.proof));
 writeJSON(path.join(root,'.runtime','phase2','MCR_PHASE2_LETZTE_INVENTUR.json'),phase2Inventory([row]));
 const pilot=preflightPhase2Write(root,id,{expectedProofFile:prepared.file,paths});
 assert.equal(pilot.preview.reviewAssignee,'mark.baindl');assert.equal(pilot.wwid,wwid);
 const artifacts=pilot.verified.artifacts,names=artifacts.map(a=>a.name);
 const upload=planPhase2UploadContinuation({artifacts,evidence:{items:names.map(name=>({name,status:'ABSENT',count:0,present:false,ready:false}))}});
 assert.equal(upload.missing.length,2);
 const j=pilot.journal;j.begin();j.advance('UPLOAD_INTENT');
 assert.throws(()=>j.recordUploadFileIntent({...artifacts[0],name:'different.pdf'}),{code:'P2_UPLOAD_FILE_INTENT'});
 for(const a of artifacts){j.recordUploadFileIntent(a);j.recordUploadFileProvisional(a);}
 j.recordUploadVisualReview({names});
 assert.equal(choosePhase2Candidate([row],{getPdfJournal:()=>j.read(),accountReady:()=>true,prepareMissingPdf:true}).pdfPreparationRequired,undefined);
 await assert.rejects(preparePhase2PdfEvidence(opts),{code:'P2_PDF_PREP_PREVIOUS_ACTION'});
 fs.appendFileSync(artifacts[0].file,'changed');
 assert.throws(()=>preflightPhase2Write(root,id,{expectedProofFile:prepared.file,paths}),{code:'P2_PDF_MUTATED'});
});

test('kombinierter AO/Kontoauszug with failed statement leaves no partial ticket proof or upload',async t=>{
 const {root,paths}=fixture(t);
 const result=await preparePhase2PdfEvidence({root,page:{},row:{...row,descriptionValue:row.descriptionValue+' & AO'},
  mapping:stockFixture([stockRow({B:wwid,C:1,D:1})]),ask:()=>assert.fail(),memberLookup:async()=>member,log:()=>{},paths,
  statementGenerator:async()=>({status:'GENERATOR_NOT_VERIFIED',error:'P2_KONTOAUSZUG_INPUT_REQUIRED'}),
  generator:()=>assert.fail('no partial job'),ui:{assertTicket:async()=>{}},openTicket:async()=>{}});
 assert.equal(result.reason,'P2_KONTOAUSZUG_INPUT_REQUIRED');assert.equal(result.noWrite,true);
 assert.equal(fs.existsSync(path.join(root,'.runtime','phase2','actions','MCR_PHASE2_'+id+'.json')),false);
});

test('all requested statement plans and WWID must be present in current stock before either generator starts',async t=>{
 const {root,paths}=fixture(t);
 for(const sourceRow of [stockRow({B:'7788'}),stockRow({B:wwid,C:1,D:0}),stockRow({B:wwid,C:2,D:1})]){
  const result=await preparePhase2PdfEvidence({root,page:{},row,mapping:stockFixture([sourceRow]),paths,
   ui:{assertTicket:async()=>{}},openTicket:async()=>{},memberLookup:async()=>member,ask:()=>assert.fail(),
   log:()=>{},statementGenerator:()=>assert.fail('incomplete combined case must never start a single generator')});
  assert.equal(result.reason,'P2_KONTOAUSZUG_GENERATOR_PREFLIGHT_FAILED');
  assert.equal(result.noWrite,true);assert.match(result.technicalDetails.generatorReason,/Bestand/);
 }
});
