import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {readLiveWorkbook,refreshLiveWorkbook,assertLiveWorkbookCurrent,inspectWorkbookQueueBoundary,phase1WorkbookBoundaryProof} from '../lib/live-workbook.mjs';
import {fixture,row,cells} from './rc97-workbook-fixture.mjs';
import {ROOT} from './helpers.mjs';
import {masterRun} from '../tools/cli.mjs';

const digest='a'.repeat(64);
function environment(bytes=fixture()){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'mcr105-boundary-')),file=path.join(root,'current.xlsx');
 fs.mkdirSync(path.join(root,'config'));fs.writeFileSync(file,bytes);
 fs.writeFileSync(path.join(root,'config/local-runner-queue-send.json'),JSON.stringify({stockWorkbookPath:file}));
 return {root,file,close:()=>fs.rmSync(root,{recursive:true,force:true})};
}
test('RC105 workbook digest ignores added empty/styled/contact-only rows',()=>{
 const f=environment();try{
  const first=refreshLiveWorkbook(f.root),hash=readLiveWorkbook(f.file).businessSha256;
  fs.writeFileSync(f.file,fixture({rows:`<row r="3">${cells({...row,L:'20'},3)}</row><row r="9" ht="19"/><row r="10"><c r="FM10" t="inlineStr"><is><t>test@example.invalid</t></is></c></row>`}));
  assert.equal(readLiveWorkbook(f.file).businessSha256,hash);
  assert.equal(assertLiveWorkbookCurrent(f.root,first).businessSha256,hash);
  assert.equal(refreshLiveWorkbook(f.root).fileHash,first.fileHash);
 }finally{f.close();}
});
test('RC105 workbook digest is independent of formula/error cell XML order',()=>{
 const values={...row};delete values.C;delete values.D;
 const c='<c r="C2"><f>1+0</f><v>1</v></c>',d='<c r="D2"><f>0+0</f><v>0</v></c>';
 const f=environment(fixture({values,extraCells:c+d}));try{
  const first=readLiveWorkbook(f.file).businessSha256;
  fs.writeFileSync(f.file,fixture({values,extraCells:d+c}));
  assert.equal(readLiveWorkbook(f.file).businessSha256,first);
 }finally{f.close();}
});
test('RC105 queue boundary detects real USC change without modifying snapshot or workbook',()=>{
 const f=environment();try{
  const active=refreshLiveWorkbook(f.root),pointer=fs.readFileSync(active.pointerPath);
  const changed=fixture({values:{...row,L:'77'}});fs.writeFileSync(f.file,changed);
  const boundary=inspectWorkbookQueueBoundary(f.root,active);
  assert.deepEqual(boundary,{status:'REFRESH_REQUIRED',schema:'MCR_WORKBOOK_QUEUE_BOUNDARY_V1',reason:'WORKBOOK_DATA_CHANGED',nextTicketOpened:false,mappingSha256:active.fileHash});
  assert.ok(fs.readFileSync(active.pointerPath).equals(pointer));assert.ok(fs.readFileSync(f.file).equals(changed));
  assert.throws(()=>assertLiveWorkbookCurrent(f.root,active),{code:'WORKBOOK_DATA_CHANGED'});
 }finally{f.close();}
});
test('RC105 verified empty queue needs no workbook read and source/read failures do not gain retry authority',()=>{
 let calls=0;const assertCurrent=()=>{calls++;throw Object.assign(new Error('changed'),{code:'WORKBOOK_DATA_CHANGED'});};
 assert.deepEqual(inspectWorkbookQueueBoundary('x',{}, {queueExhausted:true,assertCurrent}),{status:'QUEUE_EXHAUSTED'});assert.equal(calls,0);
 for(const code of ['WORKBOOK_UNAVAILABLE','WORKBOOK_SOURCE_CHANGED','WORKBOOK_CHANGED_DURING_READ','OPERATOR_ABORT'])
  assert.throws(()=>inspectWorkbookQueueBoundary('x',{}, {assertCurrent:()=>{throw Object.assign(new Error('test'),{code});}}),{code});
});
const diagnostic=()=>({schema:'MCR_LOCAL_RUNNER_DIAGNOSTIC_V2',mode:'REAL',lastError:null,phase:'QUEUE_BOUNDARY',mapping:{fileHash:digest},
 loop:{completed:true,finishReason:'WORKBOOK_REBIND_AT_QUEUE_BOUNDARY',processed:0,processedTickets:[]},
 send:{clicked:false,verified:false},save:{clicked:false,verified:false},
 workbookBoundary:{status:'REFRESH_REQUIRED',schema:'MCR_WORKBOOK_QUEUE_BOUNDARY_V1',reason:'WORKBOOK_DATA_CHANGED',nextTicketOpened:false,mappingSha256:digest}});
test('RC105 workbook boundary proof rejects incomplete action, wrong phase, unknown error and unbound mapping',()=>{
 assert.equal(phase1WorkbookBoundaryProof(diagnostic()),true);
 for(const mutate of [d=>d.send={clicked:true,verified:false},d=>d.save={clicked:true,verified:false},d=>d.forward={clicked:true,verified:false},
  d=>d.phase='SEND_AND_SAVE',d=>d.lastError='OPERATOR_ABORT',d=>d.workbookBoundary.nextTicketOpened=true,
  d=>d.workbookBoundary.mappingSha256='b'.repeat(64),d=>d.loop.completed=false,d=>d.loop.processed=1]){
  const d=diagnostic();mutate(d);assert.equal(phase1WorkbookBoundaryProof(d),false);
 }
 const done=diagnostic();done.loop.processed=1;done.loop.processedTickets=[{sendAck:'BOUND_NEW_OUTGOING_HISTORY',save:'MY_TASKS_ALL_DESCRIPTION_CONTENT_MATCH'}];done.send={clicked:true,verified:true};done.save={clicked:true,verified:true};
 assert.equal(phase1WorkbookBoundaryProof(done),true);
});
function masterFixture(){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'mcr105-master-boundary-'));
 fs.cpSync(ROOT,root,{recursive:true,filter:p=>!p.includes('/.runtime/')&&!p.includes('/diagnostics/')&&!p.includes('/Ergebnis/')});
 return {root,close:()=>fs.rmSync(root,{recursive:true,force:true})};
}
const empty={pilotVerified:false,noEligible:true,processed:0,runId:'2026-11-20T12-00-00_empty',reason:'NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS'};
const sent={pilotVerified:true,processed:1,runId:'2026-11-20T12-00-00_sent'};
const phase2={status:'COMPLETED_VISIBLE_SCOPE',processed:1,skipped:[],scope:'VISIBLE_MY_TASKS_NO_PAGINATION',runId:'phase2-test'};
function boundary(mappingSha256='TEST_ONLY',processed=0){return {verified:true,workbookRefreshRequired:true,processed,runId:'2026-11-20T12-00-00_boundary',finishReason:'WORKBOOK_REBIND_AT_QUEUE_BOUNDARY',workbookBoundary:{status:'REFRESH_REQUIRED',schema:'MCR_WORKBOOK_QUEUE_BOUNDARY_V1',reason:'WORKBOOK_DATA_CHANGED',nextTicketOpened:false,mappingSha256}};}
test('RC105 master immediately enters phase2 after certified empty phase1 without another confirmation',async()=>{
 const f=masterFixture(),calls=[];try{
  const r=await masterRun({rootDir:f.root,confirm:async()=>{calls.push('start');return 'MASTER_START';},output:()=>{},
   runPhase1:async()=>{calls.push('empty');return empty;},runPhase2:async()=>{calls.push('phase2');return phase2;},
   refreshAtBoundary:()=>{throw Error('empty queue requires no rebinding');}});
  assert.deepEqual(calls,['start','empty','phase2']);assert.equal(r.state,'COMPLETE_VISIBLE_SCOPE');
 }finally{f.close();}
});
test('RC105 master rebinds initial changed workbook then scans under same start approval',async()=>{
 const f=masterFixture(),calls=[];let n=0;try{
  const r=await masterRun({rootDir:f.root,confirm:async()=>{calls.push('start');return 'MASTER_START';},output:()=>{},
   runPhase1:async(pilot,opts)=>{assert.equal(pilot,true);calls.push('pilot');if(n++===0)return boundary();assert.equal(opts.masterBoundaryApproved,true);return empty;},
   refreshAtBoundary:()=>{calls.push('refresh');return {fileHash:digest};},runPhase2:async()=>{calls.push('phase2');return phase2;}});
  assert.deepEqual(calls,['start','pilot','refresh','pilot','phase2']);assert.equal(r.mappingSha256,digest);assert.equal(r.phase1.workbookRebindings.length,1);
 }finally{f.close();}
});
test('RC105 master keeps completed batch counts and requires new pilot after boundary rebind',async()=>{
 const f=masterFixture(),calls=[];let n=0;try{
  const r=await masterRun({rootDir:f.root,confirm:async()=> 'MASTER_START',output:()=>{},
   runPhase1:async(pilot,opts)=>{calls.push(pilot?'pilot':'batch');n++;if(n===1)return sent;if(n===2){assert.equal(pilot,false);return boundary('TEST_ONLY',2);}assert.equal(pilot,true);assert.equal(opts.masterBoundaryApproved,true);return empty;},
   refreshAtBoundary:()=>{calls.push('refresh');return {fileHash:digest};},runPhase2:async()=>{calls.push('phase2');return phase2;}});
  assert.deepEqual(calls,['pilot','batch','refresh','pilot','phase2']);assert.equal(r.completion.phase1Processed,3);
 }finally{f.close();}
});
test('RC105 master limits rebinding to three and never converts explicit abort into continuation',async()=>{
 const f=masterFixture();let calls=0,refreshes=0;try{
  await assert.rejects(()=>masterRun({rootDir:f.root,confirm:async()=> 'MASTER_START',output:()=>{},
   runPhase1:async()=>boundary(calls++===0?'TEST_ONLY':digest),refreshAtBoundary:()=>{refreshes++;return {fileHash:digest};},
   runPhase2:async()=>{throw Error('phase2 must not run');}}),{code:'WORKBOOK_CHANGING_REPEATEDLY'});
  assert.equal(calls,4);assert.equal(refreshes,3);
  await assert.rejects(()=>masterRun({rootDir:f.root,confirm:async()=> 'MASTER_START',output:()=>{},
   runPhase1:async()=>{throw Object.assign(new Error('abort'),{code:'OPERATOR_ABORT'});},
   refreshAtBoundary:()=>{throw Error('must not rebind');},runPhase2:async()=>{throw Error('must not continue');}}),{code:'OPERATOR_ABORT'});
 }finally{f.close();}
});
