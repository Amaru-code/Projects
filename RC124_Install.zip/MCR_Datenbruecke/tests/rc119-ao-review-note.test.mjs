import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {temp} from './helpers.mjs';
import {isConfirmedAoFailure,pendingAoReviewNote,saveAoReviewNote,withAoReviewNote} from '../lib/phase2-ao-review-note.mjs';
import {descriptionPhase2Rule} from '../lib/phase2-description.mjs';
import {choosePhase2Candidate} from '../src/phase2-run.mjs';

const id='99981119',note='Manuel review required';
const row={ticketId:id,descriptionValue:'USC 10 / PP+\nStandardantwort versendet\nMöchte Auszahlungsoption'};
const prepared={ticketId:id,reason:'AO_CONTROL_YEAR_MISSING',technicalDetails:{audit_sha256:'b'.repeat(64),audit_reason:'Jahreszeile fehlt.'},
 reviewMember:{mercerId:'1234',wwid:'5678'}};
function fixture(t){
 const root=temp();t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
 let field=row.descriptionValue,storage=field;const events=[];
 const args={root,page:{},row,prepared,log:()=>{},ask:async()=>{throw Error('unexpected prompt')},checkAllowed:()=>{},
  ui:{assertTicket:async(_page,x)=>assert.equal(x,id),additionalDescriptionState:async()=>({ok:true,editable:true,value:field}),
   navigateToScope:async()=>events.push('queue')},
  memberLookup:async()=>({profileVerified:true,profile:{mercerId:'1234'},memberReferenceWwid:'5678'}),
  edit:async()=>events.push('edit'),
  commit:async(_page,{expected,allowedBefore})=>{assert.deepEqual(allowedBefore,[field]);field=expected;events.push('edit note')},
  watch:async()=>({settle:async()=>({status:'NETWORK_QUIET'}),cancel:()=>{}}),
  save:async(_page,{preActionCheck,beforeAutoClick})=>{await preActionCheck();await beforeAutoClick();events.push('save');storage=field;},
  queue:async()=>({ok:true,rows:[{...row,descriptionValue:storage}]}),
  open:async()=>{events.push('open saved ticket');field=storage;}};
 return {root,args,events,setField:v=>{field=v;},storage:()=>storage};
}

test('Audited business failure adds exactly the requested fourth line and verifies the single save by reopening',async t=>{
 const f=fixture(t);
 assert.equal(await saveAoReviewNote(f.args),'VERIFIED');
 assert.deepEqual(f.events,['edit','edit note','save','queue','open saved ticket']);
 assert.equal(f.storage(),row.descriptionValue+'\n'+note);
 assert.equal(descriptionPhase2Rule({...row,descriptionValue:f.storage()}).reason,'P2_AO_MANUAL_REVIEW_REQUIRED');
 const journal=JSON.parse(fs.readFileSync(path.join(f.root,'.runtime/phase2/actions/MCR_AO_NOTE_'+id+'.json')));
 assert.equal(journal.state,'VERIFIED');assert.equal(journal.verifiedBy,'REOPENED_TICKET');
 assert.equal(journal.reason,prepared.reason);
});
test('Fourth line preserves multiple source rows and the combined original request exactly',()=>{
 const original='USC 8 / DC\r\nUSC 9 / PP+\r\nStandardantwort versendet\r\nMöchte Kontoauszug & Auszahlungsoption\r\n';
 const marked=withAoReviewNote({...row,descriptionValue:original});
 assert.equal(marked.split('\n')[3],note);
 assert.equal(marked.split('\n').filter(line=>line!==note).join('\r\n'),original);
 assert.throws(()=>withAoReviewNote({...row,descriptionValue:marked}),{code:'P2_AO_NOTE_DESCRIPTION_CHANGED'});
});
test('Unconfirmed, technical and skipped jobs do not acquire a manual review note',()=>{
 assert.equal(isConfirmedAoFailure(prepared),true);
 for(const change of [{reason:'PP_INPUT_REQUIRED'},{reason:'AO_CONTACT_INPUT_DEFERRED'},{reason:'AO_EXCEL_INIT_FAILED'},{technicalDetails:{}},{reviewMember:null}]){
  assert.equal(isConfirmedAoFailure({...prepared,...change}),false);
 }
});
test('Different person or operator changed description prevents writes',async t=>{
 const f=fixture(t);
 await assert.rejects(saveAoReviewNote({...f.args,memberLookup:async()=>({profileVerified:true,profile:{mercerId:'1234'},wwid:'9999'})}),{code:'P2_AO_NOTE_MEMBER_CHANGED'});
 f.setField(row.descriptionValue+'!');
 await assert.rejects(saveAoReviewNote(f.args),{code:'P2_AO_NOTE_DESCRIPTION_CHANGED'});
 assert.equal(f.events.includes('save'),false);
});
test('Indeterminate save is never repeated and only exact independent server readback clears the intent',async t=>{
 const f=fixture(t);
 const interrupted=async(_page,{beforeAutoClick})=>{await beforeAutoClick();f.events.push('save attempted');throw Error('connection lost');};
 await assert.rejects(saveAoReviewNote({...f.args,save:interrupted}),/connection lost/);
 assert.equal(pendingAoReviewNote(f.root,row),true);
 const next={ticketId:'99981120',descriptionValue:row.descriptionValue};
 const pick=choosePhase2Candidate([row,next],{prepareMissingPdf:true,pendingReviewNote:r=>pendingAoReviewNote(f.root,r)});
 assert.equal(pick.row.ticketId,next.ticketId);assert.equal(pick.skipped[0].reason,'P2_AO_NOTE_PENDING');
 await assert.rejects(saveAoReviewNote(f.args),{code:'P2_AO_NOTE_PENDING'});
 assert.equal(pendingAoReviewNote(f.root,{...row,descriptionValue:row.descriptionValue+'\n'+note}),false);
 assert.equal(f.events.filter(x=>x==='save attempted').length,1);
});
test('A saved marker keeps the case open. Removing the marker restores eligibility',()=>{
 const marked={...row,descriptionValue:withAoReviewNote(row)};
 const opts={prepareMissingPdf:true};
 assert.equal(choosePhase2Candidate([marked],opts).row,null);
 assert.equal(choosePhase2Candidate([row],opts).row.ticketId,id);
});
