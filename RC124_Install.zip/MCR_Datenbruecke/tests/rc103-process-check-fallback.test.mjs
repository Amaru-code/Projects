import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import fs from 'node:fs';
import {readWindowsProcessSnapshot,windowsIdle} from '../tools/process-guard.mjs';
const root='C:\\Projects\\MCR_Datenbruecke';
const profile=root+'\\.runtime\\edge-profile';
const p=(pid,cmd,parentPid=1)=>({pid,parentPid,name:'node.exe',
 createdAt:'2026-11-20T08:00:00.000Z',executablePath:'C:\\Program Files\\nodejs\\node.exe',
 commandLine:'"C:\\Program Files\\nodejs\\node.exe" "'+cmd+'"'});
const good=[p(750,'C:\\Other\\safe.mjs')];
const snapshot=(list=good)=>({schema:'MCR_WINDOWS_PROCESS_SNAPSHOT_V1',checked:true,processes:list});
const isCim=(args)=>path.win32.basename(args.at(-1))==='process-guard.ps1';
const isWmi=(args)=>path.win32.basename(args.at(-1))==='process-guard-wmi.ps1';

test('RC103: CIM timeout -> fresh WMI snapshot, no unchecked idle shortcut',()=>{
 const calls=[];const runner=(_bin,args,opts)=>{
  calls.push({args,timeout:opts.timeout});
  if(isCim(args)){const e=new Error('timed out');e.code='ETIMEDOUT';throw e;}
  assert.equal(isWmi(args),true);return JSON.stringify(snapshot());
 };
 const result=readWindowsProcessSnapshot({ownPid:750,runner,prefer:'CIM'});
 assert.equal(result.provider,'WMI');assert.equal(calls.length,2);
 assert.equal(calls[0].timeout,18000);assert.equal(calls[1].timeout,23000);
 const proof=windowsIdle(root,{platform:'win32',excludePid:750,profileDirectory:profile,readSnapshot:()=>result});
 assert.equal(proof.checked,true);assert.equal(proof.blockedCount,0);assert.equal(proof.snapshotProvider,'WMI');
});

test('RC103: a successful preferred WMI check is fresh every time, no cached process IDs',()=>{
 let calls=0;const runner=(_bin,args)=>{calls++;assert.equal(isWmi(args),true);return JSON.stringify(snapshot());};
 const first=readWindowsProcessSnapshot({runner,ownPid:750,prefer:'WMI'});
 const second=readWindowsProcessSnapshot({runner,ownPid:750,prefer:'WMI'});
 assert.equal(first.provider,'WMI');assert.equal(second.provider,'WMI');assert.equal(calls,2);
});

test('RC103: incomplete or malformed CIM result cannot be treated as proof',()=>{
 for(const broken of [
  {schema:'MCR_WINDOWS_PROCESS_SNAPSHOT_V1',checked:true,processes:[]},
  snapshot([p(950,'C:\\Other\\unrelated.mjs')]),
  snapshot([good[0],good[0]]),
  {schema:'MCR_WINDOWS_PROCESS_SNAPSHOT_V1',checked:true,processes:[{pid:'750',parentPid:1,name:'node.exe'}]}
 ]){
  let calls=0;const result=readWindowsProcessSnapshot({prefer:'CIM',ownPid:750,runner:(_bin,args)=>{
   calls++;return JSON.stringify(isCim(args)?broken:snapshot());
  }});
  assert.equal(result.provider,'WMI');assert.equal(calls,2);
 }
});

test('RC103: WMI fallback with existing owned runner must block startup',()=>{
 const owned=p(751,root+'\\src\\local-bot-full-run.mjs');
 const result=readWindowsProcessSnapshot({prefer:'CIM',ownPid:750,runner:(_bin,args)=>{
  if(isCim(args))throw Object.assign(new Error('bad'),{code:'EACCES'});
  return JSON.stringify(snapshot([...good,owned]));
 }});
 assert.throws(()=>windowsIdle(root,{platform:'win32',excludePid:750,profileDirectory:profile,readSnapshot:()=>result}),{code:'MCR_PROCESSES_ACTIVE'});
});

test('RC103: two unavailable providers must fail closed with explicit bounded reasons',()=>{
 const result=()=>readWindowsProcessSnapshot({prefer:'CIM',ownPid:750,runner:(_bin,args)=>{
  if(isCim(args))throw Object.assign(new Error('timeout'),{code:'ETIMEDOUT'});
  throw Object.assign(new Error('denied'),{code:'EACCES'});
 }});
 assert.throws(result,e=>e.code==='PROCESS_CHECK_UNAVAILABLE'&&
  /CIM:TIMEOUT.*WMI:POWERSHELL_BLOCKED/.test(e.message));
});

test('RC103: bounded migration snapshot check passes timeout to each provider',()=>{
 const timeouts=[];
 const result=readWindowsProcessSnapshot({prefer:'CIM',ownPid:750,timeout:6500,runner:(_bin,args,opts)=>{
  timeouts.push(opts.timeout);
  if(isCim(args))throw Object.assign(new Error('timeout'),{code:'ETIMEDOUT'});
  return JSON.stringify(snapshot());
 }});
 assert.equal(result.provider,'WMI');assert.deepEqual(timeouts,[6500,6500]);
});

test('RC103: fallback PowerShell script exists with WMI Win32_Process enumeration, no Get-Process-only snapshot',()=>{
 const rootDir=new URL('../tools/',import.meta.url);
 const wmi=fs.readFileSync(new URL('process-guard-wmi.ps1',rootDir),'utf8');
 const stop=fs.readFileSync(new URL('process-stop.ps1',rootDir),'utf8');
 assert.match(wmi,/Get-WmiObject -Class Win32_Process/);
 assert.match(wmi,/ManagementDateTimeConverter/);
 assert.match(stop,/Get-WmiObject -Class Win32_Process -Filter/);
 assert.match(stop,/Same-Identity/);
 assert.match(stop,/Stop-Process -InputObject \$process/);
});
