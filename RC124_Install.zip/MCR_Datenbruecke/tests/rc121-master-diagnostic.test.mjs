import test from 'node:test';
import assert from 'node:assert/strict';
import {runnerDiagnosticError} from '../tools/cli.mjs';

test('RC121 master identifies only the unresolved Intel views from the current runner diagnostic',()=>{
 const diagnostic={lastError:'INTL_SCOPE_NOT_AVAILABLE',phase:'QUEUE_BOUNDARY',
  navigation:{missingScopes:['IN_BEARBEITUNG','IN_BEARBEITUNG','unrelated form data']}};
 const error=runnerDiagnosticError(diagnostic);
 assert.deepEqual(error.missingScopes,['IN_BEARBEITUNG']);
 assert.match(error.message,/IN_BEARBEITUNG/);
 assert.doesNotMatch(error.message,/unrelated form data/);
 assert.equal(error.runnerPhase,'QUEUE_BOUNDARY');
 assert.equal(runnerDiagnosticError({...diagnostic,lastError:'TICKET_BINDING'}).missingScopes,undefined);
 assert.equal(runnerDiagnosticError({...diagnostic,navigation:undefined}).code,'INTL_SCOPE_NOT_AVAILABLE');
});
