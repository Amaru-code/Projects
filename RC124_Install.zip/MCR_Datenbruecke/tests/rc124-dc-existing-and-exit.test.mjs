import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {mapping as makeMapping,row as makeStock} from './helpers.mjs';
import {preparePhase2PdfEvidence} from '../src/phase2-pdf-prepare.mjs';
import {preflightPhase2Write} from '../src/phase2-comarch-pilot.mjs';
import {inspectExistingStatements,pdfSignature} from '../lib/phase2-pdf-evidence.mjs';
import {phase2Inventory} from '../lib/phase2-readonly.mjs';
import {canReuseCurrentPdfApproval} from '../lib/phase2-pdf-approval.mjs';
import {planPhase2UploadContinuation} from '../lib/phase2-upload-continuation.mjs';
import {writeJSON} from '../lib/control.mjs';

const ticketId='99124560',wwid='11368594',name=wwid+'_Kontoauszug_DC.pdf';
const row={ticketId,descriptionValue:'USC 20/DC\nStandardantwort versendet\nMöchte KA',
 source:'E-MAIL',intelGroupVerified:true,groupName:'Intel Deutschland GmbH'};
const member={wwid,profileVerified:true,profile:{first:'Test',last:'Muster',mercerId:'77222222'}};

// A real PDF text page, independently readable by the production extractor.
function document(id){
 const text='BT /F1 12 Tf 48 720 Td (Test Muster WWID: '+id+' Kontoauszug DC 2026) Tj ET';
 const objects=['<< /Type /Catalog /Pages 2 0 R >>','<< /Type /Pages /Count 1 /Kids [3 0 R] >>',
  '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>',
  '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>','<< /Length '+text.length+' >>\nstream\n'+text+'\nendstream'];
 let out='%PDF-1.4\n';const offsets=[0];
 for(const [i,value] of objects.entries()){offsets.push(out.length);out+=(i+1)+' 0 obj\n'+value+'\nendobj\n';}
 const xref=out.length;
 return out+'xref\n0 6\n0000000000 65535 f \n'+offsets.slice(1).map(n=>String(n).padStart(10,'0')+' 00000 n \n').join('')+
  'trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n'+xref+'\n%%EOF\n';
}

function fixture(t){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'mcr-rc124-statement-'));
 t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
 const folder=path.join(root,'Kontoauszug_DC'),statementOutput=path.join(folder,'Ausgabe_PDF');
 fs.mkdirSync(statementOutput,{recursive:true});const file=path.join(statementOutput,name);
 for(const n of ['_2026_LNW_DC_Output.xlsm','Personenordner_Zuordnung.csv'])fs.writeFileSync(path.join(folder,n),'fixture');
 const paths=()=>({folder,statementOutput}),log=[];
 const opts={root,paths,row,page:{},mapping:makeMapping([makeStock({B:wwid,C:1,D:0})]),
  openTicket:async()=>{},ui:{assertTicket:async(_page,id)=>assert.equal(id,ticketId)},memberLookup:async()=>member,
  ask:()=>assert.fail('unplanned operator prompt'),log:x=>log.push(x)};
 fs.mkdirSync(path.join(root,'.runtime/phase2'),{recursive:true});
 writeJSON(path.join(root,'.runtime/phase2/MCR_PHASE2_LETZTE_INVENTUR.json'),phase2Inventory([row]));
 return {root,file,folder,paths,opts,log};
}

for(const existing of [true,false])test('RC124 '+(existing?'reviewed pre-existing':'silent successful CLI')+' exact DC to the upload journal',async t=>{
 const f=fixture(t);
 const body=document(wwid),script=path.join(f.folder,'kontoauszug_dc_generator.py');
 if(existing){
  fs.writeFileSync(f.file,body);
  const old=new Date(Date.now()-600000);fs.utimesSync(f.file,old,old);
  fs.writeFileSync(script,'raise RuntimeError("existing reviewed PDF must not be regenerated")');
 }else{
  fs.writeFileSync(script,'from pathlib import Path\nPath("Ausgabe_PDF/'+name+'").write_bytes('+JSON.stringify(body)+'.encode("ascii"))\n');
 }
 const answer=async q=>{assert(existing);assert(q.includes(wwid)&&q.includes('Zeitraum'));return 'JA';};
 const prepared=await preparePhase2PdfEvidence({...f.opts,reviewExistingDc:existing,ask:answer});
 assert.equal(prepared.status,'PDF_PROOF_READY',JSON.stringify(prepared));
 const pilot=preflightPhase2Write(f.root,ticketId,{expectedProofFile:prepared.file,paths:f.paths});
 const artifact=pilot.verified.artifacts[0];
 assert.equal(artifact.file,f.file);
 assert.equal(prepared.proof.operatorContentReviewed,existing);
 assert.equal(artifact.provenance,existing?'CENTRAL_DC_OPERATOR_REVIEW':'STATEMENT_GENERATOR_CLI');
 assert(canReuseCurrentPdfApproval({pdfReviewedThisRun:true,sessionPresent:true,ticketId,proof:prepared.proof,member,wwid}));
 const upload=planPhase2UploadContinuation({artifacts:[artifact],evidence:{items:[{name,status:'ABSENT',count:0,present:false,ready:false}]}});
 assert.equal(upload.missing.length,1);
 pilot.journal.begin();pilot.journal.advance('UPLOAD_INTENT');pilot.journal.recordUploadFileIntent(artifact);
 await assert.rejects(preparePhase2PdfEvidence({...f.opts,reviewExistingDc:true}),{code:'P2_PDF_PREP_PREVIOUS_ACTION'});
 fs.appendFileSync(f.file,'changed');
 assert.throws(()=>preflightPhase2Write(f.root,ticketId,{expectedProofFile:prepared.file,paths:f.paths}),{code:'P2_PDF_MUTATED'});
});

test('RC124 existing-file review rejects conflicting PDF identity, incomplete bytes, refusal and mutation',async t=>{
 for(const mode of ['foreign','incomplete','refusal','mutated']){
  await t.test(mode,async t=>{
   const f=fixture(t);
   fs.writeFileSync(f.file,mode==='incomplete'?'%PDF-1.4'+'x'.repeat(500):document(mode==='foreign'?'99445566':wwid));
   const answer=async()=>{assert(['refusal','mutated'].includes(mode));if(mode==='mutated')fs.appendFileSync(f.file,'changed');return mode==='refusal'?'UEBERSPRINGEN':'JA';};
   const call=()=>preparePhase2PdfEvidence({...f.opts,reviewExistingDc:true,ask:answer,statementGenerator:()=>assert.fail('no implicit regeneration')});
   if(mode==='mutated')await assert.rejects(call(),{code:'P2_PDF_MUTATED'});
   else{
    const result=await call();assert.equal(result.status,'SKIPPED_UNCHANGED');
    assert.equal(result.reason,mode==='refusal'?'PDF_CONTENT_REVIEW_DEFERRED':'P2_KONTOAUSZUG_AUDIT_REQUIRED');
   }
  });
 }
});


test('verified named AO is read directly from its output directory; links and changed bytes still block',t=>{
 const f=fixture(t),output=path.dirname(f.file),name='2026-12-31_Auszahlungsoption_Muster Test_'+wwid+'.pdf';
 const selected=path.join(output,name),foreign=path.join(output,'different-ticket.pdf');
 fs.writeFileSync(selected,document(wwid));
 const artifact={plan:'AO',provenance:'CENTRAL_AO_GENERATOR_AUDIT',name,...pdfSignature(selected)};
 const check=choice=>inspectExistingStatements(f.root,['AO'],wwid,{...member.profile,year:2026,paths:()=>({output}),selectedArtifacts:[choice]});
 // An unrelated PDF entry that is a directory must never be inspected.
 fs.mkdirSync(foreign);assert.equal(check(artifact).artifacts[0].sha256,artifact.sha256);
 assert.throws(()=>check({...artifact,name:'../'+name}),{code:'P2_PDF_SELECTION'});
 fs.appendFileSync(selected,'changed');
 assert.throws(()=>check(artifact),{code:'P2_PDF_MUTATED'});
 if(process.platform!=='win32'){
  const dest=path.join(f.root,'external');
  fs.renameSync(selected,dest);fs.symlinkSync(dest,selected);
  assert.throws(()=>check(artifact),{code:'LINK_BLOCKED'});
 }
});

test('RC124 local finalized receipt reaches the attachment boundary while the copy and redirected stdout are still open',async t=>{
 const f=fixture(t),marker=path.join(f.folder,'release-copy');
 const script=[
  'from pathlib import Path','import os, sys, time',
  'sys.stdout = open(os.devnull, "w")',
  'def copy_to_person_folder(pdf, *, employee_wwid):',
  '    for n in range(400):',
  '        if Path("release-copy").exists(): return',
  '        time.sleep(.05)',
  '    raise OSError("archive timeout")',
  'pdf=Path("Ausgabe_PDF") / "'+name+'"',
  'pdf.write_bytes('+JSON.stringify(document(wwid))+'.encode("ascii"))',
  'copy_to_person_folder(pdf, employee_wwid=sys.argv[2])'
 ].join('\n');
 fs.writeFileSync(path.join(f.folder,'kontoauszug_dc_generator.py'),script);
 const {runAccountStatement}=await import('../lib/phase2-statement-generator.mjs');
 const {setTimeout:wait}=await import('node:timers/promises');
 try{
  const prepared=await preparePhase2PdfEvidence({...f.opts,statementGenerator:(root,plan,id,opts)=>
   runAccountStatement(root,plan,id,{...opts,handoffMs:25,timeoutMs:5000})});
  assert.equal(prepared.status,'PDF_PROOF_READY',JSON.stringify(prepared));
  const pilot=preflightPhase2Write(f.root,ticketId,{expectedProofFile:prepared.file,paths:f.paths});
  assert.equal(pilot.verified.artifacts[0].statementReceipt.postprocessing,'RUNNING');
  assert(!fs.existsSync(marker));
  const manualWhileBusy=await preparePhase2PdfEvidence({...f.opts,reviewExistingDc:true});
  assert.equal(manualWhileBusy.reason,'P2_KONTOAUSZUG_GENERATOR_BUSY');
 }finally{
  fs.writeFileSync(marker,'1');
  const dir=path.join(f.root,'.runtime/phase2/dc-generator');
  for(let i=0;i<100;i++){
   const files=fs.existsSync(dir)?fs.readdirSync(dir).filter(n=>n.endsWith('.json')):[];
   if(files.length&&JSON.parse(fs.readFileSync(path.join(dir,files[0]))).event==='EXIT')break;
   await wait(20);
  }
 }
});
