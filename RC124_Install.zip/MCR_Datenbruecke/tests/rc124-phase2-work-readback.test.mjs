import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage,sleep} from '../lib/cdp.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
import {setPhase2Gevo,savePhase2Ticket,phase2FieldSnapshot} from '../lib/phase2-comarch-actions.mjs';
import {openPhase2Ticket} from '../lib/phase2-navigation.mjs';
import {bindSavedWorkQueue,observedWorkSave} from '../lib/phase2-saved-work-readback.mjs';
import {watchPhase2Save} from '../lib/phase2-save-settle.mjs';
const id='91000001';

test('RC123 MBC journal with a settled click is readback-only, even before the first verified save',()=>{
 const journal={schema:'MCR_PHASE2_WORK_JOURNAL_V1',ticketId:id,state:'TICKET_SAVE_INTENT',
  events:['DRAFT_SAVE_INTENT','MBC_SIGNATURE_DRAFT_SAVE_VERIFIED','DRAFT_SAVE_VERIFIED','TICKET_SAVE_INTENT',
   'TICKET_SAVE_AUTO_CLICK_INTENT','TICKET_SAVE_NETWORK_OBSERVED'].map(state=>({state}))};
 assert.equal(observedWorkSave(journal,id),true);
 assert.equal(observedWorkSave(journal,'91000002'),false);
 assert.equal(observedWorkSave({...journal,events:[...journal.events,{state:'EXECUTE_INTENT'}]},id),false);
 assert.equal(observedWorkSave({...journal,events:journal.events.slice(0,-2)},id),false);
});

async function withPage(run){
 const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-P2-DOM-RC124-'));let browser,cdp;
 try{
  browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',
   headless:true,extraArgs:process.platform==='linux'?['--no-sandbox','--disable-dev-shm-usage']:[]});
  ({cdp}=await connectBrowser(browser.port));
  const page=await attachPage(cdp,t=>t.type==='page'&&t.url==='about:blank');
  await run(page);
 }finally{await cleanupTemporaryTestBrowser({profile,browser,cdp});}
}

test('MBC selection and single-save readback from a covered detail in the same tab',{timeout:45000},()=>withPage(async page=>{
 const requests=[];
 let savedGevo='';
 const edit='<h1>Ticket-ID: '+id+'</h1><input id="mainForm:gevo-value-id" aria-controls="gevo-results">'+
  '<input aria-controls="other-results"><ul role="listbox" id="other-results"><li role="option">Anfrage Member</li></ul>'+
  '<ul role="listbox" id="gevo-results" hidden><li role="option">Anfrage Member Plus</li><li id="correct" role="option">Anfrage Member</li></ul>'+
  '<button id="save">Ticket speichern</button><script>'+
  'const field=document.getElementById("mainForm:gevo-value-id"),list=document.getElementById("gevo-results");'+
  'field.oninput=()=>setTimeout(()=>{list.hidden=false;},180);'+
  'correct.onclick=e=>{window.optionTrusted=e.isTrusted;field.value=correct.textContent;list.hidden=true;};'+
  'save.onclick=e=>{if(e.isTrusted)fetch("/save",{method:"POST",body:field.value}).then(r=>r.text());};</script>';
 const queue='<div id="storedSearchesContainer_MY_TASKS"><a class="selected">In_Bearbeitung</a></div>'+
  '<table id="mainForm:tasksTableFor_MyTasksList"><thead><tr><th>Ticket-ID</th><th>Quelle</th><th>Zusätzliche Beschreibung</th><th>Gruppenname</th></tr></thead>'+
  '<tbody><tr><td><a href="/saved">'+id+'</a></td><td>E-MAIL</td><td>Entwurf vorbereitet</td><td>Intel</td></tr></tbody></table>';
 const server=http.createServer((req,res)=>{
  requests.push(req.method+' '+req.url);
  res.setHeader('Content-Type','text/html;charset=utf-8');res.setHeader('Cache-Control','no-store');
  if(req.url==='/save'&&req.method==='POST'){
   let body='';req.on('data',d=>body+=d);req.on('end',()=>{savedGevo=body;res.end('OK');});return;
  }
  if(req.url==='/saved'){res.end('<h1>Ticket-ID: '+id+'</h1><input id="mainForm:gevo-value-id" value="'+savedGevo+'">');return;}
  res.end(req.url==='/workspace'?queue:req.url==='/edit'?edit:'');
 });
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 try{
  const origin='http://127.0.0.1:'+server.address().port;
  await page.cdp.send('Page.navigate',{url:origin+'/edit'},page.sessionId);
  for(let i=0;i<40&&!await page.call(()=>!!document.getElementById('save'));i++)await sleep(80);
  const mark=await setPhase2Gevo(page,{ticketId:id});
  assert.equal(mark.label,'Anfrage Member');assert.equal(await page.call(()=>window.optionTrusted),true);
  const watch=await watchPhase2Save(page);
  const click=await savePhase2Ticket(page,{ticketId:id});
  assert.equal(click.automaticClicks,1);assert.equal((await watch.settle()).status,'NETWORK_QUIET');
  assert.equal(savedGevo,mark.label);
  await page.call(()=>{
   const cover=document.createElement('div');cover.style='position:fixed;inset:0;background:white';document.body.append(cover);
   cover.innerHTML='<div role="dialog"><progress></progress>Bitte warten</div>';
   setTimeout(()=>cover.firstElementChild.remove(),400);
  });
  const queue=await bindSavedWorkQueue(page,{url:origin+'/workspace',ticketId:id});
  assert.equal(queue.rows.length,1);assert.equal(queue.rows[0].ticketId,id);
  await openPhase2Ticket(page,queue.rows[0]);assert.equal((await phase2FieldSnapshot(page)).gevo.value,mark.label);
  assert.equal(requests.filter(r=>r==='GET /workspace').length,1);
  const before=requests.length;
  await assert.rejects(()=>bindSavedWorkQueue(page,{url:origin+'/workspace',ticketId:'91000002'}),
   {code:'P2_WORK_SAVE_READBACK_PENDING'});
  await page.call(()=>{document.body.insertAdjacentHTML('beforeend','<div role="dialog">Unbekannter Dialog</div>');});
  await assert.rejects(()=>bindSavedWorkQueue(page,{url:origin+'/workspace',ticketId:id}),
   {code:'P2_WORK_SAVE_READBACK_PENDING'});
  assert.equal(requests.slice(before).filter(r=>r.endsWith('/workspace')).length,0);
  assert.deepEqual(requests.filter(r=>r.startsWith('POST')),['POST /save']);
 }finally{server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}
}));
