export async function installFixture(page,{rows=[
  ['99021001','Fremde GmbH','In Bearbeitung',''],
  ['99021002','Intel Deutschland GmbH','Abgeschlossen',''],
  ['99021003','Intel Deutschland GmbH','In Bearbeitung',''],
  ['99021004','Intel Deutschland GmbH','In Bearbeitung',''],
],labels=['Ticket-ID','Group Name','Status','Quelle','Zusätzliche Beschreibung']}={}) {
 await page.call((rows,labels)=>{
  document.body.innerHTML='<nav><a id="general">Offene Vorgänge</a><div id="storedSearchesContainer_MY_TASKS"></div><div id="storedSearchesContainer_MY_QUEUES"></div></nav><main id="view"></main>';
  window.fixtureEvents=[];
  document.getElementById('general').onclick=()=>window.fixtureEvents.push('general');
  const view=document.getElementById('view');
  const table=document.createElement('table');
  table.id='mainForm:tasksTableFor_MyTasksList';
  table.createCaption().textContent='Meine Vorgänge';
  const head=table.createTHead().insertRow();
  for (const label of labels) {
   const header=document.createElement('th');
   header.textContent=label;
   head.append(header);
  }
  const body=table.createTBody();
  for (const [id,group,status,description] of rows) {
   const row=body.insertRow();
   for (const [i,field] of [id,group,status,'E-MAIL',description].entries()) {
    const cell=row.insertCell();
    if(i!==0){cell.textContent=field;continue;}
    const button=document.createElement('button');
    button.type='button';
    button.textContent=id;
    button.onclick=()=>{
     window.fixtureEvents.push(id);
     const detail=document.createElement('h2');
     detail.textContent='Ticket-ID: '+id;
     view.textContent='';view.append(detail);
    };
    cell.append(button);
   }
  }
  view.append(table);
 },rows,labels);
}

export async function checkIncident(page, UI, findPhase1Candidate, assert) {
 const own='IN_BEARBEITUNG';
 const id='99021004';
 const processed=new Set(['99021003']);
 const noPrompt=()=>assert.fail('The exact INTL01 row is available in the displayed own-tasks table');
 const readList=(scope,opts)=>UI.navigateToScope(page,scope,opts);
 const findOwnTicket=({allowOperator})=>UI.findOwnPhase1Ticket(page,{processed,ask:noPrompt,allowOperator});
 await installFixture(page);
 const chosen=await findPhase1Candidate({processed,readList,findOwnTicket,ask:noPrompt,resetView:noPrompt});
 assert.equal(chosen.scope,own);
 assert.equal(chosen.row.ticketId,id);
 assert.deepEqual(await page.call(()=>window.fixtureEvents),[]);
 await page.call(()=>{document.querySelector('table tbody tr:last-child').cells[1].textContent='Fremde GmbH';});
 await assert.rejects(()=>UI.openTicket(page,chosen.row,{scope:chosen.scope}));
 assert.deepEqual(await page.call(()=>window.fixtureEvents),[]);
 await installFixture(page);
 const current=await findOwnTicket({allowOperator:false});
 assert.equal(current.row.ticketId,id);
 assert.equal((await UI.openTicket(page,current.row,{scope:current.scope})).mode,'AUTO');
 assert.equal(await UI.detailTicketId(page),id);
 assert.deepEqual(await page.call(()=>window.fixtureEvents),[id]);
 await installFixture(page,{rows:[[id,'Intel Deutschland GmbH','In Bearbeitung','USC 20 / DC\nStandardantwort versendet']]});
 const readback=await UI.readPhase1OwnTicket(page,current.row);
 assert.equal(readback.ticketId,id);
 assert.match(readback.descriptionRaw,/Standardantwort versendet/);
 await page.call(()=>{document.querySelector('table tbody tr').cells[1].textContent='Fremde GmbH';});
 assert.equal(await UI.readPhase1OwnTicket(page,current.row),null);
 for(const data of [
    {rows:[['99021005','Fremde GmbH','In Bearbeitung','INTL01'],['99021006','Intel International Holdings','In Bearbeitung','']]},
    {rows:[['99021007','Intel Deutschland GmbH','Erledigt','']]},
    {rows:[['99021008','Intel Deutschland GmbH','In Bearbeitung','']],labels:['Ticket-ID','Betreff','Status','Quelle','Zusätzliche Beschreibung']},
    {rows:[['99021009','Intel Deutschland GmbH','In Bearbeitung','']],labels:['Ticket-ID','Group Name','Group Name','Quelle','Zusätzliche Beschreibung']}
 ]){
  await installFixture(page,data);
  assert.equal(await findOwnTicket({allowOperator:false}),null);
  assert.deepEqual(await page.call(()=>window.fixtureEvents),[]);
 }
}

// Historical branch headers and stored-search span structure from the RC28
// continuation fixture. A general table is already occupied on startup.
export async function installLegacyMenu(page, ownRowsAvailable=false){
 await page.call(ownAvailable=>{
  document.body.innerHTML='<nav><a id="other">Offene Vorgänge</a><a title="Meine Vorgänge" id="my-header">Meine Vorgänge</a><span id="storedSearchesContainer_MY_TASKS" style="display:none"><a id="my-child">In_Bearbeitung</a></span><a title="Warteschlange" id="queue-header">Warteschlange</a><span id="storedSearchesContainer_MY_QUEUES" style="display:none"><a id="queue-child">INTL01</a></span></nav><main id="main"></main>';
  window.fixtureEvents=[];
  const ids=document.getElementById.bind(document);
  const table=(family,id)=>{
   const main=ids('main');
   main.innerHTML='<table id="mainForm:tasksTableFor_'+family+'"><thead><tr><th>Ticket-ID</th><th>Quelle</th><th>Zusätzliche Beschreibung</th></tr></thead><tbody></tbody></table>';
   if(!id)return;
   const tr=main.querySelector('tbody').insertRow();
   const first=tr.insertCell(),button=document.createElement('button');
   button.type='button';button.textContent=id;first.append(button);
   tr.insertCell().textContent='E-MAIL';tr.insertCell();
   button.onclick=()=>{window.fixtureEvents.push(id);main.textContent='';const title=document.createElement('h2');title.textContent='Ticket-ID: '+id;main.append(title);};
  };
  table('MyTasksList','99022001');
  ids('other').onclick=()=>window.fixtureEvents.push('foreign');
  const connect=(kind,container,family,id)=>{
   ids(kind+'-header').onclick=()=>{window.fixtureEvents.push(kind+'-header');ids(container).style.display='inline';};
   ids(kind+'-child').onclick=()=>{
    window.fixtureEvents.push(kind+'-child');
    for(const item of document.querySelectorAll('nav span a'))item.style.fontWeight='normal';
    ids(kind+'-child').style.fontWeight='bold';
    table(family,id);
   };
  };
  connect('my','storedSearchesContainer_MY_TASKS','MyTasksList',ownAvailable?'99022002':null);
  connect('queue','storedSearchesContainer_MY_QUEUES','MyQueuesTasksList','99022003');
 },ownRowsAvailable);
}

export async function checkLegacyMenu(page, UI, findPhase1Candidate, assert){
 for(const ownRowsAvailable of [false,true]){
  await installLegacyMenu(page,ownRowsAvailable);
  const unexpected=()=>assert.fail('Verified legacy parent and child must be resolved before any reset, row fallback, or operator prompt');
  const chosen=await findPhase1Candidate({processed:new Set(),readList:(scope,options)=>UI.navigateToScope(page,scope,options),findOwnTicket:unexpected,ask:unexpected,resetView:unexpected});
  const id=ownRowsAvailable?'99022002':'99022003';
  assert.equal(chosen.scope,ownRowsAvailable?'IN_BEARBEITUNG':'WARTESCHLANGE_INTL01');
  assert.equal(chosen.row.ticketId,id);
  assert.equal((await UI.openTicket(page,chosen.row,{scope:chosen.scope})).mode,'AUTO');
  assert.equal(await UI.detailTicketId(page),id);
  assert.deepEqual(await page.call(()=>window.fixtureEvents),ownRowsAvailable?['my-header','my-child',id]:['my-header','my-child','queue-header','queue-child',id]);
 }
}
