import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {createHash} from 'node:crypto';
import {reusableAoProof} from '../lib/phase2-ao-reuse.mjs';
import {verifyAoGeneratorProof} from '../lib/phase2-ao-proof.mjs';
import {reviewedPdfProof,preparePhase2PdfEvidence} from '../src/phase2-pdf-prepare.mjs';
import {inspectExistingStatements,generatorPaths} from '../lib/phase2-pdf-evidence.mjs';
import {fixture,row,cells} from './rc97-workbook-fixture.mjs';
import {refreshLiveWorkbook} from '../lib/live-workbook.mjs';
import {writeJSON} from '../lib/control.mjs';
const sha=x=>createHash('sha256').update(x).digest('hex');
const wwid='11369951',id='89664431';
const member={profileVerified:true,profile:{mercerId:'99900001',first:'Boris',last:'Schmulewitsch'},memberReferenceWwid:wwid,wwid:null};
const ticket={ticketId:id,descriptionValue:'USC 20/PP+\nStandardantwort versendet\nMöchte Auszahlungsoption'};
const document='%PDF-1.4\n'+('Fake no actual calculation.\n'.repeat(30))+'%%EOF';
function setup(){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'mcr106-reuse-')),w=path.join(root,'current.xlsx');
 fs.mkdirSync(path.join(root,'config'));
 fs.mkdirSync(path.join(root,'.runtime','phase2'),{recursive:true});
 fs.writeFileSync(path.join(root,'config/local-runner-queue-send.json'),JSON.stringify({stockWorkbookPath:w}));
 fs.writeFileSync(w,fixture({values:{...row,B:wwid},rows:`<row r="3">${cells({...row,B:'22336688'},3)}</row>`}));
 const active=refreshLiveWorkbook(root),mapping=active.map;
 const base=path.join(root,'AO'),output=path.join(base,'Ausgabe PDF'),audit=path.join(base,'Audit_Logs');
 fs.mkdirSync(output,{recursive:true});fs.mkdirSync(audit,{recursive:true});
 const sourcePaths={script:path.join(base,'auszahlungsoption_generator.py'),master:path.join(base,'master.xlsx'),control:path.join(base,'control.xlsm'),workbook:path.join(base,'working.xlsm')};
 for(const [key,file] of Object.entries(sourcePaths))fs.writeFileSync(file,'fixture '+key);
 const paths=(r,plan)=>plan==='AO'?{...generatorPaths(r,plan),output,audit,...sourcePaths}:generatorPaths(r,plan);
 const name=`${new Date().getFullYear()}-12-31_Auszahlungsoption_Schmulewitsch Boris_${wwid}.pdf`;
 const pdfFile=path.join(output,name),auditFile=path.join(audit,'20261120_115850_'+wwid+'.json');
 const auditData={timestamp:'2026-11-20T11:58:50',wwid,status:'success',record:187,name:'Schmulewitsch Boris',stichtag:`31.12.${new Date().getFullYear()}`,contact_supplied:false,pdf:pdfFile};
 const generate=(fresh=false)=>{
  const startedAtMs=Date.now();
  const currentAudit=fresh?path.join(audit,new Date().toISOString().slice(0,19).replace(/-/g,'').replace('T','_').replace(/:/g,'')+'_'+wwid+'.json'):auditFile;
  const currentData=fresh?{...auditData,timestamp:new Date().toISOString()}:auditData;
  fs.writeFileSync(pdfFile,document);fs.writeFileSync(currentAudit,JSON.stringify(currentData));
  fs.utimesSync(pdfFile,new Date(startedAtMs),new Date(startedAtMs));fs.utimesSync(currentAudit,new Date(startedAtMs),new Date(startedAtMs));
  return {schema:'MCR_AO_GENERATOR_PROOF_V1',requestId:'0'.repeat(32),wwid,name:auditData.name,stichtag:auditData.stichtag,
   stichtagIso:`${new Date().getFullYear()}-12-31`,file:pdfFile,auditFile:currentAudit,sha256:sha(fs.readFileSync(pdfFile)),bytes:fs.statSync(pdfFile).size,
   auditSha256:sha(fs.readFileSync(currentAudit)),sourceSha256:sha(fs.readFileSync(sourcePaths.script)),calculationEvidence:{schema:'MCR_AO_CALCULATION_INPUTS_V1',record:187,...Object.fromEntries(Object.entries(sourcePaths).map(([k,file])=>[k,sha(fs.readFileSync(file))]))},generatedAt:new Date().toISOString(),auditTimestamp:currentData.timestamp,freshness:{schema:'MCR_AO_FRESH_GENERATION_V1',startedAtMs,newPdf:true,newAudit:true,pdfMtimeMs:fs.statSync(pdfFile).mtimeMs,auditMtimeMs:fs.statSync(currentAudit).mtimeMs}};
 };
 const store=(gen,includeBinding=true)=>{
  const a=verifyAoGeneratorProof(root,gen,{wwid,first:'Boris',last:'Schmulewitsch',paths,fresh:true});
  const before=inspectExistingStatements(root,['AO'],wwid,{first:'Boris',last:'Schmulewitsch',selectedArtifacts:[a],paths});
  const p=reviewedPdfProof({root,ticketId:id,rule:{targets:['AO']},wwid,member,before,wwidOrigin:'BOUND_INTL01_MEMBER_REFERENCE',planEvidence:{verified:true},automaticAo:true,paths});
  if(includeBinding)p.memberBusinessEvidence={schema:'MCR_AO_MEMBER_WORKBOOK_V1',wwid,fingerprint:sha(JSON.stringify({id:wwid,records:mapping.payload.entries[wwid].records,description:mapping.payload.entries[wwid].description,genderStatus:mapping.payload.entries[wwid].genderStatus}))};
  fs.mkdirSync(path.join(root,'.runtime','phase2'),{recursive:true});writeJSON(path.join(root,'.runtime','phase2',`MCR_PHASE2_PDF_BELEG_${id}_2000-old-test.json`),p);
  return p;
 };
 return {root,mapping,member,paths,pdfFile,auditFile,generate,store,cleanup:()=>fs.rmSync(root,{recursive:true,force:true})};
}
test('RC111 after prior aborted no-write AO run: regenerate exactly once without operator prompts',async()=>{
 const f=setup();try{
  const g=f.generate(),p=f.store(g);const reuse=reusableAoProof({root:f.root,ticketId:id,wwid,member,mapping:f.mapping,paths:f.paths});
  assert.equal(reuse.status,'AUTO_REUSE');assert.equal(reuse.artifact.sha256,p.artifacts[0].sha256);
  const page={ticketId:null},logs=[];let calls=0;
  const result=await preparePhase2PdfEvidence({root:f.root,page,row:ticket,mapping:f.mapping,paths:f.paths,
   ui:{assertTicket:async(p,id)=>assert.equal(p.ticketId,id)},openTicket:async(p,row)=>{p.ticketId=row.ticketId},
   memberLookup:async()=>member,ask:async()=>{throw Error('no questions needed')},log:x=>logs.push(x),
   generator:async()=>{calls++;return {status:'GENERATOR_EXECUTED',proof:f.generate(true)};}});
  assert.equal(result.status,'PDF_PROOF_READY');assert.equal(calls,1);
  assert(logs.some(x=>x.includes('P2_AO_REGENERATION_REQUIRED')));
 }finally{f.cleanup();}
});
test('RC111 RC105 proof lacking stock binding no longer triggers old-PDF review',async()=>{
 const f=setup();try{
  f.store(f.generate(),false);
  assert.equal(reusableAoProof({root:f.root,ticketId:id,wwid,member,mapping:f.mapping,paths:f.paths}).status,'OPERATOR_REVIEW');
  let questions=0,calls=0;
  const result=await preparePhase2PdfEvidence({root:f.root,page:{ticketId:null},row:ticket,mapping:f.mapping,paths:f.paths,
   ui:{assertTicket:async(p,id)=>assert.equal(p.ticketId,id)},openTicket:async(p,row)=>{p.ticketId=row.ticketId},
   memberLookup:async()=>member,ask:async()=>{questions++;return 'JA'},log:()=>{},generator:async()=>{calls++;return {status:'GENERATOR_EXECUTED',proof:f.generate(true)};}});
  assert.equal(result.status,'PDF_PROOF_READY');assert.equal(questions,0);assert.equal(calls,1);
  assert.equal(reusableAoProof({root:f.root,ticketId:id,wwid,member,mapping:f.mapping,paths:f.paths}).status,'AUTO_REUSE');
 }finally{f.cleanup();}
});
test('RC106 old AO file altered or member swapped: never automatically regenerate',()=>{
 const f=setup();try{
  f.store(f.generate());fs.appendFileSync(f.pdfFile,'tampered');
  assert.equal(reusableAoProof({root:f.root,ticketId:id,wwid,member,mapping:f.mapping,paths:f.paths}).status,'REVIEW_REQUIRED');
  const wrong={...member,profile:{...member.profile,mercerId:'wrong'}};
  assert.equal(reusableAoProof({root:f.root,ticketId:id,wwid,member:wrong,mapping:f.mapping,paths:f.paths}).status,'REVIEW_REQUIRED');
 }finally{f.cleanup();}
});

test('RC111 four-day-old proof is historical; no old audit review or fallback',async()=>{
 const f=setup();try{
  const original=f.store(f.generate(),false),proofDir=path.join(f.root,'.runtime','phase2');
  original.artifacts[0].generation.generatedAt=new Date(Date.now()-4*24*3600*1000).toISOString();
  delete original.artifacts[0].generation.calculationEvidence;
  writeJSON(path.join(proofDir,`MCR_PHASE2_PDF_BELEG_${id}_2000-old-test.json`),original);
  const get=()=>reusableAoProof({root:f.root,ticketId:id,wwid,member,mapping:f.mapping,paths:f.paths});
  assert.equal(get().status,'OPERATOR_REVIEW');assert.equal(get().olderThanDay,true);
  let questions=0,calls=0;
  const options={root:f.root,page:{ticketId:null},row:ticket,mapping:f.mapping,paths:f.paths,
   ui:{assertTicket:async(p,id)=>assert.equal(p.ticketId,id)},openTicket:async(p,row)=>{p.ticketId=row.ticketId},
   memberLookup:async()=>member,log:()=>{},generator:async()=>{calls++;return {status:'GENERATOR_EXECUTED',proof:f.generate(true)};}};
  const prepared=await preparePhase2PdfEvidence({...options,ask:async()=>{questions++;throw Error('No historical review')}});
  assert.equal(prepared.status,'PDF_PROOF_READY');assert.equal(calls,1);assert.equal(questions,0);
 }finally{f.cleanup();}
});
test('RC108 seven-day-old or wrong-year proof remains blocked, not silently rerun',()=>{
 const f=setup();try{
  const p=f.store(f.generate()),file=path.join(f.root,'.runtime','phase2',`MCR_PHASE2_PDF_BELEG_${id}_2000-old-test.json`);
  const check=()=>reusableAoProof({root:f.root,ticketId:id,wwid,member,mapping:f.mapping,paths:f.paths});
  p.artifacts[0].generation.generatedAt=new Date(Date.now()-7*24*3600*1000-1000).toISOString();writeJSON(file,p);
  assert.equal(check().reason,'AO_PREVIOUS_PROOF_EXPIRED');
  p.artifacts[0].generation.generatedAt=new Date().toISOString();p.artifacts[0].generation.stichtagIso=`${new Date().getFullYear()-1}-12-31`;writeJSON(file,p);
  assert.equal(check().reason,'AO_PREVIOUS_PROOF_EXPIRED');
 }finally{f.cleanup();}
});
test('RC111 an old proof cannot be returned as a fresh generator receipt',async()=>{
 const f=setup();try{
  const p=f.store(f.generate(),false);p.artifacts[0].generation.generatedAt=new Date(Date.now()-4*24*3600*1000).toISOString();
  writeJSON(path.join(f.root,'.runtime','phase2',`MCR_PHASE2_PDF_BELEG_${id}_2000-old-test.json`),p);
  delete p.artifacts[0].generation.freshness;
  p.artifacts[0].generation.generatedAt=new Date().toISOString();
  await assert.rejects(preparePhase2PdfEvidence({root:f.root,page:{ticketId:null},row:ticket,mapping:f.mapping,paths:f.paths,
   ui:{assertTicket:async()=>{}},openTicket:async()=>{},memberLookup:async()=>member,log:()=>{},
   ask:async()=>assert.fail('No old PDF approval'),generator:async()=>({status:'GENERATOR_EXECUTED',proof:p.artifacts[0].generation})}),e=>e.code==='P2_AO_FRESHNESS_REQUIRED');
 }finally{f.cleanup();}
});

test('RC109 older AO can reuse automatically only with full calculation provenance',()=>{
 const f=setup();try{
  const p=f.store(f.generate()),file=path.join(f.root,'.runtime','phase2',`MCR_PHASE2_PDF_BELEG_${id}_2000-old-test.json`);
  p.artifacts[0].generation.generatedAt=new Date(Date.now()-4*24*3600*1000).toISOString();writeJSON(file,p);
  const check=()=>reusableAoProof({root:f.root,ticketId:id,wwid,member,mapping:f.mapping,paths:f.paths});
  assert.equal(check().status,'AUTO_REUSE');
  fs.appendFileSync(f.paths(f.root,'AO').control,'changed');assert.equal(check().status,'OPERATOR_REVIEW');
  assert.equal(check().calculationEvidence,'CHANGED');
 }finally{f.cleanup();}
});

test('RC112 missing contacts queue never suppresses another human-mediated attempt',async()=>{
 const f=setup();try{
  const master=f.paths(f.root,'AO').master,queueFile=path.join(f.root,'.runtime','phase2','ao-contact-queue',id+'.json');
  const logs=[];let calls=0,ready=false;
  const run=()=>preparePhase2PdfEvidence({root:f.root,page:{ticketId:null},row:ticket,mapping:f.mapping,paths:f.paths,
   ui:{assertTicket:async()=>{}},openTicket:async()=>{},memberLookup:async()=>member,log:x=>logs.push(x),
   ask:async()=>assert.fail('No contact guessing or old PDF review'),generator:async()=>{
    calls++;
    return ready?{status:'GENERATOR_EXECUTED',proof:f.generate(true)}:{status:'GENERATOR_BLOCKED',error:'AO_CONTACT_DATA_REQUIRED',missingFields:['Adresse','PLZ'],details:{master_sha256:sha(fs.readFileSync(master))}};
   }});
  const first=await run();assert.equal(first.reason,'AO_WAITING_FOR_CONTACT_DATA');assert.deepEqual(first.missingFields,['Adresse','PLZ']);
  const queue=JSON.parse(fs.readFileSync(queueFile));assert.equal(queue.state,'AO_WAITING_FOR_CONTACT_DATA');assert.equal(queue.wwid,wwid);
  assert.equal((await run()).reason,'AO_WAITING_FOR_CONTACT_DATA');assert.equal(calls,2);
  fs.appendFileSync(master,'changed fixture contact data');ready=true;
  const resumed=await run();assert.equal(resumed.status,'PDF_PROOF_READY');assert.equal(calls,3);
  assert.equal(JSON.parse(fs.readFileSync(queueFile)).state,'AO_NEW_PDF_VERIFIED');
 }finally{f.cleanup();}
});
test('RC111 existing AO without an old receipt never blocks fresh generation',async()=>{
 const f=setup();try{
  fs.writeFileSync(f.pdfFile,document);let calls=0;
  const prepared=await preparePhase2PdfEvidence({root:f.root,page:{ticketId:null},row:ticket,mapping:f.mapping,paths:f.paths,
   ui:{assertTicket:async()=>{}},openTicket:async()=>{},memberLookup:async()=>member,log:()=>{},
   ask:async()=>assert.fail('No old-PDF approval'),generator:async()=>{calls++;return {status:'GENERATOR_EXECUTED',proof:f.generate(true)};}});
  assert.equal(prepared.status,'PDF_PROOF_READY');assert.equal(calls,1);
 }finally{f.cleanup();}
});
test('RC111 existing upload intent blocks any new AO generation',async()=>{
 const f=setup();try{
  const actions=path.join(f.root,'.runtime','phase2','actions');fs.mkdirSync(actions,{recursive:true});
  const file=path.join(actions,'MCR_PHASE2_'+id+'.json');fs.writeFileSync(file,'{"state":"UPLOAD_INTENT"}');const old=fs.readFileSync(file);
  await assert.rejects(preparePhase2PdfEvidence({root:f.root,page:{},row:ticket,mapping:f.mapping,paths:f.paths,
   openTicket:async()=>assert.fail('No open'),memberLookup:async()=>assert.fail('No member read'),generator:async()=>assert.fail('No regeneration')}),e=>e.code==='P2_PDF_PREP_PREVIOUS_ACTION');
  assert.deepEqual(fs.readFileSync(file),old);
 }finally{f.cleanup();}
});
