import {installActivePage} from './rc123-active-heading-fixture.mjs';

const own='IN_BEARBEITUNG',queue='WARTESCHLANGE_INTL01';

export async function installQueueResult(page,html,count='0'){
 await installActivePage(page,{queue:true});
 await page.call((html,count)=>{
  document.querySelector('tbody').innerHTML=html;
  const menu=document.getElementById('storedSearchesContainer_MY_QUEUES');
  menu.innerHTML='<a href="#" aria-current="page"><span>INTL01</span> <span class="count"></span></a><a href="#">Sonstige (0)</a>';
  menu.querySelector('.count').textContent=count;
  menu.querySelector('a').onclick=e=>e.preventDefault();
 },html,count);
}

export async function checkQueueResults(page,ui,find,assert){
 const blank='<tr style="height:25px">'+('<td>&nbsp;</td>'.repeat(5))+'</tr>';
 const msg='<tr><td colspan="5">Es wurden keine Vorgänge gefunden.</td></tr>';
 const resultTypes=[[msg,'EMPTY_RESULT_MESSAGE'],
  ['<tr><td colspan="5">Showing 0 to 0 of 0 entries</td></tr>','ZERO_RESULT_REPORT'],
  [blank,'BLANK_ROWS_AND_BOUND_ZERO_COUNT']];
 for(const [html,expected] of resultTypes){
  await installQueueResult(page,html);
  const result=await ui.navigateToScope(page,queue,{quick:true});
  assert.equal(result.state,'READY_EMPTY');assert.equal(result.emptyEvidence,expected);
 }
 for(const [html,count,expected] of [[blank,'1','BLANK_CELLS_REQUIRE_ZERO_COUNT'],
  ['<tr><td colspan="5"><span role="progressbar"></span></td></tr>','0','SHORT_ROW'],
  ['<tr><td colspan="5"><button>Keine Treffer</button></td></tr>','0','SHORT_ROW'],
  ['<tr><td>ungueltig</td><td>INTL01</td><td></td><td>E-Mail</td><td></td></tr>','0','INVALID_TICKET_CELL']]){
  await installQueueResult(page,html,count);
  const snap=await ui.queueTableSnapshot(page);
  assert.equal(snap.rowIssue?.kind,expected);
  assert.equal(snap.tableId,'mainForm:tasksTableFor_MyQueuesTasksList');
  assert(!JSON.stringify(snap.rowIssue).includes('ungueltig'));
 }
 await installQueueResult(page,msg);
 await page.call(()=>document.querySelector('tbody').setAttribute('aria-busy','true'));
 assert.equal((await ui.queueTableSnapshot(page)).state,'QUEUE_LOADING');
 await installQueueResult(page,msg,'2');
 await assert.rejects(()=>ui.navigateToScope(page,queue,{quick:true}),e=>e.code==='INTL_SCOPE_NOT_AVAILABLE'&&e.navigationState.tableState==='COUNT_CONFLICT');
 const examined=[];
 const fallback=()=>assert.fail('Unexpected manual recovery or reset');
 const result=await find({processed:new Set(['99023041']),readList:async (scope,options)=>{
  if(scope===own)await installActivePage(page);
  else await installQueueResult(page,msg);
  return ui.navigateToScope(page,scope,options);
 },onScan:(scope,counts)=>examined.push([scope,counts]),resetView:fallback,ask:fallback});
 assert(!result.row);
 assert.deepEqual(examined.map(([scope,n])=>[scope,n.visible,n.processedOrExcluded]),[[own,1,1],[queue,0,0]]);
 await installQueueResult(page,msg,'0');
 await page.call(()=>{setTimeout(()=>{
  const cells=['99123456','INTL01','Intel Deutschland GmbH','E-MAIL',''];
  document.querySelector('tbody').innerHTML='<tr>'+cells.map(v=>'<td>'+v+'</td>').join('')+'</tr>';
  document.querySelector('.count').textContent='1';
 },85);});
 const next=await ui.navigateToScope(page,queue,{quick:true});
 assert.deepEqual(next.rows.map(r=>r.ticketId),['99123456']);
 return 'Verified exact empty messages, result summaries, scoped zero badges, mixed/loading and malformed refusal, zero/positive conflict, normal two-list exhaustion and delayed next ticket.';
}
