import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {findEdgeExecutable, launchBrowser, connectBrowser, attachPage} from '../lib/cdp.mjs';
import {navigateToScope, openTicket} from '../lib/browser-workflow.mjs';
import {findPhase1Candidate} from '../lib/phase1-worklist-search.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';

test('RC121 browser opens only the bound Intel ticket when an unfiltered, READY own-tasks table is already displayed', {timeout:30000}, async () => {
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'MCR-RC20-NOTE-RC121-'));
  let browser, cdp;
  try {
    browser = await launchBrowser({
      executable:findEdgeExecutable(), userDataDir:profile, startUrl:'about:blank', headless:true,
      extraArgs:process.platform === 'linux' ? ['--no-sandbox','--disable-dev-shm-usage'] : []
    });
    ({cdp} = await connectBrowser(browser.port));
    const page = await attachPage(cdp, t => t.type === 'page' && t.url === 'about:blank');

    await page.call(() => {
      document.body.innerHTML = `<nav>
        <a id="general">Meine Vorgänge</a>
        <div id="storedSearchesContainer_MY_TASKS"><span hidden>In_Bearbeitung</span></div>
        <div id="storedSearchesContainer_MY_QUEUES"><a id="intel">INTL01 (1)</a></div>
      </nav><main id="list"></main>`;
      window.fixtureEvents = [];
      const list = document.getElementById('list');
      const table = (family, label, id) => {
        list.innerHTML = `<table id="mainForm:tasksTableFor_${family}">
          <caption>${label}</caption>
          <thead><tr><th>Ticket-ID</th><th>Quelle</th><th>Zusätzliche Beschreibung</th></tr></thead>
          <tbody><tr><td><button type="button">${id}</button></td><td>E-MAIL</td><td></td></tr></tbody>
        </table>`;
        list.querySelector('button').onclick = () => {
          window.fixtureEvents.push(id);
          list.innerHTML = '<h2>Ticket-ID: ' + id + '</h2>';
        };
      };
      document.getElementById('general').onclick = () => window.fixtureEvents.push('general');
      document.getElementById('intel').onclick = event => {
        window.fixtureEvents.push('queue');
        event.currentTarget.setAttribute('aria-current','page');
        table('MyQueuesTasksList','INTL01','99000102');
      };
      table('MyTasksList','Meine Vorgänge','99000101');
    });

    const searched = [];
    const candidate = await findPhase1Candidate({
      readList:(scope, options) => { searched.push(scope); return navigateToScope(page, scope, options); },
      resetView:() => assert.fail('Usable alternate was discarded'),
      ask:() => assert.fail('Usable alternate should not require a prompt'),
      processed:new Set()
    });
    assert.deepEqual(searched, ['IN_BEARBEITUNG','WARTESCHLANGE_INTL01']);
    assert.equal(candidate.scope, 'WARTESCHLANGE_INTL01');
    assert.equal(candidate.row.ticketId, '99000102');

    // The same table id and ticket also occur in another saved search.
    // When the view changes after selection the old receipt may not open it.
    await page.call(() => { document.querySelector('table caption').textContent = 'INTL02'; });
    await assert.rejects(() => openTicket(page, candidate.row, {scope:candidate.scope}), {code:'INTL_TABLE_CHANGED'});
    assert.deepEqual(await page.call(() => window.fixtureEvents), ['queue']);

    await page.call(() => { document.querySelector('table caption').textContent = 'INTL01'; });
    const rebound = await navigateToScope(page, candidate.scope);
    assert.equal((await openTicket(page, rebound.rows[0], {scope:candidate.scope})).mode, 'AUTO');
    assert.deepEqual(await page.call(() => window.fixtureEvents), ['queue','99000102']);
  } finally {
    await cleanupTemporaryTestBrowser({profile,browser,cdp});
  }
});
