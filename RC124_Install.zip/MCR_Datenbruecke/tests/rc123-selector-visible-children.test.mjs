import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {inspectIntelNavigation} from '../lib/intel-worklist-navigation.mjs';

// Keep selection tests independent of the operating system and Edge version.
// Labels, handlers and counters are separate nodes as in the RC119 lookup.
function make(tag,content,attrs={},style={}){
 const node={
  tagName:tag.toUpperCase(),nodeType:1,parentElement:null,isConnected:true,style,
  getAttribute:k=>attrs[k]??null,hasAttribute:k=>Object.hasOwn(attrs,k),
  classList:{contains:()=>false},getClientRects:()=>[{}],
  get textContent(){return this.childNodes.map(c=>c.nodeType===3?c.nodeValue:c.textContent).join('');},
  get children(){return this.childNodes.filter(c=>c.nodeType===1);},
  contains(n){return n===this||this.children.some(c=>c.contains(n));},
  matches(selector){return selector.split(',').some(s=>s===tag||s==='[onclick]'&&!!attrs.onclick);},
  closest(sel){return this.matches(sel)?this:this.parentElement?.closest(sel);},
  querySelectorAll(sel){return this.children.flatMap(c=>[...(c.matches(sel)?[c]:[]),...c.querySelectorAll(sel)]);}
 };
 node.childNodes=(Array.isArray(content)?content:[content]).map(c=>typeof c==='string'?{nodeType:3,nodeValue:c}:c);
 for(const c of node.children)c.parentElement=node;
 return node;
}
function probe(children,scope='WARTESCHLANGE_INTL01'){
 const id='storedSearchesContainer_'+(scope==='IN_BEARBEITUNG'?'MY_TASKS':'MY_QUEUES');
 const container=make('div',children,{id});
 const document={querySelectorAll:s=>s==='[id="'+id+'"]'?[container]:[]};
 const style=n=>({display:'inline',visibility:'visible',fontWeight:'400',...n.style});
 return vm.runInNewContext('('+inspectIntelNavigation.toString()+')(scope,false,false)',{document,scope,getComputedStyle:style});
}
test('RC123 independent exact passive label can be used inside a shared group of clickable spans',()=>{
 for(const [name,scope] of [['INTL01','WARTESCHLANGE_INTL01'],['In_Bearbeitung','IN_BEARBEITUNG']]){
  const labels=['Other',name,'More'].map(s=>make('span',s,{}, {cursor:'pointer'}));
  const result=probe([make('div',labels)],scope);
  assert.equal(result.state,'CHILD');assert.equal(result.active,false);
 }
});
test('RC123 scoped link can be clicked on its exact child label next to an unclassed separate count',()=>{
 for(const name of ['INTL01','INTL0\u200b1']){
  const a=make('a',[make('span',name),make('span','17')]);
  assert.equal(probe([a]).state,'CHILD');
 }
 for(const parts of [['INTL01',make('span','0')],[make('span','INTL01'),'0']]){
  assert.equal(probe([make('a',parts)]).state,'CHILD');
 }
 assert.equal(probe([make('a',[make('span','INTL01'),make('span','17')],{'aria-label':'West'})]).state,'CHILD_NOT_VISIBLE');
 assert.equal(probe([make('a',[make('span','INTL01'),make('span',' West')])]).state,'CHILD_NOT_VISIBLE');
 assert.equal(probe([make('a','INTL010')]).state,'CHILD_NOT_VISIBLE');
});
test('RC123 saved search rows support a loupe, numeric count, and exact tooltip on an icon-only control',()=>{
 const row=make('div',[make('span','🔍'),make('span','INTL01'),make('span','19')]);
 assert.equal(probe([row]).state,'CHILD');
 assert.equal(probe([make('a','19',{'title':'\u200eINTL01\u200e'})]).state,'CHILD');
 const foreign=make('a','19',{'aria-label':'INTL09','title':'INTL01'});
 const mismatch=probe([foreign]);
 assert.equal(mismatch.state,'CHILD_NOT_VISIBLE');
 assert.equal(mismatch.menuObservation.visibleAccessibleMatches,1);
 assert.equal(probe([make('a','West',{'aria-label':'INTL01'})]).state,'CHILD_NOT_VISIBLE');
});
test('RC123 omitted, conflicting, and duplicate labels remain distinguishable',()=>{
 const separate=s=>make('span',s,{}, {cursor:'pointer'});
 const missing=probe([make('div',[separate('West'),separate('East')])]);
 assert.equal(missing.menuObservation.visibleExactLabels,0);
 assert.equal(missing.menuObservation.visibleNodes,3);
 const row=make('div',[separate('INTL01'),separate(' West')],{onclick:'openRow()'}, {cursor:'pointer'});
 const conflict=probe([row]);
 assert.equal(conflict.state,'CHILD_NOT_VISIBLE');assert.equal(conflict.menuObservation.visibleExactLabels,1);
 assert.equal(conflict.menuObservation.rejectedOwners,1);
 assert.equal(probe([make('div',[separate('INTL01'),separate('INTL01')])]).state,'DUPLICATE_CHILD');
});
