import test from 'node:test';
import assert from 'node:assert/strict';
import {activeLegacyDc} from '../lib/phase2-dc-existing-process.mjs';

const script='kontoauszug_dc_generator.py';
const processes=(lines)=>lines.map(([name,commandLine],i)=>({name,commandLine,pid:100+i}));
const check=lines=>activeLegacyDc({platform:'win32',readSnapshot:()=>({processes:processes(lines)})});

test('RC120 detects direct RC119, interactive and quoted-path Python DC processes on this host',()=>{
 const rows=[
  ['python.exe','python '+script+' --wwid 11369832'],
  ['Python.exe','"C:\\Program Files\\Python\\python.exe" -u "K:\\Berechnungen mit Leerzeichen\\'+script+'"'],
  ['py.exe','py -3.12 -X utf8 -- ".\\'+script+'" --wwid 1378'],
  ['pythonw.exe','pythonw --check-hash-based-pycs always -W default:warning '+script.toUpperCase()],
 ];
 assert.deepEqual(check(rows),[100,101,102,103]);
});

test('RC120 incidental names in arguments, shell commands or modules are not direct DC programs',()=>{
 const rows=[
  ['python.exe','python statement-dc-run.py '+script+' --wwid 11369832'],
  ['python.exe','python -c "print(42)" '+script],
  ['python.exe','python -m compileall '+script],
  ['python.exe','python -W '+script+' different.py'],
  ['python.exe','python C:\\scripts\\old_'+script],
  ['python.exe','python -V '+script],
  ['cmd.exe','cmd /c python '+script],
  ['python.exe',null],
  ['python.exe','python "unterminated '+script],
 ];
 assert.deepEqual(check(rows),[]);
});

test('RC120 queries a fresh Windows snapshot for every admission and propagates a failed check',()=>{
 let calls=0;
 const readSnapshot=()=>{calls++;return {processes:calls===1?processes([['python.exe','python '+script]]):[]};};
 assert.deepEqual(activeLegacyDc({platform:'win32',readSnapshot}),[100]);
 assert.deepEqual(activeLegacyDc({platform:'win32',readSnapshot}),[]);
 assert.throws(()=>activeLegacyDc({platform:'win32',readSnapshot:()=>{throw new Error('WMI unavailable');}}),/WMI unavailable/);
 assert.deepEqual(activeLegacyDc({platform:'linux',readSnapshot:()=>assert.fail()}),[]);
});
