import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {choosePhase2Candidate} from '../src/phase2-run.mjs';
import {inspectPhase2Tickets} from '../lib/phase2-intake-audit.mjs';
import {assessPhase2WorkResume} from '../lib/phase2-work-resume.mjs';
import {mayDeferPhase2WorkRuleConflict} from '../lib/phase2-safe-defer.mjs';
import {handlePhase2Work} from '../src/phase2-work-handler.mjs';
import {phase2WorkJournal} from '../lib/phase2-work-journal.mjs';
import {writeJSON} from '../lib/control.mjs';
const id='89419822',next='99999999',description='USC 20/ PP+\nStandardantwort versendet\nMöchte sonstige Auskunft';
const row={ticketId:id,descriptionValue:description,intelGroupVerified:true},other={...row,ticketId:next};
const work={schema:'MCR_PHASE2_WORK_JOURNAL_V1',ticketId:id,rule:'MARK_DIRECT',state:'REVIEW_VERIFIED',descriptionBefore:'USC 20/ PP+\nMöchte sonstige Auskunft',descriptionAfter:description,events:[{state:'TICKET_SAVE_VERIFIED'},{state:'REVIEW_VERIFIED'}]};
test('RC108 old MARK_DIRECT journal with incompatible original rule is isolated; next ticket selected',()=>{
 const getWorkJournal=t=>t===id?work:null;
 const pick=choosePhase2Candidate([row,other],{getWorkJournal});
 assert.equal(pick.row.ticketId,next);assert.equal(pick.kind,'MARK_DIRECT');assert.deepEqual(pick.skipped,[{ticketId:id,reason:'WORK_JOURNAL_RULE_CONFLICT'}]);
 const audit=inspectPhase2Tickets([row,other],{getWorkJournal});assert.equal(audit.items[0].stage,'BLOCKED');assert.equal(audit.items[0].reason,'WORK_JOURNAL_RULE_CONFLICT');assert.equal(audit.counts.ready,1);
});
test('RC108 compatible old work journal remains resumable, including valid description with CRLF',()=>{
 const valid={...work,descriptionBefore:description};assert.equal(assessPhase2WorkResume(row,valid).allowed,true);
 assert.equal(assessPhase2WorkResume({...row,descriptionValue:description.replaceAll('\n','\r\n')},valid).allowed,true);
 assert.equal(assessPhase2WorkResume(row,{...valid,events:[...valid.events,{state:'EXECUTE_INTENT'}]}).allowed,false);
 assert.equal(assessPhase2WorkResume(row,{...valid,rule:'DB_DIRECT'}).reason,'WORK_JOURNAL_RULE_CONFLICT');
});
test('RC108 handler rejects incompatible historical rule before browser action and journal stays byte identical',async()=>{
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'mcr108-rule-'));try{
  const journal=phase2WorkJournal(root,id);writeJSON(journal.file,work);const before=fs.readFileSync(journal.file);
  const page=new Proxy({}, {get(){throw Error('Unexpected browser operation')}});
  await assert.rejects(handlePhase2Work({root,page,row,mapping:null,ask:async()=>assert.fail('No question')}),{code:'P2_WORK_RULE'});
  assert.deepEqual(fs.readFileSync(journal.file),before);
 }finally{fs.rmSync(root,{recursive:true,force:true});}
});
test('RC108 fallback continues only for specific pre-write rule error and unchanged journals',()=>{
 const base={code:'P2_WORK_RULE',beforeWork:work,afterWork:structuredClone(work)};
 assert.equal(mayDeferPhase2WorkRuleConflict(base),true);
 assert.equal(mayDeferPhase2WorkRuleConflict({...base,code:'CDP_ERROR'}),false);
 assert.equal(mayDeferPhase2WorkRuleConflict({...base,afterWork:{...work,state:'EXECUTE_INTENT'}}),false);
 assert.equal(mayDeferPhase2WorkRuleConflict({...base,afterPdf:{state:'UPLOAD_INTENT'}}),false);
});
