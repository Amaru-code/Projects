import test from 'node:test';
import assert from 'node:assert/strict';
import {startupWorkbookRefresh} from '../tools/cli.mjs';

function harness({installed=true,guardFailure=null,idleFailure=null,refreshFailure=null}={}){
 const calls=[],messages=[],rootDir='C:/MCR_TEST_ROOT';
 const run=()=>startupWorkbookRefresh({
  rootDir,installed,output:s=>messages.push(s),
  guard:p=>{calls.push('guard');assert.equal(p,rootDir);if(guardFailure)throw Object.assign(new Error('guard unavailable'),{code:guardFailure});},
  idle:p=>{calls.push('idle');assert.equal(p,rootDir);if(idleFailure)throw Object.assign(new Error('other bot active'),{code:idleFailure});},
  refresh:(p,{log})=>{calls.push('refresh');assert.equal(p,rootDir);if(refreshFailure)throw Object.assign(new Error('xls missing'),{code:refreshFailure});log('PASS BESTAND_EXCEL_AKTUELL: test fixture');return {fileHash:'fixture'};}
 });
 return {run,calls,messages};
}

test('RC98 startup: only installed program auto-refreshes; update source stays inert',()=>{
 const t=harness({installed:false});assert.deepEqual(t.run(),{status:'NOT_INSTALLED'});assert.deepEqual(t.calls,[]);assert.deepEqual(t.messages,[]);
});
test('RC98 startup: installed start checks guard, idle, then refresh and reports success',()=>{
 const t=harness();assert.deepEqual(t.run(),{status:'REFRESHED'});assert.deepEqual(t.calls,['guard','idle','refresh']);assert(t.messages.some(x=>x.startsWith('PASS BESTAND_EXCEL_AKTUELL')));assert(t.messages.some(x=>x.startsWith('PASS STARTUP_BESTAND_GEPRUEFT')));
});
test('RC98 startup: every menu opening reevaluates leading XLSX, no previous success cache',()=>{
 const t=harness();assert.equal(t.run().status,'REFRESHED');assert.equal(t.run().status,'REFRESHED');assert.equal(t.calls.filter(x=>x==='refresh').length,2);
});
test('RC98 startup: unavailable source warns but does not authorize ticket actions or fall back to JSON',()=>{
 const t=harness({refreshFailure:'WORKBOOK_UNAVAILABLE'});assert.deepEqual(t.run(),{status:'BLOCKED',code:'WORKBOOK_UNAVAILABLE'});assert.deepEqual(t.calls,['guard','idle','refresh']);assert(t.messages.some(x=>/WARN STARTUP_BESTAND_NICHT_AKTUELL: WORKBOOK_UNAVAILABLE/.test(x)));
});
test('RC98 startup: concurrent bot stops snapshot writes before refresh',()=>{
 const t=harness({idleFailure:'MCR_PROCESSES_ACTIVE'});assert.equal(t.run().status,'BLOCKED');assert.deepEqual(t.calls,['guard','idle']);assert(t.messages.some(x=>x.includes('MCR_PROCESSES_ACTIVE')));
});
test('RC98 startup: migration guard suppresses refresh',()=>{
 const t=harness({guardFailure:'MIGRATION_PRIORITY_ACTIVE'});assert.equal(t.run().status,'BLOCKED');assert.deepEqual(t.calls,['guard']);
});
test('RC98 startup: no workbook contact flush or COMARCH write is invoked',()=>{
 const t=harness();assert.equal(t.run().status,'REFRESHED');assert(!t.calls.some(x=>/contact|mail|send|save|phase/i.test(x)));
});
