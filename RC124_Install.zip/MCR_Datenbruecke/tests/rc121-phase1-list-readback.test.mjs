import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {navigateToScope,queueTableSnapshot,readBoundWorklist} from '../lib/browser-workflow.mjs';
import {inspectIntelNavigation} from '../lib/intel-worklist-navigation.mjs';

const own='IN_BEARBEITUNG', queue='WARTESCHLANGE_INTL01';
const id='99000718', text='USC 20 / DC\nStandardantwort versendet';
const unavailable=()=>Object.assign(new Error('Saved view unavailable'),{code:'INTL_SCOPE_NOT_AVAILABLE'});
const code=fs.readFileSync(new URL('../src/local-bot-full-run.mjs',import.meta.url),'utf8');
function runnerFunction(name,end,context){
 const start=code.indexOf('async function '+name+'(');
 const stop=code.indexOf(end,start);
 assert(start>=0&&stop>start);
 return vm.runInNewContext('('+code.slice(start,stop).trim()+')',context);
}

test('RC121 a previously sent ticket can rebind by exact ID in the other proven worklist',async()=>{
 const events=[],page={};
 const UI={
  detailTicketId:async()=>null,
  navigateToScope:async(_page,scope)=>{
   events.push(scope);
   if(scope===own)throw unavailable();
   return {rows:[{ticketId:'99000719'},{ticketId:id}]};
  },
  openTicket:async(p,row,{scope})=>{assert.equal(p,page);assert.equal(scope,queue);events.push('open:'+row.ticketId);},
  assertTicket:async(p,ticketId)=>{assert.equal(p,page);events.push('bound:'+ticketId);}
 };
 const rebind=runnerFunction('rebindSentTicket','async function verifySaved(',{UI,need:assert.ok});
 await rebind(page,id);
 assert.deepEqual(events,[own,queue,'open:'+id,'bound:'+id]);
});

test('RC121 save readback can finish on a bound alternate queue; a changed description is polled without clicking again',async()=>{
 const events=[],diag={save:{}};
 const initial={rows:[{ticketId:id,descriptionBlank:true,descriptionRaw:''}]};
 const UI={
  navigateToScope:async(_page,scope)=>{
   events.push(scope);
   if(scope===own)throw unavailable();
   return initial;
  },
  readBoundWorklist:async(_page,scope,previous)=>{
   assert.equal(scope,queue);assert.equal(previous,initial);events.push('passive read');
   return {rows:[{ticketId:id,descriptionBlank:false,descriptionRaw:text}]};
  }
 };
 const verify=runnerFunction('verifySaved','/** No reply text',{diag,UI,DEMO:false,sleep:async()=>{},fail:assert.fail});
 await verify({},id,text);
 assert.deepEqual(events,[own,queue,'passive read']);
 assert.equal(diag.save.verified,true);
 assert.equal(diag.save.verification,'QUEUE_ALL_DESCRIPTION_CONTENT_MATCH');
});

test('RC121 a conflicting active view invalidates a saved-table receipt even with identical row, table ID and render',async()=>{
 let foreign=false;
 const page={call:async(fn)=>{
  if(fn===inspectIntelNavigation)return {state:'CURRENT_VIEW',active:!foreign,conflict:foreign};
  return {ok:true,scope:own,state:'READY',render:'doc1/table1',rows:[{ticketId:id}]};
 }};
 const initial=await navigateToScope(page,own);
 assert.equal((await readBoundWorklist(page,own,initial)).rows[0].ticketId,id);
 foreign=true;
 assert.equal(await readBoundWorklist(page,own,initial),null);
});

test('RC121 a same-family table in a replacement document cannot reuse the clicked worklist proof',async()=>{
 // Use the real serialised table reader on empty but ready tables. Both
 // documents allocate the same node numbers in the same order.
 const family='mainForm:tasksTableFor_MyTasksList';
 function documentContext(token){
  const doc={defaultView:{getComputedStyle:()=>({visibility:'visible',display:'table'})}};
  const table={id:family,isConnected:true,getClientRects:()=>[{}],ownerDocument:doc,closest:()=>null,
   tHead:{rows:[{cells:['Ticket-ID','Quelle','Zusätzliche Beschreibung'].map(textContent=>({textContent}))}]},
   tBodies:[{rows:[]}]};
  doc.querySelectorAll=selector=>selector==='[id="'+family+'"]'?[table]:[];
  return vm.createContext({window:{crypto:{randomUUID:()=>token}},document:doc});
 }
 const page={call:(fn,...args)=>vm.runInContext('('+fn.toString()+')(...'+JSON.stringify(args)+')',world)};
 let world=documentContext('doc-a');
 const a=await queueTableSnapshot(page,{trackRender:true});
 world=documentContext('doc-b');
 const b=await queueTableSnapshot(page,{trackRender:true});
 assert(a.ok&&b.ok);assert.notEqual(a.render,b.render);
 assert.equal(a.render.slice(a.render.indexOf('/')),b.render.slice(b.render.indexOf('/')));
 let clicked=false,scopeTable={ok:false,state:'NO_QUEUE',rows:[]};
 const boundPage={
  call:async fn=>fn===inspectIntelNavigation?{state:'CHILD',active:false,point:{x:9,y:9}}:scopeTable,
  mouseClick:async()=>{assert.equal(clicked,false);clicked=true;scopeTable=a;}
 };
 const first=await navigateToScope(boundPage,own);
 assert(clicked);assert((await readBoundWorklist(boundPage,own,first)).ok);
 scopeTable=b;
 assert.equal(await readBoundWorklist(boundPage,own,first),null);
});
