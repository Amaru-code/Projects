import test from 'node:test';import assert from 'node:assert/strict';
import http from 'node:http';
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';import {EventEmitter} from 'node:events';
import {connectBrowser,releaseSharedPage,launchBrowser,attachFreshPage,findEdgeExecutable} from '../lib/cdp.mjs';
import {createFlowRecorder,sanitizeFlowLine} from '../lib/flow-events.mjs';import {createFlowServer} from '../lib/flow-server.mjs';
import {createDeliveryConsole} from '../lib/delivery-console.mjs';import {describeTicketIssue} from '../lib/ticket-error-catalog.mjs';
const tmp=()=>fs.mkdtempSync(path.join(os.tmpdir(),'mcr-rc94-'));
const root=path.resolve(new URL('..',import.meta.url).pathname);

test('RC94: local discovery retries are read-only and bounded; no send/save retry',async()=>{
 let calls=0,retries=0;const c={connect:async()=>{},close:()=>{}};
 const r=await connectBrowser(12345,{delayMs:0,fetchImpl:async u=>{assert.equal(u,'http://127.0.0.1:12345/json/version');if(++calls<3)throw new TypeError('fetch failed');return {ok:true,json:async()=>({webSocketDebuggerUrl:'ws://127.0.0.1:12345/devtools/browser/test'})};},connectionFactory:()=>c,onRetry:()=>retries++});
 assert.equal(r.cdp,c);assert.equal(calls,3);assert.equal(retries,2);
});
test('RC94: failed discovery has actionable system code and retained cause',async()=>{
 let n=0;await assert.rejects(connectBrowser(12345,{attempts:2,delayMs:0,fetchImpl:async()=>{n++;throw Object.assign(new Error('fetch failed'),{cause:{code:'ECONNREFUSED'}});}}),e=>e.code==='BROWSER_LOOPBACK_UNAVAILABLE'&&e.connectionCause==='ECONNREFUSED');assert.equal(n,2);
 assert.equal(describeTicketIssue({reason:'BROWSER_LOOPBACK_UNAVAILABLE',phase:'P1'}).errorCode,'MCR-SYS-101');
});
test('RC94: remote/other-port websocket is never connected',async()=>{
 for(const url of ['ws://example.invalid:12345/devtools/browser/x','ws://127.0.0.1:12346/devtools/browser/x']){
  let n=0;await assert.rejects(connectBrowser(12345,{fetchImpl:async()=>{n++;return {ok:true,json:async()=>({webSocketDebuggerUrl:url})};},connectionFactory:()=>{throw Error('must not connect');}}),{code:'BROWSER_ENDPOINT_MISMATCH'});assert.equal(n,1);
 }
});
test('RC94: never close last shared page before a neutral keeper exists',async()=>{
 const calls=[];const cdp={send:async(m,p)=>{calls.push([m,p]);if(m==='Target.getTargets')return {targetInfos:[{type:'page',targetId:'mine'}]};if(m==='Target.createTarget')return {targetId:'keeper'};return {};}};
 assert.deepEqual(await releaseSharedPage(cdp,'mine'),{closed:true,keeper:'keeper'});
 assert.deepEqual(calls.map(c=>c[0]),['Target.getTargets','Target.createTarget','Target.closeTarget']);
 assert.deepEqual(calls[2][1],{targetId:'mine'});
});
test('RC94: keeper creation failure leaves original page untouched',async()=>{
 const calls=[];const c={send:async m=>{calls.push(m);return m==='Target.getTargets'?{targetInfos:[{type:'page',targetId:'mine'}]}:{};}};
 await assert.rejects(releaseSharedPage(c,'mine'),{code:'BROWSER_KEEPER_MISSING'});assert.ok(!calls.includes('Target.closeTarget'));
});
test('RC94: no duplicate close when owned page already disappeared',async()=>{
 const calls=[];const c={send:async m=>{calls.push(m);return {targetInfos:[]};}};assert.equal((await releaseSharedPage(c,'gone')).alreadyClosed,true);assert.equal(calls.length,1);
});
test('RC94: sanitized map stream has codes but no names, addresses, text or paths',()=>{
 assert.equal(sanitizeFlowLine('NAME_DISCOVERY: confidential name test@example.invalid C:\\secret'),'NAME_DISCOVERY:');
 assert.equal(sanitizeFlowLine('MercerID aus Profil: 12345678'),null);
 assert.equal(sanitizeFlowLine('PASS STATUS_COLUMNS_SAVED: C:\\Users\\Secret\\data.csv'),'PASS STATUS_COLUMNS_SAVED:');
 assert.equal(sanitizeFlowLine('Dear Customer, secret body'),null);
 assert.equal(sanitizeFlowLine('TICKET_RESULT: 12345678 | VERSAND_UND_SPEICHERUNG_VERIFIZIERT | secret'),'TICKET_RESULT: 12345678 | VERSAND_UND_SPEICHERUNG_VERIFIZIERT');
});
test('RC94: recorder fixes phase and emits ordered run-specific envelopes',()=>{
 const d=tmp();try{const x=createFlowRecorder(d);x.begin('MASTER');x.line('MASTER_PHASE1_BATCH 1');x.line('TICKET_ID: 12345678');x.line('MASTER_PHASE2: secret');x.line('P2_NAECHSTES_TICKET: 87654321 | DB_DIRECT');x.finish('RETURNED');
 const es=fs.readFileSync(x.file,'utf8').trim().split('\n').map(JSON.parse);assert.equal(es.length,6);assert.deepEqual(es.map(e=>e.seq),[1,2,3,4,5,6]);assert.equal(es[2].phase,'P1');assert.equal(es[4].phase,'P2');assert.equal(es[4].ticket,'87654321');assert.ok(!JSON.stringify(es).includes('secret'));
 }finally{fs.rmSync(d,{recursive:true,force:true});}
});
test('RC94: SSE bridge blocks foreign origin, host, token, writes and arbitrary paths',async()=>{
 const d=tmp();fs.mkdirSync(path.join(d,'tools','flow-lab'),{recursive:true});fs.writeFileSync(path.join(d,'tools','flow-lab','MCR_Flow_Lab_RC94.html'),'<h1>test</h1>');
 const s=await createFlowServer(d),base='http://127.0.0.1:'+s.port;
 try{
  assert.equal((await fetch(base+'/health?token='+s.token)).status,200);
  assert.equal((await fetch(base+'/events')).status,403);
  assert.equal((await fetch(base+'/events?token='+s.token,{headers:{Origin:'https://evil.invalid'}})).status,403);
  assert.equal(await new Promise((resolve,reject)=>{const q=http.get(base+'/health?token='+s.token,{headers:{Host:'evil.invalid'}},r=>{r.resume();resolve(r.statusCode);});q.on('error',reject);}),403);
  assert.equal((await fetch(base+'/events?token='+s.token,{method:'POST'})).status,405);
  assert.equal((await fetch(base+'/private_data/mapping.json?token='+s.token)).status,404);
  assert.equal((await fetch(base+'/')).status,200);
 }finally{await s.close();fs.rmSync(d,{recursive:true,force:true});}
});
test('RC94: SSE emits real ordered events and resumes after last event id',async()=>{
 const d=tmp();fs.mkdirSync(path.join(d,'tools','flow-lab'),{recursive:true});fs.writeFileSync(path.join(d,'tools','flow-lab','MCR_Flow_Lab_RC94.html'),'test');
 const s=await createFlowServer(d),r=createFlowRecorder(d),url='http://127.0.0.1:'+s.port+'/events?token='+s.token;
 const abort=new AbortController();try{
  r.begin('P1');r.line('TICKET_ID: 12345678');s.poll();const response=await fetch(url,{signal:abort.signal});const reader=response.body.getReader();let text='';
  while(!text.includes('TICKET_ID')){const x=await reader.read();text+=new TextDecoder().decode(x.value);}
  assert.match(text,/event: reset/);assert.match(text,/MCR_FLOW_EVENT_V1/);const ids=[...text.matchAll(/^id: (.*)$/gm)].map(x=>x[1]);assert.equal(ids.length,2);abort.abort();
  r.line('PASS SEND_IN_HISTORY_BOUND: sensitive');s.poll();const a2=new AbortController();const rr=await fetch(url,{headers:{'Last-Event-ID':ids[1]},signal:a2.signal});let tx='';const rd=rr.body.getReader();while(!tx.includes('SEND_IN_HISTORY')){tx+=new TextDecoder().decode((await rd.read()).value);}assert.ok(!tx.includes('TICKET_ID'));assert.ok(!tx.includes('sensitive'));a2.abort();
 }finally{abort.abort();await s.close();fs.rmSync(d,{recursive:true,force:true});}
});
test('RC94: explicitly hidden panel moves manual approval to terminal without auto-approval',async()=>{
 let child;const msgs=[];
 const launcher=()=>{child=new EventEmitter();child.stdin=new EventEmitter();child.stdout=new EventEmitter();child.stdin.writable=true;child.stdin.end=()=>{};child.stdin.write=line=>{const m=JSON.parse(line);msgs.push(m);if(m.event==='suspend')child.stdout.emit('data',JSON.stringify({schema:'MCR_CONTROL_V1',event:'hidden',seq:m.seq})+'\n');};return child;};
 const x=createDeliveryConsole({platform:'win32',launcher});const ready=x.ready();child.stdout.emit('data','{"schema":"MCR_CONTROL_V1","event":"ready"}\n');await ready;
 child.stdout.emit('data','{"schema":"MCR_CONTROL_V1","event":"visibility","visible":false}\n');let asked=0;
 const lease=await x.authorize({ticketId:'12345678',ask:async q=>{asked++;assert.match(q,/ENTER/);return '';}});assert.equal(asked,1);assert.equal(x.gate.mode,'MANUAL');assert.ok(!msgs.some(m=>m.event==='approval'));await x.commitAuthorization(lease);x.close();
});
test('RC94: hide DURING a pending panel approval resolves safely to explicit terminal approval',async()=>{
 let child;const launcher=()=>{child=new EventEmitter();child.stdin=new EventEmitter();child.stdout=new EventEmitter();child.stdin.writable=true;child.stdin.end=()=>{};child.stdin.write=()=>{};return child;};
 const x=createDeliveryConsole({platform:'win32',launcher});const ready=x.ready();child.stdout.emit('data','{"schema":"MCR_CONTROL_V1","event":"ready"}\n');await ready;
 let asked=0;const pending=x.authorize({ticketId:'12345678',ask:async()=>{asked++;return '';}});child.stdout.emit('data','{"schema":"MCR_CONTROL_V1","event":"visibility","visible":false}\n');const lease=await pending;assert.equal(asked,1);assert.equal(lease.ticket,'12345678');x.close();
});
test('RC94: actual Chromium closes its only work tab, retains keeper and opens next fresh tab', {timeout:35000},async(t)=>{
 if(process.platform==='win32'){t.skip('Real Windows must be supervised');return;}const exe=findEdgeExecutable('auto');if(!exe){t.skip('Chromium absent');return;}
 const d=tmp();let b,c1,c2;try{
  b=await launchBrowser({executable:exe,userDataDir:path.join(d,'profile'),startUrl:'about:blank',headless:true,extraArgs:['--no-sandbox','--disable-dev-shm-usage']});
  ({cdp:c1}=await connectBrowser(b.port));const p=await attachFreshPage(c1,'about:blank');const ts=await c1.send('Target.getTargets');
  for(const x of ts.targetInfos.filter(t=>t.type==='page'&&t.targetId!==p.targetId))await c1.send('Target.closeTarget',{targetId:x.targetId});
  const result=await releaseSharedPage(c1,p.targetId);assert.ok(result.keeper);c1.close();c1=null;
  ({cdp:c2}=await connectBrowser(b.port));const p2=await attachFreshPage(c2,'about:blank');assert.notEqual(p.targetId,p2.targetId);assert.equal(await p2.call(()=>location.href),'about:blank');assert.equal(b.child.exitCode,null);
 }finally{try{await c2?.send('Browser.close');}catch{}c1?.close();c2?.close();b?.child?.kill();await new Promise(r=>setTimeout(r,300));try{fs.rmSync(d,{recursive:true,force:true,maxRetries:3,retryDelay:100});}catch{}}
});

test('RC94: stage journal telemetry retains actual step without exposing content',()=>{
 for(const c of ['UPLOAD_INTENT','GEVO_VERIFIED','DRAFT_SAVE_INTENT','TICKET_SAVE_VERIFIED','REVIEW_VERIFIED','EXECUTE_INTENT','ROUTED_VERIFIED'])assert.equal(sanitizeFlowLine('P2_JOURNAL '+c+' | private body'),'P2_JOURNAL '+c);
 assert.equal(sanitizeFlowLine('STOP RUNNER_ERROR [PHASE INITIAL]: fetch failed PRIVATE'),'STOP RUNNER_ERROR:');
 assert.equal(sanitizeFlowLine('STOP LIVE_NOT_VERIFIED: PRIVATE'),'STOP LIVE_NOT_VERIFIED:');
});
test('RC94: split UTF-8 and stderr/stdout chunks never mix or lose final event',()=>{
 const d=tmp();try{const r=createFlowRecorder(d);r.begin('P1');r.chunk(Buffer.from('TICKET_ID: 1234'),'out');r.chunk(Buffer.from('STOP RUNNER_ERROR: geheim\n'),'err');r.chunk(Buffer.from('5678\n'),'out');r.chunk(Buffer.from('PASS P1_SPRACHE: ENGLISCH'),'out');r.endStream('out');r.finish('INTERRUPTED');const a=fs.readFileSync(r.file,'utf8').trim().split('\n').map(JSON.parse);assert.deepEqual(a.map(x=>x.line),['FLOW_RUN_START:','STOP RUNNER_ERROR:','TICKET_ID: 12345678','PASS P1_SPRACHE: ENGLISCH','FLOW_RUN_END:']);}finally{fs.rmSync(d,{recursive:true,force:true});}
});
test('RC94: invalid unicode token cannot crash local viewer',async()=>{
 const d=tmp();fs.mkdirSync(path.join(d,'tools','flow-lab'),{recursive:true});fs.writeFileSync(path.join(d,'tools','flow-lab','MCR_Flow_Lab_RC94.html'),'test');const s=await createFlowServer(d);try{assert.equal((await fetch('http://127.0.0.1:'+s.port+'/health?token='+encodeURIComponent('ü'.repeat(64)))).status,403);assert.equal((await fetch('http://127.0.0.1:'+s.port+'/health?token='+s.token)).status,200);}finally{await s.close();fs.rmSync(d,{recursive:true,force:true});}
});
test('RC94: quickly truncated and refilled event file switches runs without dropping beginning',async()=>{
 const d=tmp();fs.mkdirSync(path.join(d,'tools','flow-lab'),{recursive:true});fs.writeFileSync(path.join(d,'tools','flow-lab','MCR_Flow_Lab_RC94.html'),'test');const r=createFlowRecorder(d);r.begin('P1');r.line('TICKET_ID: 12345678');const old=JSON.parse(fs.readFileSync(r.file,'utf8').split('\n')[0]).run;const s=await createFlowServer(d);const a=new AbortController();try{
 r.begin('MASTER');for(let i=0;i<40;i++)r.line('PASS MEMBER_STRUCTURED_PROFILE_VERIFIED: private');s.poll();const rr=await fetch('http://127.0.0.1:'+s.port+'/events?token='+s.token,{signal:a.signal});const rd=rr.body.getReader();let tx='';while(!tx.includes('"seq":41,'))tx+=new TextDecoder().decode((await rd.read()).value);assert.ok(tx.includes('"seq":1,'));assert.ok(!tx.includes(old));assert.equal((tx.match(/event: reset/g)||[]).length,1);assert.equal((tx.match(/^id:/gm)||[]).length,41);
 }finally{a.abort();await s.close();fs.rmSync(d,{recursive:true,force:true});}
});
test('RC94: only exact read-only map server is exempt from ordinary Windows idle guard',async()=>{
 const {windowsIdle}=await import('../tools/process-guard.mjs');const {classifyWindowsProcesses}=await import('../tools/process-policy.mjs');const rt='C:\\Projects\\MCR_Datenbruecke',profile=rt+'\\.runtime\\edge-profile';
 const p=(pid,cmd)=>({pid,parentPid:1,name:'node.exe',createdAt:'2026-01-01T00:00:00Z',executablePath:'C:\\Node\\node.exe',commandLine:'"C:\\Node\\node.exe" "'+cmd+'"'});
 const own=p(11,'C:\\elsewhere\\installer.mjs');const viewer=p(22,rt+'\\tools\\flow-map-server.mjs');const snap={schema:'MCR_WINDOWS_PROCESS_SNAPSHOT_V1',checked:true,processes:[own,viewer]};
 assert.equal(windowsIdle(rt,{platform:'win32',excludePid:11,profileDirectory:profile,readSnapshot:()=>snap}).blockedCount,0);
 assert.ok(classifyWindowsProcesses(snap,{root:rt,profileDirectory:profile,excludePid:11}).owned.some(x=>x.pid===22),'migration still recognizes exact owned service');
 for(const cmd of [rt+'\\src\\local-bot-full-run.mjs',rt+'\\tools\\other.mjs'])assert.throws(()=>windowsIdle(rt,{platform:'win32',excludePid:11,profileDirectory:profile,readSnapshot:()=>({...snap,processes:[own,p(22,cmd)]})}),{code:'MCR_PROCESSES_ACTIVE'});
});
