import test from 'node:test';
import assert from 'node:assert/strict';
import {contactObservation} from '../lib/workbook-contacts.mjs';
import {confirmMemberCorrection,reviewReceipt} from '../lib/member-review.mjs';
import {LIVE_WORKBOOK_SCHEMA} from '../lib/live-workbook.mjs';
import {makeMultirowMapping} from '../lib/multirow-tpp-mapping.mjs';
import {row} from './helpers.mjs';

const member=(changes={})=>({id:'99900001',source:'MEMBER_PROFILE_VERIFIED',profileIdMatches:true,firstName:'Erika',lastName:'Beispiel',...changes});
const person=(changes={})=>({name:'Erika Beispiel',firstName:'Erika',lastName:'Beispiel',sources:['Absender-Anzeigename'],...changes});
function options(changes={}){
 const meta={filename:'synthetic.xlsx',sheet:'Output',sha256:'a'.repeat(64),liveWorkbook:{schema:LIVE_WORKBOOK_SCHEMA,path:'C:\\MCR-Test\\source.xlsx',businessSha256:'b'.repeat(64)}};
 const active={map:makeMultirowMapping({meta,allRows:()=>[row()]},{headerConfirmed:true})};
 return {active,ticketId:'99990001',member:member(),person:person(),review:{reviewed:false},
  mail:{senderEmail:'erika.beispiel@example.invalid',senderName:'Erika Beispiel',body:'Bitte senden Sie mir Informationen.'},
  recipient:'erika.beispiel@example.invalid',languageEvidence:{language:'DE',reason:'CURRENT_ORIGINAL_MESSAGE'},observedAt:'2026-11-18T09:00:00Z',...changes};
}
test('RC97 contact: original sender, structured member and current language produce an exact WWID-bound observation',()=>{
 const result=contactObservation(options());
 assert.equal(result.wwid,'99900001');assert.equal(result.comarchId,'99900001');assert.equal(result.email,'erika.beispiel@example.invalid');
 assert.equal(result.language,'DE');assert.equal(result.identityVerified,true);assert.equal(result.ownerConfirmed,true);
});
test('RC97 contact: a body name never changes a foreign sender into the member contact',()=>{
 const o=options({mail:{senderEmail:'fremde.person@example.invalid',senderName:'Fremde Person',body:'Name: Erika Beispiel\nIch frage nach diesem Mitglied.'},recipient:'fremde.person@example.invalid'});
 assert.throws(()=>contactObservation(o),{code:'WORKBOOK_CONTACT_OWNER'});
});
test('RC97 contact: only a name in the body without sender-name/alias/signature evidence is insufficient',()=>{
 const o=options({mail:{senderEmail:'postfach123@example.invalid',senderName:'postfach123@example.invalid',body:'Name: Erika Beispiel\nBitte prüfen Sie den Vorgang.'},recipient:'postfach123@example.invalid'});
 assert.throws(()=>contactObservation(o),{code:'WORKBOOK_CONTACT_OWNER'});
});
test('RC97 contact: exact complete sender-email alias can associate contact but initials cannot',()=>{
 const o=options();o.mail.senderName=o.mail.senderEmail;
 assert.equal(contactObservation(o).email,o.mail.senderEmail);
 o.mail.senderName='';o.mail.senderEmail='eb.beispiel@example.invalid';o.recipient=o.mail.senderEmail;
 assert.throws(()=>contactObservation(o),{code:'WORKBOOK_CONTACT_OWNER'});
});
test('RC97 contact: current matching signature permits otherwise opaque sender address',()=>{
 const o=options({mail:{senderName:'',senderEmail:'mail123@example.invalid',body:'Bitte senden Sie mir Informationen.\nMit freundlichen Grüßen\nErika Beispiel'},recipient:'mail123@example.invalid'});
 assert.equal(contactObservation(o).email,'mail123@example.invalid');
});
test('RC97 contact: foreign explicit sender display defeats even a matching email alias or signature',()=>{
 const o=options();o.mail.senderName='Andere Person';o.mail.body+='\nMit freundlichen Grüßen\nErika Beispiel';
 assert.throws(()=>contactObservation(o),{code:'WORKBOOK_CONTACT_OWNER'});
});
test('RC97 contact: foreign current signature defeats otherwise matching sender display',()=>{
 const o=options();o.mail.body+='\nMit freundlichen Grüßen\nAndere Person';
 assert.throws(()=>contactObservation(o),{code:'WORKBOOK_CONTACT_OWNER'});
});
test('RC97 contact: quoted signature cannot prove current contact ownership',()=>{
 const o=options({mail:{senderName:'',senderEmail:'mail123@example.invalid',body:'Bitte prüfen.\nOn Monday someone wrote:\nMit freundlichen Grüßen\nErika Beispiel'},recipient:'mail123@example.invalid'});
 assert.throws(()=>contactObservation(o),{code:'WORKBOOK_CONTACT_OWNER'});
});
test('RC97 contact: typed NAME fallback and quoted-only candidate remain unqualified without owner review',()=>{
 for(const p of [person({sources:['MANUELL_BESTAETIGT'],manualConfirmed:true}),person({quotedOnly:true}),person({manualConfirmed:true,sources:['COMARCH_PROFILE_OPERATOR_REVIEWED']})]){
  assert.throws(()=>contactObservation(options({person:p})),{code:'WORKBOOK_CONTACT_OWNER'});
 }
});
test('RC97 contact: the actual selected-profile ENTER permits contact learning from an opaque sender',async()=>{
 const m=member(),r=await confirmMemberCorrection({member:m,mailPerson:null,evidence:{expectedId:null},ask:async()=>''});
 const review=reviewReceipt(m,r.person,r.reviewed,r);
 const o=options({person:{...r.person,profileReview:review},review,mail:{senderName:'',senderEmail:'mail123@example.invalid',body:'Bitte helfen Sie.'},recipient:'mail123@example.invalid'});
 assert.equal(contactObservation(o).email,'mail123@example.invalid');
});
test('RC97 contact: representative and legacy identity-only token cannot save FM or FN',async()=>{
 for(const gate of ['VERTRETER','ZUORDNUNG_GEPRUEFT']){
  const m=member(),r=await confirmMemberCorrection({member:m,mailPerson:{firstName:'EB',lastName:'Beispiel'},evidence:{expectedId:null},ask:async()=>gate});
  assert.throws(()=>contactObservation(options({person:r.person,review:reviewReceipt(m,r.person,r.reviewed,r)})),{code:'WORKBOOK_CONTACT_REPRESENTATIVE'});
 }
});
test('RC97 contact: owner flag cannot bless a different member or altered review names',()=>{
 const m=member(),p=person(),review=reviewReceipt(m,p,true,{contactOwnerConfirmed:true});
 for(const changed of [{...review,memberId:'99900002'},{...review,originalFirstName:'Andere'},{...review,lastName:'Fremde'}]){
  assert.throws(()=>contactObservation(options({review:changed})),{code:'MEMBER_REVIEW_CHANGED'});
 }
});
test('RC97 contact: an explicit MercerID in the current mail must match even after manual owner confirmation',()=>{
 const o=options();o.review=reviewReceipt(o.member,o.person,true,{contactOwnerConfirmed:true});o.mail.body='MercerID: 99900002';
 assert.throws(()=>contactObservation(o),{code:'MEMBER_ID_CONFLICT'});
});
test('RC97 contact: explicitly reviewed swapped profile names retain correct identity receipt',()=>{
 const m=member({firstName:'Beispiel',lastName:'Erika'}),p=person(),review=reviewReceipt(m,p,true,{swappedProfile:true,contactOwnerConfirmed:true});
 assert.equal(contactObservation(options({member:m,person:p,review})).wwid,'99900001');
});
test('RC97 contact: generic Member text, profile conflict and wrong recipient never qualify',()=>{
 for(const m of [member({source:'MEMBER_FIELD'}),member({source:'PROFILE_ROWS'}),member({profileIdMatches:false})])assert.throws(()=>contactObservation(options({member:m})),{code:'WORKBOOK_CONTACT_PROFILE'});
 assert.throws(()=>contactObservation(options({recipient:'someone.else@example.invalid'})),{code:'WORKBOOK_CONTACT_SENDER'});
});
test('RC97 contact: a prefix lookup preserves MercerID and compares separately labeled WWID',()=>{
 const m=member({id:'1199900001',wwid:'99900001',wwidEvidence:'EXACT_LABELED_WWID'}),result=contactObservation(options({member:m}));
 assert.equal(result.wwid,'99900001');assert.equal(result.comarchId,'1199900001');
 assert.throws(()=>contactObservation(options({member:{...m,wwid:'99900002'}})),{code:'WORKBOOK_CONTACT_WWID'});
});
test('RC97 contact: language requires original-message detection or explicit original-language choice',()=>{
 for(const languageEvidence of [{language:'DE',reason:'DEFAULT'},{language:'EN',reason:'COMARCH_UI'},{language:null,reason:'MIXED_OR_TOO_SHORT'}])assert.throws(()=>contactObservation(options({languageEvidence})),{code:'WORKBOOK_CONTACT_LANGUAGE'});
 assert.equal(contactObservation(options({languageEvidence:{language:'EN',reason:'OPERATOR_ORIGINAL_LANGUAGE',manual:true}})).language,'EN');
});
