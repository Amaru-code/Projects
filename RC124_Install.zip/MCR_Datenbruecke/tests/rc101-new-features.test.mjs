import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {EventEmitter} from 'node:events';
import {parsePhase2Description,descriptionPhase2Rule} from '../lib/phase2-description.mjs';
import {accountStatementPlan} from '../lib/phase2-account-statement-plan.mjs';
import {inspectExistingStatements,generatorPaths,documentFilenameMatches,documentWwidFromFilename} from '../lib/phase2-pdf-evidence.mjs';
import {phase2DraftPreview} from '../lib/phase2-draft-preview.mjs';
import {planPhase2UploadContinuation} from '../lib/phase2-upload-continuation.mjs';
import {phase2Journal} from '../lib/phase2-write-journal.mjs';
import {DeliveryGate,createDeliveryConsole} from '../lib/delivery-console.mjs';
import {safePreactionSkip} from '../lib/preaction-skip.mjs';
import {generatorInputContract,runLocalStatementGenerator} from '../lib/phase2-local-generator.mjs';
const description=(request,plans='DC;PP+')=>`USC 20/${plans}\nStandardantwort versendet\n${request}`;
const row=txt=>descriptionPhase2Rule({ticketId:'89827030',descriptionValue:txt});
for(const request of ['Möchte Kontoauszug & Auszahlungsoption','Möchte Kontoauszug und Auszahlungsoptionen','Möchte KA + AO'])
 test('RC101 combined targets: '+request,()=>{
  const d=description(request),parsed=parsePhase2Description(d);
  assert.equal(parsed.requestKind,'ACCOUNT_STATEMENT');assert.deepEqual(row(d).targets,['DC','PP+','AO']);
  const plan=accountStatementPlan({ticketId:'89827030',description:d,memberName:'Max Mustermann',wwid:'11412817'});
  assert.equal(plan.expectedOutputCount,3);assert.deepEqual(plan.scripts.map(x=>x.plan),['DC','PP+','AO']);
 });
for(const request of ['Möchte AO','Möchte Auszahlungsoptionen','Möchte Auszahlungsoption','Möchte Auszahlungoption'])
 test('RC101 AO only: '+request,()=>assert.deepEqual(row(description(request)).targets,['AO']));
for(const request of ['Möchte Kontoauszug und Rentenberatung','Keine Auszahlung','Möchte Auszahlungoption und MBC'])
 test('RC101 no unrelated free text inferred: '+request,()=>assert.equal(row(description(request)).kind,'MARK_DIRECT'));
function fixture(fn){const folder=fs.mkdtempSync(path.join(os.tmpdir(),'mcr-rc101-'));const root=path.join(folder,'MCR_Datenbruecke');fs.mkdirSync(root);try{return fn(root);}finally{fs.rmSync(folder,{recursive:true,force:true});}}
const testPaths=(root,plan)=>{const p=generatorPaths(root,plan);return plan==='AO'?{...p,output:path.join(root,'..','Auszahlungsoption','Ausgabe PDF')}:p;};
const pdf='%PDF-1.4\n'+('dummy data\n'.repeat(40))+'\n%%EOF';
test('RC101 DC+PP+AO: exact WWID, validated family/given name, hashes, 3 uploads and draft',()=>fixture(root=>{
 const id='11412817';const names={DC:`${id}_Kontoauszug_DC.pdf`,'PP+':`${id}_Kontoauszug_PP+.pdf`,AO:`2025-12-31_Auszahlungsoption_Nachname_Vorname_${id}.pdf`};
 for(const [plan,name] of Object.entries(names)){const {output}=testPaths(root,plan);fs.mkdirSync(output,{recursive:true});fs.writeFileSync(path.join(output,name),pdf);}
 const verified=inspectExistingStatements(root,['DC','PP+','AO'],id,{first:'Vorname',last:'Nachname',paths:testPaths});
 assert.equal(verified.artifacts.length,3);assert.deepEqual(verified.artifacts.map(a=>a.plan),['DC','PP+','AO']);
 const proof={...verified,operatorContentReviewed:true,ticketId:'89827030'};
 const preview=phase2DraftPreview({ticketId:'89827030',source:'E-MAIL',description:description('Möchte Kontoauszug & AO'),pdfProof:proof});
 assert.deepEqual(preview.expectedDocuments,['DC','PP+','AO']);
 const upload=planPhase2UploadContinuation({artifacts:verified.artifacts,evidence:{items:verified.artifacts.map(a=>({name:a.name,present:false,ready:false,count:0,status:'ABSENT'}))}});
 assert.equal(upload.missing.length,3);
 const journal=phase2Journal(root,'89827030',{initial:{ticketId:'89827030',descriptionSha256:'f'.repeat(64),pdfHashes:verified.artifacts.map(a=>({plan:a.plan,sha256:a.sha256}))}});
 journal.begin();journal.advance('UPLOAD_INTENT');
 for(const a of verified.artifacts)journal.recordUploadFileIntent({plan:a.plan,name:a.name,sha256:a.sha256});
 assert.equal(journal.read().events.filter(e=>e.state==='UPLOAD_FILE_INTENT').length,3);
}));
test('RC101 AO: suffix identification, mismatched person rejected, multiple same WWID rejected',()=>fixture(root=>{
 const {output}=testPaths(root,'AO');fs.mkdirSync(output,{recursive:true});
 const name='2025-12-31_Auszahlungsoption_Nachname_Vorname_11412817.pdf';fs.writeFileSync(path.join(output,name),pdf);
 assert(documentFilenameMatches('AO',name,'11412817'));assert.equal(documentWwidFromFilename('AO',name),'11412817');
 assert(!documentFilenameMatches('AO',name,'11412818'));
 assert.throws(()=>inspectExistingStatements(root,['AO'],'11412817',{first:'Andere',last:'Nachname',paths:testPaths}),e=>e.code==='P2_EXACT_PDF_NAME');
 fs.writeFileSync(path.join(output,'2025-12-30_Auszahlungsoption_Nachname_Vorname_11412817.pdf'),pdf);
 assert.throws(()=>inspectExistingStatements(root,['AO'],'11412817',{first:'Vorname',last:'Nachname',paths:testPaths}),e=>e.code==='P2_EXACT_PDF_MISSING');
}));
test('RC101 only fixed BAT input forms are classified, unknown GUI/menu prompt never guessed',()=>{
 assert.equal(generatorInputContract('@echo off\nset /p "WWID=WWID:"\necho %WWID%').mode,'SINGLE_WWID_STDIN');
 assert.equal(generatorInputContract('@echo off\npython gen.py %1').mode,'WWID_ARGUMENT');
 assert.equal(generatorInputContract('@echo off\nset /p option=Menu\nset /p WWID=Name').mode,'UNKNOWN_INPUT_CONTRACT');
 assert.equal(generatorInputContract('start "" powershell.exe -File generator.ps1').mode,'UNKNOWN_INPUT_CONTRACT');
});
test('RC101 legacy UVA generator calls allowlisted cmd.exe and sends exactly one WWID line',async()=>{
 const folder=fs.mkdtempSync(path.join(os.tmpdir(),'mcr-rc101-gen-')),root=path.join(folder,'MCR_Datenbruecke');fs.mkdirSync(root);
 try{
  const p=generatorPaths(root,'DC'),localFolder=path.join(folder,'fixed-bat');fs.mkdirSync(localFolder);
  const localStart=path.join(localFolder,'START_KONTOAUSZUG_DC.bat');
  fs.writeFileSync(localStart,'@echo off\r\nset /p "WWID=WWID:"\r\n');
  let observed;
  const mockSpawn=(bin,args,opts)=>{const c=new EventEmitter();let input='';c.stdout=new EventEmitter();c.stderr=new EventEmitter();c.stdin={on:()=>{},end:x=>{input=x;setImmediate(()=>c.emit('close',0));}};observed={bin,args,opts,get input(){return input;}};return c;};
  const result=await runLocalStatementGenerator(root,'UVA','11412817',{spawnImpl:mockSpawn,isWindows:true,paths:()=>({...p,start:localStart,folder:localFolder}),wait:()=>new Promise(res=>setTimeout(res,1))});
  assert.equal(result.status,'GENERATOR_EXECUTED');assert.equal(observed.bin,'cmd.exe');assert.equal(observed.input,'11412817\r\n');
  assert.equal(observed.opts.cwd,localFolder);assert(observed.args.at(-1).includes(localStart));
 }finally{fs.rmSync(folder,{recursive:true,force:true});}
});
test('RC101 pause revokes prior manual/auto approval, requires CONTINUE plus reapproval',()=>{
 const gate=new DeliveryGate('AUTO'),r=gate.request('89827030'),before=gate.lease();assert(before);
 assert(gate.accept({schema:'MCR_CONTROL_V1',event:'pause'}));assert.equal(gate.paused,true);assert.equal(gate.lease(),null);
 assert.equal(gate.mode,'MANUAL');assert.equal(gate.accept({schema:'MCR_CONTROL_V1',event:'approve',ticket:r.ticket,challenge:r.challenge}),false);
 assert(gate.accept({schema:'MCR_CONTROL_V1',event:'continue'}));assert.equal(gate.lease(),null);
 assert.throws(()=>gate.consume(before),e=>e.code==='SEND_APPROVAL_CHANGED');
 assert(gate.accept({schema:'MCR_CONTROL_V1',event:'approve',ticket:r.ticket,challenge:r.challenge}));
 assert(gate.lease());gate.consume(gate.lease());
});
test('RC101 changed recipient is deferred only with explicit ticket-bound pre-send proof',()=>{
 const ticketId='89827030',r={schema:'MCR_RECIPIENT_REVIEW_V1',ticketId,noSendIntent:true,originalBound:true};
 assert.equal(safePreactionSkip('RECIPIENT_REVIEW_REQUIRED','DESCRIPTION_AND_FIXED_FIELDS',{ticketId,recipientReview:r}),'RECIPIENT_REVIEW');
 assert.equal(safePreactionSkip('RECIPIENT_REVIEW_REQUIRED','DESCRIPTION_AND_FIXED_FIELDS',{ticketId,recipientReview:r,pending:true}),null);
 assert.equal(safePreactionSkip('RECIPIENT_CHANGED_AT_CLICK','SEND_AND_SAVE',{ticketId,recipientReview:r}),null);
});
test('RC101 signature restores neutral Member blur before signature chooser',()=>{
 const src=fs.readFileSync(new URL('../lib/comarch-fixed-fields.mjs',import.meta.url),'utf8');
 const sub=src.indexOf('const subcategorySelection=await select('),sig=src.indexOf('await select(signatureId,Prep.FIXED.signature,');
 assert(sub>0&&sig>sub);assert(src.slice(sub,sig).includes("await focus('mainForm:member-value-id','Unterkategorie per Member-Fokus bestaetigen')"));
});

test('RC101 STOP pauses COMARCH file attachments as well as mouse commands',async()=>{
 const ui=createDeliveryConsole({platform:'linux',initialMode:'MANUAL'});
 const calls=[],cdp={async send(method){calls.push(method);return method;}};
 const undo=ui.protectInput(cdp);ui.gate.accept({schema:'MCR_CONTROL_V1',event:'pause'});
 const upload=cdp.send('DOM.setFileInputFiles',{files:['C:/fake.pdf']});
 await new Promise(r=>setTimeout(r,10));
 assert.equal(calls.length,0);
 ui.gate.accept({schema:'MCR_CONTROL_V1',event:'continue'});
 assert.equal(await upload,'DOM.setFileInputFiles');
 assert.deepEqual(calls,['DOM.setFileInputFiles']);undo();ui.close();
});
