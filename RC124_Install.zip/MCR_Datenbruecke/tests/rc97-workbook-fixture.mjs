/** Synthetic OOXML fixture only; no production workbook data. */
import {writeZip} from '../lib/zip.mjs';
export const sheetPart='xl/worksheets/sheet1.xml';
export const header={B:'WWID',C:'IsEligible_DC',D:'IsEligible_IPP',E:'IsEligible_PensIntel',F:'IsEligible_TPP',G:'JUB',H:'UEB',I:'ZW',L:'USC',O:'Gender'};
export const row={B:'99900001',C:'1',D:'0',E:'0',F:'1',G:'1',H:'0',I:'1',L:'10',O:'M'};
const esc=s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');
export const cells=(values,r,prefix='')=>Object.entries(values).map(([c,v])=>`<${prefix}c r="${c}${r}" t="inlineStr"><${prefix}is><${prefix}t>${esc(v)}</${prefix}t></${prefix}is></${prefix}c>`).join('');
export function fixture({values=row,extraCells='',suffix='',prefix='',dimension='A1:Z3',rows=null,headers=header}={}){
 const p=prefix?prefix+':':'';
 const sheet=`<${p}worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:s="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:x14="urn:test"><${p}dimension ref="${dimension}"/><${p}sheetData><${p}row r="1">${cells(headers,1,p)}</${p}row><${p}row r="2" spans="2:15" ht="18" customHeight="1">${cells(values,2,p)}${extraCells}</${p}row>${rows??`<${p}row r="3">${cells({...row,L:'20'},3,p)}</${p}row>`}</${p}sheetData>${suffix}</${p}worksheet>`;
 return writeZip([
  {name:'xl/workbook.xml',data:'<workbook xmlns:r="urn:r"><sheets><sheet name="Output" sheetId="1" r:id="rId1"/><sheet name="Unrelated" sheetId="2" r:id="rId2"/></sheets></workbook>'},
  {name:'xl/_rels/workbook.xml.rels',data:'<Relationships><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/></Relationships>'},
  {name:sheetPart,data:sheet},
  {name:'xl/worksheets/sheet2.xml',data:'<worksheet><sheetData><row r="1"><c r="A1"><f>1+2</f><v>3</v></c></row></sheetData></worksheet>'},
  {name:'xl/styles.xml',data:'<styleSheet><cellXfs count="1"><xf numFmtId="0"/></cellXfs></styleSheet>'},
  {name:'xl/sharedStrings.xml',data:'<sst><si><t>existing@example.invalid</t></si></sst>'},
  {name:'xl/comments1.xml',data:'<comments><authors><author>Fixture</author></authors><commentList><comment ref="FM2" authorId="0"><text><t>Keep note</t></text></comment></commentList></comments>'},
  {name:'customXml/item1.xml',data:'<?xml version="1.0"?><keep> Original bytes &amp; spacing </keep>'},
  {name:'xl/media/image1.bin',data:Buffer.from([0,1,2,3,255,128])}
 ]);
}
