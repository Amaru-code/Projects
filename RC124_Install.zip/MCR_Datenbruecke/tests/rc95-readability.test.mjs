import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const html=fs.readFileSync(new URL('../tools/flow-lab/MCR_Flow_Lab_RC94.html',import.meta.url),'utf8');
const source=[...html.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/g)].map(m=>m[1]).find(s=>s.includes('RC95 · Original diagram'));
const css=html.match(/<style id="mcr95-presentation">([\s\S]*?)<\/style>/)[1];
assert.ok(source,'embedded original-map readability module exists');
const context=vm.createContext({
  window:{__MCR_READABILITY_TEST__:true},
  localStorage:{getItem:()=>null,setItem:()=>{}},
});
vm.runInContext(source,context,{filename:'RC95-embedded-readability.js'});
const {cameraBox,project,overlap,placeLabels}=context.window.MCRReadability95;
const plain=value=>JSON.parse(JSON.stringify(value));
const near=(actual,expected,message)=>assert.ok(Math.abs(actual-expected)<1e-8,`${message}: ${actual} ≠ ${expected}`);
const item=(id,x,y,extra={})=>({id,title:id,full:`Vollständiger Originaltext ${id}`,point:{x,y},...extra});

test('test flag exposes pure geometry without document or browser dependencies',()=>{
  assert.equal(typeof cameraBox,'function');
  assert.equal(typeof project,'function');
  assert.equal(typeof placeLabels,'function');
  assert.equal(context.document,undefined);
});

test('camera box has independently calculated pan, zoom and viewport dimensions',()=>{
  assert.deepEqual(plain(cameraBox({x:120,y:-80,s:.4},1200,700)),{x:-300,y:200,w:3000,h:1750});
  assert.deepEqual(plain(cameraBox({x:0,y:0,s:1},800,600)),{x:0,y:0,w:800,h:600});
});

test('projection uses the center of a world bound including a nonzero SVG origin',()=>{
  assert.deepEqual(plain(project({x:.5,y:-30,w:100,h:80},{x:9,y:12,s:2})),{x:110,y:32});
});

test('camera rectangle maps to the exact viewport corners across relevant zoom levels',()=>{
  for(const scale of [.025,.035,.082,.65,1,2.5,3.5]){
    const camera={x:-325.25,y:218.125,s:scale};
    const box=cameraBox(camera,933,627);
    const a=project({x:box.x,y:box.y,w:0,h:0},camera);
    const b=project({x:box.x+box.w,y:box.y+box.h,w:0,h:0},camera);
    near(a.x,0,`left at ${scale}`);near(a.y,0,`top at ${scale}`);
    near(b.x,933,`right at ${scale}`);near(b.y,627,`bottom at ${scale}`);
  }
});

test('dragging in screen pixels is independent of the zoom scale',()=>{
  for(const s of [.082,.65,1,3.5]){
    const bounds={x:193.5,y:1008.25,w:190,h:82};
    const a=project(bounds,{x:28,y:-49,s});
    const b=project(bounds,{x:28+57,y:-49-31,s});
    near(b.x-a.x,57,`horizontal drag at ${s}`);
    near(b.y-a.y,-31,`vertical drag at ${s}`);
  }
});

test('semantic label rectangles stay in screen pixels when world scale changes',()=>{
  const world={x:200,y:250,w:180,h:80};
  const sizes=[];
  for(const s of [.082,.35,.65]){
    const point=project(world,{x:300,y:130,s});
    const result=placeLabels([item('CURRENT',point.x,point.y,{width:202,height:48,current:true})],1000,700);
    assert.equal(result.length,1);
    sizes.push([result[0].w,result[0].h]);
  }
  assert.deepEqual(plain(sizes),[[202,48],[202,48],[202,48]]);
  assert.match(css,/\.overview-label95\s*\{[^}]*font\s*:[^;}]*\b\d+(?:\.\d+)?px\//s);
  assert.match(css,/\.overview-leaders95,\.overview-labels95\s*\{[^}]*position:absolute/s);
});

test('edge labels clamp within the visible rectangle and reserved lower edge',()=>{
  const width=540,height=350;
  for(const [x,y]of [[0,0],[width,0],[0,height],[width,height],[width/2,0],[width/2,height]]){
    const result=placeLabels([item('EDGE',x,y)],width,height);
    assert.equal(result.length,1,`edge ${x},${y}`);
    const b=result[0];
    assert.ok(b.x>=10&&b.x+b.w<=width-10,`horizontal clamp at ${x},${y}`);
    assert.ok(b.y>=8&&b.y+b.h<=height-38,`vertical clamp at ${x},${y}`);
  }
});

test('labels outside the viewport are not pulled onto unrelated visible locations',()=>{
  assert.equal(placeLabels([item('LEFT',-1,50),item('RIGHT',501,50),item('TOP',50,-1),item('BOTTOM',50,301)],500,300).length,0);
});

test('ranked current label is retained before colliding lower-priority labels',()=>{
  const candidates=[item('CURRENT',250,160,{current:true,width:202}),...Array.from({length:20},(_,i)=>item(`OTHER-${i}`,250,160))];
  const result=placeLabels(candidates,520,340);
  assert.equal(result[0].id,'CURRENT');
  assert.equal(result[0].current,true);
  assert.equal(result.filter(x=>x.id==='CURRENT').length,1);
  assert.ok(result.length<candidates.length,'conflicts should be omitted rather than overlapping');
  for(let i=0;i<result.length;i++)for(let j=i+1;j<result.length;j++){
    assert.equal(overlap(result[i],result[j]),false,`${result[i].id} overlaps ${result[j].id}`);
  }
});

test('blocked reading window is respected and an alternative placement is used',()=>{
  const blocked=[{x:210,y:70,w:190,h:110}];
  const result=placeLabels([item('CURRENT',300,200,{current:true})],650,450,blocked);
  assert.equal(result.length,1);
  assert.equal(overlap(result[0],blocked[0]),false);
  assert.notEqual(result[0].y,200-48-12,'blocked first option must not be selected');
});

test('fully covered viewport returns no labels instead of overlaying a reading window',()=>{
  assert.equal(placeLabels([item('A',200,150)],500,350,[{x:0,y:0,w:500,h:350}]).length,0);
});

test('dense placement remains collision-free and does not mutate source labels or blockers',()=>{
  let seed=92831;
  const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
  const candidates=Array.from({length:160},(_,i)=>item(`N${i}`,random()*900,random()*650));
  const blocked=[{x:15,y:450,w:280,h:145},{x:770,y:500,w:110,h:100}];
  const before=JSON.stringify({candidates,blocked});
  const result=placeLabels(candidates,900,650,blocked);
  assert.ok(result.length>5,'enough overview stations should remain');
  assert.ok(result.length<candidates.length,'limited space should omit lower-priority labels');
  assert.equal(JSON.stringify({candidates,blocked}),before);
  for(let i=0;i<result.length;i++){
    const a=result[i];
    assert.ok(a.x>=10&&a.x+a.w<=890&&a.y>=8&&a.y+a.h<=612);
    for(const b of blocked)assert.equal(overlap(a,b),false);
    for(let j=i+1;j<result.length;j++)assert.equal(overlap(a,result[j]),false);
  }
});

test('shortened visible title retains the exact full original label and source identity',()=>{
  const full='Zeile 3: „Möchte Kontoauszug“\nIdentität, PDF und WWID prüfen; KEINE E-MAIL.';
  const input=item('KA',250,200,{title:'Kontoauszug · PDFs',full,current:true,sourceGraph:6});
  const [out]=placeLabels([input],800,600);
  assert.equal(out.id,'KA');assert.equal(out.full,full);assert.equal(out.title,'Kontoauszug · PDFs');
  assert.equal(out.sourceGraph,6);assert.equal(out.current,true);
  assert.deepEqual(plain(out.point),{x:250,y:200});
});

test('very narrow viewport never creates labels too small to read',()=>{
  assert.equal(placeLabels([item('A',45,100)],90,350).length,0);
  const [out]=placeLabels([item('A',60,100)],120,350);
  assert.ok(out.w>=80&&out.w<=96);
});

test('hidden or too-short viewport yields no overflowing semantic labels',()=>{
  for(const height of [0,10,40,80])assert.equal(placeLabels([item('A',140,0)],300,height).length,0,`height ${height}`);
});
