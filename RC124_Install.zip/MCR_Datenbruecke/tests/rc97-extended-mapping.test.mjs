import test from 'node:test';
import assert from 'node:assert/strict';
import {row,mapping} from './helpers.mjs';
import {makeMultirowMapping,lookupMultirow,validateMultirowMapping,RULE,EXTENDED_RULE} from '../lib/multirow-tpp-mapping.mjs';
import {sha256} from '../lib/core.mjs';
import {parsePhase2Description,descriptionPhase2Rule} from '../lib/phase2-description.mjs';

const key='99900001';
function live(rows,override={}){
 return makeMultirowMapping({meta:{sheet:'Output',sha256:'a'.repeat(64),liveWorkbook:{path:'K:\\fixture.xlsx',businessSha256:'b'.repeat(64)},...override},allRows:()=>rows},
  {headerConfirmed:true,generatedAt:'2026-11-18T10:00:00Z'});
}
const extendedRow=o=>row({C:0,D:0,E:0,F:0,G:0,H:0,I:0,...o});
const rehash=map=>{map.payloadSha256=sha256(JSON.stringify(map.payload));return map;};

test('RC97 JUB-only source row is a valid plan and keeps WWID/physical row provenance',()=>{
 const map=live([extendedRow({G:1})]),entry=lookupMultirow(map,key);
 assert.equal(entry.description,'USC 10/ JUB');
 assert.equal(entry.records[0].jub,1);assert.equal(entry.records[0].extendedPlans,true);
 assert.equal(entry.records[0].jubSourceColumn,'G');assert.equal(entry.records[0].sourceRow,2);
 assert.equal(map.payload.rule,EXTENDED_RULE);
 assert.deepEqual(map.payload.source.columnsConfirmed,['B','C','D','E','F','G','H','I','L','O']);
});

test('RC97 all seven flags preserve exact order and the established E/PensIntel DB+ alias',()=>{
 const entry=lookupMultirow(live([extendedRow({C:1,D:1,E:1,F:1,G:1,H:1,I:1})]),key);
 assert.equal(entry.description,'USC 10/ DC;PP+;DB+;TPP;JUB;UEB;ZW');
 assert.equal(entry.records[0].pensIntel,1);assert.equal(entry.records[0].dbPlus,1);
});

test('RC97 G/H/I blank and cached-formula provenance remain distinct from zero',()=>{
 const r=lookupMultirow(live([extendedRow({G:'',H:1,I:'',formulas:['H','G','L']})]),key).records[0];
 assert.equal(r.jub,null);assert.equal(r.ueb,1);assert.equal(r.zw,null);
 assert.deepEqual(r.blankColumns,['G','I']);assert.deepEqual(r.formulas,['G','H','L']);
 assert.equal(r.description,'USC 10/ UEB');
});

test('RC97 invalid G/H/I or formula errors block the entire person, not only the bad row',()=>{
 for(const change of [{G:2},{H:'yes'},{I:-1},{G:1,errors:{G:'NO_CACHE'}}]){
  const map=live([extendedRow({G:1}),extendedRow({row:3,...change})]);
  assert.equal(map.payload.entries[key],undefined);
  assert.ok(map.payload.blocked[key].codes.some(c=>['FLAG_INVALID','CELL_ERROR'].includes(c)));
  assert.throws(()=>lookupMultirow(map,key),{code:'ID_BLOCKED'});
 }
});

test('RC97 NO_PLAN checks all C through I and never treats blank as an entitlement',()=>{
 const map=live([extendedRow({G:'',H:'',I:''})]);
 assert.deepEqual(map.payload.blocked[key].codes,['NO_PLAN']);
 assert.equal(lookupMultirow(live([extendedRow({I:1})]),key).description,'USC 10/ ZW');
});

test('RC97 extended multirow descriptions keep physical row order and duplicate lines',()=>{
 const e=lookupMultirow(live([extendedRow({row:8,I:1}),extendedRow({row:3,G:1}),extendedRow({row:2,G:1})]),key);
 assert.deepEqual(e.sourceRows,[2,3,8]);assert.deepEqual(e.descriptionLines,['USC 10/ JUB','USC 10/ JUB','USC 10/ ZW']);
});

test('RC97 legacy V2 payload shape and validation stay unchanged',()=>{
 const map=mapping();validateMultirowMapping(map);
 assert.equal(map.payload.rule,RULE);
 assert.deepEqual(map.payload.source.columnsConfirmed,['B','C','D','E','F','L','O']);
 assert.equal(Object.hasOwn(lookupMultirow(map,key).records[0],'extendedPlans'),false);
});

test('RC97 rehashed extended metadata corruption still fails semantic validation',()=>{
 const cases=[map=>{map.payload.source.columnsConfirmed=['B','C','D','E','F','L','O'];},
  map=>{map.payload.entries[key].records[0].jubSourceColumn='H';},
  map=>{map.payload.entries[key].records[0].extendedPlans=false;},
  map=>{delete map.payload.source.liveWorkbook;},
  map=>{map.payload.source.liveWorkbook.businessSha256='invalid';}];
 for(const mutate of cases){const map=live([extendedRow({G:1})]);mutate(map);assert.throws(()=>validateMultirowMapping(rehash(map)));}
 const legacy=mapping();legacy.payload.entries[key].records[0].jub=1;
 assert.throws(()=>validateMultirowMapping(rehash(legacy)),{code:'MAP_COLUMNS'});
});

test('RC97 phase2 recognizes extended labels but does not invent execution rules',()=>{
 const d=parsePhase2Description('USC 10/ JUB;UEB;ZW\nStandardantwort versendet');
 assert.equal(d.valid,true);assert.deepEqual(d.unknownPlans,[]);
 assert.equal(descriptionPhase2Rule({ticketId:'99900002',descriptionValue:d.raw}).reason,'NOT_REQUESTED');
 assert.equal(descriptionPhase2Rule({ticketId:'99900002',descriptionValue:d.raw+'\nMoechte Kontoauszug'}).reason,'NO_DC_PP_PLAN');
 const rule=descriptionPhase2Rule({ticketId:'99900002',descriptionValue:'USC 10/ DC;JUB\nStandardantwort versendet\nMoechte Kontoauszug'});
 assert.deepEqual(rule.targets,['DC']);
});
