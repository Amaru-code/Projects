import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import Identity from '../lib/identity-evidence.cjs';
import {requireThat as need} from '../lib/core.mjs';
import {confirmMemberCorrection,requireReviewedMember,reviewReceipt} from '../lib/member-review.mjs';
import {promptProfileOrManualPerson} from '../lib/manual-person.mjs';
import {readBoundMemberProfile} from '../lib/member-profile-input.mjs';

const profile=(overrides={})=>({id:'11999991',source:'MEMBER_PROFILE_VERIFIED',profileIdMatches:true,firstName:'Erika',lastName:'Beispiel',...overrides});
const hint={firstName:'EB',lastName:'Beispiel'};
const evidence={expectedId:null};
function inputs(values){const prompts=[],logs=[];return {prompts,logs,ask:async q=>{prompts.push(q);assert(values.length,'No unexpected retyping prompt');return values.shift();},log:x=>logs.push(x)};}

test('RC97: alias conflict displays committed profile and asks one explicit ownership/authority question',async()=>{
 const io=inputs(['']),member=profile({wwid:'00999991',wwidEvidence:'EXACT_LABELED_WWID'});
 const result=await confirmMemberCorrection({member,mailPerson:hint,evidence,...io});
 assert.equal(result.person.firstName,'Erika');assert.equal(result.person.lastName,'Beispiel');
 assert.equal(result.reviewed,true);assert.equal(result.contactOwnerConfirmed,true);assert.equal(io.prompts.length,1);
 assert(io.prompts[0].includes('Berechtigung'));assert(io.prompts[0].includes('VERTRETER'));
 assert(!io.prompts.some(q=>/Vorname.*eingeben|Nachname.*eingeben|MercerID.*eingeben/.test(q)));
 assert(io.logs.some(x=>x.includes('MercerID: 11999991')));assert(io.logs.some(x=>x.includes('WWID')&&x.includes('00999991')));
});

test('RC97: authorized representative remains reviewable without saving its address/language as member contact',async()=>{
 const member=profile(),result=await confirmMemberCorrection({member,mailPerson:hint,evidence,...inputs(['VERTRETER'])});
 assert.equal(result.reviewed,true);assert.equal(result.contactOwnerConfirmed,false);
 const receipt=reviewReceipt(member,result.person,result.reviewed,result);
 assert.equal(receipt.contactOwnerConfirmed,false);assert.equal(requireReviewedMember(member,result.person,evidence,receipt),true);
});

test('RC97: an exact matching profile needs no correction question',async()=>{
 const result=await confirmMemberCorrection({member:profile(),mailPerson:{firstName:'Erika',lastName:'Beispiel'},evidence,ask:async()=>assert.fail('No second confirmation')});
 assert.equal(result.reviewed,false);
});

test('RC97: abort, reselect and unrecognized confirmation remain different outcomes',async()=>{
 for(const [answer,code] of [['ABBRUCH','MEMBER_REVIEW_CANCELLED'],['NEU SUCHEN','MEMBER_REVIEW_RESELECT'],['JA','MEMBER_REVIEW_NOT_AUTHORIZED']]){
  await assert.rejects(()=>confirmMemberCorrection({member:profile(),mailPerson:hint,evidence,...inputs([answer])}),{code});
 }
 await assert.rejects(()=>confirmMemberCorrection({member:profile(),mailPerson:hint,evidence,ask:async()=>undefined}),{code:'MEMBER_REVIEW_CANCELLED'});
});

test('RC97: explicit original MercerID conflict and contradictory profile block before any confirmation',async()=>{
 for(const [member,ev,code] of [[profile(),{expectedId:'99999992'},'MEMBER_ID_CONFLICT'],[profile({source:'MEMBER_PROFILE_CONFLICT',profileIdMatches:false}),evidence,'MEMBER_PROFILE_CONFLICT'],[profile({source:'MEMBER_FIELD',firstName:null,lastName:null}),evidence,'MEMBER_REVIEW_NO_PROFILE']]){
  await assert.rejects(()=>confirmMemberCorrection({member,mailPerson:hint,evidence:ev,ask:async()=>assert.fail('Must stop before asking')}),{code});
 }
});

test('RC97: no name hint reuses already selected profile, retains review and re-reads after confirmation',async()=>{
 const io=inputs(['']);let reads=0;
 const p=await promptProfileOrManualPerson({...io,evidence,readMember:async()=>{reads++;return profile();}});
 assert.equal(p.firstName,'Erika');assert.equal(p.lastName,'Beispiel');assert.equal(p.profileReview.memberId,'11999991');
 assert.equal(p.profileReview.contactOwnerConfirmed,true);assert.equal(io.prompts.length,1);assert.equal(reads,2);
});

test('RC97: no name hint permits browser selection and then derives names without typed names',async()=>{
 const io=inputs(['','']);let reads=0;
 const p=await promptProfileOrManualPerson({...io,evidence,readMember:async()=>++reads===1?null:profile()});
 assert.equal(p.name,'Erika Beispiel');assert.equal(io.prompts.length,2);assert.equal(reads,3);
 assert(!io.prompts.some(x=>x.startsWith('Vorname')||x.startsWith('Nachname')));
});

test('RC97: browser query text cannot be promoted to profile; explicit typed-name fallback remains available',async()=>{
 const io=inputs(['NAMEN','Erika','Beispiel','JA']);
 const p=await promptProfileOrManualPerson({...io,evidence,readMember:async()=>profile({source:'MEMBER_FIELD',profileIdMatches:null})});
 assert.equal(p.name,'Erika Beispiel');assert.equal(p.profileReview,undefined);assert.equal(io.prompts.length,4);
});

test('RC97: changed profile during manual confirmation cannot leave a reusable identity receipt',async()=>{
 const io=inputs(['']);let reads=0;
 await assert.rejects(()=>promptProfileOrManualPerson({...io,evidence,readMember:async()=>++reads===1?profile():profile({id:'11999992'})}),{code:'MEMBER_REVIEW_CHANGED'});
});

test('RC97: ticket-binding failure while confirming missing name propagates before returning person',async()=>{
 const io=inputs(['']);let reads=0;
 await assert.rejects(()=>promptProfileOrManualPerson({...io,evidence,readMember:async()=>{if(++reads>1)throw Object.assign(new Error('Wrong ticket'),{code:'TICKET_BINDING'});return profile();}}),{code:'TICKET_BINDING'});
});

test('RC97: original full name / profile exact reversal still needs one explicit review and stable receipt',async()=>{
 const member=profile({firstName:'Beispiel',lastName:'Erika'}),person={firstName:'Erika',lastName:'Beispiel'};
 const r=await confirmMemberCorrection({member,mailPerson:person,evidence,...inputs([''])});
 assert.equal(r.swappedProfile,true);assert.equal(r.person.firstName,'Erika');
 const receipt=reviewReceipt(member,r.person,true,r);assert.equal(requireReviewedMember(member,r.person,evidence,receipt),true);
 assert.throws(()=>requireReviewedMember(profile(),r.person,evidence,receipt),{code:'MEMBER_REVIEW_CHANGED'});
});

function profileReader({selected=profile(),proof,changeTicket=false}={}){
 let reads=0;
 const ui={assertTicket:async(p,id)=>{assert.equal(id,'99990001');reads++;if(changeTicket&&reads>1)throw Object.assign(new Error('changed ticket'),{code:'TICKET_BINDING'});},selectedMember:async()=>selected};
 const readEvidence=async()=>proof??{profileVerified:true,profile:{mercerId:selected.id,first:selected.firstName,last:selected.lastName},wwid:'00999991',wwidEvidence:'EXACT_LABELED_WWID'};
 return {ui,readEvidence};
}
test('RC97: same bound profile reads WWID separately and preserves leading zeroes',async()=>{
 const p=await readBoundMemberProfile({},'99990001',profileReader());
 assert.equal(p.id,'11999991');assert.equal(p.wwid,'00999991');assert.notEqual(p.wwid,p.id);
});
test('RC97: absent explicit WWID does not use MercerID as WWID',async()=>{
 const p=await readBoundMemberProfile({},'99990001',profileReader({proof:{profileVerified:true,profile:{mercerId:'11999991',first:'Erika',last:'Beispiel'},wwid:null,memberReferenceWwid:'11999991',wwidEvidence:'NO_EXPLICIT_WWID_FIELD'}}));
 assert.equal(p.wwid,null);assert.equal(p.id,'11999991');
});
test('RC97: stale profile evidence or switched ticket cannot be reused',async()=>{
 await assert.rejects(()=>readBoundMemberProfile({},'99990001',profileReader({proof:{profileVerified:true,profile:{mercerId:'11999992',first:'Erika',last:'Beispiel'}}})),{code:'MEMBER_REVIEW_CHANGED'});
 await assert.rejects(()=>readBoundMemberProfile({},'99990001',profileReader({changeTicket:true})),{code:'TICKET_BINDING'});
});

function actualReview({changeMember=false,changeTicket=false,person=hint}={}){
 const source=fs.readFileSync(new URL('../src/local-bot-full-run.mjs',import.meta.url),'utf8');
 const body=source.slice(source.indexOf('async function completeMemberSelection('),source.indexOf('async function selectMember('));
 let confirmed=false,questions=0;
 const current=()=>confirmed&&changeMember?profile({id:'11999992'}):profile();
 const check=async()=>{if(confirmed&&changeTicket)throw Object.assign(new Error('changed ticket'),{code:'TICKET_BINDING'});};
 const context={Identity,need,confirmMemberCorrection,requireReviewedMember,reviewReceipt,DEMO:false,DEMO_SCENARIO:'normal',diag:{},show:()=>{},log:()=>{},fail:(code,m)=>need(false,code,m),
  ask:async()=>{questions++;confirmed=true;return '';},
  UI:{assertTicket:check,selectedMember:async()=>current()},readBoundMemberProfile:async()=>{await check();return current();}};
 const fn=vm.runInNewContext(body+';memberReviewWithReselect',context);
 return {run:()=>fn({},profile(),person,evidence,{},()=>{},'99990001'),questions:()=>questions};
}
test('RC97: real runner returns selected profile after one authority question and bound readback',async()=>{
 const h=actualReview(),r=await h.run();assert.equal(h.questions(),1);assert.equal(r.person.firstName,'Erika');assert.equal(r.review.contactOwnerConfirmed,true);
});
test('RC97: real runner blocks changed selected member immediately after operator confirmation',async()=>{
 const h=actualReview({changeMember:true});await assert.rejects(h.run(),{code:'MEMBER_REVIEW_CHANGED'});assert.equal(h.questions(),1);
});
test('RC97: real runner blocks switched ticket immediately after operator confirmation',async()=>{
 const h=actualReview({changeTicket:true});await assert.rejects(h.run(),{code:'TICKET_BINDING'});assert.equal(h.questions(),1);
});
test('RC97: real runner reuses a confirmed no-name profile receipt without another confirmation',async()=>{
 const person=await promptProfileOrManualPerson({...inputs(['']),evidence,readMember:async()=>profile()});
 const h=actualReview({person}),r=await h.run();assert.equal(h.questions(),0);assert.equal(r.person.firstName,'Erika');assert.equal(r.review.contactOwnerConfirmed,true);
});
