import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import os from 'node:os';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {createFlowRecorder} from '../lib/flow-events.mjs';
const html=fs.readFileSync(new URL('../tools/flow-lab/MCR_Flow_Lab_RC94.html',import.meta.url),'utf8');
const scripts=[...html.matchAll(/<script([^>]*)>([\s\S]*?)<\/script>/g)].map(m=>({attributes:m[1],source:m[2]}));
const graphs=JSON.parse(scripts.find(s=>s.attributes.includes('id="graphData"')).source);
const upgrade=scripts.find(s=>s.source.includes('function parseEvent(line,context)')).source;
function parser(){
 const context=vm.createContext({LIVE:{events:[],run:1,seq:0,unmapped:0},Date});
 const a=upgrade.indexOf('function parseEvent('),b=upgrade.indexOf('\nfunction refsForEvent',a);
 vm.runInContext(upgrade.slice(a,b)+';globalThis.api={parseEvent,ingestLine,eventsForTicket,ctx};',context);
 return {...context.api,LIVE:context.LIVE};
}
test('RC95: every embedded JavaScript block parses and all original graphs remain',()=>{
 for(const script of scripts)if(!/application\/json|text\/plain/.test(script.attributes))new vm.Script(script.source);
 assert.equal(createHash('sha256').update(scripts.find(s=>s.attributes.includes('id="graphData"')).source).digest('hex'),'91b221990624477c4042ce30272e06dacbd25387ed0eff1bde81eab32b1978af');
 assert.equal(graphs.length,12);assert.equal(graphs.reduce((n,g)=>n+g.nodes.length,0),341);
 assert.equal(graphs.reduce((n,g)=>n+g.edges.length,0),429);
 assert.match(html,/MCRStations95/);assert.match(html,/MCRReadability95/);assert.match(html,/MCRBridge94/);
});
test('RC95: start and Phase-1 reuse never claim Phase 2',()=>{
 const p=parser();const begin=p.ingestLine('FLOW_RUN_START:');assert.equal(begin.id,'START');
 p.ingestLine('MASTER_PHASE1_BATCH:');const e=p.ingestLine('PASS MASTER_BROWSER_WIEDERVERWENDET:');
 assert.equal(e.phase,'P1');assert.notEqual(e.id,'P2MASTER');assert.match(e.label,/Phase 1/);
 assert.equal(p.ingestLine('PASS P2_DESCRIPTION_INPUT_VERIFIED:'),null,'shared field input helper is not a phase transition');
});
test('RC95: WWID retry is a waiting station, no fatal error or send permission',()=>{
 const p=parser();p.ingestLine('TICKET_ID: 89419822');
 for(const line of ['NAME_CHOICE_REQUIRED:','NAME_CHOICE_RETRY:','NAME_WWID_RETRY:','NAME_MERCERID_RETRY:']){
  const e=p.ingestLine(line);assert.equal(e.g,3);assert.equal(e.id,'MANUAL');assert.equal(e.type,'wait');assert.equal(e.ticket,'89419822');
 }
 const e=p.ingestLine('NAME_WWID_SEARCH_HINT:');assert.equal(e.id,'PICK');assert.equal(e.type,'step');
 const ok=p.ingestLine('PASS NAME_WWID_RELATION_VERIFIED:');assert.equal(ok.id,'VERIFIED');assert.equal(ok.overview,'ID');
 assert.ok(!p.LIVE.events.some(e=>['SEND','CLICK','SENT'].includes(e.id)));
});
test('RC95: second ticket does not inherit the first ticket green route',()=>{
 const p=parser();p.ingestLine('TICKET_ID: 90000001');p.ingestLine('PASS MEMBER_STRUCTURED_PROFILE_VERIFIED:');p.ingestLine('PASS SEND_IN_HISTORY_BOUND:');p.ingestLine('Ticket speichern PASS');
 p.ingestLine('TICKET_ID: 90000002');p.ingestLine('NAME_CHOICE_REQUIRED:');
 const scoped=p.eventsForTicket();assert.equal(scoped.length,2);assert.ok(scoped.every(e=>e.ticket==='90000002'));assert.ok(!scoped.some(e=>e.type==='good'));
 assert.equal(p.LIVE.events.length,6,'history remains available in the monitor');
});
test('RC95: phase transition, next-case scan and run start clear stale ticket context',()=>{
 const p=parser();p.ingestLine('TICKET_ID: 90000001');p.ingestLine('MASTER_PHASE2:');assert.equal(p.LIVE.ticket,null);
 p.ingestLine('P2_NAECHSTES_TICKET: 90000002 | DB_DIRECT');p.ingestLine('PASS P2_FALL_ABGESCHLOSSEN:');p.ingestLine('P2_BESTAND:');
 assert.equal(p.LIVE.ticket,null);assert.equal(p.LIVE.kind,null);assert.ok(p.eventsForTicket().every(e=>!e.ticket));
 p.ingestLine('FLOW_RUN_START:');assert.equal(p.LIVE.ticket,null);assert.equal(p.LIVE.kind,null);
});
test('RC95: evidence events still reference real original nodes',()=>{
 const p=parser();const lines=['FLOW_RUN_START:','MASTER_REPORT:','MASTER_PHASE1_BATCH:','PASS MASTER_BROWSER_WIEDERVERWENDET:','TICKET_ID: 90000001','NAME_CHOICE_REQUIRED:','NAME_WWID_SEARCH_HINT:','PASS NAME_WWID_RELATION_VERIFIED:','Bestandsabgleich:','PASS P1_SPRACHE: ENGLISCH','PASS FIXED_FIELDS_ALL_VERIFIED:','VERSANDFREIGABE:','SEND_PRUEFUNG_AKTIV:','PASS SEND_IN_HISTORY_BOUND:','Ticket speichern:','Ticket speichern PASS','MASTER_PHASE2:','P2_NAECHSTES_TICKET: 90000002 | MARK_DIRECT','P2_ANFRAGE_MANUELL_KLASSIFIZIEREN:','PASS P2_ANFRAGE_MARK_MANUELL_BESTAETIGT:','PASS P2_WORK_SERVER_PERSISTENCE:','P2_DIRECT_ASSIGNEE_BEGIN:','PASS P2_DIRECT_ASSIGNEE:','P2_JOURNAL REVIEW_VERIFIED','P2_DIREKT_WEITERLEITUNG:','P2_JOURNAL ROUTED_VERIFIED','P2_BESTAND:','P2_LAUF_ENDE:','OFFENE FAELLE: 0','MASTER_BROWSER_GESCHLOSSEN:'];
 for(const line of lines){const e=p.ingestLine(line);assert.ok(e,line);assert.ok(graphs[e.g].nodes.some(n=>n.id===e.id),line+' -> '+e.id);if(e.overview)assert.ok(graphs[0].nodes.some(n=>n.id===e.overview),line+' -> '+e.overview);}
});
test('RC95: skipped/stop/unknown-save proof cannot imply success',()=>{
 const p=parser();p.ingestLine('TICKET_ID: 90000001');
 const e=p.ingestLine('STOP NAME_CHOICE_CANCELLED:');assert.equal(e.type,'bad');assert.equal(e.overview,'ERR');
 const unknown=p.ingestLine('P2_WORK_READBACK_DIAG:');assert.equal(unknown.type,'wait');
 const hold=p.ingestLine('MASTER_UNTERBROCHEN:');assert.equal(hold.overview,'HOLD');assert.equal(hold.type,'bad');
});
test('RC95: all provided scenario presets retain valid original model paths',()=>{
 const pure=scripts.find(s=>s.source.includes('const RC93 =')).source;
 const model=scripts.find(s=>s.source.includes('function modelCase(')).source;
 const c=vm.createContext({console});vm.runInContext(pure+'\n'+model+'\nglobalThis.api={modelCase,validateModelPaths,DEFAULTS,PRESETS};',c);
 assert.ok(c.api.PRESETS.length>5,'multiple actual scenarios are exercised');
 const inputs=new Set();
 for(const preset of c.api.PRESETS){assert.equal(typeof preset.values,'object',preset.id+' has scenario inputs');inputs.add(JSON.stringify(preset.values));const m=c.api.modelCase({...c.api.DEFAULTS,...preset.values});assert.equal(c.api.validateModelPaths(m,graphs).length,0,preset.id);}
 assert.ok(inputs.size>5,'different preset settings, including the default preset, were exercised');
});
test('RC95: live map bridge keeps its loopback endpoint and contains no action endpoint',()=>{
 const bridge=scripts.find(s=>s.source.includes('RC94 bridge adapter.')).source;
 assert.match(bridge,/new EventSource\('\/events\?token='/);assert.match(bridge,/location\.hostname!=='127\.0\.0\.1'/);
 assert.ok(!/fetch\(|XMLHttpRequest|\/api\/send|POST/.test(bridge));
 assert.match(bridge,/d\.seq<=lastSeq/);assert.match(bridge,/run!==d\.run/);assert.match(bridge,/runStatus=d\.status/);
});

function resetHarness(runStatus='INTERRUPTED'){
 const LIVE={runStatus,events:[{run:7,seq:1}],files:new Map([['old',{}]]),ticket:'90000001',kind:'DB_DIRECT',unmapped:3,errors:['old'],seq:1,lastEvent:123,masterId:'old',run:7};
 const ctx={ticket:'90000001',kind:'DB_DIRECT',phase:'P2',batch:true};
 const c=vm.createContext({LIVE,ctx,liveEdgeStarted:new Map([['old',123]])});
 const start=upgrade.indexOf('function resetLive(){'),end=upgrade.indexOf('\nfunction leaveObservation',start);
 assert.ok(start>=0&&end>start,'embedded reset function exists');
 vm.runInContext(upgrade.slice(start,end)+';globalThis.reset=resetLive;',c);
 return {c,LIVE,ctx,reset:c.reset};
}

test('RC95: a fresh observation clears the previous run-end status and evidence',()=>{
 for(const status of ['INTERRUPTED','RETURNED']){
  const h=resetHarness(status);h.reset();
  assert.equal(h.LIVE.runStatus,null,'new replay/observation must not inherit '+status);
  assert.equal(h.LIVE.events.length,0);assert.equal(h.LIVE.run,8);assert.equal(h.LIVE.files.size,0);
  assert.equal(h.LIVE.ticket,null);assert.equal(h.LIVE.kind,null);assert.equal(h.ctx.ticket,null);
  const stationSource=scripts.find(s=>s.source.includes('window.MCRStations95=')).source;
  const c=vm.createContext({window:{},document:{getElementById:()=>null}});vm.runInContext(stationSource,c);
  const next=c.window.MCRStations95.buildLiveModel([{run:8,seq:1,phase:'P1',g:3,id:'MANUAL',overview:'ID',type:'wait',ticket:'90000002'}],{run:8,runStatus:h.LIVE.runStatus});
  assert.equal(next.current,'manual');assert.equal(next.runEnd,null);assert.equal(next.states.stop,undefined);assert.equal(next.states.finish,undefined);
 }
});

test('RC95: an empty SSE reset clears terminal presentation and redraws the waiting state',()=>{
 const h=resetHarness(null),elements=new Map(),intervals=[],sources=[];let renders=0;
 const element=()=>({textContent:'',innerHTML:'',classList:{add(){},toggle(){}},after(){}});
 const get=id=>{if(!elements.has(id))elements.set(id,element());return elements.get(id);};
 const api={state:h.LIVE,ctx:h.ctx,reset:h.reset,disconnect(){},presentNewEvents(){renders++;},ingestLine(){return null;}};
 class EventSourceStub{constructor(url){this.url=url;this.listeners={};sources.push(this);}addEventListener(type,fn){this.listeners[type]=fn;}close(){}}
 const c=vm.createContext({window:{MCRLive:api,MCRUpgrade:{setView(){}},MCRStations95:{render(){}}},document:{createElement:element,getElementById:get,querySelector:()=>element(),body:element()},location:{hostname:'127.0.0.1',port:'8787',hash:'#bridge='+'a'.repeat(64)},URLSearchParams,EventSource:EventSourceStub,setInterval:fn=>{intervals.push(fn);return intervals.length;}});
 const bridge=scripts.find(s=>s.source.includes('RC94 bridge adapter.')).source;vm.runInContext(bridge,c);
 assert.equal(sources.length,1);const es=sources[0];
 c.window.MCRBridge94.onEvent({schema:'MCR_FLOW_EVENT_V1',run:'finished-run',seq:1,phase:'P2',ticket:null,type:'run-end',status:'INTERRUPTED'});
 assert.equal(api.state.runStatus,'INTERRUPTED');assert.match(get('bridge94Label').textContent,/unterbrochen/);
 const before=renders;es.listeners.reset({data:JSON.stringify({replay:false})});
 assert.equal(api.state.runStatus,null);assert.equal(api.state.events.length,0);assert.ok(renders>before,'empty replay reset must render without waiting for another event');
 assert.match(get('bridge94Step').textContent,/Warte/);assert.match(get('bridge94Label').textContent,/wartet/);
 es.onopen();assert.doesNotMatch(get('bridge94Label').textContent,/Lauf beendet/,'ended flag must reset too');
 intervals[0]();assert.match(get('bridge94Age').textContent,/Noch kein Ereignis/,'receipt age must not refer to the previous run');
});

test('RC95: recorder, actual bridge and map retain run-level results without reviving the prior ticket',()=>{
 const temp=fs.mkdtempSync(path.join(os.tmpdir(),'mcr-rc95-flow-scope-'));
 try{
  const recorder=createFlowRecorder(temp);recorder.begin('MASTER');
  const input=['MASTER_PHASE2:','P2_NAECHSTES_TICKET: 90000001 | DB_DIRECT','P2_JOURNAL ROUTED_VERIFIED','P2_FALLERKENNUNG:','P2_BESTAND:','P2_NAECHSTES_TICKET: 90000002 | DB_DIRECT','P2_JOURNAL ROUTED_VERIFIED','P2_LAUF_ENDE:','P2_FEHLERBERICHT:','ERGEBNIS: Alle Tickets im geprueften Bereich bearbeitet; 0 Tickets konnten nicht bearbeitet werden.','OFFENE FAELLE: 0','MASTER_BROWSER_GESCHLOSSEN:'];
  for(const line of input)recorder.line(line);recorder.finish('RETURNED');
  const exported=fs.readFileSync(recorder.file,'utf8').trim().split('\n').map(JSON.parse);
  const LIVE={events:[],run:0,seq:0,unmapped:0,files:new Map()};
  const c=vm.createContext({LIVE,Date,liveEdgeStarted:new Map(),window:{},document:{getElementById:()=>null}});
  const parserSource=upgrade.slice(upgrade.indexOf('function parseEvent('),upgrade.indexOf('\nfunction refsForEvent'));
  const resetSource=upgrade.slice(upgrade.indexOf('function resetLive(){'),upgrade.indexOf('\nfunction leaveObservation'));
  vm.runInContext(parserSource+'\n'+resetSource+';globalThis.api={state:LIVE,ctx,reset:resetLive,ingestLine,scopeEvents:eventsForTicket,presentNewEvents(){}};',c);
  vm.runInContext(scripts.find(s=>s.source.includes('window.MCRStations95=')).source,c);
  const elements=new Map(),element=()=>({textContent:'',classList:{toggle(){}}}),get=id=>{if(!elements.has(id))elements.set(id,element());return elements.get(id);};
  const b=vm.createContext({window:{MCRLive:c.api,MCRUpgrade:{},MCRStations95:{render(){}}},document:{createElement:element,getElementById:get},location:{hostname:'offline',hash:''},URLSearchParams});
  vm.runInContext(scripts.find(s=>s.source.includes('RC94 bridge adapter.')).source,b);
  const snapshot=()=>c.window.MCRStations95.buildLiveModel(c.api.scopeEvents(),{run:LIVE.run,runStatus:LIVE.runStatus});
  for(const data of exported){
   b.window.MCRBridge94.onEvent(data);
   if(/^(?:P2_FALLERKENNUNG|P2_BESTAND|P2_LAUF_ENDE|P2_FEHLERBERICHT|ERGEBNIS|OFFENE FAELLE|MASTER_BROWSER_GESCHLOSSEN):/.test(data.line)){
    assert.equal(data.ticket,null,data.line+' must be exported without a preceding ticket');
    assert.equal(snapshot().ticket,null,data.line+' must remain run-level through the actual bridge');
   }
   if(data.line==='P2_NAECHSTES_TICKET: 90000002 | DB_DIRECT'){
    assert.ok(c.api.scopeEvents().every(e=>e.ticket==='90000002'));
    assert.equal(snapshot().states.handoff,undefined,'new ticket has no inherited route proof');
   }
  }
  const done=snapshot();assert.equal(done.ticket,null);assert.equal(done.current,'finish');assert.equal(done.states.finish,'good','browser close must preserve an explicit scoped completion proof');assert.equal(done.runEnd.status,'RETURNED');
  // A global summary also clears stale IDs when no scan/queue-end line preceded it.
  for(const summary of ['ERGEBNIS: Alle derzeit automatisch bearbeitbaren Tickets bearbeitet','OFFENE FAELLE: 0','NOCH NICHT ERLEDIGT: 1']){
   recorder.begin('P2');recorder.line('P2_NAECHSTES_TICKET: 90000003 | DB_DIRECT');recorder.line(summary);
   const last=JSON.parse(fs.readFileSync(recorder.file,'utf8').trim().split('\n').at(-1));assert.equal(last.ticket,null,summary);
  }
 }finally{fs.rmSync(temp,{recursive:true,force:true});}
});

function currentStations(){
 const source=scripts.find(s=>s.source.includes('RC95 Fahrplan:')).source;
 const c=vm.createContext({window:{},document:{getElementById:()=>null}});vm.runInContext(source,c);return c.window.MCRStations95;
}
test('RC109: pure AO live route uses own station, never Kontoauszug',()=>{
 const p=parser(),a=currentStations();for(const line of ['MASTER_PHASE2:','P2_NAECHSTES_TICKET: 90000001 | AUSZAHLUNGSOPTION','P2_PDF_PERSON:','P2_AO_KONTAKTDATEN_PRUEFEN:','PASS P2_AO_KONTAKTDATEN_VOLLSTAENDIG:','P2_AO_GENERATOR_ARBEITET:','PASS P2_AO_ERZEUGT_UND_GEBUNDEN:','PASS P2_PDF_BELEGE_IM_LAUF:'])p.ingestLine(line);
 let m=a.buildLiveModel(p.LIVE.events);assert.equal(m.current,'ao');assert.equal(m.states.ao,'good');assert.equal(m.states.pdf,undefined);assert.equal(m.states.handoff,undefined);
 p.ingestLine('P2_AUSZAHLUNGSOPTION_ZURUECKGESTELLT:');m=a.buildLiveModel(p.LIVE.events);assert.equal(m.current,'open');assert.equal(m.states.open,'wait');assert.equal(m.states.handoff,undefined);
});
test('RC109: combined case shows both document stations and leaves routing unproven',()=>{
 const p=parser(),a=currentStations();for(const line of ['MASTER_PHASE2:','P2_NAECHSTES_TICKET: 90000001 | KONTOAUSZUG_UND_AUSZAHLUNGSOPTION','P2_PDF_PERSON:','P2_AO_KONTAKTDATEN_PRUEFEN:','PASS P2_AO_ERZEUGT_UND_GEBUNDEN:','PASS P2_PDF_BELEGE_IM_LAUF:'])p.ingestLine(line);
 const m=a.buildLiveModel(p.LIVE.events);assert.equal(m.states.ao,'good');assert.ok(m.states.pdf);assert.equal(m.states.handoff,undefined);assert.equal(m.rule,'KONTOAUSZUG_UND_AUSZAHLUNGSOPTION');
});
test('RC109: standalone simulation parser accepts AO and combined requests',()=>{
 const pure=scripts.find(s=>s.source.includes('const RC93 =')).source;const c=vm.createContext({console});vm.runInContext(pure+';globalThis.rule=RC93.descriptionPhase2Rule;',c);
 const base='USC 10/ PP+\nStandardantwort versendet\n';
 assert.deepEqual(Array.from(c.rule({ticketId:'90000001',descriptionValue:base+'Möchte AO'}).targets),['AO']);
 assert.deepEqual(Array.from(c.rule({ticketId:'90000001',descriptionValue:base+'Möchte Kontoauszug & Auszahlungsoption'}).targets),['PP+','AO']);
});
