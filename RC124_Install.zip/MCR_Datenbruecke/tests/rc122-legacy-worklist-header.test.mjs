import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {inspectIntelNavigation} from '../lib/intel-worklist-navigation.mjs';
import {navigateToScope} from '../lib/browser-workflow.mjs';

const own='IN_BEARBEITUNG',queue='WARTESCHLANGE_INTL01';
const folderId=scope=>'storedSearchesContainer_'+(scope===own?'MY_TASKS':'MY_QUEUES');
const caption=scope=>scope===own?'Meine Vorgänge':'Warteschlange';
const element=(tagName,textContent='',attributes={},shown=true)=>({
 tagName,textContent,isConnected:true,getClientRects:()=>shown?[{}]:[],
 classList:{contains:()=>false},getAttribute:key=>attributes[key]??null,
 hasAttribute:key=>Object.hasOwn(attributes,key),closest:()=>null,querySelectorAll:()=>[]
});
const header=(name,attributes={})=>element('A',name,{title:name,...attributes});

function inspect(scope,{preceding=null,shown=false,folders=1,parent=null,items=[]}={}){
 const group=element('SPAN','',{id:folderId(scope)},shown);
 group.previousElementSibling=preceding;
 if(parent){group.parentElement=parent;parent.children=[group];}
 group.querySelectorAll=selector=>selector.startsWith('[aria-selected')?[]:items;
 const document={querySelectorAll:selector=>selector==='[id="'+folderId(scope)+'"]'?Array(folders).fill(null).map((_,i)=>i?{...group}:group):[]};
 return vm.runInNewContext('('+inspectIntelNavigation.toString()+')(scope,true,false)',
  {scope,document,getComputedStyle:()=>({display:'block',visibility:'visible',fontWeight:'400'})});
}

test('RC122 legacy title anchor is only a disclosure of its adjoining saved-search container',()=>{
 for(const scope of [own,queue]){
  const anchor=header(caption(scope));
  const proof=inspect(scope,{preceding:anchor});
  assert.equal(proof.state,'DISCLOSURE');assert.equal(proof.evidence,'LEGACY_GROUP_HEADER');assert(!proof.active);
  const heading=Object.assign(element('DIV',caption(scope)),{querySelectorAll:()=>[anchor]});
  const parent=Object.assign(element('LI'),{previousElementSibling:heading});
  assert.equal(inspect(scope,{parent}).state,'DISCLOSURE');
  // Some releases fill an empty, visible group only when its titled header is clicked.
  assert.equal(inspect(scope,{preceding:anchor,shown:true}).state,'DISCLOSURE');
  assert.equal(inspect(scope,{preceding:element('A',caption(scope)),shown:true}).state,'CHILD_NOT_VISIBLE');
  assert.equal(inspect(scope,{preceding:anchor,folders:2}).state,'DUPLICATE_CONTAINER');
  assert.equal(inspect(scope,{preceding:anchor,folders:0}).state,'CONTAINER_NOT_VISIBLE');
 }
});

test('RC122 unrelated headers, foreign links, menus with multiple actions and ambiguous labels stay untouched',()=>{
 const mixed=Object.assign(element('DIV','Fremde Gruppe Meine Vorgänge'),{querySelectorAll:()=>[header('Meine Vorgänge')]});
 const ambiguous=Object.assign(element('DIV','Meine Vorgänge'),{querySelectorAll:()=>[header('Meine Vorgänge'),header('Meine Vorgänge')]});
 const cases=[null,header('Warteschlange'),header('Offene Vorgänge'),header('Meine Vorgänge',{target:'_blank'}),
  header('Meine Vorgänge',{href:'/allTasks'}),header('Meine Vorgänge',{disabled:''}),header('Meine Vorgänge',{'aria-controls':folderId(queue)}),
  header('Meine Vorgänge',{'aria-label':'Andere Liste'}),mixed,ambiguous];
 for(const preceding of cases){
  const probe=inspect(own,{preceding});
  assert.equal(probe.state,'CHILD_NOT_VISIBLE');assert.equal(probe.menuObservation.group,'HIDDEN');
 }
});

test('RC122 a previously bold child revealed with general rows must be clicked and its delayed rows awaited',async()=>{
 const table='mainForm:tasksTableFor_MyTasksList',genericId='99010001',savedId='99010002';
 const atHeader={x:10,y:15},atChild={x:12,y:40};
 let expanded=false,clicked=false,readsAfterChild=0;
 const actions=[];
 const page={
  async call(fn,_scope,allowDisclosure,locatePoint){
   if(fn===inspectIntelNavigation){
    if(!expanded)return allowDisclosure?{state:'DISCLOSURE',evidence:'LEGACY_GROUP_HEADER',point:atHeader}:{state:'CHILD_NOT_VISIBLE',active:false};
    return {state:'CHILD',evidence:'MENU_SELECTED',active:true,point:locatePoint?atChild:null};
   }
   const ready=clicked&&++readsAfterChild>=2;
   return {ok:true,scope:own,tableId:table,state:'READY',render:ready?'child-table':expanded?'header-table':'initial-table',
    rows:[{ticketId:ready?savedId:genericId}]};
  },
  async mouseClick(x,y){
   actions.push([x,y]);if(y===atHeader.y)expanded=true;
   else if(y===atChild.y)clicked=true;
   else assert.fail('Unexpected target');
  }
 };
 const result=await navigateToScope(page,own);
 assert.deepEqual(actions,[[10,15],[12,40]]);assert.equal(result.rows[0].ticketId,savedId);
 assert.deepEqual(result.navigationEvidence,{expansionMethod:'LEGACY_GROUP_HEADER',childClicks:1,targetState:'CHILD'});
});
