import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import * as UI from '../lib/browser-workflow.mjs';
import {findPhase1Candidate} from '../lib/phase1-worklist-search.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
import {checkVisibleMenu,checkCountedFilters} from './rc123-visible-menu-fixture.mjs';
import {checkActiveHeadings} from './rc123-active-heading-fixture.mjs';
import {checkQueueResults} from './rc124-worklist-result-fixture.mjs';

test('RC123 chooses the exact visible nested menu entry before opening a ticket', {timeout:55000}, async()=>{
 const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC20-NOTE-RC123-'));
 let browser,cdp;
 try{
  browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,
   extraArgs:process.platform==='linux'?['--no-sandbox','--disable-dev-shm-usage']:[]});
  ({cdp}=await connectBrowser(browser.port));
  const page=await attachPage(cdp,t=>t.type==='page'&&t.url==='about:blank');
  await checkVisibleMenu(page,UI,findPhase1Candidate,assert);
  await checkCountedFilters(page,UI,findPhase1Candidate,assert);
  await checkCountedFilters(page,UI,findPhase1Candidate,assert,{direct:true});
  await checkActiveHeadings(page,UI,assert);
  await checkQueueResults(page,UI,findPhase1Candidate,assert);
 } finally{
  await cleanupTemporaryTestBrowser({profile,browser,cdp});
 }
});
