"""RC116: synthetic original-generator contract, no Excel or live files."""
import importlib.util
import json
import os
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('ao_bridge',ROOT/'tools'/'ao-generator-bridge.py')
bridge=importlib.util.module_from_spec(spec);spec.loader.exec_module(bridge)
FIXTURE=r'''from pathlib import Path
from datetime import datetime
import json, time
BASE=Path(__file__).resolve().parent
WORKBOOK=BASE/'IPP_Leistungsberechnungen_Arbeitsdatei.xlsm'
OUTPUT=BASE/'Ausgabe PDF'
AUDIT=BASE/'Audit_Logs'
MASTER=BASE/'master.xlsx'
CONTROL_TEMPLATE=BASE/'control.xlsm'
TRACE=BASE/'trace.txt'
MODE=__MODE__
def trace(s):
    with TRACE.open('a',encoding='utf8') as f:f.write(s+'\n')
class Excel:
    def __init__(self):trace('excel')
    def Quit(self):trace('quit')
def lookup_person(excel,wwid):
    assert isinstance(excel,Excel)
    trace('lookup_person')
    return {'WWID':int(wwid),'Name':'Nachname Vorname',**json.loads(MASTER.read_text(encoding='utf8'))}
def is_missing_contact_value(value):return value in (None,'','#NV','#N/A')
def request_missing_address(person):
    trace('request_missing_address')
    changed=False
    for field in ('Adresse','PLZ'):
        if is_missing_contact_value(person.get(field)):
            person[field]=input(field+': ').strip();changed=True
            if not person[field]:raise ValueError('empty contact')
    return changed
def save_contact_to_master(excel,person,wwid):
    assert isinstance(excel,Excel)
    trace('save_contact_to_master')
    if MODE=='readonly':raise PermissionError('Gesamtdatenbestand ist schreibgeschützt')
    if MODE=='savefail':raise OSError('network write error')
    MASTER.write_text(json.dumps({k:person[k] for k in ('Adresse','PLZ')},ensure_ascii=False),encoding='utf8')
def default_stichtag(today=None):return datetime((today or datetime.now()).year,12,31)
def ask_stichtag():
    default=default_stichtag();v=input(f'Stichtag (TT.MM.JJJJ) [{default:%d.%m.%Y}]: ').strip()
    return datetime.strptime(v,'%d.%m.%Y') if v else default
def write_audit(wwid,status,**details):
    AUDIT.mkdir(exist_ok=True)
    p=AUDIT/(datetime.now().strftime('%Y%m%d_%H%M%S_')+wwid+'.json')
    p.write_text(json.dumps({'timestamp':datetime.now().isoformat(timespec='seconds'),'wwid':wwid,'status':status,**details},ensure_ascii=False),encoding='utf8')
    return p
def progression_balances(wwid):
    raise ValueError('Kein historischer Basiskontostand vor 01.01.2026 für WWID '+wwid+'.')
def lookup_balances(wwid):
    if MODE=='history':progression_balances(wwid)
    if MODE=='balance':raise ValueError('Keine numerischen Basis-/Schattenkontowerte für WWID '+wwid+' gefunden.')
    if MODE=='year':raise LookupError('Jahr 2026 wurde in Kontrolle!A nicht gefunden.')
    if MODE=='unknown':raise ValueError('Fiktiver spezifischer Fehler')
def create_pdf(wwid):
    trace('create_pdf');date=ask_stichtag();excel=Excel()
    try:
        person=lookup_person(excel,wwid)
        supplied=request_missing_address(person)
        if supplied:save_contact_to_master(excel,person,wwid)
        if MODE=='private':raise ValueError('Fehler '+person['Adresse']+' '+person['PLZ'])
        if MODE=='prompt':input('Unbekannte Frage: ')
        lookup_balances(wwid);trace('calculate')
        OUTPUT.mkdir(exist_ok=True)
        pdf=OUTPUT/f'{date:%Y-%m-%d}_Auszahlungsoption_{person["Name"]}_{wwid}.pdf'
        if MODE!='stale':pdf.write_bytes(b'%PDF-1.7\n'+b'x'*500+b'\n%%EOF')
        if MODE=='badpdf':pdf.write_bytes(b'x'*500)
        WORKBOOK.write_bytes(b'working file saved')
        audit=write_audit(wwid,'success',name=person['Name'],stichtag=date.strftime('%d.%m.%Y'),record=7,pdf=str(pdf),contact_supplied=supplied)
        if MODE=='wrong_audit':audit.write_text(audit.read_text().replace(wwid,'99999999'))
        return pdf,audit,7,person
    except Exception as exc:
        if MODE!='noaudit':write_audit(wwid,'failed',reason=str(exc))
        raise
    finally:excel.Quit()
'''
class DummyExcel:
    def install(self):pass
    def cleanup(self,*args):pass
    def restore(self):pass
class NativeGeneratorTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.folder=Path(self.temp.name);self.script=self.folder/'auszahlungsoption_generator.py';self.wwid='11412817';self.stages=[]
        (self.folder/'IPP_Leistungsberechnungen_Arbeitsdatei.xlsm').write_bytes(b'old')
        (self.folder/'control.xlsm').write_bytes(b'control')
    def tearDown(self):self.temp.cleanup()
    def fixture(self,mode='ok',address='Fiktive Strasse 1',postcode='01234 Beispielort'):
        self.script.write_text(FIXTURE.replace('__MODE__',repr(mode)),encoding='utf8')
        (self.folder/'master.xlsx').write_text(json.dumps({'Adresse':address,'PLZ':postcode},ensure_ascii=False),encoding='utf8')
    def run_gen(self,callback=None,allowed=True,first='Vorname',source_sha=None):
        with patch.object(bridge,'OwnedExcel',DummyExcel):
            return bridge.generate(self.script,self.wwid,'a'*32,source_sha or bridge.sha(self.script.read_bytes()),10,lambda v:None,stage=self.stages.append,expected_first=first,expected_last='Nachname',contact_io=callback,contact_write_allowed=allowed)
    def trace(self):return (self.folder/'trace.txt').read_text().splitlines()
    def fields(self):return json.loads((self.folder/'master.xlsx').read_text())
    def test_original_lookup_single_lifecycle(self):
        self.fixture();p=self.run_gen(lambda f:self.fail('no prompt'))['proof'];self.assertEqual(self.trace(),['create_pdf','excel','lookup_person','request_missing_address','calculate','quit']);self.assertEqual(p['wwid'],self.wwid);self.assertNotIn('contactInput',p);self.assertEqual(p['sha256'],bridge.sha(Path(p['file']).read_bytes()))
    def test_original_save_with_city(self):
        self.fixture(address='',postcode='');seen=[]
        def cb(f):seen.append(f);return '01234 Fiktiver Ort' if f=='PLZ' else 'Fiktive Straße 7'
        p=self.run_gen(cb)['proof'];self.assertEqual(seen,['Adresse','PLZ']);self.assertEqual(self.fields(),{'Adresse':'Fiktive Straße 7','PLZ':'01234 Fiktiver Ort'});self.assertEqual(self.trace(),['create_pdf','excel','lookup_person','request_missing_address','save_contact_to_master','calculate','quit']);self.assertEqual(p['contactInput'],{'schema':'MCR_AO_GENERATOR_CONTACT_V2','fields':seen,'generatorSaveReported':True});self.assertNotIn('Fiktive Straße',json.dumps(p));self.assertNotIn('MASTER_READ_OK',self.stages)
    def test_existing_numeric_postcode_is_not_overwritten(self):
        self.fixture(postcode='01234');self.run_gen(lambda f:self.fail('no prompt'));self.assertEqual(self.fields()['PLZ'],'01234')
    def test_only_missing_postal_line(self):
        self.fixture(postcode='');seen=[];self.run_gen(lambda f:seen.append(f) or '01234 Beispielort');self.assertEqual(seen,['PLZ']);self.assertEqual(self.fields()['Adresse'],'Fiktive Strasse 1')
    def test_decline_second_prompt_no_save(self):
        self.fixture(address='',postcode='')
        def cb(f):
            if f=='PLZ':raise bridge.BridgeError('AO_CONTACT_INPUT_DEFERRED','declined')
            return 'Fiktive Strasse 7'
        with self.assertRaises(bridge.BridgeError) as e:self.run_gen(cb)
        self.assertEqual(e.exception.code,'AO_CONTACT_INPUT_DEFERRED');self.assertNotIn('save_contact_to_master',self.trace());self.assertEqual(self.fields(),{'Adresse':'','PLZ':''})
    def test_no_contact_write_allowed_complete_contacts(self):self.fixture();self.assertEqual(self.run_gen(allowed=False)['status'],'SUCCESS')
    def test_no_contact_write_allowed_missing_contacts(self):
        self.fixture(address='');
        with self.assertRaises(bridge.BridgeError) as e:self.run_gen(lambda f:self.fail('must not prompt'),allowed=False)
        self.assertEqual(e.exception.code,'AO_QUEUE_PAUSED_MASTER_WRITE')
    def test_no_contact_callback(self):
        self.fixture(address='');
        with self.assertRaises(bridge.BridgeError) as e:self.run_gen()
        self.assertEqual(e.exception.code,'AO_CONTACT_DATA_REQUIRED')
    def test_wrong_member_before_input(self):
        self.fixture(address='');
        with self.assertRaises(bridge.BridgeError) as e:self.run_gen(lambda f:self.fail('no prompt'),first='Andere')
        self.assertEqual(e.exception.code,'P2_AO_GENERATOR_PERSON');self.assertNotIn('save_contact_to_master',self.trace())
    def test_unrecognized_prompt(self):
        self.fixture(mode='prompt');
        with self.assertRaises(bridge.BridgeError) as e:self.run_gen(lambda f:self.fail('no prompt'))
        self.assertEqual(e.exception.code,'AO_UNEXPECTED_INPUT')
    def test_readonly_error_from_original_save(self):
        self.fixture(mode='readonly',address='')
        with self.assertRaises(bridge.BridgeError) as e:self.run_gen(lambda f:'Fiktive Strasse 7')
        self.assertEqual(e.exception.code,'MASTER_OPENED_READONLY');self.assertEqual(e.exception.details['operation'],'open_contact_write');self.assertIn('audit_path',e.exception.details);self.assertNotIn('calculate',self.trace())
    def test_unknown_save_failure_no_pdf(self):
        self.fixture(mode='savefail',address='')
        with self.assertRaises(bridge.BridgeError) as e:self.run_gen(lambda f:'Fiktive Strasse 7')
        self.assertEqual(e.exception.code,'AO_CONTACT_SAVE_UNVERIFIED');self.assertEqual(e.exception.details['audit_reason'],'network write error');self.assertNotIn('calculate',self.trace())
    def test_history_error_new_audit(self):
        self.fixture(mode='history');ad=self.folder/'Audit_Logs';ad.mkdir();(ad/'20200101_000000_11412817.json').write_text('{}')
        with self.assertRaises(bridge.BridgeError) as e:self.run_gen()
        err=e.exception;self.assertEqual(err.code,'AO_PROGRESSION_HISTORY_MISSING');self.assertIn('Kein historischer Basiskontostand',str(err));self.assertEqual(err.details['operation'],'progression_balances');self.assertNotIn('20200101',err.details['audit_path']);self.assertTrue(Path(err.details['audit_path']).exists())
    def test_balance_error(self):
        self.fixture(mode='balance')
        with self.assertRaises(bridge.BridgeError) as e:self.run_gen()
        self.assertEqual(e.exception.code,'AO_BALANCE_SOURCE_MISSING')
    def test_control_year_error(self):
        self.fixture(mode='year')
        with self.assertRaises(bridge.BridgeError) as e:self.run_gen()
        self.assertEqual(e.exception.code,'AO_CONTROL_YEAR_MISSING')
    def test_unknown_reason_retained(self):
        self.fixture(mode='unknown')
        with self.assertRaises(bridge.BridgeError) as e:self.run_gen()
        self.assertEqual(e.exception.code,'AO_GENERATOR_FAILED');self.assertEqual(str(e.exception),'Fiktiver spezifischer Fehler');self.assertEqual(e.exception.details['audit_reason'],str(e.exception))
    def test_contact_values_redacted_from_failure(self):
        self.fixture(mode='private',address='',postcode='')
        with self.assertRaises(bridge.BridgeError) as e:self.run_gen(lambda f:'01234 Geheimer Ort' if f=='PLZ' else 'Geheime Straße 7')
        self.assertNotIn('Geheim',str(e.exception));self.assertNotIn('Geheim',json.dumps(e.exception.details));self.assertIn('Kontaktwert entfernt',str(e.exception))
    def test_old_pdf_archived_new_audit_required(self):
        self.fixture();out=self.folder/'Ausgabe PDF';out.mkdir();p=out/f'{bridge.datetime.now().year}-12-31_Auszahlungsoption_Nachname Vorname_{self.wwid}.pdf';p.write_bytes(b'%PDF-1.7\nold file\n%%EOF');old=p.read_bytes();proof=self.run_gen()['proof'];self.assertNotEqual(p.read_bytes(),old);self.assertEqual((out/'.mcr_historie'/('a'*32)/p.name).read_bytes(),old);self.assertTrue(proof['freshness']['newAudit'])
    def test_stale_pdf_refused(self):
        self.fixture(mode='stale');out=self.folder/'Ausgabe PDF';out.mkdir();p=out/f'{bridge.datetime.now().year}-12-31_Auszahlungsoption_Nachname Vorname_{self.wwid}.pdf';p.write_bytes(b'%PDF-1.7\n'+b'x'*500+b'\n%%EOF');os.utime(p,(time.time()-10,)*2)
        with self.assertRaises(bridge.BridgeError) as e:self.run_gen()
        self.assertEqual(e.exception.code,'AO_RESULT_STALE')
    def test_invalid_pdf_refused(self):
        self.fixture(mode='badpdf')
        with self.assertRaises(bridge.BridgeError) as e:self.run_gen()
        self.assertEqual(e.exception.code,'AO_RESULT_PDF')
    def test_wrong_audit_refused(self):
        self.fixture(mode='wrong_audit')
        with self.assertRaises(bridge.BridgeError) as e:self.run_gen()
        self.assertEqual(e.exception.code,'AO_AUDIT_MISMATCH')
    def test_changed_source_refused(self):
        self.fixture()
        with self.assertRaises(bridge.BridgeError) as e:self.run_gen(source_sha='0'*64)
        self.assertEqual(e.exception.code,'AO_SCRIPT_CHANGED');self.assertFalse((self.folder/'trace.txt').exists())
    def test_workbook_owner_marker_not_deleted(self):
        self.fixture();p=self.folder/'~$IPP_Leistungsberechnungen_Arbeitsdatei.xlsm';p.write_text('owner')
        with self.assertRaises(bridge.BridgeError) as e:self.run_gen()
        self.assertEqual(e.exception.code,'AO_WORKBOOK_BUSY');self.assertEqual(p.read_text(),'owner')
    def test_postcode_validation(self):
        for good in ['01234 Beispielort','78073 Bad Dürrheim','12345 Frankfurt am Main']:self.assertTrue(bridge.valid_contact('PLZ',good))
        for bad in ['01234','0123 Ort','01234 123','01234 Ort\nX','=01234 Ort','']:self.assertFalse(bridge.valid_contact('PLZ',bad))
    def test_ambiguous_or_historical_failure_not_used(self):
        self.fixture();ad=self.folder/'Audit_Logs';ad.mkdir();exc=ValueError('test');now=bridge.datetime.now();before={'20200101_000000_11412817.json'}
        (ad/next(iter(before))).write_text(json.dumps({'timestamp':now.isoformat(),'wwid':self.wwid,'status':'failed','reason':'test'}))
        self.assertEqual(bridge.find_failed_audit(ad,self.wwid,time.time()-1,before,exc)['audit_state'],'NO_BOUND_FAILURE_AUDIT')
        for n in ['20261124_120001_11412817.json','20261124_120002_11412817.json']:(ad/n).write_text(json.dumps({'timestamp':now.isoformat(),'wwid':self.wwid,'status':'failed','reason':'test'}))
        self.assertEqual(bridge.find_failed_audit(ad,self.wwid,time.time()-1,before,exc)['audit_state'],'AMBIGUOUS')
    def test_watchdog_human_pause(self):
        w=bridge.ActiveTimeWatchdog(.03);w.start();results=[];t=threading.Thread(target=lambda:results.append(w.wait_expired()));t.start()
        with w.human_input():time.sleep(.08);self.assertEqual(results,[])
        w.finish();t.join(1);self.assertEqual(results,[False])
if __name__=='__main__':unittest.main()
