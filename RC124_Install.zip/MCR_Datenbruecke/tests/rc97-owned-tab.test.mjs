import test from 'node:test';
import assert from 'node:assert/strict';
import {ownedStartupUrl,claimStartupTarget,assertOwnedPageTarget,attachOwnedPage,detachOwnedPage} from '../lib/cdp.mjs';
import {browserLeaseEnvironment,validateBrowserLease} from '../lib/master-browser-lease.mjs';

const url='https://comarchecm.mercer.com/';
const masterId='2026-11-18T12-00-00_master97';
function fakeBrowser({marker=ownedStartupUrl(masterId),staleFrames=0,navigationError=null,neverFresh=false}={}){
 const calls=[],sessions=new Map();let next=0,loader=1,pendingStale=0,oldLoader='loader-1';
 const targets=[{type:'page',targetId:'owned',url:marker},{type:'page',targetId:'foreign-blank',url:'about:blank'},
  {type:'page',targetId:'restored-comarch',url}];
 const cdp={calls,targets,sessions,async send(method,params={},sessionId=null){
  calls.push({method,params,sessionId});
  if(method==='Target.getTargets')return {targetInfos:targets.map(t=>({...t}))};
  if(method==='Target.attachToTarget'){assert.ok(targets.some(t=>t.targetId===params.targetId));const id='session-'+(++next);sessions.set(id,params.targetId);return {sessionId:id};}
  if(method==='Target.detachFromTarget'){sessions.delete(params.sessionId);return {};}
  if(method==='Target.activateTarget')return {};
  if(['Runtime.enable','Page.enable','DOM.enable'].includes(method))return {};
  const target=targets.find(t=>t.targetId===sessions.get(sessionId));assert.ok(target,'session is attached to an existing target');
  if(method==='Page.getFrameTree'){
   const value=neverFresh||pendingStale-->0?oldLoader:'loader-'+loader;
   return {frameTree:{frame:{id:'frame-'+target.targetId,loaderId:value,url:target.url}}};
  }
  if(method==='Page.navigate'){
   if(navigationError)return {errorText:navigationError};
   oldLoader='loader-'+loader;loader++;pendingStale=staleFrames;target.url=params.url;
   return {frameId:'frame-'+target.targetId,loaderId:'loader-'+loader};
  }
  if(method==='Runtime.evaluate')return {result:{value:{ready:'complete',url:target.url}}};
  throw Error('Unexpected CDP action: '+method);
 }};return cdp;
}

test('RC97: claims only the unique launcher marker, leaving restored and unrelated blank tabs alone',async()=>{
 const b=fakeBrowser();const id=await claimStartupTarget(b,ownedStartupUrl(masterId));
 assert.equal(id,'owned');assert.deepEqual(b.calls.map(c=>c.method),['Target.getTargets']);
 assert.equal(b.targets.length,3);
 await assert.rejects(claimStartupTarget(b,'about:blank'),{code:'BROWSER_OWNED_MARKER'});
});
test('RC97: ambiguous or absent startup marker never falls back to an existing COMARCH tab',async()=>{
 const b=fakeBrowser();b.targets.push({...b.targets[0],targetId:'duplicate'});
 await assert.rejects(claimStartupTarget(b,ownedStartupUrl(masterId)),{code:'BROWSER_OWNED_TARGET_AMBIGUOUS'});
 await assert.rejects(claimStartupTarget(b,ownedStartupUrl('2026-11-18_other-master'),{timeoutMs:0}),{code:'BROWSER_OWNED_TARGET_MISSING'});
 assert.ok(b.calls.every(c=>c.method==='Target.getTargets'));
});
test('RC97: pilot, batch and Phase 2 retain one owned tab with independent sessions and fresh navigation',async()=>{
 const b=fakeBrowser();const targetId=await claimStartupTarget(b,ownedStartupUrl(masterId));
 const sessions=[];
 for(const phase of ['pilot','batch','phase2']){
  const p=await attachOwnedPage(b,url,{targetId,intervalMs:0});
  assert.equal(p.targetId,targetId,phase);assert.equal(p.reusedOwnedTarget,true);
  sessions.push(p.sessionId);assert.deepEqual(await detachOwnedPage(p),{detached:true,targetRetained:true});
 }
 assert.equal(new Set(sessions).size,3);assert.equal(b.sessions.size,0);assert.equal(b.targets.length,3);
 assert.equal(b.calls.filter(c=>c.method==='Page.navigate').length,3);
 assert.ok(!b.calls.some(c=>['Target.createTarget','Target.closeTarget','Browser.close'].includes(c.method)));
 assert.ok(b.calls.filter(c=>c.method==='Target.attachToTarget').every(c=>c.params.targetId==='owned'));
 assert.equal(b.targets[1].url,'about:blank');assert.equal(b.targets[2].url,url);
});
test('RC97: ready stale ticket DOM is not accepted until the top-frame loader changes',async()=>{
 const b=fakeBrowser({staleFrames:3});
 await attachOwnedPage(b,url,{targetId:'owned',intervalMs:0});
 assert.equal(b.calls.filter(c=>c.method==='Page.getFrameTree').length,5);
 assert.equal(b.calls.filter(c=>c.method==='Page.navigate').length,1);
});
test('RC97: failed navigation detaches the new session and retains the page for review without a second navigation',async()=>{
 const b=fakeBrowser({navigationError:'net::ERR_CONNECTION_RESET'});
 await assert.rejects(attachOwnedPage(b,url,{targetId:'owned'}),{code:'PAGE_START_NAVIGATION'});
 assert.equal(b.sessions.size,0);assert.equal(b.targets.length,3);
 assert.equal(b.calls.filter(c=>c.method==='Page.navigate').length,1);
 assert.ok(!b.calls.some(c=>['Target.closeTarget','Target.createTarget'].includes(c.method)));
});
test('RC97: absent leased tab does not adopt another page or replay a navigation',async()=>{
 const b=fakeBrowser();b.targets.splice(0,1);
 await assert.rejects(assertOwnedPageTarget(b,'owned'),{code:'BROWSER_OWNED_TARGET_MISSING'});
 await assert.rejects(attachOwnedPage(b,url,{targetId:'owned'}),{code:'BROWSER_OWNED_TARGET_MISSING'});
 assert.ok(b.calls.every(c=>c.method==='Target.getTargets'));
});
test('RC97: startup timeout retains target and never accepts the previous loader or retries navigation',async()=>{
 const b=fakeBrowser({neverFresh:true});
 await assert.rejects(attachOwnedPage(b,url,{targetId:'owned',timeoutMs:0}),{code:'PAGE_START_TIMEOUT'});
 assert.equal(b.calls.filter(c=>c.method==='Page.navigate').length,1);assert.equal(b.sessions.size,0);
 assert.equal(b.targets.length,3);
});
test('RC97: lease binds exact tab, port, owner, phase, package and mapping for both phases',()=>{
 const lease={port:38911,masterId,ownerPid:25812,targetId:'owned'};
 const env=browserLeaseEnvironment(lease);
 const report={schema:'MCR_MASTER_RUN_V1',id:masterId,state:'PHASE1',manifestSha256:'a'.repeat(64),mappingSha256:'b'.repeat(64),browser:{targetId:'owned',port:38911}};
 const claims={parentPid:25812,report,manifestSha:'a'.repeat(64),mappingSha:'b'.repeat(64)};
 assert.deepEqual(validateBrowserLease(env,claims),lease);
 assert.deepEqual(validateBrowserLease(env,{...claims,report:{...report,state:'PHASE2'},phase:'PHASE2'}),lease);
 for(const browser of [{port:38911,targetId:'foreign-blank'},{port:38912,targetId:'owned'},{}])
  assert.throws(()=>validateBrowserLease(env,{...claims,report:{...report,browser}}),{code:'MASTER_BROWSER_TARGET'});
 const partial={...env};delete partial.MCR_MASTER_BROWSER_TARGET_ID;
 assert.throws(()=>validateBrowserLease(partial,claims),{code:'MASTER_BROWSER_PARTIAL'});
 assert.throws(()=>validateBrowserLease(env,{...claims,parentPid:12}),{code:'MASTER_BROWSER_OWNER'});
});
