import test from 'node:test';
import assert from 'node:assert/strict';
import {choosePhase2Candidate} from '../src/phase2-run.mjs';
import {isAoSharedWriteBlock,aoWriteBlockScope} from '../lib/phase2-ao-write-block.mjs';
import {describeTicketIssue,recoveryGroup} from '../lib/ticket-error-catalog.mjs';
const row=(ticketId,request)=>({ticketId,intelGroupVerified:true,descriptionValue:'USC 20/PP+\nStandardantwort versendet\n'+request});
const ao=row('99000001','Möchte Auszahlungsoption'),combined=row('99000002','Möchte Kontoauszug & Auszahlungsoption'),mark=row('99000003','Möchte Rentenberatung'),pp=row('99000004','Möchte Kontoauszug');
const block={ticketId:'99000000',reason:'MASTER_OPENED_READONLY',scope:'CONTACT_ONLY'};
test('RC115 write fault restricts only contact writes; complete AO can still be prepared',()=>{
 const selected=choosePhase2Candidate([ao,combined,mark,pp],{prepareMissingPdf:true,aoWriteBlock:block});
 assert.equal(selected.row.ticketId,ao.ticketId);assert.equal(selected.kind,'ACCOUNT_STATEMENT');
 assert.equal(selected.contactWriteAllowed,false);assert.deepEqual(selected.skipped,[]);
 const next=choosePhase2Candidate([ao,combined,mark,pp],{visited:new Set([ao.ticketId]),prepareMissingPdf:true,aoWriteBlock:block});
 assert.equal(next.row.ticketId,combined.ticketId);assert.equal(next.contactWriteAllowed,false);
 const other=choosePhase2Candidate([ao,combined,mark,pp],{visited:new Set([ao.ticketId,combined.ticketId]),prepareMissingPdf:true,aoWriteBlock:block});
 assert.equal(other.row.ticketId,mark.ticketId);
 const statement=choosePhase2Candidate([pp],{prepareMissingPdf:true,aoWriteBlock:block,accountReady:()=>false});
 assert.equal(statement.row.ticketId,pp.ticketId);assert.equal(statement.pdfPreparationRequired,true);
});
test('RC115 new run restores contact write permission and paused run still reads AO',()=>{
 const selected=choosePhase2Candidate([ao,combined],{prepareMissingPdf:true,aoWriteBlock:block});
 assert.equal(selected.row.ticketId,ao.ticketId);assert.equal(selected.contactWriteAllowed,false);
 assert.equal(choosePhase2Candidate([ao],{prepareMissingPdf:true}).contactWriteAllowed,true);
});
test('RC114 prior PDF journal remains subject to existing recovery gate and never triggers regeneration',()=>{
 const result=choosePhase2Candidate([ao,mark],{prepareMissingPdf:true,aoWriteBlock:block,getPdfJournal:id=>id===ao.ticketId?{state:'UPLOAD_INTENT'}:null,accountReady:()=>false});
 assert.equal(result.row.ticketId,mark.ticketId);assert.equal(result.skipped[0].reason,'PDF_JOURNAL_NOT_RESUMABLE');
 const resume=choosePhase2Candidate([ao],{prepareMissingPdf:true,aoWriteBlock:block,getPdfJournal:()=>({state:'UPLOAD_VERIFIED'}),accountReady:()=>true});
 assert.equal(resume.row.ticketId,ao.ticketId);assert.equal(resume.pdfPreparationRequired,undefined);
});
test('RC114 only shared faults latch the pause; person/field issues are not global',()=>{
 for(const r of ['MASTER_OPENED_READONLY','MASTER_WORKBOOK_WRITE_LOCKED','MASTER_WRITE_PERMISSION_DENIED','MASTER_WRITE_OPEN_FAILED','MASTER_SAVE_IO_RETRY_REQUIRED','AO_CONTACT_SAVE_UNVERIFIED']){
  assert(isAoSharedWriteBlock(r));assert.equal(recoveryGroup(r),'DATENZUGRIFF');assert(!describeTicketIssue({reason:r}).errorCode.startsWith('MCR-P2-U'));
 }
 for(const r of ['AO_MASTER_PERSON_CHANGED','MASTER_CONTACT_UPDATE_FAILED','AO_CONTACT_INPUT_DEFERRED','AO_CONTACT_DATA_REQUIRED','P2_DOCUMENT_GENERATOR_CONTRACT_REQUIRED'])assert.equal(isAoSharedWriteBlock(r),false);
 assert.equal(recoveryGroup('AO_QUEUE_PAUSED_MASTER_WRITE'),'DATENZUGRIFF');
});

test('RC115 ambiguous Save or cleanup keeps wider pause; no new AO selected',()=>{
 assert.equal(aoWriteBlockScope('MASTER_OPENED_READONLY',{operation:'open_contact_write_preflight'}),'CONTACT_ONLY');
 assert.equal(aoWriteBlockScope('MASTER_WRITE_PERMISSION_DENIED',{operation:'open_contact_write'}),'CONTACT_ONLY');
 for(const [reason,operation] of [['MASTER_WRITE_PERMISSION_DENIED','save_contact_data'],['AO_CONTACT_SAVE_UNVERIFIED','readback_contact_data'],['AO_EXCEL_CLOSE_FAILED','save_contact_data'],['MASTER_OPEN_FAILED','read_contact_data']]){
  assert.equal(aoWriteBlockScope(reason,{operation}),'ALL_NEW_AO');
  const selected=choosePhase2Candidate([ao,combined,mark],{prepareMissingPdf:true,aoWriteBlock:{...block,reason,scope:'ALL_NEW_AO'}});
  assert.equal(selected.row.ticketId,mark.ticketId);assert.deepEqual(selected.skipped.map(x=>x.reason),['AO_QUEUE_PAUSED_MASTER_WRITE','AO_QUEUE_PAUSED_MASTER_WRITE']);
 }
});
