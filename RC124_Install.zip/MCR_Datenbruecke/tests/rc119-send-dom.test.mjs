import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {historyMailSnapshots,historyCount} from '../lib/browser-workflow.mjs';
import {verifiedNewOutgoingAcknowledgement} from '../lib/mail-history-audit.mjs';

test('RC119 bound history reader handles a second table body and sortable English columns without a raw row count',async()=>{
 const origin='https://comarch.example.invalid',doc={baseURI:origin+'/tickets/',body:{},defaultView:{getComputedStyle:()=>({visibility:'visible'})}};
 const node=(data={})=>({ownerDocument:doc,isConnected:true,getClientRects:()=>[{}],...data});
 const link=href=>({getAttribute:key=>key==='href'?href:null});
 const makeRow=(out=false)=>{
  const direction=out?'outgoing':'incoming';
  const originalDoc=link('GetFile?cache=0&docId='+(out?'12':'11'));
  const original=node({innerText:'',querySelector:q=>q.includes('a[href')?originalDoc:q.includes('email_'+direction)?{}:null,
   querySelectorAll:q=>q.includes('GetFile')?[originalDoc]:[]});
  const contact=node({innerText:'Jane Doe',querySelectorAll:()=>[link('mailto:jane@example.invalid')]});
  const otherCell=v=>node({innerText:v,querySelectorAll:()=>[]});
  return node({cells:[original,out?otherCell('support@example.invalid'):contact,out?contact:otherCell('support@example.invalid'),
   otherCell(out?'Re: [MERCER#99990001] Request':'Request'),otherCell(out?'This email is to confirm that we have received your ticket and our team is currently working on it.':'Please check.'),otherCell(out?'Now':'Today')]});
 };
 const table=node({tHead:{rows:[{cells:[{textContent:'Messages'}]},{cells:['Original','From ▼','To','Subject','Content','Date'].map(textContent=>({textContent}))}]},
  tBodies:[{rows:[makeRow()]}]});
 doc.querySelectorAll=q=>q==='table'?[table]:[];
 const ctx=vm.createContext({URL,location:{origin},document:doc});
 const page={call:async f=>vm.runInContext('('+f.toString()+')()',ctx)};
 const before=await historyMailSnapshots(page);
 assert.equal(before.rows[0].documentId,'11');assert.equal(before.complete,true);
 table.tBodies.push({rows:[makeRow(true)]});
 assert.equal(await historyCount(page),null);
 const post=await historyMailSnapshots(page);
 const verify=snap=>verifiedNewOutgoingAcknowledgement(before,snap,'99990001','jane@example.invalid');
 assert.equal(post.rows.length,2);assert.equal(post.rows[0].documentId,'12');assert.equal(verify(post).verified,true);
 table.tBodies[1].rows[0].cells[2].innerText='someone@example.invalid';
 assert.equal(verify(await historyMailSnapshots(page)).verified,false);
 table.tBodies[1].rows[0].cells[2].innerText='Jane Doe';
 table.tBodies[1].rows.push(node({cells:Array.from({length:6},()=>node({querySelector:()=>null}))}));
 const incomplete=await historyMailSnapshots(page);
 assert.equal(incomplete.complete,false);assert.equal(verify(incomplete).verified,false);
});
