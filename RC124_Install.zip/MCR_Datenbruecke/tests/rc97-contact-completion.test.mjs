import test from 'node:test';
import assert from 'node:assert/strict';
import {persistWorkbookContactAfterCompletion} from '../lib/workbook-contact-completion.mjs';

test('RC97 contact completion: incomplete mail/save proof never attempts workbook write',async()=>{
 for(const [sendVerified,saveVerified] of [[false,true],[true,false],[false,false],[undefined,true],[true,'true']]){
  const result=await persistWorkbookContactAfterCompletion({sendVerified,saveVerified,record:async()=>assert.fail('No contact write before complete')});
  assert.equal(result.status,'CONTACT_NOT_ATTEMPTED');
 }
});
test('RC97 contact completion: one completed ticket invokes contact write once with bound arguments',async()=>{
 const args={ticketId:'99990001',member:{id:'11999991'}},result={status:'CONTACT_WRITTEN'};let calls=0;
 assert.equal(await persistWorkbookContactAfterCompletion({sendVerified:true,saveVerified:true,args,record:async actual=>{calls++;assert.equal(actual,args);return result;}}),result);
 assert.equal(calls,1);
});
test('RC97 contact completion: locked workbook keeps completed ticket and exposes pending result unchanged',async()=>{
 const pending={status:'CONTACT_PENDING',reason:'WORKBOOK_LOCKED'};let calls=0;
 assert.equal(await persistWorkbookContactAfterCompletion({sendVerified:true,saveVerified:true,record:async()=>{calls++;return pending;}}),pending);
 assert.equal(calls,1);
});
test('RC97 contact completion: even a failed local pending queue cannot retry or reject completed work',async()=>{
 let calls=0,warnings=0;const logs=[];
 const result=await persistWorkbookContactAfterCompletion({sendVerified:true,saveVerified:true,record:async()=>{calls++;throw Object.assign(new Error('Private path and email must not leak'),{code:'EACCES'});},onWarning:()=>warnings++,log:x=>logs.push(x)});
 assert.equal(calls,1);assert.equal(warnings,1);assert.equal(result.status,'CONTACT_WRITE_WARNING');assert.equal(result.ticketCompleted,true);assert.equal(result.resendAllowed,false);
 assert.equal(result.reason,'EACCES');assert(!logs.join('\n').includes('Private path'));assert(!logs.join('\n').includes('pending'));
});
test('RC97 contact completion: faulty warning hooks cannot unwind completed ticket and arbitrary errors are redacted',async()=>{
 const result=await persistWorkbookContactAfterCompletion({sendVerified:true,saveVerified:true,record:async()=>{throw Object.assign(new Error('broken'),{code:'private@example.invalid'});},onWarning:()=>{throw Error('counter');},log:()=>{throw Error('logger');}});
 assert.equal(result.reason,'CONTACT_WRITE_FAILED');assert.equal(result.resendAllowed,false);
});
