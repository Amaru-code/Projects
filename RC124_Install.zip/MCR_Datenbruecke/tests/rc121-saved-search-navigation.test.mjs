import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {inspectIntelNavigation} from '../lib/intel-worklist-navigation.mjs';

const scope='IN_BEARBEITUNG';
const group='storedSearchesContainer_MY_TASKS';
const tableId='mainForm:tasksTableFor_MyTasksList';

function element(tag,attrs={},children=[]){
 const node={
  nodeType:1,tagName:tag.toUpperCase(),id:attrs.id,title:attrs.title,
  isConnected:true,shown:true,weight:'400',parentElement:null,
  classList:{contains:value=>(attrs.class||'').split(' ').includes(value)},
  getAttribute:key=>attrs[key]??null,hasAttribute:key=>Object.hasOwn(attrs,key),
  childNodes:children.map(v=>typeof v==='string'?{nodeType:3,nodeValue:v}:v),
  get textContent(){return this.childNodes.map(n=>n.nodeType===3?n.nodeValue:n.textContent).join('');},
  getClientRects(){return this.shown?[{left:1,right:2,top:1,bottom:2}]:[];},
  contains(n){return n===this||this.childNodes.some(c=>c.nodeType===1&&c.contains(n));},
  matches(){return this.classList.contains('badge');},
  closest(selector){
   if(!selector.startsWith('a,button,'))return null;
   return (['A','BUTTON'].includes(this.tagName)||(selector.includes('[onclick]')&&this.hasAttribute('onclick')))?this:this.parentElement?.closest(selector);
  }
 };
 for(const n of node.childNodes)n.parentElement=node;
 return node;
}

function fixture({menuId=group,children=[],marked=[],caption,tableName,labelIds,headers={},disclosures=[]}={}){
 const folder=element('div',{id:menuId},children);
 const descendants=nodes=>nodes.flatMap(n=>n.nodeType!==1?[]:[n,...descendants(n.childNodes)]);
 folder.querySelectorAll=s=>s.startsWith('[aria-selected')?marked:descendants(children);
 const table=element('table',{'aria-label':tableName,'aria-labelledby':labelIds,id:tableId});
 if(caption)table.caption=element('caption',{},[caption]);
 const document={querySelectorAll(s){
  if(s==='[id="'+group+'"]')return menuId===group?[folder]:[];
  if(s==='[id$=":'+group+'"]')return menuId.endsWith(':'+group)?[folder]:[];
  if(s==='[id="'+tableId+'"]')return [table];
  if(s.startsWith('#'))return headers[s.slice(1)]||[];
  return s.startsWith('[aria-controls]')?disclosures:[];
 }};
 const ctx=vm.createContext({document,CSS:{escape:id=>id},getComputedStyle:n=>({display:'block',visibility:'visible',fontWeight:n.weight})});
 return vm.runInContext('('+inspectIntelNavigation.toString()+')('+JSON.stringify(scope)+',true,false)',ctx);
}

test('RC121 a directly identified current worklist is bound even without its menu child',()=>{
 const current=fixture({caption:'In Bearbeitung (11)'});
 assert.equal(current.state,'CURRENT_VIEW');assert.equal(current.evidence,'TABLE_VIEW_LABEL');
 assert.equal(current.active,true);assert.equal(current.point,null);
 const heading=element('h2',{},['In_Bearbeitung']);
 const groupHeading=element('h1',{},['Meine Vorgänge']);
 assert.equal(fixture({tableName:'Meine Vorgänge',labelIds:'g h',headers:{g:[groupHeading],h:[heading]}}).active,true);
 assert.equal(fixture({tableName:'Meine Vorgänge'}).active,false);
 assert.equal(fixture().state,'CHILD_NOT_VISIBLE');
});

test('RC121 competing labels, duplicate referenced heading, foreign active search and shared table alone never establish this scope',()=>{
 const bold=element('a',{},['In Bearbeitung']);bold.weight='700';
 const other=element('a',{'aria-selected':'true'},['Anderer Mandant']);
 for(const opts of [
  {caption:'Team West',children:[bold]},
  {caption:'In Bearbeitung',tableName:'Team West',children:[bold]},
  {caption:'In Bearbeitung',labelIds:'h',headers:{h:[element('h2'),element('h2')]}},
  {caption:'In Bearbeitung',children:[other],marked:[other]},
  {children:[bold,other],marked:[other]},
  {caption:'In Bearbeitung',children:[element('a',{'aria-selected':'false'},['In Bearbeitung'])]}
 ]){
  const state=fixture(opts);assert.equal(state.active,false);assert.equal(state.conflict,true);
 }
 assert.equal(fixture({caption:'Offene Vorgänge'}).active,false);
});

test('RC121 JSF-qualified stored searches accept a labelled option with an icon and numeric badge',()=>{
 const label=element('span',{},['In Bearbeitung']);
 const icon=element('span',{'aria-hidden':'true'},['▸']);
 const badge=element('span',{class:'badge'},['12']);
 const item=element('a',{'aria-current':'page'},[icon,label,badge]);
 const state=fixture({menuId:'mainForm:'+group,children:[item],marked:[item]});
 assert.equal(state.state,'CHILD');assert.equal(state.active,true);assert.equal(state.evidence,'MENU_SELECTED');
 for(const title of ['In Bearbeitung West','In_Bearbeitung2','In Bearbeitung (Team West)']){
  assert.equal(fixture({children:[element('a',{'aria-label':'In_Bearbeitung'},[title])]}).state,'CHILD_NOT_VISIBLE');
 }
 const foreign=element('a',{},[element('span',{onclick:'filter()'},['In Bearbeitung']),element('span',{'aria-hidden':'true'},[' West'])]);
 assert.equal(fixture({children:[foreign]}).state,'CHILD_NOT_VISIBLE');
});

test('RC121 a namespaced collapsed group is expanded only through its own disclosure',()=>{
 const id='mainForm:'+group;
 const button=owner=>Object.assign(element('button',{'aria-controls':owner,'aria-expanded':'false'}),{type:'button'});
 assert.equal(fixture({menuId:id,disclosures:[button('other'),button(id)]}).state,'DISCLOSURE');
 const genericLink=element('a',{'aria-controls':id,'aria-expanded':'false',href:'#other'});
 assert.equal(fixture({menuId:id,disclosures:[genericLink,button(group)]}).state,'CHILD_NOT_VISIBLE');
 const collapse=target=>Object.assign(element('button',{'data-bs-toggle':'collapse','data-bs-target':target,'aria-expanded':'false'}),{type:'button'});
 assert.equal(fixture({menuId:id,disclosures:[collapse('#'+id)]}).state,'DISCLOSURE');
 assert.equal(fixture({menuId:id,disclosures:[collapse('#other'),collapse('#'+id+',#other')]}).state,'CHILD_NOT_VISIBLE');
});

test('RC121 common bold menu styling cannot select a stored search; distinct emphasis or explicit selection can',()=>{
 const bold=element('a',{},['In Bearbeitung']);bold.weight='700';
 const sibling=element('a',{},['Team West']);sibling.weight='700';
 assert.equal(fixture({children:[bold,sibling]}).active,false);
 sibling.weight='400';assert.equal(fixture({children:[bold,sibling]}).active,true);
 assert.equal(fixture({children:[bold]}).active,false);
 bold.style={fontWeight:'bold'};assert.equal(fixture({children:[bold]}).active,true);
});
