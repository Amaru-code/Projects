import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {refreshLiveWorkbook,readLiveWorkbook,assertLiveWorkbookCurrent,workbookPath,DEFAULT_WORKBOOK_PATH,BUSINESS_COLUMNS} from '../lib/live-workbook.mjs';
import {readWorkbookBuffer} from '../lib/xlsx-multirow.mjs';
import {lookupMultirow} from '../lib/multirow-tpp-mapping.mjs';
import {readZip,writeZip} from '../lib/zip.mjs';
import {sha256} from '../lib/core.mjs';
import {putActive} from './helpers.mjs';
import {fixture,row,header,cells} from './rc97-workbook-fixture.mjs';

function environment(bytes=fixture()){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'mcr97-live-source-'));
 const file=path.join(root,'current.xlsx'),config=path.join(root,'config/local-runner-queue-send.json');
 fs.mkdirSync(path.dirname(config));fs.writeFileSync(file,bytes);
 const configure=value=>fs.writeFileSync(config,JSON.stringify({stockWorkbookPath:value}));configure(file);
 return {root,file,config,configure,close:()=>fs.rmSync(root,{recursive:true,force:true})};
}
const replacePart=(bytes,name,transform)=>{const z=readZip(bytes);return writeZip(z.names.map(n=>({name:n,data:n===name?transform(z.get(n).toString('utf8')):z.get(n)})));};

test('RC97 live source: extended reader exposes every authorized source column and preserves multirow/PensIntel',()=>{
 const input=fixture({values:{...row,E:'1',H:'1',FM:'one@example.invalid',FN:'EN'}});
 const book=readWorkbookBuffer(input,'source.xlsx',{extended:true});
 assert.deepEqual(Object.keys(book.meta.headers),BUSINESS_COLUMNS);
 assert.equal(book.allRows()[0].FM,'one@example.invalid');assert.equal(book.allRows()[0].FN,'EN');
 const env=environment(input);
 try{
  const map=refreshLiveWorkbook(env.root).map,e=lookupMultirow(map,'99900001');
  assert.deepEqual(e.sourceRows,[2,3]);
  assert.deepEqual(e.descriptionLines,['USC 10/ DC;DB+;TPP;JUB;UEB;ZW','USC 20/ DC;TPP;JUB;ZW']);
  assert.equal(e.records[0].pensIntel,1);assert.equal(e.records[0].dbPlus,1);
  assert.equal(map.payload.source.liveWorkbook.path,env.file);
 }finally{env.close();}
});

test('RC97 live source: every WWID, plan, USC and gender column independently invalidates business digest',()=>{
 const env=environment();
 try{
  const first=readLiveWorkbook(env.file),changes={B:'99900009',C:'0',D:'1',E:'1',F:'0',G:'0',H:'1',I:'0',L:'11',O:'F'};
  for(const [column,value] of Object.entries(changes)){
   fs.writeFileSync(env.file,fixture({values:{...row,[column]:value}}));
   assert.notEqual(readLiveWorkbook(env.file).businessSha256,first.businessSha256,column);
  }
 }finally{env.close();}
});

test('RC97 live source: contact content/formulas and unrelated workbook parts cannot invalidate pilot business binding',()=>{
 const env=environment();
 try{
  const active=refreshLiveWorkbook(env.root),first=readLiveWorkbook(env.file);
  const contacts=fixture({extraCells:'<c r="FM2" t="str"><f>CONTACT()</f></c><c r="FN2" t="inlineStr"><is><t>EN</t></is></c>'});
  const changed=replacePart(contacts,'xl/worksheets/sheet2.xml',s=>s.replace('<f>1+2</f><v>3</v>','<f>3+4</f><v>7</v>'));
  fs.writeFileSync(env.file,changed);
  const next=readLiveWorkbook(env.file);
  assert.notEqual(next.hash,first.hash);assert.equal(next.businessSha256,first.businessSha256);
  assert.equal(next.rows[0].errors.FM,'Formel ohne gespeichertes Ergebnis');
  assert.equal(next.mappingBook.allRows()[0].errors.FM,undefined);
  assert.equal(assertLiveWorkbookCurrent(env.root,active).businessSha256,first.businessSha256);
  const same=refreshLiveWorkbook(env.root);assert.equal(same.path,active.path);assert.equal(same.fileHash,active.fileHash);
 }finally{env.close();}
});

test('RC97 live source: business formula provenance is detected even when its cached numeric value is unchanged',()=>{
 const original={...row};delete original.G;
 const env=environment(fixture({values:original,extraCells:'<c r="G2"><f>1+0</f><v>1</v></c>'}));
 try{
  const first=readLiveWorkbook(env.file);
  // A formula disappearing from a business cell changes its provenance.
  fs.writeFileSync(env.file,fixture());
  assert.notEqual(readLiveWorkbook(env.file).businessSha256,first.businessSha256);
 }finally{env.close();}
});

test('RC97 live source: current XLSX replaces a stale valid JSON snapshot and archives its pointer',()=>{
 const env=environment();
 try{
  const legacy=putActive(env.root),oldFile=path.join(env.root,'private_data',legacy.name),oldBytes=fs.readFileSync(oldFile);
  const pointer=path.join(env.root,'private_data/active-mapping.json'),before=fs.readFileSync(pointer);
  const active=refreshLiveWorkbook(env.root);
  assert.notEqual(active.path,oldFile);
  assert.equal(lookupMultirow(active.map,'99900001').descriptionLines[0],'USC 10/ DC;TPP;JUB;ZW');
  const archives=fs.readdirSync(path.join(env.root,'private_data/mapping_archive'));
  assert.equal(archives.length,1);
  assert.ok(fs.readFileSync(path.join(env.root,'private_data/mapping_archive',archives[0])).equals(before));
  assert.ok(fs.readFileSync(oldFile).equals(oldBytes));
  assert.equal(JSON.parse(fs.readFileSync(pointer)).sourceSha256,sha256(fs.readFileSync(env.file)));
 }finally{env.close();}
});

test('RC97 live source: an unavailable network workbook never falls back to valid old JSON',()=>{
 const env=environment();
 try{
  putActive(env.root);const pointer=path.join(env.root,'private_data/active-mapping.json'),before=fs.readFileSync(pointer);
  fs.unlinkSync(env.file);
  assert.throws(()=>refreshLiveWorkbook(env.root),{code:'WORKBOOK_UNAVAILABLE'});
  assert.ok(fs.readFileSync(pointer).equals(before));
 }finally{env.close();}
});

test('RC97 live source: missing pointer is recreated from XLSX without modifying prior snapshot or source bytes',()=>{
 const env=environment();
 try{
  const source=fs.readFileSync(env.file),mtime=fs.statSync(env.file).mtimeMs,first=refreshLiveWorkbook(env.root),old=fs.readFileSync(first.path);
  fs.unlinkSync(first.pointerPath);
  const restored=refreshLiveWorkbook(env.root);
  assert.equal(restored.pointerPath,first.pointerPath);assert.ok(fs.existsSync(restored.pointerPath));
  assert.notEqual(restored.path,first.path);assert.ok(fs.readFileSync(first.path).equals(old));
  assert.ok(fs.readFileSync(env.file).equals(source));assert.equal(fs.statSync(env.file).mtimeMs,mtime);
  assert.equal(restored.map.payload.source.liveWorkbook.businessSha256,first.map.payload.source.liveWorkbook.businessSha256);
 }finally{env.close();}
});

test('RC97 live source: source path switch is a distinct binding error even for identical workbook bytes',()=>{
 const env=environment();
 try{
  const active=refreshLiveWorkbook(env.root),other=path.join(env.root,'other.xlsx');fs.copyFileSync(env.file,other);env.configure(other);
  assert.throws(()=>assertLiveWorkbookCurrent(env.root,active),{code:'WORKBOOK_SOURCE_CHANGED'});
 }finally{env.close();}
});

test('RC97 live source: invalid headers/no usable rows preserve the active pointer and all source bytes',()=>{
 const env=environment();
 try{
  const first=refreshLiveWorkbook(env.root),pointer=fs.readFileSync(first.pointerPath);
  for(const [bytes,code] of [
   [fixture({headers:{...header,H:'Different'}}),'HEADER_H'],
   [fixture({values:{...row,C:'0',D:'0',E:'0',F:'0',G:'0',H:'0',I:'0'},rows:''}),'WORKBOOK_NO_VALID_ROWS'],
   [replacePart(fixture(),'xl/workbook.xml',s=>s.replace('name="Output"','name="Wrong"')),'SHEET']
  ]){
   fs.writeFileSync(env.file,bytes);
   assert.throws(()=>refreshLiveWorkbook(env.root),{code});
   assert.ok(fs.readFileSync(first.pointerPath).equals(pointer));assert.ok(fs.readFileSync(env.file).equals(bytes));
  }
 }finally{env.close();}
});

test('RC97 live source: strict absolute XLSX path and empty-file errors identify configuration/source failure',()=>{
 const env=environment();
 try{
  for(const value of ['relative.xlsx','C:relative.xlsx','https://example.invalid/file.xlsx',path.join(env.root,'file.xlsm'),'/tmp/line\nbreak.xlsx']){
   env.configure(value);assert.throws(()=>workbookPath(env.root),{code:'WORKBOOK_PATH'});
  }
  env.configure(env.file);fs.writeFileSync(env.file,'');assert.throws(()=>readLiveWorkbook(env.file),{code:'WORKBOOK_SIZE'});
  fs.writeFileSync(env.config,'{}');assert.equal(workbookPath(env.root),DEFAULT_WORKBOOK_PATH);
  assert.equal(DEFAULT_WORKBOOK_PATH,String.raw`K:\INTL01\6_AU (Admin)\~ Data\~ Bestand Intel Gesamtübersicht\INTL01_Gesamtdatenbestand_30.09.2025.xlsx`);
 }finally{env.close();}
});

test('RC97 live source: legacy ClientEEID/IsEligible header spellings remain supported in extended mode',()=>{
 const bytes=fixture({headers:{...header,B:'ClientEEID',G:'IsEligible_JUB',H:'IsEligible_UEB',I:'IsEligible_ZW'},
  rows:`<row r="4">${cells({...row,B:'99900002',L:'30'},4)}</row>`});
 const book=readWorkbookBuffer(bytes,'legacy.xlsx',{extended:true});assert.equal(book.meta.dataRows,2);
 assert.deepEqual(book.allRows().map(r=>r.row),[2,4]);
});
