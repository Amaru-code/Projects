// Order and captions follow the two historical COMARCH views.
// Element names and attributes are reconstructed. All example IDs are fictitious.
export async function installActivePage(page,{queue=false,variant='genuine'}={}){
 await page.call(({queue,variant})=>{
  const own=!queue,heading=own?'Meine Vorgänge':'Warteschlange',filter=own?'In_Bearbeitung':'INTL01';
  const id=own?'99023041':'99023042';
  const nav='<nav><div id="storedSearchesContainer_MY_TASKS"><span>Archiv</span></div><div id="storedSearchesContainer_MY_QUEUES"><span>Sonstige</span></div></nav>';
  const named=variant==='similar'?filter+' Archiv':filter;
  const caption=variant==='wrongFamily'?(own?'Warteschlange':'Meine Vorgänge'):heading;
  const header='<div><strong>'+caption+'</strong></div>';
  const filterRow='<div><img width="14" height="14" alt="" title="Gespeicherte Suche"><span>'+named+'</span><a title="Favorit"><img width="10" height="10" alt=""></a><a title="Löschen"><img width="10" height="10" alt=""></a><a title="Einstellungen"><img width="10" height="10" alt=""></a></div>';
  const markedFilter=variant==='composedSuffix'?filterRow.replace('<span>'+named+'</span>','<span>'+named+'</span><span> West</span>'):filterRow;
  const criteria='<div>Suchkriterien</div>';
  const table='<table id="mainForm:tasksTableFor_'+(own?'MyTasksList':'MyQueuesTasksList')+'"><thead><tr><th>Ticket-ID</th><th>Group Employer Code</th><th>Group Name</th><th>Quelle</th><th>Zusätzliche Beschreibung</th></tr></thead><tbody><tr><td><button id="ticket">'+id+'</button></td><td>INTL01</td><td>Intel Deutschland GmbH</td><td>E-MAIL</td><td></td></tr></tbody></table>';
  document.body.innerHTML=nav+'<form id="mainForm"><section id="side"></section><main id="pane"></main></form>';
  const pane=document.getElementById('pane');
  pane.innerHTML=header+(variant==='otherPane'||variant==='rowText'?'':markedFilter)+(variant==='duplicate'?filterRow:'')+criteria+table;
  if(variant==='foreignRow'){pane.querySelector('tbody tr').cells[1].textContent='ZZ9999';pane.querySelector('tbody tr').cells[2].textContent='Andere GmbH';}
  if(variant==='otherPane')document.getElementById('side').innerHTML=filterRow;
  if(variant==='rowText')pane.querySelector('tbody td:last-child').innerHTML=filterRow;
  if(variant==='wrongOrder')pane.append(pane.children[1]);
  if(variant==='competing')pane.querySelector('table').insertAdjacentHTML('beforebegin','<div><img alt="" title="Gespeicherte Suche"><span>Archiv</span></div><div>Suchkriterien</div>');
  window.fixtureEvents=[];
  document.getElementById('ticket').onclick=()=>{
   window.fixtureEvents.push(id);pane.innerHTML='<h2>Ticket-ID: '+id+'</h2>';
  };
 },{queue,variant});
}
export async function checkActiveHeadings(page,current,assert){
 for(const queue of [false,true]){
  const scope=queue?'WARTESCHLANGE_INTL01':'IN_BEARBEITUNG';
  await installActivePage(page,{queue});
  for(const variant of ['similar','composedSuffix','wrongFamily','otherPane','rowText','wrongOrder','duplicate','competing']){
   await installActivePage(page,{queue,variant});
   assert.equal(await current.activeIntelScope(page,scope),false,scope+' '+variant);
  }
  await installActivePage(page,{queue,variant:'foreignRow'});
  assert.equal(await current.activeIntelScope(page,scope),false,'conflicting visible client code');
  await assert.rejects(()=>current.navigateToScope(page,scope,{quick:true}),{code:'INTL_SCOPE_NOT_AVAILABLE'});
  assert.deepEqual(await page.call(()=>window.fixtureEvents),[]);
  await installActivePage(page,{queue});
  const s=await current.navigateToScope(page,scope,{quick:true});
  const id=queue?'99023042':'99023041';
  assert.equal(s.rows.length,1);assert.equal(s.rows[0].ticketId,id);
  assert.deepEqual(await page.call(()=>window.fixtureEvents),[]);
  assert.equal((await current.openTicket(page,s.rows[0],{scope})).mode,'AUTO');
  assert.equal(await current.detailTicketId(page),id);
 }
 return 'Both reconstructed main pane headings independently bind their table, exact ticket opened in each case; misleading heading layouts and contradictory visible row tenant refused for each family.';
}
