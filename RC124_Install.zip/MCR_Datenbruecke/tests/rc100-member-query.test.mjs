import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {setInputQuery,typeTrustedFixedQuery} from '../lib/browser-workflow.mjs';

const memberId='mainForm:member-value-id',ticketId='89827030',query='Beispiel Erika';
function harness({value='',focused=true,onSend=null,onRead=null,onWait=null,onSynthetic=null,onClick=null}={}){
 const calls={native:[],synthetic:[],mouse:0,reads:0,waits:0,ticketChecks:0,compat:0,logs:[]};
 const fields=[];let ticket=ticketId,selectionAll=false;
 const label={isConnected:true,closest:()=>null,get textContent(){return 'Ticket-ID: '+ticket;},getClientRects:()=>[{}]};
 const doc={activeElement:null,querySelectorAll:selector=>{
  if(selector==='input')return fields;
  if(selector.split(',').includes('label')&&selector.split(',').includes('h1')){calls.ticketChecks++;return [label];}
  return [];
 },getElementById:id=>fields.find(x=>x.id===id),elementFromPoint:()=>fields[0]};
 class Input{
  constructor(text){Object.assign(this,{id:memberId,tagName:'INPUT',_value:text,isConnected:true,disabled:false,readOnly:false,ownerDocument:doc});}
  get value(){return this._value;}
  set value(x){this._value=String(x);}
  getClientRects(){return [{left:20,top:30,right:320,bottom:60}];}
  scrollIntoView(){}
  dispatchEvent(event){calls.synthetic.push({type:event.type,key:event.key,value:this.value});onSynthetic?.(api,event,this);return true;}
 }
 class Event{constructor(type,options={}){this.type=type;Object.assign(this,options);}}
 const win={getComputedStyle:()=>({display:'block',visibility:'visible'}),innerWidth:1200,innerHeight:900,HTMLInputElement:Input,Event,KeyboardEvent:Event};
 doc.defaultView=win;fields.push(new Input(value));if(focused)doc.activeElement=fields[0];
 const context=vm.createContext({document:doc,getComputedStyle:win.getComputedStyle,setTimeout:fn=>{fn();return 1;}});
 const api={calls,fields,doc,replace(text=fields[0].value,{focus=false}={}){
  fields[0].isConnected=false;fields[0]=new Input(text);selectionAll=false;doc.activeElement=focus?fields[0]:null;return fields[0];
 },setTicket:value=>{ticket=value;},newInput:text=>new Input(text)};
 api.page={sessionId:'bound-session',call:async(fn,...args)=>{
  if(fn.name==='inputState'){calls.reads++;onRead?.(api);}
  if(fn.name==='memberCompatibilityQuery')calls.compat++;
  context.args=args;return vm.runInContext('('+fn.toString()+')(...args)',context);
 },mouseClick:async()=>{calls.mouse++;doc.activeElement=fields[0];onClick?.(api);},cdp:{send:async(method,p)=>{
  calls.native.push({method,...p,ticketChecks:calls.ticketChecks});
  if(method==='Input.dispatchKeyEvent'&&p.type==='rawKeyDown'&&p.key==='a'&&p.modifiers===2)selectionAll=true;
  if(method==='Input.dispatchKeyEvent'&&p.type==='rawKeyDown'&&p.key==='Backspace'){
   fields[0]._value=selectionAll?'':Array.from(fields[0]._value).slice(0,-1).join('');selectionAll=false;
  }
  if(method==='Input.insertText'){
   fields[0]._value=selectionAll?p.text:fields[0]._value+p.text;selectionAll=false;
  }
  if(method==='Input.dispatchKeyEvent'&&p.type==='char'){
   fields[0]._value=selectionAll?p.text:fields[0]._value+p.text;selectionAll=false;
  }
  await onSend?.(api,method,p);
 }}};
 api.options={ticketId,wait:async()=>{calls.waits++;await onWait?.(api);},log:x=>calls.logs.push(x)};
 api.run=(text=query,extra={})=>setInputQuery(api.page,memberId,text,{...api.options,...extra});
 return api;
}
const insertions=h=>h.calls.native.filter(x=>x.method==='Input.insertText');
const finalKey=p=>p.type==='keyUp'&&p.key==='a'&&!p.modifiers;
const reviewProof=(error,attempts,reason)=>{
 assert.equal(error.code,'MEMBER_QUERY_REVIEW_REQUIRED');
 assert.deepEqual(error.memberQueryRecovery,{schema:'MCR_MEMBER_QUERY_RECOVERY_V1',ticketId,queryOnly:true,attempts,reason});
 return true;
};

test('RC100 Member: exact readback survives focus loss after final keyup',async()=>{
 const h=harness({onSend:(h,m,p)=>{if(finalKey(p)&&h.fields[0].value===query)h.doc.activeElement=null;}});
 assert.equal(await h.run(),true);assert.equal(h.fields[0].value,query);
 assert.equal(insertions(h).length,1);assert.equal(h.calls.compat,0);assert.equal(h.calls.mouse,0);
});

test('RC100 Member: replacement of the populated node is read back from the current input',async()=>{
 const h=harness({onSend:(h,m,p)=>{if(finalKey(p)&&h.fields[0].value===query)h.replace(query);}});
 assert.equal(await h.run(),true);assert.equal(h.fields[0].value,query);
 assert.equal(insertions(h).length,1);assert.equal(h.calls.compat,0);
});

test('RC100 Member: one discarded final character is repaired by whole native text insertion',async()=>{
 let discarded=false;
 const h=harness({onSend:(h,m,p)=>{if(!discarded&&finalKey(p)&&h.fields[0].value===query){discarded=true;h.replace(query.slice(0,-1));}}});
 assert.equal(await h.run(),true);assert.equal(h.fields[0].value,query);
 assert.deepEqual(insertions(h).map(x=>x.text),[query.slice(0,-1),query]);
 assert.equal(h.calls.compat,0);assert.ok(h.calls.logs.some(x=>x.includes('FULL_NATIVE')));
 assert.ok(h.calls.logs.some(x=>x.startsWith('PASS MEMBER_QUERY_RECOVERED')));
});

test('RC100 Member: first native attempt emptied by ICEfaces is retried over only its own empty input',async()=>{
 let cleared=false;
 const h=harness({onSend:(h,m,p)=>{if(!cleared&&finalKey(p)&&h.fields[0].value===query){cleared=true;h.fields[0].value='';}}});
 assert.equal(await h.run(),true);assert.deepEqual(insertions(h).map(x=>x.text),[query.slice(0,-1),query]);
});

test('RC100 Member: lost Ctrl+A on a replacement cannot append a full query to a prefix',async()=>{
 let controls=0,reset=false;
 const h=harness({onSend:(h,m,p)=>{
  if(finalKey(p)&&!reset&&h.fields[0].value===query){reset=true;h.fields[0].value=query.slice(0,-1);}
  if(p.type==='keyUp'&&p.key==='Control'&&++controls===2)h.replace(h.fields[0].value,{focus:true});
 }});
 assert.equal(await h.run(),true);assert.equal(h.fields[0].value,query);
 // The failed clear is not followed by an insert; compatibility writes once.
 assert.deepEqual(insertions(h).map(x=>x.text),[query.slice(0,-1)]);
 assert.equal(h.calls.compat,1);
});

test('RC100 Member: committed Member or changed query appearing during focus is not overwritten',async()=>{
 for(const changed of ['INTL01-11999991 | Beispiel Erika','Different query']){
  const h=harness({focused:false,onClick:h=>{h.fields[0].value=changed;}});
  await assert.rejects(h.run(),e=>e.code==='MEMBER_QUERY_REVIEW_REQUIRED');
  assert.equal(h.calls.native.length,0);assert.equal(h.calls.compat,0);assert.equal(h.fields[0].value,changed);
 }
});

test('RC100 Member: an initially committed INTL01 display is preserved without keyboard events',async()=>{
 const committed='INTL01-11999991 | Beispiel Erika',h=harness({value:committed});
 await assert.rejects(h.run(),e=>reviewProof(e,1,'MEMBER_QUERY_VALUE_CHANGED'));
 assert.equal(h.fields[0].value,committed);assert.equal(h.calls.native.length,0);assert.equal(h.calls.compat,0);
});

test('RC100 Member: explicit bound new search may replace exactly the captured unsuitable Member display',async()=>{
 const h=harness({value:'INTL01-11999991 | Other Person',focused:false});
 assert.equal(await h.run(query,{replaceCommittedForNewSearch:true}),true);
 assert.equal(h.fields[0].value,query);assert.equal(insertions(h).length,1);
 assert.equal(h.calls.compat,0);assert.equal(h.calls.synthetic.length,0);
 assert.equal(h.calls.mouse,1);assert.ok(h.calls.ticketChecks>2);
});

test('RC100 Member: explicit new search still rejects a changed committed or foreign value after focus',async()=>{
 for(const changed of ['INTL01-11999992 | Different Member','Unrelated query']){
  const h=harness({value:'INTL01-11999991 | Other Person',focused:false,onClick:h=>{h.fields[0].value=changed;}});
  await assert.rejects(h.run(query,{replaceCommittedForNewSearch:true}),e=>reviewProof(e,1,'MEMBER_QUERY_VALUE_CHANGED'));
  assert.equal(h.fields[0].value,changed);assert.equal(h.calls.native.length,0);assert.equal(h.calls.compat,0);
 }
});

test('RC100 Member: unbound replacement flag cannot overwrite a committed Member',async()=>{
 const committed='INTL01-11999991 | Other Person',h=harness({value:committed});
 await assert.rejects(h.run(query,{ticketId:null,replaceCommittedForNewSearch:true}),e=>e.code==='MEMBER_QUERY_VALUE_CHANGED'&&e.memberQueryRecovery===undefined);
 assert.equal(h.fields[0].value,committed);assert.equal(h.calls.native.length,0);assert.equal(h.calls.compat,0);
});

test('RC100 Member: initial replacement authority cannot overwrite a committed Member during a retry',async()=>{
 const committed='INTL01-11999991 | Other Person';let controls=0;
 const h=harness({value:committed,onSend:(h,m,p)=>{
  if(finalKey(p)&&controls===1)h.fields[0].value=query.slice(0,-1);
  if(p.type==='keyUp'&&p.key==='Control'&&++controls===2)h.fields[0].value=committed;
 }});
 await assert.rejects(h.run(query,{replaceCommittedForNewSearch:true}),e=>reviewProof(e,2,'MEMBER_QUERY_VALUE_CHANGED'));
 assert.equal(h.fields[0].value,committed);assert.equal(insertions(h).length,1);assert.equal(h.calls.compat,0);
 assert.ok(!h.calls.native.some(x=>x.key==='Backspace'));
});

test('RC100 Member: two lost native queries reach the restricted RC96 search compatibility path once',async()=>{
 const h=harness({onSend:(h,m,p)=>{if(finalKey(p))h.fields[0].value='';}});
 assert.equal(await h.run(),true);assert.equal(h.fields[0].value,query);
 assert.equal(insertions(h).length,2);assert.equal(h.calls.compat,1);
 assert.deepEqual(h.calls.synthetic.map(x=>x.type),['input','input','keyup']);
 assert.ok(h.calls.logs.some(x=>x.includes('RC96_QUERY_COMPAT')));
});

test('RC100 Member: persistent query reset has exactly three attempts and a same-ticket defer proof',async()=>{
 const h=harness({onSend:(h,m,p)=>{if(finalKey(p))h.fields[0].value='';},onSynthetic:(h,event)=>{if(event.type==='keyup')h.fields[0].value='';}});
 await assert.rejects(h.run(),e=>reviewProof(e,3,'FIXED_QUERY_MISMATCH'));
 assert.equal(insertions(h).length,2);assert.equal(h.calls.compat,1);
 assert.equal(h.calls.logs.filter(x=>x.startsWith('MEMBER_QUERY_RETRY')).length,2);
});

test('RC100 Member: a different value or committed INTL01 member is never overwritten by recovery',async()=>{
 for(const changed of ['Different Person','INTL01-11999991 | Beispiel Erika']){
  const h=harness({onSend:(h,m,p)=>{if(finalKey(p))h.fields[0].value=changed;}});
  await assert.rejects(h.run(),e=>reviewProof(e,1,'MEMBER_QUERY_VALUE_CHANGED'));
  assert.equal(h.fields[0].value,changed);assert.equal(insertions(h).length,1);assert.equal(h.calls.compat,0);
 }
});

test('RC100 Member: duplicate or read-only current input prevents every recovery write',async()=>{
 for(const reason of ['INPUT_NOT_UNIQUE','INPUT_NOT_EDITABLE']){
  const h=harness({onSend:(h,m,p)=>{if(finalKey(p)){
   h.fields[0].value='';
   if(reason==='INPUT_NOT_UNIQUE')h.fields.push(h.newInput(''));
   else h.fields[0].readOnly=true;
  }}});
  await assert.rejects(h.run(),e=>reviewProof(e,1,reason));
  assert.equal(insertions(h).length,1);assert.equal(h.calls.compat,0);
 }
});

test('RC100 Member: changed ticket prevents retry and does not produce a defer proof',async()=>{
 const h=harness({onSend:(h,m,p)=>{if(finalKey(p)){h.fields[0].value='';h.setTicket('89827031');}}});
 await assert.rejects(h.run(),e=>e.code==='TICKET_BINDING'&&e.memberQueryRecovery===undefined);
 assert.equal(insertions(h).length,1);assert.equal(h.calls.compat,0);
});

test('RC100 Member: changing ticket during slow focus is caught before any keyboard operation',async()=>{
 const h=harness({focused:false,onClick:h=>h.setTicket('89827031')});
 await assert.rejects(h.run(),{code:'TICKET_BINDING'});assert.equal(h.calls.native.length,0);
});

test('RC100 Member: CDP failure propagates unchanged and never triggers another input strategy',async()=>{
 const cause=Object.assign(new Error('Transport closed'),{code:'CDP_ERROR'});
 const h=harness({onSend:(h,m)=>{if(m==='Input.insertText')throw cause;}});
 await assert.rejects(h.run(),e=>e===cause);assert.equal(insertions(h).length,1);assert.equal(h.calls.compat,0);
});

test('RC100 Member: explicit manual abort propagates without retry or defer proof',async()=>{
 const h=harness();h.fields[0].readOnly=true;
 await assert.rejects(h.run(query,{manualGate:async()=> 'ABBRUCH'}),e=>e.code==='NAME_CHOICE_CANCELLED'&&e.memberQueryRecovery===undefined);
 assert.equal(h.calls.native.length,0);assert.equal(h.calls.compat,0);
});

test('RC100 Member: an unbound caller receives only its one normal attempt',async()=>{
 const h=harness({onSend:(h,m,p)=>{if(finalKey(p))h.fields[0].value='';}});
 await assert.rejects(h.run(query,{ticketId:null}),e=>e.code==='FIXED_QUERY_MISMATCH'&&e.memberQueryRecovery===undefined);
 assert.equal(insertions(h).length,1);assert.equal(h.calls.compat,0);assert.equal(h.calls.logs.length,0);
});

test('RC100 Member: Unicode names and numeric IDs preserve complete query bytes',async()=>{
 for(const text of ['Müller Zoë','García José','李 王','00999001','Ä Ö','A']){
  const h=harness();assert.equal(await h.run(text),true);assert.equal(h.fields[0].value,text);
  assert.equal(h.calls.compat,0);assert.equal(h.calls.synthetic.length,0);
 }
});

test('RC100 Member: each native operation rechecks the ticket, except unconditional Control release',async()=>{
 const h=harness();assert.equal(await h.run(),true);let prior=0;
 for(const event of h.calls.native){
  if(!(event.type==='keyUp'&&event.key==='Control'))assert.ok(event.ticketChecks>prior);
  prior=event.ticketChecks;
 }
});

test('RC100 Member: query-only compatibility cannot write a different input or use a malformed ticket',async()=>{
 for(const [id,options,code] of [['mainForm:category-value-id',{ticketId},'MEMBER_QUERY_FIELD'],[memberId,{ticketId:'invalid'},'TICKET_BINDING']]){
  const h=harness();await assert.rejects(setInputQuery(h.page,id,query,options),{code});assert.equal(h.calls.native.length,0);assert.equal(h.calls.synthetic.length,0);
 }
});

test('RC100: fixed-field input preserves its prior exact and one-character-prefix behavior',async()=>{
 const exact=harness();assert.equal(await typeTrustedFixedQuery(exact.page,memberId,query),'EXACT');
 const partial=harness({onSend:(h,m,p)=>{if(finalKey(p))h.fields[0].value=query.slice(0,-1);}});
 assert.equal(await typeTrustedFixedQuery(partial.page,memberId,query),'ONE_CHAR_PREFIX');
 assert.equal(insertions(partial).length,1);assert.equal(partial.calls.synthetic.length,0);assert.equal(partial.calls.compat,0);
});
