import test from 'node:test';
import assert from 'node:assert/strict';
import {chooseOwnTicket,ownRowStatus} from '../lib/phase1-own-ticket.mjs';
import {findOwnPhase1Ticket,readPhase1OwnTicket,openTicket} from '../lib/browser-workflow.mjs';
import {inspectIntelNavigation} from '../lib/intel-worklist-navigation.mjs';

const id='99122001',own='IN_BEARBEITUNG';
const make=(groups,statuses,more={})=>({ticketId:id,descriptionValue:'',descriptionBlank:true,descriptionRaw:'',source:'E-MAIL',ownFields:{groups,statuses,ambiguous:false},...more});
const options={processed:new Set(),ask:async()=>assert.fail('Unexpected operator prompt'),allowOperator:true};
test('RC122 exact semantic group and working status authorize only an eligible row',async()=>{
 const verified=make(['Intel Deutschland GmbH','INTL01'],['In Bearbeitung']);
 assert.equal(ownRowStatus(verified),'VERIFIED');
 for(const row of [make(['INTL010'],['In Bearbeitung']),make(['INTL01'],['Abgeschlossen']),make(['INTL01','Other Company'],['In Bearbeitung']),
  make(['INTL01'],['In Bearbeitung'],{ownFields:{groups:['INTL01'],statuses:['In Bearbeitung'],ambiguous:true}})]){
  assert.equal(ownRowStatus(row),'BLOCKED');
  assert.equal(await chooseOwnTicket([row],options),null);
 }
 assert.equal((await chooseOwnTicket([verified],options)).row,verified);
 assert.equal(await chooseOwnTicket([verified],{...options,processed:new Set([id])}),null);
 assert.equal(await chooseOwnTicket([make([],['In Bearbeitung'])],options),null);
 assert.equal(await chooseOwnTicket([make(['INTL01'],['In Bearbeitung'],{descriptionValue:'different note',descriptionBlank:false})],options),null);
});
test('RC122 operator can confirm missing status for one known Intel row only',async()=>{
 const intel=make(['INTL01'],[]),foreign=make(['Other Company'],[],{ticketId:'99122002'});
 assert.equal(await chooseOwnTicket([intel],{...options,allowOperator:false}),null);
 for(const answer of ['', 'anything',foreign.ticketId]){
  assert.equal(await chooseOwnTicket([intel,foreign],{...options,ask:async()=>answer}),null);
 }
 assert.equal((await chooseOwnTicket([intel,foreign],{...options,ask:async()=>id})).row,intel);
 await assert.rejects(chooseOwnTicket([intel],{...options,ask:async()=>'ABBRUCH'}),{code:'RUN_NOT_ARMED'});
});
function fixture(){
 let contents=[make(['INTL01'],['In Bearbeitung'])],render='first-document',conflict=false;
 const list=()=>({ok:true,tableId:'mainForm:tasksTableFor_MyTasksList',scope:own,render,rows:structuredClone(contents)});
 const page={call:async(fn,...args)=>{
  if(fn===inspectIntelNavigation)return {state:'CHILD_NOT_VISIBLE',active:false,conflict};
  assert.equal(args[0],true);assert.equal(args[1],true);return list();
 },mouseClick:()=>assert.fail('row changed before click')};
 return {page,setRows:rows=>contents=rows,replace:()=>render='new-document',conflict:()=>conflict=true};
}
test('RC122 pre-open evidence expires on rerender, contradictory row, changed field or conflicting current view',async()=>{
 for(const kind of ['document','group','status','description','view']){
  const s=fixture(),{row}=await findOwnPhase1Ticket(s.page,options);
  if(kind==='document')s.replace();
  else if(kind==='view')s.conflict();
  else if(kind==='group')s.setRows([make(['INTL02'],['In Bearbeitung'])]);
  else if(kind==='status')s.setRows([make(['INTL01'],['Zu prüfen'])]);
  else s.setRows([make(['INTL01'],['In Bearbeitung'],{descriptionRaw:'new'})]);
  await assert.rejects(openTicket(s.page,row,{scope:own}),{code:'INTL_TABLE_CHANGED'});
 }
});
test('RC122 readback can rebind the exact previously chosen own ticket, even with missing saved searches',async()=>{
 const s=fixture(),{row}=await findOwnPhase1Ticket(s.page,options);
 s.replace();s.setRows([make(['INTL01'],['In Bearbeitung'],{ticketId:'99122002'}),make(['INTL01'],['In Bearbeitung'],{descriptionValue:'Saved',descriptionRaw:'Saved',descriptionBlank:false})]);
 const found=await readPhase1OwnTicket(s.page,row);
 assert.equal(found.ticketId,id);assert.equal(found.descriptionRaw,'Saved');
 s.setRows([make(['INTL02'],['In Bearbeitung'])]);
 assert.equal(await readPhase1OwnTicket(s.page,row),null);
});
