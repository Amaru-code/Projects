import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {fixture,row,cells} from './rc97-workbook-fixture.mjs';
import {refreshLiveWorkbook,assertLiveWorkbookCurrent} from '../lib/live-workbook.mjs';
import {beneficiaryBusinessFingerprint,evaluateAoWorkbookChange,rebindWorkbookAfterGeneratedAo} from '../lib/phase2-post-generator-workbook.mjs';
const sha=x=>createHash('sha256').update(x).digest('hex');
const id='11369951';
function makeRoot(){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'mcr106-ao-rebind-'));
 const file=path.join(root,'current.xlsx');fs.mkdirSync(path.join(root,'config'));
 fs.writeFileSync(path.join(root,'config','local-runner-queue-send.json'),JSON.stringify({stockWorkbookPath:file}));
 const set=({main={...row,B:id},other={...row,B:'22336688'},contact=false}={})=>fs.writeFileSync(file,fixture({values:main,rows:`<row r="3">${cells(other,3)}</row>${contact?'<row r="4"><c r="FM4" t="inlineStr"><is><t>contact@example.invalid</t></is></c></row>':''}`}));
 set();return {root,file,set,close:()=>fs.rmSync(root,{recursive:true,force:true})};
}
function proof(active){return {schema:'MCR_PHASE2_PDF_PROOF_V1',ticketId:'89664431',targets:['AO'],
 comarchStatus:'NOT_ATTACHED_NOT_SAVED_NOT_FORWARDED',wwidSha256:sha(id),
 artifacts:[{plan:'AO',generation:{wwid:id}}],memberBusinessEvidence:{schema:'MCR_AO_MEMBER_WORKBOOK_V1',wwid:id,
 fingerprint:beneficiaryBusinessFingerprint(active.map,id)}};}
test('RC106 no new workbook binding when business digest unchanged',()=>{
 const f=makeRoot();try{
  const active=refreshLiveWorkbook(f.root),old=active.fileHash;
  f.set({contact:true});
  const result=rebindWorkbookAfterGeneratedAo(f.root,active,proof(active));
  assert.equal(result.status,'CURRENT');assert.equal(result.active.fileHash,old);
 }finally{f.close();}
});
test('RC106 unrelated employee changed while AO generating: fresh mapping, same AO beneficiary, no full run stop',()=>{
 const f=makeRoot();try{
  const active=refreshLiveWorkbook(f.root),p=proof(active),logs=[];
  f.set({other:{...row,B:'22336688',L:'77'}});
  const result=rebindWorkbookAfterGeneratedAo(f.root,active,p,{log:x=>logs.push(x)});
  assert.equal(result.status,'BENEFICIARY_UNCHANGED');assert.notEqual(result.active.fileHash,active.fileHash);
  assert.ok(logs.some(x=>x.includes('PASS P2_AO_BESTAND_SICHER_NEU_GEBUNDEN')));
  assert.ok(assertLiveWorkbookCurrent(f.root,result.active));
 }finally{f.close();}
});
test('RC106 beneficiary USC changed during AO generation: defer, do not authorize old PDF',()=>{
 const f=makeRoot();try{
  const active=refreshLiveWorkbook(f.root),p=proof(active),logs=[];
  f.set({main:{...row,B:id,L:'99'}});
  const result=rebindWorkbookAfterGeneratedAo(f.root,active,p,{log:x=>logs.push(x)});
  assert.equal(result.status,'BENEFICIARY_REVIEW_REQUIRED');
  assert.ok(logs.some(x=>x.includes('P2_AO_BESTAND_PERSON_GEAENDERT')));
  assert.ok(assertLiveWorkbookCurrent(f.root,result.active));
 }finally{f.close();}
});
test('RC106 beneficiary removed/blocked during calculation: defer',()=>{
 const f=makeRoot();try{
  const active=refreshLiveWorkbook(f.root),p=proof(active);
  f.set({main:{...row,B:id,C:'not-a-flag'}});
  const result=rebindWorkbookAfterGeneratedAo(f.root,active,p);
  assert.equal(result.status,'BENEFICIARY_REVIEW_REQUIRED');
 }finally{f.close();}
});
test('RC106 tampered or already attached PDF proof cannot rebind',()=>{
 const f=makeRoot();try{
  const active=refreshLiveWorkbook(f.root),p=proof(active);
  f.set({other:{...row,B:'22336688',L:'77'}});
  for(const changed of [{...p,wwidSha256:'0'.repeat(64)}, {...p,comarchStatus:'ATTACHED'}])
   assert.throws(()=>rebindWorkbookAfterGeneratedAo(f.root,active,changed),e=>e.code==='P2_AO_REBIND_PROOF');
  assert.throws(()=>evaluateAoWorkbookChange({beforeMap:active.map,afterMap:active.map,proof:{...p,targets:['DC']}}),e=>e.code==='P2_AO_REBIND_PROOF');
 }finally{f.close();}
});
