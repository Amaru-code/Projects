import test from 'node:test';
import assert from 'node:assert/strict';
import {findPhase1Candidate} from '../lib/phase1-worklist-search.mjs';

const own = 'IN_BEARBEITUNG';
const intel = 'WARTESCHLANGE_INTL01';
const other = 'WARTESCHLANGE_FREMD';
const eligible = id => ({ticketId:id, descriptionBlank:true, descriptionValue:'', source:'E-MAIL'});
const ready = (scope, rows = []) => ({ok:true, scope, state:rows.length ? 'READY' : 'READY_EMPTY', rows});
const unavailable = scope => Object.assign(new Error('Scope unproven: ' + scope), {
  code:'INTL_SCOPE_NOT_AVAILABLE',
  navigationState:{targetState:'CHILD_NOT_VISIBLE', tableState:'READY'}
});
const unexpected = () => assert.fail('Unexpected reload or operator prompt');

test('RC121 missing own child with a READY table reaches the separate verified Intel queue on the first pass', async () => {
  const prior = eligible('99000001');
  const ticket = eligible('99000002');
  const seen = [];
  const processed = new Set([prior.ticketId]);
  const result = await findPhase1Candidate({
    processed,
    readList: async scope => {
      seen.push(scope);
      if (scope === own) throw unavailable(own);
      assert.equal(scope, intel);
      return ready(intel, [prior, ticket]);
    },
    ask:unexpected,
    resetView:unexpected
  });
  assert.deepEqual(seen, [own, intel]);
  assert.equal(result.scope, intel);
  assert.deepEqual(result.row, ticket);
  assert.deepEqual([...processed], [prior.ticketId]);
});

test('RC121 an accessible own list retains priority and selects at most one ticket', async () => {
  const ticket = eligible('99000003');
  const result = await findPhase1Candidate({
    processed:new Set(),
    readList: async scope => {
      assert.equal(scope, own);
      return ready(own, [ticket, eligible('99000004')]);
    },
    ask:unexpected, resetView:unexpected
  });
  assert.equal(result.scope, own);
  assert.deepEqual(result.row, ticket);
});

test('RC121 an empty own list and a queue containing only a completed ticket prove both lists exhausted', async () => {
  const ticket = eligible('99000005');
  const scanned = [];
  const result = await findPhase1Candidate({
    processed:new Set([ticket.ticketId]),
    readList: async scope => {
      scanned.push(scope);
      return ready(scope, scope === intel ? [ticket] : []);
    },
    ask:unexpected, resetView:unexpected
  });
  assert.deepEqual(scanned, [own, intel]);
  assert.equal(result.scope, null);
  assert.equal(result.row, null);
});

test('RC121 missing primary is still an incomplete scan when the alternate has only excluded tickets', async () => {
  const seen = new Set();
  const ticket = eligible('99000006');
  await assert.rejects(() => findPhase1Candidate({
    processed:new Set([ticket.ticketId]),
    readList: async scope => {
      seen.add(scope);
      if (scope === own) throw unavailable(scope);
      return ready(intel, [ticket]);
    }
  }), {code:'INTL_SCOPE_NOT_AVAILABLE'});
  assert.deepEqual([...seen], [own, intel]);
});

test('RC121 missing children for both lists produce a boundary failure even with table state READY', async () => {
  const seen = new Set();
  await assert.rejects(() => findPhase1Candidate({
    processed:new Set(), readList: async scope => { seen.add(scope); throw unavailable(scope); }
  }), {code:'INTL_SCOPE_NOT_AVAILABLE'});
  assert.deepEqual([...seen], [own, intel]);
});

test('RC121 an unavailable primary can recover automatically or after the operator expands the same list', async t => {
  for (const recovery of ['reload', 'operator']) await t.test(recovery, async () => {
    const events = [];
    const ticket = eligible('99000007');
    let fixed = false;
    const result = await findPhase1Candidate({
      processed:new Set(),
      readList: async scope => {
        events.push(scope);
        if (scope === own && !fixed) throw unavailable(scope);
        return ready(scope, scope === own ? [ticket] : []);
      },
      resetView: async () => { events.push('reset'); fixed = recovery === 'reload'; return true; },
      ask: async question => {
        assert.equal(recovery, 'operator');
        assert.match(question, /In_Bearbeitung/i);
        assert(events.includes(intel));
        events.push('operator');
        fixed = true;
        return '';
      }
    });
    assert.equal(result.scope, own);
    assert.deepEqual(result.row, ticket);
    assert.equal(events.filter(e => e === 'reset').length, 1);
    assert.equal(events.filter(e => e === 'operator').length, recovery === 'operator' ? 1 : 0);
    assert(events.indexOf(intel) < events.indexOf('reset'));
  });
});

test('RC121 a ready foreign snapshot cannot supply an eligible row or an empty-list proof', async () => {
  for (const foreignRows of [[eligible('99000008')], []]) {
    await assert.rejects(() => findPhase1Candidate({
      processed:new Set(),
      readList: async scope => scope === own ? ready(other, foreignRows) : ready(intel)
    }));
  }
});

test('RC121 an unexpected ticket-binding error is never treated as a missing menu', async () => {
  const err = Object.assign(new Error('Binding changed'), {code:'TICKET_BINDING'});
  await assert.rejects(() => findPhase1Candidate({
    processed:new Set(),
    readList: async scope => { assert.equal(scope, own); throw err; },
    ask:unexpected, resetView:unexpected
  }), e => e === err);
});
