import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import os from 'node:os';
import fs from 'node:fs';
import {prepareFreshRun} from '../lib/run-reset.mjs';

test('one successful idle check precedes pre-action recovery on a clean start',t=>{
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'mcr-startup-'));
 t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
 const events=[];
 const guard=()=>{events.push('idle');return {schema:'MCR_PROCESS_GUARD_V1',checked:true,blockedCount:0,unknownCount:0};};
 const fresh=prepareFreshRun(root,{guard,afterInitialIdle:()=>events.push('recovery')});
 assert.deepEqual(events,['idle','recovery']);
 assert.equal(fresh.lockReleased,false);
 assert.deepEqual(fresh.pending,[]);
 assert.throws(()=>prepareFreshRun(root,{guard:()=>({checked:false}),afterInitialIdle:()=>assert.fail('unverified idle')}),{code:'PROCESS_CHECK_UNAVAILABLE'});
});
