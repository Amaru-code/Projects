import assert from 'node:assert/strict';
import test from 'node:test';
import {parsePhase2Start,phase2StartRows} from '../lib/phase2-run-selection.mjs';
import {choosePhase2Candidate} from '../src/phase2-run.mjs';
import {applyEnterApproval} from '../lib/operator-enter.mjs';

const row=(id,request,plan='DC')=>({ticketId:String(id),group:'Intel Deutschland GmbH',intelGroupVerified:true,
 descriptionValue:'USC 20/'+plan+'\nStandardantwort versendet\n'+request});
const direct=row(99911101,'Möchte Unterlagen','DB+');
const old=row(99911102,'Möchte Auszahlungsoption');
const fresh=row(99911103,'Möchte Auszahlungsoption');
const dc=row(99911104,'Möchte Kontoauszug');
const mixed=row(99911105,'Möchte Kontoauszug und Auszahlungsoption');
const rows=[direct,old,dc,mixed,fresh];

test('AO selects one pure AO job ahead of older journal resumes and excludes other work',()=>{
 const selection=parsePhase2Start(' ao ');
 assert.equal(selection.single,true);
 const filtered=phase2StartRows(rows,selection,0,id=>id===old.ticketId);
 assert.deepEqual(filtered,[fresh,old]);
 const pick=choosePhase2Candidate(filtered,{prepareMissingPdf:true});
 assert.equal(pick.row,fresh);
 assert.equal(pick.pdfPreparationRequired,true);
 assert.deepEqual(phase2StartRows([mixed],selection,0),[]);
 assert.deepEqual(phase2StartRows(rows,parsePhase2Start('AO '+mixed.ticketId),0),[mixed]);
});
test('explicit DC selection requires one matching COMARCH ticket whose saved request includes DC',()=>{
 const sel=parsePhase2Start('DC '+dc.ticketId);
 assert.deepEqual(phase2StartRows(rows,sel,0),[dc]);
 assert.deepEqual(phase2StartRows(rows,parsePhase2Start('DC '+mixed.ticketId),0),[mixed]);
 assert.throws(()=>phase2StartRows([dc,dc],sel,0),{code:'P2_START_NOT_IN_QUEUE'});
 assert.throws(()=>phase2StartRows(rows,parsePhase2Start('DC '+old.ticketId),0),{code:'P2_START_DOCUMENT_MISMATCH'});
 assert.throws(()=>parsePhase2Start('DC'),{code:'P2_TICKET_ID'});
 assert.throws(()=>parsePhase2Start('AO 123'),{code:'P2_TICKET_ID'});
 assert.throws(()=>phase2StartRows(rows,parsePhase2Start('AO 77777777'),0),{code:'P2_START_NOT_IN_QUEUE'});
});
test('empty and numeric starts retain existing multi-ticket behavior, review and journal exclusions apply',()=>{
 const all=parsePhase2Start(applyEnterApproval('Start-Ticket oder ENTER fuer alle. Genau ein Dokumentticket: AO, AO <Ticketnummer> oder DC <Ticketnummer>: ',''));
 assert.equal(all.single,false);
 assert.deepEqual(phase2StartRows(rows,all,0),rows);
 const first=parsePhase2Start(dc.ticketId);
 assert.deepEqual(phase2StartRows(rows,first,0),[dc]);
 assert.deepEqual(phase2StartRows(rows,first,1),rows);
 const marked={...old,descriptionValue:old.descriptionValue+'\nManuel review required'};
 assert.deepEqual(phase2StartRows([marked],parsePhase2Start('AO'),0),[]);
 const selected=phase2StartRows([fresh],parsePhase2Start('AO'),0);
 assert.equal(choosePhase2Candidate(selected,{blockedIds:[fresh.ticketId],prepareMissingPdf:true}).row,null);
});
