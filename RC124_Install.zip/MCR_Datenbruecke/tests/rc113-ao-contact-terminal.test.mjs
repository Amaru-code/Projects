import test from 'node:test';
import assert from 'node:assert/strict';
import {PassThrough} from 'node:stream';
import {EventEmitter} from 'node:events';
import readline from 'node:readline/promises';
import {askAoContactLine} from '../lib/ao-contact-terminal.mjs';
const tick=()=>new Promise(resolve=>setImmediate(resolve));
function terminal(){const input=new PassThrough(),output=new PassThrough(),interruptSource=new EventEmitter();let text='';output.on('data',s=>text+=s);const rl=readline.createInterface({input,output,terminal:false});return {rl,input,interruptSource,get text(){return text;},close(){rl.close();input.destroy();output.destroy();}};}
test('RC113 real readline: two sequential contact prompts on one interface',async()=>{
 const t=terminal();try{let question=askAoContactLine(t.rl,'Adresse: > ',{interruptSource:t.interruptSource});await tick();assert.equal(t.text,'Adresse: > ');t.input.write('Fiktive Teststrasse 7\n');assert.equal(await question,'Fiktive Teststrasse 7');
 question=askAoContactLine(t.rl,'PLZ: > ',{interruptSource:t.interruptSource});await tick();t.input.write('01234\n');assert.equal(await question,'01234');assert.equal(t.text,'Adresse: > PLZ: > ');assert.equal(t.interruptSource.listenerCount('SIGINT'),0);
 }finally{t.close();}
});
test('RC113 readline interrupt defers only the current field and permits subsequent questions',async()=>{
 const t=terminal();try{let question=askAoContactLine(t.rl,'Adresse: > ',{interruptSource:t.interruptSource});await tick();t.rl.emit('SIGINT');assert.equal(await question,null);assert.equal(t.interruptSource.listenerCount('SIGINT'),0);
 question=askAoContactLine(t.rl,'Naechstes Ticket: > ',{interruptSource:t.interruptSource});await tick();t.input.write('OK\n');assert.equal(await question,'OK');
 }finally{t.close();}
});
test('RC113 process interrupt and generator exit cancel the active readline question',async()=>{
 const t=terminal();try{let question=askAoContactLine(t.rl,'Adresse: > ',{interruptSource:t.interruptSource});await tick();t.interruptSource.emit('SIGINT');assert.equal(await question,null);
 const a=new AbortController();question=askAoContactLine(t.rl,'PLZ: > ',{signal:a.signal,interruptSource:t.interruptSource});await tick();a.abort();assert.equal(await question,null);assert.equal(t.interruptSource.listenerCount('SIGINT'),0);
 }finally{t.close();}
});
test('RC113 panel abort cancels the question without passing a contact value',async()=>{
 const t=terminal();try{const gate=new EventEmitter();gate.closed=false;const question=askAoContactLine(t.rl,'PLZ: > ',{gate,interruptSource:t.interruptSource});await tick();gate.closed=true;gate.emit('change');assert.equal(await question,null);assert.equal(gate.listenerCount('change'),0);}
 finally{t.close();}
});
test('RC113 raw terminal Ctrl+C clears a partly typed address; next question receives only new input',async()=>{
 const input=new PassThrough(),output=new PassThrough();output.resume();const rl=readline.createInterface({input,output,terminal:true});const interruptSource=new EventEmitter();
 try{let q=askAoContactLine(rl,'Adresse: > ',{interruptSource});input.write('Nicht abgeschlossene Eingabe');input.write('\x03');assert.equal(await q,null);assert.equal(rl.line,'');
 q=askAoContactLine(rl,'Naechstes Ticket: > ',{interruptSource});input.write('Neu\r');assert.equal(await q,'Neu');}finally{rl.close();input.destroy();output.destroy();}
});
