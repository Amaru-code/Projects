import test from 'node:test';
import assert from 'node:assert/strict';
import {assertRouteBinding,routeNotStarted,withRouteBindingRecovery} from '../lib/phase2-route-binding.mjs';
import {McrError} from '../lib/core.mjs';

const id='99991991';
const tableId='mainForm:tasksTableFor_MyTasksList';
const own={ok:true,errors:0,ids:[id],context:{tableId}};
const state=()=>({ticketId:id,schema:'MCR_PHASE2_WORK_JOURNAL_V1',state:'REVIEW_VERIFIED',
 events:['TICKET_SAVE_VERIFIED','REVIEW_VERIFIED'].map(state=>({state}))});
const lost=()=>new McrError('P2_ROUTE_BINDING_BEFORE_CLICK','Test');
const noWait=async()=>{};
function setup(){
 const journal=state(),result={opens:0,navigations:0},fresh={...own,ids:[id]};
 const options={ticketId:id,journal:{read:()=>journal},routeListBefore:own};
 const actions={
  navigate:async(p,s,o)=>{assert.equal(s,'IN_BEARBEITUNG');assert.deepEqual(o,{refresh:true});result.navigations++;},
  queue:async()=>({ok:true,scope:'IN_BEARBEITUNG',rows:[{ticketId:id,intelGroupVerified:true}]}),
  list:async()=>fresh,
  open:async(p,r)=>{assert.equal(r.ticketId,id);result.opens++;},
  check:async(p,actual,list)=>{assert.equal(actual,id);assert.equal(list,fresh);}
 };
 return {options,journal,result,fresh,actions};
}

test('transient empty ticket header needs two consecutive correct readings',async()=>{
 const headers=[id,null,null,id,id];let reads=0;
 await assertRouteBinding({},id,own,{read:async()=>({header:headers[reads++],urlIds:[]}),wait:noWait});
 assert.equal(reads,5);
});

test('a foreign header or explicit URL ID rejects immediately, and a URL alone never binds the ticket',async()=>{
 for(const seen of [{header:'99991992',urlIds:[id]},{header:id,urlIds:[id,'99991992']},{header:null,urlIds:[id]}]){
  await assert.rejects(assertRouteBinding({},id,own,{read:async()=>seen,wait:noWait}),{code:'P2_ROUTE_BINDING_BEFORE_CLICK'});
 }
});
test('duplicate, missing or differently scoped queue rows reject before consulting a header',async()=>{
 for(const list of [{...own,ids:[id,id]},{...own,ids:[]},{...own,errors:1},{...own,context:{tableId:'other'}}]){
  let called=false;
  await assert.rejects(assertRouteBinding({},id,list,{read:async()=>{called=true;},wait:noWait}),{code:'P2_ROUTE_BINDING_BEFORE_CLICK'});
  assert.equal(called,false);
 }
});

test('verified pre-click interruption reopens exactly the saved ticket and executes normal approval path anew',async()=>{
 const {options,result,fresh,actions}=setup();let approvals=0;
 const run=async(p,o)=>{approvals++;if(approvals===1)throw lost();assert.equal(o.routeListBefore,fresh);return 'routed';};
 assert.equal(await withRouteBindingRecovery({},options,run,actions),'routed');
 assert.deepEqual(result,{opens:1,navigations:1});assert.equal(approvals,2);
});

test('missing, ambiguous and foreign rows defer only the saved ticket; no reopening or forwarding',async()=>{
 for(const rows of [[],[{ticketId:id},{ticketId:id}],[{ticketId:id,intelGroupVerified:false}]]){
  const {options,result,actions}=setup();
  actions.queue=async()=>({ok:true,scope:'IN_BEARBEITUNG',rows});
  await assert.rejects(withRouteBindingRecovery({},options,async()=>{throw lost();},actions),{code:'P2_ROUTE_BINDING_DEFERRED'});
  assert.equal(result.opens,0);
 }
});

test('repeated conflict is deferred after exactly one reopen; cancellation still propagates',async()=>{
 const {options,result,actions}=setup();let calls=0;
 await assert.rejects(withRouteBindingRecovery({},options,async()=>{calls++;throw lost();},actions),{code:'P2_ROUTE_BINDING_DEFERRED'});
 assert.equal(calls,2);assert.equal(result.opens,1);
 await assert.rejects(withRouteBindingRecovery({},options,async()=>{throw new McrError('P2_OPERATOR_ABORT','abort');},actions),{code:'P2_OPERATOR_ABORT'});
 assert.equal(result.opens,1);
});

test('an actual or uncertain earlier routing action forbids a second attempt',async()=>{
 for(const event of ['EXECUTE_INTENT','REVIEW_EXECUTE_MANUAL_CLICK_INTENT','ROUTED_VERIFIED']){
  const {options,journal,result,actions}=setup();journal.events.push({state:event});
  assert.equal(routeNotStarted(journal,id),false);
  await assert.rejects(withRouteBindingRecovery({},options,async()=>{throw lost();},actions),{code:'P2_ROUTE_BINDING_BEFORE_CLICK'});
  assert.deepEqual(result,{opens:0,navigations:0});
 }
});

test('unknown journal format or missing saved evidence never qualifies for replay',()=>{
 const j=state();
 for(const v of [null,{...j,schema:'unknown'},{...j,ticketId:'99991992'},{...j,events:[{state:'REVIEW_VERIFIED'}]},{...j,events:[null]}]){
  assert.equal(routeNotStarted(v,id),false);
 }
});

test('the real detail reader accepts the linked readonly ticket number and rejects editable fields or contradictory visible headers',async()=>{
 const {runInNewContext}=await import('node:vm');
 const {detailTicketId}=await import('../lib/browser-workflow.mjs');
 function el(tag,text,attrs={}){return {tagName:tag,textContent:text,isConnected:true,
  getClientRects:()=>[{}],closest:()=>null,matches:()=>tag==='INPUT'||tag==='OUTPUT',
  querySelectorAll:()=>[],...attrs};}
 const input=el('INPUT','',{readOnly:true,value:id}),label=el('LABEL','Ticket-ID:',{control:input});
 const headers=[label,el('H2','Ticket-ID: '+id,{isConnected:false})];
 const page={call:async fn=>runInNewContext('('+fn.toString()+')()',
  {document:{querySelectorAll:()=>headers},getComputedStyle:()=>({visibility:'visible'})})};
 assert.equal(await detailTicketId(page),id);
 input.readOnly=false;assert.equal(await detailTicketId(page),null);
 input.readOnly=true;headers.push(el('H2','Ticket-ID: 99991992'));assert.equal(await detailTicketId(page),null);
 headers.pop();headers.push(el('TD','Ticket-ID: 99991992',{closest:()=>({})}));
 assert.equal(await detailTicketId(page),id);
});
