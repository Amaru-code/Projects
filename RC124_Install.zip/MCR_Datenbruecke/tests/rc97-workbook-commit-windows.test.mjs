/** Native Windows qualification of the real exclusive-file adapter.
 * Uses only disposable, synthetic local XLSX files. Never reads K: or COMARCH. */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawn,spawnSync} from 'node:child_process';
import {fixture} from './rc97-workbook-fixture.mjs';
import {readWorkbookBuffer} from '../lib/xlsx-multirow.mjs';
import {patchContactCells} from '../lib/xlsx-contact-patch.mjs';
import {sha256} from '../lib/core.mjs';

const native={skip:process.platform!=='win32'?'Windows FileShare.None / PowerShell not available on this host':false,timeout:30000};
const script=fileURLToPath(new URL('../tools/workbook-commit.ps1',import.meta.url));
const powershell=path.join(process.env.SystemRoot||'C:\\Windows','System32','WindowsPowerShell','v1.0','powershell.exe');
function prepared(){
 const directory=fs.mkdtempSync(path.join(os.tmpdir(),'mcr97-native-commit-'));
 const before=fixture(),book=readWorkbookBuffer(before,'fixture.xlsx',{extended:true});
 const after=patchContactCells(before,book,[{ref:'FM2',value:'synthetic@example.invalid'},{ref:'FN2',value:'EN'}]);
 const request={schema:'MCR_WORKBOOK_COMMIT_V1',path:path.join(directory,'synthetic.xlsx'),stagedPath:path.join(directory,'stage.xlsx'),backupPath:path.join(directory,'backup.xlsx'),transactionPath:path.join(directory,'transaction.json'),beforeSha256:sha256(before),afterSha256:sha256(after)};
 fs.writeFileSync(request.path,before);fs.writeFileSync(request.stagedPath,after);
 return {directory,before,after,request};
}
function invoke(p){
 const file=path.join(p.directory,'request.json');fs.writeFileSync(file,JSON.stringify(p.request));
 const run=spawnSync(powershell,['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',script,'-RequestPath',file],{encoding:'utf8',windowsHide:true,timeout:20000,maxBuffer:1024*1024});
 assert.equal(run.error,undefined,String(run.error));
 assert.equal(run.signal,null,String(run.stderr));
 return {run,result:JSON.parse(String(run.stdout).replace(/^\uFEFF/,'').trim())};
}
const cleanup=p=>fs.rmSync(p.directory,{recursive:true,force:true,maxRetries:3,retryDelay:100});

test('RC97 native Windows: one commit preserves full backup and records verified hash readback',native,()=>{
 const p=prepared();try{
  const {run,result}=invoke(p);assert.equal(run.status,0);assert.equal(result.ok,true);assert.equal(result.code,'WORKBOOK_COMMITTED_VERIFIED');
  assert.ok(fs.readFileSync(p.request.path).equals(p.after));assert.ok(fs.readFileSync(p.request.backupPath).equals(p.before));
  const transaction=JSON.parse(fs.readFileSync(p.request.transactionPath,'utf8'));
  assert.equal(transaction.state,'COMMITTED_VERIFIED');assert.equal(transaction.beforeSha256,sha256(p.before));assert.equal(transaction.afterSha256,sha256(p.after));
  assert.equal(readWorkbookBuffer(fs.readFileSync(p.request.path),'synthetic.xlsx',{extended:true}).allRows()[0].FM,'synthetic@example.invalid');
 }finally{cleanup(p);}
});
test('RC97 native Windows: source changed after planning is rejected before backup or mutation',native,()=>{
 const p=prepared();try{
  p.request.beforeSha256='0'.repeat(64);const {run,result}=invoke(p);
  assert.equal(run.status,1);assert.equal(result.code,'WORKBOOK_CONCURRENT_CHANGE');assert.equal(result.ok,false);
  assert.ok(fs.readFileSync(p.request.path).equals(p.before));assert.equal(fs.existsSync(p.request.backupPath),false);assert.equal(fs.existsSync(p.request.transactionPath),false);
 }finally{cleanup(p);}
});
test('RC97 native Windows: changed staged bytes are rejected before opening the source for writing',native,()=>{
 const p=prepared();try{
  fs.appendFileSync(p.request.stagedPath,'tampered stage');const {run,result}=invoke(p);
  assert.equal(run.status,1);assert.equal(result.code,'WORKBOOK_STAGE_CHANGED');assert.ok(fs.readFileSync(p.request.path).equals(p.before));
  assert.equal(fs.existsSync(p.request.backupPath),false);assert.equal(fs.existsSync(p.request.transactionPath),false);
 }finally{cleanup(p);}
});
test('RC97 native Windows: an existing backup is not overwritten and source remains unchanged',native,()=>{
 const p=prepared();try{
  fs.writeFileSync(p.request.backupPath,'existing unrelated backup');const {run,result}=invoke(p);
  assert.equal(run.status,1);assert.equal(result.ok,false);assert.ok(fs.readFileSync(p.request.path).equals(p.before));
  assert.equal(fs.readFileSync(p.request.backupPath,'utf8'),'existing unrelated backup');assert.equal(fs.existsSync(p.request.transactionPath),false);
 }finally{cleanup(p);}
});
test('RC97 native Windows: a conflicting exclusive handle prevents writes, then releasing it permits the same verified commit',native,async()=>{
 const p=prepared();let holder;
 try{
  const lockScript=path.join(p.directory,'hold-synthetic-file.ps1');
  fs.writeFileSync(lockScript,"param([string]$LockPath)\n$h=[IO.FileStream]::new($LockPath,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)\ntry { [Console]::Out.WriteLine('LOCK_HELD'); [Console]::Out.Flush(); [void][Console]::In.ReadLine() } finally { $h.Dispose() }\n");
  holder=spawn(powershell,['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',lockScript,'-LockPath',p.request.path],{stdio:['pipe','pipe','pipe'],windowsHide:true});
  const exited=new Promise((resolve,reject)=>{holder.once('exit',code=>resolve(code));holder.once('error',reject);});
  await new Promise((resolve,reject)=>{
   const timeout=setTimeout(()=>reject(Error('Synthetic file lock was not acquired')),10000);let output='';
   holder.stdout.on('data',d=>{output+=d.toString();if(output.includes('LOCK_HELD')){clearTimeout(timeout);resolve();}});
   holder.once('error',e=>{clearTimeout(timeout);reject(e);});holder.once('exit',()=>{clearTimeout(timeout);if(!output.includes('LOCK_HELD'))reject(Error('Synthetic file lock process exited early'));});
  });
  const blocked=invoke(p);assert.equal(blocked.run.status,1);assert.equal(blocked.result.code,'WORKBOOK_LOCKED_OR_IO');
  assert.equal(fs.existsSync(p.request.backupPath),false);assert.equal(fs.existsSync(p.request.transactionPath),false);
  holder.stdin.end('\n');assert.equal(await exited,0);holder=null;
  assert.ok(fs.readFileSync(p.request.path).equals(p.before));
  const retry=invoke(p);assert.equal(retry.run.status,0);assert.ok(fs.readFileSync(p.request.path).equals(p.after));
 }finally{if(holder){holder.stdin.end('\n');holder.kill();await new Promise(resolve=>holder.exitCode!==null?resolve():holder.once('exit',resolve));}cleanup(p);}
});
