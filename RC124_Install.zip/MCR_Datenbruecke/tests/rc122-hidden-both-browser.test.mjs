import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage} from '../lib/cdp.mjs';
import * as UI from '../lib/browser-workflow.mjs';
import {findPhase1Candidate} from '../lib/phase1-worklist-search.mjs';
import {cleanupTemporaryTestBrowser} from './browser-test-profile-cleanup.mjs';
import {checkIncident,checkLegacyMenu} from './rc122-hidden-both-fixture.mjs';

test('RC122 opens one eligible Intel ticket in a mixed own-tasks table while both saved menus lack children', {timeout:55000}, async()=>{
 const profile=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-RC20-NOTE-RC122-'));
 let browser,cdp;
 try{
  browser=await launchBrowser({executable:findEdgeExecutable(),userDataDir:profile,startUrl:'about:blank',headless:true,
   extraArgs:process.platform==='linux'?['--no-sandbox','--disable-dev-shm-usage']:[]});
  ({cdp}=await connectBrowser(browser.port));
  const page=await attachPage(cdp,t=>t.type==='page'&&t.url==='about:blank');
  await checkLegacyMenu(page,UI,findPhase1Candidate,assert);
  await checkIncident(page,UI,findPhase1Candidate,assert);
 } finally{
  await cleanupTemporaryTestBrowser({profile,browser,cdp});
 }
});
