import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const html=fs.readFileSync(new URL('../tools/flow-lab/MCR_Flow_Lab_RC94.html',import.meta.url),'utf8');
test('RC96 fullscreen module parses and only adds read-only UI',()=>{
 const source=html.match(/<script id="mcr96-fullscreen-script">([\s\S]*?)<\/script>/)?.[1];
 assert.ok(source);new vm.Script(source);
 for(const token of ['mcr96PlanBtn','mcr96PlanBar','mcr96Close','mcr96Fit','requestFullscreen','fullscreenchange','Escape'])assert.ok(source.includes(token));
 for(const forbidden of ['COMARCH_SEND','sendEmail','writeTicket','fetch(','.runtime/phase2'])assert.ok(!source.includes(forbidden),forbidden);
});
test('RC96 styling is scoped to Fahrplan fullscreen; original graph data retained',()=>{
 assert.match(html,/<style id="mcr96-fullscreen-style">/);
 assert.match(html,/#compactPane:fullscreen/);
 assert.match(html,/body\.mcr96-plan-full #compactPane/);
 const graphs=JSON.parse(html.match(/<script[^>]*id="graphData"[^>]*>([\s\S]*?)<\/script>/)[1]);
 assert.equal(graphs.length,12);
 assert.equal(graphs.reduce((n,x)=>n+x.nodes.length,0),341);
 assert.equal(graphs.reduce((n,x)=>n+x.edges.length,0),429);
});
