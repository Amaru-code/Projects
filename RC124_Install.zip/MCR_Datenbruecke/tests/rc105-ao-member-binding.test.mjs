import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {sha256} from '../lib/core.mjs';
import {assertCentralAoMemberBinding,createPhase2BoundTicketGuard} from '../lib/phase2-ao-member-binding.mjs';

const ticketId='99990001',wwid='99900001';
const member={profileVerified:true,profile:{mercerId:'1199900001',first:'Erika',last:'Beispiel'},wwid:null,memberReferenceWwid:wwid};
const proof={ticketId,memberProfileVerified:true,memberId:member.profile.mercerId,memberName:{first:'Erika',last:'Beispiel'},
 wwidSha256:sha256(wwid),wwidOrigin:'BOUND_INTL01_MEMBER_REFERENCE',operatorContentReviewed:false,
 operatorPersonTicketBindingReviewed:false,artifacts:[{plan:'AO',provenance:'CENTRAL_AO_GENERATOR_AUDIT',generation:{schema:'MCR_AO_GENERATOR_PROOF_V1',wwid}}]};
const check=(m=member,p=proof)=>assertCentralAoMemberBinding({proof:p,member:m,ticketId,wwid});

test('RC105 central AO keeps exact member binding for a standalone or mixed document request',()=>{
 assert.doesNotThrow(()=>check());
 assert.doesNotThrow(()=>check(member,{...proof,artifacts:[{plan:'DC',provenance:'EXISTING_FILE_READ_ONLY'},...proof.artifacts],operatorContentReviewed:true,operatorPersonTicketBindingReviewed:true}));
 for(const m of [null,{...member,profileVerified:false},{...member,profile:{...member.profile,mercerId:'1199900002'}},
  {...member,profile:{...member.profile,first:'Andere'}},{...member,profile:{...member.profile,last:'Person'}}])
  assert.throws(()=>check(m),e=>e.code==='P2_AO_MEMBER_CHANGED');
 assert.throws(()=>check(member,{...proof,ticketId:'99990002'}),e=>e.code==='P2_AO_MEMBER_CHANGED');
});

test('RC105 the same WWID evidence must survive; another matching source does not hide its disappearance',()=>{
 assert.throws(()=>check({...member,memberReferenceWwid:null,wwid}),e=>e.code==='P2_AO_WWID_EVIDENCE_LOST');
 assert.throws(()=>check({...member,memberReferenceWwid:null,wwid:null}),e=>e.code==='P2_AO_WWID_EVIDENCE_LOST');
 assert.throws(()=>check({...member,wwid:'99900002'}),e=>e.code==='P2_AO_WWID_CHANGED');
 const explicit={...proof,wwidOrigin:'EXPLICIT_COMARCH_FIELD'};
 assert.doesNotThrow(()=>check({...member,wwid},explicit));
 assert.throws(()=>check(member,explicit),e=>e.code==='P2_AO_WWID_EVIDENCE_LOST');
 assert.throws(()=>check({...member,wwid,memberReferenceWwid:'99900002'},explicit),e=>e.code==='P2_AO_WWID_CHANGED');
 assert.throws(()=>check(member,{...proof,wwidSha256:sha256('99900002')}),e=>e.code==='P2_AO_WWID_CHANGED');
});

test('RC105 manual WWID exception remains explicitly reviewed and cannot become automatic AO permission',()=>{
 const manual={...proof,wwidOrigin:'OPERATOR_ENTRY'},unlabeled={...member,wwid:null,memberReferenceWwid:null};
 assert.throws(()=>check(unlabeled,manual),e=>e.code==='P2_AO_WWID_EVIDENCE_LOST');
 assert.doesNotThrow(()=>check(unlabeled,{...manual,operatorContentReviewed:true,operatorPersonTicketBindingReviewed:true}));
 assert.throws(()=>check({...unlabeled,wwid:'99900002'},{...manual,operatorContentReviewed:true,operatorPersonTicketBindingReviewed:true}),e=>e.code==='P2_AO_WWID_CHANGED');
});

test('RC105 every central AO bound() call rereads the current profile and brackets it with exact ticket checks',async()=>{
 const events=[],page={};let current=member;
 const bound=createPhase2BoundTicketGuard({proof,page,ticketId,wwid,
  assertTicket:async(p,id)=>{assert.equal(p,page);assert.equal(id,ticketId);events.push('ticket');},
  memberLookup:async p=>{assert.equal(p,page);events.push('member');return current;}});
 await bound();assert.deepEqual(events,['ticket','member','ticket']);
 current={...member,profile:{...member.profile,mercerId:'1199900002'}};
 await assert.rejects(bound(),{code:'P2_AO_MEMBER_CHANGED'});
 assert.deepEqual(events,['ticket','member','ticket','ticket','member']);
});

test('RC105 legacy DC/PP+ guard preserves one ticket check and never adds AO member reads',async()=>{
 const events=[],legacy={...proof,artifacts:[{plan:'DC',provenance:'EXISTING_FILE_READ_ONLY'},{plan:'PP+',provenance:'EXISTING_FILE_READ_ONLY'}]};
 const bound=createPhase2BoundTicketGuard({proof:legacy,page:{},ticketId,wwid,
  assertTicket:async()=>events.push('ticket'),memberLookup:async()=>assert.fail('No new member read on legacy files')});
 await bound();assert.deepEqual(events,['ticket']);assert.doesNotThrow(()=>check(null,legacy));
});

test('RC105 real upload/save/route preconditions invoke the strengthened bound hook',()=>{
 const code=fs.readFileSync(new URL('../src/phase2-comarch-pilot.mjs',import.meta.url),'utf8');
 assert.match(code,/const bound=createPhase2BoundTicketGuard\(\{proof,page,ticketId:id,wwid,memberLookup,assertTicket:UI\.assertTicket\}\)/);
 assert(code.indexOf('assertCentralAoMemberBinding({proof,member,ticketId:id,wwid})')<code.indexOf('await ensurePhase2Edit(page'));
 for(const pattern of [/beforeSelect:async\(\{file,name\}\)=>\{\s*await bound\(\);assertUnchanged\(\);/,
  /beforeExecute:async\(\)=>\{await bound\(\);assertUnchanged\(\);/,
  /const beforeSave=async\(\)=>\{assertLiveWorkbookCurrent\(root,activeMapping\);\s*await bound\(\);assertUnchanged\(\);/])assert.match(code,pattern);
});
