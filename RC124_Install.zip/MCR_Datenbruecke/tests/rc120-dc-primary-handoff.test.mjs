import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {setTimeout as delay} from 'node:timers/promises';
import {runAccountStatement} from '../lib/phase2-statement-generator.mjs';

const id='11369832', person={first:'Test',last:'Muster'};
const pdf='%PDF-1.4\n'+('synthetic test data\n'.repeat(20))+'%%EOF';
const name=id+'_Kontoauszug_DC.pdf';
const start='import sys,time\nfrom pathlib import Path\np=Path("Ausgabe_PDF") / "'+name+'"\n';
const exportPdf='p.write_bytes('+JSON.stringify(pdf)+'.encode())\n';
function fixture(t,script){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'mcr-dc-finalized-'));
 const folder=path.join(root,'DC'),output=path.join(folder,'Ausgabe_PDF'),release=path.join(folder,'finish-copy');
 fs.mkdirSync(output,{recursive:true});
 fs.writeFileSync(path.join(folder,'kontoauszug_dc_generator.py'),start+script);
 for(const file of ['_2026_LNW_DC_Output.xlsm','Personenordner_Zuordnung.csv'])fs.writeFileSync(path.join(folder,file),'synthetic');
 const log=[],receiptDir=path.join(root,'.runtime/phase2/dc-generator');
 const execute=(opts={})=>runAccountStatement(root,'DC',id,{person,paths:()=>({folder,statementOutput:output}),log:s=>log.push(s),...opts});
 t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
 return {root,folder,output,execute,release,log,receiptDir};
}

test('RC120 fresh DC primary can enter verification before optional copy finishes; competing exporter is bound to same workbook lock',async t=>{
 const f=fixture(t,'def copy_to_person_folder(pdf,person_name,wwid):\n'+
  '    for i in range(300):\n        if Path("finish-copy").exists(): break\n        time.sleep(.05)\n'+
  '    import shutil\n    return shutil.copy2(pdf, Path("copy-result"))\n'+exportPdf+
  'copy_to_person_folder(p,"Muster Test",sys.argv[2])\n');
 try{
  const a=await f.execute({handoffMs:60});
  assert.equal(a.status,'GENERATOR_EXECUTED',JSON.stringify(a));
  assert.equal(a.artifact.name,name);assert.equal(a.artifact.bytes,Buffer.byteLength(pdf));
  assert(f.log.some(v=>v.startsWith('P2_DC_PDF_CREATED:')));
  assert(f.log.some(v=>v.startsWith('P2_DC_PRIMAEREXPORT_BEREIT:')));
  assert(!fs.existsSync(path.join(f.folder,'copy-result')));
  const secondInstallation=path.join(f.root,'other-installation');
  const busy=await runAccountStatement(secondInstallation,'DC',id,{person,paths:()=>({folder:f.folder,statementOutput:f.output})});
  assert.equal(busy.error,'P2_KONTOAUSZUG_GENERATOR_BUSY',JSON.stringify(busy));assert(!busy.artifact);
 }finally{
  fs.writeFileSync(f.release,'1');
  let closed=false;
  for(let i=0;i<150;++i){
   const receipts=fs.readdirSync(f.receiptDir).filter(n=>n.endsWith('.json')).map(n=>JSON.parse(fs.readFileSync(path.join(f.receiptDir,n),'utf8')));
   if(receipts.some(r=>r.event==='EXIT'&&r.exit_code===0&&r.previous==='COPY_OK')){closed=true;break;}
   await delay(20);
  }
  assert(closed,'original DC generator should complete cleanup');
 }
});

test('RC120 copy exception isolated from the completed primary; unrelated generator failure stays open',async t=>{
 for(const [label,tail,ok] of [
  ['copy alone', 'copy_to_person_folder(p,"Muster Test",sys.argv[2])',true],
  ['another failure','try: copy_to_person_folder(p,"Muster Test",sys.argv[2])\nexcept OSError: pass\nraise ValueError("Fehler in der Rechnung")',false]
 ]){
  await t.test(label,async t=>{
   const f=fixture(t,'def copy_to_person_folder(pdf,person_name,wwid):\n    raise OSError("Kopie fehlgeschlagen")\n'+exportPdf+tail);
   const a=await f.execute();
   assert.equal(Boolean(a.artifact),ok,JSON.stringify(a));
   if(ok)assert.equal(a.warning,'P2_KONTOAUSZUG_PERSON_FOLDER_UNAVAILABLE');
  });
 }
});

test('RC120 stale, differently bound or incomplete DC exports never receive early upload proof',async t=>{
 for(const [label,setup,body] of [
  ['old PDF',true,'copy_to_person_folder(p,"Muster Test",sys.argv[2])'],
  ['wrong WWID',false,exportPdf+'copy_to_person_folder(p,"Muster Test","9912345")'],
  ['incomplete bytes',false,'p.write_bytes(b"%PDF-1.4" + b"x"*512)\ncopy_to_person_folder(p,"Muster Test",sys.argv[2])'],
  ['unreported PDF in output; generator still active',false,exportPdf+'time.sleep(10)']
 ]){
  await t.test(label,async t=>{
   const f=fixture(t,'def copy_to_person_folder(pdf,person_name,wwid): pass\n'+body);
   if(setup)fs.writeFileSync(path.join(f.output,name),pdf);
   const a=await f.execute({timeoutMs:400,handoffMs:30});
   assert(!a.artifact,JSON.stringify(a));assert(!f.log.some(v=>v.startsWith('P2_DC_PDF_CREATED:')));
  });
 }
});

test('RC120 rejects a DC file changed after the primary receipt, including the same filename and valid PDF envelope',async t=>{
 const f=fixture(t,'def copy_to_person_folder(pdf,person_name,wwid):\n'+
  '    pdf.write_bytes(pdf.read_bytes().replace(b"synthetic",b"different"))\n'+exportPdf+
  'copy_to_person_folder(p,"Muster Test",sys.argv[2])\n');
 const a=await f.execute();assert(!a.artifact);
 assert.equal(a.error,'P2_KONTOAUSZUG_AUDIT_REQUIRED',JSON.stringify(a));
});

test('RC120 missing original DC program stops in preflight before generator start',async t=>{
 const f=fixture(t,'pass\n');fs.unlinkSync(path.join(f.folder,'kontoauszug_dc_generator.py'));
 const a=await f.execute();
 assert.equal(a.error,'P2_KONTOAUSZUG_GENERATOR_PREFLIGHT_FAILED');
 assert(!f.log.some(x=>x.startsWith('P2_KONTOAUSZUG_GENERATOR_START:')));
});

for(const [label,tail] of [
 ['late failing workbook save','time.sleep(.25)\nraise ValueError("Workbook.Save failed")'],
 ['failing cleanup in finally','try:\n    time.sleep(.25)\nfinally:\n    raise OSError("Excel.Close failed")'],
 ['failing generator atexit cleanup','import atexit\n@atexit.register\ndef close_excel():\n    time.sleep(.25)\n    raise OSError("atexit Excel.Quit failed")']
]){
 test('RC120 '+label+' after the original archive callsite refuses the existing PDF',async t=>{
  const f=fixture(t,'def copy_to_person_folder(pdf,person_name,wwid):\n    Path("copied-before-failure").touch()\n'+exportPdf+
   'copy_to_person_folder(p,"Muster Test",sys.argv[2])\n'+tail+'\n');
  const a=await f.execute({handoffMs:10});
  assert.equal(a.error,'P2_KONTOAUSZUG_GENERATOR_FAILED',JSON.stringify(a));assert(!a.artifact);
  assert(!f.log.some(s=>s.startsWith('P2_DC_PDF_CREATED:')));
  assert(!fs.existsSync(path.join(f.folder,'copied-before-failure')));
 });
}

test('RC120 an archive call with a consumed return value preserves original semantics and waits for the generator',async t=>{
 const f=fixture(t,'def copy_to_person_folder(pdf,person_name,wwid): return "expected-value"\n'+exportPdf+
  'result=copy_to_person_folder(p,"Muster Test",sys.argv[2])\nassert result=="expected-value"\ntime.sleep(.15)\nraise ValueError("primary failed after actual copy")\n');
 const a=await f.execute({handoffMs:10});
 assert.equal(a.error,'P2_KONTOAUSZUG_GENERATOR_FAILED');
 assert(!a.artifact);assert(!f.log.some(s=>s.startsWith('P2_DC_PDF_CREATED:')));
});

test('RC120 skips the central generator if an older direct DC process is still active on the workstation',async t=>{
 const f=fixture(t,'raise AssertionError("DC must not be started")\n');
 const r=await f.execute({existingDc:()=>[30784]});
 assert.equal(r.error,'P2_KONTOAUSZUG_GENERATOR_BUSY');assert.match(r.reason,/30784/);
 assert(!r.artifact);assert(!f.log.some(x=>x.startsWith('P2_KONTOAUSZUG_GENERATOR_START:')));
 const unavailable=await f.execute({existingDc:()=>{throw Error('snapshot unavailable');}});
 assert.equal(unavailable.error,'P2_KONTOAUSZUG_GENERATOR_PREFLIGHT_FAILED');
});
