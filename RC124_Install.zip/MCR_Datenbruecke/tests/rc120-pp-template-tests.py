import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

# Avoid writing .pyc files inside the installation under test.
sys.dont_write_bytecode = True
TOOL = Path(__file__).resolve().parents[1] / "tools" / "statement-preflight.py"
spec = importlib.util.spec_from_file_location("statement_preflight", TOOL)
pp = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pp)
WRONG = pp.TEMPLATE.encode().decode("cp1252").encode().decode("cp1252")


class TemplateTests(unittest.TestCase):
    def setUp(self):
        td = tempfile.TemporaryDirectory()
        self.addCleanup(td.cleanup)
        self.folder = Path(td.name) / "Kontoauszug_PP+"
        self.folder.mkdir()
        self.script = self.folder / pp.PP_SCRIPT
        (self.folder / pp.TEMPLATE).write_bytes(b"test template")

    def run_cli(self, *args):
        return subprocess.run([sys.executable, "-B", str(TOOL), *map(str, args)], cwd=self.folder, capture_output=True)

    def test_persistent_and_idempotent(self):
        for codec, spelling in [("utf-8-sig", WRONG), ("cp1252", WRONG), ("utf-8", pp.TEMPLATE.encode().decode("latin1"))]:
            with self.subTest(encoding=codec):
                literal = repr(spelling)
                cookie = "utf-8" if codec == "utf-8-sig" else codec
                src = (f"# coding: {cookie}\r\nfrom pathlib import Path\r\n"
                       f"NOTE = {literal}  # preserve literal for unrelated output\r\n"
                       f"füße = 1; TEMPLATE = Path(__file__).parent / {literal}  # {spelling}\r\n"
                       "assert TEMPLATE.read_bytes() == b'test template'\r\n")
                before = src.encode(codec)
                self.script.write_bytes(before)
                result = self.run_cli("repair-pp", self.script)
                self.assertEqual(result.returncode, 0, result.stdout)
                detail = json.loads(result.stdout)
                backup = Path(detail["backup"])
                self.assertEqual(backup.read_bytes(), before)
                after = self.script.read_bytes()
                prefix, suffix = src.split(" / "+literal+" ", 1)
                self.assertEqual(after, (prefix+" / "+json.dumps(pp.TEMPLATE, ensure_ascii=False)+" "+suffix).encode(codec))
                self.assertEqual(json.loads(self.run_cli("repair-pp", self.script).stdout)["status"], "PP_TEMPLATE_ALREADY_CORRECT")
                self.assertEqual(list(self.folder.glob("*.bak")), [backup])
                run = subprocess.run([sys.executable, "-B", str(self.script)], capture_output=True)
                self.assertEqual(run.returncode, 0, run.stderr)
                backup.unlink()

    def test_missing_canonical_or_ambiguous(self):
        source = f"TEMPLATE = {WRONG!r}\nSECOND_TEMPLATE = {WRONG!r}\n".encode()
        self.script.write_bytes(source)
        with self.assertRaisesRegex(ValueError, "nicht eindeutig"):
            pp.repair_pp(self.script)
        (self.folder / pp.TEMPLATE).unlink()
        with self.assertRaisesRegex(OSError, "Datei fehlt"):
            pp.repair_pp(self.script)
        self.assertEqual(self.script.read_bytes(), source)
        self.assertFalse(list(self.folder.glob("*.bak")))

    def test_source_changed_before_replace(self):
        self.script.write_text("TEMPLATE = "+repr(WRONG)+"\n", encoding="utf-8")
        original = self.script.read_bytes()
        written_by_editor = original + b"# concurrent editor\n"
        def edit(_, __):
            self.script.write_bytes(written_by_editor)
        with mock.patch.object(pp.shutil, "copymode", side_effect=edit):
            with self.assertRaisesRegex(RuntimeError, "seit Beginn"):
                pp.repair_pp(self.script)
        self.assertEqual(self.script.read_bytes(), written_by_editor)
        self.assertEqual(next(self.folder.glob("*.bak")).read_bytes(), original)
        self.assertFalse(list(self.folder.glob("*.tmp")))

    def test_runtime_correction_only_changes_the_template_path(self):
        for form in ["Path(__file__).parent / VALUE", "Path(__file__).parent.joinpath(VALUE)", "Path(VALUE)"]:
            self.script.write_text("from pathlib import Path\nprint("+repr(WRONG)+")\nTEMPLATE="+
                                   form.replace("VALUE",repr(WRONG))+"\nprint(TEMPLATE.name)\n", encoding="utf-8")
            run = self.run_cli("run-pp", self.script)
            self.assertEqual(run.returncode, 0, run.stderr)
            self.assertEqual(run.stdout.decode("utf8").splitlines(), [WRONG, pp.TEMPLATE])

    def test_pp_preflight_and_real_python_entry_point(self):
        files = [self.folder / "IPP_Kontoauszuege_Arbeitsdatei.xlsm", self.folder / "Kontostand_Kontrolle_Arbeitsdatei.xlsm",
                 self.folder.parent / "Daten" / "eckwerte_runtime.py", self.folder.parent / "Daten" / "Personenordner_Zuordnung.csv"]
        for file in files:
            file.parent.mkdir(exist_ok=True)
            file.write_bytes(b"synthetic")
        for spelling in [WRONG, pp.TEMPLATE]:
            self.script.write_text("from pathlib import Path\nimport sys\nTEMPLATE=Path(__file__).parent/"+repr(spelling)+"\n"
                "assert TEMPLATE.read_bytes()==b'test template'\nprint(sys.argv[1:])\n", encoding="utf-8")
            before = self.script.read_bytes()
            result = self.run_cli("check", "PP+", self.folder, self.folder / "Ausgabe_PDF")
            self.assertEqual(result.returncode, 0, result.stdout)
            self.assertEqual(json.loads(result.stdout), {"ok":True, "templateRepair":spelling!=pp.TEMPLATE})
            run = self.run_cli("run-pp", self.script, "--wwid", "999999", "--stichtag", "31.12.2026")
            self.assertEqual(run.returncode, 0, run.stderr)
            self.assertIn(b"999999", run.stdout)
            self.assertEqual(self.script.read_bytes(), before)
        files[2].unlink()
        result=self.run_cli("check", "PP+", self.folder, self.folder / "Ausgabe_PDF")
        self.assertEqual(result.returncode, 1)
        self.assertIn("eckwerte_runtime.py", json.loads(result.stdout)["reason"])

if __name__ == "__main__":
    unittest.main()
