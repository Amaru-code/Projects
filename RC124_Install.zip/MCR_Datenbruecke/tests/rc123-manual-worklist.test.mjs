import test from 'node:test';
import assert from 'node:assert/strict';
import {findPhase1Candidate} from '../lib/phase1-worklist-search.mjs';
import {readManuallySelectedPhase1List,readBoundWorklist} from '../lib/browser-workflow.mjs';
import {manualWorklistSelection} from '../lib/manual-worklist-selection.mjs';

const own='IN_BEARBEITUNG',queue='WARTESCHLANGE_INTL01';
const unavailable=()=>Object.assign(new Error('unbound'),{code:'INTL_SCOPE_NOT_AVAILABLE'});
const row={ticketId:'99123005',descriptionBlank:true,descriptionValue:'',source:'E-MAIL'};

test('manual failure in the own list still allows the operator to open the Intel queue',async()=>{
 const visits=[];
 const result=await findPhase1Candidate({readList:async()=>{throw unavailable();},ask:async()=>'',
  readManualList:async s=>{visits.push(s);if(s===own)throw unavailable();
   return {scope:s,ok:true,rows:[{...row,ticketId:'99123006'},row]};},processed:new Set(['99123006'])});
 assert.deepEqual(visits,[own,queue]);assert.equal(result.row.ticketId,row.ticketId);assert.equal(result.scope,queue);
});

test('manual failure on both lists keeps phase 1 incomplete; cancellation stops immediately',async()=>{
 for(const abort of [false,true]){
  const visits=[];
  const action=findPhase1Candidate({readList:async()=>{throw unavailable();},ask:async()=>'',
   readManualList:async s=>{visits.push(s);if(abort)throw Object.assign(new Error('stopped'),{code:'RUN_NOT_ARMED'});throw unavailable();},processed:new Set()});
  await assert.rejects(action,err=>abort?err.code==='RUN_NOT_ARMED':err.code==='INTL_SCOPE_NOT_AVAILABLE'&&err.navigationState.missingScopes.length===2);
  assert.deepEqual(visits,abort?[own]:[own,queue]);
 }
});

test('operator click receipt requires a stable subsequent render and is revoked after a later selection',async()=>{
 const events=[];
 let table=0,valid=true;
 const page={call:async(fn,s,op)=>{
  if(fn===manualWorklistSelection){
   events.push(op);
   switch(op){
   case 'arm': return {state:'ARMED'};
   case 'observe': return {state:'MATCHING_TABLE',sequence:1,hint:null};
   case 'retain': return {state:'BOUND',token:'test-token'};
   case 'bound': return valid;
   default: assert.fail(op);
   }
  }
  const late=++table>=2;
  return {ok:true,scope:queue,state:'READY',tableId:'mainForm:tasksTableFor_MyQueuesTasksList',render:late?'stable':'initial',rows:[late?row:{...row,ticketId:'99123007'}]};
 }};
 const result=await readManuallySelectedPhase1List(page,queue,{ask:async prompt=>{assert.match(prompt,/INTL01/);assert.deepEqual(events,['arm']);return '';}});
 assert.equal(result.rows[0].ticketId,row.ticketId);assert.equal(events.at(-1),'retain');
 assert(await readBoundWorklist(page,queue,result));valid=false;assert.equal(await readBoundWorklist(page,queue,result),null);
});
