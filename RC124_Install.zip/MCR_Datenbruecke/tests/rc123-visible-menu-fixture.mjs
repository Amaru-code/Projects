import {installLegacyMenu} from './rc122-hidden-both-fixture.mjs';

// Reconstruct the leaf-label navigation supported by RC119. The item counts and
// table family are taken from the failing run. No production DOM or data here.
export async function installVisibleMenu(page,{own=false,absent=false}={}){
 await installLegacyMenu(page,own);
 await page.call(missing=>{
  for(const [group,tag,total,name] of [
   ['storedSearchesContainer_MY_TASKS','my',26,'In_Bearbeitung'],
   ['storedSearchesContainer_MY_QUEUES','queue',22,'INTL01']
  ]){
   const container=document.getElementById(group);
   const select=document.getElementById(tag+'-child').onclick;
   container.textContent='';container.style.display='block';
   const wrapper=document.createElement('div');container.append(wrapper);
   for(let i=0;i<total-1;i++){
    const entry=document.createElement('span');
    entry.className='search-item';entry.style.cursor='pointer';entry.style.display='inline-block';
    entry.style.marginRight='4px';
    entry.textContent=i===2&&!missing?name:i===3?name+' Archiv':'Suche '+String(i+1);
    if(i===2)entry.id=tag+'-child';
    wrapper.append(entry);
   }
   wrapper.addEventListener('click',event=>{
    if(event.target.id===tag+'-child'&&!missing){select();return;}
    window.fixtureEvents.push('WRONG_MENU_ITEM');
   });
  }
 },absent);
}

export async function checkVisibleMenu(page,UI,findPhase1Candidate,assert){
 for(const own of [false,true]){
  await installVisibleMenu(page,{own});
  const unexpected=()=>assert.fail('Normal navigation must open the exact visible entry before asking or resetting');
  const selected=await findPhase1Candidate({
   processed:new Set(),readList:(s,o)=>UI.navigateToScope(page,s,o),
   findOwnTicket:unexpected,resetView:unexpected,ask:unexpected
  });
  const id=own?'99022002':'99022003';
  assert.equal(selected.scope,own?'IN_BEARBEITUNG':'WARTESCHLANGE_INTL01');
  assert.equal(selected.row.ticketId,id);
  assert.equal((await UI.openTicket(page,selected.row,{scope:selected.scope})).mode,'AUTO');
  assert.equal(await UI.detailTicketId(page),id);
  assert.deepEqual(await page.call(()=>window.fixtureEvents),own?['my-child',id]:['my-child','queue-child',id]);
 }
}

// Historic screenshot (the focus outline spans the label and a right-aligned
// plain count). The same INTL01 label appears in another, unrelated group.
export async function installCountedFilters(page,{direct=false,own=false}={}){
 await installLegacyMenu(page,own);
 await page.call(directText=>{
  const byId=id=>document.getElementById(id);
  document.querySelector('nav').insertAdjacentHTML('beforeend','<div id="storedSearchesContainer_OTHER"><a href="#">INTL01<span>72</span></a></div>');
  byId('storedSearchesContainer_OTHER').querySelector('a').onclick=()=>window.fixtureEvents.push('wrong-branch');
  for(const [group,kind,entries,wanted] of [
   ['storedSearchesContainer_MY_TASKS','my',[['Geprueft','0'],['In_Bearbeitung','10'],['PeerReview','0'],['Wiedervorlage','1']],'In_Bearbeitung'],
   ['storedSearchesContainer_MY_QUEUES','queue',[['INTL01','0'],['NichtZuordenbar','4'],['PeerReview','0']],'INTL01']
  ]){
   const container=byId(group),handle=byId(kind+'-child').onclick;
   container.style.display='block';container.textContent='';
   for(const [label,count] of entries){
    const item=document.createElement('a');
    item.href='#';item.style.display='block';item.style.width='140px';
    const icon=document.createElement('img');icon.alt='';icon.width=8;icon.height=8;item.append(icon);
    if(directText)item.append(document.createTextNode(label));
    else{const name=document.createElement('span');name.textContent=label;item.append(name);}
    const badge=document.createElement('span');badge.style.float='right';badge.textContent=count;item.append(badge);
    if(label===wanted)item.id=kind+'-child';
    item.onclick=event=>{event.preventDefault();if(label===wanted)handle();else window.fixtureEvents.push('wrong-filter');};
    container.append(item);
   }
  }
 },direct);
}

export async function checkCountedFilters(page,UI,findPhase1Candidate,assert,{direct=false}={}){
 await installCountedFilters(page,{direct});
 const unexpected=()=>assert.fail('Expected exact counted saved searches without asking, reset or row fallback');
 const choice=await findPhase1Candidate({processed:new Set(),readList:(s,o)=>UI.navigateToScope(page,s,o),findOwnTicket:unexpected,ask:unexpected,resetView:unexpected});
 assert.equal(choice.scope,'WARTESCHLANGE_INTL01');
 assert.equal(choice.row.ticketId,'99022003');
 await UI.openTicket(page,choice.row,{scope:choice.scope});
 assert.equal(await UI.detailTicketId(page),'99022003');
 assert.deepEqual(await page.call(()=>window.fixtureEvents),['my-child','queue-child','99022003']);
}
