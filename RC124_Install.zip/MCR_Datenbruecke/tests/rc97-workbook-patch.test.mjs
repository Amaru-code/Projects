import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {readZip,writeZip} from '../lib/zip.mjs';
import {parseXml,child,children,plain} from '../lib/xml.mjs';
import {readWorkbookBuffer} from '../lib/xlsx-multirow.mjs';
import {patchContactCells,replaceZipPart} from '../lib/xlsx-contact-patch.mjs';
import {readLiveWorkbook,refreshLiveWorkbook,assertLiveWorkbookCurrent} from '../lib/live-workbook.mjs';
import {lookupMultirow} from '../lib/multirow-tpp-mapping.mjs';

import {fixture,header,row,cells,sheetPart} from './rc97-workbook-fixture.mjs';
const book=b=>readWorkbookBuffer(b,'fixture.xlsx',{extended:true});
const xml=b=>parseXml(readZip(b).get(sheetPart));
const dataRow=(b,r)=>children(child(xml(b),'sheetData'),'row').find(x=>Number(x.attrs.r)===r);
const cellAt=(b,r)=>children(dataRow(b,Number(r.match(/\d+/)[0])),'c').find(c=>c.attrs.r===r);
function withDataDescriptor(bytes,part){
 const end=bytes.length-22,start=bytes.readUInt32LE(end+16),central=Buffer.from(bytes.subarray(start,end)),tail=Buffer.from(bytes.subarray(end));
 let target=null;
 for(let p=0;p<central.length;){const length=46+central.readUInt16LE(p+28)+central.readUInt16LE(p+30)+central.readUInt16LE(p+32),name=central.subarray(p+46,p+46+central.readUInt16LE(p+28)).toString();if(name===part)target={p,offset:central.readUInt32LE(p+42),packed:central.readUInt32LE(p+20)};p+=length;}
 assert.ok(target);const local=Buffer.from(bytes.subarray(0,start)),dataEnd=target.offset+30+local.readUInt16LE(target.offset+26)+local.readUInt16LE(target.offset+28)+target.packed;
 const descriptor=Buffer.alloc(16);descriptor.writeUInt32LE(0x08074b50);descriptor.writeUInt32LE(central.readUInt32LE(target.p+16),4);descriptor.writeUInt32LE(target.packed,8);descriptor.writeUInt32LE(central.readUInt32LE(target.p+24),12);
 local.writeUInt16LE(local.readUInt16LE(target.offset+6)|8,target.offset+6);local.fill(0,target.offset+14,target.offset+26);central.writeUInt16LE(central.readUInt16LE(target.p+8)|8,target.p+8);
 for(let p=0;p<central.length;){if(central.readUInt32LE(p+42)>target.offset)central.writeUInt32LE(central.readUInt32LE(p+42)+16,p+42);p+=46+central.readUInt16LE(p+28)+central.readUInt16LE(p+30)+central.readUInt16LE(p+32);}
 tail.writeUInt32LE(start+16,16);return Buffer.concat([local.subarray(0,dataEnd),descriptor,local.subarray(dataEnd),central,tail]);
}

test('RC97 workbook patch: only target worksheet bytes change; other parts and target style/metadata survive',()=>{
 const original=fixture({extraCells:'<c r="FM2" s="7" cm="4" vm="2" t="s"><v>0</v></c><c r="FO2" t="inlineStr"><is><t>Unrelated right-hand cell</t></is></c>'});
 const result=patchContactCells(original,book(original),[{ref:'FM2',value:'existing@example.invalid; new@example.invalid'},{ref:'FN2',value:'EN'}]);
 const before=readZip(original),after=readZip(result);assert.deepEqual(after.names,before.names);
 for(const name of before.names)if(name!==sheetPart)assert.ok(after.get(name).equals(before.get(name)),name);
 const fm=cellAt(result,'FM2');assert.equal(fm.attrs.s,'7');assert.equal(fm.attrs.cm,'4');assert.equal(fm.attrs.vm,'2');assert.equal(fm.attrs.t,'inlineStr');
 assert.equal(plain(child(fm,'is')),'existing@example.invalid; new@example.invalid');
 assert.equal(plain(child(cellAt(result,'FO2'),'is')),'Unrelated right-hand cell');
 assert.deepEqual(book(result).allRows().map(r=>Object.fromEntries(Object.keys(row).map(c=>[c,r[c]]))),book(original).allRows().map(r=>Object.fromEntries(Object.keys(row).map(c=>[c,r[c]]))));
});
test('RC97 workbook patch: insertion stays in numeric column order and escaped text round-trips for prefixed XML',()=>{
 const original=fixture({prefix:'s',extraCells:'<s:c r="FO2" t="inlineStr"><s:is><s:t>after</s:t></s:is></s:c>'});
 const result=patchContactCells(original,book(original),[{ref:'FN2',value:'DE'},{ref:'FM2',value:'new+tag@example.invalid & old@example.invalid'}]);
 assert.deepEqual(children(dataRow(result,2),'c').slice(-3).map(c=>c.attrs.r),['FM2','FN2','FO2']);
 assert.equal(book(result).allRows()[0].FM,'new+tag@example.invalid & old@example.invalid');
 assert.equal(book(result).allRows()[0].FN,'DE');
});
test('RC97 workbook patch: updating one source row cannot touch a second row for the same WWID',()=>{
 const original=fixture({extraCells:'<c r="FM2" t="inlineStr"><is><t>first@example.invalid</t></is></c>',rows:`<row r="3">${cells({...row,L:'20',FM:'second@example.invalid',FN:'DE'},3)}</row>`});
 const result=patchContactCells(original,book(original),[{ref:'FM2',value:'first@example.invalid; new@example.invalid'}]);
 assert.equal(book(result).allRows()[1].FM,'second@example.invalid');assert.equal(book(result).allRows()[1].FN,'DE');
});
test('RC97 workbook patch: formula, merged contact cells, sheet protection and signed packages block before producing output',()=>{
 const cases=[
  [fixture({extraCells:'<c r="FM2"><f>CONTACT()</f><v>0</v></c>'}),'WORKBOOK_CONTACT_FORMULA'],
  [fixture({suffix:'<mergeCells count="1"><mergeCell ref="FM2:FN3"/></mergeCells>'}),'WORKBOOK_MERGED_CONTACT'],
  [fixture({suffix:'<sheetProtection sheet="1"/>'}),'WORKBOOK_PROTECTED']
 ];
 for(const [input,code] of cases){const snapshot=Buffer.from(input);assert.throws(()=>patchContactCells(input,book(input),[{ref:'FM2',value:'new@example.invalid'}]),{code});assert.ok(input.equals(snapshot));}
 const input=fixture(),z=readZip(input),signed=writeZip([...z.names.map(name=>({name,data:z.get(name)})),{name:'_xmlsignatures/sig1.xml',data:'<Signature/>'}]);
 assert.throws(()=>patchContactCells(signed,book(signed),[{ref:'FM2',value:'new@example.invalid'}]),{code:'WORKBOOK_SIGNED'});
});
test('RC97 workbook patch: contacts outside a merge and unrelated formulas are preserved',()=>{
 const original=fixture({extraCells:'<c r="FP2"><f>1+1</f><v>2</v></c>',suffix:'<mergeCells count="1"><mergeCell ref="A5:O5"/></mergeCells>'});
 const result=patchContactCells(original,book(original),[{ref:'FM2',value:'a@example.invalid'}]);
 assert.equal(plain(child(cellAt(result,'FP2'),'f')),'1+1');
 assert.equal(children(child(xml(result),'mergeCells'),'mergeCell')[0].attrs.ref,'A5:O5');
});
test('RC97 workbook patch: out-of-scope cells and missing data rows are rejected',()=>{
 const original=fixture();for(const ref of ['B2','FO2','FM999','FN0'])assert.throws(()=>patchContactCells(original,book(original),[{ref,value:'x'}]));
 assert.throws(()=>patchContactCells(original,book(original),[{ref:'FM2',value:'a\u0001b'}]),{code:'WORKBOOK_WRITE_SCOPE'});
});
test('RC97 workbook patch: replaced ZIP part retains archive comment and unchanged compressed chunks',()=>{
 const original=fixture(),comment=Buffer.from('Retained fixture comment'),tail=Buffer.from(original.subarray(-22));tail.writeUInt16LE(comment.length,20);
 const input=Buffer.concat([original.subarray(0,-22),tail,comment]),z=readZip(input);
 const result=replaceZipPart(input,sheetPart,Buffer.from(z.get(sheetPart).toString().replace('Gender','Gender')));
 assert.ok(result.subarray(-comment.length).equals(comment));
 const localChunks=b=>{const zz=readZip(b),out=new Map();let offset=0;for(const name of zz.names){const nl=b.readUInt16LE(offset+26),el=b.readUInt16LE(offset+28),size=b.readUInt32LE(offset+18),end=offset+30+nl+el+size;out.set(name,b.subarray(offset,end));offset=end;}return out;};
 const before=localChunks(input),after=localChunks(result);for(const name of z.names)if(name!==sheetPart)assert.ok(before.get(name).equals(after.get(name)),name);
});
test('RC97 workbook patch: row spans and sheet dimension extend to the actual updated cells without shrinking',()=>{
 const original=fixture({dimension:'A1:O2'});
 const fm=patchContactCells(original,book(original),[{ref:'FM3',value:'new@example.invalid'}]);
 assert.equal(child(xml(fm),'dimension').attrs.ref,'A1:FM3');
 const both=patchContactCells(original,book(original),[{ref:'FM2',value:'new@example.invalid'},{ref:'FN2',value:'EN'}]);
 assert.equal(dataRow(both,2).attrs.spans,'2:170');assert.equal(dataRow(both,2).attrs.ht,'18');assert.equal(dataRow(both,2).attrs.customHeight,'1');
 const wide=fixture({dimension:'A1:XFD100'}),changed=patchContactCells(wide,book(wide),[{ref:'FM2',value:'new@example.invalid'}]);
 assert.equal(child(xml(changed),'dimension').attrs.ref,'A1:XFD100');
});
test('RC97 workbook patch: streaming ZIP data descriptors remain valid after worksheet replacement',()=>{
 const original=withDataDescriptor(withDataDescriptor(fixture(),sheetPart),'customXml/item1.xml');
 const b=book(original),result=patchContactCells(original,b,[{ref:'FM2',value:'descriptor@example.invalid'}]),before=readZip(original),after=readZip(result);
 for(const name of before.names)if(name!==sheetPart)assert.ok(after.get(name).equals(before.get(name)),name);
 assert.equal(book(result).allRows()[0].FM,'descriptor@example.invalid');
});
test('RC97 workbook patch: extra cell metadata and rich text are deferred rather than silently lost',()=>{
 const metadata=fixture({extraCells:'<c r="FM2" t="inlineStr"><is><t>old@example.invalid</t></is><extLst><ext uri="fixture"><x14:keep>metadata</x14:keep></ext></extLst></c>'});
 assert.throws(()=>patchContactCells(metadata,book(metadata),[{ref:'FM2',value:'new@example.invalid'}]),{code:'WORKBOOK_CONTACT_METADATA'});
 const rich=fixture({extraCells:'<c r="FM2" t="inlineStr"><is><r><rPr><b/></rPr><t>old@example.invalid</t></r></is></c>'});
 assert.throws(()=>patchContactCells(rich,book(rich),[{ref:'FM2',value:'new@example.invalid'}]),{code:'WORKBOOK_CONTACT_RICH_TEXT'});
});
test('RC97 workbook patch: malformed, duplicate or out-of-grid updates are rejected before merge parsing',()=>{
 const original=fixture({suffix:'<mergeCells count="1"><mergeCell ref="FM2:FN3"/></mergeCells>'});
 for(const ref of ['nonsense','FM0','FN1048577','FM01','FM2:FN2'])
  assert.throws(()=>patchContactCells(original,book(original),[{ref,value:'x'}]),{code:'WORKBOOK_WRITE_SCOPE'});
 assert.throws(()=>patchContactCells(original,book(original),[{ref:'FM2',value:'x'},{ref:'FM2',value:'y'}]),{code:'WORKBOOK_WRITE_SCOPE'});
 assert.ok(patchContactCells(original,book(original),[]).equals(original));
});
test('RC97 workbook source: contact-only updates keep the active snapshot hash, business changes invalidate it',()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'mcr97-book-'));
 try{
  const file=path.join(dir,'stock.xlsx');fs.writeFileSync(file,fixture());fs.mkdirSync(path.join(dir,'config'));
  fs.writeFileSync(path.join(dir,'config/local-runner-queue-send.json'),JSON.stringify({stockWorkbookPath:file}));
  const first=refreshLiveWorkbook(dir);const entry=lookupMultirow(first.map,'99900001');
  assert.equal(entry.rowCount,2);assert.deepEqual(entry.descriptionLines,['USC 10/ DC;TPP;JUB;ZW','USC 20/ DC;TPP;JUB;ZW']);
  const live=readLiveWorkbook(file),updated=patchContactCells(live.bytes,live.book,[{ref:'FM2',value:'a@example.invalid'},{ref:'FN2',value:'DE'}]);
  fs.writeFileSync(file,updated);assert.equal(assertLiveWorkbookCurrent(dir,first).businessSha256,live.businessSha256);
  const second=refreshLiveWorkbook(dir);assert.equal(second.fileHash,first.fileHash);assert.equal(second.path,first.path);
  fs.writeFileSync(file,fixture({values:{...row,H:'1'}}));
  assert.throws(()=>assertLiveWorkbookCurrent(dir,first),{code:'WORKBOOK_DATA_CHANGED'});
  const third=refreshLiveWorkbook(dir);assert.notEqual(third.fileHash,first.fileHash);assert.match(lookupMultirow(third.map,'99900001').description,/JUB;UEB;ZW/);
  fs.unlinkSync(file);assert.throws(()=>assertLiveWorkbookCurrent(dir,third),{code:'WORKBOOK_UNAVAILABLE'});
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
