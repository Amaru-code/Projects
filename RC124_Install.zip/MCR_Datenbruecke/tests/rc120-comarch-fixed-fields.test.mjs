import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {fixedOptionSnapshot,openFixedSuggestions} from '../lib/comarch-option.mjs';
import {COMARCH_FIELD_IDS} from '../lib/comarch-fixed-fields.mjs';
import Prep from '../lib/ticket-prep.cjs';

function popupFixture(field='signature'){
 const elements=[];let hit=null;
 const fieldRect={left:20,right:350,top:120,bottom:145};
 const menuRect={left:30,right:360,top:150,bottom:180};
 function element(tag,{id='',attrs={},text='',rect=menuRect,position='static',parent=null}={}){
  const n={tag,id,attrs,rect,position,children:[],parentElement:parent,isConnected:true,scrolls:0,
   getAttribute(a){return this.attrs[a]??null;},getClientRects(){return this.hidden?[]:[this.rect];},
   getBoundingClientRect(){return this.rect;},scrollIntoView(){this.scrolls++;},get firstElementChild(){return this.children[0];},
   get innerText(){return text||this.children.map(c=>c.innerText).join('\t');},
   get textContent(){return this.innerText;},
   contains(x){return !!x&&(x===this||this.children.some(c=>c.contains(x)));},
   matches(selector){return selector.split(',').some(raw=>{
    const q=raw.trim().replace(/^:scope > /,'');
    if(q==='*'||q===this.tag)return true;
    if(q.startsWith('.'))return (this.attrs.class||'').split(' ').includes(q.slice(1));
    const exact=/^\[([\w-]+)="([^"]+)"\]$/.exec(q);
    if(exact)return this.attrs[exact[1]]===exact[2];
    const subset=/^\[([\w-]+)\*="([^"]+)"(?: i)?\]$/.exec(q);
    if(subset)return (subset[1]==='id'?id:this.attrs[subset[1]]||'').toLowerCase().includes(subset[2].toLowerCase());
    return false;
   });},
   closest(selector){for(let p=this;p;p=p.parentElement)if(p.matches(selector))return p;return null;},
   querySelectorAll(selector){const direct=selector.includes(':scope >');return elements.filter(e=>e!==this&&
    (direct?e.parentElement===this:this.contains(e))&&e.matches(selector));},
   querySelector(selector){return this.querySelectorAll(selector)[0]||null;}
  };
  parent?.children.push(n); elements.push(n); return n;
 }
 const doc={defaultView:{innerWidth:1200,innerHeight:900,getComputedStyle:n=>({visibility:'visible',display:'block',position:n.position})},
  querySelectorAll:s=>elements.filter(n=>n.matches(s)),getElementById:id=>id?elements.find(n=>n.id===id)||null:null,elementFromPoint:()=>hit};
 doc.body=element('body');
 const input=element('input',{id:COMARCH_FIELD_IDS[field],rect:fieldRect,parent:doc.body});
 doc.activeElement=input;
 const context=vm.createContext({document:doc});
 const keys=[];
 const page={call:async(fn,...args)=>{context.args=args;return vm.runInContext('('+fn.toString()+')(...args)',context);},
  cdp:{send:async(method,p)=>keys.push([method,p.key,p.type])},sessionId:'fake'};
 return {doc,input,page,keys,element,hit(n){hit=n;},snapshot(opts){return fixedOptionSnapshot(page,input.id,Prep.FIXED[field],opts);}};
}
test('RC120 signature: detached ARIA-owned AJAX grid splits code and name into columns; only the owning row is clicked',async()=>{
 const h=popupFixture();h.input.attrs['aria-controls']='jsf:generatedPopup';
 const menu=h.element('div',{id:'jsf:generatedPopup',attrs:{role:'grid'},parent:h.doc.body,
  rect:{left:180,right:520,top:600,bottom:640}});
 const row=h.element('tr',{parent:menu});const code=h.element('td',{text:'INTL01',parent:row});
 h.element('td',{text:'Intel Deutschland GmbH',parent:row});
 const unrelated=h.element('div',{id:'other',attrs:{role:'listbox'},parent:h.doc.body});
 h.element('li',{text:Prep.FIXED.signature,parent:unrelated});
 h.hit(code);const result=await h.snapshot();
 assert.equal(result.points.length,1);assert.equal(result.points[0].method,'OWNED_POPUP_OPTION');
});
test('RC120 field-owned popup resolves an untagged delegated category item with nested highlights and tooltip',async()=>{
 const h=popupFixture('category');h.input.attrs['aria-controls']='list';
 const box=h.element('div',{id:'list',attrs:{role:'listbox'},parent:h.doc.body});
 const row=h.element('div',{parent:box,attrs:{title:'Kategorie auswählen'}});const text=h.element('span',{text:Prep.FIXED.category,parent:row});
 h.element('div',{text:Prep.FIXED.category+' – Sonderfall',parent:box});h.hit(text);
 assert.equal((await h.snapshot()).state,'EXACT_OPTION');
});
test('RC120 bound subcategory never selects a matching substring inside a liability option',async()=>{
 const h=popupFixture('subcategory');h.input.attrs['aria-controls']='list';
 const box=h.element('div',{id:'list',attrs:{role:'listbox'},parent:h.doc.body});
 const row=h.element('li',{parent:box});const partial=h.element('span',{text:Prep.FIXED.subcategory,parent:row});
 h.element('span',{text:' - potenzieller Haftungsfall',parent:row});h.hit(partial);
 assert.equal((await h.snapshot()).points.length,0);
});
test('RC120 active field cannot borrow a neighbouring field’s popup during replacement',async()=>{
 const h=popupFixture(); h.input.attrs['aria-controls']='unmounted';
 const other=h.element('input',{id:COMARCH_FIELD_IDS.category,parent:h.doc.body,attrs:{'aria-owns':'other'}});
 const menu=h.element('div',{id:'other',attrs:{role:'listbox'},parent:h.doc.body});
 h.hit(h.element('li',{text:Prep.FIXED.signature,parent:menu}));
 assert.equal((await h.snapshot()).points.length,0);
 delete h.input.attrs['aria-controls'];assert.equal((await h.snapshot()).points.length,0);
 assert.ok(other);
});
test('RC120 two equal options, a different tenant, or an overlay yield no click',async()=>{
 const h=popupFixture(); h.input.attrs['aria-controls']='list';
 const box=h.element('div',{id:'list',attrs:{role:'listbox'},parent:h.doc.body});
 const first=h.element('li',{text:Prep.FIXED.signature,parent:box}),second=h.element('li',{text:Prep.FIXED.signature,parent:box});
 h.hit(first); assert.equal((await h.snapshot()).state,'MULTIPLE_EXACT_OPTIONS');
 second.hidden=true;h.hit(null);assert.equal((await h.snapshot()).state,'OPTION_OCCLUDED');
 first.hidden=true;h.hit(h.element('li',{text:'INTL02 - Intel Deutschland GmbH',parent:box}));
 assert.equal((await h.snapshot()).points.length,0);
});
test('RC120 opens a collapsed focused widget using ArrowDown; it never sends Enter',async()=>{
 const h=popupFixture();assert.equal(await openFixedSuggestions(h.page,h.input.id),true);
 assert.deepEqual(h.keys.map(k=>k.slice(1)),[['ArrowDown','rawKeyDown'],['ArrowDown','keyUp']]);
 h.doc.activeElement=h.doc.body;assert.equal(await openFixedSuggestions(h.page,h.input.id),false);assert.equal(h.keys.length,2);
});

test('RC120 delegated single untagged option with a disqualifying suffix cannot split into individual choices',async()=>{
 const h=popupFixture('subcategory');h.input.attrs['aria-controls']='list';
 const box=h.element('div',{id:'list',attrs:{role:'listbox'},parent:h.doc.body});
 const row=h.element('div',{parent:box});const partial=h.element('span',{text:Prep.FIXED.subcategory,parent:row});
 h.element('span',{text:' - potenzieller Haftungsfall',parent:row});h.hit(partial);
 assert.equal((await h.snapshot()).points.length,0);
});
