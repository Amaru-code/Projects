# RC124 für MCR Datenbrücke

## Ein Dokumentticket aus Menü 4 bearbeiten

| Eingabe beim Start von Phase 2 | Ergebnis |
|---|---|
| `AO` | Liest die sichtbare eigene Liste und bearbeitet höchstens einen geeigneten reinen AO-Auftrag. Ein neuer Auftrag hat Vorrang vor der Wiederaufnahme eines früher begonnenen. |
| `AO <COMARCH-Ticketnummer>` | Bearbeitet genau diesen Vorgang, sofern er eine Auszahlungsoption anfordert. Bei einem kombinierten Auftrag werden zuerst die benötigten Kontoauszüge vorbereitet. |
| `DC <COMARCH-Ticketnummer>` | Prüft für genau diesen Vorgang die kanonische DC-PDF im zentralen Ordner Ausgabe_PDF. Fehlt die Datei, startet die reguläre Erzeugung. Bei kombinierten Aufträgen gelten alle Dokumentanforderungen. |
| Nur eine Ticketnummer | Beginnt wie bisher mit diesem Ticket und sucht danach weitere geeignete Vorgänge. |
| Enter | Bearbeitet wie bisher die passenden sichtbaren eigenen Vorgänge. |

Die Einzelauswahl startet den produktiven Phase-2-Ablauf bis zur vorgesehenen internen Weiterleitung. Phase 2 verschickt keine E-Mail. Für ein Ticket mit Uploadjournal bestimmt der belegte Stand den nächsten Schritt. Ein fachlicher AO-Prüfvermerk bleibt wirksam. Im Menü 4 zeigt `P2_NAECHSTES_TICKET` den ausgewählten Auftrag. Gibt es nur kombinierte AO-Aufträge, zeigt der Bot die entsprechenden Ticketnummern bei der Suche mit `AO` an.

### Auszahlungsoption

Bei einem neuen AO-Auftrag bindet der Bot den COMARCH-Member und die WWID, ruft den zentralen Generator für den Stichtag auf und prüft die neu erzeugte PDF und den Auditnachweis. Fordert der Generator eine fehlende Adresse oder PLZ an, erscheint die Eingabe im laufenden Terminal. Bei einem fachlichen Berechnungsfehler nennt das Laufprotokoll den verfügbaren Grund. Wird im selben Lauf zunächst ein anderes Ticket bearbeitet, belegt der Inventurzähler allein noch keinen Generatorstart.

### DC-Kontoauszug

Der Bot prüft den Abschlussbeleg auch dann, wenn die Standardausgabe des Generators verzögert oder umgeleitet wird. Sobald der primäre Export und sein Abschluss belegt sind, kann die Uploadvorbereitung parallel zur optionalen Personenordner-Kopie fortfahren. Ein frisch erzeugter kanonischer Auszug kann auch nach regulärem Prozessende mit Exit-Code 0 zugeordnet werden, wenn der Generator keinen Dateipfad ausgegeben hat und die beschriftete WWID und der vollständige Name im Dokument bestätigt werden. Ist nur die Datei sichtbar, zeigt das Protokoll den noch offenen Abschluss.

Für einen Auszug aus einem früheren Versuch nutzt die gezielte Eingabe `DC <COMARCH-Ticketnummer>` die im Ticket gebundene WWID. Im zentralen Ordner prüft der Bot `<WWID>_Kontoauszug_DC.pdf`. Bei einem aktiven DC-Schreiber bleibt die Datei zur Prüfung offen. Vor der Übernahme prüft der Bediener den Inhalt, Namen, WWID und Abrechnungszeitraum. Der Bot bindet die bestätigten Dateibytes per SHA-256 an den Upload. Die Anzeige in COMARCH und die Prüfung nach dem Ticketspeichern sind eigene Schritte.

## Ticketliste, MBC und Startdauer

- Nach dem Versandpilot erkennt die Listenprüfung weitere eindeutige leere Ergebnisdarstellungen. Sie prüft die zugehörige aktive Liste und die Tabellenstruktur. Bei weiterhin unklaren Zeilen stehen Tabellen-ID und Strukturmerkmale im Protokoll. Nach einer kurzen ersten Prüfung bleibt bei langsamem Aufbau Zeit zur Wiederholung.
- Im Feld für die Geschäfts­vorfallsart sucht Phase 2 den exakten Vorschlag „Anfrage Member“ und überprüft die Auswahl. Das gilt für den MBC-Entwurf und den Dokumentablauf.
- Nach einem ausgelösten Speicherschritt prüft der Bot den Serverzustand im selben Bot-Tab. Falls die Menüansicht durch die Ticketansicht verdeckt ist, kann er die konfigurierte Vorgangsliste neu laden, das gebundene Ticket erneut öffnen und die Felder abgleichen. Ein früheres MBC-Journal mit beobachtetem Speicherversuch begrenzt die Wiederaufnahme auf den Nachweis, solange dieser offen ist.
- Die Startvorbereitung vermeidet eine direkt aufeinanderfolgende Windows-Prozessabfrage. Im eigenständigen Menü 4 schützt die erworbene Laufsperre auch die Bestandsvorbereitung. Bei einer Excel-Besitzerdatei spart der Bot das Erzeugen neuer XLSX-Dateibytes für eine zurückzustellende Kontaktänderung. Das Protokoll nennt die gemessene Zeit für Bestand und Kontakte, Browserbindung und Lesen der Phase-2-Liste.

## Installation

`RC124_Install.zip` außerhalb der vorhandenen Installation entpacken. Die entpackte `MCR_Datenbruecke\START.cmd` starten, Menü **1** wählen und die vorhandene Installation als Ziel übernehmen. Nach `PASS INSTALLATION_COMPLETE` die installierte `START.cmd` mit dem Menütitel **0.8.1-rc.124** verwenden.
