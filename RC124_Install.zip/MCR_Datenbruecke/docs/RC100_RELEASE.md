# RC100 – Member-Suchtext stabil prüfen und begrenzt wiederherstellen

Version **0.8.1-rc.100**, 19. November 2026. Grundlage: das gelieferte RC99-Paket.

## Befund

Im gemeldeten RC99-Lauf öffnete sich das eigene Botfenster erfolgreich. Der weitere Abbruch betraf die Eingabe in die Member-Suche.

RC97 hatte den vollständigen Eingabeweg aus RC96 durch einen nativen Weg ersetzt, der zunächst den Suchtext bis auf das letzte Zeichen und anschließend das letzte Zeichen schreibt. Die abschließende Prüfung koppelte den exakten Suchtext außerdem an den fortbestehenden Fokus im Feld. Wenn COMARCH den Fokus nach der Eingabe verlagerte, konnte dadurch selbst der bereits vollständig übernommene Suchtext als nicht bestätigt gelten. Eine tatsächlich unvollständige Eingabe wurde ebenfalls nicht ausreichend begrenzt wiederhergestellt.

## Änderung der Suche

RC100 bindet die Eingabe weiterhin an das konkrete Ticket und das eindeutig geprüfte Suchfeld. Nach der Eingabe zählt ein stabiler, exakter Rücklesewert. Der Fokus muss für den Eingriff passen; ein späterer Fokuswechsel allein macht einen nachgewiesenen Suchtext nicht falsch.

Falls der Suchtext wirklich unvollständig bleibt, gibt es höchstens drei kontrollierte Eingabewege:

1. Reguläre native Texteingabe.
2. Vollständige native Eingabe des Suchtexts in das erneut geprüfte Feld.
3. Eingeschränkter Kompatibilitätsweg für den vollständigen Text, angelehnt an RC96.

Vor einem erneuten Eingriff werden Ticketbindung, Suchfeld und aktueller Inhalt geprüft. Automatische Wiederholungen überschreiben keine fremden Inhalte und kein bereits ausgewähltes Personenprofil. Eine ausdrücklich gewählte neue Suche per Namensnummer, WWID oder MercerID darf den schon vor dem Fokussieren vorhandenen, unveränderten Member-Suchfeldwert ersetzen. Das gilt nur für den ersten Eingabeweg mit bestätigter Ticketbindung; eine währenddessen geänderte Auswahl wird nicht überschrieben. Die Begrenzung verhindert eine endlose Eingabeschleife. Namen sowie Suchanfragen mit WWID beziehungsweise MercerID verwenden denselben reparierten Weg.

Die Bestätigung des Suchtexts wählt noch keine Person aus und erteilt keine Versandfreigabe. Die bisherigen Nachweise für das tatsächlich ausgewählte Memberprofil, Namen, MercerID, WWID-Zuordnung und erforderliche manuelle Identitätsprüfung bleiben erhalten.

## Einzelnes Ticket offenlassen

Bleibt die bekannte Suchstörung trotz der begrenzten Eingabewege bestehen, kann der Bot `MEMBER_QUERY_REVIEW_REQUIRED` mit einem passenden Nachweis erzeugen. Dieser Nachweis ist nur gültig, wenn die Störung auf die gebundene Suche begrenzt blieb und keine ungeklärte Ticketaktion begonnen wurde.

Dann bleibt dieses eine Ticket ohne Versand, Speicherung oder Weiterleitung offen, und der Lauf kann mit dem nächsten geeigneten Ticket fortfahren. Der Bot meldet den offenen Fall. Ein unbekannter Fehler, eine veränderte Ticketbindung, ein fremder Feldinhalt oder eine unsichere bereits begonnene Aktion erhält dadurch keine pauschale Fortsetzungsfreigabe.

Wird ein Runnerfehler an den Master weitergegeben, bleiben der ursprüngliche Fehlercode und die Ursache sichtbar. `LIVE_NOT_VERIFIED` soll einen verfügbaren konkreten Fehler nicht verdecken.

## Wiederanlauf und bestehende Funktionen

Der vorhandene Wiederanlauf verwendet weiterhin die bisherigen Nachweise für beendete Prozesse und den Zustand des alten Laufs. Ungeklärte frühere Versandabsichten bleiben unverändert im Journal und vom automatischen Neuversand ausgeschlossen. RC100 setzt keine solchen Vorgänge auf erledigt oder erneut versendbar. Für die Reparatur ist keine Erweiterung dieser Wiederanlauffreigaben vorgesehen.

Der Browserstart mit ausdrücklich erzeugter Seite aus RC99 bleibt erhalten. Ebenso bleiben die automatische XLSX-Prüfung beim installierten Programmstart, die erneute Quellenprüfung vor Menü 3/4/5, die getrennte FM/FN-Kontaktpflege und die ENTER-Bestätigungen aktiv. Menü 2 bleibt optionale Wartung.

## Installation

`RC100_Install.zip` vollständig außerhalb der vorhandenen Installation entpacken. Die darin enthaltene `MCR_Datenbruecke\START.cmd` öffnen, Menü **1** wählen und die vorhandene Installation als Ziel übernehmen. Nach `PASS INSTALLATION_COMPLETE` muss das installierte Hauptmenü **0.8.1-rc.100** anzeigen. Anschließend kann Menü **5** mit **ENTER** gestartet werden.

Das Update ersetzt Software und bewahrt private_data, Konfiguration, Browserprofil und bisherige Laufjournale. Die Einrichtung versendet keine Nachrichten. Das zugelassene RC99-Manifest ist fest an diesen SHA-256-Wert gebunden:

```text
6238414a74e00a2a7c1c77cd62907a36ab65af0aa251474df12d4a85bef3abee
```

Auch die bereits zugelassenen Vorgänger einschließlich RC96, RC97 und RC98 bleiben mit ihren ursprünglichen Manifest- und Programmdateiprüfungen unterstützt.

## Prüfung und praktische Grenze

Die ausgeführte Offline-Auswahl umfasst 46 Module und 510 Tests: 505 bestanden, keine fehlgeschlagen, fünf native Windows-Tests auf Linux übersprungen. Darin sind die 39 neuen RC100-Tests enthalten. Alle vier Updates von den gelieferten Originalpaketen RC96, RC97, RC98 und RC99 samt jeweiligem Rückweg bestanden; drei Manipulationsfälle wurden ohne Zieländerung abgewiesen. Einzelheiten und Prüfgrenzen stehen in `RC100_Pruefbericht.txt` und `RC100_QA.json`.

20 Module mit echtem Browserstart wurden wegen der hier nicht verfügbaren Chromium-Ausführung nicht ausgeführt und bleiben im Paket enthalten. Der vollständige produktive Windows-/COMARCH-Lauf wird durch die Offline-Prüfung nicht nachgewiesen.

Die reale RC100-Prüfung auf dem Windows-/COMARCH-System des Anwenders steht bei Erstellung des Releases aus. Lokale Testfälle verwenden synthetische Daten; für die Entwicklungsprüfung werden keine Kundennachrichten versendet und keine Kundentickets bearbeitet.
