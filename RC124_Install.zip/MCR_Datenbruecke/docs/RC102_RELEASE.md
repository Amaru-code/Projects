# MCR DATENBRUECKE 0.8.1-rc.102 – BAT-Pfade / AO / UVA

Stand: 19.11.2026. Diese Version baut unmittelbar auf RC101 auf.

## Vorgabe und implementierte Pfade

Alle vier Generator-Startdateien sind **absolute, fest hinterlegte K:-Pfade**. Sie liegen nun unter:

`K:\INTL01\6_AU (Admin)\Berechnungen - UV & Renten (PP+, DC+)`

| Dokument | BAT-Pfad |
|---|---|
| Auszahlungsoption (AO) | `K:\INTL01\6_AU (Admin)\Berechnungen - UV & Renten (PP+, DC+)\Auszahlungsoption\START_Auszahlungsoption.bat` |
| Unverfallbarkeitsauskunft (UVA PP+) | `K:\INTL01\6_AU (Admin)\Berechnungen - UV & Renten (PP+, DC+)\UVA PP+\START_UVA_PP.bat` |
| Kontoauszug PP+ | `K:\INTL01\6_AU (Admin)\Berechnungen - UV & Renten (PP+, DC+)\Kontoauszug_PP+\START_KONTOAUSZUG.bat` |
| Kontoauszug DC | `K:\INTL01\6_AU (Admin)\Berechnungen - UV & Renten (PP+, DC+)\Kontoauszug_DC\START_KONTOAUSZUG_DC.bat` |

Die Schreibweise `Kontoauszug_PP+` auf K: ist bewusst **anders** als der lokale Verzeichnisname `Kontoauszug_pp+`.

## Was sich an den Laufwegen ändert

- Für fehlende DC-, PP+- oder AO-Ausgaben wird nun der jeweilige fest hinterlegte BAT-Generator herangezogen. Ein exakt verifizierter, bereits vorhandener PDF-Ausdruck wird **nicht** erneut generiert.
- RC101 übersprang die AO-Generatorausführung grundsätzlich. RC102 behandelt AO auf demselben begrenzten Generatorweg wie DC/PP+.
- Die WWID wird nur bei einer durch direkte BAT-Inspektion bestätigten eindeutigen `%1`-Schnittstelle oder genau einer `set /p`-WWID-Abfrage automatisch übergeben. Unbekannte GUI-/Mehrfach-Prompts dürfen nicht erraten werden. Ein BAT-Aufruf ist **kein** Beleg für ein erzeugtes PDF.
- Die bestehenden, früher bestätigten **lokalen PDF-Ausgabeordner** bleiben unabhängig von den BAT-Pfaden bestehen:
  - `...\Ticket_bot\Kontoauszug_DC\Ausgabe_PDF`
  - `...\Ticket_bot\Kontoauszug_pp+\Ausgabe_PDF`
  - `...\Ticket_bot\Auszahlungsoption\Ausgabe PDF`
- Ein neues Output-Verzeichnis für die vier K:-Generatoren wurde nicht geliefert. RC102 ändert daher keine PDF-Dateisuche auf ein nicht bestätigtes K:-Ausgabeverzeichnis.
- UVA ist als vierter fest erlaubter BAT-Generator registriert und wird in der lokalen Inventur ausgewiesen. **Kein automatischer UVA-Ticketauftrag/Upload** ohne bestätigtes UVA-PDF-Ausgabeformat, -Verzeichnis und Namens-/WWID-Regeln. Bis dahin ist keine generierte UVA-Datei als automatisch zuordnungsfähig anzunehmen.
- Sicherheit unverändert: strenge WWID-/Personenbindung, PDF-Dateisignatur, Mehrdeutigkeitskontrolle, Inhaltsfreigabe, keine ungeprüften E-Mail-Sendungen und keine Wiederholung unklarer Tickets.

## Installation

1. `RC102_Install.zip` in einen neuen, separaten Ordner entpacken.
2. `MCR_Datenbruecke\START.cmd` aus der neuen ZIP starten, Menü 1 wählen und die bestehende Installation als Ziel übernehmen.
3. `PASS INSTALLATION_COMPLETE` sowie die Menüversion `0.8.1-rc.102` abwarten. Danach nur die installierte START.cmd verwenden.
4. Der Rechner muss beim Echtlauf K: sehen und die vier Startdateien lesen dürfen. Das K:-Laufwerk muss im **selben Windows-Benutzerkontext** wie der Bot verbunden sein.

Die Installation verwendet wie zuvor ausschließlich den verifizierten Softwaretausch; Konfiguration, private_data, Browserprofil und Ticketjournale werden nicht überschrieben. Das Update selbst versendet keine E-Mails.

## Prüfgrenze

Der BAT-Dateiinhalt auf dem K:-Laufwerk lag dem Testsystem nicht vor. Die Pfade, WWID-Absicherung, sichere Aufrufkonstruktion, AO-Generatoranbindung, Ausgabe- und Integritätsprüfung sind offline testbar; reale BAT-Dialoge, tatsächlicher PDF-Ausgabeort und COMARCH-Browserbearbeitung müssen am Windows-Arbeitsplatz mit beaufsichtigtem Pilot geprüft werden.
