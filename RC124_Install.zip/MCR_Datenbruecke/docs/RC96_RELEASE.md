# RC96 · Fahrplan-Vollbild (anzeigeseitig)

## Zweck

Der Fahrplan kann den gesamten Monitor exklusiv nutzen. Neben Titel, aktueller Phase und Station erscheinen Zoomschritte, eine Einpassen-Funktion und der direkte Ausgang aus dem Vollbild.

## Technischer Umfang

- Bestehende RC95-Stationskarte und zwölf Mermaid-Originaldiagramme unverändert.
- Nur HTML/CSS und lokaler rein lesender Steuerteil der Kartenansicht geändert.
- Keine Änderung an P1-/P2-Prozessen, COMARCH-Browsersteuerung, Versand, Speicherung oder Review.
- Wechsel in native Browser-Fullscreen-Ansicht mit CSS-Fallback, ESC, eigener Schließen-Taste.
- Lesbarkeit: Großansicht mit Vergrößerung oder gesamte Stationskarte per Einpassen; gleichzeitige Volltext-Lesbarkeit aller Originalknoten ist physisch nicht möglich.

## Einschränkung

Ein bestätigter lokaler Chromium-UI-Test ersetzt keinen Test im Unternehmens-Edge bzw. einen Live-Lauf mit COMARCH.
