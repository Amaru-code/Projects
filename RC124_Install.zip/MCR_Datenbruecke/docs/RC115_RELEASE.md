# RC115 – getrennte Master-Excel-Zugriffe

Basis: RC114. Gezielte Aenderungen an AO-Adapter, Schreibdiagnose und Auswahllogik bei Schreibsperren. Kein Austausch der zentralen Berechnungsformeln, COMARCH-Versand- oder Uploadlogik. Reine AO mit vollstaendigen Kontaktfeldern sind bei belegtem Vorab-Schreibfehler weiterhin moeglich; ungeklaerte Saves bleiben gesperrt. Alte PDFs sind kein Ersatz fuer einen neuen AO-Auftrag.

Installation: RC115_Install.zip separat entpacken, START.cmd, Menue 1, vorhandene RC114-Installation uebernehmen. PASS INSTALLATION_COMPLETE und rc.115 pruefen. Danach Menue 4; fuer den reinen AO-Test zuerst Ticket 89664431 (vollstaendige Kontaktdaten aus vorigem erfolgreichen Generatorlauf sind wahrscheinlich, aber erneut zu pruefen), fuer den Kontakt-Schreibtest 90102357. Keine fremden Excel-Prozesse beenden, keine Besitzerdatei loeschen.
