# RC109 – Dokumenttypen und Generatorvertrag

Ausgehend von RC108, 24.11.2026. Nur lokale Bot-Software; keine Änderung an den Berechnungsformeln, dem zentralen Python-Skript, BAT-Dateien oder an der produktiven Excel-Datei.

## AO-Schnittstelle

Der Bot ruft `tools/ao-generator-bridge.py` mit dem zentralen, unveränderten `auszahlungsoption_generator.py`, `--wwid`, `--stichtag`, `--non-interactive`, Request-ID und geprüftem Skript-Hash auf. Python/pywin32 wird vorher geprüft. `lookup_person` des zentralen Skripts liest den IPP-Datensatz aus dem Gesamtdatenbestand. Beide Kontaktfelder werden mit der originalen Missing-Value-Regel geprüft. Bei fehlenden Feldern wird `create_pdf` nicht aufgerufen. Bei der eigentlichen Berechnung erfolgt eine zweite Personensuche mit Abgleich gegen den ersten Datensatz. Eingabeaufforderungen und Kontakt-Schreibfunktionen werden im Bot-Aufruf blockiert; der zentrale manuelle Aufruf bleibt unverändert. Status BLOCKED (Exit 2, missing_fields), SUCCESS (Exit 0 mit proof), FAILED (Exit 1, Timeout-Sonderfall Exit 4). Technische Fortschrittsmeldungen sind keine Erfolgsnachweise. Maximal 15 Minuten Standard-Watchdog für einen Generatorlauf; kein blindes Wiederholen.

Erfolg erfordert den gebundenen Prozessbeleg, passenden Erfolgs-Audit, WWID/Name/Stichtag und technisch geprüfte PDF samt SHA-256. Die fachliche Kontrolle bleibt bei Mark. Quellenhashes von Master, Kontrollmappe und zentralem Skript sowie nach Speichern der Arbeitsdatei und Datensatznummer werden für spätere Wiederaufnahme gebunden, wenn stabil lesbar. Wiederverwendung verlangt einen ticketgebundenen Beleg, unveränderten Member-/Bestandsfingerabdruck, eindeutige PDF, keine neueren Audits für die WWID und vollständige unveränderte Quellenbelege; bei fehlender/abweichender Quellenevidenz bleibt fachliche Prüfung nötig. Die bestehenden Alters- und Stichtagsgrenzen bleiben erhalten. Eine ältere ungebundene Datei wird nicht überschrieben. Hashgleichheit belegt unveränderte Dateien, nicht die fachliche Richtigkeit der Berechnung. Änderungen anderer Personen in diesen gemeinsamen Dateien können deshalb zusätzliche Prüfung erforderlich machen.

## DC/PP+/UVA

Kein unbestätigter START-BAT-Aufruf im automatischen PDF-Vorbereitungsweg. Bereits vorhandene eindeutige DC-/PP+-PDFs unterliegen weiterhin der Inhalts-/Zuordnungsprüfung. Fehlende, mehrdeutige oder ungültige PDFs blockieren nur den Fall vor Schreibbeginn. Bei kombinierten Anfragen zuerst Kontoauszüge prüfen, dann ggf. AO berechnen. Für einen nicht-interaktiven DC-/PP+-Generator braucht es den tatsächlichen Python-/PowerShell-/Makro-Einstieg, erforderliche Argumente, Interpreter, Fehler- und Auditformat und bestätigten Ausgabeordner. UVA bleibt nicht automatisch eingebunden. Keine vermuteten Argumente an unbekannte Programme übergeben.

## Karte

26 aktuelle Fahrplanstationen; AO eigener Zweig, KA+AO Kombination. Auszahlungsoptionen in der Ticketansicht und in der Statusausgabe getrennt. Historische Originaldiagramme (341 Knoten) bleiben als Referenz erhalten. Live-Karte bleibt reine Anzeige und zeigt nur belegte Ereignisse. Alte Browserkarte nach Update neu öffnen (Menü M).

## Betrieb

Softwareupdate über START.cmd, Menü 1, anschließend installierte START.cmd. Phase 2 weiterhin ohne Kunden-E-Mail. Bereits begonnene/ungeklärte COMARCH-Schreibaktionen dürfen nicht wiederholt werden. Stammdatenfälle werden ohne Upload/Speicherung/Weiterleitung zurückgestellt; der Lauf geht weiter. Bestandsdaten und Protokolle werden nicht gelöscht.
