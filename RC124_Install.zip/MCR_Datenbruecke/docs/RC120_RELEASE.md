# MCR Datenbrücke 0.8.1-rc.120

## Installation und gezielter Test

Das ZIP in einen eigenen Ordner außerhalb der Installation entpacken. Dort `MCR_Datenbruecke\START.cmd` öffnen und Menü 1 auswählen. Der Installer prüft die bisherige Software und zeigt die Zielversion an. Nach `PASS INSTALLATION_COMPLETE` gilt die `START.cmd` der aktualisierten Installation. Menü 4 startet Phase 2. Dort lässt sich ein einzelnes Startticket angeben. Menü 5 startet den Master-Lauf und kann in Phase 1 echte Standardantworten versenden.

## Kategorie, Unterkategorie und Signatur

Die gemeinsame Auswahl steht in `lib/comarch-fixed-fields.mjs`. Sie bedient die Felder für Versand, interne Weiterleitung und die betreffenden Phase-2-Schritte. `lib/comarch-option.mjs` ordnet die Vorschlagsliste ihrem Feld zu. Es unterstützt beschriftete Popups und das ältere Layout mit einer direkt am aktiven Feld geöffneten Tabelle. Bei einer in zwei Zellen dargestellten Signatur werden Kennung und Firmenname gemeinsam verglichen. Während COMARCH das Feld neu zeichnet, wartet der Bot auf einen eindeutigen Treffer. Anschließend prüft er Klickziel und übernommenen Feldwert. Ein verdeckter, fremder oder mehrdeutiger Vorschlag führt zur Sichtprüfung.

## Phase 1 nach einem abgeschlossenen Pilot-Ticket

Beim Suchen des nächsten Tickets prüft der Bot die Knoten `In_Bearbeitung` und `INTL01` in ihren vorgesehenen Listenabschnitten. Einen eindeutig zugehörigen, zugeklappten Abschnitt kann er öffnen. Er wartet auf den Tabellenwechsel und liest auch mehrere sichtbare Tabellenkörper. Bei einem fehlenden Knoten kann er die Ansicht im selben Bot-Tab neu laden. Falls COMARCH den Knoten weiterhin verborgen hält, lässt sich die begonnene Suche nach dem Sichtbarmachen mit Enter fortsetzen. Für jede geprüfte Liste nennt `P1_LISTENBESTAND` die Zahl sichtbarer, bereits bearbeiteter bzw. ausgeschlossener, fachlich ungeeigneter und verbleibender geeigneter Zeilen. Eine bestätigte interne Weiterleitung gibt den nächsten Einzelpiloten frei.

## Phase 2 vor dem letzten Weiterleitungsklick

Der Bot vergleicht den Ticketkopf wiederholt mit der erwarteten ID und dem Eintrag in der eigenen Vorgangsliste. Enthält die URL eine explizite Ticket-ID, muss auch diese passen. Bei einem Detailwechsel unmittelbar vor dem Klick kann er das bereits gespeicherte Ticket einmal aus einer frisch gelesenen eigenen Liste öffnen. Dann prüft er die fachlichen Felder, den vorgesehenen Empfänger und die Freigabe erneut. Das Journal muss die bestätigte Speicherung und Prüferauswahl enthalten. Ein bereits protokollierter Weiterleitungsversuch schließt diese Wiederholung aus. Bleibt das Ticket vor dem Klick uneindeutig, kann der Lauf nach erfolgreicher Rückkehr zur eigenen Liste die anderen Fälle bearbeiten.

## PP+-Vorlage

Vor dem Kontoauszug prüft RC120 WWID und Plan im eingelesenen Bestand, Python, Generator, benötigte Dateien und den Ausgabeordner. Zu PP+ gehören auch die Arbeitsdatei, die Kontrollmappe, das Eckwerte-Modul und die Personenordner-Zuordnung. Wird genau der bekannte falsch dekodierte Name der Vorlage im Python-Quelltext gefunden, löst ihn der Bot für seinen Generatorlauf als `IPP Kontoauszüge Updates_Template.xlsm` auf. Fehlende Dateien erscheinen mit ihrem konkreten Pfad im Laufbericht.

Soll auch der manuelle BAT-Aufruf vom reparierten Dateinamen profitieren, steht im installierten Ordner folgender einmaliger Befehl zur Verfügung. Er prüft die tatsächliche Vorlage, sichert das Originalskript und ersetzt das eindeutig betroffene Literal unter Beibehaltung der Dateikodierung. Der Botlauf selbst braucht diesen Eingriff nicht.

```bat
python tools\statement-preflight.py repair-pp "K:\INTL01\6_AU (Admin)\Berechnungen - UV & Renten (PP+, DC+)\Kontoauszug_PP+\kontoauszug_generator.py"
```

## DC-Kontoauszug

Der Laufbericht meldet die aktive Laufzeit, den beobachteten PDF-Export und den Nachlauf. Wenn der zentrale Generator die Personenordner-Kopie als eigenständigen Aufruf ausführt, merkt der Adapter die Kopie vor und lässt zunächst das Hauptprogramm einschließlich der Aufräumarbeiten zu Ende laufen. Erst nach erfolgreicher Rückkehr und erneutem Hashvergleich meldet er `P2_DC_PDF_CREATED`. Der Bot kann die geprüfte PDF an den normalen Anlagenprozess übergeben, während die Kopie noch läuft. Verwendet das Hauptprogramm das Ergebnis der Kopierfunktion, gilt die ursprüngliche Reihenfolge mit Prüfung des Prozessabschlusses. Bei ausbleibendem Nachweis meldet der Bot alle 15 Sekunden seine Laufzeit und beendet den Warteversuch nach spätestens 15 Minuten zuzüglich der begrenzten Vorprüfung. Ein alter DC-Prozess mit erkennbarem Direktaufruf auf diesem Windows-Rechner und eine belegte RC120-Sperre im gemeinsamen Ausgabeordner führen zur Rückstellung des Folgefalls. Für den Anhang prüft der Bot den Bezug zur aktuellen Erzeugung, den freigegebenen Ausgabeordner, die WWID, den Namen, das PDF-Format, die Dateigröße und den SHA-256. Bei uneindeutiger maschineller Namensprüfung ist eine Sichtprüfung des konkreten Dokuments vorgesehen. Der Upload verwendet den vorhandenen Phase-2-Anlagenprozess mit erneuter Ticketbindung und Prüfung nach dem Speichern. Der Status des DC-Laufs wird unter `.runtime\phase2\dc-generator` geführt.

## Offene Auszahlungsoptionen

Meldet der AO-Generator einen zugeordneten fachlichen Fehler, bleibt der Vermerk `Manuel review required` beim Ticket. Nach der fachlichen Klärung und Anpassung der Vermerkzeile im gespeicherten Ticket ist ein neuer Generatorlauf möglich. Bei einem älteren Uploadjournal liest RC120 beim Öffnen des Tickets den Anlagenbereich auch während des Nachladens erneut. Eine bereits begonnene Dateiauswahl darf ausschließlich mit eindeutig zuordenbarer Anlage und passendem Journal fortgesetzt werden.

## Prüfumgebung

Die Release-Prüfung verwendet lokale COMARCH-Oberflächenmodelle, synthetische Tickets, Excel-Dateien und Generatorprogramme sowie isolierte Installationskopien. Für das Paket wurde kein produktives Ticket geöffnet, versendet oder weitergeleitet. Der letzte Nachweis für die Darstellung der firmenspezifischen Vorschlagslisten, die zentralen Excel-Berechnungen und den dauerhaften COMARCH-Anhang erfolgt in der Windows-Installation.
