# RC97 – Member-Auswahl, ein Bot-Tab und aktueller Excel-Bestand

Version **0.8.1-rc.97**, 18. November 2026.

RC97 setzt auf dem erfolgreichen RC96-Lauf auf. Die sechs angeforderten Verbesserungen betreffen Fokus, Tab-Verwaltung, Pflichtfeldablauf, Profilübernahme und den laufend gepflegten Excel-Bestand. Das ursprüngliche Kartendesign und der Fahrplan mit Vollbild bleiben enthalten.

## Installation und erster Start

1. `RC97_Install.zip` vollständig in einen separaten Ordner entpacken.
2. Darin `MCR_Datenbruecke\START.cmd` öffnen, **1** wählen und die vorhandene Installation als Ziel übernehmen.
3. `PASS INSTALLATION_COMPLETE` abwarten. Danach ausschließlich die `START.cmd` der installierten Version verwenden. Der Titel muss **0.8.1-rc.97** anzeigen.
4. Vor dem ersten Ticketlauf **2 – Excel-Bestand neu einlesen / offene Kontaktdaten ergänzen** ausführen. Damit lässt sich die neue Quelle prüfen, ohne einen Ticketlauf zu starten.
5. Danach wie bisher **3**, **4** oder **5** verwenden. Der aktuelle Excel-Bestand wird auch beim Start dieser Menüwege automatisch eingelesen.

Das Update bewahrt private_data, Konfiguration, Browserprofil und Laufjournale. Es versendet keine Nachrichten. Die unveränderte RC96-Ausgabe wird anhand ihres vollständigen Manifests und aller Programmdateien geprüft. Eine lokal abgeänderte Installation wird nicht ungeprüft ersetzt.

## 1. Member-Feld und Pflichtfelder

Die alte Fokusprüfung las unmittelbar nach einem Klick einmal das aktive Element. Wenn COMARCH/ICEfaces das Feld kurz darauf neu aufbaute, erschien bereits die manuelle Fokusfrage. Zusätzlich verwendete die Member-Suche synthetische Eingabeereignisse.

RC97 wartet kurz auf stabilen Fokus und prüft das richtige Feld erneut. Bei einer verzögerten Ersetzung ist höchstens ein neuer, frisch geprüfter Klick auf dasselbe Eingabefeld möglich. Die Suche verwendet native Browser-Tastatureingabe und liest den vollständigen Suchtext zurück. Fremde, doppelte oder verdeckte Felder werden nicht geraten.

Der reguläre Pflichtfeldweg lautet:

**Kategorie wählen → einmal Member zur Übernahme → Unterkategorie wählen → direkt Signatur → Antworteditor.**

Der zusätzliche Member-Fokus nach der Unterkategorie bleibt nur als begrenzter Rückfallweg, wenn die direkte Übernahme nicht bestätigt wird. Eine bereits vollständig bestätigte Pflichtfeldkombination wird bei späteren Prüfungen desselben Tickets und Members gelesen, ohne den ganzen Auswahlweg erneut auszuführen. Vor dem ersten Suchtext entfällt das bisherige Warten auf eine noch leere Vorschlagsliste.

Manuelle Hilfe bleibt möglich, wenn COMARCH das richtige Feld tatsächlich verdeckt oder keine eindeutigen Vorschläge liefert. Eine vollständige Beseitigung solcher Oberflächenprobleme lässt sich ohne Prüfung in der echten COMARCH-Sitzung nicht zusichern. Sende-, Speicher- und Weiterleitungsklicks werden dadurch nicht wiederholt.

## 2. Ein Bot-Tab

RC96 hielt einen leeren Tab als Anker und erzeugte für Pilot, Folgelauf und Phase 2 neue Seiten. RC97 bindet einen eindeutig zum gestarteten Bot gehörenden Tab. Die drei Teilläufe verwenden dieselbe Tab-ID; sie laden darin COMARCH frisch und prüfen, dass tatsächlich eine neue Ansicht geladen wurde.

Am Ende eines Teillaufs wird die technische Verbindung getrennt, der Tab bleibt erhalten. Der Master beendet seinen Edge-Prozess am Laufende. Ein Ticketwechsel innerhalb eines Teillaufs nutzt weiterhin denselben Tab. Die Live-Karte ist ein separates Anzeigefenster im normalen Browser.

Fremde oder wiederhergestellte Browser-Tabs werden nicht übernommen oder geschlossen. Wird der gebundene Bot-Tab während des Laufs geschlossen, meldet der Bot den fehlenden Tab, statt einen anderen zu verwenden oder eine Ticketaktion zu wiederholen.

## 3. Gelesene Namen übernehmen

Wenn Vorname, Nachname und MercerID bereits aus dem eindeutig ausgewählten COMARCH-Profil lesbar sind, werden sie übernommen. Die bisherigen drei erneuten Eingaben von ID, Vorname und Nachname entfallen in diesem Fall.

Bei einem wirklichen Namenskonflikt zeigt der Bot das Profil an und fragt einmal:

- **ENTER:** Person und Berechtigung geprüft; der Originalabsender gehört zu dieser Person.
- **VERTRETER:** Berechtigte Vertretung bestätigt; E-Mail und Sprache werden nicht als persönlicher Kontakt des Members in FM/FN übernommen.
- **NEU SUCHEN:** Member erneut auswählen.
- **ABBRUCH:** Lauf anhalten.

Fehlt der Name in der Nachricht, versucht der Bot zuerst, das bereits ausgewählte Profil zu lesen. Andernfalls kann die Person im Member-Feld ausgewählt werden; danach liest der Bot die Profilwerte. Nur die ausdrückliche Alternative **NAMEN** verwendet die getrennte Namenseingabe.

Nach einer manuellen Pause werden Ticket und Profil erneut geprüft. WWID und MercerID bleiben getrennt. Ein ausdrücklich beschriftetes WWID-Feld wird zusätzlich mit dem Bestands-Lookup verglichen. Der bisherige Präfix-11-Lookup verändert nur den Suchschlüssel zum Bestand, niemals die COMARCH-ID.

## 4. Verbindliche Excel-Quelle

Voreingestellt ist:

```text
K:\INTL01\6_AU (Admin)\~ Data\~ Bestand Intel Gesamtübersicht\INTL01_Gesamtdatenbestand_30.09.2025.xlsx
```

Der bestehende Leser verwendet das Blatt **Output**. Bei fehlendem oder nicht eindeutigem Blatt und widersprüchlichen Spaltenüberschriften erscheint ein konkreter Fehler. Es wird kein anderes Blatt geraten.

| Spalte | Verwendung |
| --- | --- |
| B | WWID / bisheriger ClientEEID-Schlüssel |
| C | DC: 1 aktiv, 0 inaktiv, leer nicht gesetzt |
| D | PP+: 1/0/leer |
| E | PensIntel: 1/0/leer |
| F | TPP: 1/0/leer |
| G | JUB: 1/0/leer |
| H | UEB: 1/0/leer |
| I | ZW: 1/0/leer |
| L | USC |
| O | M/F für die Anrede; fehlende oder widersprüchliche Werte behalten den Prüfweg |
| FM | Ergänzte eigene E-Mail-Adressen |
| FN | Sprache der Originalnachricht: DE oder EN |

Die vorhandene Projektregel behandelt E/PensIntel bereits als `pensIntel` und `dbPlus`. RC97 behält deshalb die bestehende **DB+**-Anzeige und die zugehörige Phase-2-Regel bei. JUB, UEB und ZW werden zusätzlich gelesen und in den Planzeilen angezeigt. Sie erhalten keine erfundenen neuen Bearbeitungs- oder PDF-Regeln. Kontoauszugsziele bleiben DC/PP+.

Alle Bestandszeilen derselben WWID bleiben in ihrer Reihenfolge erhalten. Ein Fehler in einer zugehörigen fachlichen Zeile sperrt die vollständige Zuordnung; es wird keine scheinbar vollständige Teilmenge verwendet. Die Begrenzung der COMARCH-Beschreibung bleibt geprüft.

### Aktualität und JSON

Die XLSX ist die führende Quelle. JSON bleibt intern als überprüfter Lauf-Snapshot erhalten, damit Pilotfreigabe, Browser-Lease und Journale einen festen Bezug haben. Es muss kein JSON-Bestand von Hand nachgepflegt werden.

Vor dem Lauf wird die Quelle neu gelesen. Vor Tickets und entscheidenden Schreibgrenzen wird geprüft, ob WWID, Merkmale, USC oder Anrede seit dem Einlesen geändert wurden. Bei einer fachlichen Änderung hält der Bot vor der nächsten betroffenen Aktion an: **Menü 2**, anschließend neu starten. Bereits abgeschlossene Tickets bleiben geschützt. Ist K: nicht erreichbar, gibt es keinen stillen Rückfall auf ein altes JSON.

Änderungen nur in FM/FN oder anderen unbeteiligten Spalten lösen keine neue Pilotpflicht aus. Formelwerte werden aus den gespeicherten Excel-Ergebnissen gelesen; vorhandene Formelprüfungen bleiben erforderlich. Der Bot berechnet die Bestandsdatei nicht neu.

Ein abweichender Dateipfad kann in `config/local-runner-queue-send.json` über `stockWorkbookPath` gesetzt werden. In JSON sind Rückstriche doppelt zu schreiben. Die bestehende Konfiguration bleibt beim Update erhalten; fehlt dieser neue Schlüssel, gilt der oben angegebene Standardpfad.

## 5. E-Mail und Sprache ergänzen

Die Kontaktübernahme erfolgt nach nachgewiesenem Versand **und** Speichern des Tickets. Sie verwendet den gebundenen Originalabsender, den geprüften Antwortempfänger, das zuletzt bestätigte Memberprofil, die daraus aufgelöste WWID und die Originalsprache.

Bei der manuell geprüften Zuordnung genügt die oben beschriebene ENTER-Bestätigung auch bei einer undurchsichtigen E-Mail-Adresse. Ohne manuelle Prüfung muss ein eindeutiger passender Absender- oder aktueller Signaturbezug vorliegen. Ein Name, der lediglich im Nachrichtentext erwähnt wird, wird nicht als Inhaber der Absenderadresse angenommen.

FM ergänzt eine noch nicht enthaltene Adresse; bestehende Adressen bleiben erhalten. Deduplizierung berücksichtigt Groß-/Kleinschreibung. FN erhält DE/EN aus der Originalnachricht beziehungsweise der bereits vorgesehenen manuellen Sprachwahl. Eine verspätete ältere Ergänzung darf keine neuere, vom Bot protokollierte Sprachbeobachtung zurücksetzen. Unabhängige manuelle Änderungen in FN haben keinen auswertbaren Zellzeitstempel; sie werden nicht zeitlich verglichen. Bei mehrfacher WWID werden die passenden Zeilen gemeinsam aktualisiert, fremde WWIDs nicht.

Eine Adresse, die bereits bei einer anderen WWID steht, fremde FM/FN-Überschriften, Formeln, Zellfehler, geschützte oder verbundene Kontaktzellen und besondere Zellinhalte werden zur Prüfung zurückgestellt. Bestehende Fachspalten, Formeln, Formatierungen und andere ZIP-Bestandteile werden nicht durch einen vollständigen Excel-Neuaufbau ersetzt.

### Sperren, Sicherung und Wiederaufnahme

Der Windows-Schreibadapter hält die Datei vom Vergleich mit dem gelesenen Original über Sicherung und Schreibabsicht bis zum Schreiben und Zurücklesen exklusiv geöffnet. Vor der Änderung wird die vollständige Originaldatei unter `.runtime/workbook/backups` gesichert. Wird ein Schreibfehler erkannt, wird das Original nur innerhalb desselben gehaltenen Dateihandles zurückgeschrieben und geprüft.

Nach einem Prozess- oder Rechnerabbruch dient `.runtime/workbook/transactions` zur Klärung. Eine später fremd veränderte Datei wird nicht blind durch eine ältere Sicherung ersetzt. Das ist eine gesicherte Schreibtransaktion mit Wiederherstellungsnachweis, kein atomarer Dateiaustausch.

Ist Excel geöffnet oder die Datei gesperrt, bleibt die Ergänzung unter `.runtime/workbook/contacts` als **PENDING** erhalten. Nach dem Schließen der Datei wird sie beim nächsten Menü-2-, Phase-1-, Phase-2- oder Masterstart erneut versucht. Diese Wiederholung betrifft ausschließlich Excel. Sie kann keine E-Mail senden oder ein Ticket weiterleiten.

Typische Meldungen:

| Meldung | Bedeutung |
| --- | --- |
| BESTAND_EXCEL_NEU_EINGELESEN | Neuer fachlicher Bestand aktiviert |
| BESTAND_EXCEL_AKTUELL | Quelle erneut gelesen; fachliche Daten unverändert |
| BESTAND_KONTAKT_GESPEICHERT | FM/FN gespeichert und verifiziert oder bereits vorhanden |
| BESTAND_ERGAENZUNG_OFFEN | Ergänzung dauerhaft vorgemerkt; Grund wird angegeben |
| BESTAND_KONTAKT_NICHT_UEBERNOMMEN | Eigenkontakt nicht ausreichend belegt; keine FM/FN-Änderung |
| WORKBOOK_CONTACT_AFTER_COMPLETE | Kontaktupdate nicht bestätigt; Ticket bleibt abgeschlossen. Bei Speicherfehler kann auch die lokale Vormerkung fehlen. |

## Einordnung des gelieferten RC96-Protokolls

Der gezeigte Lauf ist technisch abgeschlossen: Phase 1 hat sieben Tickets mit Versand und Speicherung bestätigt, Phase 2 zwei Tickets ohne E-Mail weitergeleitet. Die sieben neuen Phase-1-Tickets hatten noch keinen Bearbeitungsauftrag in der zusätzlichen Beschreibung und wurden mit `NOT_REQUESTED` offengelassen. Sie sind damit nicht fachlich in Phase 2 erledigt. Die künftige LenX-Erstellung des Auftrags bleibt ein eigenes Phase-3-Thema.

## Prüfung und verbleibende Live-Abnahme

Automatisierte lokale Prüfungen umfassen die Member-/Namensübernahme, Fokuszustände, Ein-Tab-Lifecycle, erweiterte Bestandsmerkmale, Quellaktualität, Mehrfachzeilen, E-Mail-/Sprachzuordnung, Warteschlange, ZIP-/OOXML-Erhaltung und die Trennung von Kontaktfehlern und abgeschlossenem Ticketversand. Der separate Prüfbericht nennt die tatsächlich ausgeführten Testzahlen.

Zusätzlich enthält das Paket fünf Windows-Tests für den nativen Dateischreibadapter mit ausschließlich temporären Testdateien. Auf dem Entwicklungsrechner wurden sie mangels Windows/PowerShell übersprungen. Das reale K:-Laufwerk, die konkrete Bestandsdatei, Excel-Sperren über SMB und COMARCH wurden hier nicht live ausgeführt. Für den ersten Einsatz sind das Einlesen mit Menü 2, die Profilübernahme in einem passenden Ticket und die anschließende Kontrolle der betroffenen FM/FN-Zeilen die entscheidenden Nachweise. Der erste Versandpilot bleibt an die neue Software-/Bestandsversion gebunden.
