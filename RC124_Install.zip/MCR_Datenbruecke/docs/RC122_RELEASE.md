# MCR Datenbrücke 0.8.1-rc.122

## Erstes Ticket in Phase 1 öffnen

RC121 konnte bei einem eingeklappten COMARCH-Menü für beide gespeicherten Suchen `CHILD_NOT_VISIBLE` melden, während die allgemeine Tabelle „Meine Vorgänge“ bereits geladen war. Der Master-Lauf hielt dann vor dem ersten Ticket mit `MCR-P1-112` an.

RC122 erkennt den älteren Menüaufbau, bei dem die Gruppenüberschrift selbst ein Link ist. Der Bot öffnet die passende Gruppe, wählt ihren exakten Untereintrag und wartet auf die zugehörige Tabelle. Zuerst prüft er „Meine Vorgänge“ → `In_Bearbeitung`. Findet er dort keinen geeigneten Vorgang, prüft er „Warteschlange“ → `INTL01`. Beim erfolgreichen Öffnen über den Gruppenlink erscheint `PASS P1_LISTE_UEBER_GRUPPENLINK` im Terminal.

Falls gespeicherte Suchen weiterhin unerreichbar sind, kann Phase 1 einen einzelnen geeigneten Vorgang aus „Meine Vorgänge“ bearbeiten. Dazu müssen die Intel-Gruppe und der Status „In Bearbeitung“ derselben Zeile zugeordnet sein. Fehlt der Status in einer ansonsten eindeutig zugeordneten Intel-Zeile, kann der Bediener ihn in COMARCH prüfen und genau eine der angebotenen Ticket-IDs eingeben. Vor der Bearbeitung prüft der Bot die Zeile und die ID im geöffneten Ticket erneut. Das Journal schließt bereits erledigte und gesperrte Tickets aus. Für die Meldung, dass beide Listen abgearbeitet sind, müssen beide gespeicherten Listen geprüft sein.

## Installation von RC121 aus

1. `RC122_Install.zip` in einen separaten Ordner entpacken.
2. Dort `MCR_Datenbruecke\START.cmd` öffnen, **1** wählen und die vorhandene Installation als Ziel übernehmen.
3. Nach `PASS INSTALLATION_COMPLETE` erscheint das installierte Hauptmenü mit **0.8.1-rc.122**. **5** startet den Master-Lauf. Phase 1 kann dabei echte Standardantworten versenden.

## Prüfung

Im lokalen Chromium-Test zeigten beide Versionen zunächst dieselbe Tabelle. RC121 blieb bei zwei eingeklappten Gruppen stehen. RC122 öffnete bei leerer eigener Liste das passende Ticket aus der Warteschlange. In einem zweiten Durchlauf öffnete RC122 zuerst den geeigneten eigenen Vorgang. Weitere Tests prüfen eine verzögert wechselnde Tabelle, fremde Vorgänge und eine unmittelbar vor dem Öffnen geänderte Gruppenzuordnung. Der produktive Windows-Edge-Lauf steht aus.
