# RC118 – Signaturkonflikte

Basis: RC117. Kein globaler Abbruch für einen isolierten, ticketgebundenen Signaturkonflikt vor Beginn einer Aktion. Zwölf begrenzte Lesewiederholungen; bei stabilem zulässigem Zustand bisherige exakte Vorschlagsauswahl fortsetzen. Bei dauerhaft fremdem/unklarem Wert: im MANUAL-Modus einmalige gezielte Benutzerkorrektur oder Überspringen, im AUTO-Modus zurückstellen. Kein fremder Wert wird automatisch ersetzt. Journal, Ticket- und Memberbindung bleiben Pflicht. Bei offenen Aktionsabsichten, anderer Ticketbindung oder fehlender sicherer Listennavigation weiterhin sicherer Stop. Keine Änderung an Phase 2, AO-Generator oder Formeln. Windows/COMARCH-Echttest ausstehend.

Installation: RC118 separat entpacken, START.cmd -> Menü 1. Bestehende Installation übernehmen. PASS INSTALLATION_COMPLETE und RC117 -> RC118 kontrollieren. Keine Journale löschen. Anschließend ausschließlich installierte START.cmd verwenden.
