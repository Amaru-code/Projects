# RC99 – Eigenes Botfenster ausdrücklich erzeugen und binden

Version **0.8.1-rc.99**, 19. November 2026. Grundlage: das gelieferte RC98-Paket.

## Befund aus dem gemeldeten Lauf

Nach erfolgreichem Update von RC97 auf RC98 brach Menü 5 vor Beginn der Ticketbearbeitung mit `BROWSER_OWNED_TARGET_MISSING` und „Eigene Browserstartseite fehlt. Keine fremde Seite uebernommen.“ ab.

Dieser Fehler entsteht im bisherigen Startablauf nach dem Start des Edge-Prozesses und dem Verbinden der Browsersteuerung: Der Bot sucht einen Tab mit exakt passender Startmarkierung in der URL. Fehlt dieser Treffer, beendet die Fehlerbehandlung den gestarteten Browser wieder. Das erklärt den Abbruch vor dem ersten Ticket. Weshalb die Markierung auf dem betroffenen Windows-/Edge-System fehlte, ist mit dem vorliegenden Protokoll nicht empirisch geklärt. Insbesondere wird keine bestimmte Behandlung von URL-Fragmenten durch Edge als bewiesene Ursache behauptet.

## Änderung

1. Edge startet mit `--no-startup-window`, ohne Start-URL.
2. Nach dem Verbinden erzeugt der Bot über `Target.createTarget` ausdrücklich eine Seite mit `url: 'about:blank'`, `newWindow: true` und `background: false`.
3. Die Antwort dieser Erzeugung liefert die Tab-ID. Der Bot prüft und bindet genau diese ID; eine Suche nach einer markierten Startadresse entfällt.
4. Anschließend wird COMARCH in dieser eigenen Seite geladen. Für die weiteren Phasen bleiben die vorhandenen Prüfungen auf die gebundene Tab-ID und eine frisch geladene Ansicht aktiv.

Der Startweg gilt für den gemeinsamen Browser von Menü 3/5, für einen eigenständigen Phase-1-Start sowie für Phase 2 über Menü 4. Ein Masterlauf hält weiterhin eine eigene Seite über Pilot, Folgelauf und Phase 2 hinweg. Die Live-Karte bleibt ein separates Anzeigefenster.

Anfängliche Fehler beim Erzeugen oder Binden des Botfensters erhalten eine eigene Diagnose. Der Verlust eines bereits gebundenen Tabs während des Laufs bleibt ein Abbruchgrund. Der Bot übernimmt dafür keine fremde Seite und beginnt keine Ticketaktion auf einem Ersatz-Tab. Versand-, Speicher- und Weiterleitungsaktionen werden durch diese Änderung nicht wiederholt.

## Installation

`RC99_Install.zip` vollständig außerhalb der bisherigen Installation entpacken. Die neue `MCR_Datenbruecke\START.cmd` öffnen, Menü **1** wählen und die bestehende Installation als Ziel übernehmen. Nach `PASS INSTALLATION_COMPLETE` die installierte Version **0.8.1-rc.99** verwenden. Für Menü **5** genügt weiterhin **ENTER** als Startbestätigung.

RC98 wird nur mit dem folgenden unveränderten Manifest und den dazu passenden Programmdateien als Vorgängerversion akzeptiert:

```text
3ee7396e87f717f55d03c7ed6176e114c36d98e063c8c78fa1b8632595707a94
```

Die bereits verifizierbaren älteren Versionen einschließlich RC97 bleiben unterstützt. Das Update ersetzt Software; private_data, Konfiguration, Browserprofil und bisherige Laufjournale bleiben an ihrem Ort. Die Einrichtung versendet keine Nachrichten.

## Bestehender Ablauf

- Die automatische XLSX-Prüfung beim Öffnen des installierten Hauptmenüs bleibt erhalten.
- Menü 3/4/5 lesen die führende Quelle vor der Ticketbearbeitung erneut. Menü 2 bleibt eine optionale Wartungsfunktion.
- Die Startprüfung allein schreibt keine FM/FN-Kontakte und beginnt keine COMARCH-Ticketaktion.
- Die bestehenden Nachweise für Identität, Pilotfreigabe, Versand, Speicherung und Weiterleitung sowie die Sperre gegen doppelten Versand bleiben aktiv.

## Prüfung und praktische Grenze

Die lokale Prüfung des neuen Startwegs verwendet simulierte Browserprotokoll-Antworten. Sie kann die Parameter der Seitenerzeugung, die direkte Bindung der zurückgegebenen ID und das Verhalten bei fehlender oder verlorener Seite prüfen. Sie bestätigt keine Anmeldung und keinen Ticketlauf auf dem Windows-Rechner des Anwenders.

Die reale Windows-/Edge-/COMARCH-Probe steht bei Erstellung dieses Releases aus. Es wurden für diese Reparatur keine Kundennachrichten versendet und keine Kundentickets bearbeitet. Die erste praktische Kontrolle ist, ob Menü 5 das eigene Edge-Fenster öffnet und bis zur COMARCH-Anmeldung beziehungsweise zum vorgesehenen Laufstart gelangt.

Technische Protokollreferenz: [Chrome DevTools Protocol – Target.createTarget](https://chromedevtools.github.io/devtools-protocol/tot/Target/#method-createTarget).
