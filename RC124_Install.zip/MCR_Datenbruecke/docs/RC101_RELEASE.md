# MCR DATENBRUECKE 0.8.1-rc.101

**19. November 2026 – auf Grundlage des Originalpakets RC100.**

## Anlass und konkrete RC100-Beobachtung

Im beaufsichtigten RC100-Echtlauf wurde Ticket `89827030` **nachweislich einmal gesendet und gespeichert**. Beim nächsten Ticket `89772824` war vor dem Versand der ursprünglich gelesene Empfänger nicht mehr identisch (`RECIPIENT_CHANGED`). In beiden Tickets musste die Signatur `INTL01 - Intel Deutschland GmbH` manuell gewählt werden. Daraus lässt sich weder ein realer Doppelversand noch die genaue ICEfaces-Ursache der Signaturauswahl ableiten. RC101 behebt nachprüfbare Änderungen im Auswahlablauf und ergänzt eine sichere Reaktion auf Benutzerkorrekturen.

## Korrektur: Pflichtfelder / Signatur

* Der RC96-erprobte Wechsel zum Member-Feld nach der Unterkategorie stellt den serverseitigen COMARCH-Commit wieder her, **bevor** die Signaturauswahl beginnt. Die RC97-/RC100-Abkürzung direkt zur Signatur entfällt.
* Die Signatur wird ausschließlich über den exakten sichtbaren Vorschlag gebunden. Nach AJAX-Aktualisierungen wird der Feldwert geprüft, bei zulässigem Leerwert begrenzt neu gewählt; ein fremder Signaturwert wird nicht überschrieben.
* Es bleibt eine beaufsichtigte Fallback-Auswahl, falls COMARCH die Vorschläge nicht eindeutig zur Browsersteuerung übermittelt. RC101 verspricht keine ungeprüfte Live-Automatik.

## Dokumente: Kontoauszug DC / PP+ und Auszahlungsoption AO

* Die bekannten Kontoauszug-BATs bleiben fest gebunden: `Kontoauszug_DC\START_KONTOAUSZUG_DC.bat` und `Kontoauszug_pp+\START_KONTOAUSZUG.bat`, relativ **zum Elternordner** der installierten Datenbrücke. Der Bot liest zuerst vorhandene, personengebundene PDFs und erzeugt nur fehlende Kontoauszüge.
* Ein vorhandener BAT wird **lokal gestartet**. Trägt er eine klar identifizierbare `set /p`-WWID-Eingabe, schreibt der Bot einmal die unabhängig geprüfte WWID über Standard-Eingabe. Trägt er einen eindeutigen `%1`-Parametervertrag, übergibt er die WWID als Argument. Bei unbekannten Menüs/GUIs schreibt er **nicht blind** in das fremde Generatorprogramm, sondern lässt die Eingabe manuell erledigen. Ein Generator-Exitcode allein ist kein PDF-Beleg; echte Dateien werden wiederholt auf stabile, zugeordnete PDF-Bytes geprüft.
* **AO** ist eine dritte Dokumentart ohne Generator. Verwendet wird ausschließlich eine bereits vorhandene PDF aus `Auszahlungsoption\Ausgabe PDF`, zum Beispiel `2025-12-31_Auszahlungsoption_Nachname_Vorname_11412817.pdf`. Die Kennung wird **nur vom Dateiende** gelesen; Vorname, Nachname und Datum werden zusätzlich geprüft. Mehrere Kandidaten zu derselben WWID, eine abweichende Person oder ein nicht verifizierbares Dokument bleiben zur Prüfung offen.
* Unterstützte Zeile 3: `Möchte Auszahlungsoption`, `Möchte Auszahlungsoptionen`, `Möchte AO`, `Möchte Kontoauszug & Auszahlungsoption`, `Möchte KA + AO` sowie Kombination mit `und`. Unbekannte Bitten bleiben in der vorhandenen Mark-Route; keine beliebige Textsuche nach dem Wort „Auszahlung“.
* In einer Anfrage können **DC, PP+ und AO** gemeinsam benötigt werden. Dokumentplan, PDF-Inhaltsfreigabe, Dateihashes, Uploadplan, Wiedereinstieg und Journal lassen bis zu drei unterschiedliche geprüfte Anlagen zu. COMARCH wird nur mit den zugehörigen Dateien bearbeitet; Phase 2 versendet weiterhin **keine E-Mail**.
* Kontoauszug-Entwürfe verwenden den bisherigen Text. AO-only- und kombinierte Entwürfe behaupten ohne weiteren Nachweis **nicht**, die AO-Datei sei verschlüsselt. Vor Entwurfs-/Ticket-Speichern und Weiterleitung sind dieselben echten COMARCH-Bestätigungen nötig wie zuvor.

## Pause / Fortsetzen und Browseränderungen

* Die kleine Steuerung verwendet den vorhandenen **STOP**-Knopf nun als **Pause**; im Pausenzustand wird er zu **CONTINUE**. Die Automatik wartet bei gesteuerten Browser-Eingaben und gibt nach der Fortsetzung frühere Auto-/Manuell-Freigaben **nicht** still wieder frei. AUTO wird bei Pause auf MANUELL zurückgesetzt.
* Nach einem Empfängerwechsel vor dem Versand prüft der Bot erneut und bietet die **Wiederherstellung des ursprünglich gebundenen Empfängers** an. Nur bei exakter Übereinstimmung kann der Vorgang fortfahren. Andernfalls bleibt das einzelne Ticket als `EMPFAENGER_PRUEFUNG_OFFEN` ohne neuen Sendeklick zurückgestellt. Nachträglich abweichende Pflichtfelder erhalten ebenfalls eine explizite Prüfmöglichkeit.
* **Nicht versprochen:** beliebige Änderungen während einer irreversiblen COMARCH-Aktion oder ein unbestätigter Versand lassen sich nicht automatisch „wegklicken“. Offene Versand-/Speicher-/Weiterleitungsjournale blockieren weiterhin unbekannte Wiederholungen und dürfen nicht zurückgesetzt werden.

## Installation

`RC101_Install.zip` vollständig **außerhalb** der vorhandenen Installation entpacken, `MCR_Datenbruecke\START.cmd` starten, Menü **1**, bestehendes Ziel mit **ENTER** übernehmen, `PASS INSTALLATION_COMPLETE` abwarten. Danach ausschließlich die **installierte** `START.cmd` verwenden; der Menü-Titel muss **0.8.1-rc.101** lauten. Menü **5** ist weiterhin ein **Echtlauf** mit Versand in Phase 1. Ein vorheriges Menü 2 ist nicht erforderlich; die aktive XLSX wird beim Start und vor Menü 3/4/5 geprüft. Das Update bewahrt `private_data`, `config`, Browserprofil und Laufjournale.

## Prüfgrenzen

Offlineprüfungen nutzen simulierte COMARCH-DOMs, synthetische Mitglieder- und PDF-Dateien sowie simulierte Windows-Prozesse. Die echten beiden BAT-Dateien wurden nicht bereitgestellt; ihre Benutzerführung, Laufzeiten und Ausgabeformate können erst auf dem Windows-Rechner des Anwenders bestätigt werden. Native PowerShell-WinForms und die Echtlauf-Signaturwahl sind hier nicht ausführbar. Die konkreten Testzahlen, Einschränkungen und der erfolgreiche RC100→RC101-Installations-/Rückwegtest stehen im gesonderten RC101-Prüfbericht.
