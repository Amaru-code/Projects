# RC104 – Verifizierbare COMARCH-Feldsteuerung und Empfängerfreigabe

Ausgangsbasis: vollständiges RC103-Installationspaket.

## Änderungen

- `lib/input-focus.mjs`: Wenn das exakt identifizierte aktive ICEfaces-Eingabefeld durch Rendering/Overlays keinen geometrisch sicheren Klickpunkt bietet, wird ausschließlich das gebundene Feld mit `focus()` fokussiert. Keine Texteingabe oder Geschäftsklick über diese Funktion. Verboten bei einem anderen aktiven Modal. Zweimalige Fokusbestätigung nach DOM-Neuzeichnung.
- `lib/browser-workflow.mjs`: Autocomplete-Vorschläge werden nun auch in nach oben geöffneten Listen erkannt, sofern die exakte Option einmalig, sichtbar und tatsächlich klickbar ist. Kein Klick auf mehrdeutige Optionen.
- `src/local-bot-full-run.mjs`: Eine während AJAX neu positionierte **exakte** Vorschlagsoption wird an ihrem neuen Punkt nochmals stabil geprüft; nur dann bekommt sie einen echten CDP-Mausklick. Unterkategorie/Signatur bleiben streng auf `Personenschriftwechsel` / `INTL01 - Intel Deutschland GmbH` begrenzt. Der antwortende CKEditor bekommt einen begrenzten Warte-/Wiederholungsweg, jedoch keinerlei Überschreibung fremder Entwürfe.
- `lib/phase1-recipient-approval.mjs`: **absichtlich geänderte** und erneut gelesene Empfängeradresse kann vom Benutzer mit `JA` für die exakte Adresse und Ticket-ID freigegeben werden. Eine danach wieder geänderte Adresse oder ein anderes Ticket stoppt den Sendeklick. Eine manuell geänderte Versandadresse wird nicht ungeprüft in den Mitarbeiterdatenbestand übernommen. Versandbelege verifizieren den tatsächlich freigegebenen Empfänger.
- `src/phase2-run.mjs`: Falls die CDP-Child-Session beim Eintritt in Phase 2 vor dem ersten Ticket verloren geht, darf dieselbe **bereits freigegebene, eigene Tab-ID** einmalig neu gebunden werden. Keine andere Tab-ID, kein erneuter Geschäftsklick, kein Rebind nach begonnenen Ticketaktionen.

## Weiter geltende Grenzen

- Echtes Senden, Speichern und Weiterleiten erfolgen nach den bisherigen Protokollen und nur mit Ticket-/Identitäts-/Freigabenachweisen. Bei unklarer Aktion kein erneuter Klick.
- K:-Generatorpfade von RC102/RC103 unverändert. AO-Generatoren mit unbekannter BAT-Eingabeschnittstelle verlangen weiterhin manuelle WWID-Eingabe. Ohne die echte BAT-Datei lässt sich die Eingabeschnittstelle nicht seriös automatisieren.
- Live-Versand mit COMARCH/Windows wurde in dieser Arbeitsumgebung nicht simuliert. Gezielte Unit- und Paket-/Rollbacktests sind ein **Offline-Nachweis**, kein Nachweis, dass die Unternehmensoberfläche jeden neuen Fallback akzeptiert.
- Neue Felder werden ausschließlich im Botfenster gebunden. Während ein Bestandsdatensatz oder der Empfänger von Menschen bearbeitet wird, wird vor Send erneut verifiziert; kein stiller Override.

## Bedienung

Vollständiges Paket separat entpacken; `MCR_Datenbruecke\START.cmd` → Menü 1 und bestehenden Ordner übernehmen. Anschließend ausschließlich installierte `START.cmd` verwenden. Nach `PASS INSTALLATION_COMPLETE` muss `0.8.1-rc.104` angezeigt werden. Beim ersten Masterlauf beaufsichtigen.
