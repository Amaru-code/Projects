# MCR DATENBRUECKE RC103 – Windows-Prozesspruefung vor Edge-Start

Stand: 20.11.2026. Direktes Update von RC101 oder RC102 auf RC103 ist vorgesehen.

## Reproduzierte Ursache im Quellcode

- `MASTER_UNTERBROCHEN: PROCESS_CHECK_UNAVAILABLE` entstand vor `MASTER_BROWSER_START`.
- Die unveraenderte Prozesspruefung von RC96 bis RC102 verwendete nur `process-guard.ps1` / `Get-CimInstance`, gestartet mit einer starren 8000-ms-Frist.
- Ein Timeout, Startfehler, Windows-WMI-Fehler oder unlesbare JSON-Antwort wurde in einem einzigen pauschalen Fehler zusammengefasst. Der konkrete Fehler auf dem Windows-Arbeitsplatz ist aus der Nutzerkonsole allein nicht nachweisbar.
- Die bereits bei RC101 angezeigte `BESTAND_ERGAENZUNG_OFFEN`-Nachricht ist kein Browser-/Prozessstartfehler.

## Implementierter Fix

1. `tools/process-guard.mjs` prueft vollstaendige Windows-Prozesslisten weiter **vor** dem Browserstart. Die erste `Get-CimInstance`-Abfrage hat nun maximal 18 Sekunden.
2. Scheitert CIM, wird **frisch** ueber `tools/process-guard-wmi.ps1` / `Get-WmiObject -Class Win32_Process` abgefragt (max. 23 Sekunden). Beide enthalten PID, Parent-PID, Prozessname, Startzeit, Kommandozeile und ausfuehrbaren Pfad. Die eigene Node-PID muss in der Liste stehen.
3. Nach einem erfolgreichen WMI-Fallback bevorzugt die aktuelle Botinstanz WMI fuer weitere neue Prozesslisten. Es wird **keine Prozessliste zwischengespeichert**.
4. Das bisherige `process-policy.mjs` klassifiziert weiterhin exakte Instanzidentitaeten und Profil-/Script-Zugehoerigkeit. Unbekannte oder noch laufende Bot-Prozesse blockieren weiter. Ein versagender zweiter Provider fuehrt weiterhin zu `PROCESS_CHECK_UNAVAILABLE`, jetzt mit separaten technischen Ursachen (TIMEOUT, ACCESS_DENIED usw.).
5. `tools/process-stop.ps1` kann bei einem CIM-Fehler die einzelne PID erneut mit WMI abfragen. Vor einer Beendigung sind PID, Parent-PID, Startzeit, Kommandozeile, ausfuehrbarer Pfad und ein geoeffneter Windows-Prozesshandle weiterhin erforderlich. Keine Namens-Wildcards, kein allgemeines `taskkill`.
6. Meldung `PASS PROCESS_CHECK_WMI_FALLBACK` vor `MASTER_BROWSER_START`, wenn der alternative Prozessnachweis benutzt wurde.

## Nicht veraendert

- RC102: Alle vier K:-BAT-Generatorpfade fuer AO/UVA/PP+/DC; vorhandene PDF-Ausgabeordner.
- Eigener Edge/COMARCH-Tab aus RC99, Signatur- und Fehler-/Pause-/Weiterlauf-Logik aus RC100–102.
- Kein Neustart einer ungeprueften Sendung oder Weiterleitung, keine manipulative Aenderung von Journalen, Browserprofil, privatem Mapping oder Workbook.

## Installation und Grenzen

- ZIP in separaten Ordner entpacken, `MCR_Datenbruecke\START.cmd` daraus starten, Menue 1, alte Installation auswaehlen, `PASS INSTALLATION_COMPLETE` abwarten. Danach nur die **installierte** START.cmd benutzen.
- RC101 und RC102 sind per urspruenglichem Manifest-SHA authentifiziert; ein Update direkt von RC101 auf RC103 ist erlaubt.
- Die neuen Provider-/Sperrpfade sind mit Testdoubles geprueft; produktiver Windows-Edge-/COMARCH-Lauf konnte in der Linux-Testumgebung nicht ausgefuehrt werden.
- Falls CIM und WMI zugleich ausfallen oder Windows keinen vollstaendigen Prozessnachweis erlaubt, bleibt der Lauf aus Sicherheitsgruenden angehalten. Bitte die erweiterte Meldung `STOP PROCESS_CHECK_UNAVAILABLE` senden, damit die Windows-Ursache diagnostiziert werden kann.
