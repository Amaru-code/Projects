# RC107 – 24.11.2026
Basis: unverändertes RC106-Installationspaket. Keine Änderungen an AO-Berechnungen, Excel-Generatoren oder Versandregeln.

- Bedienfenster: Start parallel zur Browserbindung, Bereitschaftsprüfung bis 18 Sekunden; verspätetes Fenster bleibt verfügbar, Terminalfreigabe bleibt als Rückfallweg. Keine automatische Versandfreigabe durch Fensterfehler.
- Signatur: begrenzte erneute Suche, exakte Auswahl nach erneuter Ticket-/Member-/Hit-Test-Prüfung; zusätzlich INTL01 und Intel Deutschland als Suchbegriffe. Mehrdeutige oder fremde Optionen bleiben unzulässig.
- Phase-1-Weiterleitung ohne E-Mail: Nachweis aus dem ursprünglichen Listenbereich und beobachteter Weiterleitungsaktion zusätzlich zum bestehenden Erfolgsnachweis. Kein zweiter Weiterleitungsklick. Nicht nachweisbare Fälle werden als offen dokumentiert und für beide Phasen gesperrt; nach sicherer Rückkehr zur Liste können weitere Fälle bearbeitet werden. Alte unklare Weiterleitungen bleiben gesperrt.
- Zeitmessungen für Startvorbereitung, Browserbindung, Listenentscheidung, Diagnose und Bedienfenster. Keine Verkürzung der fachlichen Sicherheitsprüfungen.
- Installation: getrennt entpacken, START.cmd, Menü 1, vorhandenes Ziel übernehmen. Erst PASS INSTALLATION_COMPLETE bestätigt den Softwaretausch.
- Produktives COMARCH und natives Windows-Bedienfenster müssen vor einer unbeaufsichtigten Freigabe auf dem Zielrechner geprüft werden.
