# MCR DATENBRUECKE 0.8.1-rc.94

**Ticketbot und Flow Lab 1.2 gemeinsam.** Originalbasis: das bereitgestellte RC93-Paket und Flow Lab 1.1. Keine produktiven Bestandsdaten, Browserprofile oder Ticketjournale im Paket.

## Installieren und starten

1. ZIP vollständig in einen **separaten** Ordner entpacken.
2. Dort `MCR_Datenbruecke\START.cmd` öffnen und **1** wählen. Vorhandene Installation mit ENTER bestätigen. Auf `PASS INSTALLATION_COMPLETE` achten.
3. Danach die `START.cmd` der **installierten** Version öffnen. Bei **„Live-Karte parallel öffnen?“** genügt ENTER. `N` startet ohne Karte.
4. Wie gewohnt **5** für den Master-Run wählen. Eindeutige Freigaben weiterhin mit ENTER; Identitäts-/PDF-Prüfungen bleiben erhalten.

Die Karte läuft im normalen Browser, COMARCH weiter im eigenen Bot-Edge. Beide lassen sich auf getrennte Bildschirme legen. Im Hauptmenü öffnet **M** die Karte erneut. Mit **`MAP_START.cmd` im installierten Projektordner** lässt sie sich separat starten, auch bevor der Bot arbeitet. Der Klick auf `MAP_START.cmd` bearbeitet keine Tickets.

```text
1  Schnellinstallation / aktualisieren
2  Bestandsdaten / Mapping aktualisieren
3  PHASE 1: Alle geeigneten Tickets bearbeiten
4  PHASE 2: Bearbeiten und weiterleiten
5  MASTER RUN: Phase 1 -> Phase 2
0  Beenden
M  Live-Karte öffnen (nur Anzeige)
```

## Verbundene Live-Karte

Der lokale Nur-Lese-Dienst überträgt geordnete Bot-Ereignisse mit Lauf-ID, Sequenznummer, Phase und Zeitpunkt. Keine erneute Ordnerauswahl. Standard ist der ruhige **Live-Fahrplan**, ohne automatische Kamerafahrten. Die zwölf ursprünglichen Diagramme, 341 Knoten, 429 Kanten, freie Entscheidungen, Simulator und Rückwärtstaste bleiben erhalten. Die Fachmodelle beschreiben weiterhin RC93; RC94 verändert hier die Bedienung und Verbindung, nicht die Fachregeln.

Grün zeigt **protokollierte** Schritte. Ein Klick ist kein Erfolgsnachweis. Fehlende Zwischenmeldungen werden nicht als ausgeführte Schritte erfunden. Bei hoher Ereignisdichte zeichnet die Karte alle gespeicherten Ereignisse bis zum aktuellen Stand, statt den Bot künstlich zu verlangsamen. Die aktuelle Station pulsiert; die Ansicht bleibt ruhig. Grüne Verbindungen beruhen auf vorhandenen Graphkanten bzw. beobachteten Stationsübergängen.

Die Kamera rendert die Detailkarten über eine SVG-`viewBox` statt über eine großflächige CSS-Skalierung. Für den gesamten, sehr großen Graphen gibt es physische Grenzen der Schriftgröße: Der Fahrplan und das zoomunabhängige Lesefenster liefern die lesbare Übersicht. Kein Versprechen, 341 vollständige Texte gleichzeitig auf einem kleinen Bildschirm lesbar zu machen.

## Bedienfenster

- An der Titelleiste ziehen: Position wird gespeichert, auch über mehrere Monitore.
- **−**: auf die Titelleiste einklappen.
- **×**: ausblenden, **nicht** den Bot stoppen.
- Doppelklick auf das MCR-Infobereichsymbol: wieder anzeigen. Rechtsklick bietet Anzeigen, Verstecken, Stoppen.
- Bei verborgenem Fenster erfolgt eine notwendige manuelle Freigabe im Terminal. Verstecken aktiviert **niemals AUTO** und erteilt keine Freigabe.
- Nur Geometrie/Sichtbarkeit stehen in `.runtime\ui\panel-position.json`; weder Ticketinhalte noch Freigaben werden dort gespeichert.

## Browserübergang und Fehler

RC94 hält eine neutrale Masterseite offen und schließt beim Teilprozessende nur die eigene Arbeitsseite. Die lokale Debugverbindung wird begrenzt erneut aufgebaut. Vor einem neuen Teilprozess kann ein nachweislich beendeter **eigener** Browser wieder gestartet werden. Ein aktiver Browser mit unklarem Verbindungszustand wird nicht zwangsweise ersetzt.

**Keine Wiederholung von Versand-, Speicher-, Upload- oder Weiterleitungsklicks.** Die Wiederholung betrifft ausschließlich den lokalen Verbindungsaufbau vor einer Aktion. Bereits bestätigte Tickets bleiben erledigt. Bei unbekanntem Aktionsausgang gelten weiterhin die vorhandenen Sperren/Journale.

Neue systembezogene Fehler: `MCR-SYS-101` (lokaler Edge-Debugzugriff nicht erreichbar), `MCR-SYS-102` (Debuggeradresse passt nicht zum eigenen Port), `MCR-SYS-103` (neutrale Masterseite nicht herstellbar).

## Lokaler Dienst / Datenschutz

Nur `127.0.0.1`, zufälliger Port, Tokenbindung, Host-/Origin-Prüfung, nur GET. Keine externe Website, kein Internetdienst und keine Steuerung von COMARCH aus der Karte. Exportiert werden feste technische Ereigniscodes, Ticketnummer, Phase und Zeitpunkt, **keine Namen, MemberIDs, E-Mail-Adressen, Kundentexte oder Pfade**. Ticketnummern sind dennoch interne Daten: Karte und Dateien nicht öffentlich freigeben.

Dateien: `.runtime\flow\events.jsonl` (aktueller/letzter Lauf) und `bridge.json` (lokale Dienstverbindung). Der Dienst bleibt nach dem Botlauf verfügbar, damit die Karte verbunden bleibt. Beim Softwareupdate wird der zugehörige Dienst beendet; danach die Karte über die installierte Version erneut öffnen. Alte Links können nach einem Dienstneustart ungültig sein. Ein Ausfall der Karte erteilt keine Freigabe und beendet nicht absichtlich den Bot.

Falls Unternehmensrichtlinien lokale Browseradressen sperren, die Richtlinie **nicht** umgehen. Der Bot funktioniert ohne Karte weiter; die HTML-Datei unter `tools\flow-lab` bleibt als Simulator verwendbar, einschließlich des bisherigen freigegebenen Ordnerlesewegs. Ein manuell als Datei geöffnetes HTML verbindet sich nicht automatisch mit einem beliebigen Dienst.

## Umfang der Prüfung

Automatisierte Node-/Chromium-Tests sowie isolierter Update-/Rückwegtest mit synthetischen Daten; siehe `docs/RC94_RELEASE.md` und den ausgelieferten Prüfbericht. **Keine produktive COMARCH-Ausführung und kein nativer Windows-WinForms-Live-Test in dieser Umgebung.** Der vollständige Windows-Durchlauf ist deshalb beaufsichtigt zu prüfen. Die ursprüngliche Ursache des gemeldeten `fetch failed` ist aus dem Konsolenlog nicht eindeutig bewiesen.

## Wartung

`node tools/cli.mjs --selftest`, `--demo`, `--status`, `--review`, `--rollback`, `--map`. Update/Rückweg ändern Software, nicht den gespeicherten Kundenbestand. Original-Code und spätere Freigaben weiterhin ausschließlich über das versionsgebundene Paket verwenden.
