# RC98 – Automatische Bestandspruefung beim Start

- Installierte Software: beim Oeffnen des Hauptmenues XLSX auf K: automatisch einlesen.
- Nur lokale Bestandssnapshots, **keine** FM/FN-Schreibaktionen und keine COMARCH-Aktionen am Start.
- Start nur, wenn die eigene Bot-Prozessgruppe ruht; fremde und aktive Prozesse bleiben unberuehrt.
- Wird die XLSX nicht gelesen, erscheint `WARN STARTUP_BESTAND_NICHT_AKTUELL` mit Fehlercode. Menue 3/4/5 muss wie zuvor vor Ticketaktionen unabhaengig die XLSX erfolgreich lesen.
- Menue 2 bleibt fuer Kontakt-Wiederaufnahme und explizite Wartung vorhanden.
- RC97-Installationen werden ausschliesslich bei gueltigem RC97-MANIFEST akzeptiert; private_data, config, .runtime und Laufjournale bleiben erhalten.
