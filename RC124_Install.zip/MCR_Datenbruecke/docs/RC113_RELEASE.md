# RC113 – Ruhiger AO-Kontakteingabemodus

Basis: Original-RC112-Paket. Die zentralen Berechnungsformeln auf K: bleiben unveraendert.

- Ein bestehendes MCR-Terminal fuer beide Eingaben. Klarer Kontext (Ticket, WWID, Person, fehlendes Feld). Keine zweite Konsole.
- Node-Fortschritt und Konsolenausgaben der Ticketsteuerung werden waehrend der Frage unterdrueckt. Beide Zeitbudgets (Node und Python) zaehlen ausschliesslich aktive technische Arbeit; Nutzerwartezeit ist ausgenommen. Keine automatische Fortsetzung ohne Eingabe.
- Adresse und PLZ einzeln auf dieselbe Generatorinstanz uebertragen. Rueckmeldung je Feld, Speichermeldung erst nach Readback. Eingabewerte nicht ins Bot-Protokoll schreiben.
- ENTER ohne Wert / UEBERSPRINGEN oder an Node gelieferter Strg+C waehrend der Frage: Einzelfall kontrolliert zurueckstellen. Keine erneute Generierung innerhalb desselben Versuchs. Falls Windows den gesamten Batch extern unterbricht, muss der Zustand beim naechsten Lauf geprueft werden.
- Keine Aenderung an Berechnungsformeln, PDF-/Auditvalidierung, Anlagennachweis, Phase 1 oder Aktionsjournal-Schutz. Weiterleitung intern an Mark, keine E-Mail in Phase 2.
