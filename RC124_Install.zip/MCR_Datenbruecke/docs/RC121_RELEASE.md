# MCR Datenbrücke 0.8.1-rc.121

## Start von Phase 1

RC120 prüfte beim Start zuerst die gespeicherte Suche `In_Bearbeitung`. Blieb der Eintrag unsichtbar, konnte der Lauf schon an dieser Stelle mit `MCR-P1-112` enden. Die Warteschlange `INTL01` kam dann gar nicht an die Reihe.

RC121 sucht im Einzelpiloten und im Folgelauf in beiden zugelassenen COMARCH-Listen. Hat die erste Liste einen passenden Vorgang, behält sie Vorrang. Ist sie unlesbar, prüft der Bot die Warteschlange vor dem Neuladen oder einer Rückfrage. Findet er dort ein geeignetes Ticket, zeigt `P1_FORTSETZUNG_AUS_GEPRUEFTER_LISTE` die benutzte und die noch offene Liste an.

Die Navigation erkennt auch „In Bearbeitung“ mit Leerzeichen und Einträge mit einem separaten Zähler. Bei verdecktem Menü kann eine eindeutig zur sichtbaren Tabelle gehörende Listenbezeichnung die aktuelle Suche bestätigen. Ticketnummer und Liste werden vor dem Öffnen erneut geprüft.

## Wenn kein weiteres Ticket gefunden wird

Zum Abschluss von Phase 1 müssen beide Listen geprüft sein. Fehlt für eine Ansicht noch der Nachweis, versucht der Bot, sie im selben Edge-Tab erneut zu lesen. Falls eine Bedienaufforderung erscheint, im Bot-Edge die dort genannte **gespeicherte Liste** auswählen und anschließend im MCR-Fenster ENTER drücken. Bleibt die Zuordnung offen, nennt das Masterprotokoll die noch fehlenden Listen. Der Tabellenstatus `READY` bedeutet, dass die Tabellenzeilen lesbar sind. Die Zuordnung zur gespeicherten Suche wird separat geprüft.

## Update von RC120

`RC121_Install.zip` in einen separaten Ordner entpacken. Die dortige `MCR_Datenbruecke\START.cmd` öffnen, **1** wählen und die vorhandene Installation als Ziel übernehmen. Nach `PASS INSTALLATION_COMPLETE` und dem Titel **0.8.1-rc.121** startet **5** den Master-Lauf. Phase 1 kann dabei echte Standardantworten versenden.
