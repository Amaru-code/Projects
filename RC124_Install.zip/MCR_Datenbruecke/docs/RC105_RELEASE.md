# MCR Datenbruecke 0.8.1-rc.105

Stand: 20. November 2026. Grundlage: unverändertes RC104-Installationspaket.

## Auszahlungsoption automatisch erzeugen und anhängen

Bei einem passenden Phase-2-Auftrag wie „Möchte Auszahlungsoption“, „Möchte AO“
oder „Möchte Kontoauszug & Auszahlungsoption“ verwendet der Bot weiterhin die
verifizierte COMARCH-Person. Die WWID muss aus dem ausdrücklich beschrifteten
WWID-Feld oder der gebundenen INTL01-Memberreferenz stammen. MercerID und WWID
werden nicht pauschal gleichgesetzt.

Der zentrale Generator bleibt hier:

```text
K:\INTL01\6_AU (Admin)\Berechnungen - UV & Renten (PP+, DC+)\Auszahlungsoption\auszahlungsoption_generator.py
```

Der Bot ruft dessen vorhandene Funktion `create_pdf(wwid)` über einen kleinen
Adapter auf. Die Berechnungsformeln, Excel-Blätter, Kontrollmappe und
Beitragslogik werden nicht in den Ticketbot kopiert oder verändert.

Die bekannte Stichtagsabfrage wird mit leerer Eingabe beantwortet, also wie
ENTER. Das ist der 31.12. des aktuellen Jahres: im Jahr 2026 der 31.12.2026.
Eine freie Stichtagsableitung aus Kundentext ist nicht Bestandteil dieser Version.

Ausgabe und Erfolgs-Audit kommen aus:

```text
K:\INTL01\6_AU (Admin)\Berechnungen - UV & Renten (PP+, DC+)\Auszahlungsoption\Ausgabe PDF
K:\INTL01\6_AU (Admin)\Berechnungen - UV & Renten (PP+, DC+)\Auszahlungsoption\Audit_Logs
```

Der Generator kann einen kanonischen UNC-Pfad zurückgeben. Die Anbindung prüft
die Datei am bestätigten Ausgabeort und bindet PDF und Audit an denselben
Aufruf, die WWID, den Namen und den Stichtag. Die fertige PDF muss vollständig
geschrieben sein; Dateigröße und SHA256 werden festgehalten und vor den
weiteren Aktionen erneut verglichen.

Alte AO-Dateien anderer Jahre werden nicht willkürlich ausgewählt. Der Bot
verwendet das genaue Ergebnis des aktuellen Generatoraufrufs. Der zentrale
Generator darf wie bisher seinen Datensatz in der Arbeitsdatei aktualisieren
und seine gleichnamige Ergebnisdatei ersetzen. Andere Ergebnisdateien werden
vom Bot nicht gelöscht.

Für einen neuen reinen AO-Auftrag mit verifizierter UI-WWID entfallen sowohl
`PDFS_BEREIT` als auch eine zusätzliche Bereitschafts-/Inhaltsbestätigung vor
der Anlage. Der Nachweis lautet ausdrücklich **automatisch für Mark vorbereitet**.
Er behauptet keine menschliche Prüfung der Berechnung. Das Ticket erhält
weiterhin den Status „Bearbeitet not reviewed“ und geht zur fachlichen Prüfung
an `mark.baindl`. Phase 2 versendet keine Kunden-E-Mail.

Bei kombinierten Aufträgen bleiben die vorhandenen DC-/PP+-Prüfregeln erhalten.
Eine notwendige Inhaltsprüfung der alten Kontoauszüge wird deshalb nicht durch
einen AO-Audit ersetzt. UVA erhält keine neue automatische Anlageregel.

## BAT oder Python im Bot?

RC105 verwendet den **zentralen Python-Generator über einen kleinen Adapter**.
Die vorhandene `START_Auszahlungsoption.bat` bleibt unverändert für die manuelle
Bedienung. Sie kann bei der Erkennung des passenden Python-Interpreters helfen.
Die Suche berücksichtigt `.venv`, `venv`, eine eindeutig lesbare
Interpreterzeile der BAT sowie `py.exe -3` und `python.exe`. Vor einer Berechnung
werden Python, pywin32 und die erwartete Skriptschnittstelle geprüft.

Der eigentliche Aufruf startet ohne Shell und ohne zusätzliches CMD-Fenster.
Die abschließende BAT-Pause wird dadurch gar nicht aufgerufen. Es bleibt kein
Fenster zurück, das durch ENTER geschlossen werden müsste.

Es gibt genau einen Berechnungsaufruf je Versuch. Ein Interpreterwechsel ist
nur während der schreibfreien Vorprüfung zulässig. Nach einem unklaren
Berechnungsergebnis wird nicht automatisch ein zweites Mal gerechnet.

## Wartezeit, Sperren und Ausnahmefälle

Die normale Berechnung darf bis zu neun Minuten laufen. Alle 15 Sekunden wird
ein Fortschrittshinweis ausgegeben. Eine Betriebssystem-Dateisperre verhindert
gleichzeitige AO-Berechnungen durch diese Bot-Anbindung. Die zusätzliche Prüfung
der Excel-Besitzerdatei erkennt eine bereits geöffnete AO-Arbeitsdatei.

Die Bereinigung betrifft nur die nachweislich neu gestartete Excel-Instanz
dieses Aufrufs. Bereits laufende fremde Excel-Prozesse werden nicht geschlossen.
Die bestehende manuelle BAT verwendet die neue Bot-Sperre nicht selbst.

Fehlende Adresse/PLZ, eine gesperrte Arbeitsdatei, nicht erreichbares K:, fehlendes
Python/pywin32 oder ein echter Berechnungsfehler werden mit einer konkreten
Ursache protokolliert. Der Bot erfindet keine Eingaben und hängt keine alte PDF
als Ersatz an. Solange keine COMARCH-Schreibaktion begonnen wurde, bleibt dieses
Ticket offen und der Lauf kann andere geeignete Tickets bearbeiten.

Vor der Anlage wird die COMARCH-Person erneut gebunden. Ein Memberwechsel,
verschwundene WWID-Evidenz oder eine nachträglich geänderte PDF geben keine
Anlage frei. Bereits vorhandene gleichnamige Anhänge werden nicht doppelt
hochgeladen; unklare frühere Upload-/Speicher-/Weiterleitungsjournale behalten
ihre bestehenden Wiederaufnahmeprüfungen.

## Automatischer Übergang zwischen den Phasen

Das RC104-Protokoll zeigt einen erfolgreichen Übergang nach
`NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS`. Die vorherigen Unterbrechungen entstanden
an `WORKBOOK_DATA_CHANGED`, bevor ein neues Ticket geöffnet wurde.

RC105 prüft zunächst die erlaubten Listen. Ist Phase 1 nachweislich leer,
geht der Master automatisch weiter. Liegt ein neues Ticket vor und hat sich
der Bestand verändert, beendet der Teilprozess sauber an dieser Grenze. Der
Master liest den Bestand neu ein und bindet erforderlichenfalls einen neuen
Einzelpiloten im selben Browser. Bestätigte Abschlüsse bleiben erhalten.

Vor Phase 2 wird der Bestand ebenfalls frisch gebunden. Zwischen vollständig
beendeten Phase-2-Tickets ist eine begrenzte Neubindung möglich. Innerhalb eines
aktiven Tickets bleiben die Bestandsprüfungen streng. Eine bereits begonnene
Aktion wird nicht unter einer still ausgetauschten Datenbasis wiederholt.

Es sind höchstens drei Neubindungen je Phase-1-Master beziehungsweise
Phase-2-Lauf vorgesehen. Ein ausdrücklicher ABBRUCH führt nicht zur Fortsetzung.

Der fachliche Fingerprint ignoriert neu angelegte Leer-, Formatierungs- und
reine Kontaktzeilen. Formel-/Fehlerspalten werden in fester Reihenfolge
verglichen. Echte Änderungen an verwendeten Bestandswerten bleiben erkennbar.
Ohne die damalige XLSX ist nicht bewiesen, welcher konkrete Excel-Unterschied
die beiden gemeldeten RC104-Unterbrechungen auslöste.

## Bewusst geänderte Empfängeradresse

Der bestätigte neue Empfänger wird nun mit einem ticketgebundenen Freigabebeleg
bis zur tatsächlichen Verlaufsprüfung weitergegeben. ENTER oder JA bestätigt
die angezeigte neue Adresse nach erneutem Rücklesen.

Die Prüfung verlangt weiterhin genau eine neue passende Ausgangsnachricht,
die richtige Adresse, das richtige Ticket und den richtigen Inhalt. Die alte
Prüfung `RECIPIENT_NOT_ORIGINAL_SENDER` blockiert den ausdrücklich genehmigten
Adresswechsel nicht mehr. Es gibt weiterhin nur einen Versandklick.

## Installation

1. `RC105_Install.zip` vollständig in einen separaten Ordner entpacken.
2. Darin `MCR_Datenbruecke\START.cmd` starten, Menü **1**, vorhandene Installation wählen.
3. Nach `PASS INSTALLATION_COMPLETE` nur die installierte `START.cmd` verwenden.
4. Der Titel muss **0.8.1-rc.105** anzeigen. Menü **5** startet den Master;
   Menü **4** bleibt für die getrennte Phase 2 verfügbar.

Private Daten, Konfiguration, Browserprofil und bisherige Journale bleiben am
Ort. Das Update selbst versendet keine Nachrichten und führt keinen
AO-Generator aus. Der genaue Testumfang steht im Prüfbericht dieser Version.
