# MCR Datenbrücke 0.8.1-rc.123

## Ticketliste beim Start von Phase 1

RC122 meldete im betroffenen Lauf 26 sichtbare Menüelemente unter „Meine Vorgänge“ und 22 unter „Warteschlange“. Die Erkennung blieb vor der Auswahl des ersten Tickets stehen.

Frühere COMARCH-Aufnahmen zeigen den Namen der gespeicherten Suche mit einer separaten Trefferzahl im Menü. Außerdem steht der aktive Filter im Ergebnisbereich zwischen der Gruppenüberschrift und „Suchkriterien“. RC123 nutzt beide Anzeigen.

- Im Menü sucht der Bot die exakte Beschriftung im zugehörigen Abschnitt. Ein separater Trefferzähler und benachbarte Menüeinträge können diese Beschriftung umgeben. Gleichnamige Einträge in einem anderen Abschnitt und ähnlich benannte Suchen bleiben unterscheidbar.
- Ist die richtige Suche bereits geöffnet, kann der Bot den Gruppennamen, den aktiven Filter und „Suchkriterien“ über der passenden Ergebnistabelle bestätigen. Beim Start liest er diese Anzeige und die zugehörigen Zeilen zweimal. Dieser Weg erscheint im Terminal als `PASS P1_AKTIVER_LISTENFILTER`.
- Falls eine manuelle Auswahl nötig ist, den genau benannten **Filter** im Bot-Edge einmal anklicken und nach Anzeige der Liste im Terminal Enter drücken. Der Bot beobachtet diesen Klick und den Wechsel der Tabelle. Bei bestätigter Auswahl erscheint `PASS P1_LISTE_MANUELL_GEBUNDEN`.

Sobald ein geeignetes Ticket geöffnet ist und seine Nummer in der Detailansicht stimmt, erscheint `PASS P1_TICKET_GEOEFFNET` mit der Ticket-ID. Bei leerer eigener Liste prüft der Bot die gespeicherte Warteschlange `INTL01`. Ticketjournal, Versandfreigabe und Empfängerprüfung gelten im weiteren Ablauf.

## Installation von RC122 aus

1. `RC123_Install.zip` in einen separaten Ordner entpacken.
2. Dort `MCR_Datenbruecke\START.cmd` öffnen, im Menü **1** wählen und die vorhandene Installation als Ziel übernehmen.
3. Nach `PASS INSTALLATION_COMPLETE` den Menütitel **0.8.1-rc.123** prüfen. **3** startet Phase 1, **5** den Master-Lauf. Beide können in Phase 1 echte Standardantworten versenden.

## Prüfumfang

Im lokalen Chromium-Vergleich liefen RC119, RC122 und RC123 gegen dieselbe nachgestellte Menüform mit sichtbaren Einträgen. RC119 erkannte die exakte Beschriftung, RC122 meldete `CHILD_NOT_VISIBLE`, RC123 öffnete das erwartete Testticket. Weitere Browserfälle prüfen die Filteranzeige rechts, eine leere eigene Liste mit einem Ticket in der Warteschlange, eingeklappte Gruppen und die manuelle Listenauswahl. Die Tests enthalten fiktive Tickets. Eine Bestätigung im produktiven Windows-Edge steht aus.
