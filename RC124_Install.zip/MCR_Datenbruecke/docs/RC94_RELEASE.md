# RC94 · Bot und Live-Karte

## Tatsächliche Grundlage und Diagnose

Grundlage sind `RC93_Install(2).zip` und `MCR_Flow_Lab_1_1_Paket(1).zip` aus dieser Unterhaltung. Die Bot-Fachlogik wird übernommen, nicht neu erfunden.

Im vorgelegten Echtlauf vom 17.11.2026 ist Ticket 89489272 mit Versand- UND Speichernachweis abgeschlossen. Erst der nachfolgende Phase-1-Teilprozess scheitert in INITIAL mit `fetch failed`, vor einer neuen Ticket-ID. Im RC93-Quellcode liegt unmittelbar nach der Meldung zur Browserwiederverwendung der lokale HTTP-Abruf des Debugendpunkts. Die genaue Ursache des nicht erreichbaren Endpunkts (Browser beendet, lokaler Netzwerk-/Prozesszustand usw.) ist damit **nicht** endgültig bestimmt. RC94 schützt nachgewiesene Schwachstellen des Verbindungs-/Lebenszyklus, ohne eine erfundene COMARCH-Ursache zu behaupten.

Im Original-Flow-Lab-Parser werden `MASTER_BROWSER_WIEDERVERWENDET` und `P2_MASTER_BROWSER_WIEDERVERWENDET` gemeinsam auf den Phase-2-Knoten abgebildet. Das ist ein direkt im Quellcode bestätigter Darstellungsfehler. RC94 trennt die Meldungen nach Phase/Teilprozess.

## Implementierung

- `lib/flow-events.mjs`: datensparsame Laufereignisse, Sequenznummern, getrennte stdout/stderr-Decoder, fest definierte Journalstufen.
- `lib/flow-server.mjs`: loopbackgebundener HTTP-/SSE-Nur-Lese-Dienst, Token, Origin/Host-Prüfung, Wiederverbindung/Cursor, Laufwechsel trotz schneller Dateikürzung.
- `lib/flow-launcher.mjs`, `tools/flow-map-server.mjs`, `MAP_START.cmd`: eigener Kartenstart und automatische Wiederverwendung des lokalen Dienstes.
- `tools/cli.mjs`: Startangebot und M-Verknüpfung, strukturierte Ereignisse aus beiden Phasen, Browserprüfung vor dem nächsten Teilprozess.
- `tools/flow-lab/MCR_Flow_Lab_RC94.html`: Originaldiagramme/Simulator erhalten, exakte Phasenzuordnung, stabile Fahrplankamera, SVG-ViewBox, sichtbare lokale Verbindung.
- `lib/cdp.mjs`, `src/local-bot-full-run.mjs`: maximal vier Verbindungsversuche, eigene neutrale Browserseite, frische Arbeitsseite, kein Schließen der letzten Seite ohne Ersatz; echte Browserbindung erst nach Aufbau als PASS melden.
- `tools/panel-shell.ps1`, beide bestehenden Fenster und `lib/delivery-console.mjs`: gemeinsame helle Oberfläche, Verschieben/Einklappen/Verstecken, Infobereich, manuelle Terminalfreigabe bei verborgenem Panel.
- `tools/deploy.mjs`, `tools/integrity.mjs`, `tools/process-guard.mjs`: versiegeltes gemeinsames Paket, Launcher im Update/Rückweg, ausschließlich exakter Nur-Lese-Dienst als zulässiger Parallelprozess. Update darf den eigenen Dienst weiterhin beenden.
- `lib/ticket-error-catalog.mjs`: konkrete Systemcodes für Verbindungsfehler statt einer irreführenden Ticket-Fachregelmeldung.

## Grenzen und keine Nebenwirkungen

Die Karte ist kein Fernsteuerungsweg. Sie kann weder Senden noch Speichern, Routing oder AUTO freigeben. Die produktiven Prüfungen und Aktionsjournale bleiben maßgeblich. Eine Verbindungserneuerung wiederholt keinen Ticketlauf und keinen schreibenden Klick. Browserreaktionen im Simulator sind weiterhin Simulationen. LenX und Phase 3 bleiben das gekennzeichnete Zukunftsmodell.

Der Ereignisleser prüft im Normalbetrieb alle 80 ms; die Oberfläche zeichnet über requestAnimationFrame. Das sind Implementierungseinstellungen, keine zugesicherte Ende-zu-Ende-Latenz auf beliebiger Hardware. Gleichzeitige Ereignisse können gemeinsam gezeichnet werden; sie bleiben geordnet im Verlauf. Es gibt keine künstlich langsame Vorführung, die als Echtzeit ausgegeben wird.

## Testnachweise

Der separat ausgelieferte `RC94_Pruefbericht.txt` nennt Testzahlen und Testumgebung. Alle übernommenen Regressionen sind im Paket enthalten; die neuen Tests stehen in `tests/rc94-integration.test.mjs`. Die Browser-UI und der echte HTTP/SSE-Transport wurden getrennt geprüft: Die hier vorhandene verwaltete Chromium-Umgebung blockiert Browsernavigation zu 127.0.0.1 mit `ERR_BLOCKED_BY_ADMINISTRATOR`. Diese Richtlinie wurde nicht umgangen. Daher ist der vollständige integrierte Browser-/Windows-Echtlauf als **noch nicht abgenommen** ausgewiesen.

Ein Browserfoto, ein erfolgreiches Unit-Test-Ergebnis oder eine synthetische Vorschau sind kein Beleg für einen bereits produktiv durchgeführten RC94-Lauf.
