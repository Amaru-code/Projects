# RC95 · WWID-Auswahl und Originalkarte

Stand: 18. November 2026.

## Gemeldeter Fehler

Im bereitgestellten Protokoll endet Ticket `89419822` während `MAIL_AND_PERSON` mit `NAME_CHOICE`. Der Dialog bot zwei Namenshinweise an, wandelte die Eingabe jedoch ausschließlich mit `Number()` in eine Listennummer um und verlangte 1 bis zur Anzahl der Kandidaten. Die eingegebene Kennung `11370121` verletzte diese Bedingung. Der Fehler wurde anschließend vom Master als `LIVE_NOT_VERIFIED` zusammengefasst.

Es handelt sich um einen reproduzierbaren Dialog-/Validierungsfehler vor dem Versandpfad. Die Eingabe wurde nicht als WWID an die Member-Auflösung übergeben. Das Protokoll beweist keine fehlgeschlagene WWID-Suche im tatsächlichen Bestand: Eine solche Suche fand an dieser Stelle noch nicht statt.

## Änderungen im Runner

- `lib/person-choice.mjs`: Listennummer, WWID-Suchhinweis und ausdrücklich eingegebene MercerID werden getrennt geparst. Tippfehler führen zurück zur Eingabe. Führende Nullen bleiben Teil der Kennung.
- `src/local-bot-full-run.mjs`: Der Personendialog kann die Kennung bis zur gebundenen Member-Suche weiterreichen. Nach unabhängiger Profil-/Namens-/Kennungsprüfung kehrt der Ablauf in die bestehenden Verarbeitungsschritte zurück. Ein Wechsel zurück zur Namensnummer erzwingt eine neue Namenssuche.
- Ticketbindung wird nach Benutzerpausen und vor der Auswahl eines erneut gelesenen Vorschlags geprüft. Eine veränderte Ticketansicht wird nicht als gültiger Treffer übernommen.
- `lib/preaction-skip.mjs`: ausdrückliches Überspringen bleibt auf den Zustand vor Schreibaktionen ohne ungeklärtes Journal begrenzt. `ABBRUCH` bleibt ein echter Laufabbruch.
- `lib/ticket-error-catalog.mjs` und `tools/cli.mjs`: konkrete Ursachen für die Personenauswahl, ausdrücklichen Abbruch und fehlende Ticketbindung.

Die Kennung überschreibt niemals eine ausdrücklich in der Originalnachricht angegebene `expectedId`. Vollständiger Originalname, bestätigter COMARCH-Member und die bestehenden Versand-/Speichernachweise bleiben erforderlich. Netzwerk-, Profil- oder Ticketbindungsfehler werden nicht pauschal als Tippfehler wiederholt.

## Änderungen der Darstellung

Das Original-`graphData` mit 12 Diagrammen, 341 Knoten und 429 Kanten bleibt bytegleich. Sein SHA256 ist `91b221990624477c4042ce30272e06dacbd25387ed0eff1bde81eab32b1978af`.

- Der Fahrplan ersetzt die irreführenden linearen Reihen durch 25 Stationen mit beschrifteten Fachzweigen, Schleifen und Ausnahmen.
- Kontextzeile mit Phase, aktueller Station, jüngster Meldung und bedingtem Folgeschritt.
- Stabile Stationselemente bei neuen Ereignissen. Kein vollständiger Kartenaufbau pro Meldung; Scrollposition und Fokus werden erhalten.
- Lokale, kurze Kantenanimation ausschließlich für frische belegte Stationswechsel. Keine verzögerte Wiedergabe alter Meldungen als Echtzeit.
- Der aktuelle Verlauf ist auf Ticket, Phase und Lauf begrenzt. Frühere Ticketabschlüsse werden nicht auf den nächsten Fall übertragen.
- Reset und Wiederverbindung entfernen alte Abschlusszustände. Globale Ergebnisberichte tragen keine alte Ticket-ID. Ein neutraler Browserabschluss überschreibt weder einen belegten Erfolg noch ausgewiesene offene Fälle.
- WWID-Rückfragen erscheinen als wartende Personenklärung. Ein Zuordnungsnachweis erteilt keine Versandfreigabe.
- Native SVG-Texte dort, wo der vollständige Text im vorhandenen Knoten passt. Bei kleinerem Maßstab kollisionsarme Kurzbeschriftungen in Bildschirmgröße, Priorität für aktuelle Station und Ausgänge.
- Verschiebbares, einklappbares und ausblendbares Lesefenster. Der SVG-Export verwendet wieder den gesamten Diagrammausschnitt.

Die frühere native SVG-viewBox-Kamera der hier verwendeten RC94-Fassung wird beibehalten. Die neue Verbesserung besteht in der zusätzlichen Beschriftungsebene, der Textdarstellung und dem Fahrplan.

## Basis und Update

Arbeitsbasis ist die historische RC94-Paketfassung, deren Logtexte und Kartenstarter mit dem Kundenprotokoll übereinstimmen. Die vorhandene `#bridge`-/`events`-Verbindung bleibt bestehen. Der Installer erkennt zwei tatsächlich vorliegende RC94-Ausgaben ausschließlich anhand ihrer verifizierten Manifest-Prüfsummen; Integritätsprüfung und Rückweg werden nicht gelockert.

Ein zusätzlicher `MAP_OEFFNEN.cmd`-Alias verwendet denselben Kartenstart wie `MAP_START.cmd`. Software-Update und Rückweg behandeln beide bekannten Starter. Daten, Konfiguration und Aktionsjournale werden nicht durch Demoinhalte ersetzt.

## Abnahme

Die ausgeführten Prüfungen und die noch nicht durchgeführte Windows-/Edge-/COMARCH-Abnahme stehen in `RC95_Pruefbericht.txt`. Ein bestandener isolierter Dialogtest beweist die Reparatur des Eingabepfades; er beweist nicht, dass die reale Kennung `11370121` bereits im produktiven System verifiziert oder das Ticket versendet wurde.
