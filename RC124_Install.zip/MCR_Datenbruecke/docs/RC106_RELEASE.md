# MCR DATENBRUECKE 0.8.1-rc.106

Stand: 20. November 2026. Grundlage: unverändertes RC105-Paket.

## Warum RC105 nach der AO-Berechnung stoppte

Der Master erledigte Phase 1 und öffnete Phase 2 erfolgreich. Ticket 89664431
wurde mit dem verifizierten Member Boris Schmulewitsch und WWID 11369951
an die zentrale AO-Berechnung übergeben. Der Generator lieferte eine vollständige
2026-12-31-PDF sowie einen passenden Erfolgs-Audit. Die COMARCH-Anlage wurde
noch nicht ausgeführt.

Unmittelbar anschließend prüfte die Phase-2-Laufsteuerung weiterhin die
Geschäftsdatenbindung vom Beginn des Tickets. Inzwischen war ein anderer
Business-SHA256 für die Quell-XLSX erkannt worden. **Welches Feld tatsächlich
geändert wurde, ist ohne die beiden Quellzustände nicht bekannt.** RC105
unterbrach deswegen die gesamte Bearbeitung mit `WORKBOOK_DATA_CHANGED`.

## Sichere Neubindung nach externer AO-Berechnung

RC106 prüft exakt an der Grenze zwischen bestätigter PDF-Erstellung und
irgendeiner COMARCH-Schreibaktion den aktuellen Excel-Bestand. Wenn eine
neue Fachdatenbindung benötigt wird, erstellt er sie nur über den bereits
freigegebenen offiziellen XLSX-Importweg. Für die konkrete WWID vergleicht er
alle verifizierten MCR-Mapping-Datensätze inklusive USC, Flags, Gender und
ursprünglicher Quellzeilen. Andere Mitarbeiter können sich ändern, ohne dass
deshalb der aktive Vorgang automatisch verworfen wird.

Wenn die personenbezogenen Fachdaten gleich bleiben, darf die verifizierte
AO-PDF weiter zum bestehenden Upload-/Speicher-/Weiterleitungsprozess gehen.
Bei Änderungen oder fehlenden/gesperrten Daten der verifizierten WWID wird
**nur dieses Ticket** ohne COMARCH-Schreibaktion zurückgestellt. Die
aktualisierte Bestandsbindung steht den anderen Tickets weiter zur Verfügung.
Ein weiterer Quellwechsel *während* des Neubindens führt zur sicheren Sperre;
keine Ticketaktion wird wiederholt. Außerhalb dieser nachgewiesenen
No-Write-Grenze wird `WORKBOOK_DATA_CHANGED` weiterhin nicht ignoriert.

## Vorhandene AO aus einem abgebrochenen RC105-Lauf

Bevor RC106 einen neuen AO-Generator ausführt, prüft es für dasselbe Ticket
zunächst vorhandene `MCR_PHASE2_PDF_BELEG_...json` im gesicherten Laufbestand.
Nur bei passender Ticket-ID, identischem verifiziertem COMARCH-Member,
WWID, Jahresstichtag, Erfolgs-Audit und identischen PDF-Hashes kommt eine
Wiederverwendung in Betracht. Das letzte Ergebnis muss aus den vergangenen
24 Stunden sein. Der Ticket-Aktionsjournalordner darf noch keine
COMARCH-Schreibaktion enthalten.

Neue RC106-Nachweise tragen einen personenbezogenen Bestandsfingerabdruck.
Wenn dieser beim nächsten Start exakt zu den aktuellen MCR-Mappingdaten passt,
wird die AO ohne erneuten Generatorlauf verwendet. Ein alter RC105-Nachweis
hat diesen Datensatzfingerabdruck noch nicht. Die einmalige menschliche
Freigabe für die bestätigte PDF und den aktuellen Fachstand ist deshalb
notwendig. Diese Freigabe startet **keine** zweite Berechnung.

Eine manipulierte PDF, ein fehlender Audit, eine andere Member-ID oder
geänderte personenbezogene Fachdaten geben weder die alte Anlage noch einen
stillen neuen Generatoraufruf frei. Bei einem unklaren alten Beleg bleibt
dieses Ticket zur unabhängigen Prüfung offen.

## Bestehende Sicherheitsregeln

- Echte Mailversände bleiben Phase 1 vorbehalten. Phase 2 hat keinen
  E-Mail-Versandpfad.
- Der automatische AO-Generator bleibt zentral auf K:; keine Kopie seiner
  Finanzformeln wird verteilt.
- Genaue COMARCH-Member-/WWID-Prüfung bleibt vor Datei-Upload, Speichern,
  Entwurf und Weiterleitung aktiv.
- Bereits gestartete unbestätigte COMARCH-Schreibaktionen bleiben gesperrt;
  keine blinden Wiederholungsklicks, keine gelöschten historischen Journale.
- Der Softwaretausch ändert `private_data`, Profil, Konfiguration oder
  `.runtime` nicht.

## Installation

RC106-Installationspaket separat entpacken, enthaltene
`MCR_Datenbruecke\START.cmd` starten, Menü 1 und vorhandene Installation wählen.
Nach `PASS INSTALLATION_COMPLETE` nur die installierte `START.cmd` verwenden.
Menü 4 führt direkt zu Phase 2, Menü 5 startet Master Phase 1 → Phase 2.
