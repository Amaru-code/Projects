# RC119 für die MCR Datenbrücke

## Installation

Das vollständige ZIP in einen separaten Ordner entpacken. Darin `MCR_Datenbruecke\START.cmd` öffnen und Menü 1 wählen. Bei einer bestehenden RC118-Installation zeigt der Installer den Wechsel auf `0.8.1-rc.119` an. Nach `PASS INSTALLATION_COMPLETE` die installierte `START.cmd` verwenden. Menü 4 startet Phase 2. Menü 5 startet den Master-Lauf mit produktivem E-Mail-Versand in Phase 1.

## Signatur und Versandverlauf

Die Signatursuche übernimmt einen sichtbaren exakten Vorschlag. Andernfalls beginnt sie im leeren Feld mit `INTL01`. Benötigt die Vorschlagsliste mehr Buchstaben, hängt der Bot die fehlenden Zeichen an und prüft erneut. Auch ein verzögert erscheinender Vorschlag muss zum aktuellen Feld im gleichen Ticket gehören. Nach der Auswahl prüft der Bot die vollständige Signatur bei einem Fokuswechsel. Eine fremde Auswahl braucht eine Entscheidung für dieses Ticket.

Unmittelbar vor dem Versand liest der Bot den Nachrichtenverlauf des geöffneten Tickets. Taucht dort bereits eine Standardantwort auf, kann der Bot den Fall vor dem Versandklick zur Prüfung zurückstellen. Nach dem Klick vergleicht er die Nachrichten bis zu 60 Sekunden mit dem zuvor gelesenen Stand. Für den automatischen Nachweis braucht er eine neue, stabil sichtbare Ausgangsnachricht mit passendem Empfänger, Betreffbezug und Antworttext. Die Ausgabe nennt den noch fehlenden Nachweis. Bei ungeklärtem Ausgang bleibt die Sichtprüfung am bestehenden Verlauf möglich.

## Auszahlungsoption mit fachlichem Berechnungsfehler

Ergibt der zentrale Generator einen zugeordneten Fehlbeleg, etwa für ein fehlendes Kontrolljahr oder fehlende historische Salden, ergänzt der Bot die zusätzliche Beschreibung um die vierte Zeile `Manuel review required`. Die bisherigen Zeilen bleiben in ihrer Reihenfolge erhalten. Der Bot prüft Ticket, Member und WWID erneut, speichert den Vermerk und liest ihn im wieder geöffneten Ticket zurück. Der Fall zählt weiterhin als offen. Wenn die Ursache behoben ist, gibt das Entfernen der Vermerkzeile im gespeicherten Ticket den Fall für die nächste automatische Bearbeitung frei. Ein unbestätigter Speicherversuch wird beim nächsten Lauf anhand des gespeicherten Texts abgeglichen.

## Kontoauszüge für DC und PP+

Der Bot ruft den jeweiligen zentralen Python-Generator im zugehörigen Arbeitsordner auf. Die Programme und Excel-Arbeitsmappen liegen auf dem Netzlaufwerk. Die BAT-Dateien bleiben für den manuellen Aufruf verfügbar.

| Plan | Ordner unter `Berechnungen - UV & Renten (PP+, DC+)` | Argumente für Python |
|---|---|---|
| DC | `Kontoauszug_DC` | `kontoauszug_dc_generator.py --wwid <WWID>` |
| PP+ | `Kontoauszug_PP+` | `kontoauszug_generator.py --wwid <WWID> --stichtag 31.12.2026` |

Für neue Aufträge zählt die frische PDF, die der gestartete Prozess aus seinem Ordner `Ausgabe_PDF` meldet. Der Bot prüft Dateityp, Größe, Aktualität, SHA-256 und Personenzuordnung. Ist die Person nicht sicher maschinell lesbar, kann der Bediener den Inhalt im Dokument prüfen. Bei kombinierten Aufträgen müssen sämtliche verlangten Dokumente bereitstehen, bevor der Upload beginnt. Beim Wiederaufnehmen einer bereits begonnenen Ticketaktion gelten der gespeicherte Beleg und das Aktionsjournal.

Die Schritte `P2_KONTOAUSZUG_GENERATOR_START`, `P2_KONTOAUSZUG_PDF_ERSTELLT` und `P2_KONTOAUSZUG_NEW_PDF_VERIFIED` zeigen den Fortschritt. Der Fehlerbericht unterscheidet fehlende Pflichtdaten, Generatorfehler, die Personenordner-Kopie, fehlende Ausgabe und uneindeutige Nachweise. Meldet der Generator bei erfolgreichem Abschluss allein ein Problem mit der zusätzlichen Personenordner-Kopie, zeigt der Bot den Hinweis an und prüft die primäre PDF weiter. Der Phase-2-Abschluss zählt eine Weiterleitung erst mit verifiziertem COMARCH-Beleg.
