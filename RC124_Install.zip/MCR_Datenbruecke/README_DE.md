# MCR DATENBRUECKE 0.8.1-rc.124

Version **0.8.1-rc.124**, 25. November 2026.

## Neu in RC124

Menü 4 akzeptiert `AO` für einen einzelnen sichtbaren Auszahlungsoptionsfall, `AO <Ticketnummer>` für einen bestimmten AO- oder kombinierten Auftrag und `DC <Ticketnummer>` für einen einzelnen DC-Auftrag. Die Nummer ist jeweils die COMARCH-Ticketnummer. [Änderungen und Bedienung](docs/RC124_RELEASE.md)

## Neu in RC123

Phase 1 erkennt auch einzeln anklickbare Beschriftungen innerhalb einer bereits sichtbaren gespeicherten Suche. [Start in der Ticketliste und Installation](docs/RC123_RELEASE.md)

## Neu in RC122

Phase 1 kann die gespeicherten Suchen im älteren COMARCH-Menü über die zugehörige Gruppenüberschrift öffnen. [Änderungen beim Start und Installation](docs/RC122_RELEASE.md)

## Neu in RC121

Wenn COMARCH beim Start den Eintrag `In_Bearbeitung` ausblendet, prüft Phase 1 auch die gespeicherte Warteschlange `INTL01`. Die Einzelheiten stehen im [Releasebericht für RC121](docs/RC121_RELEASE.md).

## Neu in RC120

Auswahl der COMARCH-Pflichtfelder, Wiederaufnahme der Intel-Listen und der Weiterleitung, Prüfung der Kontoauszugsvorlagen und DC-PDF-Übergabe sind im [Releasebericht](docs/RC120_RELEASE.md) beschrieben.

## Neu in RC119

Die Signatursuche behält den eingegebenen Filter. Der Versandnachweis liest die Nachrichtenhistorie des geöffneten Tickets. Fachlich gescheiterte Auszahlungsoptionen erhalten in der zusätzlichen Beschreibung den Vermerk `Manuel review required`. PP+ und DC verwenden ihre zentralen Python-Generatoren mit der gebundenen WWID. Details und Prüfumfang stehen in [RC119_RELEASE.md](docs/RC119_RELEASE.md).

## Historische Änderungen aus RC118 – Signaturkonflikte ohne unnötigen Masterabbruch

- Vorübergehend ungebundene oder unerwartete Signaturwerte bis zu zwölfmal rein lesend nachprüfen, vor weiterer Eingabe Ticket/Member erneut binden. Nur bekannte Suchzustände weiterverwenden; fremden Wert nicht blind überschreiben.
- Bei tatsächlich nicht auflösbarer Signatur vor dem ersten Send-/Save-/Forward-Intent: im manuellen Modus einmal gezielt korrigieren oder überspringen; im AUTO-Modus zurückstellen. Nur exakt bestätigte Pflichtfelder erlauben Fortsetzung. Ticketbezogener Bericht, sichere Rückkehr zur Liste. Bereits begonnene Aktionen bleiben unverändert geschützt.
- Keine Änderungen an AO, Phase 2 oder fachlichen Berechnungen. Live-COMARCH-Nachweis ausstehend.

## Historische Änderungen aus RC117 – gebundene Beschreibung vor Entwurf und begrenzte Wiederaufnahme

- Dokumententwurf: gebundene zusaetzliche Beschreibung lesen, kurze reine Lesewiederholung. Nur fehlenden eigenen Marker bei unveraenderten Originalzeilen per Compare-and-Swap mit Journal einmalig wiederherstellen. Keine fremde Beschreibung ersetzen. Konflikt im lokalen Terminal anzeigen; keine ungepruefte Speicherung.
- Wiederaufnahme aus DRAFT_SAVE_INTENT nur fuer unveraendertes Upload-first-Journal ohne Entwurf-Speicherklick-Intent, mit identischen PDF-Hashes, sichtbaren Anlagen, korrektem GEVO, gleicher WWID/Person, Originalbeschreibung und ausdruecklicher Bedienerpruefung. Kein zweiter Generatorstart oder Upload. Wenn Anlagen nicht mehr vorhanden sind: manuell klaeren, kein Replay. Unbekannte Klickzustände bleiben gesperrt.
- Ein, zwei oder drei Anlagen korrekt in Bedienfragen benennen. Ungebundener Dateiname ist kein automatischer Uploadnachweis; serverseitige Lesebelege bleiben Pflicht.
- Optional: `python tools/ao-history-diagnose.py --wwid 11369795 1378 --year 2026` liest die Kontrollmappe schreibgeschuetzt, meldet nur Anzahlen; keine Betraege, keine Aenderung an Berechnung oder Dateien.
- AO-Adapter und zentrale Saldenlogik unveraendert. Produktiver COMARCH-/Excel-Lauf ausstehend.

## Historische Änderungen aus RC116 – Originalgenerator und vollstaendige postalische Zeile

- AO: Der Adapter fuehrt die originale `create_pdf(wwid)` des zentralen Python-Skripts aus. Originale Excel-Lese-, Schreib- und Berechnungsfunktionen; keine separaten Excel-Instanzen, Schreibvorpruefungen oder Ersatz-Speicherhooks. Identitaetsbindung am Ergebnis der Originalsuche, Eingabevermittlung und Dateinachweise bleiben. Der Adapter beobachtet nur vom Generator erzeugte Excel-Instanzen fuer die kontrollierte Bereinigung.
- Neue PLZ-Eingabe: fuenf Ziffern UND Ort, z.B. `78073 Bad Dürrheim`; vollstaendig als Text uebergeben. Bestehende Werte nicht ungefragt ueberschreiben. Bei abgelehnter Eingabe kein Upload. Keine personenbezogenen Kontaktwerte im Bot-Protokoll.
- Der Originalgenerator ist fuer die Speicherung verantwortlich. Ein Erfolgs-Audit mit contact_supplied bestaetigt die gemeldete Speicherung; kein unabhaengiger Excel-Readback mehr durch den Bot. Schreibfehler werden getrennt gemeldet; keine automatische Wiederholung unbekannter Save-/Upload-Aktionen.
- Bei Fehler: eindeutigen neuen failed-Audit anhand WWID, Zeitpunkt, neuem Dateinamen und exaktem Fehlertext binden. Pfad, Grund und erkannter Berechnungsschritt werden lokal ausgegeben; falls nicht eindeutig, konkreter Originalfehler und Auditstatus. Keine Kontaktdaten im Fehlertext, keine erfundenen Salden.
- Neu erzeugte PDF und Erfolgs-Audit bleiben Pflicht. Gleichnamige alte Dateien werden als historische Referenz gesichert. Keine Wiederverwendung bei neuen Auftraegen. Kein Aendern am zentralen Generator oder dessen Berechnungsformeln.
- PP+/DC bleiben unveraendert. Windows/Excel/COMARCH-Echtlauf ausstehend.

## Historische Änderungen aus RC115 (durch RC116 im AO-Pfad ersetzt)

- Die originale IPP-Lesefunktion arbeitet in einer eigenen DispatchEx-Instanz. Vor jedem Schreibtest: Workbook geschlossen, Excel Quit, COM-Referenzen freigegeben, eigener Prozesshandle bereinigt. Die separate Berechnungsinstanz bleibt unberuehrt und oeffnet die Masterdatei in diesem Pfad nicht.
- Maximal drei schreibende Vorpruefungen ohne Speichern, in jeweils frischer Instanz, nach 5 bzw. 10 Sekunden Wartezeit. Excel ReadOnly-Empfehlung ignorieren, aber niemals echte Sperre oder Berechtigung umgehen. Keine Retry-Schreibaktion nach einem ungeklaerten Save.
- Bei bleibendem Fehler: Besitzerdatei nur auf Existenz pruefen (kein Besitzername), ReadOnly-Dateiattribut, nicht veraendernder Write-Open-Test, eigener eindeutiger temporaerer Schreibtest im Zielordner mit sofortiger Bereinigung. Hinweise sind keine Aussage ueber den Verursacher.
- Erst nach erfolgreicher Vorpruefung Eingabe. Nach Eingabe erneutes isoliertes Lesen, getrenntes Schreiben, Schliessen und erneutes Lesen in weiterer Instanz; nur verifizierte Kontaktwerte erlauben PDF. Keine dauerhafte Sperre waehrend der Recherche.
- Nach belegtem Fehler VOR der Schreibaktion werden lediglich weitere Kontakteingaben/Schreibversuche unterbunden; ein AO-Fall mit vollstaendigen Kontakten kann ohne Stammdaten-Schreibzugriff weiterlaufen. Bei unklarem Save, Lese- oder Bereinigungsfehler bleiben alle neuen AO-Auftraege pausiert. Journalgebundene Wiederaufnahmen bleiben unveraendert.
- Kein produktiver Windows-/Excel-/COMARCH-Test hier; die Sperrursache muss ggf. am Netzlaufwerk geklaert werden. Keine fremden Excel-Prozesse beenden oder Besitzerdateien loeschen.

## Historische Änderungen aus RC114 (Schreibpruefung und Kontakt-Lesebeleg)

- Vor einer fehlenden Adresse/PLZ oeffnet der Adapter die kanonische Masterdatei mit ReadOnly=False, UpdateLinks=0, Notify=False, prueft den echten ReadOnly-Status, die WWID-/Namenszeile und die fehlenden Zellen. Keine Testschreibaktion; Schliessen ohne Speichern. Das ist keine Garantie fuer eine spaetere Speicherbarkeit.
- Der zentrale Generator bleibt auf K: unveraendert; der Adapter uebernimmt ausschliesslich seinen Kontaktspeicher-Hook: erneute Bindung der Originalperson, Recheck im schreibend geoeffneten Workbook, nur fehlende/fehlerhafte Felder schreiben. Aenderungen am Formelzustand oder an vorhandenen Kontakten blockieren Ueberschreibung. Fehlende Formelergebnisse koennen nach Hinweis durch ausdrueckliche Kontakteingabe ersetzt werden. Keine anderen Formeln oder Daten schreiben.
- PLZ-Eingabe: genau fuenf Ziffern, ohne Ort. Ungueltige PLZ wird lokal erneut abgefragt, ohne Neustart des Generators. Textformat erhaelt fuehrende Nullen bei neu geschriebenen PLZ.
- Nach Save und Close: kanonische Person erneut lesend laden, beide Werte und Quellzeile pruefen. Erst dann Berechnung und PDF. Fehlende Save-Evidenz ist keine Freigabe zum erneuten Schreiben.
- Differenzierte Master-Schreibfehler mit Zielpfad und technischer Ursache. Nach gemeinsamem Zugriffs-/Schreibproblem werden alle weiteren NEUEN AO-Auftraege (auch kombinierte) im aktuellen Lauf zurueckgestellt; nicht-AO-Faelle und sichere journalgebundene Wiederaufnahmen bleiben moeglich. Neuer Lauf nach Klaerung der Datei. Keine fremden Excel-Prozesse beenden, keine Besitzerdatei entfernen.

## Historische Änderungen aus RC113 (ruhiger Eingabemodus)

- Bei einer echten Adresse-/PLZ-Frage zeigt das bestehende MCR-Terminal Ticket, Person, WWID und das gefragte Feld. Kein zweites Konsolenfenster.
- Keine Fortschrittsmeldungen waehrend der Benutzereingabe; aktive technische Zeitbudgets im Node-Prozess und Python-Watchdog werden bis zur Antwort unterbrochen. Normale Generator-Zeitlimits bleiben erhalten.
- ENTER ohne Wert / UEBERSPRINGEN stellt den Fall offen; eine an Node gelieferte Strg+C-Eingabe waehrend der Frage wird ebenfalls als Ablehnung behandelt. Externe Unterbrechung des Windows-Batchprozesses ist nicht garantiert abfangbar. Keine personenbezogenen Eingabewerte im Laufprotokoll.
- Der Generator speichert wie bisher erst nach kompletter Eingabe aller benoetigten Felder. Nach bestaetigtem Abbruch vor Speicherung: kein Upload, naechster Fall. Keine Aenderung an PDF-/Auditpruefung oder fachlichen Formeln.

## Historische Änderungen aus RC112 (interaktiver Kontaktweg)

- Neue AO-Auftraege immer neu exportieren. Keine alte PDF als Ersatz; keine Altbeleg-Freigabefrage. Bestehende, eventuell begonnene COMARCH-Aktionen bleiben journalgebunden.
- Der installierte Python-Adapter fuehrt die originale zentrale `create_pdf(wwid)` im selben Python-Prozess aus. Die zentrale Datei auf K: wird nicht veraendert. Kein BAT-Fenster, keine doppelte Stammdaten-Vorpruefung, keine Sperre allein aufgrund der Kontaktwarteschlange.
- Der zentrale Generator liest die IPP-Person selbst. WWID/Name werden gebunden, die originale Stichtagsfrage mit ENTER beantwortet. Nur seine tatsaechlich angeforderten Adresse-/PLZ-Felder werden ueber eine stdin/stdout-Leitung vermittelt. Eingabe im Terminal bedeutet ausdruecklich fachlich geprueften Schreibauftrag fuer diese WWID. ENTER oder UEBERSPRINGEN laesst den Einzelfall offen. Keine erfundenen Werte. Keine Adresse/PLZ im Bot-Journal.
- Der Generator speichert ueber seine eigene `save_contact_to_master`-Funktion. Vor dem Schreibauftrag wird der Datensatz nochmals gelesen; nach dem Speichern werden die Kontaktwerte und Quellzeile kontrolliert. Bei einem unklaren Schreibresultat kein Upload. Ab RC113: Beide technischen Timeouts laufen ausschliesslich waehrend aktiver Generatorarbeit; Benutzerwartezeit zaehlt nicht.
- Neuer Audit, neuer Export, Datei-Hash und Ticketbindung bleiben zwingend. Vorhandene gleichnamige PDF wird historisch gesichert; fehlende alte PDF ist kein Hindernis. Keine COMARCH-Kunden-E-Mail in Phase 2, nur interne Weiterleitung an Mark.
- PP+/DC nur bei eindeutigen PDFs; kombinierter Fall erst bei allen Dokumenten. Windows-/Excel-/COMARCH-Echtlauf ausstehend.

## Historische Änderungen aus RC111 (Kontakt-Vorprüfung durch RC112 ersetzt)

- Jeder neue, noch nicht begonnene AO-Dokumentauftrag erzeugt eine neue PDF über den zentralen Generator. Alte PDF-/Audit-Belege sind nur historische Referenzen, auch nach einem Abbruch ohne COMARCH-Schreibaktion. Kein JA-Dialog zur alten PDF.
- Bei gleichem Jahres-Dateinamen wird die bisherige PDF vor Export unter `Ausgabe PDF/.mcr_historie/<Request-ID>/` gesichert. Der zentrale Generator und seine fachliche Berechnungslogik bleiben unverändert. Seine vorhandene same-date-Balance-Cache-Logik bleibt bestehen: eine neue PDF bedeutet nicht zwingend eine neue Kontostandsberechnung.
- Neuheitsnachweis: Startanker, neuer Audit-Dateiname, PDF-/Audit-Zeitstempel, geänderte Dateievidenz, Request-ID, WWID, Name, Stichtag, Hash und technische PDF-Prüfung. Nur der konkrete neue Ticketbeleg wird an die Uploadstrecke übergeben.
- Fehlende Adresse/PLZ: `.runtime/phase2/ao-contact-queue/<Ticket-ID>.json` speichert WWID, Member-ID, Stichtag und fehlende Feldnamen (keine Adresswerte). `AO_WAITING_FOR_CONTACT_DATA`. Nutzer ergänzt und speichert die kanonische Arbeitsmappe fachlich. Bei stabil nachgewiesen unveränderten Stammdaten- und Generatorbytes kein erneuter Excel-Preflight; bei Änderungen/unklarem Dateizugriff erneute Live-Prüfung. `AO_READY_FOR_REGENERATION` nach vollständigen Kontaktdaten. Kein Schreiben durch den Bot.
- Vorhandene Phase-2-Aktionsjournale behalten ihren bisherigen Sicherheits-/Wiederaufnahmepfad. Kein neuer Generatoraufruf nach einem unklaren Upload/Speichern/Weiterleiten. Keine Teilanlage bei kombinierten Aufträgen. PP+/DC weiterhin nur mit eindeutiger PDF bis zur bestätigten Schnittstelle.
- Keine Kunden-E-Mail in Phase 2; weiter an Mark zur fachlichen Prüfung. Produktive Windows-/Excel-/COMARCH-Prüfung ausstehend.

## Historische Änderungen aus RC110

- Fehlerkorrektur: Eine Excel-Besitzerdatei `~$...xlsx` blockiert die lesende AO-Kontaktpruefung nicht mehr. Der zentrale IPP-Lookup verwendet ReadOnly=True und UpdateLinks=0. Die Besitzerdatei wird nicht geloescht. Die Schutzpruefung der zu schreibenden AO-Arbeitsdatei bleibt aktiv.
- Getrennte Fehlercodes fuer fehlende Datei/Ordner, nachweisbaren Sharing-Fehler, verweigerten Zugriff, sonstigen Open-Fehler und eigene Excel-Initialisierung. Technische Diagnose mit Operation und numerischem HRESULT/Winerror, ohne Zellinhalte. `PASS AO_MASTER_READ_OK` markiert erfolgreichen lesenden Lookup; danach erst Kontaktpruefung und Berechnung.
- Wiederaufnahmegruppen in Phase-2-Bericht und Terminal. Keine automatische Freigabe oder persistente Sperre allein aufgrund einer Fehlergruppe. Frische Liste und Journalpruefung bleiben erforderlich.
- Historisch in RC110: AO-Wiederverwendung. Für neue Aufträge ab RC111 ersetzt durch Neuerzeugung.
- PP+/DC weiterhin erst bei bestaetigter Generator-Schnittstelle oder eindeutiger vorhandener PDF. Zentrale Skripte und Formeln unveraendert. Keine Kunden-E-Mail in Phase 2.

## Bisherige Änderungen aus RC109

- Live-Fahrplan: eigene AO-Station, getrennte Falltypen und Rückstellmeldungen; kombinierte Fälle zeigen AO und Kontoauszug. Historische Detaildiagramme bleiben unverändert.
- AO: lokaler Python-Adapter mit explizitem Stichtag, WWID, nicht-interaktivem Modus und JSON-Ergebnis. Vor der Berechnung prüft der Adapter Adresse/PLZ über die originale IPP-Stammdatensuche (nur lesen). Fehlende Daten blockieren nur den Einzelfall. Kein Schreiben von Kontaktdaten, keine Terminal-Eingabe, keine geänderten Berechnungsformeln.
- Historisch: AO-Wiederverwendung mit Quellenbelegen. Ab RC111 bei neuen Aufträgen nicht mehr aktiv.
- PP+/DC: Vorhandene eindeutige PDFs können wie bisher verarbeitet werden. Ohne bestätigte nicht-interaktive Schnittstelle kein BAT-Start; fehlende oder uneindeutige Dateien stellen den Einzelfall zurück. Phase 2 weiterhin ohne Kunden-E-Mail.
- Die zentralen Generator-Dateien auf K: werden nicht mit diesem Update ersetzt. Für PP+/DC/UVA wird ein tatsächlicher maschinenlesbarer Aufruf erst nach Vorlage der Generatorquellen und des bestätigten Ausgabeformats integriert.

## Bisherige Änderungen aus RC108

- AO: Die Rückmeldung nennt das tatsächlich angeforderte Feld (Adresse oder PLZ). Fehlende Daten werden nicht erfunden; der Fall bleibt ohne COMARCH-Schreibaktion offen. Adressdaten im bestätigten Stammblatt fachlich ergänzen, speichern und einen neuen Phase-2-Lauf starten.
- Historisch: AO-Wiederverwendung mit Altersgrenze. Ab RC111 Neuerzeugung vor erster Schreibaktion; bestehende Aktionsjournale nicht löschen.
- Phase 2: Inventur und Auswahl eines alten Arbeitsjournals verwenden dieselbe Regelprüfung wie der Handler. Widersprüchliche Originalbeschreibung/Journalregel wird zurückgestellt; unveränderte Journale und neu gebundene Liste ermöglichen die Fortsetzung. Keine Wiederholung unbekannter Schreibaktionen.
- Phase 2 bleibt ohne E-Mail. Der zentrale Generator, Excel-Berechnungsformeln und Browser-/Signaturwege wurden nicht geändert.

## Bisherige Änderungen aus RC105

**Auszahlungsoptionen automatisch erstellen:** Phase 2 ruft die zentrale
`auszahlungsoption_generator.py` auf K: auf. Die WWID stammt aus dem verifizierten
COMARCH-Member. Der Standardstichtag wird wie bei ENTER bestätigt. PDF, Audit,
Name, WWID, Stichtag und Dateihash werden gemeinsam geprüft. Die normale AO
wird anschließend ohne `PDFS_BEREIT`-Rückfrage angehängt und im bestehenden
Ablauf an Mark zur fachlichen Prüfung gegeben. Es entsteht kein zusätzliches
CMD-Fenster. Berechnungsformeln bleiben ausschließlich im zentralen Generator.

**Phase 1 → Phase 2:** Eine nachweislich leere Phase-1-Warteschlange führt
weiter automatisch in Phase 2. Ein veränderter Excel-Bestand wird an sicheren
Grenzen vor dem nächsten Ticket neu eingelesen. Innerhalb eines aktiven Tickets
bleiben die Daten- und Versandprüfungen wirksam. Leer-/Formatierungszeilen lösen
keinen fachlichen Bestandswechsel mehr aus.

**Bewusst geänderter Empfänger:** Die ausdrückliche Freigabe mit ENTER oder JA
gilt jetzt auch für die automatische Prüfung der neuen Ausgangsnachricht.
Die alte zusätzliche Wartezeit durch `RECIPIENT_NOT_ORIGINAL_SENDER` entfällt,
wenn der neue Ausgang exakt belegt ist. Es bleibt bei einem Versandklick.

Details, Ausnahmefälle und Prüfumfang: `docs/RC105_RELEASE.md` und
`docs/RC105_Pruefbericht.txt`. Die Fokus-/Signaturkorrekturen aus RC104,
der eigene Browserstart und die bisherigen Bestands-/Kontaktregeln bleiben enthalten.

## Installation und erster Start

1. `RC124_Install.zip` vollständig in einen separaten Ordner außerhalb der vorhandenen Installation entpacken.
2. Darin `MCR_Datenbruecke\START.cmd` öffnen, **1** wählen und die vorhandene Installation als Ziel übernehmen.
3. `PASS INSTALLATION_COMPLETE` abwarten. Danach ausschließlich die `START.cmd` der installierten Version verwenden. Der Titel muss **0.8.1-rc.124** anzeigen.
4. Die automatische Bestandsprüfung abwarten. Menü **2** kann für gesonderte Wartung verwendet werden; es ist kein Pflichtschritt vor dem Master Run.
5. Für den vollständigen Lauf **5** wählen und mit **ENTER** bestätigen. Das eigene Edge-Fenster soll sich öffnen. Falls erforderlich, dort bei COMARCH anmelden und den angezeigten Bedienhinweisen folgen. Menü **3** und **4** bleiben für die getrennten Phasen verfügbar.

Das Update bewahrt private_data, Konfiguration, Browserprofil und Laufjournale. Es versendet keine Nachrichten. Die zugelassenen Bestandsversionen bis RC111 werden anhand ihrer fest gebundenen Manifest-Hashes und sämtlicher Programmdateien geprüft; die bisher unterstützten älteren Versionen bleiben zugelassen. Eine lokal abgeänderte Installation wird nicht ungeprüft ersetzt. Die Menüs 3 und 5 bearbeiten nach der Startbestätigung echte Tickets mit E-Mail-Versand in Phase 1; Phase 2 arbeitet weiterhin ohne E-Mail-Versand.

## 1. Member-Feld und Pflichtfelder

Seit RC97 wurde der Suchtext zunächst bis auf das letzte Zeichen und anschließend mit dem letzten Zeichen über native Tastatureingabe gesetzt. Die abschließende Prüfung verlangte zusätzlich den Fokus im Suchfeld. Dadurch konnte ein bereits vollständig übernommener Suchtext als Fehler gelten, wenn COMARCH den Fokus während der Aktualisierung verlagerte.

RC100 trennt diese Prüfungen: Vor einer Eingabe müssen Ticket und Suchfeld eindeutig gebunden sein. Danach entscheidet ein stabiler, exakter Rücklesewert, ob die Eingabe übernommen wurde; ein inzwischen verschobener Fokus allein widerlegt diesen Wert nicht.

Ist der Text tatsächlich nicht vollständig, sind höchstens drei begrenzte Eingabewege vorgesehen: der reguläre native Weg, die vollständige native Texteingabe und ein eingeschränkter Kompatibilitätsweg nach dem RC96-Verhalten. Vor jedem erneuten Eingriff werden die Bindung und der aktuelle Feldinhalt geprüft. Fremde Inhalte oder ein bereits ausgewähltes Personenprofil werden dabei nicht überschrieben. Derselbe Eingabeweg gilt für Namen und für die Suche mit WWID beziehungsweise MercerID.

Ein dauerhaft nicht bestätigter Suchtext kann nur mit dem besonderen Nachweis `MEMBER_QUERY_REVIEW_REQUIRED` zum Zurückstellen dieses einen Tickets führen. Der Nachweis muss bestätigen, dass der Fehler auf die gebundene Suche begrenzt blieb und keine zu prüfende Ticketaktion begonnen wurde. Das Ticket bleibt offen; der Bot sendet, speichert oder leitet es nicht weiter. Ohne diesen Nachweis bleiben unklare Zustände ein Abbruchgrund. Ein erfolgreich eingegebener Suchtext ist noch keine bestätigte Person: Die vollständigen Profil-, Namens- und ID-Nachweise bleiben unverändert erforderlich.

Der reguläre Pflichtfeldweg lautet:

**Kategorie wählen → Member-Fokus zur Übernahme → Unterkategorie wählen → Member-Fokus zur sicheren COMARCH-Übernahme → Signatur → Antworteditor.**

Der Member-Fokus nach der Unterkategorie ist in RC101 wieder der reguläre, bewährte Weg zur COMARCH-Übernahme vor der Signatur. Eine bereits vollständig bestätigte Pflichtfeldkombination wird bei späteren Prüfungen desselben Tickets und Members gelesen, ohne den ganzen Auswahlweg erneut auszuführen. Vor dem ersten Suchtext entfällt das bisherige Warten auf eine noch leere Vorschlagsliste.

Manuelle Hilfe bleibt möglich, wenn COMARCH das richtige Feld tatsächlich verdeckt oder keine eindeutigen Vorschläge liefert. Eine vollständige Beseitigung solcher Oberflächenprobleme lässt sich ohne Prüfung in der echten COMARCH-Sitzung nicht zusichern. Sende-, Speicher- und Weiterleitungsklicks werden dadurch nicht wiederholt.

## 2. Ein Bot-Tab

Der eigene Browserstart aus RC99 wurde im folgenden Benutzerlauf erfolgreich erreicht. RC100 behält diesen Startweg bei.

Im gemeldeten RC98-Lauf war die Browsersteuerung bereits erreichbar, aber die anschließende Suche nach der exakt markierten Startadresse fand keinen passenden Tab. Die Fehlerbehandlung beendete daraufhin den gestarteten Browser. Deshalb konnte das Botfenster kurz erscheinen oder wieder verschwinden, bevor die Ticketbearbeitung begann. Warum die Markierung im konkreten Windows-/Edge-Lauf fehlte, ist aus dem Protokoll nicht nachgewiesen.

RC99 startet den eigenen Edge-Prozess ohne automatisch erzeugtes Startfenster und ohne Startadresse. Danach erzeugt die Browsersteuerung ausdrücklich eine neue leere Seite in einem sichtbaren neuen Fenster und erhält deren eindeutige Tab-ID zurück. Der Bot prüft genau diese Seite und bindet sie an den Lauf. Eine Suche nach einer Startmarkierung oder die Übernahme eines schon vorhandenen Tabs ist dafür nicht mehr nötig.

Pilot, Folgelauf und Phase 2 verwenden im Master weiter dieselbe Tab-ID. Jeder Teillauf lädt darin COMARCH frisch und prüft, dass tatsächlich eine neue Ansicht geladen wurde. Derselbe ausdrückliche Seitenstart gilt für eigenständige Phasen ohne gemeinsamen Masterbrowser.

Am Ende eines Teillaufs wird die technische Verbindung getrennt, der Tab bleibt erhalten. Der Master beendet seinen Edge-Prozess am Laufende. Ein Ticketwechsel innerhalb eines Teillaufs nutzt weiterhin denselben Tab. Die Live-Karte ist ein separates Anzeigefenster im normalen Browser.

Fremde oder wiederhergestellte Browser-Tabs werden nicht übernommen. Fehler beim ersten Erzeugen oder Binden des Botfensters werden von einem späteren Verlust des bereits gebundenen Tabs unterschieden. Wird dieser Tab während der Bearbeitung geschlossen, hält der Bot weiterhin an; er ersetzt ihn nicht während einer Ticketaktion und wiederholt keinen Versand.

## 3. Gelesene Namen übernehmen

Wenn Vorname, Nachname und MercerID bereits aus dem eindeutig ausgewählten COMARCH-Profil lesbar sind, werden sie übernommen. Die bisherigen drei erneuten Eingaben von ID, Vorname und Nachname entfallen in diesem Fall.

Bei einem wirklichen Namenskonflikt zeigt der Bot das Profil an und fragt einmal:

- **ENTER:** Person und Berechtigung geprüft; der Originalabsender gehört zu dieser Person.
- **VERTRETER:** Berechtigte Vertretung bestätigt; E-Mail und Sprache werden nicht als persönlicher Kontakt des Members in FM/FN übernommen.
- **NEU SUCHEN:** Member erneut auswählen.
- **ABBRUCH:** Lauf anhalten.

Fehlt der Name in der Nachricht, versucht der Bot zuerst, das bereits ausgewählte Profil zu lesen. Andernfalls kann die Person im Member-Feld ausgewählt werden; danach liest der Bot die Profilwerte. Nur die ausdrückliche Alternative **NAMEN** verwendet die getrennte Namenseingabe.

Nach einer manuellen Pause werden Ticket und Profil erneut geprüft. WWID und MercerID bleiben getrennt. Ein ausdrücklich beschriftetes WWID-Feld wird zusätzlich mit dem Bestands-Lookup verglichen. Der bisherige Präfix-11-Lookup verändert nur den Suchschlüssel zum Bestand, niemals die COMARCH-ID.

## 4. Verbindliche Excel-Quelle

Voreingestellt ist:

```text
K:\INTL01\6_AU (Admin)\~ Data\~ Bestand Intel Gesamtübersicht\INTL01_Gesamtdatenbestand_30.09.2025.xlsx
```

Der bestehende Leser verwendet das Blatt **Output**. Bei fehlendem oder nicht eindeutigem Blatt und widersprüchlichen Spaltenüberschriften erscheint ein konkreter Fehler. Es wird kein anderes Blatt geraten.

| Spalte | Verwendung |
| --- | --- |
| B | WWID / bisheriger ClientEEID-Schlüssel |
| C | DC: 1 aktiv, 0 inaktiv, leer nicht gesetzt |
| D | PP+: 1/0/leer |
| E | PensIntel: 1/0/leer |
| F | TPP: 1/0/leer |
| G | JUB: 1/0/leer |
| H | UEB: 1/0/leer |
| I | ZW: 1/0/leer |
| L | USC |
| O | M/F für die Anrede; fehlende oder widersprüchliche Werte behalten den Prüfweg |
| FM | Ergänzte eigene E-Mail-Adressen |
| FN | Sprache der Originalnachricht: DE oder EN |

Die vorhandene Projektregel behandelt E/PensIntel bereits als `pensIntel` und `dbPlus`. RC97 behält deshalb die bestehende **DB+**-Anzeige und die zugehörige Phase-2-Regel bei. JUB, UEB und ZW werden zusätzlich gelesen und in den Planzeilen angezeigt. Sie erhalten keine erfundenen neuen Bearbeitungs- oder PDF-Regeln. Kontoauszugsziele bleiben DC/PP+.

Alle Bestandszeilen derselben WWID bleiben in ihrer Reihenfolge erhalten. Ein Fehler in einer zugehörigen fachlichen Zeile sperrt die vollständige Zuordnung; es wird keine scheinbar vollständige Teilmenge verwendet. Die Begrenzung der COMARCH-Beschreibung bleibt geprüft.

### Aktualität und JSON

Die XLSX ist die führende Quelle. JSON bleibt intern als überprüfter Lauf-Snapshot erhalten, damit Pilotfreigabe, Browser-Lease und Journale einen festen Bezug haben. Es muss kein JSON-Bestand von Hand nachgepflegt werden.

Vor dem Lauf wird die Quelle neu gelesen. Vor Tickets und entscheidenden Schreibgrenzen wird geprüft, ob WWID, Merkmale, USC oder Anrede seit dem Einlesen geändert wurden. Vor dem Öffnen des nächsten Tickets kann RC105 einen geänderten Bestand automatisch neu binden; pro Master sind höchstens drei solcher Neubindungen erlaubt. Innerhalb eines bereits aktiven Tickets hält der Bot vor einer betroffenen Aktion weiterhin an. Bereits abgeschlossene Tickets bleiben geschützt. Ist K: nicht erreichbar, gibt es keinen stillen Rückfall auf ein altes JSON.

Änderungen nur in FM/FN oder anderen unbeteiligten Spalten lösen keine neue Pilotpflicht aus. Formelwerte werden aus den gespeicherten Excel-Ergebnissen gelesen; vorhandene Formelprüfungen bleiben erforderlich. Der Bot berechnet die Bestandsdatei nicht neu.

Ein abweichender Dateipfad kann in `config/local-runner-queue-send.json` über `stockWorkbookPath` gesetzt werden. In JSON sind Rückstriche doppelt zu schreiben. Die bestehende Konfiguration bleibt beim Update erhalten; fehlt dieser neue Schlüssel, gilt der oben angegebene Standardpfad.

## 5. E-Mail und Sprache ergänzen

Die Kontaktübernahme erfolgt nach nachgewiesenem Versand **und** Speichern des Tickets. Sie verwendet den gebundenen Originalabsender, den geprüften Antwortempfänger, das zuletzt bestätigte Memberprofil, die daraus aufgelöste WWID und die Originalsprache.

Bei der manuell geprüften Zuordnung genügt die oben beschriebene ENTER-Bestätigung auch bei einer undurchsichtigen E-Mail-Adresse. Ohne manuelle Prüfung muss ein eindeutiger passender Absender- oder aktueller Signaturbezug vorliegen. Ein Name, der lediglich im Nachrichtentext erwähnt wird, wird nicht als Inhaber der Absenderadresse angenommen.

FM ergänzt eine noch nicht enthaltene Adresse; bestehende Adressen bleiben erhalten. Deduplizierung berücksichtigt Groß-/Kleinschreibung. FN erhält DE/EN aus der Originalnachricht beziehungsweise der bereits vorgesehenen manuellen Sprachwahl. Eine verspätete ältere Ergänzung darf keine neuere, vom Bot protokollierte Sprachbeobachtung zurücksetzen. Unabhängige manuelle Änderungen in FN haben keinen auswertbaren Zellzeitstempel; sie werden nicht zeitlich verglichen. Bei mehrfacher WWID werden die passenden Zeilen gemeinsam aktualisiert, fremde WWIDs nicht.

Eine Adresse, die bereits bei einer anderen WWID steht, fremde FM/FN-Überschriften, Formeln, Zellfehler, geschützte oder verbundene Kontaktzellen und besondere Zellinhalte werden zur Prüfung zurückgestellt. Bestehende Fachspalten, Formeln, Formatierungen und andere ZIP-Bestandteile werden nicht durch einen vollständigen Excel-Neuaufbau ersetzt.

### Sperren, Sicherung und Wiederaufnahme

Der Windows-Schreibadapter hält die Datei vom Vergleich mit dem gelesenen Original über Sicherung und Schreibabsicht bis zum Schreiben und Zurücklesen exklusiv geöffnet. Vor der Änderung wird die vollständige Originaldatei unter `.runtime/workbook/backups` gesichert. Wird ein Schreibfehler erkannt, wird das Original nur innerhalb desselben gehaltenen Dateihandles zurückgeschrieben und geprüft.

Nach einem Prozess- oder Rechnerabbruch dient `.runtime/workbook/transactions` zur Klärung. Eine später fremd veränderte Datei wird nicht blind durch eine ältere Sicherung ersetzt. Das ist eine gesicherte Schreibtransaktion mit Wiederherstellungsnachweis, kein atomarer Dateiaustausch.

Ist Excel geöffnet oder die Datei gesperrt, bleibt die Ergänzung unter `.runtime/workbook/contacts` als **PENDING** erhalten. Nach dem Schließen der Datei wird sie beim nächsten Menü-2-, Phase-1-, Phase-2- oder Masterstart erneut versucht. Diese Wiederholung betrifft ausschließlich Excel. Sie kann keine E-Mail senden oder ein Ticket weiterleiten.

Typische Meldungen:

| Meldung | Bedeutung |
| --- | --- |
| BESTAND_EXCEL_NEU_EINGELESEN | Neuer fachlicher Bestand aktiviert |
| BESTAND_EXCEL_AKTUELL | Quelle erneut gelesen; fachliche Daten unverändert |
| BESTAND_KONTAKT_GESPEICHERT | FM/FN gespeichert und verifiziert oder bereits vorhanden |
| BESTAND_ERGAENZUNG_OFFEN | Ergänzung dauerhaft vorgemerkt; Grund wird angegeben |
| BESTAND_KONTAKT_NICHT_UEBERNOMMEN | Eigenkontakt nicht ausreichend belegt; keine FM/FN-Änderung |
| WORKBOOK_CONTACT_AFTER_COMPLETE | Kontaktupdate nicht bestätigt; Ticket bleibt abgeschlossen. Bei Speicherfehler kann auch die lokale Vormerkung fehlen. |

## Einordnung des gelieferten RC96-Protokolls

Der gezeigte Lauf ist technisch abgeschlossen: Phase 1 hat sieben Tickets mit Versand und Speicherung bestätigt, Phase 2 zwei Tickets ohne E-Mail weitergeleitet. Die sieben neuen Phase-1-Tickets hatten noch keinen Bearbeitungsauftrag in der zusätzlichen Beschreibung und wurden mit `NOT_REQUESTED` offengelassen. Sie sind damit nicht fachlich in Phase 2 erledigt. Die künftige LenX-Erstellung des Auftrags bleibt ein eigenes Phase-3-Thema.

## Prüfung und verbleibende Live-Abnahme

Der bestehende Testsatz deckt die Member-/Namensübernahme, Fokuszustände, Ein-Tab-Lifecycle, erweiterte Bestandsmerkmale, Quellaktualität, Mehrfachzeilen, E-Mail-/Sprachzuordnung, Warteschlange, ZIP-/OOXML-Erhaltung und die Trennung von Kontaktfehlern und abgeschlossenem Ticketversand ab. RC100 ergänzt die Prüfung des stabilen Suchtextes bei Fokuswechsel, der begrenzten Eingabewege und des Zurückstellens eines einzelnen nachweislich ungeänderten Tickets. Konkrete Testergebnisse beziehen sich auf den jeweils ausgeführten lokalen Prüflauf.

Der originale Fehlercode des Runners bleibt bei einer Weitergabe an den Master sichtbar, damit eine Sammelmeldung wie `LIVE_NOT_VERIFIED` die eigentliche Ursache nicht verdeckt. Der bestehende Wiederanlauf ordnet einen beendeten alten Lauf weiterhin anhand seiner lokalen Nachweise ein. Ungeklärte frühere Versandabsichten bleiben im Journal und sind vom automatischen Neuversand ausgeschlossen; abgeschlossene Tickets bleiben ebenfalls geschützt.

Zusätzlich enthält das Paket Windows-Tests für den nativen Dateischreibadapter mit ausschließlich temporären Testdateien; sie werden auf Linux übersprungen. Die erneute Prüfung der RC100-Member-Suche im produktiven Windows-/COMARCH-System steht aus. Dabei muss der vollständige Suchtext übernommen und anschließend das tatsächliche Personenprofil geprüft werden. Der erste Versandpilot bleibt an die neue Software-/Bestandsversion gebunden. Menü 2 ist dafür kein zusätzlicher Pflichtschritt.
