"""Check the configured generator's inputs without importing it or opening Excel."""
import ast
import hashlib
import io
import os
import shutil
import stat
import uuid
import json
from pathlib import Path
import sys
import tempfile
import tokenize
import types

PP_SCRIPT = "kontoauszug_generator.py"
DC_SCRIPT = "kontoauszug_dc_generator.py"
TEMPLATE = "IPP Kontoausz\u00fcge Updates_Template.xlsm"


def template_spellings():
    variants = {TEMPLATE}
    for _ in range(2):
        for old in tuple(variants):
            for encoding in ("cp1252", "latin1"):
                try:
                    variants.add(old.encode("utf-8").decode(encoding))
                except UnicodeError:
                    continue
    return variants - {TEMPLATE}


def checked_source(script):
    with tokenize.open(script) as source:
        text = source.read()
    tree = ast.parse(text, filename=str(script))
    variants = template_spellings()
    changes = 0
    if script.name == PP_SCRIPT and any(isinstance(node, ast.Constant) and isinstance(node.value, str)
                                        and node.value in variants for node in ast.walk(tree)):
        literals = path_literals(tree)
        if any(node.value in variants for node in literals):
            node = template_literal(tree)
            node.value = TEMPLATE
            changes = 1
    code = compile(tree, str(script), "exec", dont_inherit=True)
    return code, changes


def require_readable(file):
    if not file.is_file():
        raise FileNotFoundError(f"Datei fehlt: {file}")
    with file.open("rb") as stream:
        if not stream.read(1):
            raise ValueError(f"Datei ist leer: {file}")


def path_literals(tree):
    """Select the literal that provides the template path; never edit a comment,
    print statement, docstring or a different workbook with a similar name."""
    spellings = template_spellings() | {TEMPLATE}
    matches = []

    def exact(node):
        return isinstance(node, ast.Constant) and isinstance(node.value, str) and node.value in spellings

    for node in ast.walk(tree):
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Div) and exact(node.right):
            matches.append(node.right)
        elif isinstance(node, (ast.Assign, ast.AnnAssign)) and exact(node.value):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            if any(isinstance(t, ast.Name) and ("TEMPLATE" in t.id.upper() or "VORLAGE" in t.id.upper())
                   for t in targets):
                matches.append(node.value)
        elif isinstance(node, ast.Call):
            path_function = (isinstance(node.func, ast.Name) and node.func.id == "Path" or
                             isinstance(node.func, ast.Attribute) and node.func.attr in {"joinpath", "Path"} or
                             isinstance(node.func, ast.Attribute) and node.func.attr == "join" and
                             isinstance(node.func.value, ast.Attribute) and node.func.value.attr == "path")
            if path_function:
                matches.extend(arg for arg in node.args if exact(arg))
    return matches


def template_literal(tree):
    matches = path_literals(tree)
    if len(matches) != 1:
        raise ValueError("Der PP+-Vorlagenpfad im Quelltext ist nicht eindeutig. Gefundene Pfad-Literale: " + str(len(matches)))
    return matches[0]


def repaired_bytes(raw, filename):
    encoding, _ = tokenize.detect_encoding(io.BytesIO(raw).readline)
    text = raw.decode(encoding)
    if text.encode(encoding) != raw:
        raise ValueError("Quellkodierung kann nicht bytegenau beibehalten werden.")
    tree = ast.parse(text, filename)
    node = template_literal(tree)
    if node.value == TEMPLATE:
        return raw
    # AST columns are UTF-8 byte offsets, including in non-UTF-8 sources.
    # Work with the original line endings and only replace the STRING token.
    lines = text.splitlines(keepends=True)
    def position(number, column):
        prefix = lines[number-1].encode("utf-8")[:column].decode("utf-8")
        return sum(map(len, lines[:number-1])) + len(prefix)
    start = position(node.lineno, node.col_offset)
    end = position(node.end_lineno, node.end_col_offset)
    token = text[start:end]
    tokens = [t for t in tokenize.generate_tokens(io.StringIO(token).readline) if t.type == tokenize.STRING]
    if len(tokens) != 1 or tokens[0].string != token:
        raise ValueError("Zusammengesetzter Vorlagenname. Quelltext muss manuell geprueft werden.")
    new_literal = json.dumps(TEMPLATE, ensure_ascii=False)
    try:
        new_literal.encode(encoding)
    except UnicodeEncodeError:
        new_literal = json.dumps(TEMPLATE, ensure_ascii=True)
    updated = (text[:start] + new_literal + text[end:]).encode(encoding)
    compile(updated, filename, "exec", dont_inherit=True)
    if template_literal(ast.parse(updated, filename)).value != TEMPLATE:
        raise ValueError("Rueckpruefung des korrigierten Vorlagenpfads fehlgeschlagen.")
    return updated


def replace_script(staged, script):
    if os.name != "nt":
        os.replace(staged, script)
        return
    # ReplaceFile preserves the original Windows file's metadata and ACLs.
    # A sharing violation or metadata merge failure must leave a clear error.
    import ctypes
    from ctypes import wintypes
    replace = ctypes.WinDLL("kernel32", use_last_error=True).ReplaceFileW
    replace.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.LPCWSTR,
                        wintypes.DWORD, wintypes.LPVOID, wintypes.LPVOID]
    replace.restype = wintypes.BOOL
    if not replace(str(script), str(staged), None, 0, None, None):
        raise ctypes.WinError(ctypes.get_last_error())


def repair_pp(script):
    if script.name != PP_SCRIPT or script.is_symlink() or not script.is_file():
        raise ValueError("Bitte den genauen Pfad der regulaeren Datei " + PP_SCRIPT + " angeben.")
    script = script.resolve()
    require_readable(script.parent / TEMPLATE)
    lock = script.with_name("." + script.name + ".mcr-repair.lock")
    # Coordinate concurrent repair invocations. External editor changes during
    # prepare/backup are checked again immediately before replacement.
    with lock.open("xb"):
        pass
    backup = None
    staged = None
    try:
        original_stat = script.stat()
        original = script.read_bytes()
        updated = repaired_bytes(original, str(script))
        digest = lambda data: hashlib.sha256(data).hexdigest()
        if updated == original:
            return {"ok": True, "status": "PP_TEMPLATE_ALREADY_CORRECT", "script": str(script), "sha256": digest(original)}

        backup = script.with_name(script.name + ".mcr-" + uuid.uuid4().hex + ".bak")
        with backup.open("xb") as f:
            f.write(original)
            f.flush()
            os.fsync(f.fileno())
        if backup.read_bytes() != original:
            raise OSError("Die Originalsicherung konnte nicht bestaetigt werden: " + str(backup))

        with tempfile.NamedTemporaryFile(prefix=".mcr-pp-template-", suffix=".tmp", dir=script.parent, delete=False) as f:
            staged = Path(f.name)
            f.write(updated)
            f.flush()
            os.fsync(f.fileno())
        shutil.copymode(script, staged)
        if staged.read_bytes() != updated:
            raise OSError("Staging-Datei wurde vor dem Ersetzen geaendert.")
        current = script.lstat()
        unchanged = (current.st_dev, current.st_ino, current.st_mtime_ns, current.st_size) == (
            original_stat.st_dev, original_stat.st_ino, original_stat.st_mtime_ns, original_stat.st_size)
        if not stat.S_ISREG(current.st_mode) or not unchanged or script.read_bytes() != original:
            raise OSError("Generator seit Beginn der Reparatur geaendert. Vorhandene Version bleibt erhalten.")
        replace_script(staged, script)
        if script.read_bytes() != updated:
            raise OSError("Generator nach dem Ersetzen nicht bytegenau bestaetigt.")
        return {"ok": True, "status": "PP_TEMPLATE_REPAIRED", "script": str(script), "backup": str(backup),
                "originalSha256": digest(original), "sha256": digest(updated)}
    except (OSError, ValueError, SyntaxError, LookupError) as exc:
        if backup is not None:
            raise RuntimeError(str(exc) + " | Sicherung: " + str(backup)) from exc
        raise
    finally:
        if staged is not None:
            staged.unlink(missing_ok=True)
        lock.unlink(missing_ok=True)


def probe(plan, folder, output):
    if plan not in {"PP+", "DC"} or output != folder / "Ausgabe_PDF":
        raise ValueError("Generatorplan oder Ausgabeordner ist nicht gebunden.")
    script = folder / (PP_SCRIPT if plan == "PP+" else DC_SCRIPT)
    require_readable(script)
    _, repairs = checked_source(script)
    if plan == "PP+":
        required = [folder / TEMPLATE, folder / "IPP_Kontoauszuege_Arbeitsdatei.xlsm",
                    folder / "Kontostand_Kontrolle_Arbeitsdatei.xlsm",
                    folder.parent / "Daten" / "eckwerte_runtime.py",
                    folder.parent / "Daten" / "Personenordner_Zuordnung.csv"]
    else:
        required = [folder / "_2026_LNW_DC_Output.xlsm", folder / "Personenordner_Zuordnung.csv"]
        work = folder / "_2026_LNW_DC_Arbeitsdatei.xlsm"
        if work.exists():
            required.append(work)
    for file in required:
        require_readable(file)
    output.mkdir(exist_ok=True)
    # Exercise create, write, close and delete with our own unique temporary file.
    with tempfile.NamedTemporaryFile(prefix=".mcr_preflight_", suffix=".tmp", dir=output) as stream:
        stream.write(b"1")
        stream.flush()
    return {"ok": True, "templateRepair": bool(plan == "PP+" and repairs)}


def run_pp(script, args):
    if script.name != PP_SCRIPT or script.parent != Path.cwd().resolve():
        raise ValueError("Unerwarteter Generatorpfad.")
    require_readable(script.parent / TEMPLATE)
    code, _ = checked_source(script)
    module = types.ModuleType("__main__")
    module.__file__ = str(script)
    sys.modules["__main__"] = module
    sys.argv[:] = [str(script), *args]
    sys.path[0] = str(script.parent)
    exec(code, module.__dict__)


if __name__ == "__main__":
    if sys.argv[1] == "check":
        try:
            result = probe(sys.argv[2], Path(sys.argv[3]).resolve(), Path(sys.argv[4]).resolve())
        except (OSError, ValueError, SyntaxError, LookupError) as error:
            result = {"ok": False, "reason": str(error)}
        print(json.dumps(result, ensure_ascii=True))
        sys.exit(0 if result["ok"] else 1)
    elif sys.argv[1] == "repair-pp" and len(sys.argv) == 3:
        try:
            result = repair_pp(Path(sys.argv[2]))
        except (OSError, ValueError, RuntimeError, SyntaxError, LookupError) as error:
            result = {"ok": False, "status": "PP_TEMPLATE_REPAIR_FAILED", "reason": str(error)}
        print(json.dumps(result, ensure_ascii=True))
        sys.exit(0 if result["ok"] else 1)
    elif sys.argv[1] == "run-pp":
        run_pp(Path(sys.argv[2]).resolve(), sys.argv[3:])
    else:
        raise SystemExit("Unbekannte Aktion.")
