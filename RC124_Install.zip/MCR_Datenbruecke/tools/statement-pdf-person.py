"""Return identity status and hash of the inspected statement. Never emit its text."""
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import unicodedata


def extract(data):
    try:
        from pypdf import PdfReader
    except ImportError:
        try:
            from PyPDF2 import PdfReader
        except ImportError:
            PdfReader = None
    if PdfReader:
        reader = PdfReader(io.BytesIO(data))
        return '\n'.join(reader.pages[i].extract_text() or '' for i in range(min(2, len(reader.pages))))
    tool = shutil.which('pdftotext')
    if tool:
        args = [tool, '-f', '1', '-l', '2', '-enc', 'UTF-8', '-', '-']
        result = subprocess.run(args, input=data, capture_output=True, check=True, timeout=15)
        return result.stdout.decode('utf-8')
    return ''


def words(s):
    return re.findall(r'[^\W_]+', unicodedata.normalize('NFC', s).casefold(), re.UNICODE)


def labelled_wwids(text):
    return re.findall(r'(?i)\b(?:WWID|ClientEEID|EmployeeIDNumber)\s*[:#-]?\s*([0-9]{4,15})\b', text)


def identify(text, file, wwid, first, last, plan):
    fields = labelled_wwids(text)
    if any(value != wwid for value in fields):
        return 'MISMATCH'
    canonical = os.path.basename(file).casefold() == f'{wwid}_Kontoauszug_{plan}.pdf'.casefold()
    stream = ' ' + ' '.join(words(text)) + ' '
    names = (first + ' ' + last, last + ' ' + first)
    if (canonical or fields) and any((' ' + ' '.join(words(name)) + ' ') in stream for name in names):
        return 'MATCH'
    return 'REVIEW'


if __name__ == '__main__':
    with open(sys.argv[1], 'rb') as source:
        data = source.read(50 * 1024 * 1024 + 1)
    fields = []
    try:
        text = extract(data) if len(data) <= 50 * 1024 * 1024 else ''
        fields = labelled_wwids(text)
        result = identify(text, *sys.argv[1:])
    except Exception:
        result = 'REVIEW'
    print(json.dumps({'status': result, 'wwidInText': bool(fields) and set(fields) == {sys.argv[2]}, 'sha256': hashlib.sha256(data).hexdigest()}))
