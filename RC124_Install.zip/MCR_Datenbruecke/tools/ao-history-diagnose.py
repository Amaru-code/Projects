"""RC117: read-only AO history diagnostics. Never generate, save, or print balances.
Run with the same Windows Python installation as the AO generator.
"""
import argparse
from collections import Counter
from datetime import datetime, timedelta
import json
from pathlib import Path

CONTROL = Path(r'K:\INTL01\6_AU (Admin)\~ Data\~ Bestand Intel Gesamtübersicht\2026-01-Kontostand Kontrolle1 - corrected.xlsm')

def normalize_wwid(value):
    text = str(value or '').strip()
    return text[:-2] if text.endswith('.0') and text[:-2].isdigit() else text

def date_like_generator(value):
    if isinstance(value, datetime):
        return value
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        try:
            return datetime(1899, 12, 30) + timedelta(days=float(value))
        except (ValueError, OverflowError):
            return None
    return None

def numeric(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and not -2146827000 <= value <= -2146826000

def assess(rows, wwid, year):
    cutoff = datetime(year, 1, 1).date()
    counts = Counter()
    for r in rows:
        if len(r) < 7 or normalize_wwid(r[1]) != wwid:
            continue
        counts['matched_wwid'] += 1
        account = str(r[5] or '').strip()
        if account not in ('Basiskonto', 'Schattenkonto'):
            counts['different_account_type'] += 1
            continue
        prefix = 'base' if account == 'Basiskonto' else 'shadow'
        dt = date_like_generator(r[4])
        if not dt:
            counts[prefix + '_invalid_date'] += 1
        if not numeric(r[6]):
            counts[prefix + '_invalid_amount'] += 1
        if dt and numeric(r[6]):
            relation = 'before' if dt.date() < cutoff else 'exact' if dt.date() == cutoff else 'after'
            counts[prefix + '_valid_' + relation] += 1
    keys = ['matched_wwid','different_account_type'] + [p + '_' + s for p in ('base','shadow') for s in ('invalid_date','invalid_amount','valid_before','valid_exact','valid_after')]
    return {'wwid': wwid, 'cutoff': str(cutoff), **{k: counts[k] for k in keys}}

def main():
    p = argparse.ArgumentParser(description='Nur lesende Diagnose der AO-Kontostandshistorie; keine Betraege oder Namen ausgegeben.')
    p.add_argument('--wwid', nargs='+', required=True)
    p.add_argument('--year', type=int, default=datetime.now().year)
    a = p.parse_args()
    if any(not x.isascii() or not x.isdigit() for x in a.wwid) or not 1901 <= a.year <= 9998:
        p.error('WWID/Zieljahr ungueltig')
    import win32com.client as win32
    excel = book = None
    try:
        excel = win32.DispatchEx('Excel.Application')
        excel.Visible = False
        excel.DisplayAlerts = False
        excel.AskToUpdateLinks = False
        excel.AutomationSecurity = 3  # disable macros
        book = excel.Workbooks.Open(str(CONTROL), ReadOnly=True, UpdateLinks=0, Notify=False)
        if not book.ReadOnly:
            raise RuntimeError('ReadOnly nicht bestaetigt; Diagnose abgebrochen')
        sheet = book.Worksheets('Kontostände Intel DEU')
        used = sheet.UsedRange
        # The original generator assumes UsedRange starts at column A and skips
        # its first row. Report violations rather than silently moving columns.
        meta = {'sheet': 'Kontostände Intel DEU', 'used_range_first_row': used.Row, 'used_range_first_column': used.Column}
        rows = used.Value2
        if used.Column != 1 or not isinstance(rows, tuple) or not rows or not isinstance(rows[0], tuple):
            raise RuntimeError('UsedRange passt nicht zur festen Spaltenannahme des Generators: '+json.dumps(meta))
        print(json.dumps({'read_only': True, **meta, 'results': [assess(rows[1:], x, a.year) for x in a.wwid]}, ensure_ascii=False, indent=2))
    finally:
        try:
            if book is not None:
                book.Close(SaveChanges=False)
        finally:
            if excel is not None:
                excel.Quit()

if __name__ == '__main__':
    main()
