# RC44 – DC-Kontoauszugordner dauerhaft auf Unterstrich umgestellt

**Version 0.8.1-rc.44.** Der DC-Ausgabeordner ist jetzt fest `Kontoauszug_DC\Ausgabe_PDF` (statt `Kontoauszug DC\Ausgabe_PDF`). Menü 10, 11 und 12 nutzen diesen gemeinsamen Pfad. Die PP+-Dateien bleiben unter `Kontoauszug_pp+\Ausgabe_PDF`. Die freigegebenen FilePond-/Journal- und Versandregeln aus RC43 bleiben unverändert. Das ZIP enthält keine erzeugten Lauf- oder Diagnoseberichte; der Installer erhält bestehende Laufdaten und Referenzen. Siehe `docs/RC44_DC_OUTPUT_PFAD_UND_SAUBERES_PAKET.md`.

---

# RC43 – FilePond: Kontoauszuege zuerst anhaengen

**Version 0.8.1-rc.43.** Menü 12 wählt die bereits in Menü 11 geprüften PDFs unmittelbar aus den lokalen DC-/PP+-Ausgabeordnern aus. Die Reihenfolge lautet jetzt **PDFs anhängen → Anfrage Member → vierte Beschreibungszeile → Entwurf speichern → Ticket speichern → gespeicherte PDF-Anlagen prüfen → optional an mark.baindl weiterleiten**.

Wichtig: Die bisherige COMARCH-Anlage verwendet ein sichtbares FilePond-Label `Dateien hierher ziehen oder zum Auswählen klicken` und dynamische `filepond--browser-*`-IDs. Der Bot klickt dieses Label per echter Browsermaus, fängt den nativen Dateidialog ab und übergibt exakt die SHA256-geprüften Kontoauszugs-Pfade an das korrekt gebundene Input. Es wird kein Dateiname über Javascript als vermeintlich hochgeladen gesetzt. Alte `emailAttachmentFileUpload`-Oberflächen bleiben als gesonderter Fallback erhalten. Zwei PDFs werden bei Mehrfachauswahl einmalig, andernfalls nacheinander mit neuem Feldabgleich gewählt.

Nach FilePond-Anzeige gilt nur **im Browser vorgemerkt**, nicht serverseitig gespeichert. Nach Entwurfs-/Ticketspeicherung muss COMARCH die beiden Anlagen nach erneutem Öffnen anzeigen. Nur bei bestätigtem Tickettext, beiden Anlagen, einem zugeordneten Member und deiner Freigabe kann die Weiterleitung an Mark Baindl erfolgen. Kein E-Mail-Versand durch Menü 12.

**Alter offener Journalstand `GEVO_INTENT`:** Der RC42-Durchlauf wurde vor einer Dateiaktion gestoppt; das bisherige Journal wird nicht gelöscht. Nach unabhängigem Nachweis, dass kein Upload, Entwurf, Ticket-Speichern oder Weiterleiten vorgenommen wurde, ist eine einmalige kontrollierte Übernahme in die neue Upload-Zuerst-Reihenfolge vorgesehen (`PHASE2_FREIGABE_UND_WIEDERAUFNAHME`). Bei Zweifel ABBRUCH. Alle Journale ab `UPLOAD_INTENT`, Speichern und Weiterleitung sind weiterhin ohne erneute externe Prüfung gesperrt.

Weitere Details: `docs/RC43_FILEPOND_NATIVE_UPLOAD_VOR_GEVO.md`.

---

## RC42 – Phase 2: COMARCH-GEVO-Fokus und einmaliger Wiederanlauf

**Aktuelle Version: 0.8.1-rc.42.** Im Phase-2-Menü 12 wird ein leeres, gegebenenfalls verdecktes Feld `mainForm:gevo-value-id` kontrolliert fokussiert. Wenn COMARCH den sicheren Browserklick verhindert, darf der Operator **genau dieses Eingabefeld** selbst fokussieren; anschließend wird der DOM-Fokus technisch geprüft und `Anfrage Member` mittels der bewährten echten Browser-Tastatur eingegeben. Keine unsicheren JavaScript-Klicks oder fremde Felder.

Eine alte RC41-Unterbrechung unmittelbar bei `GEVO_INTENT` kann nach erneutem Einlesen von **demselben** Ticket, identischen ursprünglichen Beschreibungszeilen, unveränderten PDF-Prüfsummen und fehlenden Anlagen im COMARCH-Ticket einmalig fortgesetzt werden, jedoch nur nach ausdrücklicher Bestätigung **ohne Upload, Speichern, Weiterleiten oder sonstige Aktion**. Das Journal wird erhalten und erweitert; es wird nicht gelöscht. Bereits begonnene Upload-/Speicher-/Weiterleitungsaktionen bleiben gesperrt. Phase-1-Echtversand unverändert. Näheres unter `docs/RC42_PHASE2_GEVO_FOCUS_UND_KONTROLLIERTER_WIEDERANLAUF.md`.

---

## RC41 – Windows-Testbrowser nach erfolgreicher Fiktivprobe sicher beenden

Nur beim fiktiven Testbrowser: streng auf eigenen Browser-PID und temporäres Profil begrenzte Windows-Prozessbaum-Bereinigung, falls CDP und normaler Prozessabbruch nicht reichen. Kein Verhalten des produktiven Ticketlaufs wird geändert. Siehe `docs/RC41_WINDOWS_FICTIONAL_BROWSER_PROCESS_FINALIZATION.md`.

## RC40 – Windows-Selbsttest nach erfolgreicher Browserweiterleitung

Die RC39-E2E-Prüfung `missing-comarch-member-mark` konnte unter Last nach `RUN COMPLETE` ohne sauberen Child-Exit im Timeout enden. RC40 fährt fiktive Chromium-Prozesse kontrolliert über CDP herunter, verifiziert den Exit und begrenzt die Testparallelität. Phase-1- und Phase-2-Funktionen bleiben unverändert. Details unter `docs/RC40_WINDOWS_TEST_BROWSER_SHUTDOWN.md`.

---

## RC33 – Quelle ist kein Ticketfilter

Siehe `docs/RC33_SOURCE_NEUTRAL_ELIGIBILITY.md`. Die Auswahl beruecksichtigt Quellen unabhaengig von `E-MAIL`; ein Versand wird nur bei verifizierter Antwortadresse vorbereitet.

# RC32 – Person nicht in COMARCH gefunden

**Aktuelle Version:** 0.8.1-rc.32. Neuer, ausdrücklich manuell bestätigter No-Mail-Weg bei vollständig fehlender COMARCH-Member/MercerID-Auswahl. Die bisherige Standardantwort bleibt unverändert.

Bei ausbleibender Member-Bestätigung im Terminal **1 erneut suchen**, **2 nach sorgfältiger COMARCH-Prüfung nicht gefunden**, **0 unbearbeitet lassen**. Für 2 wird die exakte Bestätigung `PERSON NICHT GEFUNDEN` verlangt. Danach den erlaubten Bearbeiter wählen, im Pilot `WEITERLEITEN` freigeben; nur ein nachgewiesener Forward gilt als erledigt. Kein unbestätigter Member, keine Antwortmail, keine erfundenen USC-Daten. Weitere Details: `docs/RC32_COMARCH_PERSON_NICHT_GEFUNDEN.md`.

---

# RC31 – Sichere Weiterleitung bei fehlendem Bestandsdatensatz

**Aktuelle Version:** 0.8.1-rc.31. Keine Änderung am bestätigten Standardantwort-Versand.

COMARCH-Bearbeiter wird über das echte Feld `mainForm:persona-assignment-id`
ausgewählt. Das Terminal bietet **1 Baindl Mark (`mark.baindl`)**,
**2 Gutierrez Victor (`Victor.Gutierrez`)** oder **0 Abbruch**.
Es darf nur ein eindeutiger, tatsächlich übernommener Vorschlag weitergeleitet
werden. Der Browser erzeugt höchstens einen Weiterleitungsklick; Erfolg muss
neu nachgewiesen oder vor Ort unabhängig geprüft werden.

`ROUTE_FIXED_FIELDS_NOT_SAVED` aus RC30: Die Signatur ist für die Antwortmaske
relevant und wird **vor** dem Speichern geprüft. Nach Wiederöffnen der
No-Mail-Weiterleitung werden Zuständigkeit, Kategorie und Unterkategorie
geprüft. Verlorene Werte können höchstens einmal kontrolliert nachgesetzt,
neu gespeichert und nochmals geprüft werden. Danach ggf. STOP, ohne Weiterleitung.
Ein angefangener Vorgang bleibt im unveränderten Journal geschützt.

**Wichtig beim bisherigen Ticket 87086074:** RC30 hat den Tickettext
nachweislich gespeichert, aber ausdrücklich keine Weiterleitung bestätigt.
Vor neuem Start in COMARCH kontrollieren und ggf. **Menü 5** verwenden.
Ein bereits mit Text versehenes altes Ticket wird aus Sicherheitsgründen nicht
automatisch wieder als neuer Erstkontakt verarbeitet: Die ausstehende
Weiterleitung ist notfalls manuell abzuschließen. Keine blinden Klicks.

Siehe `docs/RC31_WEITERLEITUNG_EXAKTES_PERSONA_FELD.md`.

---

# RC30 – Stabilisierung der Erstsichtung und Phase-2-Leseprobe

**Aktuelle Version:** 0.8.1-rc.30. Der Standardantwort-Echtlauf und sein
Doppelversand-Schutz bleiben auf dem RC29-Verhalten; hinzu kommen die gebundene
Vertauschungspruefung, begrenzte Name-/ID-Rueckfragen, Tagesprotokoll und
Browserkontrolle. `docs/RC30_BETRIEB_UND_PHASE2_VORPRUEFUNG.md` beschreibt die
Freigabegrenzen. **Phase 2 ist in RC30 noch nicht schreibend aktiv.**

# RC29 – Falscher Absendername und kleines Live-Statusfenster

**Neu:** Wenn die E-Mail nachweislich einen falschen Personennamen enthält, kann die zugeordnete Person *ausschließlich* nach verifiziertem strukturiertem COMARCH-Profil, ausdrücklicher MercerID- und Namensbestätigung und Prüfung der Berechtigung durch den Operator korrigiert werden. Ein aktueller ausdrücklicher MercerID-Widerspruch ist nicht übersteuerbar. Unveränderte normale Fälle laufen ohne Rückfrage. Vor jedem Versand prüft der Bot weiterhin denselben Member und das Versandjournal.

**Live-Status:** Ein kleines, mausdurchlässiges Windows-Fenster zeigt Ticket, Person, MercerID, USC/Pläne und Standardantwort-Status. Es ist rein informativ, steuert keine Aktionen, schreibt keine personenbezogenen Statusdateien und blendet nach Abschluss ab. Ohne Windows-PowerShell läuft der Bot unverändert weiter. Die bisherigen zwei getrennten CSV-Spalten bleiben erhalten.

**Ablauf:** Neues ZIP **separat** entpacken, `START.cmd` im neuen Paket starten, **Menü 1** für gesichertes Upgrade und Tests, dann **Menü 3** für einen erneuten echten RC29-Piloten. Alte RC28-Pilottickets nicht erneut versenden. Details: `docs/RC29_MANUELLE_MEMBER_KORREKTUR_UND_LIVE_FENSTER.md`.

---

# RC25 – Versandbestätigung über COMARCH-Nachrichtenverlauf

Einzelne oder fehlende OK-Dialoge sind kein automatischer Versandfehler mehr. Sobald **genau ein neuer, ausgehender Standardantwort-Eintrag** zur **aktuellen Ticket-ID** und zum **ursprünglichen Absender** nachweisbar ist, darf der Bot den einmaligen Versand als bestätigt behandeln und das Ticket einmal speichern. Die neue Nachricht muss nach dem einen einzigen Sendeklick entstanden sein. Doppelte Sendeklicks bleiben verboten. Weitere Informationen: `docs/RC25_SEND_CONFIRMATION_AND_FULL_RUN.md`.

**Full Run (Menü 4)** bleibt bis zum echten, gesendeten **und gespeicherten** Piloten (Menü 3) gesperrt. Ein alter RC24-`SEND_UNVERIFIED` darf nicht ungeprüft als gespeicherter Pilot zertifiziert werden. Das alte Ticket wird bis zur Klärung im Versandjournal geschützt und vom nächsten Lauf ausgeschlossen.

## RC23: Verwaiste Lauf-Sperre automatisch archivieren

Beim Installieren oder Starten schließt RC23 nach einer unabhängigen Prozessprüfung nur **verwaiste** REAL_RUN-Sperren. Offene `SEND_INTENT`-Tickets werden **nicht gelöscht und nicht erneut gesendet**, sondern beim neuen Ticketlauf ausgeschlossen. Ein noch laufender Bot, eine Migrationssperre oder ein unlesbares Journal bleibt gesperrt. Details: `docs/RC23_RUN_RECOVERY.md`.

# RC20 – Nachrichtenzähler und idempotente Standardantwort-Markierung

**Neu:** Pro Ticket die sichtbaren Kunden-, Ausgangs-, System- und unbekannten Nachrichten zählen. Eine nachweislich bereits versendete Standardbestätigung im selben Ticket führt zur Ergänzung `Standardantwort versendet` in der zusätzlichen Beschreibung, zu genau einem verifizierten Speichern und zum nächsten Ticket – **ohne einen zweiten Versand**. Vollständige Regeln unter `docs/RC20_NACHRICHTENVERLAUF_UND_STATUSMARKIERUNG.md`.

# RC19 — Sicherer Sprung zum nächsten unbeantworteten Ticket

- Ausgehende Standardantworten, die nachweislich zum aktuellen Ticket und Originalabsender gehören, führen zu `PASS SKIP_ALREADY_ANSWERED` statt zum Gesamtabbruch.
- Das beantwortete Ticket wird nicht verändert, nicht erneut gesendet und nicht automatisch als gespeichert zertifiziert.
- Der Bot sucht direkt das nächste geeignete, noch unbeantwortete Ticket.
- CKEditor mit `<html contenteditable="true">` wird nur im Body beschrieben; vorhandene fremde Entwürfe bleiben geschützt.
- COMARCH-Empfänger werden aus `mainForm:email-to-editable` verifiziert.
- Bestehende Reihenfolge und Einzelversand bleiben unverändert. Ein echter COMARCH-Pilot ist erforderlich.

# RC19 — Sicherer Sprung zum nächsten unbeantworteten Ticket

- Ausgehende Standardantworten, die nachweislich zum aktuellen Ticket und Originalabsender gehören, führen zu `PASS SKIP_ALREADY_ANSWERED` statt zum Gesamtabbruch.
- Das beantwortete Ticket wird nicht verändert, nicht erneut gesendet und nicht automatisch als gespeichert zertifiziert.
- Der Bot sucht direkt das nächste geeignete, noch unbeantwortete Ticket.
- CKEditor mit `<html contenteditable="true">` wird nur im Body beschrieben; vorhandene fremde Entwürfe bleiben geschützt.
- COMARCH-Empfänger werden aus `mainForm:email-to-editable` verifiziert.
- Bestehende Reihenfolge und Einzelversand bleiben unverändert. Ein echter COMARCH-Pilot ist erforderlich.

# RC18 Slim: COMARCH Systemdaten-Sender, Eingangspost statt Ausgangspost, Entwurfschutz

RC18 behebt einen anhand des tatsächlichen ICEfaces-DOMs nachgewiesenen Fehler: Das Label `E-mail von:` und der Absenderwert stehen in **benachbarten Tabellenzellen**, nicht als direkte Geschwisterelemente. Die Namenserkennung liest jetzt die eindeutig zugeordnete Nachbarzelle. Persönliche E-Mail-Adressen erzeugen einen Suchkandidaten, der weiterhin über den richtigen COMARCH-Member und gegebenenfalls eine explizite MercerID verifiziert werden muss.

Die Mailhistorie unterscheidet ein- und ausgehende Dokumente anhand der dokumentierten COMARCH-Bildsymbole. Der Bot verarbeitet nicht versehentlich die eigene Ausgangsantwort als aktuelle Absender-Mail. Vor dem Ändern der Pflichtfelder oder des Antworteditors wird eine bereits versendete Empfangsbestätigung geprüft. Vorhandene eigene Entwürfe werden nicht durch Standardtexte überschrieben. Bei einem solchen Fall: **kein erneuter Versand**, sondern Speicherung/Zustand manuell verifizieren. Keine pauschale Freigabe `SICHER_KEIN_VERSAND` bei vorhandener Ausgangs-Mail.

Siehe `docs/RC18_ECHTES_ICEFACES_HTML_UND_DRAFTSCHUTZ.md`.

# RC17: COMARCH-Autoauswahl + E-Mail-von (keine blinden Mehrfachversände)

## RC14: Automatische Namenssuche (COMARCH-History / MSG)

Neben Nachricht und Signatur wird der aktuelle Absender ausgewertet. Eine
Adresse wie `vorname.nachname@firma.de` liefert einen **Suchkandidaten**,
aber niemals allein eine berechtigte Identitaet. Erst nach genauer
COMARCH-Member- und MercerID-Pruefung kann der Bot weitermachen. Bei
Konflikten bleiben die manuellen Kontrollen und das Versandjournal aktiv.

Siehe `docs/RC14_AUTOMATISCHE_NAMENSSUCHE.md`.

## RC13: Legacy COMARCH Kategorie-Suche

Der Kategorienwert kann nach ICEfaces-Keyup um ein Zeichen gekuerzt sein. RC13 akzeptiert diesen Zustand nur als Such-Praefix; der eindeutige vollstaendige Vorschlag muss dennoch physisch ausgewaehlt und danach verifiziert werden. Siehe docs/RC13_COMARCH_QUERY_FIX.md.

# MCR Datenbruecke 0.8.1 RC9 – echter Member-Klick auch nach Unterkategorie

**RC9 korrigiert die reale COMARCH-Unterkategorie mit einem zusätzlichen echten Member-Klick ohne Wertänderung.** Wenn die Unterkategorie trotz Klick nicht bestätigt wird, ist eine kontrollierte manuelle Korrektur möglich, bevor der Bot sicher stoppt. **RC8 ergänzt den bewährten manuellen Namensfallback aus RC7 und korrigiert den COMARCH-Fokuswechsel vor der Unterkategorie.** RC7 behebt `NAME_NONE [PHASE MAIL_AND_PERSON]`: Erkennt der Bot in der lesbaren Original-Mail keinen Namen, fragt er im Konsolenfenster **Vorname und Nachname getrennt ab**. Bitte direkt aus der angezeigten Original-Mail / dem aktuellen Ticket übernehmen, mit `JA` bestätigen. Leere, ungültige oder abgelehnte Eingaben werden erneut abgefragt (bis zu fünf Versuche). `ABBRUCH` beendet die Verarbeitung kontrolliert ohne E-Mail und ohne Weiterleitung.

Nach manueller Eingabe wird der ausgewählte COMARCH-Member weiterhin auf denselben Namen und die ggf. in der aktuellen Nachricht explizit vorhandene MercerID geprüft; **keine automatische Akzeptanz**. Erst nach bestätigtem COMARCH-Member beginnt der unveränderte Bestandsabgleich (vollständige ID, ggf. genau ein führendes `11` entfernen). Bei tatsächlichem Nichttreffer bleibt die getrennte Weiterleitung an Gutierrez Victor ohne Mail.

**Installation:** RC9 vollständig in einen NEUEN Ordner unter Downloads entpacken. Dort `START.cmd`, Menü 1, bestehende Installation als Ziel, Tests/Demo, `EINRICHTEN`. Danach immer `START.cmd` im bisherigen Projektordner. Die `private_data`-Dateien, das aktive Mapping, Edge-Profil und frühere Lauf-/Versandprotokolle bleiben unverändert. RC8 kann nach einem nachgewiesenen Vor-Aktionsabbruch ohne Versand-/Speicher-/Weiterleitungsversuch die alte Laufblockade selbst protokolliert aufheben. Bei jeder Unsicherheit bleibt Menü 5 verpflichtend; keine blinde Wiederholung.

Weitere technische Details: `docs/RC7_MANUAL_NAME_FALLBACK.md`.

---

# MCR Datenbrücke – 0.8.1 RC6 (gezielte Member-Feld-Wiederherstellung)

**Neuer RC6-Fix für `ACTION_OCCLUDED_OR_OFFSCREEN [PHASE MEMBER_SEARCH]`:** Die Eingabe zur COMARCH-Member-Suche wird zunächst als **exakt ein bearbeitbares Eingabefeld** erkannt. Der Bot probiert automatisch vier Scroll-Ausrichtungen (Mitte, Anfang, Ende, nächster sichtbarer Bereich), prüft den sichtbaren Bereich mit `elementFromPoint()` und verwendet höchstens **einen** echten Browser-Mausklick. Wenn das Feld vorübergehend fehlt, wartet er auf die ICEfaces-Aktualisierung. Nur wenn die automatische Fokussierung unmöglich bleibt, fordert er dich auf, das **Member-Eingabefeld im eigenen Bot-Edge** selbst anzuklicken; er prüft anschließend, dass genau dieses Eingabefeld fokussiert ist. Keine JS-Klicks durch überdeckende Dialoge, keine unsichere blinde Suche.

Dasselbe Verfahren aktiviert das Memberfeld beim Setzen der Unterkategorie und unterstützt die Kategorie-/Signatur-Suchfelder. **E-Mail-Versand, Speichern und Weiterleiten bleiben an ihren bisherigen strengen, echten Klick- und Nachweispfaden.** Die Regel zum Entfernen von `11` greift ausschließlich nach nachgewiesener COMARCH-Member-Identität und bei fehlendem Original-Bestandskey.

Der letzte RC5-Pilot stoppte *vor* der Bestandsauswertung und vor einer Versand-/Weiterleitungsaktion. Ein abgebrochener Echtlauf erzeugt dennoch `INTERRUPTED_REVIEW_REQUIRED`: COMARCH auf ausgehende Nachrichten und Weiterleitungen prüfen und erst dann über Menü 5 freigeben. Eigenes Bot-Edge vorher schließen. RC6 installierst du aus einem **separat entpackten ZIP** über Menü 1; `private_data`, aktives Mapping, Konfiguration, Browserprofil und Journale bleiben am bisherigen Ort. Regulärer Lauf erst nach einem echten erfolgreichen beaufsichtigten Einzelticket-Piloten.

---

# MCR Datenbruecke – vollständiges Paket 0.8.1 RC5

**RC5 behebt die COMARCH-Fehlermeldung `RUNNER_ERROR: Ungeltige Klickposition` beim Öffnen eines Member-Vorschlags.** Ein unbeschränkter Mittelpunkt von `getBoundingClientRect()` kann bei COMARCH-Autocomplete auch außerhalb des sichtbaren Browserfensters liegen. RC5 verwendet nur innerhalb des Viewports liegende und durch `document.elementFromPoint()` bestätigte Punkte, prüft die Bindung direkt vor dem einen echten Mausclick und fordert bei Unsicherheit eine manuelle Auswahl. Nach jeder Auswahl muss die Identität weiterhin nachgewiesen werden. Neue datensparsame Phasenmeldungen helfen bei Fehlern. Die Weiterleitungs-, `11`-Fallback-, Versand-, Speicher- und Wiederanlaufsperren sind unverändert.

**Der letzte RC4-Pilot stoppte vor E-Mail und Weiterleitung.** Ein abgebrochener Echtlauf erzeugt dennoch eine `INTERRUPTED_REVIEW_REQUIRED`-Sperre: Vor neuem Pilot COMARCH prüfen, dass weder gesendet noch weitergeleitet wurde, und nur bei tatsächlicher Bestätigung über Menü 5 dokumentieren. Das eigene Bot-Edge-Fenster für die Prozessprüfung schließen, aber keine allgemeinen Edge-Fenster beenden.

**Installation:** RC5-ZIP vollständig in ein *neues* Verzeichnis unter Downloads entpacken, **nicht** in die installierte `MCR_Datenbruecke`. Aus dem entpackten RC5-Ordner `START.cmd` starten → Menü 1 → bestehenden Pfad übernehmen → alle lokalen Selbsttests und fiktiven Browserproben durchführen → `EINRICHTEN`. Das Ziel wird als RC4 geprüft und softwareseitig archiviert. `private_data`, aktives Mapping, bestehendes Browserprofil, Konfiguration und bisherige Laufkontrollmetadaten bleiben am Ort. Einrichten versendet keine E-Mail. Nach `PASS INSTALLATION_COMPLETE` ausschließlich die `START.cmd` im bisherigen Installationsordner verwenden.

**Abnahmegrenze:** Die reale COMARCH-Koordinatenlage kann unter Linux nicht vollständig nachgestellt werden. RC5 ist bis zum beaufsichtigten Windows-Pilot nicht produktiv freigegeben. Nicht bei unklarem Versand/Weiterleitung automatisch erneut versuchen.

---

## Frühere RC4-Installationskorrektur

**RC4 behebt den auf Windows aufgetretenen Installationsabbruch** `STOP EPERM` beim Verschieben von `stage\tests` nach `MCR_Datenbruecke\tests`. Neue Software wird aus einer separat geprüften Stage dateiweise kopiert und nach jeder Top-Level-Einheit auf den vollständigen Baum-Hash geprüft. Die Installation bleibt bis zur abschließenden Verifikation gesperrt; eine begonnene fehlgeschlagene Installation wird auf die geprüfte Vorversion zurückgestellt. Bestehende Browser- und Mappingdaten werden nicht angefasst.

Wenn RC3 `Rueckweg: SOFTWARE_RESTORED` gemeldet hat, zunächst den wiederhergestellten Zielordner über seine `START.cmd` und Menü 6 prüfen. Das Downloadpaket besitzt kein `private_data` und ist **nie** für Menü 3 oder 4 bestimmt. Der letzte reale Ticketversuch kann weiterhin `INTERRUPTED_REVIEW_REQUIRED` melden; die Prüfung unter Menü 5 nur anhand COMARCH durchführen, nicht pauschal freigeben.

Dieses ZIP enthält das vollständige Programm in einem Ordner `MCR_Datenbruecke`.
Es ist kein Patch und sucht keine RC1.1-, V8-, V9- oder sonstigen Alt-Downloads.
Alle Laufzeitmodule, Identity-Prüfungen, Demo-Daten, Selbsttests und der Installer
sind enthalten. Externe npm-Abhängigkeiten: keine. Verwendet werden die bereits
vorhandene portable Node-Installation (ab 22.15) und Microsoft Edge.

**Prüfstand:** reale Chromium-Tests der fiktiven Oberfläche und lokale Unit-/Dateisystemtests.
Windows/echtes COMARCH sind nicht aus der Entwicklungsumgebung geprüft. RC bedeutet
Release-Kandidat, nicht eine bereits nachgewiesene produktive Freigabe.


## Neu in RC3: MercerID mit optionalem Praefix `11` und kontrollierte Weiterleitung

- **Exakte MercerID zuerst.** Beispiel `11369422`: Das aktivierte V2-Mapping wird zuerst nach `11369422` abgefragt.
- Nur wenn dies `ID_NOT_FOUND` ergibt, prueft der Bot bei einer mit `11` beginnenden ID zusaetzlich den Schluessel ohne diese **eine** Praefixfolge (`369422`). Kein sonstiges Kuerzen, keine Namensheuristik und keine Aenderung der COMARCH-ID.
- Bei `ID_BLOCKED`, ungueltiger Kennung oder anderen fachlichen Fehlern wird gestoppt. Eine Sperre darf nie durch den Fallback umgangen werden.
- Wenn auch der zweite Schluessel fehlt: keine Antwortmail. Stattdessen im selben Ticket die **zusaetzliche Beschreibung** exakt `Person nicht im Gesamtbestand gefunden`, **Zustaendigkeit** `Second Level`, **Dokumentenkategorie** `Allgemeine Schriftwechsel`, **Unterkategorie** `Personenschriftwechsel` sowie Signatur setzen und speichern. Nach erneuter Pruefung aller vier Felder im gespeicherten Ticket nur den eindeutigen Vorschlag **Gutierrez Victor (Victor.Gutierrez)** aus der oberen Bearbeiter-Suche waehlen und **Weiterleitung** einmal ausloesen.
- Eine Forward-Aktion fuehrt ein vom Mailversand getrenntes Journal. Bei unbestaetigter Weiterleitung nicht wiederholt klicken; Menue 5 verlangt die vorherige manuelle Statuspruefung.
- **Keine Live-Freigabe durch reine Weiterleitung:** Ein erfolgreich an Victor umgeleitetes Pilotticket ist noch kein Beweis fuer den Mailversand-/Speicherprozess. Fuer Menue 4 braucht es weiterhin einen tatsaechlich gesendeten und gespeicherten Pilotfall.

Die neue Version muss ueber Menue 1 des **separat entpackten RC4-Pakets** aktualisiert werden. **Nicht** in den bisherigen `MCR_Datenbruecke`-Ordner entpacken oder alte Programmdateien einzeln ersetzen. Das aktive `private_data`-Mapping und bestehende `.runtime`-Daten bleiben im bisherigen Ordner und werden im Installer weder geloescht noch verschoben. Nach vorherigem Stopp `ID_NOT_FOUND` sollte Menue 5 genutzt werden, bevor ein neuer Liveversuch beginnt; keine Antwort blind erneut senden.

## Historisch: Korrektur RC2: STOP UNSEALED_CODE / lib/mail-download.cjs

Die neue Laufzeit benötigt die frühere Datei `lib/mail-download.cjs` nicht mehr.
Sie ist deshalb nicht Bestandteil des aktiven Komplettpakets. Liegt sie weiterhin
neben den neuen Dateien, stoppt die strenge Startprüfung. Das alte RC1 konnte
auch im Installer diesen ansonsten vollständig geprüften Mischbestand nicht
übernehmen. Dieser Übergangsfall ist jetzt ausdrücklich abgedeckt.

**Nicht einzelne Dateien löschen, keine Prüfsummen editieren, nicht darüberkopieren.**
Fuer ein Upgrade immer das jeweils aktuelle, vollstaendige Komplettpaket in einen neuen Ordner unter Downloads entpacken.
`START.cmd` ausschließlich aus diesem neuen Ordner starten, dann Menü 1 wählen.
Den bestehenden Projektpfad übernehmen. Der Installer erkennt ein unverändertes
Beta 4, das veröffentlichte RC1 sowie die aktuelle Version. Bei RC1/RC2 darf er
zusätzlich genau die bekannten, bytegeprüften Altdateien aus Beta 4 als
Update-Ausgangsbestand übernehmen. Diese Erkennung ist KEINE Startfreigabe.

`PASS BEKANNTE_BETA4_ALTDATEIEN_VERIFIZIERT` zählt die tatsächlich vorhandenen
Altdateien. 15 frühere Pfade sind mit ihren ursprünglichen SHA-256-Werten
hinterlegt; nicht alle müssen auf dem Rechner vorhanden sein. Geänderte oder
unbekannte zusätzliche Dateien bleiben gesperrt.

Nach Bestätigung mit `EINRICHTEN` wird der vollständige alte Softwarebestand
unter `_MCR_Archiv/complete_<Zeitpunkt>/software` gesichert. Die Programmordner
werden vollständig ersetzt und nicht ineinanderkopiert. Das Ziel muss danach
die unverändert strenge Prüfung ohne zusätzliche Programmdateien bestehen.
`private_data`, bestehende Config, Browserprofil, Diagnosen, `last-run.json` und
Versandjournal bleiben erhalten. Ein ungeklärter früherer Versand bleibt gesperrt.

Auch der Rückweg wurde für Dateien korrigiert, die in Alt- und Neuversion bereits
bytegleich sind: Eine bereits passende Originaldatei verursacht keine falsche
`ROLLBACK_COLLISION` mehr; das zusätzliche verifizierte Backup bleibt erhalten.
Der Rückweg stellt den tatsächlichen Ausgangsstand wieder her. War dieser vorher
ein gesperrter Mischbestand, ist das kein nachträglicher Nachweis der Startfähigkeit.

Das Archiv unter `tests/fixtures/complete-0.8.1-rc.1.zip` ist ausschließlich eine
versiegelte Testreferenz. Es wird nicht als laufendes Programm installiert und
muss nicht separat heruntergeladen oder vom Bediener ausgewählt werden.

## Drei Schritte

1. ZIP über „Alle extrahieren“ nach Downloads oder in einen anderen **neuen** Ordner
   entpacken. Nicht über den bisherigen `MCR_Datenbruecke`-Ordner kopieren.
2. Den alten Ticketbot und sein eigenes Edge-Fenster schließen. Im neuen Ordner
   `START.cmd` starten und **1 – Einrichten / aktualisieren und testen** auswählen.
   Der vorgeschlagene Zielpfad ist:
   `%USERPROFILE%\projects\Aktive_Projekte\Ticket_bot\MCR_Datenbruecke`
3. Nach bestandenen Selbsttests und drei fiktiven Szenarien (normal, Praefix `11`, Weiterleitung ohne E-Mail) mit `EINRICHTEN` bestaetigen.
   Das Programm archiviert nur die alte Software, installiert die neue Software
   und öffnet das Hauptmenü der bestehenden Installation. Künftig nur dort `START.cmd`.

Die Einrichtung sendet keine echten Nachrichten. Sie verändert weder die
Bestandsdateien unter `private_data` noch die vorhandene Config oder das Browserprofil.
Alte Software liegt separat unter `Ticket_bot\_MCR_Archiv\complete_<Zeitpunkt>\software`.
Der Installer führt vor jedem Update einen Hashvergleich des alten und neuen
Softwarestands durch. Unerwartete Änderungen werden nicht still überschrieben.

## Einmaliger echter Pilot

**Menü 3** ist ein beaufsichtigter Lauf für maximal ein echtes Ticket.
Das startet das eigene Bot-Edge-Fenster mit dem vorhandenen Browserprofil.
Nach Anmeldung `START` im Terminal eingeben. Unmittelbar vor dem Versand zeigt
es Ticket, Person, Empfänger, Beschreibung und Antwort lokal an.
Erst nach eigener Kontrolle mit `SENDEN` bestätigen.

Der Bot klickt Senden einmal, prüft den Anwendungsnachweis, klickt Ticket speichern
einmal und prüft den vollständigen Beschreibungstext in der Ticketliste.
Ein erfolgreiches Ticketlimit wird als normaler begrenzter Abschluss behandelt.
Erst nach `PASS LIVE_PILOT_SEND_AND_SAVE_VERIFIED` kann **Menü 4** den regulären
Lauf durchführen. Der reguläre Lauf verlangt eine eigene START-Freigabe und ein
Limit von 1 bis 100 Tickets. Ein leerer Lauf ist KEINE Pilotabnahme.

## Ein früherer Lauf ist ungeprüft?

Eine bestehende `last-run.json` aus Beta 4 wird übernommen und nicht zurückgesetzt.
Bei `LIVE_REVIEW_REQUIRED`, einer toten Laufsperre oder einer offenen Versandabsicht
**Menü 5** verwenden. Zuerst den letzten echten COMARCH-Nachrichtenverlauf prüfen.

* `SICHER_KEIN_VERSAND` nur wählen, wenn für alle offenen Fälle tatsächlich keine
  Antwort verschickt wurde. Erst diese ausdrückliche Erklärung erlaubt einen Retry.
* `VERSAND_UND_SPEICHERUNG_GEPRUEFT` nur wählen, wenn die bereits versendeten Antworten
  und die gespeicherten Tickets manuell nachgewiesen sind. Bereits beantwortete
  Tickets müssen auch für den alten Bot nicht mehr zulässig sein.
* Bei Unsicherheit ENTER: die Sperre bleibt bestehen.

Die Prüfentscheidung ist eine Bestätigung durch den Bediener, kein automatisch
ermittelter Versandnachweis. Menü 5 sendet und speichert nichts selbst.
Das neue dauerhafte Versandjournal verhindert den automatischen Neuversand nach
unklaren Unterbrechungen. Die einmalige Prüfung alter Beta-4-Läufe bleibt nötig,
weil diese Version noch kein solches ticketbezogenes Journal führte.

## Menü

1. Einrichten / aktualisieren und testen (kein Echtversand)
2. Fiktive Zwei-Ticket-Demo
3. Ein echtes Pilotticket mit SENDEN-Freigabe
4. Regulärer Lauf nach Pilotabnahme
5. Vorherigen Lauf prüfen / Wiederanlauf freigeben
6. Paket-/Mappingstatus und Selbsttests
7. Software-Rückweg
8. Mappingwartung aus derselben freigegebenen XLSX (für Reparatur NICHT nötig)
0. Beenden

## Erhaltene Fachregeln

Zuerst Meine Vorgänge / In_Bearbeitung, danach Warteschlange INTL01.
Nur E-MAIL-Tickets mit vollständig leerer zusätzlicher Beschreibung.
Echte Member-Auswahl und passender Name; nur ausdrücklich aktuelle MercerIDs
sind bindend. Zitierte/contextuelle Nummern werden nicht als aktuelle MercerID geraten.
Das aktive V2-Mehrzeilenmapping bleibt maßgeblich; kein Rückfall auf ältere Snapshots.
Pro physischer Bestandszeile eine Beschreibung, einschließlich identischer Zeilen.
Reihenfolge DC;PP+;DB+;TPP. Leere Flags bleiben leer; ungültige Zeilen sperren die Person.
Anrede aus Spalte O, bei fehlenden/widersprüchlichen Daten manuelle Prüfung.
Eine neutrale Antwort pro Ticket, nicht eine Antwort je Bestandszeile.

## Was tatsächlich geändert wurde

- Ein vollständiger Programmeinstieg ersetzt die vielen Wiederherstellungsstarter.
- Identity-Guard aus dem vorhandenen Reparaturcode integriert, inklusive Zitattrenner-Fix.
- Neue mitgelieferte deterministische fiktive Daten, fachlich dieselbe Zwei-Zeilen-Prüfung.
  Sie werden ausdrücklich NICHT als byteidentisches historisches RC1.1-Archiv bezeichnet.
- Demo-Payload-Zeitstempel ist fest; Originaldatei-, Payload- und fachliche Prüfungen
  werden nicht mehr mit einem historischen Laufhash verwechselt.
- Send/Save nutzen sichtbare Client-Rechtecke plus Zielprüfung vor dem Browserklick.
  Demo und echter Runner verwenden denselben Klickmechanismus; kein spezieller
  JavaScript-Speicheraufruf nur für die Demo.
- Dauerhafte Versandabsicht vor dem Sendeklick, gemeinsame Laufsperre und
  konservativer Wiederanlaufschutz.
- Keine pauschale Löschung alter MSG-Downloads. Jeder neue Download erhält einen
  eigenen Unterordner; die Originalbestandsdateien bleiben unangetastet.
- Ein echter Pilot verlangt zusätzlich die Freigabe der konkret vorbereiteten Antwort.

Der Programmcode wurde aus den im Chat übergebenen Quellen konsolidiert und teilweise
in kleinere Module aufgeteilt. Das ist eine neue, vollständig versiegelte Version,
kein behaupteter bytegleicher 0.7.4-/RC1.1-Stand. Neue Hashes stehen im Manifest.

## Ergebnisdateien

`Ergebnis\STATUS.json`, `Ergebnis\DEMO_ERGEBNIS.json` und
`Ergebnis\LETZTER_ECHTLAUF.json` enthalten Status/Klickzähler, keine Mailinhalte.
Der Demo-Bericht wird aus dem temporären Testordner dauerhaft nach Ergebnis kopiert.
Die aktuellen Diagnosen liegen unter `diagnostics` bzw. für die Demo unter Ergebnis.

**Nicht hochladen:** private_data, echte MSGs, .runtime/edge-profile und das vollständige
lokale Versandjournal. Das Browserprofil enthält private Sitzungsdaten.
Das lokale Journal enthält Ticketkennungen zur Wiederanlaufkontrolle; diese werden
nicht in die datensparsamen Diagnose-ZIPs übernommen.

## Rückweg

START.cmd aus dem **neuen separat entpackten ZIP** -> Menü 7.
Der Rückweg prüft die archivierte Software vor der Wiederherstellung. Neue Software
bleibt im Archiv erhalten; es werden keine Tickets oder versendeten Mails zurückgesetzt.
Bei einer unterbrochenen Installation verhindert `BETA_UMSTELLUNG_LAEUFT.txt` einen
normalen Start. Diesen Marker nicht manuell entfernen. Gegebenenfalls zuerst eine
verwaiste Laufsperre über Menü 5 prüfen, niemals einen laufenden Prozess blind beenden.

## Grenzen

Ein Versandnachweis der Anwendung ist keine externe Zustellbestätigung.
Die fiktive Demo bildet nicht jede ICEfaces-/COMARCH-Serverreaktion ab.
Ein erfolgreicher lokaler Test ersetzt den ersten echten Windows-Piloten nicht.
Bei Dateisystemen ohne verlässliches fsync ist ein absoluter Stromausfallschutz
nicht beweisbar; Hash-Rücklesen, Archiv und konservative Sperren bleiben aktiv.

## RC8 (23.10.2026) – neue feste Feldreihenfolge und automatische Vor-Aktionsfreigabe

Nach Auswahl der Dokumentenkategorie fokussiert RC8 **nur** das bereits bestätigte Member-Eingabefeld (ohne Änderung), wartet auf die Kategorieübernahme und verarbeitet erst danach die Unterkategorie. Es folgen Signatur `INTL01 - Intel Deutschland GmbH`, eindeutiger Antworteditor, kontrollierter Versand, zwei OK-Bestätigungen und Ticket speichern. Der Bot wechselt bei regulärem Lauf danach zum nächsten Ticket; Menü 3 bleibt bewusst auf ein beaufsichtigtes Pilotticket begrenzt.

Eine manuelle `SICHER_KEIN_VERSAND`-Eingabe entfällt automatisch nur, wenn die aktuelle Diagnose mit der letzten Run-ID übereinstimmt, kein Send-/Forward-Intent existiert und **kein Bot-Versand/Speichern begonnen** wurde. Sonst bleibt Menü 5 verpflichtend, um Doppelversand zu verhindern. Vollständige Details in `docs/RC8_KATEGORIE_FOKUS_UND_WIEDERANLAUF.md`.


## RC9 (23.10.2026) – realer Member-Klick nach Unterkategorie

Nach der Auswahl von `Personenschriftwechsel` klickt der Bot **nur** ins bereits ausgewählte `Member`-Textfeld (ohne Text oder Member-Zuordnung zu ändern). Er wartet auf die stabile Übernahme der Unterkategorie. Als Kompatibilitätsfallback ist der bisherige Fokuswechsel auf die Signatur weiterhin möglich; wenn beides nicht bestätigt wird, kann der Operator die Unterkategorie einmal manuell auswählen und durch den unveränderten Member-Klick bestätigen. Ohne positive Prüfung erfolgt kein Versand. Danach folgen Signatur, Antwort, zwei OK-Bestätigungen und Speichern wie zuvor. Siehe `docs/RC9_PRUEFBERICHT.md`.


## RC10: SLIM-Auslieferung ohne Archivrekursion
Die historischen `complete-0.8.1-rc.N.zip` in `tests/fixtures/` waren
ausschliesslich fuer Regressionstests der alten Upgradeversionen noetig.
Bei RC8 und RC9 verdoppelte sich die Paketgroesse wegen verschachtelter ZIPs.
Diese historischen Archive werden ab RC10 **nicht mehr mit ausgeliefert**.
Die lauffaehige Software, Testdateien, Original-Manifestreferenzen,
Installation und Rueckweg bleiben im Komplettpaket.
Menue 1 prueft alle vorgesehenen Laufzeit-, Sicherheits- und Installer-Tests
und vier simulierte Tickets; die historischen Archive-Upgrade-Tests werden
separat mit den unveraenderten Original-ZIPs qualifiziert.
Wer eigenstaendig alle historischen Upgrade-Tests ausfuehren will, kann die
urspruenglichen veroeffentlichten ZIPs im separaten QA-Ordner bereitstellen
und `MCR_TEST_FIXTURE_DIR` fuer den direkten Node-Testlauf setzen.
Keine Fremddaten in das installierte `tests/fixtures/` zurueckkopieren,
sonst greift die Integritaetssperre `UNSEALED_CODE`.

## RC11 – dialogfester Einzelversand

Nach Versand wird jeder sichtbare COMARCH-OK-Dialog nur einmal mit einem echten Browser-Mausklick bestaetigt. Derselbe noch sichtbare Dialog wird nicht erneut angeklickt. Eine dritte ausdrueckliche Erfolgsmeldung „Nachricht gesendet“ kann einmal quittiert werden, unbekannte Zusatzdialoge blockieren. Der Sendebutton wird niemals wiederholt. Bei bereits begonnenem, ungeprueftem Versand (etwa RC10 `SEND_UNEXPECTED_EXTRA_DIALOG`) zuerst COMARCH-Nachrichtenverlauf und Speicherung ueberpruefen und ueber Menue 5 dokumentieren; keine Doppelmail riskieren. Die alte Feldfolge mit Member-Fokus und die Bestandsregeln bleiben unveraendert. Details: `docs/RC11_EINMALIGER_VERSAND_UND_DIALOGE.md`.


## RC12 – Einmalige automatische Pflichtfeld-Auswahl und Pilot

- RC12 gibt die Suchworte fuer **Dokumentenkategorie**, **Unterkategorie** und **Signatur** ueber echte Chromium-Tastaturereignisse ein. Dies aktiviert ICEfaces-Autocomplete auch dann, wenn synthetische JavaScript-Ereignisse ignoriert werden. Der Bot klickt nur einen einzelnen, eindeutigen, sichtbaren und nach Hit-Test sicheren Vorschlag.
- Auswaehlbare Unterkategorie bleibt **ausschliesslich Personenschriftwechsel**. Der Fokuswechsel zur Uebernahme erfolgt durch einen Klick in das bestaetigte Member-Eingabefeld, ohne den Memberwert zu bearbeiten. Keine erneute automatische Unterkategorie-Auswahl und kein alternativer Signatur-Fokuswechsel.
- Die einmalige Freigabe `START` fuer Menue 3 gilt als Freigabe des kontrollierten Einzelpiloten; eine weitere Eingabe `SENDEN` ist nicht mehr notwendig. Der Bot prueft vor dem einen Versandklick Ticket, Member/MercerID, Empfaenger, Beschreibung, Antwort und sichtbare identische Antworten im Ticketverlauf. Der dauerhafte Sendejournal-Eintrag wird vor dem Klick gesichert.
- Jede Versandbestaetigung und jeder Speicherklick erfolgt weiterhin hoechstens einmal je erkanntem Dialog bzw. Ticket. Nur nach unabhängiger Bestaetigung von Versand und Speicherung wird ein Ticket als erledigt markiert.
- Menue **4** ist absichtlich erst nach einem realen, sauberen Menue-3-Pilot mit belegtem Versand und Speicherung fuer genau diese Software- und Mapping-Version zugaenglich. Menue 3 verarbeitet nur ein Ticket; Menue 4 verarbeitet danach die naechsten Tickets sequentiell ohne weitere SENDEN-Aufforderung.
- Bei mehrdeutigen oder nicht sichtbaren Vorschlaegen ist weiterhin kontrollierte manuelle Auswahl bzw. Stopp vorgesehen. RC12 wurde nicht gegen das produktive COMARCH auf Windows getestet.


## RC21: Windows-Tempordner-EPERM nach bestandenem Browser-Selbsttest
- Die Test-only Browserprofil-Bereinigung schliesst Edge und versucht temp-Dateien asynchron erneut.
- Eine laenger anhaltende Betriebssystem-Sperre erzeugt WARN statt eines false negative fuer den Fachtest.
- Details siehe docs/RC21_WINDOWS_BROWSER_TEST_CLEANUP.md. Produktionsbrowser und Sendelogik unveraendert.

## RC28: USC/Plan und Versandstatus getrennt dokumentieren

Wenn eine Standardantwort im aktuellen Ticket **nachweislich** versendet und das Ticket gespeichert wurde, enthält `Zusätzliche Beschreibung` sowohl alle unveränderten USC-/Planzeilen als auch die gesonderte Zeile `Standardantwort versendet`. Bei bereits beantworteten Tickets mit leerer Beschreibung wird die USC-Information vor der Statusmarkierung über den COMARCH-Member und den aktiven Bestand geprüft. Es erfolgt niemals ein zweiter Versand.

Unter `.runtime/reports/MCR_Bearbeitungsstatus_<lauf>.csv` wird nach jedem erfolgreich gespeicherten Ticket ein lokaler CSV-Bericht mit echten separaten Spalten `Ticket_ID`, `USC_Plaene` und `Standardantwort` geschrieben. Die COMARCH-Maske selbst bietet jedoch nur ein einziges Feld `Zusätzliche Beschreibung`; dort sind die Angaben getrennte **Zeilen**, keine echten zusätzlichen COMARCH-Spalten. Details: `docs/RC28_FORTSETZUNG_USC_UND_STATUS.md`.

RC28 stabilisiert außerdem die Browser-Neubindung beim automatischen Folgelauf nach einem bestätigten Piloten und versucht alternative sichtbare Positionen für den einen Speicherklick. Keine blinden Klicks, keine gelöschten Versandjournale.

## RC34 – Phase 2 (Kontoauszug) getrennt gestartet

Neu im Hauptmenue: `9` COMARCH-Inventur (nur lesen), `10` Generatoren pruefen (nur lesen), `11` beaufsichtigter PDF-Dateibeleg (Operator startet vorhandene BAT-Programme manuell). Phase-1-Funktionen sind unveraendert. Es erfolgt **kein** automatischer Kontoauszug-Generatorstart, kein COMARCH-Dateiupload, kein Eintrag `Bearbeitet not reviewed` und keine Weiterleitung an Mark Baindl. Siehe `docs/RC34_PHASE2_KONTOAUSZUG_PILOT.md`.

## RC35 – Windows-EPERM im RC34-Phase-2-Selbsttest behoben

Nur der **temporäre Testbrowser-Cleanup** wurde gehärtet. Der Fehler `EPERM` beim Entfernen eines `MCR-P2-DOM-*`-Ordners führt nach bestätigten Testassertions nicht mehr zu einem fälschlichen Fehlschlag; bei transienten Sperren wird erneut probiert, bei persistenten Sperren eindeutig gewarnt. Andere Fehler bleiben hart. Phase-1-/Phase-2-Funktionen und reale COMARCH-Aktionen bleiben unverändert. Siehe `docs/RC35_WINDOWS_EPHEMERAL_TEST_PROFILE_FIX.md`.

## RC36 – DC-PDF-Namensformate (beaufsichtigter Pilot)

Menü 11 erkennt `{WWID}_Kontoauszug_DC.pdf`, die bisherige `Intel_{WWID}_KA_DE_{Jahr}[_{Monat}]`-Schreibweise und eine gesondert als schwach klassifizierte `{Jahr}_DC_Kontoauszug_{Nachname}{VornameInitial}`-Variante. Die Namens-/Initial-Variante darf **nur mit einer zusätzlichen ausdrücklichen WWID- und Personenprüfung im geöffneten PDF** fortfahren; die automatische Anlage bleibt ausnahmslos deaktiviert. Siehe `docs/RC36_PHASE2_DC_FILENAMES_AND_IDENTITY.md`.

## RC37 – Phase 2 (vorhandene WWID-PDFs)

Menü 11 öffnet das Kontoauszug-Ticket lesend in COMARCH und nimmt vorhandene exakt benannte DC-/PP+-PDFs an, ohne sie erneut erzeugen zu lassen. Ist eine eigenständig beschriftete WWID im COMARCH-Member nicht verfügbar, benötigt die Zuordnung aus zwei übereinstimmenden Dateinamen eine abschließende manuelle Inhalts- und Berechtigungsprüfung. Keine automatische COMARCH-Aktion; Details: `docs/RC37_PHASE2_BESTEHENDE_PDFS_UND_POST_SEND.md`.


## RC39 – Phase 2: beaufsichtigter Kontoauszug-Pilot

Menü 12 ist ein separater, konservativ abgesicherter Einzelticket-Pilot für die zuvor unter Menü 11 geprüften PDFs. Er kann beide Anlagen in COMARCH einfügen, nach COMARCH-Nachweisen die vierte Beschreibungszeile ergänzen, Entwurf und Ticket speichern sowie nach **zusätzlicher ausdrücklicher Freigabe** an Baindl Mark (`mark.baindl`) zur Überprüfung weiterleiten. Keine E-Mail-Versandfunktion. Keine automatische Wiederholung von Upload, Speichern oder Weiterleiten. Bei fehlendem oder unklarem Upload-Feld erfolgt ein kontrollierter Stopp. Details und Grenzen in `docs/RC39_PHASE2_COMARCH_PILOT.md`.
