/* Produce a review-only source patch. NEVER change the installed release. */
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';

const sha256 = b => createHash('sha256').update(b).digest('hex');
const kit = path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');

export function patchRunner(original) {
  let value = original;
  const modifications = [];
  function once(label, old, replacement) {
    const count=value.split(old).length-1;
    if(count!==1)throw Error(`SOURCE_ANCHOR_${label}: erwartet 1, gefunden ${count}. Keine Vorschau erstellt.`);
    value=value.replace(old,replacement);
    modifications.push({anchor:label,count});
  }
  function exactCount(label,old,replacement,expected) {
    const count=value.split(old).length-1;
    if(count!==expected)throw Error(`SOURCE_ANCHOR_${label}: erwartet ${expected}, gefunden ${count}. Keine Vorschau erstellt.`);
    value=value.split(old).join(replacement);
    modifications.push({anchor:label,count});
  }

  once('IMPORT',
    "const QueueSend = require('../lib/queue-send.cjs');",
    "const QueueSend = require('../lib/queue-send.cjs');\nconst Identity = require('../lib/identity-evidence.cjs');");
  once('IDENTIFIER_EVIDENCE',
    'const ids=[...new Set(hints.map(h=>h.clientId))];',
    'const ids=[...new Set(hints.map(h=>h.clientId))];\n  const idProof=Identity.buildEvidence(mail,hints); // only current explicit MercerID is binding');
  exactCount('RETURN_IDENTITIES','expectedId:ids.length===1?ids[0]:null','idProof',5);
  once('SELECT_SIGNATURE',
    'async function selectMember(page, person, expectedId, rl){',
    'async function selectMember(page, person, idProof, rl){');
  once('PRESELECT_VERIFY',
    "if(expectedId&&preselected.id!==expectedId)fail('MEMBER_ID_CONFLICT','Bereits ausgewählter COMARCH-Member widerspricht dem geprüften MercerID-Hinweis aus der Mail.');",
    'Identity.requireMatched(preselected,person,idProof);');
  once('SUGGESTION_ID',
    'if(expectedId){const exact=suggestions.filter(s=>s.id===expectedId);if(exact.length===1)pick=exact[0];}',
    'if(idProof?.expectedId){const exact=suggestions.filter(s=>s.id===idProof.expectedId);if(exact.length===1)pick=exact[0];}');
  once('AFTER_SELECTION_VERIFY',
    "if(expectedId&&selected.id!==expectedId)fail('MEMBER_ID_CONFLICT','Ausgewählter COMARCH-Member widerspricht dem geprüften MercerID-Hinweis aus der Mail.');",
    'Identity.requireMatched(selected,person,idProof);');
  once('LOCAL_VARIABLES',
    'let mail=null,person=null,expectedId=null;',
    'let mail=null,person=null,idProof=null;');
  once('HISTORY_DESTRUCTURE',
    '({mail,person,expectedId}=historyChoice);diag.mail.parsed=true;',
    '({mail,person,idProof}=historyChoice);diag.mail.parsed=true;');
  once('MSG_DESTRUCTURE',
    '({person,expectedId}=await choosePerson(mail,rl));log(\'Original-MSG lokal gelesen.\');',
    '({person,idProof}=await choosePerson(mail,rl));log(\'Original-MSG lokal gelesen.\');');
  once('NAME_LOG',
    "+(expectedId?' [MercerID-Hinweis vorhanden]':'')",
    "+(idProof?.hasExplicit?' [ausdrueckliche aktuelle MercerID]':' [COMARCH-Namensabgleich]')");
  once('SELECT_CALL',
    'const selected=await selectMember(page,person,expectedId,rl);',
    "const selected=await selectMember(page,person,idProof,rl);\n  diag.member.identityEvidenceMode=idProof?.mode??'UNKNOWN';\n  log('Identitaetsnachweis PASS ('+(idProof?.mode??'UNKNOWN')+').');");
  once('DIAGNOSTIC_VERSION',
    "version:'0.7.4-TPP-QUOTED-SIGNATURE'",
    "version:'0.8.0-beta5-IDENTITY-CANDIDATE'");
  once('BANNER',
    "heading('MCR Local Runner 0.7.4 - TPP pro Zeile + zitierte Signaturen');",
    "heading('MCR Local Runner 0.8.0-beta5 Candidate - ID-Hinweise und COMARCH-Member');");

  if(value.includes('expectedId')) {
    // String may appear legitimately only as idProof.expectedId inside new code.
    const remaining=value.replace(/idProof\??\.expectedId/g,'');
    if(remaining.includes('expectedId'))throw Error('LEFTOVER_EXPECTED_ID: Nicht alle Aufrufstellen migriert.');
  }
  return {value,modifications};
}

function arg(name){const i=process.argv.indexOf(name);return i<0?null:process.argv[i+1];}
function validateOutside(source,out){
  const r=path.resolve(source),d=path.resolve(out);
  if (d===r || d.startsWith(r+path.sep) || r.startsWith(d+path.sep)) {
    throw Error('OUTPUT_INSIDE_PROJECT: Vorschau muss AUSSERHALB des Originalprojekts liegen.');
  }
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
 try {
  const root=arg('--root'),out=arg('--out');
  if(!root||!out)throw Error('AUFRUF: node tools/prepare.mjs --root "<MCR_Datenbruecke>" --out "<leerer separater Ordner>"');
  validateOutside(root,out);
  const src=path.join(root,'src','local-bot-full-run.mjs');
  if(!fs.statSync(src).isFile())throw Error('RUNNER_NOT_FOUND: Quellcode fehlt.');
  if(fs.existsSync(out))throw Error('OUTPUT_EXISTS: Zielordner existiert bereits. Wähle einen neuen, leeren Pfad.');
  const raw=fs.readFileSync(src,'utf8');
  const {value,modifications}=patchRunner(raw.replace(/^\uFEFF/,''));
  const helper=fs.readFileSync(path.join(kit,'lib','identity-evidence.cjs'));
  // No fsync or rename: previously observed managed-Windows EPERM errors.
  // A completed PATCH_REPORT.json is the commit marker.
  fs.mkdirSync(path.join(out,'src'),{recursive:true});
  fs.mkdirSync(path.join(out,'lib'),{recursive:true});
  fs.writeFileSync(path.join(out,'src','local-bot-full-run.mjs'),value,'utf8');
  fs.writeFileSync(path.join(out,'lib','identity-evidence.cjs'),helper);
  const check=spawnSync(process.execPath,['--check',path.join(out,'src','local-bot-full-run.mjs')],{encoding:'utf8'});
  if(check.status!==0)throw Error('SYNTAX_FAIL: '+(check.stderr??''));
  const manifest={schema:'MCR_IDENTITY_PATCH_PREVIEW_V1',installedCodeUnchanged:true,readyForLive:false,
    sourceSha256:sha256(Buffer.from(raw,'utf8')),candidateRunnerSha256:sha256(Buffer.from(value,'utf8')),
    helperSha256:sha256(helper),syntaxCheck:'PASS',modifications};
  fs.writeFileSync(path.join(out,'PATCH_REPORT.json'),JSON.stringify(manifest,null,2)+'\n');
  console.log('\nPREVIEW_PASS: Originalprojekt NICHT geaendert.');
  console.log('Anker-Patches: '+modifications.length+' | Syntax: PASS');
  console.log('Quellcode SHA256: '+manifest.sourceSha256);
  console.log('Vorschau-Runner SHA256: '+manifest.candidateRunnerSha256);
  console.log('Kandidaten-Ordner: '+out);
  console.log('WICHTIG: Kandidat NICHT als echtes Beta 5 starten. Beta 4 bleibt versiegelt.');
 }catch(e){console.error('STOP: '+e.message);process.exitCode=1;}
}
