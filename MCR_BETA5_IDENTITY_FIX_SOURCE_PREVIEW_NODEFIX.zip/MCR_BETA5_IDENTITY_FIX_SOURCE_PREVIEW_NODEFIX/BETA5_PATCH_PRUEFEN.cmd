@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
set "KIT=%~dp0"
set "PROJ=%USERPROFILE%\projects\Aktive_Projekte\Ticket_bot\MCR_Datenbruecke"
if not "%~1"=="" set "PROJ=%~1"
set "DEST=%KIT%candidate_preview_%RANDOM%_%RANDOM%"

echo ==============================================================
echo  MCR Beta 5 - Identity-Guard PATCH VORSCHAU - KEIN ECHTLAUF
echo ==============================================================
 echo.
echo Quelle: %PROJ%
echo Ausgabe: %DEST%
 echo.

rem Use the existing portable Node from the shared compiler before global PATH.
rem node_modules contains dependencies; the runtime binary is one level above.
set "MCR_RESOLVED_NODE="
if defined NODE_EXE if exist "%NODE_EXE%" set "MCR_RESOLVED_NODE=%NODE_EXE%"
if not defined MCR_RESOLVED_NODE if exist "%USERPROFILE%\projects\Compiler\javascript\tools\node\node.exe" set "MCR_RESOLVED_NODE=%USERPROFILE%\projects\Compiler\javascript\tools\node\node.exe"
if not defined MCR_RESOLVED_NODE for /f "delims=" %%N in ('where node.exe 2^>nul') do if not defined MCR_RESOLVED_NODE set "MCR_RESOLVED_NODE=%%N"
if not defined MCR_RESOLVED_NODE (
  echo STOP: Weder der portable Node noch node.exe im PATH gefunden.
  echo Erwartet: %USERPROFILE%\projects\Compiler\javascript\tools\node\node.exe
  echo Optional: NODE_EXE auf vorhandene node.exe setzen.
  goto :fail
)
for %%N in ("%MCR_RESOLVED_NODE%") do if /i not "%%~nxN"=="node.exe" (
  echo STOP: NODE_EXE muss auf eine Datei namens node.exe verweisen.
  goto :fail
)
echo Verwendete Node-Laufzeit: %MCR_RESOLVED_NODE%
"%MCR_RESOLVED_NODE%" --version
if errorlevel 1 goto :fail
"%MCR_RESOLVED_NODE%" -e "const [a,b]=process.versions.node.split('.').map(Number);if(a<22||(a===22&&b<15))process.exit(3)"
if errorlevel 1 (
  echo STOP: Benoetigt wird Node.js 22.15 oder neuer.
  goto :fail
)
if not exist "%PROJ%\src\local-bot-full-run.mjs" (
  echo STOP: Original-Beta-4-Runner fehlt unter %PROJ%\src\local-bot-full-run.mjs
  echo Keine Datei veraendert. Bitte Quellpfad pruefen.
  goto :fail
)
"%MCR_RESOLVED_NODE%" --test "%KIT%tests\identity-evidence.test.cjs" "%KIT%tests\patcher.test.mjs"
if errorlevel 1 goto :fail
"%MCR_RESOLVED_NODE%" "%KIT%tools\prepare.mjs" --root "%PROJ%" --out "%DEST%"
if errorlevel 1 goto :fail
echo.
echo PATCH-VORSCHAU ERFOLGREICH. Beta 4 bleibt UNVERAENDERT.
echo Beta 5 erst nach Paket-Integrationspruefung freigeben.
pause
exit /b 0
:fail
echo.
echo STOP: Keine produktive Datei veraendert. Nichts senden.
pause
exit /b 1
