# MCR Ticket Assistant – Beta 5 Identity Guard – Source Preview Kit

**Stand:** 16.10.2026. **Starter-Revision:** portable Node-Fix 1.0.1. **Nicht die produktive Beta 5.** Dieses Paket erstellt nur einen geprueften **Quellcode-Kandidaten**. Es installiert nichts, startet keinen Browser, veraendert kein Ticket, sendet keine E-Mail, speichert kein Ticket, setzt keine Sperre zurueck und schreibt **nicht** in den vorhandenen Beta-4-Ordner.

## Zweck

In 0.7.4 uebergibt `choosePerson()` die einzige aus Mailtext und Kontext extrahierte Nummer automatisch als `expectedId`, auch wenn sie lediglich ein schwacher Kontexttreffer aus dem Mailtext ist. `selectMember()` stoppt dann bei einer Abweichung mit `MEMBER_ID_CONFLICT`. Der alte Ablauf kontrolliert ausserdem bei `MEMBER_FIELD` die ausgewiesene Nummer, nicht aber in jeder Konstellation den angezeigten Namen.

Der vorgeschlagene Quellcode-Kandidat trennt deshalb **ausdruecklich erkannte MercerID in der aktuellen Mail / im Betreff** von allgemeinen Kontextkandidaten und zitiertem Alttext. Nur eine eindeutige ausdrueckliche Kennung ist ein hartes ID-Vergleichskriterium; Kontextnummern duerfen die COMARCH-Auswahl nicht automatisch ersetzen. Die **aus COMARCH abgelesene Member-ID und der Name** werden gemeinsam geprueft. Ein echter expliziter Widerspruch, zwei verschiedene explizite IDs, falscher Name oder eine nicht nachvollziehbare Member-Auswahl stoppen weiterhin.

Die Quellcodeanpassung betrifft nur `src/local-bot-full-run.mjs` und ein zusaetzliches reines `lib/identity-evidence.cjs`. Das aktive TPP-Mehrzeilen-Mapping, Reihenfolge MyTasks/INTL01, PAGE_FETCH, Ticketbeschreibung, Antworttext, Versand- und Speicherfunktionen bleiben unveraendert.

## So benutzt du das Paket

1. ZIP **ausserhalb von** `MCR_Datenbruecke` entpacken (z.B. in `Downloads\MCR_Beta5_Patchkit`).
2. Beta-4-Tool und MCR-Edge vorher beenden, um waehrend der Vorschau keine Quelle umzuschreiben.
3. `BETA5_PATCH_PRUEFEN.cmd` starten. **Der Starter findet die vorhandene portable Node-Laufzeit automatisch** unter `%USERPROFILE%\projects\Compiler\javascript\tools\node\node.exe` (nicht im Unterordner `node_modules`). Optional kann `NODE_EXE` eine andere vorhandene Node-Laufzeit angeben; erst danach wird `PATH` betrachtet. Benötigt wird Node.js 22.15 oder neuer. Standardquelle: `%USERPROFILE%\projects\Aktive_Projekte\Ticket_bot\MCR_Datenbruecke`. Ein alternativer Pfad kann als erstes CMD-Argument uebergeben werden.
4. Der Starter fuehrt die lokalen Node-Tests aus und erzeugt unter dem Patchkit einen **neuen** Ordner `candidate_preview_*` mit:
   - `src/local-bot-full-run.mjs` – gepruefter Patch-Kandidat;
   - `lib/identity-evidence.cjs` – rein lokale Evidenzregeln;
   - `PATCH_REPORT.json` – Quellhash, Kandidatenhash, Patcher-Anker und Syntaxstatus.
5. **Nicht** die Kandidatendateien in die versiegelte Beta 4 kopieren oder den Kandidaten separat live starten. Dazu fehlt noch die Beta-5-Release-Integration.

## Tests und Sicherheitsgrenzen

Es gibt 17 Node-Tests fuer starke/schwache ID-Hinweise, abweichende und mehrfache explizite Kennungen, zitierte Alttexte, Namensabgleich, Umlaute, fuehrende Nullen sowie Patch-Anker. Diese Tests pruefen die **isolierte Logik**, nicht COMARCH LIVE, nicht den Nachrichtenversand und nicht das Versiegelungs-/Wiederanlaufsystem.

**Wichtiger offener Punkt:** Ohne aktuelle Original-MSG oder datensparsame Erkennungsdiagnose ist die konkrete Ursache des Raab-Konflikts nur eine technisch gestuetzte Hypothese. Der Release darf deshalb erst nach realem, autorisiertem, beaufsichtigtem Test in einer passenden Testumgebung produktiv aktiviert werden. Echter Mailversand/Mehrfach-Queue-Lauf darf nicht zum alleinigen Ersttest des Patches werden.

## Fuer die abschliessende produktive Beta 5

Es fehlen vor allem die **Beta-4-Release-Steuerung** (`START.cmd`, `tools/`, Freigabe-/Integritaetsmanifest, zentrale Metadaten und die tatsaechlichen vorhandenen Quellcode-Dateien). Damit muss der Kandidat aufgenommen, die neue Dateiliste/Hashbindung neu erzeugt, die unveraenderte Mapping-Bindung nachgewiesen und die Wiederanlauf-Sperre korrekt weitergefuehrt werden. Nicht durch direkte Aenderung des versiegelten 0.8.0-beta.4.

Vor Austausch solcher Dateien: `private_data`, `.runtime`, `diagnostics`, MSG, Kontaktdaten und echte Bestandsdateien nicht beilegen. Ein vollstaendig authentischer End-to-End-Test mit COMARCH ist hier nicht erfolgt.

## Portable-Node-Fix 1.0.1

Der zuvor angezeigte STOP `Node.js im PATH nicht gefunden` betraf nur den CMD-Starter des Preview-Kits. Es war **kein** Fehler des produktiven Beta-4-Ticketkerns. Der neue Starter erkennt die portable `node.exe`, ohne sie zu installieren und ohne den globalen `PATH` zu verändern. Im Erfolgsfall zeigt er den **tatsächlich verwendeten** Node-Pfad und die Versionsnummer an.

Es werden nach wie vor nur Quellcode-Kandidaten **außerhalb** des installierten Projekts erzeugt. Für Beta 5 sind anschließend eine formale Integrations- und Release-Prüfung sowie ein beaufsichtigter Test nötig.
