import test from 'node:test';
import assert from 'node:assert/strict';
import {patchRunner} from '../tools/prepare.mjs';
const fixture = `version:'0.7.4-TPP-QUOTED-SIGNATURE';
const QueueSend = require('../lib/queue-send.cjs');
const ids=[...new Set(hints.map(h=>h.clientId))];
return {person:c,expectedId:ids.length===1?ids[0]:null};
return {person:candidates[0],expectedId:ids.length===1?ids[0]:null};
return {person:scored[0].c,expectedId:ids.length===1?ids[0]:null};
return {person:scored[0].c,expectedId:ids.length===1?ids[0]:null};
return {person:scored[n-1].c,expectedId:ids.length===1?ids[0]:null};
async function selectMember(page, person, expectedId, rl){
if(expectedId&&preselected.id!==expectedId)fail('MEMBER_ID_CONFLICT','Bereits ausgewählter COMARCH-Member widerspricht dem geprüften MercerID-Hinweis aus der Mail.');
if(expectedId){const exact=suggestions.filter(s=>s.id===expectedId);if(exact.length===1)pick=exact[0];}
if(expectedId&&selected.id!==expectedId)fail('MEMBER_ID_CONFLICT','Ausgewählter COMARCH-Member widerspricht dem geprüften MercerID-Hinweis aus der Mail.');
let mail=null,person=null,expectedId=null;
({mail,person,expectedId}=historyChoice);diag.mail.parsed=true;
({person,expectedId}=await choosePerson(mail,rl));log('Original-MSG lokal gelesen.');
+(expectedId?' [MercerID-Hinweis vorhanden]':'')
const selected=await selectMember(page,person,expectedId,rl);
heading('MCR Local Runner 0.7.4 - TPP pro Zeile + zitierte Signaturen');`;
test('all expected anchors produce preview without original changes',()=>{
 const original=fixture;
 const p=patchRunner(fixture);
 assert.equal(p.modifications.length,14);
 assert.ok(p.value.includes('Identity.requireMatched'));
 assert.ok(p.value.includes('identity-evidence.cjs'));
 assert.ok(p.value.includes("version:'0.8.0-beta5-IDENTITY-CANDIDATE'"));
 assert.equal(fixture,original);
});
test('source changes are rejected rather than silently patched',()=>{
 assert.throws(()=>patchRunner('different application'),/SOURCE_ANCHOR/);
});
test('double patching fails closed',()=>{
 const patched=patchRunner(fixture).value;
 assert.throws(()=>patchRunner(patched),/SOURCE_ANCHOR/);
});
