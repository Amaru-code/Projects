'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const P = require('../lib/identity-evidence.cjs');
const person = {firstName:'Wolfgang',lastName:'Raab'};
const selected = {id:'11369422',display:'Raab Wolfgang (INTL01-11369422) - 1959-03-31',source:'MEMBER_FIELD'};
const mail = (subject, body) => ({subject,body});

test('explicit current MercerID matches selected person and passes', () => {
 const proof=P.buildEvidence(mail('Anliegen MercerID: 11369422','Viele Gruesse\nWolfgang Raab'),[]);
 assert.equal(proof.expectedId,'11369422');
 assert.equal(proof.mode,'CURRENT_EXPLICIT_ID');
 assert.equal(P.requireMatched(selected,person,proof),true);
});
test('wrong weak contextual number never becomes mandatory MercerID',()=>{
 const proof=P.buildEvidence(mail('Anliegen Wolfgang Raab 98765432','Mit freundlichen Gruessen\nWolfgang Raab'),[{clientId:'98765432',strength:'CONTEXTUAL'}]);
 assert.equal(proof.expectedId,null);
 assert.equal(proof.mode,'NAME_AND_COMARCH_ONLY');
 assert.equal(P.requireMatched(selected,person,proof),true);
});
test('explicit wrong current ID blocks',()=>{
 const proof=P.buildEvidence(mail('MercerID: 99999999','Wolfgang Raab'));
 assert.throws(()=>P.requireMatched(selected,person,proof),{code:'MEMBER_ID_CONFLICT'});
});
test('two distinct current explicit IDs block even if one matches',()=>{
 assert.throws(()=>P.buildEvidence(mail('INTL01-11369422','ClientEEID: 99999999')),{code:'MAIL_ID_AMBIGUOUS'});
});
test('repeated same ID is not ambiguous',()=>{
 const p=P.buildEvidence(mail('MercerID: 11369422','INTL01-11369422'));
 assert.equal(p.expectedId,'11369422');
});
test('different quoted ID after reply separator is not binding',()=>{
 const p=P.buildEvidence(mail('Re: Anliegen','Neue Nachricht\nVielen Dank\nOn Friday 12 September wrote:\nMercerID: 99999999'));
 assert.equal(p.expectedId,null);
});
test('greater-than quotation is not binding',()=>{
 const p=P.buildEvidence(mail('Re:','Neue Nachricht\n> INTL01-99999999'));
 assert.equal(p.expectedId,null);
});
test('current explicit ID takes precedence over unrelated quoted ID',()=>{
 const p=P.buildEvidence(mail('MercerID: 11369422','Neue Nachricht\n-----Original Message-----\nMercerID: 99999999'));
 assert.equal(P.requireMatched(selected,person,p),true);
});
test('generic employee number is advisory, not a MercerID',()=>{
 const p=P.buildEvidence(mail('Employee ID: 98765432','Wolfgang Raab'));
 assert.equal(p.expectedId,null);
});
test('wrong name blocks even when explicit ID matches',()=>{
 const p=P.buildEvidence(mail('MercerID: 11369422','Wolfgang Raab'));
 assert.throws(()=>P.requireMatched({...selected,display:'Mueller Peter (INTL01-11369422)'},person,p),{code:'MEMBER_NAME_MISMATCH'});
});
test('member field containing ONLY ID cannot pass without profile names',()=>{
 assert.throws(()=>P.requireMatched({...selected,display:'INTL01-11369422'},person,null),{code:'MEMBER_NAME_MISMATCH'});
});
test('profile source requires both exact names',()=>{
 const s={id:'11369422',display:'Raab Wolfgang',source:'PROFILE_ROWS',firstName:'Wolfgang',lastName:'Raab'};
 assert.equal(P.requireMatched(s,person,null),true);
 assert.throws(()=>P.requireMatched({...s,lastName:'Braun'},person,null),{code:'MEMBER_NAME_MISMATCH'});
});
test('German umlaut/transcription normalized only for name comparison',()=>{
 assert.equal(P.memberNameMatches({id:'11369422',display:'Zoeger Angela (INTL01-11369422)',source:'MEMBER_FIELD'},{firstName:'Angela',lastName:'Zöger'}),true);
});
test('leading zeros in different ID never silently removed',()=>{
 assert.throws(()=>P.requireMatched({...selected,id:'011369422'},person,P.buildEvidence(mail('INTL01-11369422','body'))),{code:'MEMBER_ID_CONFLICT'});
});
