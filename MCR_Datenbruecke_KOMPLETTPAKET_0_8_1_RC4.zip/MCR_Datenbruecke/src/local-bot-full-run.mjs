/** Consolidated runner: supplied COMARCH workflow + Identity Guard + guarded
 * trusted send/save, durable no-retry ledger and explicit bounded completion.
 * No old downloads or source patches are required at runtime. */
import os from 'node:os';import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import readline from 'node:readline/promises';
import {findEdgeExecutable,launchBrowser,connectBrowser,attachPage,sleep} from '../lib/cdp.mjs';
import {sha256,requireThat as need} from '../lib/core.mjs';import {loadActiveMapping} from '../lib/active-mapping.mjs';import {makeMultirowMapping,lookupMultirow} from '../lib/multirow-tpp-mapping.mjs';
import {resolveConfig} from '../lib/config.mjs';import {VERSION,readJSON,writeJSON,stamp,verifySession,ledger,assertNoReview,plainPath} from '../lib/control.mjs';
import {writeZip} from '../lib/zip.mjs';import {trustedAction} from '../lib/browser-actions.mjs';import * as UI from '../lib/browser-workflow.mjs';import {injectDemo} from '../lib/demo.mjs';
import {resolveMemberMapping,NOT_FOUND_DESCRIPTION} from '../lib/member-mapping.mjs';import {selectAssignee,forwardOnce,ASSIGNEE_DISPLAY} from '../lib/forwarding.mjs';
import Core from '../lib/data-core.cjs';import Person from '../lib/person-quoted.cjs';import Identity from '../lib/identity-evidence.cjs';import Prep from '../lib/ticket-prep.cjs';import Queue from '../lib/queue-send.cjs';import Msg from '../lib/msg.cjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),args=new Set(process.argv.slice(2)),DEMO=args.has('--demo'),PILOT=args.has('--pilot');
const MAX=DEMO?3:PILOT?1:Number(process.env.MCR_MAX_TICKETS||100),DEMO_SCENARIO=process.env.MCR_DEMO_SCENARIO||'normal',log=s=>console.log(s),clean=UI.clean;
const diag={schema:'MCR_LOCAL_RUNNER_DIAGNOSTIC_V2',version:VERSION,mode:DEMO?'DEMO':'REAL',createdAt:new Date().toISOString(),runId:process.env.MCR_RUN_ID||stamp(),lastError:null,mapping:{loaded:false},browser:{launched:false},send:{clicked:false,verified:false},save:{clicked:false,verified:false},loop:{processed:0,myTasksProcessed:0,queueProcessed:0,forwarded:0,completed:false,finishReason:null,processedTickets:[]},privacy:'No names, IDs, email addresses, mail text, mapping values, paths, URLs or browser profile content.'};
const fail=(c,m)=>need(false,c,m);
async function ask(rl,text){return clean(await rl.question(text));}
async function choosePerson(mail,rl){
 const current=Identity.currentBodyPart(mail.body),currentCandidates=Person.candidates({...mail,body:current});let cs=currentCandidates,quotedOnly=false;
 if(!cs.length){cs=Person.candidates(mail);quotedOnly=true;}need(cs.length,'NAME_NONE','Kein ausreichend sicherer Namenshinweis. Kein Versand.');
 const hints=Person.identifierHints(mail,Core.analyzeMail((mail.subject?'Betreff: '+mail.subject+'\n':'')+mail.body).idHints,cs),evidence=Identity.buildEvidence(mail,hints);let person;
 if(cs.length===1)person=cs[0];else{
  const subject=Person.norm(mail.subject),scored=cs.map(c=>({c,score:(subject.includes(Person.norm(c.firstName+' '+c.lastName))||subject.includes(Person.norm(c.lastName+' '+c.firstName))?7:0)+(c.sources.includes('Adressblock')?5:0)+(c.sources.includes('Beschrifteter Name')?5:0)+(c.sources.includes('Signatur')?3:0)})).sort((a,b)=>b.score-a.score);
  if(!quotedOnly&&!scored[0].c.quotedOnly&&scored[0].score>=7&&scored[0].score-(scored[1]?.score||0)>=3)person=scored[0].c;
  else{need(!DEMO,'DEMO_PERSON_AMBIGUOUS','Fiktive Person nicht eindeutig.');log('Mehrere Namenshinweise:');cs.forEach((c,i)=>log(`${i+1}: ${c.name}`));const n=Number(await ask(rl,'Nummer der betroffenen Person: '));need(Number.isInteger(n)&&n>=1&&n<=cs.length,'NAME_CHOICE','Ungueltige Personenauswahl.');person=cs[n-1];}
 }
 if((quotedOnly||person.quotedOnly)&&!DEMO)need(/^ja$/i.test(await ask(rl,'Name nur in aelterer/zitierter Korrespondenz. Zugehoerigkeit geprueft? JA: ')),'QUOTED_NAME_REVIEW','Zitierte Person nicht bestaetigt.');
 Person.query(person.firstName,person.lastName);return {person,evidence};
}
async function downloadMail(page,cfg,rl){
 const folder=path.join(cfg.downloadDirectory,stamp());fs.mkdirSync(folder,{recursive:true});await page.cdp.send('Browser.setDownloadBehavior',{behavior:'allow',downloadPath:folder},null);
 const links=await page.call(function(){const a=[];for(const row of document.querySelectorAll('tr.iceDatTblRow')){const n=row.querySelector('a[href*="GetFile?docId="]');if(!n||!row.getClientRects().length)continue;try{const u=new URL(n.getAttribute('href'),document.baseURI);if(u.origin===location.origin&&/\/DMSWWW\/GetFile$/i.test(u.pathname)&&/^\d{1,15}$/.test(u.searchParams.get('docId')||''))a.push(u.href);}catch{}}return a.reverse();});
 for(const url of links){const r=await page.call(async function(url){try{const r=await fetch(url,{credentials:'include',cache:'no-store',redirect:'error',signal:AbortSignal.timeout(20000)});if(!r.ok)return null;const bytes=new Uint8Array(await r.arrayBuffer());if(bytes.length<512||bytes.length>33554432)return null;let s='';for(let i=0;i<bytes.length;i+=32768)s+=String.fromCharCode(...bytes.subarray(i,i+32768));return btoa(s);}catch{return null;}},url);if(r){try{const bytes=Buffer.from(r,'base64'),mail=Msg.parseMsg(bytes);fs.writeFileSync(path.join(folder,'ticket.msg'),bytes,{flag:'wx',mode:0o600});return mail;}catch{}}}
 need(!DEMO,'DEMO_MAIL_MISSING','Fiktive Mail fehlt.');log('MSG-Download automatisch nicht bestaetigt. Im Bot-Browser die aktuelle Original-Mail herunterladen.');await ask(rl,'Nach dem Download ENTER: ');
 const files=fs.readdirSync(folder).filter(n=>/\.msg$/i.test(n));need(files.length===1,'MAIL_DOWNLOAD','Genau eine neue MSG im separaten Downloadordner erforderlich.');return Msg.parseMsg(fs.readFileSync(path.join(folder,files[0])));
}
async function mailAndPerson(page,cfg,rl){const s=await UI.historyMailSnapshots(page);if(s.ok){for(const row of s.rows){const mail={subject:row.subject,senderName:'',senderEmail:row.sender,body:row.content};if(Person.candidates(mail).length){diag.mailSource='HISTORY_DOM';return {mail,...await choosePerson(mail,rl)};}}}const mail=await downloadMail(page,cfg,rl);diag.mailSource='MSG_DOWNLOAD';return {mail,...await choosePerson(mail,rl)};}
async function selectMember(page,person,evidence,rl){let s=await UI.selectedMember(page,person);if(s){Identity.requireMatched(s,person,evidence);return s;}
 const id='mainForm:member-value-id';need(await UI.setInputQuery(page,id,Queue.memberSearchQuery(person.firstName,person.lastName)),'MEMBER_FIELD','Member-Feld nicht bearbeitbar.');let suggestions=[];
 for(let i=0;i<45;i++){await sleep(180);suggestions=await UI.suggestionPoints(page,id,[person.lastName+' '+person.firstName,person.firstName+' '+person.lastName],{member:true});if(suggestions.length)break;}
 let pick=null;if(evidence.expectedId){const xs=suggestions.filter(s=>s.id===evidence.expectedId);if(xs.length===1)pick=xs[0];}if(!pick&&suggestions.length===1)pick=suggestions[0];
 if(pick)await page.mouseClick(pick.x,pick.y);else{need(!DEMO,'DEMO_MEMBER_AMBIGUOUS','Demo-Member nicht eindeutig.');await ask(rl,'Richtigen Member im Bot-Browser auswaehlen; dann ENTER: ');}
 for(let i=0;i<150;i++){s=await UI.selectedMember(page,person);if(s)break;await sleep(200);}need(s,'MEMBER_COMMIT','COMARCH hat keine eindeutige Member/MercerID-Zuordnung bestaetigt.');Identity.requireMatched(s,person,evidence);return s;
}
async function fixedFields(page,rl){
 const r=await page.call(function(text){const s=document.getElementById('mainForm:responsibility-value-id');if(!s||s.tagName!=='SELECT'||s.disabled)return false;const o=Array.from(s.options).filter(x=>String(x.textContent).trim()===text);if(o.length!==1)return false;Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype,'value').set.call(s,o[0].value);s.dispatchEvent(new Event('input',{bubbles:true}));s.dispatchEvent(new Event('change',{bubbles:true}));return s.selectedOptions[0]?.textContent.trim()===text;},Prep.FIXED.responsibility);need(r,'RESPONSIBILITY','Second Level konnte nicht gesetzt werden.');
 for(const [id,value] of [['mainForm:category-value-id',Prep.FIXED.category],['mainForm:category-sub-value-id',Prep.FIXED.subcategory],['mainForm:signature-value-id',Prep.FIXED.signature]]){
  if(id.includes('category-sub')){await trustedAction(page,{id:'mainForm:member-value-id'});await sleep(700);}
  let ok=false;const end=Date.now()+10000;while(Date.now()<end){ok=await page.call(id=>{const f=document.getElementById(id);return f&&!f.disabled&&!f.readOnly&&f.getClientRects().length>0;},id);if(ok)break;await sleep(200);}need(ok,'FIXED_FIELD','Abhaengiges Feld nicht bearbeitbar.');
  need(await UI.setInputQuery(page,id,value),'FIXED_FIELD','Feld konnte nicht gesetzt werden.');let xs=[];for(let i=0;i<35;i++){await sleep(180);xs=await UI.suggestionPoints(page,id,[value]);if(xs.length)break;}
  if(xs.length===1){await page.mouseClick(xs[0].x,xs[0].y);await sleep(800);}else{need(!DEMO,'DEMO_FIXED_FIELD','Demo-Auswahl unklar.');await ask(rl,'Bitte exakt "'+value+'" auswaehlen, dann ENTER: ');}
  need(await page.call((id,value)=>String(document.getElementById(id)?.value||'').trim()===value,id,value),'FIXED_VERIFY','Feldwert nicht bestaetigt.');
 }
}
async function sendOnce(page,rl,id,journal){
 const before=await UI.historyCount(page),ed=await UI.editor(page);need(Number.isInteger(before)&&before>=1&&ed.ok&&!ed.empty,'SEND_PRECONDITION','Nachrichtenverlauf/Antworteditor nicht eindeutig.');diag.send={clicked:false,verified:false,historyBefore:before,historyAfter:null,htmlDialogs:0,jsDialogs:0};let window=true,error=null;
 const off=page.cdp.on('Page.javascriptDialogOpening',(p,s)=>{if(!window||s!==page.sessionId)return;if(!['alert','confirm'].includes(p.type)){error='UNEXPECTED_JS_DIALOG';return;}diag.send.jsDialogs++;page.cdp.send('Page.handleJavaScriptDialog',{accept:true},s).catch(()=>{error='DIALOG_FAILED';});});
 try{await UI.assertTicket(page,id);await trustedAction(page,{id:'mainForm:send-new-message-button'},()=>{diag.send.clicked=true;});const end=Date.now()+45000;let stable=0,reset=0;
  while(Date.now()<end){need(!error,error||'DIALOG_FAILED','Unerwarteter Versanddialog. Nicht erneut senden.');const d=await UI.htmlOk(page);need(d!=='UNKNOWN','UNEXPECTED_DIALOG','Unbekannter Versanddialog. Nicht erneut senden.');if(d==='OK'){diag.send.htmlDialogs++;await sleep(350);continue;}const n=await UI.historyCount(page);need(n===null||n<=before+1,'SEND_MULTIPLE_HISTORY_ROWS','Mehr als ein neuer Verlaufseintrag. Manuell pruefen.');
   if(n===before+1){if(!stable)stable=Date.now();if(Date.now()-stable>=900){diag.send.historyAfter=n;diag.send.verified=true;diag.send.ackMode='HISTORY_INCREMENT';journal?.set(id,'SENT_CONFIRMED');return;}}else stable=0;
   const e=await UI.editor(page);if(!DEMO&&e.ok&&e.empty&&diag.send.jsDialogs+diag.send.htmlDialogs>=1){if(!reset)reset=Date.now();if(Date.now()-reset>=1500){diag.send.historyAfter=n;diag.send.verified=true;diag.send.ackMode='EDITOR_RESET_AFTER_CONFIRMED_DIALOGS';journal?.set(id,'SENT_CONFIRMED');return;}}else reset=0;await sleep(250);
  }fail('SEND_UNVERIFIED','Versand nicht bestaetigt. Kein erneuter Klick; Wiederanlauf bleibt gesperrt.');
 }finally{window=false;off();}
}
async function saveOnce(page,id,journal,{forwardOnly=false}={}){diag.save={clicked:false,verified:false};let window=true,error=null;const off=page.cdp.on('Page.javascriptDialogOpening',(p,s)=>{if(!window||s!==page.sessionId)return;if(!['alert','confirm'].includes(p.type)){error='UNEXPECTED_SAVE_DIALOG';return;}page.cdp.send('Page.handleJavaScriptDialog',{accept:true},s).catch(()=>{error='SAVE_DIALOG_FAILED';});});
 try{await UI.assertTicket(page,id);await trustedAction(page,{text:'Ticket speichern'},()=>{if(forwardOnly)journal?.forwardSet(id,'ROUTE_SAVE_INTENT');else journal?.set(id,'SAVE_INTENT');diag.save.clicked=true;});log('Ticket speichern: ein gepruefter Browser-Mausklick ausgefuehrt.');const end=Date.now()+12000;let quiet=0;while(Date.now()<end){need(!error,error||'SAVE_DIALOG_FAILED','Speicherdialog unklar.');const d=await UI.htmlOk(page);need(d!=='UNKNOWN','UNEXPECTED_SAVE_DIALOG','Speicherdialog unklar.');if(d==='OK'){quiet=0;await sleep(350);continue;}if(!quiet)quiet=Date.now();if(Date.now()-quiet>1800)return;await sleep(200);}}
 finally{window=false;off();}
}
async function verifySaved(page,id,description){for(const scope of ['IN_BEARBEITUNG','WARTESCHLANGE_INTL01']){let snap=await UI.navigateToScope(page,scope),row=snap.rows.find(r=>r.ticketId===id);if(!row)continue;const end=Date.now()+(DEMO?1200:10000);while(Date.now()<end){if(!row.descriptionBlank&&clean(row.descriptionValue)===clean(description)){diag.save.verified=true;diag.save.verification=scope==='IN_BEARBEITUNG'?'MY_TASKS_ALL_DESCRIPTION_CONTENT_MATCH':'QUEUE_ALL_DESCRIPTION_CONTENT_MATCH';await UI.navigateToScope(page,'IN_BEARBEITUNG');return;}await sleep(250);snap=await UI.queueTableSnapshot(page);row=snap.rows.find(r=>r.ticketId===id);if(!row)break;}}
 fail('SAVE_UNVERIFIED','Vollstaendige Beschreibung nach Speichern nicht nachgewiesen. Nicht erneut senden.');}

/** No reply text, no recipient, no send button for unmatched identities.
 * Save the exact note and fixed fields FIRST and verify persistence. Only then
 * select the top-level assignee and trigger the one-way forward action.
 */
async function forwardMissingPerson(page,rl,row,scope,journal,person,evidence,member){
 log('BESTAND_NOT_FOUND_EXACT_AND_PREFIX11 - Keine E-Mail, kein Versand.');
 let w=await UI.writeDescription(page,NOT_FOUND_DESCRIPTION);
 need(w.ok,'DESCRIPTION_WRITE','Manueller Klaerungstext nicht eindeutig einsetzbar: '+w.state);
 await sleep(650);need(await UI.verifyDescription(page,NOT_FOUND_DESCRIPTION),'DESCRIPTION_VERIFY','Manueller Klaerungstext nicht nachweisbar.');
 await fixedFields(page,rl);need(await UI.verifyDescription(page,NOT_FOUND_DESCRIPTION),'DESCRIPTION_CHANGED','Beschreibung nach Kategorieauswahl veraendert.');
 const recheck=await UI.selectedMember(page,person);Identity.requireMatched(recheck,person,evidence);need(recheck.id===member.id,'MEMBER_CHANGED','Member vor Weiterleitung veraendert.');
 if(PILOT&&!DEMO){
  log('PILOT OHNE E-MAIL: '+row.ticketId+' | Weiterleitung an '+ASSIGNEE_DISPLAY+'.');
  log('Zusatzbeschreibung: '+NOT_FOUND_DESCRIPTION+' | Zust.: Second Level | Kategorie: Allgemeine Schriftwechsel | Unterkategorie: Personenschriftwechsel.');
  need((await ask(rl,'Angaben geprueft und Weiterleitung statt E-Mail freigeben? WEITERLEITEN: ')).toUpperCase()==='WEITERLEITEN','ROUTE_NOT_ARMED','Weiterleitung nicht freigegeben. Kein Versand.');
 }
 if(!DEMO){need(loadActiveMapping(root).fileHash===diag.mapping.fileHash,'MAPPING_CHANGED','Aktives Mapping veraendert.');journal.beginForward(row.ticketId,NOT_FOUND_DESCRIPTION);}
 await saveOnce(page,row.ticketId,journal,{forwardOnly:true});await verifySaved(page,row.ticketId,NOT_FOUND_DESCRIPTION);
 journal?.forwardSet(row.ticketId,'ROUTE_SAVED_VERIFIED');
 // Re-open the same verified ticket without selecting an unrelated row.
 let current=null;
 for(const s of [scope,scope==='IN_BEARBEITUNG'?'WARTESCHLANGE_INTL01':'IN_BEARBEITUNG']){
  const snap=await UI.navigateToScope(page,s);current=snap.rows.find(r=>r.ticketId===row.ticketId);
  if(current)break;
 }
 need(current,'ROUTE_TICKET_NOT_VISIBLE','Beschreibung gespeichert, Ticket vor Weiterleitung nicht erneut auffindbar. Kein blinder Klick.');
 await UI.openTicket(page,current);await UI.ensureEdit(page);await UI.assertTicket(page,row.ticketId);
 need(await UI.verifyDescription(page,NOT_FOUND_DESCRIPTION),'ROUTE_DESCRIPTION_NOT_PERSISTED','Gespeicherte Beschreibung vor Weiterleitung nicht nachgewiesen.');
 const fixed=await UI.fixedFieldValues(page);
 need(fixed.responsibility===Prep.FIXED.responsibility&&fixed.category===Prep.FIXED.category&&fixed.subcategory===Prep.FIXED.subcategory&&fixed.signature===Prep.FIXED.signature,'ROUTE_FIXED_FIELDS_NOT_SAVED','Zustaendigkeit/Kategorien/Signatur nach Speichern nicht vollstaendig. Keine Weiterleitung.');
 await selectAssignee(page);
 const finalFixed=await UI.fixedFieldValues(page);
 need(finalFixed.responsibility===Prep.FIXED.responsibility&&finalFixed.category===Prep.FIXED.category&&finalFixed.subcategory===Prep.FIXED.subcategory&&finalFixed.signature===Prep.FIXED.signature,'ROUTE_FIXED_FIELDS_CHANGED','Pflichtfelder nach Bearbeiterauswahl veraendert; keine Weiterleitung.');
 const proof=await forwardOnce(page,{
  beforeClick:()=>journal?.forwardSet(row.ticketId,'FORWARD_INTENT'),
  confirmManually:DEMO?null:async()=>{
   log('Weiterleitung wurde genau einmal angeklickt, aber COMARCH hat keinen auswertbaren Erfolgsnachweis gezeigt.');
   log('Bitte in COMARCH sicherstellen: Ticket ist Gutierrez Victor zugewiesen und Beschreibung gespeichert. KEINEN zweiten Weiterleitungsklick ausloesen.');
   return (await ask(rl,'Nach eigener Pruefung WEITERGELEITET bestaetigen, sonst ENTER: ')).toUpperCase()==='WEITERGELEITET';
  }
 });
 journal?.forwardSet(row.ticketId,'ROUTED_CONFIRMED');
 diag.forward={verified:true,method:proof.source,noEmail:true,descriptionVerified:true,fixedFieldsVerified:true};
 diag.loop.processed++;diag.loop.forwarded++;
 if(scope==='IN_BEARBEITUNG')diag.loop.myTasksProcessed++;else diag.loop.queueProcessed++;
 diag.loop.processedTickets.push({source:scope,type:'FORWARDED_WITHOUT_EMAIL',route:proof.source,save:diag.save.verification,lookup:'NOT_FOUND_EXACT_AND_PREFIX11',fixedFieldsVerified:true});
 log('PASS PERSON_NOT_FOUND_FORWARDED - ohne E-Mail an '+ASSIGNEE_DISPLAY+'.');
 await UI.navigateToScope(page,'IN_BEARBEITUNG');
}
async function processTicket(page,mapping,rl,row,scope,cfg,journal){await UI.ensureEdit(page);await UI.assertTicket(page,row.ticketId);const {person,evidence}=await mailAndPerson(page,cfg,rl),member=await selectMember(page,person,evidence,rl);log('Identitaetsnachweis PASS ('+evidence.mode+').');
 const resolved=resolveMemberMapping(mapping.map,member.id);
 diag.lookup={status:resolved.kind,method:resolved.method,sourceRowCount:resolved.entry?.rowCount??0,descriptionLineCount:resolved.entry?.descriptionLines.length??0,genderStatus:resolved.entry?.genderStatus??null};
 if(resolved.kind==='NOT_FOUND'){await forwardMissingPerson(page,rl,row,scope,journal,person,evidence,member);return;}
 if(resolved.method==='PREFIX_11_REMOVED')log('PASS PREFIX11_FALLBACK_MATCH - COMARCH-ID unveraendert; nur Bestands-Lookup mit gekuerzter Kennung.');
 const entry=resolved.entry;
 if(entry.hasCachedFormulas&&!DEMO)need(/^ja$/i.test(await ask(rl,'Aktualitaet der gespeicherten Formelwerte aller Bestandszeilen geprueft? JA: ')),'FORMULA_REVIEW_REQUIRED','Formelcache nicht freigegeben.');
 log('Bestandsabgleich: '+entry.rowCount+' Quellzeile(n), eine Antwort pro Ticket.');const w=await UI.writeDescription(page,entry.description);need(w.ok,'DESCRIPTION_WRITE','Beschreibung nicht eindeutig einsetzbar: '+w.state);await sleep(700);need(await UI.verifyDescription(page,entry.description),'DESCRIPTION_VERIFY','Beschreibung nach Seitenreaktion abweichend.');await fixedFields(page,rl);
 let sal=entry.gender==='M'?'Herr':entry.gender==='F'?'Frau':null;if(!sal){need(!DEMO,'DEMO_GENDER','Fiktive Anrede fehlt.');const a=(await ask(rl,'Anrede aus Bestand nicht eindeutig. Geprueft: H=Herr / F=Frau: ')).toUpperCase();need(['H','F'].includes(a),'SALUTATION_REQUIRED','Anrede nicht freigegeben.');sal=a==='H'?'Herr':'Frau';}
 const reply=Prep.replyText(sal,person.lastName);need((await UI.editor(page,reply)).ok,'REPLY_WRITE','Antworteditor unklar/abweichend befuellt.');await sleep(500);const dest=await UI.recipient(page);need(dest.ok,'RECIPIENT','Genau ein Empfaenger im Feld An erforderlich.');
 if(PILOT&&!DEMO){log('\nPILOT: '+row.ticketId+' | '+person.firstName+' '+person.lastName+' | An: '+dest.address);log(entry.description);log(reply);need(/^senden$/i.test(await ask(rl,'Identitaet, Empfaenger, Text und Verlauf auf bereits versendete Antwort geprueft? SENDEN: ')),'PILOT_NOT_ARMED','Kein Versand freigegeben.');}
 await UI.assertTicket(page,row.ticketId);const finalMember=await UI.selectedMember(page,person);Identity.requireMatched(finalMember,person,evidence);need(finalMember.id===member.id,'MEMBER_CHANGED','Member vor Versand geaendert.');need((await UI.recipient(page)).address===dest.address,'RECIPIENT_CHANGED','Empfaenger geaendert.');need(await UI.verifyDescription(page,entry.description),'DESCRIPTION_CHANGED','Beschreibung vor Versand geaendert.');const ed=await UI.editor(page);need(ed.ok&&Prep.sameText(ed.text,reply),'REPLY_CHANGED','Antwort vor Versand geaendert.');
 if(!DEMO){need(loadActiveMapping(root).fileHash===mapping.fileHash,'MAPPING_CHANGED','Aktives Mapping im Lauf geaendert.');journal.begin(row.ticketId,entry.description);}
 await sendOnce(page,rl,row.ticketId,journal);log('Versandnachweis PASS ('+diag.send.ackMode+').');await saveOnce(page,row.ticketId,journal);await verifySaved(page,row.ticketId,entry.description);journal?.set(row.ticketId,'COMPLETE');log('Ticket speichern PASS ('+diag.save.verification+').');
 diag.loop.processed++;if(scope==='IN_BEARBEITUNG')diag.loop.myTasksProcessed++;else diag.loop.queueProcessed++;diag.loop.processedTickets.push({source:scope,sendAck:diag.send.ackMode,save:diag.save.verification,sourceRowCount:entry.rowCount,descriptionLineCount:entry.descriptionLines.length,lookupMethod:resolved.method});
}
async function diagnostic(cfg){fs.mkdirSync(cfg.diagnosticDirectory,{recursive:true});plainPath(cfg.diagnosticDirectory);const raw=JSON.stringify(diag,null,2)+'\n',manifest=JSON.stringify({schema:'MCR_DIAGNOSTIC_MANIFEST_V1',payload:[{path:'diagnostic.json',sha256:sha256(raw)}]},null,2)+'\n';const file=path.join(cfg.diagnosticDirectory,'MCR_LOCAL_RUNNER_'+stamp()+'_UPLOAD.zip');const bytes=writeZip([{name:'diagnostic.json',data:raw},{name:'manifest.json',data:manifest}]);fs.writeFileSync(file,bytes,{flag:'wx'});writeJSON(path.join(cfg.diagnosticDirectory,'last-result.json'),diag);log('Diagnose: '+file);log('Diagnose-ZIP-SHA256: '+sha256(bytes));}
async function main(){let cfg=null,browser=null,cdp=null,rl=null;try{
 log('\n==============================================================\n MCR DATENBRUECKE '+VERSION+' | '+(DEMO?'FIKTIVE DEMO - KEIN ECHTVERSAND':PILOT?'BEAUFSICHTIGTER EINZELTICKET-PILOT':'ECHTER TICKETLAUF')+'\n==============================================================');need(Number.isInteger(MAX)&&MAX>=1&&MAX<=100,'TICKET_LIMIT','Limit muss 1 bis 100 sein.');cfg=resolveConfig(root);if(DEMO){const sandbox=fs.mkdtempSync(path.join(os.tmpdir(),'MCR-Fiktiv-Profil-'));cfg.runtimeDirectory=sandbox;cfg.profileDirectory=path.join(sandbox,'edge-profile');cfg.downloadDirectory=path.join(sandbox,'downloads');}let mapping,journal=null;
 if(DEMO){const f=readJSON(path.join(root,'examples/DEMO_mapping.json'),65536);need(f.schema==='MCR_FICTIONAL_SOURCE_V1'&&f.rows.length===2&&f.rows.every(r=>r.B==='99900001'),'DEMO_SOURCE','Fiktive Quelle fehlt.');const map=makeMultirowMapping({meta:f.source,allRows:()=>f.rows},{mode:'DEMO',headerConfirmed:true,generatedAt:'2026-01-01T00:00:00.000Z'});need(lookupMultirow(map,'99900001').description===f.expectedDescription,'DEMO_SEMANTICS','Fiktive Beschreibung abweichend.');mapping={map,fileHash:map.payloadSha256};diag.demoExpectedDescriptionSha256=sha256(f.expectedDescription);}
 else{verifySession(root,process.env.MCR_SESSION_TOKEN);mapping=loadActiveMapping(root);journal=ledger(root);journal.assertClear();}
 diag.mapping={loaded:true,multirow:true,explicitActive:!DEMO,fileHash:mapping.fileHash};log('Aktives Mapping geprueft. Mehrzeilen/TPP-Regeln bleiben erhalten.');fs.mkdirSync(cfg.runtimeDirectory,{recursive:true});fs.mkdirSync(cfg.downloadDirectory,{recursive:true});rl=readline.createInterface({input:process.stdin,output:process.stdout});const exe=findEdgeExecutable(cfg.edgePath);need(exe,'BROWSER_NOT_FOUND','Microsoft Edge/Chromium fehlt.');
 browser=await launchBrowser({executable:exe,userDataDir:cfg.profileDirectory,startUrl:DEMO?'about:blank':cfg.comarchUrl,headless:DEMO,extraArgs:DEMO?['--disable-background-networking','--disable-component-update','--disable-sync',...(process.platform!=='win32'&&process.getuid?.()===0?['--no-sandbox']:[])]:[]});diag.browser.launched=true;({cdp}=await connectBrowser(browser.port));const page=await attachPage(cdp,t=>DEMO?t.url==='about:blank':t.url.startsWith('https://comarchecm.mercer.com/'),DEMO?30000:180000);
 if(DEMO){await injectDemo(page,{width:Number(process.env.MCR_DEMO_WIDTH||1000),scenario:DEMO_SCENARIO});}else{log('Im eigenen Bot-Edge anmelden. Kein Ticket manuell starten; der Bot beginnt in Meine Vorgaenge.');need(/^start$/i.test(await ask(rl,'Echter Lauf, maximal '+MAX+' Ticket(s). START zum Freigeben: ')),'RUN_NOT_ARMED','Kein Lauf freigegeben.');}
 const processed=new Set(journal?.completedIds()||[]);await UI.navigateToScope(page,'IN_BEARBEITUNG');
 while(diag.loop.processed<MAX){let row=null,scope=null;for(const s of ['IN_BEARBEITUNG','WARTESCHLANGE_INTL01']){const q=await UI.navigateToScope(page,s);row=q.rows.find(r=>r.descriptionBlank&&r.source.toUpperCase()==='E-MAIL'&&!processed.has(r.ticketId));if(row){scope=s;break;}}
 if(!row){diag.loop.completed=true;diag.loop.finishReason='NO_ELIGIBLE_TICKETS_IN_BOTH_LISTS';break;}
 await UI.openTicket(page,row);log('\n--- Ticket '+(diag.loop.processed+1)+' aus '+scope+' ---');await processTicket(page,mapping,rl,row,scope,cfg,journal);processed.add(row.ticketId);await sleep(400);
 }
 if(diag.loop.processed===MAX){diag.loop.completed=true;diag.loop.finishReason=PILOT?(diag.loop.forwarded?'PILOT_LIMIT_AFTER_VERIFIED_FORWARD':'PILOT_LIMIT_AFTER_VERIFIED_SAVE'):'LIMIT_AFTER_VERIFIED_ACTION';}
 if(DEMO){const b=await page.eval('window.__mcrMultirowDemo');diag.demoBrowser={sendClicks:b.sendClicks,saveClicks:b.saveClicks,forwardClicks:b.forwardClicks||0,savedLineCounts:b.savedLineCounts,trustedSends:b.trustedSends,trustedSaves:b.trustedSaves,trustedForwards:b.trustedForwards||[],savedDescriptionsMatch:b.savedDescriptions.every(s=>sha256(s)===diag.demoExpectedDescriptionSha256),savedMissingDescriptionsMatch:b.savedDescriptions.every(s=>s===NOT_FOUND_DESCRIPTION)};
   if(DEMO_SCENARIO==='missing-member')need(diag.loop.processed===2&&diag.loop.forwarded===2&&b.sendClicks===0&&b.saveClicks===2&&b.forwardClicks===2&&b.trustedForwards.every(Boolean)&&diag.demoBrowser.savedMissingDescriptionsMatch,'DEMO_FORWARD_NOT_VERIFIED','Fiktive Weiterleitung ohne E-Mail nicht nachgewiesen.');
   else need(diag.loop.processed===2&&b.sendClicks===2&&b.saveClicks===2&&b.savedLineCounts.length===2&&b.savedLineCounts.every(n=>n===2)&&b.trustedSends.every(Boolean)&&b.trustedSaves.every(Boolean)&&diag.demoBrowser.savedDescriptionsMatch,'DEMO_NOT_VERIFIED','Zwei fiktive Tickets mit echten Browserklicks nicht nachgewiesen.');}
 log('\nRUN COMPLETE | Bearbeitet: '+diag.loop.processed+' | '+diag.loop.finishReason);if(DEMO)log(DEMO_SCENARIO==='missing-member'?'PASS OFFLINE_DEMO_2_FORWARDINGS_NO_EMAIL':'PASS OFFLINE_DEMO_2_TICKETS_VERIFIED');
 }catch(e){diag.lastError=/^[A-Z0-9_]{1,80}$/.test(e.code||'')?e.code:'RUNNER_ERROR';console.error('\nSTOP '+diag.lastError+': '+e.message);process.exitCode=1;}finally{if(cfg)try{await diagnostic(cfg);}catch(e){console.error('STOP DIAGNOSTIC_WRITE_FAILED');process.exitCode=1;}try{rl?.close();}catch{}try{cdp?.close();}catch{}if(DEMO||args.has('--close-browser'))try{browser?.child?.kill();}catch{}}
}
await main();
