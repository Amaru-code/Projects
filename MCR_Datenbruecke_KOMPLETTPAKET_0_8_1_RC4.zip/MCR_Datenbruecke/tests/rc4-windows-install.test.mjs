/** RC4 regression for the Windows EPERM observed while moving stage/tests. */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {ROOT,temp,putActive} from './helpers.mjs';
import {sha256} from '../lib/core.mjs';
import {readZip} from '../lib/zip.mjs';
import {safeRelative,treeDigest,verifyPackage,verifyPrevious} from '../tools/integrity.mjs';
import {planInstall,installSoftware,journals,restoreSoftware} from '../tools/deploy.mjs';

const rc3=fs.readFileSync(path.join(ROOT,'tests/fixtures/complete-0.8.1-rc.3.zip'));
const rc3Sha='ead9a69a6b64d9c317bdcad7eb23095dbe9444a0741485e78335aa962c82780b';
function setupOld(){
 const parent=temp(),target=path.join(parent,'MCR_Datenbruecke');fs.mkdirSync(target);
 const z=readZip(rc3);
 for(const name of z.names){
  assert.ok(name.startsWith('MCR_Datenbruecke/'));
  const rel=name.slice('MCR_Datenbruecke/'.length);assert.ok(safeRelative(rel));
  const p=path.join(target,rel);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,z.get(name));
 }
 putActive(target);
 const c=path.join(target,'.runtime/beta-control');fs.mkdirSync(c,{recursive:true});
 fs.mkdirSync(path.join(target,'.runtime/edge-profile'),{recursive:true});
 fs.mkdirSync(path.join(target,'diagnostics'),{recursive:true});
 fs.writeFileSync(path.join(target,'.runtime/edge-profile/private.txt'),'edge profile sentinel');
 fs.writeFileSync(path.join(c,'last-run.json'),' {"state":"INTERRUPTED_REVIEW_REQUIRED","operation":"REAL_RUN"}\n');
 fs.writeFileSync(path.join(target,'diagnostics/local.txt'),'old diagnostic preserved');
 const before={private:treeDigest(path.join(target,'private_data')),profile:treeDigest(path.join(target,'.runtime/edge-profile')),oldManifest:sha256(fs.readFileSync(path.join(target,'MANIFEST.json'))),oldTests:treeDigest(path.join(target,'tests'))};
 return {parent,target,before,cleanup(){fs.rmSync(parent,{recursive:true,force:true});}};
}
function assertProtected(f){
 assert.equal(treeDigest(path.join(f.target,'private_data')),f.before.private);
 assert.equal(treeDigest(path.join(f.target,'.runtime/edge-profile')),f.before.profile);
 assert.equal(fs.readFileSync(path.join(f.target,'.runtime/beta-control/last-run.json'),'utf8'),' {"state":"INTERRUPTED_REVIEW_REQUIRED","operation":"REAL_RUN"}\n');
 assert.equal(fs.readFileSync(path.join(f.target,'diagnostics/local.txt'),'utf8'),'old diagnostic preserved');
}
function isStageTests(src){return src.replace(/\\/g,'/').includes('/stage/tests');}
function isOldTests(src,dst){const s=src.replace(/\\/g,'/'),d=dst.replace(/\\/g,'/');return s.endsWith('/MCR_Datenbruecke/tests')&&d.includes('/software/tests');}
const eperm=()=>Object.assign(new Error('Windows EPERM injected'),{code:'EPERM'});

test('RC3 ZIP is pinned and recognized as legal update input',()=>{
 assert.equal(sha256(rc3),rc3Sha);
 const f=setupOld();try{assert.equal(verifyPrevious(f.target).version,'0.8.1-rc.3');assertProtected(f);}finally{f.cleanup();}
});

test('RC3 -> RC4 installs by copying stage/tests and keeps it in archive',()=>{
 const f=setupOld();const rename=fs.renameSync;
 let calledStageRename=0;
 try{
  fs.renameSync=(src,dst)=>{if(isStageTests(src)){calledStageRename++;throw eperm();}return rename(src,dst);};
  const p=planInstall(ROOT,f.target);const r=installSoftware(p,{guard:()=>{}});
  assert.equal(r.state,'COMPLETE');
  assert.equal(calledStageRename,0,'installer should not attempt directory rename on stage/tests');
  assert.equal(verifyPackage(f.target).version,'0.8.1-rc.4');
  assert.ok(fs.existsSync(path.join(r.archive,'stage/tests')));
  assert.equal(treeDigest(path.join(f.target,'tests')),treeDigest(path.join(r.archive,'stage/tests')));
  assertProtected(f);
 }finally{fs.renameSync=rename;f.cleanup();}
});

test('EPERM on renaming OLD tests falls back to checked copy',()=>{
 const f=setupOld();const rename=fs.renameSync;let denies=0;
 try{
  fs.renameSync=(src,dst)=>{if(isOldTests(src,dst)){denies++;throw eperm();}return rename(src,dst);};
  const r=installSoftware(planInstall(ROOT,f.target),{guard:()=>{}});
  assert.equal(r.state,'COMPLETE');assert.ok(denies>=4);
  assert.equal(verifyPackage(f.target).version,'0.8.1-rc.4');
  assert.equal(treeDigest(path.join(r.archive,'software/tests')),f.before.oldTests);
  assertProtected(f);
 }finally{fs.renameSync=rename;f.cleanup();}
});

test('copy failure halfway through stage/tests restores full RC3 and blocks installation',()=>{
 const f=setupOld();const copy=fs.copyFileSync;let blocked=false;
 try{
  fs.copyFileSync=(src,dst,...rest)=>{
   const s=String(src).replace(/\\/g,'/'),d=String(dst).replace(/\\/g,'/');
   if(!blocked && s.includes('/stage/tests/') && d.includes('/MCR_Datenbruecke/tests/') ){
    blocked=true;throw eperm();
   }
   return copy(src,dst,...rest);
  };
  let error;
  try{installSoftware(planInstall(ROOT,f.target),{guard:()=>{}});}catch(e){error=e;}
  assert.equal(blocked,true,'copy failure was injected');
  assert.equal(error?.code,'EPERM');assert.equal(error?.rollback,'SOFTWARE_RESTORED');
  assert.equal(verifyPrevious(f.target).version,'0.8.1-rc.3');
  assert.equal(sha256(fs.readFileSync(path.join(f.target,'MANIFEST.json'))),f.before.oldManifest);
  assert.equal(treeDigest(path.join(f.target,'tests')),f.before.oldTests);
  assert.equal(fs.existsSync(path.join(f.target,'BETA_UMSTELLUNG_LAEUFT.txt')),false);
  assertProtected(f);
 }finally{fs.copyFileSync=copy;f.cleanup();}
});

test('RC4 installation has a verified rollback to original RC3 (including pending state)',()=>{
 const f=setupOld();try{
  const r=installSoftware(planInstall(ROOT,f.target),{guard:()=>{}});
  assert.equal(verifyPackage(f.target).version,'0.8.1-rc.4');
  assert.equal(restoreSoftware(journals(f.target)[0]).state,'ROLLED_BACK');
  assert.equal(verifyPrevious(f.target).version,'0.8.1-rc.3');
  assert.equal(sha256(fs.readFileSync(path.join(f.target,'MANIFEST.json'))),f.before.oldManifest);
  assert.equal(treeDigest(path.join(f.target,'tests')),f.before.oldTests);
  assertProtected(f);
 }finally{f.cleanup();}
});
