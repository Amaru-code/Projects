/** Regressions for the exact user-reported startup stop. All target folders and
 * user data below are synthetic. The RC1 ZIP is byte-identical release data. */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {spawnSync} from 'node:child_process';
import {ROOT,temp,putActive} from './helpers.mjs';
import {sha256} from '../lib/core.mjs';
import {readZip} from '../lib/zip.mjs';
import {verifyPackage,verifyPrevious,treeDigest,safeRelative} from '../tools/integrity.mjs';
import {planInstall,installSoftware,restoreSoftware,journals} from '../tools/deploy.mjs';

const rc2Zip=fs.readFileSync(path.join(ROOT,'tests/fixtures/complete-0.8.1-rc.2.zip'));
const rc1Zip=fs.readFileSync(path.join(ROOT,'tests/fixtures/complete-0.8.1-rc.1.zip'));
const oldMail=fs.readFileSync(path.join(ROOT,'tests/fixtures/beta4-mail-download.cjs.txt'));
const mailSha='7c2d9d444fc241fe4cb2335df12039a201ef3c27d9b23f9692c2662d3d651ce2';
const protectedNames=['private_data','.runtime','diagnostics','config','v0.8 beta.zip'];
function fixture({mixed=true,current=false}={}){
  const parent=temp(),target=path.join(parent,'MCR_Datenbruecke');fs.mkdirSync(target);
  if(current){
    const m=JSON.parse(fs.readFileSync(path.join(ROOT,'MANIFEST.json')));
    for(const rel of [...m.payload.map(x=>x.path),'MANIFEST.json','SHA256SUMS.txt']){
      const out=path.join(target,rel);fs.mkdirSync(path.dirname(out),{recursive:true});fs.copyFileSync(path.join(ROOT,rel),out);
    }
  }else{
    assert.equal(sha256(rc1Zip),'138b5b89d954b3c2a81939ae76a6f6b303118c52f907169ba176c280cebeebe0');
    const z=readZip(rc1Zip);
    for(const n of z.names){assert.ok(n.startsWith('MCR_Datenbruecke/'));const rel=n.slice('MCR_Datenbruecke/'.length);assert.ok(safeRelative(rel));const f=path.join(target,rel);fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,z.get(n));}
  }
  putActive(target);
  fs.mkdirSync(path.join(target,'.runtime/beta-control'),{recursive:true});
  fs.mkdirSync(path.join(target,'.runtime/edge-profile'),{recursive:true});
  fs.mkdirSync(path.join(target,'diagnostics'),{recursive:true});
  fs.writeFileSync(path.join(target,'.runtime/beta-control/last-run.json'),'{"state":"STOP_REVIEW_REQUIRED","operation":"REAL_RUN"}\n');
  fs.writeFileSync(path.join(target,'.runtime/beta-control/ticket-ledger.json'),'{"schema":"MCR_TICKET_LEDGER_V1","tickets":{"synthetic":{"state":"SEND_INTENT"}}}\n');
  fs.writeFileSync(path.join(target,'.runtime/edge-profile/KEEP_PRIVATE.txt'),'profile sentinel; not copied');
  fs.writeFileSync(path.join(target,'diagnostics/KEEP.txt'),'earlier diagnostics');
  fs.writeFileSync(path.join(target,'v0.8 beta.zip'),'local archive sentinel');
  if(mixed)fs.writeFileSync(path.join(target,'lib/mail-download.cjs'),oldMail);
  const protectedBefore=Object.fromEntries(protectedNames.map(n=>[n,treeDigest(path.join(target,n))]));
  return {parent,target,protectedBefore,cleanup(){fs.rmSync(parent,{recursive:true,force:true});}};
}
function preserve(f,{afterInstall=false}={}){
  for(const [n,h] of Object.entries(f.protectedBefore)){
    // Installer may add its own receipt/lock. Existing .runtime data must remain.
    if(afterInstall&&n==='.runtime')continue;
    assert.equal(treeDigest(path.join(f.target,n)),h,n);
  }
  assert.equal(fs.readFileSync(path.join(f.target,'.runtime/beta-control/last-run.json'),'utf8'),'{"state":"STOP_REVIEW_REQUIRED","operation":"REAL_RUN"}\n');
  assert.equal(fs.readFileSync(path.join(f.target,'.runtime/beta-control/ticket-ledger.json'),'utf8'),'{"schema":"MCR_TICKET_LEDGER_V1","tickets":{"synthetic":{"state":"SEND_INTENT"}}}\n');
  assert.equal(fs.readFileSync(path.join(f.target,'.runtime/edge-profile/KEEP_PRIVATE.txt'),'utf8'),'profile sentinel; not copied');
}
function modify(f,rel,fn){const p=path.join(f.target,rel);fs.writeFileSync(p,fn(fs.readFileSync(p)));}

test('exact Beta4 mail-download.cjs reference has its original bytes/hash',()=>{assert.equal(oldMail.length,1528);assert.equal(sha256(oldMail),mailSha);});
test('registry covers all fifteen documented obsolete Beta4 code/data files',()=>{const r=JSON.parse(fs.readFileSync(path.join(ROOT,'tools/reference/beta4-residuals.json')));assert.equal(r.files.length,15);assert.equal(new Set(r.files.map(x=>x.path)).size,15);for(const f of r.files){assert.ok(safeRelative(f.path));assert.match(f.sha256,/^[a-f0-9]{64}$/);assert.ok(Number.isInteger(f.bytes)&&f.bytes>0);}});
test('published RC1 ZIP plus original old file reproduces exact UNSEALED_CODE',async()=>{const f=fixture();try{const orig=await import(pathToFileURL(path.join(f.target,'tools/integrity.mjs')));assert.throws(()=>orig.verifyPackage(f.target),e=>e.code==='UNSEALED_CODE'&&e.message==='Unerwartete Programmdatei: lib/mail-download.cjs');preserve(f);}finally{f.cleanup();}});
test('clean published RC1 recognized as upgrade input',()=>{const f=fixture({mixed:false});try{const x=verifyPrevious(f.target);assert.equal(x.version,'0.8.1-rc.1');assert.equal(x.state,'COMPLETE_RELEASE_VERIFIED');assert.deepEqual(x.legacyResiduals,[]);preserve(f);}finally{f.cleanup();}});
test('mixed RC1 is recognized read-only and only for software update',()=>{const f=fixture();try{const before=treeDigest(f.target),x=verifyPrevious(f.target);assert.equal(x.authorization,'SOFTWARE_UPDATE_ONLY');assert.equal(x.state,'COMPLETE_WITH_VERIFIED_BETA4_RESIDUALS');assert.deepEqual(x.legacyResiduals.map(x=>x.path),['lib/mail-download.cjs']);assert.equal(x.legacyResiduals[0].sha256,mailSha);assert.equal(treeDigest(f.target),before);preserve(f);}finally{f.cleanup();}});
test('normal execution verifier still rejects extra legacy code',()=>{const f=fixture({current:true});try{assert.throws(()=>verifyPackage(f.target),{code:'UNSEALED_CODE'});preserve(f);}finally{f.cleanup();}});
test('source with known legacy leftovers is not accepted as new release',()=>{const f=fixture({current:true}),target=fixture({mixed:false});try{assert.throws(()=>planInstall(f.target,target.target),{code:'UNSEALED_CODE'});preserve(f);preserve(target);}finally{f.cleanup();target.cleanup();}});
test('mixed RC1 installs completely, archives old file and preserves private state',()=>{const f=fixture();try{const p=planInstall(ROOT,f.target);assert.equal(p.old.legacyResiduals.length,1);const r=installSoftware(p,{guard:()=>{}});assert.equal(r.state,'COMPLETE');assert.equal(verifyPackage(f.target).version,'0.8.1-rc.4');assert.equal(fs.existsSync(path.join(f.target,'lib/mail-download.cjs')),false);assert.equal(sha256(fs.readFileSync(path.join(r.archive,'software/lib/mail-download.cjs'))),mailSha);preserve(f,{afterInstall:true});assert.equal(fs.existsSync(path.join(r.archive,'software/private_data')),false);assert.equal(fs.existsSync(path.join(r.archive,'software/.runtime')),false);}finally{f.cleanup();}});
test('clean RC1-to-RC2 upgrade requires no old download or extra-file bypass',()=>{const f=fixture({mixed:false});try{const r=installSoftware(planInstall(ROOT,f.target),{guard:()=>{}});assert.equal(r.state,'COMPLETE');verifyPackage(f.target);preserve(f,{afterInstall:true});}finally{f.cleanup();}});

test('original released RC2 ZIP upgrades to RC4 without moving active mapping or browser profile',()=>{
 assert.equal(sha256(rc2Zip),'6e89fe5fd4922513c4f6e8ecccfd8d82e8ceec68ce320328dab6db080de078b3');
 const parent=temp(),target=path.join(parent,'MCR_Datenbruecke');fs.mkdirSync(target);
 try{
  const z=readZip(rc2Zip);for(const name of z.names){assert.ok(name.startsWith('MCR_Datenbruecke/'));const rel=name.slice('MCR_Datenbruecke/'.length);assert.ok(safeRelative(rel));const to=path.join(target,rel);fs.mkdirSync(path.dirname(to),{recursive:true});fs.writeFileSync(to,z.get(name));}
  putActive(target);fs.mkdirSync(path.join(target,'.runtime/edge-profile'),{recursive:true});fs.mkdirSync(path.join(target,'.runtime/beta-control'),{recursive:true});
  const profile=path.join(target,'.runtime/edge-profile/PRIVATE_SENTINEL');fs.writeFileSync(profile,'KEEP_BROWSER_PROFILE');
  fs.writeFileSync(path.join(target,'.runtime/beta-control/last-run.json'),'{"state":"STOP_REVIEW_REQUIRED","operation":"REAL_RUN"}\n');
  const m=verifyPrevious(target);assert.equal(m.version,'0.8.1-rc.2');assert.equal(m.legacyResiduals.length,0);
  const oldHash=sha256(fs.readFileSync(path.join(target,'private_data/active-mapping.json')));
  const r=installSoftware(planInstall(ROOT,target),{guard:()=>{}});
  assert.equal(r.state,'COMPLETE');assert.equal(verifyPackage(target).version,'0.8.1-rc.4');
  assert.equal(sha256(fs.readFileSync(path.join(target,'private_data/active-mapping.json'))),oldHash);
  assert.equal(fs.readFileSync(profile,'utf8'),'KEEP_BROWSER_PROFILE');
  assert.equal(JSON.parse(fs.readFileSync(path.join(target,'.runtime/beta-control/last-run.json'))).state,'STOP_REVIEW_REQUIRED');
  assert.equal(restoreSoftware(journals(target)[0]).state,'ROLLED_BACK');
  assert.equal(verifyPrevious(target).version,'0.8.1-rc.2');
  assert.equal(fs.readFileSync(profile,'utf8'),'KEEP_BROWSER_PROFILE');
 }finally{fs.rmSync(parent,{recursive:true,force:true});}
});

test('same-release overlay can be replaced from clean package, never run mixed',()=>{const f=fixture({current:true});try{assert.throws(()=>verifyPackage(f.target),{code:'UNSEALED_CODE'});assert.equal(verifyPrevious(f.target).legacyResiduals.length,1);installSoftware(planInstall(ROOT,f.target),{guard:()=>{}});verifyPackage(f.target);preserve(f,{afterInstall:true});}finally{f.cleanup();}});
test('rollback preserves the exact original mixed source, not a false runnable claim',()=>{const f=fixture();try{const p=planInstall(ROOT,f.target);installSoftware(p,{guard:()=>{}});const r=restoreSoftware(journals(f.target)[0]);assert.equal(r.state,'ROLLED_BACK');for(const x of p.oldItems)assert.equal(treeDigest(path.join(f.target,x.name)),x.hash);assert.equal(verifyPrevious(f.target).state,'COMPLETE_WITH_VERIFIED_BETA4_RESIDUALS');preserve(f,{afterInstall:true});}finally{f.cleanup();}});
for(const mutation of ['append','same-size'])test('changed old file is rejected before writes: '+mutation,()=>{const f=fixture();try{modify(f,'lib/mail-download.cjs',b=>mutation==='append'?Buffer.concat([b,Buffer.from(' ') ]):Buffer.concat([Buffer.from('X'),b.subarray(1)]));const before=treeDigest(f.target);assert.throws(()=>planInstall(ROOT,f.target),{code:'LEGACY_RESIDUAL_CHANGED'});assert.equal(treeDigest(f.target),before);preserve(f);}finally{f.cleanup();}});
for(const rel of ['lib/unknown.cjs','tools/nested/unknown.mjs','lib/elsewhere/mail-download.cjs'])test('unknown path remains blocked: '+rel,()=>{const f=fixture();try{const p=path.join(f.target,rel);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,oldMail);const before=treeDigest(f.target);assert.throws(()=>planInstall(ROOT,f.target),{code:'UNSEALED_CODE'});assert.equal(treeDigest(f.target),before);}finally{f.cleanup();}});
test('modified sealed RC1 runner is not reinterpreted as a legacy leftover',()=>{const f=fixture();try{modify(f,'src/local-bot-full-run.mjs',b=>Buffer.concat([Buffer.from('X'),b.subarray(1)]));assert.throws(()=>planInstall(ROOT,f.target),{code:'PACKAGE_HASH'});preserve(f);}finally{f.cleanup();}});
test('modified old manifest cannot whitelist its own unknown code',()=>{const f=fixture();try{modify(f,'MANIFEST.json',b=>Buffer.from(b.toString().replace('"dataPolicy"','"unapprovedDataPolicy"')));assert.throws(()=>planInstall(ROOT,f.target),{code:'PREVIOUS_MANIFEST_CHANGED'});preserve(f);}finally{f.cleanup();}});
test('unsupported old release version fails closed',()=>{const f=fixture();try{modify(f,'MANIFEST.json',b=>Buffer.from(b.toString().replace('0.8.1-rc.1','0.8.0-unknown')));assert.throws(()=>planInstall(ROOT,f.target),{code:'PREVIOUS_COMPLETE_VERSION'});preserve(f);}finally{f.cleanup();}});
test('known leftover changed after preview prevents installation',()=>{const f=fixture();try{const p=planInstall(ROOT,f.target);fs.appendFileSync(path.join(f.target,'lib/mail-download.cjs'),' ');assert.throws(()=>installSoftware(p,{guard:()=>{}}),{code:'LEGACY_RESIDUAL_CHANGED'});preserve(f);}finally{f.cleanup();}});
test('unknown root starter still prevents a migration',()=>{const f=fixture();try{fs.writeFileSync(path.join(f.target,'CUSTOM.cmd'),'private operator program');assert.throws(()=>planInstall(ROOT,f.target),{code:'UNKNOWN_ROOT_PROGRAM'});preserve(f);}finally{f.cleanup();}});
test('a legacy-file symlink cannot be archived as trusted source',{skip:process.platform==='win32'},()=>{const f=fixture();try{const p=path.join(f.target,'lib/mail-download.cjs'),outside=path.join(f.parent,'outside.txt');fs.writeFileSync(outside,oldMail);fs.unlinkSync(p);fs.symlinkSync(outside,p);assert.throws(()=>planInstall(ROOT,f.target),{code:'LINK_BLOCKED'});preserve(f);}finally{f.cleanup();}});
test('existing operation lock is not discarded by the update',()=>{const f=fixture();try{const lf=path.join(f.target,'.runtime/beta-control/operation.lock.json');fs.writeFileSync(lf,'{"operation":"REAL_RUN","pid":123,"token":"preserve"}');const p=planInstall(ROOT,f.target);assert.throws(()=>installSoftware(p,{guard:()=>{}}),{code:'OPERATION_LOCKED'});assert.equal(fs.readFileSync(lf,'utf8'),'{"operation":"REAL_RUN","pid":123,"token":"preserve"}');}finally{f.cleanup();}});
for(const phase of ['OLD','NEW'])test('real RC1 mixed-source move failure restores all exact old bytes: '+phase,()=>{const f=fixture();try{const p=planInstall(ROOT,f.target);let n=0;assert.throws(()=>installSoftware(p,{guard:()=>{},fault(kind){if(kind===phase&&++n===3)throw Object.assign(new Error('injected'),{code:'TEST_MOVE_FAILURE'});}}),e=>e.code==='TEST_MOVE_FAILURE'&&e.rollback==='SOFTWARE_RESTORED');for(const x of p.oldItems)assert.equal(treeDigest(path.join(f.target,x.name)),x.hash);assert.equal(verifyPrevious(f.target).legacyResiduals.length,1);preserve(f,{afterInstall:true});}finally{f.cleanup();}});

test('actual CLI: original mixed startup stops, installed RC2 main menu starts',()=>{const f=fixture();try{const env={...process.env};delete env.NODE_OPTIONS;delete env.NODE_PATH;const run=()=>spawnSync(process.execPath,[path.join(f.target,'tools/cli.mjs'),'--menu'],{cwd:f.target,input:'0\n',encoding:'utf8',timeout:15000,env});const before=run();assert.equal(before.status,1);assert.match(before.stderr,/STOP UNSEALED_CODE: Unerwartete Programmdatei: lib\/mail-download\.cjs/);installSoftware(planInstall(ROOT,f.target),{guard:()=>{}});const after=run();assert.equal(after.status,0,after.stderr);assert.match(after.stdout,/MCR DATENBRUECKE 0\.8\.1-rc\.4/);assert.doesNotMatch(after.stderr,/UNSEALED_CODE/);preserve(f,{afterInstall:true});}finally{f.cleanup();}});
